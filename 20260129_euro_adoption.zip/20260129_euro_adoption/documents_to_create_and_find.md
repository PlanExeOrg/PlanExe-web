# Documents to Create

## Create Document 1: Project Charter: DKK to EUR Transition (Builder's Blueprint)

**ID**: d82255ac-ff0a-483a-9a03-e131da63edfc

**Description**: Foundational project management document defining scope, objectives (SMART criteria), high-level milestones (4-8 years), resource baseline (DKK 15-25B estimate), primary dependencies, and alignment with the 'Builder's Blueprint' strategy. Primary audience is the Joint Ministerial Consultative Body.

**Responsible Role Type**: Chief Transition Architect / Project Director

**Primary Template**: PMI Project Charter Template

**Secondary Template**: Governmental Transition Program Template

**Steps to Create**:

- Finalize SMART goals and objectives based on project scope documents.
- Define the initial structure and membership of the Joint Ministerial Consultative Body.
- Establish the initial, high-level budget range and funding stability requirements (including inflation indexation strategy).
- Obtain formal authorization signatures from core Ministerial stakeholders.

**Approval Authorities**: Joint Ministerial Consultative Body (Chaired by Prime Minister's Office)

**Essential Information**:

- Clearly define the scope, objectives (SMART criteria), and success metrics for the entire DKK to EUR transition project.
- Explicitly confirm alignment with the chosen 'Builder's Blueprint' strategy, detailing how sequencing (deferring opt-out repeal until post-ERM II confirmation) is maintained.
- Document the initial high-level timeline (confirming the 4 to 8-year bound, with Q1 2030 earliest referendum target), and primary dependency sequencing.
- Establish and document the initial resource baseline: the estimated budget range (DKK 15–25 Billion) and the specific funding stability mechanism (e.g., inflation indexation review mandate).
- Formally identify and define the structure and membership of the 'Joint Ministerial Consultative Body' (JMCB) as the primary governance entity.
- List the eight critical dependencies, with special emphasis on securing the EU agreement for the Opt-Out Resolution Mechanism Process.

**Risks of Poor Quality**:

- Lack of formal authorization leads to immediate stakeholder misalignment regarding project mandate and resource commitment.
- Vague scope definition results in scope creep, especially concerning secondary decisions not explicitly prioritized in the 'Builder's Blueprint'.
- If funding baselines are not finalized, subsequent inflation risk (Issue 2 Review finding) cannot be effectively mitigated, leading to budget shortfalls mid-project.
- Misalignment on governance structure (JMCB) could lead to decision-making bottlenecks (Risk 9) during critical convergence phases.
- Failure to link the Charter to the *Builder's Blueprint* compromises its ability to defend project sequencing choices against 'Pioneer's Path' advocates.

**Worst Case Scenario**: The project proceeds without a formally agreed-upon scope and resource baseline, leading to political confusion over mandate authority, resource contention between technical integration and public readiness efforts, and ultimately forcing a major timeline reset or underfunding of critical convergence milestones, jeopardizing the ability to meet ECB criteria.

**Best Case Scenario**: The Charter provides immediate, authoritative clarity across all core Ministerial stakeholders, immediately unlocking the budget, finalizing the JMCB structure, and securing commitment to the necessary long-term (6+ years) operational sequencing required by the 'Builder's Blueprint', thereby accelerating the start of key parallel workstreams like the Shadow Integration Team.

**Fallback Alternative Approaches**:

- If full consensus on budget figures (DKK 15-25B) is not immediately achieved, utilize the mid-point (DKK 20B) for initial planning reference and require a mandatory 90-day review for budget indexation protocol finalization instead of Charter signature.
- If the JMCB membership cannot be finalized, proceed with the Charter signed by the Prime Minister's Office and the Ministers of Finance and Justice, granting them delegated authority to establish interim governance until the full body is seated.
- If SMART goal finalization is delayed, utilize the Goal Statement from 'project-plan.md' as the default baseline, pending formal review within 30 days.

## Create Document 2: Opt-Out Resolution & EU Negotiation Strategy Framework

**ID**: fe94fb70-e99c-4701-94da-755527818159

**Description**: High-level framework detailing the chosen legal pathway (Extraordinary Council Session focus) for lifting the DKK opt-out, including conditional negotiation triggers based on ERM II performance markers (12-month stability). Primary audience is the Senior EU Legal & Treaty Negotiator and the Chief Transition Architect.

**Responsible Role Type**: Senior EU Legal & Treaty Negotiator

**Primary Template**: International Treaty Negotiation Strategy Template

**Secondary Template**: Legal Pathway Analysis Document

**Steps to Create**:

- Conduct feasibility assessment for Protocol Amendment vs. full Treaty Review.
- Define the precise 12-month ERM II stability markers that trigger formal EU negotiation advancement.
- Draft initial high-level talking points for engagement with the European Commission and relevant Member States.
- Integrate findings from the Dual-Path Legal Contingency Mandate planning.

**Approval Authorities**: Chief Transition Architect, Ministry of Justice

**Essential Information**:

- Define the prerequisites (legal basis, constitutional review status) for initiating the Extraordinary European Council Session (ECS) request (Strategy 4.2).
- Quantify the specific internal DKK exchange rate stability markers (e.g., volatility range, interest rate alignment) within the *first* 12 months of ERM II participation that will trigger *formal* advancement of the ECS negotiation.
- Detail the content of the 'Dual-Path Legal Contingency Mandate' regarding procedural steps and penalties if the referendum fails, specifically addressing the status of preparatory domestic legislation.
- List the three key Member States (MS) identified for securing bilateral assurances concurrently with the ECS request, based on negotiation risk analysis.
- Explicitly map the required documentation deliverables from Danmarks Nationalbank and the Ministry of Justice necessary to support the ECS submission.

**Risks of Poor Quality**:

- Failure to define clear 12-month ERM II triggers leads to diplomatic stagnation, as the Foreign Office lacks concrete milestones to advance the ECS request.
- Incomplete Dual-Path Legal Contingency Mandate exposes the project to significant financial liabilities (DKK 500M–1.5B) if the referendum fails, due to contested provisional legislation.
- Lack of alignment between legal strategy and diplomatic priorities results in conflicting messaging to the European Commission, jeopardizing the targeted 'protocol amendment' approach.
- Misalignment with Ministry of Justice requirements results in rejection of the legal strategy by domestic courts, stalling all progress towards the referendum.

**Worst Case Scenario**: The EU requires political alignment (opt-out certainty) as a prerequisite, forcing negotiations to halt entirely post-ERM II stability confirmation, resulting in a project timeline extension past 8 years and the likely collapse of the referendum mandate effectiveness due to political fatigue.

**Best Case Scenario**: Crystal-clear decision points (12-month ERM II signal) enable the Chief Transition Architect to transition from conditional diplomatic engagement to formal treaty negotiation within 15 months of ERM II entry, securing the legal foundation early, minimizing Risk 1, and enabling a 2030 referendum target.

**Fallback Alternative Approaches**:

- If ECS feasibility is immediately questioned by the EU, pivot to drafting domestic legislation attempting to utilize existing treaty interpretations for opt-out suspension, leveraging the contingent legal mandate structure immediately.
- If diplomatic engagement stalls before 12 months, authorize a targeted, secret 'Pre-Protocol' engagement track with the European Parliament leadership to secure political endorsement, running parallel to Central Bank system readiness.
- If Ministry of Justice flags constitutional roadblocks to the dual path, immediately simplify the contractual re-denomination strategy (Decision 7) to only mandate immediate rounding, accepting higher governance overhead to reduce legal drafting complexity.

## Create Document 3: Initial ERM II Entry and Convergence Alignment Plan

**ID**: 01724a50-0737-4922-ae41-cca5cfe6fe7a

**Description**: Strategic plan outlining the 'Maintain Current Strict Policy' approach pre-ERM II entry, modeling the required DKK parity maintenance, and establishing initial benchmarks for meeting primary Maastricht criteria during the mandatory convergence tracking period. Primary audience: Macroeconomic Convergence & ERM Strategist, Danmarks Nationalbank.

**Responsible Role Type**: Macroeconomic Convergence & ERM Strategist

**Primary Template**: Monetary Policy Transition Scenario Plan

**Secondary Template**: ECB Convergence Checklist Pre-Audit Benchmark

**Steps to Create**:

- Model the implications of maintaining the current DKK policy as informal ERM alignment.
- Establish benchmarks for inflation, deficit, and interest rate convergence metrics for the upcoming ERM II window.
- Define the initial operational limits for the DKK fluctuation band upon formal ERM II entry.
- Liaise with the Central Bank Technical Integration Lead regarding data reporting needs based on this strategy.

**Approval Authorities**: Joint Ministerial Consultative Body

**Essential Information**:

- Define the specific DKK parity maintenance strategy and modeling results that treat the current DKK management as the 'informal ERM II alignment mechanism' (Decision 2, Choice 1).
- Establish the precise, quantitative benchmarks (e.g., inflation rate ceiling, deficit limit) Danmarks Nationalbank must meet during the convergence tracking period, aligned with primary Maastricht criteria.
- Detail the proposed initial operational limits and fluctuation band commitment for the DKK upon formal ERM II entry, consistent with the conservative stance of the 'Builder's Blueprint'.
- Identify specific data reporting requirements needed by the ECB/Eurosystem based on the chosen convergence strategy, linking directly to Central Bank Operational Integration Timeline (Decision 8).
- Quantify the projected impact of the current strict DKK policy on immediate export competitiveness and domestic industrial short-term shock (Trade-Off analysis from Decision 2).
- Document the linkage between this alignment plan and the requirements set by the Opt-Out Resolution Mechanism Selection (Decision 4, Strategy 4.2).

**Risks of Poor Quality**:

- Inaccurate convergence modeling could lead to the DKK entering ERM II at an unsustainable parity, resulting in immediate speculative pressure or requiring rapid, destabilizing interest rate hikes.
- Failure to align reporting standards precisely with ECB needs risks delaying formal ERM II entry approval, directly jeopardizing the fixed 24-month convergence window assumption (Risk 3).
- If the document masks the required domestic fiscal adjustments needed to meet convergence criteria, it creates a high political risk of last-minute austerity measures causing public backlash (Risk 2).
- Lack of clarity on initial fluctuation band commitment (post-ERM II entry) creates uncertainty for commercial debt markets, compounding issues for Commercial Contract Re-denomination Strategy.

**Worst Case Scenario**: The plan miscalculates the necessary adjustments for convergence, forcing the National Bank to either abandon the current exchange rate policy prematurely (causing market chaos) or failing the ECB audit, leading to a multi-year delay in ERM II entry and significant erosion of the committed DKK 15-25 Billion budget due to prolonged planning costs.

**Best Case Scenario**: The document provides a robust, auditable benchmark showing immediate compliance pathways, enabling prompt acceptance by the ECB into ERM II, thereby securing the foundational economic requirement needed to schedule the national referendum securely and moving the project reliably towards the Q1 2030 target timeline.

**Fallback Alternative Approaches**:

- Utilize the ECB's existing published 'Roadmap for Countries Preparing to Adopt the Euro' as a minimum acceptable template, focusing only on aligning statistical reporting requirements first.
- Commission an emergency 4-week rapid simulation workshop focused solely on modeling the DKK parity implications under the widest possible ERM II fluctuation band, using the results as a placeholder until full modeling is complete.
- Develop a simplified 'Minimum Viable Guideline' focusing only on the three highest-impact convergence criteria (inflation, deficit, stability), requiring sign-off from the National Bank Director before broader ministerial review.

## Create Document 4: Governance Architecture Charter & Delegation Matrix

**ID**: c90cd6a3-b027-48b9-8b37-d1e8e54495d3

**Description**: Document formally establishing the Joint Ministerial Consultative Body, defining its mandate, decision escalation protocols (including consensus definition), and setting delegation thresholds for the Chief Transition Architect and operational leads (e.g., specialized directive authority below DKK 50M). Primary audience: All Role Leads.

**Responsible Role Type**: Chief Transition Architect / Project Director

**Primary Template**: Inter-Agency Governance Charter

**Secondary Template**: Delegation of Authority Matrix (Public Sector)

**Steps to Create**:

- Formalize membership, frequency, and reporting lines for the Joint Ministerial Consultative Body.
- Define the specific thresholds for when operational leads (e.g., Technical Lead, Logistics Coordinator) can issue binding directives without full consensus.
- Document the process for annual review and adjustment of delegation thresholds.
- Secure sign-off from all participating Ministry Heads.

**Approval Authorities**: Prime Minister's Office

**Essential Information**:

- Define the precise mandate and scope of the Joint Ministerial Consultative Body (JMCB), emphasizing its role in cross-cutting policy change consensus.
- Establish a clear, quantitative threshold (e.g., DKK 50 million budget directive authority) below which operational leads (Chief Transition Architect, Technical Lead) can issue binding directives without full JMCB consensus.
- Document the formal escalation path for directives exceeding the delegation threshold, detailing required steps (e.g., 7-day ministerial review window) before recourse to the Prime Minister's Office.
- Specify the roles and required representation from the Ministry of Finance, Justice, and Business within the JMCB.
- Detail the mechanism and schedule for the annual review and required re-approval of delegation thresholds by all participating Ministry Heads.

**Risks of Poor Quality**:

- Decision-making paralysis within the JMCB if consensus definition is unclear, leading to cascading delays across IT integration and legal preparation timelines (Risk 9).
- Operational leads issuing binding directives that violate high-level policy (e.g., monetary strategy), leading to technical or legal non-compliance with ECB requirements.
- Budgetary overruns due to lack of clear monetary constraints on operational expenditures below the consensus threshold.
- Conflict between Ministries if the framework for consensus definition or conflict resolution (escalation) is not explicitly defined.

**Worst Case Scenario**: The JMCB becomes a constant bottleneck, requiring ministerial sign-off for routine technical or logistical directives, causing failure to meet ERM II integration milestones or missing critical deadlines set by the slower 'Consolidator's Course' timeline, potentially pushing the project timeline beyond the 8-year goal and resulting in high political capital burnout.

**Best Case Scenario**: Expedited decision velocity is achieved through clear delegation, allowing operational teams to execute technical convergence (Risk 4 mitigation) and logistical synchronization (Risk 5 mitigation) promptly, securing the 'Builder's Blueprint' progress benchmark without sacrificing Ministerial oversight on high-stakes political/legal matters.

**Fallback Alternative Approaches**:

- If ministerial consensus on delegation thresholds proves slow, default to a temporary, highly centralized authority structure (similar to the 'Pioneer's Path' model) for the first 12 months, strictly limited to operational execution directives only.
- Develop a 'Tiered Directive Authority' matrix based on the complexity domain (Finance, Legal, Tech) where the relevant Ministry Head pre-approves the director *within their domain* to issue directives up to a lower threshold (e.g., DKK 10M) without full JMCB vote.
- Utilize the Chief Transition Architect to draft and enforce an emergency, time-bound delegation matrix, pending formal JMCB ratification within 30 days.

## Create Document 5: Initial Risk Register & Mitigation Action Plan (Priority Focus)

**ID**: a6b9d284-ddd2-4e2a-bde5-ae325d469b36

**Description**: Initial documentation of the top 9 identified risks, mapping residual risks to specific mitigation actions derived from the strategic decisions and expert feedback (e.g., establishing Shadow Team, launching conditional negotiation track). Primary audience: All Role Leads.

**Responsible Role Type**: Fiscal Oversight & Budget Manager

**Primary Template**: IPMA Standard Risk Register

**Secondary Template**: Risk & Mitigation Action Tracking Log

**Steps to Create**:

- Populate initial risk scores (L/S) based on provided analysis.
- Map each mitigation strategy (e.g., Shadow Team, Indexation Mandate) to a responsible role and a firm deadline (e.g., Q3 2026).
- Establish the protocol for escalating unmitigated or materialized risks to the Joint Ministerial Consultative Body.
- Verify budget allocation for initial risk mitigation steps (e.g., DKK 25M for 'Killer App').

**Approval Authorities**: Chief Transition Architect

**Essential Information**:

- List the top 9 identified risks (Regulatory, Financial, Technical, Social/Operational).
- Detail the specific mitigation action explicitly linked to **each** of the 9 risks, referencing the chosen strategic decisions (e.g., defining the function of the 'Shadow Integration Team' or the reliance on 'automatic rounding' legislation).
- Quantify the impact metrics associated with each risk (Likelihood/Severity scores).
- Define the clear mapping between each mitigation action and a responsible role/deadline (e.g., who owns the budget for indexation, when the diplomatic track must commence).
- Explicitly define the protocol for escalating unmitigated or materialized risks to the 'Joint Ministerial Consultative Body' (Decision 5.2).
- Quantify the required initial budget allocation for high-priority mitigation efforts (e.g., referencing the DKK 25M for 'Killer App' or DKK 50M contingency).
- Incorporate corrective actions identified during the strategic review (e.g., immediate parallel diplomatic engagement, mandate for inflation-indexed budget reviews, dual-path legal contingency drafting).

**Risks of Poor Quality**:

- Failure to prioritize risks leads to misallocation of limited political and financial capital, focusing on low-impact issues.
- Vague mapping to mitigation actions means no single owner is accountable, leading to mitigation failures that leave critical risks (like referendum failure or convergence block) unaddressed.
- Inaccurate quantification of required funds for mitigation (budget shortfalls) results in the inability to execute planned risk reduction strategies, causing critical budget execution delays.
- Lack of a clear escalation protocol means that materialized risks will cause decision paralysis at the ministerial level, directly halting progress on convergence timelines.

**Worst Case Scenario**: Critical risks (e.g., EU refusing the negotiated sequencing, or the budget eroding due to unindexed inflation) materialize without clear, pre-defined escalation paths, leading to immediate political deadlock, the termination of the 'Builder's Blueprint' strategy, and significant sunk cost write-offs (potentially exceeding DKK 1 Billion) as the project collapses or stalls indefinitely beyond the 8-year window.

**Best Case Scenario**: A highly structured, actionable register allows the Fiscal Oversight Manager to immediately resource and track all necessary preparatory work (Shadow Team setup, diplomatic track initiation, budget indexation implementation), ensuring that the project proceeds with maximum political certainty derived from mitigated technical and public acceptance risks, aligning execution with the 4-8 year target window.

**Fallback Alternative Approaches**:

- Develop a simplified 3-risk register (Focusing only on Legal/EU Accord, Convergence Failure, Referendum Failure) using a RACI matrix instead of detailed deadlines, to be completed within 7 days.
- If detailed budget allocation is blocked, prioritize documentation detailing the required staff/expertise secondments (Assumption 3) as a proxy for resource needs, deferring final cost approval.
- Instead of mapping to all 9 risks, initially focus only on documenting the mitigation actions directly tied to the five Critical Decisions chosen under the 'Builder's Blueprint' strategy.


# Documents to Find

## Find Document 1: Existing EU Treaty Text Regarding Opt-Out Mechanisms (Article 16, Protocol No. 30, etc.)

**ID**: 9bd6c734-c945-436b-8ebc-25287fbbda23

**Description**: Raw legal text governing the existing DKK opt-out concerning the Euro. Essential for the Senior EU Legal & Treaty Negotiator to model potential amendment routes (Decision 4) and scope required for negotiation.

**Recency Requirement**: Current consolidated text is essential.

**Responsible Role Type**: Senior EU Legal & Treaty Negotiator

**Steps to Find**:

- Search official EUR-Lex portal for latest consolidated Treaties of the European Union.
- Consult historical Danish protocols concerning the Edinburgh Agreement.
- Directly source official text from the Council of the EU documentation archives.

**Access Difficulty**: Easy

**Essential Information**:

- Detail the exact wording and legal implications of the existing Danish opt-out mechanism regarding the Euro (Protocol No. 30 implications).
- Quantify all possible legal pathways (Treaty amendment vs. political declaration) for revoking the opt-out, including necessary ratification steps within the EU institutions (Decision 4).
- List all relevant articles within the Treaty on European Union (TEU) applicable to the process selected by the 'Extraordinary European Council session' strategy (Decision 4.2).
- Identify specific domestic Danish constitutional articles that trigger legislative review or require a specific type of parliamentary majority for treaty ratification.
- Map the exact dependency chain: how the chosen resolution mechanism (Decision 4) constrains the timeline for the Legal Pathway (Decision 1) and the Opt-Out Resolution (Decision 4).

**Risks of Poor Quality**:

- Selecting an invalid or outdated legal pathway for opt-out removal leads to failed Ministerial high-level consultations and a multi-year delay awaiting proper procedure.
- Misinterpretation of domestic constitutional law risks the entire treaty ratification process being legally challenged post-parliamentary vote.
- Failing to assess the full scope of required EU treaty amendment leads to incorrect initial diplomatic positioning, severely damaging credibility when negotiating with the European Council.
- If the document supports the incorrect Opt-Out Resolution Mechanism Selection, political capital will be wasted pursuing a route the EU either rejects or cannot legally deliver.

**Worst Case Scenario**: The legal team confidently proceeds based on faulty text or interpretation, leading to an internationally recognized legal deadlock in Brussels or Copenhagen, resulting in the formal collapse of the official accession effort and immediate termination of the project due to failure to navigate the primary legal gateway.

**Best Case Scenario**: The Senior EU Legal & Treaty Negotiator uses the precise text to engineer the most efficient legal strategy, allowing the 'Extraordinary European Council session' request to proceed immediately with binding confidence, immediately unblocking Decision 1 (Legal Pathway) and setting the political timeline definitively.

**Fallback Alternative Approaches**:

- Commission a retainer contract with external, specialized EU Treaty law firm based in Brussels for immediate, binding verification of all interpretation related to Protocol No. 30.
- Initiate targeted, formal requests for clarification (without revealing full strategy) to the European Commission's Legal Service regarding procedural precedence for opt-out waivers.
- Prioritize developing the domestic constitutional impact assessment (Risk 2 mitigation) to identify required parliamentary procedure, assuming the EU process defaults to a full Treaty Amendment Protocol.

## Find Document 2: ECB Convergence Criteria Official Checklist and Latest Assessment Guide

**ID**: 1f050d91-076c-41b5-a95c-f2775e3d14a5

**Description**: The definitive, current checklist detailing all mandatory primary and secondary convergence criteria (inflation, deficit, debt, interest rates, ERM II participation) required by the ECB for final Euro adoption assessment. Essential input for the Initial ERM II Entry Plan (Decision 12).

**Recency Requirement**: Must be the most recently revised version published by ECB.

**Responsible Role Type**: Macroeconomic Convergence & ERM Strategist

**Steps to Find**:

- Download current convergence criteria documentation directly from the ECB website.
- Review the standard ECB assessment methodology documents related to ongoing convergence monitoring.
- Search for historical ECB annual reports detailing the final compliance requirements for recent entrants (e.g., Slovakia, Lithuania).

**Access Difficulty**: Easy

**Essential Information**:

- Detail the *exact* mandatory primary convergence criteria (e.g., specific upper limit for inflation deviation, deficit/debt percentages) required by the ECB for final Euro adoption.
- List all secondary, non-binding convergence criteria (e.g., regulatory harmonization targets, climate risk reporting adoption evidence) that will be required or strongly advised during the final assessment period.
- Identify the current official status/assessment guide defining the structure of the ERM II participation requirement (e.g., duration, permissible fluctuation band rules).
- Quantify the mandatory documentation evidence required by the ECB to prove compliance with each criterion within the checklist.

**Risks of Poor Quality**:

- Adopting outdated criteria leads to national restructuring efforts (e.g., fiscal tightening) aimed at obsolete targets, wasting budgetary resources (DKK 15-25B budget risk).
- Misunderstanding the difficulty of secondary criteria forces critical resource allocation away from primary convergence fulfillment, jeopardizing the 24-month ERM II minimum participation target.
- Failure to prepare necessary audit documentation results in immediate ECB rejection of formal adoption application, causing project timeline slippage beyond 8 years.
- Using incorrect benchmarks directly conflicts with the 'Convergence Standard Harmonization Triage' strategy, causing internal operational misalignment.

**Worst Case Scenario**: The project fails the final ECB adoption review due to reliance on obsolete or incomplete convergence criteria, necessitating forced, high-cost, last-minute fiscal and regulatory restructuring, leading to a minimum 18-month delay and significant political fallout (Risk 3 realization).

**Best Case Scenario**: The document provides a perfectly accurate, up-to-date roadmap, allowing the Macroeconomic Convergence Strategist to proactively structure the ERM II participation timeline, ensuring all primary criteria are met well ahead of schedule, accelerating the Q1 2030 referendum target.

**Fallback Alternative Approaches**:

- Engage the ECB liaison office in Brussels immediately to request a formal briefing explicitly detailing the criteria relevant to Denmark's specific opt-out history.
- Commission an external banking consultancy specializing in Eurozone accession to conduct an immediate 'Gap Analysis' against the last three successful entrant assessments.
- Task the National Bank's internal audit function (as per Assumption 8 ESE protocol) to benchmark current performance against the *most stringent* publicly available full checklist, treating it as the baseline requirement.

## Find Document 3: Danmarks Nationalbank's Current IT Infrastructure Documentation Mapping

**ID**: c70bbf9c-34de-4f1b-be36-b280eed49c6c

**Description**: Detailed topological maps and system specifications for Danmarks Nationalbank's critical payment systems (e.g., gross settlement systems, real-time monitoring tools) as they currently interact with non-Eurozone systems. Needed to guide the Shadow Integration Team's initial simulation scope (Risk 4 mitigation).

**Recency Requirement**: System architecture documentation from the last 12 months.

**Responsible Role Type**: Central Bank Technical Integration Lead

**Steps to Find**:

- Request internal documentation directly from Danmarks Nationalbank IT Security and Operations department.
- Review any existing internal gap analysis reports comparing current systems against TARGET2 specifications.
- Check internal National Bank secure data repositories for system specification drawings.

**Access Difficulty**: Medium

**Essential Information**:

- Detailed topological maps of Danmarks Nationalbank's critical payment systems (e.g., gross settlement systems) that interact with non-Eurozone systems.
- Specific system specifications (version numbers, APIs, protocols) for current Danmarks Nationalbank infrastructure.
- Identification of all current external interfaces that must be reconfigured or replaced to meet Eurosystem/TARGET2 requirements.
- Documentation reflecting system architecture from the last 12 months to ensure currency.

**Risks of Poor Quality**:

- Incomplete or outdated documentation will lead to inaccurate scoping for the 'Shadow Integration Team,' causing critical integration gaps with Eurosystem infrastructure (TARGET2).
- Incorrect external interface data will result in the 'Euro Simulation Exercises' (ESE) being technically invalid, failing to catch actual compatibility issues.
- Failure to identify all dependencies will introduce unforeseen complexity and resource drain during the formal technical integration phase following the referendum.

**Worst Case Scenario**: Significant technical integration failure impacting the ability of Danmarks Nationalbank to participate fully in Eurosystem payment operations on Euro Day, forcing a severe, unexpected delay (potentially 4-6 months remediation) or resulting in operational isolation.

**Best Case Scenario**: The documentation allows the 'Shadow Integration Team' to immediately and accurately map current state against target state, optimizing the simulation scope, accelerating technical readiness ahead of the formal political timeline, and directly mitigating Risk 4.

**Fallback Alternative Approaches**:

- Initiate mandatory, on-site technical deep-dive sessions with Danmarks Nationalbank's lead system architects to manually reconstruct the topological maps by interviewing key personnel.
- Procure an external specialized consultancy firm with documented experience integrating national central banks into TARGET2 to conduct an immediate, high-level infrastructure audit.
- Prioritize gathering only the formal specifications for the Gross Settlement System interfaces, accepting lower fidelity on peripheral monitoring tools initially.

## Find Document 4: Danish Fiscal Data: Historical Deficit and Debt Ratios (Last 5 Years)

**ID**: 68c583fb-c961-489c-bf8f-17e7e422deaf

**Description**: Raw national accounts data providing mandatory metrics for fiscal convergence (Debt/GDP < 60%, Deficit/GDP < 3%). Needed by the Macroeconomic Strategist to set internal policy baselines.

**Recency Requirement**: Data covering the last five complete fiscal years, plus the latest quarterly figures.

**Responsible Role Type**: Fiscal Oversight & Budget Manager

**Steps to Find**:

- Access Statistics Denmark (DST) database for national accounts tables.
- Review the Ministry of Finance's most recent publicly issued Budget Stress Test data.
- Source raw data from Eurostat tables related to Maastricht criterion reporting for Denmark.

**Access Difficulty**: Easy

**Essential Information**:

- List the specific, binding DKK Deficit/GDP ratio for the last five fiscal years and the latest available quarterly ratio.
- List the specific, binding DKK Debt/GDP ratio for the last five fiscal years and the latest available quarterly ratio.
- Identify the mandated reporting standard used across all provided historical data sets (e.g., ESA 2010 compliance level).
- Quantify the variance (in percentage points) between the latest reported figures and the Maastricht Treaty thresholds (3% Deficit, 60% Debt).

**Risks of Poor Quality**:

- Inaccurate fiscal data (Risk 3) leads to a fundamentally incorrect assessment of the feasibility of meeting convergence criteria during the ERM II window.
- Using non-standardized reporting decades (e.g., mixing pre-ESA 2010 data) causes the ECB convergence audit to fail or require lengthy reconciliation, delaying formal ERM II entry.
- Missing the latest quarterly figures prevents the Macroeconomic Strategist from setting the immediate fiscal policy levers required under the 'Joint Ministerial Consultative Body' governance structure.

**Worst Case Scenario**: Failure to meet the deficit ceiling during the ERM II preparatory period due to overlooked historical overruns, resulting in a mandatory 6-18 month fiscal correction delay and invalidating the chosen 'Builder's Blueprint' sequencing by forcing the project past the 8-year window.

**Best Case Scenario**: Confirmation that historical fiscal performance already provides a significant buffer (e.g., DKK 1-2% average margin below thresholds), allowing the Fiscal Oversight Manager to de-prioritize severe domestic contraction measures, thus speeding up the convergence timeline and increasing political certainty for the referendum.

**Fallback Alternative Approaches**:

- Immediately initiate an emergency third-party actuarial review of the last three years of deficit calculations, citing potential scope changes in state pension liabilities.
- Formally request clarification and primary data confirmation directly from the European Commission's DG ECFIN regarding Denmark's most recent reported Maastricht figures.
- Instruct the Ministry of Finance to issue provisional internal policy caps based on the most conservative reported figures (Risk 3 mitigation) until official confirmation is received.

## Find Document 5: Danish Constitutional Text Regarding National Referenda and Treaty Ratification

**ID**: 65931c18-fbf5-4265-b1e9-eb0ea60bf4d5

**Description**: The specific articles of the Danish Constitution governing the requirements (majority size, turnout thresholds, sequence) for enacting a national referendum on matters concerning international treaty changes, which constrains the Public Referendum Design (Decision 3).

**Recency Requirement**: Current version of the Constitution.

**Responsible Role Type**: Senior EU Legal & Treaty Negotiator

**Steps to Find**:

- Retrieve the official, current text of the Danish Constitution from the Folketinget website.
- Consult prior legal analyses or White Papers concerning previous Danish treaty votes.
- Seek clarification from the Ministry of Justice's constitutional department on procedural precedents.

**Access Difficulty**: Easy

**Essential Information**:

- Exact statutory thresholds (majority size, required turnout) for enacting a national referendum on international treaty changes within the Danish Constitution.
- Explicit sequence mandated by the Constitution for synchronizing a national referendum with related parliamentary or executive treaty ratification acts.
- Any specific constitutional preconditions related to maintaining or suspending existing opt-outs prior to a final referendum vote.
- Identify specific articles that govern the process for aligning constitutional requirements with external EU treaty amendment procedures.

**Risks of Poor Quality**:

- Adopting Decision 3 ('Public Referendum Design and Timing') based on outdated or misinterpreted constitutional requirements resulting in a legally invalid referendum, requiring costly repetition.
- Miscalculating the required political capital for the referendum due to underestimating the statutory bar, leading to failure of the mandate gate (Strategy 3.2).
- Inability to commit to the 'Builder's Blueprint' timeline (Q1 2030 referendum target) if mandatory procedural steps are discovered late in the process.

**Worst Case Scenario**: The referendum is conducted according to flawed legal assumptions, declared void by a domestic court challenge, forcing the entire project timeline to reset by 12-24 months to re-align political consensus and re-run the constitutional process, leading to significant sunk cost waste.

**Best Case Scenario**: Precise knowledge of referenda requirements allows for the optimal scheduling of Decision 3, precisely aligning the vote date with the end of the ERM II period (Q3 2029) as planned in the projected timeline, ensuring maximum legal certainty and political momentum.

**Fallback Alternative Approaches**:

- Immediately initiate formal, expedited request for clarity and pre-approval of the proposed referendum process from the Ministry of Justice's constitutional division.
- If constitutional clarity remains ambiguous, pivot Decision 3 choice to the most legally robust, albeit potentially conservative option, such as implementing a nationwide deliberative panel (Strategy 3.3's process) to build undeniable political legitimacy preemptively.
- Engage external, specialized EU/Danish constitutional law partners to prepare a 'Dual-Path Legal Contingency Mandate' that hedges against different ratification sequences specified in the Constitution (referenced in Review Assumption 3).

## Find Document 6: Lithuanian (LITAS) to TARGET2 Payment System Integration Reports (2013-2014)

**ID**: afd1a60c-7d77-4a90-bc07-59724fc5c43c

**Description**: Technical reports detailing the integration roadmap, security hardening efforts, and successful migration steps taken by the Bank of Lithuania (BoL) to connect their national payment systems to the ECB's TARGET2 infrastructure (Decision 8). Directly informs the Central Bank Technical Integration Lead.

**Recency Requirement**: Technical reports published between 2013 and 2014.

**Responsible Role Type**: Central Bank Technical Integration Lead

**Steps to Find**:

- Access the Bank of Lithuania (Lietuvos bankas) official library/publication portal.
- Search ECB Convergence Reports (2014) for specific commentary on Payment System Migration.
- Review BoL annual reports detailing cooperation memoranda with the Eurosystem.

**Access Difficulty**: Medium

**Essential Information**:

- Identify the exact timelines and sequencing constraints imposed by the EU/ECB regarding the Opt-Out Resolution Mechanism Selection (Decision 4) relative to ERM II entry (Decision 12).
- Detail the specific points of contact and required documentation format for initiating the 'Extraordinary European Council session' (Strategic Choice 4.2).
- Quantify the required diplomatic effort (e.g., number of preparatory meetings, required member state endorsements) needed to secure the protocol amendment per Decision 4.
- Determine the specific legal triggers within Danish constitutional law that require concurrent or prerequisite negotiations for Opt-Out Repeal versus ERM II confirmation.

**Risks of Poor Quality**:

- Incorrect sequencing of negotiations risks violating political agreements established with the EU Council, leading to immediate timeline blockage or revocation of conditional support.
- Missing explicit EU procedural requirements for the Extraordinary Council session leads to the submission being rejected, forcing an immediate pivot to higher-risk treaty amendment negotiations (Strategy 4.3).
- Inaccurate understanding of required diplomatic capital results in under-resourcing the lead negotiators, causing delays in securing agreements necessary for Decision 1 ('Legal Pathway').

**Worst Case Scenario**: A fundamental breakdown in diplomatic sequencing forces a pivot from the planned Council Request (Strategy 4.2) back toward a full Treaty Amendment process without prior EU consensus, extending the legal preparation phase by 18-24 months and causing the referendum timeline (Decision 3) to slip past the 8-year constraint.

**Best Case Scenario**: Clear confirmation is received detailing the EU's acceptance of the targeted protocol amendment process (Strategy 4.2), allowing diplomatic efforts to conclude in parallel with the mandatory 24-month ERM II period, thereby establishing legal certainty early and stabilizing market perception.

**Fallback Alternative Approaches**:

- Initiate immediate, high-level bilateral consultations with Germany, France, and Italy to secure informal political buy-in on the process, anticipating official objections to the Extraordinary Council Request.
- Task the Justice Ministry to immediately draft the domestic legislation contingent upon Strategy 4.3 (Unilateral Declaration/ECB Approval) as a formal 'Plan B' contingency, to be ratified by Folketinget pending EU outcome.
- Engage external EU legal counsel specializing in Treaty on European Union Protocol amendments to map optimal political positioning and procedural triggers.

## Find Document 7: Danish Commercial Contract Law and Consumer Protection Statute regarding Price Fixed Obligations

**ID**: 13ab57d1-991b-46bc-8294-38af24ce1a07

**Description**: Current Danish statutes detailing the legal enforceability and rounding rules for long-term private financial contracts (e.g., mortgages, leases) that might be automatically converted upon a change of legal tender. Essential for drafting the mandatory re-denomination legislation (Decision 7).

**Recency Requirement**: Current codified private and commercial law statutes.

**Responsible Role Type**: Financial & Legal Redenomination Specialist

**Steps to Find**:

- Search official Danish legislative databases (e.g., Retsinformation) for relevant acts concerning currency conversion precedents.
- Consult the Ministry of Justice guidance on commercial law impact during previous Danish monetary changes (e.g., major USD peg changes).
- Obtain codified texts via the Danish Bar Association or legal publishers.

**Access Difficulty**: Medium

**Essential Information**:

- Detail the specific statutes governing the enforceability of pre-existing private financial obligations (mortgages, leases) denominated in DKK upon the official Euro Day.
- Identify the exact legal mechanism and mandated rounding rules (if any) currently codified for converting fixed DKK obligations to EUR.
- Specify any existing consumer protection clauses that limit government intervention or mandatory legislative override on private contract terms related to currency conversion.
- List precedents or established legal interpretation guidelines concerning unilateral price adjustments due to sovereign acts of currency change.

**Risks of Poor Quality**:

- Adopting an inaccurate legal basis for Decision 7 (Commercial Contract Re-denomination Strategy) leads to immediate, widespread litigation post-Euro Day, paralyzing the Danish judicial system.
- If the document fails to identify necessary consumer protection limitations, the mandated 'automatic rounding' (Strategy 7.1) may be challenged and overturned, imposing massive liabilities on financial institutions.
- Misunderstanding the statutory limits on government override increases the political friction caused by implementing Decision 7, potentially requiring amendments to the 'Joint Ministerial Consultative Body' protocols due to legal conflict.

**Worst Case Scenario**: Inaccurate understanding of fundamental contract law invalidates the chosen legislative strategy for contract re-denomination, resulting in billions of DKK in successful consumer litigation against financial institutions, leading to systemic instability and a mandatory DKK freeze pending legislative correction.

**Best Case Scenario**: Precise legal knowledge allows the rapid drafting and passage of robust, ironclad legislative instruments for automatic rounding, completely eliminating post-conversion contract disputes and supporting a high 'Fit Score' for the chosen 'Builder's Blueprint' strategy.

**Fallback Alternative Approaches**:

- Initiate immediate engagement with the Ministry of Justice and the Danish Bar Association to commission a high-priority legal opinion analyzing the precise constraints on overriding private contracts under current commercial statutes.
- Temporarily adopt the most conservative fallback strategy for Decision 7: Mandate a 18-month explicit dual-quoting transition period (Strategy 7.2) until the legal framework is fully clarified, accepting increased market confusion.
- If no precedent exists, prepare parallel domestic legislation authorizing immediate, temporary government guarantees over rounding discrepancies to maintain market function while the primary legal mechanism is resolved.