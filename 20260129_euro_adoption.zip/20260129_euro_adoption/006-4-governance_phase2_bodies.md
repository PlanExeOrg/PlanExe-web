### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Provides high-level strategic direction and oversight for the entire euro adoption project, given its significant political, economic, and legal implications. Ensures alignment with government policy and manages strategic risks.

**Responsibilities:**

- Provide strategic direction and oversight for the project.
- Approve key project milestones and deliverables.
- Approve budgets exceeding 5 million EUR.
- Monitor and manage strategic risks.
- Resolve escalated issues from lower-level governance bodies.
- Ensure alignment with government policy and EU regulations.
- Approve the Referendum Framing Strategy and Legal Pathway Selection.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Review and approve initial project plan.
- Define escalation paths and decision-making protocols.

**Membership:**

- Prime Minister (or designated representative)
- Minister of Finance
- Minister of Economy
- Governor of Danmarks Nationalbank
- Director General of the Danish FSA
- Independent Expert in Political Science
- Independent Expert in Economics

**Decision Rights:** Strategic decisions related to project scope, budget (above 5 million EUR), timeline, and key policy choices (Referendum Framing, Legal Pathway).

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Prime Minister (or designated representative) has the casting vote. Dissenting opinions are recorded in the minutes.

**Meeting Cadence:** Quarterly, with ad-hoc meetings as needed for critical decisions.

**Typical Agenda Items:**

- Review of project progress against milestones.
- Review of financial performance and budget adherence.
- Discussion and approval of strategic decisions.
- Risk assessment and mitigation planning.
- Stakeholder engagement updates.
- Review of compliance with EU regulations.

**Escalation Path:** Cabinet (for issues exceeding the PSC's authority or requiring inter-ministerial coordination).
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages the day-to-day execution of the project, ensuring efficient resource allocation, risk management, and adherence to the project plan. Provides a central point of coordination and communication.

**Responsibilities:**

- Develop and maintain the project plan.
- Manage project budget (below 5 million EUR) and resources.
- Track project progress and report to the Project Steering Committee.
- Identify and manage operational risks.
- Coordinate project activities across different workstreams.
- Manage communication and stakeholder engagement at the operational level.
- Implement and maintain project management tools and processes.
- Manage the Risk Register and escalate risks as needed.

**Initial Setup Actions:**

- Establish PMO structure and staffing.
- Develop project management plan.
- Implement project management tools and systems.
- Define reporting procedures.
- Establish communication protocols.

**Membership:**

- Project Director
- Workstream Leads (Legal, Economic, Communication, IT)
- Risk Manager
- Finance Manager
- Communication Manager
- PMO Support Staff

**Decision Rights:** Operational decisions related to project execution, resource allocation (within approved budget), and risk management (below strategic thresholds).

**Decision Mechanism:** Decisions made by the Project Director, in consultation with Workstream Leads. Unresolved issues are escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly.

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of risks and issues.
- Resource allocation and budget management.
- Coordination of workstream activities.
- Stakeholder engagement updates.
- Review of action items.

**Escalation Path:** Project Steering Committee (for issues exceeding the PMO's authority or impacting strategic objectives).
### 3. Legal and Compliance Committee (LCC)

**Rationale for Inclusion:** Ensures compliance with all relevant EU and Danish laws and regulations, including GDPR, ethical standards, and financial regulations. Provides specialized legal advice and guidance to the project team.

**Responsibilities:**

- Provide legal advice and guidance on all aspects of the project.
- Ensure compliance with EU and Danish laws and regulations.
- Conduct legal due diligence.
- Monitor and manage legal risks.
- Develop and implement compliance policies and procedures.
- Review and approve contracts and agreements.
- Oversee data protection and privacy compliance (GDPR).
- Ensure ethical standards are maintained throughout the project.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop compliance policies and procedures.
- Identify key legal and regulatory requirements.

**Membership:**

- Chief Legal Counsel (Danmarks Nationalbank)
- Legal Representatives from relevant ministries (Finance, Economy)
- External Legal Expert (EU Law)
- Compliance Officer (Danish FSA)
- Data Protection Officer
- Ethics Officer

**Decision Rights:** Decisions related to legal compliance, interpretation of laws and regulations, and approval of legal documents.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Chief Legal Counsel (Danmarks Nationalbank) has the casting vote.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical legal issues.

**Typical Agenda Items:**

- Review of legal and regulatory developments.
- Discussion of compliance issues.
- Review of contracts and agreements.
- Legal risk assessment and mitigation planning.
- Data protection and privacy compliance updates.
- Ethics compliance updates.

**Escalation Path:** Project Steering Committee (for issues with significant strategic or financial implications) or relevant regulatory bodies (e.g., ECB, European Commission) for compliance breaches.
### 4. Stakeholder Engagement Group (SEG)

**Rationale for Inclusion:** Facilitates effective communication and engagement with key stakeholders, including the public, businesses, and EU institutions. Ensures that stakeholder concerns are addressed and that the project is implemented in a transparent and inclusive manner.

**Responsibilities:**

- Develop and implement a stakeholder engagement strategy.
- Identify and analyze key stakeholder groups.
- Conduct public consultations and focus groups.
- Manage communication with stakeholders.
- Address stakeholder concerns and feedback.
- Monitor public opinion and sentiment.
- Coordinate with the Communication Manager on public awareness campaigns.
- Provide input on the Referendum Framing Strategy.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop stakeholder engagement strategy.
- Identify key stakeholder groups.

**Membership:**

- Communication Manager (PMO)
- Public Relations Officer
- Representatives from business and employer organizations
- Representatives from trade unions
- Representatives from consumer advocacy groups
- Representatives from municipalities
- Independent Expert in Public Communication

**Decision Rights:** Decisions related to stakeholder engagement strategy, communication plans, and public consultations.

**Decision Mechanism:** Decisions made by consensus. In case of disagreement, the issue is escalated to the Project Director.

**Meeting Cadence:** Bi-weekly.

**Typical Agenda Items:**

- Review of stakeholder engagement activities.
- Discussion of stakeholder concerns and feedback.
- Monitoring of public opinion and sentiment.
- Planning of public consultations and focus groups.
- Review of communication materials.
- Updates on stakeholder engagement strategy.

**Escalation Path:** Project Director (for issues requiring strategic decisions or impacting project objectives).