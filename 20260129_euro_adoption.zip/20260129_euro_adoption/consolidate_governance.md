# Governance Audit


## Audit - Corruption Risks

- Bribery of EU or Danish officials to fast-track or block treaty change and referendum processes
- Nepotism in awarding consultancy and IT conversion contracts to politically connected firms
- Conflicts of interest among ministers or regulators influencing the choice of conversion methodology or cash logistics partners
- Kickbacks from payment service providers or cash logistics firms in exchange for exclusive migration or distribution roles
- Misuse of non-public information on referendum timing or parity decisions to gain financial advantage in currency markets

## Audit - Misallocation Risks

- Budget padding for public information campaigns beyond actual reach, with funds diverted to unrelated priorities
- Double spending of earmarked euro transition funds across multiple ministries without reconciliation
- Inefficient allocation of technical personnel to IT conversion causing bottlenecks and extended dual-circulation costs
- Unauthorized use of Nationalbank or government contingency assets to cover cash shortages during conversion
- Poor record-keeping leading to unaccounted conversion costs and inability to trace disbursements for audits

## Audit - Procedures

- Quarterly internal compliance audits of treaty change and referendum documentation against legal checklists, with a post-referendum external audit
- Pre- and post-implementation IT system audits for payment and conversion platforms, including penetration testing and dual-currency reconciliation testing
- Contract review thresholds for procurement above a set value, with mandatory competitive bidding and conflict-of-interest declarations
- Expense and reimbursement workflows requiring itemized dual-currency conversion receipts and segregation of duties for payment approvals
- Periodic compliance checks against Maastricht criteria and ERM II rules, with remediation plans reported to the Folketinget

## Audit - Transparency Measures

- Public dashboard tracking referendum thresholds, ERM II entry status, and conversion milestones with weekly updates
- Published summaries of key ministerial and EU negotiation meetings, including voting records and derogation requests
- Whistleblower hotline and protection policy managed by an independent ombudsperson, with anonymized case tracking
- Open access to final conversion methodology documents, rounding rules, and cash logistics SOPs
- Mandatory disclosure registers for contracts above a defined threshold, listing beneficiaries and conflict-of-interest statements

# Internal Governance Bodies

### 1. Euro Adoption Steering Committee

**Rationale for Inclusion:** High-level strategic oversight is required to guide Denmark’s multi-year transition from opt-out to full euro adoption, manage treaty change, referendum, and alignment with EU/ECB rules.

**Responsibilities:**

- Approve major strategic decisions and milestone gates
- Authorize budgets above defined thresholds (e.g., >500M DKK)
- Oversee risk register and contingency planning
- Ensure compliance with EU, ECB, and Danish constitutional requirements
- Provide final sign-off on referendum timing and treaty change posture

**Initial Setup Actions:**

- Define Terms of Reference and membership
- Select Chair and independent members
- Establish financial thresholds and escalation matrix

**Membership:**

- Prime Minister (Chair)
- Minister of Finance
- Minister of Economic Affairs
- Danmarks Nationalbank Governor
- Danish Financial Supervisory Authority Head
- Independent external macroeconomist (non-Danish)

**Decision Rights:** Strategic decisions including referendum authorization, treaty change posture, ERM II entry approval, budgets >500M DKK, and adoption-go/no-go gates.

**Decision Mechanism:** Consensus required; fallback to supermajority (≥75%) with independent chair casting tie-breaking vote.

**Meeting Cadence:** Monthly, with ad hoc emergency sessions.

**Typical Agenda Items:**

- Review of convergence metrics vs Maastricht criteria
- Referendum readiness and public mandate status
- ERM II entry and parity setting
- Budget and funding approvals
- Risk register updates and contingency triggers

**Escalation Path:** Directly to Folketinget and, if unresolved, to the Danish Parliament’s Constitutional Committee within 14 days.
### 2. Dual Circulation Management Office

**Rationale for Inclusion:** Operational management of day-to-day transition activities, including IT, cash logistics, payment systems, and dual pricing coordination.

**Responsibilities:**

- Execute conversion of payment systems and IT infrastructure
- Manage dual circulation scheduling and cutover plans
- Coordinate cash supply and seigniorage capture
- Monitor operational KPIs and incident response
- Implement stakeholder training and support programs

**Initial Setup Actions:**

- Define RACI and governance workflows
- Establish technical standards and test plans
- Set up cross-functional workstreams (Legal, IT, Operations, Communications)

**Membership:**

- Deputy Prime Minister (Head of Operations)
- Chief Digital Officer
- Danmarks Nationalbank Deputy Governor
- FSA Head of Payment Systems
- Municipalities Representative
- Commercial Banks Liaison (non-voting advisor)

**Decision Rights:** Operational decisions up to 250M DKK, implementation schedules, and day-to-day risk management within approved thresholds.

**Decision Mechanism:** Majority vote; tie resolved by Head of Operations.

**Meeting Cadence:** Weekly operational reviews; biweekly steering alignment.

**Typical Agenda Items:**

- IT system migration status and testing results
- Cash logistics and euro availability metrics
- Dual pricing and rounding compliance
- Incident logs and resolution plans
- Stakeholder feedback integration

**Escalation Path:** Escalate to Euro Adoption Steering Committee for decisions beyond operational thresholds or unresolved issues within 7 days.
### 3. Legal and Treaty Compliance Committee

**Rationale for Inclusion:** Dedicated oversight of legal, treaty, and constitutional compliance, including referendum design, EU negotiations, and contract conversion rules.

**Responsibilities:**

- Draft and review treaty change and derogation requests
- Ensure referendum design meets constitutional thresholds
- Provide legal interpretation of EU requirements
- Oversee legacy DKK contract renegotiation frameworks
- Monitor GDPR and regulatory alignment

**Initial Setup Actions:**

- Establish legal assessment checklists
- Engage independent external counsel for impartial review
- Define compliance audit schedule

**Membership:**

- Minister of Justice (Chair)
- Attorney General
- EU Law Professor (independent academic)
- Data Protection Authority Representative
- FSA Legal Counsel (non-voting)

**Decision Rights:** Authority to approve legal instruments up to 1B DKK in contingent liabilities; binding interpretation of EU and constitutional mandates.

**Decision Mechanism:** Unanimous consent; if unreachable, refer to independent arbitration panel.

**Meeting Cadence:** Biweekly, with urgent sessions as needed.

**Typical Agenda Items:**

- Treaty change draft review and legal risk scoring
- Referendum question wording and threshold validation
- Contract conversion methodology compliance
- Data protection and privacy impact assessments
- Regulatory filings and EU correspondence review

**Escalation Path:** Escalate unresolved legal disputes to the Danish Supreme Court or EU Court of Justice as appropriate.
### 4. Stakeholder Engagement and Communication Council

**Rationale for Inclusion:** Ensure sustained public and stakeholder buy-in through structured communication, education, and inclusive participation across demographics.

**Responsibilities:**

- Design and execute multi-channel communication strategy
- Coordinate town halls, digital Q&A, and SME outreach
- Monitor sentiment and misinformation trends
- Manage public dashboards and transparency reporting
- Engage unions, employers, and municipalities on social pacts

**Initial Setup Actions:**

- Develop communication roadmap and KPIs
- Establish independent media monitoring
- Create stakeholder advisory panels

**Membership:**

- Minister of Culture (Chair)
- Head of National Broadcasting
- Consumer Association Representative
- Trade Union Confederation Lead
- Business Federation Spokesperson
- Independent Communications Strategist (external)

**Decision Rights:** Approve communication budgets up to 100M DKK; mandate public messaging standards; trigger corrective campaigns.

**Decision Mechanism:** Consensus; fallback to majority vote with external advisor tie-break.

**Meeting Cadence:** Biweekly; ad hoc during referendum and conversion peaks.

**Typical Agenda Items:**

- Message testing and channel performance
- Public awareness and misinformation tracking
- Stakeholder feedback synthesis
- Crisis communication drills
- Transparency dashboard updates

**Escalation Path:** Escalate to Euro Adoption Steering Committee if public trust metrics fall below defined thresholds.
### 5. Risk and Contingency Oversight Board

**Rationale for Inclusion:** Integrated risk management across all governance bodies, with dedicated focus on financial, operational, and systemic contingencies.

**Responsibilities:**

- Maintain and update the comprehensive risk register
- Monitor contingency reserves and trigger usage
- Run scenario simulations and stress tests
- Report risk posture to steering and operational bodies
- Ensure alignment with EU/ECB stability requirements

**Initial Setup Actions:**

- Finalize risk taxonomy and scoring matrix
- Establish contingency funding mechanisms
- Define simulation and drill schedules

**Membership:**

- Head of Risk Management (Chair)
- Chief Financial Officer
- IT Security Lead
- External Risk Consultant (independent)
- Representative from Euro Adoption Steering Committee

**Decision Rights:** Approve risk mitigation budgets up to 500M DKK; authorize contingency activation; mandate corrective actions.

**Decision Mechanism:** Consensus; supermajority (≥80%) if consensus fails.

**Meeting Cadence:** Weekly risk review; monthly deep-dive simulations.

**Typical Agenda Items:**

- Risk register updates and new risk identification
- Contingency fund status and drawdown triggers
- Scenario analysis results and action plans
- Cross-body risk dependencies and mitigation coordination
- Compliance with EU risk reporting standards

**Escalation Path:** Immediate escalation to Euro Adoption Steering Committee and Folketinget if high-impact risks materialize or reserves are breached.

# Governance Implementation Plan

### 1. Establish an Inter-Ministerial Formation Team to set up the Euro Adoption Steering Committee, Dual Circulation Management Office, Legal and Treaty Compliance Committee, Stakeholder Engagement and Communication Council, and Risk and Contingency Oversight Board.

**Responsible Body/Role:** Project Sponsor (Prime Minister's Office) and designated Formation Lead

**Suggested Timeframe:** Project Week 1–2

**Key Outputs/Deliverables:**

- Formation Team charter
- Initial membership lists and Terms of Reference drafts
- High-level timeline and governance calendar

**Dependencies:**

- Government decision to pursue euro adoption
- Ministerial mandate and budget allocation

### 2. Draft Terms of Reference (ToR) for the Euro Adoption Steering Committee, Dual Circulation Management Office, Legal and Treaty Compliance Committee, Stakeholder Engagement and Communication Council, and Risk and Contingency Oversight Board.

**Responsible Body/Role:** Formation Lead (with legal and policy support)

**Suggested Timeframe:** Project Week 2–3

**Key Outputs/Deliverables:**

- Draft ToR for each governance body
- Draft RACI and decision matrices

**Dependencies:**

- Formation Team charter
- Initial membership lists

### 3. Circulate draft ToR for review and feedback to nominated members and relevant ministries.

**Responsible Body/Role:** Formation Lead

**Suggested Timeframe:** Project Week 3–4

**Key Outputs/Deliverables:**

- Feedback summary
- Annotated draft ToR

**Dependencies:**

- Draft ToR availability
- Nominated members confirmed

### 4. Finalize and approve Terms of Reference for all governance bodies.

**Responsible Body/Role:** Project Sponsor (Prime Minister's Office) with ministerial sign-off

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Approved ToR for each governance body
- Official appointment letters for initial members

**Dependencies:**

- Completed review and feedback incorporation
- Ministerial endorsement

### 5. Formally appoint and confirm membership of the Euro Adoption Steering Committee, including Chair and independent members.

**Responsible Body/Role:** Project Sponsor (Prime Minister's Office)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Membership confirmation notices
- Appointment confirmation email

**Dependencies:**

- Approved ToR
- Ministerial decision

### 6. Formally appoint and confirm membership of the Dual Circulation Management Office, Legal and Treaty Compliance Committee, Stakeholder Engagement and Communication Council, and Risk and Contingency Oversight Board.

**Responsible Body/Role:** Project Sponsor (Prime Minister's Office)

**Suggested Timeframe:** Project Week 6–7

**Key Outputs/Deliverables:**

- Membership confirmation notices for all bodies
- Organizational charts

**Dependencies:**

- Approved ToR
- Ministerial decision

### 7. Hold inaugural kick-off meeting for the Euro Adoption Steering Committee to set strategic direction and approve milestone gates.

**Responsible Body/Role:** Euro Adoption Steering Committee (Chair)

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Kick-off meeting minutes
- Approved strategic roadmap and milestone gates

**Dependencies:**

- Membership confirmations
- Approved ToR

### 8. Hold inaugural kick-off meeting for the Dual Circulation Management Office to finalize conversion methodology and operational timelines.

**Responsible Body/Role:** Dual Circulation Management Office (Head of Operations)

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Kick-off meeting minutes
- Operational plan and timeline

**Dependencies:**

- Membership confirmations
- Strategic roadmap from Steering Committee

### 9. Hold inaugural kick-off meeting for the Legal and Treaty Compliance Committee to initiate treaty change and referendum design.

**Responsible Body/Role:** Legal and Treaty Compliance Committee (Chair)

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Kick-off meeting minutes
- Initial legal and treaty workplan

**Dependencies:**

- Membership confirmations
- Strategic roadmap

### 10. Hold inaugural kick-off meeting for the Stakeholder Engagement and Communication Council to launch communication strategy and public preparedness planning.

**Responsible Body/Role:** Stakeholder Engagement and Communication Council (Chair)

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Kick-off meeting minutes
- Communication strategy and calendar

**Dependencies:**

- Membership confirmations
- Initial legal and treaty workplan

### 11. Hold inaugural kick-off meeting for the Risk and Contingency Oversight Board to activate risk register and contingency planning.

**Responsible Body/Role:** Risk and Contingency Oversight Board (Chair)

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Kick-off meeting minutes
- Risk register and contingency plan

**Dependencies:**

- Membership confirmations
- Communication strategy

### 12. Conduct a 90-day governance health-check after all bodies are formed and initial meetings held to verify alignment, decision rights, and escalation paths.

**Responsible Body/Role:** Project Sponsor (Prime Minister's Office) with Formation Lead support

**Suggested Timeframe:** Project Week 13–16

**Key Outputs/Deliverables:**

- Governance health-check report
- Corrective action plan (if needed)

**Dependencies:**

- All kick-off meetings completed
- Initial workplans and risk register

# Decision Escalation Matrix

**Budget Request Exceeding PMO Authority**
Escalation Level: Euro Adoption Steering Committee
Approval Process: Steering Committee vote with supermajority (≥75%) and independent chair tie-break
Rationale: Exceeds delegated financial thresholds; requires strategic alignment and risk oversight.
Negative Consequences: Budget overruns, delayed timelines, and compromised contingency reserves if not escalated.

**Critical Risk Materialization Beyond PMO Capacity**
Escalation Level: Risk and Contingency Oversight Board
Approval Process: Board consensus to activate contingency reserves and scenario response plans
Rationale: High-impact risk requiring cross-body coordination and immediate resource reallocation.
Negative Consequences: Operational failure, market instability, and potential project suspension if unaddressed.

**PMO Deadlock on Vendor Selection**
Escalation Level: Dual Circulation Management Office
Approval Process: Majority vote with Head of Operations casting tie-breaking vote
Rationale: Operational gridlock affecting conversion timelines and IT readiness.
Negative Consequences: Conversion delays, increased costs, and disruption to dual-circulation planning.

**Proposed Major Scope Change**
Escalation Level: Legal and Treaty Compliance Committee
Approval Process: Unanimous consent; if unreachable, independent arbitration
Rationale: Legal and treaty implications require specialized constitutional and EU law expertise.
Negative Consequences: Non-compliance with EU rules, referendum invalidation, or treaty rejection.

**Reported Ethical Violation**
Escalation Level: Stakeholder Engagement and Communication Council
Approval Process: Consensus-driven investigation with external advisor tie-break
Rationale: Requires transparent, independent review to preserve public trust and integrity.
Negative Consequences: Reputational damage, public mistrust, and potential legal penalties if mishandled.

# Monitoring Progress

### 1. Convergence and Maastricht Criteria Monitoring
**Monitoring Tools/Platforms:**

  - ECB Convergence Indicators Dashboard
  - National Statistical Institute reports
  - FSA compliance tracking system

**Frequency:** Quarterly

**Responsible Role:** Economic Affairs Ministry and Danmarks Nationalbank

**Adaptation Process:** If convergence gaps are identified, adjust fiscal and monetary policy measures and notify EU institutions; trigger contingency reserves if material.

**Adaptation Trigger:** Any Maastricht criterion falling outside the reference range for two consecutive quarters.

### 2. Public Mandate Acquisition Timeline Monitoring
**Monitoring Tools/Platforms:**

  - Referendum readiness tracker
  - Public opinion survey platform
  - Media sentiment analysis dashboard

**Frequency:** Monthly

**Responsible Role:** Stakeholder Engagement and Communication Council

**Adaptation Process:** Adjust communication strategy and timing of referendum preparations based on public awareness and sentiment metrics.

**Adaptation Trigger:** Public awareness below 70% or misinformation index above threshold before referendum.

### 3. Financial Infrastructure Migration Monitoring
**Monitoring Tools/Platforms:**

  - IT system migration status board
  - Dual-currency processing test results
  - Payment success rate and settlement latency KPIs

**Frequency:** Bi-weekly

**Responsible Role:** Dual Circulation Management Office

**Adaptation Process:** Remediate identified IT or operational gaps; adjust cutover schedules and conduct additional stress tests.

**Adaptation Trigger:** Test failure rate above 5% or critical incident unresolved within 48 hours.

### 4. Cash Conversion Logistics and Seigniorage Monitoring
**Monitoring Tools/Platforms:**

  - Euro cash inventory system
  - Central cash hub dashboards
  - Denmark Cash Logistics Tracker

**Frequency:** Weekly

**Responsible Role:** Cash Conversion Logistics Team

**Adaptation Process:** Reallocate cash reserves and adjust distribution routes; engage ECB for supplemental supply if needed.

**Adaptation Trigger:** Cash availability below 10% of forecasted demand or seigniorage capture variance >2%.

### 5. Treaty Change Negotiation Posture Monitoring
**Monitoring Tools/Platforms:**

  - EU negotiation status tracker
  - Political alignment index
  - Member state sentiment heatmap

**Frequency:** Monthly

**Responsible Role:** Legal and Treaty Compliance Committee

**Adaptation Process:** Revise negotiation strategy and seek alternative pathways or derogation options if progress stalls.

**Adaptation Trigger:** No material progress in EU discussions for two consecutive months or opposition from key member states.

### 6. Risk Register and Contingency Monitoring
**Monitoring Tools/Platforms:**

  - Comprehensive risk register
  - Scenario simulation engine
  - Contingency fund utilization dashboard

**Frequency:** Weekly

**Responsible Role:** Risk and Contingency Oversight Board

**Adaptation Process:** Activate contingency plans, reallocate reserves, and update mitigation actions based on risk triggers.

**Adaptation Trigger:** High-impact risk materialization or contingency reserve drawdown >30%.

### 7. Stakeholder Sentiment and Social Pact Monitoring
**Monitoring Tools/Platforms:**

  - Stakeholder feedback portal
  - Social media and hotline analytics
  - Union and employer organization engagement logs

**Frequency:** Monthly

**Responsible Role:** Stakeholder Engagement and Communication Council

**Adaptation Process:** Refine social pacts and wage-price protocols; launch targeted education or corrective campaigns.

**Adaptation Trigger:** Negative sentiment trend or industrial action threat level rising above baseline.

### 8. IT and Payment System Integration Monitoring
**Monitoring Tools/Platforms:**

  - System integration test results
  - Legacy sunsetting progress tracker
  - Interoperability certification status

**Frequency:** Bi-weekly

**Responsible Role:** Dual Circulation Management Office IT Workstream

**Adaptation Process:** Extend integration timelines, provide additional technical support, or adjust certification requirements.

**Adaptation Trigger:** Integration test failure rate exceeding 5% or certification delays beyond agreed milestones.

### 9. Legal and Constitutional Compliance Monitoring
**Monitoring Tools/Platforms:**

  - Referendum design compliance checklist
  - Constitutional review tracker
  - EU legal alignment audit log

**Frequency:** Monthly

**Responsible Role:** Legal and Treaty Compliance Committee

**Adaptation Process:** Revise referendum wording or legal instruments; seek advisory opinions or parliamentary clarifications.

**Adaptation Trigger:** Legal challenge likelihood score above threshold or constitutional review flag.

### 10. Communication and Public Awareness Monitoring
**Monitoring Tools/Platforms:**

  - Public awareness survey platform
  - Message penetration and recall dashboard
  - Misinformation tracking system

**Frequency:** Monthly

**Responsible Role:** Stakeholder Engagement and Communication Council

**Adaptation Process:** Intensify outreach channels, correct misinformation, and adjust messaging for demographic gaps.

**Adaptation Trigger:** Public awareness below 75% or misinformation index exceeding tolerance level.

# Governance Extra

## Governance Validation Checks

1. Point 1: Completeness Confirmation – All core requested components are present: internal_governance_bodies, governance_implementation_plan, decision_escalation_matrix, monitoring_progress, and supporting context (project description, assumptions, scenarios, risks). No critical artifact is missing.
2. Point 2: Internal Consistency Check – Logical alignment across stages is generally maintained: implementation plan references the defined bodies; escalation matrix follows the governance hierarchy; monitoring roles map to committee responsibilities. Minor nuance: the Dual Circulation Management Office is listed as an internal governance body but is also referenced as a PMO office in the implementation plan—clarify whether it is a standing committee or an operational unit to avoid role ambiguity.
3. Point 3: Potential Gaps / Areas for Enhancement – Several nuanced gaps require more detail:
      • Clarity of roles for advisors and independent members: responsibilities, authority limits, and expected contributions are mentioned but not explicitly detailed (e.g., voting rights, confidentiality obligations).
      • Project Sponsor authority: the ultimate Project Sponsor’s role within the governance structure (decision rights, escalation authority, final sign-off) needs explicit definition to prevent bottlenecks.
      • Depth of conflict-of-interest and whistleblower processes: currently referenced at a high level; specific procedures (reporting channels, investigation steps, protections) are underdeveloped.
      • Change control and delegation thresholds: escalation matrix uses broad categories like “Senior Management”; more granular delegation parameters (e.g., thresholds for PMO, Legal, and Nationalbank decisions) would improve operability.
      • Integration across components: audit procedures are linked to monitoring but require stronger traceability to risk register triggers and contingency activation criteria.
4. Point 4: Risk Register and Scenario Specificity – The risk register is comprehensive but would benefit from quantified likelihood/impact scores and explicit linkage to monitoring triggers (e.g., which risk thresholds activate the Risk and Contingency Oversight Board).
5. Point 5: Communication Protocols – Stakeholder engagement and communication council mandates are clear; however, detailed protocols for crisis communication, media handling, and rumor control during dual circulation are not specified.

## Tough Questions

1. Given the multi-year timeline and potential political turnover, what specific mechanisms will ensure continuity of governance decisions and prevent renegotiation of settled design choices?
2. Provide evidence of the current fiscal space (structural deficit, debt trajectory) and explain how Denmark will maintain sufficient budgetary room to fund contingency reserves without compromising convergence criteria.
3. Detail the whistleblower protection framework and the investigative process for ethics violations, including how allegations involving ministers or EU institutions will be handled impartially.
4. What are the precise thresholds and formulas used to set the DKK/EUR parity band before ERM II entry, and how will these interact with ECB monetary policy decisions to avoid policy conflict?
5. Describe the technical validation process for payment system migration, including test environments, penetration testing schedules, and fallback procedures if critical failures occur during cutover.
6. How will the government manage the risk of capital flight or market instability if the referendum passes but convergence metrics are not fully met within the planned timeline?
7. Explain the contingency funding mechanism for euro cash shortages: what is the pre-commitment facility size, trigger conditions, and repayment strategy to avoid fiscal stress?

## Summary

The governance framework adopts a cautious, sequenced Builder path emphasizing domestic readiness, stakeholder alignment, and EU-compliant design. Its strengths include clear multi-year milestones, a structured set of governance bodies, and an integrated risk register. Key focus areas are refining role definitions for advisors and the Project Sponsor, detailing conflict-of-interest and whistleblower processes, specifying delegation thresholds below the Steering Committee, and strengthening integration between audit, monitoring, and contingency triggers.