# Governance Audit


## Audit - Corruption Risks

- Bribery or undue influence targeting Danish FSA or Ministry of Finance personnel responsible for signing off on the final commercial banking compliance certifications required before ERM II entry.
- Nepotism in selecting the single, state-funded technology integrator tasked with mandatory IT upgrades for all municipalities, potentially leading to substandard or inflated contract awards (related to Decision 14).
- Kickbacks or conflicts of interest arising from the selection and contracting of European cash-in-transit security firms for the 30-day dual circulation window, where officials might favor specific providers for transportation or depot management contracts.
- Misuse of internal economic forecasts regarding the final DKK/EUR conversion rate by individuals within Danmarks Nationalbank or the PM's office to benefit related foreign exchange positions prior to public announcement.
- Trading favors between Ministry of Business representatives and Business/Employer Organisations in exchange for favorable, non-binding DKK/EUR contract re-denomination adherence during the transition period (Decision 7).

## Audit - Misallocation Risks

- Misuse of the ring-fenced DKK 50 million contingency fund intended for cash logistics security, potentially diverting funds to cover unexpected operational shortfalls in another unrelated workstream (e.g., IT system shadowing).
- Inefficient allocation of Danish diplomatic resources pursuing an 'Extraordinary European Council session' (Decision 4.2) when resources should have been focused on fulfilling domestic constitutional preparation timelines.
- Double spending on IT system integration by the 'Shadow Integration Team' (Decision 8.1) and the official Central Bank integration track, if the political decision to halt shadow work is delayed, leading to redundant consultant fees.
- Budgetary misuse of public funds allocated for the 'Societal Readiness Pacing' communication campaign (Decision 11), funding political messaging rather than mandatory educational requirements regarding rounding rules or dual pricing.
- Unauthorized use of Danmarks Nationalbank’s advanced sorting and counting machinery (intended for efficient DKK destruction per Decision 13) for non-official commercial purposes during the dual circulation overlap.

## Audit - Procedures

- Bi-annual forensic review of procurement contracts (especially for cash logistics and IT integration consultants) exceeding DKK 25 Million, focusing on sole-source justifications and conflict of interest disclosures, mandated by the Joint Ministerial Consultative Body.
- Quarterly reconciliation of actual expenditure against the inflation-indexed budget baseline, specifically scrutinizing expenditures related to the DKK 100 Million public information allocation to ensure funds are not drawn down prematurely or disproportionately during the ERM II period.
- Pre- and Post-Referendum Audit of Public Information Spend: Verifying compliance with Societal Readiness Pacing (Decision 11) by testing material content against established criteria and confirming disbursement to municipal outreach centers according to defined incentive structures (Decision 14).
- Compliance testing of a statistically significant sample (minimum 15%) of commercial loan and lease agreement files one year post-Euro Day to verify 100% adherence to the mandated 'automatic rounding to the nearest cent' rule (Decision 7), checking ledger entries against preparatory legislation.
- Technical Audit of Danmarks Nationalbank (Post-Shadow Phase): Reviewing the deliverables and technical audit trails from the 'Shadow Integration Team' (Decision 8.1) to confirm that non-binding simulations were executed robustly against ECB benchmarks before official ERM II commencement.

## Audit - Transparency Measures

- Publishing quarterly expenditure reports for the entire DKK 15–25 Billion transition envelope on a dedicated government project website, segmented by the 14 strategic decisions, allowing tracking of cost drivers beyond contingency.
- Mandatory public release of the agenda, key decisions, and Ministerial consensus records from the 'Joint Ministerial Consultative Body' meetings within 14 days, ensuring visibility into decision velocity (Decision 5) while protecting sensitive EU negotiation positions.
- Establishment of a centralized, anonymous whistleblower mechanism managed by an independent external body (not under PM/Ministry oversight) specifically for reporting misuse related to contract awarding for cash logistics and IT integration.
- Public release of the compliance roadmaps published by municipalities detailing their Strategy 14 adherence, allowing citizens to verify local government switchover timelines and service consistency.
- Post-referendum publication of the 'Dual-Path Legal Contingency Mandate' detailing the exact criteria for the automatic repeal of preparatory contract legislation should a 'No' vote occur, ensuring legal clarity for businesses regarding sunk costs and liabilities.

# Internal Governance Bodies

### 1. Project Steering Committee

**Rationale for Inclusion:** Given the high complexity and scale of transitioning Denmark's currency, a dedicated steering committee is essential for providing strategic oversight and ensuring alignment with national objectives.

**Responsibilities:**

- Provide high-level strategic direction for the project.
- Approve significant project milestones and budget allocations above DKK 50 million.
- Oversee strategic risk management and ensure compliance with EU regulations.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Elect Chair and define membership roles.
- Set meeting schedule.

**Membership:**

- Prime Minister
- Minister of Finance
- Minister of Justice
- Minister of Business
- Independent EU law expert

**Decision Rights:** Empowered to approve project milestones and budgets exceeding DKK 50 million.

**Decision Mechanism:** Decisions made by majority vote; in case of a tie, the Chair has the casting vote.

**Meeting Cadence:** Monthly meetings with additional sessions as needed during critical phases.

**Typical Agenda Items:**

- Review project progress and milestones.
- Discuss strategic risks and mitigation strategies.
- Approve budget reallocations and major expenditures.

**Escalation Path:** Issues unresolved after Steering Committee discussions escalate to the Prime Minister.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** The PMO is crucial for managing day-to-day operations, ensuring project execution aligns with strategic goals, and facilitating communication among stakeholders.

**Responsibilities:**

- Manage the operational execution of the project.
- Coordinate between various departments and stakeholders.
- Monitor project timelines and deliverables.

**Initial Setup Actions:**

- Establish project management frameworks and tools.
- Define roles and responsibilities within the PMO.
- Set up communication protocols.

**Membership:**

- Project Manager
- Financial Analyst
- Legal Advisor
- Communications Officer

**Decision Rights:** Empowered to make operational decisions and budget allocations up to DKK 50 million.

**Decision Mechanism:** Decisions made by consensus; if consensus cannot be reached, the Project Manager makes the final decision.

**Meeting Cadence:** Weekly meetings to track progress and address operational issues.

**Typical Agenda Items:**

- Review project status and upcoming tasks.
- Identify and address operational risks.
- Discuss stakeholder engagement and communication strategies.

**Escalation Path:** Unresolved operational issues escalate to the Project Steering Committee.
### 3. Technical Advisory Group

**Rationale for Inclusion:** This group provides specialized technical input on the legal, financial, and operational aspects of the euro adoption process, ensuring compliance with EU standards.

**Responsibilities:**

- Advise on legal and regulatory compliance.
- Provide technical assessments of financial systems integration.
- Review and recommend best practices for public communication.

**Initial Setup Actions:**

- Identify and recruit technical experts from relevant fields.
- Define the group's scope and objectives.
- Establish a meeting schedule.

**Membership:**

- Legal Experts in EU Law
- Financial Systems Analysts
- Public Communication Specialists
- External EU Compliance Consultant

**Decision Rights:** Advisory role with no decision-making authority; recommendations submitted to the PMO.

**Decision Mechanism:** Consensus-based recommendations; if consensus cannot be reached, majority opinion is documented.

**Meeting Cadence:** Bi-monthly meetings or as needed during critical phases.

**Typical Agenda Items:**

- Review compliance with EU convergence criteria.
- Discuss technical integration challenges.
- Evaluate public communication strategies.

**Escalation Path:** Issues requiring further attention escalate to the Project Steering Committee.
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** To ensure that all aspects of the project adhere to ethical standards and compliance regulations, particularly regarding public engagement and financial practices.

**Responsibilities:**

- Monitor compliance with GDPR and other relevant regulations.
- Ensure ethical standards are maintained throughout the project.
- Review public engagement strategies for transparency and fairness.

**Initial Setup Actions:**

- Define the committee's charter and objectives.
- Select independent members to ensure impartiality.
- Establish reporting protocols.

**Membership:**

- Independent Compliance Officer
- Ethics Advisor
- Legal Counsel
- Public Engagement Specialist

**Decision Rights:** Empowered to recommend compliance actions and ethical guidelines; no financial decision-making authority.

**Decision Mechanism:** Decisions made by consensus; if consensus cannot be reached, the Chair has the final say.

**Meeting Cadence:** Quarterly meetings or as needed based on project developments.

**Typical Agenda Items:**

- Review compliance with ethical standards.
- Discuss public engagement strategies and their ethical implications.
- Evaluate risks related to GDPR and other regulations.

**Escalation Path:** Compliance issues escalate to the Project Steering Committee.

# Governance Implementation Plan

### 1. Project Sponsor (Designated Minister) approves the 'Builder's Blueprint' strategy (Decision 5.2, 5.4, 5.11, 5.12) and formally authorizes the creation of the governance structure.

**Responsible Body/Role:** Project Sponsor (Designated Minister)

**Suggested Timeframe:** Project Week 1 (Day 1)

**Key Outputs/Deliverables:**

- Formal Endorsement of 'Builder's Blueprint'
- Authorization Memo for Governance Setup

**Dependencies:**

- Strategic Decisions finalized and adopted

### 2. Project Manager (Acting Lead) drafts the initial Terms of Reference (ToR) for the Project Steering Committee (PSC) and the Project Management Office (PMO), incorporating governance roles defined in Decision 5.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1
- Draft PMO Charter v0.1

**Dependencies:**

- Authorization Memo for Governance Setup

### 3. Project Sponsor officially nominates members and designates the Chair for the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Sponsor (Designated Minister)

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Official PSC Member List & Chair Nomination Letter

**Dependencies:**

- Draft PSC ToR v0.1

### 4. Project Manager (Acting Lead) drafts the initial charters/scopes for the Technical Advisory Group (TAG) and Ethics & Compliance Committee (ECC), ensuring alignment with Decision 9 adherence and Risk 7 mitigation.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft TAG Scope v0.1
- Draft ECC Charter v0.1

**Dependencies:**

- Authorization Memo for Governance Setup

### 5. PSC Chair (once appointed) reviews and approves the PSC ToR and PMO Charter, formally authorizing the PMO to proceed with operational setup and recruitment.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved PSC ToR v1.0
- Approved PMO Charter v1.0

**Dependencies:**

- Official PSC Member List & Chair Nomination Letter
- Draft PSC ToR v0.1

### 6. Project Manager (now operating under PMO Charter) initiates the recruitment/selection process for independent members of the TAG and ECC, utilizing external consultant contacts (Assumption 3, Decision 9).

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 3 - 4

**Key Outputs/Deliverables:**

- Shortlist of TAG/ECC Candidates
- Contracts/Secondment Agreements for External Experts (incl. EU Compliance Consultant)

**Dependencies:**

- Approved PMO Charter v1.0

### 7. PSC Chair approves the final Charters/Scopes for the TAG and ECC based on recommendations from the Project Sponsor.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Approved TAG Scope v1.0
- Approved ECC Charter v1.0

**Dependencies:**

- Draft TAG Scope v0.1
- Draft ECC Charter v0.1

### 8. The newly appointed Project Manager officially assumes leadership and establishes project management framework, communication protocols defined in PMO Charter (Decision 5.2).

**Responsible Body/Role:** Project Manager (PMO)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Established Project Management Tools & Reporting Baseline
- Internal Communication Protocols Document

**Dependencies:**

- Approved PMO Charter v1.0

### 9. Finalize memberships for TAG and ECC. Assign Reporting Officers (Legal Counsel, Compliance Officer) as required by ECC/TAG operational mandates.

**Responsible Body/Role:** Project Manager (PMO) & Project Sponsor

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Final Confirmed Membership Lists for TAG and ECC
- Designation of ECC Independent Compliance Officer

**Dependencies:**

- Shortlist of TAG/ECC Candidates

### 10. Hold the inaugural (kick-off) meeting for the Project Steering Committee (PSC) to confirm governance mandate, review initial priorities (Legal Pathway, ERM Strategy), and approve communication timeline sequencing (Decision 11).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Steering Committee Kick-off Meeting Minutes
- Approved High-Level Timeline reflecting pre-ERM II strategy
- Action Item: PMO to schedule regular monthly meetings

**Dependencies:**

- Final Confirmed Membership Lists for TAG and ECC
- Approved PSC ToR v1.0

### 11. Hold inaugural kick-off meetings for the Project Management Office (PMO), Technical Advisory Group (TAG), and Ethics & Compliance Committee (ECC) to establish operating rhythm and immediate engagement priorities (e.g., Legal/Convergence requirements).

**Responsible Body/Role:** Project Manager (PMO) leading kickoff, Committee Chairs overseeing session

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- PMO Kick-off Minutes & Initial Action Log
- TAG Initial Workplan focusing on Convergence Triage (Decision 9)
- ECC Initial Compliance Review Schedule

**Dependencies:**

- Final Confirmed Membership Lists for TAG and ECC
- Established Project Management Tools & Reporting Baseline

### 12. PMO establishes linkage protocols with the Ministry of Finance for budget tracking and contingency fund management (Assumption 2 & 5), ensuring inflation indexing provisions are captured.

**Responsible Body/Role:** Project Management Office (PMO) & Financial Analyst (within PMO)

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Budget Monitoring Framework v1.0
- Ring-fenced Contingency Account Protocol Established (DKK 50M+)

**Dependencies:**

- Approved PSC ToR v1.0

# Decision Escalation Matrix

**Budget Request Exceeding Steering Committee Authority (>$50M)**
Escalation Level: Project Sponsor (Designated Minister)
Approval Process: Direct Ministerial authorization; requires justification report from PSC detailing alternatives rejected.
Rationale: Exceeds the financial approval limit delegated to the Project Steering Committee ($50 million threshold).
Negative Consequences: Project budget overrun; political liability for unauthorized expenditure; potential delay in funding critical work streams.

**Materialization of Critical Risk 1 (Failure to secure EU opt-out repeal agreement)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Emergency session vote by PSC members using majority rule, potentially calling for immediate diplomatic resource reallocation.
Rationale: This risk fundamentally threatens the project's legal trajectory (Legal Pathway to Opt-Out Removal) and risks exceeding the 8-year timeline limit.
Negative Consequences: Project termination or multi-year timeline extension; political embarrassment; massive sunk cost write-off.

**PMO Deadlock on Cross-Cutting Policy (e.g., finalizing ERM II entry parity guidance)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Submitted for urgent vote by PSC members, requiring ministerial consensus consensus if possible.
Rationale: The PMO requires consensus for operational decisions; deadlock prevents progress on high-priority levers like Exchange Rate Mechanism Entry Strategy.
Negative Consequences: Stagnation of critical monetary policy alignment; inability to meet ECB deadlines; potential market instability.

**Proposed Major Change to Conversion Schedule (e.g., shortening Dual Circulation to <30 days)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Risk review by TAG, followed by PSC vote, ensuring alignment with Societal Readiness Pacing (Decision 11).
Rationale: Such a change significantly alters operational execution (Cash Logistics) and impacts public acceptance, requiring strategic oversight beyond PMO authority.
Negative Consequences: Increased public confusion and operational errors; security risks during high-volume cash withdrawal; potential referendum backlash if perceived as too rushed.

**Reported Breach of Ethical Guidelines (e.g., Transparency Failure in Public Communication)**
Escalation Level: Ethics & Compliance Committee (ECC)
Approval Process: Independent investigation by ECC; recommended non-financial sanctions or corrective actions submitted to PSC.
Rationale: Requires impartial review by the Ethics & Compliance Committee as per its mandate to monitor transparency and fairness in public engagement.
Negative Consequences: Erosion of public trust, impacting referendum outcome (Risk 2); regulatory penalties related to communication fairness.

**Technical Integration Conflict requiring Nationalbank System Re-architecture (Risk 4)**
Escalation Level: Technical Advisory Group (TAG)
Approval Process: TAG consensus recommendation to PMO, with high-cost implications escalating to PSC for approval.
Rationale: Requires specialized technical remediation advice which exceeds the PMO's technical advisory capacity, especially concerning Eurosystem integration.
Negative Consequences: Failure to connect to Eurosystem infrastructure on Euro Day; non-compliance with Central Bank Operational Integration Timeline.

# Monitoring Progress

### 1. Tracking Adherence to 'Builder's Blueprint' Strategic Sequencing
**Monitoring Tools/Platforms:**

  - Project Steering Committee (PSC) Monthly Review
  - Governance Implementation Plan Status Report

**Frequency:** Monthly

**Responsible Role:** Project Steering Committee (PSC)

**Adaptation Process:** If sequencing violations (e.g., negotiating Opt-Out repeal before 12 months of ERM II stability) are identified, the PSC convenes an emergency session to formally re-authorize the deviation or mandate corrective action via the PMO.

**Adaptation Trigger:** Identification of deviation from the chosen strategic path (Builder's Blueprint) regarding the sequencing of political commitment (Opt-Out Repeal) vs. economic proof (ERM II completion).

### 2. Monitoring Critical Risk 1: EU Opt-Out Repeal Negotiation Status
**Monitoring Tools/Platforms:**

  - Diplomatic Engagement Tracker (Managed by Legal Advisor/PMO)
  - Risk Register (Focus on Risk 1)

**Frequency:** Bi-weekly

**Responsible Role:** Legal Advisor (within PMO)

**Adaptation Process:** If negotiation progress stalls or if the EU demands alignment contradicting the planned sequencing (pre-ERM II finalization), the PSC reviews budget reallocation for enhanced diplomatic support (Assumption 1), and the Project Sponsor initiates high-level contact.

**Adaptation Trigger:** No formal progress (e.g., key EU meeting outcome) recorded for 30 days, or if the EU formally insists that treaty amendment discussions must precede the 12-month ERM II stability marker.

### 3. Monitoring Critical Risk 3: Convergence Criteria Achievement Status
**Monitoring Tools/Platforms:**

  - Technical Advisory Group (TAG) Quarterly Compliance Report
  - Danmarks Nationalbank Economic Indicator Dashboard

**Frequency:** Monthly (Input to PSC Monthly Review)

**Responsible Role:** Technical Advisory Group (TAG)

**Adaptation Process:** If projected deficit/inflation trends indicate failure to meet criteria by the projected ERM II exit window, the TAG immediately advises the PSC to initiate stricter fiscal/monetary policy recommendations, potentially requiring changes to Decision 9 (Convergence Triage) priorities.

**Adaptation Trigger:** Projected adherence failure of 3 months or more to two or more primary convergence criteria (Fiscal Deficit, Inflation) before the planned ERM II confirmation review.

### 4. Tracking Referendum Certainty & Societal Readiness (Risk 2 & 6 Mitigation)
**Monitoring Tools/Platforms:**

  - Economic Alignment Stakeholder Forum (EASF) Polling/Feedback Data
  - Societal Readiness Pacing Progress Tracker (tracking campaign reach/sector penetration)

**Frequency:** Quarterly

**Responsible Role:** Communications Officer (within PMO)

**Adaptation Process:** If stakeholder satisfaction targeted at 80% drops below 70%, the PMO must immediately propose increasing the budget allocation for targeted outreach (per Assumption 1) or adjust the messaging strategy, requiring PSC sign-off.

**Adaptation Trigger:** Quarterly EASF results show public confusion rating (Risk 6 metric) above 20% or projected vote intention falling below a 60% mandate threshold.

### 5. Monitoring Critical Risk 4: Technical Integration Status (Shadow Team Progress)
**Monitoring Tools/Platforms:**

  - Shadow Integration Team Technical Progress Reports
  - Risk 4 Mitigation Tracker

**Frequency:** Bi-weekly

**Responsible Role:** Technical Advisory Group (TAG)

**Adaptation Process:** Significant technical slippage triggers TAG escalation to the PSC to approve immediate resource shifts (e.g., diverting earmarked staff from other workstreams) or drawing from the Ring-fenced Contingency Fund (Assumption 5) for urgent specialist contracts/overtime.

**Adaptation Trigger:** Failure of a primary milestone in the Euro Simulation Exercises (ESE) or non-alignment detected in two consecutive TAG technical reviews.

### 6. Monitoring Governance Velocity and Bottlenecks (Risk 9)
**Monitoring Tools/Platforms:**

  - Decision Escalation Matrix Status Log
  - Inaugural PSC Meeting Minutes (tracking decision velocity)

**Frequency:** Monthly

**Responsible Role:** Project Manager (PMO)

**Adaptation Process:** If tracking shows more than two critical items (e.g., ERM guidance, resource allocation disputes) have been deferred or deadlocked in the PSC for more than 14 days, the Project Manager escalates the governance structure efficiency directly to the Project Sponsor for intervention or reinforcement of delegation thresholds.

**Adaptation Trigger:** Two or more high-priority decision types remain unresolved at the PSC level for longer than the mandated response time specified in the Decision Escalation Matrix.

### 7. Monitoring Financial Buffer Health (Inflation/Contingency)
**Monitoring Tools/Platforms:**

  - Budget Monitoring Framework v1.0 (tracking inflation indexing)
  - Ring-fenced Contingency Account Protocol Status

**Frequency:** Quarterly

**Responsible Role:** Financial Analyst (within PMO)

**Adaptation Process:** If actual inflation exceeds projected baseline by 1.0 pp, the Analyst triggers a mandatory governance review by the PSC to approve the release of additional indexed capital from the Treasury buffer or authorize deferral of lower-priority Decoupled Decisions (e.g., Decision 14).

**Adaptation Trigger:** Deviation of actual expenditure or inflation indexation rate from the planned baseline that threatens the real value of the DKK 50M contingency fund.

# Governance Extra

## Governance Validation Checks

1. Completeness Confirmation: All requested core components (bodies, implementation plan, escalation matrix, monitoring plan) appear to have been generated in the provided input files.
2. Internal Consistency Check: The governance framework demonstrates strong alignment with the selected 'Builder's Blueprint' strategy. The PSC structure aligns with the consensus-based 'Joint Ministerial Consultative Body' (Decision 5.2). Escalation paths correctly route budget issues (>$50M) to the Project Sponsor, which aligns with the Project Sponsor's role in approving initial strategy and major budget allocations from the PSC.
3. Internal Consistency Check: The monitoring plan directly tracks the strategic sequencing chosen (Builder's Blueprint) and critical risks identified in the strategic decisions (e.g., monitoring Risk 1: EU Opt-Out Repeal status and Risk 3: Convergence Criteria).
4. Potential Gaps / Areas for Enhancement: Clarity of Roles - The 'Project Sponsor (Designated Minister)' role is central (approving strategy, handling highest escalations), but their specific ministerial portfolio (Finance, PMO Chief of Staff, etc.) is not explicitly named in the PSC membership or roles definitions, only referenced as 'Designated Minister'. This needs formal definition.
5. Potential Gaps / Areas for Enhancement: Process Depth - The 'Ethics & Compliance Committee (ECC)' has governance duties but lacks explicit integration with the detailed corruption/misallocation areas identified in the Phase 1 Audit (e.g., specific audit procedures for cash-in-transit contracting). Clarity is needed on *how* ECC monitors the whistleblower mechanism.
6. Potential Gaps / Areas for Enhancement: Thresholds/Delegation - The split between PSC ($>50M$) and PMO ($<50M$) for budget authority is clear, but there is no defined delegation threshold for the Project Manager to unilaterally approve changes to established internal protocols (e.g., minor adjustments to the EASF schedule, or small scope changes within TAG workstreams).
7. Potential Gaps / Areas for Enhancement: Specificity - The Monitoring Plan identifies adaptation triggers (e.g., 30-day stall in EU negotiation), but lacks defined *ministerial actions* to be taken *immediately* following such a trigger, beyond reviewing budget reallocation or initiating high-level contact. The specific remedial actions must be pre-approved at this stage.

## Tough Questions

1. Given the reliance on the 'Joint Ministerial Consultative Body' (Decision 5.2) for consensus, what is the documented Plan B if one key Minister consistently abstains or delays consensus on urgent ERM II alignment decisions, and how does this impact the 'Governance Velocity' metric tracked by the PMO?
2. The chosen strategy defers formal Opt-Out repeal until *after* 24 months of ERM II stability. If the EU Council formally demands a high-level political commitment to repeal (pre-referendum) as a prerequisite for favorable ERM II terms in Q3 2027, what specific delegated authority does the Project Sponsor have to override the 'Builder's Blueprint' sequencing without triggering a full strategic review?
3. The DKK 50 million contingency fund is indexed for inflation, but how is the ring-fencing mechanism protected against diversion by the PSC, especially if Critical Risk 3 (Convergence Failure) requires costly, last-minute fiscal adjustments not covered by standard operational budgets?
4. How is the Project Steering Committee ensuring that the specialized workforce relies (60% secondments) do not create systemic operational gaps in Danmarks Nationalbank's existing core functions during the multi-year transition, or what is the exit strategy for external EU/ECB consultants if the referendum fails?
5. For the required 'automatic rounding' compliance (Decision 7), what specific legal instrument (Act, Executive Order) sets the precise rounding methodology, and has the Technical Advisory Group validated that this methodology minimizes litigation risk across the 50 largest Danish banks/lenders?
6. The Ethics & Compliance Committee must monitor transparency. Where in the framework is the protocol defined for *retracting* or *correcting* public information released in anticipation of the referendum, should the chosen ERM Entry Strategy (Decision 12) be forced to change by ECB negotiation prior to Euro Day?
7. What is the quantifiable 'hurdle rate' of public confusion (defined by the Communications Officer) that would trigger immediate resource reallocation from the budget allocated for Societal Readiness Pacing (Assumption 1) into remedial local outreach according to the Monitoring Plan?

## Summary

The project governance framework is robustly aligned with the selected 'Builder's Blueprint' strategy, correctly sequencing political commitment behind proven technical convergence milestones. Key strengths lie in establishing clear, differentiated decision-making tiers (PSC vs. PMO) and embedding active monitoring against strategic sequencing and identified critical risks. However, the framework requires immediate refinement to formally define the specific mandate of the Project Sponsor, detail the accountability flow between the ECC and corruption mitigation procedures, and establish pre-approved remedial decision matrices to address potential sequencing conflicts arising from EU institutional demands during the long ERM II period.