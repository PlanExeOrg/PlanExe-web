## Primary Decisions
The vital few decisions that have the most impact.


The vital few levers center on securing political legitimacy and establishing the legal-economic framework for entry. Critical levers are Opt-Out Resolution (legal basis), Legal Pathway (political execution), Referendum Design (public mandate), and Governance Architecture (decision speed). High levers center on the core economic constraints: ERM Entry Strategy and Central Bank Integration. These five pillars address the fundamental tension between political certainty, rapid external alignment, and democratic integrity, which collectively override the purely logistical or downstream execution challenges.

### Decision 1: Legal Pathway to Opt-Out Removal
**Lever ID:** `6e61e622-4747-4854-9e7a-c25d49ad32a9`

**The Core Decision:** This lever defines the political and legal mechanism for Denmark to formally abandon its existing EU opt-out regarding the euro. Success hinges on securing an EU agreement (potentially a treaty change) and aligning domestic constitutional requirements with the agreed-upon EU process. Key metrics are the date of agreement signature and successful passage of required parliamentary and referendum votes.

**Why It Matters:** Choosing a strategy of immediately initiating EU treaty renegotiation to lift the DKK opt-out frontloads the political risk, potentially accelerating the timeline if the EU offers a favorable path. However, this path commits substantial high-level diplomatic resources early and risks a binding political commitment before the domestic economic convergence baseline is definitively secured, potentially leading to a failed referendum due to premature commitment.

**Strategic Choices:**

1. Initiate immediate, high-level EU consultation seeking a fast-track political agreement to repeal the opt-out concurrent with starting ERM II entry preparations.
2. Defer formal opt-out repeal negotiations until after successful completion of a mandatory 24-month minimum ERM II participation and fulfillment of all primary convergence criteria.
3. Propose a legally novel 'Transitional Alignment Protocol' to the European Commission that institutes euro price-level parity for all government accounts without immediately repealing the constitutional opt-out.

**Trade-Off / Risk:** Negotiating treaty repeal early commits significant diplomatic capital, but succeeding removes the existential legal barrier, whereas deferral delays the crucial legal certainty needed for operational planning.

**Strategic Connections:**

**Synergy:** It directly enables Structuring the Pre-Adoption Exchange Rate Mechanism Inclusion by establishing the prerequisite legal foundation for engaging with ERM II framework rules.

**Conflict:** Conflict exists with Public Referendum Design and Timing, as the nature and timing of the opt-out repeal negotiation heavily constrain the date and arguments available for the subsequent mandatory local vote.

**Justification:** *Critical*, This lever defines the fundamental political and legal trajectory. Its conflict with Referendum Design shows it controls the timing and political risk profile of the entire project, making it the primary gate to EU participation.

### Decision 2: Exchange Rate Mechanism Entry Strategy
**Lever ID:** `6d0bcc03-4082-4b2d-ab9d-23450b4041ba`

**The Core Decision:** This focuses on the tactical entry into the Exchange Rate Mechanism II (ERM II), determining the initial DKK parity and fluctuation band before formal adoption. The strategy balances minimizing the shock associated with the fixed parity adjustment against gaining the necessary operational runway within the mechanism. Success is measured by market stability in the months leading up to and following the formal ERM II entry.

**Why It Matters:** The decision on the fixed entry rate of the DKK into the ERM II significantly impacts the competitiveness of Danish exporters immediately following the peg, but a more flexible entry strategy minimizes speculative pressure leading up to the formal peg commitment. Selecting a tight pre-ERM II alignment path accelerates market expectations but increases the short-term domestic industrial shock if the DKK has been overvalued relative to the eventual conversion rate, forcing difficult economic adjustments sooner.

**Strategic Choices:**

1. Maintain the current strict DKK exchange rate policy, effectively treating the Danish Central Bank's current management as an informal ERM II alignment mechanism to minimize the pre-entry shock.
2. Engineer a gradual, managed 12-month pre-ERM appreciation of the DKK against the neutral trading-basket index to preemptively align valuation with projected conversion parity.
3. Advocate for a wide initial fluctuation band within the ERM II structure upon entry, providing the National Bank maximum defensive operational flexibility during the required minimum participation period.

**Trade-Off / Risk:** A preemptive appreciation smooths the entry rate but contracts the domestic economy before the convergence window, while an early flexible band provides operational comfort at the cost of heightened public uncertainty regarding the final parity benchmark.

**Strategic Connections:**

**Synergy:** It is critical for Convergence Standard Harmonization Triage, as the chosen ERM entry point fundamentally pre-determines the necessary fiscal policy adjustments needed to meet the inflation and stability criteria.

**Conflict:** A strategy focusing on aggressive pre-entry appreciation conflicts with Societal Readiness Pacing, as this economic adjustment may cause short-term competitiveness issues that reduce public support before readiness campaigns peak.

**Justification:** *High*, It governs the immediate economic shock and competitiveness adjustment required for Euro adoption. Its strong synergy with Convergence Triage shows it sets the baseline for all subsequent economic restructuring required by the ECB.

### Decision 3: Public Referendum Design and Timing
**Lever ID:** `7739944a-db61-4920-9b9e-002b9ede4449`

**The Core Decision:** This lever establishes the political vehicle, messaging framework, and precise timing for the national referendum deciding on the treaty opt-out removal. Success requires maximizing voter turnout and securing a clear mandate, often by aligning the vote date with periods of confirmed economic stability or key political milestones. Its design profoundly shapes public perception of the financial commitment.

**Why It Matters:** Scheduling the referendum immediately following a period of demonstrable economic convergence post-ERM II entry offers voters maximum certainty regarding stability benefits, yet this timing risks voter fatigue if the preparatory phase is excessively long. Insisting on a highly complex, multi-stage referendum mechanism enhances legitimacy by requiring deeper engagement, but this complexity increases the risk of procedural delays overriding the political momentum generated by the adoption timeline.

**Strategic Choices:**

1. Set the referendum date exactly 90 days prior to the planned Euro Adoption Day, ensuring maximum recent stability data informs the electorate immediately prior to voting.
2. Structure the vote as a binary 'Yes/No' referendum immediately conditional on the Folketinget first affirming fulfillment of the ECB's convergence checklist criteria.
3. Establish a nation-wide deliberative democracy panel across all municipalities to debate key economic impact points for six months before the official referendum campaign commences.

**Trade-Off / Risk:** Tying the vote date closely to adoption maximizes conviction based on recent data, yet delaying the vote until after the ERM period creates a very long window where political opposition can consolidate against the decision.

**Strategic Connections:**

**Synergy:** It is closely linked to Legal Pathway to Opt-Out Removal, as the complexity and necessity of the required treaty process directly impose constraints on the feasible timing and permissible legal structure of the vote.

**Conflict:** The timing of the referendum directly impacts Commercial Contract Re-denomination Strategy; a vote held too early might force an earlier operational deadline, straining businesses preparing for contract realignment.

**Justification:** *Critical*, This lever controls the democratic mandate gate. Its deep synergy with the Legal Pathway choice dictates that the political success narrative and timing are inextricably linked to securing the EU agreement.

### Decision 4: Opt-Out Resolution Mechanism Selection
**Lever ID:** `bc902349-db45-4b43-83e7-f8c081a8c073`

**The Core Decision:** This lever chooses the binding legal mechanism—treaty amendment or political declaration—to revoke the DKK opt-out. The choice dictates the project's domestic legislative complexity and external negotiation duration. Success hinges on securing the highest level of political buy-in across the EU while minimizing procedural risk and constitutional friction domestically.

**Why It Matters:** Choosing the path of treaty amendment versus utilizing an implicit political agreement with the EU institutions for the opt-out removal dictates the required domestic legislative rigor and timeline dependency on the European Parliament and Council. A full treaty review significantly extends the legal preparation phase, demanding multiple rounds of parliamentary debate and potentially triggering unforeseen constitutional challenges within the Danish legal system.

**Strategic Choices:**

1. Initiate high-level political dialogue seeking a Commission declaration that accession to ERM II constitutes de facto suspension of the opt-out, bypassing formal treaty amendment negotiation.
2. Formally request an Extraordinary European Council session to debate a targeted protocol amendment to the Treaty on European Union specifically addressing the Danish opt-out waiver mechanism.
3. Prepare parallel domestic legislation for two scenarios: one contingent on a successful referendum and another that uses existing national law to unilaterally rescind the opt-out declaration subject to ECB approval.

**Trade-Off / Risk:** Formal treaty amendment introduces significant dependency risk on 27 other member states and the Parliament, whereas a political declaration relies heavily on favorable current EU political sentiment and ECB alignment.

**Strategic Connections:**

**Synergy:** This lever must precede and inform the Legal Pathway to Opt-Out Removal by defining the specific legal framework and timeline constraints that the pathway must adhere to for execution.

**Conflict:** It creates inherent tension with Public Referendum Design and Timing, as a complex, multi-year treaty amendment path necessitates delaying the referendum until external negotiations are sufficiently advanced.

**Justification:** *Critical*, This is the core choice for the legal foundation: treaty change complexity vs. political negotiation risk. It directly determines the timeline dependency against the EU institutions.

### Decision 5: Inter-Agency Governance Architecture
**Lever ID:** `39194a2e-2f74-49dd-a717-a62007f9030a`

**The Core Decision:** This lever establishes the top-level decision-making body and structures required to coordinate the complex interdependencies between legal requirements, central bank operations, and regulatory oversight. Success relies on clear delegation, preventing agency silos while ensuring expert input shapes binding directives promptly. Key metrics are decision velocity and integration success across financial and operational domains.

**Why It Matters:** The structure for decision-making among the Prime Minister's Office, Danmarks Nationalbank, and the Danish FSA determines the speed of cross-domain issue resolution, such as payment system compliance versus banking stability oversight. A centralized steering committee prevents departmental silos but risks bottlenecks at the ministerial level for operational directives.

**Strategic Choices:**

1. Establish a single, small 'Euro Transition Authority' chaired by the Prime Minister's Chief of Staff, empowered to issue binding executive directives across all implementing ministries and agencies.
2. Maintain agency autonomy under a quarterly 'Joint Ministerial Consultative Body,' requiring consensus among Finance, Justice, and Business Ministers for any cross-cutting policy change.
3. Delegate immediate operational decision-making authority for IT and logistics solely to Danmarks Nationalbank, restricting Ministerial oversight to only legal and political compliance checkpoints.

**Trade-Off / Risk:** Granting executive authority to a centralized office streamlines speed but risks bypassing necessary expert review from specialized agencies, potentially leading to technical integration failures.

**Strategic Connections:**

**Synergy:** It amplifies Central Bank Operational Integration Timeline by ensuring directives for integration are rapidly approved, and enables Opt-Out Resolution Mechanism Selection through clear executive buy-in.

**Conflict:** It risks slowing down the Convergence Standard Harmonization Triage if the centralized authority becomes a bottleneck, or conflicts with the flexibility needed by the Public Referendum Design and Timing.

**Justification:** *Critical*, This defines the decision velocity for the entire complex project. Its ability to streamline approval for the Legal Pathway and Operational Integration makes it a fundamental control point for managing cross-silo risk.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Cash Logistics and Dual Circulation Duration
**Lever ID:** `837b8145-1495-4c09-82c2-946802b300b4`

**The Core Decision:** This determines the length of the overlap period where both DKK and EUR cash circulate. A shorter duration minimizes the complex inventory management and security overhead for banks and the Nationalbank, but increases consumer stress and limits adaptation time. Success is gauged by the speed of DKK withdrawal rate and the incidence of dual-currency errors post-Euro Day.

**Why It Matters:** A shorter dual circulation period drastically reduces the complexity and cost associated with managing two parallel payment infrastructures and stock levels of dual currency, but significantly increases the operational burden and risk of error for retailers and the public. Allocating substantial upfront budget for dual-circulation logistics accelerates public acceptance but increases sunk costs should the referendum fail, necessitating rapid write-offs for printing and distribution setup.

**Strategic Choices:**

1. Implement an aggressive 30-day dual circulation period, focusing resources heavily on national media campaigns and providing immediate, high-volume cash exchange booths staffed by the Nationalbank.
2. Mandate a six-month dual circulation period structured around seasonal business cycles, allowing small businesses adequate time to exhaust existing DKK stock before mandatory conversion deadlines.
3. Circulate only Euro coins during the first three months of dual circulation, requiring all large-value DKK transactions to be settled exclusively via cashless digital transfer until Euro notes are fully deployed.

**Trade-Off / Risk:** A short circulation window maximizes infrastructure efficiency but strains public adaptation speed, imposing a high behavioral change cost, contrasted with a long window that inflates logistics overhead and defers the final separation point.

**Strategic Connections:**

**Synergy:** This length directly dictates the resource allocation required for Operationalizing National Bank Capacity for Cash Conversion Logistics, as a shorter period demands massive upfront deployment capacity.

**Conflict:** A very short dual circulation period conflicts with Societal Readiness Pacing, as it accelerates the required behavioral change speed beyond what broad public assimilation campaigns can realistically manage.

**Justification:** *High*, This is the most visible operational trade-off (Speed vs. Public Stress). Its conflict with Societal Readiness Pacing highlights its role in managing immediate public friction during the final conversion phase.

### Decision 7: Commercial Contract Re-denomination Strategy
**Lever ID:** `68ea1c18-1da4-43b1-9fc6-18cdacf7ab6a`

**The Core Decision:** This lever defines the legal mandate governing how pre-existing financial obligations denominated in DKK—like loans, leases, and service agreements—must be converted to EUR. The primary goal is minimizing post-adoption litigation and ensuring fair rounding. Success criteria involve low rates of documented contractual disputes in the first year following full conversion.

**Why It Matters:** Mandating immediate contractual re-denomination by the government significantly reduces post-adoption legal friction for consumers, but it forces thousands of private entities (especially older, less dynamic firms) to overhaul legacy contracts before the technical readiness window is mature. Allowing businesses greater latitude in the timing of conversion smoothens immediate private sector burden, yet it creates significant market confusion due to the existence of active DKK and EUR price points across various sectors simultaneously.

**Strategic Choices:**

1. Legislate a 'no-change' rule for all existing private long-term contracts (e.g., mortgages, leases) requiring automatic rounding to the nearest cent upon the Euro Day, with no clause permitting renegotiation prior.
2. Institute a mandatory 18-month transition phase where all new debt and service contracts must quote pricing in both DKK and EUR, with DKK pricing being explicitly non-binding after the first conversion warning date.
3. Require Danmarks Nationalbank to sponsor an industry-specific software patch for major ERP systems covering the 100 largest employers to automate mandatory re-denomination of their price lists and payroll structures.

**Trade-Off / Risk:** Forcing automated contract change resolves legal uncertainty quickly but overwrites private agreements, while allowing market flexibility reduces immediate compliance strains but risks protracted dual-pricing confusion and potential consumer exploitation.

**Strategic Connections:**

**Synergy:** Effective implementation synergizes with Cash Logistics and Dual Circulation Duration by establishing a clear legal end-point for DKK pricing, minimizing ambiguity during the physical circulation window.

**Conflict:** Heavy-handed legislative standardization of re-denomination can negatively impact Societal Readiness Pacing by creating unnecessary perceived government interference in private financial arrangements, potentially lowering acceptance.

**Justification:** *Medium*, Important for minimizing post-adoption litigation, but it is fundamentally an execution detail that flows from the decisions made in the legal and timing levers; less central than setting the political path.

### Decision 8: Central Bank Operational Integration Timeline
**Lever ID:** `2ddb66fc-1de0-411c-bf8e-351278e0f4c3`

**The Core Decision:** This lever defines the phased timeline for integrating Danmarks Nationalbank's core operational systems with the ECB's infrastructure, such as payment mechanisms. Success is measured by adherence to technical milestones aligning with ERM II entry requirements. Early linkage speeds technical readiness but strains current budgets; late integration risks crucial operational gaps unless contingency protocols are robustly simulated.

**Why It Matters:** Integrating Danmarks Nationalbank operations with ECB systems (e.g., TARGET2) early streamlines technical exchange linkage required for ERM II, but this early integration demands significant upfront investment in staff training and cybersecurity readiness before the political mandate is fully secured. Phasing in technical integration strictly after the referendum result allows resource allocation to follow political certainty, but this deferral risks pushing the technical delivery timeline dangerously close to the mandatory Euro Day hard deadline.

**Strategic Choices:**

1. Establish a parallel 'Shadow Integration Team' reporting to the Ministry of Finance to conduct full-scale, non-binding linkage simulations with the ECB/Eurosystem irrespective of the political path chosen.
2. Condition all primary system integration efforts solely on the successful passage of the national referendum, pausing all significant preparatory work until the political decision unlocks the required EU negotiation mandate.
3. Immediately embed designated analysts from the National Bank within the ECB's monetary operations division for a full two-year rotational assignment focused solely on infrastructure alignment documentation.

**Trade-Off / Risk:** Shadow integration reduces political exposure if the vote fails but risks technical integration cascading delays due to lack of institutional authority, contrasting with embedding staff early which secures expertise but incurs immediate overhead costs regardless of political outcome.

**Strategic Connections:**

**Synergy:** It strongly amplifies the Exchange Rate Mechanism Entry Strategy by ensuring technical systems are ready to support formal currency stability requirements when ERM II entry is confirmed.

**Conflict:** It directly competes for resources with Structuring the Pre-Adoption Exchange Rate Mechanism Inclusion, as both demand senior technical staff alignment with external financial bodies simultaneously.

**Justification:** *High*, Governs the technical readiness of the Nationalbank to function within the Eurosystem. Its conflict with ERM Entry Strategy shows that technical capacity is a major constraint on the economic timeline.

### Decision 9: Convergence Standard Harmonization Triage
**Lever ID:** `7dbdf914-5c83-4fde-8b84-7d6313043587`

**The Core Decision:** This strategy dictates how aggressively Denmark adopts the European System of Central Banks (ESCB) standards, both mandatory and non-binding, within Danmarks Nationalbank pre-adoption. Success is gauged by audit readiness against convergence criteria benchmarks. Aggressive adoption mitigates future compliance risk but requires significant internal restructuring capital long before certainty.

**Why It Matters:** Determining the strictness of adopting ECB and Eurosystem operational standards before formal ERM II entry sets the pace for Danmarks Nationalbank's internal restructuring and IT modernization efforts. Overly aggressive convergence adoption incurs high upfront adaptation costs but accelerates readiness, mitigating future compliance shocks upon entry.

**Strategic Choices:**

1. Prioritize achieving primary convergence criteria (e.g., inflation, deficit) and defer non-binding ECB best practice recommendations on internal operational procedures until post-adoption.
2. Immediately implement the full suite of ECB statistical reporting frameworks and governance structures within Danmarks Nationalbank to achieve maximal institutional alignment prior to ERM II entry commitment.
3. Adopt negotiated 'phased-in' convergence milestones for operational alignment, focusing initially only on exchange rate stability mechanisms while delaying secondary regulatory harmonization.

**Trade-Off / Risk:** Prematurely adopting non-binding ECB governance structures may unnecessarily strain Nationalbank resources, yet deferring crucial operational alignment risks failing the mandatory compliance audit required for formal entry.

**Strategic Connections:**

**Synergy:** It strongly synergizes with Central Bank Operational Integration Timeline by setting the internal, quality-of-service requirements that the technical integration processes must meet for full system compatibility.

**Conflict:** It conflicts with Convergence Standard Harmonization Triage if aggressive internal restructuring prematurely consumes resources better allocated to immediate legal preparations mandated by Opt-Out Resolution Mechanism Selection.

**Justification:** *Medium*, This dictates internal restructuring quality. It’s important, but it is largely dictated by the constraints set by the ERM Entry Strategy and Operational Integration Timeline, making it a dependent execution strategy.

### Decision 10: Cash Stock Synchronization Strategy
**Lever ID:** `a4abd6f2-751d-4619-a810-96f46b774c0e`

**The Core Decision:** This lever governs the logistics of securing, managing, and distributing the initial mass of EUR notes and coins versus destroying DKK cash. Success metrics involve minimizing public disruption during conversion and reducing security costs. It requires precise forecasting of retail, banking, and ATM cash needs across the dual circulation window.

**Why It Matters:** The timing and scale of the mandated DKK destruction and EUR introduction must be managed against forecasted consumer demand spikes and logistical resilience across regional distribution channels. Understocking the initial euro supply risks public panic and reliance on informal exchange rates, while excessive physical inventory incurs high security and warehousing costs during the dual circulation phase.

**Strategic Choices:**

1. Execute a highly centralized, single-day 'Big Bang' cash exchange coordinated precisely with the currency withdrawal deadline, requiring maximum front-loaded logistics provisioning.
2. Implement a managed, regionalized rollout of common dual-denomination goods pricing followed by a staggered two-month dual circulation period, allowing Northern regions to absorb initial demand shocks.
3. Establish secured, temporary 'Buffer Stock Depots' in three non-urban logistical hubs managed solely by the Treasury and Nationalbank to circumvent commercial bank distribution bottlenecks during the first 30 days.

**Trade-Off / Risk:** Centralized Big Bang minimizes confusion but escalates immediate risk exposure to logistics failure, whereas staggered rollout might artificially extend the DKK's psychological price relevance beyond the official timeline.

**Strategic Connections:**

**Synergy:** It directly enables the success of Operationalizing National Bank Capacity for Cash Conversion Logistics by providing the specific timing and volume forecasts needed for logistical planning and execution.

**Conflict:** It poses a trade-off with Commercial Contract Re-denomination Strategy; focusing heavily on physical cash logistics might delay necessary legal focus on resolving contractual conversion ambiguity.

**Justification:** *Medium*, A vital logistical component, but it is focused on executing the outcome defined by the Cash Logistics duration lever; its impact is primarily on cost efficiency and distribution friction, not fundamental strategic direction.

### Decision 11: Societal Readiness Pacing
**Lever ID:** `c2264783-106d-43b2-ad83-164107e4d9e1`

**The Core Decision:** This lever manages the timing and substance of public engagement campaigns to ensure citizens and businesses understand the transition timeline, dual pricing, and operational changes. Success is determined by standardized surveys showing high levels of awareness and low levels of reported confusion post-conversion events, balancing educational breadth with political sequencing.

**Why It Matters:** The intensity and sequencing of public information campaigns influence citizen trust and preparedness for mandatory dual-pricing and rounding rules, especially among vulnerable populations. A high-intensity campaign risks public fatigue and burnout well before the final adoption date, while a low-intensity campaign may result in mass operational errors during the conversion window.

**Strategic Choices:**

1. Launch a single, all-encompassing, high-authority communication blitz 18 months prior to conversion, using mandatory televised public service announcements across all channels.
2. Sustain a continuous, low-frequency educational stream targeting specific sectors (SMEs, pensioners, retail) via dedicated municipal outreach centers rather than relying solely on national media saturation.
3. Defer all major public information investment until after the referendum outcome, concentrating messaging solely on technical implementation requirements for financial supervisors and large corporations initially.

**Trade-Off / Risk:** A premature high-intensity campaign wastes resources if the referendum fails, conversely, post-referendum delay eliminates the necessary time buffer for comprehensive operational retraining across SMEs.

**Strategic Connections:**

**Synergy:** It is critical for supporting Public Referendum Design and Timing, as effective readiness messaging must prime the electorate before they cast their vote on the currency change.

**Conflict:** An overly ambitious Societal Readiness Pacing can strain capacity needed for the initial phases of Commercial Contract Re-denomination Strategy, diverting communication resources prematurely.

**Justification:** *High*, While execution-focused, success hinges on public acceptance, which is crucial for constitutional change. Its synergy with the Referendum lever (the mandate gate) elevates its importance over mere logistical campaigns.

### Decision 12: Structuring the Pre-Adoption Exchange Rate Mechanism Inclusion
**Lever ID:** `c7d3bbe1-d871-46b8-9783-eaebfb03581c`

**The Core Decision:** This strategic choice defines the path for securing the necessary ECB approval by managing the DKK's exchange rate stability before formal adoption. The primary goal is to meet ERM II criteria effectively, balancing market signaling against the domestic monetary policy constraints imposed by managing the DKK's fluctuations against the Euro target.

**Why It Matters:** Entry into ERM II stabilizes the DKK/EUR relationship, satisfying a key ECB prerequisite while signalling serious intent to markets and locking the central bank's operational stance. However, maintaining the DKK's current tight fluctuation band against the EUR creates significant domestic interest rate pressure and potential volatility within the Danish mortgage market if the linkage requires interest rate adjustments to maintain parity commitment.

**Strategic Choices:**

1. Enter ERM II immediately post-referendum approval, committing to the widest allowable fluctuation band permitted under standard rules to provide operational flexibility for monetary policy stabilization.
2. Negotiate a bespoke, narrower fluctuation band target with the ECB *prior* to formal ERM II entry, leveraging historical DKK stability to achieve early convergence signal, accepting higher immediate domestic rate pressure.
3. De-link the DKK peg from the fixed band environment entirely during the target two-year ERM II period, focusing purely on achieving inflation and deficit targets while keeping the final rate flexible until the 'hard' entry date.

**Trade-Off / Risk:** Negotiating a bespoke band limits the necessary signaling effect to the markets, potentially extending the overall convergence period because the ECB prioritizes demonstrated stability within the established framework.

**Strategic Connections:**

**Synergy:** Success here is foundational for the Exchange Rate Mechanism Entry Strategy and provides the anchor point required for the Commercial Contract Re-denomination Strategy's timing.

**Conflict:** Aggressive or non-standard structuring creates immediate tension with the Exchange Rate Mechanism Entry Strategy by altering expected EU negotiation parameters, and complicates Convergence Standard Harmonization Triage.

**Justification:** *High*, This is the formal negotiation point of the economic entry. It directly constrains the Exchange Rate Mechanism Entry Strategy by setting the official terms of the DKK's long-term rigidity.

### Decision 13: Operationalizing National Bank Capacity for Cash Conversion Logistics
**Lever ID:** `2c321248-caf2-49c3-97de-3f52f03b0eb8`

**The Core Decision:** This focuses purely on the physical challenge of managing the currency's lifecycle: collecting, verifying, transporting, and destroying the DKK after the Euro day. Success is measured by the speed of DKK withdrawal, minimizing security incidents, and maintaining public trust through logistical reliability; it requires massive, secured infrastructure planning.

**Why It Matters:** The complete withdrawal of the DKK requires the National Bank to manage the physical destruction or recirculation of billions of kronen notes and millions of coins, a process demanding significant secure storage expansion and logistical contracts. Over-investing in temporary sorting and destruction infrastructure creates stranded assets post-transition, whereas under-investing risks massive bottlenecks in the final DKK withdrawal phase, leading to public dissatisfaction.

**Strategic Choices:**

1. Contract with multiple specialized European cash-in-transit security firms for parallel, geographically dispersed cash collection routes to minimize single-point failure risk during the withdrawal window.
2. Rely primarily on the commercial banking network for the initial bulk collection of DKK, dedicating National Bank facilities only to the final exchange and destruction protocols, minimizing public capital outlay.
3. Mandate that all commercial entities above a specified revenue threshold must purchase and use specialized, ECB-approved DKK counting and sorting machines in the final six months to diffuse collection volume.

**Trade-Off / Risk:** Over-reliance on commercial bank primary collection shifts the burden of verification and security during the high-risk accumulation phase onto entities less centrally accountable for final currency integrity.

**Strategic Connections:**

**Synergy:** It directly enables the Cash Logistics and Dual Circulation Duration by ensuring the physical mechanism for supply removal is robust, and coordinates manpower via the Societal Readiness Pacing.

**Conflict:** Large capital outlays here constrain the budget available for the Societal Readiness Pacing public outreach campaigns, and rapid execution risks conflicting with prudent financial management implied by Convergence Standard Harmonization Triage.

**Justification:** *Medium*, Highly technical and resource-intensive, this is the execution engine for physical currency management. It is subordinate to the Cash Logistics Duration lever, which sets the strategic tempo for withdrawal.

### Decision 14: Strategy for Aligning Municipal and Regional Public Service Conversion
**Lever ID:** `bf46e777-fb8a-4663-972d-65b3126f201b`

**The Core Decision:** This lever addresses ensuring consistency and fairness across all sub-national governmental entities regarding the operational switch to EUR accounting and pricing. It requires balancing the efficiency of centralized mandates against the reality of diverse local IT maturity and budgetary capacity across municipalities and regions.

**Why It Matters:** Local governments operate highly devolved IT systems for taxation, utilities, and subsidies, which must all align to the new rounding rules and dual-currency accounting during the transition. A centralized directive offers consistency but risks slow local adaptation due to outdated systems, while granting local autonomy risks creating pockets of non-compliance and inconsistent citizen services across different regions.

**Strategic Choices:**

1. Centralize the mandate for all municipal IT system upgrades through a single, state-funded technology integrator, enforcing a uniform changeover schedule regardless of local system age or disruption.
2. Provide targeted financial incentives managed by the Ministry of Finance for municipalities that demonstrate they can achieve full EUR compliance 90 days ahead of the national target, promoting internal competition.
3. Allow individual municipalities to choose their conversion approach—either full dual-system operation until the cutoff or immediate 'Euro-first' accounting—provided they publish a clear public compliance roadmap quarterly.

**Trade-Off / Risk:** Granting local autonomy creates significant fragmentation in the citizen experience, potentially leading to protracted disputes over local fees and tax assessments during the critical first year of adoption.

**Strategic Connections:**

**Synergy:** Alignment here accelerates the Societal Readiness Pacing by ensuring citizens face consistent public service conversion, and supports smooth execution of Cash Logistics and Dual Circulation Duration for local cash handling.

**Conflict:** Centralized mandates risk creating friction with the Inter-Agency Governance Architecture if local implementation conflicts arise, and may clash with existing budgetary limitations underlying Convergence Standard Harmonization Triage efforts.

**Justification:** *Low*, This is a necessary, but highly localized, implementation detail concerning compliance consistency across sub-national entities. It is a downstream consequence of the national readiness and governance choices.
