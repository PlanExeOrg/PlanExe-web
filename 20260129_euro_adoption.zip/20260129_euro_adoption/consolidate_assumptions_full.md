# Purpose

**Purpose:** business

**Purpose Detailed:** A structured, ministerial-level plan outlining the legal, political, economic, operational, and communication steps required for Denmark to replace the Danish krone with the euro, respecting the current EU opt-out and requiring treaty change and referendum.

**Topic:** Denmark national transition plan to adopt the euro as national currency

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** The plan is a high-level national transition strategy that requires physical, real-world actions: government decision-making, parliamentary processes (Folketinget), treaty negotiations with EU institutions, national referendums, central bank operations, commercial bank system upgrades, payment system changes, public communication campaigns, and logistical cash conversion. Even though the output is a document, executing the plan demands physical coordination, legal proceedings, political processes, and economic infrastructure changes that cannot be automated or performed digitally.

# Physical Locations

This plan **does not** imply any physical location.
No requirements for the physical location.

## Location 1
Denmark

Copenhagen

Christiansborg Palace, 1218 Copenhagen

**Rationale**: The seat of Denmark's Parliament and government ministries, ideal for coordinating inter-ministerial leadership, Folketinget proceedings, and high-level treaty negotiations.

## Location 2
Denmark

Copenhagen

Danmarks Nationalbank headquarters, 1650 Copenhagen

**Rationale**: Critical for overseeing monetary policy, ERM II readiness, liquidity management, and the technical transition of central bank reserves and payment systems.

## Location 3
European Union

Brussels

European Commission and Eurogroup meeting venues

**Rationale**: Necessary for formal EU negotiations on treaty derogation, ERM II conditions, and securing alignment with ECB convergence criteria and regulatory approvals.

## Location 4
Denmark

Aarhus

Aarhus City Hall and municipal IT infrastructure hub

**Rationale**: Key for piloting municipal dual-circulation management, public communication outreach, and testing localized cash conversion logistics outside Copenhagen.

## Location Summary
No location is strictly required by the plan’s content, as it is a ministerial-level document. However, four real-world sites are suggested to support execution: Christiansborg Palace for political leadership; Danmarks Nationalbank for monetary/technical transition; EU venues for treaty negotiations; and Aarhus City Hall for municipal pilot implementation.

# Currency Strategy

This plan involves money.

## Currencies

- **DKK:** Local currency of Denmark; included for domestic transactions during dual circulation period.
- **EUR:** Target currency for adoption; required for EU integration and as primary currency for budgeting.
- **USD:** Stable international currency included due to currency instability risks; used for international reporting and as a reference to mitigate hyperinflation and exchange-rate uncertainty.

**Primary currency:** EUR

**Currency strategy:** For local transactions, use DKK during the dual-circulation period and transition to EUR for all official budgeting and reporting. For international and stability-sensitive planning, use USD as a stable reference. Manage currency risk by aligning with ECB monetary policy, using forward contracts where necessary, and communicating clearly with stakeholders to minimize exchange-rate volatility impacts.

# Identify Risks


## Risk 1 - Regulatory & Permitting
Failure to secure necessary EU agreement for treaty change to lift the opt-out. This could be due to political opposition from other member states, failure to meet EU requirements, or unforeseen legal challenges.

**Impact:** Project termination or indefinite delay. Could result in significant wasted resources and reputational damage for the government. A delay of 2-5 years or complete project termination.

**Likelihood:** Medium

**Severity:** High

**Action:** Engage in proactive and sustained diplomatic efforts with key EU member states and institutions. Ensure full compliance with all EU requirements and proactively address any concerns raised by the EU Commission, ECB, or Eurogroup. Develop alternative negotiation strategies and fallback positions.

## Risk 2 - Political
Referendum fails to secure public support for euro adoption. This could be due to public concerns about loss of sovereignty, economic uncertainty, or lack of trust in the government.

**Impact:** Project termination. Significant political damage to the government. A delay of 5+ years or complete project termination.

**Likelihood:** Medium

**Severity:** High

**Action:** Develop a comprehensive communication and public engagement strategy to address public concerns and build support for euro adoption. Ensure transparency and provide clear and accurate information about the benefits and costs of euro adoption. Tailor messaging to different segments of the population. Consider a preliminary, non-binding referendum to gauge public opinion early in the process.

## Risk 3 - Economic & Financial
Failure to meet the Maastricht convergence criteria, particularly regarding inflation, government debt, or exchange rate stability. This could delay or prevent euro adoption.

**Impact:** Delay in euro adoption. Increased economic uncertainty and volatility. Damage to Denmark's reputation. A delay of 1-3 years.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Implement sound fiscal and monetary policies to ensure compliance with the Maastricht criteria. Closely monitor economic indicators and take corrective action as needed. Maintain close coordination with the ECB and other EU institutions. Develop contingency plans to address potential economic shocks.

## Risk 4 - Operational
Difficulties in converting IT systems, payment systems, and financial contracts to the euro. This could disrupt economic activity and create confusion.

**Impact:** Disruptions to financial markets and payment systems. Increased costs for businesses and consumers. Reputational damage. A delay of 3-6 months and an extra cost of 10,000,000-50,000,000 DKK.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a detailed conversion plan with clear timelines and responsibilities. Provide technical assistance and training to businesses and financial institutions. Conduct thorough testing of all systems before the conversion date. Implement a phased conversion approach to minimize disruption. Mandate dual pricing for a period of time.

## Risk 5 - Social
Public resistance to rounding rules and price changes. This could lead to social unrest and undermine support for euro adoption.

**Impact:** Social unrest. Damage to public trust. Increased political opposition. A delay of 1-6 months and an extra cost of 1,000,000-5,000,000 DKK.

**Likelihood:** Low

**Severity:** Medium

**Action:** Develop clear and transparent rounding rules. Provide public education about the impact of rounding on prices. Engage with consumer groups and other stakeholders to address concerns. Consider measures to mitigate the impact of rounding on low-income households. Conclude a formal Social Pact with major employer organizations and trade unions, legally binding them to a negotiated set of rounding rules for collective agreements and public sector wages before the referendum is called.

## Risk 6 - Technical
Failure of critical IT systems during the conversion process. This could disrupt financial transactions and create widespread chaos.

**Impact:** Significant disruption to financial markets and payment systems. Loss of public trust. Reputational damage. A delay of 1-4 weeks and an extra cost of 5,000,000-20,000,000 DKK.

**Likelihood:** Low

**Severity:** High

**Action:** Conduct rigorous testing of all IT systems before the conversion date. Develop contingency plans to address potential system failures. Ensure adequate backup systems are in place. Provide technical support to businesses and financial institutions. Implement a 'Big Bang' conversion of all outstanding financial contracts, wages, and central bank accounts to the euro on a single pre-determined Day One, minimizing the administrative burden of prolonged dual-currency operations.

## Risk 7 - Supply Chain
Inadequate supply of euro banknotes and coins. This could lead to cash shortages and undermine public confidence.

**Impact:** Cash shortages. Public dissatisfaction. Damage to the credibility of the conversion process. A delay of 1-2 weeks and an extra cost of 1,000,000-5,000,000 DKK.

**Likelihood:** Low

**Severity:** Medium

**Action:** Establish a secure and reliable supply chain for euro banknotes and coins. Coordinate with the ECB and other euro area countries to ensure adequate supply. Establish centralized, government-managed cash-in-transit hubs across all major municipalities to manage parallel DKK withdrawal and EUR issuance for the first month, creating a buffer against initial commercial bank distribution failures.

## Risk 8 - Security
Increased risk of counterfeiting and fraud during the dual circulation period. This could undermine public confidence in the euro.

**Impact:** Increased counterfeiting and fraud. Loss of public trust. Damage to the reputation of the euro. An extra cost of 500,000-2,000,000 DKK.

**Likelihood:** Low

**Severity:** Low

**Action:** Implement measures to prevent counterfeiting and fraud. Provide public education about the security features of euro banknotes and coins. Strengthen law enforcement efforts to combat counterfeiting and fraud. Mandate all large retailers and supermarkets to assume the function of DKK exchange points during the dual circulation period, offering euro change for DKK payments, thereby distributing the logistical cost and liability across private sector distribution networks.

## Risk 9 - Financial
Unexpected costs associated with the conversion process. This could strain the government budget and lead to unpopular spending cuts.

**Impact:** Budget overruns. Reduced funding for other government programs. Public dissatisfaction. An extra cost of 10,000,000-100,000,000 DKK.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a detailed budget for the conversion process. Closely monitor spending and identify potential cost savings. Seek financial assistance from the EU if needed. Implement a conditional legislative trigger that activates only after a positive referendum, optimizing resource use and timeline management.

## Risk 10 - Market/Competitive
Negative market reaction to the euro adoption process. This could lead to capital flight and economic instability.

**Impact:** Capital flight. Economic instability. Increased borrowing costs. A delay of 6-12 months and an extra cost of 5,000,000-25,000,000 DKK.

**Likelihood:** Low

**Severity:** Medium

**Action:** Maintain close communication with financial markets. Implement sound economic policies to maintain investor confidence. Develop contingency plans to address potential market volatility. Announce a broad, officially sanctioned fluctuation band around the current traded central rate, signaling intent without locking the final conversion rate ahead of formal ERM II entry.

## Risk summary
The most critical risks are the failure to secure EU agreement for treaty change and the failure to win public support in the referendum. These risks could lead to project termination and significant political damage. Effective mitigation strategies include proactive diplomatic engagement, comprehensive public communication, and sound economic policies. The financial and technical risks, while significant, can be managed through detailed planning, rigorous testing, and adequate resources. A key trade-off is between the speed of the conversion process and the level of disruption to the economy and society. The 'Builder' scenario, with its emphasis on staged, reversible actions and robust domestic readiness, is the most appropriate approach for managing these risks.

# Make Assumptions


## Question 1 - What specific legal and treaty steps are required to lift Denmark's EU opt-out and establish a binding roadmap for euro adoption?

**Assumptions:** Assumption: The EU and Denmark can agree on a simplified treaty adjustment procedure that does not require renegotiating primary EU treaties, and that Denmark's constitutional referendum practice can be satisfied with a binary 'Yes/No' vote on the specific opt-out waiver.

**Assessments:** Title: Legal and Treaty Steps Assessment
Description: Evaluation of the domestic and EU legal processes needed to move from opt-out to adoption.
Details: Risks include prolonged negotiations if EU member states demand broader conditionality, or if the referendum question is deemed too complex for voters, causing rejection. Benefits include a clear, legitimate pathway that reinforces EU rule of law and Danish sovereignty. Mitigation: Draft a concise, single-issue treaty amendment with pre-negotiated flexibility clauses; align referendum timing with EU political cycle to maximize legitimacy; secure advance ECB and Commission guidance to reduce uncertainty.

## Question 2 - What is the planned timeline and sequencing of milestones from the political decision to adopt the euro through full withdrawal of the Danish krone?

**Assumptions:** Assumption: A multi-year timeline of 4–8 years is realistic, with clear gates: political decision → referendum → treaty change → ERM II entry (2 years) → dual circulation → full euro adoption.

**Assessments:** Title: Timeline & Milestones Assessment
Description: Evaluation of the sequence and duration of phases to ensure orderly transition.
Details: Risks include underestimating dual-circulation complexity, causing extended parallel costs, or political momentum loss if milestones slip. Benefits include predictable planning for businesses and the public, and reduced market volatility. Mitigation: Implement a gated project plan with independent phase-gate reviews; publish a public milestone dashboard; build schedule buffers for technical integration and public education.

## Question 3 - What personnel, institutions, and governance structures are needed to manage the transition, and how will responsibilities be allocated?

**Assumptions:** Assumption: Existing Danish institutions (Folketinget, Danmarks Nationalbank, Financial Supervisory Authority) can be augmented with temporary cross-ministerial task forces without requiring new permanent bodies.

**Assessments:** Title: Resources & Personnel Assessment
Description: Evaluation of human capital, institutional roles, and coordination mechanisms.
Details: Risks include capacity gaps in central bank IT conversion and public communication, leading to delays or errors. Benefits include leveraging established expertise and clear accountability. Mitigation: Define a RACI matrix for all workstreams; recruit specialist euro-transition staff; establish a Municipal and Public Sector Dual Circulation Management Office; set up a Stakeholder Engagement Secretariat.

## Question 4 - How will Denmark's euro adoption be governed domestically and vis-à-vis EU institutions to ensure compliance and adaptability?

**Assumptions:** Assumption: Denmark will maintain its constitutional referendum requirement while accepting EU conditionality, and will use the Eurogroup and ECB as primary technical governance bodies during the transition.

**Assessments:** Title: Governance & Regulations Assessment
Description: Evaluation of the regulatory and institutional oversight framework.
Details: Risks include conflicts between national referendum practice and EU harmonization demands, or insufficient representation in ECB decision spaces. Benefits include stronger monetary policy alignment and credibility. Mitigation: Establish a formal Dialogue Channel with the ECB and Commission; secure pre-approval for Danish derogation terms; embed parliamentary oversight committees with access to expert advice.

## Question 5 - What specific measures will manage financial, operational, and systemic risks during the transition, including market stability and contingency planning?

**Assumptions:** Assumption: A comprehensive risk register with quantified likelihood and impact can be maintained, and that contingency reserves equivalent to at least 6 months of dual-circulation costs can be pre-allocated.

**Assessments:** Title: Safety & Risk Management Assessment
Description: Evaluation of the identification, mitigation, and monitoring of transition risks.
Details: Risks include unanticipated market shocks or operational failures causing service disruptions. Benefits include increased resilience and public confidence. Mitigation: Develop scenario-based contingency plans; conduct full-scale simulation drills; establish a crisis management cell; secure political backing for rapid decision-making during incidents.

## Question 6 - What is the approach to assessing, communicating, and managing environmental impacts and sustainability considerations of the euro transition?

**Assumptions:** Assumption: The environmental footprint of the transition will be limited and manageable, focusing on energy-efficient IT systems and reduced cash logistics, in line with EU green standards.

**Assessments:** Title: Environmental Impact Assessment
Description: Evaluation of ecological implications and sustainability measures.
Details: Risks include unintended increases in carbon footprint from cash transportation and data center loads. Benefits include alignment with EU Green Deal objectives and improved corporate image. Mitigation: Use green energy for central bank and bank data centers; optimize cash-in-transit routes; publish an environmental impact statement; set KPIs for emission reductions during dual circulation.

## Question 7 - How will the government ensure sustained public and stakeholder buy-in through communication, education, and inclusive participation?

**Assumptions:** Assumption: A sustained, multi-channel communication strategy backed by municipal and business networks can achieve over 70% public awareness and understanding of key transition details before referendum and conversion.

**Assessments:** Title: Stakeholder Involvement Assessment
Description: Evaluation of engagement strategies with citizens, businesses, and institutions.
Details: Risks include misinformation and public resistance, especially around rounding and price changes. Benefits include smoother adoption and reduced social friction. Mitigation: Launch town-hall and digital Q&A campaigns; co-create rounding guidelines with consumer groups; provide SME toolkits; monitor sentiment via social listening and adjust messaging iteratively.

## Question 8 - What are the technical and operational specifications for converting payment systems, IT infrastructure, pricing, and cash logistics to support dual circulation and final euro adoption?

**Assumptions:** Assumption: Danish banks and payment providers can align on common technical standards (e.g., ISO 20022) with ECB oversight, and that a single, government-coordinated cash logistics chain can handle nationwide dual-circulation needs.

**Assessments:** Title: Operational Systems Assessment
Description: Evaluation of the technical readiness and integration of payment and IT systems.
Details: Risks include system incompatibility causing transaction failures and prolonged dual-circulation costs. Benefits include a robust, future-proof payments ecosystem and enhanced interoperability with euro area systems. Mitigation: Mandate open standards; conduct end-to-end stress tests; establish a Central Conversion Unit for IT and cash logistics; implement dual pricing display requirements for a fixed period.

# Distill Assumptions

- Define Denmark's legal and treaty steps to lift the euro opt-out and hold a constitutional referendum.
- Implement a multi-year timeline: political decision, referendum, treaty change, ERM II, dual circulation, full adoption.
- Augment existing Danish institutions with cross-ministerial task forces to manage transition governance.
- Ensure EU and ECB governance alignment while preserving Denmark's constitutional referendum requirement.
- Maintain a comprehensive risk register with contingency reserves for systemic and operational risks.
- Limit transition environmental impact through energy-efficient systems and reduced cash logistics.
- Execute a sustained multi-channel communication strategy to achieve public awareness and buy-in.
- Align payment systems and IT infrastructure on common technical standards with ECB oversight.

# Review Assumptions

## Domain of the expert reviewer
National monetary transition and EU integration policy

## Domain-specific considerations

- ERM II entry sequencing and ECB oversight
- Treaty change and constitutional referendum design
- Dual-currency IT and payment system conversion
- Cash logistics and seigniorage capture
- Stakeholder alignment and social pacts
- Environmental and sustainability impacts
- Risk register and contingency budgeting

## Issue 1 - Missing assumption: Independent fiscal and monetary capacity during the pre-ERM II convergence period
No explicit assumption on Denmark’s ability to maintain autonomous fiscal support and Danmarks Nationalbank’s operational capacity while converging under external ECB oversight. This is critical because convergence criteria require low deficits and stable inflation, yet pre-ERM II monetary accommodation may be constrained by external parity commitments. Impact: If fiscal space is insufficient, convergence delays could increase project cost by 5–10% (approx. 2–4 billion DKK) and delay the referendum by 6–12 months.

**Recommendation:** Quantify fiscal space using a baseline structural deficit threshold (<0.5% of GDP) and simulate ECB policy scenarios. Establish a pre-commitment facility (e.g., a temporary credit line with the ECB or ESM) to preserve autonomy. Define a fiscal rule that allows temporary, rules-based deviations during the convergence ramp-up, with independent verification by the FSA.

**Sensitivity:** 

## Issue 2 - Missing assumption: Legal enforceability of referendum outcomes and fallback mechanisms
The plan assumes a binary referendum can lock the process, but does not address scenarios where turnout or margin is ambiguous, or where post-referendum political shifts occur. This is critical because legal uncertainty can stall treaty change and delay ERM II entry by 12–24 months. Impact: Potential cost of 10–15% of budget (approx. 5–8 billion DKK) due to extended legal processes, repeated campaigns, and market uncertainty.

**Recommendation:** Embed a clear legal test (e.g., >50% turnout and >40% of electorate in favor) and a defined fallback (e.g., a ‘soft referendum’ mandate for the Folketing to proceed with treaty change under specified conditions). Draft contingency protocols for annulment or narrow wins, including a 12-month cooling-off and re-engagement phase with adjusted communication.

**Sensitivity:** 

## Issue 3 - Missing assumption: Currency risk management during dual circulation and ECB balance sheet exposure
Assumptions on cash logistics and seigniorage do not fully account for exchange-rate volatility between DKK and EUR during the dual-circulation window. This is critical because DKK depreciation could trigger import inflation and erode public confidence, while ECB valuation of Danmarks Nationalbank reserves may fluctuate. Impact: A 5% DKK depreciation could increase conversion costs by 2–3% (approx. 1–2 billion DKK) and delay full adoption by 3–6 months due to repricing pressures.

**Recommendation:** Implement a dynamic hedging program using EUR/DAK forwards aligned with the parity band, and establish a Sovereign Conversion Fund capitalized at 0.5–1% of GDP to absorb FX volatility. Publish daily parity bands and conduct weekly stress tests with the ECB.

**Sensitivity:** 

## Issue 4 - Missing assumption: Interoperability and legacy system sunsetting for payment infrastructures
Assumptions on IT alignment (e.g., ISO 20022) do not address coexistence costs and technical debt in legacy Danish banking systems. This is critical because fragmented standards can cause transaction failures and increase dual-circulation costs. Impact: Inadequate integration could raise operational risk costs by 15–20% (approx. 300–500 million DKK annually) and delay full adoption by 6–9 months.

**Recommendation:** Mandate a phased legacy sunsetting schedule with incentives for early adoption (e.g., regulatory capital relief for compliant institutions). Create an Interoperability Certification Body under the FSA to audit and accredit systems, with penalties for non-compliance.

**Sensitivity:** 

## Issue 5 - Missing assumption: Public inflation expectations and wage-price spiral risks during dual circulation
The plan does not explicitly model how price rounding and dual pricing may feed into inflation expectations. This is critical because anchored expectations are vital for ECB compliance and referendum stability. Impact: Unanchored expectations could increase wage demands by 1–2 percentage points, raising CPI inflation by 0.5–1% and forcing premature ECB-style tightening, which could reduce ROI by 3–5% over the transition.

**Recommendation:** Introduce a Wage-Price Protocol with indexed rounding caps and a public dashboard for transparency. Pair with a macroprudential buffer (e.g., countercyclical capital buffers) to dampen demand-side pressures, and simulate scenarios using the ECB’s Convergence Report templates.

**Sensitivity:** 

## Review conclusion
The transition plan lacks explicit assumptions on fiscal-monetary autonomy during convergence, referendum legal enforceability, currency risk management, legacy system interoperability, and inflation expectation anchoring. These gaps could increase costs by 5–15% and delay completion by 12–24 months. Prioritize: (1) fiscal space analysis with ECB-aligned rules; (2) referendum legal design with fallback clauses; (3) dynamic FX hedging and a Sovereign Conversion Fund. Embed these into a quantified risk register with contingency budgets and independent audits.