# Purpose

**Purpose:** business

**Purpose Detailed:** This is a comprehensive strategic and logistical plan for a national government to execute a major change in monetary policy and infrastructure, involving treaty negotiation, public referendum, economic restructuring, and national operational change management. This falls under large-scale governmental initiative and economic management.

**Topic:** National currency transition from DKK to EUR for Denmark

# Domain

**Primary domain:** Public Finance

**Secondary domains:** European Union Law, Macroeconomic Management, Monetary Policy

**Rationale:** Public Finance owns the core success criterion: successfully effecting the national financial transition to the euro. Monetary Policy is a close second, but Public Finance captures the holistic national adoption/replacement mandate better than general policy. Economic Policy Communication is relegated as it is subordinate to the actual financial execution.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Public Finance | 5 | 5 | outcome | The core outcome is the national change of legal tender to a new currency. |
| Monetary Policy | 5 | 5 | outcome | The primary outcome is the change of national currency, which is monetary policy execution. |
| European Union Law | 5 | 4 | constraint | Adoption requires navigating EU treaty changes and compliance with ECB mandates. |
| Macroeconomic Management | 4 | 4 | method | The transition requires managing ERM II, convergence criteria, and exchange rate risk. |
| Change Management | 4 | 4 | method | Large-scale operational and public preparedness requires dedicated change management strategies. |
| Economic Policy Communication | 4 | 4 | outcome | Successful public preparedness and managing perception are critical to achieving adoption legally. |
| Project Implementation | 4 | 3 | method | The project demands a structured, multi-phase implementation roadmap from decision to launch. |

**Warnings:**
- Dropped duplicate fit domain: European Union Law
- Dropped duplicate fit domain: European Union Law
- First-pass produced 7 candidate(s) after 3 batch call(s); target was 9.

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** The plan outlines a comprehensive strategy for Denmark to transition its national currency from the Danish Krone (DKK) to the Euro (EUR). This process inherently requires extensive physical activities, even though it has deep legal and digital components. Physical requirements include: (1) Organizing and executing a nationwide *referendum* (physical polling stations, voter logistics). (2) Negotiating and signing *treaty changes* in physical locations (EU institutions, ministerial meetings). (3) Central bank and commercial bank coordination, involving the physical handling, exchange, transport, and security of vast amounts of existing DKK cash and new EUR coins/notes (cash and coin logistics). (4) Physical implementation of IT systems across all businesses and public bodies, often requiring on-site installation, testing, and verification. Therefore, this project is classified as physical due to the mandatory physical logistics of a national currency change, referendum, and hardware/system implementation.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Location suitable for high-level government meeting and ongoing coordination (Inter-Agency Governance)
- Logistical hubs for secure management, sorting, and destruction of DKK cash and distribution of EUR (Cash Logistics)
- Locations for nationwide referendum execution (Polling stations)
- EU institutional locations for treaty negotiation and sign-off

## Location 1
Denmark

Copenhagen (Governmental and Central Bank Hub)

Christiansborg Palace / Danmarks Nationalbank HQ

**Rationale**: This is the necessary physical nexus for the 'Joint Ministerial Consultative Body' (Decision 5) and houses the Danish Central Bank, essential for all operational and legal decision-making related to currency transition and ERM II strategy.

## Location 2
Belgium

Brussels (EU Negotiations)

European Quarter (Commission/Council/ECB liaison offices)

**Rationale**: Necessary for the critical phases of 'Opt-Out Resolution Mechanism Selection' and 'Legal Pathway to Opt-Out Removal,' requiring direct physical engagement with EU institutions in Brussels.

## Location 3
Denmark

Nationwide infrastructure for Referendum and Cash Logistics

Municipal polling places and designated secured National Bank regional cash handling depots

**Rationale**: Covers the physical execution requirements of the 'Public Referendum Design' and 'Cash Stock Synchronization Strategy,' demanding widespread physical presence across all administrative regions.

## Location Summary
The transition plan requires three primary types of physical locations: Copenhagen for core Danish governmental and central bank coordination (Christiansborg/Nationalbank); Brussels for all necessary EU treaty negotiations and European Council meetings; and the entire national territory for executing the public referendum and the logistics of cash handling and distribution.

# Currency Strategy

This plan involves money.

## Currencies

- **DKK:** The current national currency being replaced; needed for local transactions prior to Euro Day.
- **EUR:** The target currency for all future transactions, budgeting, and reporting.
- **USD:** A stable international benchmark currency often used for comparative economic analysis or during the period of high domestic uncertainty leading up to the vote.

**Primary currency:** EUR

**Currency strategy:** The primary strategy is to transition the budget and reporting currency to EUR immediately upon the political decision to proceed, following established EU convergence criteria via ERM II. While the DKK will be used for existing transactions until Euro Day, all long-term planning and external financial reporting will be denominated in EUR to manage exchange rate risk during the multi-year transition implied by the chosen 'Builder's Blueprint'.

# Identify Risks


## Risk 1 - Regulatory & Permitting
Failure to secure the necessary unanimous agreement from the European Council/Parliament to amend the TEU protocol and lift the Danish opt-out, as required by the chosen 'Formally request an Extraordinary European Council session' strategy.

**Impact:** A minimum delay of 12–24 months in the entire timeline due to being forced onto a less certain legal pathway or requiring domestic ratification processes for a new treaty amendment. Potential political capital burnout.

**Likelihood:** Medium

**Severity:** High

**Action:** Mitigation via Strategy 4 (Opt-Out Resolution Mechanism Selection): Focus diplomatic efforts immediately on securing bilateral assurances from key member states (e.g., Germany, France) to minimize political resistance during the Council session. Prepare parallel contingency legal arguments based on existing EU treaties in case the protocol amendment fails.

## Risk 2 - Regulatory & Permitting
The Danish Folketinget or the public rejects the required constitutional change/referendum needed to lift the existing opt-out.

**Impact:** Project termination or forced return to a permanent opt-out status. Financial loss of DKK 500M–1B in sunk costs relating to preparatory EU engagement, IT simulations, and initial communication materials.

**Likelihood:** Medium

**Severity:** High

**Action:** Mitigation via Strategy 11 (Societal Readiness Pacing): Implement continuous, high-quality communication campaigns starting immediately after the 'political decision' to proceed, emphasizing the benefits of adoption, even before the finalized ERM II parity is known. Ensure the 'Public Referendum Design' is structurally simple and widely accepted.

## Risk 3 - Financial/Economic
Failure to meet the primary convergence criteria (e.g., deficit within 3% of GDP) within the required ERM II participation window, leading to a delayed entry approval from the ECB.

**Impact:** Delay of 6–18 months, forcing the government to implement painful, last-minute fiscal adjustments (e.g., unexpected cuts or tax hikes) which can trigger public backlash and increase economic contraction.

**Likelihood:** Medium

**Severity:** High

**Action:** Mitigation via Strategy 9 (Convergence Harmonization Triage): Adopt the most aggressive technical alignment strategy, implementing ECB statistical reporting immediately post-referendum to secure early internal compliance audit capabilities. Strategy 2 for ERM Entry should be chosen to provide a buffer against market misalignment shocks.

## Risk 4 - Technical/Operational
Integration failure or significant delay in Danmarks Nationalbank's core operational systems (e.g., payment systems, reserve management) connecting with Eurosystem infrastructure (e.g., TARGET2).

**Impact:** Inability to participate fully in Eurosystem operations on Euro Day, risking operational isolation or non-compliance with ECB governance requirements. Requires an extra 4–6 months of dedicated technical remediation effort.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Mitigation via Strategy 8 (Central Bank Integration): Establish the 'Shadow Integration Team' immediately, operating irrespective of the 'Opt-Out Resolution' timeline, ensuring that technical readiness precedes political certainty, minimizing risk if the referendum passes quickly.

## Risk 5 - Supply Chain/Logistics
Inadequate supply, security failure, or logistical bottlenecks in the distribution/destruction of EUR/DKK cash during the short dual circulation window (assumed 30-60 days due to strain on resources).

**Impact:** Localized cash shortages leading to public panic, increased counterfeiting risk, or extended dual circulation periods due to slow DKK removal, costing an extra DKK 100M in security/storage overhead.

**Likelihood:** High

**Severity:** Medium

**Action:** Mitigation via Strategy 10 & 6: Contract multiple specialized cash-in-transit firms for dispersion (Strategy 13.1) and commit to an aggressive 30-day dual circulation period (Strategy 6.1) predicated on a massive, front-loaded media campaign to drive immediate consumer acceptance of carrying two currencies.

## Risk 6 - Social/Change Management
Significant public confusion or rejection due to inconsistent pricing, especially among SMEs or vulnerable populations, leading to widespread errors in dual circulation and public trust erosion.

**Impact:** High incidence of consumer disputes or accidental overpayment, potentially forcing the government to enforce complex consumer protection measures retroactively, delaying the final DKK withdrawal timeline by 1–3 months.

**Likelihood:** High

**Severity:** Medium

**Action:** Mitigation via Strategy 11: Implement rolling, sector-specific educational outreach through municipal centers, focusing efforts *after* the referendum result, but ensuring key operational rules (rounding, conversion) are communicated early via utility providers and tax authorities.

## Risk 7 - Operational/Contractual
Widespread legal disputes regarding the mandatory re-denomination of private, long-term contracts (e.g., housing loans, existing B2B agreements) under the chosen legislative framework.

**Impact:** Significant litigation burden on the judicial system post-Euro Day, potentially requiring emergency legislation or the creation of complex arbitration bodies, delaying full economic normalization by up to 2 years in some sectors.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Mitigation via Strategy 7: Mandate automatic rounding for all existing long-term contracts without negotiation (Strategy 7.1), coupled with robust legal clarity published by the Ministry of Justice well in advance, reinforcing the certainty required by the 'Builder's Blueprint'.

## Risk 8 - Financial/Market Risk
Speculative pressure or market instability arising from the announcement of the DKK's entry parity within ERM II, contradicting the desired 'minimal pre-entry shock' based on Strategy 2 for ERM Entry.

**Impact:** The National Bank being forced to expend significant reserves defending the peg or being forced to adopt a less favorable official entry rate than preferred, leading to negative long-term impact on Danish export competitiveness.

**Likelihood:** Low

**Severity:** High

**Action:** Mitigation via Strategy 12 (Structuring ERM Inclusion): Focus negotiation with the ECB on maintaining the current implied tight binding band during the informal convergence period (Strategy 2 for ERM Entry), using historical alignment as leverage to minimize market surprises during the formal entry.

## Risk 9 - Governance/Resource Management
Decision-making paralysis or resource contention within the 'Joint Ministerial Consultative Body' (Strategy 5.2), where required consensus among multiple ministers slows down urgent operational directives.

**Impact:** Cascading delays across technical and operational workstreams (e.g., IT system harmonization, contract law finalization) due to bottlenecks in required political sign-off, potentially extending the timeline beyond 8 years.

**Likelihood:** High

**Severity:** Medium

**Action:** Mitigation via Strategy 5: While adopting the consultative body, delegate clear thresholds to the chairs of the consultation (PM's office representative) to issue binding directives on logistical and technical matters (e.g., DKK 50M budget allocations) unless an explicit policy conflict is raised by a minister within 7 days.

## Risk summary
The transition plan, adhering to the 'Builder's Blueprint,' faces critical risks concentrated at the intersection of political authorization and economic convergence. The **most critical risks (High Severity/High Impact)** involve **Legal/Regulatory Approval of Opt-Out Removal** (delaying accession) and **Failure to meet ECB Convergence Criteria** (blocking entry). These hinge on external agreements and domestic fiscal discipline, respectively. The third critical area is **Governance Bottlenecks** within the chosen consultative structure, which could translate political certainty into operational delays. Successful mitigation requires aggressive, early diplomatic action regarding the treaty change in parallel with immediate, high-quality technical preparation (Shadow Integration Teams) to bridge the gap between the political decision and the necessary operational reality, accepting the high upfront costs associated with rigorous convergence alignment.

# Make Assumptions


## Question 1 - Given the chosen 'Builder's Blueprint' strategy, which prioritizes postponing opt-out repeal until after successful ERM II completion, what is the required minimum allocation figure for the initial multi-year, government-funded public information campaign (Strategy 11), expressed as a percentage of the total estimated national transition budget?

**Assumptions:** Assumption: Based on comparable EU adoptions (e.g., Slovakia, Lithuania), a high-certainty public information strategy requires sustained funding equating to 0.5% of the total estimated national transition budget (which is assumed to be in the range of DKK 15–25 billion over 6 years) to effectively manage the high political risk associated with reversing the opt-out.

**Assessments:** Title: Funding & Budget Allocation Assessment
Description: Evaluation of the necessary committed funding floor for the public information campaign based on chosen risk profile.
Details: Committing 0.5% of an estimated DKK 20 billion transition budget implies an allocation of DKK 100 million dedicated solely to the Societal Readiness Pacing ($DR 11$. This allocation is critical mitigation for Risk 2 (Referendum failure). If the Builder's Blueprint is followed, this expenditure must be released immediately post-political decision to maintain momentum, regardless of ERM II status. Opportunity exists to phase this expenditure over 3-4 initial years, prioritizing educational material creation over mass media saturation until the referendum date is set.

## Question 2 - Assuming the political decision is made today (2026-May-02) and adhering to the 'Builder's Blueprint' which mandates a minimum 24-month ERM II participation period, what is the earliest realistic target date for the national referendum (Decision 3) regarding opt-out repeal?

**Assumptions:** Assumption: The 'Builder's Blueprint' dictates that formal ERM II entry (post-negotiation/treaty agreement) occurs in Q3 2027. Given the minimum 24-month participation period, convergence confirmation readiness would be Q3 2029, allowing for a 6-month lag for Folketinget affirmation and referendum scheduling, leading to a Q1 2030 referendum.

**Assessments:** Title: Timeline & Milestones Assessment
Description: Establishing the critical milestone for democratic consent based on mandatory convergence periods.
Details: The earliest target for the referendum is Q1 2030, placing the project near the higher end of the 4-8 year band. This long lead time directly mitigates Risk 3 (Convergence Failure) by securing the political mandate only when technical economic criteria are functionally met. The main risk is stakeholder impatience (Strategy 5.2 Governance Bottleneck) during the prolonged ERM II period, requiring carefully timed communication updates to sustain political support over the 3-year preparatory phase.

## Question 3 - Given the elected governance structure of a 'Joint Ministerial Consultative Body' (Decision 5), how will the necessary specialized technical workforce (including ECB integration experts, as per Strategy 8.3) be sourced, trained, and retained across potential multi-year ERM II fluctuations without relying on an immediate, high-cost permanent staffing expansion?

**Assumptions:** Assumption: Due to the high political risk associated with early formal opt-out repeal (Strategy 2), long-term hiring is deferred. Staffing will rely on securing 60% of required technical staff through short-term, high-value secondments from Danmarks Nationalbank and specialized EU/ECB consultative contracts, with the remainder filled by leveraging the 'Shadow Integration Team' concept (Strategy 8.1).

**Assessments:** Title: Resources & Personnel Assessment
Description: Strategy for securing specialized personnel while managing post-referendum employment uncertainty.
Details: A hybrid approach utilizing secondments and external consultants minimizes the sunk cost if the referendum fails, aligning with the pragmatic nature of the 'Builder's Blueprint.' Risk 9 (Governance Paralysis) is managed by delegating initial contracts to the Nationalbank Chair. Opportunity: Early secondment exposure to ECB systems accelerates internal skill transfer, making the bank more robust during the target 24-month ERM II period, improving convergence metrics.

## Question 4 - Which specific regulatory approval mechanisms (domestic constitutional review vs. EU procedure) carry the higher risk of forcing the timeline past 8 years, and what mechanism is prioritized in the 'Opt-Out Resolution Mechanism Selection' to prevent this outcome?

**Assumptions:** Assumption: Formally requesting an Extraordinary European Council session (Strategy 4.2) carries a lower long-term procedural risk than relying on a novel political declaration (Strategy 4.1), due to the need for high-level legal certainty required by the ECB. However, treaty amendment carries a higher risk of 27-state ratification delays if domestic constitutional review is also triggered simultaneously.

**Assessments:** Title: Governance & Regulations Assessment
Description: Evaluation of legal pathways' impact on timeline certainty versus political maneuvering.
Details: The primary governance risk is the 27-state ratification of a targeted protocol amendment (Risk 1). The chosen strategy (4.2) accepts this political risk to gain ECB certainty. Mitigation requires relentless diplomatic pressure, focusing initial EU engagement on securing unanimous agreement on the *process* before negotiating the *substance*. Domestic constitutional review must be managed concurrently by the Ministry of Justice to ensure legislative readiness for post-referendum ratification.

## Question 5 - Considering the high likelihood of logistical pressure during the assumed 30-day dual circulation period, what specific contingency capital must be ring-fenced to cover immediate, unbudgeted security enhancements for cash transport and storage if Risk 5 (Cash Supply Failure) materializes?

**Assumptions:** Assumption: Based on Risk 5 analysis, an unbudgeted DKK 50 million contingency fund is necessary to rapidly contract Tier-2 security providers or expand insured temporary storage facilities should the primary logistics chain show strain in the first two weeks of dual circulation.

**Assessments:** Title: Safety & Risk Management Assessment
Description: Quantification of immediate financial resources needed for physical security backup protocols.
Details: Ring-fencing DKK 50 million provides a crucial buffer against the high likelihood of logistical/security incidents during the compressed 30-day dual phase. This fund should be distinct from the IT budget ($DR 8$) and linked directly to the Cash Logistics lever ($DR 6$). Opportunity: Pre-qualifying three regional security contracts now (even if currently unfunded) allows immediate activation within 72 hours if initial monitoring reveals bottlenecks, drastically reducing response time.

## Question 6 - Since the plan commits to joining the existing Euro Area, how will the Danish government proactively address potential future political scrutiny from other EU states regarding environmental reporting and sustainability standards misalignment that might emerge as Denmark integrates its fiscal mechanisms with the ECB framework?

**Assumptions:** Assumption: Denmark commits to adopting the ECB's current guidelines on climate-related financial risk reporting and stress testing protocols immediately upon ERM II entry, even if these are not strictly mandatory for DKK-only participation, ensuring a 'best practice' profile ahead of the Euro Day.

**Assessments:** Title: Environmental Impact Assessment
Description: Proactive alignment with non-monetary EU standards to build political leverage for convergence approval.
Details: While the core focus is monetary, proactive adoption of ECB climate-related disclosure standards for financial institutions (as part of Convergence Triage $DR 9$) minimizes future friction with the European Commission and Parliament regarding general alignment. This strategy builds goodwill, which is indirectly beneficial for securing successful treaty/opt-out repeal negotiation (Risk 1 mitigation), though it adds minor operational cost to the commercial banks.

## Question 7 - To ensure the 'Joint Ministerial Consultative Body' remains effective (Decision 5) across the long timeline, what specific mechanism will be instituted to manage communication and expectation setting with key external stakeholders (Business, Unions) to prevent fragmentation of support between the political decision and the referendum date?

**Assumptions:** Assumption: A quarterly 'Economic Alignment Stakeholder Forum' ($EASF$) will be established, chaired by the Ministry of Business, feeding directly into the Consultative Body. This forum will provide mandatory updates on convergence progress (via $DR 9$) and receive early warnings on upcoming ERM II alignment changes (via $DR 12$), targeting a consistent 80% stakeholder satisfaction rating in annual pulse checks.

**Assessments:** Title: Stakeholder Involvement Assessment
Description: Structuring engagement channels to maintain broad support across the multi-year convergence phase.
Details: The $EASF$ addresses the high inherent risk of stakeholder fatigue during the long ERM II period. By providing structured technical updates ($DR 9$) rather than purely political announcements, it grounds support in verifiable progress, mitigating a key driver for reduced support during long preparation times. Failure to maintain this forum risks eroding the business community's willingness to invest in necessary IT upgrades ahead of conversion deadlines.

## Question 8 - Considering the commitment to 'Maintain the current strict DKK exchange rate policy' (Decision 2) during pre-ERM II convergence, what is the mandated protocol for Danmarks Nationalbank to simulate and validate the integrity of DKK-based IT payment systems (e.g., domestic clearing houses) against the projected EUR conversion logic before formal integration with TARGET2 (€-systems)?

**Assumptions:** Assumption: The National Bank will mandate internal 'Euro Simulation Exercises' ($ESE$) using anonymized historical DKK transaction data against the projected 1:7.46 DKK/EUR conversion rate, running these tests across all critical payment systems (not just those directly connecting to TARGET2) for a minimum of six continuous months prior to formal ERM II entry.

**Assessments:** Title: Operational Systems Assessment
Description: Establishing non-binding, robust internal testing procedures for domestic operational readiness.
Details: The $ESE$ directly mitigates Risk 4 (Technical Integration Failure) by testing domestic systems before external linkage. Since Strategy 2 for ERM Entry is chosen (minimal pre-entry shock), the operational systems must be ready to transition quickly once the DKK peg is formalized. The key is ensuring that the results of these $ESE$ are shared with the 'Joint Ministerial Consultative Body' ($DR 5$) to ensure technical preparedness drives governance decisions, not the reverse.

# Distill Assumptions

- Public information funding requires 0.5% of the total estimated national transition budget.
- The earliest realistic national referendum target date is Q1 2030, post 24-month ERM II.
- Technical staffing relies on 60% secondments from Nationalbank and specialized EU/ECB contracts.
- Formally requesting an Extraordinary European Council session is the prioritized legal mechanism.
- A DKK 50 million contingency fund is ring-fenced for immediate security enhancements if risks materialize.
- Denmark commits to adopting ECB climate risk reporting standards proactively upon ERM II entry.
- A quarterly Economic Alignment Stakeholder Forum will manage external communication and support across timelines.
- National Bank mandates six months of internal Euro Simulation Exercises based on projected conversion rates.
- The project expects a multi-year process spanning 4 to 8 years from decision to full euro use.
- Adoption requires lifting the current EU opt-out via treaty change and a subsequent national referendum.
- The plan must be compatible with EU/ECB convergence criteria, including ERM II participation.
- The chosen strategy defers opt-out repeal until after minimum 24 months of successful ERM II participation.
- The existing strict DKK exchange rate policy is maintained during the pre-ERM II convergence period.
- The referendum structure will be binary, conditional on affirming prior fulfillment of ECB convergence checklist.
- The selected governance structure is a Joint Ministerial Consultative Body requiring ministerial consensus.
- A 30-day dual circulation period is assumed for cash logistics, requiring contingency planning.
- Commercial contracts mandate automatic rounding to the nearest cent upon Euro Day with no prior renegotiation.
- Danmarks Nationalbank integration phases timeline is heavily constrained by ERM II entry requirements.
- Convergence triage prioritizes mandatory criteria, deferring non-binding ECB best practices initially.
- Local government operational switch requires centralized mandates for IT upgrades with financial incentives.
- The project excludes any assumption of a 'Nordic euro' or separate currency union structure.

# Review Assumptions

## Domain of the expert reviewer
Strategic Project Planning & Governmental Transition Management

## Domain-specific considerations

- Sequencing of political consent vs. economic convergence criteria
- Management of EU/ECB institutional dependencies and external dependencies
- Public behavior change management and democratic mandate security
- Sunk cost management due to long pre-adoption phase (ERM II)

## Issue 1 - Underestimated Timeline Risk Associated with Deferring Opt-Out Repeal
The chosen 'Builder's Blueprint' strategy assumes the earliest referendum date is Q1 2030, based on a minimum 24-month ERM II period starting in Q3 2027. This implies a political decision today (May 2026) leads to an 8-year timeline (2026-2034) for full adoption, which strains the implied 4-8 year window. Furthermore, deferring the Opt-Out repeal negotiation (Decision 1) until after ERM II completion (Decision 4) creates a *missed assumption*: the assumption that the EU will entertain a treaty amendment process *after* Denmark has already met technical convergence criteria, rather than demanding the political alignment happens concurrently or beforehand. This sequence increases political risk with the EU Council/Parliament.

**Recommendation:** Immediately initiate parallel, high-level diplomatic tracks. While ERM entry proceeds (Strategy 12), a 'conditional negotiation' track for the Opt-Out Repeal Protocol must begin, explicitly tied to meeting the 12-month ERM II stability mark, not the end. This requires amending the governance structure to empower the Consultative Body (Decision 5) to manage the diplomatic risk transfer, rather than relying solely on late-stage treaty requests ($Risk 1$).

**Sensitivity:** If the EU demands the Opt-Out resolution precede formal ERM II entry confirmation, the project timeline baseline of Q1 2030 would be delayed by 12–18 months (pushing adoption to Q1 2031/2032) due to extended EU ratification timelines. This delay impacts ROI by reducing the period of full utilization by 1.5 years, lowering projected ROI by 8-12% based on a standard 15-year cash flow model.

## Issue 2 - Critical Missing Assumption: Funding Stability During Prolonged ERM II Period
The project assumes funding levels (DKK 15–25 billion over 6 years) are stable, and technical staffing relies on secondments (Assumption 3). Crucially, there is *no assumption* explicitly stating the funding mechanism is indexed or protected against sustained high inflation or elevated interest rates over the 6-8 year projected timeline. The 'Builder's Blueprint' is economically conservative (maintaining strict DKK policy), but high inflation during the 24-month ERM II period could rapidly erode the real value of the committed budget (DKK 100M for communication, DKK 50M contingency) and make retaining seconded staff unaffordable.

**Recommendation:** Introduce mandatory annual budget real-indexation reviews tied to a neutral CPI index (e.g., Euro Area CPI). Specifically, the contingency fund (Assumption 5) should be structured as an external ring-fenced escrow account protected from annual departmental reallocation, with a minimum capital hold of DKK 50M + 5% annual inflation adjustment.

**Sensitivity:** If average annual inflation over the 6-year timeline exceeds the current baseline expectation by 2 percentage points (e.g., 3.5% vs. 1.5% baseline), the real value of the DKK 20B budget is reduced by roughly DKK 2.2 Billion. This forces delays in cash logistics scaling or requires an immediate capital call, potentially increasing the cost of capital by 0.5-1.0% per year on any bridging loans taken during the ERM II phase.

## Issue 3 - Under-Explored Assumption: Legal Finality of Contract Re-denomination Post-Referendum Failure
Assumption 7 mandates automatic rounding for all contracts post-Euro Day. However, the 'Builder's Blueprint' strategy defers the vote/legal opt-out repeal until the end of ERM II participation (Q1 2030). There is a critical *omission* regarding the legal status of these pre-mandate contract rounding rules if the referendum *fails*. If the referendum fails, is the government legally obliged to retract the mandatory rounding legislation enacted contingent on success? This uncertainty creates massive risk for SMEs and IT readiness (Risk 7).

**Recommendation:** Immediately task the Justice Ministry (via the Joint Ministerial Body, Decision 5) to draft a **Dual-Path Legal Contingency Mandate**. This mandate must clearly stipulate that all preparatory legislation for re-denomination (Decision 7) is automatically repealed *without penalty or sunk cost imputation* if the referendum fails. The cost of preparing this dual documentation should be factored into the DKK 50M contingency fund ($Risk 5$).

**Sensitivity:** If legal challenge invalidates the provisional contract legislation post-referendum failure, the cost of retrospective litigation and compensation payments to entities that upgraded systems based on the assumption of mandated conversion could range from DKK 500 Million to DKK 1.5 Billion in unforeseen liabilities, potentially impacting future ROI by 3-6% from write-offs.

## Review conclusion
The project's chosen 'Builder's Blueprint' strategy introduces significant timeline dependency risks by sequencing political opt-out repeal strictly after substantial operational convergence. The three most critical intervening issues are the **unrealistic sequencing risk concerning EU approval timelines**, the **failure to explicitly hedge against budget erosion during the long ERM II period (e.g., inflation)**, and the **unspecified legal consequence for preparatory contract legislation should the national referendum fail**. Addressing these requires immediate parallel diplomatic engagement, establishing inflation-indexed budget mechanisms, and drafting definitive dual-path legal contingency mandates.