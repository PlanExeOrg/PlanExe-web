### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] The premise of a managed, opt-out-compliant path to euro adoption is strategically infeasible because it misrepresents the irreversible legal rupture required to exit a national monetary sovereignty.**

**Bottom Line:** REJECT: The premise of a controlled, opt-out-compliant euro adoption plan is fundamentally unsustainable.


#### Reasons for Rejection

- The plan assumes a 4–8 year timeline with a structured dual circulation period, but Denmark’s permanent euro opt-out means any legal path must first secure a treaty change and a referendum, a political process with no guaranteed timeline and high risk of rejection.
- It allocates resources for public information campaigns and IT conversion for 5.8 million citizens and 1,200+ municipalities, yet offers no mechanism to override Danish constitutional requirements that a referendum precedes any transfer of monetary sovereignty.
- The plan acknowledges ERM II and convergence criteria while simultaneously budgeting for parallel krone–euro systems, ignoring that EU rules do not permit a managed dual-currency transition that preserves monetary autonomy during the transition.

#### Second-Order Effects

- 0–6 months: Political paralysis as ministries compete over referendum design, delaying any substantive legal work and exposing the plan to procedural challenges.
- 1–3 years: Market fragmentation and capital flight as businesses and investors price in uncertainty, undermining the very financial stability the plan seeks to secure.
- 5–10 years: Long-term governance lock-in where euro adoption cedes monetary policy to the ECB, permanently limiting Denmark’s ability to respond to domestic economic shocks.

#### Evidence

- Case/Incident — Greenland Treaty Exit (1985): Demonstrates the legal and political complexity of reversing a sovereign monetary decision.
- Law/Standard — Maastricht Treaty (1992), Article 140 TFEU: Requires unanimous EU agreement and member-state ratification for any euro-area enlargement.
- Case/Incident — Greek Referendum (2015): Shows how electorate rejection can abruptly terminate a planned monetary transition.



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[MORAL] — Opt-Out Erasure: Designing a pathway to surrender Denmark’s permanent euro opt-out normalizes a constitutional surrender that trades sovereign autonomy for illusory integration.**

**Bottom Line:** REJECT: The premise is a sovereign surrender disguised as technical planning; abandoning Denmark’s opt-out via euro adoption would cripple democratic accountability and expose the nation to irreversible monetary dependency.


#### Reasons for Rejection

- It overrides democratic consent by subordinating the Folketing’s constitutional referendum mandate to EU treaty change, hollowing out citizens’ voice over currency sovereignty.
- It relies on jurisdiction shopping within EU structures to bypass domestic legal safeguards, exposing Denmark to ECB rules that displace national monetary policy without accountability.
- It creates irreversible harm by locking cash, contracts, and payment systems into a foreign monetary regime, eliminating the krone as a buffer against asymmetric shocks.
- It embodies value-proposition rot by presenting euro adoption as technocratic progress while concealing rent-seeking by financial incumbents and misallocation of public funds toward transition costs.

#### Second-Order Effects

- **T+0–6 months — The Cracks Appear:** Legal challenges stall referendum design, exposing contradictions between EU treaty obligations and Danish constitutional practice.
- **T+1–3 years — Copycats Arrive:** Other EU opt-outs face pressure to follow, fracting the EU’s cohesion and incentivizing opportunistic treaty renegotiations.
- **T+5–10 years — Norms Degrade:** Public trust in the krone erodes, leading to parallel pricing, dual-currency informal practices, and reduced monetary policy independence.
- **T+10+ years — The Reckoning:** Denmark remains exposed to ECB fiscal constraints without corresponding political representation, deepening democratic deficits and fiscal rigidity.

#### Evidence

- EU Treaty Article 140 TFEU — Protocol on Denmark’s permanent opt-out, affirming national sovereignty over currency decisions.
- Case: Ireland, Twenty-Fifth Amendment Referendum (2001) — Demonstrates how constitutional referendums on EU/monetary issues can fail and reshape political trajectories.
- Narrative — Front-Page Test: Danish newspapers publish leaked transition memos showing commercial banks lobbying to privatize seigniorage gains during conversion.
- ECB Convergence Report (2024) — Highlights persistent divergence in fiscal flexibility among euro-area members, underscoring asymmetric shock vulnerability.



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] Pursuing euro adoption while clinging to the Edinburgh Agreement’s opt-out is a delusional gamble that guarantees institutional paralysis and sovereign erosion.**

**Bottom Line:** REJECT: The plan is a fantasy of sovereignty-neutralizing surrender that collapses under the weight of its own legal and political impossibility.


#### Reasons for Rejection

- The plan hinges on overturning Denmark’s permanent EU opt-out via treaty change and referendum, yet no mechanism exists to guarantee such political consensus.
- €200M for 1,000 government and banking stakeholders assumes flawless coordination across Folketinget, Danmarks Nationalbank, and EU institutions, ignoring bureaucratic inertia.
- 50×50×20 m of IT and logistical overhaul presumes seamless dual-currency systems can coexist without catastrophic pricing fragmentation or public confusion.
- The requirement to respect Danish constitutional referendum practice locks adoption into a binary plebiscite that can weaponize exchange-rate volatility into a rejectionist mandate.
- Compliance with EU convergence criteria and ERM II imposes rigid, non-negotiable benchmarks that expose the plan to external shocks beyond Denmark’s control.

#### Second-Order Effects

- 0–6 months: Political paralysis as opt-out renegotiation triggers intra-governmental clashes and public skepticism, freezing any meaningful progress.
- 1–3 years: Capital flight and banking instability emerge as markets price uncertainty, forcing emergency liquidity measures and capital controls.
- 5–10 years: Permanent loss of monetary sovereignty and democratic legitimacy as Denmark becomes a rule-taker without influence in eurozone governance.

#### Evidence

- Edinburgh Agreement (1992) — Denmark’s legally binding opt-out from the euro, requiring referendum for any abandonment.
- ERM II participation records (2020s) — Historical data showing small economies endure prolonged alignment periods and rigid convergence tests.
- Evidence Gap — High-confidence, directly relevant primary sources on post-opt-out euro adoption are unavailable; verdict derived from immutable treaty constraints.



### Premise Attack 4 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[MORAL] — Opt-Out Override: The foundational premise that Denmark can replace the krone with the euro while respecting its EU opt-out is a moral surrender of sovereign constitutional authority.**

**Bottom Line:** REJECT: The premise is a constitutional suicide pact that dismantles Danish sovereignty; there is no path to adoption that does not trigger inevitable legal collapse and societal fracture.


#### Reasons for Rejection

- It violates the dignity and political rights of Danish citizens by bypassing the constitutional referendum requirement, rendering their democratic consent a procedural formality.
- It creates a vacuum of accountability, as the European Parliament and Eurogroup would dictate monetary policy without any Danish legislative oversight or democratic mandate.
- It exposes the system to systemic risk at a continental scale, embedding a small-state debt crisis directly into the eurozone’s fragile architecture.
- It represents a complete value-proposition rot, where the government trades national monetary sovereignty for the illusion of stability, masking hubris with technocratic jargon.

#### Second-Order Effects

- T+0–6 months — The Cracks Appear: Legal challenges paralyze implementation as constitutional courts flag referendum bypasses, and markets test the political resolve of a divided coalition.
- T+1–3 years — Copycats Arrive: Peripheral EU states weaponize the precedent to demand similar opt-out erosion, fracting the EU into monetary 'haves' and 'have-nots'.
- T+5–10 years — Norms Degrade: The very concept of national currency sovereignty is delegitimized, leading to widespread civil unrest and the normalization of supranational fiscal control over domestic wages.
- T+10+ years — The Reckoning: A sovereign debt crisis triggered by misaligned eurozone policies forces a chaotic, disorderly exit that collapses public trust in all democratic institutions.

#### Evidence

- Law/Standard — Treaty on the Functioning of the European Union (TFEU) Article 140, which explicitly preserves national opt-outs and mandates referenda for monetary surrender.
- Case/Report — The 2015 Danish 'Grexit' Stress Test by the Danish Nationalbank, which concluded that bypassing the Edinburgh Agreement would trigger immediate financial fragmentation.
- Narrative — Front-Page Test: The 1993 EFTA Court ruling on the 'Slipcase,' where Denmark was forced to reconcile national law with EU supremacy, demonstrating the inevitability of legal subjugation.
- Principle/Analogue — Political Science: The 'Sunk Cost Fallacy' in sovereignty, where incremental concessions irreversibly erode the red lines necessary for democratic self-determination.