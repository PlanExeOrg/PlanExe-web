Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 15 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 4 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan involves economics/governance/policy, which are out of scope. The plan describes a "comprehensive, multi-year governmental plan to transition Denmark from the krone to the euro..."

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (Euro adoption) + market (Denmark) + tech/process + policy without independent evidence at comparable scale. There is no evidence of a similar project in a comparable context.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Project Lead / Deliverable: Validation Report / Date: 2025-12-31


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because no business-level mechanism-of-action is defined for the overall Euro adoption strategy. While individual decisions have justifications, the plan lacks a clear inputs→process→customer value model for the entire initiative. "The plan is highly ambitious, involving a complete overhaul..."

**Mitigation**: Project Lead: Develop a one-pager outlining the overall Euro adoption strategy's value hypothesis, success metrics, and decision hooks by 2025-12-31.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the risk register identifies several risks (regulatory, political, financial, etc.), but the plan doesn't explicitly map cascades or second-order effects. The plan mentions "comprehensive risk assessment and mitigation plans" but lacks cascade analysis.

**Mitigation**: Risk Management Team: Expand the risk register to include cascade effects and second-order risks, mapping dependencies and adding controls by 2026-06-30.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions "EU Council Agreement, ECB Concurrence, National Legislation Amendments" but lacks a detailed timeline or dependencies. The plan does not include authoritative permit lead times.

**Mitigation**: Legal Team: Create a permit/approval matrix with dependencies, lead times, and NO-GO thresholds by 2026-06-30.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed sources/term sheets are absent. The plan lacks a dated financing plan listing sources/status, draw schedule, and covenants. Runway length is undefined. The plan mentions "Funding for public information campaigns" but lacks specifics.

**Mitigation**: CFO: Create a dated financing plan listing sources/status, draw schedule, covenants, and a NO-GO on missed financing gates by 2026-06-30.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget range of 200-500 million EUR lacks scale-appropriate benchmarks or vendor quotes normalized by area. The plan states "200-500 million EUR for legal, IT, communication, logistics, based on other EU nations."

**Mitigation**: Finance Team: Benchmark (≥3) similar Euro adoption projects, obtain vendor quotes, normalize per-area (cost/m²), and adjust budget or de-scope by 2026-06-30.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., referendum within 2 years) as single numbers without ranges or alternative scenarios. The plan states "Referendum within 2 years, 1-2 years legal adjustments..."

**Mitigation**: Project Management: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the referendum timeline by 2026-06-30.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because core components lack engineering artifacts. The plan mentions "IT infrastructure upgrades" but lacks detailed specifications, interface contracts, acceptance tests, or an integration plan. The plan does not include non-functional requirements.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates by 2026-06-30.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes several critical claims without providing verifiable evidence. For example, it states, "Successful referendum to lift the opt-out" without providing evidence of a plan to achieve this.

**Mitigation**: Project Lead: Develop an evidence pack containing verifiable artifacts (documents, links, IDs) for all critical legal, contract, and operational claims by 2026-06-30.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major deliverable, Euro adoption, is mentioned without specific, verifiable qualities. The goal statement is "Denmark adopts the euro through a managed national transition plan..."

**Mitigation**: Project Team: Define SMART criteria for 'Euro adoption,' including a KPI for Euro usage (e.g., 95% of transactions in EUR) by 2026-06-30.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because Educational Outreach Programs do not directly support the core project goals of legal certainty or economic stability. The plan states the goal is to "inform the public about the euro's benefits..."

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of Educational Outreach Programs, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog by 2026-06-30.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'EU Negotiation Specialist' role requires rare expertise in EU law, Danish politics, and international relations to secure favorable entry terms. The plan states, "An EU negotiation specialist is essential..."

**Mitigation**: HR: Validate the availability of qualified 'EU Negotiation Specialists' by surveying the talent market and identifying potential candidates by 2026-06-30.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "EU Council Agreement, ECB Concurrence, National Legislation Amendments" but lacks a detailed regulatory matrix (authority, artifact, lead time, predecessors). Legality is unclear and required approvals are unmapped. The plan does not include a **Fatal-Flaw Analysis**.

**Mitigation**: Legal Team: Create a regulatory matrix (authority, artifact, lead time, predecessors) and conduct a **Fatal-Flaw Analysis** to identify showstoppers by 2026-06-30.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "Financial Transition is enabled by Financial Sector Preparedness" but lacks a detailed operational sustainability plan. There is no discussion of long-term maintenance, personnel dependency, or technology obsolescence.

**Mitigation**: Project Team: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, and technology roadmap by 2026-06-30.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions physical locations (Christiansborg Palace, Aarhus City Hall, Odense City Hall) but lacks evidence of zoning/land-use compliance, occupancy/egress, fire load, structural limits, noise, or permit status.

**Mitigation**: Facilities Team: Perform a fatal-flaw screen with authorities/experts, seek written confirmation where feasible, and define fallback designs/sites by 2026-06-30.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "EU Council Agreement" but lacks evidence of SLAs with vendors or tested failover plans for critical dependencies. Redundancy and continuity are not addressed. The plan does not include a vendor dependency map.

**Mitigation**: Procurement Team: Secure SLAs with key vendors, add a secondary supplier/path for critical dependencies, and test failover by 2026-06-30.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Finance Department is incentivized by minimizing costs, while the Public Communication team is incentivized by maximizing public support, creating a conflict over campaign spending. The plan states, "Funding for public information campaigns."

**Mitigation**: Project Lead: Define a shared OKR for Finance and Public Communication focused on 'Cost-effective Public Support' by 2026-06-30.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Lead: Add a monthly review with KPI dashboard and a lightweight change board with escalation thresholds by 2026-06-30.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies several high risks (failed referendum, failure to secure EU agreements, disruptive financial transition) but lacks a cross-impact analysis. A failed referendum could trigger government collapse and legal challenges.

**Mitigation**: Risk Management Team: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by 2026-06-30.