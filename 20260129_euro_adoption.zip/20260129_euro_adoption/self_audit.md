Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 19 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 0 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan deals exclusively with established legal, economic, and operational aspects of a sovereign currency change, which do not violate fundamental laws of physics.

**Mitigation**: None.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on the novel combination of deferring political opt-out repeal until after long-term ERM II convergence is proven, which contradicts assumed EU protocol expectations, as evidenced by FM2 and FM4 tripwires.

**Mitigation**: EU Legal Team: Secure written confirmation from the European Commission supporting the post-ERM II opt-out repeal sequencing by Q4 2026.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because multiple key strategic concepts are defined by their chosen option ('Builder's Blueprint') without a clear quantifiable mechanism beyond vague measures. For example, Governance Architecture is set to 'Maintain agency autonomy under a quarterly 'Joint Ministerial Consultative Body',' which Review 1 identifies as a 'Governance Bottleneck' ($R9$).

**Mitigation**: Chief Transition Architect: Produce one-pagers defining success metrics (velocity targets, consensus threshold) for the Joint Ministerial Consultative Body by Q4 2026.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Builder's Blueprint' strategy explicitly defers the major political risk (Opt-Out repeal) until after a long operational phase, creating systemic timeline risk (FM2, FM4). The plan minimizes cascades, referring only to 'political capital burnout' rather than financial fallout like sunk cost losses or timeline breach consequences.

**Mitigation**: EU Legal Team: Secure written confirmation from the European Commission supporting the post-ERM II opt-out repeal sequencing by Q4 2026.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan assumes a specific, long 24-month minimum ERM II participation followed by referendum scheduling, which Review 1 notes could be undermined by EU sequencing demands, potentially violating timeline constraints. The plan lacks an authoritative permit/approval matrix for EU treaty negotiation milestones.

**Mitigation**: EU Legal Team: Secure written confirmation from the European Commission supporting the post-ERM II opt-out repeal sequencing by Q4 2026.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the pricing relies on a multi-year budget (DKK 15–25 Billion over 6 years) that lacks indexation, leading to Budget Erosion Threat (FM1). The plan does not name committed sources; it only notes the reference range and 'Budgeted public financing.'

**Mitigation**: Fiscal Oversight Manager: Formalize commitment letters for the DKK 15B minimum budget, indexing all multi-year operational spending against CPI by Q4 2026.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan's reliance on inflation-indexed funding is an unverified, critical assumption (A2) over a 4-8 year timeline, where failure leads to budget erosion sufficient to force scope cuts on technical mitigation (FM5). The supporting review clearly states, "No assumption states funding is indexed against sustained high inflation."

**Mitigation**: Fiscal Oversight Manager: Formalize commitment letters for the DKK 15B minimum budget, indexing all multi-year operational spending against CPI by Q4 2026.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Builder's Blueprint' strategy selectively commits to conservative options (Deferring opt-out repeal) but fails to provide any sensitivity analysis or projection ranges for the time-bound goal of 4 to 8 years. The premortem analysis identifies budget erosion (FM1) and EU sequencing friction (FM2) as critical failure modes dependent on time, yet no scenario analysis is present.

**Mitigation**: Chief Transition Architect: Mandate the Fiscal Oversight Manager to deliver a Best/Base/Worst-Case scenario analysis for the 8-year timeline, varying ERM II duration and EU negotiation speed, by Q4 2026.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the instruction requires assessment for engineering artifacts (specs, tests, contracts, NFRs) for build-critical components. The plan only defines strategic and political decisions (e.g., Governance Architecture, ERM Entry Strategy) without evidentiary detail for any underlying technical implementation. The absence of technical specs for core components directly triggers the HIGH alert condition.

**Mitigation**: Central Bank Technical Integration Lead: Produce formal engineering specifications and interface contracts for the 'Shadow Integration Team' integration project by Q2 2026.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks verifiable artifacts for critical claims: specifically, the primary legal move, Opt-Out Resolution Mechanism Selection (Decision 4), is contingent upon an 'Extraordinary European Council session,' for which no planning documents, formal requests, or evidence of high-level political buy-in are cited, making the core legal foundation unproven.

**Mitigation**: Senior EU Legal & Treaty Negotiator: Obtain written confirmation from the European Commission scheduling or precondition agreement for the Extraordinary European Council Dialogue by Q4 2026.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because Decision 3, 'Public Referendum Design and Timing,' is poorly defined. The primary choices focus on abstract timing ('Set the referendum date exactly 90 days prior') without verifiable quality.

**Mitigation**: Public Referendum Lead: Define SMART criteria for Decision 3, including a KPI for voter mandate success (e.g., >60% 'Yes' vote) by Q4 2026.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan's dependency on a detailed, high-stakes negotiation ("Formally request an Extraordinary European Council session") is described abstractly, lacking the necessary preparatory governance artifact needed to show feasibility, as noted in Review 10, Data Quality Concern 1.

**Mitigation**: Senior EU Legal & Treaty Negotiator: Develop and present the drafted proposal for the Extraordinary European Council session to the Joint Ministerial Consultative Body by Q4 2026.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the role 'Senior EU Legal & Treaty Negotiator' is critical for navigating the novel legal path required to lift the opt-out, a mission-critical dependency. This expertise, specializing in Treaty Law and European Council protocols, is presented as rare given the contractor's specific background in Brussels expertise.

**Mitigation**: Senior EU Legal & Treaty Negotiator: Secure written confirmation from the European Commission supporting the post-ERM II opt-out repeal sequencing by Q4 2026.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan's fundamental requirement is navigating complex EU law to lift the DKK opt-out, but it lacks crucial mapping artifacts. The core legal move relies on an 'Extraordinary European Council session' (Decision 4.2), which is completely unmapped regarding authority, artifact needs, or lead time, suggesting a potential showstopper.

**Mitigation**: Senior EU Legal & Treaty Negotiator: Develop a Regulatory Matrix detailing authorities, artifacts, and lead times for all EU treaty negotiation steps required by Decision 4 by Q4 2026.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan exhibits gaps across multiple aspects of operational sustainability, primarily concerning funding stability over a long timeline (4-8 years) leading to budget erosion (FM1), and potential governance bottlenecks (FM3) preventing adaptation.

**Mitigation**: Fiscal Oversight Manager: Institute mandatory annual budget real-indexation reviews for all non-committed capital expenditures linked to CPI forecasts by Q4 2026.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan's chosen strategy ('Builder's Blueprint') hinges on a specific sequencing (deferring opt-out repeal until after ERM II) that introduces high diplomatic risk, as internal review (FM2, FM4) suggests the EU may not accept this political commitment timeline.

**Mitigation**: EU Legal Team: Secure written confirmation from the European Commission supporting the post-ERM II opt-out repeal sequencing by Q4 2026.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan assumes the existing strict DKK exchange rate policy can be maintained during the long ERM II period without severe economic contradiction (Assumption A6), which risks market intervention costs exceeding DKK 100M and jeopardizing the chosen ERM Entry Strategy (Decision 2.1).

**Mitigation**: Macroeconomic Strategist: Model the impact of a 3% DKK appreciation scenario against baseline projections by Q2 2026 to quantify required market defense capability.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Finance Department (incentivized by budget adherence) conflicts with Danmarks Nationalbank (incentivized by technical readiness/monetary stability). The chosen Blueprint defers political action, lengthening the ERM II period, forcing deeper convergence effort strain. Verbatim quote: "(Finance/JMCB) risks decision-making paralysis on time-sensitive technical matters" (premortem FM3).

**Mitigation**: Chief Transition Architect: Finalize and embed a joint OKR requiring 80% confidence in technical readiness 12 months prior to the referendum date by Q4 2026.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan explicitly chooses a consensus-based governance model ('Joint Ministerial Consultative Body') which the premortem analysis identified as a critical bottleneck (FM3), with a demonstrated 85% likelihood of decision paralysis on urgent matters.

**Mitigation**: Chief Transition Architect: Propose a binding governance amendment setting a mandatory 14-day sign-off period for all risk-mitigation directives by Q4 2026.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because selecting the consensus-based 'Joint Ministerial Consultative Body' governance model (Decision 5.2) over centralized authority creates an unmitigated systemic risk of decision paralysis (FM3) that cascades across legal, technical, and readiness workstreams based on assumptions A3 and A9.

**Mitigation**: Chief Transition Architect: Propose a binding governance amendment setting a mandatory 14-day sign-off period for all risk-mitigation directives by Q4 2026.