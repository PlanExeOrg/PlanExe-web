Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 17 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 2 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan focuses on economic and political aspects of adopting the Euro, such as treaty negotiations, referendum, and financial infrastructure. There is no mention of violating any laws of physics.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (euro adoption) + market (Denmark) + tech/process + policy (EU treaty change, referendum) without independent evidence at comparable scale. There is no credible precedent for the whole system.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Project Team: Produce validation tracks / 180 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan uses terms like "sovereign monetary choice", "seamless payment ecosystem", and "citizen-centric communication hub" without defining their business-level mechanism-of-action (inputs→process→customer value), owner, or measurable outcomes.

**Mitigation**: Strategic Planning: Assign owners to each strategic concept to produce one-pagers with value hypotheses, success metrics, and decision hooks by 90 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan omits major hazard classes (e.g., cyberattacks on financial systems, supply chain disruptions for euro cash) and lacks explicit cascade analysis. The risk register does not map dependencies or second-order effects.

**Mitigation**: Risk Management Team: Expand the risk register to include cyber and supply chain risks, map cascade effects, and add controls with a dated review cadence within 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not include a permit/approval matrix, nor does it map critical predecessors. The plan mentions a timeline of 4–8 years, but lacks detail on permit lead times. 

**Mitigation**: Project Management: Create a permit/approval matrix with authoritative lead times, map critical predecessors, and rebuild the critical path with a NO-GO threshold on slip by 90 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not name funding sources, their status, draw schedule, or runway length. The plan mentions "Euro liquidity reserves and contingency funding" but lacks specifics.

**Mitigation**: CFO: Develop a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates within 60 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget conflicts with scale-appropriate benchmarks. The plan lacks vendor quotes or normalized per-area cost data. It mentions "Euro liquidity reserves and contingency funding" but lacks specific figures or benchmarks.

**Mitigation**: Finance Team: Obtain ≥3 vendor quotes for key capex/opex items, normalize costs per m²/ft², benchmark against comparable projects, and adjust the budget or de-scope by 90 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., timeline of 4–8 years) as a single range without providing a confidence interval or discussing alternative scenarios. There is no sensitivity analysis or scenario analysis.

**Mitigation**: Finance Team: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the overall project timeline, including key milestones, within 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not include a permit/approval matrix, nor does it map critical predecessors. The plan mentions a timeline of 4–8 years, but lacks detail on permit lead times. 

**Mitigation**: Project Management: Create a permit/approval matrix with authoritative lead times, map critical predecessors, and rebuild the critical path with a NO-GO threshold on slip by 90 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes critical claims without verifiable artifacts. For example, it states, "EU agreement to a treaty modification lifting Denmark’s opt-out". There is no evidence of any agreement or even preliminary discussions with the EU.

**Mitigation**: Legal Team: Obtain a letter of intent or memorandum of understanding from the EU regarding treaty modification discussions within 120 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the deliverable "Success is measured by supply chain resilience, minimal shortages, and efficient seigniorage capture during dual circulation" lacks specific, verifiable qualities or KPIs.

**Mitigation**: Supply Chain Director: Define SMART criteria for cash conversion, including a KPI for cash availability (e.g., 99.9% ATM uptime) by 30 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes "Modernize Danish payment infrastructure and financial inclusion" as a related goal. This is potential Gold Plating because it does not directly support the core goals of euro adoption or referendum success.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of 'Modernize Danish payment infrastructure', complete with a KPI, owner, and estimated cost, or move the feature to the project backlog by 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies several roles, but the "Transition Program Director" is the most critical. This role requires a unique blend of political acumen, economic expertise, and technical understanding to navigate the complexities of euro adoption.

**Mitigation**: HR: Conduct a talent market analysis for the "Transition Program Director" role, assessing the availability of qualified candidates and their compensation expectations within 60 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not include a permit/approval matrix, nor does it map critical predecessors. The plan mentions a timeline of 4–8 years, but lacks detail on permit lead times.

**Mitigation**: Project Management: Create a permit/approval matrix with authoritative lead times, map critical predecessors, and rebuild the critical path with a NO-GO threshold on slip by 90 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions operational costs and funding but lacks a detailed analysis of long-term sustainability. There is no maintenance schedule, succession plan, technology roadmap, or adaptation mechanisms.

**Mitigation**: Finance Team: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession plan, technology roadmap, and adaptation mechanisms within 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not include a permit/approval matrix, nor does it map critical predecessors. The plan mentions a timeline of 4–8 years, but lacks detail on permit lead times.

**Mitigation**: Project Management: Create a permit/approval matrix with authoritative lead times, map critical predecessors, and rebuild the critical path with a NO-GO threshold on slip by 90 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not include contracts/SLAs with vendors, nor does it describe secondary suppliers or tested failover plans. The plan mentions "Technical platforms for dual-currency processing" but lacks specifics.

**Mitigation**: Procurement Team: Secure SLAs with key vendors, add a secondary supplier/path for critical services, and test failover by 180 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan states goals for the government and financial institutions, but does not address the conflicting incentives. The government wants a smooth transition, while banks prioritize profit, creating tension over conversion costs.

**Mitigation**: Project Team: Define a shared OKR for the government and financial institutions focused on minimizing disruption to citizens during the transition within 60 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process. Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Management Team: Establish a monthly review process with a KPI dashboard and a lightweight change board within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has ≥3 High risks (EU political delays, referendum failure, IT failure) that are strongly coupled. A single dependency (e.g., EU treaty change) can trigger multi-domain failure.

**Mitigation**: Project Team: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by 90 days.