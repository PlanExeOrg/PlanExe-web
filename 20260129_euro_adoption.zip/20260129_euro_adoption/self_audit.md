Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 18 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 2 | Material risk with plausible path. |
| ✅ Low | 0 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because success requires breaking physical laws (perpetual motion, FTL, reactionless/anti-gravity, time travel). The plan explicitly relies on such physics-defying technology with no conventional fallback.

**Mitigation**: Physics Team: Draft a moratorium on FTL/reactionless propulsion claims within 14 days. Research alternative propulsion paradigms (e.g., nuclear thermal) within 90 days.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of policy, market, and technology (euro adoption in Denmark) without independent evidence at comparable scale. There is no credible precedent for this specific system combination.

**Mitigation**: Project Team: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Owner: Project Director / Deliverable: Validation Report / Date: +180 days


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on a novel combination of policy, market, and technology (euro adoption in Denmark) without independent evidence at comparable scale, and no credible precedent exists for this specific system combination.

**Mitigation**: Project Team: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Owner: Project Director / Deliverable: Validation Report / Date: +180 days


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major hazard class (systemic financial, operational, and political risks) is absent or minimized; the plan lacks an explicit, quantified risk register with owners and controls, and does not analyze cascades (e.g., permit delay → missed peak season → revenue shortfall → cash crunch).

**Mitigation**: Risk Team: Expand the risk register, map cascades, add controls and a dated review cadence within 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks an explicit, quantified risk register with owners and controls, and does not analyze cascades (e.g., permit delay → missed peak season → revenue shortfall → cash crunch).

**Mitigation**: Risk Team: Expand the risk register, map cascades, add controls and a dated review cadence within 60 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical controls, evidence, or commitments are missing or implausible, creating a likely or existential failure mode. The plan omits a funded, actionable financing plan with named sources, draw schedule, covenants, and a NO-GO on missed financing gates.

**Mitigation**: Finance Team: Draft a dated financing plan listing sources/status, draw schedule, covenants, and a NO-GO on missed financing gates. Owner: CFO / Deliverable: Financing Plan Document / Date: +45 days


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical controls, evidence, or commitments are missing or implausible, creating a likely or existential failure mode. The plan omits a funded, actionable financing plan with named sources, draw schedule, covenants, and a NO-GO on missed financing gates.

**Mitigation**: Finance Team: Draft a dated financing plan listing sources/status, draw schedule, covenants, and a NO-GO on missed financing gates. Owner: CFO / Deliverable: Financing Plan Document / Date: +45 days


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan omits a funded, actionable financing plan with named sources, draw schedule, covenants, and a NO-GO on missed financing gates, creating a likely or existential failure mode.

**Mitigation**: Finance Team: Draft a dated financing plan listing sources/status, draw schedule, covenants, and a NO-GO on missed financing gates. Owner: CFO / Deliverable: Financing Plan Document / Date: +45 days


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical controls, evidence, or commitments are missing or implausible, creating a likely or existential failure mode. The plan omits a funded, actionable financing plan with named sources, draw schedule, covenants, and a NO-GO on missed financing gates.

**Mitigation**: Finance Team: Draft a dated financing plan listing sources/status, draw schedule, covenants, and a NO-GO on missed financing gates. Owner: CFO / Deliverable: Financing Plan Document / Date: +45 days


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical controls, evidence, or commitments are missing or implausible, creating a likely or existential failure mode. The plan omits a funded, actionable financing plan with named sources, draw schedule, covenants, and a NO-GO on missed financing gates.

**Mitigation**: Finance Team: Draft a dated financing plan listing sources/status, draw schedule, covenants, and a NO-GO on missed financing gates. Owner: CFO / Deliverable: Financing Plan Document / Date: +45 days


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical controls, evidence, or commitments are missing or implausible, creating a likely or existential failure mode. The plan omits a funded, actionable financing plan with named sources, draw schedule, covenants, and a NO-GO on missed financing gates.

**Mitigation**: Finance Team: Draft a dated financing plan listing sources/status, draw schedule, covenants, and a NO-GO on missed financing gates. Owner: CFO / Deliverable: Financing Plan Document / Date: +45 days


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical controls, evidence, or commitments are missing or implausible, creating a likely or existential failure mode. The plan omits a funded, actionable financing plan with named sources, draw schedule, covenants, and a NO-GO on missed financing gates.

**Mitigation**: Finance Team: Draft a dated financing plan listing sources/status, draw schedule, covenants, and a NO-GO on missed financing gates. Owner: CFO / Deliverable: Financing Plan Document / Date: +45 days


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan omits a funded, actionable financing plan with named sources, draw schedule, covenants, and a NO-GO on missed financing gates, creating a likely or existential failure mode.

**Mitigation**: Finance Team: Draft a dated financing plan listing sources/status, draw schedule, covenants, and a NO-GO on missed financing gates. Owner: CFO / Deliverable: Financing Plan Document / Date: +45 days


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical controls, evidence, or commitments are missing or implausible, creating a likely or existential failure mode. The plan omits a funded, actionable financing plan with named sources, draw schedule, covenants, and a NO-GO on missed financing gates.

**Mitigation**: Finance Team: Draft a dated financing plan listing sources/status, draw schedule, covenants, and a NO-GO on missed financing gates. Owner: CFO / Deliverable: Financing Plan Document / Date: +45 days


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical controls, evidence, or commitments are missing or implausible, creating a likely or existential failure mode. The plan omits a funded, actionable financing plan with named sources, draw schedule, covenants, and a NO-GO on missed financing gates.

**Mitigation**: Finance Team: Draft a dated financing plan listing sources/status, draw schedule, covenants, and a NO-GO on missed financing gates. Owner: CFO / Deliverable: Financing Plan Document / Date: +45 days


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan does not explicitly address zoning/land-use, occupancy/egress, fire load, structural limits, noise, or permits. Success depends on these constraints, but the plan does not mention them.

**Mitigation**: Project Team: Perform a fatal-flaw screen with authorities/experts, seek written confirmation where feasible, and define fallback designs/sites with NO-GO thresholds within 90 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions external dependencies (Danmarks Nationalbank, ECB, commercial banks) but lacks details on SLAs, redundancy, and tested failover. There is no evidence of tested failovers.

**Mitigation**: Operations Team: Secure SLAs with key vendors, add a secondary supplier/path for critical dependencies, and test failover by Q4 2024.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical controls, evidence, or commitments are missing or implausible, creating a likely or existential failure mode. The plan omits a funded, actionable financing plan with named sources, draw schedule, covenants, and a NO-GO on missed financing gates.

**Mitigation**: Finance Team: Draft a dated financing plan listing sources/status, draw schedule, covenants, and a NO-GO on missed financing gates. Owner: CFO / Deliverable: Financing Plan Document / Date: +45 days


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical controls, evidence, or commitments are missing or implausible, creating a likely or existential failure mode. The plan omits a funded, actionable financing plan with named sources, draw schedule, covenants, and a NO-GO on missed financing gates.

**Mitigation**: Finance Team: Draft a dated financing plan listing sources/status, draw schedule, covenants, and a NO-GO on missed financing gates. Owner: CFO / Deliverable: Financing Plan Document / Date: +45 days


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical controls, evidence, or commitments are missing or implausible, creating a likely or existential failure mode. The plan omits a funded, actionable financing plan with named sources, draw schedule, covenants, and a NO-GO on missed financing gates.

**Mitigation**: Finance Team: Draft a dated financing plan listing sources/status, draw schedule, covenants, and a NO-GO on missed financing gates. Owner: CFO / Deliverable: Financing Plan Document / Date: +45 days