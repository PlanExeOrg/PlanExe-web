
## Question 1 - What specific legal and treaty steps are required to lift Denmark's EU opt-out and establish a binding roadmap for euro adoption?

**Assumptions:** Assumption: The EU and Denmark can agree on a simplified treaty adjustment procedure that does not require renegotiating primary EU treaties, and that Denmark's constitutional referendum practice can be satisfied with a binary 'Yes/No' vote on the specific opt-out waiver.

**Assessments:** Title: Legal and Treaty Steps Assessment
Description: Evaluation of the domestic and EU legal processes needed to move from opt-out to adoption.
Details: Risks include prolonged negotiations if EU member states demand broader conditionality, or if the referendum question is deemed too complex for voters, causing rejection. Benefits include a clear, legitimate pathway that reinforces EU rule of law and Danish sovereignty. Mitigation: Draft a concise, single-issue treaty amendment with pre-negotiated flexibility clauses; align referendum timing with EU political cycle to maximize legitimacy; secure advance ECB and Commission guidance to reduce uncertainty.

## Question 2 - What is the planned timeline and sequencing of milestones from the political decision to adopt the euro through full withdrawal of the Danish krone?

**Assumptions:** Assumption: A multi-year timeline of 4–8 years is realistic, with clear gates: political decision → referendum → treaty change → ERM II entry (2 years) → dual circulation → full euro adoption.

**Assessments:** Title: Timeline & Milestones Assessment
Description: Evaluation of the sequence and duration of phases to ensure orderly transition.
Details: Risks include underestimating dual-circulation complexity, causing extended parallel costs, or political momentum loss if milestones slip. Benefits include predictable planning for businesses and the public, and reduced market volatility. Mitigation: Implement a gated project plan with independent phase-gate reviews; publish a public milestone dashboard; build schedule buffers for technical integration and public education.

## Question 3 - What personnel, institutions, and governance structures are needed to manage the transition, and how will responsibilities be allocated?

**Assumptions:** Assumption: Existing Danish institutions (Folketinget, Danmarks Nationalbank, Financial Supervisory Authority) can be augmented with temporary cross-ministerial task forces without requiring new permanent bodies.

**Assessments:** Title: Resources & Personnel Assessment
Description: Evaluation of human capital, institutional roles, and coordination mechanisms.
Details: Risks include capacity gaps in central bank IT conversion and public communication, leading to delays or errors. Benefits include leveraging established expertise and clear accountability. Mitigation: Define a RACI matrix for all workstreams; recruit specialist euro-transition staff; establish a Municipal and Public Sector Dual Circulation Management Office; set up a Stakeholder Engagement Secretariat.

## Question 4 - How will Denmark's euro adoption be governed domestically and vis-à-vis EU institutions to ensure compliance and adaptability?

**Assumptions:** Assumption: Denmark will maintain its constitutional referendum requirement while accepting EU conditionality, and will use the Eurogroup and ECB as primary technical governance bodies during the transition.

**Assessments:** Title: Governance & Regulations Assessment
Description: Evaluation of the regulatory and institutional oversight framework.
Details: Risks include conflicts between national referendum practice and EU harmonization demands, or insufficient representation in ECB decision spaces. Benefits include stronger monetary policy alignment and credibility. Mitigation: Establish a formal Dialogue Channel with the ECB and Commission; secure pre-approval for Danish derogation terms; embed parliamentary oversight committees with access to expert advice.

## Question 5 - What specific measures will manage financial, operational, and systemic risks during the transition, including market stability and contingency planning?

**Assumptions:** Assumption: A comprehensive risk register with quantified likelihood and impact can be maintained, and that contingency reserves equivalent to at least 6 months of dual-circulation costs can be pre-allocated.

**Assessments:** Title: Safety & Risk Management Assessment
Description: Evaluation of the identification, mitigation, and monitoring of transition risks.
Details: Risks include unanticipated market shocks or operational failures causing service disruptions. Benefits include increased resilience and public confidence. Mitigation: Develop scenario-based contingency plans; conduct full-scale simulation drills; establish a crisis management cell; secure political backing for rapid decision-making during incidents.

## Question 6 - What is the approach to assessing, communicating, and managing environmental impacts and sustainability considerations of the euro transition?

**Assumptions:** Assumption: The environmental footprint of the transition will be limited and manageable, focusing on energy-efficient IT systems and reduced cash logistics, in line with EU green standards.

**Assessments:** Title: Environmental Impact Assessment
Description: Evaluation of ecological implications and sustainability measures.
Details: Risks include unintended increases in carbon footprint from cash transportation and data center loads. Benefits include alignment with EU Green Deal objectives and improved corporate image. Mitigation: Use green energy for central bank and bank data centers; optimize cash-in-transit routes; publish an environmental impact statement; set KPIs for emission reductions during dual circulation.

## Question 7 - How will the government ensure sustained public and stakeholder buy-in through communication, education, and inclusive participation?

**Assumptions:** Assumption: A sustained, multi-channel communication strategy backed by municipal and business networks can achieve over 70% public awareness and understanding of key transition details before referendum and conversion.

**Assessments:** Title: Stakeholder Involvement Assessment
Description: Evaluation of engagement strategies with citizens, businesses, and institutions.
Details: Risks include misinformation and public resistance, especially around rounding and price changes. Benefits include smoother adoption and reduced social friction. Mitigation: Launch town-hall and digital Q&A campaigns; co-create rounding guidelines with consumer groups; provide SME toolkits; monitor sentiment via social listening and adjust messaging iteratively.

## Question 8 - What are the technical and operational specifications for converting payment systems, IT infrastructure, pricing, and cash logistics to support dual circulation and final euro adoption?

**Assumptions:** Assumption: Danish banks and payment providers can align on common technical standards (e.g., ISO 20022) with ECB oversight, and that a single, government-coordinated cash logistics chain can handle nationwide dual-circulation needs.

**Assessments:** Title: Operational Systems Assessment
Description: Evaluation of the technical readiness and integration of payment and IT systems.
Details: Risks include system incompatibility causing transaction failures and prolonged dual-circulation costs. Benefits include a robust, future-proof payments ecosystem and enhanced interoperability with euro area systems. Mitigation: Mandate open standards; conduct end-to-end stress tests; establish a Central Conversion Unit for IT and cash logistics; implement dual pricing display requirements for a fixed period.