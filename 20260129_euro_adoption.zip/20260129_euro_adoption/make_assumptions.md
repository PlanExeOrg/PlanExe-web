
## Question 1 - Given the chosen 'Builder's Blueprint' strategy, which prioritizes postponing opt-out repeal until after successful ERM II completion, what is the required minimum allocation figure for the initial multi-year, government-funded public information campaign (Strategy 11), expressed as a percentage of the total estimated national transition budget?

**Assumptions:** Assumption: Based on comparable EU adoptions (e.g., Slovakia, Lithuania), a high-certainty public information strategy requires sustained funding equating to 0.5% of the total estimated national transition budget (which is assumed to be in the range of DKK 15–25 billion over 6 years) to effectively manage the high political risk associated with reversing the opt-out.

**Assessments:** Title: Funding & Budget Allocation Assessment
Description: Evaluation of the necessary committed funding floor for the public information campaign based on chosen risk profile.
Details: Committing 0.5% of an estimated DKK 20 billion transition budget implies an allocation of DKK 100 million dedicated solely to the Societal Readiness Pacing ($DR 11$. This allocation is critical mitigation for Risk 2 (Referendum failure). If the Builder's Blueprint is followed, this expenditure must be released immediately post-political decision to maintain momentum, regardless of ERM II status. Opportunity exists to phase this expenditure over 3-4 initial years, prioritizing educational material creation over mass media saturation until the referendum date is set.

## Question 2 - Assuming the political decision is made today (2026-May-02) and adhering to the 'Builder's Blueprint' which mandates a minimum 24-month ERM II participation period, what is the earliest realistic target date for the national referendum (Decision 3) regarding opt-out repeal?

**Assumptions:** Assumption: The 'Builder's Blueprint' dictates that formal ERM II entry (post-negotiation/treaty agreement) occurs in Q3 2027. Given the minimum 24-month participation period, convergence confirmation readiness would be Q3 2029, allowing for a 6-month lag for Folketinget affirmation and referendum scheduling, leading to a Q1 2030 referendum.

**Assessments:** Title: Timeline & Milestones Assessment
Description: Establishing the critical milestone for democratic consent based on mandatory convergence periods.
Details: The earliest target for the referendum is Q1 2030, placing the project near the higher end of the 4-8 year band. This long lead time directly mitigates Risk 3 (Convergence Failure) by securing the political mandate only when technical economic criteria are functionally met. The main risk is stakeholder impatience (Strategy 5.2 Governance Bottleneck) during the prolonged ERM II period, requiring carefully timed communication updates to sustain political support over the 3-year preparatory phase.

## Question 3 - Given the elected governance structure of a 'Joint Ministerial Consultative Body' (Decision 5), how will the necessary specialized technical workforce (including ECB integration experts, as per Strategy 8.3) be sourced, trained, and retained across potential multi-year ERM II fluctuations without relying on an immediate, high-cost permanent staffing expansion?

**Assumptions:** Assumption: Due to the high political risk associated with early formal opt-out repeal (Strategy 2), long-term hiring is deferred. Staffing will rely on securing 60% of required technical staff through short-term, high-value secondments from Danmarks Nationalbank and specialized EU/ECB consultative contracts, with the remainder filled by leveraging the 'Shadow Integration Team' concept (Strategy 8.1).

**Assessments:** Title: Resources & Personnel Assessment
Description: Strategy for securing specialized personnel while managing post-referendum employment uncertainty.
Details: A hybrid approach utilizing secondments and external consultants minimizes the sunk cost if the referendum fails, aligning with the pragmatic nature of the 'Builder's Blueprint.' Risk 9 (Governance Paralysis) is managed by delegating initial contracts to the Nationalbank Chair. Opportunity: Early secondment exposure to ECB systems accelerates internal skill transfer, making the bank more robust during the target 24-month ERM II period, improving convergence metrics.

## Question 4 - Which specific regulatory approval mechanisms (domestic constitutional review vs. EU procedure) carry the higher risk of forcing the timeline past 8 years, and what mechanism is prioritized in the 'Opt-Out Resolution Mechanism Selection' to prevent this outcome?

**Assumptions:** Assumption: Formally requesting an Extraordinary European Council session (Strategy 4.2) carries a lower long-term procedural risk than relying on a novel political declaration (Strategy 4.1), due to the need for high-level legal certainty required by the ECB. However, treaty amendment carries a higher risk of 27-state ratification delays if domestic constitutional review is also triggered simultaneously.

**Assessments:** Title: Governance & Regulations Assessment
Description: Evaluation of legal pathways' impact on timeline certainty versus political maneuvering.
Details: The primary governance risk is the 27-state ratification of a targeted protocol amendment (Risk 1). The chosen strategy (4.2) accepts this political risk to gain ECB certainty. Mitigation requires relentless diplomatic pressure, focusing initial EU engagement on securing unanimous agreement on the *process* before negotiating the *substance*. Domestic constitutional review must be managed concurrently by the Ministry of Justice to ensure legislative readiness for post-referendum ratification.

## Question 5 - Considering the high likelihood of logistical pressure during the assumed 30-day dual circulation period, what specific contingency capital must be ring-fenced to cover immediate, unbudgeted security enhancements for cash transport and storage if Risk 5 (Cash Supply Failure) materializes?

**Assumptions:** Assumption: Based on Risk 5 analysis, an unbudgeted DKK 50 million contingency fund is necessary to rapidly contract Tier-2 security providers or expand insured temporary storage facilities should the primary logistics chain show strain in the first two weeks of dual circulation.

**Assessments:** Title: Safety & Risk Management Assessment
Description: Quantification of immediate financial resources needed for physical security backup protocols.
Details: Ring-fencing DKK 50 million provides a crucial buffer against the high likelihood of logistical/security incidents during the compressed 30-day dual phase. This fund should be distinct from the IT budget ($DR 8$) and linked directly to the Cash Logistics lever ($DR 6$). Opportunity: Pre-qualifying three regional security contracts now (even if currently unfunded) allows immediate activation within 72 hours if initial monitoring reveals bottlenecks, drastically reducing response time.

## Question 6 - Since the plan commits to joining the existing Euro Area, how will the Danish government proactively address potential future political scrutiny from other EU states regarding environmental reporting and sustainability standards misalignment that might emerge as Denmark integrates its fiscal mechanisms with the ECB framework?

**Assumptions:** Assumption: Denmark commits to adopting the ECB's current guidelines on climate-related financial risk reporting and stress testing protocols immediately upon ERM II entry, even if these are not strictly mandatory for DKK-only participation, ensuring a 'best practice' profile ahead of the Euro Day.

**Assessments:** Title: Environmental Impact Assessment
Description: Proactive alignment with non-monetary EU standards to build political leverage for convergence approval.
Details: While the core focus is monetary, proactive adoption of ECB climate-related disclosure standards for financial institutions (as part of Convergence Triage $DR 9$) minimizes future friction with the European Commission and Parliament regarding general alignment. This strategy builds goodwill, which is indirectly beneficial for securing successful treaty/opt-out repeal negotiation (Risk 1 mitigation), though it adds minor operational cost to the commercial banks.

## Question 7 - To ensure the 'Joint Ministerial Consultative Body' remains effective (Decision 5) across the long timeline, what specific mechanism will be instituted to manage communication and expectation setting with key external stakeholders (Business, Unions) to prevent fragmentation of support between the political decision and the referendum date?

**Assumptions:** Assumption: A quarterly 'Economic Alignment Stakeholder Forum' ($EASF$) will be established, chaired by the Ministry of Business, feeding directly into the Consultative Body. This forum will provide mandatory updates on convergence progress (via $DR 9$) and receive early warnings on upcoming ERM II alignment changes (via $DR 12$), targeting a consistent 80% stakeholder satisfaction rating in annual pulse checks.

**Assessments:** Title: Stakeholder Involvement Assessment
Description: Structuring engagement channels to maintain broad support across the multi-year convergence phase.
Details: The $EASF$ addresses the high inherent risk of stakeholder fatigue during the long ERM II period. By providing structured technical updates ($DR 9$) rather than purely political announcements, it grounds support in verifiable progress, mitigating a key driver for reduced support during long preparation times. Failure to maintain this forum risks eroding the business community's willingness to invest in necessary IT upgrades ahead of conversion deadlines.

## Question 8 - Considering the commitment to 'Maintain the current strict DKK exchange rate policy' (Decision 2) during pre-ERM II convergence, what is the mandated protocol for Danmarks Nationalbank to simulate and validate the integrity of DKK-based IT payment systems (e.g., domestic clearing houses) against the projected EUR conversion logic before formal integration with TARGET2 (€-systems)?

**Assumptions:** Assumption: The National Bank will mandate internal 'Euro Simulation Exercises' ($ESE$) using anonymized historical DKK transaction data against the projected 1:7.46 DKK/EUR conversion rate, running these tests across all critical payment systems (not just those directly connecting to TARGET2) for a minimum of six continuous months prior to formal ERM II entry.

**Assessments:** Title: Operational Systems Assessment
Description: Establishing non-binding, robust internal testing procedures for domestic operational readiness.
Details: The $ESE$ directly mitigates Risk 4 (Technical Integration Failure) by testing domestic systems before external linkage. Since Strategy 2 for ERM Entry is chosen (minimal pre-entry shock), the operational systems must be ready to transition quickly once the DKK peg is formalized. The key is ensuring that the results of these $ESE$ are shared with the 'Joint Ministerial Consultative Body' ($DR 5$) to ensure technical preparedness drives governance decisions, not the reverse.