### 1. Project Sponsor (Prime Minister) designates an Interim Chair for the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Appointment Notification

**Dependencies:**

- Project Start

### 2. Interim Chair of the PSC drafts initial Terms of Reference (ToR) for the PSC, based on the pre-defined responsibilities and membership.

**Responsible Body/Role:** Interim Chair, Project Steering Committee

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1

**Dependencies:**

- Appointment of Interim Chair

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Project Management Office (PMO), based on the pre-defined responsibilities and membership.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**

- Project Start

### 4. Project Manager drafts initial Terms of Reference (ToR) for the Legal and Compliance Committee (LCC), based on the pre-defined responsibilities and membership.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft LCC ToR v0.1

**Dependencies:**

- Project Start

### 5. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group (SEG), based on the pre-defined responsibilities and membership.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SEG ToR v0.1

**Dependencies:**

- Project Start

### 6. Circulate Draft PSC ToR v0.1 to nominated PSC members for review and feedback.

**Responsible Body/Role:** Interim Chair, Project Steering Committee

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft PSC ToR v0.1
- Nominated Members List Available

### 7. Circulate Draft PMO ToR v0.1 to nominated PMO members for review and feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft PMO ToR v0.1
- Nominated Members List Available

### 8. Circulate Draft LCC ToR v0.1 to nominated LCC members for review and feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft LCC ToR v0.1
- Nominated Members List Available

### 9. Circulate Draft SEG ToR v0.1 to nominated SEG members for review and feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SEG ToR v0.1
- Nominated Members List Available

### 10. Interim Chair of the PSC finalizes the PSC ToR based on feedback received.

**Responsible Body/Role:** Interim Chair, Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PSC ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft PSC ToR v0.1

### 11. Project Manager finalizes the PMO ToR based on feedback received.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft PMO ToR v0.1

### 12. Project Manager finalizes the LCC ToR based on feedback received.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final LCC ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft LCC ToR v0.1

### 13. Project Manager finalizes the SEG ToR based on feedback received.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SEG ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft SEG ToR v0.1

### 14. Project Sponsor formally appoints the Chair and members of the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails
- Public Announcement (if appropriate)

**Dependencies:**

- Final PSC ToR v1.0
- Nominated Members List Available

### 15. Project Director is appointed within the PMO.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation

**Dependencies:**

- Final PMO ToR v1.0

### 16. Chief Legal Counsel (Danmarks Nationalbank) is appointed as Chair of the Legal and Compliance Committee (LCC).

**Responsible Body/Role:** Governor, Danmarks Nationalbank

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation

**Dependencies:**

- Final LCC ToR v1.0

### 17. Communication Manager (PMO) is appointed as Chair of the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation

**Dependencies:**

- Final SEG ToR v1.0

### 18. Hold the initial kick-off meeting for the Project Steering Committee (PSC).

**Responsible Body/Role:** Chair, Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Agreement on initial priorities

**Dependencies:**

- Appointment of PSC Chair and Members
- Final PSC ToR v1.0

### 19. Hold the initial kick-off meeting for the Project Management Office (PMO).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Assignment of initial tasks

**Dependencies:**

- Appointment of Project Director
- Final PMO ToR v1.0

### 20. Hold the initial kick-off meeting for the Legal and Compliance Committee (LCC).

**Responsible Body/Role:** Chair, Legal and Compliance Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Agreement on initial priorities

**Dependencies:**

- Appointment of LCC Chair
- Final LCC ToR v1.0

### 21. Hold the initial kick-off meeting for the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Chair, Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Agreement on initial priorities

**Dependencies:**

- Appointment of SEG Chair
- Final SEG ToR v1.0

### 22. The Project Steering Committee (PSC) reviews and approves the initial project plan presented by the PMO.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved Project Plan v1.0

**Dependencies:**

- Initial PSC Kick-off Meeting
- Initial PMO Kick-off Meeting
- Project Plan Drafted by PMO

### 23. The Legal and Compliance Committee (LCC) develops and implements initial compliance policies and procedures.

**Responsible Body/Role:** Legal and Compliance Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Compliance Policies and Procedures v1.0

**Dependencies:**

- Initial LCC Kick-off Meeting

### 24. The Stakeholder Engagement Group (SEG) develops and implements the stakeholder engagement strategy.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Stakeholder Engagement Strategy v1.0

**Dependencies:**

- Initial SEG Kick-off Meeting