# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: EU Monetary Law Specialist

**Knowledge**: EU monetary law, treaty change procedures, ERM II rules

**Why**: Addresses legal/treaty steps and ECB compliance for opt-out lifting

**What**: Draft the legal roadmap for treaty modification and referendum design

**Skills**: Regulatory analysis, treaty negotiation, EU law

**Search**: EU monetary law treaty change ERM II Denmark opt-out

## 1.1 Primary Actions

- Commission a detailed legal analysis of the EU treaty change process, identifying specific articles for amendment and potential negotiating obstacles.
- Conduct a thorough economic simulation of Denmark's economy under various ERM II scenarios, including potential exchange rate shocks and speculative attacks.
- Obtain a formal legal opinion from constitutional law experts on the specific requirements for a valid referendum on transferring sovereignty, clearly defining turnout and support thresholds.

## 1.2 Secondary Actions

- Engage with EU law experts, former treaty negotiators, economists specializing in exchange rate regimes, and central bankers with experience in ERM II.
- Develop a clear communication strategy to manage market expectations during ERM II participation and public understanding of the referendum process.
- Establish a dedicated legal team to monitor constitutional developments and potential legal challenges to the referendum.

## 1.3 Follow Up Consultation

Discuss the findings of the legal and economic analyses, the proposed communication strategy, and the contingency plans for different referendum outcomes. We will also review the revised project plan to ensure it addresses the identified weaknesses and incorporates the recommended mitigation measures.

## 1.4.A Issue - Lack of Concrete Treaty Change Strategy

The plan mentions treaty change as a requirement but lacks a detailed strategy for achieving it. It doesn't specify which treaty articles need amendment, potential negotiating roadblocks with other member states, or alternative legal pathways if a full treaty change proves impossible. The 'Builder' scenario's approach of presenting a 'non-negotiable, fully costed implementation timeline' is naive and unrealistic in EU treaty negotiations. This is a critical oversight, as treaty change is the foundational legal step.

### 1.4.B Tags

- treaty_change
- legal_strategy
- EU_negotiation

### 1.4.C Mitigation

Conduct a thorough legal analysis identifying the specific treaty articles requiring amendment. Engage with EU law experts and former treaty negotiators to understand potential obstacles and develop alternative legal strategies (e.g., using existing treaty flexibilities). Model different negotiation scenarios and their impact on the timeline. Consult with the Danish Ministry of Foreign Affairs and legal scholars specializing in EU law. Read: 'The Law and Practice of EU External Relations' by Cremona and 'EU Law' by Craig and de Búrca.

### 1.4.D Consequence

Without a concrete treaty change strategy, the entire euro adoption plan is built on sand. Denmark could face years of fruitless negotiations or be forced to abandon the project altogether.

### 1.4.E Root Cause

Underestimation of the complexities of EU treaty change procedures and a lack of in-depth legal expertise within the planning team.

## 1.5.A Issue - Insufficient Focus on ERM II Realities

The plan treats ERM II as a mere formality, failing to adequately address the potential challenges and constraints it imposes. The 'Builder' scenario's approach of achieving full Maastricht criteria compliance *before* ERM II entry is unrealistic. ERM II is *designed* to test convergence. The plan needs a more nuanced understanding of how ERM II participation will affect Denmark's monetary policy autonomy and exchange rate management. There's a lack of discussion on potential speculative attacks on the Krone within the ERM II band and the policy responses available.

### 1.5.B Tags

- ERM_II
- monetary_policy
- exchange_rate
- speculation

### 1.5.C Mitigation

Conduct a detailed simulation of Denmark's economy under various ERM II scenarios, including potential exchange rate shocks and speculative attacks. Analyze the ECB's past interventions in ERM II and their effectiveness. Develop a clear communication strategy to manage market expectations during ERM II participation. Consult with economists specializing in exchange rate regimes and central bankers with experience in ERM II. Read: 'Monetary Policy in the Eurozone' by de Grauwe and 'Exchange Rate Economics' by MacDonald.

### 1.5.D Consequence

Underestimating ERM II risks could lead to exchange rate instability, loss of monetary policy control, and ultimately, failure to meet the convergence criteria, derailing the euro adoption process.

### 1.5.E Root Cause

A superficial understanding of the ERM II mechanism and its potential impact on Denmark's economy.

## 1.6.A Issue - Referendum Threshold Ambiguity and Constitutional Risks

The plan mentions a referendum but lacks a rigorous analysis of the constitutional requirements for its validity. The statement 'draft referendum legislation with >50% turnout and >40% electorate threshold' is vague and potentially unconstitutional. What constitutes a valid 'electorate threshold'? Is it 40% of all eligible voters, or 40% of those who actually vote? This ambiguity could lead to legal challenges and invalidate the referendum result. The plan needs a clear legal opinion on the constitutional requirements for a valid referendum on transferring sovereignty.

### 1.6.B Tags

- referendum
- constitutionality
- legal_risk
- thresholds

### 1.6.C Mitigation

Obtain a formal legal opinion from constitutional law experts on the specific requirements for a valid referendum on transferring sovereignty. Clearly define the turnout and support thresholds in the referendum legislation, leaving no room for ambiguity. Develop contingency plans for different referendum outcomes, including scenarios where the thresholds are not met. Consult with constitutional law scholars and experienced referendum organizers. Read: 'Constitutional Law of Denmark' by Jensen and 'Referendums Around the World' by Qvortrup.

### 1.6.D Consequence

A poorly designed referendum could be challenged in court, leading to years of legal uncertainty and potentially invalidating the entire euro adoption process.

### 1.6.E Root Cause

Insufficient attention to the constitutional complexities of holding a referendum on transferring sovereignty.

---

# 2 Expert: Central Bank Transition Strategist

**Knowledge**: central bank operations, liquidity management, dual-currency systems

**Why**: Guides Danmarks Nationalbank conversion strategy and euro liquidity

**What**: Design central bank asset reclassification and settlement protocols

**Skills**: Monetary policy, liquidity risk, payment systems

**Search**: central bank transition euro adoption liquidity management

## 2.1 Primary Actions

- Establish an independent Convergence Audit Council with ECB and Danish Fiscal Council oversight to certify Maastricht compliance before any ERM II application.
- Operationalize a Central Conversion Unit (CCU) with authority to enforce dual-pricing SLAs, payment system failover protocols, and real-time liquidity stress testing.
- Pass a Referendum Legality Act defining turnout and support thresholds, independent electoral oversight, and a binding but challengeable implementation trigger, including a 12-month cooling-off period.

## 2.2 Secondary Actions

- Mandate weekly reconciliation and settlement reporting from all payment operators with automated exception escalation.
- Create a public-facing transition dashboard publishing convergence metrics, FX bands, cash reserve levels, and referendum progress.
- Commission an independent legal review of contract conversion enforceability and publish a summary to guide legislative drafting.

## 2.3 Follow Up Consultation

Next session should focus on: (1) detailed design of the Convergence Audit Council mandate and membership; (2) draft SLA templates for dual-currency reconciliation and failure response; (3) legal memo on referendum enforceability with fallback legislative options.

## 2.4.A Issue - Over-reliance on political momentum without binding technical preconditions for ERM II entry

The plan assumes that political commitment alone can drive ERM II entry, but without legally binding technical checkpoints and independent verification of convergence, Denmark risks entering under unsustainable conditions and facing ECB non-compliance.

### 2.4.B Tags

- governance
- compliance
- risk

### 2.4.C Mitigation

Embed an independent technical audit body with real-time convergence dashboards and mandatory 'stop gates' that delay ERM II entry if Maastricht criteria drift beyond tolerance. Consult the ECB and Danish Fiscal Council for threshold definitions and enforcement mechanisms.

### 2.4.D Consequence

Failure to align with ECB rules could delay or block ERM II entry, increasing volatility and undermining credibility.

### 2.4.E Root Cause

Empty

## 2.5.A Issue - Insufficient detail on dual-currency operational resilience and systemic risk controls

The plan describes dual pricing and cash hubs but lacks concrete failover protocols, reconciliation SLAs, and stress test scenarios for payment system outages or liquidity crunches during the dual-circulation period.

### 2.5.B Tags

- operational risk
- liquidity
- IT resilience

### 2.5.C Mitigation

Define measurable resilience KPIs (e.g., transaction success rate >99.9%, reconciliation within 1 hour), conduct weekly end-to-end stress tests, and establish a Central Conversion Unit with authority to trigger circuit breakers. Consult payment system operators and the Financial Stability Board for best practices.

### 2.5.D Consequence

Operational failures could cause merchant disruption, public loss of confidence, and regulatory penalties.

### 2.5.E Root Cause

Empty

## 2.6.A Issue - Ambiguity in legal enforceability of referendum outcomes and contract conversion rules

The plan assumes a clear legal path post-referendum, but Danish constitutional practice and EU law may create ambiguities in enforcing the result and mandating contract conversion, leaving room for litigation and paralysis.

### 2.6.B Tags

- legal
- constitutional
- contract law

### 2.6.C Mitigation

Commission an independent legal review of referendum enforceability and draft a ministerial decree with sunset clauses and arbitration triggers. Consult the Danish Supreme Court and EU legal advisors to pre-empt challenges. Provide a public summary of findings and a fallback legislative pathway.

### 2.6.D Consequence

Legal uncertainty could stall implementation, trigger market disputes, and erode public trust.

### 2.6.E Root Cause

Empty

---

# The following experts did not provide feedback:

# 3 Expert: Political Communications Lead

**Knowledge**: public communication, referendum strategy, stakeholder engagement

**Why**: Plans the referendum timeline and public preparedness campaigns

**What**: Create communication and change-management strategy for citizens and businesses

**Skills**: Crisis communication, public affairs, media strategy

**Search**: political communications referendum strategy Denmark euro adoption

# 4 Expert: Financial Systems Integration Architect

**Knowledge**: payment systems, dual-pricing implementation, IT migration

**Why**: Oversees financial infrastructure migration and cash conversion logistics

**What**: Define dual-pricing, POS upgrades, and cash logistics execution plan

**Skills**: Payment systems, IT project management, operational continuity

**Search**: payment systems integration dual pricing POS migration euro adoption

# 5 Expert: EU Monetary Law Specialist

**Knowledge**: EU monetary law, treaty change procedures, ERM II rules

**Why**: Addresses legal/treaty steps and ECB compliance for opt-out lifting

**What**: Draft the legal roadmap for treaty modification and referendum design

**Skills**: Regulatory analysis, treaty negotiation, EU law

**Search**: EU monetary law treaty change ERM II Denmark opt-out

# 6 Expert: Central Bank Transition Strategist

**Knowledge**: central bank operations, liquidity management, dual-currency systems

**Why**: Guides Danmarks Nationalbank conversion strategy and euro liquidity

**What**: Design central bank asset reclassification and settlement protocols

**Skills**: Monetary policy, liquidity risk, payment systems

**Search**: central bank transition euro adoption liquidity management

# 7 Expert: Political Communications Lead

**Knowledge**: public communication, referendum strategy, stakeholder engagement

**Why**: Plans the referendum timeline and public preparedness campaigns

**What**: Create communication and change-management strategy for citizens and businesses

**Skills**: Crisis communication, public affairs, media strategy

**Search**: political communications referendum strategy Denmark euro adoption

# 8 Expert: Financial Systems Integration Architect

**Knowledge**: payment systems, dual-pricing implementation, IT migration

**Why**: Oversees financial infrastructure migration and cash conversion logistics

**What**: Define dual-pricing, POS upgrades, and cash logistics execution plan

**Skills**: Payment systems, IT project management, operational continuity

**Search**: payment systems integration dual pricing POS migration euro adoption