# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: EU Treaty Law Specialist

**Knowledge**: Treaty change, Protocol amendments, European Council procedure, Opt-out legal frameworks

**Why**: The core legal challenge is lifting the DKK opt-out, requiring expertise in complex EU treaty amendment procedures and Council negotiation strategy (Decision 4).

**What**: Analyze the feasibility and timeline of 'Protocol Amendment' versus full treaty renegotiation under current EC mandates.

**Skills**: International law, EU lobbying, Legal due diligence, Constitutional constraint modeling

**Search**: EU treaty amendment process EU Council, Legal pathways Danish Euro opt-out, ECB protocol negotiation strategy

## 1.1 Primary Actions

- Establish the 'EU Opt-Out Engagement Taskforce' within 7 days to draft negotiation proposals.
- Approve the formation of the 'Shadow Integration Team' by May 9 to begin technical simulations.
- Task the Ministry of Justice to finalize the 'Dual-Path Legal Contingency Mandate' by June 15.

## 1.2 Secondary Actions

- Schedule regular updates with the taskforce to monitor negotiation progress.
- Conduct a review of the technical simulation results and adjust the integration plan accordingly.
- Engage external legal counsel to validate the contingency mandate and ensure compliance with existing laws.

## 1.3 Follow Up Consultation

Discuss the progress of the EU Opt-Out Engagement Taskforce and the outcomes of the initial technical simulations in the next meeting. Evaluate the effectiveness of the legal contingency planning and any adjustments needed.

## 1.4.A Issue - Insufficient Clarity on Opt-Out Negotiation Strategy

The current plan lacks a clear, actionable strategy for negotiating the removal of Denmark's opt-out from the euro. This is critical as it directly impacts the timeline and feasibility of the entire transition process.

### 1.4.B Tags

- opt-out
- negotiation
- strategy

### 1.4.C Mitigation

Establish a dedicated 'EU Opt-Out Engagement Taskforce' to draft a formal proposal for negotiation pathways with the European Commission. This taskforce should include senior diplomats and legal advisors to ensure a robust approach.

### 1.4.D Consequence

Without a clear negotiation strategy, Denmark risks EU rejection of the sequencing, leading to critical political timeline failures and jeopardizing the entire euro adoption process.

### 1.4.E Root Cause

Lack of proactive engagement and clarity in the negotiation framework with EU institutions.

## 1.5.A Issue - Delayed Technical Integration Planning

The plan does not prioritize immediate technical integration simulations, which are essential for ensuring readiness for euro adoption. This delay could lead to significant operational risks.

### 1.5.B Tags

- technical integration
- risk
- readiness

### 1.5.C Mitigation

Immediately approve the establishment of a 'Shadow Integration Team' tasked with conducting Euro Simulation Exercises using historical transaction data. This will help identify potential gaps in technical readiness.

### 1.5.D Consequence

Failure to address technical integration early could result in operational failures during the transition, leading to public dissatisfaction and potential financial instability.

### 1.5.E Root Cause

Insufficient urgency in addressing technical readiness independent of political timelines.

## 1.6.A Issue - Inadequate Legal Contingency Planning

The plan lacks a comprehensive legal contingency framework to address potential failures in the referendum process. This could expose the government to significant legal disputes and financial losses.

### 1.6.B Tags

- legal
- contingency
- referendum

### 1.6.C Mitigation

Task the Ministry of Justice to produce a 'Dual-Path Legal Contingency Mandate' that outlines automatic repeals of preparatory legislation if the referendum fails, ensuring legal clarity and financial protection.

### 1.6.D Consequence

Without a solid legal contingency plan, the government risks prolonged legal disputes and financial liabilities, which could delay economic normalization and undermine public trust.

### 1.6.E Root Cause

Neglecting to incorporate robust legal frameworks into the transition planning process.

---

# 2 Expert: Central Banking Digital Transformation Consultant

**Knowledge**: Payment systems integration, TARGET2, Eurosystem readiness, SEPA migration, IT de-risking

**Why**: Technical readiness is a major constraint (Risk 4, Decision 8). An expert can assess the 'Shadow Integration Team' plan versus full ECB requirements.

**What**: Review the planned integration timeline for Danmarks Nationalbank against ECB technical milestones, identifying non-negotiable upfront CAPEX needs.

**Skills**: Core banking systems, Core banking systems, ISO 20022 migration, Financial infrastructure security

**Search**: ECB Eurosystem integration consulting, TARGET2 implementation lead, Central bank IT transformation expert

## 2.1 Primary Actions

- Establish the 'Euro Transition Authority' to streamline decision-making and expedite the transition process.
- Develop and launch a public engagement campaign that includes a 'killer app' to illustrate the benefits of euro adoption.
- Reassess the project timeline to identify opportunities for acceleration and set interim milestones.

## 2.2 Secondary Actions

- Conduct a stakeholder analysis to identify key influencers and potential opposition to euro adoption.
- Implement regular progress updates to maintain transparency and public trust throughout the transition process.
- Engage with EU institutions early to secure support for the proposed sequencing of opt-out repeal and ERM II participation.

## 2.3 Follow Up Consultation

Discuss the establishment of the 'Euro Transition Authority' and the proposed public engagement campaign, including the timeline for implementation and expected outcomes.

## 2.4.A Issue - Inadequate Governance Structure

The current governance structure, relying on the Joint Ministerial Consultative Body, risks decision-making paralysis due to the need for consensus among multiple ministries. This could slow critical operational directives and delay the transition timeline.

### 2.4.B Tags

- Governance
- Decision-Making
- Bureaucracy

### 2.4.C Mitigation

Establish a dedicated 'Euro Transition Authority' with executive powers to expedite decision-making and streamline the transition process. This authority should be chaired by a senior official with direct access to the Prime Minister.

### 2.4.D Consequence

Without a more agile governance structure, the project may face significant delays, risking the overall timeline and increasing the likelihood of political and public discontent.

### 2.4.E Root Cause

The reliance on a consensus-based governance model that is inherently slow and cumbersome.

## 2.5.A Issue - Insufficient Public Engagement Strategy

The public engagement strategy lacks a clear, compelling narrative to mobilize support for the euro adoption. Current plans may lead to public fatigue and confusion, especially if the referendum is delayed.

### 2.5.B Tags

- Public Engagement
- Communication
- Referendum

### 2.5.C Mitigation

Develop a comprehensive public engagement campaign that includes a 'killer app' to demonstrate the benefits of euro adoption. This should be coupled with targeted outreach to key demographics to ensure widespread understanding and support.

### 2.5.D Consequence

Failure to effectively engage the public could result in a low turnout or negative sentiment during the referendum, jeopardizing the entire transition plan.

### 2.5.E Root Cause

A lack of innovative and engaging communication strategies to connect with the public on the benefits of euro adoption.

## 2.6.A Issue - Overly Conservative Timeline

The proposed timeline of 4-8 years for full euro adoption may be overly conservative, potentially leading to project fatigue and budget erosion. This could also create opportunities for political opposition to gain traction.

### 2.6.B Tags

- Timeline
- Project Management
- Political Risk

### 2.6.C Mitigation

Reassess the timeline to identify opportunities for acceleration, such as overlapping phases of the transition plan. Consider setting interim milestones that can be celebrated to maintain momentum and public interest.

### 2.6.D Consequence

An overly extended timeline may lead to loss of political capital and public interest, increasing the risk of referendum failure and project derailment.

### 2.6.E Root Cause

A cautious approach that prioritizes risk management over proactive engagement and momentum-building.

---

# The following experts did not provide feedback:

# 3 Expert: Public Finance Economist specializing in Sovereign Debt

**Knowledge**: Public budget indexing, Long-term fiscal forecasting, Maastricht criteria compliance, Sovereign debt management

**Why**: The plan requires a multi-year budget (DKK 15-25B) vulnerable to inflation erosion (Issue 2) and must continuously meet Maastricht criteria (Risk 3).

**What**: Design the precise inflation-indexing mechanism for the transition budget and model the impact of immediate DKK pre-appreciation on current debt service capacity.

**Skills**: Fiscal policy modeling, Inflation accounting, Public sector financial management, Budgeting control

**Search**: Public project inflation indexing Denmark, Fiscal impact DKK EUR conversion, Sovereign budget management multi-year

# 4 Expert: Behavioral Scientist specializing in Public Finance Change

**Knowledge**: Cash transition management, Consumer rounding compliance, Behavioral economics for policy adoption, Referendum messaging

**Why**: The success of the conversion (cash logistics, contract change) depends heavily on high societal readiness and compliance (Decision 11, Decision 6).

**What**: Evaluate the proposed 'Societal Readiness Pacing' strategy against the chosen referendum timing and propose metrics for the 'killer app' success.

**Skills**: Change management communications, Survey design, Financial literacy campaign, Stakeholder engagement strategy

**Search**: Behavioral science currency transition, Consumer rounding adoption, Public finance change management expert

# 5 Expert: EU ERM II Compliance Negotiator

**Knowledge**: ERM II entry requirements, ECB convergence assessment, Exchange rate stability, Bilateral negotiation with ECB

**Why**: The chosen strategy defers formal opt-out repeal until after ERM II stability is demonstrated, making the negotiation of entry terms and convergence signals critical (Decision 12, Decision 2).

**What**: Model the negotiation strategy for securing ECB acceptance of the DKK's current rate policy as an 'informal ERM II alignment' pathway.

**Skills**: ECB liaison, Monetary policy coordination, Financial market signaling, Regulatory arbitrage detection

**Search**: Negotiating ERM II entry criteria Hungary, ECB convergence checklist implementation, Exchange Rate Mechanism stability protocol

# 6 Expert: Commercial Litigation & Contract Law Attorney

**Knowledge**: Contract law harmonization, Automatic re-denomination clauses, Consumer protection finance law, Legal contingency planning

**Why**: A key risk is widespread legal disputes from mandatory contract re-denomination (Risk 7, Decision 7), requiring expertise in voiding/automating private agreements.

**What**: Review the 'no-change' contract re-denomination mandate (Decision 7.1) for immediate constitutional challenges under Danish contract law.

**Skills**: Commercial dispute resolution, Contractual nullification analysis, Financial services regulatory compliance, Litigation risk assessment

**Search**: Automatic currency conversion contract law Denmark, Finance contract litigation risk, Legal impact mandatory euro adoption

# 7 Expert: Public Sector IT Governance Auditor

**Knowledge**: Municipal IT maturity assessment, ERP system migration compliance, Public sector procurement for shared services, Digital transformation auditing

**Why**: The plan involves ensuring thousands of local government IT systems align (Decision 14), which requires auditing decentralized maturity and managing centralized mandates.

**What**: Develop a scalable framework for auditing municipal readiness and tracking compliance with centralized accounting standards ahead of Euro Day.

**Skills**: IT governance framing, Public sector ERP rollout, Sub-national data standardization, Cloud migration oversight

**Search**: Auditing municipal ERP system readiness, Public sector IT centralization challenges, Local government digital transformation expert

# 8 Expert: Logistics and Security Supply Chain Director

**Knowledge**: High-value asset security, Cash-in-transit optimization, National cash withdrawal/destruction protocols, Cross-border logistics security

**Why**: Executing the aggressive 30-day dual circulation (Decision 6) requires world-class physical security and logistical orchestration (Decision 13).

**What**: Benchmark proposed cash logistics security contracting against global best practices for high-volume, high-security currency withdrawal exercises.

**Skills**: Cash handling security protocols, Logistics risk mitigation, Secured warehousing contracts, Supply chain resilience planning

**Search**: Secure currency replacement logistics planning, Cash destruction security protocols, High-value logistics audit