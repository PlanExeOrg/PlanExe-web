This plan **does not** imply any physical location.
No requirements for the physical location.

## Location 1
Denmark

Copenhagen

Christiansborg Palace, 1218 Copenhagen

**Rationale**: The seat of Denmark's Parliament and government ministries, ideal for coordinating inter-ministerial leadership, Folketinget proceedings, and high-level treaty negotiations.

## Location 2
Denmark

Copenhagen

Danmarks Nationalbank headquarters, 1650 Copenhagen

**Rationale**: Critical for overseeing monetary policy, ERM II readiness, liquidity management, and the technical transition of central bank reserves and payment systems.

## Location 3
European Union

Brussels

European Commission and Eurogroup meeting venues

**Rationale**: Necessary for formal EU negotiations on treaty derogation, ERM II conditions, and securing alignment with ECB convergence criteria and regulatory approvals.

## Location 4
Denmark

Aarhus

Aarhus City Hall and municipal IT infrastructure hub

**Rationale**: Key for piloting municipal dual-circulation management, public communication outreach, and testing localized cash conversion logistics outside Copenhagen.

## Location Summary
No location is strictly required by the plan’s content, as it is a ministerial-level document. However, four real-world sites are suggested to support execution: Christiansborg Palace for political leadership; Danmarks Nationalbank for monetary/technical transition; EU venues for treaty negotiations; and Aarhus City Hall for municipal pilot implementation.