This plan implies one or more physical locations.

## Requirements for physical locations

- Location suitable for high-level government meeting and ongoing coordination (Inter-Agency Governance)
- Logistical hubs for secure management, sorting, and destruction of DKK cash and distribution of EUR (Cash Logistics)
- Locations for nationwide referendum execution (Polling stations)
- EU institutional locations for treaty negotiation and sign-off

## Location 1
Denmark

Copenhagen (Governmental and Central Bank Hub)

Christiansborg Palace / Danmarks Nationalbank HQ

**Rationale**: This is the necessary physical nexus for the 'Joint Ministerial Consultative Body' (Decision 5) and houses the Danish Central Bank, essential for all operational and legal decision-making related to currency transition and ERM II strategy.

## Location 2
Belgium

Brussels (EU Negotiations)

European Quarter (Commission/Council/ECB liaison offices)

**Rationale**: Necessary for the critical phases of 'Opt-Out Resolution Mechanism Selection' and 'Legal Pathway to Opt-Out Removal,' requiring direct physical engagement with EU institutions in Brussels.

## Location 3
Denmark

Nationwide infrastructure for Referendum and Cash Logistics

Municipal polling places and designated secured National Bank regional cash handling depots

**Rationale**: Covers the physical execution requirements of the 'Public Referendum Design' and 'Cash Stock Synchronization Strategy,' demanding widespread physical presence across all administrative regions.

## Location Summary
The transition plan requires three primary types of physical locations: Copenhagen for core Danish governmental and central bank coordination (Christiansborg/Nationalbank); Brussels for all necessary EU treaty negotiations and European Council meetings; and the entire national territory for executing the public referendum and the logistics of cash handling and distribution.