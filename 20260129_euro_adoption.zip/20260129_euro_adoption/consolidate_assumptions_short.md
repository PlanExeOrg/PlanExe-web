# Purpose
# Purpose: business

# Purpose Detailed: A structured plan for Denmark to adopt the euro, covering legal, political, economic, operational, and communication steps, respecting the EU opt-out, and requiring treaty change and referendum.

## Topic: Denmark national transition plan to adopt the euro as national currency

# Plan Type
# Plan Overview

- Requires one or more physical locations
- Cannot be executed digitally

# Explanation

- High-level national transition strategy requiring physical actions
- Government decision-making and parliamentary processes (Folketinget)
- Treaty negotiations with EU institutions
- National referendums
- Central bank operations
- Commercial bank system upgrades
- Payment system changes
- Public communication campaigns
- Logistical cash conversion
- Involves physical coordination, legal proceedings, political processes, and economic infrastructure changes


# Physical Locations
This plan does not imply any physical location.
No requirements for the physical location.

## Location 1
Denmark

Copenhagen

Christiansborg Palace, 1218 Copenhagen

Rationale: The seat of Denmark's Parliament and government ministries, ideal for coordinating inter-ministerial leadership, Folketinget proceedings, and high-level treaty negotiations.

## Location 2
Denmark

Copenhagen

Danmarks Nationalbank headquarters, 1650 Copenhagen

Rationale: Critical for overseeing monetary policy, ERM II readiness, liquidity management, and the technical transition of central bank reserves and payment systems.

## Location 3
European Union

Brussels

European Commission and Eurogroup meeting venues

Rationale: Necessary for formal EU negotiations on treaty derogation, ERM II conditions, and securing alignment with ECB convergence criteria and regulatory approvals.

## Location 4
Denmark

Aarhus

Aarhus City Hall and municipal IT infrastructure hub

Rationale: Key for piloting municipal dual-circulation management, public communication outreach, and testing localized cash conversion logistics outside Copenhagen.

## Location Summary
No location is strictly required by the plan’s content, as it is a ministerial-level document. However, four real-world sites are suggested to support execution: Christiansborg Palace for political leadership; Danmarks Nationalbank for monetary/technical transition; EU venues for treaty negotiations; and Aarhus City Hall for municipal pilot implementation.

# Currency Strategy
This plan involves money.

## Currencies

- DKK: Local currency of Denmark; included for domestic transactions during dual circulation period.
- EUR: Target currency for adoption; required for EU integration and as primary currency for budgeting.
- USD: Stable international currency included due to currency instability risks; used for international reporting and as a reference to mitigate hyperinflation and exchange-rate uncertainty.

Primary currency: EUR

Currency strategy: For local transactions, use DKK during the dual-circulation period and transition to EUR for all official budgeting and reporting. For international and stability-sensitive planning, use USD as a stable reference. Manage currency risk by aligning with ECB monetary policy, using forward contracts where necessary, and communicating clearly with stakeholders to minimize exchange-rate volatility impacts.

# Identify Risks
## Risk 1 - Regulatory & Permitting

- Failure to secure EU agreement for treaty change to lift the opt-out due to political opposition, unmet requirements, or legal challenges.
- Impact: Project termination or indefinite delay, wasting resources and causing reputational damage; delay of 2-5 years or termination.
- Likelihood: Medium
- Severity: High
- Action: Engage diplomatically with key EU members; ensure compliance; address EU concerns; develop alternatives.

## Risk 2 - Political

- Referendum fails to secure public support for euro adoption due to sovereignty concerns, economic uncertainty, or lack of trust.
- Impact: Project termination; significant political damage; delay of 5+ years or termination.
- Likelihood: Medium
- Severity: High
- Action: Implement communication strategy; ensure transparency; tailor messaging; consider preliminary referendum.

## Risk 3 - Economic & Financial

- Failure to meet Maastricht convergence criteria, delaying or preventing adoption.
- Impact: Delay; increased uncertainty and volatility; reputation damage; delay of 1-3 years.
- Likelihood: Medium
- Severity: Medium
- Action: Implement sound fiscal/monetary policies; monitor indicators; coordinate with ECB; develop contingencies.

## Risk 4 - Operational

- Difficulties converting IT, payment systems, and contracts, disrupting activity.
- Impact: Market disruptions; increased costs; reputational damage; delay of 3-6 months and extra cost of 10,000,000-50,000,000 DKK.
- Likelihood: Medium
- Severity: Medium
- Action: Create detailed conversion plan; provide training; test systems; phase conversion; mandate dual pricing.

## Risk 5 - Social

- Public resistance to rounding rules and price changes.
- Impact: Social unrest; trust damage; political opposition; delay of 1-6 months and extra cost of 1,000,000-5,000,000 DKK.
- Likelihood: Low
- Severity: Medium
- Action: Define transparent rounding rules; educate public; engage stakeholders; mitigate impact; formal Social Pact.

## Risk 6 - Technical

- Critical IT system failure during conversion.
- Impact: Significant disruptions; trust loss; reputational damage; delay of 1-4 weeks and extra cost of 5,000,000-20,000,000 DKK.
- Likelihood: Low
- Severity: High
- Action: Rigorous testing; contingency plans; backup systems; technical support; 'Big Bang' conversion.

## Risk 7 - Supply Chain

- Inadequate euro banknote and coin supply.
- Impact: Cash shortages; dissatisfaction; credibility damage; delay of 1-2 weeks and extra cost of 1,000,000-5,000,000 DKK.
- Likelihood: Low
- Severity: Medium
- Action: Secure supply chain; coordinate with ECB; establish centralized cash hubs.

## Risk 8 - Security

- Increased counterfeiting and fraud during dual circulation.
- Impact: More counterfeiting; trust loss; reputation damage; extra cost of 500,000-2,000,000 DKK.
- Likelihood: Low
- Severity: Low
- Action: Prevent counterfeiting; educate public; strengthen enforcement; mandate exchange points.

## Risk 9 - Financial

- Unexpected conversion costs straining the budget.
- Impact: Budget overruns; reduced funding; dissatisfaction; extra cost of 10,000,000-100,000,000 DKK.
- Likelihood: Medium
- Severity: Medium
- Action: Detailed budget; monitor spending; seek EU aid; conditional legislative trigger.

## Risk 10 - Market/Competitive

- Negative market reaction causing capital flight and instability.
- Impact: Capital flight; instability; higher borrowing costs; delay of 6-12 months and extra cost of 5,000,000-25,000,000 DKK.
- Likelihood: Low
- Severity: Medium
- Action: Maintain market communication; sound policies; contingency plans; fluctuation band announcement.

## Risk summary

- Most critical: EU agreement failure and referendum rejection, risking termination and political damage.
- Mitigation: Diplomatic engagement, public communication, sound policies.
- Manageable financial/technical risks through planning and testing.
- Trade-off between conversion speed and economic disruption; 'Builder' approach recommended.


# Make Assumptions
## Question 1 - What specific legal and treaty steps are required to lift Denmark's EU opt-out and establish a binding roadmap for euro adoption?

- Assumptions: EU and Denmark agree on a simplified treaty adjustment; Danish referendum is a binary Yes/No on the opt-out waiver.
- Assessments: Legal and Treaty Steps Assessment.
- Details: Risks: prolonged negotiations; referendum complexity. Benefits: clear, legitimate pathway reinforcing rule of law and sovereignty. Mitigation: single-issue amendment; aligned referendum timing; ECB and Commission guidance.

## Question 2 - What is the planned timeline and sequencing of milestones from the political decision to adopt the euro through full withdrawal of the Danish krone?

- Assumptions: Multi-year timeline of 4–8 years with gates: political decision → referendum → treaty change → ERM II (2 years) → dual circulation → full adoption.
- Assessments: Timeline & Milestones Assessment.
- Details: Risks: dual-circulation complexity; momentum loss. Benefits: predictable planning, reduced volatility. Mitigation: gated reviews; public dashboard; schedule buffers.

## Question 3 - What personnel, institutions, and governance structures are needed to manage the transition, and how will responsibilities be allocated?

- Assumptions: Existing Danish institutions can be augmented with temporary cross-ministerial task forces.
- Assessments: Resources & Personnel Assessment.
- Details: Risks: capacity gaps in IT and communication. Benefits: established expertise, clear accountability. Mitigation: RACI matrix; specialist staff; Dual Circulation Management Office; Stakeholder Engagement Secretariat.

## Question 4 - How will Denmark's euro adoption be governed domestically and vis-à-vis EU institutions to ensure compliance and adaptability?

- Assumptions: Denmark maintains referendum requirement while accepting EU conditionality; Eurogroup and ECB are primary governance bodies.
- Assessments: Governance & Regulations Assessment.
- Details: Risks: conflict between referendum practice and EU harmonization; ECB representation gaps. Benefits: monetary policy alignment, credibility. Mitigation: Dialogue Channel with ECB/Commission; pre-approved derogation; parliamentary oversight.

## Question 5 - What specific measures will manage financial, operational, and systemic risks during the transition, including market stability and contingency planning?

- Assumptions: Comprehensive risk register with quantified likelihood/impact; pre-allocated reserves for 6 months of dual-circulation costs.
- Assessments: Safety & Risk Management Assessment.
- Details: Risks: market shocks, operational failures. Benefits: resilience, public confidence. Mitigation: scenario plans; simulation drills; crisis cell; political backing for rapid decisions.

## Question 6 - What approach to assessing, communicating, and managing environmental impacts and sustainability considerations of the euro transition?

- Assumptions: Limited environmental footprint via energy-efficient IT and reduced cash logistics aligned with EU green standards.
- Assessments: Environmental Impact Assessment.
- Details: Risks: increased carbon footprint from cash transport and data loads. Benefits: EU Green Deal alignment, improved image. Mitigation: green energy; optimized routes; impact statement; emission KPIs.

## Question 7 - How will the government ensure sustained public and stakeholder buy-in through communication, education, and inclusive participation?

- Assumptions: Sustained multi-channel strategy can achieve over 70% public awareness before referendum and conversion.
- Assessments: Stakeholder Involvement Assessment.
- Details: Risks: misinformation, resistance around rounding and prices. Benefits: smoother adoption, reduced friction. Mitigation: town halls and digital Q&A; rounding guidelines with consumer groups; SME toolkits; sentiment monitoring.

## Question 8 - What are the technical and operational specifications for converting payment systems, IT infrastructure, pricing, and cash logistics to support dual circulation and final euro adoption?

- Assumptions: Banks and providers align on standards (e.g., ISO 20022) with ECB oversight; single government-coordinated cash logistics chain.
- Assessments: Operational Systems Assessment.
- Details: Risks: system incompatibility, prolonged dual-circulation costs. Benefits: robust, future-proof payments ecosystem. Mitigation: open standards; stress tests; Central Conversion Unit; dual pricing display.


# Distill Assumptions
- Define Denmark's legal and treaty steps to lift the euro opt-out and hold a constitutional referendum.
- Implement a multi-year timeline: political decision, referendum, treaty change, ERM II, dual circulation, full adoption.
- Augment existing Danish institutions with cross-ministerial task forces to manage transition governance.
- Ensure EU and ECB governance alignment while preserving Denmark's constitutional referendum requirement.
- Maintain a comprehensive risk register with contingency reserves for systemic and operational risks.
- Limit transition environmental impact through energy-efficient systems and reduced cash logistics.
- Execute a sustained multi-channel communication strategy to achieve public awareness and buy-in.
- Align payment systems and IT infrastructure on common technical standards with ECB oversight.


# Review Assumptions
## Domain of the expert reviewer
National monetary transition and EU integration policy

## Domain-specific considerations

- ERM II entry sequencing and ECB oversight
- Treaty change and constitutional referendum design
- Dual-currency IT and payment system conversion
- Cash logistics and seigniorage capture
- Stakeholder alignment and social pacts
- Environmental and sustainability impacts
- Risk register and contingency budgeting

## Issue 1 - Missing assumption: Independent fiscal and monetary capacity during the pre-ERM II convergence period
No explicit assumption on Denmark’s ability to maintain autonomous fiscal support and Danmarks Nationalbank’s operational capacity while converging under external ECB oversight. Impact: If fiscal space is insufficient, convergence delays could increase project cost by 5–10% (approx. 2–4 billion DKK) and delay the referendum by 6–12 months.

Recommendation: Quantify fiscal space using a baseline structural deficit threshold (<0.5% of GDP) and simulate ECB policy scenarios. Establish a pre-commitment facility (e.g., a temporary credit line with the ECB or ESM) to preserve autonomy. Define a fiscal rule that allows temporary, rules-based deviations during the convergence ramp-up, with independent verification by the FSA.

Sensitivity: 

## Issue 2 - Missing assumption: Legal enforceability of referendum outcomes and fallback mechanisms
The plan assumes a binary referendum can lock the process, but does not address scenarios where turnout or margin is ambiguous, or where post-referendum political shifts occur. Impact: Legal uncertainty can stall treaty change and delay ERM II entry by 12–24 months. Potential cost of 10–15% of budget (approx. 5–8 billion DKK).

Recommendation: Embed a clear legal test (e.g., >50% turnout and >40% of electorate in favor) and a defined fallback (e.g., a ‘soft referendum’ mandate for the Folketing to proceed with treaty change under specified conditions). Draft contingency protocols for annulment or narrow wins, including a 12-month cooling-off and re-engagement phase with adjusted communication.

Sensitivity: 

## Issue 3 - Missing assumption: Currency risk management during dual circulation and ECB balance sheet exposure
Assumptions on cash logistics and seigniorage do not fully account for exchange-rate volatility between DKK and EUR during the dual-circulation window. Impact: A 5% DKK depreciation could increase conversion costs by 2–3% (approx. 1–2 billion DKK) and delay full adoption by 3–6 months due to repricing pressures.

Recommendation: Implement a dynamic hedging program using EUR/DAK forwards aligned with the parity band, and establish a Sovereign Conversion Fund capitalized at 0.5–1% of GDP to absorb FX volatility. Publish daily parity bands and conduct weekly stress tests with the ECB.

Sensitivity: 

## Issue 4 - Missing assumption: Interoperability and legacy system sunsetting for payment infrastructures
Assumptions on IT alignment (e.g., ISO 20022) do not address coexistence costs and technical debt in legacy Danish banking systems. Impact: Inadequate integration could raise operational risk costs by 15–20% (approx. 300–500 million DKK annually) and delay full adoption by 6–9 months.

Recommendation: Mandate a phased legacy sunsetting schedule with incentives for early adoption (e.g., regulatory capital relief for compliant institutions). Create an Interoperability Certification Body under the FSA to audit and accredit systems, with penalties for non-compliance.

Sensitivity: 

## Issue 5 - Missing assumption: Public inflation expectations and wage-price spiral risks during dual circulation
The plan does not explicitly model how price rounding and dual pricing may feed into inflation expectations. Impact: Unanchored expectations could increase wage demands by 1–2 percentage points, raising CPI inflation by 0.5–1% and forcing premature ECB-style tightening, which could reduce ROI by 3–5% over the transition.

Recommendation: Introduce a Wage-Price Protocol with indexed rounding caps and a public dashboard for transparency. Pair with a macroprudential buffer (e.g., countercyclical capital buffers) to dampen demand-side pressures, and simulate scenarios using the ECB’s Convergence Report templates.

Sensitivity: 

## Review conclusion
The transition plan lacks explicit assumptions on fiscal-monetary autonomy during convergence, referendum legal enforceability, currency risk management, legacy system interoperability, and inflation expectation anchoring. These gaps could increase costs by 5–15% and delay completion by 12–24 months. Prioritize: (1) fiscal space analysis with ECB-aligned rules; (2) referendum legal design with fallback clauses; (3) dynamic FX hedging and a Sovereign Conversion Fund. Embed these into a quantified risk register with contingency budgets and independent audits.