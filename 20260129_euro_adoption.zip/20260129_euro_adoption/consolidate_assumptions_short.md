# Purpose
# National Currency Transition: DKK to EUR

## Purpose

- Business: Comprehensive strategic and logistical plan for national government execution of major change in monetary policy and infrastructure.

## Topic

- National currency transition from DKK to EUR for Denmark.

## Plan Components (Implied Structure)

- Treaty negotiation
- Public referendum
- Economic restructuring
- National operational change management


# Domain
# Project Plan Condensation

## Primary Domain
Public Finance

## Secondary Domains
European Union Law, Macroeconomic Management, Monetary Policy

## Rationale
Public Finance holds the core success criterion: national financial transition to the euro. Monetary Policy is close second, but Public Finance captures the holistic national adoption mandate. Economic Policy Communication is subordinate to financial execution.

## Disciplines Involved

- Public Finance: Importance 5, Specificity 5, Role outcome. Reason: Core outcome is national change of legal tender.
- Monetary Policy: Importance 5, Specificity 5, Role outcome. Reason: Primary outcome is change of national currency (monetary policy execution).
- European Union Law: Importance 5, Specificity 4, Role constraint. Reason: Adoption requires navigating EU treaty changes and ECB mandates.
- Macroeconomic Management: Importance 4, Specificity 4, Role method. Reason: Transition requires managing ERM II, convergence criteria, and exchange rate risk.
- Change Management: Importance 4, Specificity 4, Role method. Reason: Large-scale operational and public preparedness needs dedicated strategies.
- Economic Policy Communication: Importance 4, Specificity 4, Role outcome. Reason: Successful public preparedness and perception management are critical for legal adoption.
- Project Implementation: Importance 4, Specificity 3, Role method. Reason: Demands structured, multi-phase implementation roadmap from decision to launch.

## Warnings

- Dropped duplicate fit domain: European Union Law
- Dropped duplicate fit domain: European Union Law
- First-pass produced 7 candidate(s) after 3 batch call(s); target was 9.


# Plan Type
# Denmark Currency Transition Plan (DKK to EUR)

## Constraints and Classification

- Requires one or more physical locations.
- Cannot be executed digitally. Classification: Physical (due to referendum, treaty signing, cash logistics, and system implementation).

## Key Physical Requirements

- Nationwide referendum execution (polling stations, voter logistics).
- Treaty changes negotiation and signing (EU institutions, Ministerial meetings).
- Central bank and commercial bank coordination: physical handling, exchange, transport, and security of DKK/EUR cash.
- Physical implementation/verification of IT systems across all entities.


# Physical Locations
# Project Plan - Physical Locations

## Requirements for physical locations

- Location for high-level government meeting and ongoing coordination (Inter-Agency Governance)
- Logistical hubs for secure cash management and distribution (Cash Logistics)
- Locations for nationwide referendum execution (Polling stations)
- EU institutional locations for treaty negotiation and sign-off

## Location 1
Denmark - Copenhagen (Governmental and Central Bank Hub)

- Christiansborg Palace / Danmarks Nationalbank HQ
- Rationale: Nexus for 'Joint Ministerial Consultative Body' and houses Central Bank, essential for currency transition/ERM II strategy.

## Location 2
Belgium - Brussels (EU Negotiations)

- European Quarter (Commission/Council/ECB liaison offices)
- Rationale: Necessary for 'Opt-Out Resolution Mechanism Selection' and 'Legal Pathway to Opt-Out Removal,' requiring physical engagement with EU institutions.

## Location 3
Denmark - Nationwide infrastructure for Referendum and Cash Logistics

- Municipal polling places and secured National Bank regional cash handling depots
- Rationale: Covers physical execution of 'Public Referendum Design' and 'Cash Stock Synchronization Strategy.'

## Location Summary
Requires three primary locations: Copenhagen for Danish governmental/central bank coordination; Brussels for EU treaty negotiations; and the national territory for referendum execution and cash logistics.

# Currency Strategy
# Project Plan Shortened

## Currencies

- DKK: Current national currency, needed for local transactions pre-Euro Day.
- EUR: Target currency for future transactions, budgeting, and reporting.
- USD: Stable international benchmark for analysis during uncertainty.

Primary currency: EUR

Currency strategy:

- Transition budget/reporting to EUR immediately upon political decision, adhering to EU convergence criteria via ERM II.
- DKK used for existing transactions until Euro Day.
- Long-term planning and external reporting denominated in EUR to manage exchange rate risk during transition ('Builder's Blueprint').


# Identify Risks
## Risk 1 - Regulatory & Permitting
Failure to get unanimous EU agreement to amend TEU protocol and lift Danish opt-out via 'Formally request an Extraordinary European Council session' strategy.

- Impact: 12–24 month delay; forced onto uncertain legal pathway; political capital burnout.
- Likelihood: Medium
- Severity: High
- Action: Mitigation via Strategy 4: Focus diplomacy on securing bilateral assurances from key MS. Prepare parallel contingency legal arguments based on existing EU treaties.

## Risk 2 - Regulatory & Permitting
Danish rejection (Folketinget or referendum) of required constitutional change/referendum to lift opt-out.

- Impact: Project termination or return to permanent opt-out. Financial loss DKK 500M–1B (sunk costs).
- Likelihood: Medium
- Severity: High
- Action: Mitigation via Strategy 11: Implement continuous, high-quality communication campaigns immediately after 'political decision' emphasizing benefits. Ensure 'Public Referendum Design' is simple.

## Risk 3 - Financial/Economic
Failure to meet primary convergence criteria (e.g., deficit < 3% GDP) during ERM II window, delaying ECB approval.

- Impact: 6–18 month delay; forces painful, last-minute fiscal adjustments causing backlash/contraction.
- Likelihood: Medium
- Severity: High
- Action: Mitigation via Strategy 9: Adopt aggressive technical alignment; implement ECB statistical reporting immediately post-referendum for early compliance audits. Use Strategy 2 for ERM Entry buffer.

## Risk 4 - Technical/Operational
Integration failure or delay in Danmarks Nationalbank systems connecting with Eurosystem infrastructure (e.g., TARGET2).

- Impact: Inability to participate fully on Euro Day; risk of isolation/non-compliance. Requires 4–6 extra months remediation.
- Likelihood: Medium
- Severity: Medium
- Action: Mitigation via Strategy 8: Establish 'Shadow Integration Team' immediately, irrespective of 'Opt-Out Resolution' timeline, ensuring technical readiness precedes political certainty.

## Risk 5 - Supply Chain/Logistics
Inadequate supply, security failure, or bottlenecks in EUR/DKK cash distribution/destruction during dual circulation (30-60 days).

- Impact: Localized cash shortages; panic; increased counterfeiting risk; extended dual circulation costing DKK 100M overhead.
- Likelihood: High
- Severity: Medium
- Action: Mitigation via Strategy 10 & 6: Contract multiple cash-in-transit firms. Commit to aggressive 30-day dual circulation predicated on immediate massive media campaign for consumer acceptance.

## Risk 6 - Social/Change Management
Public confusion or rejection due to inconsistent pricing, especially SMEs/vulnerable populations, eroding trust.

- Impact: High consumer disputes; potential retroactive consumer protection enforcement; 1–3 month delay in DKK withdrawal.
- Likelihood: High
- Severity: Medium
- Action: Mitigation via Strategy 11: Implement rolling, sector-specific outreach via municipal centers *after* referendum. Communicate key operational rules (rounding) early via utilities/tax authorities.

## Risk 7 - Operational/Contractual
Widespread legal disputes regarding mandatory re-denomination of private, long-term contracts (loans, B2B agreements).

- Impact: Significant judicial burden; possible emergency legislation; delaying economic normalization by up to 2 years in sectors.
- Likelihood: Medium
- Severity: Medium
- Action: Mitigation via Strategy 7: Mandate automatic rounding for all existing long-term contracts without negotiation (Strategy 7.1). Publish robust legal clarity in advance per 'Builder's Blueprint'.

## Risk 8 - Financial/Market Risk
Speculative pressure/instability from announcement of DKK entry parity contradicting 'minimal pre-entry shock' (Strategy 2).

- Impact: National Bank defends peg using reserves or adopts less favorable official rate, negatively impacting long-term export competitiveness.
- Likelihood: Low
- Severity: High
- Action: Mitigation via Strategy 12: Focus negotiation with ECB on maintaining tight binding band during informal convergence, using historical alignment as leverage to minimize surprises during formal entry.

## Risk 9 - Governance/Resource Management
Decision-making paralysis or resource contention in 'Joint Ministerial Consultative Body' (Strategy 5.2), slowing directives.

- Impact: Cascading delays across workstreams (IT, contracts) due to political sign-off bottlenecks, potentially extending timeline beyond 8 years.
- Likelihood: High
- Severity: Medium
- Action: Mitigation via Strategy 5: Delegate clear thresholds to consultation chairs to issue binding directives on logistical/technical matters (e.g., DKK 50M budget) unless a minister raises explicit conflict within 7 days.

## Risk summary
Plan faces critical risks at political authorization/economic convergence intersection. Critical risks: Legal/Regulatory Opt-Out Removal (delay) and Failure to meet ECB Convergence Criteria (entry block). Third critical area: Governance Bottlenecks delaying operations despite political certainty. Mitigation requires aggressive, early diplomacy for treaty change parallel to immediate, high-quality technical preparation (Shadow Integration Teams) to bridge political decision and operational reality, accepting high upfront convergence alignment costs.

# Make Assumptions
## Question 1 - Minimum Allocation for Public Information Campaign (Strategy 11)

- Required minimum allocation: 0.5% of the total estimated national transition budget.
- Assumption: Total budget estimated at DKK 15–25 billion over 6 years. 0.5% of DKK 20 billion implies DKK 100 million allocation for Societal Readiness Pacing ($DR 11$).
- Detail: This expenditure is critical mitigation for Risk 2 (Referendum failure) and must release immediately post-political decision.

## Question 2 - Earliest Realistic Target Date for National Referendum (Decision 3)

- Mandate: Minimum 24-month ERM II participation period required by 'Builder's Blueprint'.
- Timeline: Formal ERM II entry Q3 2027 $\rightarrow$ Convergence confirmation Q3 2029 $\rightarrow$ Referendum scheduling lag $\rightarrow$ Earliest target Q1 2030.
- Detail: Mitigates Risk 3 (Convergence Failure). Risk: Stakeholder impatience (Strategy 5.2) during the 3-year preparatory phase.

## Question 3 - Sourcing Specialized Technical Workforce

- Assumption: Rely on 60% via short-term secondments (Danmarks Nationalbank, EU/ECB consultants) due to deferred long-term hiring. Remainder from 'Shadow Integration Team' (Strategy 8.1).
- Detail: Hybrid approach minimizes sunk cost if referendum fails.
- Opportunity: Early secondment accelerates internal skill transfer, improving convergence metrics during ERM II.
- Risk Managed: Risk 9 (Governance Paralysis) delegated to Nationalbank Chair for initial contracts.

## Question 4 - Higher Risk Regulatory Approval Mechanism

- Risk Assessment: Novel political declaration (Strategy 4.1) has higher procedural risk than Extraordinary European Council session (Strategy 4.2). Treaty amendment ratification (27-state) carries highest delay risk if domestic review is triggered simultaneously.
- Prioritized Mechanism: Strategy 4.2 (Extraordinary Council session) chosen for ECB certainty, accepting political risk of ratification.
- Mitigation: Secure agreement on the *process* first. Domestic constitutional review managed concurrently by Ministry of Justice.

## Question 5 - Contingency Capital for Dual Circulation Security (Risk 5)

- Required Ring-fenced Contingency: DKK 50 million.
- Purpose: Cover immediate, unbudgeted security enhancements for cash transport/storage if Risk 5 (Cash Supply Failure) materializes during the 30-day dual circulation period.
- Linkage: Fund distinct from IT budget ($DR 8$), linked to Cash Logistics lever ($DR 6$).
- Opportunity: Pre-qualify three regional security contracts for 72-hour activation.

## Question 6 - Addressing Future Environmental/Sustainability Scrutiny

- Commitment: Proactively adopt ECB's climate-related financial risk reporting and stress testing protocols immediately upon ERM II entry.
- Detail: Adopting standards acts as 'best practice' ahead of Euro Day.
- Benefit: Minimizes future friction with European Commission/Parliament, mitigating Risk 1 (Opt-out repeal negotiation friction).

## Question 7 - Mechanism for Stakeholder Communication and Support Fragmentation

- Mechanism: Quarterly 'Economic Alignment Stakeholder Forum' ($EASF$), chaired by Ministry of Business.
- Function: Mandatory updates on convergence progress ($DR 9$); early warnings on ERM II changes ($DR 12$).
- Target: Maintain 80% stakeholder satisfaction.
- Detail: $EASF$ manages risk of stakeholder fatigue during long ERM II period by grounding support in verifiable progress.

## Question 8 - Protocol for Simulating Integrity of DKK IT Payment Systems

- Mandated Protocol: Internal 'Euro Simulation Exercises' ($ESE$).
- Scope: Simulate historical DKK transaction data against projected 1:7.46 DKK/EUR rate across all critical payment systems for minimum six continuous months prior to ERM II entry.
- Detail: $ESE$ results shared with Joint Ministerial Consultative Body ($DR 5$).
- Risk Managed: Directly mitigates Risk 4 (Technical Integration Failure) before external linkage.


# Distill Assumptions
# Project Planning Summary

## Funding and Budget

- Public info funding: 0.5% of total national transition budget.
- Contingency fund: DKK 50 million ring-fenced for immediate security enhancements.

## Timeline and Milestones

- Earliest realistic referendum target: Q1 2030 (post 24-month ERM II).
- Project spans 4 to 8 years from decision to full euro use.

## Legal and Governance

- Prioritized legal mechanism: Formally requesting an Extraordinary European Council session.
- Adoption requires lifting the current EU opt-out via treaty change and subsequent national referendum.
- Opt-out repeal deferred until after minimum 24 months of successful ERM II participation.
- Referendum structure will be binary, conditional on affirming prior fulfillment of ECB convergence checklist.
- Governance structure: Joint Ministerial Consultative Body requiring ministerial consensus.

## Convergence Strategy

- Plan must be compatible with EU/ECB convergence criteria, including ERM II participation.
- Existing strict DKK exchange rate policy maintained during pre-ERM II convergence.
- Convergence triage prioritizes mandatory criteria; defers non-binding ECB best practices initially.
- Denmark commits to adopting ECB climate risk reporting standards proactively upon ERM II entry.

## Operational Readiness

- Technical staffing relies on 60% secondments from Nationalbank and specialized EU/ECB contracts.
- National Bank mandates six months of internal Euro Simulation Exercises based on projected conversion rates.
- Local government operational switch requires centralized mandates for IT upgrades with financial incentives.
- Dual circulation period assumed: 30 days for cash logistics (contingency planning required).
- Commercial contracts mandate automatic rounding to nearest cent upon Euro Day (no prior renegotiation).
- Danmarks Nationalbank integration phases timeline constrained by ERM II entry requirements.

## Communication and Scope

- Quarterly Economic Alignment Stakeholder Forum manages external communication and timelines.
- Project excludes assumption of 'Nordic euro' or separate currency union structure.


# Review Assumptions
## Domain of the expert reviewer
Strategic Project Planning & Governmental Transition Management

## Domain-specific considerations

- Sequencing political consent vs. economic convergence.
- Management of EU/ECB institutional and external dependencies.
- Public behavior change and democratic mandate security.
- Sunk cost management from long pre-adoption (ERM II).

## Issue 1 - Underestimated Timeline Risk Associated with Deferring Opt-Out Repeal
The 'Builder's Blueprint' assumes earliest referendum Q1 2030, based on minimum 24-month ERM II starting Q3 2027 (8-year timeline, strains 4-8 year window). Deferring Opt-Out repeal negotiation until after ERM II completion creates a missed assumption: the EU may require political alignment concurrently or beforehand, increasing political risk with the EU Council/Parliament.

Recommendation: Initiate parallel, high-level diplomatic tracks immediately. Begin 'conditional negotiation' track for Opt-Out Repeal Protocol tied to meeting the 12-month ERM II stability mark, not the end. Amend governance to empower the Consultative Body (Decision 5) for diplomatic risk transfer.

Sensitivity: If EU demands Opt-Out resolution precede ERM II confirmation, timeline delays by 12–18 months (adoption Q1 2031/2032). ROI drops 8-12% due to 1.5 years less utilization.

## Issue 2 - Critical Missing Assumption: Funding Stability During Prolonged ERM II Period
Project assumes stable funding (DKK 15–25 billion over 6 years) and secondments for staffing (Assumption 3). *No assumption* states funding is indexed against sustained high inflation or elevated interest rates over 6-8 years. High inflation erodes committed budget (DKK 100M comms, DKK 50M contingency).

Recommendation: Introduce mandatory annual budget real-indexation reviews tied to neutral CPI. Contingency fund (Assumption 5) must be a ring-fenced escrow account, minimum DKK 50M + 5% annual inflation adjustment.

Sensitivity: If average annual inflation exceeds baseline by 2 pp (3.5% vs 1.5%), real budget value reduces by approx. DKK 2.2 Billion. This forces scaling delays or requires capital call, increasing cost of capital by 0.5-1.0% per year on bridging loans.

## Issue 3 - Under-Explored Assumption: Legal Finality of Contract Re-denomination Post-Referendum Failure
Assumption 7 mandates automatic rounding post-Euro Day. Deferring vote until end of ERM II (Q1 2030) omits the legal status of pre-mandate rounding rules if the referendum *fails*. Uncertainty affects SMEs and IT readiness (Risk 7).

Recommendation: Task Justice Ministry (via Decision 5) to draft Dual-Path Legal Contingency Mandate. Mandate must stipulate preparatory re-denomination legislation (Decision 7) is automatically repealed *without penalty* if referendum fails. Cost of dual documentation factored into DKK 50M contingency ($Risk 5$).

Sensitivity: If post-failure legal challenge invalidates provisional contract legislation, litigation/compensation costs could be DKK 500 Million to DKK 1.5 Billion, impacting future ROI by 3-6% from write-offs.

## Review conclusion
'Builder's Blueprint' introduces significant timeline risks by sequencing political opt-out repeal strictly after operational convergence. Critical issues are: unrealistic EU approval sequencing, failure to hedge budget erosion (inflation), and unspecified legal consequences post-referendum failure. Address by immediate parallel diplomatic engagement, inflation-indexed budgets, and definitive dual-path legal mandates.