This plan involves money.

## Currencies

- **DKK:** Local currency of Denmark; included for domestic transactions during dual circulation period.
- **EUR:** Target currency for adoption; required for EU integration and as primary currency for budgeting.
- **USD:** Stable international currency included due to currency instability risks; used for international reporting and as a reference to mitigate hyperinflation and exchange-rate uncertainty.

**Primary currency:** EUR

**Currency strategy:** For local transactions, use DKK during the dual-circulation period and transition to EUR for all official budgeting and reporting. For international and stability-sensitive planning, use USD as a stable reference. Manage currency risk by aligning with ECB monetary policy, using forward contracts where necessary, and communicating clearly with stakeholders to minimize exchange-rate volatility impacts.