This plan involves money.

## Currencies

- **DKK:** The current national currency being replaced; needed for local transactions prior to Euro Day.
- **EUR:** The target currency for all future transactions, budgeting, and reporting.
- **USD:** A stable international benchmark currency often used for comparative economic analysis or during the period of high domestic uncertainty leading up to the vote.

**Primary currency:** EUR

**Currency strategy:** The primary strategy is to transition the budget and reporting currency to EUR immediately upon the political decision to proceed, following established EU convergence criteria via ERM II. While the DKK will be used for existing transactions until Euro Day, all long-term planning and external financial reporting will be denominated in EUR to manage exchange rate risk during the multi-year transition implied by the chosen 'Builder's Blueprint'.