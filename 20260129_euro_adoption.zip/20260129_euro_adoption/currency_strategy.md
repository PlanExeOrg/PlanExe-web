This plan involves money.

## Currencies

- **DKK:** Current currency of Denmark, needed for local transactions during the transition period.
- **EUR:** Target currency for Denmark, needed for budgeting and planning the transition.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting and reporting. DKK will be used for local transactions during the transition period. Exchange rate risks should be monitored and managed during the transition.