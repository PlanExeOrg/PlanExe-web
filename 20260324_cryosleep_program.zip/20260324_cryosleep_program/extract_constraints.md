## Positive Constraints

- 15-year timeline
- ¥18 billion budget
- Headquarters at Kunming Institute of Zoology, Chinese Academy of Sciences
- Develop reversible suspended metabolism foundations for mammals
- Long-term goal of human cryosleep for deep-space missions
- Track A: pharmacologically induced metabolic suppression at 10–15°C
- Track B: vitrification-based preservation below −80°C
- Track C: implantable bioelectronic life-support systems
- Tier 1: work with small hibernating mammals and rats
- Tier 1 Track A: 12-month torpor with 85% performance retention
- Tier 1 Track B: organ revival within 70% of baseline
- Tier 4: proceed to non-human primates only if revival rates exceed 85%
- Mandatory publication of primary endpoints within 18 months
- Full dataset publication within 36 months
- Independent scientific advisory board with at least three international members
- Model tier-gate failures and budget reallocation on partial success
- Define minimum viable scientific outcome if full revival is impossible
- Project start ASAP

## Negative Constraints

- Do not use blockchain
- Do not use VR
- Do not use AR
- Do not use metaverse
- Do not use immortality
