**Purpose:** business

**Purpose Detailed:** Large-scale governmental and societal initiative focused on developing medical devices and space technology with commercialization potential

**Topic:** National research program on reversible suspended metabolism