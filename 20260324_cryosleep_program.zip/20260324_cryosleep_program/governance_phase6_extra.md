## Governance Validation Checks

1. Core components (Audit, Bodies, Plan, Escalation, Monitoring) are present and cover required governance domains.
2. Budget authority thresholds (¥500M) align consistently across PSC responsibilities, PMO limits, and Escalation Matrix.
3. IAEC oversight authority on welfare aligns with Monitoring indicators and Escalation pathways.
4. Gap: Senior Sponsor role lacks formal authority boundaries relative to the PSC Chair in the implementation steps.
5. Gap: Conflict of Interest management lacks specific recusal or voting restriction protocols following disclosure.
6. Gap: Program termination logic for early catastrophic failure (before Tier 3) is not explicitly defined beyond budget reallocation.

## Tough Questions

1. What specific evidence supports the 85% revival rate threshold for Tier 4 progression given current small-mammal data variability?
2. Show the documented recusal protocol if a Steering Committee member has financial ties to an implant vendor under review.
3. If Tier 3 gates fail twice consecutively, what is the exact timeline and governance vote required to terminate the program versus pivot to commercial devices?
4. Detail the cybersecurity incident response chain for LIMS data integrity breaches, including notification timelines for CAS and CMSA.
5. How is the ¥3.6 billion contingency reserve accessed if state funding drops 20% in Year 5 without prior PSC approval?
6. Define the threshold for 'cognitive function drop below 85%'—is this mean, median, or worst-case individual animal data?
7. What is the mechanism to resolve NMPA guideline shifts that contradict Tier 3 experimental designs already approved by the IAEC?

## Summary

The framework establishes a robust tiered governance model with clear budget authorities and independent ethical oversight. Key strengths include aligned escalation paths and contingency planning for partial success. However, operational details regarding conflict management, data security response, and formal termination criteria require further definition to ensure resilience against financial and regulatory volatility.