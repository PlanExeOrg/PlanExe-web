This plan involves money.

## Currencies

- **CNY:** The project is headquartered in China with all funding and operational expenses denominated in Chinese Yuan.

**Primary currency:** CNY

**Currency strategy:** Local currency will be used for all transactions with no additional international risk management needed.