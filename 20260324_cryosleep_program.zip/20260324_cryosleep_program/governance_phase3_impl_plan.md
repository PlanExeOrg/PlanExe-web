### 1. Senior Sponsor (CAS Leadership) drafts initial Program Steering Committee Terms of Reference and Conflict of Interest policy.

**Responsible Body/Role:** Senior Sponsor (CAS Leadership)

**Suggested Timeframe:** Week 1

**Key Outputs/Deliverables:**

- Draft Program Steering Committee ToR v0.1
- Conflict of Interest Policy Draft

**Dependencies:**

- Project Charter Approved

### 2. Senior Sponsor formally appoints Program Steering Committee members and designates Chair.

**Responsible Body/Role:** Senior Sponsor (CAS Leadership)

**Suggested Timeframe:** Week 2

**Key Outputs/Deliverables:**

- Formal Appointment Letters for PSC Members
- Confirmed Membership List

**Dependencies:**

- Draft Program Steering Committee ToR v0.1

### 3. Program Steering Committee convenes inaugural meeting to approve ToR and establish decision mechanisms.

**Responsible Body/Role:** Program Steering Committee

**Suggested Timeframe:** Week 3

**Key Outputs/Deliverables:**

- Approved Program Steering Committee ToR
- Inaugural Meeting Minutes

**Dependencies:**

- Formal Appointment Letters for PSC Members

### 4. Program Steering Committee approves Program Management Office Mandate and defines initial operational budget thresholds.

**Responsible Body/Role:** Program Steering Committee

**Suggested Timeframe:** Month 2

**Key Outputs/Deliverables:**

- Approved PMO Mandate Document
- Financial Authority Matrix

**Dependencies:**

- Approved Program Steering Committee ToR

### 5. Program Steering Committee appoints Program Director and PMO technical track leads.

**Responsible Body/Role:** Program Steering Committee

**Suggested Timeframe:** Month 2

**Key Outputs/Deliverables:**

- Signed Program Director Contract
- PMO Membership Roster

**Dependencies:**

- Approved PMO Mandate Document

### 6. PMO holds inaugural meeting to deploy data integration platform and set initial KPIs.

**Responsible Body/Role:** Program Management Office

**Suggested Timeframe:** Month 2

**Key Outputs/Deliverables:**

- Kunming LIMS Configuration
- Operational KPI Register

**Dependencies:**

- PMO Membership Roster

### 7. Program Steering Committee defines IAEC Charter to ensure external independence and technical validation authority.

**Responsible Body/Role:** Program Steering Committee

**Suggested Timeframe:** Month 2

**Key Outputs/Deliverables:**

- IAEC Charter Draft
- Audit Scope Document

**Dependencies:**

- Approved Program Steering Committee ToR

### 8. Program Steering Committee appoints External Bioethicist Chair and IAEC members.

**Responsible Body/Role:** Program Steering Committee

**Suggested Timeframe:** Month 3

**Key Outputs/Deliverables:**

- IAEC Appointment Letters
- Ethics Conflict of Interest Forms

**Dependencies:**

- IAEC Charter Draft

### 9. IAEC holds inaugural meeting to approve animal welfare escalation protocols and audit schedule.

**Responsible Body/Role:** Independent Assurance and Ethics Committee

**Suggested Timeframe:** Month 3

**Key Outputs/Deliverables:**

- Approved Animal Welfare Protocols
- First Year Audit Plan

**Dependencies:**

- IAEC Appointment Letters

### 10. PMO distributes Unified Governance Rhythm to all consortium partners and research tracks.

**Responsible Body/Role:** Program Management Office

**Suggested Timeframe:** Month 3

**Key Outputs/Deliverables:**

- Consolidated Governance Calendar
- Escalation Communication Protocol

**Dependencies:**

- Operational KPI Register
- First Year Audit Plan