
## Audit - Corruption Risks

- Bribery or kickbacks in the selection of suppliers for cryoprotectant precursors and implant components
- Nepotism in the recruitment of the 500 FTE workforce across CAS and partner universities
- Conflicts of interest where researchers license patents to private firms without disclosing financial ties
- Regulatory capture attempts to influence NMPA or CMSA validation criteria for implantable devices
- Fraudulent bidding or inflated costs during the construction of the Kunming research campus

## Audit - Misallocation Risks

- Overspending on early Tier 1 or 2 research phases leaving insufficient funds for Tier 4 primate studies
- Double-counting personnel effort across consortium partners when reporting FTE progress
- Unauthorized personal use of shared laboratory equipment like negative pressure rooms or LIMS resources
- Hoarding or wasting stockpiled chemical materials intended for 12 months of operations
- Diversion of technology transfer licensing revenue into unapproved accounts rather than program budget

## Audit - Procedures

- Independent financial sign-off required before releasing funds from one Tier gate to the next
- Quarterly spot checks on vendor contracts for critical materials to verify pricing fairness
- Third-party audits of Tier 4 primate trial data against predefined welfare and cognitive recovery thresholds
- Annual reconciliation of implant IP licensing royalties against central program accounts
- Quarterly integrity checks on centralized Laboratory Information Management System logs to prevent data tampering

## Audit - Transparency Measures

- Public dashboard displaying real-time budget burn rates and Tier 1 through 4 milestone progress
- Mandatory publication registry for negative results and failed revival data within 18 months of collection
- Publicly accessible conflict of interest declarations for researchers involved in IP commercialization decisions
- Monthly summarized minutes from CMSA advisory review sessions distributed to all consortium partners
- Secure anonymous whistleblower channel available to staff at all partner institutions for reporting misconduct