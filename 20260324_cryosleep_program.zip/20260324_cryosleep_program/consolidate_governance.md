# Governance Audit


## Audit - Corruption Risks

- Bribery or kickbacks in the selection of suppliers for cryoprotectant precursors and implant components
- Nepotism in the recruitment of the 500 FTE workforce across CAS and partner universities
- Conflicts of interest where researchers license patents to private firms without disclosing financial ties
- Regulatory capture attempts to influence NMPA or CMSA validation criteria for implantable devices
- Fraudulent bidding or inflated costs during the construction of the Kunming research campus

## Audit - Misallocation Risks

- Overspending on early Tier 1 or 2 research phases leaving insufficient funds for Tier 4 primate studies
- Double-counting personnel effort across consortium partners when reporting FTE progress
- Unauthorized personal use of shared laboratory equipment like negative pressure rooms or LIMS resources
- Hoarding or wasting stockpiled chemical materials intended for 12 months of operations
- Diversion of technology transfer licensing revenue into unapproved accounts rather than program budget

## Audit - Procedures

- Independent financial sign-off required before releasing funds from one Tier gate to the next
- Quarterly spot checks on vendor contracts for critical materials to verify pricing fairness
- Third-party audits of Tier 4 primate trial data against predefined welfare and cognitive recovery thresholds
- Annual reconciliation of implant IP licensing royalties against central program accounts
- Quarterly integrity checks on centralized Laboratory Information Management System logs to prevent data tampering

## Audit - Transparency Measures

- Public dashboard displaying real-time budget burn rates and Tier 1 through 4 milestone progress
- Mandatory publication registry for negative results and failed revival data within 18 months of collection
- Publicly accessible conflict of interest declarations for researchers involved in IP commercialization decisions
- Monthly summarized minutes from CMSA advisory review sessions distributed to all consortium partners
- Secure anonymous whistleblower channel available to staff at all partner institutions for reporting misconduct

# Internal Governance Bodies

### 1. Program Steering Committee

**Rationale for Inclusion:** Essential for providing high-level strategic direction and financial oversight across the ¥18 billion budget, ensuring alignment between CAS, CMSA, and national objectives.

**Responsibilities:**

- Approve strategic budget allocations exceeding ¥500 million
- Confirm tier transition gates (Tier 3 to Tier 4)
- Validate strategic risk mitigation plans
- Review annual program milestones and contingency triggers

**Initial Setup Actions:**

- Appoint an independent chairperson from external scientific advisory board
- Define formal Terms of Reference and conflict of interest policies
- Establish financial thresholds for decision approval

**Membership:**

- Director of Kunming Institute of Zoology (Chair)
- CMSA Space Systems Engineering Representative
- Independent External Scientific Advisor
- Chief Finance Officer

**Decision Rights:** Strategic direction, final budget approval above ¥500 million, Tier 4 progression authorization.

**Decision Mechanism:** Two-thirds majority vote; Chair holds casting vote in case of deadlock.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Financial performance vs. budget plan
- Tier gate review and authorization
- Strategic risk register update
- Personnel escalation and key appointments

**Escalation Path:** No further internal escalation; major disputes resolved by CAS Board or CMSA oversight.
### 2. Program Management Office

**Rationale for Inclusion:** Required for day-to-day execution coordination across multi-institutional tracks, ensuring data consistency and operational efficiency.

**Responsibilities:**

- Monitor daily operational execution against timelines
- Manage budget allocations below ¥500 million
- Coordinate data integration between consortium partners
- Track operational risks and implement mitigation

**Initial Setup Actions:**

- Deploy unified data integration platform at Kunming HQ
- Recruit technical leads for Tracks A, B, and C
- Set operational KPIs and reporting protocols

**Membership:**

- Program Director
- Track Leads (Torpor, Cryopreservation, Implant Systems)
- Operations Manager
- Data Governance Lead

**Decision Rights:** Operational scheduling, budget execution below ¥500 million, protocol adjustments within approved scope.

**Decision Mechanism:** Consensus among Track Leads; Program Director decides in tie-break scenarios.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Progress update by research track
- Resource allocation rebalancing
- Operational risk review
- Data integrity verification checks

**Escalation Path:** Escalate to Program Steering Committee for issues exceeding operational thresholds or requiring strategic pivot.
### 3. Independent Assurance and Ethics Committee

**Rationale for Inclusion:** Mandated to ensure ethical compliance, technical validation, and anti-corruption oversight, maintaining public trust and regulatory alignment.

**Responsibilities:**

- Review animal welfare welfare and cognitive function stop-gates
- Audit financial integrity and procurement processes
- Validate technical milestone achievements against predefined endpoints
- Ensure compliance with NMPA and data privacy regulations

**Initial Setup Actions:**

- Hire external independent auditors for financial checks
- Establish animal welfare escalation protocols
- Draft compliance policy for IP and data release

**Membership:**

- External Bioethicist (Chair)
- Independent Financial Auditor
- Lead Animal Welfare Officer
- External NMPA Regulatory Consultant

**Decision Rights:** Veto authority on ethical violations, technical gate verification, compliance audit findings.

**Decision Mechanism:** Unanimous vote required for ethical vetoes; majority for technical validation.

**Meeting Cadence:** Quarterly (or per milestone)

**Typical Agenda Items:**

- Welfare incident review and investigation
- Financial audit report presentation
- Technical validation against predefined metrics
- Compliance status for NMPA and CAS

**Escalation Path:** Escalate ethical or compliance breaches directly to Program Steering Committee or external regulatory bodies.

# Governance Implementation Plan

### 1. Senior Sponsor (CAS Leadership) drafts initial Program Steering Committee Terms of Reference and Conflict of Interest policy.

**Responsible Body/Role:** Senior Sponsor (CAS Leadership)

**Suggested Timeframe:** Week 1

**Key Outputs/Deliverables:**

- Draft Program Steering Committee ToR v0.1
- Conflict of Interest Policy Draft

**Dependencies:**

- Project Charter Approved

### 2. Senior Sponsor formally appoints Program Steering Committee members and designates Chair.

**Responsible Body/Role:** Senior Sponsor (CAS Leadership)

**Suggested Timeframe:** Week 2

**Key Outputs/Deliverables:**

- Formal Appointment Letters for PSC Members
- Confirmed Membership List

**Dependencies:**

- Draft Program Steering Committee ToR v0.1

### 3. Program Steering Committee convenes inaugural meeting to approve ToR and establish decision mechanisms.

**Responsible Body/Role:** Program Steering Committee

**Suggested Timeframe:** Week 3

**Key Outputs/Deliverables:**

- Approved Program Steering Committee ToR
- Inaugural Meeting Minutes

**Dependencies:**

- Formal Appointment Letters for PSC Members

### 4. Program Steering Committee approves Program Management Office Mandate and defines initial operational budget thresholds.

**Responsible Body/Role:** Program Steering Committee

**Suggested Timeframe:** Month 2

**Key Outputs/Deliverables:**

- Approved PMO Mandate Document
- Financial Authority Matrix

**Dependencies:**

- Approved Program Steering Committee ToR

### 5. Program Steering Committee appoints Program Director and PMO technical track leads.

**Responsible Body/Role:** Program Steering Committee

**Suggested Timeframe:** Month 2

**Key Outputs/Deliverables:**

- Signed Program Director Contract
- PMO Membership Roster

**Dependencies:**

- Approved PMO Mandate Document

### 6. PMO holds inaugural meeting to deploy data integration platform and set initial KPIs.

**Responsible Body/Role:** Program Management Office

**Suggested Timeframe:** Month 2

**Key Outputs/Deliverables:**

- Kunming LIMS Configuration
- Operational KPI Register

**Dependencies:**

- PMO Membership Roster

### 7. Program Steering Committee defines IAEC Charter to ensure external independence and technical validation authority.

**Responsible Body/Role:** Program Steering Committee

**Suggested Timeframe:** Month 2

**Key Outputs/Deliverables:**

- IAEC Charter Draft
- Audit Scope Document

**Dependencies:**

- Approved Program Steering Committee ToR

### 8. Program Steering Committee appoints External Bioethicist Chair and IAEC members.

**Responsible Body/Role:** Program Steering Committee

**Suggested Timeframe:** Month 3

**Key Outputs/Deliverables:**

- IAEC Appointment Letters
- Ethics Conflict of Interest Forms

**Dependencies:**

- IAEC Charter Draft

### 9. IAEC holds inaugural meeting to approve animal welfare escalation protocols and audit schedule.

**Responsible Body/Role:** Independent Assurance and Ethics Committee

**Suggested Timeframe:** Month 3

**Key Outputs/Deliverables:**

- Approved Animal Welfare Protocols
- First Year Audit Plan

**Dependencies:**

- IAEC Appointment Letters

### 10. PMO distributes Unified Governance Rhythm to all consortium partners and research tracks.

**Responsible Body/Role:** Program Management Office

**Suggested Timeframe:** Month 3

**Key Outputs/Deliverables:**

- Consolidated Governance Calendar
- Escalation Communication Protocol

**Dependencies:**

- Operational KPI Register
- First Year Audit Plan

# Decision Escalation Matrix

**Budget Reallocation Exceeding ¥500 Million Threshold**
Escalation Level: Program Steering Committee
Approval Process: Two-thirds majority vote by Committee members
Rationale: Financial requests surpass Program Management Office operational authority limits.
Negative Consequences: Unauthorized spending leading to budget deficit or lack of funds for later tiers.

**Ambiguous Tier 3 Gate Results Requiring Progression Decision**
Escalation Level: Program Steering Committee
Approval Process: Strategic risk review followed by binding vote on Tier 4 initiation
Rationale: Scientific data near thresholds requires executive judgment on risk versus reward.
Negative Consequences: Premature continuation causing resource waste or premature termination of viable research.

**Major Animal Welfare Violation Detected During Primate Trials**
Escalation Level: Program Steering Committee
Approval Process: Independent Assurance and Ethics Committee recommendation reviewed for Program-wide halt authorization
Rationale: Ethical compliance issues override operational timelines and necessitate program-wide policy shifts.
Negative Consequences: Regulatory sanctions, loss of social license, or criminal liability for personnel.

**Intellectual Property Dispute Among Consortium Partners**
Escalation Level: Program Steering Committee
Approval Process: Binding arbitration by Committee chair with input from legal advisors
Rationale: Conflict between academic and state ownership models requires high-level resolution.
Negative Consequences: Stalled technology transfer, litigation, or fractured research consortium.

**Unexpected National Regulatory Standards Shift Affecting Protocols**
Escalation Level: Program Steering Committee
Approval Process: Strategic pivot approval involving revised budget and timeline allocation
Rationale: Compliance requirements exceed operational adjustment capacity and demand strategic resource realignment.
Negative Consequences: Non-compliance fines, regulatory stoppages, or delayed commercial launch.

# Monitoring Progress

### 1. Scientific Milestone Tracking Against Tiered Gates
**Monitoring Tools/Platforms:**

  - Kunming Laboratory Information Management System (LIMS)
  - Tiered Milestone Dashboard
  - Pre-Registered Statistical Analysis Scripts

**Frequency:** Monthly

**Responsible Role:** Program Management Office

**Adaptation Process:** PMO proposes budget rebalancing or protocol adjustments to Program Steering Committee if data indicates divergence from predefined scientific endpoints.

**Adaptation Trigger:** Revival rates deviate from Tier 3 targets (85%) or cognitive function falls below 90% baseline at scheduled checkpoints.

### 2. Budget Sustainability and Commercialization Pipeline Monitoring
**Monitoring Tools/Platforms:**

  - Enterprise Resource Planning (ERP) Dashboard
  - Technology Transfer Licensing CRM
  - Contingency Reserve Tracker

**Frequency:** Monthly

**Responsible Role:** Chief Finance Officer

**Adaptation Process:** CFO presents reallocation proposal to Program Steering Committee to utilize Tier 4 reserve or accelerate IP licensing if commercialization targets are not met.

**Adaptation Trigger:** Projected licensing revenue falls below 20% of Tier 4 reserve threshold or state funding allocation shifts exceed 5%.

### 3. Animal Welfare and Ethical Compliance Audits
**Monitoring Tools/Platforms:**

  - Independent Assurance and Ethics Committee (IAEC) Audit Reports
  - Animal Welfare Incident Log
  - Cognitive Function Testing Protocols

**Frequency:** Quarterly

**Responsible Role:** Independent Assurance and Ethics Committee

**Adaptation Process:** IAEC issues formal halt or modification recommendation to Program Steering Committee following confirmed welfare violation or cognitive threshold breach.

**Adaptation Trigger:** Post-revival cognitive function drops below 85% of controls or specific welfare incident protocols are triggered.

### 4. Consortium Data Integrity and Coordination Verification
**Monitoring Tools/Platforms:**

  - Unified Data Integration Platform
  - Cross-Institutional Data Sync Logs
  - Standard Operating Procedure Repository

**Frequency:** Bi-weekly

**Responsible Role:** Data Governance Lead

**Adaptation Process:** PMO coordinates protocol standardization updates with partner universities to address identified data inconsistencies or synchronization delays.

**Adaptation Trigger:** Data inconsistency errors exceed 1% or cross-site synchronization delays impact Tier 3 convergence readiness.

### 5. Critical Supply Chain Resilience Check
**Monitoring Tools/Platforms:**

  - Supplier Relationship Management Portal
  - Critical Material Inventory Logs
  - Geopolitical Risk Feed

**Frequency:** Monthly

**Responsible Role:** Operations Manager

**Adaptation Process:** Operations Manager executes dual-sourcing activation or stockpile top-up plan approved by Program Steering Committee when thresholds are breached.

**Adaptation Trigger:** Lead time variance exceeds 30% or critical chemical inventory drops below 6 months of operational reserve.

# Governance Extra

## Governance Validation Checks

1. Core components (Audit, Bodies, Plan, Escalation, Monitoring) are present and cover required governance domains.
2. Budget authority thresholds (¥500M) align consistently across PSC responsibilities, PMO limits, and Escalation Matrix.
3. IAEC oversight authority on welfare aligns with Monitoring indicators and Escalation pathways.
4. Gap: Senior Sponsor role lacks formal authority boundaries relative to the PSC Chair in the implementation steps.
5. Gap: Conflict of Interest management lacks specific recusal or voting restriction protocols following disclosure.
6. Gap: Program termination logic for early catastrophic failure (before Tier 3) is not explicitly defined beyond budget reallocation.

## Tough Questions

1. What specific evidence supports the 85% revival rate threshold for Tier 4 progression given current small-mammal data variability?
2. Show the documented recusal protocol if a Steering Committee member has financial ties to an implant vendor under review.
3. If Tier 3 gates fail twice consecutively, what is the exact timeline and governance vote required to terminate the program versus pivot to commercial devices?
4. Detail the cybersecurity incident response chain for LIMS data integrity breaches, including notification timelines for CAS and CMSA.
5. How is the ¥3.6 billion contingency reserve accessed if state funding drops 20% in Year 5 without prior PSC approval?
6. Define the threshold for 'cognitive function drop below 85%'—is this mean, median, or worst-case individual animal data?
7. What is the mechanism to resolve NMPA guideline shifts that contradict Tier 3 experimental designs already approved by the IAEC?

## Summary

The framework establishes a robust tiered governance model with clear budget authorities and independent ethical oversight. Key strengths include aligned escalation paths and contingency planning for partial success. However, operational details regarding conflict management, data security response, and formal termination criteria require further definition to ensure resilience against financial and regulatory volatility.