Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 12 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 5 | Material risk with plausible path. |
| ✅ Low | 3 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is a research study focused on biomedical engineering and cryobiology, leveraging known biological hibernation and physical vitrification processes. It does not require breaking any laws of physics because it relies on established thermodynamic and physiological mechanisms rather than impossible energy creation or non-physical causation.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on whole-body reversible suspension for medical and space applications without independent evidence at comparable scale, noting 'Whole-body vitrification and revival without damage is unproven in small mammals' and 'Extremely high novelty and risk.'

**Mitigation**: Program Director: Establish parallel validation tracks for technical feasibility, regulatory clearance, and ethics within 90 days, defining NO-GO gates for Tier 3 revival rates below 60% or regulatory rejection.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because "Dual-Use Technology Transfer Path" exists without business-level mechanism-of-action one-pagers defining value hypotheses, success metrics, and assigned owners per strategic concept.

**Mitigation**: Strategy Team: Produce one-pagers with value hypotheses, success metrics, and decision hooks for each framework within 60 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because plan lists risks like "Heavy reliance on state funding creating exposure to budget shifts" but omits explicit second-order cascade maps linking delays to shortfalls or cash crunches.

**Mitigation**: Risk Register Team: Expand risk register to map explicit second-order cascades and define controls for each identified pathway within 30 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because permit/approval matrix comparing lead times to schedule is absent. Expert-review notes 'First-in-Human Trial Approval Timeline Missing' and pathways 'could delay Tier 4 trials by 12–18 months'.

**Mitigation**: Regulatory Affairs Manager: Build permit/approval matrix with standard lead times and NO-GO thresholds within 45 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because funding sources CAS and CMSA are cited as "Funded by ¥18 billion" without term sheets, draw schedules, or defined financing covenants for the 15-year runway.

**Mitigation**: Finance Team: Draft a dated financing plan detailing CAS/CMSA status, draw schedule, covenants, and NO-GO gates within 30 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because plan states "¥18 billion program" but omits vendor quotes or normalized cost per area benchmarks required to validate budget against market rates.

**Mitigation**: Infrastructure Manager: Benchmark three construction vendors and normalize cost per square meter against campus footprint to adjust budget within 60 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because core objectives list single targets like "Generate ¥100 million in licensing revenue... by 2030-09-01" without ranges or alternative scenarios for critical projections.

**Mitigation**: Finance Team: Model revenue sensitivity and best/worst-case timelines within 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because expert review states "CMSA Spaceflight Redundancy Standards Not Integrated" and "NMPA Class III Device Classification Pathway Undefined" for critical implant components.

**Mitigation**: Engineering Lead: Draft interface contracts, acceptance tests, and CMSA redundancy specs for Track C implants within 60 days to address expert review gaps.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because plan notes "undefined NMPA classification pathways and missing CMSA redundancy standards could halt deployment" and relies on unverified assumptions like "CMSA Will Adopt Program Protocols" without artifacts.

**Mitigation**: Regulatory Affairs Manager: Secure written NMPA classification intent and CMSA redundancy commitments within 90 days to validate critical operational claims before Tier 2 initiation.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan cites "medical devices, and implantable bioelectronic systems" without defining specific NMPA classification pathways or CMSA redundancy standards required for commercialization.

**Mitigation**: Regulatory Affairs Manager: Define SMART acceptance criteria for implant deliverables including specific NMPA Class III codes and CMSA redundancy metrics within 60 days to validate commercial readiness.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan ties features like LIMS deployment and dual-sourcing to explicit objectives: "data consistency across partner institutions" and preventing "supply chain disruptions."

**Mitigation**: Strategy Team: Review the LIMS and dual-sourcing cost breakdown against budget goals within 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because Plan requires "50 senior international cryobiologists" by 2028, noting "private sector poaching risk destabilizing Track C" with no concrete retention or market validation plan.

**Mitigation**: HR Director: Conduct market availability and compensation benchmarking for senior cryobiologists within 45 days to validate feasibility before scaling recruitment.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because expert review states 'NMPA Class III Device Classification Pathway Undefined' and missing CMSA redundancy standards could halt deployment, leaving required approvals unmapped.

**Mitigation**: Regulatory Affairs Manager: Build regulatory matrix mapping NMPA classification codes and CMSA redundancy standards with lead times within 60 days to validate pathways before Tier 2 initiation.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because project-plan states "Heavy reliance on state funding creating exposure to budget shifts" and expert-review notes a "potential ¥3.6 billion annual gap" if licensing revenue fails.

**Mitigation**: Finance Team: Draft a sustainable operational budget validating dual-use licensing revenue against state cuts within 90 days to confirm long-term viability.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan lists "Obtain environmental permits and construction approvals" as tasks but does not confirm zoning, fire load, or structural limits are satisfied.

**Mitigation**: Infrastructure Manager: Complete zoning and building permit audits with local authorities within 60 days to confirm structural and fire load compliance before campus construction begins.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because plan states "Adopt dual-sourcing strategies for critical materials" yet Decision 13 notes "Centralizing equipment... creates single points of failure." No tested facility failovers.

**Mitigation**: Infrastructure Team: Finalize supplier SLAs and validate backup power failover within 60 days to secure continuity against supply or facility disruptions.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because CAS and Commercialization Lead conflict. "Conflicts with Budget Allocation Strategy as revenue from civilian licensing might reduce reliance on state funding." Goals clash on resource allocation.

**Mitigation**: Program Director: Draft a shared OKR linking Tier 3 survival gates to commercial revenue targets within 45 days to align CAS funding stability with medical device dual-use goals.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan specifies KPIs with owners and corrective actions in Review 6, and defines stop rules and tripwires for change control in the premortem section.

**Mitigation**: Program Director: Formalize the monthly review cadence and change-control board charter with defined thresholds within 30 days to ensure consistent execution.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because plan cites "Heavy reliance on state funding" and "undefined NMPA classification pathways" but lacks a cross-impact map showing how funding cuts cascade to regulatory delays.

**Mitigation**: Risk Management Team: Create a cross-impact matrix and bow-tie analysis for top high risks within 30 days, including combined heatmap with owner and NO-GO thresholds.