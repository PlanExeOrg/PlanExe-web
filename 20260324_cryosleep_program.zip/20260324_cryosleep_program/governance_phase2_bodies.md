### 1. Program Steering Committee

**Rationale for Inclusion:** Essential for providing high-level strategic direction and financial oversight across the ¥18 billion budget, ensuring alignment between CAS, CMSA, and national objectives.

**Responsibilities:**

- Approve strategic budget allocations exceeding ¥500 million
- Confirm tier transition gates (Tier 3 to Tier 4)
- Validate strategic risk mitigation plans
- Review annual program milestones and contingency triggers

**Initial Setup Actions:**

- Appoint an independent chairperson from external scientific advisory board
- Define formal Terms of Reference and conflict of interest policies
- Establish financial thresholds for decision approval

**Membership:**

- Director of Kunming Institute of Zoology (Chair)
- CMSA Space Systems Engineering Representative
- Independent External Scientific Advisor
- Chief Finance Officer

**Decision Rights:** Strategic direction, final budget approval above ¥500 million, Tier 4 progression authorization.

**Decision Mechanism:** Two-thirds majority vote; Chair holds casting vote in case of deadlock.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Financial performance vs. budget plan
- Tier gate review and authorization
- Strategic risk register update
- Personnel escalation and key appointments

**Escalation Path:** No further internal escalation; major disputes resolved by CAS Board or CMSA oversight.
### 2. Program Management Office

**Rationale for Inclusion:** Required for day-to-day execution coordination across multi-institutional tracks, ensuring data consistency and operational efficiency.

**Responsibilities:**

- Monitor daily operational execution against timelines
- Manage budget allocations below ¥500 million
- Coordinate data integration between consortium partners
- Track operational risks and implement mitigation

**Initial Setup Actions:**

- Deploy unified data integration platform at Kunming HQ
- Recruit technical leads for Tracks A, B, and C
- Set operational KPIs and reporting protocols

**Membership:**

- Program Director
- Track Leads (Torpor, Cryopreservation, Implant Systems)
- Operations Manager
- Data Governance Lead

**Decision Rights:** Operational scheduling, budget execution below ¥500 million, protocol adjustments within approved scope.

**Decision Mechanism:** Consensus among Track Leads; Program Director decides in tie-break scenarios.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Progress update by research track
- Resource allocation rebalancing
- Operational risk review
- Data integrity verification checks

**Escalation Path:** Escalate to Program Steering Committee for issues exceeding operational thresholds or requiring strategic pivot.
### 3. Independent Assurance and Ethics Committee

**Rationale for Inclusion:** Mandated to ensure ethical compliance, technical validation, and anti-corruption oversight, maintaining public trust and regulatory alignment.

**Responsibilities:**

- Review animal welfare welfare and cognitive function stop-gates
- Audit financial integrity and procurement processes
- Validate technical milestone achievements against predefined endpoints
- Ensure compliance with NMPA and data privacy regulations

**Initial Setup Actions:**

- Hire external independent auditors for financial checks
- Establish animal welfare escalation protocols
- Draft compliance policy for IP and data release

**Membership:**

- External Bioethicist (Chair)
- Independent Financial Auditor
- Lead Animal Welfare Officer
- External NMPA Regulatory Consultant

**Decision Rights:** Veto authority on ethical violations, technical gate verification, compliance audit findings.

**Decision Mechanism:** Unanimous vote required for ethical vetoes; majority for technical validation.

**Meeting Cadence:** Quarterly (or per milestone)

**Typical Agenda Items:**

- Welfare incident review and investigation
- Financial audit report presentation
- Technical validation against predefined metrics
- Compliance status for NMPA and CAS

**Escalation Path:** Escalate ethical or compliance breaches directly to Program Steering Committee or external regulatory bodies.