
## Documents to Create

### 1. Program Charter

**ID:** 0e070886-14d5-4af0-9ef6-295e10a54ac7

**Description:** Foundational document defining program scope, budget, governance structure, and authority lines. Specifies roles of Program Director and CAS oversight.

**Responsible Role Type:** Program Director

**Primary Template:** National Key R&D Program Charter Template

**Secondary Template:** PMI Project Charter Template

**Steps:**

- Define official program scope and success criteria
- Secure approval from CAS and CMSA leadership
- Establish governance structure and decision-making authorities

**Approval Authorities:** Chinese Academy of Sciences (CAS), China Manned Space Agency (CMSA)

### 2. Strategic Research Framework

**ID:** 63d9fe70-2066-474c-b022-31b0e6cd1c35

**Description:** High-level strategy defining research tracks (Torpor, Cryopreservation, Implants) and tiered gating systems based on the Pragmatic Foundation scenario.

**Responsible Role Type:** Cryobiology Research Lead

**Primary Template:** Multi-Track Research Program Framework

**Secondary Template:** Tiered Milestone Plan

**Steps:**

- Align research tracks with Scientific Track Priority decision
- Define Tier 1-4 milestones and success metrics
- Establish data convergence requirements at Tier 3

**Approval Authorities:** Program Director, CAS Research Consortium

### 3. High-Level Risk Register

**ID:** 09b26ece-d44b-497d-a5ee-c518eb674563

**Description:** Initial risk assessment documenting technical, regulatory, and operational risks with mitigation strategies based on expert review feedback.

**Responsible Role Type:** Program Director

**Primary Template:** Standard Risk Register Template

**Secondary Template:** N/A

**Steps:**

- Review expert review findings on regulatory and safety risks
- Document mitigation strategies for supply chain and compliance
- Identify contingency budget allocations

**Approval Authorities:** Program Director, Finance Controller

### 4. Stakeholder Engagement Plan

**ID:** ff3577ed-d1bb-4ac8-8b42-f38762e7d6ad

**Description:** Strategy for managing relationships with CAS, CMSA, NMPA, universities, and international boards to ensure alignment and transparency.

**Responsible Role Type:** Program Director

**Primary Template:** Stakeholder Management Plan Template

**Secondary Template:** Communications Strategy Framework

**Steps:**

- Map stakeholder groups and influence levels
- Define communication cadence and reporting formats
- Establish formal review schedules with regulators

**Approval Authorities:** CAS Ethics Committee, Program Director

### 5. Budget Allocation Framework

**ID:** 19193185-9c80-486a-9836-6ffdcd08cc34

**Description:** Overview of fund distribution across tiers and tracks, including contingency reserves and commercialization reinvestment rules.

**Responsible Role Type:** Finance Controller

**Primary Template:** Multi-Year Budget Allocation Model

**Secondary Template:** R&D Funding Structure Template

**Steps:**

- Draft high-level % split (60% R&D, 20% infra, etc.)
- Define gating triggers for budget reallocation
- Establish Tier 4 contingency reserve protocols

**Approval Authorities:** Program Director, CAS Finance Office

### 6. Intellectual Property Governance Policy

**ID:** f4631eb5-5548-453c-9692-64b77b8919bf

**Description:** Defined rules for CAS ownership, university rights, and private licensing agreements.

**Responsible Role Type:** Technology Transfer and Commercialization Lead

**Primary Template:** Joint Research IP Agreement Template

**Secondary Template:** Technology Licensing Standard Form

**Steps:**

- Draft joint ownership terms with universities
- Define private investor rights and revenue shares
- Establish filing deadlines for priority patents

**Approval Authorities:** CAS Legal Office, Program Director

### 7. Animal Welfare & Ethics Governance Plan

**ID:** 8939afe9-8e73-4e77-a717-e92f0b18214d

**Description:** Formal protocol for independent ethics boards, stop-gates, and 3R compliance for trials.

**Responsible Role Type:** Animal Welfare & Ethics Officer

**Primary Template:** Institutional Animal Care and Use Committee Plan

**Secondary Template:** Bioethics Compliance Framework

**Steps:**

- Replace cognitive kill-switches with physiological markers
- Draft euthanasia and monitoring procedures
- Recruit and credential independent ethics board

**Approval Authorities:** CAS Ethics Committee, Independent Bioethics Board

### 8. Regulatory Alignment Strategy

**ID:** 865832c7-760a-4beb-ad8f-0cab359a65b1

**Description:** Roadmap for engaging NMPA and CMSA on classification and clinical trial pathways.

**Responsible Role Type:** Regulatory Affairs Manager

**Primary Template:** Regulatory Submission Strategy Template

**Secondary Template:** Clinical Trial Planning Framework

**Steps:**

- Map implant features to device classification codes
- Draft clinical trial application milestones
- Schedule pre-submission meetings with MDEC

**Approval Authorities:** Program Director, NMPA Liaison

## Documents to Find

### 1. China National Key R&D Program Guidelines

**ID:** 06fa68a3-549c-4b59-959a-8b1c2bf960af

**Description:** Official funding structure and reporting requirements for national science initiatives.

**Recency Requirement:** Current fiscal year version

**Responsible Role Type:** Program Director

**Access Difficulty:** Medium

**Steps:**

- Access Ministry of Science and Technology website
- Contact CAS Finance Office for internal distribution

### 2. NMPA Medical Device Classification Guidelines

**ID:** 4209c4e0-968d-469a-ae4d-d2fe85f4519d

**Description:** Regulatory rules defining Class III implant requirements and evaluation criteria.

**Recency Requirement:** Latest published regulations

**Responsible Role Type:** Regulatory Affairs Manager

**Access Difficulty:** Medium

**Steps:**

- Search NMPA official website for medical device regulations
- Consult NMPA Medical Device Evaluation Center (MDEC)

### 3. CMSA Spaceflight Life Support Standards

**ID:** 4a6a6a9f-b038-42ee-8ad6-ac1e2ba7cb65

**Description:** Technical requirements and safety margins for crewed mission life support hardware.

**Recency Requirement:** Current active version

**Responsible Role Type:** Regulatory Affairs Manager

**Access Difficulty:** Hard

**Steps:**

- Contact CMSA Life Support Systems Engineering Office
- Review existing CMSA safety documentation repositories

### 4. Cryoprotectant Import Control Lists

**ID:** a2994dbf-4ff3-4409-8e40-a4ea79987901

**Description:** National regulations on chemical sourcing and export controls for biological materials.

**Recency Requirement:** Latest official update

**Responsible Role Type:** Infrastructure and Supply Chain Manager

**Access Difficulty:** Medium

**Steps:**

- Check Ministry of Commerce export control lists
- Verify with chemical supplier compliance offices

### 5. China Organ Transplant Logistics Statistics

**ID:** 313158db-afed-4928-bf35-2741c1b0360f

**Description:** Market data on organ preservation volumes and clinical demand for life-support systems.

**Recency Requirement:** Within last 2 years

**Responsible Role Type:** Technology Transfer and Commercialization Lead

**Access Difficulty:** Medium

**Steps:**

- Access Chinese Organ Transplant Registry data
- Consult industry association reports on transplant logistics

### 6. China Bioethics Review Guidelines

**ID:** 606636e2-94a9-4353-ae50-794f83bcbfcf

**Description:** National standards for ethical review of animal and human research protocols.

**Recency Requirement:** Latest published version

**Responsible Role Type:** Animal Welfare & Ethics Officer

**Access Difficulty:** Easy

**Steps:**

- Access National Health Commission website
- Contact CAS Ethics Committee directly

### 7. Cryobiology Scientific Baseline Data

**ID:** 81c03ece-a71c-4129-9fbb-a9ba02ab6f3e

**Description:** Aggregated survival rates and cognitive recovery metrics from published academic studies.

**Recency Requirement:** Most recent available peer-reviewed data

**Responsible Role Type:** Cryobiology Research Lead

**Access Difficulty:** Medium

**Steps:**

- Search international databases (PubMed, IEEE)
- Contact UPMC and NASA research groups for shared data

### 8. CAS Technology Transfer Policy Documents

**ID:** cd4d87ad-8147-46b5-9d5e-8e588afc0d31

**Description:** Internal rules on spinoff creation, revenue sharing, and government rights.

**Recency Requirement:** Current policy version

**Responsible Role Type:** Technology Transfer and Commercialization Lead

**Access Difficulty:** Medium

**Steps:**

- Access internal CAS Knowledge Transfer Office portal
- Consult legal team for standard templates