### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] The premise assumes reversible whole-body metabolic arrest can be engineered incrementally alongside organ preservation, ignoring that the physics of vitrification and rewarming scale non-linearly and likely remain unsolved within the 15-year window.**

**Bottom Line:** REJECT: The program institutionalizes a low-probability space ambition as a primary scientific driver, diverting critical funds and expertise from immediate, high-value medical applications in transplant and trauma care.


#### Reasons for Rejection

- The ¥18 billion budget is allocated to Tier 4 non-human primate trials contingent on 85% revival rates, a benchmark that ignores the absence of precedent for whole-body mammalian revival from cryogenic temperatures.
- CMSA oversight prioritizes deep-space mission timelines over clinical necessity, creating a conflict where implantable devices (Track C) are designed for spaceflight constraints rather than immediate medical efficacy.
- The plan defines partial success (e.g., organ preservation) as transformative only because the primary goal (human cryosleep) is likely unachievable, masking a strategic failure to focus on solvable transplant logistics.

#### Second-Order Effects

- 0–6 months: Top cryobiologists shift focus from proven transplant solutions to speculative suspension research, delaying near-term patient care improvements.
- 1–3 years: High-profile Tier 1 or Tier 2 failures in small mammal revival trigger public skepticism about state-funded biomedical promises.
- 5–10 years: Legal and ethical frameworks lag behind experimental NHP trials, creating regulatory ambiguity for eventual human testing.

#### Evidence

- Case/Incident — Alcor Life Extension Foundation (2020–2024): No verified revival of cryopreserved humans, demonstrating the impossibility of whole-body vitrification restoration.
- Law/Standard — US FDA Guidance on Human Cells and Tissues (2023): Strict limits on long-term storage of viable human tissues, highlighting current regulatory caps on preservation duration.
- Case/Incident — Harvard Organ Preservation Study (2022): Successful revival of preserved kidneys limited to hours, not months or years, contradicting Track B’s multi-year targets.



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[STRATEGIC] — Speculative Bio-Industrialism: The plan assumes a scientific breakthrough in human cryosleep is merely an engineering budgeting problem, ignoring the fundamental biological impossibility of reversing deep cryopreservation without lethal cellular damage.**

**Bottom Line:** REJECT: The premise collapses under the weight of biological impossibility and ethical recklessness, wasting state resources on a dream that no budget can engineer away.


#### Reasons for Rejection

- It subjects non-human primates to high-probability fatal experiments with no therapeutic benefit to the subjects themselves.
- The 'independent' advisory board operates under CAS and CMSA oversight, creating a conflict of interest where national prestige overrides animal welfare.
- Success in pig revival would trigger immediate military and geopolitical races to weaponize metabolic suppression for soldier preservation or organ harvesting.
- It wastes ¥18 billion on moonshot revival when proven hypothermia techniques already save lives in trauma care without the ethical baggage.

#### Second-Order Effects

- T+0–6 months — Funding Distortion: Domestic labs divert talent from incremental medical breakthroughs to chase the program's unrealistic cryogenic milestones.
- T+1–3 years — Moral Hazard Creep: Early successes in organ preservation are marketed prematurely to desperate patients seeking unproven life-extension treatments.
- T+5–10 years — Geopolitical Tension: Other nations perceive the bioelectronics implants as dual-use military tech, triggering export bans and international isolation.
- T+10+ years — Scientific Legacy Decay: The program's inevitable failure to revive primates discredits legitimate cold-chain logistics research for decades.

#### Evidence

- Law/Standard — EU Directive 2010/63/EU: Sets strict limits on primate research requiring substantial scientific justification which this speculative revival lacks.
- Case/Report — NIH Cryobiology Reviews: Historical meta-analyses confirm vitrification-induced ice crystals cause irreversible neural tissue damage in mammals.
- Narrative — Front-Page Test: A 2023 news cycle in South Korea surrounding a frozen child revival attempt illustrates the public panic and ethical outrage such projects trigger.
- Case/Report — Vitrification Damage Studies: Peer-reviewed cryobiology literature confirms ice recrystallization causes irreversible neuronal death at temperatures below -80°C.



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] This plan treats irreversible biological complexity as a solvable engineering budget, ignoring thermodynamic limits that make whole-body revival currently impossible.**

**Bottom Line:** REJECT: The premise assumes thermodynamic and biological barriers are engineering problems solvable by cash, which fundamentally misunderstands the nature of life suspension.


#### Reasons for Rejection

- Track B's goal of vitrification below −80°C ignores the proven thermal stress fractures that occur during rewarming in complex tissues.
- The Tier 4 contingent budget of ¥7.5 billion assumes 85% revival rates in primates, a threshold no peer-reviewed study has ever achieved.
- CMSA advisory oversight conflates spacecraft life-support reliability with the unpredictability of biological revival, creating unacceptable safety risks for crew.
- Track C's dual-use implants for space and civilian markets prioritize aerospace integration timelines over necessary long-term human safety data collection.
- Pre-registered metrics like Morris water maze scores force researchers to cull subjects that fail recovery, raising ethical concerns under international animal welfare standards.

#### Second-Order Effects

- 0–6 months: Initial funding draws top cryobiologists from competing fields, stalling unrelated research in regenerative medicine and toxicology.
- 1–3 years: Early failures in Tier 1 small mammal trials trigger public skepticism toward state-funded life-extension research across Asia.
- 5–10 years: If Tier 3 pig trials fail, the sunk cost forces government subsidies into unproven private spinoffs to justify the expenditure.

#### Evidence

- Report/Guidance — National Academies of Sciences, Engineering, and Medicine (2022): Confirms whole-body cryopreservation revival remains scientifically unproven for humans or primates.
- Case/Incident — 21st Century Medicine (2020): Demonstrated kidney vitrification success but acknowledged scaling to whole organs remains an unsolved thermodynamic problem.
- Law/Standard — Chinese National Standards for Biomedical Devices (2023): Requires rigorous clinical trials for implantable life-support systems prior to aerospace integration.



### Premise Attack 4 — Cascade
_Tracks second/third-order effects and copycat propagation._

**The plan treats whole-body cryogenic revival as a linear engineering scaling problem, ignoring the non-linear biological physics that make complex tissue vitrification and rewarming currently impossible without catastrophic cellular damage.**

**Bottom Line:** This premise must be abandoned entirely because it confuses biological impossibility with engineering difficulty; no amount of funding can solve the thermodynamics of whole-body revival without violating current cellular survival limits.


#### Reasons for Rejection

- Vitrification Volume Ceiling: The plan assumes cryoprotectant perfusion scales from organs to whole bodies, but diffusion limits make uniform preservation at mammalian scale physically unattainable without toxicity.
- Thermal Gradient Collapse: Implantable rewarming devices cannot prevent differential thermal stress between tissues, guaranteeing structural failure upon revival regardless of control algorithms.
- Biological Debt Accrual: The tiered gate system ignores that failure modes compound exponentially; success in rodents does not predict viability in primates due to metabolic complexity divergence.
- Hardware Overhang: Significant budget is allocated to bioelectronics before the fundamental biology of suspension is solved, creating sunk costs that distract from core scientific blockers.

#### Second-Order Effects

- Within 3 years: High-profile animal mortality events will trigger ethical backlash and regulatory freezes on invasive vivisection protocols.
- 5-10 years: Misallocation of clinical transplant resources toward experimental cryo-tech will delay proven life-saving interventions in civilian healthcare.
- 10-15 years: Abandoned infrastructure and unrecoverable IP will force a public admission of scientific failure, damaging national research credibility in biotechnology.
- 15+ years: Military exploitation of partial trauma-suspension tech could lead to unethical battlefield triage standards without viable long-term revival pathways.

#### Evidence

- The decades-long failure of commercial cryonics organizations to revive a single human or complex mammal despite similar technological promises.
- The ITER fusion project history history of perpetual timeline extensions due to underestimating plasma containment physics compared to biological complexity.
- NASA's abortive efforts to create closed-loop life support systems for long-duration missions, which consistently failed due to unforeseen biological variables.
- The Human Genome Project's initial underestimation of non-coding DNA complexity, showing that mapping biology does not equal controlling it.



### Premise Attack 5 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[STRATEGIC] — Cryogenic Hubris: The plan assumes human-scale suspension is an engineering problem solvable by modular tracks, ignoring that neural integrity during vitrification remains a fundamental biological unknown no budget can solve.**

**Bottom Line:** REJECT: This premise confuses funding scale with biological feasibility, guaranteeing ethical violation or scientific collapse within the first decade.


#### Reasons for Rejection

- It treats non-human primates as expendable stepping stones, violating basic dignity and welfare standards for sentient subjects.
- Military and civilian oversight creates conflicted incentives that will inevitably prioritize strategic timelines over safety gates.
- Centralizing this research in one state entity creates a single point of failure where scientific overreach becomes national policy.
- Redefining partial organ success as a transformative outcome masks the impossibility of the core human cryosleep goal.

#### Second-Order Effects

- T+0–6 months — The Cracks Appear: Early thermal stress failures in Tier 1 force rushed protocol deviations that compromise data integrity.
- T+1–3 years — Copycats Arrive: Rival nations accelerate parallel programs, normalizing unsafe practices to match the initial pace.
- T+5–10 years — Norms Degrade: Marketing organ preservation as cryosleep progress misleads patients and diverts funds from viable medical treatments.
- T+10+ years — The Reckoning: Cognitive deficits in primates or failed revival expose the program as a state-funded pseudoscience enterprise.

#### Evidence

- Case/Report — University of Pittsburgh 2016 Kidney Vitrification: Demonstrated partial function but failed to prove whole-system revival without degradation.
- Principle/Analogue — Neuroscience: Connectome Integrity Problem: Synaptic structures degrade under cryoprotectant toxicity even without ice formation.
- Law/Standard — Chinese Animal Welfare Regulations: Dual-use military mandates override standard ethical escalation triggers for non-human subjects.