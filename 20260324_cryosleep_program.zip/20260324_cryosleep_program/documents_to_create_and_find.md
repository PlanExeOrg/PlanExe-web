# Documents to Create

## Create Document 1: Program Charter

**ID**: 0e070886-14d5-4af0-9ef6-295e10a54ac7

**Description**: Foundational document defining program scope, budget, governance structure, and authority lines. Specifies roles of Program Director and CAS oversight.

**Responsible Role Type**: Program Director

**Primary Template**: National Key R&D Program Charter Template

**Secondary Template**: PMI Project Charter Template

**Steps to Create**:

- Define official program scope and success criteria
- Secure approval from CAS and CMSA leadership
- Establish governance structure and decision-making authorities

**Approval Authorities**: Chinese Academy of Sciences (CAS), China Manned Space Agency (CMSA)

**Essential Information**:

- Define program scope: 15-year timeline, ¥18 billion budget, Kunming Institute of Zoology headquarters.
- Specify governance roles: Program Director authority versus CAS and CMSA oversight lines.
- List success criteria: Tier 3 85% large-mammal revival rates and 90% cognitive recovery metrics.
- Detail budget allocation: 60% R&D, 20% infrastructure, 15% Tier 4 contingency reserve.
- Identify stakeholders: CAS research consortium, NMPA regulators, CMSA advisory body, and partner universities.
- Define decision-making process: Authority over strategic levers (e.g., Track Priority) and escalation paths.
- Include risk mitigation: Technical feasibility, regulatory compliance, and supply chain plans.

**Risks of Poor Quality**:

- Unclear authority lines cause delays in approving strategic decisions like Track Priority or Budget Allocation.
- Ambiguous budget definitions lead to funding gaps during critical Tier 3 or Tier 4 phases.
- Unspecified oversight criteria prevent timely approval from CAS and CMSA.

**Worst Case Scenario**: Program termination due to governance misalignment with state funders, resulting in loss of ¥18 billion investment and reputational damage.

**Best Case Scenario**: Streamlined decision-making enables rapid strategic pivots during scientific hurdles, ensuring on-time delivery of Tier 3 milestones and continuous state funding.

**Fallback Alternative Approaches**:

- Adopt the 'National Key R&D Program Charter Template' strictly to reduce drafting time and ensure compliance.
- Hold a focused workshop with CAS and CMSA representatives to agree on governance authority before drafting full text.
- Develop a simplified 'Executive Summary Charter' for immediate approval, expanding detailed governance later.

## Create Document 2: Strategic Research Framework

**ID**: 63d9fe70-2066-474c-b022-31b0e6cd1c35

**Description**: High-level strategy defining research tracks (Torpor, Cryopreservation, Implants) and tiered gating systems based on the Pragmatic Foundation scenario.

**Responsible Role Type**: Cryobiology Research Lead

**Primary Template**: Multi-Track Research Program Framework

**Secondary Template**: Tiered Milestone Plan

**Steps to Create**:

- Align research tracks with Scientific Track Priority decision
- Define Tier 1-4 milestones and success metrics
- Establish data convergence requirements at Tier 3

**Approval Authorities**: Program Director, CAS Research Consortium

**Essential Information**:

- Identify specific resource distribution ratios for synthetic torpor, deep cryopreservation, and implant tracks.
- Define quantitative exit criteria and success metrics for Tier 1 through Tier 4.
- Specify data integration requirements for Tier 3 empirical convergence across all tracks.
- Incorporate budget allocation constraints and contingency reserves from the Pragmatic Foundation scenario.
- List dependencies on external approvals (NMPA, CMSA) for each milestone phase.
- Detail mechanisms for triggering Tier 4 contingency responses if biological gates fail.

**Risks of Poor Quality**:

- Fragmented expertise leading to failed breakthroughs in individual scientific tracks.
- Ambiguous milestones causing funding delays or premature termination of viable pathways.
- Misaligned metrics between medical revenue goals and spaceflight viability requirements.
- Unclear data convergence protocols preventing valid comparison of experimental results at Tier 3.
- Financial strain due to lack of defined off-ramps when primary objectives are unachievable.

**Worst Case Scenario**: Full budget depletion of ¥18 billion without achieving Tier 3 convergence, commercial viability, or regulatory clearance, resulting in program termination and reputational damage.

**Best Case Scenario**: Synchronized progress across parallel tracks with clear decision gates, ensuring financial sustainability through dual-use commercialization even if primary spaceflight goals stall.

**Fallback Alternative Approaches**:

- Leverage existing SMART criteria from project-plan.md as a temporary scaffold for milestone definition.
- Schedule a focused workshop with track leads to collaboratively draft milestone tables and resource splits.
- Adopt the Tiered Milestone Plan template first, deferring detailed track alignment until Scientific Track Priority is formally ratified.
- Engage the Program Director to pre-approve high-level budget caps per tier before finalizing technical details.

## Create Document 3: High-Level Risk Register

**ID**: 09b26ece-d44b-497d-a5ee-c518eb674563

**Description**: Initial risk assessment documenting technical, regulatory, and operational risks with mitigation strategies based on expert review feedback.

**Responsible Role Type**: Program Director

**Primary Template**: Standard Risk Register Template

**Secondary Template**: N/A

**Steps to Create**:

- Review expert review findings on regulatory and safety risks
- Document mitigation strategies for supply chain and compliance
- Identify contingency budget allocations

**Approval Authorities**: Program Director, Finance Controller

**Essential Information**:

- Identify top technical risks (e.g., vitrification damage, ice crystallization) with probability and severity scores.
- Detail regulatory risks (NMPA/CMSA alignment, animal welfare) and required compliance actions.
- Quantify financial risks (state funding reliance) and define contingency budget allocations (e.g., 15% reserve).
- Specify operational mitigation strategies (supply chain dual-sourcing, talent retention plans).
- Incorporate expert review feedback (currency hedging, dynamic regulatory advisory boards).

**Risks of Poor Quality**:

- Incomplete risk identification leads to unforeseen budget overruns during Tier 3/4 phases.
- Vague mitigation strategies result in delayed response to supply chain or regulatory disruptions.
- Missing financial risk planning causes funding gaps if state budgets shift unexpectedly.

**Worst Case Scenario**: Program suspension due to unmanaged ethical violations or budget exhaustion before achieving Tier 3 revival milestones.

**Best Case Scenario**: Proactive risk mitigation ensures continuous funding, regulatory compliance, and timely achievement of all tiered milestones within the 15-year window.

**Fallback Alternative Approaches**:

- Utilize existing consortium risk templates and adapt them to project-specific criteria.
- Prioritize documentation of the top 5 critical risks initially to accelerate approval.
- Engage external risk consultants to validate mitigation strategies for technical and regulatory uncertainties.

## Create Document 4: Budget Allocation Framework

**ID**: 19193185-9c80-486a-9836-6ffdcd08cc34

**Description**: Overview of fund distribution across tiers and tracks, including contingency reserves and commercialization reinvestment rules.

**Responsible Role Type**: Finance Controller

**Primary Template**: Multi-Year Budget Allocation Model

**Secondary Template**: R&D Funding Structure Template

**Steps to Create**:

- Draft high-level % split (60% R&D, 20% infra, etc.)
- Define gating triggers for budget reallocation
- Establish Tier 4 contingency reserve protocols

**Approval Authorities**: Program Director, CAS Finance Office

**Essential Information**:

- Define annual expenditure caps for Tier 1 through Tier 4 based on the ¥18 billion total budget.
- Quantify the percentage split between research tracks (synthetic torpor vs. deep cryopreservation).
- Establish specific gating triggers that authorize budget reallocation between tiers upon milestone success or failure.
- Detail the 15% Tier 4 contingency reserve protocols and release conditions.
- Specify commercialization reinvestment rules for licensing revenue generated from implantable devices.
- Requires input from the Finance Controller, Program Director, and strategic decision logs.

**Risks of Poor Quality**:

- Ambiguous reallocation triggers cause delays when scientific milestones are missed.
- Insufficient contingency reserves leave the program vulnerable to state funding cuts.
- Misaligned spending priorities fragment expertise across parallel research tracks.
- Lack of commercialization rules delays revenue generation needed for sustainability.

**Worst Case Scenario**: Program termination due to capital exhaustion before Tier 3 validation gates are reached, resulting in total loss of investment.

**Best Case Scenario**: Enables data-driven go/no-go decisions on funding continuation and ensures financial resilience against biological hurdles.

**Fallback Alternative Approaches**:

- Adopt the Multi-Year Budget Allocation Model template with default R&D splits.
- Limit initial scope to Tier 1-3 allocations pending Tier 4 outcome data.
- Convene a finance workshop with CAS representatives to validate contingency percentages.

## Create Document 5: Animal Welfare & Ethics Governance Plan

**ID**: 8939afe9-8e73-4e77-a717-e92f0b18214d

**Description**: Formal protocol for independent ethics boards, stop-gates, and 3R compliance for trials.

**Responsible Role Type**: Animal Welfare & Ethics Officer

**Primary Template**: Institutional Animal Care and Use Committee Plan

**Secondary Template**: Bioethics Compliance Framework

**Steps to Create**:

- Replace cognitive kill-switches with physiological markers
- Draft euthanasia and monitoring procedures
- Recruit and credential independent ethics board

**Approval Authorities**: CAS Ethics Committee, Independent Bioethics Board

**Essential Information**:

- Define specific physiological markers to replace cognitive kill-switches for early termination.
- Quantify exact cognitive decline thresholds (e.g., 85% baseline) for stop-gate activation.
- Draft detailed euthanasia and post-mortem monitoring procedures for failed trials.
- Outline the charter and credentialing process for the Independent Bioethics Board.
- List 3R compliance requirements for Tier 1 through Tier 4 primate trials.
- Identify required inputs from veterinary teams and existing CAS Bioethics Guidelines.

**Risks of Poor Quality**:

- Unclear termination triggers lead to unnecessary animal suffering and public backlash.
- Regulatory bodies (NMPA/CMSA) reject protocols due to non-compliance with international standards.
- Budget waste occurs when experiments halt prematurely without clear ethical justification.
- Consortium partners face inconsistent ethical standards, causing data interoperability issues.
- Reputational damage results in loss of social license to operate at the Kunming campus.

**Worst Case Scenario**: Program suspension or permanent ban by government regulators due to ethical violations, resulting in total loss of the ¥18 billion investment and irreversible reputational damage.

**Best Case Scenario**: Uninterrupted research progression through Tier 4 with full regulatory approval, maintaining public trust and enabling timely human trials without ethical stoppages.

**Fallback Alternative Approaches**:

- Utilize the existing Institutional Animal Care and Use Committee template with minimal adaptation.
- Engage an external ethics consultant to draft the plan within one month.
- Develop a provisional interim governance framework for Tier 1-2 trials pending full board credentialing.
- Schedule a focused workshop with CAS Ethics Committee members to define stop-gates collaboratively.

## Create Document 6: Regulatory Alignment Strategy

**ID**: 865832c7-760a-4beb-ad8f-0cab359a65b1

**Description**: Roadmap for engaging NMPA and CMSA on classification and clinical trial pathways.

**Responsible Role Type**: Regulatory Affairs Manager

**Primary Template**: Regulatory Submission Strategy Template

**Secondary Template**: Clinical Trial Planning Framework

**Steps to Create**:

- Map implant features to device classification codes
- Draft clinical trial application milestones
- Schedule pre-submission meetings with MDEC

**Approval Authorities**: Program Director, NMPA Liaison

**Essential Information**:

- Identify specific NMPA device classification codes applicable to implantable life-support systems.
- Define clinical trial milestone timelines aligning Tier 3 animal data with Tier 4 human trial requirements.
- Map safety validation criteria from CMSA spaceflight standards against NMPA medical device safety protocols.
- Include pre-submission meeting agendas for regulatory bodies to confirm data requirements before Tier 2 completion.
- Requires input from engineering team on device specs and research protocols for Tier 3/4 experimental designs.

**Risks of Poor Quality**:

- Regulatory rejection of clinical trial applications due to mismatched safety benchmarks.
- Delays in Tier 4 progression resulting from late discovery of compliance gaps.
- Budget overruns caused by re-testing to satisfy unanticipated regulatory standards.
- Conflicts between medical and spaceflight requirements delaying dual-use technology transfer.

**Worst Case Scenario**: Program suspension due to non-compliance with NMPA or CMSA regulations, causing loss of state funding and failure to meet the 15-year delivery timeline.

**Best Case Scenario**: Accelerated regulatory approval enabling Tier 4 trials on schedule, with harmonized standards reducing rework and supporting dual-use commercialization.

**Fallback Alternative Approaches**:

- Engage external regulatory consultants to expedite classification mapping and compliance checks.
- Develop a simplified compliance matrix focusing only on critical Tier 3 data requirements initially.
- Pursue provisional medical device exemptions to allow partial validation while finalizing the full pathway.
- Schedule targeted meetings with NMPA liaisons to clarify specific protocol expectations before drafting the full strategy.


# Documents to Find

## Find Document 1: China National Key R&D Program Guidelines

**ID**: 06fa68a3-549c-4b59-959a-8b1c2bf960af

**Description**: Official funding structure and reporting requirements for national science initiatives.

**Recency Requirement**: Current fiscal year version

**Responsible Role Type**: Program Director

**Steps to Find**:

- Access Ministry of Science and Technology website
- Contact CAS Finance Office for internal distribution

**Access Difficulty**: Medium

**Essential Information**:

- Identify exact funding disbursement milestones linked to Tier 1-4 gates.
- List mandatory reporting formats and submission timelines.
- Quantify allowed expenditure ratios for R&D versus infrastructure.
- Detail audit triggers and required documentation for compliance.

**Risks of Poor Quality**:

- Budget hold-ups due to misaligned reporting schedules.
- Compliance penalties jeopardizing future state funding.
- Project restructuring costs from incompatible national KPIs.

**Worst Case Scenario**: Program suspension and financial clawback due to audit failure, halting the 15-year timeline.

**Best Case Scenario**: Seamless fund disbursement and audit approvals ensuring financial stability for parallel research tracks.

**Fallback Alternative Approaches**:

- Consult CAS Finance Office liaisons for current fiscal year updates.
- Review prior successful grant reports from partner universities.
- Engage external compliance consultant specializing in National Key R&D initiatives.

## Find Document 2: NMPA Medical Device Classification Guidelines

**ID**: 4209c4e0-968d-469a-ae4d-d2fe85f4519d

**Description**: Regulatory rules defining Class III implant requirements and evaluation criteria.

**Recency Requirement**: Latest published regulations

**Responsible Role Type**: Regulatory Affairs Manager

**Steps to Find**:

- Search NMPA official website for medical device regulations
- Consult NMPA Medical Device Evaluation Center (MDEC)

**Access Difficulty**: Medium

**Essential Information**:

- Define exact Class III classification thresholds for implantable life-support systems used in metabolic suppression.
- List required pre-clinical safety data points specifically for cryoprotectant interface biocompatibility.
- Specify clinical trial protocol requirements for Tier 4 human validation and revival metrics.
- Identify mandatory documentation formats and submission channels to the Medical Device Evaluation Center (MDEC).
- Quantify expected review timelines for high-risk device categories to align with Tier 4 gates.

**Risks of Poor Quality**:

- Misclassification leading to immediate application rejection and significant program timeline slippage.
- Design non-compliance requiring costly hardware re-engineering before large-mammal trials.
- Unanticipated data requirements causing delays in Tier 3 to Tier 4 transition.
- Financial shortfall due to delayed medical market entry and lost revenue streams.

**Worst Case Scenario**: Regulatory denial prevents Tier 4 initiation, halting the commercialization pathway and threatening the ¥18 billion budget sustainability before program completion.

**Best Case Scenario**: Clear alignment enables on-schedule Tier 4 clearance, unlocking medical device revenue to subsidize spaceflight research and securing long-term program viability.

**Fallback Alternative Approaches**:

- Initiate pre-submission meetings with NMPA officials to clarify classification and data expectations.
- Engage third-party regulatory consultants with recent NMPA approval experience.
- Conduct limited exploratory trials under existing research exemptions to validate assumptions.
- Adapt international FDA or EMA standards as baseline compliance targets where local rules are ambiguous.

## Find Document 3: Cryoprotectant Import Control Lists

**ID**: a2994dbf-4ff3-4409-8e40-a4ea79987901

**Description**: National regulations on chemical sourcing and export controls for biological materials.

**Recency Requirement**: Latest official update

**Responsible Role Type**: Infrastructure and Supply Chain Manager

**Steps to Find**:

- Check Ministry of Commerce export control lists
- Verify with chemical supplier compliance offices

**Access Difficulty**: Medium

**Essential Information**:

- List of cryoprotectant precursors (e.g., DMSO, ethylene glycol) requiring export licenses under current Ministry of Commerce regulations.
- Specific quantity thresholds that trigger mandatory inspection or special import permits for biological research materials.
- Required documentation format for customs clearance of dual-use chemical compounds.
- Updated contact details for regulatory inquiries regarding cryobiology research exemptions.

**Risks of Poor Quality**:

- Shipment seizures due to outdated classification codes cause Tier 2-3 experimental delays.
- Undetected dual-use restrictions halt Track B vitrification protocol development.
- Non-compliance penalties increase operational costs beyond the 10% operations budget allocation.

**Worst Case Scenario**: Critical chemical shortages force suspension of large-mammal trials, extending the program beyond the 15-year timeline and risking state funding cuts.

**Best Case Scenario**: Uninterrupted material flow maintains experimental velocity, ensuring Tier 3 gates are met on schedule without triggering supply chain contingency reserves.

**Fallback Alternative Approaches**:

- Activate dual-sourcing agreements with domestic chemical suppliers identified in Risk 5 mitigation plans.
- Request formal pre-clearance consultation with local customs authorities for pending research shipments.
- Leverage consortium partner university procurement channels for materials under academic research exemptions.

## Find Document 4: China Bioethics Review Guidelines

**ID**: 606636e2-94a9-4353-ae50-794f83bcbfcf

**Description**: National standards for ethical review of animal and human research protocols.

**Recency Requirement**: Latest published version

**Responsible Role Type**: Animal Welfare & Ethics Officer

**Steps to Find**:

- Access National Health Commission website
- Contact CAS Ethics Committee directly

**Access Difficulty**: Easy

**Essential Information**:

- Identify the minimum cognitive function recovery threshold required for Tier 4 human trial authorization.
- List mandatory adverse event reporting timelines for Tier 3 large-mammal revival trials.
- Define the required composition and external membership quota for the independent ethics review board.
- Detail the specific waste disposal protocols for cryoprotectant chemicals to prevent environmental contamination.
- Quantify the acceptable animal welfare stop-gate metrics (e.g., post-revival cognitive decline percentage).

**Risks of Poor Quality**:

- Regulatory rejection of human trial permits due to non-compliance with national ethical standards.
- Program suspension caused by public backlash over inadequate animal welfare protections.
- Legal liability and funding cuts due to unmet safety benchmarks for chemical handling.
- Inability to secure CMSA oversight approval without aligned ethical frameworks.

**Worst Case Scenario**: Complete termination of the 15-year program due to ethical violations, resulting in total loss of ¥18 billion investment and irreversible damage to national scientific reputation.

**Best Case Scenario**: Seamless regulatory approval for Tier 3 and Tier 4 trials, establishing the program as the global benchmark for ethical cryobiology research and accelerating medical market entry.

**Fallback Alternative Approaches**:

- Engage CAS Ethics Committee directly for a pre-review meeting to clarify existing guidelines.
- Adopt international AAALAC standards as a proxy compliance framework while awaiting national specifics.
- Consult legal counsel specializing in Chinese biomedical research to draft internal policies based on draft regulations.

## Find Document 5: Cryobiology Scientific Baseline Data

**ID**: 81c03ece-a71c-4129-9fbb-a9ba02ab6f3e

**Description**: Aggregated survival rates and cognitive recovery metrics from published academic studies.

**Recency Requirement**: Most recent available peer-reviewed data

**Responsible Role Type**: Cryobiology Research Lead

**Steps to Find**:

- Search international databases (PubMed, IEEE)
- Contact UPMC and NASA research groups for shared data

**Access Difficulty**: Medium

**Essential Information**:

- List exact survival rates for large mammals (e.g., primates) under torpor versus vitrification protocols.
- Quantify cognitive recovery metrics as a percentage of baseline function post-revival.
- Detail maximum sustainable suspension durations for each regime without irreversible damage.
- Identify specific tissue or organ failure rates associated with rewarming processes.
- Provide peer-reviewed sources published within the last 5 years to ensure recency.

**Risks of Poor Quality**:

- Incorrect empirical thresholds lead to premature commitment to a suboptimal scientific track.
- Tier 3 gate criteria become unrealistic, causing unnecessary program suspension or failure.
- Regulatory bodies reject validation standards due to lack of robust external data support.
- Resource allocation misaligns with actual biological capabilities, wasting capital on unviable paths.

**Worst Case Scenario**: Program fails at Tier 3 because baseline data underestimated biological risks, resulting in total budget exhaustion without achieving viable revival protocols and significant reputational damage.

**Best Case Scenario**: High-fidelity baseline data enables precise definition of Tier 3 gates, accelerating track convergence and securing early regulatory alignment for human trials.

**Fallback Alternative Approaches**:

- Initiate small-scale internal pilot studies to generate preliminary survival and recovery metrics.
- Engage consortium partners to share proprietary data under non-disclosure agreements.
- Adopt conservative performance estimates with increased contingency reserves for Tier 3 execution.

## Find Document 6: CAS Technology Transfer Policy Documents

**ID**: cd4d87ad-8147-46b5-9d5e-8e588afc0d31

**Description**: Internal rules on spinoff creation, revenue sharing, and government rights.

**Recency Requirement**: Current policy version

**Responsible Role Type**: Technology Transfer and Commercialization Lead

**Steps to Find**:

- Access internal CAS Knowledge Transfer Office portal
- Consult legal team for standard templates

**Access Difficulty**: Medium

**Essential Information**:

- Quantify revenue split percentages between CAS, universities, and private investors for implantable device licenses.
- Define IP ownership rights for dual-use technologies applicable to both medical and spaceflight domains.
- Specify government rights regarding national security access to proprietary cryobiology data.
- Outline restrictions on publication timing relative to patent filing windows for spinoff creation.

**Risks of Poor Quality**:

- Unclear IP ownership leads to litigation delaying technology transfer and revenue generation.
- Misaligned revenue shares reduce university participation in consortium research.
- Failure to disclose government rights triggers regulatory rejection by NMPA or CMSA.
- Ambiguous spinoff rules stall commercialization, impacting financial sustainability.

**Worst Case Scenario**: Legal disputes over IP ownership halt commercialization efforts, causing budget shortfalls and forcing program termination before Tier 4.

**Best Case Scenario**: Clear policies enable immediate licensing revenue to subsidize space research while ensuring full compliance with national security and regulatory requirements.

**Fallback Alternative Approaches**:

- Engage CAS Knowledge Transfer Office directly for verbal guidance on standard terms.
- Draft a provisional Memorandum of Understanding based on precedents from similar national R&D programs.
- Consult external legal counsel specializing in biomedical IP to model compliant structures.