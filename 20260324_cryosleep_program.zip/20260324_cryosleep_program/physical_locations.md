This plan implies one or more physical locations.

## Requirements for physical locations

- purpose-built campus for research
- facilities for in vivo mammal experiments
- biosecurity containment for chemicals
- proximity to consortium partners
- space for 500 FTE personnel

## Location 1
China

Kunming, Yunnan

Kunming Institute of Zoology Campus

**Rationale**: The plan specifies this site as the headquarters. It offers specialized zoology expertise and infrastructure for mammal research required in the initial tiers.

## Location 2
China

Beijing

CAS Institute of Zoology

**Rationale**: Participation by this institute provides access to established hibernation biology research networks for cross-institutional data validation.

## Location 3
China

Hangzhou, Zhejiang

Zhejiang University Campus

**Rationale**: Zhejiang University is a partner for materials science, essential for developing cryoprotectants and implantable hardware during the program.

## Location Summary
The primary campus is located at Kunming Institute of Zoology for research and development. Additional sites at Beijing and Zhejiang facilitate consortium cooperation on biology and materials science.