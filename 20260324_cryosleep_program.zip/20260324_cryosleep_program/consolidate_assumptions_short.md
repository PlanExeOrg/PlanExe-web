# Purpose
# Purpose

- business
- Large-scale governmental and societal initiative for medical devices and space technology with commercialization potential

# Topic

- National research program on reversible suspended metabolism


# Domain
# Domains

- Primary: Cryobiology
- Secondary: Biomedical Engineering, Aerospace Medicine, Pharmacology

## Rationale

- Cryobiology defines core success criteria for metabolic suppression and revival.
- Other fields support tracks but do not define overall outcomes.

## Disciplines

- Cryobiology (outcome): Core science for metabolic suppression and revival.
- Thermal Engineering (method): Manages thermal stress during perfusion and rewarming.
- Bioethics (constraint): Mandatory oversight board and welfare triggers.
- Neural Engineering (method): Tracks brain activity and cognitive retention.
- Biomedical Engineering (method): Designs implantable life-support systems.
- Pharmacology (method): Track A relies on pharmacologically induced suppression.
- Space Systems Engineering (method): Requires spacecraft life-support hardware integration.
- Transplant Medicine (market): Immediate applications include organ transplant logistics.
- Aerospace Medicine (stakeholder): Defines spaceflight integration requirements.


# Plan Type
- Plan requires one or more physical locations and cannot be executed digitally.
- Involves establishing a research campus at the Kunming Institute of Zoology.
- Includes extensive in vivo experiments on mammals, including surgical implantation of bioelectronic devices.
- Development and testing of physical medical hardware and biological protocols require real-world laboratories, equipment, and living subjects.


# Physical Locations
This plan implies one or more physical locations.

## Requirements for physical locations

- purpose-built campus for research
- facilities for in vivo mammal experiments
- biosecurity containment for chemicals
- proximity to consortium partners
- space for 500 FTE personnel

## Location 1

- China, Kunming, Yunnan
- Kunming Institute of Zoology Campus
- Rationale: Headquarters; offers specialized zoology expertise and infrastructure for initial tier mammal research.

## Location 2

- China, Beijing
- CAS Institute of Zoology
- Rationale: Access to established hibernation biology research networks for cross-institutional data validation.

## Location 3

- China, Hangzhou, Zhejiang
- Zhejiang University Campus
- Rationale: Partner for materials science essential for developing cryoprotectants and implantable hardware.

## Location Summary
Primary campus at Kunming Institute of Zoology for R&D. Additional sites at Beijing and Zhejiang facilitate consortium cooperation on biology and materials science.

# Currency Strategy
## Currencies

- CNY: Project headquartered in China with all funding and expenses denominated in Chinese Yuan.
- Strategy: Local currency used for all transactions; no additional international risk management needed.


# Identify Risks
## Risk 1 - Technical Feasibility
Whole-body vitrification and revival without damage is unproven in small mammals. Ice crystallization may cause micro-injuries to brain and organs.

- Impact: Failure to meet Tier 2/3 viability benchmarks could force redesign. Estimated delay 3–5 years, ¥4–6 billion rerouting to partial-suspension.
- Likelihood: High
- Severity: High
- Action: Maintain parallel Track A (torpor) and Track B (vitrification) resources. Mandate interim biological assays before Tier 3 scaling.

## Risk 2 - Regulatory & Animal Welfare
Tier 4 primate trials involve high ethical stakes. Public/regulatory pushback on cognitive impairment could halt authorization.

- Impact: Program suspension or ban. Loss of ¥7.5 billion budget, reputational damage, 12–24 month stoppage.
- Likelihood: Medium
- Severity: High
- Action: Engage independent bioethics board early. Implement strict 85% cognitive function thresholds as stop gates.

## Risk 3 - Financial Sustainability
Heavy reliance on state funding (National Key R&D, CAS, CMSA) creates exposure to budget shifts. Commercialization revenue may fail if NMPA approval is missed.

- Impact: 20% state budget cut could create ¥3.6 billion annual gap. Spinoffs may yield ¥200–400 million if adoption is slow.
- Likelihood: Medium
- Severity: Medium
- Action: Establish 15% contingency reserve from Tier 3/4 budgets. Accelerate Tech Transfer Office licensing by Year 4.

## Risk 4 - Operational Coordination
Consortium involves CAS institutes, universities, and hospitals with distinct data standards. Inconsistencies could undermine Tier 3 convergence.

- Impact: Delays due to data sync errors or protocol mismatch. 6–12 month slippage, ¥500 million–1 billion re-validation cost.
- Likelihood: High
- Severity: Medium
- Action: Deploy unified data integration platform at Kunming HQ. Centralize protocol standardization via binding steering committee.

## Risk 5 - Supply Chain Security
Specialized cryoprotectant precursors and micro-pump components may be sourced globally. Export controls could interrupt supply for Track B implants.

- Impact: Production halt for prototypes. Lead time increases 3–6 months, cost overruns ¥150–300 million per event.
- Likelihood: Medium
- Severity: Medium
- Action: Adopt dual-sourcing with domestic manufacturers. Stockpile critical materials for 12 months of Tier 2–3 operations.

## Risk summary
Critical risks exist in Technical Feasibility and Regulatory & Animal Welfare. Financial and supply chains are manageable. Core science risk could derail the 15-year timeline if Tier 3 gates fail. Mitigation prioritizes parallel tracks, ethical stop-gates, and accelerating commercial licensing to ensure economic viability.

# Make Assumptions
## Question 1 - Budget allocation across tracks and tiers

- Budget: 60% R&D, 20% infrastructure, 10% contingency, 10% operations, 15% Tier 4 reserve.
- Financial Feasibility: Evaluate stability against risks. Contingency mitigates state cuts; Tier 3 overspending risk if gates fail.

## Question 2 - Go/no-go points and schedule delays

- Schedule: Tier 1-2 take 6 years, Tier 3 takes 4 years, Tier 4 takes 5 years, 6-month regulatory buffers.
- Schedule Feasibility: Evaluate timeline realism. Buffers account for delays; Tier 3 failure risk extending program beyond 15 years.

## Question 3 - Workforce recruitment and expertise gaps

- Staff: 70% from CAS/university pools, 30% external, retention bonuses tied to milestones.
- Talent Strategy: Evaluate stability. Internal recruitment reduces cost; private sector poaching risk destabilizing Track C.

## Question 4 - Compliance mechanisms and IP ownership

- IP/Regulatory: CAS holds majority IP, universities retain publication rights, NMPA engagement begins at Tier 2.
- Regulatory Compliance: Evaluate framework. Early NMPA engagement reduces risk; IP disputes could slow tech transfer.

## Question 5 - Toxicity protocols and welfare triggers

- Safety: Cryoprotectant toxicity manageable with existing protocols, welfare triggers enforced by independent committee.
- Operational Safety: Evaluate mitigation. Strict welfare protects trust but limits optimization; toxicity protocols must prevent neurological damage.

## Question 6 - Waste disposal and containment procedures

- Waste: Chemical waste incinerated or neutralized on-site to prevent discharge.
- Environmental Risk: Evaluate impact. On-site neutralization critical; spillage penalties could halt Kunming operations.

## Question 7 - Partner integration and review process

- Partners: CMSA provides monthly review access, private partners restricted to licensing until Tier 3 validation.
- Partnership Dynamics: Evaluate collaboration. Balancing transparency with security; conflicting priorities risk delays.

## Question 8 - Data integration and lab management systems

- Systems: Centralized cloud-based LIMS at Kunming HQ with offline capabilities.
- Systems Integration: Evaluate reliability. Centralized LIMS ensures consistency; cybersecurity risks require strict access controls.


# Distill Assumptions
# Budget and Timeline

- ¥18 billion budget allocates 60 percent to R&D.
- Tier 1 through 3 span six years with six-month buffers.

# Execution Dependencies

- Tier 4 depends on Tier 3 achieving 85 percent revival rates.
- Three parallel research tracks converge at Tier 3.

# Workforce and IP

- Recruitment assumes 70 percent internal hiring with milestone bonuses.
- CAS holds majority IP rights; universities retain publication privileges.

# Compliance and Access

- NMPA engagement begins at Tier 2.
- CMSA receives monthly review; private partners wait until Tier 3.

# Ethics and Environment

- Independent committee enforces animal welfare triggers.
- Chemical waste neutralized on-site to prevent contamination.

# Technology and Market

- Cloud LIMS deployed at Kunming headquarters.
- Implant devices target medical markets to subsidize spaceflight research.


# Review Assumptions
## Domain of the expert reviewer
Biomedical Research Program Management

## Domain-specific considerations

- Regulatory Compliance
- Supply Chain Resilience
- Talent Acquisition
- Budget Allocation

## Issue 1 - Unrealistic Currency and Supply Chain Risk Management
The plan assumes no international risk management despite global sourcing. Geopolitical tensions or currency fluctuations could disrupt Tier 2-3 operations.

- Recommendation: Implement currency hedging, secure dual-source domestic suppliers for cryoprotectants, and allocate 5% budget for supply chain contingency.
- Sensitivity: A 20% import cost increase could raise total costs by ¥150M-300M. Disruptions could delay Tier 3 by 6-12 months.

## Issue 2 - Inadequate Talent Retention Strategy
Relying on 70% internal hiring limits access to specialized cryobiology experts. Private sector poaching could destabilize the workforce.

- Recommendation: Increase external hiring to 40% for critical roles. Offer equity-like incentives or long-term career paths to retain talent.
- Sensitivity: A 15% senior staff turnover could increase recruitment costs by ¥50M-75M and delay Tier 4 validation by 6-9 months.

## Issue 3 - Misaligned Regulatory Engagement Timeline
Assuming NMPA engagement at Tier 2 covers human-use standards may be premature as standards evolve based on animal data.

- Recommendation: Establish a dynamic regulatory advisory board meeting quarterly. Align Tier 3 data collection with evolving NMPA guidelines.
- Sensitivity: If NMPA requirements shift post-Tier 2, rework could delay human trials by 12-18 months, increasing costs by ¥300M-500M.

## Review conclusion
The project requires robust financial hedging, aggressive talent acquisition, and dynamic regulatory planning. Addressing these areas will improve the likelihood of staying within the 15-year timeline and ¥18 billion budget.