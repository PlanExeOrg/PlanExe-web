# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Regulatory Affairs Specialist

**Knowledge**: NMPA device classification,CMSA spaceflight safety,clinical trial design

**Why**: Plan requires early NMPA alignment to avoid rework on implant safety protocols and CMSA interface standards.

**What**: Map Tier 3 data points to future medical device regulatory pathways.

**Skills**: Regulatory strategy,compliance mapping,validation criteria

**Search**: NMPA medical device regulation specialist,CMSA spaceflight safety standards,clinical trial regulatory strategy

## 1.1 Primary Actions

- Schedule a pre-submission meeting with NMPA MDEC to confirm Track C implant classification code by 2026-12-31.
- Draft a CMSA safety compliance matrix mapping implant features to aerospace redundancy requirements by 2027-02-28.
- Prepare and file the Clinical Trial Application for the implantable life-support system parallel to Tier 3 validation by 2029-06-30.

## 1.2 Secondary Actions

- Recruit a dedicated Regulatory Affairs Director with prior NMPA Class III device approval experience.
- Update the data governance policy to allow NMPA raw data inspection without violating IP protection timelines.
- Conduct a risk assessment on CMSA safety standards and integrate into Tier 4 protocol design.

## 1.3 Follow Up Consultation

Review the NMPA classification letter of intent and CMSA redundancy matrix to confirm they align with the scientific milestones. Discuss specific clinical trial endpoints required for first-in-human approval.

## 1.4.A Issue - NMPA Class III Device Classification Pathway Undefined

The plan treats Track C implants as research tools initially but targets commercialization without defining the specific NMPA device classification pathway. Class III implants require rigorous clinical evaluation and pre-market approval. Without a declared classification code and pre-submission strategy, later regulatory rework will delay market entry by years.

### 1.4.B Tags

- NMPA Compliance
- Device Classification
- Commercialization Risk

### 1.4.C Mitigation

Consult NMPA Medical Device Evaluation Center (MDEC) for pre-submission guidance. Read NMPA Guidelines for Clinical Evaluation of Medical Devices. Provide technical documentation for implant prototypes to verify classification code (e.g., 6846 for active implantable devices).

### 1.4.D Consequence

Program delays due to late-stage classification disputes and potential rejection of clinical trial data not aligned with device standards.

### 1.4.E Root Cause

Assumption that research data suffices for regulatory approval without early classification alignment.

## 1.5.A Issue - CMSA Spaceflight Redundancy Standards Not Integrated

CMSA life support systems require triple redundancy and specific fail-safe states that the current implant design lacks. The plan focuses on biological viability but ignores aerospace reliability standards. Without this alignment, CMSA will not certify the protocol for crewed missions regardless of biological success.

### 1.5.B Tags

- CMSA Safety
- System Redundancy
- Spaceflight Certification

### 1.5.C Mitigation

Consult CMSA Life Support Systems Engineering Office. Review ISO 24306 (Life Support Systems) and CMSA-specific safety margins. Provide engineering specs showing power, data, and thermal redundancy to match flight safety requirements.

### 1.5.D Consequence

Rejection of the human cryosleep protocol by CMSA, leaving the spaceflight goal unachievable even if biological revival works.

### 1.5.E Root Cause

Prioritization of biological metrics over aerospace engineering reliability standards.

## 1.6.A Issue - First-in-Human Trial Approval Timeline Missing

The plan moves from Tier 3 (large mammals) to Tier 4 (primates/humans) without specifying the Investigational Device Exemption (IDE) equivalent timeline. NMPA requires clinical trial approval before human exposure. Starting Tier 4 without filed regulatory applications creates a compliance gap that could halt the program mid-execution.

### 1.6.B Tags

- Clinical Trial Design
- Regulatory Approval
- Timeline Risk

### 1.6.C Mitigation

Consult National Medical Products Administration for clinical trial registration requirements. Read NMPA Measures for Drug and Medical Device Clinical Trial Management. Submit clinical trial application concurrently with Tier 3 completion to minimize regulatory delay.

### 1.6.D Consequence

Suspension of Tier 4 trials due to lack of regulatory clearance, wasting Tier 3 investments and delaying human protocols.

### 1.6.E Root Cause

Treating Tier 4 as pure research rather than regulated clinical investigation.

---

# 2 Expert: Bioethics and Animal Welfare Auditor

**Knowledge**: Primate cognitive assessment,animal welfare law,neuroethics

**Why**: Plan mandates strict welfare triggers for Tier 4 primate trials to prevent public backlash and legal compliance issues.

**What**: Validate cognitive function stop-gates and ethics board protocols.

**Skills**: Ethics review,welfare assessment,neuroethics monitoring

**Search**: primate research ethics auditor,animal welfare compliance specialist,neuroethics advisor

## 2.1 Primary Actions

- Establish an independent neuroethics board by 2026-12-31 with veto power over Tier 4 initiation.
- Revise euthanasia protocols to remove automated cognitive kill-switches and adopt physiological welfare markers.
- Conduct a formal 3R (Replacement, Reduction, Refinement) audit for NHP trials before Tier 4.

## 2.2 Secondary Actions

- Train all veterinary staff on recognition of distress in metabolically suppressed mammals.
- Publish a long-term monitoring protocol extending to 5 years for primate subjects.
- Consult international guidelines (e.g., IACUC, EU Directive 2010/63) for primate cognitive assessment standards.

## 2.3 Follow Up Consultation

Review the revised euthanasia protocol and 3R justification documents. Verify that physiological welfare indicators are operationalized for real-time monitoring during Tier 3 trials.

## 2.4.A Issue - Cognitive Thresholds for Euthanasia Are Ethically Unsound

The pre-project assessment proposes an automated stop-gate to euthanize subjects if post-revival cognitive function drops below 85% of controls. This metric is subjective in suspended states and risks delaying intervention until irreversible neural damage occurs. Using cognitive testing as a kill switch may cause additional distress to compromised subjects.

### 2.4.B Tags

- Animal Welfare
- Euthanasia Criteria
- Neuroethics

### 2.4.C Mitigation

Replace cognitive thresholds with physiological welfare markers (pain, distress, autonomic stability). Establish an independent neuroethics board to review euthanasia protocols case-by-case rather than algorithmic triggers. Consult the Guide for the Care and Use of Laboratory Animals for humane endpoints.

### 2.4.D Consequence

Regulatory shutdown, legal violations of animal welfare laws, public backlash, and scientific invalidity due to stress-induced cognitive decline confounding results.

### 2.4.E Root Cause

Lack of defined neuroethical framework for assessing suffering in metabolic suppression states.

## 2.5.A Issue - Insufficient 3R Compliance for Non-Human Primate Trials

Tier 4 escalation to non-human primates relies on Tier 3 gate success. The current plan lacks robust justification for why lower species cannot suffice at this stage. International standards require rigorous minimization of primate numbers and strict necessity proofs.

### 2.5.B Tags

- Primate Research
- Regulatory Compliance
- Ethical Review

### 2.5.C Mitigation

Conduct a formal 3R (Replacement, Reduction, Refinement) audit before Tier 4 initiation. Limit NHP numbers to absolute minimum. Ensure environmental enrichment and behavioral monitoring. Consult CAS Ethics Committee and international primate research guidelines.

### 2.5.D Consequence

Regulatory halt of Tier 4, loss of social license, and exposure of the program to ethical scrutiny.

### 2.5.E Root Cause

Overconfidence in scalability from rodents to primates without intermediate ethical review.

## 2.6.A Issue - Inadequate Post-Revival Neurological Surveillance

Current protocols measure cognitive recovery at 30, 90, and 180 days post-revival. For primates, chronic deficits, neurodegeneration, or behavioral changes may take years to manifest. Short-term monitoring does not guarantee long-term functional health.

### 2.6.B Tags

- Long-term Monitoring
- Neurodegeneration
- Study Design

### 2.6.C Mitigation

Extend post-revival monitoring for primates to a minimum of 5 years. Include comprehensive behavioral ethograms and neuroimaging beyond 180 days. Publish long-term data as required by international peer standards to validate human trial basis.

### 2.6.D Consequence

Undetected suffering in research subjects, invalid data for human safety standards, and potential liability from delayed adverse effects.

### 2.6.E Root Cause

Short-term milestone focus versus long-term welfare reality in neuroethics.

---

# The following experts did not provide feedback:

# 3 Expert: Biomedical Supply Chain Strategist

**Knowledge**: Cryoprotectant sourcing,chemical logistics,geopolitical trade risks

**Why**: Plan relies on specialized chemicals and implant components vulnerable to trade disruptions affecting Tier 1-4 timelines.

**What**: Audit dual-sourcing strategies for cryoprotectants and micro-pump parts.

**Skills**: Risk mitigation,vendor management,materials logistics

**Search**: biomedical supply chain risk manager,cryoprotectant sourcing specialist,chemical logistics auditor

# 4 Expert: Technology Transfer and IP Commercialization Lead

**Knowledge**: Dual-use licensing,medical device IP,venture revenue models

**Why**: Plan needs Track C implant commercialization to subsidize space research, requiring clear IP ownership and revenue-sharing.

**What**: Define IP governance structure for CAS-private licensee agreements.

**Skills**: Patent strategy,licensing negotiation,tech commercialization

**Search**: biomedical IP commercialization expert,technology transfer office director,dual use tech licensing specialist

# 5 Expert: Campus Infrastructure Project Manager

**Knowledge**: Cleanroom construction, biofacility design, project management

**Why**: Plan mandates Kunming campus with negative pressure rooms by 2027 to handle chemical hazards.

**What**: Oversee construction timelines and safety compliance for research facilities.

**Skills**: Facility engineering, safety compliance, timeline management

**Search**: biotech facility construction manager, cleanroom design specialist, biofacility safety

# 6 Expert: Bioelectronic Systems Engineer

**Knowledge**: Implantable device design, micro-pump engineering, neural interface

**Why**: Track C requires functional implantable life-support devices tested in Tier 2/3.

**What**: Validate prototype reliability and miniaturization for implant trials.

**Skills**: Hardware prototyping, embedded systems, biocompatibility testing

**Search**: implantable device engineer, biomedical hardware specialist, micro-pump design

# 7 Expert: Research Data Integrity and Cybersecurity Lead

**Knowledge**: LIMS architecture, data security, API standards

**Why**: Plan requires centralized data systems and encryption for implant design files.

**What**: Ensure LIMS deployment meets security and interoperability standards.

**Skills**: Data governance, cybersecurity, systems integration

**Search**: biomedical data security lead, LIMS implementation specialist, research data governance

# 8 Expert: Research Program Financial Officer

**Knowledge**: Public grant management, tiered budgeting, contingency planning

**Why**: ¥18B budget requires reallocation based on tier gates without disrupting flow.

**What**: Monitor budget variance and manage contingency reserves across tiers.

**Skills**: Financial controls, grant compliance, resource allocation

**Search**: research program financial officer, grant budget manager, public R&D finance