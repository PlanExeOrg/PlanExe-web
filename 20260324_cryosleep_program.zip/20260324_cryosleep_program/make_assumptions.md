
## Question 1 - How will the ¥18 billion budget be allocated across the three tracks and four tiers, and what specific contingency reserves are earmarked for Tier 4 failures?

**Assumptions:** Assumption: 60% of budget goes to R&D, 20% to infrastructure, 10% to contingency, and 10% to operations, with a 15% reserve for Tier 4 pivot.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluate budget stability against risks and allocation plans.
Details: Contingency reserves mitigate state funding cuts; risk of overspending on Tier 3 large mammals may drain reserves if Tier 3 gates fail prematurely.

## Question 2 - What are the precise go/no-go decision points for transitioning from Tier 2 to Tier 3, and how are delays in primate testing accounted for in the 15-year schedule?

**Assumptions:** Assumption: Assume Tier 1-2 take 6 years, Tier 3 takes 4 years, and Tier 4 takes 5 years, with 6-month buffers for regulatory delays.

**Assessments:** Title: Schedule Feasibility Assessment
Description: Evaluate timeline realism and buffer adequacy.
Details: Buffers account for regulatory delays; risk of Tier 3 failure extending program beyond 15 years without clear exit criteria for budget reclamation.

## Question 3 - How will the 500 FTE workforce be recruited and retained across the consortium partners, and what specific expertise gaps are being addressed for bioelectronics and cryobiology?

**Assumptions:** Assumption: Assume 70% of staff are recruited from existing CAS/university pools, 30% hired externally, with retention bonuses tied to milestone completion.

**Assessments:** Title: Talent Strategy Assessment
Description: Evaluate workforce stability and expertise coverage.
Details: Internal recruitment reduces cost; risk of talent poaching by private sector during later phases could destabilize Track C implant development.

## Question 4 - What specific mechanisms will ensure compliance with NMPA and international bioethics standards for primate trials, and how is IP ownership structured among CAS and university partners?

**Assumptions:** Assumption: Assume CAS holds majority IP rights, with universities retaining publication rights, and NMPA engagement begins at Tier 2.

**Assessments:** Title: Regulatory Compliance Assessment
Description: Evaluate legal and ethical framework for trials.
Details: Early NMPA engagement reduces approval risk; IP disputes could slow tech transfer if university rights conflict with state commercialization goals.

## Question 5 - What protocols are in place to mitigate cryoprotectant toxicity and thermal stress risks during rewarming, and how are animal welfare escalation triggers enforced?

**Assumptions:** Assumption: Assume cryoprotectant toxicity is manageable with existing protocols, and welfare triggers are enforced by an independent external committee.

**Assessments:** Title: Operational Safety Assessment
Description: Evaluate risk mitigation and ethical enforcement.
Details: Strict welfare triggers protect public trust but may limit optimization; toxicity protocols must be robust to prevent irreversible neurological damage in primates.

## Question 6 - What waste disposal and containment procedures are designed for cryoprotectant chemicals and biological samples to prevent local environmental contamination?

**Assumptions:** Assumption: Assume chemical waste is incinerated or neutralized on-site to prevent discharge into local water systems.

**Assessments:** Title: Environmental Risk Assessment
Description: Evaluate ecological impact of chemical handling.
Details: On-site neutralization is critical; regulatory penalties for spillages could halt operations at Kunming campus and damage consortium reputation.

## Question 7 - How will CMSA and private medical device partners be integrated into the review process without compromising academic transparency or national security requirements?

**Assumptions:** Assumption: Assume CMSA provides monthly review access, and private partners are restricted to licensing discussions until Tier 3 validation.

**Assessments:** Title: Partnership Dynamics Assessment
Description: Evaluate collaboration effectiveness and access control.
Details: Balancing transparency with security; risk of delays due to conflicting priorities between CMSA spaceflight needs and medical device market timelines.

## Question 8 - What data integration and lab management systems will be deployed across the distributed consortium sites to ensure protocol consistency and real-time monitoring?

**Assumptions:** Assumption: Assume a centralized cloud-based LIMS is deployed at Kunming HQ with offline capabilities for secure data handling.

**Assessments:** Title: Systems Integration Assessment
Description: Evaluate data reliability and synchronization.
Details: Centralized LIMS ensures consistency; cybersecurity risks for sensitive biological data require strict access controls to prevent unauthorized replication.