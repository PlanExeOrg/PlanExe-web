A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | State funding remains stable at ¥18B without significant cuts for the 15-year program duration. | Request explicit written budget continuity commitments from CAS and CMSA for Years 6-10. | CAS Finance Office issues a revised fiscal outlook reducing program allocation by 15% or more in the next 18 months. |
| A2 | Domestic suppliers can consistently meet cryoprotectant purity standards equivalent to global leaders. | Purchase pilot batches of domestic DMSO and ethylene glycol and submit to independent mass spectrometry. | Independent lab reports impurity levels exceeding 100ppm in more than 30% of tested domestic batches. |
| A3 | NMPA will classify Track C implants as Class III devices without requiring additional pre-market human trials beyond Tier 4 primate data. | Schedule pre-submission meeting with NMPA MDEC to draft classification code intent letter. | NMPA MDEC requires a separate human clinical trial phase before commercial device registration is permitted. |
| A4 | Retention of senior cryobiologists remains above 85% annually throughout the 15-year program. | Analyze current turnover rates against industry benchmarks for similar biotech firms. | Turnover of Tier 3+ staff exceeds 20% in the first 24 months. |
| A5 | Metabolic suppression protocols scale linearly from rodents to large mammals without unexpected toxicity or failure. | Run pilot toxicity assays on rabbit models using Tier 1 protocol formulations. | Rabbit survival rate drops below 60% during suspension trials. |
| A6 | Consortium partners maintain data interoperability standards without requiring major integration rework. | Conduct joint validation exercise across Kunming, Beijing, and Zhejiang data nodes. | Data mismatch rates exceed 5% in cross-institutional audit. |
| A7 | Public sentiment remains supportive despite increased animal welfare scrutiny during Tier 4 trials. | Conduct a national sentiment survey focused on cryobiology research ethics. | Negative media coverage regarding primate welfare increases by 50% within 6 months. |
| A8 | Implantable life-support devices maintain 99% reliability rates during 90-day suspension. | Perform accelerated life testing on micro-perfusion pumps under thermal stress. | Device failure rate exceeds 5% in continuous operation testing. |
| A9 | Intellectual property protections prevent competitor replication of Track C designs for 15 years. | Audit current patent filings and review international IP theft trends. | Competitors file similar device patents within 3 years of disclosure. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Fiscal Cliff Collapse | Process/Financial | A1 | Program Director | CRITICAL (20/25) |
| FM2 | The Chemical Contamination Catastrophe | Technical/Logistical | A2 | Infrastructure & Supply Chain Manager | CRITICAL (15/25) |
| FM3 | The Regulatory Gridlock | Market/Human | A3 | Regulatory Affairs Manager | CRITICAL (20/25) |
| FM4 | The Brain Drain Bottleneck | Market/Human | A4 | Program Director | CRITICAL (15/25) |
| FM5 | The Scale-Up Shock | Technical/Logistical | A5 | Cryobiology Research Lead | CRITICAL (15/25) |
| FM6 | The Siloed Consortium | Process/Financial | A6 | Data Systems Architect | HIGH (12/25) |
| FM7 | The Public Trust Erosion | Market/Human | A7 | Animal Welfare & Ethics Officer | CRITICAL (15/25) |
| FM8 | The Hardware Betrayal | Technical/Logistical | A8 | Bioelectronics & Implant Engineer | CRITICAL (15/25) |
| FM9 | The IP Leaks | Process/Financial | A9 | Technology Transfer & Commercialization Lead | HIGH (10/25) |


### Failure Modes

#### FM1 - The Fiscal Cliff Collapse

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Program Director
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
State budget cuts occur during Tier 3 (Years 6-9) when operational costs are highest. Contingency reserves are insufficient to cover the variance. Critical staff are laid off, and Tier 4 preparatory work halts. The program loses momentum and fails to reach commercialization milestones.

##### Early Warning Signs
- Annual budget variance exceeds 10% in two consecutive quarters
- CAS Finance delays disbursement by more than 60 days
- Technology transfer revenue is below 10% of target after Year 4

##### Tripwires
- State budget allocation drops by >= 15% in Q3 Year 5
- Cash reserves fall below 6 months of operational spend
- Key personnel exit rate exceeds 20% annually

##### Response Playbook
- Contain: Suspend non-essential Tier 3 animal trials and pause infrastructure expansion to conserve cash.
- Assess: Engage Finance Controller to audit Tier 4 reserves and model alternative licensing revenue scenarios.
- Respond: Submit emergency budget reallocation request to CAS Executive Committee and activate Tier 4 commercialization pivot.


**STOP RULE:** If state funding drops by more than 30% annually and contingency reserves are depleted, terminate Tier 3 trials immediately.

---

#### FM2 - The Chemical Contamination Catastrophe

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Infrastructure & Supply Chain Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Domestic cryoprotectants fail purity checks during Tier 2 and Tier 3 transitions. Toxicity causes high mortality rates in large mammals. Protocols must be redesigned, and imported chemicals are blocked by trade restrictions. The timeline slips by 3-5 years.

##### Early Warning Signs
- Domestic supplier batch purity variance > 20ppm
- Tier 2 small mammal toxicity reports show 15% increased mortality
- Export licenses for key materials are delayed > 90 days

##### Tripwires
- Domestic chemical purity fails 2 consecutive independent audits
- Tier 2 toxicity mortality exceeds 15% baseline by 10%
- Global shipping delays exceed 180 days for critical components

##### Response Playbook
- Contain: Halt all Tier 2 and Tier 3 chemical usage immediately and quarantine existing stock.
- Assess: Engage external toxicologists to verify impurity sources and biological impact.
- Respond: Switch to pre-vetted international stockpiles and initiate protocol redesign for alternative chemical solutions.


**STOP RULE:** If domestic chemical suppliers cannot meet 99.9% purity standards within 6 months and stockpile reserves are < 3 months, terminate Track B vitrification.

---

#### FM3 - The Regulatory Gridlock

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Regulatory Affairs Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
NMPA refuses to classify implants as Class III without human trial data. Track C commercialization revenue is blocked. The program relies entirely on state funding. Budget cuts arrive simultaneously, and the dual-use strategy fails. The program cannot pivot to medical revenue.

##### Early Warning Signs
- NMPA MDEC rejects Class III classification intent letter
- Technology transfer licensing negotiations stall > 12 months
- Medical device partners withdraw interest citing regulatory uncertainty

##### Tripwires
- NMPA classification intent letter delayed > 12 months from request
- Licensing revenue reaches 0% of target by end of Year 4
- CMSA fails to adopt protocols by 2028

##### Response Playbook
- Contain: Freeze all commercialization marketing and focus on academic publication to maintain credibility.
- Assess: Engage NMPA MDEC for formal clarification on data requirements for Class III approval.
- Respond: Launch parallel human safety study track if commercial pathway is confirmed closed.


**STOP RULE:** If NMPA requires separate human trials before Tier 4 primate data submission, terminate commercialization track and pivot to purely academic research.

---

#### FM4 - The Brain Drain Bottleneck

- **Archetype**: Market/Human
- **Root Cause**: Assumption A4
- **Owner**: Program Director
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Competitors offer significantly higher compensation and equity packages. Senior cryobiologists leave for private sector. Institutional knowledge disappears. Protocol execution stalls. Tier 4 validation delays by 6-9 months.

##### Early Warning Signs
- Unapproved resignation requests from 2+ Tier 3 staff
- Private sector job offers to key staff increase by 20%
- Retention bonus payouts increase without performance milestone

##### Tripwires
- Tier 3+ staff turnover exceeds 15% annually
- Key research roles remain vacant > 90 days
- Internal survey satisfaction score drops below 60%

##### Response Playbook
- Contain: Freeze non-essential hiring and secure retention bonuses for critical staff.
- Assess: Audit knowledge transfer status and document critical protocols immediately.
- Respond: Offer equity-like incentives and restructure career pathing to counter poaching.


**STOP RULE:** If senior staff turnover exceeds 30% annually and knowledge transfer cannot be secured, terminate Tier 4 human trials planning.

---

#### FM5 - The Scale-Up Shock

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Cryobiology Research Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Physiological scaling is non-linear. Large mammals suffer irreversible organ failure during suspension. Protocols must be redesigned. Tier 3 validation fails. Budget exhausted before Tier 4.

##### Early Warning Signs
- Rabbit survival rates drop below 75% in pilot trials
- Neural recovery benchmarks miss by > 10% in Tier 2
- Unexpected toxicity markers appear in 20% of subjects

##### Tripwires
- Large mammal revival rate drops below 60%
- Neural recovery benchmark < 80% of baseline
- Protocol iteration cycles exceed 5

##### Response Playbook
- Contain: Halt all Tier 3 trials and quarantine remaining subjects immediately.
- Assess: Deploy independent toxicology review to identify failure points.
- Respond: Pivot budget to Track A torpor or redesign chemical formulations for large mammal safety.


**STOP RULE:** If Tier 3 large mammal revival rate fails to reach 60% within 2 protocol iterations, terminate the program.

---

#### FM6 - The Siloed Consortium

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A6
- **Owner**: Data Systems Architect
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
Partner institutions maintain incompatible data standards. Tier 3 convergence requires massive manual rework. Validation timelines slip by 12-18 months. Costs rise by ¥500M+. State funding dependency extends without progress.

##### Early Warning Signs
- Data schema mismatches exceed 10% in quarterly audit
- Cross-site validation takes > 30 days
- Local infrastructure overrides standard protocols

##### Tripwires
- Consortium interoperability index drops below 75%
- Data integration costs exceed ¥50M per tier
- LIMS adoption rates < 80% across sites

##### Response Playbook
- Contain: Freeze all Tier 3 data submissions until schema alignment is verified.
- Assess: Deploy Data Systems Architect to audit all partner interfaces.
- Respond: Mandate binding steering committee enforcement and re-allocate budget to integration engineering.


**STOP RULE:** If interoperability index remains below 75% for two consecutive quarters and Tier 3 is impacted, terminate the program.

---

#### FM7 - The Public Trust Erosion

- **Archetype**: Market/Human
- **Root Cause**: Assumption A7
- **Owner**: Animal Welfare & Ethics Officer
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Media coverage highlights cognitive decline in primates. Public protests form outside facilities. CMSA halts approvals. The program loses social license. Tier 4 is permanently blocked.

##### Early Warning Signs
- Negative sentiment score on social media drops below 40%
- Number of NGO protests exceeds 5 per quarter
- NMPA public hearing attendance increases by 200%

##### Tripwires
- Media sentiment index drops below 30%
- Regulatory suspension notices issued by CMSA
- Protest group membership exceeds 5000 individuals

##### Response Playbook
- Contain: Pause Tier 4 trials immediately and issue transparent public statement.
- Assess: Commission independent third-party welfare review to verify cognitive metrics.
- Respond: Revise ethical protocols to prioritize long-term monitoring over immediate cognitive tests.


**STOP RULE:** If public sentiment index remains below 20% for two consecutive quarters, terminate Tier 4 trials permanently.

---

#### FM8 - The Hardware Betrayal

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Bioelectronics & Implant Engineer
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Micro-perfusion pumps fail during Tier 3 large mammal trials. Organ viability collapses. Protocols become useless. Hardware redesign is needed. Timeline slips by 2 years. Costs overrun by ¥500M.

##### Early Warning Signs
- Device failure rate > 2% in Tier 2 small mammals
- Thermal stress testing shows 50000 hours failure rate
- Vendor component batches show variance > 5%

##### Tripwires
- Tier 3 device failure rate > 10%
- Implant downtime exceeds 48 hours per subject
- Supply chain lead times for pumps > 120 days

##### Response Playbook
- Contain: Halt all suspension trials using current implant hardware.
- Assess: Engage hardware reliability experts to audit thermal and power redundancy.
- Respond: Shift budget to backup non-implant thermal management or redesign pump systems.


**STOP RULE:** If device failure rate exceeds 15% in Tier 3 validation, terminate Track C implant development.

---

#### FM9 - The IP Leaks

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Technology Transfer & Commercialization Lead
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
Competitors replicate Track C implant designs. Licensing revenue disappears. Dual-use strategy fails. State funding dependency remains high. Program financial model collapses.

##### Early Warning Signs
- Similar device patents filed by foreign entities
- Technology Transfer Office licensing revenue < 10% target
- Internal patent filing logs show unauthorized disclosure

##### Tripwires
- Competitor patents published within 18 months of disclosure
- Licensing revenue falls below ¥50M by Year 4
- Trade secret theft investigation opened

##### Response Playbook
- Contain: Immediately restrict data access and file emergency injunctions.
- Assess: Engage IP lawyers to audit infringement and calculate damages.
- Respond: Accelerate patent enforcement and pivot revenue model to service licensing.


**STOP RULE:** If competitor patents block licensing revenue by 2028, terminate commercialization track and pivot to open science publication.
