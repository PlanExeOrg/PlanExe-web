**Purpose:** business

**Purpose Detailed:** Development of a threat model, strategic playbook, and a sustainable TaaS offering for government and private sector partners to defend against ASI manipulation techniques.

**Topic:** DARPA program for ASI threat modeling and strategic playbook development with a Threat-as-a-Service (TaaS) sustainment capability.