This plan involves money.

## Currencies

- **USD:** Primary currency for budgeting, reporting, and transactions within the United States.

**Primary currency:** USD

**Currency strategy:** The project will primarily use USD for all transactions. No additional international risk management is needed as the project is based in the USA.