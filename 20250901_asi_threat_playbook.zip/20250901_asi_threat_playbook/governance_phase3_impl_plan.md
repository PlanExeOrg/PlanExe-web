### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Ethics Review Board.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics Review Board ToR v0.1

**Dependencies:**

- Project Plan Approved

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Plan Approved

### 4. Circulate Draft SteerCo ToR for review by DARPA Program Manager, Project Director, Chief Scientist, and Legal Counsel.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1

### 5. Circulate Draft Ethics Review Board ToR for review by Project Director, Ethicist, and Legal Counsel.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Ethics Review Board ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft Ethics Review Board ToR v0.1

### 6. Circulate Draft Technical Advisory Group ToR for review by Project Director, Chief Scientist, and AI/ML Experts.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1

### 7. Project Manager finalizes the Terms of Reference for the Project Steering Committee based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft SteerCo ToR v0.2

### 8. Project Manager finalizes the Terms of Reference for the Ethics Review Board based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics Review Board ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Ethics Review Board ToR v0.2

### 9. Project Manager finalizes the Terms of Reference for the Technical Advisory Group based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Technical Advisory Group ToR v0.2

### 10. Project Director formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 11. Project Director formally appoints the Chair of the Ethics Review Board.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics Review Board ToR v1.0

### 12. Project Director formally appoints the Chair of the Technical Advisory Group.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Technical Advisory Group ToR v1.0

### 13. Project Director confirms membership of the Project Steering Committee (DARPA Program Manager, Project Director, Chief Scientist, Ethics Review Board Chair, Independent Security Expert).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Appointment Confirmation Email
- Final SteerCo ToR v1.0

### 14. Project Director confirms membership of the Ethics Review Board (Ethicist (Chair), Social Scientist, Legal Counsel, Independent AI Ethics Expert, Representative from a Subscriber Agency).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Appointment Confirmation Email
- Final Ethics Review Board ToR v1.0

### 15. Project Director confirms membership of the Technical Advisory Group (Chief Scientist (Chair), AI/ML Engineers, Cybersecurity Experts, Data Analysts, Independent AI/ML Expert, Independent Cybersecurity Expert).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Appointment Confirmation Email
- Final Technical Advisory Group ToR v1.0

### 16. Project Manager schedules and facilitates the initial kick-off meeting for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation Email
- Final SteerCo ToR v1.0

### 17. Project Manager schedules and facilitates the initial kick-off meeting for the Ethics Review Board.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation Email
- Final Ethics Review Board ToR v1.0

### 18. Project Manager schedules and facilitates the initial kick-off meeting for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation Email
- Final Technical Advisory Group ToR v1.0

### 19. The Project Steering Committee reviews and approves the project scope, budget, and schedule.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Approved Project Scope
- Approved Project Budget
- Approved Project Schedule

**Dependencies:**

- Meeting Minutes with Action Items
- Project Plan Approved

### 20. The Ethics Review Board reviews and approves the initial customer vetting protocols.

**Responsible Body/Role:** Ethics Review Board

**Suggested Timeframe:** Project Month 2

**Key Outputs/Deliverables:**

- Approved Customer Vetting Protocols

**Dependencies:**

- Meeting Minutes with Action Items

### 21. The Technical Advisory Group reviews and approves the initial technical designs and architectures for the TaaS platform.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Month 2

**Key Outputs/Deliverables:**

- Approved Technical Designs and Architectures

**Dependencies:**

- Meeting Minutes with Action Items