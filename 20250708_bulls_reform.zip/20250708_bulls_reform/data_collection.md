## 1. Regulatory Timeline & Lobbying Cost Assessment

High risk (Risk 1) depends entirely on timely permitting. Understanding the political cost and timeline constraints (Missing Info 1) is immediately necessary to protect the July 2027 launch date.

### Data to Collect

- Specific regulatory milestones required by Pamplona City Council for festival site access (Music Venue & Stunt Zone).
- Estimated lobbying/liaison hours and associated budget required to secure all permits by Q1 2027.
- Precedent data on timeframes for securing multi-year venue access in Pamplona for similar large-scale events.

### Simulation Steps

- Use public municipal records databases (if accessible online) or comparable Spanish city planning portals to model standard permit timelines in Pamplona.
- Develop a Monte Carlo simulation to estimate the cost impact (%) of a 1-month delay in site access on fixed operational expenditures (Risk 1 modeling).

### Expert Validation Steps

- Consult the Senior Municipal & Regulatory Liaison (Role 4) with a preliminary timeline matrix derived from Step 1 to quantify required liaison expenditures.
- Consult the Cultural Transition Lead (Role 1) to align required permit deadlines for the Memory Pavilion with the overall 1-year launch mandate.

### Responsible Parties

- Senior Municipal & Regulatory Liaison (Role 4)
- Cultural Transition Lead (Role 1)

### Assumptions

- **High:** Pamplona's municipal review process adheres to Spanish national standards for public event permitting, allowing for acceleration via dedicated liaison effort.
- **Medium:** The Memory Pavilion construction permits can be synchronized with, or slightly follow, the main festival site permits without causing cascade failure.

### SMART Validation Objective

Secure a formalized, Council-vetted regulatory timeline matrix and an associated guaranteed lobbying budget ceiling from Role 4 by 2026-06-30.

### Notes

- This addresses the highest identified risk: Regulatory Paralysis. Immediate consultation minimizes reliance on slow-moving quarterly updates.


## 2. Year 2 Operational Cost & Pavilion Liability Seeding

Addressing Weakness #3 and Expert Review Concern #2. Without a funded plan for the long-term asset, the project risks immediate failure of its legacy component post-inauguration.

### Data to Collect

- Estimated annual operational expenditure (OpEx) required post-launch for the permanent, museum-quality Memory Pavilion (e.g., staffing, climate control, basic maintenance).
- Minimum retained profit target required from Year 1 gross revenue to cover Year 2 Pavilion OpEx.
- Revised financial modeling showing budget implications if the contingency buffer is drawn down by 25% in Year 1.

### Simulation Steps

- Develop a baseline NPV model for the Pavilion's OpEx over 10 years, based on comparable Spanish civic cultural centers.
- Use the Financial Controller's ERP simulation to model the impact of a 70% sell-through scenario on the retained profit allocated for Year 2 seeding.

### Expert Validation Steps

- Consult the Festival Financial Sustainability Modeler (Expert 7) to validate the assumed Year 2 OpEx figure and the required Year 1 retained profit target.
- Consult the Historical Archivist & Pavilion Project Lead (Role 8) to refine the OpEx assumptions based on content delivery needs.

### Responsible Parties

- Financial Controller & Contingency Manager (Role 5)
- Festival Financial Sustainability Modeler (Expert 7)

### Assumptions

- **High:** The core 40% contingency (~€10M) is NOT intended to sustain Year 2 operational costs, only Year 1 capital/operational risks.
- **Medium:** A fixed annual operational budget for the Pavilion (estimated at €400k/year) can be reliably met by retained corporate profit in Year 2.

### SMART Validation Objective

Finalize and approve a formal Year 2 Pavilion Operating Budget Model (including required profit seeding target) by the Month 8 operational review (Q1 2027).

### Notes

- This directly confronts the long-term sustainability gap identified in the review.


## 3. Music Talent Acquisition Strategy Revision

Expert review identified the co-production strategy as a critical revenue dependency risk (Threat 5/Issue 2.5). Regaining control over the primary draw is paramount.

### Data to Collect

- Revised talent acquisition strategy prioritizing either direct booking (Strategy 1/2) or a heavily modified co-production deal (Strategy 3).
- Financial commitment required (cash deposit vs. retained revenue share) to lock in one globally neutral Tier-1 headliner directly.
- Legal analysis summary of 'Minimum Quality Act' clauses, performance guarantees, and penalty structures in standard European promoter co-production contracts concerning revenue share.

### Simulation Steps

- Model the Year 1 budget impact of using €4.0M (from 60% hard cost) for a direct Tier-1 booking vs. the risk profile of retaining zero capital in the budget but granting 30% future revenue share to a promoter.
- Run scenario simulations on Ticket Velocity (70% target) under both options using established festival conversion rates.

### Expert Validation Steps

- Consult the Festival Curation & Talent Broker (Role 2) to immediately pause co-production settlement and engage the legal review.
- Consult the European Music Festival Promoter Relations Specialist (Expert 2) for immediate contract risk analysis (Issue 2.5).

### Responsible Parties

- Festival Curation & Talent Broker (Role 2)
- Financial Controller & Contingency Manager (Role 5)

### Assumptions

- **High:** The €4.0M capital allocation for direct booking is available within the 60% hard cost pool without violating the feasibility of the Memory Pavilion's initial capital expenditure.
- **Medium:** A Tier-1 neutral headliner can still be secured via direct booking within the required timeline (by end of June 2026).

### SMART Validation Objective

Finalize and obtain sign-off on the revised Talent Acquisition Strategy (modified Decision 5) by 2026-06-15, ensuring direct contractual control or a highly restrictive performance guarantee over Year 1 headliners.

### Notes

- This action directly addresses the promoter control failure identified by two separate experts.


## 4. Stunt Attraction Governance & 'Killer App' Definition

The secondary attraction is the project's only proprietary asset and requires immediate elevation from placeholder to 'Killer App' to drive overall appeal and mitigate quality risk (Threat 4/Issue 1.6).

### Data to Collect

- A finalized design brief for the Stunt Attraction's mandatory 'Killer App' routine, detailing required physical skills, required rehearsal hours, and required external directorial expertise.
- A funding plan specifying the non-contingency budget allocation (e.g., €750k from initial 60% pool) necessary to contract a world-class Physical Comedy Director.
- A revised Decision 13 sourcing policy specifying local execution but international artistic/choreographic oversight.

### Simulation Steps

- Role-play simulation: The Theatrical Attraction Director (Role 3) presents the 'Killer App' concept to the Cultural Transition Lead (Role 1) for immediate narrative alignment check (Decision 11/1 compatibility).
- Develop a training schedule variance model showing the timeline impact of specialized international directorial input vs. baseline local training budget.

### Expert Validation Steps

- Consult the Physical Comedy Choreographer and Director (Expert 4) to vet the proposed 'Killer App' design for feasibility and immediate impact potential (Issue 1.6).
- Consult the Cultural Transition Lead (Role 1) to ensure the stunt's theme supports the educational framing of the Memory Pavilion (Issue 1.4).

### Responsible Parties

- Theatrical Attraction Director (Role 3)
- Cultural Transition Lead (Role 1)

### Assumptions

- **Medium:** Sufficient specialized directorial expertise can be contracted within the required timeframe (Q4 2026) despite potential competition with major European established festivals.
- **Low:** Elevating the stunt quality through external hiring does not require increasing the total head count beyond the budgeted 15 local performers.

### SMART Validation Objective

Finalize the 'Killer App' directorial contract and obtain sign-off on the associated budget allocation by 2026-10-31.

### Notes

- This action leverages Opportunity #1 and directly mitigates Threat 4 by securing quality control at the design source.


## 5. Crisis Communication Protocol Establishment

Addressing Weakness 2 and Expert Concern #2. The slow engagement cadence must be supplemented immediately with agile crisis communication capabilities.

### Data to Collect

- A defined, operational 48-hour Rapid Response Protocol document identifying triggers, approvals, and signatory authority for communications.
- Budget re-allocation plan detailing how the existing €200k PR budget will be functionally deployed to staff the 3-person Rapid Response Team.
- A summary of existing legal/policy red lines that the Rapid Response Team must never cross (e.g., admitting fault on regulatory matters).

### Simulation Steps

- Conduct a tabletop simulation: If a major traditionalist group issues a formal boycott declaration, model the 48-hour response chain via the proposed protocol, tracking approval times.
- Map the 3-person team structure against the mandated role cover (Role 6 personnel) to ensure continuous coverage.

### Expert Validation Steps

- Consult the Crisis Communications Strategist (Expert 8) to draft the formal 48-hour protocol document.
- Consult the Community & Stakeholder Relations Specialist (Role 6) to confirm operational feasibility and compliance with Ministerial messaging (addressing Weakness 2).

### Responsible Parties

- Community & Stakeholder Relations Specialist (Role 6)
- Crisis Communications Strategist (Expert 8)

### Assumptions

- **Medium:** The existing €200k PR/Liaison budget is sufficient to fund the immediate hiring/retention of a specialized 3-person external rapid response team for a critical initial 6-month period.
- **High:** The Cultural Transition Lead (Role 1) will delegate appropriate narrative approval authority to the rapid response team for time-sensitive media responses.

### SMART Validation Objective

The 48-hour Rapid Response Protocol (including budget allocation and designated points of contact) must be fully operational and approved by Role 1 by 2026-06-15.

### Notes

- This is a crucial governance measure to prevent narrative drift between quarterly town halls.

## Summary

The project faces critical threats (Regulatory Paralysis, Revenue Dependency, and Narrative Weakness) requiring immediate clarification of three core areas: 1) Talent acquisition control, 2) Long-term asset sustainability, and 3) Crisis communications readiness. The most sensitive assumptions regarding fiscal control and external dependency (Talent Phasing) must be validated first. 

**IMMEDIATE ACTIONABLE TASKS:**
1. **Talent Control (High Priority):** Immediately pause the co-production settlement for Decision 5, allocate €4M contingency capital for direct booking of one Tier-1 headliner, and task Role 2/Role 5 with revising the talent strategy by 2026-06-15 (Data Collection Item 3).
2. **Crisis Readiness (High Priority):** Finalize and activate the 48-hour Rapid Response Communications Protocol, utilizing the existing PR budget to staff the team, to counter the slow engagement cadence by 2026-06-15 (Data Collection Item 5).
3. **Regulatory Security (High Priority):** Engage Expert 3 (Regulatory Liaison) immediately to lock down the critical regulatory timeline for permits by Q1 2027, informing all subsequent construction/operational planning, with initial data by 2026-06-30 (Data Collection Item 1).
4. **Sustainability Planning (Medium Priority):** Commission Expert 7 (Financial Modeler) to quantify the long-term liability of the Memory Pavilion, seeking a definitive Year 2 OpEx seed target by the Month 8 review (Data Collection Item 2).