**Verdict:** 🟢 USABLE

**Rationale:** The prompt describes a concrete, actionable project with clear constraints, a defined timeline (1 year), a specific budget (€25 million), and detailed requirements for the replacement events (music festival and low-infrastructure stunt comedy).