## Primary Decisions
The vital few decisions that have the most impact.


The vital few levers cluster around financial risk management, primary attraction delivery, and essential political negotiation. Critical levers are Budget Allocation (F64BC1F6), which governs risk tolerance, and Talent Investment Phasing (254C6B07), which drives initial revenue velocity. High-impact levers address the core cultural trade-off between Music Curation Style (F15917) and managing stakeholder consensus via Engagement Cadence (796783C2) and Sponsorship (3025C88C). The group addresses the tension between High Upfront Investment vs. Operational Buffer and Cultural Evolution vs. Political Placation.

### Decision 1: Cultural Memory Integration Strategy
**Lever ID:** `1cda49e9-5e15-4eb9-8192-cd2127efbde7`

**The Core Decision:** This strategy dictates how the project frames the cessation of the Running of the Bulls to ensure the cultural transition is perceived as evolution rather than outright abolition. Success means achieving moderate acceptance from traditionalists while simultaneously attracting progressive audiences. Metrics involve measuring public sentiment via targeted surveys regarding the new narrative framing and tracking participation rates across different demographic cohorts during the initial event.

**Why It Matters:** Framing the cessation of the bull run as an 'evolution' rather than an 'abolition' can soften initial resistance from traditionalists, encouraging moderate participation in the new festival. This requires dedicating significant physical space and early programming slots to archival exhibits, participatory heritage workshops, or commemorative ceremonies acknowledging the bull run’s history. However, overly reverent historical framing risks alienating younger residents and external progressive audiences who are the primary drivers for change, potentially leading to low attendance at the new centerpiece.

**Strategic Choices:**

1. Establish a permanent, museum-quality pavilion dedicated solely to the historical sociological context and archival footage of the bull run, positioning the festival as the next chapter of a continuous civic celebration.
2. Relegate all historical remembrance to peripheral, small-scale, one-time off-site events conducted weeks before the main festival to minimize perceived competition with the new attractions.
3. Integrate the performance elements of the historical run into the stunt-comedy format through stylized, scripted, non-animal interpretations that directly parody traditional elements during the main event structure.

**Trade-Off / Risk:** Directly incorporating historical rituals into the new festival structure risks confusing the transition message and angering hardline abolitionists, though low-key digital archives are unlikely to sway entrenched opposition.

**Strategic Connections:**

**Synergy:** It strongly amplifies Pre-Launch Community Ritual Succession Planning by providing the narrative justification needed for respectful continuity in new communal commemorations.

**Conflict:** It conflicts with Stunt Attraction Performative Style Calibration, as an overly reverent memory strategy might constrain the ability to use parody or satire in the new stunt show format.

**Justification:** *High*, This is critical for managing the core societal tension: transitioning culture without causing alienation. It directly governs the narrative framing that determines moderate success across demographics, impacting public adoption significantly.

### Decision 2: Stakeholder Engagement Cadence
**Lever ID:** `796783c2-7a3a-43e8-9293-464e4627cc0c`

**The Core Decision:** This lever defines the frequency and nature of communication channels used to manage external perceptions and internal alignment throughout the transition. The goal is maintaining narrative control while securing necessary political consensus without bogging down execution teams in constant scrutiny. Success is measured by delays attributed to political negotiation versus delays attributed to logistical failures, and by positive media framing related to transparency.

**Why It Matters:** Establishing a controlled, public-facing sequence for announcements manages narrative control, preventing reactionary criticism from dominating the planning phase and allowing the transition team to frame each milestone. An overly frequent engagement schedule, however, invites constant micro-scrutiny and opens the planning process to persistent lobbying from vested interest groups attempting to dilute the non-animal mandate. This directly impacts PR workload and the internal team's ability to execute focused development milestones.

**Strategic Choices:**

1. Implement a strict quarterly public town-hall schedule focusing exclusively on operational logistics, while all cultural messaging adjustments are handled via controlled Ministerial-level press releases delivered via a designated spokesperson.
2. Form a small, elite Civic Advisory Panel composed of influential traditionalists and arts leaders, meeting bi-weekly in private to negotiate minor programming concessions in exchange for public endorsements.
3. Launch a comprehensive, gamified digital platform allowing continuous anonymous submission of event ideas and concerns, filtering the high-volume input through an AI sentiment analysis tool before presenting actionable items monthly.

**Trade-Off / Risk:** The private advisory panel risks accusations of 'backroom dealing' that could undermine public trust, despite its potential utility in securing necessary political consensus for the cultural shift.

**Strategic Connections:**

**Synergy:** It directly supports Local Stakeholder Transition Sponsorship by establishing the necessary regular communication rhythm to secure and maintain buy-in from key community figures.

**Conflict:** An overly frequent or private engagement cadence conflicts with Budget Allocation Between New Assets and Operational Buffer, as constant lobbying requires dedicating more time/resources to PR than planned.

**Justification:** *High*, This lever controls narrative integrity and political friction. Its configuration dictates how effectively other strategic levers (like Sponsorship and Memory Integration) can be communicated, making it a central process hub.

### Decision 3: Budget Allocation Between New Assets and Operational Buffer
**Lever ID:** `f64bc1f6-0b75-4f79-8c18-1195ef8fe7c4`

**The Core Decision:** This governs the immediate financial risk profile by determining the split between immediate, high-quality asset investment (talent, infrastructure) and retained capital contingency. A balanced approach ensures the new centerpiece is attractive enough to drive adoption while protecting against unforeseen regulatory delays or minor infrastructure overruns typical of large urban projects. Success hinges on meeting artistic benchmarks without depleting the buffer before the critical midpoint review.

**Why It Matters:** Aggressively allocating the €25 million toward high-impact, one-off talent acquisitions and premium marketing shortens the time required to establish the festival's reputation and drive initial ticket sales, accelerating cultural adoption. Conversely, retaining a substantial operational contingency mitigates risk associated with sudden unexpected regulatory changes or necessary infrastructure reinforcement required by the municipality, protecting the project from mid-cycle insolvency. Underfunding the buffer jeopardizes the sustainability beyond the first year.

**Strategic Choices:**

1. Commit 75% of the total budget to upfront guarantees for headline talent, major site infrastructure deposits, and focused international media purchasing, accepting a minimal ten percent contingency reserve.
2. Allocate exactly 60% to hard costs and programming, reserving the remaining 40% as a strictly non-discretionary capital contingency fund that cannot be accessed before the operational review at month nine.
3. Front-load the largest expenditures onto securing long-term municipal leases and venue access agreements, structuring payments around performance milestones to limit upfront cash flow strain.

**Trade-Off / Risk:** A minimal contingency fund offers maximum immediate firepower for quality assets, but this strategy maximizes exposure to unforeseen logistical demands or unforeseen political interference requiring immediate capital response.

**Strategic Connections:**

**Synergy:** It enables Music Festival Talent Investment Phasing by determining the pool of capital available to secure headline acts early, thereby setting the expectation for overall festival quality.

**Conflict:** Aggressive investment in new assets directly conflicts with protecting the Operational Buffer, increasing vulnerability to unexpected demands stemming from Local Stakeholder Transition Sponsorship negotiations.

**Justification:** *Critical*, This is the primary resource constraint for the entire €25M project. It dictates the core trade-off between quality asset investment (festival draw) and financial resilience against unforeseen regulatory/logistical demands, making it foundational.

### Decision 4: Legacy Event Scheduling Priority
**Lever ID:** `c53a7050-aa76-4926-91b4-e9e7508b1607`

**The Core Decision:** This lever sets the temporal relationship between the final traditional event and the launch of the replacement festival centerpiece. The objective is maximizing narrative momentum by creating a clean, impactful transition point that forces public attention onto the successor event immediately. Success is gauged by media saturation metrics in the immediate week following the final run, favoring coverage of the new event over critiques of the old one.

**Why It Matters:** Scheduling the final Running of the Bulls event immediately preceding the launch of the new festival creates a clear, highly visible temporal break, allowing the cancellation/transition narrative to be immediately replaced by the launch narrative. This risks the momentum being overshadowed by intense, polarized media focus on the final bull run's controversies, potentially generating negative press that harms the new event's debut. Conversely, spacing the events too far apart allows the transition energy to dissipate, making the new festival feel disconnected from the core mission.

**Strategic Choices:**

1. Run the final bull run on July 6th and launch the new, concurrent music and stunt festival on July 7th, demanding immediate media and public focus pivot to the replacement event.
2. Delay the new festival launch until the following year to allow for a dedicated 12-month public campaign focused solely on the *cessation* announcement, ensuring the bull run's end is the primary news story.
3. Integrate the final bull-running events into a structured, multi-day civic celebration that transitions directly into the new festival's opening night ceremony without an explicit one-day break between themes.

**Trade-Off / Risk:** The immediate pivot generates maximum narrative crossover but risks the debut being perceived as a hastily organized post-mortem rather than a confident, established cultural offering.

**Strategic Connections:**

**Synergy:** It provides the crucial 'drop-dead' date necessary for coordinating the launch sequence of the Music Festival Curation Style and setting the tone for the entire project timeline.

**Conflict:** Scheduling the final run immediately before the new launch risks polarizing the audience, potentially conflicting with Cultural Memory Integration Strategy by making the transition feel too abrupt or confrontational.

**Justification:** *High*, This sets the temporal hinge of the entire strategic pivot. Scheduling determines narrative momentum and the immediate public focus, directly impacting the launch window's chance of success or failure.

### Decision 5: Music Festival Talent Investment Phasing
**Lever ID:** `254c6b07-a0dc-453d-8255-04539b9f9531`

**The Core Decision:** This lever determines the upfront financial commitment to securing the Music Festival's main appeal. Phasing dictates whether initial capital is spent securing high-profile, attention-grabbing talent early or held back for operational needs and assessing audience response to the new format. Key success metrics involve balancing immediate ticket velocity against maintaining sufficient contingency funding.

**Why It Matters:** The €25 million budget must fund both the one-time transition messaging and the ongoing festival structure, forcing a decision on talent booking timing. Booking major, expensive headliners early locks in high PR impact but consumes significant operational cash needed for contingency or improving the stunt attraction's staging quality later.

**Strategic Choices:**

1. Allocate sixty percent of the music budget immediately to secure two internationally recognized Tier-1 headliners for the first year to guarantee broad initial media coverage and sell-through velocity.
2. Reserve the entire music budget until month nine, focusing initial funding on infrastructure setup, only booking mid-tier, regionally dominant acts to test audience appetite for the new format first.
3. Enter into a long-term co-production agreement with a leading European festival promoter who guarantees talent placement in exchange for a share of future, non-guaranteed revenue streams.

**Trade-Off / Risk:** Aggressive upfront booking guarantees initial ticket sales and public attention, but it forces a significant depletion of contingency funds, exposing the project to severe risk if ancillary costs or unexpected logistical challenges arise.

**Strategic Connections:**

**Synergy:** This is amplified by Stakeholder Engagement Cadence, as early headliner booking provides tangible assets for initial stakeholder buy-in presentations.

**Conflict:** It directly conflicts with Budget Allocation Between New Assets and Operational Buffer, as high upfront talent investment depletes the necessary reserves for unexpected operational costs or staging improvements.

**Justification:** *Critical*, This is the timing mechanism for the most critical revenue/draw element (lever F15917). How the money for the main draw is spent over time directly controls exposure to financial risk versus PR impact.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Cultural Memory Preservation Medium
**Lever ID:** `55ce9a74-5d19-46d3-a4bc-ddfb868e5f5b`

**The Core Decision:** This determines the tangible form through which the city's cultural heritage relating to the bull run will be archived and honored post-cessation. The choice significantly impacts capital expenditure versus long-term operational commitment. The goal is selection of a medium that satisfies the core need for remembrance without consuming critical replacement infrastructure funds, measured by preservation artifact visibility and minimal ongoing maintenance costs.

**Why It Matters:** Defining the primary vehicle for honoring tradition dictates the tangible artifacts remaining after the bull run ends, influencing public acceptance. If physical relocation of historical sites is chosen over digital simulation, it consumes capital earmarked for festival infrastructure, potentially reducing the quality of the music acts. Conversely, prioritizing digital archiving requires complex, long-term maintenance contracts that shift cost from a one-time capital expense to a perpetual operational burden.

**Strategic Choices:**

1. Establish a permanent, high-touch physical museum adjacent to the historic route detailing the history and risk of the former event, ensuring tangible presence for older generations.
2. Develop a fully immersive, interactive virtual reality experience accessible globally that meticulously maps the historical routes and narrates the stories of past participants, prioritizing digital access over physical footprint.
3. Institute an annual, one-day academic symposium and historical reenactment performed by trained local historians using period-accurate, non-injurious props, dedicating the rest of the budget to the festival.
4. Fund dedicated academic studies on Basque heritage and regional identity, embedding the memory within ongoing educational structures rather than a singular dedicated attraction.

**Trade-Off / Risk:** The physical museum option anchors the budget heavily on real estate and construction, diverting funds from the urgent need to deliver a compelling new festival centerpiece capable of attracting a new audience segment.

**Strategic Connections:**

**Synergy:** The choice of medium directly impacts the narrative and physical framing pursued by the Cultural Memory Integration Strategy, guiding its execution across physical or digital domains.

**Conflict:** Prioritizing a permanent physical museum severely strains the Budget Allocation Between New Assets and Operational Buffer, as real estate and construction divert essential funds from the festival's premium offerings.

**Justification:** *Medium*, This is a specific outcome of the broader Cultural Memory strategy. While important for legacy, its primary impact is financial allocation (linking to Budget); it is less central than the narrative framing lever (1cda49e9).

### Decision 7: Stunt Attraction Performer Employment Model
**Lever ID:** `132643b8-9b0e-463c-8c61-e7c329994d09`

**The Core Decision:** This lever dictates the employment framework for the stunt-comedy performers, balancing long-term quality assurance against immediate financial flexibility. A fixed ensemble guarantees cohesive narrative and high performance chemistry throughout the festival, but incurs high fixed payroll costs year-round. Relying on short-term contracts maximizes cost savings during the off-season, but risks fragmented comedic timing and lower overall production value.

**Why It Matters:** The choice between full-time employment and short-term contracting affects the stability and quality of the recurring comedic performances throughout the festival run. Securing a core ensemble hired year-round guarantees consistent quality and enables deeper character development for the stunt-comedy narrative, but it introduces significant fixed salary overhead during the 11 months the festival is dark. Relying on rolling, high-rate guest specialists minimizes fixed payroll risk but risks performance fragmentation and a lack of integrated comedic timing across the multi-day event.

**Strategic Choices:**

1. Contract a single, established European physical theater troupe on a renewable three-year basis as the core attraction anchors, locking in quality but forfeiting flexibility in later curation.
2. Establish an open casting call process held six months before launch that hires independent contractors solely for the 10-day festival window, maximizing cost avoidance during off-peak periods.
3. Develop an in-house residency program where local acting students receive stipends to learn and perform simplified versions of the stunt material, prioritizing community integration over established professional polish.

**Trade-Off / Risk:** Hiring independent contractors for the short window maximizes immediate cost control, but the resulting lack of rehearsal time for complex comedic timing will likely result in a performance quality that fails to sufficiently replace the spectacle of the bull run.

**Strategic Connections:**

**Synergy:** Synergizes with Stunt Attraction Design Scope by defining the workforce capable of executing the necessary routines—a fixed troupe aids complex narrative. It also stabilizes the Stunt Attraction Performative Style Calibration.

**Conflict:** This conflicts with Budget Allocation Between New Assets and Operational Buffer by establishing higher fixed soft costs, potentially limiting funds for necessary operational buffers or music festival guarantees. It also constrains Stunt Attraction Performer Sourcing Policy flexibility.

**Justification:** *Medium*, This is primarily an HR and fixed-cost lever. It affects the consistency of the sub-attraction but is subordinate to the high-level decisions regarding the stunt design scope and the overall budget allocation.

### Decision 8: Music Festival Curation Style
**Lever ID:** `f15917a4-6e3c-45a9-90fc-243efeef5e81`

**The Core Decision:** This lever sets the artistic and demographic direction for the main music festival, which is the primary event centerpiece. The curation choice determines if the festival acts as a neutral revenue generator or as an active agent of cultural transition. Booking legacy acts secures immediate financial viability but risks appearing culturally stagnant; cutting-edge bookings risk early financial failure but strongly signal modernity.

**Why It Matters:** The style of music booked will directly influence the demographic reached, the required venue infrastructure, and the PR framing of the replacement festival. Booking established, nostalgic acts, while ensuring high initial attendance via known quantities, risks framing the event merely as a generic legacy concert, failing to drive the cultural transition mandate. Conversely, focusing exclusively on emerging, experimental genres cultivates critical acclaim but severely jeopardizes the first-year revenue targets necessary to prove the financial viability of the non-animal format.

**Strategic Choices:**

1. Prioritize sourcing established, high-draw European rock and pop headliners known for appealing to an older demographic to ensure immediate ticket sales recoup the initial investment.
2. Commission regional and international electronic music producers and performance artists to curate a forward-looking schedule emphasizing innovation and contemporary soundscapes, appealing to younger, non-traditional audiences.
3. Structure the lineup based on a rotational focus, dedicating one day strictly to contemporary Spanish/Basque artists and the second day to seeking one globally recognized, culturally neutral contemporary act.

**Trade-Off / Risk:** Focusing on established legacy acts guarantees ticket revenue for the first year, but this reliance confirms the fears of tradition supporters that the event is just a standard concert, undermining the deeper cultural replacement objective.

**Strategic Connections:**

**Synergy:** Works powerfully with Music Festival Talent Investment Phasing, as the curation style dictates which investment tiers are prioritized for securing headliners necessary to cover the cultural transition costs.

**Conflict:** Conflicts directly with Cultural Memory Integration Strategy; a purely avant-garde style may alienate community members who value cultural lineage, risking negative sentiment backlash and reduced local support.

**Justification:** *High*, As the project's central revenue driver and primary replacement centerpiece, the curation style defines the festival's demographic reach and cultural signal, directly impacting adoption and viability.

### Decision 9: Stunt Attraction Design Scope
**Lever ID:** `aca2c924-e300-4aa1-824a-7c1e40e0a5cd`

**The Core Decision:** This defines the degree of theatrical rigidity versus improvisational freedom within the human-scale stunt attraction. A highly scripted approach ensures repeatable quality and narrative integrity, key for audience satisfaction under high scrutiny. Conversely, allowing ample room for crowd interaction and spontaneity honors the unpredictability of the previous spectacle but introduces risks to safety compliance and overall artistic coherence across performances.

**Why It Matters:** The complexity and duration of the low-infrastructure stunt show directly impact the required lead time for performer training and the necessary site fit-out within the existing public spaces. Choosing a tightly choreographed, short-duration routine allows for maximum realism and repeatable quality through many daily shows, but it forces the music festival to carry the majority of the 'major event' weight. Opting for loosely structured, improv-heavy crowd interaction maximizes the perceived spontaneity and unique feel of each showing, but it introduces high variability in safety compliance and overall theatrical coherence.

**Strategic Choices:**

1. Design the 30-minute centerpiece attraction as a single, continuous, highly scripted physical comedy narrative requiring zero audience participation beyond observation, emphasizing theatrical precision.
2. Develop a modular performance structure allowing 60% of the show to be pre-scripted while leaving 40% open for controlled, timed interactions with crowds gathered in designated, safe zones.
3. Mandate that the attraction shifts daily themes based on local current events or performer interpretation, prioritizing high adaptability and performer autonomy over narrative consistency.

**Trade-Off / Risk:** Building a completely scripted routine guarantees high aesthetic quality for the stunt element, but the lack of organic spectator involvement means the attraction risks feeling static and failing to provide the dynamic, unpredictable energy that draws crowds.

**Strategic Connections:**

**Synergy:** Strong synergy exists with Stunt Attraction Performer Employment Model; a highly scripted design benefits greatly from having a consistent ensemble hired under a long-term contract for rehearsal integration.

**Conflict:** Directly trades off against Stunt Attraction Performative Style Calibration. A strictly scripted scope limits the performer autonomy needed to execute evolving comedic interpretations or community-responsive material.

**Justification:** *Medium*, This is a key design choice for the secondary attraction. It is important for fulfilling the 'low-infrastructure' goal, but the music festival's success is the primary driver of the €25M strategic goal.

### Decision 10: Pre-Launch Community Ritual Succession Planning
**Lever ID:** `02477803-e85b-4f48-97bd-6e877c63d1b1`

**The Core Decision:** This lever manages the immediate void created by removing the traditional pre-run rituals. Imposing a replacement quickly anchors the new festival structure but risks accusations of being prescriptive and inauthentic. Allowing a hiatus offers local groups agency but risks a narrative vacuum exploited by opponents or leads to disorganized, low-impact adjacency events failing to capture necessary public attention.

**Why It Matters:** Determining whether to immediately replace the traditional pre-run event rituals (like the 'txupinazo') with a formalized, state-sponsored observance or to allow a one-year gap where these adjacency events fade naturally impacts short-term local stability. If a replacement is immediately imposed, it consumes budget and risks superficial adoption, but leaving a vacuum might allow more radical, unmanaged local opposition to coalesce outside the festival's direct control.

**Strategic Choices:**

1. Formally petition the city council to immediately sanction and fund a new civic tradition observance to occupy the morning slot traditionally preceding the bull run during the transition year.
2. Intentionally leave the morning pre-run ritual slots vacant for the first year, allowing local community organizing groups to propose and execute their own small-scale, non-animal replacements for self-determination.
3. Integrate the music festival's opening ceremonies directly into the traditional morning schedule, positioning the main stage as the new civic gathering point replacing all prior adjacent activities.

**Trade-Off / Risk:** Establishing an immediate, top-down civic replacement risks creating resentment through perceived cultural appropriation, yet allowing a vacuum risks losing control over the public narrative space entirely during the critical first year.

**Strategic Connections:**

**Synergy:** Essential for establishing a strong foundation with Cultural Memory Integration Strategy by providing a concrete, scheduled time and place for new cultural narratives to begin taking hold immediately.

**Conflict:** This decision heavily influences Stakeholder Engagement Cadence; an imposed replacement may alienate local political figures who feel overlooked, while a policy of inaction might be seen as neglecting necessary local relationships.

**Justification:** *High*, This manages the immediate, sensitive narrative vacuum before the festival. Its configuration determines the initial tone of community agency and alignment with the Cultural Memory Strategy.

### Decision 11: Stunt Attraction Performative Style Calibration
**Lever ID:** `34930f47-3235-465a-ac6e-2a9386a3d991`

**The Core Decision:** This calibration sets the fundamental emotional tone of the low-infrastructure stunt attraction, determining if it emphasizes high-stakes physical comedy or visually echoes the structure of the previous event. A reliance on slapstick mitigates risk framing but requires exceptional comedic execution. Mimicking historical sequences risks accusations of superficial replacement, yet provides a familiar visual shorthand for immediate audience comprehension.

**Why It Matters:** The tone and physical lexicon of the stunt-comedy attraction directly influence its acceptance by audiences accustomed to high-stakes realism versus those seeking pure levity. Leaning into physical comedy reduces the perceived risk profile, which aids cultural acceptance but might fail to draw audiences seeking spectacle unless the comedic timing is exceptionally sharp, risking failure to compete with the drama of the prior event.

**Strategic Choices:**

1. Direct the stunt team to focus exclusively on elaborate, near-miss physical slapstick and low-level controlled chaos, emphasizing the performers' vulnerability and comedic reactions over any technical precision.
2. Mandate the inclusion of sequences that visually echo historical moments from the bull run, translating the danger into highly choreographed, controlled sequences featuring human protagonists overcoming benign obstacles.
3. Treat the attraction as a revolving roster of visiting international sketch comedy troupes, minimizing commitment to any singular, repeating visual identity, prioritizing variety over consistency.

**Trade-Off / Risk:** Emphasis on slapstick risks appearing juvenile and failing to justify its prime scheduling position, whereas direct visual echoes of the tradition may attract criticism for merely re-skinning the previous spectacle conceptually.

**Strategic Connections:**

**Synergy:** Synergizes well with Pre-Launch Community Ritual Succession Planning by offering a tone that can either contrast sharply with or subtly reference past events, setting the mood for the transition.

**Conflict:** If calibrated toward visual echoes of the old event, this lever strongly conflicts with Cultural Memory Preservation Medium, as it risks enshrining a superficial imitation rather than fostering genuine memory evolution.

**Justification:** *Low*, This lever modifies the tone of the secondary attraction. It is tactical optimization based on the primary scope decision (ACA2C924) and carries less systemic weight than festival curation or budget control.

### Decision 12: Local Stakeholder Transition Sponsorship
**Lever ID:** `3025c88c-e506-4763-8e70-e9a76db8551a`

**The Core Decision:** This strategic choice involves securing political capital by granting long-term, favorable status to incumbent local entities in exchange for public endorsement of the festival transition. Success is measured by the reduction in localized political resistance and achieving public perception as a consensus-driven project, rather than purely top-down imposition.

**Why It Matters:** Securing explicit endorsement from key traditional stakeholders, such as veteran hoteliers or local cultural associations, provides essential political cover for the transition, but their price for participation often involves demanding favorable, restrictive contracts for their continued service delivery.

**Strategic Choices:**

1. Offer multi-year, fixed-rate partnership contracts to a consortium of five established, traditional local businesses to exclusively manage all hospitality, security overnight operations, and vendor licensing for the new festival.
2. Bypass established stakeholder groups and implement an open, competitive bidding process for all ancillary service contracts, leveraging the budget to attract specialized international providers.
3. Establish a subsidized local incubator fund that awards seed capital exclusively to new, non-traditional micro-enterprises founded by residents under 30 to service the festival.

**Trade-Off / Risk:** Partnering with established local groups buys crucial short-term political calm but locks in potentially inefficient, high-cost long-term service agreements that burden the new festival's operating margins.

**Strategic Connections:**

**Synergy:** It strongly synergizes with Cultural Memory Integration Strategy, as established stakeholders can serve as trusted conduits for respectfully weaving legacy themes into the new event narrative.

**Conflict:** This conflicts with Local Business Integration Mandate if the negotiated sponsorship deals involve exclusive service rights that restrict open tendering or preference for newer, non-traditional local vendors.

**Justification:** *High*, This is the primary lever for securing crucial local political buy-in and risk mitigation from established interests, directly affecting the project's operability within the city structure.

### Decision 13: Stunt Attraction Performer Sourcing Policy
**Lever ID:** `ab0cc16f-5b7c-46a3-a84e-deda919b2952`

**The Core Decision:** This policy governs the human capital strategy for the low-infrastructure stunt attraction, balancing professional execution (external acts) against local economic benefit (training locals). The goal is to establish a reliable, context-appropriate comedic performance level that respects the 'human-scale' constraint while maximizing community value perception.

**Why It Matters:** The choice between hiring established, high-cost comedic physical performers versus training local talent impacts both the perceived quality and the community integration of the new attraction. Utilizing established touring acts guarantees a higher initial baseline of comedic timing and execution, likely securing positive early press coverage. However, reliance on external talent prevents the attraction from becoming a local employment opportunity, potentially inviting criticism of cultural appropriation or displacement.

**Strategic Choices:**

1. Secure a single, internationally recognized troupe specializing in physical comedy and clowning, ensuring highly professional execution but requiring expensive international contracts and riders.
2. Launch an immediate, intensive training conservatory in partnership with a Madrid-based physical theater school to develop a core troupe of local performers over nine months.
3. Source performers exclusively from existing local theatrical organizations and regional community theaters, focusing on adaptability and requiring significant in-house direction for physical coordination.

**Trade-Off / Risk:** Training local talent aligns with community benefit, but the inevitable learning curve introduces significant early execution risk that could undermine the comedy's effectiveness.

**Strategic Connections:**

**Synergy:** This aligns well with Stunt Attraction Performative Style Calibration by ensuring the hired talent possesses the foundational skills necessary to execute the desired comedic timing and physical challenges.

**Conflict:** Training local talent increases the timeline pressure on Pre-Launch Community Ritual Succession Planning, as the community needs reassurance that the new centerpiece will be ready on schedule.

**Justification:** *Medium*, Similar to employment model, this policy impacts the quality and community perception of the secondary attraction. It's secondary to the festival's high-stakes financing and curation decisions.

### Decision 14: Local Business Integration Mandate
**Lever ID:** `1294ab9a-6dba-46c1-82cc-c42e530a5363`

**The Core Decision:** This lever enforces a strict local procurement preference for non-core operational expenditures, prioritizing local economic impact over potential efficiency gains from international providers. Success involves maximizing verifiable local spending metrics without compromising essential logistics like festival security or infrastructure setup quality.

**Why It Matters:** Establishing strict mandates for integrating existing local hospitality and retail into the new festival structure affects the overall local economic benefit narrative versus vendor efficiency. Mandating that all non-core services (like catering and security) must utilize local Pamplona-based firms ensures maximum goodwill among established businesses, supporting the narrative of community uplift. This local preference, however, may lead to delays and service level inconsistencies compared to contracting with specialized, experienced international event providers.

**Strategic Choices:**

1. Institute a binding requirement that 80% of all non-talent operational expenditures, including construction and hospitality, must be contracted through pre-vetted businesses registered within the Navarran autonomous community.
2. Operate a completely self-contained vendor ecosystem utilizing pre-existing international contracts for all key operational logistics to ensure predictable execution quality on core delivery timelines.
3. Establish a profit-sharing incentive model linked to the festival's overall success, offering significantly reduced vendor fees to local businesses willing to assume a higher proportional financial risk.

**Trade-Off / Risk:** Mandating high local procurement guarantees supportive community optics, yet it subordinates execution reliability to local capability, threatening core event logistics control.

**Strategic Connections:**

**Synergy:** This powerfully reinforces Local Stakeholder Transition Sponsorship by ensuring tangible financial benefits flow directly to established, supportive local business sectors.

**Conflict:** It creates tension with the Music Festival Curation Style; if talented local vendors cannot meet the high-bar operational demands for a major international music festival, service quality may suffer.

**Justification:** *Medium*, This directly operationalizes the Local Sponsorship lever by dictating procurement, impacting local goodwill and operational efficiency. High impact on local narrative, but less direct impact on core revenue than curation.
