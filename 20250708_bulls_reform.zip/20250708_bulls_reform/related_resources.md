## Suggestion 1 - The Edinburgh Festival Fringe (Overall Transition Management & Scale)

The Edinburgh Festival Fringe is a massive, decentralized annual arts festival in Edinburgh, Scotland. While not involving the cessation of a traditional spectacle like a bull run, its complexity lies in managing hundreds of disparate, independent, and often radically different art forms (including physical comedy, theatre, and music) across a dense urban environment over several weeks. The scale involves managing massive logistical throughput, securing highly contested central venues, and balancing commercial success with artistic quality. The operational management of coordinating diverse content across a limited geographical footprint mirrors the challenge of managing a centralized music festival alongside localized, human-scale stunt attractions in Pamplona.

### Success Metrics

Maintaining high annual event volume (over 3,000 shows) despite severe temporal and spatial constraints.
Achieving high levels of international press coverage focusing on the diversity and quality of the arts program.
Effective management of city services (waste, security, transport) scaling up and down rapidly annually.
High satisfaction ratings for ease of access and navigation for attendees.

### Risks and Challenges Faced

Managing intense competition for limited central venue space and accommodation rates.
Ensuring performer safety and minimal friction with permanent city residents due to high temporary population density.
Maintaining artistic freedom and diversity while ensuring basic standards of commercial viability and health & safety across all venues.

### Where to Find More Information

Official Edinburgh Festival Fringe website (www.edfringe.com) for operational reports and governance structure.
Publications detailing urban impact studies related to large-scale annual city activations in Edinburgh.
Academic papers focusing on cultural sector management in constrained city environments.

### Actionable Steps

Contact the Fringe Society Administration/Operations Department via their official website contact channels to inquire about vendor onboarding processes and annual city liaison structures.
Seek academic case studies or industry white papers analyzing the logistical planning for the Fringe's dense programming schedule.
Identify specific event producers within the Fringe who specialize in physical theater or slapstick comedy to understand performer management similar to the Stunt Attraction (Decision 9).

### Rationale for Suggestion

This suggestion provides the best analogue for managing the sheer scale and output diversity of the *new* centerpiece (the major music festival and the theatrical stunt show) within a constrained urban environment (Pamplona). Specifically, the logistical complexity of coordinating numerous decentralized, unique performance styles across city streets directly informs the planning required for the human-scale stunt attraction and city-wide festival flow.
## Suggestion 2 - The Seville Expo '92 (Major Infrastructure Transition and Political Buy-in)

The 1992 Universal Exposition (Expo '92) in Seville, Spain, was a massive infrastructural undertaking designed to modernize the city and create lasting cultural/tourism assets, financed largely through public funds (€4.5 billion adjusted for inflation). The project required extensive negotiation with local, regional, and national political bodies, managing significant cultural expectations, and rapidly building out venues for a short-term event while ensuring long-term utility (e.g., the island site becoming a science park/business hub).

### Success Metrics

Successful hosting of the 6-month Expo event within budget and on time.
The successful post-event repurposing of the primary site infrastructure (a major planning success).
Significant increase in international tourism and business investment in Andalusia following the event.
Securing multi-level governmental consensus for land use and public financing.

### Risks and Challenges Faced

Significant political infighting and delays in securing final national government funding commitments (similar to Pamplona's need for political consensus - Decision 2).
Managing the environmental and social impact of rapid, large-scale construction in a historically sensitive region.
Ensuring the public felt ownership of the infrastructure investment post-event (legacy integration).

### Where to Find More Information

Official archives of The General Society for the New Millennium of Seville (SEAT '92).
Spanish government reports detailing infrastructure legacy funds and post-Expo site redevelopment.
Journalistic archives detailing the political negotiations required to secure the multi-tiered funding.

### Actionable Steps

Focus research on the Seville municipal/regional political negotiation teams active during 1987-1992 to identify precedents for managing large, sensitive public spending in Spain.
Identify the specific organizational units responsible for managing the transition from temporary event infrastructure to permanent city assets—relevant for the future viability of Pamplona's Memory Pavilion.
Review final budget allocation structures to understand how contingencies were managed against upfront construction risks, informing Pamplona's 60/40 split (Decision 3).

### Rationale for Suggestion

This project is essential because it is geographically and politically proximal (Spain) and deals directly with the high-stakes management of public spending (€25M in Pamplona vs. billions in Seville) and creating a lasting cultural utility out of a temporary event structure (the Memory Pavilion). It offers strong lessons in securing necessary *political buy-in* (Decision 2 & 12) for a disruptive, large-scale municipal project.
## Suggestion 3 - The Transition of the Winter Circus in France/Europe (Theatrical & Stunt Attraction Refinement)

Many traditional European circuses, facing declining attendance and increasing scrutiny over animal acts, have undergone multi-year transitions to human-centric spectaculars. For instance, Cirque Éloize (Canada, but heavily influential in Europe) or specific French companies that have entirely phased out large animal husbandry for acrobatic, clowning, and theatrical narratives. This transition involves repurposing established performance skills (physicality, timing) into sophisticated, non-animal narratives, directly addressing the required low-infrastructure, human-scale stunt-comedy attraction.

### Success Metrics

Achieving critical acclaim for new, non-animal shows based on physical prowess and narrative depth.
Maintaining consistent touring schedules and revenue streams despite high initial capital investment in retraining/new staging.
Successful framing of the new format as artistic evolution rather than loss of tradition.

### Risks and Challenges Faced

Retaining established audiences accustomed to historical performance staples (e.g., big cat acts or elephants).
The high operational cost and time required to train highly skilled physical performers to a professional standard (relevant to Decision 13/10 training locals).
Reconciling the narrative demands of traditionalist circus audiences with the desire for modern, progressive content.

### Where to Find More Information

Documentation related to the organizational shifts within major contemporary circuses like Cirque du Soleil or Cirque Éloize regarding their move away from traditional spectacle.
Interviews with physical comedians or narrative directors who specialized in translating high-stakes physical risk into theatrical comedy.
European arts council reports on funding sustainable, non-animal performance arts.

### Actionable Steps

Specifically analyze the rehearsal schedules and casting processes used by contemporary circuses to build their core acrobatic/clowning ensembles to inform the €800k training budget assumption for Pamplona's 15 performers (Assumption Q3).
Review critiques of early, poorly-received transitional circus shows to understand common pitfalls in the 'parody' vs. 'respectful evolution' balance (Decision 11 calibration).
Identify key performance directors known for blending physical humor and narrative structure to inform the Stunt Attraction's design scope (Decision 9).

### Rationale for Suggestion

This is the most technically relevant analogue for the *secondary* attraction: the human-scale stunt-comedy show. It provides real-world case studies on structuring, financing, and achieving quality in low-infrastructure, skill-based performance designed to replace high-spectacle, high-controversy events, directly informing the Stunt Attraction Design Scope (Decision 9) and Performer Sourcing Policy (Decision 13).

## Summary

The project requires balancing high-stakes cultural transition, rigorous fiscal prudence (€25M budget, 40% contingency), and the demanding logistics of launching two major parallel attractions (a Music Festival and a Stunt Show) within a single year in a geographically specific, politically sensitive city (Pamplona). The chosen strategy favors balanced evolution over aggression. The recommendations focus on three critical areas: 1) Large-scale logistical management within a dense city (Edinburgh Festival Fringe), 2) High-level political and financial navigation of major Spanish public works (Seville Expo '92), and 3) Technical guidance for executing the replacement stunt-comedy attraction through precedents in European theatrical transition (Contemporary Circus Models).