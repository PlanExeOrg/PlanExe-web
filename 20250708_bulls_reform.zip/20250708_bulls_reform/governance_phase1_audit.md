
## Audit - Corruption Risks

- Kickbacks paid to municipal planning officials or inspectors to expedite or bypass rigorous safety or zoning sign-offs required for the main festival venue or the permanent Memory Pavilion construction (dependency on securing permits by Q1 2027).
- Nepotism or preferential treatment in awarding the 80% mandated local procurement contracts (Decision 14) to favored local businesses or partners of political figures, regardless of their competence in critical areas like temporary infrastructure or security subcontracting.
- Bribery schemes involving the European festival promoter partner to influence the ultimate fee structure or revenue share in the co-production agreement (Decision 5), potentially leading to inflated service costs charged back to the project.
- Trading of favors concerning the Stakeholder Engagement Cadence (Decision 2), where private concessions are granted to the Civic Advisory Panel (Strategy 2) in exchange for public endorsements that may not reflect genuine community support.
- Misuse of funds earmarked for the operational buffer (€10M contingency) through unauthorized 'expediting fees' or undisclosed 'consultancy pay-offs' disguised as unforeseen logistics costs to award contracts quickly.

## Audit - Misallocation Risks

- Over-commitment of the €25M budget to high-cost, one-off Tier-1 music headliners through aggressive Talent Investment Phasing (Decision 5, Strategy 1), depleting the 40% Operational Buffer necessary for long-term sustainability and unforeseen retrofitting costs.
- Misallocation of budget intended for the physical stunt attraction infrastructure towards overly complex, expensive digital archiving (Memory Preservation Medium, Strategy 2), resulting in a high-quality digital asset but a deficient, low-impact physical centerpiece.
- Unauthorized diversion of funds from the contingency reserve during the first nine months (before the operational review) to cover operational shortfalls caused by inefficient, inexperienced local vendors mandated under the 80% Navarre procurement rule (Decision 14).
- Excessive or inappropriate use of funds allocated for PR/Liaison efforts (€200k) for non-essential lobbying or overly lavish private stakeholder meetings instead of proactive public reporting on operational wins.
- Inefficient allocation of capital resources toward creating a highly scripted, theatrical stunt attraction (Decision 9, Strategy 1) if it requires unforeseen high fixed payroll costs for a permanent ensemble (Decision 7, Strategy 1), straining the operational budget buffer beyond expected Year 1 break-even projections.

## Audit - Procedures

- Quarterly financial audit review focusing specifically on drawdown rates from the 40% Operational Buffer (€10M), requiring verification of supporting documentation for any expenditure exceeding 10% of the buffer outside of approved hard asset costs.
- Compliance review of procurement contracts (Decision 14) semi-annually (Month 4 and Month 9 milestone reviews) to verify that the 80% Navarre mandate is met, cross-referencing invoices against subcontractor validation to detect unauthorized subcontracting of critical services.
- Periodic review (pre-launch and post-inaugural event) of the Cultural Memory Integration Strategy's spend (Museum Pavilion) against its agreed narrative scope, ensuring construction quality meets 'museum-quality' standards stipulated in the pragmatic path selected.
- Contract audit focusing on the Music Festival Co-Production Agreement (Decision 5) to confirm adherence to the promoter's performance benchmarks, specifically tracking the 80% deferred payment schedule for artist fees against actual ticket sales velocity.
- Physical and documentary compliance audit of the Stunt Attraction safety protocols (Assumption Q5) immediately after contractor mobilization (Q4 2026) to confirm adherence to Spanish safety standards (1:50 ratio, temporary barricading), irrespective of the source (local or international sub-contractor).

## Audit - Transparency Measures

- Establish a public-facing dashboard tracking the utilization of the 40% Operational Buffer, updated monthly, showing retained balance and categorical usage (e.g., Retrofitting, Regulatory Compliance, Emergency Talent Reserve).
- Mandate that minutes from the private Civic Advisory Panel meetings (Decision 2, Strategy 2) detailing negotiated programming concessions are released to the public via Ministerial press release no later than 30 days after the quarterly town hall.
- Publish the full eligibility criteria and final vendor selection justification reports for the top 5 highest-value local procurement contracts awarded under the Navarre mandate (Decision 14) immediately upon contract signing.
- Create and publicly circulate a detailed narrative guide explaining the design choices and sociological framing of the Historical Memory Pavilion (Decision 1) to provide context for progressive stakeholders and counter potential accusations of superficial memorialization.
- Implement a formal, independently managed whistleblower channel (auditor-accessible) allowing staff and local vendors who suspect breaches related to the 80% local procurement mandate or contract favoritism to report concerns without fear of reprisal.