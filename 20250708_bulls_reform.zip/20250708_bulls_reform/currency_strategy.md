This plan involves money.

## Currencies

- **EUR:** The project is clearly located in Pamplona, Spain, which uses the Euro. The stated budget is denominated in Euros (€25 million).
- **USD:** Included as a stable international benchmark currency, although EUR is primary due to the location and budget denomination.

**Primary currency:** EUR

**Currency strategy:** Since the project is geographically confined to Spain (Eurozone) and the budget is explicitly denominated in Euros, EUR will be used for budgeting and all major transactions. Local transactions will also use EUR, eliminating significant foreign exchange risk exposure.