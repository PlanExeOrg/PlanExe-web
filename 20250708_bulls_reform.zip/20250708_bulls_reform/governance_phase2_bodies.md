### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** The project involves a €25M municipal cultural transformation with high political visibility and strategic risk (cultural friction, financial prudence). A PSC is essential for high-level strategic oversight, budget approval thresholds, and resolving conflicts between strategic goals (Pioneer vs. Builder).

**Responsibilities:**

- Approve all financial disbursements exceeding €1 million or 10% of the agreed operational buffer.
- Provide final sign-off on the Cultural Memory Integration Strategy and Legacy Event Scheduling.
- Oversee and accept/reject the Executive Director's performance reports quarterly.
- Approve major external contract awards (e.g., Promoter Co-Production Agreement).
- Resolve escalated governance conflicts from the Operational Management Group.

**Initial Setup Actions:**

- Finalize and ratify the PSC Terms of Reference (ToR), defining roles and escalation logic.
- Establish the formal €1M expenditure threshold for strategic review.
- Mandate a dedicated risk register review focusing on Political/Regulatory and Financial Risks (Risks 1 & 2).

**Membership:**

- Project Sponsor (Chair, Senior Municipal Executive)
- Head of Finance (Internal)
- Designated Senior City Council Liaison
- External Independent Governance Advisor (Non-voting)

**Decision Rights:** All decisions impacting strategic alignment, budget contingency draws over €1M, and mandated strategic levers (e.g., Cultural Memory Integration Strategy).

**Decision Mechanism:** Simple majority vote among voting members, with the Chair casting the deciding vote in case of a tie.

**Meeting Cadence:** Monthly for the first six months, then Quarterly.

**Typical Agenda Items:**

- Review of Strategic Risk Heat Map (Focus on External Political Sentiment)
- Approval of Capex releases against Milestone 1 and 2.
- Review of narrative framing adherence based on PR/Liaison reports.
- Escalations from the Operational Management Group.

**Escalation Path:** Unresolvable conflicts requiring resource reallocation beyond the €10M buffer or public political deadlock are escalated to the Mayor's Office/City Executive Board.
### 2. Operational Management Group (OMG)

**Rationale for Inclusion:** Given the project's complexity and tight 1-year timeline, operational decisions below the strategic threshold require a dedicated body to manage day-to-day execution, logistical oversight, and tactical risk response.

**Responsibilities:**

- Manage the tactical execution of the Budget Allocation (60% hard costs) and Talent Investment Phasing.
- Oversee day-to-day compliance with the 80% Local Procurement Mandate.
- Manage the Stunt Attraction design (Decision 9) implementation and performer scheduling.
- Control operational risk register and execute immediate mitigation actions for issues below €250k.
- Coordinate the Quarterly Town Halls (Decision 2).

**Initial Setup Actions:**

- Establish the operational decision rights threshold (€250k expenditure limit).
- Finalize the Procurement Oversight Charter aligned with Decision 14.
- Mandate the setup of the Rapid Response PR protocol (per governance audit).

**Membership:**

- Project Director (Chair)
- Lead Project Manager (Logistics & Timeline)
- Finance Controller (Internal)
- Head of Festival Curation
- Stunt Attraction Director

**Decision Rights:** All operational decisions, project schedule adjustments not causing >1-month delay, expenditure below €250k, and tactical risk mitigation below €1M cumulative impact.

**Decision Mechanism:** Consensus required. If consensus fails, the Project Director decision is binding, unless the decision causes a financial impact exceeding €100k, in which case it escalates to the PSC.

**Meeting Cadence:** Weekly.

**Typical Agenda Items:**

- Progress against physical milestones (Venue access, Pavilion foundation).
- Review of Operational Risk Register (Focus on Supply Chain Risk 5/Operational Risk 4).
- Stunt Performer training progress and quality assurance checks.
- Budget drawdown reports vs. weekly burn rate projections.

**Escalation Path:** Any unresolved issue, or any financial commitment exceeding €250k or threatening to draw down the Operational Buffer by more than 5% (€500k), must be escalated immediately to the Project Steering Committee (PSC).
### 3. Compliance and Assurance Panel (CAP)

**Rationale for Inclusion:** Due to high governance risks identified (corruption, misallocation) related to municipal contracts, procurement mandates (80% local), and environmental compliance (€500k cost, 60% diversion goal), an independent assurance body is required to uphold transparency and regulatory adherence.

**Responsibilities:**

- Conduct mandatory pre-approval review of all local procurement contracts over €50k (Decision 14).
- Audit compliance with Spanish Public Safety and EU Environmental Regulations.
- Manage the independent whistleblower channel for procurement misconduct.
- Review the payout schedule for the European Promoter co-production deal (Decision 5) semi-annually.
- Ensure transparency dashboard for Operational Buffer usage is accurate.

**Initial Setup Actions:**

- Establish formal auditing/review schedule (Month 4 and Month 9 milestones specified in audit).
- Vet and appoint an independent external auditor/compliance specialist.
- Finalize criteria for 'authorized subcontracting' under local procurement mandates.

**Membership:**

- External Independent Auditor (Chair, designated expert)
- Project Legal Counsel
- PSC Chair's Nominee (Internal, non-operational role)
- External Environmental Compliance Specialist

**Decision Rights:** The CAP has no disbursement authority but possesses the right to veto any contract or expenditure that fails to meet procurement compliance criteria or regulatory standards until the PSC overturns the veto.

**Decision Mechanism:** Unanimous agreement required for audit findings affecting major procurement contracts or regulatory adherence. If failed, the finding is escalated directly to the PSC with majority opinion noted.

**Meeting Cadence:** Pre-launch: Monthly; Post-launch: Quarterly.

**Typical Agenda Items:**

- Review of Buffer Drawdown Rate vs. Permitted Categories.
- Status of Regulatory Sign-offs (Permitting Risk 1).
- Whistleblower channel activity report (anonymized).
- Audit of high-value local vendor compliance.

**Escalation Path:** Direct, immediate escalation of any confirmed or highly suspected corruption or misappropriation of contingency funds to the Project Steering Committee (PSC) and the City Council’s internal audit office.