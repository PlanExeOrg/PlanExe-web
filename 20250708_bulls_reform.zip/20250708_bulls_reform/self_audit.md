Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 19 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 0 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is a cultural transition and event planning project that focuses on logistical, cultural, and creative substitution, which does not require the violation of any known laws of physics or dependency on non-physical causation.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel and highly complex combination of cultural substitution, high-stakes political negotiation, and aggressive short-term financial leverage, which the expert review confirms lacks independent evidence at scale. This combination creates existential failure modes.

**Mitigation**: Legal Team & Cultural Transition Lead: Run parallel validation tracks (Market/Demand, Legal/IP/Regulatory, Technical/Operational) to produce authoritative sources for talent control and municipal permits before Month 4 review. Define two NO-GO gates.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan introduces multiple undefined strategic concepts, such as 'Pragmatic Foundation' and specific decision strategies, without corresponding value hypotheses or detailed success metrics beyond basic KPIs. For example, 'Cultural Transition Management' importance is 5, but its success mechanism is vague.

**Mitigation**: Cultural Transition Lead: Produce one-pagers defining explicit inputs/process/value for 'Pragmatic Foundation' and 'Cultural Transition Management' within 45 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the detailed risk analysis shows the failure mode FM3 (Confused Cultural Mandate) is CRITICAL (16/25). This failure mode hinges on the incompatibility between the Museum Pavilion (Decision 1) and the Stunt Attraction style (Decision 11), which the plan fails to reconcile. The premise that 'The Pragmatic Foundation is the optimal choice' seems to rely on balancing contradictory goals.

**Mitigation**: Cultural Transition Lead & Theatrical Attraction Director: Mandate joint workshops to finalize a 'Tone Compatibility Document' detailing narrative boundaries between the Stunt Show and Memory Pavilion by Q3 2026.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents high-risk scheduling choices, notably integrating the final bull run with the new festival launch (Decision 4, Strategy 3), which one expert flagged as a 'dangerous narrative ambiguity' risking media overshadowing the pivot, violating the timeline's narrative integrity.

**Mitigation**: Cultural Transition Lead: Immediately decouple final run timing from launch; mandate the final run occurs at least three weeks prior to the July 2027 festival opening to create a clean narrative break.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on a 'long-term co-production agreement' (Decision 5, Strategy 3) to secure high-draw talent, which transfers control of the primary revenue driver to an external party; this indicates a lack of firm commitment/term sheets for headline acts, threatening the 70% sell-through target.

**Mitigation**: Talent Broker: Immediately halt co-production settlement for high-tier acts and reallocate €4M from the 60% hard cost pool to secure one globally neutral Tier-1 headliner via direct contract by 2026-06-15.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan commits to a permanent, museum-quality pavilion (Decision 1) without budgeting its perpetual operational costs, creating an unfunded and unaccounted-for long-term liability threatening sustainability post-Year 1.

**Mitigation**: Historical Archivist & Financial Controller: Finalize the Year 2 Pavilion OpEx model and present a mandatory Year 1 profit retention target to seed this liability by the Month 8 operational review.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan adheres rigidly to single point estimates for key performance projections, specifically a 70% sell-through rate (€18M gross) and a fixed 40% contingency buffer. The expert review identified the failure to model scenarios where revenue is missed or where the buffer is drawn early as a critical threat.

**Mitigation**: Financial Controller & Talent Broker: Produce a sensitivity analysis modeling event success at 55% and 85% sell-through rates, impacting contingency draw and Year 2 seeding targets, reported before Month 4 review.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the instruction mandates artifacts for build-critical components (specs, tests, contracts). The plan centers on complex creative and logistical builds (Stunt Attraction, Memory Pavilion, Festival Curation) but provides no explicit engineering artifacts outside of high-level strategy decisions and work breakdown tasks (WBS).

**Mitigation**: Theatrical Attraction Director & Historical Archivist: Produce detailed design specifications, interface contracts, and acceptance test criteria for the 'Killer App' stunt routine and the Memory Pavilion footprint by Q4 2026.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes critical claims (e.g., permanent museum; 40% buffer adherence) without evidence packs. Decision 1 claims a 'museum-quality pavilion' is central, but no supporting artifact (e.g., architectural brief, zoning consultation) is provided to verify its feasibility or long-term cost alignment.

**Mitigation**: Historical Archivist & Regulatory Liaison: Produce initial Pavilion zoning consultation documents and provide a preliminary CapEx ceiling estimate within 60 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project centers on multiple critical deliverables like the 'permanent, museum-quality pavilion' and the 'major music festival' without defined SMART criteria, creating high ambiguity regarding expected quality and acceptance.

**Mitigation**: Historical Archivist & Festival Curation Broker: Define SMART acceptance criteria for the Pavilion (e.g., HVAC performance or unique exhibit count) and the Music Festival (e.g., 70% sell-through KPI) within 60 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the introduction of a 'permanent, museum-quality pavilion' (Decision 1) adds significant, unfunded long-term operational liability, which conflicts with the pragmatic focus on fiscal prudence and the fixed €25M budget.

**Mitigation**: Historical Archivist & Financial Controller: Finalize the Year 2 Pavilion OpEx model and present a mandatory Year 1 profit retention target to seed this liability by the Month 8 operational review.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan's success critically depends on the 'Cultural Transition Lead & Project Sponsor' (Role 1), whose expertise is described as navigating complex Spanish public projects and consensus-building, a rare and essential skill for this volatile cultural overhaul.

**Mitigation**: Cultural Transition Lead: Conduct immediate external market validation to confirm the availability and typical contracting rate for experts matching Dr. Vargas's profile within 60 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan offers no evidence that legality is mapped; it mentions securing permits but omits control regimes, regulator identification, or cost/lead times, suggesting a reliance on slow communication that experts flagged as a fatal flaw.

**Mitigation**: Municipal & Regulatory Liaison: Develop and secure approval for a formal Regulatory Matrix detailing authorities, artifacts, and lead times for all listed permits by 2026-12-31.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because this addresses a critical, identified weakness: the long-term operational cost of the permanent Memory Pavilion is unfunded, directly threatening sustainability post-Year 1.

**Mitigation**: Historical Archivist & Financial Controller: Finalize the Year 2 Pavilion OpEx model and present a mandatory Year 1 profit retention target to seed this liability by the Month 8 operational review.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan's core strategy hinges on securing municipal permits, but the mitigation plan remains purely aspirational without quantifying the political friction or specific timeline acceleration costs required in Pamplona. The plan acknowledges high regulatory risk (Risk 1).

**Mitigation**: Municipal & Regulatory Liaison: Quantify the lobbying cost ceiling (e.g., €250k) needed as an incentive/accelerator to secure all Q1 2027 permits by 2026-12-31.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the evaluation criteria require evidence of contracts/SLAs plus *tested failovers*. The plan only mentions securing multi-year contracts (Decision 12) but provides no evidence of established SLAs or any documented process for testing external vendor failover resilience (e.g., security, infrastructure).

**Mitigation**: Logistics Coordinator & Financial Controller: Develop and execute a minimum of one failover test for critical local vendor services (security/power) using contingency funds by Month 8 operational review.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Finance Department (incentivized by Budget Allocation/Dec 3) seeks fiscal prudence, conflicting with R&D's (implied in Curation/Dec 8) need for high upfront talent spend to drive revenue velocity and narrative control.

**Mitigation**: Cultural Transition Lead & Financial Controller: Establish a shared OKR mandating Year 1 talent spend is tied to a pre-sale ticket metric, enforced by Month 4 review, within 90 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks explicitly defined KPIs, owners, and a change-control process with defined thresholds, despite relying on a slow engagement cadence (quarterly town halls) that expert reviews identified as insufficient for rapid narrative control.

**Mitigation**: Cultural Transition Lead: Establish a formal Governance Board responsible for a mandatory monthly review cadence, KPI dashboard, and a lightweight change control process with defined thresholds by 2026-07-15.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan combines ≥3 High-rated risk areas (Regulatory Paralysis, Talent Dependency, Unfunded Legacy Liability) that cascade: regulatory failure delays site access, forcing talent commitment decisions earlier, which exacerbates revenue risk and final contingency buffers.

**Mitigation**: Cultural Transition Lead: Establish mandatory combined heatmap/Risk Interdependency Map with GO/NO-GO thresholds for Risks 1, 6, and 7 by 2026-07-15.