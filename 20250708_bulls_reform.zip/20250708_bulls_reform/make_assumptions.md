
## Question 1 - What specific target attendance and revenue goals define the financial success of the Year 1 music festival within the €25M budget framework?

**Assumptions:** Assumption: Year 1 Financial Success is defined by achieving cash-flow neutrality by the end of the 10-day event window, requiring a minimum of 70% overall capacity sell-through across all music and stunt attraction ticket tiers, equating to approximately €18 million in gross ticket revenue.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluation of initial revenue velocity required to support the project's scale.
Details: Achieving €18M revenue target hinges on the delegated European promoter securing compelling headliners via the co-production agreement (Decision 5). If sell-through falls below 60%, the 40% Operational Buffer (€10M) will need to cover the €3.6M marketing/guarantee deficit, risking the sustainability of the Memory Pavilion construction schedule. Mitigation requires aggressive Q3 2026 marketing commencement.

## Question 2 - What is the concrete target date for securing all major site access licenses (Music Festival Hub and Museum Pavilion) to ensure the 1-year timeline is feasible?

**Assumptions:** Assumption: The 1-year project timeline (starting ASAP, May 2026) mandates that all primary physical sites, particularly the permanent Memory Pavilion, must have construction permits secured by Q1 2027 to allow for a July 2027 grand operational opening.

**Assessments:** Title: Timeline and Regulatory Nexus Assessment
Description: Analyzing the critical path dependency between political negotiation and physical groundbreaking.
Details: Risk 1 (Regulatory & Permitting) is High Likelihood. Successful integration of the final bull run (July 2026) and the new festival launch (July 2027) requires firming up the Museum Pavilion location by Q4 2026. Failure here forces the pivot narrative (Decision 4) to become strained, as the permanent anchor is missing. Opportunity exists to use the quarterly town halls (Decision 2) to announce regulatory wins as proof of progress.

## Question 3 - Given the choice to train local performers for the stunt attraction, what is the validated ceiling headcount and associated fixed payroll cost allocated within the €25M budget for the core ensemble?

**Assumptions:** Assumption: The chosen performer sourcing model (Decision 13) involves training a core ensemble of 15 local stunt performers for 9 months, allocated a fixed soft-cost budget of €800,000, representing roughly 3.2% of the total capital.

**Assessments:** Title: Personnel Capacity and Cost Control Assessment
Description: Evaluating the cost and skill reliability of the human capital dedicated to the secondary attraction.
Details: The €800k investment is relatively low compared to the expected festival revenue drivers, placing pressure on the training quality (Risk 4). If the local ensemble performs poorly, external recruitment may be necessary mid-cycle, requiring reallocation from the Operational Buffer (Risk 2). Benefit: Strong goodwill aligned with Local Stakeholder Sponsorship (Decision 12).

## Question 4 - What specific mechanism is in place within the Stakeholder Engagement Cadence to counteract immediate political backlash from traditionalists who publicly endorse the project but privately lobby against the memory pavilion's location or scope?

**Assumptions:** Assumption: The Ministerial-level press releases used in the quarterly cadence (Decision 2, Strategy 1) will be supported by direct, designated liaison officers assigned to manage the five most politically sensitive local councils, supported by a dedicated €200k PR/Liaison budget line item.

**Assessments:** Title: Governance and Political Mitigation Assessment
Description: Assessing controls against internal stakeholder sabotage.
Details: The risk of 'backroom dealing' undermining public trust is noted in Decision 2. Dedicated liaison officers are necessary to manage the tension between public messaging and private negotiation (Decision 12). A failure in this area constitutes a mid-level governance risk, potentially stalling permitting if key local politicians feel sidelined by the Ministerial framing.

## Question 5 - What specific, measurable safety protocols will bridge the gap between the low-infrastructure nature of the stunt attraction and managing public interaction, particularly concerning crowd control near the performers?

**Assumptions:** Assumption: The stunt attraction will utilize portable, but certified, temporary barricading systems and require a licensed security ratio of 1:50 spectators (per local Spanish public assembly standards) for all performance zones, costing approximately €400,000 for the 10-day event run.

**Assessments:** Title: Safety & Compliance Risk Assessment
Description: Evaluating infrastructure compliance for the human-scale spectacle.
Details: The low-infrastructure constraint heightens the risk associated with crowd dynamics (Risk 5). Given the mandated use of local providers, the €400k allocation must be strictly controlled and likely co-managed with an international safety consultant to ensure compliance despite local vendor limitations. This directly ties into Risk 5 mitigation requirements.

## Question 6 - How will the environmental footprint of hosting a major new music festival (power generation, waste management, temporary structure transportation) be assessed and managed relative to Pamplona’s municipal sustainability targets?

**Assumptions:** Assumption: The plan assumes adherence to standard EU festival sustainability guidelines, requiring a projected 60% diversion rate for solid waste and the exclusive use of renewable energy sources/biofuels for all on-site temporary power generation, a cost estimated at €500,000.

**Assessments:** Title: Environmental Impact and Green Strategy Assessment
Description: Analyzing resource consumption and compliance against municipal environmental standards.
Details: While not explicitly a primary driver in the strategic decisions, significant environmental expenditure (€500k estimate) falls under the Operational Buffer (Decision 3). Failure to hit the 60% diversion rate could trigger significant municipal fines, increasing Risk 1 volatility. Opportunity exists to frame this positive environmental performance as a key feature in the stakeholder engagement cadence (Decision 2).

## Question 7 - How will cultural memory integration (museum pavilion) be leveraged to secure endorsements from progressive stakeholders who view any ritualistic commemoration as inherently problematic?

**Assumptions:** Assumption: The Museum Pavilion (Decision 1, Strategy 1) will be framed not as a celebration of the event, but as a sociological, educational study of historical risk, public spectacle, and cultural anthropology, specifically targeting academic and high-brow cultural critics for support.

**Assessments:** Title: Stakeholder Segmentation and Messaging Assessment
Description: Tailoring the memory strategy to satisfy progressive critics while placating traditionalists.
Details: This assessment focuses on satisfying the complex requirement of preserving memory without endorsing spectacle. Success depends on clear messaging differentiation: one message for traditionalists (continuity) and an academic/critical message for progressives (evolution/study). This directly influences the success of the Cultural Memory Integration Strategy alignment with external progressive audiences.

## Question 8 - What are the critical, non-negotiable performance benchmarks required from the Music Festival Promoter partner (via Decision 5, Strategy 3) to guarantee that the co-production agreement remains operationally sound and doesn't compromise service quality?

**Assumptions:** Assumption: The co-production agreement mandates the promoter guarantees 80% of artist fees are paid via deferred payment structures tied to ticket sales milestones, and requires the promoter to personally underwrite 100% of any regulatory fines incurred in Year 1 due to talent scheduling or contractor disputes.

**Assessments:** Title: Operational Systems Reliability Assessment
Description: Defining contractual safeguards for the project’s primary revenue and operational system.
Details: The assumption places significant financial risk transfer onto the promoter, insulating the €10M buffer from promoter failure on talent delivery. However, this aggressive position introduces Risk 7 (Revenue Velocity based on promoter commitment). The operational team must implement robust tracking systems to monitor the promoter’s adherence to the 80% deferred payment schedule, integrating this into the quarterly review process.