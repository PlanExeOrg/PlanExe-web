# Purpose
# Project Plan Summary

## Purpose

- Business: Large-scale public/societal initiative.
- Budget: €25 million.
- Scope: Cultural and public welfare change in the city; major community transition project.

## Topic

- Replacing Pamplona's Running of the Bulls with a non-animal festival.


# Domain
# Project Plan Outline

## Primary Domain

- Cultural Transition Management

## Secondary Domains

- Festival Curation
- Public Finance
- Public Relations

## Rationale

- Cultural Transition Management is primary: success hinges on managing the sensitive shift away from the Running of the Bulls.
- Event Production and Theatrical Performance Directing are critical components supporting this goal.

## Disciplines Involved

- Cultural Transition Management: Importance 5, Specificity 5, Role outcome, Reason: Primary goal is managing sensitive cultural change away from the bull run.
- Event Production: Importance 5, Specificity 5, Role outcome, Reason: Core outcome is launching a high-quality, non-animal music and stunt festival.
- Theatrical Performance Directing: Importance 5, Specificity 5, Role outcome, Reason: Directly responsible for designing the core stunt-comedy attraction.
- Festival Curation: Importance 4, Specificity 4, Role outcome, Reason: Replacement centerpiece requires planning a major music festival component.
- Public Relations: Importance 4, Specificity 4, Role method, Reason: Managing social/political discourse around ending a tradition is critical.
- Historical Preservation: Importance 4, Specificity 4, Role constraint, Reason: Respectfully preserving cultural memory is a key requirement.
- Community Engagement Strategy: Importance 4, Specificity 4, Role method, Reason: Essential for navigating public shift away from a major tradition.
- Public Finance: Importance 4, Specificity 3, Role constraint, Reason: Fixed €25 million budget necessitates careful financial planning.
- Large-Scale Event Logistics: Importance 4, Specificity 3, Role method, Reason: Needed to organize music festival and stunt show logistics.


# Plan Type
# Project Constraints

## Physical Requirements

- Requires one or more physical locations.
- Cannot be executed digitally.
- Involves concrete, physical steps for cultural/festival transition.

  - Securing/preparing physical venues in Pamplona.
  - Constructing low-infrastructure staging for stunt-comedy attraction.
  - Managing physical logistics for major music festival (sound, staging, artist travel/accommodation).
  - Coordinating physical security and crowd control.

- Core activities (launching festival) depend on physical infrastructure/location (Pamplona).


# Physical Locations
# Project Plan: Physical Locations

## Requirements for physical locations

- Secure/prepare venues in Pamplona for a major music festival.
- Space for low-infrastructure, human-scale stunt-comedy attraction staging.
- Space for a permanent, museum-quality pavilion for historical/archival context.
- Accessibility and high capacity for large public events.

## Location 1

- Spain, Pamplona (Iruña), Navarre
- Plaza de Toros (Bullring Area) or surrounding grounds.
- Rationale: Core activity in Pamplona; established infrastructure capacity for festival hub.

## Location 2

- Spain, Pamplona City Center
- Designated City Streets/Parks for the Stunt-Comedy Attraction route.
- Rationale: Requires accessible, human-scale public space for controlled interaction; central parks/plazas offer flexibility.

## Location 3

- Spain, Pamplona (Navarre)
- Adjacent to the historical route for the Memory Pavilion.
- Rationale: Required for permanent, museum-quality pavilion; geographically linked to traditional events (near bullring/start of run) as a transition anchor.

## Location Summary
All primary locations must be in Pamplona, Spain.

- Location 1: Main Music Festival (existing large venue).
- Location 2: Adaptable, low-infrastructure Stunt-Comedy Attraction (central, flexible public space).
- Location 3: Permanent Museum Pavilion (historical memory integration).


# Currency Strategy
# Project Plan Summary

## Currencies

- EUR: Primary currency (Pamplona, Spain location; €25M budget).
- USD: International benchmark.

Currency strategy: EUR is primary for budgeting and transactions due to location and budget denomination, avoiding significant FX risk.

# Identify Risks
## Risk 1 - Regulatory & Permitting
Failure to secure municipal permits/venue access agreements within 1 year due to local political hesitance.
Impact: 3-6 month delay or festival downsizing; €3–€5 million overrun.
Likelihood: High
Severity: High
Action: Prioritize Decision 3, Strategy 3 (Front-load lease payments) and Decision 12 (Stakeholder Sponsorship). Dedicate regulatory team for weekly city council interaction; secure 2027 permits by Q4 2026.

## Risk 2 - Financial
40% operational buffer (€10 million) insufficient due to unforeseen retrofitting costs or higher upfront guarantee for music festival co-production talent.
Impact: Cuts to Stunt-Comedy or Memory Pavilion; potential €2–€4 million shortfall against €25M lifecycle spend.
Likelihood: Medium
Severity: High
Action: Strictly adhere to 40% contingency (Decision 3). Institute rigorous milestone-based release (Month 4, Month 9 reviews). Decision 5 agreement must tie talent payment phasing to ticket sales velocity.

## Risk 3 - Social & Cultural
Mobilized opposition from traditionalists causes demonstrations, boycotts, or vandalism targeting the stunt attraction or pavilion site.
Impact: Negative launch narratives; 20-30% initial ticket sales dip; operational disruption.
Likelihood: High
Severity: Medium
Action: Leverage Decision 1 (Museum Pavilion) as a cultural continuity anchor. Use quarterly communication (Decision 2) to preempt critiques and amplify local testimonials (Decision 12).

## Risk 4 - Operational
Stunt-Comedy Attraction fails quality expectations due to using in-training local performers (Decision 13, Strategy 2), clashing with cultural replacement mandate.
Impact: Secondary attraction fails; music festival bears 100% cultural weight; stunt perceived as afterthought.
Likelihood: Medium
Severity: Medium
Action: Invest heavily in specialized physical theater coaching during training. Design attraction scope (Decision 9) for modular, script-heavy content (Strategy 1) over high-risk improv.

## Risk 5 - Supply Chain / Vendor Management
Local vendor mandates (Decision 14) lead to using inexperienced local security/infrastructure for high-capacity festival.
Impact: Operational failure (crowd flow, setup/teardown); regulatory fines; event footprint scaling back.
Likelihood: Medium
Severity: High
Action: Require local vendors (via Decision 12) to subcontract specialized expertise from vetted international firms for core safety services while maintaining local contract value majority.

## Risk 6 - Integration / Transition
Transition structure (final run integrated with new opening) creates narrative collision; final bull run overshadows new opening ceremony.
Impact: Failure to achieve narrative pivot on July 7th; media focus remains on controversy; 15% ticket sales velocity impact.
Likelihood: High
Severity: Medium
Action: Mitigate via Decision 1 (Museum Pavilion) as a non-confrontational anchor. Use formal communications (Decision 2) to define the pivot point; minimize spontaneous media interaction July 6th-7th.

## Risk 7 - Financial / Revenue Velocity
Co-production model (Decision 5) yields poor Year 1 talent draw because promoter demands excessive revenue share, restricting marketing capital.
Impact: Inability to sell 70% of seats by Month 10; reliance on Operational Buffer.
Likelihood: Medium
Severity: Medium
Action: Establish strict internal ceiling (e.g., 20% revenue share max) for the promoter. Task Force must hold alternative direct talent agency discussions to quantify securing headliners directly.

## Risk 8 - Long-term Sustainability
Low-infrastructure stunt attraction proves unsustainable past Year 1 due to performer turnover or difficulty securing new scripts, causing audience fatigue.
Impact: Secondary attraction becomes redundant by Year 2; unsustainable reliance on music festival revenue.
Likelihood: Medium
Severity: Low
Action: Ensure employment model (Decision 7) prioritizes establishing a cohesive ensemble (Strategy 1). Allocate budget to develop a Year 3 infrastructure-heavy stunt concept pipeline.

## Risk summary
Project faces high risk in Regulatory/Political Friction, Cultural Adoption/PR Management, and Fiscal Prudence (maintaining buffer). Mitigation must focus on proactive engagement with Pamplona's municipal government and ensuring local procurement mandates do not compromise Music Festival operational quality.

# Make Assumptions
# Year 1 Music Festival Planning Summary

## Question 1 - Financial Success Goals

- Assumption: Financial success = cash-flow neutrality by end of 10-day event.
- Goal: Minimum 70% capacity sell-through, equating to approx. €18M gross ticket revenue.
- Assessment: Hinging on promoter securing headliners (Decision 5). Below 60% sell-through impacts the 40% Operational Buffer (€10M) by covering the €3.6M deficit. Mitigation: Aggressive Q3 2026 marketing commencement.

## Question 2 - Target Date for Site Access Licenses

- Assumption: 1-year timeline (start May 2026) needs construction permits for Memory Pavilion secured by Q1 2027 for July 2027 operational opening.
- Assessment: Regulatory/Permitting Risk is High Likelihood.
- Details: Must firm up Museum Pavilion location by Q4 2026 to avoid straining the pivot narrative (Decision 4). Use quarterly town halls (Decision 2) to announce regulatory wins.

## Question 3 - Stunt Attraction Headcount and Payroll

- Assumption: Training 15 local stunt performers for 9 months.
- Allocation: Fixed soft-cost budget of €800,000 (approx. 3.2% of capital).
- Assessment: €800k is low, pressuring training quality (Risk 4). Poor performance necessitates external recruitment, drawing from Operational Buffer (Risk 2). Benefit: Goodwill via Local Stakeholder Sponsorship (Decision 12).

## Question 4 - Political Backlash Mitigation Mechanism

- Assumption: Ministerial press releases (Decision 2, Strategy 1) supported by designated liaisons for five sensitive councils.
- Budget: Dedicated €200k PR/Liaison budget.
- Assessment: Risk of 'backroom dealing' undermining trust noted in Decision 2. Liaisons manage tension between public messaging and private negotiation (Decision 12). Failure is mid-level governance risk, potentially stalling permitting.

## Question 5 - Safety Protocols for Stunt Attraction

- Assumption: Utilize certified temporary barricading and 1:50 spectator security ratio (Spanish standards).
- Cost: Approx. €400,000 for 10 days.
- Assessment: Low-infrastructure constraint heightens crowd dynamics risk (Risk 5). €400k must be co-managed with international safety consultant due to local provider reliance.

## Question 6 - Environmental Footprint Management

- Assumption: Adherence to EU guidelines: 60% solid waste diversion; exclusive renewable energy/biofuels for temporary power.
- Cost Estimate: €500,000.
- Assessment: Environmental expenditure falls under Operational Buffer (Decision 3). Failure to hit 60% diversion risks municipal fines, increasing Risk 1 volatility. Opportunity: Frame positive environmental performance in stakeholder cadence (Decision 2).

## Question 7 - Leveraging Cultural Memory Integration for Progressive Stakeholders

- Assumption: Museum Pavilion (Decision 1, Strategy 1) framed as a sociological, educational study of historical risk/spectacle, targeting academic critics.
- Assessment: Depends on clear messaging differentiation: continuity for traditionalists, academic study for progressives. Influences alignment with external progressive audiences.

## Question 8 - Promoter Performance Benchmarks (Decision 5)

- Assumption 1: Promoter guarantees 80% of artist fees via deferred payments tied to ticket sales milestones.
- Assumption 2: Promoter underwrites 100% of Year 1 regulatory fines from talent/contractor disputes.
- Assessment: Risk transfer insulates the €10M buffer from promoter failure on talent delivery. Introduces Risk 7 (Revenue Velocity based on promoter commitment). Requires robust tracking of the 80% deferred payment schedule in quarterly reviews.


# Distill Assumptions
# Project Plan Summary

## Financial Targets

- Year 1 success: €18 million gross ticket revenue, 70% sell-through.
- Total budget: €25 million investment.
- Budget Allocation: 60% hard costs, 40% contingency.
- Contingency fund access restricted until month nine operational review.

## Key Deliverables & Timeline

- Timeline: One year, targeting July 2027 operational opening.
- Site licenses (including museum) secured by Q1 2027.

## Stunt Attraction Requirements

- Structure: Low-infrastructure, human-scale.
- Content: Slapstick, comedic physical vulnerability.
- Exclusions: No extreme sports, pyrotechnics, robotics, or construction.
- Safety & Security: 1:50 security ratio, certified temporary barricades (portable systems).

## Operations & Logistics

- Stunt Performers: 15 local performers, 9 months training, cost €800,000.
- Power: Temporary power cost €500,000, must use renewable biofuels.
- Waste: Assumed 60% waste diversion rate.
- Procurement: 80% of non-talent ops spending mandated within Navarre.

## Stakeholder & Regulatory Engagement

- Communication: Quarterly town halls; Ministerial press releases supported by €200k for liaison officers.
- Cultural Framing: Memory pavilion framed as sociological study to secure progressive support. Transition framing aims for moderate acceptance by traditionalists.

## Governance & Agreements

- Strategy: Project avoids the most aggressive strategic scenario.
- Promoter Agreement: 80% artist fees deferred; promoter underwrites Year 1 fines.
- Talent Acquisition: Headliners secured via long-term co-production revenue-share agreement.

## Legacy & Transition

- Legacy: Managed via a permanent, museum-quality historical pavilion.
- Festival Transition: Replacement festival pivots away from the final bull run immediately after; final bull run transitions directly into the new festival opening ceremony.


# Review Assumptions
## Domain of the expert reviewer
Large-Scale Cultural Transition and Public Project Management

## Domain-specific considerations

- Political & Cultural Stakeholder Management in Tradition-Heavy Contexts
- Financial Resilience for Novel, High-Visibility Public Initiatives
- Logistical Planning for Large City-Center Festivals
- Narrative Control and Societal Acceptance Metrics

## Issue 1 - Missing Assumption: Sustainability of Revenue (Post Year 1)

- Plan assumes Year 1 goals (€18M revenue, 70% sell-through) cover €25M investment.
- Missing: Guaranteed funding mechanism for Year 2+.
- €10M operational buffer is Year 1 contingency, not Year 2 costs.
- Museum-Quality Pavilion (long-term liability) threatened if Year 1 only breaks even.
- Recommendation: Establish Year 2/3 financial model. Pavilion needs fixed annual €400K operational budget. Target 15% retained profit (€3.75M) in Year 1 after contingency to seed Year 2 fund. Adjust talent phasing or cap Pavilion fit-out if necessary.
- Sensitivity: Break-even Year 1 means immediate €400K operational gap for Pavilion in Year 2, drawing down Year 1 contingency buffer by 10% (~€4M remaining). ROI timeline collapses without Year 2 funding mechanism.

## Issue 2 - Unrealistic Assumption: Complete Narrative Control via Bandwidth-Limited Engagement

- Stakeholder Engagement Cadence (quarterly town halls, Ministerial press releases) assumes narrative control is maintainable.
- Low bandwidth engagement cannot counter rapid criticism.
- Relying only on Ministerial releases risks 'backroom dealing' perception regarding sponsorship transparency.
- Recommendation: Augment quarterly cycle with structured 'Rapid Response' protocol. Deploy task force post-decision (talent, location) within 48 hours using PR Liaison budget (€200k). Publicly link Local Stakeholder Sponsorship milestones to quarterly reports.
- Sensitivity: Unchallenged negative sentiment for 90 days may increase media saturation by 40-60%, causing 10-15% slump in initial ticket sales velocity (loss of €1.8M - €2.7M in Year 1).

## Issue 3 - Under-Explored Assumption: Impact of Local Procurement Mandates on Quality and Timeline

- Decision 14 mandates 80% of non-talent OPEX stay in Navarre (supports Decision 12).
- Assumptions only vaguely estimate cost (€400K for security staffing) and note 'service level inconsistencies.'
- Critical missing detail: Time penalty for vetting/overseeing less experienced local vendors (fencing, catering, construction oversight).
- Recommendation: Conduct 'Local Vendor Capability Audit' for top 5 procurement categories. Bake in 15% administrative overhead contingency for QA/rework queues for mandatory local vendors. If gaps found, adjust decision to require local vendors to subcontract proven international expertise for critical elements.
- Sensitivity: 5% overhead on hard/operational costs (~€12M of €25M total) adds €600,000 management cost, drawing down Operational Buffer. One-month delay due to contractor mobilization (Risk 1 dependency) costs ~€150,000 in holding costs.

## Review conclusion

- Plan shows strong strategic alignment in narrative management and fiscal prudence (40% buffer).
- Three critical gaps must be addressed:
- 1. No defined Year 2 budget threatens the long-term asset viability (Pavilion).
- 2. Assumed narrative control based on slow cadence is politically naive; needs proactive media response systems.
- 3. 80% local procurement mandate introduces unquantified risk of timeline delays and quality overhead drawing on contingency funds.
- Addressing these unknowns is vital before executing.
