This plan implies one or more physical locations.

## Requirements for physical locations

- Securing and preparing physical venues in Pamplona for a major music festival.
- Space for low-infrastructure, human-scale stunt-comedy attraction staging.
- Space for a permanent, museum-quality pavilion dedicated to historical/archival context.
- Accessibility and high capacity for large public events.

## Location 1
Spain

Pamplona (Iruña), Navarre

Plaza de Toros (Bullring Area) or surrounding grounds for the main festival hub.

**Rationale**: The core activity must take place in Pamplona. The former bullring area or adjacent city grounds are historically central to the event and offer existing infrastructure capacity suitable for a transition festival hub.

## Location 2
Spain

Pamplona City Center

Designated City Streets/Parks for the Stunt-Comedy Attraction route.

**Rationale**: The low-infrastructure stunt attraction requires accessible, human-scale public space that allows for controlled crowd interaction but avoids major construction. Central city parks or large plazas offer the necessary flexibility.

## Location 3
Spain

Pamplona (Navarre)

Location adjacent to the historical route for the Memory Pavilion.

**Rationale**: The chosen 'Pragmatic Foundation' strategy requires establishing a permanent, museum-quality pavilion for cultural memory integration. This site should be geographically linked to the traditional events (often near the bullring or the start of the run) to serve as a transition anchor.

## Location Summary
All primary locations must be situated within Pamplona, Spain, dictated by the project's focus. Location 1 is for the main Music Festival (utilizing existing large venue capacity). Location 2 is for the adaptable, low-infrastructure Stunt-Comedy Attraction requiring central, flexible public space. Location 3 is required for the permanent Museum Pavilion dedicated to historical memory integration.