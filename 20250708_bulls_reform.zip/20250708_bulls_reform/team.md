*Roles Needed & Example People*

# Roles

## 1. Cultural Transition Lead & Project Sponsor

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Cultural Transition Lead is the central authority responsible for long-term strategy, stakeholder consensus, and narrative control throughout the 1-year project; this requires deep organizational embedding and loyalty.

**Explanation**:
Serves as the ultimate authority, responsible for integrating the strategic decisions (especially Cultural Memory and Engagement) into a unified narrative acceptable to the city. Drives the political mandate across the 1-year timeline.

**Consequences**:
Lack of unified vision; failure to reconcile traditionalists with progressives, leading to public backlash and potential project derailment due to political friction (Risk 3).

**People Count**:
1

**Typical Activities**:
Chairing weekly steering committee meetings; directly formulating the messaging for Ministerial press releases (Decision 2); serving as the final adjudicator on disputes between the Music Festival and Stunt Attraction teams; reporting directly to the Project Governance Team on political risk levels (Risk 3 & 6).

**Background Story**:
Dr. Elena Vargas, hailing from Seville, brings over two decades of experience navigating complex Spanish public projects, having served briefly as an aide during the politically fraught closure of industrial sites in Andalusia before moving into cultural transformation consulting. With a PhD in Political Sociology from Complutense University, her expertise lies in consensus-building and framing controversial policy changes without triggering outright opposition, skills honed by managing the delicate political choreography surrounding major infrastructural shifts reminiscent of the Seville Expo '92 legacy planning. She is intimately familiar with the high-stakes risk of narrative conflict (Decision 6) and is essential for driving the overall vision and securing high-level municipal acceptance for this 1-year mandate.

**Equipment Needs**:
Secure, high-bandwidth video conferencing suite for sensitive international/ministerial negotiations; Dedicated secure document management system (for Ministerial press releases and political briefs).

**Facility Needs**:
Private, high-security office space within the main project headquarters for confidential stakeholder meetings (Civic Advisory Panel if utilized) and strategic document review.

## 2. Festival Curation & Talent Broker

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Talent Broker will engage in high-stakes negotiation (Decision 5: Co-production agreement) for short-term, high-value contracts (headliners). This role is best suited for an experienced broker on a project-specific or retainer basis, rather than a fixed employee.

**Explanation**:
Manages the primary revenue driver—the music festival. Responsible for negotiating the co-production agreement (Decision 5) and ensuring the musical style aligns with the progressive audience target, balancing risk vs. draw.

**Consequences**:
Failure to secure adequate headliners or booking acts that alienate the target demographic, resulting in missed revenue targets (€18M goal) and compromising the financial viability of the transition.

**People Count**:
min 1, max 2, depending on project scale and workload

**Typical Activities**:
Negotiating the final terms of the European co-production agreement; direct sourcing and contracting of Tier-1/Tier-2 headliners; modeling revenue projections based on talent tier deployment; maintaining relationships with major music rights holders and securing favorable deferred payment schedules (Assumption Q8).

**Background Story**:
Marcus 'The Hammer' Holloway, originally from London's vibrant, competitive music scene, built his reputation as a fearless talent broker known for securing unpredictable, high-value acts for short-run European festivals, often utilizing complex, revenue-sharing deals to mitigate upfront risk. His background includes a decade acting as an agent and three years as an independent festival promoter, giving him deep insight into the psychology of headliner negotiation and festival viability (Decision 5), which he employs strategically to maximize ticket velocity. His experience in the high-stakes, rapid-delivery environment of niche festivals makes him perfectly suited to establish the new music festival's appeal while respecting the pragmatic constraints imposed by the 40% operational buffer.

**Equipment Needs**:
Access to global music rights databases and performance rights organization (PRO) portals; Financial modeling software for calculating revenue share projections (co-production deals); Secure communication channels for sensitive talent negotiations.

**Facility Needs**:
Dedicated professional office space with soundproofing capabilities for private negotiations; Access to established music industry networking events/conferences (e.g., Primavera Sound, Mad Cool) for industry insight.

## 3. Theatrical Attraction Director (Stunt/Comedy Focus)

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Stunt Attraction Director must execute highly specific strategic decisions (Decisions 9 & 13) and manage the continuous training of a core local ensemble for nine months. This requires deep integration and continuity, favoring employment.

**Explanation**:
Owns the entire design, execution, and quality control of the low-infrastructure stunt-comedy center piece, ensuring it meets the 'human-scale,' 'comedy-driven' mandate while managing the training and output of the local performer ensemble (Decision 9 & 13).

**Consequences**:
The secondary attraction becomes incoherent or low-quality, failing to provide sufficient spectacle to replace the previous event, placing unsustainable pressure on the music festival for overall success (Risk 4).

**People Count**:
1

**Typical Activities**:
Designing the modular structure and specific comedic sequences for the 30-minute attraction (Decision 9); selecting and overseeing the Madrid-based physical theater consultant; managing the nine-month training curriculum for the 15 local performers; ensuring the final performance aligns with the chosen Performative Style Calibration (Decision 11).

**Background Story**:
Javier 'Javi' Ortiz, born and raised in the historic heart of Pamplona, is a veteran physical theater director whose career spans both traditional mime troupes and contemporary European circus productions, giving him unique insight into spectacle replacement (Suggestion 3). After his own company successfully transitioned their show aesthetic away from high-risk stunts to narrative-driven physical comedy, Javi developed an expertise in crafting repeatable, high-quality, human-scale performance—exactly what the stunt-comedy mandate requires (Decision 9). His knowledge of local cultural rhythms and his command over the training of physical performers (Decision 13) make him indispensable for creating a successful secondary attraction that satisfies the cultural mandate without relying on pyrotechnics or engineering excess.

**Equipment Needs**:
Specialized lighting and sound equipment for testing stunt blocking and projection mapping (low-level); Contracts secured with the physical theater consultant; Training facilities (rehearsal space) suitable for 15 performers with high ceilings and durable flooring.

**Facility Needs**:
Dedicated, secure rehearsal studio space in or near Pamplona for the 9-month performer training program; Access to a temporary, cordoned-off public space for final safety walk-throughs prior to the festival.

## 4. Senior Municipal & Regulatory Liaison

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Municipal Liaison needs specialized expertise in Spanish regulatory frameworks and political navigation (Risk 1 mitigation, Decision 12). This specialized, high-leverage interface is best secured via a high-rate consultancy contract.

**Explanation**:
Serves as the dedicated interface with Pamplona's City Council and regional bodies. Critical for securing venue access, navigating permitting (especially for the permanent Memory Pavilion), and managing adherence to local procurement mandates (Decision 12, Risk 1 mitigation).

**Consequences**:
Significant delays in securing essential site access licenses past Q1 2027, forcing the project into a multi-year timeline or requiring sharp, costly last-minute operational compromises.

**People Count**:
1

**Typical Activities**:
Leading weekly liaison meetings with the Pamplona City Council; submitting and tracking all building and performance permits (Q1 2027 deadline focus); serving as the primary contact for all regulatory sign-offs for staged events, security protocols, and the Pavilion construction.

**Background Story**:
Isabel Muñoz, a native of Pamplona, traded a lucrative career in international construction law for municipal compliance, driven by a desire to ensure that large urban projects serve the community responsibly, drawing lessons from the infrastructural challenges faced in cities like Seville. Her specialization is in navigating the complexities of Spanish zoning, permitting, and multi-jurisdictional regulatory approvals, making her uniquely qualified to secure the essential site access agreements and the complex permits for the permanent Memory Pavilion (Suggestion 2). Isabel is the project's firewall against bureaucratic paralysis, essential for mitigating the high likelihood of regulatory delays (Risk 1) and embedding the project within local procurement mandates (Decision 12/14).

**Equipment Needs**:
Subscription access to Spanish municipal regulatory code databases; Secure digital filing system compliant with municipal record-keeping requirements; Dedicated liaison budget for travel and hospitality expenditures with city council members.

**Facility Needs**:
Office located within close physical proximity to the Pamplona City Hall to facilitate rapid response and weekly liaison meetings; Access to private meeting rooms for sensitive negotiations concerning venue leases and permits.

## 5. Financial Controller & Contingency Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Financial Control requires constant monitoring of the €25M budget and the strict 40% contingency fund against defined milestones (Decision 3, Assumption Q2/Q8). This demands continuous, internal oversight and fiduciary responsibility.

**Explanation**:
Executes the strict 60/40 budget allocation (Decision 3). Monitors all capital expenditure against the operational buffer, providing the mandatory Month 4 and Month 9 sign-off checkpoints and ensuring long-term liabilities (like the Pavilion's running costs) are accounted for.

**Consequences**:
Premature depletion of the €10M contingency fund due to poor tracking or hidden costs (e.g., underestimation of local vendor QA needs), leading to insolvency or forced cuts to core assets by year-end.

**People Count**:
1

**Typical Activities**:
Implementing the financial tracking system and executing the Month 4 and Month 9 budget reconciliation reviews (Assumption Q2); reporting real-time buffer utilization rates to the Lead; auditing vendor contracts to ensure adherence to local procurement mandates without compromising core infrastructure quality (Risk 5/Issue 3).

**Background Story**:
Chen Wei, a financial risk analyst from Frankfurt, specialized in modeling contingency strength for high-visibility public infrastructure projects before pivoting his focus entirely to cultural finance, recognizing the unique balance required between artistic investment and fiscal conservatism. His expertise lies in creating rigorous oversight systems that respect mandated capital splits, such as the 60/40 allocation (Decision 3), while rigorously tracking drawdowns against operational milestones (Month 4 & 9 reviews). Chen views the €10 million contingency as sacred armor against political/regulatory shocks, ensuring the project's long-term asset viability by protecting seed capital from immediate operational creep.

**Equipment Needs**:
Specialized Enterprise Resource Planning (ERP) or financial tracking software configured for milestone-based budget release (Month 4 & 9); Secure vault or digital system for maintaining the 40% contingency reserve integrity; Currency hedging capability access (though EUR primary).

**Facility Needs**:
A secure, dedicated financial office space isolated from general operations to ensure confidentiality of budget tracking and contingency status; Access to high-speed internet for automated transaction monitoring.

## 6. Community & Stakeholder Relations Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Community Specialist manages the ongoing, measured communication cadence (Decision 2) and liaises with sponsored local businesses (Decision 12). Maintaining narrative control over time requires a dedicated, internal resource.

**Explanation**:
Manages the narrative flow via the defined (slow/measured) engagement cadence (Decision 2). Focuses on translating technical/financial progress into community-digestible updates and actively managing the integration of local businesses/sponsorships through quarterly reviews.

**Consequences**:
Inability to maintain narrative control; public information gaps filled by opposition narratives, escalating social risk and potentially undermining political consensus needed for permits.

**People Count**:
2

**Typical Activities**:
Drafting all Ministerial press releases and public statements; designing informational packets for town halls; managing the PR Liaison team budget (€200k) for rapid, targeted response (Issue 2); coordinating public messaging to amplify local sponsorship wins (Decision 12).

**Background Story**:
Sofia Ramos, based in Madrid but with deep family roots in the Navarran region, is a communications strategist renowned for transforming potentially divisive public initiatives into narratives of unified civic progress, frequently deploying thoughtful, measured engagement strategies that contrast with aggressive advocacy. Her career has focused on managing high-friction community divestment projects, making the nuanced communication required by the Cultural Memory Integration Strategy her core focus. Sofia understands that managing the narrative requires patience—not instant, reactive engagement—and she is tasked with translating the technical (budget, permits) into digestible, trust-building updates via the quarterly town hall structure (Decision 2).

**Equipment Needs**:
Marketing toolkit including professional graphic design software subscriptions and template libraries for Ministerial releases; Digital platform management tools for community feedback/sentiment analysis (if Strategy 3 of Decision 2 is selected intermittently); Comprehensive media monitoring software.

**Facility Needs**:
A central communications hub equipped for rapid content production and media response; Dedicated space for hosting small, controlled stakeholder briefing sessions.

## 7. Logistics & Site Operations Coordinator

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Logistics Coordinator manages the high-intensity, short-duration event (10-day festival). This role is best filled by experienced event production contractors who can deploy specialized teams rapidly for setup/teardown, aligning with a project of fixed duration.

**Explanation**:
The hands-on planner responsible for turning venue rights into usable space. Manages site security ratios, temporary infrastructure needs (power/waste mandated compliance), and coordinates the complex, integrated schedule between the final bull run, the stunt attraction route, and the main music festival setup.

**Consequences**:
Operational failures during the 10-day event window stemming from poor coordination between the separate attractions, safety compliance breaches (Risk 5), or failure to meet environmental diversion targets.

**People Count**:
1

**Typical Activities**:
Creating the integrated 'Day 0 to Day 10' site schedule ensuring seamless handover from the final bull run to the festival opening; securing and managing compliance for temporary power and waste diversion providers; designing and overseeing the security barricade deployment for the Stunt Attraction.

**Background Story**:
Luiz Costa, a seasoned event production manager from Lisbon, specializes in the temporal compression of large festivals, having overseen the rapid build-outs and tear-downs for city-center music events across Southern Europe, skills highly applicable to integrating the final bull run with the festival opening (Decision 4). Luiz focuses intensely on the physical sequencing of operations, ensuring that the low-infrastructure stunt attraction's route does not impede the setup for the main stage and managing critical compliance logistics like temporary power and crowd flow (Assumption Q5/Q6). He is the person responsible for translating the strategic timeline into day-to-day, on-the-ground coordination during the critical transition week.

**Equipment Needs**:
Master scheduling software capable of handling integrated timelines for construction, security build-out, and performance schedules; Access to specialized temporary infrastructure vendors (barricading, bio-fuel generators); Compliance checklist software for environmental and safety standards.

**Facility Needs**:
On-site field office/HQ near the primary festival grounds in Pamplona for daily logistical coordination; Secure temporary storage facilities for festival equipment staging prior to the event window.

## 8. Historical Archivist & Pavilion Project Lead

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Archivist/Pavilion Lead manages a specialized, long-term build and content creation process. Their primary deliverable is securing the permanent structure, which is better managed through a fixed-scope consultancy agreement tied to milestones (Permitting, Design Finalization, Construction Handover).

**Explanation**:
Responsible for delivering the tangible output of the Cultural Memory Integration Strategy—the museum-quality pavilion. This role manages the design, content curation, compliance, and long-term operational planning (addressing sustainability review gaps) for this permanent asset.

**Consequences**:
The long-term memory asset becomes a financial/political burden if built without sufficient planning for annual operating costs, potentially jeopardizing the project's sustainability beyond Year 1.

**People Count**:
1

**Typical Activities**:
Finalizing the content curation and archival acquisition for the Memory Pavilion (Decision 1/Assumption Q7); liaising with regulatory bodies regarding the Pavilion's permanent building plans; developing the Year 2+ operational budget proposal specifically for the Pavilion asset to address long-term sustainability (Issue 1).

**Background Story**:
Dr. Patricia Nielsen, an architectural historian and arts administrator from Copenhagen, specializes in designing sustainable public heritage installations, which directly addresses the long-term liability of the mandated Museum-Quality Pavilion (Decision 1, Issue 1). Patricia's strength lies in ensuring that fixed cultural assets are not just archives but educational, sociologically resonant spaces that justify their perpetual operational budget. Her work involves balancing the upfront capital expenditure against the necessary multi-year operational funding strategy to ensure the memory component thrives beyond the initial transition, safeguarding the project's long-term cultural relevance.

**Equipment Needs**:
Specialized architectural/CAD software for the Pavilion design phase; Content Management System (CMS) suitable for interactive museum exhibits; Long-term operational budget modeling software to project Year 2+ liabilities.

**Facility Needs**:
A designated, quiet workspace for archival research; Regular (e.g., monthly) site visits/walkthroughs of the designated Pavilion location with municipal planners and architects.

---

# Omissions

## 1. Missing Post-Event Operational Funding Strategy

The plan focuses heavily on deploying the €25M budget successfully within the first year (launching the festival and building the Pavilion), but the review identified that the long-term operational cost for the 'museum-quality pavilion' is unaddressed, threatening sustainability and potentially drawing down the Year 1 financial gains.

**Recommendation**:
The Financial Controller (Role 5) and the Historical Archivist (Role 8) must immediately collaborate to develop a Year 2 operational budget for the Pavilion, targeting a dedicated retained profit of at least €3.75M (15% of initial capital) from Year 1 revenue to seed this perpetual fund.

## 2. Underdeveloped Proactive Crisis Communication Structure

The team relies on slow, controlled quarterly town halls and Ministerial releases (Decision 2). In a high-stakes cultural transition, this low-bandwidth approach leaves a vacuum vulnerable to immediate, negative media surges before official rebuttals can be prepared (Issue 2 identified this gap).

**Recommendation**:
The Community & Stakeholder Relations Specialists (Role 6) need a defined, empowered 'Rapid Response Protocol' supported by the existing €200k PR budget. This protocol must ensure a response is issued within 48 hours of any significant negative narrative gaining national traction.

## 3. Unquantified Risk from Local Procurement Mandates on Timelines

The 80% local procurement mandate (Decision 14) supports local relations (Decision 12) but the team has not quantified the administrative overhead or timeline delay risk associated with managing less experienced local vendors for critical functions like security or infrastructure setup (Risk 5/Issue 3).

**Recommendation**:
The Logistics & Site Operations Coordinator (Role 7), in conjunction with the Financial Controller (Role 5), must build a 15% administrative quality assurance (QA) contingency into the operational budget *specifically* for managing local vendor rework/oversight, and must pre-approve secondary international subcontractors for core safety elements.

## 4. Missing Coordination for Stunt Attraction Skill Transfer (Year 1 to Year 2)

The plan focuses on training 15 locals for the first event (Assumption Q3) but neglects the strategy for maintaining quality or developing new acts *after* the initial event. This threatens Risk 8 (performer turnover and stunt fatigue by Year 2).

**Recommendation**:
The Theatrical Attraction Director (Role 3) must incorporate a short-term mentorship block into the nine-month training, pairing the 15 local performers with a key member of the consultant troupe to ensure skill continuity and production maturity beyond the inaugural 10-day run.

---

# Potential Improvements

## 1. Clarify Roles in Private Negotiation vs. Public Reporting

There is ambiguity concerning who formally manages the private negotiations required by the Civic Advisory Panel (Decision 2, Strategy 2) versus who drafts the public Ministerial communications (Decision 2, Strategy 1). Overlap introduces risk of inconsistent messaging (Risk 6).

**Recommendation**:
The Cultural Transition Lead (Role 1) must explicitly task the Senior Municipal & Regulatory Liaison (Role 4) with all 'back-channel' negotiations (Civic Advisory Panel inputs, Decision 12), while the Community & Stakeholder Relations Specialist (Role 6) is solely responsible for drafting and disseminating all *public-facing* official statements and press releases.

## 2. Strengthen Music Talent Contract Phasing Linkage to Financial Milestones

The talent phasing relies on a co-production agreement with deferred payments (Decision 5, Assumption Q8). If ticket sales velocity drops (Assumption Q1/Risk 7), the promoter's performance assurance is untested under duress.

**Recommendation**:
The Festival Curation & Talent Broker (Role 2) must secure clauses in the co-production agreement mandating that deferred payment triggers be tied to *both* ticket milestones AND pre-sale commencement dates, allowing the Financial Controller (Role 5) to actively claw back commitments if early targets are missed.

## 3. Integrate Memory Pavilion Design Timeline into Regulatory Track

The Memory Pavilion is a permanent structure requiring building permits by Q1 2027 (Timeline Assumption Q2), but its integration is generally managed by the Archivist (Role 8) for content, not compliance. Regulatory risk (Risk 1) is high.

**Recommendation**:
The Historical Archivist (Role 8) must report mandatory Pavilion design milestones directly into the Municipal & Regulatory Liaison's (Role 4) weekly risk tracking cadence, treating Pavilion permitting as a Tier 1 regulatory dependency equivalent to the main festival site access.

## 4. Define Stunt Attraction's Narrative Relationship to Memory Pavilion

Decision 11 (Performative Style Calibration) risks conflict with Decision 1 (Cultural Memory Integration). If the stunt show uses 'visual echoes' of the past, it must not contradict the educational/sociological framing of the museum.

**Recommendation**:
The Cultural Transition Lead (Role 1) must mandate joint workshops between the Theatrical Attraction Director (Role 3) and the Historical Archivist (Role 8) to finalize a 'Tone Compatibility Document' by end of Q3 2026, ensuring the stunt show's physical language supports, rather than undermines, the academic framing of the permanent pavilion.