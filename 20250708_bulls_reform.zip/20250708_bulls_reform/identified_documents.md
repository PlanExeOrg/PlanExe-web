
## Documents to Create

### 1. Project Initiation Document (PID) / Project Charter

**ID:** 0614d873-ee53-4ff2-96ee-afe88d5d7956

**Description:** The foundational document formally authorizing the project. It summarizes the objectives (cultural overhaul, €25M budget, July 2027 launch), high-level scope (Music Festival, Stunt Show, Memory Pavilion), key stakeholders, and the selected 'Pragmatic Foundation' strategic path. It confirms the 60/40 budget split.

**Responsible Role Type:** Cultural Transition Lead & Project Sponsor

**Primary Template:** PMI Project Charter Template

**Secondary Template:** Public Sector Initiative Charter Standard

**Steps:**

- Finalize scope definition based on strategic decisions (especially Decision 1 & 4).
- Formalize high-level resource needs (€25M capital, 1-year timeline).
- Obtain formal approval from Project Governance Team.

**Approval Authorities:** Project Governance Team (Steering Committee)

### 2. Initial High-Level Risk Register & Mitigation Matrix

**ID:** 6a8c7f85-e925-4379-a9fb-902b289fb9a5

**Description:** A foundational risk management document mapping the 8 identified risks (Regulatory, Financial, Social/Cultural, Operational, Supply Chain, Integration). It must clearly link the identified risks to the chosen mitigation strategies (e.g., Risk 1 links to Decision 3 Strategy 3) and incorporate the expert review findings (e.g., Talent Risk Transfer).

**Responsible Role Type:** Financial Controller & Contingency Manager

**Primary Template:** Standard Risk Register (ISO 31000)

**Secondary Template:** Public Project Risk Assessment Template

**Steps:**

- Populate with risks identified in project files (R1-R8).
- Assign initial qualitative ratings (Likelihood/Severity).
- Integrate mitigation actions driven by Strategic Decisions (D1-D14) and Expert Review recommendations (e.g., mandatory PR rapid response setup).
- Identify key trigger points for contingency drawdown.

**Approval Authorities:** Cultural Transition Lead & Project Sponsor

### 3. Cultural Memory Integration Narrative Framework

**ID:** 1cdf470d-042f-4ae4-8b19-e28692088ffb

**Description:** Strategy document detailing the chosen approach for addressing the cessation of the bull run, based on Decision 1 ('Evolution not Abolition'). This document must reconcile the selection of the permanent Museum Pavilion with the overall pragmatism, or propose the pivot to a temporary digital-first approach as suggested by expert review (Issue 1.4.C). Defines tone compatibility (Decision 11).

**Responsible Role Type:** Cultural Transition Lead & Project Sponsor

**Primary Template:** Cultural Strategy Framework Document

**Secondary Template:** Sociological Impact Assessment Guideline

**Steps:**

- Determine final mandatory format for memory preservation (Permanent Museum vs. Digital Pop-up).
- Draft the core narrative statement ('evolution, not abolition').
- Mandate joint session between Role 3 (Stunt Director) and Role 8 (Archivist) to produce 'Tone Compatibility Document' by Q3 2026 (Omission 4).

**Approval Authorities:** Project Governance Team (Steering Committee)

### 4. High-Level Financial Framework & Contingency Drawdown Protocol

**ID:** e206c995-db90-4ed5-9b11-447b5464a15d

**Description:** A financial strategy document formalizing the €25M budget breakdown (60% CapEx/OpEx vs. 40% Contingency). Crucially, it establishes the mandatory holding period for the 40% buffer (until Month 9 review) and defines the quantitative criteria for *premature* drawdown, addressing the structural gap noted in the expert review (Issue 1.4 & 1.5).

**Responsible Role Type:** Financial Controller & Contingency Manager

**Primary Template:** Public Project Financial Control Plan

**Secondary Template:** Contingency Management Policy Document

**Steps:**

- Lock in initial 60/40 allocation figures (€15M / €10M).
- Define 'MAQ' (Minimum Achievable Quality) of Pavilion as the first cost impacted by drawdown.
- Establish baseline Year 2 Operational Cost liability projection (Issue 1.1).

**Approval Authorities:** Financial Controller & Contingency Manager, Cultural Transition Lead & Project Sponsor

### 5. Stakeholder Engagement & Narrative Control Protocol (Hybrid Model)

**ID:** 2cd87fc4-9b33-4951-b888-cfd9713a9411

**Description:** Defines the communication rhythm by merging the chosen slow engagement cadence (Decision 2, Strategy 1) with the required rapid response capability identified in the SWOT/Expert Review. Outlines the roles of Role 6 (public release drafting) vs. Role 4 (private negotiation/liaison).

**Responsible Role Type:** Community & Stakeholder Relations Specialist

**Primary Template:** Stakeholder Communication Plan

**Secondary Template:** Rapid Response Crisis Protocol

**Steps:**

- Document the 48-hour Rapid Response Protocol and resource allocation (€200k/$300k PR Budget).
- Define clear boundaries between Role 6 (Public Narrative) and Role 4 (Private Negotiation/Regulatory tracking).
- Establish bi-weekly cultural update cadence, supplementing quarterly operational town halls.

**Approval Authorities:** Cultural Transition Lead & Project Sponsor

### 6. Year 1 Talent Acquisition Restructuring Plan

**ID:** 924225c9-29ed-4989-9a20-dfb2c58189f7

**Description:** This plan addresses the critical fiscal risk posed by over-reliance on the co-production promoter (Issue 1.5 & 2.5). It mandates the immediate pivot away from full deferral by allocating up to €4.0M from the 60% hard cost pool to secure one Tier-1 headliner directly via immediate guarantee, aiming to lock in initial ticket velocity.

**Responsible Role Type:** Festival Curation & Talent Broker

**Primary Template:** Talent Acquisition Strategy Update

**Secondary Template:** Contract Restructuring Mandate

**Steps:**

- Draft contract amendments/new direct guarantee proposals based on revised financial structure.
- Identify target 'must-book' Neutral Tier-1 Headliner.
- Obtain sign-off from Financial Controller on the €4.0M reallocation from Hard Costs.

**Approval Authorities:** Cultural Transition Lead & Project Sponsor, Financial Controller & Contingency Manager

### 7. Stunt Attraction Artistic Mandate & 'Killer App' Concept Outline

**ID:** 56250bcb-8840-44a5-b01e-fad925023827

**Description:** Based on Expert Review (Issue 1.6) and Omission 4/Recommendation 1, this document elevates the Stunt Attraction from filler to primary novelty. It mandates the recruitment of a world-class Physical Theatre Director and defines the core concept ('Killer App') for the 30-minute show, ensuring it is proprietary and high-impact, superseding the generic 'slapstick' baseline.

**Responsible Role Type:** Theatrical Attraction Director (Stunt/Comedy Focus)

**Primary Template:** Theatrical Production Design Brief

**Secondary Template:** Artistic Escalation Statement

**Steps:**

- Define the specific, proprietary visual anchor ('Killer App') for the attraction.
- Develop job description/scope for specialized, high-calibre International Director.
- Allocate initial director recruitment/consultation budget (€300k-€750k) from contingency.

**Approval Authorities:** Cultural Transition Lead & Project Sponsor

### 8. Local Vendor Oversight and Subcontracting Policy

**ID:** 624439fe-1125-4215-adb3-91bf8862e00a

**Description:** Directly addresses Threat 4 and Assumption Review Issue 3. This policy formalizes the 80% local procurement mandate (Decision 14) while requiring that all vendors handling safety-critical infrastructure (security, temporary staging/barricades, power) must subcontract critical QA/oversight elements to pre-vetted international specialists, with the administrative overhead cost being baked into the budget.

**Responsible Role Type:** Logistics & Site Operations Coordinator

**Primary Template:** Procurement and Vendor Management Policy

**Secondary Template:** Subcontractor QA Mandate Template

**Steps:**

- Consult Role 6 (Logistics Expert) to quantify 15% QA overhead/rework contingency.
- Draft language for Decision 12 contracts mandating subcontracting clauses for safety elements.
- Present the revised budget impact to the Financial Controller.

**Approval Authorities:** Financial Controller & Contingency Manager, Senior Municipal & Regulatory Liaison

### 9. Year 2+ Financial Sustainability Forecast (Legacy Asset Seeding)

**ID:** 1780104f-b67b-489c-b263-28c6e85ddbd0

**Description:** A financial model projecting the financial requirements for the project beyond the initial 1-year launch phase, specifically addressing the unfunded operational liability of the permanent Memory Pavilion (estimated at €400K/year). This document establishes the recommended minimum profit retention target from Year 1 revenue to seed Year 2 operations.

**Responsible Role Type:** Financial Controller & Contingency Manager

**Primary Template:** 5-Year Rolling Financial Forecast Model

**Secondary Template:** Cultural Asset Long-Term Cost Analysis

**Steps:**

- Receive operational cost inputs from Historical Archivist (Role 8).
- Model Year 1 revenue targets (€18M) against Year 1 hard costs to determine achievable retained profit.
- Set concrete Year 1 profit retention goal (e.g., €3.75M) as a mandatory objective.

**Approval Authorities:** Financial Controller & Contingency Manager, Cultural Transition Lead & Project Sponsor

### 10. Talent Investment Risk Transfer Negotiation Strategy (Revised)

**ID:** 51baa4e9-6e3b-47fd-a0b3-db8fe8e195fb

**Description:** This document outlines the strategy for re-engaging the European Festival Promoter following the decision to internally secure one Tier-1 act. It focuses on modifying the co-production agreement clauses to include stricter 'Minimum Quality Act' specifications, performance guarantees tied to pre-sale dates, and detailed penalty structures for non-delivery, retaining primary control.

**Responsible Role Type:** Festival Curation & Talent Broker

**Primary Template:** Contract Amendment Proposal

**Secondary Template:** Promoter Risk Mitigation Checklist

**Steps:**

- Integrate legal requirements from the emergency legal review.
- Identify precise performance tiers/deadlines for penalty application.
- Define the hard parameters for the promoter's remaining talent budget allocation.

**Approval Authorities:** Festival Curation & Talent Broker, Cultural Transition Lead & Project Sponsor

### 11. Stunt Attraction Director Search Profile and Search Mandate

**ID:** e19893ec-55ed-499e-9fb1-a6ebfaa53ca5

**Description:** A detailed profile for the uniquely skilled international Physical Theatre Director needed to create the proprietary 'Killer App' for the secondary attraction. This profile will request expertise in high-impact, low-tech narrative structuring and will guide the immediate recruitment effort, funded partially from contingency.

**Responsible Role Type:** Theatrical Attraction Director (Stunt/Comedy Focus)

**Primary Template:** Specialist Recruitment Profile

**Secondary Template:** Artistic Escalation Strategy Outline

**Steps:**

- Define specific required deliverables tied to the 'Killer App' concept.
- Determine salary/consultancy fee bracket to attract world-class talent.
- Draft mandate to shift local performer training focus from breadth to depth on the core show.

**Approval Authorities:** Cultural Transition Lead & Project Sponsor

## Documents to Find

### 1. Pamplona Municipal Planning Department Venue Access and Permit Guidelines

**ID:** f628b856-4df8-48bc-a80a-2416293a4d61

**Description:** Official regulations specifying timelines, submission requirements, and prerequisites for securing multi-year leases for large event venues (Plaza de Toros area) and temporary performance zones in the city center for July 2027 execution. Essential input for Risk 1 mitigation.

**Recency Requirement:** Current/Most recent published version

**Responsible Role Type:** Senior Municipal & Regulatory Liaison

**Access Difficulty:** Medium

**Steps:**

- Access the Pamplona City Council official website for event licensing portals.
- Contact the Municipal Planning Department directly (via Role 4) to request the official permitting roadmap for major cultural events.

### 2. Navarre Regional Health and Safety Inspectorate Crowd Management Standards

**ID:** 0882d46c-b851-49c9-805a-c064fcaea10c

**Description:** Official documents detailing sector-specific safety mandates for large public assemblies in Spain, including the required spectator-to-security ratio (Assumption Q5), temporary barricade standards, and emergency service access requirements for the festival footprint.

**Recency Requirement:** Current mandatory standards

**Responsible Role Type:** Logistics & Site Operations Coordinator

**Access Difficulty:** Medium

**Steps:**

- Search the Navarre regional government portal for public assembly legislation.
- Consult the Senior Municipal Liaison (Role 4) for official contact points regarding safety sign-off.

### 3. EU Environmental Compliance Data: Waste Diversion & Biofuel Standards

**ID:** 8d0a209e-1adc-40a3-8275-8019d9e4ab06

**Description:** Specific regulatory texts detailing the mandatory 60% solid waste diversion rate and technical specifications for approved renewable energy/biofuels for temporary power generation (Assumption Q6), required for the Logistics Coordinator to vet Year 1 vendors.

**Recency Requirement:** Current EU directives and subsequent Spanish/Navarran implementation laws

**Responsible Role Type:** Logistics & Site Operations Coordinator

**Access Difficulty:** Easy

**Steps:**

- Search the European Commission Environmental Directorate websites.
- Cross-reference with official Spanish environmental agency publications for site-specific application.

### 4. Historical Sociological Survey Data related to the Running of the Bulls

**ID:** 7a4bf2ae-0764-47a0-91aa-1a4ad3b46867

**Description:** Raw, anonymized demographic data or statistical publications (e.g., from local universities or historical societies) outlining participation rates, age distribution, and historical sentiment trends related to the traditional run. Crucial input for framing the 'Cultural Memory Integration Strategy' (Decision 1) and measuring acceptance (Objective 3).

**Recency Requirement:** Data spanning the last 10 years is highly desirable

**Responsible Role Type:** Historical Archivist & Pavilion Project Lead

**Access Difficulty:** Hard

**Steps:**

- Contact relevant Navarran cultural institutes or Pamplona University Sociology/History departments.
- Search publicly accessible repositories for academic papers citing primary sentiment data on the event.

### 5. Pamplona Local Business Registry and Supplier Profiles (Navarre Region)

**ID:** 5786caff-858e-464d-b2ec-556173885557

**Description:** A list or database of registered local businesses, particularly those in hospitality, security, and temporary infrastructure, required to verify the pool of available contractors to meet the 80% local procurement mandate (Decision 14).

**Recency Requirement:** Most recently updated directory

**Responsible Role Type:** Community & Stakeholder Relations Specialist

**Access Difficulty:** Medium

**Steps:**

- Liaise with the local Chamber of Commerce or the regional economic development agency.
- Utilize the Senior Municipal Liaison to obtain lists vetted by the city council for sponsorship consideration.

### 6. Historical Spanish Public Works & Political Negotiation Precedents (e.g., Seville Expo '92 Archives)

**ID:** f1342e2e-e1fd-4314-8aae-b2a464b548db

**Description:** Documentation detailing the political negotiation tactics, multi-level governmental consensus methods, and eventual site repurposing/legacy planning related to major Spanish public projects. Crucial background for Role 4 (Municipal Liaison) and Decision 2 regarding political consensus.

**Recency Requirement:** Historical, focusing on projects concluded 1985-2000

**Responsible Role Type:** Senior Municipal & Regulatory Liaison

**Access Difficulty:** Hard

**Steps:**

- Search archives related to the Seville Expo '92 administrative body.
- Access Spanish parliamentary records concerning major expenditure approvals.

### 7. Contemporary European Circus Operational Reports (Post-Animal Transition)

**ID:** df1e05a1-3a26-4bd0-aa73-b92743d56f2f

**Description:** Case studies, white papers, or production documents from contemporary European/Canadian circuses (e.g., Cirque Éloize) detailing their transition away from animal acts—specifically focusing on rehearsal investment, ensemble training budgets, and performance synchronization for human-centric spectacles (Suggestion 3).

**Recency Requirement:** Published within the last 15 years

**Responsible Role Type:** Theatrical Attraction Director (Stunt/Comedy Focus)

**Access Difficulty:** Medium

**Steps:**

- Contact arts funding bodies in France/Quebec/Belgium specializing in contemporary spectacle.
- Review academic databases for studies on circus industry transformation.

### 8. Draft European Festival Co-Production Contract Templates (Standard Liability Clauses)

**ID:** 2bada85d-8deb-421b-8e68-0e6e282623d2

**Description:** Template agreements or summaries from major European music festival promoters that illustrate standard clauses regarding talent guarantees, deferred payment structures, liability for permitting fines, and revenue-share mechanisms related to upfront guarantees. Essential for Role 2 in negotiating the *revised* partnership agreement.

**Recency Requirement:** Most recent standard professional templates (2022-Present)

**Responsible Role Type:** Festival Curation & Talent Broker

**Access Difficulty:** Medium

**Steps:**

- Consult specialized entertainment legal counsel (as per expert recommendation).
- Review publicly available, anonymized agreements from similar mid-size European festivals.