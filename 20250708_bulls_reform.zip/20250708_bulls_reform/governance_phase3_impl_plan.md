### 1. Project Sponsor (Senior Municipal Executive) formally establishes the Project Charter and designates the Project Director and Finance Controller roles.

**Responsible Body/Role:** Project Sponsor (Senior Municipal Executive)

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Signed Project Charter
- Designation Notice for Project Director
- Designation Notice for Finance Controller

**Dependencies:**

- Project Definition Finalized (Inputs from 'initial-plan.txt' and 'project-plan.json')

### 2. Project Director drafts the initial Terms of Reference (ToR) for the Project Steering Committee (PSC), incorporating required roles, decision thresholds (€1M cap), and escalation logic.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1

**Dependencies:**

- Project Director role established

### 3. Project Sponsor reviews and approves the PSC ToR, formally appoints the PSC Chair (itself) and the External Independent Governance Advisor, and confirms all nominated PSC members.

**Responsible Body/Role:** Project Sponsor (Senior Municipal Executive)

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Finalized and Ratified PSC ToR
- Official Appointment Letters for PSC Members

**Dependencies:**

- Draft PSC ToR v0.1 review completed
- PSC Membership List finalized

### 4. PSC holds its inaugural (kick-off) meeting to ratify its ToR, mandate the initial €1M expenditure threshold, and authorize the establishment of the Operational Management Group (OMG).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- PSC Meeting Minutes 01, confirming ToR ratification
- Decision Log: €1M threshold approval
- Mandate for OMG Establishment

**Dependencies:**

- PSC formally established and members confirmed

### 5. Project Director, guided by the PSC mandate, drafts the OMG ToR, establishing the €250k operational spending limit and the Procurement Oversight Charter (incorporating Decision 14 mandates).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft OMG ToR v0.1
- Draft Procurement Oversight Charter

**Dependencies:**

- Mandate for OMG Establishment from PSC

### 6. Project Director nominates and secures PSC approval for the OMG Chair (itself) and the remaining OMG members (Lead PM, Finance Controller, Festival Curation Head, Stunt Director).

**Responsible Body/Role:** Project Director (with PSC oversight)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Finalized OMG Membership List
- PSC approval record for OMG structure

**Dependencies:**

- Draft OMG ToR reviewed
- All operational roles filled internally

### 7. OMG holds its inaugural meeting to ratify its ToR and Procurement Charter, and formally establish the Rapid Response PR Protocol (as suggested by governance review).

**Responsible Body/Role:** Operational Management Group (OMG)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- OMG Meeting Minutes 01
- Signed OMG ToR and Procurement Charter
- Rapid Response PR Protocol Document

**Dependencies:**

- OMG membership confirmed
- OMG ToR ratified

### 8. PSC mandates the formal establishment and structural requirements (auditor vetting criteria) for the Compliance and Assurance Panel (CAP), per governance risk mitigation for procurement.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- CAP Establishment Mandate
- Criteria for Independent Auditor Selection

**Dependencies:**

- PSC Meeting Minutes 01

### 9. Project Sponsor and Governance Advisor vet candidates and appoint the External Independent Auditor (CAP Chair) and the PSC Nominee for the CAP.

**Responsible Body/Role:** Project Sponsor (with Governance Advisor support)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Independent Auditor Contract Signed
- CAP Member Appointment Confirmation

**Dependencies:**

- CAP Establishment Mandate issued

### 10. OMG (with Legal Counsel support) vets candidates and secures the External Environmental Compliance Specialist for the CAP.

**Responsible Body/Role:** Operational Management Group (OMG)

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Environmental Compliance Specialist Contracted for CAP support

**Dependencies:**

- OMG Procurement Oversight Charter established

### 11. CAP holds its inaugural meeting to ratify its operating procedures, formalize the whistleblower channel, and schedule the first audit checkpoint against the Operational Buffer plan (Post-Month 2).

**Responsible Body/Role:** Compliance and Assurance Panel (CAP)

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- CAP Meeting Minutes 01
- Whistleblower Channel Activated
- Initial Audit Schedule Published

**Dependencies:**

- All CAP members appointed
- Legal Counsel engaged

### 12. OMG Lead PM initiates immediate asset preparation: securing vendor quotes for the Museum Pavilion site access (Location 3) and initiating venue access negotiations for the main festival site (Location 1) per Risk 1 mitigation.

**Responsible Body/Role:** Operational Management Group (OMG)

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Vendor vetting commenced for Pavilion construction permitting
- Initial Lease Term Sheets drafted for Venue Access Agreements

**Dependencies:**

- OMG Charter ratified
- Project Charter Authorization

### 13. PSC reviews and formally approves the initial funding release (60% of Capex) for immediate hard costs necessary to satisfy Decision 3 and Decision 5 (e.g., lease front-loading, initial promoter negotiation deposits).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- PSC Decision Log: Initial Capex Release Authorized (≤ 60% total budget)
- Funds transferred to operational accounts

**Dependencies:**

- OMG provides consolidated initial spending plan
- CFO/Finance Controller confirms 40% contingency buffer is segregated

### 14. OMG commences the nine-month training program for the 15 Stunt Performers, guided by the Stunt Attraction Director, focusing on high-script content (Decision 9, Strategy 1).

**Responsible Body/Role:** Stunt Attraction Director (under OMG oversight)

**Suggested Timeframe:** Project Week 11 - Month 8

**Key Outputs/Deliverables:**

- Stunt Performer Training Commencement Report (Month 1)
- Monthly Progress Reports on Script Choreography & Local Vendor Audits (per Risk 5 mitigation)

**Dependencies:**

- Initial Capex Release approved
- Performer Employment Model (Decision 7) confirmed (assumed fixed ensemble/local training)

### 15. OMG initiates Quarterly Town Hall cycle (Decision 2, Strategy 1) to manage external narrative and publicly confirm progress on venue permitting milestones (Risk 1).

**Responsible Body/Role:** Head of Festival Curation (Coordinating with PR Liaison, under OMG)

**Suggested Timeframe:** End of Month 3

**Key Outputs/Deliverables:**

- Town Hall 01 Documentation
- First Ministerial Press Release Issued

**Dependencies:**

- Rapid Response PR Protocol in place
- Initial venue access progress secured