**Purpose:** business

**Purpose Detailed:** Large-scale public/societal initiative involving significant budget allocation (€25 million) aimed at cultural and public welfare change within a city, framing it as a major community transition project.

**Topic:** Replacing Pamplona's Running of the Bulls with a non-animal festival