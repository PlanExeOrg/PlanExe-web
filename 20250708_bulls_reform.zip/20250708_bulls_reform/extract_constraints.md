## Positive Constraints

- Launch initiative for Pamplona
- 1-year initiative timeline
- €25 million initiative budget
- End Pamplona's traditional Running of the Bulls after the next event window
- Replace Running of the Bulls with a non-animal festival centerpiece
- Replacement centerpiece led by a major music festival
- Support replacement with a theatrical stunt-comedy attraction
- Stunt attraction features trained performers doing controlled, foolish, physical, crowd-pleasing challenges
- Stunt attraction must be low-infrastructure
- Stunt attraction must be human-scale
- Stunt attraction must be comedy-driven
- Plan must preserve cultural memory respectfully
- Plan must facilitate ending live-animal spectacle
- Include other non-animal alternatives only if they directly strengthen the transition away from bull runs
- Project start ASAP

## Negative Constraints

- Do not choose the most aggressive scenario
- Do not frame the stunt attraction as extreme sports
- Do not frame the stunt attraction as stunt engineering
- Do not frame the stunt attraction as pyrotechnics
- Do not frame the stunt attraction as robotics
- Do not frame the stunt attraction as a major construction project
- Be realistic
