## Focus and Context
How do we transition a century-old civic spectacle into a sustainable, modern cultural anchor within 12 months and €25M? This plan adopts the 'Pragmatic Foundation' to execute a managed cultural evolution, balancing high-quality asset delivery with robust fiscal containment.

## Purpose and Goals
To successfully launch the inaugural non-animal festival by July 2027, achieving cash-flow neutrality (€18M ticket goal), securing necessary municipal buy-in (permits by Q1 2027), and ensuring long-term viability by protecting a significant operational contingency.

## Key Deliverables and Outcomes
Selection of the 60/40 budget split (40% contingency); Establishment of a museum-quality Memory Pavilion for cultural continuity; Securing a long-term co-production deal for the music festival; Launch of a high-quality, scripted stunt-comedy attraction built around local talent; Integration of the final traditional event into the new festival opening ceremony.

## Timeline and Budget
Strict 1-year timeline targeting July 2027 operational launch. Total capital budget ceiling of €25 million, with a non-discretionary 40% (€10M) dedicated as a contingency buffer, accessible only upon strict milestone reviews.

## Risks and Mitigations
Primary risks are Regulatory Paralysis (mitigated by front-loading municipal lease payments) and Talent Dependency (mitigated by restructuring the co-production deal to regain upfront booking control). A major ongoing focus is enforcing quality control on local vendors to protect the contingency buffer.

## Audience Tailoring
The summary is tailored for an executive committee or project governance group requiring a high-level, strategic overview of the chosen path. It emphasizes fiscal prudence, risk management, and alignment with the mandated one-year cultural transition.

## Action Orientation
Immediate initiation of three high-priority actions: 1) Finalize the revised Talent Acquisition Strategy by June 15, 2026, by earmarking €4M for direct talent guarantees; 2) Operationalize the 48-hour Rapid Response PR Protocol to manage narrative control; 3) Task the Regulatory Liaison to lock down the Q1 2027 permit timeline with the Pamplona Council.

## Overall Takeaway
The Pragmatic Foundation strategy provides the necessary fiscal resilience and cultural sensitivity to navigate this high-stakes civic reformation, resulting in a sustainable, modern cultural asset for Pamplona.

## Feedback
To strengthen this summary, specify the required residual buffer amount (e.g., €3M) remaining post-Year 1 to fund the Pavilion's operational liabilities. Quantify the required upfront cash deposit ceiling for the restructured talent agreements. Explicitly state the new, non-integrated timing for the final bull run event to reinforce the narrative break.