**Budget Drawdown Threatening Buffer Depletion (Exceeding €500k)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Emergency PSC Vote required to approve buffer access over 5% threshold.
Rationale: The operational burn rate puts the mandatory 40% Operational Buffer at risk. Accessing this fund is a strategic financial decision reserved for the PSC, as per OMG's escalation limits.
Negative Consequences: Exposure to Financial Risk 2; potential inability to fund unforeseen regulatory costs or talent guarantees, jeopardizing Year 1 viability.

**Political Deadlock on Venue Access/Permitting (Risk 1)**
Escalation Level: Project Sponsor / Mayor's Office (via PSC)
Approval Process: PSC referral to the Senior Municipal Executive (Project Sponsor) for direct political intervention and negotiation.
Rationale: The issue involves significant local political hesitance, which the OMG cannot resolve tactically. This requires intervention at the highest municipal level (Project Sponsor) to ensure timelines are met.
Negative Consequences: Failure to secure necessary permits by Q1 2027 will lead to mandated project re-scoping or delaying the July 2027 launch, violating the time-bound goal.

**CAP Veto on Core Local Procurement Contract (Decision 14)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC must review the CAP's rationale for vetoing the contract (e.g., compliance failure) and vote to either uphold the veto or overturn it with a supermajority.
Rationale: The CAP has the authority to veto procurement based on compliance risk. If the OMG disputes this and the issue cannot be resolved consensually within the OMG, it escalates to the PSC for strategic alignment review.
Negative Consequences: Procurement delays risk supply chain failure (Risk 5), but overriding a CAP veto risks legal challenge or regulatory penalty (Risk 1 dependency).

**Unresolved Conflict on Stunt Attraction Narrative Style (Decision 11)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC reviews the conflict between the Stunt Director's tactical needs and the Cultural Memory Strategy's mandate, ruling based on alignment with the overall Pragmatic Foundation strategy.
Rationale: Disagreement on the core physical implementation's tone (slapstick vs. visual echoes) impacts the cultural acceptance narrative (Risk 6) and requires a strategic ruling that transcends operational execution.
Negative Consequences: Inconsistent tone risks failing to serve as a compelling replacement spectacle, overburdening the music festival and leading to poor audience adoption metrics.

**Dispute over Promoter Compensation/Deferred Payments (Risk 7)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC must review the promoter's request against the established internal ceiling and approve any modification to the negotiated revenue-share structure or milestone payment schedule.
Rationale: Changes to the co-production agreement (Decision 5) directly impact revenue velocity and financial risk exposure, requiring strategic-level approval beyond OMG's financial limits.
Negative Consequences: If the promoter walks or demands excessive upfront fees due to renegotiation failure, Year 1 revenue targets (€18M) will be jeopardized, straining the operational budget.

**Need for Major Contract Rerouting (Exceeding €1 Million)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Formal vote by the PSC, requiring approval that disbursement aligns with the ratified strategic plan.
Rationale: The PSC's stated mandate is to approve all disbursements exceeding €1 million or 10% of the buffer. Any major contract award (like securing a lead music headliner directly) falls under this threshold.
Negative Consequences: Unauthorized commitment of large capital sums could prevent funding a critical pre-launch regulatory milestone or deplete contingency reserves needed for unexpected political overhead.