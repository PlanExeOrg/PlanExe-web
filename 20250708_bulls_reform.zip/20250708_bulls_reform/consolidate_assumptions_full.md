# Purpose

**Purpose:** business

**Purpose Detailed:** Large-scale public/societal initiative involving significant budget allocation (€25 million) aimed at cultural and public welfare change within a city, framing it as a major community transition project.

**Topic:** Replacing Pamplona's Running of the Bulls with a non-animal festival

# Domain

**Primary domain:** Cultural Transition Management

**Secondary domains:** Festival Curation, Public Finance, Public Relations

**Rationale:** Cultural Transition Management is the primary outcome because the entire project's success hinges on managing the sensitive shift away from the Running of the Bulls. While Event Production and Theatrical Performance Directing are critical components, they serve this overarching cultural goal.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Cultural Transition Management | 5 | 5 | outcome | The primary goal is managing a sensitive cultural change away from the bull run. |
| Event Production | 5 | 5 | outcome | The core outcome is successfully launching a high-quality, non-animal music and stunt festival. |
| Theatrical Performance Directing | 5 | 5 | outcome | Directly responsible for designing the core stunt-comedy attraction. |
| Festival Curation | 4 | 4 | outcome | The replacement centerpiece requires planning a major music festival component. |
| Public Relations | 4 | 4 | method | Managing the social and political discourse around ending a tradition is critical. |
| Historical Preservation | 4 | 4 | constraint | Respectfully preserving cultural memory is a key requirement of the transition plan. |
| Community Engagement Strategy | 4 | 4 | method | Essential for navigating the public shift away from a major tradition. |
| Public Finance | 4 | 3 | constraint | The fixed €25 million budget necessitates careful financial planning and allocation. |
| Large-Scale Event Logistics | 4 | 3 | method | Needed to organize the music festival and stunt show logistics. |

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** This plan involves numerous concrete, physical steps required to execute a large-scale cultural and festival transition. Key physical elements include securing and preparing physical venues in Pamplona, constructing the low-infrastructure staging for the stunt-comedy attraction, managing the physical logistics for the major music festival (sound, staging, artist travel/accommodation), and coordinating physical security and crowd control for the new event. Furthermore, the core activities—launching a festival—are inherently dependent on physical infrastructure and location (Pamplona).

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Securing and preparing physical venues in Pamplona for a major music festival.
- Space for low-infrastructure, human-scale stunt-comedy attraction staging.
- Space for a permanent, museum-quality pavilion dedicated to historical/archival context.
- Accessibility and high capacity for large public events.

## Location 1
Spain

Pamplona (Iruña), Navarre

Plaza de Toros (Bullring Area) or surrounding grounds for the main festival hub.

**Rationale**: The core activity must take place in Pamplona. The former bullring area or adjacent city grounds are historically central to the event and offer existing infrastructure capacity suitable for a transition festival hub.

## Location 2
Spain

Pamplona City Center

Designated City Streets/Parks for the Stunt-Comedy Attraction route.

**Rationale**: The low-infrastructure stunt attraction requires accessible, human-scale public space that allows for controlled crowd interaction but avoids major construction. Central city parks or large plazas offer the necessary flexibility.

## Location 3
Spain

Pamplona (Navarre)

Location adjacent to the historical route for the Memory Pavilion.

**Rationale**: The chosen 'Pragmatic Foundation' strategy requires establishing a permanent, museum-quality pavilion for cultural memory integration. This site should be geographically linked to the traditional events (often near the bullring or the start of the run) to serve as a transition anchor.

## Location Summary
All primary locations must be situated within Pamplona, Spain, dictated by the project's focus. Location 1 is for the main Music Festival (utilizing existing large venue capacity). Location 2 is for the adaptable, low-infrastructure Stunt-Comedy Attraction requiring central, flexible public space. Location 3 is required for the permanent Museum Pavilion dedicated to historical memory integration.

# Currency Strategy

This plan involves money.

## Currencies

- **EUR:** The project is clearly located in Pamplona, Spain, which uses the Euro. The stated budget is denominated in Euros (€25 million).
- **USD:** Included as a stable international benchmark currency, although EUR is primary due to the location and budget denomination.

**Primary currency:** EUR

**Currency strategy:** Since the project is geographically confined to Spain (Eurozone) and the budget is explicitly denominated in Euros, EUR will be used for budgeting and all major transactions. Local transactions will also use EUR, eliminating significant foreign exchange risk exposure.

# Identify Risks


## Risk 1 - Regulatory & Permitting
Failure to secure the necessary municipal permits and long-term venue access agreements for the large-scale music festival and the permanent museum pavilion within the tight 1-year timeline, especially given local political hesitance toward the cancellation of the traditional event.

**Impact:** Delay in festival launch (potential 3-6 month setback) or mandatory downsizing of the music festival scale, resulting in a financial overrun of €3–€5 million due to rushed planning and penalties.

**Likelihood:** High

**Severity:** High

**Action:** Prioritize Decision 3, Strategy 3 (Front-load municipal lease securing payments) and Decision 12 (Local Stakeholder Transition Sponsorship) to secure political goodwill early. Dedicate a specialized regulatory affairs team to manage city council interactions weekly, focusing on securing the 2027 event permits by Q4 2026.

## Risk 2 - Financial
The 40% operational buffer (€10 million, based on 60/40 split) proves insufficient. This risk materializes if unexpected costs arise from retrofitting venues, or if the co-production model for the music festival requires a higher upfront guarantee than initially budgeted to secure sufficient talent.

**Impact:** Depletion of contingency funds forcing necessary cuts to the quality/scale of the Stunt-Comedy Attraction or the Memory Pavilion construction, potentially leading to a second-year funding shortfall if initial revenue targets are missed. Potential €2–€4 million shortfall against the required €25M total lifecycle spend.

**Likelihood:** Medium

**Severity:** High

**Action:** Strictly adhere to the 40% contingency (Decision 3). Institute a rigorous milestone-based release schedule for the operational buffer, releasing funds only after successful intermediate reviews (Month 4 and Month 9). Ensure the co-production agreement (Decision 5) has clear clauses regarding talent payment phasing tied to ticket sales velocity.

## Risk 3 - Social & Cultural
Intense, mobilized opposition from traditionalist factions leads to public demonstrations, media boycotts, or direct interference/vandalism targeting the low-infrastructure stunt attraction or the memory pavilion site before the first event, despite efforts to integrate memory.

**Impact:** Negative media narratives dominating the launch week, severely depressing ticket sales for the initial year (potential 20-30% revenue dip) and causing operational disruption during setup phases.

**Likelihood:** High

**Severity:** Medium

**Action:** Leverage Decision 1 (Museum Pavilion) to provide a concrete, respectful anchor for cultural continuity. Utilize the strict quarterly communication cadence (Decision 2) to preemptively address critiques and amplify favorable local testimonials secured through Local Stakeholder Transition Sponsorship (Decision 12).

## Risk 4 - Operational
The Stunt-Comedy Attraction fails to meet expectations due to fragmented comedic timing or perceived low quality, stemming from utilizing local, in-training performers (Decision 13, Strategy 2) which clashes with the high-stakes cultural replacement mandate.

**Impact:** The secondary attraction fails to provide sufficient draw or cohesion, forcing the music festival to carry 100% of the event's cultural weight, undermining the diversity of the offering. This could lead to a perception that the stunt element was an afterthought.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Invest heavily in specialized physical theater coaching/directing during the 9-month training window (Decision 13). Design the attraction scope (Decision 9) toward modular, script-heavy content (Strategy 1) rather than high-risk improv, ensuring consistent, rehearsal-driven execution even with local talent.

## Risk 5 - Supply Chain / Vendor Management
Local vendor mandates (Decision 14) force the use of local security or temporary infrastructure providers who lack experience managing multi-day, high-capacity international music festivals, leading to safety lapses or significant logistical bottlenecks.

**Impact:** Major operational failure during the music festival (e.g., inadequate crowd flow management, slow setup/teardown), potentially leading to forced scaling back of the event footprint or regulatory fines related to non-compliance.

**Likelihood:** Medium

**Severity:** High

**Action:** In setting up the Local Stakeholder Sponsorship (Decision 12), require local security/infrastructure partners to partner with, or subcontract specialized expertise from, vetted international firms for core safety services, ensuring local entities receive the majority of the contract value while quality is maintained.

## Risk 6 - Integration / Transition
The planned transition structure (final run integrated with new festival opening) creates narrative collision instead of seamless momentum. The final bull run generates intense, negative, polarized attention that overshadows the planned opening ceremony of the new event.

**Impact:** Failure to achieve narrative pivot on July 7th. Media focus remains on the controversy of the final run rather than the innovation of the replacement, reducing initial ticket sales velocity (estimated 15% immediate impact).

**Likelihood:** High

**Severity:** Medium

**Action:** Mitigate via the Cultural Memory Integration Strategy (Decision 1—Museum Pavilion) which provides an established, non-confrontational narrative anchor. Use the formal communications style (Decision 2) to firmly define the narrative pivot point, minimizing spontaneous media interaction opportunities between July 6th and 7th.

## Risk 7 - Financial / Revenue Velocity
The co-production model for the music festival (Decision 5) results in poor talent draw for Year 1 because the promoter demands an unacceptably high revenue share to compensate for the perceived risk of a brand-new event in Pamplona, thus restricting capital available for marketing.

**Impact:** Inability to sell 70% of seats by Month 10, leading to low initial revenue velocity, insufficient funds to cover Year 1 operating costs, and a requirement to dip heavily into the Operational Buffer.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Maintain the long-term focus of the co-production strategy but establish a strict internal ceiling (e.g., 20% revenue share max) for the promoter. Simultaneously, Task Force personnel must actively hold alternative discussions with international talent agencies to quantify the cost of securing headliners directly if the co-production negotiation stalls above the ceiling.

## Risk 8 - Long-term Sustainability
The low-infrastructure nature of the stunt attraction proves unsustainable past the first year due to high performer turnover or difficulty in securing consistent, high-quality new comedic scripts annually, leading to audience fatigue.

**Impact:** The secondary attraction becomes redundant by Year 2, placing unsustainable reliance on the music festival's revenue stream and increasing the overall risk profile for Year 2 renewal budgets.

**Likelihood:** Medium

**Severity:** Low

**Action:** Ensure the employment model (Decision 7) prioritizes establishing a single, cohesive ensemble (Strategy 1) rather than cycling troupes. Allocate a small portion of the operational planning budget immediately to begin developing a secondary, more infrastructure-heavy stunt concept for Year 3 consideration, ensuring a pipeline exists.

## Risk summary
The project faces high risk in three critical intertwined areas: **Regulatory/Political Friction** (gaining municipal approval for the permanent museum and event staging), **Cultural Adoption/PR Management** (managing the polarized narrative during the immediate pivot from the final traditional run), and **Fiscal Prudence** (maintaining the 40% contingency buffer while meeting high upfront quality demands). The 'Pragmatic Foundation' selection correctly prioritizes fiscal safety (40% buffer) and managed cultural transition (museum integration) over aggressive, high-volatility strategies. Mitigation must disproportionately focus on proactive engagement with Pamplona's municipal government and ensuring the local procurement mandates do not compromise the operational quality of the primary Music Festival draw.

# Make Assumptions


## Question 1 - What specific target attendance and revenue goals define the financial success of the Year 1 music festival within the €25M budget framework?

**Assumptions:** Assumption: Year 1 Financial Success is defined by achieving cash-flow neutrality by the end of the 10-day event window, requiring a minimum of 70% overall capacity sell-through across all music and stunt attraction ticket tiers, equating to approximately €18 million in gross ticket revenue.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluation of initial revenue velocity required to support the project's scale.
Details: Achieving €18M revenue target hinges on the delegated European promoter securing compelling headliners via the co-production agreement (Decision 5). If sell-through falls below 60%, the 40% Operational Buffer (€10M) will need to cover the €3.6M marketing/guarantee deficit, risking the sustainability of the Memory Pavilion construction schedule. Mitigation requires aggressive Q3 2026 marketing commencement.

## Question 2 - What is the concrete target date for securing all major site access licenses (Music Festival Hub and Museum Pavilion) to ensure the 1-year timeline is feasible?

**Assumptions:** Assumption: The 1-year project timeline (starting ASAP, May 2026) mandates that all primary physical sites, particularly the permanent Memory Pavilion, must have construction permits secured by Q1 2027 to allow for a July 2027 grand operational opening.

**Assessments:** Title: Timeline and Regulatory Nexus Assessment
Description: Analyzing the critical path dependency between political negotiation and physical groundbreaking.
Details: Risk 1 (Regulatory & Permitting) is High Likelihood. Successful integration of the final bull run (July 2026) and the new festival launch (July 2027) requires firming up the Museum Pavilion location by Q4 2026. Failure here forces the pivot narrative (Decision 4) to become strained, as the permanent anchor is missing. Opportunity exists to use the quarterly town halls (Decision 2) to announce regulatory wins as proof of progress.

## Question 3 - Given the choice to train local performers for the stunt attraction, what is the validated ceiling headcount and associated fixed payroll cost allocated within the €25M budget for the core ensemble?

**Assumptions:** Assumption: The chosen performer sourcing model (Decision 13) involves training a core ensemble of 15 local stunt performers for 9 months, allocated a fixed soft-cost budget of €800,000, representing roughly 3.2% of the total capital.

**Assessments:** Title: Personnel Capacity and Cost Control Assessment
Description: Evaluating the cost and skill reliability of the human capital dedicated to the secondary attraction.
Details: The €800k investment is relatively low compared to the expected festival revenue drivers, placing pressure on the training quality (Risk 4). If the local ensemble performs poorly, external recruitment may be necessary mid-cycle, requiring reallocation from the Operational Buffer (Risk 2). Benefit: Strong goodwill aligned with Local Stakeholder Sponsorship (Decision 12).

## Question 4 - What specific mechanism is in place within the Stakeholder Engagement Cadence to counteract immediate political backlash from traditionalists who publicly endorse the project but privately lobby against the memory pavilion's location or scope?

**Assumptions:** Assumption: The Ministerial-level press releases used in the quarterly cadence (Decision 2, Strategy 1) will be supported by direct, designated liaison officers assigned to manage the five most politically sensitive local councils, supported by a dedicated €200k PR/Liaison budget line item.

**Assessments:** Title: Governance and Political Mitigation Assessment
Description: Assessing controls against internal stakeholder sabotage.
Details: The risk of 'backroom dealing' undermining public trust is noted in Decision 2. Dedicated liaison officers are necessary to manage the tension between public messaging and private negotiation (Decision 12). A failure in this area constitutes a mid-level governance risk, potentially stalling permitting if key local politicians feel sidelined by the Ministerial framing.

## Question 5 - What specific, measurable safety protocols will bridge the gap between the low-infrastructure nature of the stunt attraction and managing public interaction, particularly concerning crowd control near the performers?

**Assumptions:** Assumption: The stunt attraction will utilize portable, but certified, temporary barricading systems and require a licensed security ratio of 1:50 spectators (per local Spanish public assembly standards) for all performance zones, costing approximately €400,000 for the 10-day event run.

**Assessments:** Title: Safety & Compliance Risk Assessment
Description: Evaluating infrastructure compliance for the human-scale spectacle.
Details: The low-infrastructure constraint heightens the risk associated with crowd dynamics (Risk 5). Given the mandated use of local providers, the €400k allocation must be strictly controlled and likely co-managed with an international safety consultant to ensure compliance despite local vendor limitations. This directly ties into Risk 5 mitigation requirements.

## Question 6 - How will the environmental footprint of hosting a major new music festival (power generation, waste management, temporary structure transportation) be assessed and managed relative to Pamplona’s municipal sustainability targets?

**Assumptions:** Assumption: The plan assumes adherence to standard EU festival sustainability guidelines, requiring a projected 60% diversion rate for solid waste and the exclusive use of renewable energy sources/biofuels for all on-site temporary power generation, a cost estimated at €500,000.

**Assessments:** Title: Environmental Impact and Green Strategy Assessment
Description: Analyzing resource consumption and compliance against municipal environmental standards.
Details: While not explicitly a primary driver in the strategic decisions, significant environmental expenditure (€500k estimate) falls under the Operational Buffer (Decision 3). Failure to hit the 60% diversion rate could trigger significant municipal fines, increasing Risk 1 volatility. Opportunity exists to frame this positive environmental performance as a key feature in the stakeholder engagement cadence (Decision 2).

## Question 7 - How will cultural memory integration (museum pavilion) be leveraged to secure endorsements from progressive stakeholders who view any ritualistic commemoration as inherently problematic?

**Assumptions:** Assumption: The Museum Pavilion (Decision 1, Strategy 1) will be framed not as a celebration of the event, but as a sociological, educational study of historical risk, public spectacle, and cultural anthropology, specifically targeting academic and high-brow cultural critics for support.

**Assessments:** Title: Stakeholder Segmentation and Messaging Assessment
Description: Tailoring the memory strategy to satisfy progressive critics while placating traditionalists.
Details: This assessment focuses on satisfying the complex requirement of preserving memory without endorsing spectacle. Success depends on clear messaging differentiation: one message for traditionalists (continuity) and an academic/critical message for progressives (evolution/study). This directly influences the success of the Cultural Memory Integration Strategy alignment with external progressive audiences.

## Question 8 - What are the critical, non-negotiable performance benchmarks required from the Music Festival Promoter partner (via Decision 5, Strategy 3) to guarantee that the co-production agreement remains operationally sound and doesn't compromise service quality?

**Assumptions:** Assumption: The co-production agreement mandates the promoter guarantees 80% of artist fees are paid via deferred payment structures tied to ticket sales milestones, and requires the promoter to personally underwrite 100% of any regulatory fines incurred in Year 1 due to talent scheduling or contractor disputes.

**Assessments:** Title: Operational Systems Reliability Assessment
Description: Defining contractual safeguards for the project’s primary revenue and operational system.
Details: The assumption places significant financial risk transfer onto the promoter, insulating the €10M buffer from promoter failure on talent delivery. However, this aggressive position introduces Risk 7 (Revenue Velocity based on promoter commitment). The operational team must implement robust tracking systems to monitor the promoter’s adherence to the 80% deferred payment schedule, integrating this into the quarterly review process.

# Distill Assumptions

- Year 1 success requires €18 million gross ticket revenue, 70% sell-through.
- Primary site licenses, including museum, must be secured by Q1 2027.
- Fifteen local stunt performers are trained for 9 months; cost is €800,000.
- Ministerial press releases are supported by €200k for liaison officers.
- Stunt zones require 1:50 security ratio using certified temporary barricades.
- Festival assumes 60% waste diversion rate; temporary power costs €500,000.
- Memory pavilion framed as sociological study to secure progressive support.
- Promoter agreement mandates 80% artist fees deferred; promoter underwrites Year 1 fines.
- Project timeline is one year, targeting July 2027 operational opening.
- Project budget is €25 million total investment.
- Stunt performers will use portable, certified barricading systems.
- The project must use renewable biofuels for temporary power generation.
- Stunt attraction will utilize portable, certified temporary barricading systems.
- The stunt attraction structure must be low-infrastructure and human-scale.
- Stunt attraction must avoid extreme sports, pyrotechnics, robotics, or construction.
- The replacement festival pivots away from the final bull run immediately after.
- Cultural transition framing must aim for moderate acceptance by traditionalists.
- The project will not pick the most aggressive strategic scenario.
- The plan commits 60% budget to hard costs, reserving 40% as contingency.
- Contingency fund access is restricted until the operational review at month nine.
- The final bull run transitions directly into the new festival opening ceremony.
- Music talent secures headliners via a long-term co-production revenue-share agreement.
- The stunt attraction tone will emphasize slapstick and comedic physical vulnerability.
- Local procurement mandates 80% of non-talent ops spending stay within Navarre.
- Legacy remembrance is managed via a permanent, museum-quality historical pavilion.
- Stakeholder engagement uses strict quarterly town halls with Ministerial press releases.

# Review Assumptions

## Domain of the expert reviewer
Large-Scale Cultural Transition and Public Project Management

## Domain-specific considerations

- Political & Cultural Stakeholder Management in Tradition-Heavy Contexts
- Financial Resilience for Novel, High-Visibility Public Initiatives
- Logistical Planning for Large City-Center Festivals
- Narrative Control and Societal Acceptance Metrics

## Issue 1 - Missing Assumption: Sustainability of Revenue (Post Year 1)
The plan assumes critical success hinges on Year 1 goals (€18M revenue, 70% sell-through) supporting the immediate €25M investment. However, a critical missing assumption is the **guaranteed funding mechanism or revenue target for Year 2 and beyond.** The 40% operational buffer (€10M) is a *contingency* for Year 1 failures, not Year 2 operating costs. If the Year 1 replacement festival is successful but only breaks even, the sustainability of the permanent 'Museum-Quality Pavilion' (a long-term liability chosen in the 'Pragmatic Foundation') is immediately threatened.

**Recommendation:** Immediately establish the financial model for Year 2/3 sustainability. Assume the Memory Pavilion requires a fixed annual operational budget of €400K (conservative estimate for museum upkeep/staffing). Define the required Year 1 gross profit margin (Targeting 15% retained profit / €3.75M) that must be achieved *after* Year 1 contingency disbursement to start seeding the Year 2 operational fund. If the current €18M revenue goal is insufficient, adjust talent phasing (Decision 5) to secure higher initial ticket velocity, or cap the Pavilion's initial fit-out scope.

**Sensitivity:** If Year 1 only achieves break-even (0% retained profit, baseline of €0 retained), the project faces an immediate operational funding gap of €400K for the Museum Pavilion in Year 2. If this gap is covered by the remaining Operational Buffer (still holding ~€4M), it reduces the buffer for genuine unforeseen Year 1 risks by 10%. If no Year 2 funding mechanism is established, the projected ROI timeline collapses after Year 1, as the cultural asset (Pavilion) becomes immediately vulnerable to budget cuts.

## Issue 2 - Unrealistic Assumption: Complete Narrative Control via Bandwidth-Limited Engagement
The chosen Stakeholder Engagement Cadence (Decision 2, Strategy 1) relies on strict quarterly town halls for operations and Ministerial press releases for culture. In a high-stakes cultural pivot, this deliberately *low* bandwidth (especially avoiding bi-weekly or continuous feedback loops) makes the assumption that the project can maintain narrative control unrealistic. Criticism moves faster than quarterly announcements. Furthermore, relying solely on Ministerial releases risks creating the 'backroom dealing' perception if internal negotiations regarding sponsorship (Decision 12) are not transparently linked to the Quarterly Reports.

**Recommendation:** Augment the quarterly cadence with a mandated, structured 'Rapid Response' protocol. For every major decision point (e.g., final talent announcements, memory pavilion location selection), deploy a dedicated digital/media task force to immediately address anticipated backlash within 48 hours, utilizing the PR Liaison budget (€200k). Furthermore, publicly link Local Stakeholder Transition Sponsorship milestones to the quarterly operational reports to validate the narrative structure.

**Sensitivity:** If negative local sentiment is allowed to solidify unchallenged for 90 days (baseline: QTRly cycle), the resulting media saturation rate related to the transition could increase by 40-60%, leading to a projected 10-15% immediate slump in initial ticket sales velocity compared to the 70% break-even target. This equates to a lost revenue of €1.8M - €2.7M in Year 1.

## Issue 3 - Under-Explored Assumption: Impact of Local Procurement Mandates on Quality and Timeline
Decision 14 mandates 80% of non-talent OPEX stay within Navarre, which strongly supports Decision 12 (Sponsorship). However, the existing assumptions only vaguely estimate the cost of this (€400K for security staffing) and note potential 'service level inconsistencies.' The critical missing detail is the *time penalty* associated with vetting, onboarding, and potentially re-training or overseeing less experienced, mandatory local vendors (e.g., temporary fencing, local catering, localized construction oversight for the pavilion).

**Recommendation:** Immediately conduct a 'Local Vendor Capability Audit' for the top 5 anticipated procurement categories (excluding hospitality). Based on this audit, bake in a 15% administrative overhead contingency *specifically* for quality assurance and expedited rework queues when dealing with mandatory local vendors. If the audit reveals significant gaps, adjust the procurement mandate (Decision 14) to include a requirement for local vendors to partner with, or subcontract proven international expertise for critical safety/infrastructure elements (similar to Risk 5 mitigation).

**Sensitivity:** If the required quality assurance/oversight for local vendors adds just 5% overhead to the total operational/infrastructure spend (Baseline: ~€12M of the €25M total budget allocated to hard/operational costs), this adds €600,000 in management costs. This directly draws down the Operational Buffer. A resulting 1-month delay in securing the Pavilion site due to contractor mobilization issues (Risk 1 dependency) could cost an estimated €150,000 in additional financing/holding costs.

## Review conclusion
The project plan demonstrates strong strategic alignment with the difficult goal of cultural transition by thoughtfully balancing narrative management (Memory Integration) and fiscal prudence (40% buffer). However, three critical planning gaps must be addressed immediately: 1) The lack of a defined Year 2 operational budget threatens the long-term viability of the permanent cultural asset chosen; 2) The assumed narrative control based on a slow engagement cadence is politically naive for a high-profile abolitionist change and must be backed by proactive media response protocols; and 3) The 80% local procurement mandate introduces an unquantified, yet significant, risk of timeline delays and quality overhead draw on the contingency fund. Addressing these unknowns before detailed execution begins is vital to protecting the initial investment and achieving long-term success.