**Purpose:** business

**Purpose Detailed:** Commercial venture focused on developing and mass-producing blood-testing devices for profit.

**Topic:** Startup for mass production of blood-testing devices