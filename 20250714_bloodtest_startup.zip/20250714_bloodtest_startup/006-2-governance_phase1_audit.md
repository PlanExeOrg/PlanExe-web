
## Audit - Corruption Risks

- Bribery of regulatory officials (FDA, CLIA) to expedite approvals or overlook non-compliance issues.
- Kickbacks from suppliers of manufacturing equipment or raw materials in exchange for awarding contracts.
- Conflicts of interest involving employees with financial ties to competing companies or suppliers.
- Nepotism in hiring, particularly for key roles in manufacturing, regulatory affairs, or quality control, potentially compromising competence and objectivity.
- Misuse of confidential information regarding competitors' technologies or regulatory strategies obtained through improper channels.

## Audit - Misallocation Risks

- Inflated invoices from contractors building the manufacturing facility in Newark, with the excess funds diverted for personal use.
- Double-billing for R&D expenses, claiming the same costs under multiple projects or grants.
- Inefficient allocation of the $50 million budget, with excessive spending on non-essential items or activities.
- Unauthorized use of company assets, such as equipment or vehicles, for personal gain.
- Misreporting of project progress or results to secure further funding or meet deadlines, despite actual performance lagging behind.

## Audit - Procedures

- Conduct quarterly internal audits of financial records, focusing on procurement, expense reports, and payroll, with a specific focus on R&D and manufacturing costs.
- Implement a mandatory ethics training program for all employees, with annual refresher courses, covering topics such as conflicts of interest, anti-bribery, and data privacy.
- Perform annual external audits of the quality management system (QMS) to ensure compliance with 21 CFR Part 820 and other relevant regulations.
- Establish a whistleblower hotline and protection policy to encourage reporting of suspected wrongdoing, with independent investigation of all complaints.
- Review all contracts with suppliers and contractors exceeding $100,000 by an independent legal counsel to ensure fair pricing and prevent conflicts of interest.

## Audit - Transparency Measures

- Publish a project progress dashboard accessible to investors and key stakeholders, showing key milestones, budget expenditures, and regulatory approval status.
- Maintain detailed minutes of all board meetings and make them available to investors upon request.
- Establish a publicly available policy on data privacy and security, outlining how patient data is collected, stored, and used.
- Document the selection criteria and justification for all major vendors and contractors, particularly those involved in manufacturing and regulatory affairs.
- Implement a system for tracking and disclosing potential conflicts of interest for all employees, with regular updates and reviews.