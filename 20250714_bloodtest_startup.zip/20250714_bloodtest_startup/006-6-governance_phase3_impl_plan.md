### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Core Team ToR v0.1

**Dependencies:**

- Project Plan Approved

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project Plan Approved

### 4. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.1

**Dependencies:**

- Project Plan Approved

### 5. Circulate Draft SteerCo ToR for review by proposed members (CEO, CTO, CMO, CFO, Independent Board Member).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on SteerCo ToR

**Dependencies:**

- Draft SteerCo ToR v0.1

### 6. Circulate Draft Core Team ToR for review by proposed members (Project Manager, Lead Scientist, Manufacturing Manager, Regulatory Affairs Manager, Marketing Manager, Data Security Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on Core Team ToR

**Dependencies:**

- Draft Core Team ToR v0.1

### 7. Circulate Draft TAG ToR for review by proposed members (Lead Scientist, External Expert in Microfluidics, External Expert in Biochemistry, Data Science Lead, Manufacturing Engineer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on TAG ToR

**Dependencies:**

- Draft TAG ToR v0.1

### 8. Circulate Draft ECC ToR for review by proposed members (Regulatory Affairs Manager, Data Security Officer, Legal Counsel, External Ethics Consultant, Patient Advocate).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on ECC ToR

**Dependencies:**

- Draft ECC ToR v0.1

### 9. Project Manager finalizes the Project Steering Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary on SteerCo ToR

### 10. Project Manager finalizes the Core Project Team Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Core Team ToR v1.0

**Dependencies:**

- Feedback Summary on Core Team ToR

### 11. Project Manager finalizes the Technical Advisory Group Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final TAG ToR v1.0

**Dependencies:**

- Feedback Summary on TAG ToR

### 12. Project Manager finalizes the Ethics & Compliance Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final ECC ToR v1.0

**Dependencies:**

- Feedback Summary on ECC ToR

### 13. CEO formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** CEO

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 14. CEO formally confirms Project Steering Committee membership.

**Responsible Body/Role:** CEO

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Final SteerCo ToR v1.0

### 15. Project Steering Committee Chair schedules and facilitates the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Email
- Membership Confirmation Emails

### 16. Project Manager formally confirms Core Project Team membership.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Final Core Team ToR v1.0

### 17. Project Manager schedules and facilitates the initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Core Team Kick-off Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation Emails

### 18. Project Manager, in consultation with the Lead Scientist, confirms Technical Advisory Group membership.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Final TAG ToR v1.0

### 19. Lead Scientist schedules and facilitates the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Lead Scientist

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- TAG Kick-off Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation Emails

### 20. Regulatory Affairs Manager confirms Ethics & Compliance Committee membership.

**Responsible Body/Role:** Regulatory Affairs Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Final ECC ToR v1.0

### 21. Regulatory Affairs Manager schedules and facilitates the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Regulatory Affairs Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- ECC Kick-off Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation Emails

### 22. Project Steering Committee reviews and approves the initial project plan and budget.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved Project Plan v1.0
- Approved Project Budget v1.0

**Dependencies:**

- SteerCo Kick-off Meeting Minutes with Action Items
- Core Team Kick-off Meeting Minutes with Action Items
- TAG Kick-off Meeting Minutes with Action Items
- ECC Kick-off Meeting Minutes with Action Items

### 23. Core Project Team develops detailed project schedule.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Detailed Project Schedule v1.0

**Dependencies:**

- Approved Project Plan v1.0

### 24. Technical Advisory Group reviews and approves technical specifications and designs.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Approved Technical Specifications v1.0
- Approved Technical Designs v1.0

**Dependencies:**

- TAG Kick-off Meeting Minutes with Action Items

### 25. Ethics & Compliance Committee develops a code of ethics and compliance.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Code of Ethics and Compliance v1.0

**Dependencies:**

- ECC Kick-off Meeting Minutes with Action Items