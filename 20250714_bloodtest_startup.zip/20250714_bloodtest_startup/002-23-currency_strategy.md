This plan involves money.

## Currencies

- **USD:** Primary currency for the project, as the manufacturing will be in Newark, California.

**Primary currency:** USD

**Currency strategy:** USD will be used for all transactions. No additional international risk management is needed.