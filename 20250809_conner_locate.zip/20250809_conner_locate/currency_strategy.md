This plan involves money.

## Currencies

- **CHF:** Local currency for operations in Switzerland (Geneva).
- **MAD:** Local currency for operations in Morocco (Casablanca).
- **EUR:** Local currency for operations in Austria (Vienna).
- **USD:** Stable currency for budgeting and potential international transactions.

**Primary currency:** USD

**Currency strategy:** USD is recommended for budgeting and reporting to mitigate risks from exchange fluctuations. Local currencies (CHF, MAD, EUR) will be used for local transactions. Hedging against exchange fluctuations may be necessary for larger transactions.