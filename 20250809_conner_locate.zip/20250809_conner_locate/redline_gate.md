**Verdict:** 🔴 REFUSE

**Rationale:** This request seeks operational details for a covert mission to locate a specific individual, which could be used for harmful purposes.

### Violation Details

| Detail                | Value |
|-----------------------|-------|
| **Category**              | Privacy Violation |
| **Claim**                 | Targeted surveillance |
| **Capability Uplift**     | Yes |
| **Severity**              | High |