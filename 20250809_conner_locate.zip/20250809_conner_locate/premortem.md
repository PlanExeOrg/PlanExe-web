A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Human intelligence sources will provide reliable and actionable information consistently throughout the operation. | Compare initial intelligence reports from human sources with publicly available information to assess accuracy. | Initial intelligence reports from human sources are demonstrably inaccurate or unverifiable compared to public sources. |
| A2 | Secure physical communication channels will remain uncompromised and effective for transmitting sensitive information. | Conduct a TSCM (Technical Surveillance Countermeasures) sweep of a designated 'secure' physical meeting location. | The TSCM sweep detects active or passive surveillance devices in the designated 'secure' location. |
| A3 | The project budget of $2,000,000 USD will be sufficient to cover all operational expenses for 24 months. | Create a detailed bottom-up cost estimate for all planned activities, including personnel, travel, equipment, and contingencies. | The bottom-up cost estimate exceeds the allocated budget by more than 10%. |
| A4 | Local authorities in Switzerland, Morocco, and Austria will remain neutral and not actively interfere with the covert operation, provided it remains discreet. | Conduct a discreet background check on key law enforcement officials in each country to assess their potential biases or connections to John Connor. | Evidence emerges of active collaboration between local law enforcement and John Connor or his known associates. |
| A5 | The political and social climate in Switzerland, Morocco, and Austria will remain stable throughout the 24-month duration of the operation, allowing for consistent operational activities. | Monitor political and social indicators (e.g., protest activity, political instability indices) in each country for significant deviations from historical norms. | A major political upheaval or social unrest event occurs in any of the three operational countries, significantly disrupting planned activities. |
| A6 | John Connor will remain within the specified operational area (Switzerland, Morocco, Austria) for the majority of the 24-month operation. | Analyze historical travel patterns and known associates of John Connor to assess the likelihood of him remaining within the specified region. | Credible intelligence indicates that John Connor has permanently relocated outside of the specified operational area. |
| A7 | The team possesses sufficient cultural sensitivity and linguistic skills to effectively navigate and interact with local populations in Switzerland, Morocco, and Austria without arousing suspicion or causing offense. | Conduct blind cultural competency assessments of team members, evaluating their understanding of local customs, etiquette, and communication styles. | Team members consistently score below a pre-defined threshold on cultural competency assessments, indicating a lack of necessary cultural awareness. |
| A8 | The technology and equipment required for the covert operation (e.g., secure communication devices, surveillance tools) will be readily available and function reliably throughout the 24-month duration. | Conduct a thorough assessment of the supply chain for critical technology and equipment, evaluating potential disruptions, lead times, and reliability of vendors. | Significant delays or disruptions are identified in the supply chain for critical technology or equipment, jeopardizing the operation's timeline or capabilities. |
| A9 | John Connor's behavior and movements will be predictable enough to allow for effective tracking and anticipation of his actions. | Analyze historical data on John Connor's past behavior and movements to identify patterns and predict future actions. | Analysis reveals a complete lack of discernible patterns in John Connor's past behavior, rendering predictive analysis ineffective. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Austerity Abyss | Process/Financial | A3 | Financial Manager | CRITICAL (20/25) |
| FM2 | The Ghost Network | Technical/Logistical | A2 | Security Personnel | CRITICAL (15/25) |
| FM3 | The Informant's Gambit | Market/Human | A1 | Intelligence Analyst | CRITICAL (20/25) |
| FM4 | The Transnational Chase | Process/Financial | A6 | Financial Manager | CRITICAL (15/25) |
| FM5 | The Arab Spring Echo | Technical/Logistical | A5 | Security Personnel | HIGH (10/25) |
| FM6 | The Swiss Double-Cross | Market/Human | A4 | Intelligence Analyst | CRITICAL (15/25) |
| FM7 | The Labyrinthine Trail | Process/Financial | A9 | Financial Manager | CRITICAL (20/25) |
| FM8 | The Digital Desert | Technical/Logistical | A8 | Security Personnel | CRITICAL (15/25) |
| FM9 | The Cultural Minefield | Market/Human | A7 | Intelligence Analyst | CRITICAL (20/25) |


### Failure Modes

#### FM1 - The Austerity Abyss

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A3
- **Owner**: Financial Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's initial budget of $2,000,000 proves woefully inadequate. Unforeseen expenses related to maintaining multiple cover identities, securing safe houses, and bribing corrupt officials quickly deplete the allocated funds. Currency exchange rate fluctuations further erode the budget's purchasing power. As funds dwindle, the team is forced to make drastic cuts, compromising operational security and effectiveness. Key personnel are laid off, safe houses are abandoned, and intelligence gathering efforts are scaled back. The lack of resources makes it impossible to adapt to changing circumstances or respond to emerging threats. The project grinds to a halt, unable to achieve its objectives due to financial insolvency. The team is left scrambling to cover their tracks, facing potential legal and financial repercussions.

##### Early Warning Signs
- Monthly expenses exceed budgeted amounts by more than 15%
- Contingency funds are depleted by 50% within the first 6 months
- Key suppliers demand upfront payments due to concerns about the project's financial stability

##### Tripwires
- Remaining cash reserves <= $500,000 USD
- Projected cost overruns >= 20% of initial budget
- Critical vendor payments delayed by >= 30 days

##### Response Playbook
- Contain: Immediately freeze all non-essential spending.
- Assess: Conduct a forensic audit to identify areas of cost overruns and potential savings.
- Respond: Secure additional funding from alternative sources or drastically scale back the project's scope.


**STOP RULE:** Remaining funds are insufficient to cover essential operational expenses for the next 3 months.

---

#### FM2 - The Ghost Network

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Security Personnel
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The team's reliance on secure physical communication channels proves to be a fatal flaw. Despite efforts to maintain secrecy, local intelligence agencies are able to intercept and decipher coded messages passed through dead drops and couriers. The team's movements are tracked, their identities are compromised, and their safe houses are raided. The reliance on physical channels makes it impossible to react quickly to emerging threats or coordinate effectively. Operatives are forced to operate in isolation, unable to share critical information or seek assistance. The operation unravels as the team is systematically hunted down and neutralized. The lack of secure digital communication leaves them vulnerable to modern surveillance techniques, rendering their efforts futile.

##### Early Warning Signs
- Increased surveillance activity observed near designated 'secure' locations
- Unexplained delays or disruptions in physical communication channels
- Operatives report feeling 'watched' or experiencing unusual encounters

##### Tripwires
- Compromise of >= 2 physical communication channels
- Detection of surveillance devices in >= 3 designated 'secure' locations
- Unexplained disappearance of >= 1 courier

##### Response Playbook
- Contain: Immediately suspend all physical communication and switch to encrypted digital channels.
- Assess: Conduct a thorough investigation to identify the source of the compromise.
- Respond: Implement enhanced counter-surveillance measures and relocate all compromised assets.


**STOP RULE:** Critical operational plans are leaked to external parties due to compromised communication channels.

---

#### FM3 - The Informant's Gambit

- **Archetype**: Market/Human
- **Root Cause**: Assumption A1
- **Owner**: Intelligence Analyst
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The team's reliance on human intelligence proves to be a double-edged sword. A key informant, motivated by greed and a desire for self-preservation, begins feeding the team false and misleading information. The team, blinded by their trust in this source, acts on this misinformation, leading them down a series of dead ends and wasting valuable resources. Meanwhile, the informant is secretly working with John Connor, providing him with information about the team's activities and helping him evade capture. As the team gets closer to Connor, the informant orchestrates a trap, leading them into a dangerous situation where they are ambushed and captured. The operation is exposed, the team's reputation is tarnished, and their efforts to locate Connor are thwarted.

##### Early Warning Signs
- Intelligence reports from the key informant consistently contradict information from other sources
- The key informant becomes increasingly evasive or secretive about their activities
- The team experiences a series of unexpected setbacks or failures that seem suspiciously orchestrated

##### Tripwires
- Accuracy rate of key informant's intelligence <= 50%
- Key informant fails to pass a polygraph test
- Unexplained financial transactions detected in key informant's bank account >= $10,000 USD

##### Response Playbook
- Contain: Immediately suspend reliance on the compromised informant.
- Assess: Conduct a thorough review of all intelligence provided by the informant to identify potential inaccuracies.
- Respond: Implement enhanced source verification protocols and diversify intelligence gathering efforts.


**STOP RULE:** The key informant is confirmed to be actively working against the team's interests.

---

#### FM4 - The Transnational Chase

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A6
- **Owner**: Financial Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The team diligently establishes cover identities, secures safe houses, and cultivates human sources within Switzerland, Morocco, and Austria. However, after months of fruitless searching, credible intelligence emerges indicating that John Connor has relocated to South America. The team is faced with a difficult decision: abandon their existing infrastructure and pursue Connor across international borders, or remain within their established operational area and risk losing him forever. The decision to pursue Connor triggers a cascade of financial and logistical challenges. Existing assets become useless, new cover identities must be established, and new relationships must be cultivated in a foreign and unfamiliar environment. The project's budget is stretched to its breaking point, and the team struggles to maintain operational security while operating in a new and hostile territory. The operation ultimately fails due to a lack of resources and the inability to adapt to Connor's unpredictable movements.

##### Early Warning Signs
- Intelligence reports consistently place Connor near border regions of the operational area
- Unexplained delays in confirming Connor's presence at previously identified locations
- Increased chatter among human sources about Connor's potential relocation

##### Tripwires
- Confirmed sighting of John Connor outside the operational area
- Relocation costs exceed 25% of the initial budget
- New intelligence indicates Connor is actively planning to leave the operational area

##### Response Playbook
- Contain: Immediately freeze all non-essential spending in the current operational area.
- Assess: Conduct a rapid assessment of the financial and logistical implications of pursuing Connor to the new location.
- Respond: Secure additional funding from alternative sources or drastically scale back the project's scope to focus on the most promising leads.


**STOP RULE:** The cost of pursuing John Connor outside the initial operational area exceeds 50% of the remaining budget.

---

#### FM5 - The Arab Spring Echo

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Security Personnel
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The team carefully establishes a network of safe houses and communication channels in Casablanca, Morocco. However, unforeseen political instability erupts as widespread protests against government corruption and economic inequality sweep across the country. The team's activities are disrupted as curfews are imposed, travel is restricted, and communication networks are shut down. The team's safe houses are compromised as local authorities crack down on suspected dissidents and foreign agents. Operatives are forced to go into hiding, unable to gather intelligence or coordinate effectively. The operation unravels as the team is caught in the crossfire of political unrest. The lack of contingency plans for political instability leaves them vulnerable and unable to adapt to the rapidly changing circumstances.

##### Early Warning Signs
- Increased protest activity and social unrest in Casablanca
- Government restrictions on travel and communication
- Reports of increased police surveillance and crackdowns on suspected dissidents

##### Tripwires
- Imposition of a nationwide state of emergency in Morocco
- Compromise of >= 2 safe houses due to political unrest
- Disruption of communication networks for >= 72 hours

##### Response Playbook
- Contain: Immediately evacuate all non-essential personnel from Casablanca.
- Assess: Conduct a rapid assessment of the security situation and identify alternative operational locations.
- Respond: Relocate all essential personnel and assets to a more stable region or suspend operations until the political situation improves.


**STOP RULE:** The security situation in Morocco deteriorates to the point where the safety of operatives cannot be guaranteed.

---

#### FM6 - The Swiss Double-Cross

- **Archetype**: Market/Human
- **Root Cause**: Assumption A4
- **Owner**: Intelligence Analyst
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The team believes they have successfully established a discreet presence in Geneva, Switzerland, confident that local authorities are unaware of their activities. However, unbeknownst to them, a high-ranking official within the Swiss Federal Intelligence Service (FIS) is secretly working with John Connor. This official, motivated by a personal vendetta against the team's sponsor, provides Connor with detailed information about their operation, including their identities, safe houses, and communication channels. The team is lured into a trap, their safe houses are raided, and their operatives are arrested on trumped-up charges. The operation is exposed, the team's reputation is tarnished, and their efforts to locate Connor are thwarted. The betrayal by a trusted authority figure leaves them vulnerable and unable to defend themselves against the coordinated attack.

##### Early Warning Signs
- Unexplained delays in obtaining necessary permits or licenses
- Increased scrutiny from local law enforcement agencies
- Suspicious activity observed near team's safe houses or communication channels

##### Tripwires
- Confirmed contact between a Swiss FIS official and John Connor
- Leak of sensitive operational information to local media
- Arrest of >= 2 operatives on questionable charges

##### Response Playbook
- Contain: Immediately suspend all operations in Switzerland and evacuate all personnel.
- Assess: Conduct a thorough investigation to identify the source of the leak and assess the extent of the damage.
- Respond: Seek diplomatic intervention from the team's sponsor or expose the corruption within the Swiss FIS to international media.


**STOP RULE:** The Swiss government officially accuses the team of espionage and demands their extradition.

---

#### FM7 - The Labyrinthine Trail

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Financial Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The team invests heavily in advanced surveillance technology and cultivates a network of informants, meticulously tracking John Connor's every move. However, Connor's behavior proves to be erratic and unpredictable, defying all attempts at pattern analysis. He abruptly changes locations, alters his routines, and employs sophisticated counter-surveillance techniques to evade detection. The team is forced to constantly reallocate resources and adapt their strategies, leading to significant cost overruns and operational inefficiencies. The constant chasing of false leads and dead ends drains the project's budget, leaving them unable to pursue promising new avenues of investigation. The operation ultimately fails due to the inability to anticipate Connor's actions and the unsustainable financial burden of chasing an elusive target.

##### Early Warning Signs
- Intelligence reports consistently place Connor in multiple locations simultaneously
- Surveillance efforts repeatedly fail to capture Connor on camera or confirm his presence at identified locations
- Predictive models consistently fail to accurately forecast Connor's movements

##### Tripwires
- Surveillance costs exceed budgeted amounts by >= 30%
- Number of false leads pursued >= 5 per month
- Predictive model accuracy rate <= 20%

##### Response Playbook
- Contain: Immediately suspend all predictive analysis efforts and re-evaluate the team's intelligence gathering strategy.
- Assess: Conduct a thorough review of Connor's past behavior to identify any previously overlooked patterns or anomalies.
- Respond: Implement a more reactive intelligence gathering approach, focusing on immediate threats and opportunities rather than long-term predictions.


**STOP RULE:** The cost of surveillance and intelligence gathering exceeds the value of the potential reward, rendering the operation financially unsustainable.

---

#### FM8 - The Digital Desert

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Security Personnel
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The team relies heavily on advanced technology and equipment to conduct their covert operation. However, unforeseen disruptions in the global supply chain lead to critical shortages of secure communication devices and surveillance tools. Existing equipment malfunctions frequently, and replacement parts are unavailable. The team is forced to rely on outdated and unreliable technology, compromising their operational security and effectiveness. Communication channels are easily intercepted, surveillance efforts are thwarted, and the team is left vulnerable to detection. The lack of reliable technology makes it impossible to adapt to changing circumstances or respond to emerging threats. The operation unravels as the team is outmaneuvered and outgunned by their adversaries.

##### Early Warning Signs
- Significant delays in receiving ordered technology and equipment
- Increased failure rate of existing technology and equipment
- Reports of supply chain disruptions affecting critical components

##### Tripwires
- Critical technology and equipment shortages >= 30 days
- Failure rate of existing equipment >= 20%
- Vendor declares bankruptcy or ceases operations

##### Response Playbook
- Contain: Immediately implement backup communication and surveillance protocols using readily available resources.
- Assess: Conduct a thorough assessment of the supply chain and identify alternative vendors or sources of equipment.
- Respond: Secure alternative sources of technology and equipment or drastically scale back the project's reliance on technology.


**STOP RULE:** The team is unable to secure reliable communication or surveillance capabilities within a reasonable timeframe, rendering the operation technically infeasible.

---

#### FM9 - The Cultural Minefield

- **Archetype**: Market/Human
- **Root Cause**: Assumption A7
- **Owner**: Intelligence Analyst
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The team, despite their best intentions, lacks the necessary cultural sensitivity and linguistic skills to effectively navigate and interact with local populations in Switzerland, Morocco, and Austria. Their clumsy attempts at blending in arouse suspicion and offend local customs. Misunderstandings and miscommunications lead to strained relationships with potential informants and collaborators. The team is perceived as arrogant and disrespectful, alienating local communities and hindering their ability to gather intelligence. Their cultural blunders are amplified by social media, attracting unwanted attention from law enforcement and media outlets. The operation is exposed, the team's reputation is tarnished, and their efforts to locate Connor are thwarted.

##### Early Warning Signs
- Complaints from local communities about the team's behavior
- Increased scrutiny from local law enforcement agencies
- Negative media coverage of the team's activities

##### Tripwires
- Formal complaints filed by local community leaders
- Negative media coverage reaches national level
- Operatives are denied access to key locations due to cultural insensitivity

##### Response Playbook
- Contain: Immediately suspend all direct interaction with local communities and implement enhanced cultural sensitivity training.
- Assess: Conduct a thorough review of the team's cultural competency and identify areas for improvement.
- Respond: Engage local cultural experts to provide guidance and facilitate communication with local communities.


**STOP RULE:** The team's cultural insensitivity leads to a significant diplomatic incident or legal action, jeopardizing the operation's viability.
