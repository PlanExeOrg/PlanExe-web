Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 14 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 5 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The goal is to locate a person, which is within the realm of possibility using real-world technology.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan combines multiple novel elements (covert operation + international locations + real-world tech + plausible deniability) without evidence of prior success at comparable scale. There is no mention of precedent for this specific combination.

**Mitigation**: Run parallel validation tracks for Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Define NO-GO gates for empirical validity and legal clearance. Project Manager: Validation Report / 2026-Apr-26


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions strategic concepts like 'Consolidator's Path' without defining their mechanism-of-action (inputs→process→customer value), owner, or measurable outcomes. The plan states, 'The Consolidator's Path directly addresses the plan's emphasis on security'.

**Mitigation**: Project Manager: Create one-pagers for each strategic path, defining the value hypothesis, success metrics, and decision hooks for each, by 2026-Apr-26.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies some second-order risks (legal, financial, social) and includes mitigation actions. However, it lacks explicit cascade analysis (e.g., permit delay → cost overrun). The risk register is present, but cascade mapping is absent.

**Mitigation**: Risk Manager: Map risk cascades from the risk register, adding controls and a dated review cadence, by 2026-Apr-26.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions 'Surveillance permits, Data privacy licenses, Financial transaction permits' but lacks a matrix linking activities to required approvals and lead times.

**Mitigation**: Legal Counsel: Create a permit/approval matrix with activities, jurisdictions, lead times, and NO-GO thresholds, by 2026-Apr-26.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan states a budget of $2,000,000 USD with $200,000 USD contingency, but expert reviews suggest this is insufficient. Funding sources, draw schedule, and covenants are undefined. Runway length is not explicitly stated.

**Mitigation**: Financial Manager: Develop a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO-GO on missed financing gates, by 2026-Apr-26.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of $2,000,000 conflicts with expert reviews suggesting it's insufficient for a 24-month multi-national covert operation. Benchmarks or per-area cost calculations are absent.

**Mitigation**: Financial Manager: Benchmark costs (≥3) for similar covert operations, normalize per-area (m²/ft²), and adjust budget or de-scope by 2026-Apr-26.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (budget, timeline) as single numbers without ranges or alternative scenarios. For example, the budget is stated as '$2,000,000 USD, with $200,000 USD contingency'.

**Mitigation**: Financial Manager: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the budget projection by 2026-Apr-26.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions strategic concepts like 'Consolidator's Path' without defining their mechanism-of-action (inputs→process→customer value), owner, or measurable outcomes. The plan states, 'The Consolidator's Path directly addresses the plan's emphasis on security'.

**Mitigation**: Project Manager: Create one-pagers for each strategic path, defining the value hypothesis, success metrics, and decision hooks for each, by 2026-Apr-26.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes several critical claims without providing verifiable evidence. For example, the plan states, 'Secure safe houses in key locations' but lacks any documentation of agreements, leases, or ownership for these locations.

**Mitigation**: Project Manager: Compile an evidence pack with verifiable artifacts (documents, links, IDs) for all critical claims, or de-scope the project, by 2026-Apr-26.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions 'the confirmed location of John Connor' without specific, verifiable qualities. What constitutes 'confirmed'? What level of certainty is required?

**Mitigation**: Project Manager: Define SMART criteria for 'confirmed location', including a KPI for location accuracy (e.g., within 100 meters), by 2026-Apr-26.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan emphasizes 'Cover Identity Breadth' by establishing a network of interconnected identities. This adds complexity without clear support for the core goal: locating John Connor. The plan states, 'to mitigate risks associated with exposure'.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the 'Cover Identity Breadth' feature, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog by 2026-Apr-26.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Cover Identity Specialist' role is mission-critical for creating believable covers, but the plan lacks evidence of talent availability. The plan states, 'Expert in creating and maintaining believable cover identities'.

**Mitigation**: HR: Conduct a talent market survey for 'Cover Identity Specialist' roles in relevant geographic areas, assessing availability and cost, by 2026-Apr-26.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions 'Surveillance permits, Data privacy licenses, Financial transaction permits' but lacks a matrix linking activities to required approvals and lead times.

**Mitigation**: Legal Counsel: Create a permit/approval matrix with activities, jurisdictions, lead times, and NO-GO thresholds, by 2026-Apr-26.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan lacks a detailed operational sustainability plan. It mentions 'decommission cover identities and assets' but omits funding/resource strategy, maintenance schedule, succession planning, technology roadmap, or adaptation mechanisms.

**Mitigation**: Project Manager: Develop an operational sustainability plan including funding strategy, maintenance schedule, succession plan, technology roadmap, and adaptation mechanisms by 2026-May-30.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies locations (Geneva, Casablanca, Vienna) but lacks evidence of zoning compliance, structural limits, or noise restrictions. The plan states, 'Suggested locations... offer a combination of international environments'.

**Mitigation**: Real Estate Team: Perform a fatal-flaw screen for zoning/land-use, occupancy/egress, fire load, structural limits, and noise at each location by 2026-Apr-26.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies external dependencies (vendors, data, facilities) but lacks evidence of SLAs or tested failovers. The plan mentions 'Secure safe houses in key locations' but lacks details on vendor contracts or backup facilities.

**Mitigation**: Procurement: Secure SLAs with key vendors (facilities, data providers) and document tested failover procedures by 2026-May-30.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan states goals for 'Operatives' (gain valuable experience) and 'Investors' (receive a return). A conflict exists where operatives may prioritize risky actions for experience, conflicting with investor ROI. The plan does not address this.

**Mitigation**: Project Manager: Define a shared OKR (Objective and Key Results) that aligns operative skill development with investor ROI, by 2026-Apr-26.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop) are absent. Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board with escalation thresholds by 2026-Apr-26.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has ≥3 High risks (Budget Inadequate, Unrealistic Timeline, Over-Reliance on HUMINT) that are strongly coupled. A budget shortfall can trigger a cascade of failures across multiple domains. The plan lacks a cross-impact analysis.

**Mitigation**: Risk Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by 2026-Apr-26.