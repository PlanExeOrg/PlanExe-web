**Purpose:** business

**Purpose Detailed:** Covert operation with strategic planning and resource management for a high-stakes objective.

**Topic:** Locating a person of interest (John Connor)