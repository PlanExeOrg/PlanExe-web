## Positive Constraints

- Locate John Connor
- John Connor may go by another identity
- John Connor may have changed appearance
- Covert mission
- Run under disguise
- Use real world technology
- Use multiple burnable covers
- Use plausible deniability
- Ultimate goal is more important than speed
- Project start ASAP

## Negative Constraints

- Do not use fictional Terminator tech
- Avoid aggressive scenarios
