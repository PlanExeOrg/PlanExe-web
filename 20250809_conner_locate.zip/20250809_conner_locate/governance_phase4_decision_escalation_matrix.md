**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds financial limit of $100,000 delegated to the PMO, requiring strategic review and approval at a higher level.
Negative Consequences: Potential budget overrun and impact on project financial viability.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: Materialization of a critical risk (e.g., compromise of cover identities) requires strategic reassessment and potentially significant resource reallocation.
Negative Consequences: Project failure, exposure of operatives, and loss of assets.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: Inability of the PMO to reach a consensus on a key operational decision necessitates resolution by the higher authority to avoid project delays.
Negative Consequences: Project delays and potential selection of a suboptimal vendor.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: Significant changes to the project scope require strategic evaluation of impact on budget, timeline, and objectives.
Negative Consequences: Project creep, budget overruns, and failure to achieve original objectives.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Steering Committee
Rationale: Allegations of ethical violations require independent review and potential corrective action to maintain project integrity and reputation.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Technical Approach Dispute**
Escalation Level: Technical Advisory Group
Approval Process: Technical Advisory Group Review and Recommendation to PMO
Rationale: Disagreement on technical approach requires specialized technical input and assurance on the selection and implementation of surveillance technologies, secure communication channels, and data management systems.
Negative Consequences: Compromised security, unreliable systems, and failure to achieve operational requirements.