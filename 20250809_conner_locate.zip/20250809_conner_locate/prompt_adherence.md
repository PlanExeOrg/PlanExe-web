# Prompt Adherence Report

**Overall Adherence: 86%**

## Summary

| ID | Directive | Type | Importance | Adherence | Category |
|----|-----------|------|------------|-----------|----------|
| D2 | John Connor may have another identity and changed appearance. | stated_fact | 4/5 | 3/5 | partially_honored |
| D6 | Use multiple burnable covers. | requirement | 4/5 | 3/5 | partially_honored |
| D1 | Locate John Connor. | requirement | 5/5 | 4/5 | fully_honored |
| D10 | Project start ASAP | constraint | 3/5 | 3/5 | partially_honored |
| D9 | Don't go for the most aggressive scenario. | intent | 4/5 | 4/5 | fully_honored |
| D3 | Covert mission must be run under disguise. | requirement | 5/5 | 5/5 | fully_honored |
| D4 | Don't use fictional Terminator tech. | banned | 5/5 | 5/5 | fully_honored |
| D5 | Use only real world technology. | requirement | 5/5 | 5/5 | fully_honored |
| D7 | Use plausible deniability. | requirement | 5/5 | 5/5 | fully_honored |
| D8 | Ultimate goal is more important than speed. | intent | 5/5 | 5/5 | fully_honored |

## Issues

### D2: John Connor may have another identity and changed appearance.

- **Category:** partially_honored
- **Adherence:** 3/5
- **Importance:** 4/5
- **Evidence:** The primary objective is to confirm John Connor's location within 24 months, maintaining operational security, gathering accurate intelligence
- **Explanation:** The plan acknowledges the need to gather intelligence, which implicitly addresses the possibility of a changed identity, but doesn't explicitly mention it.

### D6: Use multiple burnable covers.

- **Category:** partially_honored
- **Adherence:** 3/5
- **Importance:** 4/5
- **Evidence:** Key deliverables include a network of interconnected cover identities, secure communication channels, actionable intelligence reports, and a validated target location.
- **Explanation:** The plan mentions 'cover identities' but doesn't explicitly state that they are 'burnable' or that multiple covers will be used.

### D10: Project start ASAP

- **Category:** partially_honored
- **Adherence:** 3/5
- **Importance:** 3/5
- **Evidence:** The operation is planned for 24 months with an estimated budget of $3,000,000 USD, including a $500,000 USD contingency.
- **Explanation:** The plan provides a timeline, but it doesn't explicitly address the 'ASAP' start. The 24-month timeline might not be the fastest possible.
