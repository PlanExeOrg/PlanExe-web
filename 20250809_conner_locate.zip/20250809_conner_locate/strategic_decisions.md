## Primary Decisions
The vital few decisions that have the most impact.


The 'Critical' and 'High' impact levers address the fundamental project tensions of 'Security vs. Efficiency', 'Risk vs. Reward', and 'Covertness vs. Operational Effectiveness'. Specifically, they govern how to balance information security with communication, resource allocation with deniability, operational footprint with intelligence gathering, and proactive action with maintaining a low profile. No key strategic dimensions appear to be missing.

### Decision 1: Cover Identity Breadth
**Lever ID:** `8f10aa09-1022-42b7-b167-b6d04dc90054`

**The Core Decision:** Cover Identity Breadth involves developing multiple identities to mitigate risks associated with exposure. While this strategy enhances operational resilience, it also complicates logistics and management. Success metrics include the number of identities maintained and their effectiveness in blending into various environments without raising suspicion.

**Why It Matters:** Increasing the number of cover identities dilutes the risk associated with any single identity being compromised, but it also increases the logistical overhead of maintaining and managing those identities. More identities require more documentation, backstories, and potentially more physical infrastructure to support them. This can slow down operations and increase the chances of a mistake.

**Strategic Choices:**

1. Establish a network of interconnected identities with shared resources and overlapping contacts to create a more resilient and believable persona ecosystem
2. Focus on developing a single, highly detailed and meticulously crafted identity with extensive documentation and a verifiable history to minimize scrutiny
3. Employ a series of disposable, short-term identities with limited documentation and minimal interaction to reduce the risk of long-term exposure

**Trade-Off / Risk:** A broad identity network offers resilience, but the complexity increases operational overhead and the risk of cascading failures if one identity is compromised.

**Strategic Connections:**

**Synergy:** This lever amplifies Resource Allocation Across Covers by allowing for more strategic distribution of resources across a wider array of identities, enhancing operational flexibility.

**Conflict:** It conflicts with Information Security Protocol Rigor, as managing numerous identities can complicate adherence to strict security protocols, potentially increasing vulnerability.

**Justification:** *High*, High because it directly impacts resource allocation and information security, creating a fundamental tension between resilience and manageability. The synergy and conflict texts highlight its central role.

### Decision 2: Information Security Protocol Rigor
**Lever ID:** `65cb0f6c-d6e2-406f-9cde-765ca5bdbc80`

**The Core Decision:** Information Security Protocol Rigor emphasizes the implementation of stringent security measures to protect sensitive data. While it reduces the risk of breaches, it can hinder team communication and operational speed. Key success metrics include the number of security incidents and the efficiency of information sharing among team members.

**Why It Matters:** Implementing stringent information security protocols reduces the risk of data breaches and unauthorized access, but it can also hinder communication and collaboration among team members. Overly complex security measures can slow down operations and make it difficult to share information quickly and efficiently.

**Strategic Choices:**

1. Implement end-to-end encryption and multi-factor authentication for all communications and data storage, prioritizing security above all else
2. Adopt a risk-based approach to information security, focusing on protecting the most sensitive data while allowing for more flexibility in less critical areas
3. Rely on secure physical channels for sensitive information exchange, minimizing the use of digital communication and data storage

**Trade-Off / Risk:** High security can impede communication, while lax protocols increase vulnerability to exposure, demanding a balanced approach to risk mitigation.

**Strategic Connections:**

**Synergy:** This lever supports Plausible Deniability Depth by ensuring that sensitive information remains secure, thereby enhancing the layers of deniability in operations.

**Conflict:** It conflicts with Technological Surveillance Reliance, as high security measures may impede the effective use of surveillance technologies, limiting operational intelligence.

**Justification:** *Critical*, Critical because it's a central hub connecting technology, deniability, and communication. It controls the project's core risk profile, balancing security with operational efficiency, as highlighted in the conflict text.

### Decision 3: Source Network Reliability Verification
**Lever ID:** `50bba695-7bcb-4ae6-b78b-f73bfd12b14b`

**The Core Decision:** This lever focuses on the rigor applied to verifying the reliability of information sources. Success is measured by the accuracy of intelligence gathered and the avoidance of acting on false information. The scope includes all sources, from human informants to open-source data. It directly impacts the speed and trustworthiness of the operation.

**Why It Matters:** The reliability of information sources directly impacts the accuracy and validity of intelligence. Rigorous verification processes consume time and resources, potentially delaying action, but reduce the risk of acting on false or misleading information. Superficial verification is faster but riskier.

**Strategic Choices:**

1. Employ multiple independent sources to corroborate all critical information, cross-referencing data to identify discrepancies.
2. Conduct thorough background checks and credibility assessments of all informants, evaluating their motivations and biases.
3. Accept information at face value from established sources, minimizing verification efforts to expedite decision-making.

**Trade-Off / Risk:** Thorough source verification enhances intelligence accuracy but delays action, while superficial verification accelerates decision-making at the cost of reliability.

**Strategic Connections:**

**Synergy:** This lever amplifies the effectiveness of Intelligence Gathering Modality Diversity, ensuring that diverse sources are also reliable. It also supports Plausible Deniability Depth.

**Conflict:** This lever conflicts with Operational Footprint Minimization, as thorough verification often requires more extensive investigation and contact with sources. It also trades off against Covert Asset Turnover Rate.

**Justification:** *Critical*, Critical because it directly impacts the accuracy of intelligence, which is crucial for the mission's success. It balances speed and trustworthiness, as highlighted in the review and conflict texts.

### Decision 4: Intelligence Gathering Modality Diversity
**Lever ID:** `de9000fa-d668-46b3-b89b-8066341fc96d`

**The Core Decision:** This lever addresses the variety of methods used to gather intelligence. Success is measured by the resilience of the operation to compromise and the completeness of the intelligence picture. The scope includes human intelligence, open-source analysis, and technical surveillance, balancing resource allocation and risk mitigation.

**Why It Matters:** Relying on a single intelligence-gathering method makes the operation vulnerable to compromise if that method is detected or blocked. Diversifying methods increases resilience but also requires more resources and expertise. Over-reliance on human intelligence can be slow and prone to error, while excessive technological surveillance may raise suspicion.

**Strategic Choices:**

1. Integrate human intelligence, open-source analysis, and limited technical surveillance to create a multi-faceted intelligence picture
2. Prioritize cultivating trusted human sources within relevant communities to gain reliable, actionable intelligence
3. Focus on advanced technical surveillance methods, such as signal intelligence and data mining, to passively gather information

**Trade-Off / Risk:** Diverse intelligence gathering reduces reliance on any single point of failure, but requires broader skill sets and resource allocation.

**Strategic Connections:**

**Synergy:** This lever synergizes with Source Network Reliability Verification, ensuring that diverse intelligence streams are also trustworthy. It also supports Covert Asset Geographic Distribution.

**Conflict:** This lever conflicts with Technological Surveillance Reliance if diversity is low. It also trades off against Operational Footprint Minimization, as more modalities may require a larger footprint.

**Justification:** *Critical*, Critical because it ensures resilience and completeness of intelligence, directly impacting the mission's effectiveness. It balances resource allocation and risk mitigation, as highlighted in the description.

### Decision 5: Covert Action Trigger Threshold
**Lever ID:** `a5a03285-5532-43f4-89cf-8679624398c3`

**The Core Decision:** This lever defines the criteria that must be met before initiating a covert action. It balances proactive intervention with maintaining a low profile. Success is measured by the effectiveness of actions taken and the avoidance of premature exposure or missed opportunities. Careful calibration is essential for optimal outcomes.

**Why It Matters:** Setting a low threshold for covert action may lead to premature engagement and increased risk of exposure. A high threshold may delay critical interventions and allow the target to evade detection. The threshold should be calibrated to balance the need for proactive intervention with the desire to maintain a low profile.

**Strategic Choices:**

1. Establish clear, pre-defined triggers for covert action based on specific intelligence indicators and risk assessments
2. Adopt a reactive approach, only initiating covert action in response to direct threats or imminent opportunities
3. Employ a flexible, adaptive approach, adjusting the trigger threshold based on the evolving operational context and risk tolerance

**Trade-Off / Risk:** A low trigger threshold risks premature exposure, while a high threshold may allow the target to slip away, demanding careful calibration.

**Strategic Connections:**

**Synergy:** This lever amplifies Intelligence Gathering Modality Diversity, as diverse intelligence streams inform the trigger threshold. It also enables Covert Action Trigger Threshold.

**Conflict:** This lever conflicts with Operational Footprint Minimization, as a lower threshold may necessitate a larger footprint. It also trades off against Plausible Deniability Depth.

**Justification:** *Critical*, Critical because it defines when to act, balancing proactive intervention with maintaining a low profile. This directly impacts the risk of exposure versus mission success, a core strategic tension.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Resource Allocation Across Covers
**Lever ID:** `beae0d2a-7467-4bf1-9a01-4d0fa4a399ca`

**The Core Decision:** Resource Allocation Across Covers focuses on distributing operational resources among various cover identities. This lever aims to balance risk and effectiveness, with success measured by the intelligence gathered and the operational resilience of each cover. Strategic allocation can enhance mission success while managing exposure risks.

**Why It Matters:** Concentrating resources on a few key covers allows for deeper penetration and more effective intelligence gathering, but it also makes the operation more vulnerable if those covers are exposed. Spreading resources thinly across multiple covers reduces the impact of any single cover being compromised, but it also limits the effectiveness of each individual cover.

**Strategic Choices:**

1. Prioritize resource allocation to covers with the highest potential for accessing critical information, accepting a higher risk of exposure for those covers
2. Distribute resources evenly across all covers to maintain a consistent level of operational capability and minimize the impact of any single cover being compromised
3. Dynamically allocate resources based on real-time intelligence and operational needs, shifting resources between covers as the situation evolves

**Trade-Off / Risk:** Concentrating resources maximizes potential gains but creates single points of failure, while even distribution dilutes impact and responsiveness.

**Strategic Connections:**

**Synergy:** It synergizes with Cover Identity Breadth, as effective resource allocation can enhance the viability of multiple identities, allowing for deeper intelligence penetration.

**Conflict:** This lever may conflict with Plausible Deniability Depth, as concentrating resources on fewer covers can simplify deniability but increases the risk of exposure.

**Justification:** *High*, High because it governs the trade-off between deep penetration and operational resilience. Its conflict with Plausible Deniability Depth underscores its importance in balancing risk and effectiveness.

### Decision 7: Plausible Deniability Depth
**Lever ID:** `f075fd10-2c11-47d0-9013-ad05fc44b643`

**The Core Decision:** Plausible Deniability Depth focuses on creating layers of deniability to obscure the operation's origins. This lever is crucial for protecting the operation from scrutiny, with success measured by the effectiveness of deniability strategies and the ability to deflect suspicion. However, it requires careful planning and resource allocation.

**Why It Matters:** Creating deep layers of plausible deniability makes it more difficult to trace the operation back to its source, but it also requires more resources and careful planning. Overly elaborate deniability measures can become suspicious in themselves, drawing unwanted attention to the operation.

**Strategic Choices:**

1. Establish multiple layers of indirect connections and intermediaries to obscure the true source of the operation and create a complex web of plausible deniability
2. Focus on creating a single, convincing narrative that explains the operation's activities in a way that is consistent with publicly available information
3. Minimize direct involvement and rely on third-party actors to carry out key tasks, creating a buffer between the operation and its ultimate source

**Trade-Off / Risk:** Deep deniability complicates attribution but demands significant resources, while a simple narrative may be easily disproven with minimal scrutiny.

**Strategic Connections:**

**Synergy:** It synergizes with Information Security Protocol Rigor, as robust security measures can enhance the layers of deniability by protecting sensitive operational details.

**Conflict:** This lever may conflict with Resource Allocation Across Covers, as extensive deniability measures can divert resources away from operational effectiveness, risking exposure.

**Justification:** *High*, High because it directly addresses the project's need for covertness. The conflict text reveals its control over resource allocation, making it a key lever for managing exposure risk.

### Decision 8: Technological Surveillance Reliance
**Lever ID:** `0a57d564-5afb-4abf-bb19-0056e2192f8c`

**The Core Decision:** Technological Surveillance Reliance involves using advanced surveillance tools to gather intelligence efficiently. While it enhances operational capabilities, it increases the risk of detection and technical failures. Success is measured by the quality of intelligence gathered and the operational effectiveness of surveillance methods employed.

**Why It Matters:** Heavily relying on technological surveillance tools can provide valuable intelligence and enhance operational efficiency, but it also increases the risk of detection and counter-surveillance. Over-dependence on technology can make the operation vulnerable to technical glitches, hacking, and other forms of electronic interference.

**Strategic Choices:**

1. Employ advanced surveillance technologies extensively to gather intelligence and monitor targets, accepting the inherent risks of detection and counter-surveillance
2. Minimize the use of technological surveillance and rely primarily on human intelligence and traditional investigative methods to reduce the risk of electronic exposure
3. Integrate technological surveillance with human intelligence, using technology to augment and enhance traditional methods rather than replace them entirely

**Trade-Off / Risk:** Tech reliance boosts efficiency but increases vulnerability to detection, while human intelligence is less efficient but more resilient to technical failures.

**Strategic Connections:**

**Synergy:** This lever enhances Information Security Protocol Rigor by providing real-time intelligence that can inform security measures and operational adjustments.

**Conflict:** It conflicts with Cover Identity Breadth, as heavy reliance on technology can expose operational identities, undermining the effectiveness of multiple cover strategies.

**Justification:** *Medium*, Medium because while it impacts intelligence gathering, it's more of a tactical choice than a strategic one. Its conflict with Cover Identity Breadth is important, but less central than other conflicts.

### Decision 9: Covert Communication Channel Security
**Lever ID:** `515a9327-ec5a-4011-b058-b9000793368e`

**The Core Decision:** This lever focuses on the security level of communication channels used by covert operatives. It balances the need for secure, undetectable communication with the practicalities of speed and ease of use. Success is measured by the absence of compromised communications and the ability to transmit critical information reliably.

**Why It Matters:** Secure communication channels are vital for maintaining operational integrity. Increased security measures can slow down communication speed and increase operational complexity, but reduce the risk of exposure. Balancing security with efficiency is crucial for effective coordination.

**Strategic Choices:**

1. Implement end-to-end encrypted messaging with ephemeral keys and multi-factor authentication for all communications.
2. Utilize dead drops and pre-arranged signals for critical information exchange, minimizing electronic communication footprints.
3. Employ steganography techniques to embed messages within innocuous files or images, obscuring communication content.

**Trade-Off / Risk:** Prioritizing extreme communication security can hinder rapid response, but reduces the risk of interception and compromise of sensitive information.

**Strategic Connections:**

**Synergy:** This lever strongly synergizes with Information Security Protocol Rigor, as both aim to protect sensitive data and communications from unauthorized access and detection.

**Conflict:** Covert Communication Channel Security conflicts with Operational Footprint Minimization. Highly secure channels may require specialized equipment or infrastructure, increasing the footprint.

**Justification:** *Medium*, Medium because it's important for security, but less connected to the core strategic conflicts than Information Security Protocol Rigor, which it synergizes with.

### Decision 10: Covert Asset Turnover Rate
**Lever ID:** `d1a557e6-8daa-4628-902c-9b798f4e4c4a`

**The Core Decision:** This lever manages the frequency with which covert assets are replaced. It balances the risk of asset compromise against the logistical and financial costs of frequent replacement. Success is measured by minimizing both compromise incidents and unnecessary resource expenditure on asset turnover.

**Why It Matters:** The rate at which assets (vehicles, safe houses, identities) are rotated impacts operational security and cost. Higher turnover reduces the risk of compromise but increases logistical complexity and resource expenditure. A slower turnover rate is cheaper but increases the risk of detection over time.

**Strategic Choices:**

1. Establish a rapid asset rotation schedule, replacing all assets every 30 days regardless of perceived compromise.
2. Implement a risk-based asset rotation, replacing assets only when indicators of compromise are detected.
3. Maintain a minimal asset pool, accepting higher risk of compromise in exchange for reduced logistical overhead.

**Trade-Off / Risk:** Frequent asset turnover minimizes compromise risk but strains resources, while infrequent turnover saves resources but increases detection probability.

**Strategic Connections:**

**Synergy:** Covert Asset Turnover Rate synergizes with Cover Identity Breadth. A wider range of identities supports a faster turnover rate without raising suspicion.

**Conflict:** Covert Asset Turnover Rate conflicts with Resource Allocation Across Covers. A high turnover rate demands more resources, potentially limiting the resources available for each individual cover.

**Justification:** *Medium*, Medium because it's a logistical consideration that impacts resource allocation, but it's not as strategically central as the overall resource allocation strategy.

### Decision 11: Operational Footprint Minimization
**Lever ID:** `8b8f58e6-a38b-4e33-8e54-9bb1a474b5da`

**The Core Decision:** This lever aims to reduce the visibility and detectability of the operation. It balances the need for discretion with the resources and personnel required to achieve the mission objectives. Success is measured by the absence of unwanted attention and the ability to operate undetected.

**Why It Matters:** Reducing the operational footprint minimizes the chances of detection. A smaller footprint may limit the scope and effectiveness of the operation, while a larger footprint provides more resources but increases visibility. Balancing operational effectiveness with discretion is key.

**Strategic Choices:**

1. Limit the number of active operatives to the absolute minimum required for each task, relying on remote support.
2. Utilize existing public infrastructure and resources whenever possible, avoiding the establishment of dedicated facilities.
3. Employ a distributed network of independent contractors, minimizing the concentration of operational personnel.

**Trade-Off / Risk:** Minimizing the operational footprint reduces visibility but can limit operational capacity and responsiveness in critical situations.

**Strategic Connections:**

**Synergy:** Operational Footprint Minimization synergizes with Covert Asset Geographic Distribution. Distributing assets geographically helps to minimize the footprint in any single location.

**Conflict:** Operational Footprint Minimization conflicts with Intelligence Gathering Modality Diversity. Gathering intelligence through diverse methods may require a larger footprint.

**Justification:** *High*, High because it directly addresses the core goal of covertness. The conflict text highlights its trade-off with intelligence gathering, making it a key lever for managing visibility.

### Decision 12: Counter-Surveillance Protocol Depth
**Lever ID:** `fc064d66-4e49-4963-ae94-2f3854042325`

**The Core Decision:** This lever focuses on the depth and intensity of measures taken to detect and avoid surveillance. It balances the need for security with the time and resources required to implement thorough protocols. Success is measured by the ability to operate without being observed or tracked.

**Why It Matters:** Robust counter-surveillance measures are essential for detecting and avoiding observation. Deeper protocols require more time and resources, potentially slowing down the operation, but provide greater assurance of undetected movement. Weak protocols save time but increase the risk of exposure.

**Strategic Choices:**

1. Implement multi-layered counter-surveillance sweeps before and after every movement, utilizing both technical and human assets.
2. Conduct periodic vulnerability assessments of operational routes and locations, identifying and mitigating potential surveillance points.
3. Rely on basic visual checks and situational awareness, accepting a higher risk of undetected surveillance.

**Trade-Off / Risk:** Extensive counter-surveillance protocols enhance security but can impede progress, while minimal protocols expedite movement at the cost of increased risk.

**Strategic Connections:**

**Synergy:** Counter-Surveillance Protocol Depth synergizes with Information Security Protocol Rigor. Both contribute to a comprehensive security posture, protecting against different types of threats.

**Conflict:** Counter-Surveillance Protocol Depth conflicts with Operational Footprint Minimization. Deeper protocols may require more personnel or equipment, increasing the operational footprint.

**Justification:** *Medium*, Medium because it's important for security, but its impact is primarily tactical. It supports Information Security Protocol Rigor, but is less strategically significant on its own.

### Decision 13: Cover Story Consistency Enforcement
**Lever ID:** `96c068d1-416b-4e7f-9afc-1e6a4776d688`

**The Core Decision:** This lever manages the consistency and believability of cover stories used by operatives. It balances the need for airtight narratives with the training and coordination required to maintain them. Success is measured by the absence of inconsistencies that could raise suspicion or compromise the operation.

**Why It Matters:** Maintaining consistent cover stories across all operatives is crucial for avoiding suspicion. Strict enforcement requires significant training and coordination, potentially slowing down deployment, but reduces the risk of inconsistencies that could compromise the operation. Lax enforcement is faster but riskier.

**Strategic Choices:**

1. Mandate rigorous training and rehearsals for all operatives, ensuring complete fluency in their assigned cover stories.
2. Develop detailed background narratives and supporting documentation for each cover identity, accessible to all relevant personnel.
3. Rely on individual operatives to maintain their cover stories, providing minimal guidance or oversight.

**Trade-Off / Risk:** Strict cover story enforcement minimizes inconsistencies but demands extensive training, while lax enforcement saves time but increases exposure risk.

**Strategic Connections:**

**Synergy:** Cover Story Consistency Enforcement synergizes with Cover Identity Breadth. More diverse identities require even stricter enforcement to avoid conflicts and inconsistencies.

**Conflict:** Cover Story Consistency Enforcement conflicts with Covert Action Trigger Threshold. Strict enforcement may delay action, as operatives need to ensure their actions align with their cover story.

**Justification:** *Medium*, Medium because it's important for maintaining cover, but less strategically central than the breadth and depth of the cover itself. It supports Cover Identity Breadth.

### Decision 14: Covert Funding Source Obscurity
**Lever ID:** `ce03a9a1-cb2d-4d16-9e6a-a291cb510718`

**The Core Decision:** This lever manages the level of obscurity surrounding the sources of funding for the covert operation. Success is measured by the ability to maintain operational security and avoid detection through financial trails. The scope includes all funding channels, balancing accessibility with the risk of exposure and potential delays.

**Why It Matters:** The level of obscurity surrounding funding sources directly impacts the operation's vulnerability to exposure. Highly obscure sources may be difficult to access and manage, potentially slowing down operations. Conversely, easily accessible sources may leave a traceable financial trail, increasing the risk of detection.

**Strategic Choices:**

1. Utilize a network of shell corporations and offshore accounts to completely anonymize funding origins
2. Employ a combination of untraceable cryptocurrency transactions and cash-based exchanges to obscure the money trail
3. Rely on pre-existing, legitimate business ventures to provide a seemingly innocuous source of operational funds

**Trade-Off / Risk:** Obscuring funding sources adds complexity and potential delays, but traceable funds expose the operation, demanding a balance between speed and security.

**Strategic Connections:**

**Synergy:** This lever enhances Plausible Deniability Depth by making it harder to trace the operation's financial backing. It also works well with Cover Identity Breadth.

**Conflict:** This lever constrains Resource Allocation Across Covers, as highly obscure funding sources may be more difficult to manage and distribute efficiently. It also conflicts with Covert Asset Turnover Rate.

**Justification:** *Medium*, Medium because while important for security, it's more of a constraint on resource allocation than a driver of overall strategy. It supports Plausible Deniability Depth.

### Decision 15: Covert Asset Geographic Distribution
**Lever ID:** `71b818fd-a292-42e1-af1b-b2e6c7266338`

**The Core Decision:** This lever manages the geographic distribution of covert assets, such as safe houses and operational bases. Success is measured by operational resilience and the ability to adapt to the target's movements. The scope includes all physical assets, balancing logistical complexity with security and flexibility.

**Why It Matters:** Concentrating assets in a single location simplifies logistics but creates a single point of failure. Distributing assets geographically increases operational resilience but complicates coordination and communication. The optimal distribution depends on the target's likely movements and the available resources.

**Strategic Choices:**

1. Establish a network of geographically dispersed safe houses and operational bases to enhance operational security and flexibility
2. Centralize covert assets in a single, secure location to streamline logistics and maintain tight control over resources
3. Utilize a hub-and-spoke model, with a central command center and several smaller, mobile operational units, to balance control and flexibility

**Trade-Off / Risk:** Geographic distribution of assets enhances resilience but increases logistical complexity, requiring careful balancing of security and efficiency.

**Strategic Connections:**

**Synergy:** This lever amplifies Cover Identity Breadth, as a wider distribution of assets supports a greater range of cover stories. It also supports Intelligence Gathering Modality Diversity.

**Conflict:** This lever conflicts with Operational Footprint Minimization, as a wider distribution inherently increases the visible presence of the operation. It also trades off against Covert Team Compartmentalization.

**Justification:** *Medium*, Medium because it enhances resilience, but it's more of a logistical consideration than a strategic driver. It supports Cover Identity Breadth.

### Decision 16: Covert Team Compartmentalization
**Lever ID:** `c562da97-5d0b-45df-8914-b1257cf075ce`

**The Core Decision:** This lever controls the degree to which the covert team is compartmentalized, limiting information flow between members. Success is measured by the ability to contain compromises and maintain operational security. The scope includes all team members and information, balancing security with the need for collaboration and efficiency.

**Why It Matters:** Strict compartmentalization minimizes the damage from individual compromises but can hinder information sharing and collaboration. Loose compartmentalization facilitates communication but increases the risk of cascading failures. The level of compartmentalization should reflect the sensitivity of the information and the trustworthiness of the team members.

**Strategic Choices:**

1. Implement a strict need-to-know protocol, limiting information access to only those individuals who require it for their specific tasks
2. Foster a culture of open communication and information sharing within the covert team to encourage collaboration and innovation
3. Establish a tiered compartmentalization system, with varying levels of access based on individual roles and responsibilities

**Trade-Off / Risk:** Compartmentalization protects against cascading failures, but excessive restrictions can impede collaboration and slow down operations.

**Strategic Connections:**

**Synergy:** This lever enhances Information Security Protocol Rigor by limiting the spread of sensitive data. It also supports Plausible Deniability Depth.

**Conflict:** This lever constrains Cover Story Consistency Enforcement, as strict compartmentalization can make it harder to ensure that all team members are aligned on the cover story. It also conflicts with External Liaison Engagement Level.

**Justification:** *Medium*, Medium because it's important for security, but can hinder collaboration. It supports Information Security Protocol Rigor, but is less strategically significant on its own.

### Decision 17: External Liaison Engagement Level
**Lever ID:** `8430bef7-1afe-49ee-aaa3-9162d7ab348a`

**The Core Decision:** This lever determines the extent of interaction with external sources for intelligence and support. It weighs the benefits of external assistance against the risks of compromise. Success is measured by the quality of intelligence gained and the security of the operation. Vetting and careful management are crucial.

**Why It Matters:** Engaging with external liaisons (e.g., informants, local contacts) can provide valuable intelligence and resources but also introduces the risk of compromise or betrayal. Minimal engagement reduces this risk but limits access to external support. The level of engagement should reflect the trustworthiness of the liaisons and the sensitivity of the information being shared.

**Strategic Choices:**

1. Maintain strict operational independence, avoiding any reliance on external liaisons or informants
2. Cultivate a network of trusted local contacts and informants to provide valuable intelligence and logistical support
3. Establish formal partnerships with established intelligence agencies or law enforcement organizations to leverage their resources and expertise

**Trade-Off / Risk:** External liaisons offer valuable support but introduce the risk of compromise, requiring careful vetting and management.

**Strategic Connections:**

**Synergy:** This lever synergizes with Intelligence Gathering Modality Diversity, as external liaisons can provide unique intelligence streams. It also amplifies Covert Funding Source Obscurity.

**Conflict:** This lever conflicts with Information Security Protocol Rigor, as external engagement increases the attack surface. It also trades off against Covert Team Compartmentalization.

**Justification:** *Medium*, Medium because it provides access to external support but introduces risk. It synergizes with Intelligence Gathering Modality Diversity, but the risk/reward is less strategically central.
