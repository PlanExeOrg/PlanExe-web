**Verdict:** 🔴 REFUSE

**Rationale:** The prompt describes a dangerous facility with lethal traps, which could be used to cause harm.

### Violation Details

| Detail                | Value |
|-----------------------|-------|
| **Category**              | Physical Harm |
| **Claim**                 | Lethal trap facility |
| **Capability Uplift**     | Yes |
| **Severity**              | High |