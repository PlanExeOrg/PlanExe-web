This plan involves money.

## Currencies

- **USD:** The project budget is specified in USD.

**Primary currency:** USD

**Currency strategy:** USD will be used for budgeting and reporting. Given the scale of the project, hedging strategies may be necessary to manage exchange rate fluctuations if significant international transactions are involved.