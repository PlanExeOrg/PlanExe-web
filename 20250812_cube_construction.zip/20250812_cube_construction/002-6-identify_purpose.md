**Purpose:** business

**Purpose Detailed:** Building a large-scale, dangerous facility for the amusement of a billionaire, involving significant resources and infrastructure.

**Topic:** Construction and operation of a deadly amusement facility