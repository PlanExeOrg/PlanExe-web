**Budget Request Exceeding Core Project Team Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the Core Project Team's delegated financial authority and requires strategic oversight.
Negative Consequences: Potential for budget overruns and project delays due to lack of timely approval.

**Critical Risk Materialization Requiring Strategic Shift**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Plan
Rationale: The risk has a strategic impact on the project's objectives and requires a decision beyond the Core Project Team's authority.
Negative Consequences: Project failure or significant delays due to inadequate risk response.

**Technical Advisory Group Deadlock on Mitigation Strategy**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Competing Recommendations and Vote
Rationale: Lack of consensus among technical experts necessitates a decision at a higher level to ensure project progress.
Negative Consequences: Implementation of a suboptimal mitigation strategy, leading to increased risks and potential project failure.

**Reported Ethical Concern or Compliance Violation**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee Investigation & Recommendation to Project Steering Committee
Rationale: Requires independent review and investigation to ensure ethical conduct and regulatory compliance.
Negative Consequences: Legal penalties, reputational damage, and loss of public trust.

**Stakeholder Engagement Group Unresolved Community Conflict**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Stakeholder Feedback and Decision on Mitigation Strategy
Rationale: Requires higher-level intervention to resolve conflicts and maintain public support for the project.
Negative Consequences: Public resistance, project delays, and potential legal challenges.

**Proposed Major Scope Change (e.g., Expansion of Evacuation Zone)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Technical Advisory Group Input
Rationale: Significant changes to the project scope require strategic alignment and resource reallocation.
Negative Consequences: Ineffective resource allocation, project delays, and potential failure to meet project objectives.