### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**


### 2. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**


### 3. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**


### 4. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**


### 5. Circulate Draft SteerCo ToR for review by nominated members (FEMA Regional Administrator, NPS Director, Governor's Office Representatives (WY, MT, ID), Senior USGS Representative, Independent Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 6. Circulate Draft Ethics & Compliance Committee ToR for review by nominated members (Chief Compliance Officer (FEMA), Legal Counsel (Department of the Interior), Ethics Officer (National Park Service), Independent Auditor, Representative from the Department of Justice, Data Protection Officer (FEMA)).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1
- Nominated Members List Available

### 7. Circulate Draft Technical Advisory Group ToR for review by nominated members (Volcanologist (USGS), Atmospheric Scientist, Civil Engineer, Telecommunications Expert, Public Health Specialist, Independent Expert in Disaster Response Technology).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1
- Nominated Members List Available

### 8. Circulate Draft Stakeholder Engagement Group ToR for review by nominated members (Public Information Officer (FEMA), Community Liaison (National Park Service), Representatives from Local Communities (West Yellowstone, Gardiner, Cody), Representative from Tourism Industry, Volunteer Coordinator, Representative from Vulnerable Populations).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1
- Nominated Members List Available

### 9. Project Manager finalizes the Project Steering Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 10. Project Manager finalizes the Ethics & Compliance Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 11. Project Manager finalizes the Technical Advisory Group Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 12. Project Manager finalizes the Stakeholder Engagement Group Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 13. Senior Sponsor (FEMA Regional Administrator) formally appoints the Project Steering Committee Chair (FEMA Regional Administrator).

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 14. Senior Sponsor (FEMA Regional Administrator) formally appoints the Project Steering Committee members (National Park Service Director or Designee, Representative from the Governor's Office (WY), Representative from the Governor's Office (MT), Representative from the Governor's Office (ID), Senior Representative from USGS, Independent Expert in Emergency Management).

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final SteerCo ToR v1.0

### 15. Senior Sponsor (FEMA Regional Administrator) formally appoints the Ethics & Compliance Committee Chair (Chief Compliance Officer (FEMA)).

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 16. Senior Sponsor (FEMA Regional Administrator) formally appoints the Ethics & Compliance Committee members (Legal Counsel (Department of the Interior), Ethics Officer (National Park Service), Independent Auditor, Representative from the Department of Justice, Data Protection Officer (FEMA)).

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 17. Senior Sponsor (FEMA Regional Administrator) formally appoints the Technical Advisory Group members (Volcanologist (USGS), Atmospheric Scientist, Civil Engineer, Telecommunications Expert, Public Health Specialist, Independent Expert in Disaster Response Technology).

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Technical Advisory Group ToR v1.0

### 18. Senior Sponsor (FEMA Regional Administrator) formally appoints the Stakeholder Engagement Group members (Public Information Officer (FEMA), Community Liaison (National Park Service), Representatives from Local Communities (West Yellowstone, Gardiner, Cody), Representative from Tourism Industry, Volunteer Coordinator, Representative from Vulnerable Populations).

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0

### 19. Hold initial Project Steering Committee Kick-off Meeting.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Emails
- Final SteerCo ToR v1.0

### 20. Hold initial Ethics & Compliance Committee Kick-off Meeting.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Emails
- Final Ethics & Compliance Committee ToR v1.0

### 21. Hold initial Technical Advisory Group Kick-off Meeting.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Emails
- Final Technical Advisory Group ToR v1.0

### 22. Hold initial Stakeholder Engagement Group Kick-off Meeting.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Emails
- Final Stakeholder Engagement Group ToR v1.0

### 23. Project Manager defines roles and responsibilities of Core Project Team members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Roles and Responsibilities Document

**Dependencies:**


### 24. Project Manager establishes communication channels and protocols for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Communication Plan

**Dependencies:**


### 25. Project Manager develops a detailed project schedule and budget for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Detailed Project Schedule
- Project Budget

**Dependencies:**


### 26. Project Manager sets up project management tools and systems for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Management Tools and Systems Setup

**Dependencies:**


### 27. Hold initial Core Project Team Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Core Project Team Roles and Responsibilities Document
- Core Project Team Communication Plan
- Detailed Project Schedule
- Project Budget
- Project Management Tools and Systems Setup