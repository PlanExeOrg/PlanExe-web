
## Audit - Corruption Risks

- Bribery of officials to expedite permits or approvals for evacuation routes or resource staging areas.
- Kickbacks from suppliers of bottled water, medical supplies, or respiratory protection in exchange for inflated contracts.
- Conflicts of interest involving project personnel awarding contracts to companies in which they have a financial stake.
- Misuse of confidential information regarding evacuation plans or resource allocation for personal gain or to benefit specific individuals or groups.
- Nepotism in hiring personnel for key roles in the evacuation or resource distribution efforts.

## Audit - Misallocation Risks

- Diversion of funds allocated for bottled water to other purposes, leading to shortages at evacuation centers.
- Double-billing for services rendered by contractors involved in ash removal or infrastructure repair.
- Inefficient allocation of personnel, resulting in understaffed evacuation centers or traffic control points.
- Unauthorized use of government vehicles or equipment for personal purposes.
- Misreporting of evacuation progress or resource availability to create a false sense of security or to cover up inefficiencies.

## Audit - Procedures

- Conduct periodic internal reviews of all contracts awarded for goods and services related to the evacuation and recovery efforts, with a focus on identifying potential conflicts of interest or inflated pricing. (Frequency: Monthly, Responsibility: Internal Audit Department)
- Implement a robust expense reporting workflow with multiple levels of approval to prevent unauthorized or excessive spending. (Frequency: Ongoing, Responsibility: Finance Department)
- Perform regular compliance checks to ensure adherence to all applicable regulations and standards, including NIMS, EPA guidelines, and OSHA standards. (Frequency: Quarterly, Responsibility: Compliance Officer)
- Conduct post-project external audits to assess the overall effectiveness of the evacuation and recovery efforts, identify areas for improvement, and ensure accountability for all expenditures. (Frequency: Post-Project, Responsibility: External Audit Firm)
- Review all MOU's for authority transfer between NPS and State Governors to ensure compliance and prevent jurisdictional disputes. (Frequency: Within 30 days of execution, Responsibility: Legal Counsel)

## Audit - Transparency Measures

- Establish a public dashboard displaying real-time evacuation progress, resource allocation, and key performance indicators. (Type: Web-based, Responsibility: Public Information Officer)
- Publish minutes of all Unified Command meetings at the FEMA Region VIII RRCC, redacting sensitive information as necessary. (Frequency: Weekly, Responsibility: FEMA)
- Implement a whistleblower mechanism allowing individuals to report suspected fraud, waste, or abuse without fear of retaliation. (Responsibility: Ethics Officer)
- Provide public access to relevant policies and reports related to the evacuation and recovery efforts, including the evacuation plan, resource allocation matrix, and risk register. (Responsibility: Public Information Officer)
- Document the selection criteria and rationale for all major decisions related to the evacuation and recovery efforts, including vendor selection and resource allocation. (Responsibility: Project Management Office)