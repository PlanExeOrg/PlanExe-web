This plan involves money.

## Currencies

- **USD:** Primary currency for budgeting and large-scale resource procurement.

**Primary currency:** USD

**Currency strategy:** USD is recommended for budgeting and reporting to mitigate risks from potential economic disruption. All transactions will be managed in USD.