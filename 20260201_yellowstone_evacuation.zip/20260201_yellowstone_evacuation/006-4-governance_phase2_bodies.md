### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and direction for the entire 'Operation Caldera Evac' project, given its high-stakes nature, complexity, and the need for inter-agency coordination.

**Responsibilities:**

- Approve the overall project plan and any major deviations.
- Set strategic priorities and resolve conflicts between different agencies or stakeholders.
- Approve budget allocations exceeding $1 million.
- Monitor project progress against strategic goals and key performance indicators.
- Oversee risk management and ensure appropriate mitigation strategies are in place.
- Approve escalation triggers and expansion of evacuation zones.
- Ensure compliance with all relevant regulations and ethical standards.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair and Vice-Chair.
- Establish meeting schedule and communication protocols.
- Review and approve the project charter and initial risk register.

**Membership:**

- FEMA Regional Administrator (Chair)
- National Park Service Director or Designee
- Representative from the Governor's Office (WY)
- Representative from the Governor's Office (MT)
- Representative from the Governor's Office (ID)
- Senior Representative from USGS
- Independent Expert in Emergency Management

**Decision Rights:** Strategic decisions related to project scope, budget (>$1M), timeline, and risk management. Approval of major changes to the evacuation plan or resource allocation strategy.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the FEMA Regional Administrator (Chair) has the deciding vote. Any dissenting opinions must be formally recorded.

**Meeting Cadence:** Initially weekly, then bi-weekly after the first month, or more frequently as needed during critical phases of the project.

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion of key risks and mitigation strategies.
- Approval of budget requests and resource allocations.
- Review of stakeholder engagement activities.
- Updates on regulatory compliance.
- Review of escalation triggers and potential expansion of evacuation zones.

**Escalation Path:** Escalate unresolved issues to the FEMA Administrator and the Secretary of the Interior.
### 2. Core Project Team

**Rationale for Inclusion:** Manages the day-to-day execution of the 'Operation Caldera Evac' project, ensuring efficient coordination and implementation of the evacuation plan.

**Responsibilities:**

- Develop and maintain the project schedule and budget.
- Coordinate the activities of different project teams and stakeholders.
- Monitor project progress and identify potential issues or risks.
- Implement risk mitigation strategies.
- Prepare regular progress reports for the Project Steering Committee.
- Manage communication and information flow within the project team.
- Ensure compliance with project standards and procedures.

**Initial Setup Actions:**

- Define roles and responsibilities of team members.
- Establish communication channels and protocols.
- Develop a detailed project schedule and budget.
- Set up project management tools and systems.

**Membership:**

- Project Manager (FEMA)
- Lead Representative from National Park Service
- Lead Representative from Wyoming Highway Patrol
- Lead Representative from National Guard
- Logistics Coordinator
- Communications Coordinator
- Medical Coordinator
- Representative from USGS

**Decision Rights:** Operational decisions related to project execution, resource allocation (below $1M), and risk management within the approved project plan and budget.

**Decision Mechanism:** Decisions made by the Project Manager in consultation with the relevant team members. Any disagreements are escalated to the Project Steering Committee.

**Meeting Cadence:** Daily during the initial evacuation phase, then weekly during the recovery phase.

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion of current issues and risks.
- Coordination of activities between different teams.
- Review of budget and resource utilization.
- Preparation of progress reports for the Project Steering Committee.

**Escalation Path:** Escalate unresolved issues to the Project Steering Committee.
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise on volcanic activity, ashfall impacts, communication systems, and other technical aspects of the 'Operation Caldera Evac' project.

**Responsibilities:**

- Provide expert advice on volcanic hazards and risk assessment.
- Evaluate the effectiveness of communication systems and recommend improvements.
- Assess the impact of ashfall on infrastructure and public health.
- Review and validate technical plans and specifications.
- Provide technical training and support to project teams.
- Monitor technological advancements and recommend innovative solutions.

**Initial Setup Actions:**

- Identify and recruit qualified technical experts.
- Define the scope of the group's advisory role.
- Establish communication channels and protocols.
- Review relevant technical documentation and data.

**Membership:**

- Volcanologist (USGS)
- Atmospheric Scientist
- Civil Engineer
- Telecommunications Expert
- Public Health Specialist
- Independent Expert in Disaster Response Technology

**Decision Rights:** Provides recommendations and technical assessments to the Project Steering Committee and Core Project Team. Does not have direct decision-making authority but its advice is considered crucial.

**Decision Mechanism:** Decisions made by consensus among the technical experts. Any dissenting opinions are documented and presented to the Project Steering Committee.

**Meeting Cadence:** As needed, but at least monthly during the initial planning phase and during periods of heightened volcanic activity.

**Typical Agenda Items:**

- Review of volcanic activity and risk assessment.
- Evaluation of communication system performance.
- Assessment of ashfall impacts on infrastructure and public health.
- Discussion of technical challenges and potential solutions.
- Review of technical plans and specifications.

**Escalation Path:** Escalate unresolved technical issues to the Project Steering Committee.
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures ethical conduct, regulatory compliance (including GDPR and HIPAA), and accountability throughout the 'Operation Caldera Evac' project, given the potential for corruption, misallocation of resources, and privacy violations during a crisis.

**Responsibilities:**

- Develop and implement a code of ethics for all project personnel.
- Monitor compliance with all relevant regulations and legal requirements, including GDPR and HIPAA.
- Investigate allegations of fraud, waste, abuse, or ethical misconduct.
- Provide training on ethical conduct and regulatory compliance.
- Review and approve all contracts and procurement activities.
- Ensure transparency and accountability in resource allocation.
- Oversee the whistleblower mechanism and protect whistleblowers from retaliation.
- Ensure data privacy and security in accordance with GDPR and HIPAA regulations.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair and members.
- Establish reporting mechanisms and investigation procedures.
- Develop a code of ethics and compliance plan.

**Membership:**

- Chief Compliance Officer (FEMA)
- Legal Counsel (Department of the Interior)
- Ethics Officer (National Park Service)
- Independent Auditor
- Representative from the Department of Justice
- Data Protection Officer (FEMA)

**Decision Rights:** Investigates ethical breaches and compliance violations. Recommends corrective actions to the Project Steering Committee. Has the authority to halt project activities if there is a significant risk of ethical or legal violations.

**Decision Mechanism:** Decisions made by majority vote. The Chair has the deciding vote in case of a tie. All decisions and dissenting opinions are formally recorded.

**Meeting Cadence:** Monthly, or more frequently as needed to address specific issues or concerns.

**Typical Agenda Items:**

- Review of compliance reports and audit findings.
- Discussion of ethical dilemmas and potential conflicts of interest.
- Investigation of allegations of fraud, waste, or abuse.
- Approval of contracts and procurement activities.
- Review of data privacy and security measures.
- Updates on regulatory changes and compliance requirements.

**Escalation Path:** Escalate unresolved ethical or compliance issues to the Inspector General of the Department of Homeland Security and the Attorney General.
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Ensures effective communication and collaboration with all stakeholders, including local communities, tourists, and volunteer organizations, given the need for public cooperation and support during the evacuation and recovery efforts.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct regular communication with stakeholders through various channels.
- Gather feedback from stakeholders and address their concerns.
- Coordinate the activities of volunteer organizations.
- Provide information and support to local communities.
- Manage public relations and media inquiries.
- Ensure that the needs of vulnerable populations are addressed.
- Translate information into multiple languages.

**Initial Setup Actions:**

- Identify key stakeholders and their communication needs.
- Establish communication channels and protocols.
- Develop a stakeholder engagement plan.
- Recruit community representatives and volunteer coordinators.

**Membership:**

- Public Information Officer (FEMA)
- Community Liaison (National Park Service)
- Representative from Local Communities (West Yellowstone, Gardiner, Cody)
- Representative from Tourism Industry
- Volunteer Coordinator
- Representative from Vulnerable Populations

**Decision Rights:** Provides recommendations on stakeholder engagement strategies to the Core Project Team and Project Steering Committee. Does not have direct decision-making authority but its advice is considered crucial for maintaining public trust and cooperation.

**Decision Mechanism:** Decisions made by consensus among the members. Any dissenting opinions are documented and presented to the Core Project Team and Project Steering Committee.

**Meeting Cadence:** Weekly during the initial evacuation phase, then bi-weekly during the recovery phase.

**Typical Agenda Items:**

- Review of stakeholder feedback and concerns.
- Discussion of communication strategies and messaging.
- Coordination of volunteer activities.
- Updates on community needs and support services.
- Review of public relations and media inquiries.

**Escalation Path:** Escalate unresolved stakeholder issues to the Project Steering Committee.