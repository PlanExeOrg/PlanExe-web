This plan implies one or more physical locations.

## Requirements for physical locations

- Evacuation routes
- Shelter locations
- Command centers
- Resource staging areas
- Hospitals

## Location 1
USA

Yellowstone National Park

Park Interior

**Rationale**: The plan focuses on evacuating Yellowstone National Park due to imminent volcanic eruption.

## Location 2
USA

Bozeman, MT

Various locations in Bozeman, MT

**Rationale**: Bozeman, MT, is identified as a mass casualty and refugee intake center at a safe distance from Yellowstone.

## Location 3
USA

Idaho Falls, ID

Bonneville High School, Idaho Falls, ID

**Rationale**: Idaho Falls, ID, specifically Bonneville High School, is identified as a mass casualty and refugee intake center.

## Location 4
USA

Denver, CO

FEMA Region VIII Regional Response Coordination Center (RRCC), Denver, CO

**Rationale**: Denver, CO, specifically the FEMA Region VIII RRCC, is designated as the Unified Command location.

## Location Summary
The plan requires evacuation from Yellowstone National Park to safe locations such as Bozeman, MT, and Idaho Falls, ID, with command and control based in Denver, CO.