
## Documents to Create

### 1. Project Charter

**ID:** b89b6101-6588-4033-8d9c-ec0846252c7d

**Description:** A formal document that initiates the Yellowstone Caldera Evacuation Plan project, defines its objectives, scope, and stakeholders, and authorizes the project manager to use organizational resources. It serves as a high-level overview and agreement among key stakeholders.

**Responsible Role Type:** Project Manager

**Primary Template:** PMI Project Charter Template

**Steps:**

- Define project objectives and scope based on the goal statement.
- Identify key stakeholders and their roles.
- Outline high-level project deliverables and milestones.
- Define project governance and decision-making processes.
- Obtain approval from key stakeholders (FEMA, NPS, State Governors).

**Approval Authorities:** FEMA Administrator, NPS Director, State Governors (WY, MT, ID)

### 2. Risk Register

**ID:** e0d99ffa-1796-434c-8f21-25e604a5748b

**Description:** A comprehensive log of identified risks associated with the Yellowstone Caldera Evacuation Plan project, including their potential impact, likelihood, and mitigation strategies. It serves as a central repository for risk management activities.

**Responsible Role Type:** Risk Manager

**Primary Template:** PMI Risk Register Template

**Steps:**

- Identify potential risks based on project scope, assumptions, and historical data.
- Assess the likelihood and impact of each risk.
- Develop mitigation strategies for high-priority risks.
- Assign risk owners responsible for monitoring and managing each risk.
- Regularly review and update the risk register throughout the project lifecycle.

**Approval Authorities:** Project Manager, FEMA Risk Management Office

### 3. Communication Plan

**ID:** e2edc8f8-db26-44a8-9d6b-420f6f242468

**Description:** A detailed plan outlining how information will be communicated to stakeholders throughout the Yellowstone Caldera Evacuation Plan project. It defines communication channels, frequency, and responsibilities.

**Responsible Role Type:** Communication Specialist

**Primary Template:** Project Management Communication Plan Template

**Steps:**

- Identify key stakeholders and their communication needs.
- Define communication channels (e.g., email, meetings, reports).
- Establish communication frequency and timelines.
- Assign communication responsibilities to specific individuals.
- Develop a crisis communication protocol.

**Approval Authorities:** Project Manager, FEMA Public Affairs Office

### 4. Stakeholder Engagement Plan

**ID:** 81424d4c-5740-4de0-9c3b-7c43a530f6e0

**Description:** A plan outlining how stakeholders will be engaged throughout the Yellowstone Caldera Evacuation Plan project. It identifies stakeholder interests, influence, and engagement strategies.

**Responsible Role Type:** Stakeholder Engagement Manager

**Primary Template:** Project Stakeholder Engagement Plan Template

**Steps:**

- Identify key stakeholders and their interests.
- Assess stakeholder influence and impact on the project.
- Develop engagement strategies for each stakeholder group.
- Establish communication channels and feedback mechanisms.
- Regularly monitor and adjust engagement strategies as needed.

**Approval Authorities:** Project Manager, FEMA External Affairs Office

### 5. Change Management Plan

**ID:** 025f48a7-8a42-4ba4-aad2-350e11f4e646

**Description:** A plan outlining how changes to the Yellowstone Caldera Evacuation Plan project will be managed. It defines the change request process, approval authorities, and communication protocols.

**Responsible Role Type:** Change Manager

**Primary Template:** Project Change Management Plan Template

**Steps:**

- Define the change request process.
- Establish approval authorities for different types of changes.
- Develop communication protocols for notifying stakeholders of changes.
- Document all changes and their impact on the project.
- Regularly review and update the change management plan.

**Approval Authorities:** Project Manager, FEMA Program Management Office

### 6. High-Level Budget/Funding Framework

**ID:** a4a2a2d6-9d58-40bb-91dd-ebe54b10369c

**Description:** A high-level overview of the budget and funding sources for the Yellowstone Caldera Evacuation Plan project. It outlines the total project cost, funding sources (federal, state, private), and budget allocation across major project phases.

**Responsible Role Type:** Financial Analyst

**Primary Template:** Project Budget Template

**Steps:**

- Estimate the total project cost based on scope and deliverables.
- Identify potential funding sources (federal, state, private).
- Allocate budget across major project phases (planning, evacuation, recovery).
- Develop a budget tracking and reporting system.
- Obtain approval from funding agencies (FEMA, State Governments).

**Approval Authorities:** FEMA CFO, State Budget Offices (WY, MT, ID)

### 7. Funding Agreement Structure/Template

**ID:** 0b16bddf-2d25-472e-92cd-c40a0aa92531

**Description:** A template for structuring formal agreements with funding agencies (FEMA, State Governments) outlining the terms and conditions of funding for the Yellowstone Caldera Evacuation Plan project. It defines funding amounts, disbursement schedules, reporting requirements, and compliance standards.

**Responsible Role Type:** Legal Counsel

**Primary Template:** Standard Government Grant Agreement Template

**Steps:**

- Review relevant federal and state regulations governing disaster relief funding.
- Develop a standard funding agreement template incorporating legal requirements.
- Negotiate specific terms and conditions with each funding agency.
- Obtain legal review and approval of all funding agreements.
- Ensure compliance with reporting requirements and disbursement schedules.

**Approval Authorities:** FEMA Legal Counsel, State Attorney Generals (WY, MT, ID)

### 8. Initial High-Level Schedule/Timeline

**ID:** daa91a01-d93c-4628-b88d-1beb0f850532

**Description:** A high-level timeline outlining the major phases and milestones of the Yellowstone Caldera Evacuation Plan project. It provides a visual representation of the project schedule and key deadlines.

**Responsible Role Type:** Project Scheduler

**Primary Template:** Gantt Chart Template

**Steps:**

- Identify major project phases (planning, evacuation, recovery).
- Define key milestones for each phase.
- Estimate the duration of each phase and milestone.
- Develop a Gantt chart or similar visual representation of the project schedule.
- Obtain approval from key stakeholders.

**Approval Authorities:** Project Manager, FEMA Program Management Office

### 9. M&E Framework

**ID:** b55abcc0-4ede-4322-9686-77f409cb41b3

**Description:** A framework for monitoring and evaluating the effectiveness of the Yellowstone Caldera Evacuation Plan project. It defines key performance indicators (KPIs), data collection methods, and reporting frequency.

**Responsible Role Type:** Monitoring and Evaluation Specialist

**Primary Template:** Logical Framework Template

**Steps:**

- Define key performance indicators (KPIs) aligned with project objectives.
- Identify data sources and collection methods.
- Establish reporting frequency and formats.
- Develop a system for tracking and analyzing project performance.
- Obtain approval from key stakeholders.

**Approval Authorities:** Project Manager, FEMA Performance Management Office

### 10. Current State Assessment of Volcanic Threat and Preparedness

**ID:** 3b519957-a6cf-47ce-9579-b9623a368804

**Description:** A report assessing the current state of volcanic threat in the Yellowstone region and the existing level of preparedness. It identifies gaps in monitoring, evacuation planning, resource allocation, and communication.

**Responsible Role Type:** Emergency Management Specialist

**Steps:**

- Review existing USGS monitoring data and reports.
- Assess current evacuation plans and resource allocation strategies.
- Identify gaps in communication and coordination.
- Conduct interviews with key stakeholders (FEMA, NPS, State Governments).
- Develop recommendations for improving preparedness.

**Approval Authorities:** Project Manager, FEMA Preparedness Division

### 11. Resource Stockpiling and Distribution Strategy Framework

**ID:** 006359a3-c676-4cf3-b7cf-f66a696ad965

**Description:** A framework outlining the strategy for stockpiling and distributing essential resources (water, medical supplies, respiratory protection) during and after a Yellowstone eruption. It defines procurement methods, storage locations, distribution mechanisms, and prioritization criteria.

**Responsible Role Type:** Logistics and Resource Manager

**Steps:**

- Identify essential resources based on potential needs.
- Determine optimal storage locations based on accessibility and security.
- Develop distribution mechanisms (e.g., distribution centers, drone delivery).
- Establish prioritization criteria for resource allocation.
- Define procurement methods and vendor agreements.

**Approval Authorities:** Project Manager, FEMA Logistics Division

### 12. Escalation Trigger Protocol Framework

**ID:** 75886d20-0e11-4167-9aa1-f8e7709a95c5

**Description:** A framework defining the criteria and processes for escalating the response plan based on evolving volcanic activity. It outlines thresholds for expanding evacuation zones, increasing resource deployment, and activating contingency plans.

**Responsible Role Type:** Emergency Management Specialist

**Steps:**

- Define escalation triggers based on seismic activity, ground deformation, and gas emissions.
- Establish thresholds for expanding evacuation zones.
- Outline processes for increasing resource deployment.
- Define criteria for activating contingency plans.
- Establish communication protocols for escalating the response.

**Approval Authorities:** Project Manager, USGS Volcano Hazards Program

### 13. Public Communication Strategy Framework

**ID:** b1f25262-5358-4210-bf14-1360550fb27f

**Description:** A framework outlining the strategy for communicating with the public during the Yellowstone eruption crisis. It defines communication channels, frequency of updates, message content, and strategies for combating misinformation.

**Responsible Role Type:** Communication Specialist

**Steps:**

- Identify target audiences and their communication needs.
- Define communication channels (e.g., social media, local news, emergency broadcast systems).
- Establish communication frequency and timelines.
- Develop key messages and talking points.
- Develop strategies for combating misinformation.

**Approval Authorities:** Project Manager, FEMA Public Affairs Office

### 14. Evacuation Trigger Protocol Framework

**ID:** 9218aead-e0c9-4660-9e0d-bf3d5031bc96

**Description:** A framework defining the criteria that initiate the evacuation process for the Yellowstone region. It outlines the timing and scope of evacuation orders, balancing speed and accuracy to minimize risk.

**Responsible Role Type:** Emergency Management Specialist

**Steps:**

- Define evacuation triggers based on USGS data, field reports, and expert consultation.
- Establish criteria for determining the scope of evacuation orders.
- Outline processes for issuing evacuation orders.
- Develop communication protocols for notifying the public.
- Establish procedures for coordinating evacuation efforts.

**Approval Authorities:** Project Manager, USGS Volcano Hazards Program

### 15. Ashfall Mitigation Strategy Framework

**ID:** 8ee60bca-3457-4bba-be8f-54edf08348b6

**Description:** A framework outlining measures to reduce the impact of ashfall on infrastructure and public health in the Yellowstone region. It defines actions to protect critical infrastructure, manage ash removal, and provide respiratory protection.

**Responsible Role Type:** Environmental Health Specialist

**Steps:**

- Identify critical infrastructure vulnerable to ashfall.
- Develop strategies for protecting infrastructure (e.g., ash-resistant filters).
- Outline procedures for ash removal.
- Establish protocols for providing respiratory protection.
- Define measures for managing ash disposal.

**Approval Authorities:** Project Manager, EPA Regional Office

## Documents to Find

### 1. USGS Yellowstone Volcano Observatory Monitoring Data

**ID:** 9dbe6d41-75dc-4f26-8b45-b4f88942e43a

**Description:** Real-time and historical data from the USGS Yellowstone Volcano Observatory, including seismic activity, ground deformation, gas emissions, and thermal activity. This data is crucial for assessing volcanic activity and informing escalation and evacuation decisions. Intended audience: Volcanologists, emergency managers, and decision-makers.

**Recency Requirement:** Near real-time (updated hourly or daily)

**Responsible Role Type:** Volcanologist

**Access Difficulty:** Easy: Publicly available data on the USGS website.

**Steps:**

- Access the USGS Yellowstone Volcano Observatory website.
- Explore available data feeds and monitoring reports.
- Contact USGS scientists for specific data requests.

### 2. Historical Volcanic Eruption Data

**ID:** ab24a710-8724-4ec7-a516-42a69166c72e

**Description:** Data on past volcanic eruptions, including VEI (Volcanic Explosivity Index), eruption type, ashfall distribution, and impact on infrastructure and public health. This data is used to inform risk assessments and develop mitigation strategies. Intended audience: Volcanologists, emergency managers, and risk analysts.

**Recency Requirement:** Historical data acceptable, but focus on well-documented eruptions.

**Responsible Role Type:** Volcanologist

**Access Difficulty:** Medium: Requires searching multiple databases and scientific publications.

**Steps:**

- Search the Smithsonian Institution's Global Volcanism Program database.
- Review scientific literature on past volcanic eruptions.
- Contact volcanologists for specific data requests.

### 3. National Weather Service Historical Weather Data

**ID:** a7ea8e1e-d7b1-48c7-bf64-e38a293d4a87

**Description:** Historical weather data for the Yellowstone region, including wind patterns, precipitation, and temperature. This data is used to model ashfall dispersion and assess the impact of weather conditions on evacuation efforts. Intended audience: Atmospheric scientists, emergency managers, and transportation planners.

**Recency Requirement:** At least 10 years of historical data.

**Responsible Role Type:** Atmospheric Scientist

**Access Difficulty:** Easy: Publicly available data on the NWS website.

**Steps:**

- Access the National Weather Service website.
- Explore available historical weather data.
- Contact NWS meteorologists for specific data requests.

### 4. FEMA IPAWS System Documentation

**ID:** d50b6e14-819a-44a0-98fb-b43502cc8659

**Description:** Documentation on the FEMA Integrated Public Alert and Warning System (IPAWS), including technical specifications, operational procedures, and training materials. This information is used to ensure effective use of IPAWS for emergency alerts. Intended audience: Communication specialists, emergency managers, and IT personnel.

**Recency Requirement:** Current documentation.

**Responsible Role Type:** Communication Specialist

**Access Difficulty:** Medium: Requires navigating the FEMA website and potentially contacting FEMA personnel.

**Steps:**

- Access the FEMA IPAWS website.
- Review available documentation and training materials.
- Contact FEMA IPAWS program office for specific information.

### 5. State Emergency Management Plans (WY, MT, ID)

**ID:** d7ff2e03-7ff4-4125-b287-388609b1a7bb

**Description:** Emergency management plans for the states of Wyoming, Montana, and Idaho, outlining procedures for disaster response, evacuation, and resource allocation. This information is used to coordinate efforts across state lines. Intended audience: Emergency managers, state government officials, and FEMA personnel.

**Recency Requirement:** Most recent versions.

**Responsible Role Type:** Emergency Management Specialist

**Access Difficulty:** Medium: Requires navigating state government websites and potentially contacting state officials.

**Steps:**

- Access the websites of the state emergency management agencies.
- Review available plans and procedures.
- Contact state emergency management officials for specific information.

### 6. Local Evacuation Plans (West Yellowstone, Gardiner, Cody)

**ID:** db3aeb2c-52f9-4860-a300-dbdb36ba5be3

**Description:** Evacuation plans for local communities in the Yellowstone region, including West Yellowstone, Gardiner, and Cody. This information is used to coordinate evacuation efforts at the local level. Intended audience: Emergency managers, local government officials, and community leaders.

**Recency Requirement:** Most recent versions.

**Responsible Role Type:** Emergency Management Specialist

**Access Difficulty:** Medium: Requires navigating local government websites and potentially contacting local officials.

**Steps:**

- Access the websites of the local governments.
- Review available plans and procedures.
- Contact local emergency management officials for specific information.

### 7. National Park Service Emergency Response Procedures

**ID:** d4052c93-80f1-4c99-afcc-0c7000cfc552

**Description:** Emergency response procedures for Yellowstone National Park, outlining protocols for evacuation, search and rescue, and medical response. This information is used to coordinate emergency response within the park. Intended audience: NPS personnel, emergency responders, and park visitors.

**Recency Requirement:** Most recent version.

**Responsible Role Type:** NPS Ranger

**Access Difficulty:** Medium: Requires navigating the NPS website and potentially contacting NPS personnel.

**Steps:**

- Access the NPS website.
- Review available procedures and guidelines.
- Contact NPS emergency management officials for specific information.

### 8. Traffic Flow Data on US-191, US-20, US-89

**ID:** eedd80fe-09c1-40f8-9482-e9cd040700a8

**Description:** Real-time and historical traffic flow data on major evacuation routes in the Yellowstone region, including US-191, US-20, and US-89. This data is used to model traffic patterns and optimize evacuation routes. Intended audience: Traffic engineers, transportation planners, and emergency managers.

**Recency Requirement:** Near real-time (updated hourly or daily)

**Responsible Role Type:** Traffic Engineer

**Access Difficulty:** Medium: Requires accessing state DOT websites and potentially contacting DOT personnel.

**Steps:**

- Access state Department of Transportation websites (WYDOT, MDT, ITD).
- Explore available traffic data feeds and reports.
- Contact DOT traffic management centers for specific data requests.

### 9. List of Hospitals and Medical Facilities in the Region

**ID:** aafac491-7fc1-4126-a8ef-046c86896268

**Description:** A comprehensive list of hospitals and medical facilities in the Yellowstone region, including their capacity, specialties, and contact information. This information is used to coordinate medical response and allocate resources. Intended audience: Medical response coordinators, emergency managers, and healthcare providers.

**Recency Requirement:** Most recent version.

**Responsible Role Type:** Medical Response Coordinator

**Access Difficulty:** Medium: Requires accessing state health department websites and potentially contacting state officials.

**Steps:**

- Access state Department of Health websites.
- Review available directories and databases.
- Contact state health officials for specific information.

### 10. List of Shelters and Evacuation Centers

**ID:** e855514b-ac27-4d9f-932a-2b078b386618

**Description:** A list of pre-designated shelters and evacuation centers in the Yellowstone region, including their capacity, amenities, and contact information. This information is used to direct evacuees and allocate resources. Intended audience: Emergency managers, shelter managers, and community leaders.

**Recency Requirement:** Most recent version.

**Responsible Role Type:** Emergency Management Specialist

**Access Difficulty:** Medium: Requires contacting local agencies and verifying information.

**Steps:**

- Contact local emergency management agencies.
- Review available lists and directories.
- Verify the availability and suitability of each location.

### 11. EPA Guidelines for Ash Disposal

**ID:** 557f058b-b2d0-4027-a6b7-72cc0c678e1c

**Description:** EPA guidelines for the safe disposal of volcanic ash, including recommendations for handling, storage, and transportation. This information is used to minimize the environmental impact of ash disposal. Intended audience: Environmental health specialists, waste management personnel, and government officials.

**Recency Requirement:** Current guidelines.

**Responsible Role Type:** Environmental Health Specialist

**Access Difficulty:** Easy: Publicly available information on the EPA website.

**Steps:**

- Access the EPA website.
- Review available guidelines and regulations.
- Contact EPA regional office for specific information.

### 12. Existing Inter-Agency Agreements and MOUs

**ID:** f3a5206f-5ef7-4365-96cd-809d9e8b65d8

**Description:** Copies of existing inter-agency agreements and Memoranda of Understanding (MOUs) between federal, state, and local agencies involved in disaster response. These agreements define roles, responsibilities, and resource sharing protocols. Intended audience: Legal counsel, emergency managers, and government officials.

**Recency Requirement:** Current agreements.

**Responsible Role Type:** Legal Counsel

**Access Difficulty:** Medium: Requires contacting multiple agencies and potentially submitting formal requests.

**Steps:**

- Contact FEMA, state emergency management agencies, and local governments.
- Request copies of relevant agreements and MOUs.
- Review the terms and conditions of each agreement.

### 13. Vulnerable Population Demographic Data

**ID:** ad6ca577-9e2c-444e-8b8c-8edd72f5a569

**Description:** Demographic data on vulnerable populations within the Yellowstone region, including tourists, non-English speakers, people with disabilities, and those with medical conditions. This data is used to develop targeted communication and assistance strategies. Intended audience: Community outreach coordinators, emergency managers, and social workers.

**Recency Requirement:** Most recent census data and available surveys.

**Responsible Role Type:** Community Outreach Coordinator

**Access Difficulty:** Medium: Requires accessing census data and potentially contacting local organizations.

**Steps:**

- Access US Census Bureau data.
- Review available surveys and reports from local organizations.
- Contact community organizations for specific data requests.

### 14. Cybersecurity Incident Response Plans for Critical Infrastructure

**ID:** 451b8964-0483-4001-839b-19e8d0bf7c94

**Description:** Existing cybersecurity incident response plans for critical infrastructure in the Yellowstone region, including power grids, communication networks, and water systems. These plans outline procedures for detecting, containing, and recovering from cyberattacks. Intended audience: Cybersecurity risk assessors, IT personnel, and infrastructure operators.

**Recency Requirement:** Current plans.

**Responsible Role Type:** Cybersecurity Risk Assessor

**Access Difficulty:** Hard: Requires contacting private companies and potentially signing non-disclosure agreements.

**Steps:**

- Contact infrastructure operators and utility companies.
- Request copies of their cybersecurity incident response plans.
- Review the plans for completeness and effectiveness.