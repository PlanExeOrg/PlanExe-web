## Primary Decisions
The vital few decisions that have the most impact.


The 'Critical' and 'High' impact levers address the fundamental project tensions of 'Speed vs. Accuracy' (Evacuation Trigger, Escalation Trigger), 'Coordination vs. Agility' (Command & Control Decentralization), and 'Resilience vs. Centralization' (Communication Redundancy). They also govern the core logistical challenges of resource allocation and traffic management. A key missing strategic dimension might be long-term recovery planning beyond the initial evacuation phase.

### Decision 1: Resource Stockpiling and Distribution Strategy
**Lever ID:** `1099914b-296f-4e1c-99dc-2fd5f44c6a71`

**The Core Decision:** The Resource Stockpiling and Distribution Strategy lever focuses on ensuring the availability of critical resources like water, medical supplies, and respiratory protection during and after the eruption. It controls the method of resource procurement, storage location, and distribution mechanisms. Objectives include minimizing supply chain disruptions and ensuring timely access to essential goods for affected populations. Key success metrics are the speed and efficiency of resource delivery and the percentage of the population with access to needed supplies.

**Why It Matters:** Pre-positioning resources impacts supply chain resilience and accessibility. Immediate: Resources are readily available in designated locations. → Systemic: Reduces delivery times by 30% and ensures adequate supplies for evacuees, but increases storage costs and risk of spoilage. → Strategic: Enhances life support capabilities but requires significant upfront investment and logistical planning.

**Strategic Choices:**

1. Rely on just-in-time delivery of resources from existing supply chains.
2. Pre-position essential resources (water, medical supplies, respiratory protection) in strategically located distribution centers.
3. Establish a decentralized network of micro-warehouses utilizing blockchain technology for inventory management and drone delivery for rapid distribution to remote areas.

**Trade-Off / Risk:** Controls Cost vs. Responsiveness. Weakness: The options fail to account for the impact of ashfall on ground transportation of resources.

**Strategic Connections:**

**Synergy:** This lever strongly synergizes with the Resource Prioritization Framework (7318a2d2-6217-4d3e-aa72-d2fa32f1cb80). Stockpiling efforts are most effective when aligned with a clear framework for determining which resources are most critical and where they should be deployed first. It also enhances the Ashfall Mitigation Strategy (63bcc7e5-7de2-4430-b8b8-bc29866af577).

**Conflict:** This lever can conflict with the Evacuation Trigger Protocol (900e5f39-7596-492b-bc53-02f0307b939f). Premature or delayed evacuation orders can lead to either wasted resources or insufficient supplies in evacuation zones. It also competes with Traffic Flow Optimization Strategy (0a54d53a-9223-4183-866e-f6b4531c9aa2) for road space.

**Justification:** *High*, High importance due to its strong synergy with resource prioritization and ashfall mitigation. It directly impacts life support capabilities and competes with evacuation efforts for road space, highlighting a key trade-off.

### Decision 2: Escalation Trigger Protocol
**Lever ID:** `d99332ea-f030-4efd-8a98-e8754c9857ae`

**The Core Decision:** The Escalation Trigger Protocol lever defines the criteria and processes for escalating the response plan based on evolving volcanic activity. It controls the thresholds for expanding evacuation zones, increasing resource deployment, and activating contingency plans. The objective is to provide timely and data-driven decisions to minimize risk. Key success metrics include the accuracy of predictions and the speed of response to escalating threats.

**Why It Matters:** Establishing clear escalation triggers impacts the scope and timing of response measures. Immediate: Specific criteria are defined for escalating the response. → Systemic: Enables proactive expansion of the evacuation zone and resource allocation, potentially saving lives, but may also lead to unnecessary disruption and economic costs. → Strategic: Minimizes the impact of a supereruption but requires accurate monitoring and reliable forecasting.

**Strategic Choices:**

1. Rely on subjective assessments by USGS scientists to determine escalation triggers.
2. Establish pre-defined thresholds based on seismic activity, ground deformation, and gas emissions to trigger escalation protocols.
3. Implement a predictive modeling system using machine learning to forecast eruption intensity and dynamically adjust evacuation zones and resource allocation based on probabilistic risk assessments.

**Trade-Off / Risk:** Controls Proactiveness vs. Overreaction. Weakness: The options fail to address the potential for false positives and the resulting loss of public trust.

**Strategic Connections:**

**Synergy:** This lever works in synergy with the Evacuation Trigger Protocol (900e5f39-7596-492b-bc53-02f0307b939f). A well-defined escalation protocol ensures that evacuation orders are issued promptly and appropriately based on the best available data. It also enhances Command Structure Adaptability (84ae166d-b49f-4f76-9b18-2cd7d49c63d1).

**Conflict:** This lever can conflict with the Public Communication Strategy (b387d9ac-5c72-4dce-aca2-55a5b055794e). Frequent or poorly communicated escalations can lead to public confusion and distrust. It also constrains Resource Stockpiling and Distribution Strategy (1099914b-296f-4e1c-99dc-2fd5f44c6a71) due to resource limitations.

**Justification:** *Critical*, Critical because it dictates when and how the response expands, directly impacting evacuation zones and resource needs. Its conflict with public communication and resource limitations makes it a central decision point.

### Decision 3: Public Communication Strategy
**Lever ID:** `b387d9ac-5c72-4dce-aca2-55a5b055794e`

**The Core Decision:** The Public Communication Strategy lever manages the flow of information to the public during the crisis. It controls the channels used, the frequency of updates, and the content of the messages. The objective is to keep the public informed, reduce panic, and ensure compliance with evacuation orders. Key success metrics include public awareness, trust in official sources, and adherence to safety guidelines.

**Why It Matters:** Inaccurate or delayed communication can lead to panic and misinformation, hindering evacuation efforts. Immediate: Public confusion → Systemic: 40% increase in traffic accidents due to panic → Strategic: Mass casualties and complete breakdown of evacuation plan.

**Strategic Choices:**

1. Official Channels Only: Rely solely on official government channels (FEMA, NPS) for disseminating information.
2. Multi-Channel Dissemination: Utilize a multi-channel approach including social media, local news, and emergency broadcast systems to disseminate information.
3. Decentralized Information Network: Establish a decentralized, blockchain-secured information network allowing verified individuals and organizations to contribute real-time updates and counter misinformation.

**Trade-Off / Risk:** Controls Speed vs. Accuracy. Weakness: The options fail to consider the vulnerability of communication channels to cyberattacks and misinformation campaigns.

**Strategic Connections:**

**Synergy:** This lever strongly synergizes with the Evacuation Trigger Protocol (900e5f39-7596-492b-bc53-02f0307b939f). Clear and timely communication is essential for effective evacuation. It also enhances Traffic Flow Optimization Strategy (0a54d53a-9223-4183-866e-f6b4531c9aa2).

**Conflict:** This lever can conflict with the Escalation Trigger Protocol (d99332ea-f030-4efd-8a98-e8754c9857ae). Frequent escalations can undermine public trust if not communicated effectively. It also constrains Command & Control Decentralization (cca488bd-0396-4338-ad87-74dd23ef8cb8) if decentralized units disseminate conflicting information.

**Justification:** *Critical*, Critical because it directly impacts public behavior and trust, influencing evacuation compliance and reducing panic. Its synergy with evacuation triggers and traffic flow, and conflict with escalation, makes it a central communication hub.

### Decision 4: Evacuation Trigger Protocol
**Lever ID:** `900e5f39-7596-492b-bc53-02f0307b939f`

**The Core Decision:** The Evacuation Trigger Protocol defines the criteria that initiate the evacuation process. It controls the timing and scope of evacuation orders, aiming to balance speed and accuracy to minimize risk. Key success metrics include the timeliness of evacuation orders, the percentage of the population evacuated before critical thresholds are breached, and the minimization of false alarms that could erode public trust. The objective is to save lives by initiating evacuation at the optimal moment.

**Why It Matters:** Premature evacuation strains resources; delayed evacuation risks lives. Immediate: Increased public anxiety → Systemic: Reduced trust in authorities and 15% slower evacuation times due to resistance → Strategic: Undermined credibility for future disaster warnings.

**Strategic Choices:**

1. USGS Threshold: Initiate evacuation based solely on USGS seismic data exceeding pre-defined thresholds, prioritizing speed.
2. Multi-Factor Assessment: Combine USGS data with real-time field reports and expert consultation to refine evacuation triggers, balancing speed and accuracy.
3. Probabilistic Staging: Implement tiered evacuation zones based on a probabilistic eruption model, dynamically adjusting zones as new data emerges, leveraging predictive analytics.

**Trade-Off / Risk:** Controls Speed vs. Accuracy. Weakness: The options fail to consider the psychological impact of false alarms on future compliance.

**Strategic Connections:**

**Synergy:** This lever works synergistically with `Traffic Flow Optimization Strategy`. A well-defined trigger protocol ensures that traffic management plans are activated promptly, maximizing their effectiveness in facilitating a smooth evacuation. It also enhances the effectiveness of `Public Communication Strategy` by providing a clear and timely message to the public.

**Conflict:** A rapid evacuation trigger based solely on USGS data might conflict with `Multi-Factor Assessment`, potentially leading to unnecessary evacuations if field reports suggest a lower risk. It also constrains `Command Structure Adaptability`, as a rigid protocol may not allow for adjustments based on evolving circumstances.

**Justification:** *Critical*, Critical because it initiates the entire evacuation process, balancing speed and accuracy to minimize risk. Its synergy with traffic flow and public communication, and conflict with command structure, makes it a foundational element.

### Decision 5: Ashfall Mitigation Strategy
**Lever ID:** `63bcc7e5-7de2-4430-b8b8-bc29866af577`

**The Core Decision:** The Ashfall Mitigation Strategy outlines measures to reduce the impact of ashfall. It controls the actions taken to protect infrastructure and public health, aiming to minimize disruption and long-term damage. Key success metrics include the reduction in ash-related health problems, the uptime of critical infrastructure, and the speed of ash removal. The objective is to minimize the negative consequences of ashfall on the affected region.

**Why It Matters:** Inadequate ashfall mitigation leads to infrastructure damage and health crises. Immediate: Infrastructure damage → Systemic: 40% reduction in transportation capacity and increased respiratory illnesses → Strategic: Long-term economic disruption and public health crisis.

**Strategic Choices:**

1. Shelter-in-Place: Primarily advise residents to shelter-in-place, minimizing exposure to ashfall.
2. Targeted Ash Removal: Focus ash removal efforts on critical infrastructure (hospitals, power plants, communication centers), prioritizing essential services.
3. Proactive Infrastructure Hardening: Deploy ash-resistant filters on critical infrastructure, pre-position ash removal equipment, and utilize drone-based ash dispersal technologies, enhancing resilience and minimizing disruption.

**Trade-Off / Risk:** Controls Short-Term vs. Long-Term Impact. Weakness: The options fail to consider the psychological impact of prolonged shelter-in-place orders on the population.

**Strategic Connections:**

**Synergy:** This lever works synergistically with `Resource Stockpiling and Distribution Strategy`. Pre-positioning ash removal equipment and respiratory protection enhances the effectiveness of mitigation efforts. It also supports `Traffic Flow Optimization Strategy` by ensuring roads are cleared of ash to facilitate evacuation and resource delivery.

**Conflict:** A primary focus on `Shelter-in-Place` may conflict with `Proactive Infrastructure Hardening`, as it relies on individual preparedness rather than systemic protection. It also constrains `Targeted Ash Removal` if resources are not allocated to clear critical infrastructure promptly.

**Justification:** *Critical*, Critical because it directly reduces the impact of ashfall on infrastructure and health, influencing transportation and public health outcomes. Its synergy with resource stockpiling and traffic flow makes it a key mitigation component.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Traffic Flow Optimization Strategy
**Lever ID:** `0a54d53a-9223-4183-866e-f6b4531c9aa2`

**The Core Decision:** The Traffic Flow Optimization Strategy lever manages the movement of vehicles during the evacuation. It controls traffic patterns, rerouting strategies, and the use of contraflow lanes. The objective is to maximize the efficiency of evacuation routes and minimize congestion. Key success metrics include evacuation time, traffic flow rate, and the number of people safely evacuated per hour.

**Why It Matters:** Inefficient traffic flow leads to bottlenecks and delays, increasing exposure to hazards. Immediate: Road congestion → Systemic: 30% increase in evacuation time due to bottlenecks → Strategic: Higher mortality rate within Zone Zero.

**Strategic Choices:**

1. Contraflow Prioritization: Implement contraflow on primary routes (US-191, US-20, US-89) with minimal real-time adjustments.
2. Dynamic Rerouting: Utilize real-time traffic data and predictive modeling to dynamically adjust contraflow lanes and reroute traffic via secondary roads.
3. Autonomous Vehicle Integration: Deploy autonomous shuttle fleets on designated routes to expedite evacuation of vulnerable populations, coordinated via a central AI traffic management system.

**Trade-Off / Risk:** Controls Speed vs. Safety. Weakness: The options fail to consider the impact of ashfall on road visibility and vehicle performance.

**Strategic Connections:**

**Synergy:** This lever has a strong synergy with the Evacuation Trigger Protocol (900e5f39-7596-492b-bc53-02f0307b939f). A timely evacuation order allows for proactive traffic management. It also enhances Public Communication Strategy (b387d9ac-5c72-4dce-aca2-55a5b055794e) by informing the public of optimal routes.

**Conflict:** This lever can conflict with the Resource Stockpiling and Distribution Strategy (1099914b-296f-4e1c-99dc-2fd5f44c6a71). Resource convoys and evacuation traffic compete for road space. It also constrains Communication Redundancy Strategy (95b4c7d8-2376-4632-85e4-1358f7526bd3) if traffic disrupts communication infrastructure.

**Justification:** *High*, High importance due to its direct impact on evacuation speed and safety. It synergizes with the evacuation trigger and public communication, but conflicts with resource distribution, highlighting a key logistical challenge.

### Decision 7: Command & Control Decentralization
**Lever ID:** `cca488bd-0396-4338-ad87-74dd23ef8cb8`

**The Core Decision:** The Command & Control Decentralization lever determines the distribution of authority and decision-making power within the response organization. It controls the level of autonomy granted to state, local, and even self-organizing response units. The objective is to ensure rapid and effective responses at all levels. Key success metrics include the speed of decision-making and the coordination between different agencies.

**Why It Matters:** Centralized control can become a bottleneck, while decentralized control risks fragmentation and conflicting priorities. Immediate: Communication delays → Systemic: 20% slower response time due to coordination overhead → Strategic: Ineffective resource allocation and duplicated efforts.

**Strategic Choices:**

1. Centralized FEMA Command: Maintain a strictly hierarchical command structure with FEMA at the apex, directing all operations.
2. Federated Command Structure: Establish a federated command structure with clear jurisdictional boundaries and delegated authority to state and local agencies.
3. Autonomous Response Cells: Empower self-organizing response cells with pre-delegated authority and AI-driven resource allocation, operating within broad strategic guidelines.

**Trade-Off / Risk:** Controls Coordination vs. Agility. Weakness: The options fail to consider the legal implications of autonomous decision-making in emergency situations.

**Strategic Connections:**

**Synergy:** This lever synergizes with Command Structure Adaptability (84ae166d-b49f-4f76-9b18-2cd7d49c63d1). A decentralized command structure is more adaptable to changing circumstances. It also enhances Communication Redundancy Strategy (95b4c7d8-2376-4632-85e4-1358f7526bd3).

**Conflict:** This lever can conflict with the Escalation Trigger Protocol (d99332ea-f030-4efd-8a98-e8754c9857ae). Over-decentralization can lead to inconsistent responses to escalating threats. It also constrains Resource Prioritization Framework (7318a2d2-6217-4d3e-aa72-d2fa32f1cb80) if resource allocation becomes fragmented.

**Justification:** *High*, High importance because it balances coordination and agility, influencing the speed and effectiveness of the response. Its conflict with escalation protocols and resource prioritization makes it a key organizational decision.

### Decision 8: Communication Redundancy Strategy
**Lever ID:** `95b4c7d8-2376-4632-85e4-1358f7526bd3`

**The Core Decision:** The Communication Redundancy Strategy ensures reliable communication during the crisis. It controls the communication channels used, aiming to maintain connectivity even if primary systems fail. Key success metrics include the uptime of communication networks, the reach of emergency alerts, and the ability of first responders to communicate effectively. The objective is to provide continuous information flow for effective coordination and public safety.

**Why It Matters:** Communication failure leads to chaos and delayed response. Immediate: Information bottlenecks → Systemic: 30% reduction in evacuation efficiency due to misinformation and lack of coordination → Strategic: Increased casualties and public panic.

**Strategic Choices:**

1. Reliance on IPAWS: Primarily utilize FEMA's IPAWS system for emergency alerts, assuming network reliability.
2. Hybrid Communication Network: Supplement IPAWS with amateur radio networks and satellite phones for critical personnel, ensuring backup channels.
3. Mesh Network Deployment: Establish a decentralized mesh network using drone-based repeaters and citizen-operated nodes, creating a resilient communication infrastructure independent of centralized systems.

**Trade-Off / Risk:** Controls Centralization vs. Resilience. Weakness: The options fail to address the challenge of communicating with tourists who may not have local cell service or access to IPAWS.

**Strategic Connections:**

**Synergy:** This lever strongly supports `Command Structure Adaptability`. Redundant communication channels enable flexible command structures to function effectively, even if primary channels are compromised. It also amplifies the impact of the `Public Communication Strategy`, ensuring that critical information reaches the public through multiple avenues.

**Conflict:** A reliance on IPAWS alone conflicts with `Mesh Network Deployment`, as it assumes network reliability, potentially leaving areas without coverage vulnerable. It also constrains `Resource Stockpiling and Distribution Strategy` if communication failures hinder the coordination of resource delivery.

**Justification:** *High*, High importance because it ensures reliable communication, supporting command adaptability and public information. Its conflict with resource distribution highlights the importance of resilient communication channels.

### Decision 9: Resource Prioritization Framework
**Lever ID:** `7318a2d2-6217-4d3e-aa72-d2fa32f1cb80`

**The Core Decision:** The Resource Prioritization Framework dictates how resources are allocated during the crisis. It controls the distribution of essential supplies, aiming to ensure equitable access and efficient use. Key success metrics include the speed of resource delivery, the percentage of vulnerable populations reached, and the minimization of resource waste. The objective is to maximize the impact of available resources in saving lives and supporting recovery.

**Why It Matters:** Misallocation of resources hinders evacuation and life support. Immediate: Supply chain disruptions → Systemic: 20% increase in mortality rate due to lack of essential supplies (water, medical) → Strategic: Erosion of public confidence in government response capabilities.

**Strategic Choices:**

1. First-Come, First-Served: Distribute resources based on immediate demand, prioritizing areas with the highest population density.
2. Vulnerability-Based Allocation: Prioritize resource allocation based on vulnerability assessments (elderly, disabled, medical needs), ensuring equitable distribution.
3. Dynamic Resource Optimization: Utilize AI-powered logistics to predict resource needs and dynamically re-allocate supplies based on real-time demand and evolving conditions, optimizing efficiency and minimizing waste.

**Trade-Off / Risk:** Controls Equity vs. Efficiency. Weakness: The options fail to account for the political pressures that can influence resource allocation decisions.

**Strategic Connections:**

**Synergy:** This lever works in synergy with `Resource Stockpiling and Distribution Strategy`. A clear prioritization framework guides the efficient deployment of stockpiled resources to the most critical areas. It also enhances the effectiveness of `Evacuation Trigger Protocol` by ensuring resources are pre-positioned to support evacuation efforts.

**Conflict:** A 'First-Come, First-Served' approach conflicts with `Vulnerability-Based Allocation`, potentially leaving vulnerable populations underserved. It also constrains `Dynamic Resource Optimization` if resource allocation is not adjusted based on real-time needs and evolving conditions.

**Justification:** *Medium*, Medium importance. While important for resource allocation, it is less central than the stockpiling strategy itself. It addresses equity vs. efficiency but is somewhat downstream of the core logistics decisions.

### Decision 10: Command Structure Adaptability
**Lever ID:** `84ae166d-b49f-4f76-9b18-2cd7d49c63d1`

**The Core Decision:** The Command Structure Adaptability lever defines how the command structure adapts to changing circumstances. It controls the decision-making process and lines of authority, aiming to maintain effective coordination under stress. Key success metrics include the speed of decision-making, the level of inter-agency coordination, and the ability to adapt to unexpected events. The objective is to ensure a responsive and effective command structure throughout the crisis.

**Why It Matters:** Inflexible command structures impede rapid decision-making. Immediate: Jurisdictional disputes → Systemic: 10% delay in critical response actions due to bureaucratic bottlenecks → Strategic: Reduced effectiveness of the overall evacuation effort.

**Strategic Choices:**

1. Hierarchical Command: Maintain a traditional hierarchical command structure with clear lines of authority, ensuring accountability.
2. Unified Command with Liaison Officers: Implement a Unified Command structure with liaison officers from each agency to facilitate communication and coordination, bridging organizational silos.
3. Decentralized Autonomous Teams: Empower autonomous response teams with decision-making authority within pre-defined parameters, enabling rapid adaptation to local conditions and fostering agility.

**Trade-Off / Risk:** Controls Control vs. Agility. Weakness: The options do not adequately address the potential for conflicting priorities between federal, state, and local agencies.

**Strategic Connections:**

**Synergy:** This lever is synergistic with `Communication Redundancy Strategy`. Adaptable command structures rely on robust communication networks to maintain situational awareness and coordinate actions. It also amplifies the effectiveness of `Evacuation Trigger Protocol` by allowing for adjustments based on real-time data and expert judgment.

**Conflict:** A `Hierarchical Command` structure conflicts with `Decentralized Autonomous Teams`, potentially hindering rapid adaptation to local conditions. It also constrains `Command & Control Decentralization`, limiting the ability to delegate authority to lower levels.

**Justification:** *Medium*, Medium importance. It supports communication and evacuation triggers, but is less critical than the overall command decentralization strategy. It addresses control vs. agility but is secondary to the core C2 architecture.
