Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 10 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 6 | Material risk with plausible path. |
| ✅ Low | 4 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is a large-scale industrial R&D and advanced manufacturing program aiming to engineer real machines and processes from known physical principles. Nothing in the plan requires violating a named law of physics or invoking non-physical causation; the ambitious coverage and feedstock-flexibility targets are engineering and economic feasibility questions, not physics-law violations.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan concedes the '95% component-coverage claim from basic feedstock is unproven, especially for complex electronics, FPGAs' and calls integrating radically different processes into one compact line 'a feat not yet demonstrated'; cited precedents (ITER, ASML, OSAM-2) are domain-mismatched, and failure would be existential for the EUR 200B programme.

**Mitigation**: Programme Executive Board: Within 18 months, run parallel validation tracks—Market (anchor-customer LOIs), Legal (filed export licenses, CERN opinion), Technical (imec-supervised FPGA/sensor yield pilot vs IRDS baseline), Safety/Operations (bench-scale feedstock pilot vs fab baseline)—with global NO-GO gates on engineering validity and legal compliance; reject domain-mismatched PoCs; Owner: Programme Director; Deliverable: validation-track reports with NO-GO verdicts; Date: within 18 months.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because levers have owners and success metics, but the plan concedes "No killer application has been defined" and expert review flags "absence of quantified space-readiness requirements" as showstoper — key concepts left undefined.

**Mitigation**: Programme Executive Board: Direct the Commercialisation Lead and CTO to co-author one-pagers defining the killer application and quantified space-readiness parameters with value hypothesess, success metics, and decision hooks within 6 months.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ✅ Low

**Justification**: Rated LOW because register covers legal/safety/financial/reputational classes with owners/controls — "single enterprise risk register undergoes quarterly board review" — and premortem maps cascades (permit suspension → funding-gate failure).

**Mitigation**: Programme Controls & Risk Lead: Add named-owner cascade chains (permit delay → option penalties → cash crunch) to the register; begin quarterly cascade reviews within 3 months.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a permit/approval matrix and authoritative lead-time comparison; it only lists "Execute 24-month option agreements... by Q4 2026" and admits "permit delays... 6-24 months," leaving critical predecessors (zoning, export-control licenses, construction permits) unmapped against scheduled allocations despite added buffers.

**Mitigation**: Programme Controls Office: Rebuild the critical path within 90 days, mapping each permit and long-lead procurement to authoritative jurisdiction lead times, and set a NO-GO threshold on cumulative slip exceeding six months.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because funding is uncommitted: 70% public (EUR140B) awaits 'binding commitment letters from EIB/EBRD'; 30% private (EUR60B) has 'no revenue model'; EUR10B/year draw over 20-year runway lacks term sheets/covenants.

**Mitigation**: Programme CFO: Deliver a dated financing plan within 6 months listing each source's status (LOI/term sheet/closed), EUR8–12B/year draw schedule, covenants, and NO-GO triggers on missed financing gates.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the EUR 200 billion plan omits scale-appropriate benchmarks and per-area cost substantiation; only aggregate inputs (300 ha, 150,000 m², 50 MW) appear, with no normalized capex/fit-out/opex math beyond a stated 10% contingency. ITER/ESS comparables are not quantified, and no vendor quotes are cited.

**Mitigation**: Owner: Programme CFO with independent cost consultant. Deliverable: benchmark report with ≥3 normalized comparables and vendor quotes, adjusting budget or descoping by footprint. Date: within 9 months.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan explicitly models alternative scenarios: "at 2% inflation" versus "3% inflation" and "if the private share falls to 10%", plus a nine-scenario premortem, so projections are not one-sided.

**Mitigation**: Programme Controls Office: Publish a quarterly best/worst/base-case projection dashboard with confidence intervals for coverage, funding share, and completion dates within 90 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because build-critical artifacts are scheduled with owners and dates ('Publish version 1.0 of the controlled inter-module interface register'; 'Develop factory acceptance test plan and criteria'), yet core non-functional requirements remain absent: 'Missing data: unit-step process flows, equipment footrint lists, yield-by-step expectations, and space-readiness requirements.'

**Mitigation**: Factory Systems, Interface & Digital Integration Architect: Within 12 months, deliver an engineering baseline pack—technical specifications, interface definitions, acceptance test plans, integration map, and quantified space-readiness requirements—each artifact assigned a named owner and review gate.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan asserts a 'EUR 200 billion public-private risk-sharing consortium' and 95% coverage, yet no binding funding, partner MOUs, export-license IDs, or certification evidence exist—missing artifacts are critical, not minor.

**Mitigation**: Programme Governance Office: Assemble a verifiable evidence pack within 180 days—SPV signatures, partner MOUs, export-control filing receipts, committed funding—or formally descope the 95% claim until artifacts exist.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 2046 deliverable, a 'space-ready' miniaturized manufacturing module, lacks verifiable qualities; the plan itself lists 'target payload mass, power, vibration, vacuum compatibility' as Missing Information.

**Mitigation**: Programme Director with space agencies: Define SMART acceptance criteria for the space-ready module—KPIs: payload mass ≤500 kg, autonomous operation ≥90 days—delivering a quantified space-readiness baseline within 12 months.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the net-zero-2040/renewables/90%-water-recycling package adds billions, draining contingency, without supporting "manufacture over 95% of necessary components" or the space-precursor; only "EU Green Deal alignment" is cited, not binding law.

**Mitigation**: Programme Director: Deliver a Benefit Case Review within 90 days—one-page case per flagged sustainability target with KPI, owner, estimated cost, and legal basis, or move each feature to the project backlog.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the unicorn role—Electronics & Semiconductor Fabrication Deputy Lead—carries 'the highest technical risk' and is 'central to the 95% coverage claim'; such feedstock-to-FPGA expertise is rare and heavily poached.

**Mitigation**: Knowledge, Talent & Workforce Continuity Lead: Deliver within 90 days a validated talent-market report for the Electronics & Semiconductor Fabrication Deputy Lead—candidate pool, compensation benchmarks, poaching exposure—with a go/no-go recruitment threshold.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan's own review finds 'no Technology Transfer Matrix or Legal Makeability Map exists' while EU Dual-Use Regulation 2021/821, MTCR/Wassenaar licensing and CERN participation legality remain unresolved showstoppers.

**Mitigation**: Cross-Border Legal, Regulatory and Export Control Lead: Deliver fatal-flaw analysis plus regulatory matrix (authority, artifact, lead time, predecessors) within 6 months; pre-consult BAFA, CDIU, SECO, SBDU/DGDDI; NO-GO on adverse findings.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan names operational sustainability risks but lacks a post-2046 funding model; expert review flags "private investors... would need roughly 150-200B of gross licensing or product revenue," and maintenance success relies on unproven "two trained practitioners per critical skill."

**Mitigation**: Programme Director: Commission an Operational Sustainability Plan within 12 months covering 20-year operating budget, maintenance schedule, succession planning, technology refresh roadmap, and adaptation triggers for coverage and market shifts.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan relies on 'Supportive zoning and regulatory environment' plus 'pre-application zoning and environmental screening' without completed fatal-flaw screens, written approvals, or fallback designs; approval outcomes remain uncertain.

**Mitigation**: Site Development and Construction Lead: Run fatal-flaw screens with zoning, fire, structural, and noise authorities at all three nodes; obtain written confirmations and publish fallback sites and NO-GO thresholds within 6 months.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because partial redundancy is planned—'iversify suppliers' and three federated sites—but the team.md concedes 'No team role explicitly owns supplier qualification,' and no SLAs or failover tests exist.

**Mitigation**: Programme CFO: Contractually secure secondary suppliers with SLAs, provision a digital-twin failover node, and complete a failover test within 12 months.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because Strategic Funding is incentivized by gate-linked budget adhererence while R&D needs sustained breakthrouph investment; plan concedes 'overly rigid phasing could starve high-risk, high-reward avenues,' lacking shared OKR.

**Mitigation**: Programme CFO and Advanced Manufacturing Lead: Co-author a joint OKR within 90 days—shared outcome of auditable 95% coverage by 2042 with funding releases tied to yield-learning milestones.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: ✅ Low

**Justification**: Rated LOW because KPIs, cadence, owners, and stop-thresholds exist: 'corrective action is required if any family falls below 80% of its stratified target,' 'quarterly board review,' plus premortem STOP RULES and descope triggers.

**Mitigation**: Programme Controls and Risk Management Lead: Operationalize the consolidated KPI dashboard and lightweight change board within 90 days, publishing monthly KPI and descope-trigger snapshots to the quarterly board review.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan's own Review 1 warns 'export-control... can strand a site node, trigger EUR 100-500M in legal/compliance costs, and expose IP valued at EUR 50-100 billion' while the semiconductor yield and funding gaps are tightly coupled: 'missed technical gates trigger funding-gate failures' — a multi-domain cascade with no cross-impact analysis.

**Mitigation**: Programme Controls and Risk Management Lead: Deliver a combined risk interaction map with bow-tie analysis for export-control, technical coverage, funding, and integration domains, including named owners, NO-GO thresholds, and dates for review within 6 months.