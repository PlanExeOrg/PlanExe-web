# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Dual-Use Export Control and Technology Transfer Counsel

**Knowledge**: German BAFA, Dutch CDIU, Swiss SECO export controls, EU dual-use regulation, technology transfer licensing, cross-border R&D consortia

**Why**: Federated sites cross Swiss/EU borders; the assessment requires BAFA, CDIU, SECO filings by 2026-10-15 and a technology-transfer matrix to avoid regulatory gridlock.

**What**: Review the export-control classification requests and technology-transfer matrix, and design a quarantine workflow for stalled controlled items before any cross-border shipment.

**Skills**: export classification, regulatory risk assessment, intergovernmental SPV drafting, compliance program design

**Search**: BAFA CDIU SECO export control lawyer, dual-use technology transfer counsel, EU Switzerland export compliance expert

## 1.1 Primary Actions

- Immediately pause all decisions on site options, SPV structure and private-partner licensing until an export-control and technology-transfer feasibility pass is completed.
- Appoint an independent Export Control and Technology Transfer Director with stop-work authority and retain licensed dual-use/customs counsel in Germany, Netherlands, Switzerland and France.
- Complete a Technology Transfer Matrix and a Legal Makeability Map before submitting any request to BAFA, CDIU, SECO or the French SBDU/DGDDI.
- Submit concrete license applications, not just classification requests, for lithography tooling, propulsion manufacturing equipment and robotic actuation technology; no cross-border transfer or partner access until authorizations are granted.
- Redraft the SPV and consortium agreements with a binding Export Control and Technology Transfer chapter, including deemed-export screening, nationality controls, contributed-technology schedules, IP ownership rules and a 'no transfer without license' clause.
- Run an MTCR/Wassenaar and military-end-use review of the 'space-rated propulsion' and 'complex electronics/FPGA' ambitions; descope or restructure any workstream that cannot be legally licensed within the programme timeline.

## 1.2 Secondary Actions

- Engage CERN's legal and Knowledge Transfer group immediately to determine whether CERN can be a partner at all, and prepare a fallback Swiss/French industrial site that does not depend on CERN governance.
- Integrate export-control status into the makeability map so that the 95% coverage denominator only includes components and processes that are licensable.
- Design physical and cyber 'export-controlled technology' zones at each site, with nationality-based badge access, visitor screening and digital-twin access logging.
- Add export-control and licensing milestones to every funding gate, investor term sheet and partner agreement.
- Establish mandatory export-control training for all partner staff, contractors, students and visitors, with a specific module on intangible transfers and deemed exports.
- Create a joint regulatory pre-consultation with BAFA, CDIU, SECO and French authorities to obtain early government feedback on the proposed technology flows and to identify showstoppers before construction or SPV finalization.

## 1.3 Follow Up Consultation

In the next consultation, we will review your draft Technology Transfer Matrix and Legal Makeability Map, agree on jurisdiction and route-to-license strategy for each site, and begin redrafting the SPV's export-control chapter. Bring the legal description of each proposed site, partner org charts and ownership structures, preliminary technical specifications for lithography, propulsion and robotic actuation, the list of all third-country nationals expected to access the digital twin, and any existing export-control authorisations held by ASML, Zeiss, Fraunhofer or their affiliates. We will also decide whether the 'space-rated propulsion' workstream should be separated into an intergovernmental, non-commercial programme to protect the rest of the project from MTCR and catch-all exposure.

## 1.4.A Issue - Export control is a critical-path gating issue, not a 'file by 15 October' administrative step

Your plan sets dates for filing export-control classification requests but not one legal gateway for go/no-go. Classification is not a permit; it is a technical/legal opinion. A denied or delayed license can invalidate a site node, yet you are prepared to sign site options and SPV agreements before knowing whether lithography, propulsion and robotic actuation technology can cross the Swiss/EU border at all. You omit the French dual-use authority for the Pays de Gex site and fail to specify whether the CERN-adjacent site is in Switzerland or France. The federated digital twin is itself an export-control vector; every researcher of non-Swiss/non-EU nationality who accesses it will trigger deemed-export rules. You also assume 'public-private risk-sharing' is compatible with sharing controlled technology; it is not unless the private partners are cleared as consignees and end-users. This is not a paperwork problem; it is a critical-path feasibility gate that should have been started before the project plan was written.

### 1.4.B Tags

- export-control
- critical-path
- deemed-export
- classification-not-license
- missing-french-authority

### 1.4.C Mitigation

Immediately appoint an Export Control and Technology Transfer Director with independent stop-work authority. Retain licensed dual-use and customs counsel in Germany, Netherlands, Switzerland and France. Build a complete Technology Transfer Matrix before filing anything: every item of hardware, software, source code, technical data, CAD/CAM files, process recipes, metrology data, digital-twin access and personnel nationality. Identify the exact national legal basis for each site: Swiss SECO for a Swiss site, French SBDU/DGDDI for Pays de Gex, BAFA for German sites, CDIU for Dutch sites. Submit actual license applications, not merely classification requests, with full technical dossiers, end-user undertakings, consignee details and compliance plans. Read EU Regulation 2021/821, the German AWV and Ausfuhrliste, the Dutch dual-use implementation law, the Swiss Goods Control Ordinance, and the EU guidance on internal compliance programmes. The data required is your technical specification for lithography tooling, propulsion manufacturing equipment and robotic actuation, plus the complete list of third-country nationals expected to access the digital twin or laboratories. Do not sign any site option, SPV agreement or private-partner licensing term until this legal routing is complete.

### 1.4.D Consequence

Without this mitigation, the programme will make illegal technology transfers, incur criminal and administrative penalties, lose export privileges, and suffer multi-year regulatory gridlock. Site investments will be stranded and the federated integration model will collapse because each partner will be legally unable to share its core technology.

### 1.4.E Root Cause

Engineering-led planning treats export control as an external permit rather than as a design constraint. No export-control counsel appears to be in the core decision loop.

## 1.5.A Issue - Your SPV and consortium governance will fracture on technology transfer and export-control conflicts

The SPV and consortium design is a governance fantasy. A 'joint compliance office staffed by host-country representatives' will not resolve export-control conflicts; it will become a forum for national interests. ASML, Zeiss and Fraunhofer each have their own legal obligations; they will not transfer proprietary or controlled technical data into a common digital twin without a rigorous legal framework. CERN is an international organization with a mission limited to fundamental science; it cannot simply be used as an anchor for an industrial space-manufacturing programme without explicit legal and political verification. The current documents contain no deemed-export screening, no nationality-based access controls, no classification registers, no IP/export-control schedules, and no conflict-of-law resolution mechanism. The result will be partner withdrawal, national regulator intervention, and multi-billion-euro arbitration.

### 1.5.B Tags

- SPV-governance
- technology-transfer
- deemed-export
- intellectual-property
- cern-governance

### 1.5.C Mitigation

Redraft the SPV as a real legal person with a binding Export Control and Technology Transfer chapter. Include nationality-based access restrictions, mandatory screening for all staff and visitors before any digital-twin or laboratory access, and a 'no transfer or disclosure without license' clause. Add a Contributed Technology Schedule to every partner agreement, listing each partner's controlled hardware, software, recipes, patents, know-how and the associated export classifications. Designate a lead export-control authority for each technology cluster and an escalation mechanism when German, Dutch, Swiss, French or EU interpretations conflict. Engage CERN's Knowledge Transfer and legal group immediately to determine whether CERN can participate at all; if not, replace 'near CERN' with a Swiss/French industrial site that does not depend on CERN governance. Read the EU Dual-Use Regulation Article 10 on internal compliance, the EU guidance on intangible transfers, and comparable governance structures from ITER, IMEC-CC and ASML supplier programs. Data needed: partner ownership structures, all third-country nationals, technology contribution lists, current IP assignments, and existing partner-level export-control authorizations.

### 1.5.D Consequence

Without this mitigation, partners will refuse to share core technology, national export authorities will block digital-twin access, private investors will not fund, and IP disputes will consume years of the 20-year timeline. The federated model will degrade into isolated national silos, making integrated manufacturing impossible.

### 1.5.E Root Cause

Governance was designed by engineers and policy advisers, not by export-control and technology-transfer lawyers. The commercial licensing structure was chosen for funding optics without legal feasibility analysis.

## 1.6.A Issue - The 95% component-coverage and 'basic feedstock' claim is legally and technically indefensible without a licensability map

The 95% coverage promise from basic feedstock ignores that controlled goods are defined not only by the physical item but by production equipment, software and manufacturing know-how. FPGAs, sensors, propulsion units, robotic actuators, and energy systems are not neutral engineering objects; many are controlled under EU Dual-Use Regulation 2021/821, Wassenaar, MTCR and national arms-control lists. 'Space-rated propulsion manufacturing equipment' likely sits in MTCR-sensitive territory, and the phrase 'Space-Based Universal Manufacturing' will trigger end-use scrutiny under catch-all clauses. 'Basic feedstock' is irrelevant: the process recipes, G-code, CAD models, lithography tool parameters and the factory itself are 'technology' and 'production equipment'. You are confusing the raw material input with the regulated transformation process. The makeability map must include a licensability classification for each component and each process, or the 95% denominator will be legally unachievable and the programme will collapse at the first audit.

### 1.6.B Tags

- controlled-goods
- production-technology
- MTCR
- Wassenaar
- catch-all
- licensability-map

### 1.6.C Mitigation

Add a Legal Makeability Map as a mandatory companion to the component makeability map. For each of the 5,000 part numbers, determine: (1) whether the finished item is controlled under EU or national lists; (2) whether the machine, software, process recipe or inspection technique required to make it is controlled; (3) which cross-border transfers are triggered; and (4) whether the nationality of operators or digital-twin users creates deemed-export exposure. Where a component or process cannot be licensed within the programme timeline, remove it from the 95% denominator or restructure it under an explicit intergovernmental framework. For 'space-rated propulsion', conduct an MTCR/Wassenaar compliance review before committing any funding; this workstream may need to be ring-fenced under government-to-government arrangements rather than an open public-private licensing model. Consult former BAFA, CDIU, SECO and French SBDU licensing officers, and an ITAR/EAR specialist if any US-origin items or data enter the supply chain. Read EU Regulation 2021/821 Annex I and Article 4, the Wassenaar Dual-Use List and Munitions List, the German Ausfuhrliste, the Swiss Güterkontrollgesetz and Güterkontrollverordnung, and the Dutch dual-use legislation. Provide engineering-level data for process steps, tolerances, materials, control software, and intended end users.

### 1.6.D Consequence

Without this mitigation, the 95% claim is a false promise. On first audit, it will be legally indefensible. Partner institutions such as ASML and Zeiss will be trapped between their own export-control obligations and the consortium's demands, regulators will open investigations, and the programme will be forced into a massive, reputation-damaging descope.

### 1.6.E Root Cause

The project uses 'components' as a purely engineering taxonomy and ignores that the same items are regulated objects in export law. The strategic ambition of 95% coverage was set without any legal feasibility analysis of the output catalogue and production technologies.

---

# 2 Expert: Semiconductor Fabrication and Miniaturization Technologist

**Knowledge**: semiconductor lithography, FPGA manufacturing, additive/subtractive microfabrication, yield engineering, feedstock purity tolerance, cleanroom processes

**Why**: The 95% coverage claim is unproven for FPGAs and complex electronics; the makeability map and 2032 gate need realistic TRL, yield, and process-path thresholds for these highest-risk families.

**What**: Validate makeability-map assumptions for electronics and FPGAs, recommend coverage sequencing, and assess co-development, licensing, or maskless lithography options.

**Skills**: yield modeling, process qualification, technology readiness assessment, lithography roadmap planning, metrology strategy

**Search**: semiconductor manufacturing technologist, FPGA fabrication yield expert, miniaturization process engineer, lithography roadmap consultant

## 2.1 Primary Actions

- Set a hard 'semiconductor reality gate' by 2027-06-30: commission and publish a process decomposition and yield budget for one representative FPGA and one representative sensor, using external fab process engineers from imec, CEA-Leti, Fraunhofer, or an IDM. If monolithic IC fabrication from basic feedstock is not physically plausible, explicitly descope it and redefine the 95% denominator.
- Replace the blanket '95% component coverage' metric with stratified coverage targets per technology family: structural, electro-mechanical, board-level electronics, packaged sensor dies, and monolithic ICs, each with its own TRL, yield model, and feedstock purity specifications.
- Redefine the miniaturized-track gate thresholds to include meaningful 3D integration and factory-level metrics: floor area per function, energy per output, module mass/power, autonomous operation duration, and changeover time. Move the first technology gate to 2029, not 2032.
- Create a Metrology & Process Control master plan covering CD-SEM, OCD, overlay metrology, defect inspection, electrical test, SPC, FDC, R2R control, calibration, and traceability, with budget and footprint allocated before site layouts are frozen.
- Define feedstock purity specifications per process family, not as a global tolerance; generate a purity-to-yield sensitivity matrix for silicon wafers, photoresists, etch gases, CMP slurries, metal powders, and reagents.
- Partner with imec, CEA-Leti, Fraunhofer IZM/IPMS, SEMI, and an experienced semiconductor yield/equipment consultancy to audit the makeability map and all process integration assumptions before any funding tranche beyond EUR 1 billion is released.

## 2.2 Secondary Actions

- Commit budget for contamination and AMC CFD modeling at ISO Class 1-2 with FOUP/mini-environments, not just ISO Class 5 zone separation and airlocks.
- Develop an IRDS-aligned technology roadmap for electronics fabrication that treats advanced packaging and heterogeneous integration as the most likely first truly space-ready capability, with monolithic leading-edge logic as an explicitly separate and later track.
- Initiate tool-footprint and resource-consumption modeling for a genuinely miniaturized fab module, e.g., a 50 m² module producing 10 wafers per week, to ground space-readiness claims in numbers.
- Define a 'killer application' that uses the factory's realistic likely capabilities — sensor modules, RF front ends, rad-hard board assemblies, or robotic actuators — rather than monolithic FPGAs produced from raw feedstock.
- Arrange early consultation with export-control and semiconductor-equipment suppliers to understand licensing and technology-transfer restrictions on in-situ process control software, lithography sources, and advanced metrology tools.

## 2.3 Follow Up Consultation

Next consultation: review the revised makeability map and semiconductor process decomposition. Bring one FPGA and one sensor product specification, a proposed process flow with all unit steps, equipment footprint list, yield model with yield-by-step expectations, metrology master plan, and a feedstock purity specification matrix. We will challenge every gate threshold, the 95% denominator, and the claim that a compact modular factory can manufacture electronics from basic feedstock. Be prepared to descope monolithic IC fabrication and instead define the factory as a system-integration and advanced-packaging facility for externally sourced die if the decomposition does not support the original claim.

## 2.4.A Issue - The 95% component-coverage claim contains a category error: semiconductor/FPGA fabrication cannot be delivered from 'basic industrial feedstock' in a compact modular factory.

You are treating 'complex electronics, FPGAs, sensors' as if they were one component class comparable to gearboxes and actuators. An FPGA is a monolithic integrated circuit requiring hundreds of tightly controlled unit processes: single-crystal silicon growth from 9N-11N polysilicon, wafering, epitaxy, ion implantation, EUV/DUV lithography with reticles and pellicles, multi-layer dielectric deposition, CMP, metal fill, plasma etch, wet clean, and advanced packaging. Each step requires extremely specific chemical inputs: photoresists with exact molecular weights and trace-metal contamination below ppb, etch gases such as SF6/BCl3/Cl2 with 9N purity, CMP slurries with tightly controlled particle-size distributions, and ultrapure water at 18.2 MΩ·cm. Yield is exponentially sensitive to particles, metallic contamination, vibration, temperature drift, overlay error, and mask defects. 'Adaptive process control' cannot compensate for a wafer containing dislocations, ionic contamination, or a resist batch whose photoactive compound concentration is off-spec. At best, control loops can adjust a small set of equipment parameters. Your proposed makeability map of 5,000 part numbers with a single TRL and 'process modification cost' per part number is far too coarse: one FPGA part is not a single process step but an entire process flow with thousands of critical steps. Unless you decompose semiconductor manufacturing into its actual unit processes, the 95% claim is not ambitious; it is physically indefensible and will fail any independent technical audit.

### 2.4.B Tags

- semiconductor-feasibility
- coverage-claim
- feedstock-purity
- makeability-map

### 2.4.C Mitigation

Commission a semiconductor process decomposition for one representative FPGA and one representative sensor, led by real fab process engineers from imec, CEA-Leti, Fraunhofer ISIT/IPMS, or an IDM. For every unit process, list required input material specifications, equipment footprint, cleanroom class, expected yield contribution, and cycle time. Use these data to stratify the '95% component coverage' denominator by technology family: structural, electro-mechanical, board-level electronics, packaged sensor dies, and monolithic ICs. If monolithic IC fabrication from basic feedstock does not survive this decomposition, explicitly descope it and redefine 'component' as a higher-level assembly, or state that the factory builds packaged modules and systems from externally sourced die. Do not allow a spreadsheet with 5,000 part numbers to hide the fact that a single FPGA contains thousands of critical process steps.

### 2.4.D Consequence

Without this correction, the programme will be publicly and internally exposed as technically unserious. It will fail to attract the very semiconductor process engineers it needs, waste tens of billions on impossible process development, and inevitably be forced into a humiliating descope that destroys credibility with member states and private investors.

### 2.4.E Root Cause

Treating semiconductor fabrication as 'just another additive/subtractive manufacturing process' and assuming that feedstock tolerance can be compensated by software-level adaptive control, despite half a century of evidence that chip yield is dominated by contamination, metrology, and statistical process control.

## 2.5.A Issue - The miniaturization gate metrics are obsolete and irrelevant: a 10 µm line-width coupon and a robotic gearbox prove nothing about space-ready miniature manufacturing.

Your 'radically miniaturized bench-scale unit' gate is to produce a 10-layer interconnect test coupon on a 200 mm wafer with line width no more than 10 µm. That is roughly 1990s-era capability and says nothing about manufacturing miniaturization. Leading-edge FPGAs use single-digit-nanometer geometries, EUV multi-patterning, overlay budgets below 2 nm, 3D FinFET/GAA transistors, and advanced packaging with TSVs, interposers, and hybrid bonding. The actual challenge for space-based universal manufacturing is not drawing wide lines; it is shrinking the entire manufacturing ecosystem: lithography tool and vacuum loads, vibration isolation, chemical delivery, metrology, defect control, and thermal management in a compact, low-power, autonomous module. Meanwhile, the macro-scale gate — a functional robotic actuator gearbox from three feedstock batches with ±5% purity variation — is a powder metallurgy exercise, not a demonstration of breakthrough manufacturing. Neither gate includes any factory-level metric: mass, volume, power per kg of output, autonomous operation duration, changeover time, or reconfigurability. Without such metrics, 'miniaturization pathway' is a slogan. The 2032 merge gate is also too late: architecture and interface decisions will already be locked into hardware. Finally, you are conflating a miniaturized factory with a factory that makes miniaturized parts; the factory itself must be small, robust, autonomous, and space-ready.

### 2.5.B Tags

- miniaturization
- technology-readiness
- gate-criteria
- space-readiness
- advanced-packaging

### 2.5.C Mitigation

Redesign the miniaturized track around realistic 3D integration and advanced packaging: build a functional electronic subassembly such as a CubeSat avionics board or an integrated sensor module using through-silicon vias, multi-die stacking, and wafer-level bonding. Set quantitative factory-level metrics: manufacturing floor area per function, energy per component, module mass and power, autonomous yield, and changeover time between product types. Benchmark gate thresholds against current capabilities at imec, Fraunhofer IZM, CEA-Leti, and the IRDS packaging roadmap. Move the first technology gate to 2029, not 2032, and add a descope trigger if the tool footprint per manufacturing function is more than 10× a conventional microfabrication toolset.

### 2.5.D Consequence

If you keep these lax gate metrics, you will pour years and billions into demonstrating technologies that are already commercially available, while never addressing the real system-level miniaturization, autonomy, and integration problems that determine space-readiness. The 2046 'space-ready module' will be a warehouse-sized cleanroom bolted to a spacecraft and will fail.

### 2.5.E Root Cause

Equating physical miniaturization of manufactured parts with miniaturization of the manufacturing system itself, and selecting research thresholds far below state-of-the-art to make the gate artificially achievable.

## 2.6.A Issue - Metrology, contamination control, and yield engineering are dangerously underspecified: ISO Class 5 plus airlocks plus in-line spectroscopy will not produce working electronics.

Your plan treats cleanliness and measurement as zoning and layout trade-offs, not as the foundation of semiconductor yield. ISO Class 5 cleanrooms are far too dirty for leading-edge lithography and wafer-level electronics; you need ISO Class 1-2 zones or, more realistically, wafer transport in FOUPs/mini-environments, plus molecular contamination (AMC) filtration, vibration isolation, and temperature stability better than ±0.1°C. In-line spectroscopy on feedstock batches is not semiconductor metrology. You need CD-SEM, optical critical dimension (OCD) metrology, overlay metrology, film-thickness measurement, defect inspection, stress measurement, doping-profiling, particle detection, and electrical wafer test. The plan's 'Measurement Gate Rhythm' talks about where to place gates but does not acknowledge that the metrology tools themselves have huge footprints, long calibration chains, and are among the hardest things to miniaturize. 'Adaptive process control' assumes you can correlate feedstock purity variation to process settings and correct in real time. For most semiconductor processes the correlation is non-linear, multivariate, and not measurable in-situ: pattern collapse, line-edge roughness, via poisoning, implant channeling, and via-misalignment all arise from combinations of inputs that spectroscopy cannot see. A global 'purity tolerance' of ±5% is meaningless when photoresist, etch gases, CMP slurries, and silicon wafers must meet ppb/ppt trace-metal specs. Without a yield model, statistical process control (SPC), fault detection and classification (FDC), and run-to-run (R2R) control, the programme cannot even know whether a process is on target.

### 2.6.B Tags

- metrology
- contamination-control
- yield-engineering
- adaptive-control
- cleanroom-class

### 2.6.C Mitigation

Create a dedicated Metrology & Process Control workstream before any tool purchase or site layout freeze. Develop a yield model using SEMI standards and IRDS defect budgets. For each process chain, define a specific contamination control class and a specific feedstock specification matrix; do not use one global tolerance. For semiconductor processes, adopt industry-standard wafer handling: FOUPs/SMIF, mini-environments, ISO Class 1-2 or better, AMC filtration, and rigorous vibration/temperature specifications. Allocate footprint and budget for CD-SEM, OCD, overlay, defect inspection, and electrical test. Commission a 'metrology sourcing and calibration' study to determine whether the factory can maintain its own measurement standards, and if not, remove measurement tools from the in-factory coverage claim or plan a certified metrology partnership. Include SPC/FDC/R2R as a design requirement in every process module, not as an afterthought.

### 2.6.D Consequence

Without this deeper engineering, the programme will experience catastrophic yield failures in electronics fabrication. Every tool will look fine in isolation; the integrated factory will produce no working FPGAs or sensors. The programme will then blame 'feedstock variability' rather than its own failure to engineer contamination control and metrology, and the 95% coverage certification will collapse.

### 2.6.E Root Cause

Viewing semiconductor manufacturing as a broad 'additive/subtractive process' rather than as a yield-driven, contamination-limited, statistically controlled industry with decades of standards and learning curves.

---

# The following experts did not provide feedback:

# 3 Expert: Space Manufacturing Commercialization Strategist

**Knowledge**: space-based manufacturing, in-orbit servicing, mission requirements, TRL maturation, space agency partnerships, market sizing

**Why**: The goal is a precursor to space-based universal manufacturing, yet the SWOT lacks space-readiness requirements and a killer application; this role defines those targets and anchor demand.

**What**: Define space-readiness validation criteria for the 2046 module, identify anchor customers and killer-application demonstrations, and build an early partnership roadmap with space agencies.

**Skills**: mission architecture, market analysis, stakeholder engagement, business case development, requirements definition

**Search**: space manufacturing strategy consultant, in-orbit servicing market analyst, space technology readiness expert, commercial space partnerships

# 4 Expert: Megaproject Finance and Currency Risk Economist

**Knowledge**: megaproject finance, public-private partnerships, inflation indexation, currency hedging, contingency reserves, long-horizon capital structuring

**Why**: A EUR 200 billion unindexed budget loses roughly EUR 65 billion real value; the assessment demands real-euro treasury directives, EUR/CHF hedges, a EUR 20 billion reserve, and gated tranches.

**What**: Audit funding phasing and the treasury directive, model inflation and EUR/CHF scenarios, and structure private-investor returns and contingency release against technical milestones.

**Skills**: financial modeling, risk quantification, PPP structuring, treasury hedging, investor return analysis

**Search**: megaproject finance director, public-private partnership economist, currency hedging treasurer, long-horizon program cost modeler

# 5 Expert: Modular Factory Integration Architect

**Knowledge**: modular manufacturing systems, interface control, mechatronics integration, federated production networks, digital twin coordination

**Why**: The inter-module interface register and prime integrator model are central to the plan; the assessment requires v1.0 by 2027-01-15 and compliance simulations before parallel development.

**What**: Own the controlled interface register, define the 12 initial mechanical, power, fluid, and data specifications, and run the joint integration review gates.

**Skills**: systems engineering, interface management, integration testing, CAD/BOM governance, cross-site coordination

**Search**: modular factory integration architect, interface control manager, prime integrator systems engineer, distributed manufacturing integration

# 6 Expert: Feedstock Resilience and Adaptive Process Control Engineer

**Knowledge**: material purity variability, in-line spectroscopy, adaptive process control, additive/subtractive process physics, statistical process control

**Why**: The goal and SWOT demand robust adaptability to feedstock purity and composition variation, and Decision 6 requires adaptive control loops powered by measurement gates.

**What**: Design in-line spectroscopy and recalibration loops for feedstock batches, and build the purity-to-failure correlation database to qualify new materials.

**Skills**: spectroscopy, process automation, control loop tuning, DOE, quality engineering

**Search**: adaptive process control engineer, in-line spectroscopy manufacturing, feedstock variability expert, additive manufacturing process control

# 7 Expert: Cleanroom and ATEX Safety Systems Engineer

**Knowledge**: ATEX 2014/34/EU, ISO 14644 cleanrooms, contamination zoning, airlock cascade design, inert gas blanketing, CFD particle dispersion

**Why**: The assessment freezes ATEX pressure cascades and contamination zoning by 2026-10-31 and mandates CFD proof, inerting, and explosion relief before construction.

**What**: Define the negative-pressure dirty zones and positive-pressure clean bays, run CFD simulations, and specify airlocks, alarms, grounding, and inerting interlocks.

**Skills**: cleanroom design, explosion safety, CFD simulation, hazardous area classification, safety interlock engineering

**Search**: cleanroom ATEX engineer, contamination control specialist, metal powder safety expert, CFD cleanroom consultant

# 8 Expert: Knowledge Continuity and Workforce Strategist

**Knowledge**: long-horizon R&D talent retention, mentorship rotation, knowledge management, digital twin documentation, organizational learning

**Why**: The 20-year timeline and SWOT highlight knowledge attrition and scarce expertise; Decision 14 requires redundancy, rotation, and documentation to survive turnover.

**What**: Build a two-decade staffing and succession plan with paired practitioners, digital twin records for every process decision, and multi-site redundancy for critical skills.

**Skills**: workforce planning, knowledge management, retention strategy, training program design, organizational resilience

**Search**: knowledge management strategist, R&D talent retention consultant, workforce continuity planning, expertise transfer specialist