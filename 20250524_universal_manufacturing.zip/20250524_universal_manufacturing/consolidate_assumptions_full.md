# Purpose

**Purpose:** business

**Purpose Detailed:** A 20-year, EUR 200 billion large-scale industrial research and development initiative focused on advanced manufacturing infrastructure, technology development, and strategic planning for universal manufacturing capability, including electronics, robotics, propulsion, and energy systems production.

**Topic:** Earth-based modular miniaturized factory system as precursor to Space-Based Universal Manufacturing

# Domain

**Primary domain:** Advanced Manufacturing

**Secondary domains:** Semiconductor Fabrication, Materials Engineering, Robotics Engineering

**Rationale:** Advanced Manufacturing owns the core outcome: a modular miniaturized factory producing 95% of components from feedstock, with the highest importance and specificity. Aerospace Engineering targets the later space goal, while Systems Engineering and remaining disciplines are supporting methods or constraints.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Advanced Manufacturing | 5 | 5 | outcome | Core deliverable is a modular miniaturized factory performing additive and subtractive manufacturing from feedstock. |
| Systems Engineering | 5 | 4 | method | Integrates diverse manufacturing subsystems into one coherent modular miniaturized factory platform. |
| Semiconductor Fabrication | 4 | 4 | method | Manufacturing complex electronics, FPGAs, and sensors draws on lithography expertise near ASML and Zeiss. |
| Materials Engineering | 4 | 4 | constraint | Feedstock-to-component conversion must tolerate variations in material purity and composition. |
| Robotics Engineering | 4 | 4 | method | Robotic actuators and automated miniaturized factory operation are core mechanisms demanding robotics expertise. |
| Aerospace Engineering | 4 | 4 | outcome | Propulsion unit production and the ultimate space-based manufacturing goal anchor project success. |
| Metrology | 4 | 4 | method | Adapting to feedstock purity and composition variation requires precise measurement and characterization. |
| Electronics Engineering | 4 | 4 | method | Enables in-factory production of complex electronics, FPGAs, and sensors from feedstock. |
| Industrial Engineering | 4 | 3 | method | Designs modular factory layout, workflows, and processes achieving 95% component coverage. |

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** This plan is *unambiguously physical*. It describes a 20-year, EUR 200 billion initiative to construct an Earth-based modular, miniaturized factory system—a massive physical infrastructure project. The plan explicitly requires strategic physical locations near European innovation centers (CERN, ASML, Zeiss, Fraunhofer). The core deliverable involves building physical manufacturing facilities, acquiring industrial feedstock, physically fabricating components (complex electronics, FPGAs, sensors, propulsion units, robotic actuators, energy systems), and demonstrating real-world manufacturing adaptability through physical testing. The R&D activities themselves (prototyping, fabrication, characterization, assembly) all require laboratories, factories, machinery, and physical workspaces. There is no conceivable way this initiative could be executed entirely online; every stage—from site selection and facility construction to component manufacturing and validation—depends on physical presence and physical resources.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Proximity to CERN for expertise in precision instrumentation, vacuum systems, and large-scale scientific infrastructure
- Proximity to ASML for semiconductor lithography, precision mechatronics, and cleanroom manufacturing capabilities
- Proximity to Zeiss and Fraunhofer for optics, precision manufacturing, and applied industrial R&D
- Availability of large industrial land for modular factory build-out and future expansion
- Access to high-capacity clean energy, water, and advanced utility infrastructure
- Established high-tech industrial ecosystem with specialized suppliers and skilled workforce
- Transport links for feedstock delivery, module logistics, and inter-site coordination
- Supportive zoning and regulatory environment for large-scale R&D and manufacturing facilities

## Location 1
Switzerland / France

Geneva region (CERN proximity)

Meyrin, Switzerland / Pays de Gex, France (CERN campus vicinity)

**Rationale**: Direct proximity to CERN provides access to world-leading expertise in precision instrumentation, vacuum systems, cryogenics, and large-scale scientific infrastructure, aligning with the plan's need for advanced R&D and modular factory development.

## Location 2
Netherlands

Veldhoven / Eindhoven region (ASML proximity)

De Run 6501, 5504 DR Veldhoven, Netherlands

**Rationale**: ASML's Veldhoven/Eindhoven ecosystem offers semiconductor lithography, precision mechatronics, and high-tech manufacturing talent; this is critical for the electronics/FPGA fabrication and cleanroom requirements of the factory system.

## Location 3
Germany

Oberkochen / Southern Germany (Zeiss and Fraunhofer proximity)

Carl-Zeiss-Straße 22, 73447 Oberkochen, Germany, and nearby Fraunhofer institutes

**Rationale**: Zeiss and Fraunhofer are leaders in optics, precision manufacturing, and applied industrial R&D; this location supports optical systems, metrology, and additive/subtractive process development, and is central to German advanced manufacturing networks.

## Location Summary
The plan explicitly requires physical sites near European innovation centers. The three proposed nodes—Geneva/CERN, Veldhoven/ASML, and Oberkochen/Southern Germany—form a federated network that provides complementary expertise in physics, semiconductor lithography, optics, and applied manufacturing, while meeting the need for large industrial land, cleanroom infrastructure, and specialized talent.

# Currency Strategy

This plan involves money.

## Currencies

- **EUR:** The programme is explicitly budgeted at EUR 200 billion, and the primary sites in France, Germany, and the Netherlands are all in the eurozone, making EUR the natural currency for consolidated budgeting, procurement, and reporting.
- **CHF:** One major site is in the Geneva/Meyrin region near CERN in Switzerland, where local salaries, services, and some operational expenses will be incurred in Swiss francs.

**Primary currency:** EUR

**Currency strategy:** Use EUR as the single consolidated budgeting and reporting currency for the 20-year programme, aligning with the stated EUR 200 billion envelope and the eurozone locations. Denominate major contracts, funding tranches, and inter-site transfers in EUR to minimize conversion costs. Maintain a smaller CHF allocation for Swiss-side operational expenditures near CERN, with periodic hedging or natural offset mechanisms to manage EUR/CHF exchange-rate exposure over the long project horizon.

# Identify Risks


## Risk 1 - Regulatory & Permitting
The project spans multiple jurisdictions (Switzerland, France, Netherlands, Germany) with differing permitting regimes, export controls on advanced manufacturing and semiconductor technology, and environmental regulations. Delays in obtaining construction permits, tech-transfer licenses, or cross-border operational agreements could stall site development and module integration.

**Impact:** Site construction delays of 6–24 months per location, additional legal and compliance costs estimated at EUR 100–500 million, and potential misalignment of project phases across federated sites.

**Likelihood:** Medium

**Severity:** High

**Action:** Engage regulatory bodies early; establish a cross-border legal task force; harmonize compliance standards; build buffer time into the schedule; consider phased permitting for sub-sections.

## Risk 2 - Financial
The programme's 20-year, EUR 200 billion budget requires sustained political and private-sector commitment. If funding is phased with performance gates or if consortium members withdraw due to shifting priorities, financial instability could lead to project halt, loss of specialized staff, and vendor attrition.

**Impact:** Cash-flow shortfalls of EUR 10–20 billion during critical phases, project pauses of 1–3 years, and loss of key personnel, increasing restart costs by up to 30% of the affected budget.

**Likelihood:** Medium

**Severity:** High

**Action:** Negotiate multi-year legally binding commitments from public and private partners; diversify funding sources; establish contingency reserves (5–10% of total); implement transparent milestone-based disbursements to sustain investor confidence.

## Risk 3 - Technical
Achieving 95% component coverage—especially complex electronics (FPGAs, sensors, precision lithography)—from basic feedstock within a miniaturized footprint is extreme. The miniaturization pathway may encounter unproven physics, yield losses, and inability to reach required tolerances. The need for nanoscale additive/subtractive manufacturing may require breakthroughs that are not yet available.

**Impact:** Technical milestones delayed by 3–5 years; additional R&D spend of EUR 20–40 billion; possible failure to deliver space-ready modules within the 20-year horizon, undermining the precursor objective.

**Likelihood:** High

**Severity:** High

**Action:** Pursue parallel macro-scale and miniaturized prototypes as per the two-track approach; invest in early risk retirement for electronics; build external technical advisory board; implement flexible design that allows scaling back miniaturization while preserving core functionality.

## Risk 4 - Technical Integration
The federated network of sites (Geneva, Veldhoven, Oberkochen) requires seamless inter-module physical, data, and operational integration. Interface standards may be frozen prematurely or, conversely, deferred too long, causing incompatible modules, costly retrofits, or coordination breakdowns. Digital twin coordination across institutions may suffer from data formatting, latency, and security issues.

**Impact:** Integration phase extended by 2–3 years; retrofitting costs of EUR 5–15 billion; failed end-to-end demonstrations that delay credibility and may trigger funding termination.

**Likelihood:** Medium

**Severity:** High

**Action:** Adopt a prime integrator model with a shared integration layer; define interface specifications early but review iteratively; invest in robust digital twin architecture with common data standards; conduct joint integration tests at each milestone.

## Risk 5 - Supply Chain
The plan depends on basic industrial feedstock (metals, polymers, chemicals) but with strict purity requirements for electronics and precision components. Feedstock variability and availability may be affected by market fluctuations, geopolitical disruptions, or quality inconsistencies. The reliance on external inputs for even basic reagents could be interrupted.

**Impact:** Production line downtime of 1–6 months; yield drops causing scrap cost increases; additional investment in feedstock conditioning of EUR 2–8 billion; potential inability to meet production quotas.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop adaptive process controls with in-line spectroscopy; establish strategic feedstock stockpiles; diversify suppliers across regions; invest in on-site conditioning and purification to tolerate a wider purity band.

## Risk 6 - Operational
A 20-year endeavor risks losing critical expertise due to retirement, attrition, or poaching. Without active knowledge management, tacit knowledge in novel manufacturing processes and miniaturization could evaporate, causing rework, errors, and schedule delays. The federated site model also compounds coordination overhead and potential misalignment.

**Impact:** Loss of key specialists could delay critical milestones by 1–2 years; re-training and documentation costs of EUR 1–3 billion; increased error rates leading to safety and quality issues.

**Likelihood:** High

**Severity:** Medium

**Action:** Institute mentorship and rotation programmes; maintain exhaustive digital twin records and documentation; create geographic redundancy for critical roles; use competitive compensation and long-term incentives; establish a knowledge management office.

## Risk 7 - Environmental
The factory will consume large amounts of energy and water, produce waste heat and chemical byproducts, and may face strict environmental regulations. Failure to meet sustainability standards could result in fines, permit revocation, and public opposition. Clean/dirty zoning and thermal separation add complexity but also energy demands.

**Impact:** Regulatory penalties of EUR 500 million–2 billion; added costs for waste treatment and energy efficiency retrofits; potential public protests delaying construction by 1–2 years.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Incorporate heat recovery and renewable energy systems; implement closed-loop water recycling; conduct environmental impact assessments early; engage with local communities and green NGOs; set ambitious sustainability KPI and report periodically.

## Risk 8 - Social & Community
Large-scale industrial facilities near residential areas may face opposition due to noise, traffic, and perceived risks (chemical use, high-tech unknown). Community backlash could delay permits and increase costs. The project may also strain local infrastructure and housing markets.

**Impact:** Public opposition causing 1–3 years of legal battles; additional community benefits commitments of EUR 1–5 billion; reputational damage affecting talent recruitment.

**Likelihood:** Low

**Severity:** Medium

**Action:** Proactive community engagement, transparent information sessions; invest in local infrastructure and schools; offer employment opportunities; design facilities with low environmental footprint and noise insulation.

## Risk 9 - Security
The project involves cutting-edge intellectual property (semiconductor lithography, miniaturized manufacturing, space technology). Cyberattacks on digital twins, industrial espionage, and physical sabotage risk losing competitive advantage and confidential data. The multi-partner consortium increases attack surface.

**Impact:** IP theft could cost EUR 50–100 billion in lost exclusivity; cyberattacks could halt operations for weeks; reputational damage and loss of investor confidence.

**Likelihood:** Medium

**Severity:** High

**Action:** Implement zero-trust cybersecurity infrastructure; isolate critical systems; hire security experts; conduct regular penetration testing; enforce strict access controls and NDAs; establish cyber incident response team.

## Risk 10 - Market & Competitive
Over the 20-year horizon, competing technologies may emerge (alternative manufacturing methods, breakthroughs in space manufacturing) that could undermine the project's relevance or cost-effectiveness. Also, if the programme fails to demonstrate 95% coverage credibly, market adoption and future space contracts may not materialize.

**Impact:** Reduced interest from private investors, licensees, and space agencies; inability to recoup EUR 200 billion investment; potential obsolescence of certain manufacturing processes.

**Likelihood:** Low

**Severity:** Medium

**Action:** Continuously monitor technological landscape; patent key innovations; maintain flexibility to pivot; establish partnerships with emerging players; demonstrate tangible prototypes early to secure early adopters.

## Risk 11 - Legal & Contractual
The consortium model (public-private) with multiple partners across countries will require complex agreements on IP ownership, licensing, royalties, and decision-making. Disputes over IP or cost-sharing could stall progress or fragment the partnership. The chosen 'prime integrator' model may create dependency on a single entity.

**Impact:** Litigation costs of EUR 1–3 billion; partner withdrawal causing schedule delays of 2–5 years; loss of access to critical technologies.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Draft comprehensive collaboration agreements upfront; use international arbitration clauses; define IP ownership clearly; establish dispute resolution mechanisms; avoid over-dependence on one integrator by maintaining in-house capabilities.

## Risk 12 - Political
The project depends on support from multiple EU member states and Switzerland. Political changes, national elections, or shifting EU priorities could reduce funding or alter export control policies. With a 20-year horizon, such instability is almost certain to occur at some point.

**Impact:** Funding reductions of EUR 50–100 billion; cancellation of certain parts; project delays or restructuring; loss of momentum and credibility.

**Likelihood:** Medium

**Severity:** High

**Action:** Lobby for multi-party and multi-country parliamentary support; embed the project in EU-level strategic programs (e.g., Horizon Europe, EU Chips Act); create a contingency plan for downscaling; establish a resilient governance structure that can withstand political shifts.

## Risk summary
The overall risk landscape is dominated by a few interconnected high-impact threats: (1) financial instability due to funding phasing and long-term political commitment, (2) technical infeasibility of reaching 95% component coverage and miniaturization, and (3) integration failures across federated sites. These three risks are mutually reinforcing—technical delays could erode political support, and integration failures could trigger funding gates not being met. The most critical risk is technical, as the entire value proposition rests on achieving revolutionary manufacturing capabilities within a 20-year horizon; if that fails, the EUR 200 billion investment yields little. Mitigation strategies should prioritize parallel development to retire technical risk early, secure binding financial commitments to ride out technical setbacks, and enforce integration discipline through a central integrator. Secondary risks such as regulatory, security, and operational attrition must be managed but are more controllable. The project's unprecedented scale demands a proactive, adaptive risk management culture with continuous monitoring and contingency planning.

# Make Assumptions


## Question 1 - How should the EUR 200 billion be structured across public and private sources over 20 years, including annual drawdown, contingency reserves, funding gates, and management of EUR/CHF exchange-rate exposure across the Swiss and eurozone sites?

**Assumptions:** Assumption: The programme will be established as a public-private risk-sharing consortium with a 70% public / 30% private capital split, an average annual drawdown of EUR 10 billion, a 10% contingency reserve of EUR 20 billion, and a separate CHF 3 billion operational allocation for the Geneva-area site with quarterly hedging. This is consistent with large infrastructure megaprojects, which typically hold 10–20% contingency and use phased capital calls to maintain investor confidence.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluates the EUR 200 billion funding structure, cash-flow stability, and currency risk across the 20-year horizon.
Details: With an average annual drawdown of EUR 10 billion, the consortium must secure binding public commitments and mobilise EUR 60 billion of private capital through licensing-backed co-investment. A 10% contingency reserve protects against cost overruns, but milestones should be linked to technical gates without creating stop-go funding risk. The CHF 3 billion allocation covers Swiss payroll and services, but EUR/CHF volatility over 20 years could add EUR 0.5–1.5 billion in FX costs if unhedged. Recommend a central treasury function, quarterly hedging, multi-year commitment clauses, and diversified funding sources to avoid the EUR 10–20 billion cash-flow shortfalls identified in risk analysis.

## Question 2 - What is the validated 20-year master schedule from the September 2026 start, including site acquisition, construction, prototype development, integration gates, 95% component coverage, and final space-readiness demonstration, with buffer time for delays?

**Assumptions:** Assumption: The programme will run from Q4 2026 to Q4 2046 in five phases: 2026–2028 site acquisition and design; 2029–2032 macro-scale and miniaturised prototypes; 2033–2037 modular production line and first integrated demonstration; 2038–2042 95% coverage qualification; 2043–2046 space-readiness validation. A 12-month buffer is embedded before each major gate, reflecting typical 15–25% schedule slippage in 20-year industrial megaprojects.

**Assessments:** Title: Timeline and Milestone Assessment
Description: Assesses the feasibilty of the 20-year phasing and identifies critical decision gates.
Details: Key gate exit criteria include site permits by 2027, working macro and bench prototypes by 2032, a merged miniaturised line by 2035, first integrated multi-module factory by 2037, and auditable 95% coverage by 2042. Technical delays in electronics and miniaturisation could extend critical milestones by 3–5 years; therefore, parallel two-track development, early risk retirement for FPGAs, and iterative interface reviews are necessary. Annual board-level schedule reviews with slippage tolerance should be set at 10–15% per phase, with trigger points for descoping non-critical module classes if needed.

## Question 3 - What staffing model and physical resource allocation are required across the CERN, ASML, and Zeiss/Fraunhofer sites, covering peak headcount, critical-skill redundancy, laboratory space, cleanrooms, and utility capacity, to sustain a 20-year R&D and manufacturing programme?

**Assumptions:** Assumption: The programme will require approximately 18,000 direct employees at peak, including 7,000 engineers and scientists, 6,000 technicians, 3,000 operations and logistics staff, and 2,000 governance and administration staff. Physically, it will need around 300 hectares of serviced industrial land, 150,000 m2 of clean and controlled manufacturing floor, and 50 MW of dedicated clean-energy capacity. This aligns with comparable high-tech industrial ecosystems and assumes two trained practitioners for every critical skil through rotation and geographic redundancy.

**Assessments:** Title: Workforce and Physical Resource Assessment
Description: Evaluates talent sourcing, capital infrastructure, and knowledge sustainabilty.
Details: Competing with ASML, CERN, Zeiss, and Fraunhofer for top engineers will require competitive compensation, long-term incentives, and a clear career pathway; a dedicated recruitment pipeline from partner institutions should be established in 2026–2027. Attrition is a major risk over 20 years; implement structured mentorship, rotation, exhaustive digital-twin documentation, and duplicate senior specialists at two geographic sites. Physical capacity must be planned up front, as cleanrooms and powder-handling zones are extremely costly to retrofit. Site selection should prioritise grid connection, water, transport, and zoning certainty to avoid 6–24-month construction delays.

## Question 4 - What legal and governance structure will coordinate the public-private consortium, prime integrator, and sovereign partners across Switzerand, France, the Netherlands, and Germany, and how will export controls, tech-transfer licenses, and construction permits be harmonised to avoid multi-jurisdiction gridlock?

**Assumptions:** Assumption: The programme will be established as a single European Special Purpose Vehicle (SPV) governed by an intergovernmental agreement among the four host countries, with the prime integrator holding one consolidated integration budget. Export-control workstreams will be front-loaded in 2026–2027, and a joint regulatory task force will manage a common permitting calendar, mirroring best practice from CERN and ITER cross-border projects.

**Assessments:** Title: Governance and Regulatory Compliance Assessment
Description: Analyzes multi-country legal structure, permitting, and trade-control risks.
Details: Without coordination, permitting differences can delay sites 6–24 months and add EUR 100–500 million in legal and compliance costs. An intergovernmental SPV provides political resilience across election cycles and binds member states to multi-year contributions. Export controls on semiconductor lithography and space-related manufacturing technology require early classification, end-use assurance, and transfer licenses; a joint compliance office with representatives from each host country is essential. IP ownership and dispute resolution must be defined in the consortium agreement up front, with internal arbitration clauses, to prevent litigation that coud stall progress for 2–5 years.

## Question 5 - What integrated safety and risk-management framework will govern physical construction and operation of high-temperature, powder-based, chemical, and cleanroom processes across distributed sites, and how will the programme monitor and respond to technical, financial, integration, and security risks over the full 20-year horizon?

**Assumptions:** Assumption: The programme will adopt ISO 45001 occupational health and safety, ATEX-compliant explosion protection for powder handling, and a single enterprise risk register with quarterly board review. A central safety authority will conduct annual audits and incident investigations, consistent with EU industrial-safety directives and large-scale research-infrastructure practice.

**Assessments:** Title: Integrated Safety and Risk Management Assessment
Description: Evaluates physical HSE hazards and enterprise-level risk controls.
Details: Powder-based additive and subtractive processes create explosion, toxic-fume, and thermal hazards; negative-pressure dirty zones, airlocked transport, and pressure-differentiated clean bays must meet ATEX and ISO 14644 standards. The highest-impact risks are technical infeasibility, funding shortfalls, and integration failure; these should be tracked using leading indicators such as component-coverage percentage, gate slippage, interface compliance, and cash-burn rate. Retain 5–10% of budget as contingency and stage investment releases to preserve accountability. Cyber security is also a safety and financial risk; deploy zero-trust architecture, network segmentation, regular penetration testing, and an incident-response team to protect IP valued at EUR 50–100 billion.

## Question 6 - How will the modular factory system minimise environmental footprint—including energy and water demand, waste heat, chemical by-products, and land use—while meeting EU sustainability regulations and local community expectations at all three sites?

**Assumptions:** Assumption: The programme will commit to 100% renewable electricity by 2035, 80% waste-heat recovery for building conditioning and feedstock preheating, closed-loop water recycling with at least 90% recovery, and net-zero operational carbon by 2040. These targets align with the EU Green Deal and are achievable through the thermal-envelope separation and heat-recovery decisions already recommended.

**Assessments:** Title: Environmental Sustainability Assessment
Description: Assesses energy, water, waste, emissions, and regulatory alignment.
Details: Energy demand for additive/subtractive manufacturing and cleanrooms will dominate operational costs; waste-heat recovery can reduce both carbon and operating expense. Closed-loop water recycling cuts freshwater intake and wastewater permitting risk. Early environmental impact assessments for each site will be necessary for permits and can prevent 1–2 year delays from public opposition. Non-compliance could trigger penalties of EUR 0.5–2 billion, while proactive sustainability design can strengthen public trust and attract green investors. Publich annual ESG metrics, including energy intensity per manufactured component, water recovery rate, and waste-to-landfill percentage.

## Question 7 - How will the programme engage member-state governments, local communities, research institutions, private investors, and civil-society stakeholders to secure long-term political support and social license across Switzerland, France, the Netherlands, and Germany?

**Assumptions:** Assumption: The programme will allocate EUR 2 billion, approximately 1% of the total budget, for community benefits, local infrastructure, education, and transparent communication over 20 years. Stakeholder advisory boards will be established at each site with quarterly public reporting, following large-infrastructure precedent such as ITER and HS2 where proactive engagement reduces delay risk.

**Assessments:** Title: Stakeholder Engagement and Social License Assessment
Description: Evaluates political, community, and partnership communication strategies.
Details: Multi-party support across EU member states and Switzerland is critical to survive election cycles; embed the project in EU strategic frameworks such as Horizon Europe, the EU Chips Act, and Important Projests of Common European Interest. Local community opposition can cause 1–3 years of legal battles; proactive engagement, noise insulation, traffic planning, and local employment commitments will reduce risk. Private investors need transparent milestones and clear IP/licensing terms. A single communications office should publish multilingual updates, host annual demonstration days, and maintain a visible record of technical progress to counter scepticism and keep political sponsors aligned.

## Question 8 - What operational architecture—including digital twin coordination, manufacturing execution systems, inter-module interfaces, data standards, and cybersecurity—will enable the federated sites near CERN, ASML, and Fraunhofer to operate as one integrated factory?

**Assumptions:** Assumption: The programme will implement a federated digital-twin platform with a common data model, a prime-integrator-owned integration layer, and a standardised MES/ERP stack across all sites. Inter-module mechanical, power, fluid, and data interfaces will be managed through a controlled interface register, and zero-trust cybersecurity will be deployed from construction, consistent with IEC 62443 industrial security standards.

**Assessments:** Title: Operational and Digital Integration Assessment
Description: Evaluates control systems, data interoperability, and cyber-resilience.
Details: A federation-wide digital twin is essential to coordinate production schedules, knowledge transfer, and adaptive feedstock compensation across distributed sites; without common data standards, integration could extend by 2–3 years and cost EUR 5–15 billion. Interface specifications should be defined early but reviewed iteratively to avoid premature freeze, while the prime integrator runs joint integration tests at each milestone. In-situ metrology and measurement-gate data should feed adaptive process control to handle feedstock purity variation. Cyber security must be designed from day one: network segmentation, zero-trust access, encrypted data exchange, and continuous monitoring will protect against industrial espionage and operational shutdown.

# Distill Assumptions

- EUR 200 billion programme uses a 70% public / 30% private risk-sharing consortium.
- Average annual drawdown is EUR 10 billion with EUR 20 billion contingency reserve.
- A separate CHF 3 billion Geneva-site allocation will be quarterly hedged.
- Programme runs Q4 2026 to Q4 2046 in five phases with 12-month buffers before gates.
- Phasing: site/design 2026-2028, prototypes 2029-2032, modular line and integrated demo 2033-2037.
- 95% coverage qualification 2038-2042; space-readiness validation 2043-2046.
- Peak staffing is 18,000: 7,000 engineers, 6,000 technicians, 3,000 ops/logistics.
- 2,000 governance/admin staff; plus 300 hectares, 150,000 m2, 50 MW.
- Every critical skill will have two trained practitioners via rotation and geographic redundancy.
- A single European SPV will be governed by an intergovernmental agreement among Switzerland, France, Netherlands, Germany.
- Prime integrator will hold one consolidated integration budget.
- Export-control workstreams front-loaded 2026-2027; joint regulatery task force manages common permitting calendar.
- Programme adopts ISO 45001 and ATEX explosion protection for powder handling.
- A single enterprise risk register will undergo quarterly board review.
- A central safety authority will conduct annual audits and incident investigations.
- Commit to 100% renewable electricity by 2035 and net-zero operational carbon by 2040.
- Reuse 80% waste heat for building conditioning and feedstock preheating; recycle at least 90% water.
- EUR 2 billion (1% of budget) is allocated for community benefits and transparent communication.
- Stakeholder advisory boards at each site will report publicly quarterly.
- Implement a federated digital-twin platform with common data model.
- Use a standardised MES/ERP stack and an integration layer owned by the prime integrator.
- Inter-module interfaces managed through a controlled interface register; zero-trust cybersecurity from construction per IEC 62443.

# Review Assumptions

## Domain of the expert reviewer
Long-horizon industrial R&D programme finance, technology readiness, and multi-jurisdiction governance

## Domain-specific considerations

- Real vs nominal cost baseline and inflation indexing over 20 years
- Technology readiness and yield learning-curve assumptions
- Mobilisation of private capital and licensing revenue models
- Export controls and technology transfer across EU/Swiss borders
- Energy, water, and raw-material price volatility
- Political, workforce, and knowledge continuity over two decades

## Issue 1 - Missing real/nominal EUR baseline and currency hedging reference
The EUR 200 billion figure is stated without specifying whether it is in real (2026) or nominal (2046) euros. Over 20 years, inflation will dramatically erode a fixed nominal budget. The CHF 3 billion allocation also assumes an unspecified EUR/CHF baseline and hedging cost. Without an indexation or currency strategy, the programme will face a hidden scope cut or require unplanned top-ups.

**Recommendation:** Establish the cost baseline in 2026 real EUR with annual indexation clauses for labour, energy, and materials. Use net-present-value accounting in all board reporting. Set a formal EUR/CHF hedging band (e.g., 1.05–1.10) with a dedicated reserve for tail moves, and review the hedge ratio quarterly. Quantify the programme's contingency in real terms and re-baseline every 5 years.

**Sensitivity:** With a fixed nominal €200B budget and 2% average inflation, real purchasing power falls to ~€135B (a €65B loss); at 3% inflation, the loss grows to ~€90B. This would force a 25–40% scope reduction, or require a €65–90B top-up to maintain the baseline plan.

## Issue 2 - Unstated technology readiness and yield ramp assumptions
The 95% component coverage target rests on implicit assumptions about starting technology readiness levels, initial process yields, defect rates, and learning-curve slopes. Complex electronics (FPGAs, sensors, lithography) are likely to start at very low yields, and the plan does not specify the yield improvement curve needed to qualify 95% coverage by 2042. A yield plateau at even 80% would invalidate the core value proposition.

**Recommendation:** Before major construction, develop a component-makeability map that assigns each component class a baseline TRL, expected first-pass yield, and process capability index (Cpk). Set gate criteria based on demonstrated yield and statistical confidence, not just calendar dates. Fund parallel macro-scale and miniaturized prototypes to retire electronics risk early. Create a public yield dashboard and use an external technical advisory board to validate learning-curve models annually.

**Sensitivity:** Baseline: 95% coverage qualified by 2042. A 3-year delay in electronics yield ramp would add ~€30B (15% cost increase), push space-readiness from 2046 to 2049, and delay the start of value capture by 3 years. If yields plateau at 80%, the 95% claim fails, requiring €10–20B of rework or a fundamental descope.

## Issue 3 - Private capital mobilisation and licensing revenue assumptions are undefined
The 70% public / 30% private split assumes €60B of private investment, but there is no stated revenue model, expected return, or exit mechanism. Private investors will not commit to a 20-year, high-risk programme without a credible plan for licensing revenues, royalties, or equity appreciation. The plan also under-specifies IP-sharing arrangements that would underpin any private co-investment.

**Recommendation:** Build a 20-year revenue model with scenarios for module licensing, component sales, and space-contract royalties. Structure a separate commercial subsidiary to hold non-core IP and monetise it through licensing. Use EIB/EBRD co-financing and public guarantees to lower the cost of capital. Negotiate a minimum IRR threshold (e.g., 8–10%) with investors and link capital calls to technical gate achievements while retaining downside protection for the public side.

**Sensitivity:** Baseline: €60B private capital (30%). If private share falls to 10% (€20B), the €40B gap would need public funding, extending capital calls by 4–6 years or forcing a 15–25% scope reduction. If licensing revenues underperform (baseline zero), private investors would require €150–200B gross revenue to achieve an 8–12% IRR, otherwise the consortium's overall ROI turns negative.

## Review conclusion
The programme's success depends on three missing but critical assumptions: a real-vs-nominal financial baseline, technology yield/readiness trajectories, and private capital/revenue credibility. Fixing these gaps early—through indexation, yield-gated milestones, and a transparent licensing model—will materially improve the chance of delivering the 95% coverage and space-readiness promise. Export-control harmonisation and energy-price volatility, while important, are more manageable and should be addressed as part of the next-tier governance and contingency planning.