# Documents to Create

## Create Document 1: Project Charter

**ID**: a0282e4e-b02e-4879-861f-2461bcf1b6da

**Description**: High-level project charter defining the 20-year EUR 200 billion programme vision, mission, objectives, scope, budget envelope, timeline, key stakeholders, governance principles, and top-level success criteria.

**Responsible Role Type**: Programme Director & Prime Integrator

**Primary Template**: PMI Project Charter Template

**Secondary Template**: ISO 21500 Guidance on Project Management

**Steps to Create**:

- Draft with Programme Director and central integration office
- Consult cross-border legal lead on SPV governance constraints
- Review with site leads and partner institution representatives
- Present to SPV Board for approval

**Approval Authorities**: Intergovernmental SPV Board and Programme Executive Board

**Essential Information**:

- Articulate the programme vision and mission exactly as defined: establish by Q4 2046 an Earth-based modular miniaturized factory near CERN, ASML, Zeiss, and Fraunhofer that can manufacture over 95% of necessary components from basic industrial feedstock, as a precursor to Space-Based Universal Manufacturing.
- Quantify the SMART top-level success criteria: auditable certification that ≥95% of the defined component catalogue is manufactured in-factory, yields meet technical gate thresholds, first integrated multi-module demonstration completed, and final space-readiness validation passed by Q4 2046.
- Specify the financial envelope and structure: EUR 200 billion in 2026 real euros, 70% public / 30% private risk-sharing consortium, EUR 20 billion contingency reserve, CHF 3 billion Geneva-site allocation, ~EUR 10 billion average annual drawdown, annual inflation indexing, and quarterly EUR/CHF hedging.
- Define the high-level scope and explicit exclusions: component catalogue covering complex electronics, FPGAs, sensors, propulsion units, robotic actuators, and energy systems; external dependencies restricted to commodity reagents/basic feedstock per the selected Builder's Balanced Path.
- Codify the selected strategic path and critical decisions: two-track miniaturization, public-private consortium funding, prime integrator with proprietary integration layer, makeability-map-driven coverage sequencing, and external inputs limited to simplest commodities.
- Lay out the phased 20-year timeline with gate milestones and buffers: 2026–2028 site acquisition/design, 2029–2032 parallel prototypes, 2033–2037 modular line and first integrated demo, 2038–2042 95% coverage qualification, 2043–2046 space-readiness validation.
- Identify the full stakeholder universe and governance structure: Intergovernmental SPV among Switzerland/France/Netherlands/Germany, Programme Executive Board, prime integrator, consortium partners, module development teams, host governments, EU institutions, regulators, local communities, investors, and space agencies.
- Establish governance principles and decision rights: single European SPV, prime integrator with consolidated integration budget, controlled interface register, milestone-based funding releases, IP ownership and dispute resolution mechanisms, and joint compliance office.
- Reference mandatory regulatory/compliance commitments: export-control filings with BAFA/CDIU/SECO by October 2026, ATEX 2014/34/EU, ISO 14644 cleanrooms, ISO 45001, IEC 62443, EU Green Deal targets, and alignment with Horizon Europe/EU Chips Act/IPCEI.
- State the key dependencies required for execution: site option agreements by Q4 2026, SPV formation, interface register v1.0, makeability map of ≥5,000 part numbers, export-control approvals, frozen spatial safety rules, and parallel prototype funding.

**Risks of Poor Quality**:

- Vague or ambiguous scope and success criteria allow partner institutions to pursue conflicting miniaturization, coverage, and integration strategies, causing major rework and missed integration gates.
- Failure to specify the 2026 real-euro baseline and inflation indexing erodes the EUR 200 billion budget, forcing hidden 25–40% scope reductions or unplanned top-ups.
- Omitting the selected strategic path and five critical decisions leads to governance deadlock and inconsistent module development across CERN, ASML, and Zeiss/Fraunhofer sites.
- Unclear governance roles and decision rights prevent the SPV and prime integrator from resolving interface, IP, and funding disputes, delaying the programme for years.
- Missing stakeholder and political engagement commitments weaken multi-country support, increasing the likelihood of funding cuts, export-control gridlock, and permitting delays of 6–24 months.
- If top-level success criteria do not define yield thresholds, auditable coverage evidence, and gate exit criteria, funding releases become subjective and private investors refuse to commit EUR 60 billion.
- Failure to reference mandatory compliance requirements (ATEX, ISO 14644, IEC 62443, export controls) leads to construction redesigns, regulatory penalties, and potential shutdowns.
- An incomplete timeline or buffer strategy makes the programme vulnerable to 3–5-year electronics/miniaturization delays that push space-readiness past 2046 and damage credibility.

**Worst Case Scenario**: The Project Charter is approved with vague objectives, an unindexed nominal budget, unspecified governance authority, and no codified strategic path; partner sites begin parallel development under conflicting technical assumptions, the 95% coverage claim is not credibly measurable, private investors withhold the EUR 60 billion private share, technical milestones slip by 3–5 years, political support collapses across the four host countries, and the EUR 200 billion programme is cancelled or descoped to a small demonstration project before the first integrated manufacturing demo is ever built.

**Best Case Scenario**: A crisp, board-approved Project Charter codifies the Builder's Balanced Path, locks the EUR 200 billion real-euro financial envelope with indexation and hedging, defines auditable 95% coverage and yield-gated success criteria, assigns clear governance through the SPV and prime integrator, and secures multi-country political and financial commitment; it enables immediate go/no-go decisions at each phase gate, accelerates private capital mobilization, aligns all partner institutions on interfaces and sequencing, and positions the programme for credible delivery of the first integrated factory by 2037 and space-readiness by 2046.

**Fallback Alternative Approaches**:

- Use the PMI Project Charter Template and ISO 21500 guidance as a structured skeleton, populating it directly from the existing project-plan.md, assumptions.md, scenarios.md, and strategic_decisions.md rather than drafting from scratch.
- Convene a facilitated 2–3 day charter workshop with the Programme Director, prime integrator, SPV legal counsel, and site leads to resolve scope, governance, and success-criteria disagreements collaboratively.
- Delegate drafting to a small central integration office supported by finance, legal, and technical experts, then circulate the draft for targeted review to avoid prolonged committee negotiation.
- Produce a minimum viable 2–3 page 'Charter-in-Brief' covering only vision, scope, budget, timeline, governance, and top-level success criteria; expand with detailed annexes after board approval.
- Adopt the Builder's Balanced Path from scenarios.md as the decision baseline and reference strategic_decisions.md for the five critical levers, avoiding re-deliberation of already-analysed choices.
- Engage an external financial and technical expert reviewer to validate the real/nominal budget baseline, yield ramp assumptions, and private capital revenue model before final board submission.

## Create Document 2: Baseline Assessment of Universal Manufacturing Capability and Legal Feasibility

**ID**: 4687a518-12ef-458a-ada4-904f8ed4301d

**Description**: Cormprehensive current-state assessment covering the component catalogue with baseline technology readiness levels, first-pass yield estimates, feedstock purity variability, export-control licensability, site readiness, and funding gaps. Includes the initial component makeability map and legal makeability map used to define the auditable 95% component-coverage denominator.

**Responsible Role Type**: Advanced Manufacturing, Materials & Process Engineering Lead

**Primary Template**: NASA Technology Readiness Level Assessment Template

**Secondary Template**: World Bank Project Readiness Assessment

**Steps to Create**:

- Collect and synthesize raw source data from site surveys, regulatory texts, and statistical sources
- Commission expert interviews with technology and legal advisors
- Build component catalogue of at least 5,000 part numbers with TRL, yield, and process modification data
- Integrate export-control licensability classifications into the baseline dataset
- Validate with Programme Director, CTO, and external Technical Advisory Board

**Approval Authorities**: Programme Director, CTO, Intergovernmental SPV Board

**Essential Information**:

- Enumerate a component catalogue of at least 5,000 part numbers across structural, mechanical, sensor, electronics, propulsion, and energy families, classified by material family, coverage gap, and integration criticality.
- Quantify baseline Technology Readiness Level (TRL) for each component and process chain, explicitly identifying electronics/FPGA, miniaturization, and high-precision processes with TRL below 4 and estimated time/cost to maturity.
- Provide first-pass yield estimates and process capability (Cpk) per manufacturing process chain, including statistical basis and confidence intervals, enabling yield-learning-curve projections to 95% coverage by 2042.
- Detail feedstock purity and composition variability data: acceptable tolerance ranges, source variability distributions, correlation with process failure rates, and implications for conditioning and adaptive control investment.
- Map export-control licensability for each critical technology (lithography, space-rated propulsion, precision robotics, advanced materials) under BAFA, CDIU, and SECO, identifying any absolute legal barriers to in-factory manufacture or cross-border transfer.
- Assess site readiness for all three anchor clusters (Geneva/CERN, Veldhoven/ASML, Oberkochen/Zeiss-Fraunhofer): land availability, utility capacity, zoning status, environmental constraints, geotechnical conditions, and realistic permitting lead times.
- Define the auditable 95% component-coverage denominator precisely: exact component scope, counting rules for residual external inputs, handling of commodity reagents, and treatment of rotating exception lists or elimination roadmaps.
- Quantify current committed vs required funding: real (2026) vs nominal EUR baseline, private capital mobilization status, projected funding gaps, adequacy of the EUR 20bn contingency reserve, and EUR/CHF exposure assumptions with hedging strategy.
- Produce an initial legal makeability map identifying IP ownership, licensing, and regulatory constraints per component class, including which components may be legally impossible or prohibitively restricted to manufacture in-factory.
- Validate all baseline data with the Programme Director, CTO, and external Technical Advisory Board, documenting assumptions, data sources, uncertainty ranges, and revision triggers.

**Risks of Poor Quality**:

- An inaccurate or incomplete component catalogue corrupts the 95% coverage denominator, making the central auditable claim indefensible and inviting regulatory, investor, and public rejection.
- Overly optimistic baseline TRL and yield estimates lead to unrealistic coverage sequencing and funding-gate expectations, causing milestone failures, capital-release terminations, and loss of partner confidence.
- Missing export-control licensing constraints results in multi-jurisdiction legal gridlock, 2–5 year delays, and cross-border integration failure at the federated sites.
- Underestimating feedstock purity variability leads to process designs that cannot maintain yields under real-world conditions, causing production downtime, scrap, and billions in retrofitting costs.
- Site readiness gaps overlooked force emergency site changes or expensive remediation, delaying construction and driving costs beyond the EUR 200bn envelope.
- A poorly defined legal makeability map leaves the programme exposed to undiscovered IP or regulatory restrictions, undermining the in-factory universality claim and triggering litigation.
- Misstated funding gaps and real-vs-nominal erosion cause cash-flow shortfalls, withdrawal of private investors, and 1–3 year project pauses or restructuring.

**Worst Case Scenario**: The baseline assessment is accepted with materially flawed data—overstated TRL/yield estimates, missed export-control showstoppers, and a misdefined 95% coverage denominator. The programme reaches its first major funding and integration gates only to fail auditable 95% coverage validation, losing intergovernmental and private-investor confidence; the EUR 200bn initiative is forced into a massive descope or outright cancellation, delivering no space-precursor manufacturing capability and writing off tens of billions in sunk investment.

**Best Case Scenario**: A rigorous, independently validated baseline assessment establishes a credible, audit-ready foundation for the entire programme. It precisely defines the 95% coverage denominator and produces the initial component and legal makeability maps, enabling data-driven coverage sequencing, funding tranche gates, site acquisition, and export-control planning. This secures investor and intergovernmental confidence, accelerates early risk retirement, and positions the programme to meet its 2042 coverage qualification and 2046 space-readiness milestones on schedule.

**Fallback Alternative Approaches**:

- Develop a 'minimum viable makeability map' covering only the highest-risk component classes (complex electronics, FPGAs, propulsion, precision robotics) using expert estimates, then expand iteratively as early prototyping data matures.
- Leverage existing TRL and process data from partner institutions (CERN, ASML, Zeiss, Fraunhofer) and benchmark against comparable large-scale industrial R&D programmes (ITER, semiconductor fabs) instead of commissioning exhaustive new empirical studies.
- Run structured expert elicitation workshops (e.g., Delphi method) with technical and legal advisors to generate baseline TRL, yield, and licensability estimates quickly and transparently, documenting uncertainty ranges rather than false precision.
- Split the assessment into two parallel tracks: a fast-track legal, export-control, and site-feasibility check to clear go/no-go gates, and a longer-term full-component catalogue and yield baseline that evolves with the project's makeability map.
- Use the external Technical Advisory Board and independent third-party auditors to stress-test preliminary data and identify the most critical assumptions before finalization, accepting that precision improves over time.
- Phase the baseline work: first lock down the coverage denominator and legal feasibility for the highest-value 95% goal, then commit major funding only after legal, site, and export-control constraints are confirmed.

## Create Document 3: High-Level Budget and Treasury Framework

**ID**: 3dc7ef8f-a30c-412b-9379-795f21839534

**Description**: Financial framework expressing the EUR 200 billion budget in 2026 real euros with annval indexation, 70% public / 30% private funding structure, annual drawdown profiles, EUR20 billion contingency reserve, and EUR/CHF hedging approach for the Geneva site.

**Responsible Role Type**: Strategic Funding & Treasury Lead

**Primary Template**: World Bank Infrastructure Finance Toolkit

**Secondary Template**: European Investment Bank PPP Financing Framework

**Steps to Create**:

- Collect official inflation and currency historical data
- Model real versus nominal budget scenarios using found statistical datasets
- Define capital-call schedule aligned with technical gates
- Set treasury hedging policy and contingency release rules
- Obtain approval from SPV Board and Programme CFO

**Approval Authorities**: SPV Board, Programme CFO, member-state finance representatives

**Essential Information**:

- Specify the EUR 200 billion budget in 2026 real euros with an explicit indexation mechanism (e.g., annual adjustment for labour, energy, materials) and quantify sensitivity: at 2% inflation, purchasing power drops to ~€135B; at 3%, to ~€110B if left nominal.
- Detail the 70% public / 30% private funding structure: €140B public commitments and €60B private co-investment, including the revenue/licensing model, minimum IRR thresholds (8–10%), and consequences if private share falls to €20B.
- Produce a phased annual drawdown profile aligned to the programme schedule (2026–2028 site/design; 2029–2032 prototypes; 2033–2037 integrated demo; 2038–2042 95% coverage; 2043–2046 space-readiness), with capital calls tied to technical gates.
- Define the EUR 20 billion contingency reserve (10%) governance: release criteria, approval authority, 5-year re-baselining, and rules for replenishment.
- Set the treasury/hedging policy for the CHF 3 billion Geneva allocation: quarterly hedging with rolling 24-month tenors, a defined EUR/CHF band (e.g., 1.05–1.10), a dedicated tail-risk reserve, and accounting treatment in EUR.
- Include scenario/sensitivity analysis: inflation, private capital shortfall, currency tail moves, and schedule slippage, with trigger points for descoping or re-negotiation.
- Describe the approval and reporting cadence: SPV Board, Programme CFO, and member-state finance representatives review quarterly; use net-present-value accounting and real-EUR board reporting.
- List necessary inputs and sources: Eurostat/ECB/SNB inflation and FX historical data, World Bank Infrastructure Finance Toolkit, EIB PPP Financing Framework, assumptions.md financial assumptions, project-plan.md milestones and risk register.

**Risks of Poor Quality**:

- Without a real-vs-nominal baseline, the EUR 200 billion budget is overstated: 2% inflation over 20 years erodes ~€65B of purchasing power, forcing 25–40% hidden scope cuts or unplanned top-ups.
- A vague capital-call schedule not tied to technical gates can cause €10–20B cash-flow shortfalls, 1–3 year project pauses, loss of key staff, and restart costs up to 30% of affected budget.
- Unsupported private capital assumptions (€60B) undermine investor confidence; if private share drops to 10%, a €40B public gap extends capital calls by 4–6 years or forces 15–25% scope reduction.
- Poor EUR/CHF hedging strategy exposes the Geneva site to unhedged volatility, adding €0.5–1.5B in avoidable costs and creating budget uncertainty for Swiss operations.
- Unclear contingency release rules lead either to premature depletion of reserves or an inability to respond to risks, eroding SPV Board and member-state trust.
- Failure to secure approval from SPV Board, Programme CFO, and member-state finance representatives means funding tranches are not legally committed, halting procurement and construction.

**Worst Case Scenario**: The financial framework is based on a non-indexed nominal budget, private capital fails to materialize, currency exposure is unhedged, and capital calls are not aligned with technical milestones; this triggers €10–20B cash-flow shortfalls, a multi-year programme pause, loss of critical specialists, and ultimately a forced restructuring or cancellation of the EUR 200 billion programme before the 95% coverage target is reached.

**Best Case Scenario**: The High-Level Budget and Treasury Framework gives the SPV Board, member states, and private investors a credible, indexed financial structure; capital calls align with technical gates, contingency and hedging protect against inflation and currency shocks, and the 70/30 public-private consortium is fully committed—enabling go/no-go decisions on each phase, supplier contracting, talent retention, and delivery of auditable 95% component coverage by 2042 and space-readiness by 2046.

**Fallback Alternative Approaches**:

- Adapt a pre-approved World Bank or EIB PPP financing template to the programme instead of building a bespoke model from scratch.
- Run a focused 2-day workshop with the SPV Board, Programme CFO, and member-state finance representatives to agree on core parameters (real baseline, contingency, hedging band) and document decisions directly.
- Produce a 'minimum viable financial framework' covering only the real/nominal budget baseline, capital-call schedule, and contingency release rules; defer detailed hedging policy to a treasury workstream.
- Engage an external financial advisor (e.g., EIB, World Bank, major infrastructure bank) to build and validate the model on a shorter timeline.
- Start with a phase-by-phase budget for the first 10 years (2026–2036) with an indexation formula, and extend to 2046 once early technical gates and private commitments are proven.

## Create Document 4: Intergovernmental SPV and Consortium Governance Framework

**ID**: ae882efe-0a37-4b00-8857-884b7fed529c

**Description**: High-level legal and governance structure for a single European special-purpose vehicle among Switzerland, France, Netherlands, and Germany; includes decision rights, IP ownership, arbitration, contributed technology schedules, and an export-control chapter.

**Responsible Role Type**: Cross-Border Legal, Regulatory & Export Control Lead

**Primary Template**: ITER Joint Implementation Agreement Structure

**Secondary Template**: CERN Convention Governance Patterns

**Steps to Create**:

- Draft governance and decision-rightss sections with site counsel
- Incorporate export-control and technology-transfer obligations
- Run feasibility check on CERN, ASML, Zeiss, and Fraunhofer participation
- Consult member-state negotiating teams
- Obtain intergovernmental endorsement

**Approval Authorities**: Member-state governments and legal counsel

**Essential Information**:

- Define the SPV's legal form, seat, and governance bodies (e.g., council, executive board, director-general) with explicit voting rights and decision rights for Switzerland, France, Netherlands, Germany, and the public-private consortium.
- Specify the intergovernmental agreement scope: binding funding commitments, capital call schedule, contingency release rules, amendment procedure, exit/withdrawal terms, and duration/successor clauses for the 20-year horizon.
- Establish IP ownership and licensing terms for background and foreground IP, including a contributed technology schedule listing CERN, ASML, Zeiss, Fraunhofer, and private partner assets and their permitted uses.
- Detail the public-private consortium structure: 70/30 funding split, EUR 60bn private capital mobilisation, licensing revenue model, investor voting rights, minimum IRR thresholds, and technical-gate-linked capital calls.
- Include an export-control and technology-transfer chapter covering BAFa, CDIu, SECo classifications, dual-use licensing, cross-border movement of equipment/data, and quarantine procedures for controlled items.
- Define arbitration and dispute-resolution mechanisms (e.g., international arbitration, joint interface arbitration board) to avoid 2-5 year litigation that could delay partner contributions.
- Outline the prime integrator's mandate, consolidated integration budget authority, and its power over module developers at CERN, ASML, and Zeiss/Fraunhofer sites.
- Set a timeline and process for intergovernmental endorsement, member-state negotiating teams, and consultation with the joint regulatory task force to harmonise permitting calendars.
- Include governance continuity provisions: knowledge transfer, key-person retention, and secondment arrangements across partner institutions.
- Define compliance and oversight mechanisms: quarterly board reviews, single enterprise risk register, audit rights, annual reporting to member-state governments, and a joint compliance office.

**Risks of Poor Quality**:

- Ambiguous decision rights and IP ownership trigger inter-partner disputes, leading to withdrawal of a critical partner (e.g., ASML or Zeiss) and loss of access to lithography and optics technologies.
- Missing/unclear export-control and technology-transfer obligations cause BAFa/CDIu/SECo approvals to stall, delaying cross-border equipment movement and construction by 6-24 months and adding EUR 100-500m compliance costs.
- Without defined arbitration/exit mechanisms, partner withdrawal or litigation delays the schedule 2-5 years and costs EUR 1-3bn, as identified in assumptions.
- Weak private investor rights and undefined licensing revenue model reduce private capital from 30% to 10%, creating a EUR 40bn funding gap that extends capital calls or forces scope reduction.
- Failure to harmonise permitting and regulatory calendars across four jurisdictions creates gridlock and misaligned phasing across federated sites, delaying technical milestones.
- An incomplete contributed technology schedule leaves background IP unlicensed, preventing module teams from using essential CERN/ASML/Zeiss know-how and stalling parallel development.

**Worst Case Scenario**: The framework fails to obtain intergovernmental endorsement or leaves IP/export-control unresolved, prompting one sovereign partner to withdraw and triggering cross-border litigation; the programme loses access to ASML lithography and Zeiss optics, private investors pull out, and the EUR 200bn initiative collapses before construction begins—with billions in sunk costs and the space-manufacturing precursor vision ending.

**Best Case Scenario**: A ratified SPV framework gives all four member states and private investors confidence to commit EUR 200bn, secures the EUR 60bn private capital, obtains export-control approvals on schedule, and establishes clear decision rights and arbitration. This enables immediate site acquisitions, launch of parallel prototype tracks, first funding releases, and a credible path to the Q4 2046 space-readiness demonstration—making the programme investable and politically resilient.

**Fallback Alternative Approaches**:

- Use an existing legal vehicle such as a European Economic Interest Grouping (EEIG) or a Swiss/Dutch joint-stock company as an interim SPV while negotiating the full intergovernmental treaty.
- Negotiate a bilateral framework agreement among the two largest contributors (e.g., France and Germany) and allow Switzerland and Netherlands to accede via protocols, avoiding four-party deadlock.
- Draft a legally binding memorandum of understanding with arbitration and IP clauses as an interim governance instrument, with the full treaty to follow within 18 months.
- Split the framework into separable workstreams: finalise IP ownership and export-control chapters first, deferring the commercial revenue model and investor rights to a later consortium agreement.
- Engage legal experts from ITER or CERN to adapt their established joint implementation agreement templates, compressing the negotiation timeline.
- Establish an interim steering committee with delegated authority to approve site acquisitions and early prototype funding while formal ratification is pending.

## Create Document 5: Export Control and Technology Transfer Compliance Framework

**ID**: 2f2f7ff5-d98b-489c-b932-238cf24d2fa9

**Description**: Compliance framework for dual-use export controls, deemed exports, technology-transfer licensing, and cross-border data movement across Swiss and EU sites; establishes the legal makeability map and route-to-license strategy before any site option, SPV signature, or partner agreement is concluded.

**Responsible Role Type**: Cross-Border Legal, Regulatory & Export Control Lead

**Primary Template**: EU Internal Compliance Programme Template

**Secondary Template**: Wassenaar Arrangement Compliance Best Practices

**Steps to Create**:

- Identify all controlled hardware, software, technical data, and personnel nationalities
- Build technology-transfer matrix mapping each item to national authorities
- Submit preliminary license applications to BAFA, CDIU, SECO, and French SBDU/DGDDI
- Design quarantine workflow for stalled controlled items
- Establish joint compliance office with host-country representatives

**Approval Authorities**: Cross-Border Legal Lead, SPV Board, BAFA/CDIU/SECO/SBDU-DGDDI as applicable

**Essential Information**:

- Inventory every controlled hardware item, software tool, technical data package, and service across the three sites, classified against the EU Dual-Use Regulation (2021/821), Wassenaar Arrangement categories, and national control lists for BAFA, CDIU, SECO, and French SBDU/DGDDI.
- Build a technology-transfer matrix mapping each controlled item to the applicable national authority, required license type, estimated lead time, end-use/end-user assurances, and site destination (CERN-adjacent, ASML-adjacent, Zeiss/Fraunhofer-adjacent).
- Define deemed-export rules covering access to controlled technology by foreign nationals and non-EU/Swiss personnel, including nationality screening, access restrictions, and visa-based control measures for all partner institutions.
- Detail the route-to-license strategy, including preliminary license applications to BAFA, CDIU, SECO, and French SBDU/DGDDI filed before the October 2026 deadline, with a schedule for follow-up submissions and a responsible owner per application.
- Specify a quarantine workflow for stalled controlled items, including secure physical/digital isolation, alternative sourcing paths, critical-path impact assessment, and monthly escalation triggers to the SPV Board.
- Define the joint compliance office's structure, host-country representatives, decision rights, and dispute-resolution process for divergent national requirements across Switzerland, France, Netherlands, and Germany.
- Include a cross-border data-movement protocol covering encrypted transfer channels, classification of technical data, logging/auditing requirements, and alignment with EU and Swiss data protection rules.
- Provide a training and implementation plan for engineering, procurement, and logistics teams so the framework is operationally enforced before site options, SPV signature, or partner agreements are concluded.

**Risks of Poor Quality**:

- Failure to identify all controlled items and personnel nationalities can result in unlicensed exports or deemed exports, triggering criminal penalties, fines, and suspension of export privileges for the SPV and partner institutions.
- An incomplete or inaccurate technology-transfer matrix allows multi-jurisdiction gridlock to delay cross-border movement of lithography, propulsion, and robotic equipment by 6–24 months, directly impacting construction and prototyping schedules.
- Missing or late preliminary license applications to BAFA, CDIU, SECO, or SBDU/DGDDI can stall the critical path for the highest-risk component classes and force costly re-sequencing of module development.
- Lack of a quarantine workflow means one stalled license or uncontrolled item can halt dependent research and manufacturing activities across multiple federated sites, multiplying delay costs.
- Unclear deemed-export rules may lead to restricted foreign-national personnel inadvertently accessing controlled technology, causing security breaches, loss of classified-status trust, and potential withdrawal of technology partners.
- A weak or poorly governed joint compliance office leaves conflicting national requirements unresolved, adding EUR 100–500 million in legal and compliance costs and eroding political and investor confidence.

**Worst Case Scenario**: An export-control violation or a failure to secure transfer licenses for semiconductor lithography, propulsion, or robotic actuation technology triggers national security sanctions, suspension of the SPV's export privileges, and withdrawal of critical partners such as ASML and Zeiss—halting the programme for 5–10 years, invalidating the EUR 200 billion investment, and making the Q4 2046 space-readiness milestone unachievable.

**Best Case Scenario**: The framework secures all necessary dual-use and technology-transfer licenses ahead of the critical path, enabling seamless cross-border movement of hardware, technical data, and personnel across the Swiss, Dutch, French, and German sites; this protects the 20-year schedule, strengthens partner and investor confidence, cements the programme's regulatory credibility, and directly enables the go/no-go decision on site options, SPV formation, and partner agreements.

**Fallback Alternative Approaches**:

- Begin with a minimum viable controlled-item register and technology-transfer matrix covering only the highest-risk items—lithography, space-rated propulsion, and precision robotics—then expand the scope iteratively as classifications are confirmed.
- Use the EU Internal Compliance Programme Template and Wassenaar best practices as a starting framework, adapting them to the programme's specific cross-border structure instead of drafting from scratch.
- Engage specialized export-control counsel or request pre-application consultations with BAFA, CDIU, SECO, and SBDU/DGDDI to clarify requirements and accelerate preliminary license decisions.
- Adopt a conservative quarantine-first policy: physically and digitally isolate any unclassified controlled item until authorities confirm its status, allowing all other workstreams to proceed without waiting for a complete final framework.
- Convene a focused legal workshop with representatives from CERN, ASML, Zeiss, and Fraunhofer to leverage each institution's existing export-control frameworks and assign ownership for each national jurisdiction.
- Appoint an interim joint compliance coordinator from one of the partner institutions to manage cross-border approvals while the formal joint compliance office is being established.

## Create Document 6: Inter-Module Interface Covenant Framework

**ID**: a974b8be-5e89-4968-b403-19289fed19e8

**Description**: Framework for governing the mechanical, power, fluid, and data interfaces among modules built at different European centres; defines the controlled interface register, compliance simulation, freeze timing, and prime-integrator integration layer.

**Responsible Role Type**: Factory Systems, Interface & Digital Integration Architect

**Primary Template**: INCOSE/NASA Interface Control Document Framework

**Secondary Template**: ITER Interface Control Approach

**Steps to Create**:

- Define initial interface database categories and tolerances
- Establish compliance simulation requirement before parallel module development
- Set freeze and iterative review rules to avoid premature lock-in
- Define prime integrator ownership and integration layer architecture
- Approve with Programme Director and Interface Arbitration Board

**Approval Authorities**: Programme Director and Interface Arbitration Board

**Essential Information**:

- Define the full scope of the interface covenant: mechanical docking, power couplings, fluid couplings, and data handshakes, with explicit tolerance ranges, connector standards, and protocol versions.
- Establish the controlled interface register as the authoritative repository, including interface IDs, owners, status (draft/compliant/frozen), baseline versions, and change-control procedures.
- Specify the mandatory compliance simulation requirement that every module developer must pass before parallel module development begins, including simulation fidelity, acceptance criteria, and data-exchange standards.
- Set freeze and iterative review rules: define when interfaces freeze, under what conditions they can be revised, and how to avoid locking in unproven dimensions before miniaturization and prototype data are available.
- Detail the prime integrator's ownership of the integration layer: architecture, translation mechanisms between modules, consolidated integration budget, and accountability for end-to-end integration success.
- Define the Interface Arbitration Board structure, membership, escalation paths, and decision timelines for resolving interface conflicts among independent European centres.
- Quantify success metrics: integration lead time, retrofit cost exposure, upgradeability, supplier competitiveness, and number of unresolved interface exceptions.
- Address interactions with other levers: maintain compatibility with Miniaturization Pathway, enable Site Orchestration and Toolset Commonality, and identify conflicts with proprietary interfaces from licensed electronics fabrication processes.
- Include a risk section covering premature freeze versus delayed standardization, and define contingency actions for both failure modes.
- Specify governance and approval workflow, referencing the Programme Director and Interface Arbitration Board as final authorities.

**Risks of Poor Quality**:

- Prematurely freezing unproven interface tolerances forces expensive retrofits and locks in dimensions that obstruct later miniaturization, undermining the Miniaturization Pathway.
- Waiting too long to standardize prevents parallel module development across CERN, ASML, Zeiss, and Fraunhofer, causing multi-site schedule delays and idle funding tranches.
- Ambiguous or incomplete interface specifications lead to modules that physically or logically cannot integrate, triggering costly redesign and integration rework of EUR 5–15 billion and 2–3 years of delay.
- Failure to enforce compliance simulation allows partner centres to diverge from the covenant, resulting in incompatible mechanical, power, fluid, or data interfaces at the first integrated demonstration.
- Lack of a clear change-control and arbitration process creates unresolved disputes that stall integration and damage consortium trust.
- Ignoring conflicts with licensed semiconductor process kits permits proprietary interfaces to resist standardization, creating integration exceptions that grow uncontrolled.
- Missing freeze-timing criteria results in either a brittle covenant or an endlessly evolving specification, both of which reduce supplier confidence and investment certainty.

**Worst Case Scenario**: Modules developed independently across the four partner sites cannot be assembled into a functioning factory because interface specifications are incomplete, premature, or unenforced; the first integrated multi-module demonstration fails, triggering funding-gate termination, EUR 10+ billion in retrofit costs, 3–5 years of schedule slippage, and the collapse of the programme's 95% coverage and space-readiness credibility.

**Best Case Scenario**: A well-governed interface covenant with a controlled register, compliance simulation, and iterative freeze points enables all European centres to develop modules in parallel with confidence; the first integrated demonstration succeeds on schedule, retrofit costs stay near zero, a competitive supplier market emerges, and the architecture retains the flexibility needed for miniaturization—directly enabling go/no-go decisions on module integration, funding tranche releases, and the timeline to 95% coverage qualification.

**Fallback Alternative Approaches**:

- Start with a minimal viable interface standard covering only mechanical docking and data handshakes, deferring power and fluid interfaces until prototype testing reveals actual needs.
- Adopt existing industry standards (e.g., SEMI, ISO, or IEC) as the baseline interface specification rather than drafting a fully bespoke covenant from scratch.
- Rely on the prime integrator to develop proprietary translation adapters between module interfaces instead of forcing a single common physical standard across all centres.
- Convene a series of focused joint interface workshops with module leads from CERN, ASML, Zeiss, and Fraunhofer to co-design only the highest-risk interfaces before writing formal specifications.
- Implement an interface exception and risk register that tracks deviations deliberately and manages them through arbitration, rather than blocking all non-conforming module development until full compliance is achieved.

## Create Document 7: Contamination Envelope Zoning Framework

**ID**: 8adcf93e-689e-4b47-a718-fae8dd269a33

**Description**: Framework for factory pressure and airflow architecture: negative-pressure ATEX-compliant dirty zones for powder and subtractive processes, ISO Class 1-2 clean bays or mini-environment for electronics, airlock cascades, buffered transfer ports, and spatial constraints to be frozen before construction.

**Responsible Role Type**: Safety, Environmental & Sustainability Lead

**Primary Template**: ISO 14644 Cleanroom Design Framework

**Secondary Template**: ATEX Hazardous Area Classification Methodology

**Steps to Create**:

- Define zone pressure cascade and clean/dirty boundaries
- Commission CFD particle-dispersion studies for site layouts
- Integrate airlock and transfer-port overhead with module footprint
- Coordinate with factory systems and miniaturization teams
- Approve with Programme Director and central safety authority

**Approval Authorities**: Central Safety Authority, Programme Director

**Essential Information**:

- Specify the complete zone pressure cascade: negative-pressure ATEX-compliant dirty zones for powder/additive/subtractive processes, positive-pressure clean bays or mini-environments for electronics and lithography, with quantified pressure differentials between zones.
- Define the airlock architecture: number and sequence of airlock chambers (e.g., three-chamber cascades), buffered transfer ports, single-direction flow sequencing, and personnel/material movement rules to prevent cross-contamination.
- Resolve and justify the cleanliness class target: determine whether ISO Class 1-2 mini-environments or ISO Class 5 bays are required for each electronics/lithography process, trading cost, yield, and footprint; document any deviation from the project-plan baseline.
- Include ATEX hazardous area classification details: identify Zone 21/22 powder-handling cells, required equipment protection levels, and integration of explosion-prevention measures with the pressure cascade.
- Quantify spatial and throughput overhead: floor-area overhead per transfer, airlock dwell times, and impact on module footprint, directly reconciling with the Miniaturization Pathway's compact integration and short material-path requirements.
- Present CFD particle-dispersion study results for all three site layouts, confirming that dirty/clean separation is robust under worst-case airflow, thermal, and operational regimes.
- Define contamination monitoring and success metrics: electronics yield targets, contamination incident rate, particle-count monitoring points, and alarm/response protocols.
- Specify interface and sealing requirements for the Inter-Module Interface Covenant: pressure-safe sealed ports, power/fluid/data penetrations through zone boundaries, and compliance testing methods.
- Align with Thermal Envelope Separation: identify shared physical barriers, combined thermal/contamination isolation zones, and heat-recovery impacts on airflow and pressure control.
- Include formal freeze governance: design freeze date (e.g., 31 October 2026), required approvals from the Central Safety Authority and Programme Director, and a change-control process for any post-freeze modifications.

**Risks of Poor Quality**:

- Failure to freeze correct spatial zoning before construction forces extremely costly retrofits of airflow partitions and pressure cascades, inflating capital expenditure and delaying site readiness.
- Inadequate contamination separation reduces electronics/FPGA/sensor yield below the 95% coverage threshold, making the core value proposition undefensible and triggering funding-gate failures.
- Ambiguous cleanliness classification (e.g., ISO Class 5 vs 1-2) leads to either over-specification cost blowouts or under-specification yield failures.
- Uncoordinated airlock footprint and transfer-port overhead consumes the compact floor area required for miniaturization, forcing design rework or compromising dense module integration.
- ATEX compliance gaps create explosion or toxic-exposure risks in powder cells, potentially causing serious injury, regulatory penalties, and operational shutdowns.
- Missing interface sealing specs prevents modules from crossing contamination boundaries safely, causing integration failures and incompatibility across federated sites.
- Unvalidated CFD or pressure-cascade assumptions result in cross-contamination between dirty and clean zones, leading to chronic yield instability and eroded confidence in the 95% coverage claim.

**Worst Case Scenario**: A delayed or technically flawed Contamination Envelope Zoning Framework is approved without validated CFD or reconciled cleanliness classes; after construction, powder contamination infiltrates clean electronics bays, causing chronic yield drops below the 95% threshold, a safety incident triggers a regulatory shutdown, and the required retrofits and schedule slip force the EUR 200 billion programme to miss its 2046 space-readiness milestone, triggering funding termination and loss of political and investor confidence.

**Best Case Scenario**: A validated, construction-ready framework freezes ATEX and ISO zoning rules on schedule, provides costed spatial overhead integrated with miniaturized module designs, enables clean/dirty co-location without yield loss, and secures approvals from the Central Safety Authority and Programme Director. This enables go/no-go decisions on site construction, module layout finalization, and interface sealing, protecting electronics yield and making the 95% component-coverage target credible.

**Fallback Alternative Approaches**:

- Leverage existing ISO 14644 and ATEX templates and adopt a conservative default zoning configuration (maximum physical separation) as an interim control until detailed CFD and design work is completed.
- Engage a specialized contamination-control/cleanroom engineering consultancy to run CFD studies and produce the framework within a compressed timeline.
- Hold a focused stakeholder workshop with safety, electronics, miniaturization, and site leads to agree pressure cascades and boundary rules, capturing decisions in a concise 'minimum viable framework' first.
- Borrow proven cleanroom and powder-handling designs from ASML, CERN, or existing semiconductor fabs, adapting them to the modular factory layout rather than designing from scratch.
- Phase the framework: freeze the non-negotiable elements (ATEX zones, dirty/clean boundary locations, airlock sequence) immediately, and defer optimization of overhead and thermal integration to later design reviews.


# Documents to Find

## Find Document 1: EU Dual-Use Export Control Regulation and Implementing Acts (Regulation (EU) 2021/821)

**ID**: 6369718f-7ea0-4657-82f7-0a89b20e75c7

**Description**: Consolidated legal text of the EU dual-use regulation, including annexes and delegated acts. Primary legal input for the export-control compliance framework and legal makeability map.

**Recency Requirement**: Current consolidated version in force

**Responsible Role Type**: Cross-Border Legal, Regulatory & Export Control Lead

**Steps to Find**:

- Search EUR-Lex for CELEX number 32021R0821
- Download consolidated version and annex amendments
- Check delegated and implementing acts on EUR-Lex

**Access Difficulty**: Easy - publicly available on EUR-Lex

**Essential Information**:

- Identify the exact Annex I dual-use control codes (e.g., 3B001, 3B002, 9A515, robotics/mechatronics entries) that apply to the programme's planned semiconductor lithography tooling, space-rated propulsion manufacturing equipment, precision robotic actuation, and advanced metrology/feedstock processing systems.
- List the specific authorization pathways available (individual, global, EU General Export Authorisations EU001/EU002/EU003) and the conditions, validity periods, and restrictions for each one in the context of intra-EU and EU-to-Switzerland technology transfers between the CERN, ASML, and Zeiss/Fraunhofer sites.
- Detail the mandatory elements of an Internal Compliance Programme (ICP), record-keeping obligations, and end-use/end-user declaration requirements that the SPV and prime integrator must implement before submitting export-control classification requests to BAFA, CDIU, and SECO by 15 October 2026.
- Quantify the statutory processing times for license applications, appeal mechanisms, penalties for non-compliance (fines, imprisonment, equipment seizure), and any recent enforcement precedents relevant to multijurisdictional industrial R&D consortia.
- Summarize all delegated acts, implementing acts, and annex amendments in force as of the current date that affect the control lists for additive manufacturing, E-beam lithography, semiconductors, robotics, and space-related manufacturing technology.
- Clarify the scope of 'transfer within the customs territory of theUnion' and 'brokering/technical assistance' provisions applicable to federated module development and cross-border data exchange between partners in Switzerland, France, the Netherlands, and Germany.

**Risks of Poor Quality**:

- Using a superseded or unconsolidated text would cause incorrect dual-use classification of critical items, leading BAFA/CDIU/SECO applications to be rejected or mis-filed and missing the 15 October 2026 filing deadline.
- Missing delegated or implementing acts could result in uncontrolled transfers of newly listed items (such as advanced E-beam lithography equipment or specialized robotics) without necessary licenses, triggering penalties, equipment impoundment, and criminal liability.
- Misreading EU General Authorisation conditions could invalidate the programme's technology-transfer matrix and abruptly halt movement of controlled lithography, metrology, and precision robotics hardware/data between the federated sites.
- Failure to identify end-use or end-user controls could activate national 'catch-all' clauses, subjecting the space-precursor manufacturing technology to sudden license refusals and causing multi-year delaysto electronics and propulsion module development.
- Incomplete understanding of ICP compliance requirements could undermine audit readiness and cause loss of trusted-partner status with EU and Swiss regulators, delaying all subsequent export licenses.

**Worst Case Scenario**: An incorrect or incomplete legal basis leads to a major unlicensed transfer of controlled lithography or space-manufacturing technology between Veldhoven and Geneva, triggering regulatory penalties, seizure of critical equipment, revocation of existing licenses, and a multi-year suspension of cross-border technical-data exchange. This stalls the electronics fabrication and integrated-module critical path, adds EUR 3-10 billion in legaland rework costs, delays space-readiness by 3-5 years, and severely damages investor and member-state confidence in the EUR 200 billion programme.

**Best Case Scenario**: The consolidated regulation enables the cross-border legal team to pre-classify every controlled item with certainty, file complete and accurate BAFA/CDIU/SECO applications by Q3/Q4 2026, and obtain all necessary authorizations smoothly. A defensible technology-transfer matrix is established early, cross-border movement of equipment, data, and personnel proceeds on schedule, and the federated module development is fully de-risked against export-control shocks, protecting the programme's 20-year timeline and strategic autonomy objectives.

**Fallback Alternative Approaches**:

- Request the official consolidated version and annexes directly from the European Commission's Dual-Use Coordination Group or the EU Export Control Helpdesk via a formal FOI/information request if EUR-Lex access is insufficient.
- Engage a specialized EU export-control law firm to prepare a verified legal memorandum citing Regulation (EU) 2021/821 and all applicable delegated/implementing acts, including item-specific classification recommendations for the programme's technology list.
- Submit preliminary classification ruling requests to BAFA, CDIU, and SECO using detailed technology datasheets, allowing national authorities to provide binding or advisory classifications while the consolidated regulation is being verified.
- Use the European Commission's dual-use control list search tool and national control lists from Germany, the Netherlands, France, and Switzerland as interim cross-check references.
- Leverage the internal export-control compliance manuals and classification databases already maintained by project partners such as ASML, Zeiss, CERN, and Fraunhofer as practical cross-checks against the regulatory text.

## Find Document 2: Zoning and Land-Use Plans for Candidate Site Areas (Pays de Gex, Veldhoven/Eindhoven, Oberkochen/Southern Germany)

**ID**: 12eaac70-b5ca-4d25-81bf-2686abc7814e

**Description**: Official municipal zoning maps, land-use designations, building restrictions, and development plans for candidate industrial land parcels near Geneva/CERN, Veldhoven/ASML, and Oberkochen/Zeiss-Fraunhofer.

**Recency Requirement**: Current plan versions

**Responsible Role Type**: Site Development and Construction Lead

**Steps to Find**:

- Access municipal planning portals for each candidate commune
- Request pre-application zoning confirmations from local planning authorities
- Review national and regional industrial development plans

**Access Difficulty**: Medium - public records but fragmented across multiple authorities

**Essential Information**:

- Identify for each candidate parcel its current official zoning classification (e.g., industrial, mixed-use, agricultural, conservation) and the full list of permitted land-use categories under the applicable municipal plan (PLU, bestemmingsplan, Flächennutzungsplan).
- State the maximum allowable building coverage, floor area ratio, building height, setback distances, and parking/loading requirements for industrial use on each parcel.
- List any use-specific restrictions or special permit requirements for advanced manufacturing activities: semiconductor fabrication, cleanrooms, powder handling, chemical storage, high-temperature processes, and 50 MW-scale energy infrastructure.
- Detail environmental designations affecting development feasibility: Natura 2000, water protection zones, flood zones, noise contours, protected landscapes, archaeological sites, and known soil contamination.
- Quantify utility connection availability and capacity for each parcel: electrical grid capacity/upgrade path for 50 MW, water supply, sewage, gas, and data connectivity, including any known constraints or lead times for connection.
- Describe the zoning change or conditional-use permit process for each site, including expected duration, decision authority, public consultation requirements, and any documented local political opposition or support.
- Indicate whether the parcels fall within designated industrial/business parks or special economic development zones that already permit high-tech manufacturing and accelerated permitting.
- Provide the current ownership/option status or availability of each parcel, including lease terms, purchase price indications, and any known encumbrances or restrictive covenants.
- State required buffer distances to residential areas, schools, hospitals, and other sensitive receptors, and whether planned activities can comply within the parcel boundary.
- List any existing development agreements, master plans, or local infrastructure commitments that could either accelerate or block construction of the modular factory.

**Risks of Poor Quality**:

- Site selection built on outdated or incorrect zoning data may lock the programme into parcels that cannot legally accommodate the factory, forcing costly re-selection.
- Missing environmental designations (Natura 2000, flood zones) can trigger permit denials or 6–24 month delays after land options are already exercised.
- Underestimated utility connection constraints can make the 50 MW clean-energy requirement unachievable at a chosen site, requiring expensive grid upgrades or relocation.
- Unclear special-use restrictions for cleanrooms, powder handling, or lithography could invalidate the ATEX/ISO 14644 layout assumptions and force redesign.
- Failure to identify local political opposition or rezoning risk may result in public hearings blocking construction and damaging the programme's credibility.
- Incomplete information on ownership encumbrances can lead to legal disputes, higher acquisition costs, or inability to secure long-term site control.
- Inconsistent data across Swiss, French, Dutch, and German authorities may lead to incorrect cross-site comparisons and suboptimal site allocation.

**Worst Case Scenario**: The programme executes land options and begins preliminary construction based on flawed or incomplete zoning information, only to discover that the preferred parcels are legally unsuitable for the planned industrial use—due to environmental protection status, restrictive zoning, utility incapacity, or political opposition. This forces site abandonment and re-selection, causing 2–4 years of delay, hundreds of millions of euros in sunk costs, a broken funding-gate timeline, and a cascading loss of political and investor confidence that could jeopardise the entire EUR 200 billion programme.

**Best Case Scenario**: Accurate, current zoning and land-use plans confirm that all three candidate sites are either already zoned for high-tech industrial use or have clear, low-risk permit pathways. This enables rapid execution of 24-month option agreements, successful pre-application zoning confirmations, and accelerated construction permitting. The programme enters the design phase with site risk substantially retired, strengthens the credibility of the funding consortium, and keeps the 2026–2028 site acquisition and design phase on schedule.

**Fallback Alternative Approaches**:

- Engage a specialized land-use and planning consultancy to conduct independent due diligence on each candidate parcel, including direct verification with municipal planning authorities.
- Request pre-application meetings with local planning departments to obtain written preliminary zoning opinions and identify required variances or rezoning steps.
- Identify alternative industrial parks, brownfield sites, or greenfield parcels within the same regions that already hold permits for high-tech or semiconductor manufacturing.
- Expand the candidate site shortlist to include adjacent municipalities with more permissive industrial zoning and existing utility capacity.
- Negotiate option agreements with contingency clauses allowing withdrawal if zoning or permitting conditions are not met within a defined period.
- Seek government designation of the sites as projects of national or European strategic importance (e.g., IPCEI) to force expedited planning and override local restrictions.
- Purchase or lease existing industrial facilities with valid environmental and construction permits, then retrofit them for modular factory needs instead of building from scratch.
- Use the decision matrix from the zoning study to rank alternative sites on permit risk and utility readiness before exercising any land option.

## Find Document 3: Semiconductor Equipment and Process Chain Technical Specification Data (Lithography, Etch, Deposition, CM P, Metrology Tools)

**ID**: 22a7beb3-9317-4bba-bbe1-6b4a7f5fd825

**Description**: Raw technical datasheets, tool footprints, usility requirements, and capability data for semiconductor manufacturing equipment from suppliers such as ASML, Zeiss, Applied Materials, and others. Needed to asses realisitic miniaturization and makeability.

**Recency Requirement**: Current product generation data; historical data for learning curves

**Responsible Role Type**: Advanced Manufacturing, Materials & Process Engineering Lead

**Steps to Find**:

- Submit partnership inquiries to equipment suppliers
- Sign non-disclosure agreements where required
- Request technical datasheets and footprint specifications
- Attend industry briefings or imec/CEA-Leti partnership programmes

**Access Difficulty**: Hard - proprietary, requires NDAs and established business relationships

**Essential Information**:

- Quantify physical footprints (m2 footprint and m3 installation envelope, including service clearance) for current-generation lithography (DUV, EUV, maskless e-beam), etch, deposition (CVD/PVD/ALD), CMP, and metrology tools, to test whether electronics process chains fit the miniaturized modular footprint and to size ISO Class 5 clean bays before the 31 October 2026 spatial safety freeze.
- Detail per-tool utility requirements: electrical power draw (kW), cooling-water and heat-rejection loads, process gas types/purities/consumption rates, exhaust and scrubbing needs, and vibration/floor-loading limits, to validate the 50 MW energy budget and the thermal-envelope separation design.
- Specify achievable resolution, overlay accuracy, defect density, and throughput (wafers per hour) per tool generation and node, to determine whether FPGA- and sensor-class components are makeable at bench scale and to set technical gate thresholds for the 2032 prototype merge gate.
- Provide baseline first-pass yield, process capability index (Cpk), and historical yield learning curves per process chain and tool generation, to populate the component-makeability map (baseline TRL, yield estimate, process modification cost) ranking the 5,000-part catalogue and to anchor yield-gated funding tranches.
- List feedstock and consumable tolerance windows (purity and composition ranges each process chain accepts without pre-treatment), to calibrate the Feedstock Resilience Architecture and the in-line spectroscopy-based adaptive process control loops.
- Enumerate all external dependencies per process chain (reticles/masks, photoresists, specialty gases, CMP slurries, calibration standards), including supplier concentration and substitution options, to draw the External Input Allowance boundary and draft a defensible elimination roadmap.
- Extract mechanical, power, fluid, and data interface specifications per tool (dimensions, docking, connectors, control protocols) to feed the controlled inter-module interface register v1.0 and to assess Toolset Commonality Mandate feasibility at the interface layer.
- Identify supplier roadmap options for miniaturization: compact/benchtop tool variants, minimum viable operating scale, de-rating potential, and which process steps can be modularized versus fixed-installation, to inform the two-track miniaturization merge-gate criteria.
- Characterize metrology integration options: in-situ versus at-line sensor capability, measurement cycle time per part, and compatibility with real-time adaptive control, to set Measurement Gate Rhythm density without throttling throughput.
- Document licensing and co-development boundary conditions: which process kits are licensable, what NDA-gated data exists, and indicative lead times and customization constraints for co-developed subsystems with ASML and Zeiss, to ground the Electronics Fabrication Sourcing decision.

**Risks of Poor Quality**:

- Cleanroom areas, pressure cascades, and power/gas infrastructure frozen on wrong footprint or utility data force extremely costly post-construction retrofits of airflow partitions and utilities, since contamination zoning must be fixed before construction design.
- The makeability map ranks the 5,000-part catalogue on assumed rather than verified capability data, mis-sequencing component coverage, delaying the first integrated demonstration, and distorting funding tranche gates.
- Unrealistic yield and throughput thresholds derived from missing or outdated data cause prototype merge-gate and funding-gate failures even when genuine engineering progress occurs, triggering performance-linked funding stoppages.
- The co-develop-versus-license-versus-maskless decision is made without verified resolution/throughput trade-offs, delaying first custom chip production by years and adding EUR 20-40B in unplanned R&D spend.
- Overstated in-factory electronics feasibility that ignores reticles, resists, slurries, and calibration consumables collapses the 95% universality claim under external audit, damaging credibility with investors, regulators, and member states.
- Thermal and contamination zoning computed from assumed heat loads and cleanliness classes either overbuilds floor area and erodes miniaturized density, or under-protects electronics yield below the 95% qualification threshold.

**Worst Case Scenario**: The programme commits early capital and freezes the factory's spatial and interface architecture on incorrect or aspirational equipment data; by the 2033-2037 integration phase it emerges that semiconductor process chains cannot fit the miniaturized modular footprint or achieve required yield and throughput, the electronics yield plateau invalidates the auditable 95% coverage claim, performance-linked consortium gates fail, and the EUR 200B programme descopes or terminates with no space-ready module, forfeiting tens of billions in sunk investment and destroying political and investor confidence.

**Best Case Scenario**: Complete, NDA-secured current-generation and historical datasets from ASML, Zeiss, and other suppliers enable a quantitatively grounded makeability map (per-class TRL, first-pass yield, Cpk, footprint, and utility loads), validate the two-track miniaturization merge gates, and allow clean bays, utilities, and thermal/contamination zoning to be frozen correctly on the first attempt — protecting the 2032 prototype gates, the 2037 integrated demonstration, and the 2042 95% coverage qualification, while cementing ASML/Zeiss as co-development partners and materially strengthening the consortium's investment case.

**Fallback Alternative Approaches**:

- Route data acquisition through imec or CEA-Leti partnership programmes and Fraunhofer institutes, which hold established supplier relationships and can deliver parameter envelopes without direct bilateral NDA delays.
- Commission a paid, NDA-protected miniaturization feasibility study from a prime integrator or systems-engineering firm with existing ASML/Zeiss/vendor access, contractually requiring deliverable parameter ranges (footprint, power, resolution, throughput, yield) rather than raw datasheets.
- Construct a public-domain baseline from SEMI standards, ITRS/IEEE roadmaps, imec public roadmaps, academic pilot-line publications, and vendor marketing specifications, tagging each value with an uncertainty band and a validation priority for later confirmation.
- Negotiate joint concept-study agreements with ASML and Zeiss aligned with the co-development sourcing option, exchanging early visibility of programme requirements and volume commitments for preliminary access to footprint, utility, and yield envelope data.
- Scope a minimal electronics demonstrator (e.g., a simplified sensor or FPGA-class process chain at an accessible node) using open data, so that prototype gate definitions and interface register v1.0 proceed on schedule while full tool datasets are secured through partnership agreements.

## Find Document 4: ATEX Directive 2014/34/EU and Harmonised Standards; ISO 14644 Cleanroom Standards; ISO 45001 Safety Management Standard

**ID**: f85256ed-6d4b-4ab4-914d-6b48dc92735e

**Description**: Regulatory and standards texts governing explosion protection, cleanroom classifiation, and occupational health and safety. Input for contamination zoning, safety architecture, and compliance framework.

**Recency Requirement**: Current consolidated editions

**Responsible Role Type**: Safety, Environmental & Sustainability Lead

**Steps to Find**:

- Download directive text from EUR-Lex
- Purchase or access ISO standards through national standards bodies
- Review EU harmonised standard lists for ATEX

**Access Difficulty**: Medium - official directive is free; ISO standards are paywalled

**Essential Information**:

- Identify the equipment categories, protection concepts, and conformity assessment procedures required for ATEX Zone 21/22 powder-handling and subtractive cells under Directive 2014/34/EU, including ignition hazard assessment, CE/Ex marking, EU-type examination, and quality assurance requirements.
- List the current EU harmonised standards for ATEX equipment and protective systems (e.g., EN 60079 series, EN ISO 80079 series) with their exact scope, latest editions, and any transition periods or withdrawal dates.
- Specify ISO 14644-1 classification limits for the required cleanrooms (e.g., ISO Class 5 positive-pressure electronics/lithography bays), including the exact airborne particulate concentration thresholds for the relevant particle size ranges.
- Detail ISO 14644-2 monitoring and testing requirements, including minimum sampling locations, frequency of classification tests, and acceptable monitoring plans to maintain cleanroom certification over the 20-year programme.
- Provide ISO 45001 requirements for the OHS management system: clauses covering risk assessment, operational control, emergency preparedness and response, performance evaluation, audit, and certification processes that integrate with ATEX and cleanroom safety regimes.
- Clarify how ATEX negative-pressure dirty zones and ISO Class 5 positive-pressure clean bays can coexist safely within the same facility, including airlock cascade sequences and pressure differential requirements that satisfy both standards.
- State the current consolidated editions, amendment dates, and any national deviations or adoptions applicable to the three standards for Switzerland, France, Germany, and the Netherlands.
- Quantify the validation evidence required to demonstrate compliance: test reports, certification body involvement, documentation formats, and records retention periods.

**Risks of Poor Quality**:

- Incorrect ATEX zone classification or equipment category selection could create an explosion hazard in powder handling cells, leading to injuries, facility shutdown, and regulatory sanctions.
- Misreading ISO 14644 cleanroom class limits or using a superseded edition could result in an improperly designed cleanroom, causing electronics contamination and yield drops below the 95% coverage threshold.
- Conflicting pressure cascade requirements from ATEX and ISO 14644 could produce an unsafe or non-functional airlock design, forcing expensive rework after construction begins.
- Missing ISO 45001 clauses or misinterpreting audit requirements could delay certification and undermine the central safety authority's ability to conduct annual audits and incident investigations.
- Outdated standards lists or ignoring transition periods could render equipment or facilities non-compliant mid-programme, triggering costly retrofits and legal exposure.
- Ambiguity in harmonised standards coverage could lead to product-specific exemptions being missed, invalidating insurance or regulatory approvals for critical manufacturing equipment.
- Poorly integrated OHS, ATEX, and cleanroom documentation would weaken the programme's ability to demonstrate compliance to inspectors and investors, damaging credibility.

**Worst Case Scenario**: The facility is designed and built using outdated or misinterpreted ATEX/ISO 14644/ISO 45001 requirements, resulting in a catastrophic metal powder dust explosion or persistent electronics contamination causing yield failure; authorities issue shutdown orders, the programme incurs EUR 10 billion+ retrofitting costs, and the 20-year timeline collapses, ending the project's political and investor support.

**Best Case Scenario**: The safety team obtains current, authoritative standards early and freezes the contamination-envelope zoning and ATEX pressure cascades by 31 October 2026, enabling a compliant, certifiable, and safe modular factory design; cleanroom electronics yield remains high, safety audits pass without major findings, and the programme's regulatory credibility accelerates investment and public trust.

**Fallback Alternative Approaches**:

- Engage a specialised third-party safety and standards consultancy (e.g., TÜV, Dekra, or notified body) to provide an authoritative interpretation and compliance matrix for the three standards.
- Request the current harmonised standards list and directive consolidated text from the European Commission's NANDO database and EUR-Lex, which are freely accessible.
- Access ISO standards through national standards body subscriptions or institutional library licences if direct purchase costs are prohibitive.
- Benchmark against certified cleanroom and powder-handling facility designs from the semiconductor and additive-manufacturing industries to infer current compliance practice.
- Conduct early consultation with host-country regulators and notified bodies to agree on an acceptable compliance interpretation pending full standards purchase.

## Find Document 5: Eurostat HICP Inflation Indices and Swiss National Bank EUR/CHF Historical Exchange Rate Data

**ID**: 49076577-d9fc-4405-ad09-775df72d8a2f

**Description**: Official monthly inflation indices and daily/monthly EUR/CHF exchange rates. Required for real-euro budgeting, indexation, and hedge baseline.

**Recency Requirement**: Monthly data from programme start; 20-year historical series for modelling

**Responsible Role Type**: Strategic Funding & Treasury Lead

**Steps to Find**:

- Download HICP data from Eurostat database
- Download EUR/CHF series from SNB data portal
- Extract historical consumer price and energy/materials sub-indices

**Access Difficulty**: Easy - public statistical databases

**Essential Information**:

- Download the complete Euro area HICP monthly time series from Eurostat, including the all-items index and sub-indices for energy, industrial goods, and materials, with explicit base year, series key, and publication lag.
- Download the monthly and daily EUR/CHF exchange rate time series from the Swiss National Bank data portal, covering at least 20 years prior to the September 2026 programme start for modelling and a rolling window during the programme.
- Identify the exact HICP reference period and whether the EUR 200 billion budget baseline is expressed in 2026 real euros or nominal euros, including any rebased values after five-year re-baselining.
- Quantify cumulative HICP inflation scenarios (e.g., 2% and 3% annual inflation) to compute real purchasing-power erosion of the EUR 200 billion envelope over 20 years.
- Extract the EUR/CHF historical volatility, forward curve, and average annual exchange rates to set a formal hedging band (e.g., 1.05-1.10) and to size the CHF 3 billion Geneva-site allocation hedging reserve.
- Document the source, retrieval date, and revision policy for every series so the treasury model can be audited and re-validated at each five-year board review.
- Provide monthly data from Q4 2026 onward to support quarterly hedge ratio reviews and annual inflation indexation adjustments to labour, energy, and materials cost lines.

**Risks of Poor Quality**:

- Using nominal euros without HICP indexation silently erodes real purchasing power: at 2% inflation, the €200B budget drops to ~€135B real; at 3%, to ~€110B, forcing a 25-40% scope reduction or requiring €65-90B top-up.
- Incorrect or incomplete EUR/CHF historical data leads to a mis-specified hedge baseline, leaving the CHF 3 billion Geneva allocation exposed to unanticipated currency swings that could add €0.5-1.5 billion in cost.
- Stale or wrong sub-index data for energy and industrial materials misprices feedstock and utilities cost escalation, undermining annual indexation of contracts and contingency reserves.
- Missing publication lags and revision histories cause treasury models to compare inconsistent vintages, producing unreliable quarter-over-quarter cash-flow projections and investor reporting.
- Failure to distinguish real vs nominal baselines creates conflicting messages to funding partners and the consortium, triggering disputes over budget adequacy and capital-call schedules.

**Worst Case Scenario**: The programme locks in a nominal €200B commitment without an HICP-indexed baseline, and the treasury hedges CHF using a flawed historical window. Over 20 years, inflation erodes purchasing power by €65-90B and unhedged EUR/CHF swings add billions in losses. The consortium faces a mid-programme funding crisis: capital calls exceed committed amounts, political partners hesitate to top up, technical milestones slip, and the space-readiness and 95% coverage goals are descoped or abandoned.

**Best Case Scenario**: The treasury obtains authoritative HICP and EUR/CHF data, establishes the €200B budget in 2026 real euros with annual indexation, and implements a disciplined quarterly hedging programme. Investors and member states see stable, inflation-proofed funding, cash-flow forecasts are reliable, and the programme avoids financial-driven scope cuts. The credible financial baseline strengthens political support and private co-investment, enabling the 20-year technical roadmap to proceed on schedule toward 95% coverage and space-readiness validation.

**Fallback Alternative Approaches**:

- If Eurostat HICP data is unavailable or lagged, use the European Central Bank's Statistical Data Warehouse or national statistical office CPI/HICP releases and clearly document the substitution.
- If the SNB data portal lacks the required history, source EUR/CHF rates from the European Central Bank's euro foreign exchange reference rates or a reputable market data provider (e.g., Bloomberg, Refinitiv).
- If historical series are incomplete, construct a modelled series using long-term average inflation and EUR/CHF volatiity assumptions, and validate against expert economic forecasts from the IMF or OECD.
- Engage a treasury advisory firm or economics consultancy to produce an independent inflation-indexation and currency-hedging baseline when in-house data extraction resources are insufficient.
- Negotiate indexation clauses into supplier and contractor contracts using a published consumer/producer price index even if exact HICP sub-indices cannot be sourced, ensuring cost escalation is contractually covered.