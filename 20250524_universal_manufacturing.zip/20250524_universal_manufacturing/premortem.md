A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Binding public and private funding commitments will remain stable for 20 years, with the 70/30 public-private risk-sharing consortium delivering EUR 60B of private capital at an 8-10% IRR threshold and no more than 3 months of uncovered expenditure at any point. | By 2027-03-31, run investor roadshows with a draft term sheet and 20-year licensing revenue model; secure binding commitment letters from EIB/EBRD and at least two institutional investors; and hold a political-risk workshop with the four host governments to obtain SPV ratification commitments. | Private capital commitments by 2027-03-31 total less than EUR 20B (target EUR 60B), or at least two of the four host governments fail to ratify the SPV by 2027-06-30, or committed public funding falls below 60% of the real-euro baseline in any 12-month period. |
| A2 | The 95% component-coverage claim is physically achievable as defined: monolithIC FPGA and sensor fabrication from basic feedstock can reach gate-threshold yields within the programme timeline, with the 5,000-part makeability map providing sufficient granularity to sequence coverage. | By 2027-06-30, commission imec/CEA-Leti/Fraunhofer fab engineers to decompose one representative FPGA and one sensor into unit processes, build a yield budget with Cpk and contamination specs, and issue a semiconductor reality gate recommendation before releasing any tranche beyond EUR 1B. | The independent yield budget for one FPGA and one sensor shows first-pass yield below 80% at process maturity, Cpk below 1.33, or input-purity requirements that exceed feasible feedstock conditioning within 10x the planned energy/capex envelope by 2027-06-30. |
| A3 | Export-control and technology-transfer licenses for lithography, propulsion, and robotic actuation can be obtained within the programme timeline across BAFA, CDIU, SECO, and SBDU/DGDDI jurisdictions, and CERN and all anchor partners can legally participate in the federated digital twin and shared technology pool. | Immediately appoint an Export Control and Technology Transfer Director with stop-work authority; complete the Technology Transfer Matrix and Legal Makeability Map; file concrete license applications with BAFA, CDIU, SECO, and SBDU/DGDDI for lithography, propulsion, and robotic actuation; and obtain a legal opinion from CERN Knowledge Transfer by 2027-03-31. | BAFA, CDIU, SECO, or SBDU/DGDDI issues a formal denial or an MTCR/Wassenaar controlled classification for lithography, propulsion, or robotic actuation technology that cannot be licensed within 18 months, or CERN Legal confirms by 2027-03-31 that CERN cannot participate in an industrial space-manufacturing programme. |
| A4 | The programme can recruit, retain, and duplicate its ~18,000-person workforce—especially the 7,000 engineers and scientists in scarce specialties—with two trained practitioners per critical skill, and attrition will stay within modeled rates despite active poaching pressure from the ASML, CERN, Zeiss, and Fraunhofer talent ecosystems over 20 years. | By 2027-03-31, complete a critical-skill inventory with named practitioner counts per specialty and site, benchmark attrition rates against partner-institution benchmarks, sign retention agreements, and name deputies for every leadership and gate-critical technical role with documentation SLAs and time-to-competence targets. | Any gate-critical specialty is held by fewer than 2 trained practitioners for more than 90 days after the redundancy-plan deadline, or surveyed annualized attrition among senior scarce-role engineers exceeds 10%, or named deputies cover fewer than 80% of critical roles by 2027-03-31. |
| A5 | Basic industrial feedstock, standard reagents, specialty process gases, and ultrapure inputs can be procured at stable price, volume, and purity from qualified suppliers for the full 20 years, and adaptive in-line process control can compensate realistic purity variation within family-specific tolerance windows. | By 2027-04-30, qualify at least 2 suppliers per critical feedstock class, run designed experiments across 10 process families to build a statistically validated purity-to-yield sensitivity matrix, execute hardware-in-the-loop adaptive-control simulations, and lock 6-12 month strategic stockpile and dual-source agreements. | The purity-to-yield sensitivity matrix shows control loops cannot compensate within 2x the planned energy and capital envelope for 3 or more of 10 process families, or fewer than 2 suppliers qualify for any critical feedstock, reagent, or process-gas class by 2027-06-30. |
| A6 | Construction and environmental permits can be obtained by 2028 at all three sites without fundamental community opposition, and local social license plus host-government support will hold through 20 years of construction, powder handling, and 24/7 industrial operation. | By 2027-06-30, complete geotechnical, utility, zoning, and environmental screenings at all three nodes, hold pre-application consultations with French, Dutch, German, and Swiss authorities, convene community advisory boards at each site, and secure formal non-objection or support letters from host municipalities. | Any site receives a formal zoning rejection or environmental-impact objection requiring redesign, public-consultation opposition exceeds 30% of respondents at any node, or any host municipality formally withdraws support before construction permits are granted. |
| A7 | The inter-module interface register v1.0 and the federated digital-twin platform will remain stable and compatible across all partner sites, allowing parallel module development to converge without costly retrofits and coordination failures. | By 2027-06-30, run compliance simulations for all initial modules against interface register v1.0, conduct a joint integration review, and test digital-twin data handshakes with OPC UA across all three sites; freeze the interface baseline only after zero critical non-conformances are resolved. | Any initial module fails compliance simulation against register v1.0, or the joint integration review finds more than 5 critical non-conformances, or interface specification changes exceed 10% of the baseline within the first 12 months. |
| A8 | A credible near-term killer application and market demand exist for the factory's realistic capabilities, sufficient to secure anchor customer letters of intent and a 20-year licensing revenue model supporting the 30% private capital target. | By 2027-06-30, complete an independent market sizing study for candidate killer applications (advanced-packaging sensor modules, rad-hard board assemblies, robotic actuators), secure at least two anchor customer LOIs, and validate licensing royalty scenarios (3-5% on module and space-contract sales) against real customer willingness-to-pay. | Fewer than two anchor customer LOIs are signed by 2027-06-30, or independent market sizing shows total addressable licensing revenue below EUR 150B over 20 years, or no single killer application demonstrates customer willingness-to-pay at the assumed royalty rate. |
| A9 | The programme's sustainability and environmental targets—100% renewable electricity by 2035, 80% waste-heat recovery, 90% water recycling, and net-zero operational carbon by 2040—are achievable without degrading factory throughput, inflating capex, or creating grid-connection and permitting delays that jeopardize the 2046 space-readiness timeline. | By 2027-06-30, complete environmental impact assessments at all three sites, run validated simulations for waste-heat recovery and water recycling under realistic 24/7 process loads, and secure signed renewable-power purchase agreements and grid-connection capacity reservations. | Simulations show waste-heat recovery below 60% or water recycling below 70% under realistic process loads, or renewable PPA costs exceed EUR 50/MWh for the full 50 MW required capacity, or grid-connection lead times exceed 5 years at any site. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Tranche That Never Came | Process/Financial | A1 | Programme CFO / Strategic Funding & Treasury Lead | CRITICAL (20/25) |
| FM2 | The Yield Plateeau at Eighty Percent | Technical/Logistical | A2 | Advanced Manufacturing, Materials & Process Engineering Lead with Electronics and Semiconductor Deputy Lead | CRITICAL (25/25) |
| FM3 | The Border That Closed the Factory | Market/Human | A3 | Cross-Border Legal, Regulatory & Export Control Lead / Export Control and Technology Transfer Director | CRITICAL (20/25) |
| FM4 | The Empty Benches | Process/Financial | A4 | Knowledge, Talent & Workforce Continuity Lead | CRITICAL (16/25) |
| FM5 | The Purity Cliff | Technical/Logistical | A5 | Supply Chain and Procurement Lead with the Feedstock Resilience and Adaptive Process Control team | CRITICAL (16/25) |
| FM6 | The Referendum Nobody Planned | Market/Human | A6 | Stakeholder and Political Engagement Lead with the Site Development and Construction Lead | HIGH (12/25) |
| FM7 | The Green Mandate Bubble | Process/Financial | A9 | Safety, Environmental & Sustainability Lead | CRITICAL (16/25) |
| FM8 | The Interface Earthquake | Technical/Logistical | A7 | Factory Systems, Interface & Digital Integration Architect | CRITICAL (20/25) |
| FM9 | The Silence of the Anchor Customers | Market/Human | A8 | Commercialisation and Licensing Lead | CRITICAL (20/25) |


### Failure Modes

#### FM1 - The Tranche That Never Came

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Programme CFO / Strategic Funding & Treasury Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
By 2031, the EUR 200 billion programme was not a partnership but a courtroom. The first three years had gone exactly to plan: the SPV was signed, site options were executed, and two macro-scale prototype lines began assembly. But the private capital that was supposed to arrive as licensing-backed co-investment never materialized at the promised scale. EIB and pension funds had wanted a 20-year revenue model with royalty rates and exit mechanisms; the consortium had produced spreadsheets with 8-10% IRR targets but no genuine anchor customer LOIs. When electronics yield delays pushed the 2032 merge gate right, the gate-linked capital calls were triggered. Public treasuries, facing inflation and defense budgets, delayed tranches by quarters.

The second member-state government to change did not cancel but quietly reclassified its contribution as 'repayable aid', which auditors refused to count as committed funding. Private partners, watching coverage demonsurations slip and their licensing rights become embroiled in export-control restrictions, invoked material-adverse-change clauses. By 2034 the annual drawdown had fallen from EUR 10 billion to EUR 6.5 billion for two consecutive years. The contingency reserve was being consumed not for technical breakthroughs but for payroll and supplier retainers. Every funding gate became a calendar negotiation, not an evidence review, and rigid milestone phasing starved the serendipitous research that might have solved the yield problem. The treasury team spent more time re-forecasting than hedging; EUR/CHF volatility added EUR 0.9 billion of unhedged losses. With no stable capital, suppliers stopped holding strategic stockpiles, 13% of key engineers left, and the 2042 certification date became impossible.

##### Early Warning Signs
- Private capital commitments below EUR 20B by 2027-03-31
- Two or more member states delaying SPV ratification beyond 2027-06-30
- Annual drawdown variance exceeding 20% from the planned EUR 8-12B corridor for two consecutive quarters

##### Tripwires
- Private capital share below 20% of total committed funding by 2032-06-30
- Member-state contribution shortfall exceeding EUR 10B in any 12-month period
- Two consecutive missed funding-gate evidence deadlines triggering stop-go capital calls

##### Response Playbook
- Contain: Freeze non-critical capital spend and activate the EUR 20B contingency reserve to bridge the next 12 months of payroll and critical-path work.
- Assess: Run an independent audit of committed vs actual funding, re-baseline the real-euro model, and quantify the gap between current private share and the 30% target.
- Respond: Renegotiate capital-call schedules into a EUR 8-12B annual drawdown corridor, convert stop-go gates to yield-based evidence gates, and open a EUR 5B breakthrough reserve to retain key staff.


**STOP RULE:** Cancel or descope to a ground-based precursor if committed public funding falls below 60% of the real-euro baseline for two consecutive years or private capital share remains below 10% after 2029-06-30.

---

#### FM2 - The Yield Plateeau at Eighty Percent

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Advanced Manufacturing, Materials & Process Engineering Lead with Electronics and Semiconductor Deputy Lead
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
By 2036, the phrase '95% component coverage' had become a liability. At the 2027 semiconductor reality gate, the programme rejected the recommendation to descope monolithIC ICs. The makeability map continued to list FPGAs as a single line item with a TRL of 4 and a process modification cost of EUR 300M, while process engineers at Veldhoven had decomposed one representative FPGA into 1,200 unit steps and found that 40% of those steps required input purities no feedstock conditioning plant on the programme's budget could deliver. The miniaturized track celebrated a 10 µm line-width coupon, which was 1990s-era capability and proved nothing about shrinking the fab itself.

The first integrated electronics bay was built to ISO Class 5 with airlocks; the yield engineer's first lot of 200 mm wafers produced zero functional devices. The cleanroom retrofit to ISO Class 1-2 with FOUP mini-enviroments took 14 months and consumed 20% of the floor area reserved for the miniaturized line. By 2039 the electronics family had reached a plateau at 78% first-pass yield on the simplest sensor die, but monolithIC FPGA yield never passed 52%. The coverage governance board faced an impossible choice: either count unproven components in the denominator and fail the audit, or exclude them and shrink the 95% claim to below 80%. It chose to count them. When the independent certifier in 2042 reviewed the evidence package, it found that 17% of the component catalogue had no validated process chain and that the factory's own traceability system had filed coverage claims for parts actually purchased from Taiwan. The certification collapsed. The descope plan was activated: monolithIC ICs were removed from the claim, the factory was redefined as an advanced-packaging and system-integration facility using externally sourced die, and the remaining structural and mechanical coverage could not justify the EUR 200B investment. The 2046 space-readiness validation was cancelled.

##### Early Warning Signs
- FPGA first-pass yield below 60% at the 2034 process-chain qualification gate
- Measured Cpk below 1.0 on any critical electronics process chain for three consecutive months
- Coverage gain below 2 percentage points per year in the electronics family after 2038

##### Tripwires
- MonolithIC IC coverage below 50% of stratified target by 2037-12-31
- Electronics family Cpk below 1.33 for two consecutive gate reviews
- Contamination-related yield loss above 15% in any quarter after the ISO Class 1-2 retrofit deadline

##### Response Playbook
- Contain: Halt all capital releases for monolithIC IC process development and quarantine non-performng electronics process chains pending a yield autopsy.
- Assess: Commission an independent yield-learning-curve audit and recompute the 95% denominator with stratified coverage targets per technology family.
- Respond: Descope monolithIC ICs from the in-factory claim, redefine the factory as an advanced-packaging and system-integration facility, and re-sequence the coverage roadmap around proven process chains.


**STOP RULE:** Pivot the programme's core value proposition if electronics first-pass yield cannot reach 80% FPY and Cpk >= 1.33 by 2037-12-31, or if audited coverage in the electronics family remains below 50% of the 95% denominator at the 2040 gate.

---

#### FM3 - The Border That Closed the Factory

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Cross-Border Legal, Regulatory & Export Control Lead / Export Control and Technology Transfer Director
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
By 2029, the border had become the factory's most important component. The technology-transfer matrix was completed only after the SPV was signed, and it revealed what engineering-led planning had ignored: the lithography source, process recipes, CAD files, and even the digital twin itself were controlled under EU Dual-Use Regulation 2021/821, Wassenaar, and MTCR-adjacent national lists. BAFA classified the space-rated propulsion manufacturing cell as a military item under national export law. SECO and CDIU issued preliminary opinions that cross-border movement of metrology data would require end-user undertakings for every third-country national who touched the system, including the Swiss phD student from India who had built the adaptive-control model. The federated digital twin was quarantined for 11 months pending a deemed-export screening policy.

CERN's legal department concluded that its mandate covered fundamental science and knowledge transfer, not an industrial space-manufacturing node; the Geneva site had to pivot to a greenfield plot in the Pays de Gex, losing 18 months and EUR 6B. ASML and Zeiss, bound by their own export-control obligations and IP commitments, refused to contribute process recipes to the common interface register. The prime integrator's integration layer became a legal no-man's land. The programme's public credibility collapsed: annual demonstration days were cancelled, the 'European strategic autonomy' narrative was replaced by headlines about 'the factory that cannot share its own blueprints', and two anchor-customer LOIs from space agencies were withdraw. Private partners, told they could not access the very technology they had co-funded, walked away. By 2031 the federated model had degraded into four isolated national silos. A US startup and a Chinese state programme captured the emerging market for universal manufacturing, and the programme's only remaining option was a humiliating restructure into a purely intergovernmental, non-commercial propulsion project—the exact outcome the public-private model was designed to avoid.

##### Early Warning Signs
- License applications pending beyond 18 months for any critical technology cluster at BAFA, CDIU, SECO, or SBDU/DGDDI
- CERN legal opinion failing to confirm participation by 2027-03-31
- Partner technology-sharing commitments below 50% of the contributed-technology schedule by 2027-06-30

##### Tripwires
- A definitive export-control denial for lithography, propulsion, or robotic actuation issued by any national authority
- Digital-twin access blocked for more than 30 days due to deemed-export compliance at any site
- At least one anchor partner (ASML, Zeiss, Fraunhofer, or CERN) withdraws or restricts IP contribution beyond the agreed schedule

##### Response Playbook
- Contain: Issue a stop-work order on all cross-border transfers of controlled technology, quarantne affected items at originating sites, and direct non-controlled workstreams to continue.
- Assess: Complete the Technology Transfer Matrix and Legal Makeability Map, obtain formal regulator pre-consulations in all four jurisdictions, and assess fallback sites and partner substitutions.
- Respond: Ring-fence space-rated propulsion under an intergovermental programme, remove unlicensable components from the 95% denominator, and replace lost partner capabilities via in-house development or alternative European partners.


**STOP RULE:** Terminate or restructure the programme if a final license denial blocks a critical technology cluster for more than 24 months, or if CERN and at least one other anchor partner cannot participate by 2028-06-30.

---

#### FM4 - The Empty Benches

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Knowledge, Talent & Workforce Continuity Lead
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The first cracks appeared not in hardware but in headcount. The 2027 critical-skill inventory had been signed off as complete, but it counted titles, not competence: 43 specialties had exactly one qualified practitioner, including maskless e-beam control software, cryogenic feedstock conditioning, and the purity-to-yield design-of-experiments that adaptive process control depended on. By 2029, the ASML and Zeiss ecosystems—simultaneously the programme's partners and its competitors—were offering 30-40% premiums for exactly these profiles. Retention bonuses were capped by the funding phasing rules because they competed with hardware capex in every tranche; three senior metrology engineers left within one quarter.

The consequences compounded in ways no attrition model had priced. Documentation lag reached 14 months behind live practice, so the digital twin encoded outdated process assumptions; a departing powder-metallurgy lead took with her the only working mental model of a segregation defect that was quietly capsuling structural components. Replacement hires took 18-24 months to reach competence against a 12-month plan. Three simultaneous single-point losses in 2030 stalled merge-gate preparation, and each lost specialty pushed milestones 1-2 years—delays that stacked, not averaged. The rotation programme, designed as insurance, spread the remaining seniors so thin across three sites that none could lead the hardest miniaturization problems. By 2033 the programme was paying EUR 2.5 billion per year above plan in premium salaries, re-training, and rework, while the workforce spent a third of its capacity re-learning what had already once been known. The contingency reserve, meant for breakthroughs, was consumed by institutional amnesia—and the gate-linked funding tranches began to slip because the evidence packages required to release them were owned by people who had left.

##### Early Warning Signs
- Any gate-critical specialty held by fewer than 2 named, trained practitioners for more than 30 days
- Annualized attrition among senior scarce-role engineers above 10% for two consecutive years
- Median time-to-competence for rotated staff above 12 months on any critical specialty
- Digital-twin documentation lag exceeding 6 months behind live shop-floor practice

##### Tripwires
- Attrition among critical-skill engineers exceeds 12% annualized for 2 consecutive quarters
- Any gate-critical specialty lacks a second trained practitioner for more than 90 days
- Documentation lag exceeds 9 months on any process chain flagged critical to the 2032 merge gate
- Cumulative staffing-driven schedule slip exceeds 12 months by 2030-12-31

##### Response Playbook
- Contain: Execute emergency retention packages and contractor backfills for every specialty with fewer than two practitioners, and freeze non-essential rotation of remaining seniors away from critical-path work.
- Assess: Run a 30-day critical-skill census against the redundancy map to quantify single-point dependencies, documentation lag, and time-to-competence gaps by specialty and site.
- Respond: Rebalance premium compensation toward the scarcest 20 specialties, convert every departure into a mandatory 60-day knowledge-capture sprint feeding the digital twin, and rebuild rotation so deputies do hands-on process work rather than shadowing only.


**STOP RULE:** Trigger a major pivot if any of the five gate-critical specialties—electronics lithography, feedstock conditioning, interface integration, metrology calibration, or ATEX safety—has zero qualified practitioners for more than 180 days, or if staffing-driven schedule slip cumulatively exceeds 36 months.

---

#### FM5 - The Purity Cliff

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Supply Chain and Procurement Lead with the Feedstock Resilience and Adaptive Process Control team
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
Structural brackets and gearboxes came off the line beautifully. The trouble began when the sensor and electronics families entered qualification in 2034 and the factory's inputs stopped behaving like the samples in the validation lab. A consolidation wave had left a single qualified European supplier for one 9N-purity process gas precursor and one alloy powder family; when an energy-price spike and a new export restriction on specialty gases hit that supplier, batch purity began drifting outside family tolerance windows on 14% of lots. The purity-to-yield sensitivity matrix—the one that was supposed to make feedstock variation harmless—had only ever been validated for 6 of 10 process families. For lithography and etch, the failure modes were pattern collapse and via poisoning: multivariate, non-linear, and invisible to in-line spectroscopy.

Adaptive control compensated for two quarters, then stopped. Scrap and rework on the electronics chain climbed to 29%, and escaped defects began surfacing at final assembly where rework cost 20x the early-rejection price. The engineering answer was a centralized conditioning and purification facility—scheduled for 2039, needed in 2036—which consumed EUR 5 billion unplanned and stole floor area from the miniaturized module line. Then the logistics dimension detonated: a three-month stockpile, half the required depth, evaporated in 11 weeks when industrial action closed the Rotterdam corridor, idling two production families for 4 months. The 2037 integrated demonstration slipped 2 years, the stratified coverage dashboard went red on two families simultaneously, and the makeability map's optimistic tolerance windows were exposed as laboratory fiction. By 2040, feedstock-driven requalification had consumed 3 years of the coverage-qualification phase, and the 95% certification target had become arithmetically unreachable.

##### Early Warning Signs
- Fewer than 2 qualified suppliers for any critical feedstock, reagent, or process-gas class
- Lot purity variance exceeding family tolerance windows on more than 10% of incoming batches in a quarter
- Scrap and rework rate above 15% on any qualified process chain for two consecutive months

##### Tripwires
- Qualified-supplier count falls to 1 for any gate-critical input class
- Strategic stockpile coverage drops below 6 months for any critical input
- Feedstock-driven yield loss exceeds 15% in any certified process chain for a full quarter
- Unplanned feedstock conditioning capex exceeds EUR 2B above the approved baseline

##### Response Playbook
- Contain: Ration stockpiles to gate-critical process chains, freeze new production starts on affected families, and quarantine every batch outside tolerance before it reaches the line.
- Assess: Run emergency supplier audits and re-qualify the purity-to-yield matrix across all 10 process families to isolate which tolerance windows and control loops actually failed.
- Respond: Activate dual-source qualification and centralized conditioning capacity on an accelerated schedule, renegotiate long-term contracts with price-indexation and delivery-guarantee clauses, and re-sequence coverage blocks around inputs that remain available and proven.


**STOP RULE:** Halt the affected production phase and re-architect the feedstock strategy if any gate-critical input class has zero qualified suppliers for more than 120 days, or feedstock-driven yield loss exceeds 30% on any certified process chain for two consecutive quarters.

---

#### FM6 - The Referendum Nobody Planned

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Stakeholder and Political Engagement Lead with the Site Development and Construction Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
Opposition did not arrive as a referendum; it arrived as a photograph. During 2031 commissioning at the Geneva-node site in Pays de Gex, a powder-transfer spill of 200 kilograms—no injuries, no off-site release—was filmed by a drone hobbyist and paired with a leaked internal slide showing 'ATEX Zone 21/22' 400 meters from a school. The framing wrote itself: a EUR 200 billion factory that makes components nobody asked for, next to vineyards and village schools. Environmental NGOs that had been lukewarm allies on sustainability KPIs turned adversarial when the water drawdown for closed-loop recycling was miscommunicated as aquifer depletion. Within two quarters, a social-listening sentiment index that had sat at 68 fell to 41.

The political chain reaction followed the legal one. A judicial review of the environmental permit suspended construction at the Geneva node for 14 months while a supplementary impact assessment was prepared; night-shift traffic and noise complaints were upheld at the German node, forcing operating-hour restrictions that broke the single-direction material-flow design. The EUR 2 billion community-benefit package, once an asset, was renegotiated upward by EUR 1.2 billion after local elections replaced two supportive mayors with opponents who campaigned against the project. Annual demonstration days became protest flashpoints; advisory-board attendance fell below half. National politics followed local politics: one host-country coalition renegotiated its SPV contribution, and the EU Chips Act realignment redirected near-term semiconductor funding toward existing fabs. Space agencies, watching the volatility, redirected precursor-mission partnerships to a competitor consortium. With the Geneva node frozen, the federated schedule misaligned irrecoverably, private investors invoked gate-failure clauses on the stalled node, and by 2041 the programme survived only as a consolidated single-site operation whose 'universal factory' story the public no longer believed.

##### Early Warning Signs
- Public-consultation opposition above 25% of respondents at any node
- A judicial review or formal appeal filed against any construction or environmental permit
- Community advisory-board attendance below 60% for two consecutive quarters
- Social-listening sentiment index below 45/100 for two consecutive quarters at any site

##### Tripwires
- Any construction or environmental permit suspended or under judicial review for more than 90 days
- A single public consultation draws more than 1,000 registered opponents at any node
- Community-benefit renegotiation demands exceed EUR 1B above the EUR 2B allocated envelope
- Two of three sites register sentiment index below 40/100 in the same quarter

##### Response Playbook
- Contain: Suspend the triggering activity—night logistics, the implicated process cell, or the contested construction package—at the affected node within 14 days and open direct negotiation with opposing municipalities and NGO coalitions.
- Assess: Commission an independent social-license and permit-risk audit to quantify which permits, operations, or site elements are blocking, and what redesign or compensation measurably closes the gap.
- Respond: Redesign contested elements (noise, traffic, water, powder logistics), accelerate community-benefit investment at the affected node, and re-sequence construction so the opposition-prone node decouples from the critical path while permits are rebuilt.


**STOP RULE:** Cancel or relocate the affected node if a construction or environmental permit remains suspended for more than 12 months, if community-benefit renegotiation demands exceed EUR 1B above the EUR 2B envelope, or if two of three sites simultaneously lose municipal political support.

---

#### FM7 - The Green Mandate Bubble

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Safety, Environmental & Sustainability Lead
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
By 2035, the factory's sustainability department had become its most expensive problem. The assumption that waste-heat recovery could reach 80% and water recycling 90% without compromising throughput was validated in early simulations that ignored the reality of 24/7 powder-handling and lithography loads. When the first integrated line began full operation, furnace exhaust heat fluctuated violently with batch sintering cycles, and the centralized heat-recovery loop's thermal storage was undersized by a factor of four. To meet the net-zero operational carbon gate, the programme had to buy green-hydrogen backup and gold-standard carbon credits, adding EUR 1.8 billion in annual operating costs that the real-euro baseline had never priced.

Simultaneously, the assumption that 100% renewable electricity by 2035 could be secured with signed PPAs collapsed: the local grid operator at the German node had a 7-year connection queue for industrial-scale renewables, and the Dutch site's offshore wind PPA was withdrawn due to permitting appeals. The programme fell back to bilateral contracts at an average EUR 72/MWh, 44% above the assumed EUR 50/MWh cap. The contingency reserve, which was supposed to fund technical breakthroughs, was drained by energy and water-compliance overruns. By 2038, cumulative additional environmental capex reached EUR 9 billion, triggering a renegotiation of member-state contributions and forcing a 5% scope reduction in the propulsion qualification block. The sustainability KPIs—the programme's public face—became a source of audit non-conformances and greenwashing accusations, eroding political support exactly when the 2042 coverage certification needed regulator goodwill.

##### Early Warning Signs
- Waste-heat recovery efficiency below 70% in any full-integration trial by 2030
- Water recycling rate below 80% in any 90-day continuous operation period
- Renewable PPA price above EUR 55/MWh in any executed contract for the 50 MW capacity
- Grid-connection lead time exceeding 4 years at any site in utility capacity audits

##### Tripwires
- Unplanned environmental capex exceeds EUR 3B above the approved baseline by 2032-12-31
- Renewable PPA costs exceed EUR 55/MWh for more than 25% of required capacity at any site
- Any site misses its net-zero operational carbon milestone by more than 2 years
- Annual environmental operating costs exceed EUR 1B for two consecutive years after 2035

##### Response Playbook
- Contain: Suspend non-critical sustainability pilots and reallocate the environmental budget to the highest-risk compliance gaps, prioritizing permits and grid connections at the node closest to operational readiness.
- Assess: Commission an independent energy-and-resource audit to quantify the real capex and opex of meeting each sustainability KPI under substitute technology mixes (e.g., on-site storage, third-party PPAs, co-generation) against the current baseline.
- Respond: Renegotiate the sustainability roadmap to a compliance-first plan, shifting the net-zero target from 2040 to 2043, and fund the gap by accelerating licensed-module revenues from already-qualified coverage blocks.


**STOP RULE:** Trigger a major pivot if cumulative environmental compliance costs exceed EUR 15B above the real-euro baseline by 2038, or if any site loses its construction or environmental permit due to sustainability non-compliance, or if renewable PPA costs exceed EUR 70/MWh for more than 50% of required capacity.

---

#### FM8 - The Interface Earthquake

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Factory Systems, Interface & Digital Integration Architect
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
In 2027, the interface register v1.0 passed its joint integration review with only two non-conformances, both resolved within 30 days. The digital twin, the prime-integrator layer, and the OPC UA handshakes worked flawlessly in simulation. By 2031, however, the register had become a living document—but only in the sense that it kept changing. As the miniaturized prototype track pushed for smaller connectors and tighter power delivery, the interface working group amended the mechatronic docking specification 14 times in 14 months. Each amendment required every partner to re-simulate; ASML and Zeiss, both legally restricted in their cross-border data sharing, fell behind on the digital-twin synchronization. The prime integrator's integration layer, which was supposed to translate between modules, was built on the original v1.0 definitions and could not keep pace with the amendments. When the CERN-adjacent node shipped its first fully assembled module to Veldhoven in early 2033, the mechanical vacuum flange did not mate with the ASML-built transfer port—a 4-millimeter offset that had been added in revision 1.8 but never propagated to the CAM files. The integration schedule absorbed a 15-month retrofit, EUR 2.3 billion in unplanned machining and re-certification, and the substitution of a custom translation ring that permanently reduced throughput by 8%.

The digital twin, meanwhile, had bifurcated: each site ran its own version of the data model, and the master twin had to be manually reconciled weekly. The prime integrator's team spent more time negotiating data-format conversion than testing hardware. By 2035, 11% of all modules required manual interface rework at installation, and the federated network that was supposed to operate as one factory functioned as four compatible-but-not-tonal nodes. The 2037 integrated demonstration was delayed by 22 months, and the coverage qualification phase absorbed the buffer that was supposed to protect the 2042 certification date. The failure cascaded into the market: anchor customers, who had been promised turnkey factory modules, saw integration risk priced into every contract and reduced their licensing commitments by 25%. The programme survived, but the promise of 'parallel development across European centres' was quietly replaced by 'sequential integration with heroic retrofits.'

##### Early Warning Signs
- More than 3 interface specification revisions per quarter in any module family
- Any compliance simulation failing against the current interface register baseline at a partner site
- Digital-twin data-model divergence across sites exceeding 5% in periodic reconciliation audits

##### Tripwires
- Interface register revisions exceeding 10 in a single calendar year
- Manual interface rework required on more than 5% of installed modules at any node
- Digital-twin reconciliation time exceeding 20 hours per week
- Any module failing mechanical/electrical mating during factory acceptance testing

##### Response Playbook
- Contain: Freeze all non-safety-critical interface revisions for 6 months, issue a mandatory re-baseline of the digital twin across all sites, and quarantine any module that deviates from the frozen register.
- Assess: Run a full interface-conformance audit on every fabricated module and every active data handshake to map the exact retrofit scope, including cost, schedule impact, and which partners hold the non-conforming versions.
- Respond: Enforce the frozen baseline for all new hardware, establish a central interface arbitration board with authority to deny revisions, and re-sequence the integration plan to group modules by revision cohort to minimize retrofit complexity; invest in a translation layer that can absorb residual non-conformances only if cost-benefit analysis shows it cheaper than rework.


**STOP RULE:** Trigger a major pivot if interface-driven retrofit costs exceed EUR 8B cumulatively, if the integrated schedule slips more than 3 years from the baseline due to interface non-conformances, or if any partner site withdraws from the common interface register.

---

#### FM9 - The Silence of the Anchor Customers

- **Archetype**: Market/Human
- **Root Cause**: Assumption A8
- **Owner**: Commercialisation and Licensing Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
By 2028, the killer-application task force had not produced a single letter of intent. The advanced-packaging sensor module, the leading candidate, was benchmarked against imec and Fraunhofer products that were already cheaper, qualified, and in volume. The robotic actuator gearbox, the macro-track's star, was dismissed by defense and space customers as 40% heavier and 30% costlier than existing precision actuators from European SMEs. The FPGA story, still central to the public pitch, had been quietly descoped internally, but no alternative narrative had been built. The market study commissioned by the Commercialisation Lead showed the total addressable licensing revenue across all candidate applications at EUR 92 billion over 20 years—60% below the EUR 150 billion needed to support the assumed royalty rates and the 8-10% IRR demanded by private investors.

Private capital, which had been conditioned on anchor LOIs, quickly faded. The 30% private-share target was revised to 14%, adding EUR 32 billion to the public funding gap and forcing the 5-year drawdown to be compressed into 4 years, which caused cash-flow strains and staffing cuts at the least-resourced site. The first integrated demonstration was continually pushed back to satisfy investor demands for 'market-ready products,' but each pivot moved further from the original universal-manufacturing vision. Politicians who had sold the programme to their constituents as 'the factory that makes everything' watched the narrative morph into 'an expensive facility with a niche product nobody wants.' The resulting loss of political credibility compounded every other risk: permit appeals multiplied, partner institutions distanced themselves, and the space-agency partnerships that had once anchored the precursor story were snapped up by a US-based rival offering a more pragmatic in-orbit servicer. The programme limped toward the 2037 demonstration, but the demonstration itself felt meaningless—a sensor module that could be bought off the shelf for 5% of the cost it took to manufacture in-factory. The market had whispered its verdict, and the programme had built a €200B solution to a problem nobody was willing to pay to solve.

##### Early Warning Signs
- Fewer than 2 anchor customer LOIs signed by 2027-06-30
- Market sizing showing total licensing revenue below EUR 150B in the 20-year model
- Zero killer-application demonstration built by 2030-12-31

##### Tripwires
- No single anchor customer LOI signed by 2027-12-31
- Market-sizing report showing addressable revenue below EUR 100B
- Private capital share below 20% of committed funding by 2029-12-31
- The 2032 merge gate is passed without any external customer commitment to the demonstrated technology

##### Response Playbook
- Contain: Suspend further scaling of low-demand process chains, pivot the killer-app task force away from internal feature-gratifications toward documented customer interviews, and publicly reposition the programme around exportable factory modules rather than end-products.
- Assess: Commission a joint independent market and technology audit to identify which combination of customer segments (distributed manufacturing, defense logistics, in-orbit servicing, disaster relief) maximizes licensing willingness-to-pay; quantify the minimum factory capability required to serve that segment.
- Respond: Re-scope the 95% denominator to focus on the component classes demanded by the validated anchor segment, negotiate government-backed advance purchase commitments as a substitute for private LOIs, and restructure the licensing model to include upfront minimums and milestone payments to re-baselining the private capital target.


**STOP RULE:** Trigger a major pivot if no anchor customer LOI is secured by 2028-12-31, or if the independently validated total addressable licensing revenue falls below EUR 80B over the 20-year horizon, or if private capital share remains below 10% by 2030-06-30.
