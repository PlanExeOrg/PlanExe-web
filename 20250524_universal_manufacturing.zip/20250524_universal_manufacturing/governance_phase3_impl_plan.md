### 1. SPV Founding Shareholder Group ratifies the governance formation mandate, appoints an Interim Programme Director to act as Formation Lead, and authorises the Governance Implementation Workstream to establish the six internal governance bodies.

**Responsible Body/Role:** SPV Founding Shareholder Group (intergovernmental sponsor authority)

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Formation mandate resolution
- Interim Programme Director appointment letter
- Governance implementation workstream charter

**Dependencies:**

- Intergovernmental SPV agreement signed
- Four sovereign partners confirmed
- Programme kick-off authorisation received

### 2. Interim Programme Director, supported by SPV Legal Counsel, drafts the Governance Implementation Charter defining the establishment sequence, appointment authorities, target dates, dependencies, and delegated powers for each governance body.

**Responsible Body/Role:** Interim Programme Director and SPV Legal Counsel

**Suggested Timeframe:** Project Week 1-2

**Key Outputs/Deliverables:**

- Draft Governance Implementation Charter v0.1

**Dependencies:**

- Interim Programme Director appointed
- Governance body mandate agreed

### 3. SPV Founding Shareholder Group reviews and approves the Governance Implementation Charter and formally authorises the establishment of the Programme Steering Committee (PSC) as the first internal governance body.

**Responsible Body/Role:** SPV Founding Shareholder Group

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Approved Governance Implementation Charter
- Formal authorisation to form the PSC

**Dependencies:**

- Draft Governance Implementation Charter submitted

### 4. SPV Legal Counsel, instructed by the SPV Founding Shareholder Group, drafts the Programme Steering Committee Terms of Reference including responsibilities, decision rights, decision mechanism, meeting cadence, escalation path, and conflicts-of-interest policy.

**Responsible Body/Role:** SPV Legal Counsel

**Suggested Timeframe:** Project Week 2-3

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1
- Draft PSC conflicts-of-interest policy

**Dependencies:**

- Governance Implementation Charter approved
- PSC formation authorised

### 5. SPV Founding Shareholder Group and private consortium partners nominate the four sovereign shareholder representatives and the private consortium investor representative to the PSC, and the European Commission is invited to nominate a non-voting observer.

**Responsible Body/Role:** SPV Founding Shareholder Group and Private Consortium Partners

**Suggested Timeframe:** Project Week 3-4

**Key Outputs/Deliverables:**

- Confirmed PSC nominee list
- Signed nomination forms
- European Commission observer invitation

**Dependencies:**

- Draft PSC ToR v0.1 available
- PSC membership criteria agreed

### 6. SPV Founding Shareholder Group completes the external search and due diligence and formally appoints the independent external PSC Chair and two independent non-executive directors, obtaining signed conflicts-of-interest declarations.

**Responsible Body/Role:** SPV Founding Shareholder Group

**Suggested Timeframe:** Project Week 4-5

**Key Outputs/Deliverables:**

- PSC Chair appointment letter
- Independent non-executive director appointment letters
- Signed conflicts-of-interest declarations

**Dependencies:**

- PSC nominee list received
- External search completed
- Due-diligence clearances obtained

### 7. Interim Programme Director and SPV CFO prepare the PSC inaugural pack including the final PSC ToR v1.0, EUR 200 billion 2026 real-euro baseline, draft risk appetite statement, programme governance charter, and proposed quarterly meeting calendar.

**Responsible Body/Role:** Interim Programme Director and SPV CFO

**Suggested Timeframe:** Project Week 4-5

**Key Outputs/Deliverables:**

- PSC inaugural pack v0.9
- Draft risk appetite statement
- Proposed PSC quarterly calendar

**Dependencies:**

- PSC Chair and independent directors appointed
- Draft PSC ToR finalised

### 8. SPV Founding Shareholder Group reviews and approves the final PSC ToR v1.0 and the PSC inaugural pack, and authorises the PSC to convene its inaugural meeting.

**Responsible Body/Role:** SPV Founding Shareholder Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Approved PSC ToR v1.0
- Approved PSC inaugural pack
- Authorisation to convene the PSC

**Dependencies:**

- PSC inaugural pack prepared
- PSC appointments completed

### 9. Hold the PSC inaugural meeting: adopt the PSC ToR v1.0, elect the vice-chair, approve the EUR 200 billion 2026 real-euro baseline, risk appetite statement, programme governance charter, quarterly meeting calendar, and classified reporting channel.

**Responsible Body/Role:** PSC (inaugural meeting chaired by the newly appointed independent Chair)

**Suggested Timeframe:** Project Week 5-6

**Key Outputs/Deliverables:**

- Adopted PSC ToR v1.0
- Elected PSC vice-chair
- Approved EUR 200 billion real-euro baseline
- Approved risk appetite statement
- Approved programme governance charter
- PSC meeting minutes with action items

**Dependencies:**

- PSC ToR and inaugural pack approved by SPV Founding Shareholder Group
- PSC members, Chair, and independent directors appointed

### 10. PSC confirms the mandate, authority, and formation directives for the Programme Management Office (PMO), Technical Advisory Group (TAG), Ethics and Compliance Committee (ECC), Audit and Risk Assurance Committee (ARAC), and Stakeholder Engagement and Social License Advisory Group (SESLAG), setting nomination and ToR deadlines.

**Responsible Body/Role:** PSC

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Confirmed mandates for all five standing bodies
- Formation directives
- Nomination and ToR deadline schedule

**Dependencies:**

- PSC inaugural meeting completed
- Programme governance charter approved

### 11. Interim Programme Director, as PMO Chair-designate, finalises the PMO ToR, project-management methodology, delegation thresholds, escalation criteria, and decision templates, incorporating the PSC formation directives.

**Responsible Body/Role:** Interim Programme Director (PMO Chair-designate)

**Suggested Timeframe:** Project Week 6-7

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.3
- Delegation and escalation framework
- PMO project-management methodology summary

**Dependencies:**

- PSC formation directives issued

### 12. PSC approves the PMO ToR v1.0 and formally appoints or confirms the PMO membership, including the Programme Director as Chair, Deputy Programme Director, Heads of Project Controls, Engineering and Technical Integration, Procurement, Finance, Risk, Digital and Information Systems, Site Operations Leads, Prime Integrator Programme Manager, and Ethics and Compliance liaison.

**Responsible Body/Role:** PSC

**Suggested Timeframe:** Project Week 7-8

**Key Outputs/Deliverables:**

- Approved PMO ToR v1.0
- PMO appointment letters
- PMO organisation chart and role descriptions

**Dependencies:**

- PMO ToR draft finalised
- PSC approval slot available

### 13. Hold the PMO kick-off meeting and first integrated delivery review: adopt the PMO ToR, confirm delegated authorities, and assign initial ownership for the integrated master schedule, cost baseline, risk register, interface register, makeability map, and dashboard configuration.

**Responsible Body/Role:** PMO (kick-off meeting chaired by the Programme Director)

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Adopted PMO operating procedures
- PMO meeting minutes with action items
- PMO workstream ownership matrix

**Dependencies:**

- PSC approval of PMO ToR and membership

### 14. PMO operationalises the integrated management system: create the integrated master schedule, 2026 real-euro cost baseline, single operational risk register, controlled interface register, makeability map, coverage and yield metrics, and digital-twin, MES, and ERP reporting dashboards.

**Responsible Body/Role:** PMO (Head of Project Controls and Head of Digital and Information Systems under the Programme Director)

**Suggested Timeframe:** Project Week 8-12

**Key Outputs/Deliverables:**

- Integrated master schedule v0.1
- 2026 real-euro cost baseline v1.0
- Operational risk register v0.1
- Controlled interface register v0.1
- Makeability map v0.1
- Dashboard prototypes

**Dependencies:**

- PMO kick-off meeting held
- Programme baseline data available from project plan

### 15. SPV Chief Engineer (designate) and Interim Programme Director draft the TAG ToR, expert role profiles, independence and conflicts-of-interest criteria, and a draft technical gate review calendar aligned to the 2026-2046 programme phases.

**Responsible Body/Role:** SPV Chief Engineer (designate) and Interim Programme Director

**Suggested Timeframe:** Project Week 6-8

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.2
- Expert selection and independence criteria
- Draft technical gate review calendar

**Dependencies:**

- PSC formation directives issued
- Initial makeability map and TRL inventory available

### 16. PSC approves the TAG ToR v1.0 and appoints a TAG selection panel, chaired by an independent PSC non-executive director, to run the search for an independent Chair and 8-12 external experts from non-partner institutions.

**Responsible Body/Role:** PSC

**Suggested Timeframe:** Project Week 8-9

**Key Outputs/Deliverables:**

- Approved TAG ToR v1.0
- TAG selection panel membership
- Search mandate and expert role specifications

**Dependencies:**

- Draft TAG ToR submitted
- Expert selection criteria agreed

### 17. TAG selection panel completes candidate identification, due diligence, and reference checks, and submits a recommended slate of TAG Chair and independent experts to the PSC for formal appointment.

**Responsible Body/Role:** TAG selection panel (temporary, chaired by PSC independent non-executive director)

**Suggested Timeframe:** Project Week 9-11

**Key Outputs/Deliverables:**

- Recommended TAG membership slate
- Due-diligence summaries
- Independence and conflict-of-interest declarations

**Dependencies:**

- TAG selection panel appointed
- Search mandate approved

### 18. PSC formally appoints the TAG Chair and independent expert members, and confirms the Programme Chief Engineer as technical secretary and the PMO representative as non-voting observer.

**Responsible Body/Role:** PSC

**Suggested Timeframe:** Project Week 11-12

**Key Outputs/Deliverables:**

- TAG appointment letters
- Signed confidentiality agreements
- Final TAG membership list

**Dependencies:**

- Recommended TAG slate received
- Independence checks cleared

### 19. Hold the TAG inaugural meeting: adopt the TAG ToR and confidentiality and conflict-of-interest guidelines; review the initial makeability map, TRL inventory, yield assumptions, and coverage sequencing; and validate the technical gate review calendar.

**Responsible Body/Role:** TAG (inaugural meeting chaired by the independent TAG Chair)

**Suggested Timeframe:** Project Week 12-14

**Key Outputs/Deliverables:**

- Adopted TAG operating guidelines
- Initial TAG technical risk assessment
- Validated technical gate review calendar
- TAG meeting minutes with action items

**Dependencies:**

- TAG members formally appointed
- Makeability map v0.1 and operational risk register available

### 20. SPV Chief Compliance Officer (designate) and SPV Legal Director draft the ECC ToR, code of conduct, conflicts-of-interest policy, anti-corruption programme, GDPR data-governance framework, and an initial compliance risk assessment plan covering all host-country sites.

**Responsible Body/Role:** SPV Chief Compliance Officer (designate) and SPV Legal Director

**Suggested Timeframe:** Project Week 6-8

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.2
- Draft code of conduct
- Compliance risk assessment plan
- Whistleblower framework design

**Dependencies:**

- PSC formation directives issued
- Regulatory and export-control baseline established

### 21. PSC approves the ECC ToR v1.0, appoints the independent external ECC Chair and two independent external compliance and data-protection experts, and confirms the SPV Chief Compliance Officer as executive secretary and host-country export-control liaison officers as non-voting members.

**Responsible Body/Role:** PSC

**Suggested Timeframe:** Project Week 8-10

**Key Outputs/Deliverables:**

- Approved ECC ToR v1.0
- ECC appointment letters
- Host-country liaison nominations
- Signed conflicts-of-interest declarations

**Dependencies:**

- Draft ECC ToR submitted
- Candidate due diligence completed

### 22. Hold the ECC inaugural meeting: adopt the ECC ToR and compliance policies, establish the joint compliance office, launch the independent whistleblower mechanism, and initiate the cross-border compliance risk assessment.

**Responsible Body/Role:** ECC (inaugural meeting chaired by the independent external Chair)

**Suggested Timeframe:** Project Week 10-12

**Key Outputs/Deliverables:**

- Adopted ECC ToR and policies
- Joint compliance office mandate
- Whistleblower mechanism launched
- Compliance risk assessment kickoff report

**Dependencies:**

- ECC members formally appointed
- Draft compliance policies approved by PSC

### 23. SPV Chief Risk Officer (designate) and SPV CFO draft the ARAC charter, risk taxonomy, enterprise risk-management methodology, internal and external audit scope, audit sampling plan for 95% coverage claims, and EUR/CHF hedging review terms.

**Responsible Body/Role:** SPV Chief Risk Officer (designate) and SPV CFO

**Suggested Timeframe:** Project Week 6-8

**Key Outputs/Deliverables:**

- Draft ARAC charter v0.2
- Risk taxonomy v0.1
- Proposed audit and hedging review scope

**Dependencies:**

- PSC formation directives issued
- PSC risk appetite statement approved

### 24. PSC approves the ARAC charter v1.0, appoints the independent external ARAC Chair and two independent external members, and confirms the sovereign shareholders audit representative, SPV CFO, SPV CRO, and Internal Audit Director as non-voting attendees.

**Responsible Body/Role:** PSC

**Suggested Timeframe:** Project Week 8-10

**Key Outputs/Deliverables:**

- Approved ARAC charter v1.0
- ARAC appointment letters
- Non-voting participant confirmations

**Dependencies:**

- Draft ARAC charter submitted
- Candidate due diligence completed

### 25. Hold the ARAC inaugural meeting: adopt the ARAC charter, approve the enterprise risk register and risk methodology, approve the external audit procurement process, and commission the first financial-control audit and EUR/CHF hedging policy review.

**Responsible Body/Role:** ARAC (inaugural meeting chaired by the independent ARAC Chair)

**Suggested Timeframe:** Project Week 10-12

**Key Outputs/Deliverables:**

- Adopted ARAC charter
- Approved risk methodology
- External audit procurement plan
- Terms of reference for first financial-control and hedging reviews

**Dependencies:**

- ARAC members formally appointed
- Risk taxonomy and PSC risk appetite available

### 26. ARAC, supported by PMO Procurement, runs the external auditor selection within PSC-approved parameters, evaluates tenders, and appoints the SPV external auditor.

**Responsible Body/Role:** ARAC (supported by PMO Procurement)

**Suggested Timeframe:** Project Week 12-14

**Key Outputs/Deliverables:**

- Tender evaluation summary
- External auditor appointment letter
- Signed external audit engagement contract

**Dependencies:**

- ARAC inaugural meeting held
- PSC procurement parameters defined

### 27. Programme Communications Director (designate) and PMO liaison draft the SESLAG ToR, stakeholder engagement and transparency plan, social-license indicators, and community-benefit allocation process.

**Responsible Body/Role:** Programme Communications Director (designate) and PMO liaison

**Suggested Timeframe:** Project Week 6-8

**Key Outputs/Deliverables:**

- Draft SESLAG ToR v0.2
- Stakeholder engagement and transparency plan
- Social-license KPI definitions
- Community-benefit allocation process draft

**Dependencies:**

- PSC formation directives issued
- Stakeholder analysis from project plan available

### 28. PSC approves the SESLAG ToR v1.0 and membership categories; host governments, local communities, environmental NGOs, private investors, and future licensees submit nominations for external members.

**Responsible Body/Role:** PSC with host-government liaison officers and external stakeholder groups

**Suggested Timeframe:** Project Week 8-10

**Key Outputs/Deliverables:**

- Approved SESLAG ToR v1.0
- Membership category guidance
- Received stakeholder nominations

**Dependencies:**

- Draft SESLAG ToR submitted
- PSC approval available

### 29. PSC appoints the independent external SESLAG Chair and confirms the external members, the Programme Communications Director as secretary, and government liaison officers as non-voting members.

**Responsible Body/Role:** PSC

**Suggested Timeframe:** Project Week 10-12

**Key Outputs/Deliverables:**

- SESLAG appointment letters
- Confirmed SESLAG membership
- Signed conflicts-of-interest declarations

**Dependencies:**

- SESLAG nominations received
- Independent Chair due diligence completed

### 30. Hold the SESLAG inaugural meeting and form the three site-level advisory boards near Geneva/CERN, Veldhoven/ASML, and Oberkochen/Zeiss-Fraunhofer; approve baseline sentiment assessments, the community-benefit allocation process, and the 2027 public engagement calendar.

**Responsible Body/Role:** SESLAG (inaugural meeting chaired by the independent SESLAG Chair) with site-level engagement leads

**Suggested Timeframe:** Project Week 12-14

**Key Outputs/Deliverables:**

- Adopted SESLAG ToR
- Three site-level advisory boards established
- Baseline sentiment assessments commissioned
- Approved community-benefit allocation process
- 2027 public engagement calendar

**Dependencies:**

- SESLAG members appointed
- Site-level board nominations received

### 31. PSC holds its first quarterly governance review, ratifies the establishment of all five standing committees, approves the consolidated decision-rights matrix, and aligns committee calendars and reporting schedules with the master programme schedule.

**Responsible Body/Role:** PSC

**Suggested Timeframe:** Project Week 14-16

**Key Outputs/Deliverables:**

- Approved consolidated decision-rights matrix
- Formal governance framework v1.0
- Harmonised meeting calendar
- PSC ratification minutes

**Dependencies:**

- All standing committees held inaugural meetings
- PSC quarterly review scheduled

### 32. PMO Governance Secretariat publishes a governance induction pack and runs a joint orientation session for PSC and standing-committee chairs, secretaries, and members to standardise operating procedures, escalation paths, and reporting templates.

**Responsible Body/Role:** PMO Governance Secretariat

**Suggested Timeframe:** Project Week 14-18

**Key Outputs/Deliverables:**

- Governance induction pack
- Joint orientation session materials
- Common reporting templates
- Escalation path quick-reference guide

**Dependencies:**

- Formal governance framework v1.0 approved
- Committee secretariats designated

### 33. PSC and standing committees activate the standing reporting cadence: PSC quarterly, PMO weekly and monthly, TAG quarterly with pre-gate deep-dive panels, ECC monthly, ARAC quarterly, and SESLAG bi-monthly with monthly site-level advisory boards; dashboards are integrated into the digital twin platform.

**Responsible Body/Role:** PMO Governance Secretariat with all governance bodies

**Suggested Timeframe:** Project Week 16-18

**Key Outputs/Deliverables:**

- Standing committee calendars
- Standing agenda templates
- Dashboard access and reporting schedule
- Digital-twin reporting integration

**Dependencies:**

- Formal governance framework v1.0 approved
- PMO dashboards operational