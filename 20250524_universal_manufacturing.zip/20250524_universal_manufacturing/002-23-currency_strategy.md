This plan involves money.

## Currencies

- **EUR:** The project budget is defined in EUR, and the project is located in Europe.
- **CHF:** One location is in Switzerland.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting. Local currencies (CHF) may be used for local transactions. No additional international risk management is needed within the Eurozone.