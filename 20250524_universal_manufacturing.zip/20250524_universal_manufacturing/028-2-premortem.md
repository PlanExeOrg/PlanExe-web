A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The cost of raw materials will remain stable throughout the project's 20-year duration. | Obtain long-term price forecasts for key raw materials from multiple independent sources. | Forecasts indicate a cumulative price increase of >25% for key raw materials over the next 10 years. |
| A2 | The required level of expertise in advanced manufacturing techniques is readily available within the EU labor market. | Conduct a detailed skills gap analysis for key roles (e.g., additive manufacturing specialists, robotics engineers) within the EU. | The skills gap analysis reveals a shortage of qualified candidates for >50% of key roles, with an average recruitment time exceeding 6 months. |
| A3 | The project will be able to secure all necessary regulatory approvals and permits within a reasonable timeframe (<= 12 months). | Engage with relevant regulatory agencies to obtain preliminary feedback on the project's environmental and safety plans. | Regulatory agencies indicate significant concerns regarding the project's environmental impact or safety protocols, suggesting a high likelihood of delays or permit denials. |
| A4 | The modular design of the factory system will allow for easy and rapid reconfiguration to manufacture different types of components. | Develop a detailed reconfiguration plan for switching production between two significantly different component types (e.g., a sensor and a structural element). | The reconfiguration plan reveals significant challenges in terms of time, cost, or complexity, requiring >2 weeks and >EUR 500,000 to implement. |
| A5 | The project will be able to effectively integrate artificial intelligence (AI) and machine learning (ML) algorithms into the manufacturing processes to optimize performance and adapt to changing conditions. | Develop a prototype AI/ML algorithm for a specific manufacturing process (e.g., additive manufacturing layer optimization) and test its performance in a simulated environment. | The AI/ML algorithm fails to demonstrate a significant improvement in performance (e.g., >10% reduction in defects or cycle time) compared to traditional control methods. |
| A6 | The project will be able to maintain strong relationships with local communities and stakeholders throughout its 20-year lifespan. | Conduct a survey of local community members to assess their perceptions of the project and identify any concerns or potential sources of conflict. | The survey reveals significant negative perceptions of the project among local community members, with >30% expressing concerns about environmental impact, noise pollution, or traffic congestion. |
| A7 | The technology used in the modular factory will remain cutting-edge and competitive throughout the project's 20-year lifespan without requiring major, unforeseen technology overhauls. | Conduct a technology roadmap analysis, projecting the evolution of key manufacturing technologies (additive, subtractive, AI) over the next 5-10 years. | The roadmap analysis reveals a high likelihood of disruptive technologies emerging within 5 years that would render the current factory design obsolete without a major (>$50B) overhaul. |
| A8 | The project's reliance on a centralized management structure will ensure efficient decision-making and coordination across all project activities. | Conduct a simulation of a complex, multi-faceted project decision (e.g., responding to a major supply chain disruption) involving multiple teams and stakeholders. | The simulation reveals significant delays, communication breakdowns, or conflicting priorities, indicating that the centralized management structure is hindering efficient decision-making. |
| A9 | The components manufactured by the modular factory will meet the performance and reliability requirements for space-based applications. | Manufacture a prototype component (e.g., a sensor) using the modular factory and subject it to rigorous testing under simulated space conditions (vacuum, extreme temperatures, radiation). | The prototype component fails to meet key performance or reliability metrics under simulated space conditions, indicating that the manufacturing processes are not producing components suitable for their intended application. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Inflation Implosion | Process/Financial | A1 | Chief Financial Officer | CRITICAL (20/25) |
| FM2 | The Talent Tomb | Technical/Logistical | A2 | Human Resources Director | CRITICAL (15/25) |
| FM3 | The Regulatory Reef | Market/Human | A3 | Permitting Lead | CRITICAL (15/25) |
| FM4 | The Rigidity Trap | Process/Financial | A4 | Head of Engineering | CRITICAL (20/25) |
| FM5 | The AI Abyss | Technical/Logistical | A5 | Head of AI/ML Development | CRITICAL (15/25) |
| FM6 | The Community Crackdown | Market/Human | A6 | Community Relations Manager | CRITICAL (15/25) |
| FM7 | The Technological Tectonic Shift | Technical/Logistical | A7 | Chief Technology Officer | CRITICAL (15/25) |
| FM8 | The Bureaucratic Black Hole | Process/Financial | A8 | Chief Operating Officer | CRITICAL (20/25) |
| FM9 | The Space-Worthiness Mirage | Market/Human | A9 | Head of Quality Assurance | CRITICAL (15/25) |


### Failure Modes

#### FM1 - The Inflation Implosion

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Chief Financial Officer
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Unforeseen spikes in raw material costs, driven by global events or supply chain disruptions, erode the project's financial viability.  The initial budget was calculated based on current market prices, failing to account for long-term inflationary pressures.  As material costs escalate, the project is forced to make increasingly difficult trade-offs, reducing the scope of R&D activities, delaying infrastructure development, and ultimately compromising the system's capabilities.  The phased development approach, intended to mitigate technical risks, becomes a liability as each phase is more expensive than anticipated.  The project's reliance on a fixed budget and linear spending model proves unsustainable in the face of volatile market conditions.  The lack of a robust hedging strategy or alternative sourcing options exacerbates the problem, leading to a critical funding shortfall and project cancellation.

##### Early Warning Signs
- Key raw material prices increase by >10% within a single quarter.
- The project's procurement costs exceed budget projections by >15% for two consecutive quarters.
- Contingency funds are depleted by >50% within the first 5 years of the project.

##### Tripwires
- Cumulative raw material price increase >= 20% over initial projections.
- Procurement costs exceed budget by >= 25% for 2 consecutive quarters.
- Contingency fund balance <= 25% of original allocation.

##### Response Playbook
- Contain: Immediately freeze all non-essential spending and renegotiate existing contracts.
- Assess: Conduct a comprehensive cost-benefit analysis of all project activities, identifying areas for potential savings or scope reduction.
- Respond: Implement a hedging strategy to mitigate future price volatility and explore alternative, lower-cost materials.


**STOP RULE:** The projected ROI falls below 5% due to escalating raw material costs, rendering the project economically unviable.

---

#### FM2 - The Talent Tomb

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Human Resources Director
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project struggles to attract and retain qualified personnel with the specialized skills required for advanced manufacturing.  The initial assumption that a sufficient talent pool exists within the EU labor market proves false.  Competition from other high-tech industries and research institutions drives up salaries, exceeding the project's budget for personnel.  The lack of a comprehensive recruitment and retention strategy exacerbates the problem, leading to high turnover rates and a loss of critical expertise.  The project's reliance on external innovation centers becomes a vulnerability as the project lacks the internal expertise to effectively leverage their resources.  The phased development approach is hampered by a shortage of skilled engineers and scientists, delaying key milestones and compromising the system's technical capabilities.  The project's inability to build a strong internal team ultimately leads to its failure.

##### Early Warning Signs
- Recruitment time for key technical roles exceeds 6 months.
- Employee turnover rate for technical staff exceeds 15% per year.
- The project fails to meet key technical milestones for two consecutive quarters.

##### Tripwires
- Average time to fill key technical positions >= 9 months.
- Annual employee turnover rate for technical staff >= 20%.
- Project is > 6 months behind schedule on >= 2 critical technical milestones.

##### Response Playbook
- Contain: Immediately implement a hiring freeze for all non-critical positions and focus on retaining existing staff.
- Assess: Conduct a comprehensive review of the project's compensation and benefits packages, benchmarking against industry standards.
- Respond: Partner with universities and research institutions to develop specialized training programs and create a pipeline of qualified candidates.


**STOP RULE:** The project is unable to fill >50% of key technical roles after 12 months, rendering it impossible to achieve critical technical milestones.

---

#### FM3 - The Regulatory Reef

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Permitting Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project encounters significant delays and obstacles in securing the necessary regulatory approvals and permits for the manufacturing facility.  The initial assumption that approvals could be obtained within a reasonable timeframe proves overly optimistic.  Complex environmental regulations, safety standards, and data privacy laws create a bureaucratic maze that the project struggles to navigate.  Lack of proactive engagement with regulatory agencies and a failure to anticipate potential concerns exacerbate the problem.  The project's reliance on advanced manufacturing technologies raises novel regulatory challenges that require extensive testing and documentation.  The phased development approach is disrupted by permitting delays, pushing back key milestones and increasing costs.  The project's inability to secure timely regulatory approvals ultimately leads to its abandonment.

##### Early Warning Signs
- Permit applications are rejected or require significant revisions.
- Regulatory agencies request additional information or testing beyond initial expectations.
- The project faces legal challenges from environmental groups or local communities.

##### Tripwires
- Permit approvals delayed by >= 9 months beyond initial projections.
- Project receives >= 2 notices of non-compliance from regulatory agencies.
- Legal challenges from external parties result in a court injunction against project activities.

##### Response Playbook
- Contain: Immediately halt all activities that require regulatory approval and focus on addressing the identified concerns.
- Assess: Conduct a comprehensive review of the project's environmental and safety plans, identifying areas for improvement and compliance.
- Respond: Engage with regulatory agencies to negotiate a revised permitting timeline and explore alternative compliance strategies.


**STOP RULE:** The project is unable to secure key environmental permits after 18 months, rendering it impossible to construct and operate the manufacturing facility.

---

#### FM4 - The Rigidity Trap

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The modular design, initially intended for flexibility, proves cumbersome and difficult to reconfigure in practice.  Switching production between different component types requires extensive downtime, specialized expertise, and costly modifications.  The standardized interfaces, meant to simplify integration, become bottlenecks as they fail to accommodate the unique requirements of each component.  The project's reliance on a modular architecture backfires, as the cost and complexity of reconfiguration outweigh the benefits of flexibility.  The inability to rapidly adapt to changing market demands or technological advancements renders the factory system obsolete and uncompetitive.  The project's financial viability collapses as production costs escalate and revenue opportunities dwindle.

##### Early Warning Signs
- Reconfiguration time between component types exceeds initial projections by >50%.
- The cost of reconfiguration exceeds budget projections by >25%.
- The project fails to secure contracts for manufacturing a diverse range of components.

##### Tripwires
- Reconfiguration time >= 3 weeks for standard component switch.
- Reconfiguration costs >= EUR 750,000 per switch.
- Factory utilization rate <= 50% due to reconfiguration downtime.

##### Response Playbook
- Contain: Immediately halt all non-essential reconfiguration activities and focus on optimizing existing production lines.
- Assess: Conduct a thorough review of the modular design, identifying areas for simplification and standardization.
- Respond: Invest in developing automated reconfiguration tools and training programs to reduce downtime and improve efficiency.


**STOP RULE:** The cost of reconfiguration exceeds the potential revenue from manufacturing new component types, rendering the modular design economically unviable.

---

#### FM5 - The AI Abyss

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Head of AI/ML Development
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project struggles to effectively integrate AI and ML algorithms into the manufacturing processes.  The initial assumption that AI/ML could optimize performance and adapt to changing conditions proves overly optimistic.  The complexity of the manufacturing processes and the variability of the feedstock materials create challenges that the AI/ML algorithms are unable to overcome.  The lack of sufficient training data and the difficulty of interpreting AI/ML results further hinder progress.  The project's reliance on AI/ML backfires, as the algorithms generate inaccurate predictions, leading to manufacturing defects, process inefficiencies, and system instability.  The project's technical capabilities are compromised, and its ability to achieve its goals is severely diminished.

##### Early Warning Signs
- AI/ML algorithms fail to demonstrate a significant improvement in performance compared to traditional control methods.
- The project experiences unexplained manufacturing defects or process inefficiencies.
- The project struggles to collect and analyze sufficient training data for AI/ML algorithms.

##### Tripwires
- AI/ML algorithms fail to improve performance by >= 5% compared to baseline.
- Defect rate increases by >= 10% after AI/ML implementation.
- Data collection rate for AI/ML training falls below 75% of target.

##### Response Playbook
- Contain: Immediately revert to traditional control methods and halt further AI/ML implementation efforts.
- Assess: Conduct a thorough review of the AI/ML algorithms, identifying areas for improvement and addressing data quality issues.
- Respond: Invest in developing more robust AI/ML algorithms and improving data collection and analysis techniques.


**STOP RULE:** The AI/ML algorithms consistently generate inaccurate predictions, leading to significant manufacturing defects and process inefficiencies, rendering them unsuitable for use in the factory system.

---

#### FM6 - The Community Crackdown

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Community Relations Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project fails to maintain strong relationships with local communities and stakeholders, leading to opposition and delays.  The initial assumption that the project would be welcomed by the community proves false.  Concerns about environmental impact, noise pollution, traffic congestion, and job displacement generate significant resistance.  Lack of proactive engagement with the community and a failure to address their concerns exacerbate the problem.  The project faces legal challenges, protests, and negative media coverage, delaying construction and operation of the manufacturing facility.  The project's social license to operate is revoked, and its long-term viability is jeopardized.

##### Early Warning Signs
- Local community members express significant concerns about the project's environmental impact or social consequences.
- The project faces legal challenges from environmental groups or local communities.
- The project receives negative media coverage or experiences public protests.

##### Tripwires
- Community survey reveals >= 40% negative sentiment towards the project.
- Legal challenges result in a court injunction against project activities.
- Public protests disrupt project activities for >= 2 weeks.

##### Response Playbook
- Contain: Immediately halt all activities that are causing community concern and focus on addressing their grievances.
- Assess: Conduct a thorough review of the project's environmental and social impact assessments, identifying areas for improvement and mitigation.
- Respond: Engage with community leaders and stakeholders to negotiate a revised project plan that addresses their concerns and provides tangible benefits to the community.


**STOP RULE:** The project is unable to secure community support after 12 months, rendering it impossible to obtain necessary permits and operate the manufacturing facility.

---

#### FM7 - The Technological Tectonic Shift

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Chief Technology Officer
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
A disruptive breakthrough in manufacturing technology (e.g., a new form of additive manufacturing, quantum computing-driven design) renders the project's core technologies obsolete. The initial assumption of sustained competitiveness proves false. The project is locked into a 20-year plan based on technologies that are no longer state-of-the-art. Attempts to adapt are hampered by the rigid modular design and the sunk costs in existing infrastructure. The project's technical capabilities lag behind competitors, leading to a loss of market share and investor confidence. The project becomes a technological dinosaur, unable to compete in the rapidly evolving landscape of advanced manufacturing.

##### Early Warning Signs
- A competitor announces a breakthrough technology that significantly outperforms the project's core capabilities.
- Key performance metrics for the project's manufacturing processes stagnate or decline.
- The project struggles to attract and retain talent with expertise in emerging manufacturing technologies.

##### Tripwires
- A competing technology achieves >= 2x performance improvement in key metrics (e.g., manufacturing speed, material utilization).
- Project's manufacturing processes fall >= 2 years behind industry best practices.
- Loss of >= 50% of key technical personnel to competitors with more advanced technologies.

##### Response Playbook
- Contain: Immediately freeze all investments in existing technologies and redirect resources towards evaluating and adopting the disruptive technology.
- Assess: Conduct a comprehensive assessment of the disruptive technology's potential impact on the project's core capabilities and market position.
- Respond: Develop a plan to integrate the disruptive technology into the modular factory system, potentially requiring a major redesign or overhaul.


**STOP RULE:** The project is unable to adapt to the disruptive technology within 3 years, rendering its core capabilities obsolete and uncompetitive.

---

#### FM8 - The Bureaucratic Black Hole

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A8
- **Owner**: Chief Operating Officer
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's centralized management structure becomes a bottleneck, hindering efficient decision-making and coordination. The initial assumption of streamlined operations proves false. The hierarchical structure stifles innovation, slows down responses to changing market conditions, and creates communication silos between different teams. Decision-making authority is concentrated at the top, leading to delays and a lack of agility. The project's reliance on a centralized structure backfires, as it becomes increasingly difficult to manage the complexity of the modular factory system and the diverse needs of its stakeholders. The project's financial performance suffers as a result of inefficiencies, missed opportunities, and a failure to adapt to changing circumstances.

##### Early Warning Signs
- Decision-making processes become increasingly slow and cumbersome.
- Communication breakdowns and conflicting priorities emerge between different teams.
- The project struggles to respond effectively to changing market conditions or technological advancements.

##### Tripwires
- Average time to make key project decisions >= 4 weeks.
- Number of unresolved conflicts between teams >= 3 per quarter.
- Project fails to meet >= 2 key market deadlines due to slow decision-making.

##### Response Playbook
- Contain: Immediately delegate decision-making authority to lower levels of the organization and empower teams to make autonomous decisions.
- Assess: Conduct a review of the project's management structure, identifying areas for decentralization and improved communication.
- Respond: Implement a more agile and decentralized management structure, empowering teams to make decisions quickly and effectively.


**STOP RULE:** The centralized management structure consistently hinders efficient decision-making and coordination, leading to significant financial losses and a failure to achieve key project goals.

---

#### FM9 - The Space-Worthiness Mirage

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Head of Quality Assurance
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The components manufactured by the modular factory fail to meet the stringent performance and reliability requirements for space-based applications. The initial assumption of suitability proves false. The manufacturing processes introduce defects or weaknesses that are not apparent under terrestrial conditions but become critical in the harsh environment of space. The project's reliance on terrestrial testing methods proves inadequate, as they fail to replicate the extreme conditions of vacuum, temperature fluctuations, and radiation. The project's market prospects collapse as potential customers lose confidence in the quality and reliability of the manufactured components. The project becomes a costly exercise in terrestrial manufacturing with no viable market for its products.

##### Early Warning Signs
- Prototype components fail to meet key performance or reliability metrics under simulated space conditions.
- The project experiences unexplained failures of components in space-based testing.
- Potential customers express concerns about the quality and reliability of the manufactured components.

##### Tripwires
- Component failure rate under simulated space conditions >= 10%.
- Project fails to secure contracts for space-based applications due to quality concerns.
- Independent testing reveals significant defects or weaknesses in the manufactured components.

##### Response Playbook
- Contain: Immediately halt all production and focus on identifying the root causes of the component failures.
- Assess: Conduct a comprehensive review of the manufacturing processes and testing methods, identifying areas for improvement and enhanced quality control.
- Respond: Invest in developing more rigorous testing protocols and improving the manufacturing processes to ensure that components meet the requirements for space-based applications.


**STOP RULE:** The components consistently fail to meet the performance and reliability requirements for space-based applications, rendering the modular factory system commercially unviable.
