*Roles Needed & Example People*

# Roles

## 1. Programme Director & Prime Integrator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Programme Director and continuity deputy must provide accountable, uninterrupted leadership for the full 20-year programme, chair stage gates, and preserve institutional memory across federated sites—requiring a permanent full-time commitment.

**Explanation**:
This is the accountable executive role for the entire 20-year, multi-country programme. It owns the integrated roadmap, chairs stage-gate reviews, adjudicates inter-module interface conflicts, connects funding tranches to technical milestones, and ensures the three federated sites near CERN, ASML, Zeiss, and Fraunhofer operate as one factory. Because this is a two-decade effort, a single accountable director must be paired with a continuity deputy so decision-making and institutional memory survive leadership transitions.

**Consequences**:
Without a single accountable integrator, the national sites would develop in silos, interface mismatches would surface only during hardware assembly, stage gates would lack an owner, and the programme would risk EUR 5–15 billion retrofit failures and 2–3 years of integration delay.

**People Count**:
2 (a Programme Director and a standing continuity deputy), supported by a central integration office of several hundred not counted in this role.

**Typical Activities**:
Chairs quarterly stage-gate reviews with the continuity deputy and central integration office; owns the integrated 20-year master schedule and critical-path risk register; arbitrates inter-module interface conflicts and aligns funding tranches with merged prototype gates; coordinates the CERN, ASML, Zeiss and Fraunhofer site directors into a single quarterly operating rhythm; and reports to the intergovernmental SPV board with go/no-go recommendations for each phase.

**Background Story**:
Dr. Elena Voss is the Programme Director and Prime Integrator, based at the Geneva/CERN-adjacent programme headquarters in Meyrin, Switzerland. She holds a PhD in systems engineering from ETH Zurich and an MBA from INSEAD, and she spent 22 years leading multi-site integration for ITER, the European Spallation Source, and a European Space Agency lunar-infrastructure preparatory programme. Her core skills are stage-gate governance, federated programme integration, stakeholder diplomacy, and managing technical interfaces across sovereign partners. She is deeply familiar with this task because she chaired the pre-project design review that produced the 20-year roadmap, the critical-lever analysis, and the go/no-go recommendation. Dr. Voss is the right person because the programme's success hinges on a single accountable integrator who can turn the CERN, ASML, Zeiss and Fraunhofer federated sites into one factory, adjudicate inter-module conflicts, and connect EUR 200 billion funding tranches to measurable technical milestones.

**Equipment Needs**:
Integrated programme-management and digital-twin command-centre systems, secure video-telepresence for cross-site stage gates, executive dashboard/decision-support software, and a high-assurance communications suite for SPV board reporting.

**Facility Needs**:
Programme headquarters near Geneva/CERN with an executive operations/briefing centre, secure meeting rooms for board and stage-gate reviews, and physical access to the central integration office coordinating the three sites.

## 2. Strategic Funding & Treasury Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Strategic Funding & Treasury Lead manages the EUR 200 billion funding stack, real-euro indexation, hedging, contingency reserves, and investor relations continuously over two decades, so this must be a stable in-house full-time role.

**Explanation**:
This role architects the 70% public / 30% private funding stack, converts the EUR 200 billion into 2026 real euros with annual indexation, manages quarterly EUR/CHF hedging, protects a EUR 20 billion contingency reserve, and structures capital releases around technical gates. It ensures cash is available across planning, execution, monitoring, and re-baselining, while also keeping private investors committed through credible returns, licensing models, and transparent milestones.

**Consequences**:
Missing this role risks inflation eroding EUR 65–90 billion of real purchasing power, unhedged CHF exposure adding EUR 0.5–1.5 billion, weak private capital mobilisation, and cash-flow pauses that could halt the programme for years and permanently lose key staff.

**People Count**:
min 15, max 40 finance and treasury professionals depending on phase; at least 5 are needed for treasury/hedging alone and another 10 for consortium financial modelling, capital calls, and investor reporting.

**Typical Activities**:
Manages the EUR 200 billion real-euro funding stack, including annual indexation, the EUR 20 billion contingency reserve, and 70% public/30% private capital calls; executes quarterly EUR/CHF hedges with rolling 24-month tenors; models private-investor returns and licensing revenue scenarios; links capital releases to technical and measurement gates; and reports cash-flow, currency, and funding-risk metrics to the executive board.

**Background Story**:
Markus Brandt is the Strategic Funding and Treasury Lead, based at the programme's central treasury office in Frankfurt am Main and rotating among the three site finance teams. He holds a master's in financial engineering from the London School of Economics and a CFA charter, and he spent 18 years structuring multi-billion-euro infrastructure finance for the European Investment Bank and a German industrial consortium. His expertise includes real-euro inflation indexation, currency hedging, contingency reserve management, capital-call schedules, and 20-year investor models. He is familiar with this task because he co-authored the funding assumption review that flagged the EUR 65–90 billion inflation risk and designed the 70% public/30% private risk-sharing consortium. His relevance comes from his ability to keep the EUR 200 billion programme solvent over two decades, protect the EUR 20 billion reserve, hedge CHF exposure, and bind private investors through transparent, gate-linked licensing returns.

**Equipment Needs**:
Treasury management system (TMS), enterprise financial planning/ERP suite, Bloomberg/Reuters market-data terminals, foreign-exchange hedging execution platform, investor/consortium modelling tools, and secure banking/cybersecurity infrastructure.

**Facility Needs**:
Central treasury operations centre in Frankfurt with secure trading/back-office space, dedicated financial data links to the SPV, and coordination offices at each site finance team.

## 3. Cross-Border Legal, Regulatory & Export Control Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Cross-border legal, regulatory, and export-control responsibilities span the entire 20-year lifecycle and require ongoing coordination with four national jurisdictions; a dedicated full-time in-house team is needed to maintain compliance and institutional knowledge.

**Explanation**:
This role establishes the intergovernmental SPV among Switzerland, France, the Netherlands, and Germany, coordinates construction and environmental permits, files dual-use export-control classifications with BAFA, CDIU, and SECO, builds the technology-transfer matrix, and defines IP ownership and dispute-resolution rules. It is the gatekeeper that allows the federated network to move equipment, software, and technical data across borders legally from the first 90 days through final space-readiness validation.

**Consequences**:
Without it, cross-border movement of lithography, propulsion, and robotic-actuation technology is legally impossible, uncoordinated permits can delay each site 6–24 months, export-control gridlock can quarantine critical subsystems, and unresolved IP disputes can trigger EUR 1–3 billion litigation and 2–5 year partner withdrawals.

**People Count**:
min 20, max 60 legal, permitting, and trade-compliance specialists across four jurisdictions; each host country needs a dedicated team plus a central coordination cell.

**Typical Activities**:
Drafts and maintains the intergovernmental SPV agreement and joint compliance office; files and tracks dual-use export-control classifications with BAFA, CDIU, and SECO; maintains the technology-transfer matrix for every inter-site equipment, software, and data movement; coordinates construction and environmental permitting on a common four-country calendar; and defines IP ownership, licensing terms, and dispute-resolution procedures.

**Background Story**:
Claire Dubois is the Cross-Border Legal, Regulatory and Export-Control Lead, based in Pays de Gex, France, minutes from the CERN site. She holds a dual law degree from Sciences Po Paris and the University of Geneva, and she has 20 years of experience in European infrastructure law, dual-use export controls, and technology transfer at CERN and a major aerospace exporter. Her skills include negotiating intergovernmental agreements, coordinating construction and environmental permits, building technology-transfer matrices, and resolving IP and dispute issues across Swiss, French, Dutch, and German jurisdictions. She is intimately familiar with this task because she prepared the pre-project assessment's export-control and SPV governance actions, including the BAFA, CDIU and SECO filing calendar. Her relevance lies in the fact that no lithography, propulsion, or robotic-actuation hardware can cross a Swiss/EU border without her team's licences, and no construction permit can be obtained without her harmonised four-country compliance calendar.

**Equipment Needs**:
Export-control classification and licensing management software, legal matter-management and contract-lifecycle systems, secure cross-border document repository, technology-transfer matrix database, regulatory-permitting tracking tools, and translation/eDiscovery platforms.

**Facility Needs**:
Cross-border legal and compliance offices in Pays de Gex near CERN, with secure document vaults, meeting rooms for intergovernmental negotiations, and space for host-country regulatory task-force representatives.

## 4. Advanced Manufacturing, Materials & Process Engineering Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Advanced manufacturing and process engineering is the core long-duration technical workstream, involving parallel prototype tracks, yield learning, and multi-site operations; the scale and continuity require permanent full-time engineers and technologists.

**Explanation**:
This role owns the technical heart of the programme: parallel macro-scale and miniaturized prototype tracks, additive and subtractive process chains, electronics and FPGA fabrication, robotic actuator production, propulsion and energy systems, and feedstock-adaptive process control. It converts the component makeability map into real manufacturing processes, drives yield-learning curves, and retires the highest technical risks during execution and optimisation. This is the largest resource block because 95% component coverage demands simultaneous work across many material and component families.

**Consequences**:
Insufficient process engineering depth would make the 95% coverage target unachievable, yield plateaus would invalidate the value proposition, the two-track prototype strategy could not be executed, and the programme would fail its 2032 merge gate and subsequent demonstration milestones.

**People Count**:
min 2,000, max 7,000 engineers, materials specialists, and process technologists across the three sites, scaled by phase and by the number of component families in parallel development.

**Typical Activities**:
Leads the parallel macro-scale and miniaturized prototype tracks, directing additive and subtractive process chains, electronics/FPGA fabrication, robotic actuators, propulsion, and energy systems; implements feedstock-adaptive process control and yield-learning curves; updates the makeability map weekly with TRL, yield, and process-modification data; and manages the 2,000–7,000-strong process engineering workforce across the three sites.

**Background Story**:
Dr. Rajiv Menon is the Advanced Manufacturing, Materials and Process Engineering Lead, based at the Fraunhofer-adjacent centre in Oberkochen, Germany. He holds a PhD in materials science from RWTH Aachen, and he spent 15 years at Fraunhofer and Applied Materials developing additive and subtractive process chains for aerospace and semiconductor equipment. His skills cover metal-powder additive manufacturing, precision machining, thin-film electronics, robotic-actuator assembly, and adaptive process control for impure feedstock. He is deeply familiar with this task because he led the component-makeability mapping exercise that ranked 5,000 part numbers by coverage gap, TRL, yield, and process-modification cost, and he ran the early feedstock-tolerance trials. Dr. Menon is the relevant technical heart of the project because he must convert the makeability map into real, yield-ramping processes on two parallel prototype tracks and retire the highest-risk electronics and FPGA fabrication challenges before the 2032 merge gate.

**Equipment Needs**:
Macro-scale and miniaturized additive/subtractive process lines, metal-powder AM systems, precision CNC and micromachining tools, thin-film deposition/etch and semiconductor fabrication equipment, robotic-actuator assembly cells, feedstock conditioning test rigs, and process-development instrumentation.

**Facility Needs**:
Advanced manufacturing R&D laboratories at the Fraunhofer/Oberkochen site, including pilot production halls, clean and controlled process bays, powder-handling cells, thermal-envelope-separated process areas, and materials characterisation laboratories.

## 5. Factory Systems, Interface & Digital Integration Architect

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The factory systems, interface register, digital-twin backbone, and cybersecurity architecture must be governed consistently for 20 years to prevent costly retrofits and integration failures, making a full-time integrated architect role essential.

**Explanation**:
This role defines the modular factory architecture, controlled inter-module interface register, clean/dirty contamination zoning, thermal separation, toolset commonality, and the federated digital-twin / MES / ERP backbone that lets distributed sites operate as one integrated factory. It also protects cyber-resilience and data interoperability from day one, because retrofitting integration layers, airflow partitions, or cybersecurity controls after construction is prohibitively expensive.

**Consequences**:
Without it, modules built at different sites will not physically or digitally mate, retrofits could cost EUR 5–15 billion and add 2–3 years, contamination would suppress electronics yield, and the federated network could never function as a single factory.

**People Count**:
min 300, max 1,000 systems engineers, industrial architects, interface managers, and digital-twin/cybersecurity engineers; interface and zoning decisions must be staffed at every site plus a central integration authority.

**Typical Activities**:
Owns the controlled inter-module interface register and integration-layer architecture; sets the clean/dirty pressure cascade and thermal-envelope separation rules; designs the federated digital-twin, MES/ERP, and cybersecurity backbone; conducts interface compliance simulations and joint integration reviews; and freezes module layouts before fabrication to prevent costly retrofits.

**Background Story**:
Anke van der Meer is the Factory Systems, Interface and Digital Integration Architect, based in Veldhoven, Netherlands, in the ASML ecosystem. She holds an MSc in mechatronics from TU Eindhoven and has 17 years of systems engineering experience at ASML and at a high-tech logistics integrator, where she specialised in modular machine architectures, interface control documents, and digital twins. Her skills include clean/dirty zoning, thermal separation, OPC UA data harmonisation, MES/ERP integration, and cyber-resilient industrial networks. She knows this task well because she authored the controlled interface register vision and the digital-twin architecture that let federated sites run as one factory. Her relevance is that interface mismatches and contamination partitions cannot be retrofitted cheaply; her up-front architecture decisions will avoid the EUR 5–15 billion integration failures and 2–3 year schedule slips identified in the risk analysis.

**Equipment Needs**:
Federated digital-twin platform with common data model, MES/ERP stack, CAD/PLM/ALM tools, interface-register and simulation software, hardware-in-the-loop integration test stands, OPC UA interoperability testers, and industrial cybersecurity test/range infrastructure.

**Facility Needs**:
Systems integration laboratories in the ASML/Veldhoven ecosystem, with full-scale module docking/interface mock-ups, digital-twin data centre, clean/dirty pressure-cascade test bays, and a cyber-range/security operations space.

## 6. Metrology, Validation & Quality Assurance Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Metrology, validation, and QA must continuously feed measurement gates, audit evidence, and certification of the 95% coverage claim throughout the programme, requiring a permanent full-time team with sustained traceability and accountability.

**Explanation**:
This role designs and operates the measurement-gate rhythm, in-situ and at-line metrology, feedstock characterisation, makeability-map updates, yield and capability tracking, and the auditable certification evidence for the 95% coverage claim. It is central to monitoring and adjustment: it feeds adaptive process-control loops, supplies data for funding and technical gates, and produces the defensible validation that regulators, investors, and space agencies require.

**Consequences**:
Without robust metrology and QA, feedstock variation would propagate into failed components, yield learning curves would be invisible, the 95% claim would lack audit evidence, and the programme could not credibly demonstrate space-readiness or retain investor and regulator confidence.

**People Count**:
min 500, max 1,500 metrology, inspection, and QA/QC engineers across all sites; workload scales with component-family breadth and the statistical confidence required for final certification.

**Typical Activities**:
Designs and operates the measurement-gate rhythm with in-situ, at-line, and deep laboratory metrology; characterises feedstock purity and feeds adaptive process control; maintains yield, Cpk, and scrap/rework statistics for every component family; updates the makeability map with validated coverage data; and produces the certification evidence for the auditable 95% claim.

**Background Story**:
Dr. Sofia Ricci is the Metrology, Validation and Quality Assurance Lead, based at the Zeiss campus in Oberkochen, Germany. She earned a PhD in applied physics from the University of Padua and spent 14 years at Zeiss Semiconductor Manufacturing Technology developing sub-picometre optical metrology and coordinate-measurement systems. She specialises in interferometry, scatterometry, in-situ process sensing, statistical process control, and certification evidence. She is familiar with this task because she helped define the measurement-gate rhythm, the hybrid at-line/depth-characterisation strategy, and the audit trail needed to prove the 95% coverage claim. Her relevance stems from her ability to make feedstock variability visible to adaptive control loops, track yield-learning curves with statistical confidence, and generate the certifiable evidence that regulators, investors, and space agencies will demand.

**Equipment Needs**:
In-situ and at-line metrology tools (interferometers, scatterometers, SEM, CMM, profilometers), feedstock characterisation instruments (spectroscopy, ICP-MS, particle-size analysers), statistical process-control/yield analytics platforms, and reference/calibration standards.

**Facility Needs**:
Metrology, validation and quality-assurance laboratories at the Zeiss/Oberkochen campus, including cleanroom-class inspection bays, calibration laboratory, materials analysis facilities, and data centres for certification evidence management.

## 7. Safety, Environmental & Sustainability Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Safety, environmental compliance, and sustainability obligations are continuous legal and operational requirements across all three sites; permanent full-time safety and environmental staff are needed to protect personnel, permits, and social license.

**Explanation**:
This role owns ATEX-compliant powder safety, ISO 45001 occupational health, ISO 14644 cleanroom discipline, environmental impact assessments, and the net-zero / circular-economy roadmap, including 100% renewable electricity by 2035, 80% waste-heat recovery, and 90% water recycling. It protects the workforce, prevents multi-year shutdowns from explosions or contamination incidents, secures permits, and maintains social license with local communities through transparent ESG reporting throughout planning, execution, and operations.

**Consequences**:
Without it, metal-powder explosions, toxic releases, contamination breaches, regulatory penalties, and community opposition could cause injuries, EUR 0.5–2 billion fines, 1–3 year construction delays, and loss of the public support needed to sustain a 20-year political commitment.

**People Count**:
min 200, max 700 safety, environmental, and sustainability engineers and coordinators distributed across the three sites plus a central safety authority; each site needs its own team because hazards and regulators differ.

**Typical Activities**:
Enforces ATEX and ISO 45001 safety rules; manages negative-pressure dirty zones, ISO 14644 cleanrooms, airlock cascades, inert metal-powder cells, and explosion-relief systems; conducts environmental impact assessments, permits, and audits; runs the net-zero and circular-economy roadmap including 80% waste-heat recovery, 90% water recycling, and 100% renewable electricity by 2035; and publishes ESG metrics to regulators and communities.

**Background Story**:
Nadia Hoffmann is the Safety, Environmental and Sustainability Lead, based at the CERN-adjacent site in Meyrin, Switzerland, with oversight across all three nodes. She holds a master's in process safety and environmental engineering from ETH Zurich and is a certified ATEX and ISO 45001 lead auditor with 16 years of experience in chemical, powder-metallurgy, and cleanroom industries. Her skills include explosion-protection design, pressure-cascade zoning, hazardous-materials management, environmental impact assessment, and circular-economy roadmapping. She has direct familiarity with this task because she froze the spatial zoning rule separating ATEX Zone 21/22 powder cells from ISO Class 5 clean bays and commissioned the CFD particle-dispersion studies. She is the relevant authority for keeping the workforce alive, the permits intact, and the public support secure: one metal-powder explosion or contamination breach could cost billions and delay every subsequent gate.

**Equipment Needs**:
ATEX-rated process-safety equipment, gas and particle detection/monitoring networks, explosion-relief and inert-gas system test rigs, CFD/HSE simulation software, environmental emissions/water/energy monitoring systems, and PPE/incident-response equipment.

**Facility Needs**:
Safety, environmental and sustainability offices at all three sites, a central safety-authority command centre, hazardous-materials storage and testing areas, environmental monitoring stations, and emergency-response/training facilities.

## 8. Knowledge, Talent & Workforce Continuity Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Knowledge, talent, and workforce continuity must be managed for the entire 20-year horizon through mentorship, documentation, and retention programmes; a permanent full-time workforce team is required to counter attrition and preserve critical expertise.

**Explanation**:
This role sustains human capability across two decades through mentorship and rotation programmes, two trained practitioners per critical skill, geographic redundancy, exhaustive documentation and digital-twin records, competitive retention incentives, and recruitment pipelines from CERN, ASML, Zeiss, Fraunhofer, and universities. It is the maintenance-and-sustainability backbone that prevents institutional amnesia when key scientists retire, resign, or are poached.

**Consequences**:
Without it, unavoidable attrition over 20 years would strip the programme of its scarcest expertise, documentation lag would encode outdated assumptions, single-person dependencies would create critical bottlenecks, and schedule delays of 1–2 years per lost specialty would compound into multi-billion-euro losses.

**People Count**:
min 150, max 500 HR, learning-and-development, and knowledge-management professionals; more than one is required because attrition must be tracked per critical specialty and redundancy maintained across physically separate sites.

**Typical Activities**:
Runs mentorship and rotation programmes so every critical skill has two trained practitioners; maintains exhaustive documentation and digital-twin knowledge records; maps critical-specialty redundancy across geographically separate sites; manages retention incentives, leadership continuity, and recruitment pipelines from CERN, ASML, Zeiss, Fraunhofer, and universities; and tracks time-to-competence and knowledge-decay metrics.

**Background Story**:
Dr. Ingrid Bauer is the Knowledge, Talent and Workforce Continuity Lead, based in Munich and rotating through the three sites, with her office embedded in the programme's central integration office. She holds a PhD in organisational psychology from LMU Munich and has 20 years of experience managing knowledge continuity for long-horizon engineering programmes, most recently at CERN and an EU defence-technology agency. Her expertise covers mentorship and rotation systems, digital-twin documentation, redundancy planning, retention incentives, and university recruitment pipelines. She is familiar with this task because she enacted the two-practitioners-per-critical-skill policy and the geographic-redundancy map for all specialist roles across the CERN, ASML and Fraunhofer nodes. Her relevance is that the 20-year programme will inevitably suffer attrition; she prevents institutional amnesia by keeping scarce expertise duplicated, documented, and continuously learnable, so the loss of one senior scientist does not halt the critical path.

**Equipment Needs**:
HRIS and learning-management system, knowledge-management/documentation platform, digital-twin knowledge-capture tools, video/recording studios and e-learning authoring systems, and talent-analytics software for attrition and redundancy tracking.

**Facility Needs**:
Workforce-continuity offices embedded in the central integration office, training academies and classrooms at each site, knowledge-capture studios, and document/archive facilities for preserving two-decade institutional memory.

---

# Omissions

## 1. Supply Chain and Procurement Lead

The plan depends on uninterrupted feedstock, reagents, specialized equipment, and spare parts across three federated sites. No team role explicitly owns supplier qualification, strategic stockpiling, logistics coordination, or procurement risk, leaving a key source of schedule and cost exposure unmanaged.

**Recommendation**:
Appoint a full-time Supply Chain and Procurement Lead with site-based procurement teams. Develop a supplier qualification framework, dual-sourcing strategies for critical materials, strategic feedstock stockpiles, and inter-site logistics plans linked to the programme master schedule.

## 2. Site Development and Construction Lead

The programme requires developing 300 hectares, 150,000 m² of clean/controlled floor space, and 50 MW of clean-energy infrastructure across three countries. No role is accountable for site acquisition, geotechnical work, construction sequencing, commissioning, or handover to operations, despite these activities being on the critical path.

**Recommendation**:
Add a full-time Capital Projects and Site Delivery Lead with a site construction manager at each node. Hold this role accountable for executing option agreements, geotechnical surveys, utility connections, permitting integration, construction milestones, and commissioning readiness in coordination with Legal, Safety, and Factory Systems.

## 3. Stakeholder and Political Engagement Lead

Sustaining political commitment and social license over 20 years is essential for a EUR 200 billion multi-country programme. No team role owns communications, community engagement, government relations, or public reporting, leaving the programme vulnerable to political shifts, local opposition, and reputational damage.

**Recommendation**:
Create a full-time Stakeholder Engagement and Communications Lead with local liaisons at each site. Establish multilingual public reporting, quarterly community advisory boards, annual demonstration days, and structured engagement with EU institutions and member-state governments, closely coordinated with the legal and SPV governance team.

## 4. Commercialisation and Licensing Lead

The funding model assumes 30% private capital, but private investors require a credible revenue model, licensing terms, and exit or return mechanisms. While the Treasury Lead manages funding flows and Legal handles IP, no role owns the commercial strategy needed to mobilize and retain private co-investment.

**Recommendation**:
Appoint a Commercialisation and Licensing Lead responsible for building a 20-year revenue model, structuring licensing deals for module technology, managing the commercial subsidiary, and aligning private capital contributions with transparent return expectations. This role should work closely with the Funding Lead and Legal Lead to connect licensing revenue to investor commitments.

## 5. Programme Controls and Risk Management Lead

A 20-year, multi-site programme requires rigorous integrated scheduling, cost control, earned-value management, and a living enterprise risk register. The Programme Director cannot personally own these functions; without a dedicated controls function, gate decisions and board reporting will lack consistent, objective evidence.

**Recommendation**:
Stand up a Programme Controls Office led by a full-time Programme Controls and Risk Management Lead. This team should own the integrated master schedule, cost and contingency tracking, stage-gate evidence packages, change control, risk registers, and performance dashboards feeding quarterly board reviews.

---

# Potential Improvements

## 1. Clarify Decision Rights Across Roles and Sites

The Programme Director, Factory Systems Architect, and site-based leads will frequently need to resolve interface, zoning, sequencing, and integration trade-offs. Without clear decision rights, conflicts can stall progress and create silos among partner institutions.

**Recommendation**:
Publish a Delegation of Authority and RACI matrix for all major decisions, including interface changes, gate criteria, budget reallocations, and descoping triggers. Define a standing Interface Arbitration Board with named members and a documented escalation path so conflicts are resolved quickly and consistently.

## 2. Create a Dedicated Electronics and Semiconductor Sub-Programme

Complex electronics, FPGAs, and sensors represent the highest technical risk and are central to the 95% coverage claim. Under a single Advanced Manufacturing Lead spanning all materials and component families, electronics may not receive the focused leadership needed to retire risk early.

**Recommendation**:
Designate a Deputy Lead for Electronics and Semiconductor Fabrication within the Advanced Manufacturing team, with dedicated budget, milestones, and staffing. This sub-programme should own the electronics-first risk retirement activities, including lithography process development, yield learning, and FPGA fabrication, and report directly into the 2032 merge gate.

## 3. Formalize the Link Between Technical Gates and Funding Releases

The funding model ties capital releases to technical milestones, but the current structure does not define an objective, repeatable process for evidence review, validation, and Treasury action. This creates overlap and potential disputes among the Funding, Metrology, and Programme Director roles.

**Recommendation**:
Develop a Stage-Gate Playbook that specifies the evidence required for each gate, the responsible roles for producing and validating that evidence, and the exact conditions Treasury must check before releasing funds. Metrology should validate technical data, Programme Controls should assess schedule and risk impact, and Treasury should execute releases only upon confirmed compliance.

## 4. Strengthen Succession and Redundancy for All Critical Leadership Roles

The Programme Director has a continuity deputy, but the other seven leadership roles appear to have single named experts. Over a 20-year horizon, attrition or incapacity in any critical role could cause major delays and knowledge loss.

**Recommendation**:
Extend the 'two trained practitioners per critical skill' policy to every leadership role and key technical specialty. Assign named deputies within the first year, require every lead to maintain up-to-date knowledge documentation and formal shadowing plans, and verify redundancy metrics through the Knowledge, Talent and Workforce Continuity Lead.