**Budget Request Exceeding PMO Delegated Authority**
Escalation Level: Programme Steering Committee
Approval Process: PSC review at a scheduled or extraordinary meeting; consensus preferred, failing which a 75% supermajority vote, with the independent Chair holding the final casting vote.
Rationale: The request exceeds the PMO's delegated limits for annual reallocations (up to EUR 1 billion), contracts (below EUR 500 million), or funding tranche releases, and affects the EUR 200 billion 2026 real-euro baseline and sovereign/private funding commitments.
Negative Consequences: Unauthorized spending could breach the programme budget, trigger cash-flow shortfalls, undermine shareholder confidence, and force unplanned scope reductions or programme restructuring.

**Critical Technical Risk Materialization: Electronics Yield Plateau Below 95% Coverage Threshold**
Escalation Level: Programme Steering Committee
Approval Process: PSC reviews the Technical Advisory Group's written risk assessment and yield data, then decides on descoping, coverage re-sequencing, or contingency deployment using consensus or 75% supermajority, with the Chair's casting vote if needed.
Rationale: The technical risk threatens the core 95% component-coverage promise and the 2046 space-readiness date; changing coverage sequencing or external input allowance is a strategic-lever decision beyond PMO authority.
Negative Consequences: If not resolved, the programme could fail its certification, lose funding-gate releases, invalidate the universality claim, and waste up to EUR 200 billion of investment.

**PMO Deadlock on Inter-Module Interface Freeze Timing**
Escalation Level: Programme Steering Committee
Approval Process: PSC arbitrates with input from the prime integrator and Technical Advisory Group; decision by consensus or 75% supermajority, with the Chair's casting vote if needed.
Rationale: The interface covenant is a critical strategic lever, and freezing too early or too late has cross-site integration consequences that the PMO cannot resolve within its delegation.
Negative Consequences: Prolonged deadlock delays parallel module development, forces costly retrofits, and could extend integration by 2-3 years at EUR 5-15 billion additional cost.

**Proposed Major Scope Change: Expanding External Input Allowance Beyond Basic Feedstock**
Escalation Level: Programme Steering Committee
Approval Process: PSC strategic-lever review with sovereign shareholder and private investor input; approval requires consensus or 75% supermajority, and changes affecting sovereign commitments need support of at least one independent non-executive director.
Rationale: External input allowance defines the credibility boundary of the 95% in-factory claim, a critical strategic lever that cannot be changed by the PMO.
Negative Consequences: Unauthorized expansion would undermine the programme's universality promise, reduce investor and space-agency confidence, and create a contested audit position for the 95% certification.

**Reported Ethical and Compliance Breach: Export-Control Violation**
Escalation Level: Ethics and Compliance Committee
Approval Process: ECC launches an independent investigation, can suspend the export transfer or procurement by majority vote, and requires PSC ratification for material business-impacting remedies; suspected criminal conduct is reported to competent authorities.
Rationale: Export-control violations involve multi-jurisdiction legal exposure and require independent review with authority to halt non-compliant activity, not a technical or operational decision.
Negative Consequences: Failure to act could trigger BAFA/CDIU/SECO penalties, export-license revocation, legal liability, and severe reputational damage across the four host countries.

**Material Financial Control Failure or Suspected Fraud in Capital Drawdowns**
Escalation Level: Audit and Risk Assurance Committee
Approval Process: ARAC reviews audit findings and can require corrective actions; material findings and suspected fraud are escalated to the PSC and, where legally required, to external auditors or regulators.
Rationale: Independent assurance over financial integrity and risk is necessary to protect a EUR 200 billion public-private programme from misallocation, undisclosed risks, and fraud.
Negative Consequences: If undetected, financial misstatement or fraud could distort capital calls, trigger premature budget depletion, and destroy the trust of sovereign shareholders and private investors.

**Critical Stakeholder Opposition Threatening Construction Permits at a Host Site**
Escalation Level: Stakeholder Engagement and Social License Advisory Group
Approval Process: SESLAG convenes site-level advisory boards, reviews sentiment data, advises on community-benefit mitigation, and escalates unresolved permit-threatening issues to the PSC.
Rationale: Construction permit delays of 1-3 years and legal battles exceed normal PMO community-relations activity and require stakeholder and political legitimacy management.
Negative Consequences: Continued opposition can delay site construction 6-24 months, add EUR 100-500 million in legal costs, and erode the political support needed to sustain the 20-year programme.