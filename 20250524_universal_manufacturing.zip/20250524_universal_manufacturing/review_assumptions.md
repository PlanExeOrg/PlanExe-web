## Domain of the expert reviewer
Long-horizon industrial R&D programme finance, technology readiness, and multi-jurisdiction governance

## Domain-specific considerations

- Real vs nominal cost baseline and inflation indexing over 20 years
- Technology readiness and yield learning-curve assumptions
- Mobilisation of private capital and licensing revenue models
- Export controls and technology transfer across EU/Swiss borders
- Energy, water, and raw-material price volatility
- Political, workforce, and knowledge continuity over two decades

## Issue 1 - Missing real/nominal EUR baseline and currency hedging reference
The EUR 200 billion figure is stated without specifying whether it is in real (2026) or nominal (2046) euros. Over 20 years, inflation will dramatically erode a fixed nominal budget. The CHF 3 billion allocation also assumes an unspecified EUR/CHF baseline and hedging cost. Without an indexation or currency strategy, the programme will face a hidden scope cut or require unplanned top-ups.

**Recommendation:** Establish the cost baseline in 2026 real EUR with annual indexation clauses for labour, energy, and materials. Use net-present-value accounting in all board reporting. Set a formal EUR/CHF hedging band (e.g., 1.05–1.10) with a dedicated reserve for tail moves, and review the hedge ratio quarterly. Quantify the programme's contingency in real terms and re-baseline every 5 years.

**Sensitivity:** With a fixed nominal €200B budget and 2% average inflation, real purchasing power falls to ~€135B (a €65B loss); at 3% inflation, the loss grows to ~€90B. This would force a 25–40% scope reduction, or require a €65–90B top-up to maintain the baseline plan.

## Issue 2 - Unstated technology readiness and yield ramp assumptions
The 95% component coverage target rests on implicit assumptions about starting technology readiness levels, initial process yields, defect rates, and learning-curve slopes. Complex electronics (FPGAs, sensors, lithography) are likely to start at very low yields, and the plan does not specify the yield improvement curve needed to qualify 95% coverage by 2042. A yield plateau at even 80% would invalidate the core value proposition.

**Recommendation:** Before major construction, develop a component-makeability map that assigns each component class a baseline TRL, expected first-pass yield, and process capability index (Cpk). Set gate criteria based on demonstrated yield and statistical confidence, not just calendar dates. Fund parallel macro-scale and miniaturized prototypes to retire electronics risk early. Create a public yield dashboard and use an external technical advisory board to validate learning-curve models annually.

**Sensitivity:** Baseline: 95% coverage qualified by 2042. A 3-year delay in electronics yield ramp would add ~€30B (15% cost increase), push space-readiness from 2046 to 2049, and delay the start of value capture by 3 years. If yields plateau at 80%, the 95% claim fails, requiring €10–20B of rework or a fundamental descope.

## Issue 3 - Private capital mobilisation and licensing revenue assumptions are undefined
The 70% public / 30% private split assumes €60B of private investment, but there is no stated revenue model, expected return, or exit mechanism. Private investors will not commit to a 20-year, high-risk programme without a credible plan for licensing revenues, royalties, or equity appreciation. The plan also under-specifies IP-sharing arrangements that would underpin any private co-investment.

**Recommendation:** Build a 20-year revenue model with scenarios for module licensing, component sales, and space-contract royalties. Structure a separate commercial subsidiary to hold non-core IP and monetise it through licensing. Use EIB/EBRD co-financing and public guarantees to lower the cost of capital. Negotiate a minimum IRR threshold (e.g., 8–10%) with investors and link capital calls to technical gate achievements while retaining downside protection for the public side.

**Sensitivity:** Baseline: €60B private capital (30%). If private share falls to 10% (€20B), the €40B gap would need public funding, extending capital calls by 4–6 years or forcing a 15–25% scope reduction. If licensing revenues underperform (baseline zero), private investors would require €150–200B gross revenue to achieve an 8–12% IRR, otherwise the consortium's overall ROI turns negative.

## Review conclusion
The programme's success depends on three missing but critical assumptions: a real-vs-nominal financial baseline, technology yield/readiness trajectories, and private capital/revenue credibility. Fixing these gaps early—through indexation, yield-gated milestones, and a transparent licensing model—will materially improve the chance of delivering the 95% coverage and space-readiness promise. Export-control harmonisation and energy-price volatility, while important, are more manageable and should be addressed as part of the next-tier governance and contingency planning.