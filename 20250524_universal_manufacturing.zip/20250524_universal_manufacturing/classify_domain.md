**Primary domain:** Advanced Manufacturing

**Secondary domains:** Semiconductor Fabrication, Materials Engineering, Robotics Engineering

**Rationale:** Advanced Manufacturing owns the core outcome: a modular miniaturized factory producing 95% of components from feedstock, with the highest importance and specificity. Aerospace Engineering targets the later space goal, while Systems Engineering and remaining disciplines are supporting methods or constraints.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Advanced Manufacturing | 5 | 5 | outcome | Core deliverable is a modular miniaturized factory performing additive and subtractive manufacturing from feedstock. |
| Systems Engineering | 5 | 4 | method | Integrates diverse manufacturing subsystems into one coherent modular miniaturized factory platform. |
| Semiconductor Fabrication | 4 | 4 | method | Manufacturing complex electronics, FPGAs, and sensors draws on lithography expertise near ASML and Zeiss. |
| Materials Engineering | 4 | 4 | constraint | Feedstock-to-component conversion must tolerate variations in material purity and composition. |
| Robotics Engineering | 4 | 4 | method | Robotic actuators and automated miniaturized factory operation are core mechanisms demanding robotics expertise. |
| Aerospace Engineering | 4 | 4 | outcome | Propulsion unit production and the ultimate space-based manufacturing goal anchor project success. |
| Metrology | 4 | 4 | method | Adapting to feedstock purity and composition variation requires precise measurement and characterization. |
| Electronics Engineering | 4 | 4 | method | Enables in-factory production of complex electronics, FPGAs, and sensors from feedstock. |
| Industrial Engineering | 4 | 3 | method | Designs modular factory layout, workflows, and processes achieving 95% component coverage. |