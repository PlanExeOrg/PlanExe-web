### 1. Integrated Schedule and Phase-Gate Progress Monitoring against the 2026–2046 master plan, including critical-path analysis, milestone buffers, and phase-gate exit criteria.
**Monitoring Tools/Platforms:**

  - Integrated Master Schedule
  - PMO Delivery Dashboard
  - Phase-Gate Review Packs
  - Digital Twin Reporting Platform

**Frequency:** Weekly PMO operations stand-up; monthly integrated delivery review; phase-gate reviews per master schedule.

**Responsible Role:** Programme Management Office (Head of Project Controls)

**Adaptation Process:** PMO adjusts near-term schedules, resource loading, and inter-site dependencies within delegated authority; schedule slips or scope changes above delegation are escalated to the Programme Steering Committee, which may re-baseline phases or amend gate criteria.

**Adaptation Trigger:** Critical-path milestone slips more than 3 months against the baseline, phase-gate exit criteria are not met within the 12-month buffer, or annual phase slippage tolerance of 10–15% is exceeded.

### 2. 95% Component Coverage and Yield Ramp Monitoring, tracking the makeability map, component coverage percentage, TRLs, first-pass yields, and process capability indices across all component families, with emphasis on complex electronics and FPGAs.
**Monitoring Tools/Platforms:**

  - Component Makeability Map
  - Coverage and Yield Tracking Database
  - Technical Gate Review Packs
  - Public Yield Dashboard
  - TAG Technical Risk Assessments

**Frequency:** Continuous data collection; monthly PMO analysis; quarterly Technical Advisory Group validation; deep-dive panels before each major technical gate.

**Responsible Role:** PMO Head of Engineering and Technical Integration, with Technical Advisory Group independent validation

**Adaptation Process:** TAG recommends coverage re-sequencing, process modifications, or additional parallel process chains; PMO implements approved corrective actions; PSC approves strategic changes to coverage sequencing, external input allowance, or descoping options.

**Adaptation Trigger:** Coverage percentage falls more than 5 percentage points below the planned trajectory at a phase gate, first-pass yield for a critical component class remains below the gate threshold for two consecutive quarterly reviews, or a technical milestone is projected to slip more than 12 months.

### 3. Budget Drawdown, Cost Baseline, and Financial Health Monitoring, including real-euro expenditure, annual drawdowns, contingency reserve usage, EUR/CHF hedging, and capital-call accuracy.
**Monitoring Tools/Platforms:**

  - 2026 Real-Euro Cost Baseline
  - Financial Dashboard
  - Capital Call Tracker
  - EUR/CHF Hedging Report
  - Contingency Reserve Register

**Frequency:** Monthly finance review; quarterly Audit and Risk Assurance Committee review; quarterly PSC review of strategic financial risks.

**Responsible Role:** PMO Head of Finance, with Audit and Risk Assurance Committee oversight

**Adaptation Process:** PMO reforecasts and reallocates within delegated limits; ARAC recommends corrective actions and audit adjustments; PSC approves contingency activation, funding structure changes, or five-year re-baselining.

**Adaptation Trigger:** Projected cumulative drawdown variance exceeds 10% of the annual plan, contingency usage exceeds 20% of the reserve in a single year, EUR/CHF moves outside the hedged band for two consecutive quarters, or capital-call accuracy falls below 95%.

### 4. Public-Private Funding Commitment and Political Support Monitoring, tracking acquisition of the EUR 200 billion funding envelope, sovereign pledges, private co-investment, licensing revenue credibility, and political resilience across the four host countries.
**Monitoring Tools/Platforms:**

  - Public Funding Commitment Tracker
  - Private Investor Pipeline CRM/Spreadsheet
  - Licensing Revenue Model Scenarios
  - Intergovernmental Agreement Status Log
  - Political Risk Dashboard

**Frequency:** Monthly during consortium formation and fundraising; quarterly thereafter; quarterly PSC strategic review.

**Responsible Role:** Programme Director and SPV CFO, with Programme Steering Committee for strategic funding decisions

**Adaptation Process:** PSC renegotiates commitment terms, adjusts the consortium structure, activates contingency or downscaling scenarios, extends capital call schedules, or engages sovereign shareholders; PMO implements the revised drawdown and resource plan.

**Adaptation Trigger:** Public commitments fall below the 70% target or private commitments below the 30% target by an agreed milestone date, projected funding shortfall exceeds EUR 10 billion, a sovereign partner signals reduced commitment, or licensing revenue scenarios indicate private investors cannot achieve the 8–10% IRR threshold.

### 5. Enterprise Risk and Major Risk Register Monitoring, covering technical infeasibility, funding shortfalls, integration failure, regulatory gridlock, supply chain disruption, security, and political risks using leading indicators and mitigation status.
**Monitoring Tools/Platforms:**

  - Single Enterprise Risk Register
  - Top-10 Strategic Risk Dashboard
  - Incident and Near-Miss Reports
  - Risk Appetite Statement
  - Mitigation Action Trackers

**Frequency:** Monthly CRO-led risk review; quarterly ARAC and PSC reviews; extraordinary sessions within 10 working days for critical risks.

**Responsible Role:** SPV Chief Risk Officer, with ARAC independent assurance and PSC risk-appetite authority

**Adaptation Process:** Risk owners update mitigation plans and assign corrective actions; material risks are escalated to the PSC; PSC may reset risk appetite, approve contingency deployment, or mandate strategic descoping.

**Adaptation Trigger:** Any top-10 risk crosses the defined risk-appetite threshold, a new critical risk is identified, a mitigation action is overdue by more than 30 days, or a major incident occurs affecting safety, security, or programme integrity.

### 6. Inter-Module Interface Compliance and Integration Readiness Monitoring, tracking controlled interface register compliance, integration-layer performance, joint integration tests, and interface-freeze timing across federated sites.
**Monitoring Tools/Platforms:**

  - Controlled Interface Register
  - Digital Twin Integration Platform
  - Interface Compliance Simulation Reports
  - Integration Test Log
  - Prime Integrator Monthly Report

**Frequency:** Monthly PMO integration review; monthly prime-integrator report; intensive weekly review during integration phases and before interface-freeze gates.

**Responsible Role:** Prime Integrator Programme Manager and PMO Head of Technical Integration

**Adaptation Process:** PMO arbitrates minor interface deviations and updates non-frozen interface items within delegation; unresolved deadlocks or interface-freeze changes are escalated to the PSC with Technical Advisory Group advice.

**Adaptation Trigger:** Interface non-compliance rate exceeds 5% of tested items, a joint integration test fails, or an interface-freeze milestone slips more than 6 months against the master schedule.

### 7. Miniaturization Pathway and Space-Readiness Progress Monitoring, tracking the two-track macro-scale and miniaturized bench-scale prototypes, merge-gate readiness, footprint reduction, and technology readiness toward space-compatible modules.
**Monitoring Tools/Platforms:**

  - Two-Track Prototype Test Reports
  - Merge-Gate Criteria Scorecard
  - TRL Assessment Tracker
  - Miniaturization Metrics Dashboard
  - Technical Advisory Group Assessments

**Frequency:** Monthly PMO engineering review; quarterly TAG review with pre-gate deep dives; formal merge-gate review at the scheduled gate.

**Responsible Role:** PMO Engineering Lead, with Technical Advisory Group independent technical assurance

**Adaptation Process:** PMO rebalances investment and resources between the macro and miniaturized tracks; TAG recommends merging, delaying, or descoping to a modular scalable architecture; PSC approves strategic pathway changes.

**Adaptation Trigger:** One prototype track fails defined performance thresholds, the merge gate is not ready within the 6-month buffer, or projected space-readiness footprint/performance deviates more than 15% from technical targets.

### 8. Regulatory, Permitting, and Export-Control Compliance Monitoring, tracking construction permits, environmental approvals, dual-use export-control classifications with BAFA, CDIU, and SECO, and the technology-transfer matrix across the four host countries.
**Monitoring Tools/Platforms:**

  - Common Permitting Calendar
  - Export-Control License Tracker
  - Technology-Transfer Matrix
  - Joint Compliance Office Reports
  - Compliance Dashboard

**Frequency:** Bi-weekly during the 2026–2027 front-loading phase; monthly thereafter; monthly Ethics and Compliance Committee review.

**Responsible Role:** Ethics and Compliance Committee and Joint Compliance Office

**Adaptation Process:** Joint compliance office expedites filings, quarantines controlled items, re-sequences cross-border movements, and adjusts the permitting calendar; material regulatory risks are escalated to the PSC for political or intergovernmental intervention.

**Adaptation Trigger:** A construction or environmental permit slips more than 3 months from the common calendar, an export-control classification request exceeds 90 days beyond the expected resolution date, or a compliance finding requires corrective action.

### 9. External Input Allowance and Universality Claim Audit Monitoring, tracking residual external inputs, the elimination roadmap, and the auditability of the 95% in-factory manufacturing claim.
**Monitoring Tools/Platforms:**

  - External Input Register
  - Elimination Roadmap
  - Coverage Audit Reports
  - ARAC Audit Sampling Results
  - Certification Evidence Database

**Frequency:** Quarterly PMO review; annual independent audit; ARAC review of audit evidence at each coverage certification milestone.

**Responsible Role:** Audit and Risk Assurance Committee, with PMO Head of Engineering and external auditors

**Adaptation Process:** PMO assigns process-development resources to bring external inputs in-house and updates the elimination roadmap; ARAC directs corrective actions for audit findings; PSC approves any change to the external input allowance.

**Adaptation Trigger:** External input count or complexity exceeds the approved allowance, the elimination roadmap falls more than 12 months behind schedule, or an audit finds that the 95% coverage claim is not supported by sufficient evidence.

### 10. Workforce and Critical Expertise Retention Monitoring, tracking peak staffing, critical-skill redundancy, attrition, mentorship rotation, and documentation currency to protect two decades of institutional knowledge.
**Monitoring Tools/Platforms:**

  - Workforce Dashboard
  - Critical Skill Coverage Matrix
  - Attrition and Retention Tracker
  - Knowledge Management System
  - Digital Twin Documentation Log

**Frequency:** Monthly HR data review; quarterly PMO review; immediate escalation if a critical single-point risk emerges.

**Responsible Role:** PMO Head of Human Resources and Site Operations Leads

**Adaptation Process:** PMO adjusts recruitment, compensation, mentorship rotations, and geographic redundancy assignments; major retention packages or knowledge-preservation investments are escalated to the PSC.

**Adaptation Trigger:** Any critical skill falls below two trained practitioners, attrition in critical roles exceeds an annual threshold of 8%, or documentation lag exceeds 6 months behind live practice.

### 11. Stakeholder Sentiment and Social License Monitoring, tracking community sentiment, political support, media coverage, legal opposition, investor confidence, and ESG/sustainability performance across the three host regions.
**Monitoring Tools/Platforms:**

  - Site-Level Advisory Board Minutes
  - Sentiment Survey Results
  - Media Monitoring Reports
  - ESG and Sustainability Dashboard
  - Community-Benefit Programme Tracker

**Frequency:** Monthly site-level advisory boards; bi-monthly Stakeholder Engagement and Social License Advisory Group reviews; quarterly public reporting.

**Responsible Role:** Stakeholder Engagement and Social License Advisory Group, supported by the Programme Communications Director

**Adaptation Process:** SESLAG advises adjustments to community engagement and allocation of the community-benefit budget; communications teams respond to emerging issues; permit-threatening or reputation-critical issues are escalated to the PSC.

**Adaptation Trigger:** Negative sentiment trend for two consecutive quarterly surveys, formal legal opposition filed at a site, construction delay caused by community opposition exceeding 6 months, or an annual ESG target miss such as water recovery rate or energy intensity.