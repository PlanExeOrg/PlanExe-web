This plan implies one or more physical locations.

## Requirements for physical locations

- Proximity to CERN for expertise in precision instrumentation, vacuum systems, and large-scale scientific infrastructure
- Proximity to ASML for semiconductor lithography, precision mechatronics, and cleanroom manufacturing capabilities
- Proximity to Zeiss and Fraunhofer for optics, precision manufacturing, and applied industrial R&D
- Availability of large industrial land for modular factory build-out and future expansion
- Access to high-capacity clean energy, water, and advanced utility infrastructure
- Established high-tech industrial ecosystem with specialized suppliers and skilled workforce
- Transport links for feedstock delivery, module logistics, and inter-site coordination
- Supportive zoning and regulatory environment for large-scale R&D and manufacturing facilities

## Location 1
Switzerland / France

Geneva region (CERN proximity)

Meyrin, Switzerland / Pays de Gex, France (CERN campus vicinity)

**Rationale**: Direct proximity to CERN provides access to world-leading expertise in precision instrumentation, vacuum systems, cryogenics, and large-scale scientific infrastructure, aligning with the plan's need for advanced R&D and modular factory development.

## Location 2
Netherlands

Veldhoven / Eindhoven region (ASML proximity)

De Run 6501, 5504 DR Veldhoven, Netherlands

**Rationale**: ASML's Veldhoven/Eindhoven ecosystem offers semiconductor lithography, precision mechatronics, and high-tech manufacturing talent; this is critical for the electronics/FPGA fabrication and cleanroom requirements of the factory system.

## Location 3
Germany

Oberkochen / Southern Germany (Zeiss and Fraunhofer proximity)

Carl-Zeiss-Straße 22, 73447 Oberkochen, Germany, and nearby Fraunhofer institutes

**Rationale**: Zeiss and Fraunhofer are leaders in optics, precision manufacturing, and applied industrial R&D; this location supports optical systems, metrology, and additive/subtractive process development, and is central to German advanced manufacturing networks.

## Location Summary
The plan explicitly requires physical sites near European innovation centers. The three proposed nodes—Geneva/CERN, Veldhoven/ASML, and Oberkochen/Southern Germany—form a federated network that provides complementary expertise in physics, semiconductor lithography, optics, and applied manufacturing, while meeting the need for large industrial land, cleanroom infrastructure, and specialized talent.