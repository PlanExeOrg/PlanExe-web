### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Circulate Draft SteerCo ToR for review by nominated members (CTO, CFO, Head of R&D, Program Director, Independent External Advisor).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 3. Project Manager finalizes the SteerCo ToR based on feedback and obtains approval from the Program Director.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0
- Approval Confirmation

**Dependencies:**

- Feedback Summary
- Draft SteerCo ToR v0.2

### 4. Program Director formally appoints the Steering Committee Chair.

**Responsible Body/Role:** Program Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Email

### 6. Hold the initial Project Steering Committee kick-off meeting to review the ToR, confirm membership, and discuss initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Confirmed Membership List

**Dependencies:**

- Meeting Invitation
- Agenda

### 7. Project Manager drafts initial Terms of Reference (ToR) for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**

- Project Plan Approved

### 8. Circulate Draft PMO ToR for review by nominated members (Project Manager, Project Controller, Risk Manager, Communications Manager, Workstream Leads).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft PMO ToR v0.1
- Nominated Members List Available

### 9. Project Manager finalizes the PMO ToR based on feedback and obtains approval from the Program Director.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0
- Approval Confirmation

**Dependencies:**

- Feedback Summary
- Draft PMO ToR v0.2

### 10. Program Director formally appoints the Project Manager.

**Responsible Body/Role:** Program Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final PMO ToR v1.0

### 11. Project Manager schedules the initial PMO kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Email

### 12. Hold PMO Kick-off Meeting & assign initial tasks (Establish project management standards, Develop a project communication plan, Implement a project risk management process, Set up project tracking and reporting systems).

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Confirmed Membership List

**Dependencies:**

- Meeting Invitation
- Agenda

### 13. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project Plan Approved

### 14. Circulate Draft TAG ToR for review by the Head of Research and Development.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft TAG ToR v0.1

### 15. Project Manager finalizes the TAG ToR based on feedback and obtains approval from the Program Director.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Final TAG ToR v1.0
- Approval Confirmation

**Dependencies:**

- Feedback Summary
- Draft TAG ToR v0.2

### 16. Head of Research and Development identifies and recruits potential members for the Technical Advisory Group (Leading Experts in Additive Manufacturing, Subtractive Manufacturing, Materials Science, Robotics, Electronics, Software Engineering).

**Responsible Body/Role:** Head of Research and Development

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Nominated Members List

**Dependencies:**

- Final TAG ToR v1.0

### 17. Project Manager formally invites nominated members to join the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Invitation Letters

**Dependencies:**

- Nominated Members List

### 18. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Invitation Letters
- Confirmed Membership

### 19. Hold the initial Technical Advisory Group kick-off meeting to review the ToR, confirm membership, and discuss initial priorities.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Confirmed Membership List

**Dependencies:**

- Meeting Invitation
- Agenda

### 20. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.1

**Dependencies:**

- Project Plan Approved

### 21. Circulate Draft ECC ToR for review by the Legal Counsel.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft ECC ToR v0.1

### 22. Project Manager finalizes the ECC ToR based on feedback and obtains approval from the Program Director.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Final ECC ToR v1.0
- Approval Confirmation

**Dependencies:**

- Feedback Summary
- Draft ECC ToR v0.2

### 23. Legal Counsel identifies and nominates potential members for the Ethics & Compliance Committee (Compliance Officer, Environmental Sustainability Manager, Data Protection Officer, Independent Ethics Advisor).

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Nominated Members List

**Dependencies:**

- Final ECC ToR v1.0

### 24. Project Manager formally invites nominated members to join the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Invitation Letters

**Dependencies:**

- Nominated Members List

### 25. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Invitation Letters
- Confirmed Membership

### 26. Hold the initial Ethics & Compliance Committee kick-off meeting to review the ToR, confirm membership, and discuss initial priorities.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Confirmed Membership List

**Dependencies:**

- Meeting Invitation
- Agenda