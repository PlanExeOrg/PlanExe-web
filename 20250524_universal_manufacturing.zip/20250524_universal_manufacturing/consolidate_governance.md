# Governance Audit


## Audit - Corruption Risks

- Bribery or kickbacks in awarding multi-billion-euro construction and cleanroom fit-out contracts at the Geneva, Veldhoven, and Oberkochen sites, including collusive bidding among contractors.
- Conflicts of interest in the public-private consortium where board members or module leads have undisclosed financial ties to equipment vendors (lithography, metrology, robotic actuators) or feedstock suppliers, influencing procurement decisions.
- Nepotism and favouritism in hiring and staffing at partner institutions, inflating headcount or billing the SPV for relatives or affiliated personnel.
- Facilitation payments to regulators (BAFA, CDIU, SECO, local authorities) to expedite export-control licences, environmental permits, zoning approvals, or safety certifications.
- Misuse of confidential commercial and technical information—such as the inter-module interface register, makeability map, digital twin data, or IP valuations—by sharing it with competitors or private investors in exchange for personal gain.
- Trading favours in licensing and IP transactions, for example granting undervalued licensing rights to private consortium partners in return for personal benefits or reciprocal contracts.
- Corrupt procurement of basic feedstock, reagents, or specialised materials through shell suppliers at inflated prices with shared margins.

## Audit - Misallocation Risks

- Overstating component coverage or yield results in gate reports to trigger milestone-based funding releases, thereby channelling budget towards non-performing workstreams.
- Duplicate payments or double-billing for the same R&D services, equipment, or materials across the three federated sites due to fragmented ERP/MES systems and the absence of a consolidated ledger.
- Using the EUR 20 billion contingency reserve as a general slush fund for unrelated cost overruns rather than for defined technical, financial, or currency shocks.
- Gold-plating equipment purchases—such as procuring excessive lithography or metrology capability beyond module needs—and inefficiently allocating the 50 MW clean-energy capacity and cleanroom floor space to low-priority modules.
- Key scientists and engineers from CERN, ASML, Zeiss, and Fraunhofer being allocated to non-project or low-value tasks while their full time and overhead are billed to the SPV.
- Unauthorised use of project feedstock, additive manufacturing tools, cleanroom assets, or digital twin access for external sideline projects or personal purposes.
- Poor record-keeping and opaque handling of EUR/CHF hedging, inter-site transfers, and shared infrastructure costs, causing avoidable currency losses and misreported balances.

## Audit - Procedures

- Annual independent external financial audit of the SPV consolidated accounts and each site's cost centre, with findings reported to the Programme Executive Board and host governments.
- Quarterly internal audit of cash drawdowns, capital calls, and milestone-linked funding releases, verifying that expenditures match reported technical progress.
- Pre-award and post-award procurement audits for all contracts above EUR 50 million, reviewing tender documentation, sole-source justifications, conflicts-of-interest declarations, and actual deliverables, supplemented by forensic audits on high-risk procurement categories.
- Semi-annual export-control and compliance audits by the joint compliance office to verify BAFA, CDIU, and SECO licences, adherence to the technology-transfer matrix, and cross-border movement records.
- Periodic technical audits of the 95% component-coverage claim, sampling makeability-map entries, first-pass yield data, measurement-gate results, and certification-matrix evidence, with involvement of an external technical advisory board.
- Annual cybersecurity and data-integrity audits of the digital twin, MES, and ERP systems per IEC 62443, including reviews of access logs, audit trails, and changes to the controlled interface register.
- Annual physical asset and inventory verification audits, reconciling equipment, feedstock, and cleanroom utilisation against ERP records and project plans.

## Audit - Transparency Measures

- A public programme dashboard updated quarterly, showing budget drawdown versus plan, milestone status, component-coverage percentage, yield metrics, and site-level progress.
- Publication of audited annual financial statements, annual ESG metrics (energy intensity, water recovery rate, waste-to-landfill percentage), and executive summaries in English, German, French, and Dutch.
- Publication of non-confidential minutes and decisions of the Programme Executive Board and funding-gate reviews to consortium partners and host governments, with redactions only where required for IP or export-control protection.
- A public register of major contracts, suppliers, and beneficial owners, including vendor selection criteria and award justifications for contracts above EUR 50 million.
- An independent whistleblower mechanism accessible in all project languages and at all three sites, with clear confidentiality protections and published follow-up procedures.
- Publication of a sanitised version of the controlled interface register and component makeability map as open standards, along with technical gate criteria and demonstration results.
- Stakeholder advisory boards at each site with quarterly public reporting and annual demonstration days showcasing actual progress and coverage evidence.

# Internal Governance Bodies

### 1. Programme Steering Committee

**Rationale for Inclusion:** The 20-year, EUR 200 billion public-private consortium spans four sovereign hosts, multiple independent European sites, and strategic decisions that cannot be delegated to management. A strategic-level body is required to approve phase gates, funding releases, scope changes, and to arbitrate conflicts while maintaining political and investor confidence.

**Responsibilities:**

- Approve programme charter, strategic plan, and annual budget in 2026 real euros.
- Approve phase-gate decisions, funding tranche releases above EUR 10 billion, and five-year re-baselining.
- Approve any change in scope, schedule, or budget exceeding EUR 1 billion or affecting the five critical strategic levers.
- Approve major contracts, IP licensing terms, and public-private partnership arrangements above EUR 500 million.
- Set the strategic risk appetite and oversee the top-10 strategic risk register.
- Appoint and review the Programme Director and standing committee memberships.
- Resolve escalated conflicts from the PMO, Technical Advisory Group, Ethics and Compliance Committee, Audit and Risk Assurance Committee, and Stakeholder Engagement Group.

**Initial Setup Actions:**

- Finalise terms of reference and a conflicts-of-interest policy for all members.
- Elect an independent external Chair and appoint a vice-chair.
- Approve the EUR 200 billion real-euro baseline, risk appetite statement, and programme governance charter.
- Confirm the mandate, authority, and membership of the PMO and all standing committees.
- Schedule quarterly meetings, extraordinary meeting protocols, and reporting standards.
- Establish a classified reporting channel for export-control and commercially sensitive decisions.

**Membership:**

- Independent external Chair (non-executive, with no financial interest in project contractors or partners)
- Four senior representatives of sovereign shareholders (Switzerland, France, Netherlands, Germany)
- Two independent non-executive directors appointed on merit
- One elected representative of the private consortium investors
- European Commission observer (non-voting)
- Programme Director (non-voting, for reporting only)
- Co-opted technical and legal experts as required for agenda items (non-voting)

**Decision Rights:** Strategic decisions only: approves annual budgets, phase and funding gates, changes exceeding EUR 1 billion, contracts above EUR 500 million, strategic-lever changes such as miniaturization pathway, funding phasing, interface covenant, coverage sequencing, and external input allowance, plus all matters escalated from lower bodies.

**Decision Mechanism:** Consensus preferred; if not reached, 75% supermajority of voting members. If still deadlocked, the independent Chair has the final casting vote after consulting external advisers. Decisions affecting sovereign commitments additionally require support of at least one independent non-executive director.

**Meeting Cadence:** Quarterly regular meetings, with extraordinary meetings within 10 working days when a critical risk or escalation arises.

**Typical Agenda Items:**

- Strategic risk dashboard and top-10 risk review
- Phase-gate and milestone status against the 2026-2046 master schedule
- Budget drawdown, contingency reserve usage, five-year re-baselining and EUR/CHF hedging results
- Decisions on strategic levers: miniaturization pathway, interface covenant, coverage sequencing, external input allowance
- Major contracts and IP licensing items above EUR 500 million
- Reports from ARAC, Ethics and Compliance Committee, TAG, and Stakeholder Engagement Group
- Political, regulatory, and intergovernmental issues

**Escalation Path:** Final internal authority. No internal escalation for programme-level decisions; treaty-level or shareholder-consent issues are escalated to the intergovernmental shareholder council of the SPV.
### 2. Programme Management Office

**Rationale for Inclusion:** The programme's operational complexity - federated sites near CERN, ASML, Zeiss and Fraunhofer, 18,000 staff, 150,000 m2 of floor space, and a 20-year integrated schedule - requires a dedicated operational management body to execute the approved plan, coordinate module teams, and manage day-to-day risks below strategic thresholds.

**Responsibilities:**

- Maintain the integrated master schedule, cost baseline, and resource plan across all sites.
- Execute the annual plan and phase objectives approved by the Programme Steering Committee.
- Manage the operational risk register, interface register, makeability map, and coverage/yield metrics.
- Allocate budgets, staff, and facility capacity across workstreams within approved delegations.
- Run procurement processes below EUR 500 million and prepare larger contract requests for the PSC.
- Coordinate module development teams and the prime integrator to ensure interface compliance and integration readiness.
- Track technical gate readiness and arrange gate reviews.
- Implement PSC and committee decisions and report progress.

**Initial Setup Actions:**

- Establish PMO charter, reporting standards, and project-management methodology.
- Create the integrated master schedule, 2026 real-euro cost baseline, and single operational risk register.
- Appoint workstream leads, site operations leads, and prime-integrator liaison.
- Define delegation thresholds, escalation criteria, and decision templates.
- Configure digital twin, MES/ERP, and reporting dashboards for federated operation.

**Membership:**

- Programme Director (Chair, executive owner)
- Deputy Programme Director
- Head of Project Controls
- Head of Engineering and Technical Integration
- Site Operations Leads for Geneva/CERN, Veldhoven/ASML, and Oberkochen/Zeiss-Fraunhofer
- Prime Integrator Programme Manager
- Head of Procurement
- Head of Finance
- Head of Risk
- Head of Digital and Information Systems
- Ethics and Compliance liaison (non-voting advisor)

**Decision Rights:** Operational decisions within the approved plan: manages annual budget reallocations up to EUR 1 billion, enters contracts below EUR 500 million, adjusts schedules with no change to final Q4 2046 date, updates non-frozen interface register items, and allocates resources. Cannot change strategic levers, phase gates, total budget, or external input policy.

**Decision Mechanism:** Majority vote of core members. For urgent operational matters, the Programme Director may decide after consultation, with retroactive ratification at the next meeting. If site leads are deadlocked, the Programme Director has the casting vote; if a conflict of interest applies, the Deputy chairs that decision.

**Meeting Cadence:** Weekly operations stand-up and monthly integrated delivery review.

**Typical Agenda Items:**

- Critical-path schedule status and milestone slips
- Budget burn versus plan and contingency usage
- Interface register compliance and integration issues
- Makeability map updates and component coverage percentage
- Operational risk register, top operational risks and mitigation actions
- Procurement pipeline and contract execution
- Site operations: HSE, staffing, logistics, facilities
- Open actions from PSC, ARAC, Ethics and Compliance Committee, and TAG

**Escalation Path:** Escalates to the Programme Steering Committee for scope or budget changes beyond delegation, strategic-lever changes, unresolved cross-site disputes, or risks rated critical. Financial-control and integrity findings are concurrently reported to the Audit and Risk Assurance Committee.
### 3. Technical Advisory Group

**Rationale for Inclusion:** Given unresolved technology risk in miniaturization, semiconductor fabrication, additive and subtractive manufacturing, metrology, and the 95% coverage target, the programme needs independent external technical assurance to test assumptions, validate yield and TRL trajectories, and prevent groupthink. External members with no commercial stake ensure technical credibility.

**Responsibilities:**

- Review and challenge technology readiness levels, first-pass yields, process capability indices, and yield learning curves.
- Validate the component makeability map and coverage sequencing against technical feasibility.
- Assess technical risks of the miniaturization pathway, electronics fabrication sourcing, and feedstock resilience architectures.
- Recommend technical gate criteria, measurement standards, and demonstration protocols.
- Advise on interface-freeze timing and inter-module integration strategy.
- Identify emerging technologies or descoping options to preserve the 20-year schedule.
- Provide a written technical risk assessment to the PSC before each phase gate.

**Initial Setup Actions:**

- Appoint an independent Chair and internationally recognised experts with no commercial ties to project suppliers.
- Approve terms of reference, confidentiality, and conflicts-of-interest guidelines.
- Review the initial makeability map, TRL inventory, and yield assumptions from the project plan.
- Set the technical gate review calendar aligned with the 2026-2046 phases.
- Define metrics for technology risk monitoring that feed the PSC risk dashboard.

**Membership:**

- Independent external Chair (distinguished technologist, non-voting on PSC/PMO)
- 8-12 independent experts from non-partner institutions covering advanced manufacturing, semiconductor fabrication, metrology, robotics, materials science, systems engineering, and aerospace
- Two academic representatives from non-participating universities
- Programme Chief Engineer (technical secretary, non-voting)
- PMO representative (non-voting, attends at TAG invitation)

**Decision Rights:** Advisory and assurance only: issues recommendations on technical gate criteria, makeability map validation, interface-freeze timing, and descoping options. It has no authority to approve budget, schedule, or contracts; the PSC and PMO retain decision authority.

**Decision Mechanism:** Consensus preferred; when no consensus, recommendations are taken by majority and minority opinions are recorded. Dissenting views are submitted to the PSC. There is no casting vote on technical truth; the external Chair ensures the final advice clearly presents the balance of expert evidence.

**Meeting Cadence:** Quarterly full-group meetings, with focused deep-dive panels before each major technical gate and extraordinary sessions for critical technical risks.

**Typical Agenda Items:**

- TRL and yield status for electronics, FPGAs, miniaturized modules, and propulsion cells
- Component coverage percentage and remaining coverage gaps
- Makeability map updates and re-sequencing recommendations
- Readiness assessment for upcoming technical gates
- Interface freeze review and integration risk
- Feedstock variability and metrology data from in-line sensors
- Emerging technology alternatives and descope triggers

**Escalation Path:** Escalates technical risks or disagreements that exceed the PSC risk appetite directly to the Programme Steering Committee, with a copy to the Programme Management Office for immediate mitigation planning.
### 4. Ethics and Compliance Committee

**Rationale for Inclusion:** The programme's multi-jurisdiction footprint in Switzerland, France, the Netherlands and Germany, export-control obligations to BAFA, CDIU and SECO, GDPR requirements, corruption risks, and public-private funding demand a dedicated independent compliance body to own ethics and regulatory compliance oversight and prevent integrity failures that could threaten the EUR 200 billion mandate.

**Responsibilities:**

- Own the compliance and ethics framework, including GDPR and data protection, anti-corruption, conflicts of interest, whistleblower protection, and ethical research conduct.
- Oversee export-control classification and licensing with BAFA, CDIU, and SECO, and the technology-transfer matrix.
- Ensure compliance with ATEX, ISO 14644, ISO 45001, environmental permits, and EU Green Deal requirements.
- Review procurement, contracting, and licensing transactions for corruption risk and conflicts of interest.
- Direct the joint compliance office and cross-border regulatory task force.
- Approve compliance policies and monitor a programme-wide training and awareness programme.
- Investigate compliance breaches and require corrective actions.

**Initial Setup Actions:**

- Adopt terms of reference with a direct reporting line to the Programme Steering Committee.
- Appoint an independent external chair with international compliance and legal expertise.
- Conduct a compliance risk assessment across all Swiss, French, Dutch, and German sites.
- Approve the code of conduct, conflicts-of-interest policy, anti-corruption programme, and GDPR data-governance framework.
- Establish an independent multilingual whistleblower mechanism and joint compliance office.

**Membership:**

- Independent external Chair (compliance/international law, no conflict of interest)
- Two independent external compliance and data-protection experts
- SPV Chief Compliance Officer (executive secretary, non-voting)
- SPV Legal Director (non-voting advisor)
- Export-control liaison officers from the joint compliance office, one per host country
- Internal Audit liaison from ARAC (non-voting)
- Programme Director attends only when invited (non-voting)

**Decision Rights:** Within its compliance mandate, the Committee can stop non-compliant activities, suspend an export transfer or procurement, require remediation, and approve compliance policy. It cannot change technical or commercial objectives; material business-impacting remedies require PSC ratification.

**Decision Mechanism:** Majority vote of voting members; the external Chair has a casting vote on a tie. For material compliance findings, concurrence of at least one independent external member is required. Suspected criminal conduct must be reported unanimously by independent members to the PSC and, where legally required, to competent authorities.

**Meeting Cadence:** Monthly regular meetings, with extraordinary sessions within five working days for potential material compliance breaches.

**Typical Agenda Items:**

- Export-control license status, pending classifications, and technology-transfer movements
- GDPR and data-protection issues in the digital twin, MES/ERP, and cross-border data flows
- Corruption-risk indicators in major procurement and licensing transactions
- Whistleblower reports, investigations, and follow-up actions
- Compliance with ATEX, ISO 14644, ISO 45001, environmental regulations, and EU Green Deal
- Conflicts-of-interest declarations and management actions
- Ethics training completion rates and awareness campaign updates

**Escalation Path:** Escalates material or unresolved compliance issues to the Programme Steering Committee. Suspected fraud or criminal conduct involving PSC members is escalated to the SPV's external auditor and competent national authorities.
### 5. Audit and Risk Assurance Committee

**Rationale for Inclusion:** A EUR 200 billion, 20-year programme requires independent assurance over financial integrity, internal controls, and risk management. This committee protects against financial misallocation, undisclosed risks, and fraud by providing an arms-length oversight layer between the Programme Steering Committee and management.

**Responsibilities:**

- Oversee the enterprise risk management framework and maintain the strategic risk register independent of management.
- Review and challenge risk appetite, contingency reserve usage, and five-year re-baselining.
- Approve the internal audit plan and external audit scope; monitor audit findings and management actions.
- Review financial reporting, capital calls, drawdowns, and EUR/CHF hedging policies.
- Direct audits of the 95% coverage claim, makeability map, yield data, and certification evidence.
- Monitor cybersecurity and data-integrity audits per IEC 62443.
- Coordinate with the Ethics and Compliance Committee on fraud and corruption risk.

**Initial Setup Actions:**

- Establish the committee charter and appoint an independent external chair.
- Approve the risk taxonomy, risk-appetite statement, and single enterprise risk register.
- Appoint external auditors through a PSC-approved procurement.
- Commission the first financial-control audit and EUR/CHF hedging policy review.
- Define the audit sampling plan for coverage and yield claims.

**Membership:**

- Independent external Chair (senior audit/risk professional)
- Two independent external members with financial, audit, or enterprise-risk expertise
- One representative of the sovereign shareholders' audit bodies (non-voting)
- SPV Chief Risk Officer (executive secretary, non-voting)
- SPV Chief Financial Officer (non-voting attendee)
- Internal Audit Director (non-voting)
- Chair of Ethics and Compliance Committee (liaison, non-voting)

**Decision Rights:** Decision rights over assurance activities: approves internal and external audit plans, sets risk methodology, can require corrective actions for control deficiencies, and can recommend rejection of financial statements to the PSC. Cannot approve budget, scope, or contracts; these remain with the PSC and PMO.

**Decision Mechanism:** Decisions by majority of members. The independent Chair holds the casting vote on ties. Audit opinions on the SPV's financial statements require unanimous support of the independent members before being submitted to the PSC.

**Meeting Cadence:** Quarterly, plus extraordinary meetings within 10 working days after a major incident, material audit finding, or emerging strategic risk.

**Typical Agenda Items:**

- Enterprise risk register review: top risks, trends, and mitigation status
- Internal and external audit findings and management action tracking
- Capital calls, drawdown accuracy, and contingency reserve usage
- EUR/CHF hedging outcomes and five-year re-baselining scenarios
- Cybersecurity and data-integrity audit results
- Audit sampling of 95% coverage claims and yield data
- Coordination items with Ethics and Compliance on fraud and corruption

**Escalation Path:** Escalates material control failures, unmitigated critical risks, and suspected fraud to the Programme Steering Committee; illegal acts are reported to external regulators or auditors as required by law.
### 6. Stakeholder Engagement and Social License Advisory Group

**Rationale for Inclusion:** The programme depends on enduring political support and social acceptance across four countries and three local site communities. A dedicated advisory group with external civil-society and investor representation is needed to monitor sentiment, strengthen transparency, and de-risk the one-to-three-year legal and reputational threats identified in the risk assessment.

**Responsibilities:**

- Advise the PSC and PMO on stakeholder engagement, communications, and transparency.
- Oversee site-level stakeholder advisory boards near Geneva, Veldhoven, and Oberkochen.
- Monitor political, community, investor, and NGO sentiment and identify social-license risks.
- Review and advise on the EUR 2 billion community-benefit programme, local employment, education, and infrastructure commitments.
- Review quarterly public reporting and annual ESG and sustainability metrics.
- Support annual demonstration days and multilingual public engagement.
- Escalate reputational and political risks to the PSC.

**Initial Setup Actions:**

- Form site-level advisory boards with local mayors, community representatives, environmental NGOs, and employer representatives.
- Approve the stakeholder engagement and transparency plan.
- Conduct baseline sentiment assessments in all three host regions.
- Define social-license indicators and reporting cadence.
- Agree the community-benefit budget allocation process with the PMO and PSC.

**Membership:**

- Independent external Chair (community engagement/communications expert, non-voting on PSC)
- Representatives from local communities at each site (external)
- NGO representatives from environmental and social organisations (external)
- Private investor and future licensee representatives (external)
- Host-country government liaison officers, one per country (non-voting)
- Programme Communications Director (secretary, non-voting)
- PMO representative (non-voting liaison)

**Decision Rights:** Advisory on programmes and policy, with delegated authority to allocate the annual community-engagement budget up to an agreed threshold such as EUR 20 million per site per year within the PSC-approved plan. It may approve site-level public-reporting formats but cannot change technical scope or schedule.

**Decision Mechanism:** Consensus-based decisions; where consensus fails, a majority recommendation with dissenting views is transmitted to the PSC. The external Chair has a procedural casting vote; substantive disputes are escalated rather than resolved by the Chair.

**Meeting Cadence:** Bi-monthly full-group meetings; site-level advisory boards meet monthly.

**Typical Agenda Items:**

- Community sentiment and issue tracking at the three sites
- Political risk and host-government engagement updates
- Review of quarterly public reports and transparency initiatives
- ESG metrics: energy intensity, water recovery, waste, net-zero progress
- Community-benefit programme commitments and delivery status
- Investor communication and licensing transparency
- Planning for annual demonstration days and public VIP visits

**Escalation Path:** Escalates reputational, political, or community issues that could delay permits or funding to the Programme Steering Committee; urgent communications issues are referred to the Programme Director for immediate action.

# Governance Implementation Plan

### 1. SPV Founding Shareholder Group ratifies the governance formation mandate, appoints an Interim Programme Director to act as Formation Lead, and authorises the Governance Implementation Workstream to establish the six internal governance bodies.

**Responsible Body/Role:** SPV Founding Shareholder Group (intergovernmental sponsor authority)

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Formation mandate resolution
- Interim Programme Director appointment letter
- Governance implementation workstream charter

**Dependencies:**

- Intergovernmental SPV agreement signed
- Four sovereign partners confirmed
- Programme kick-off authorisation received

### 2. Interim Programme Director, supported by SPV Legal Counsel, drafts the Governance Implementation Charter defining the establishment sequence, appointment authorities, target dates, dependencies, and delegated powers for each governance body.

**Responsible Body/Role:** Interim Programme Director and SPV Legal Counsel

**Suggested Timeframe:** Project Week 1-2

**Key Outputs/Deliverables:**

- Draft Governance Implementation Charter v0.1

**Dependencies:**

- Interim Programme Director appointed
- Governance body mandate agreed

### 3. SPV Founding Shareholder Group reviews and approves the Governance Implementation Charter and formally authorises the establishment of the Programme Steering Committee (PSC) as the first internal governance body.

**Responsible Body/Role:** SPV Founding Shareholder Group

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Approved Governance Implementation Charter
- Formal authorisation to form the PSC

**Dependencies:**

- Draft Governance Implementation Charter submitted

### 4. SPV Legal Counsel, instructed by the SPV Founding Shareholder Group, drafts the Programme Steering Committee Terms of Reference including responsibilities, decision rights, decision mechanism, meeting cadence, escalation path, and conflicts-of-interest policy.

**Responsible Body/Role:** SPV Legal Counsel

**Suggested Timeframe:** Project Week 2-3

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1
- Draft PSC conflicts-of-interest policy

**Dependencies:**

- Governance Implementation Charter approved
- PSC formation authorised

### 5. SPV Founding Shareholder Group and private consortium partners nominate the four sovereign shareholder representatives and the private consortium investor representative to the PSC, and the European Commission is invited to nominate a non-voting observer.

**Responsible Body/Role:** SPV Founding Shareholder Group and Private Consortium Partners

**Suggested Timeframe:** Project Week 3-4

**Key Outputs/Deliverables:**

- Confirmed PSC nominee list
- Signed nomination forms
- European Commission observer invitation

**Dependencies:**

- Draft PSC ToR v0.1 available
- PSC membership criteria agreed

### 6. SPV Founding Shareholder Group completes the external search and due diligence and formally appoints the independent external PSC Chair and two independent non-executive directors, obtaining signed conflicts-of-interest declarations.

**Responsible Body/Role:** SPV Founding Shareholder Group

**Suggested Timeframe:** Project Week 4-5

**Key Outputs/Deliverables:**

- PSC Chair appointment letter
- Independent non-executive director appointment letters
- Signed conflicts-of-interest declarations

**Dependencies:**

- PSC nominee list received
- External search completed
- Due-diligence clearances obtained

### 7. Interim Programme Director and SPV CFO prepare the PSC inaugural pack including the final PSC ToR v1.0, EUR 200 billion 2026 real-euro baseline, draft risk appetite statement, programme governance charter, and proposed quarterly meeting calendar.

**Responsible Body/Role:** Interim Programme Director and SPV CFO

**Suggested Timeframe:** Project Week 4-5

**Key Outputs/Deliverables:**

- PSC inaugural pack v0.9
- Draft risk appetite statement
- Proposed PSC quarterly calendar

**Dependencies:**

- PSC Chair and independent directors appointed
- Draft PSC ToR finalised

### 8. SPV Founding Shareholder Group reviews and approves the final PSC ToR v1.0 and the PSC inaugural pack, and authorises the PSC to convene its inaugural meeting.

**Responsible Body/Role:** SPV Founding Shareholder Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Approved PSC ToR v1.0
- Approved PSC inaugural pack
- Authorisation to convene the PSC

**Dependencies:**

- PSC inaugural pack prepared
- PSC appointments completed

### 9. Hold the PSC inaugural meeting: adopt the PSC ToR v1.0, elect the vice-chair, approve the EUR 200 billion 2026 real-euro baseline, risk appetite statement, programme governance charter, quarterly meeting calendar, and classified reporting channel.

**Responsible Body/Role:** PSC (inaugural meeting chaired by the newly appointed independent Chair)

**Suggested Timeframe:** Project Week 5-6

**Key Outputs/Deliverables:**

- Adopted PSC ToR v1.0
- Elected PSC vice-chair
- Approved EUR 200 billion real-euro baseline
- Approved risk appetite statement
- Approved programme governance charter
- PSC meeting minutes with action items

**Dependencies:**

- PSC ToR and inaugural pack approved by SPV Founding Shareholder Group
- PSC members, Chair, and independent directors appointed

### 10. PSC confirms the mandate, authority, and formation directives for the Programme Management Office (PMO), Technical Advisory Group (TAG), Ethics and Compliance Committee (ECC), Audit and Risk Assurance Committee (ARAC), and Stakeholder Engagement and Social License Advisory Group (SESLAG), setting nomination and ToR deadlines.

**Responsible Body/Role:** PSC

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Confirmed mandates for all five standing bodies
- Formation directives
- Nomination and ToR deadline schedule

**Dependencies:**

- PSC inaugural meeting completed
- Programme governance charter approved

### 11. Interim Programme Director, as PMO Chair-designate, finalises the PMO ToR, project-management methodology, delegation thresholds, escalation criteria, and decision templates, incorporating the PSC formation directives.

**Responsible Body/Role:** Interim Programme Director (PMO Chair-designate)

**Suggested Timeframe:** Project Week 6-7

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.3
- Delegation and escalation framework
- PMO project-management methodology summary

**Dependencies:**

- PSC formation directives issued

### 12. PSC approves the PMO ToR v1.0 and formally appoints or confirms the PMO membership, including the Programme Director as Chair, Deputy Programme Director, Heads of Project Controls, Engineering and Technical Integration, Procurement, Finance, Risk, Digital and Information Systems, Site Operations Leads, Prime Integrator Programme Manager, and Ethics and Compliance liaison.

**Responsible Body/Role:** PSC

**Suggested Timeframe:** Project Week 7-8

**Key Outputs/Deliverables:**

- Approved PMO ToR v1.0
- PMO appointment letters
- PMO organisation chart and role descriptions

**Dependencies:**

- PMO ToR draft finalised
- PSC approval slot available

### 13. Hold the PMO kick-off meeting and first integrated delivery review: adopt the PMO ToR, confirm delegated authorities, and assign initial ownership for the integrated master schedule, cost baseline, risk register, interface register, makeability map, and dashboard configuration.

**Responsible Body/Role:** PMO (kick-off meeting chaired by the Programme Director)

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Adopted PMO operating procedures
- PMO meeting minutes with action items
- PMO workstream ownership matrix

**Dependencies:**

- PSC approval of PMO ToR and membership

### 14. PMO operationalises the integrated management system: create the integrated master schedule, 2026 real-euro cost baseline, single operational risk register, controlled interface register, makeability map, coverage and yield metrics, and digital-twin, MES, and ERP reporting dashboards.

**Responsible Body/Role:** PMO (Head of Project Controls and Head of Digital and Information Systems under the Programme Director)

**Suggested Timeframe:** Project Week 8-12

**Key Outputs/Deliverables:**

- Integrated master schedule v0.1
- 2026 real-euro cost baseline v1.0
- Operational risk register v0.1
- Controlled interface register v0.1
- Makeability map v0.1
- Dashboard prototypes

**Dependencies:**

- PMO kick-off meeting held
- Programme baseline data available from project plan

### 15. SPV Chief Engineer (designate) and Interim Programme Director draft the TAG ToR, expert role profiles, independence and conflicts-of-interest criteria, and a draft technical gate review calendar aligned to the 2026-2046 programme phases.

**Responsible Body/Role:** SPV Chief Engineer (designate) and Interim Programme Director

**Suggested Timeframe:** Project Week 6-8

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.2
- Expert selection and independence criteria
- Draft technical gate review calendar

**Dependencies:**

- PSC formation directives issued
- Initial makeability map and TRL inventory available

### 16. PSC approves the TAG ToR v1.0 and appoints a TAG selection panel, chaired by an independent PSC non-executive director, to run the search for an independent Chair and 8-12 external experts from non-partner institutions.

**Responsible Body/Role:** PSC

**Suggested Timeframe:** Project Week 8-9

**Key Outputs/Deliverables:**

- Approved TAG ToR v1.0
- TAG selection panel membership
- Search mandate and expert role specifications

**Dependencies:**

- Draft TAG ToR submitted
- Expert selection criteria agreed

### 17. TAG selection panel completes candidate identification, due diligence, and reference checks, and submits a recommended slate of TAG Chair and independent experts to the PSC for formal appointment.

**Responsible Body/Role:** TAG selection panel (temporary, chaired by PSC independent non-executive director)

**Suggested Timeframe:** Project Week 9-11

**Key Outputs/Deliverables:**

- Recommended TAG membership slate
- Due-diligence summaries
- Independence and conflict-of-interest declarations

**Dependencies:**

- TAG selection panel appointed
- Search mandate approved

### 18. PSC formally appoints the TAG Chair and independent expert members, and confirms the Programme Chief Engineer as technical secretary and the PMO representative as non-voting observer.

**Responsible Body/Role:** PSC

**Suggested Timeframe:** Project Week 11-12

**Key Outputs/Deliverables:**

- TAG appointment letters
- Signed confidentiality agreements
- Final TAG membership list

**Dependencies:**

- Recommended TAG slate received
- Independence checks cleared

### 19. Hold the TAG inaugural meeting: adopt the TAG ToR and confidentiality and conflict-of-interest guidelines; review the initial makeability map, TRL inventory, yield assumptions, and coverage sequencing; and validate the technical gate review calendar.

**Responsible Body/Role:** TAG (inaugural meeting chaired by the independent TAG Chair)

**Suggested Timeframe:** Project Week 12-14

**Key Outputs/Deliverables:**

- Adopted TAG operating guidelines
- Initial TAG technical risk assessment
- Validated technical gate review calendar
- TAG meeting minutes with action items

**Dependencies:**

- TAG members formally appointed
- Makeability map v0.1 and operational risk register available

### 20. SPV Chief Compliance Officer (designate) and SPV Legal Director draft the ECC ToR, code of conduct, conflicts-of-interest policy, anti-corruption programme, GDPR data-governance framework, and an initial compliance risk assessment plan covering all host-country sites.

**Responsible Body/Role:** SPV Chief Compliance Officer (designate) and SPV Legal Director

**Suggested Timeframe:** Project Week 6-8

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.2
- Draft code of conduct
- Compliance risk assessment plan
- Whistleblower framework design

**Dependencies:**

- PSC formation directives issued
- Regulatory and export-control baseline established

### 21. PSC approves the ECC ToR v1.0, appoints the independent external ECC Chair and two independent external compliance and data-protection experts, and confirms the SPV Chief Compliance Officer as executive secretary and host-country export-control liaison officers as non-voting members.

**Responsible Body/Role:** PSC

**Suggested Timeframe:** Project Week 8-10

**Key Outputs/Deliverables:**

- Approved ECC ToR v1.0
- ECC appointment letters
- Host-country liaison nominations
- Signed conflicts-of-interest declarations

**Dependencies:**

- Draft ECC ToR submitted
- Candidate due diligence completed

### 22. Hold the ECC inaugural meeting: adopt the ECC ToR and compliance policies, establish the joint compliance office, launch the independent whistleblower mechanism, and initiate the cross-border compliance risk assessment.

**Responsible Body/Role:** ECC (inaugural meeting chaired by the independent external Chair)

**Suggested Timeframe:** Project Week 10-12

**Key Outputs/Deliverables:**

- Adopted ECC ToR and policies
- Joint compliance office mandate
- Whistleblower mechanism launched
- Compliance risk assessment kickoff report

**Dependencies:**

- ECC members formally appointed
- Draft compliance policies approved by PSC

### 23. SPV Chief Risk Officer (designate) and SPV CFO draft the ARAC charter, risk taxonomy, enterprise risk-management methodology, internal and external audit scope, audit sampling plan for 95% coverage claims, and EUR/CHF hedging review terms.

**Responsible Body/Role:** SPV Chief Risk Officer (designate) and SPV CFO

**Suggested Timeframe:** Project Week 6-8

**Key Outputs/Deliverables:**

- Draft ARAC charter v0.2
- Risk taxonomy v0.1
- Proposed audit and hedging review scope

**Dependencies:**

- PSC formation directives issued
- PSC risk appetite statement approved

### 24. PSC approves the ARAC charter v1.0, appoints the independent external ARAC Chair and two independent external members, and confirms the sovereign shareholders audit representative, SPV CFO, SPV CRO, and Internal Audit Director as non-voting attendees.

**Responsible Body/Role:** PSC

**Suggested Timeframe:** Project Week 8-10

**Key Outputs/Deliverables:**

- Approved ARAC charter v1.0
- ARAC appointment letters
- Non-voting participant confirmations

**Dependencies:**

- Draft ARAC charter submitted
- Candidate due diligence completed

### 25. Hold the ARAC inaugural meeting: adopt the ARAC charter, approve the enterprise risk register and risk methodology, approve the external audit procurement process, and commission the first financial-control audit and EUR/CHF hedging policy review.

**Responsible Body/Role:** ARAC (inaugural meeting chaired by the independent ARAC Chair)

**Suggested Timeframe:** Project Week 10-12

**Key Outputs/Deliverables:**

- Adopted ARAC charter
- Approved risk methodology
- External audit procurement plan
- Terms of reference for first financial-control and hedging reviews

**Dependencies:**

- ARAC members formally appointed
- Risk taxonomy and PSC risk appetite available

### 26. ARAC, supported by PMO Procurement, runs the external auditor selection within PSC-approved parameters, evaluates tenders, and appoints the SPV external auditor.

**Responsible Body/Role:** ARAC (supported by PMO Procurement)

**Suggested Timeframe:** Project Week 12-14

**Key Outputs/Deliverables:**

- Tender evaluation summary
- External auditor appointment letter
- Signed external audit engagement contract

**Dependencies:**

- ARAC inaugural meeting held
- PSC procurement parameters defined

### 27. Programme Communications Director (designate) and PMO liaison draft the SESLAG ToR, stakeholder engagement and transparency plan, social-license indicators, and community-benefit allocation process.

**Responsible Body/Role:** Programme Communications Director (designate) and PMO liaison

**Suggested Timeframe:** Project Week 6-8

**Key Outputs/Deliverables:**

- Draft SESLAG ToR v0.2
- Stakeholder engagement and transparency plan
- Social-license KPI definitions
- Community-benefit allocation process draft

**Dependencies:**

- PSC formation directives issued
- Stakeholder analysis from project plan available

### 28. PSC approves the SESLAG ToR v1.0 and membership categories; host governments, local communities, environmental NGOs, private investors, and future licensees submit nominations for external members.

**Responsible Body/Role:** PSC with host-government liaison officers and external stakeholder groups

**Suggested Timeframe:** Project Week 8-10

**Key Outputs/Deliverables:**

- Approved SESLAG ToR v1.0
- Membership category guidance
- Received stakeholder nominations

**Dependencies:**

- Draft SESLAG ToR submitted
- PSC approval available

### 29. PSC appoints the independent external SESLAG Chair and confirms the external members, the Programme Communications Director as secretary, and government liaison officers as non-voting members.

**Responsible Body/Role:** PSC

**Suggested Timeframe:** Project Week 10-12

**Key Outputs/Deliverables:**

- SESLAG appointment letters
- Confirmed SESLAG membership
- Signed conflicts-of-interest declarations

**Dependencies:**

- SESLAG nominations received
- Independent Chair due diligence completed

### 30. Hold the SESLAG inaugural meeting and form the three site-level advisory boards near Geneva/CERN, Veldhoven/ASML, and Oberkochen/Zeiss-Fraunhofer; approve baseline sentiment assessments, the community-benefit allocation process, and the 2027 public engagement calendar.

**Responsible Body/Role:** SESLAG (inaugural meeting chaired by the independent SESLAG Chair) with site-level engagement leads

**Suggested Timeframe:** Project Week 12-14

**Key Outputs/Deliverables:**

- Adopted SESLAG ToR
- Three site-level advisory boards established
- Baseline sentiment assessments commissioned
- Approved community-benefit allocation process
- 2027 public engagement calendar

**Dependencies:**

- SESLAG members appointed
- Site-level board nominations received

### 31. PSC holds its first quarterly governance review, ratifies the establishment of all five standing committees, approves the consolidated decision-rights matrix, and aligns committee calendars and reporting schedules with the master programme schedule.

**Responsible Body/Role:** PSC

**Suggested Timeframe:** Project Week 14-16

**Key Outputs/Deliverables:**

- Approved consolidated decision-rights matrix
- Formal governance framework v1.0
- Harmonised meeting calendar
- PSC ratification minutes

**Dependencies:**

- All standing committees held inaugural meetings
- PSC quarterly review scheduled

### 32. PMO Governance Secretariat publishes a governance induction pack and runs a joint orientation session for PSC and standing-committee chairs, secretaries, and members to standardise operating procedures, escalation paths, and reporting templates.

**Responsible Body/Role:** PMO Governance Secretariat

**Suggested Timeframe:** Project Week 14-18

**Key Outputs/Deliverables:**

- Governance induction pack
- Joint orientation session materials
- Common reporting templates
- Escalation path quick-reference guide

**Dependencies:**

- Formal governance framework v1.0 approved
- Committee secretariats designated

### 33. PSC and standing committees activate the standing reporting cadence: PSC quarterly, PMO weekly and monthly, TAG quarterly with pre-gate deep-dive panels, ECC monthly, ARAC quarterly, and SESLAG bi-monthly with monthly site-level advisory boards; dashboards are integrated into the digital twin platform.

**Responsible Body/Role:** PMO Governance Secretariat with all governance bodies

**Suggested Timeframe:** Project Week 16-18

**Key Outputs/Deliverables:**

- Standing committee calendars
- Standing agenda templates
- Dashboard access and reporting schedule
- Digital-twin reporting integration

**Dependencies:**

- Formal governance framework v1.0 approved
- PMO dashboards operational

# Decision Escalation Matrix

**Budget Request Exceeding PMO Delegated Authority**
Escalation Level: Programme Steering Committee
Approval Process: PSC review at a scheduled or extraordinary meeting; consensus preferred, failing which a 75% supermajority vote, with the independent Chair holding the final casting vote.
Rationale: The request exceeds the PMO's delegated limits for annual reallocations (up to EUR 1 billion), contracts (below EUR 500 million), or funding tranche releases, and affects the EUR 200 billion 2026 real-euro baseline and sovereign/private funding commitments.
Negative Consequences: Unauthorized spending could breach the programme budget, trigger cash-flow shortfalls, undermine shareholder confidence, and force unplanned scope reductions or programme restructuring.

**Critical Technical Risk Materialization: Electronics Yield Plateau Below 95% Coverage Threshold**
Escalation Level: Programme Steering Committee
Approval Process: PSC reviews the Technical Advisory Group's written risk assessment and yield data, then decides on descoping, coverage re-sequencing, or contingency deployment using consensus or 75% supermajority, with the Chair's casting vote if needed.
Rationale: The technical risk threatens the core 95% component-coverage promise and the 2046 space-readiness date; changing coverage sequencing or external input allowance is a strategic-lever decision beyond PMO authority.
Negative Consequences: If not resolved, the programme could fail its certification, lose funding-gate releases, invalidate the universality claim, and waste up to EUR 200 billion of investment.

**PMO Deadlock on Inter-Module Interface Freeze Timing**
Escalation Level: Programme Steering Committee
Approval Process: PSC arbitrates with input from the prime integrator and Technical Advisory Group; decision by consensus or 75% supermajority, with the Chair's casting vote if needed.
Rationale: The interface covenant is a critical strategic lever, and freezing too early or too late has cross-site integration consequences that the PMO cannot resolve within its delegation.
Negative Consequences: Prolonged deadlock delays parallel module development, forces costly retrofits, and could extend integration by 2-3 years at EUR 5-15 billion additional cost.

**Proposed Major Scope Change: Expanding External Input Allowance Beyond Basic Feedstock**
Escalation Level: Programme Steering Committee
Approval Process: PSC strategic-lever review with sovereign shareholder and private investor input; approval requires consensus or 75% supermajority, and changes affecting sovereign commitments need support of at least one independent non-executive director.
Rationale: External input allowance defines the credibility boundary of the 95% in-factory claim, a critical strategic lever that cannot be changed by the PMO.
Negative Consequences: Unauthorized expansion would undermine the programme's universality promise, reduce investor and space-agency confidence, and create a contested audit position for the 95% certification.

**Reported Ethical and Compliance Breach: Export-Control Violation**
Escalation Level: Ethics and Compliance Committee
Approval Process: ECC launches an independent investigation, can suspend the export transfer or procurement by majority vote, and requires PSC ratification for material business-impacting remedies; suspected criminal conduct is reported to competent authorities.
Rationale: Export-control violations involve multi-jurisdiction legal exposure and require independent review with authority to halt non-compliant activity, not a technical or operational decision.
Negative Consequences: Failure to act could trigger BAFA/CDIU/SECO penalties, export-license revocation, legal liability, and severe reputational damage across the four host countries.

**Material Financial Control Failure or Suspected Fraud in Capital Drawdowns**
Escalation Level: Audit and Risk Assurance Committee
Approval Process: ARAC reviews audit findings and can require corrective actions; material findings and suspected fraud are escalated to the PSC and, where legally required, to external auditors or regulators.
Rationale: Independent assurance over financial integrity and risk is necessary to protect a EUR 200 billion public-private programme from misallocation, undisclosed risks, and fraud.
Negative Consequences: If undetected, financial misstatement or fraud could distort capital calls, trigger premature budget depletion, and destroy the trust of sovereign shareholders and private investors.

**Critical Stakeholder Opposition Threatening Construction Permits at a Host Site**
Escalation Level: Stakeholder Engagement and Social License Advisory Group
Approval Process: SESLAG convenes site-level advisory boards, reviews sentiment data, advises on community-benefit mitigation, and escalates unresolved permit-threatening issues to the PSC.
Rationale: Construction permit delays of 1-3 years and legal battles exceed normal PMO community-relations activity and require stakeholder and political legitimacy management.
Negative Consequences: Continued opposition can delay site construction 6-24 months, add EUR 100-500 million in legal costs, and erode the political support needed to sustain the 20-year programme.

# Monitoring Progress

### 1. Integrated Schedule and Phase-Gate Progress Monitoring against the 2026–2046 master plan, including critical-path analysis, milestone buffers, and phase-gate exit criteria.
**Monitoring Tools/Platforms:**

  - Integrated Master Schedule
  - PMO Delivery Dashboard
  - Phase-Gate Review Packs
  - Digital Twin Reporting Platform

**Frequency:** Weekly PMO operations stand-up; monthly integrated delivery review; phase-gate reviews per master schedule.

**Responsible Role:** Programme Management Office (Head of Project Controls)

**Adaptation Process:** PMO adjusts near-term schedules, resource loading, and inter-site dependencies within delegated authority; schedule slips or scope changes above delegation are escalated to the Programme Steering Committee, which may re-baseline phases or amend gate criteria.

**Adaptation Trigger:** Critical-path milestone slips more than 3 months against the baseline, phase-gate exit criteria are not met within the 12-month buffer, or annual phase slippage tolerance of 10–15% is exceeded.

### 2. 95% Component Coverage and Yield Ramp Monitoring, tracking the makeability map, component coverage percentage, TRLs, first-pass yields, and process capability indices across all component families, with emphasis on complex electronics and FPGAs.
**Monitoring Tools/Platforms:**

  - Component Makeability Map
  - Coverage and Yield Tracking Database
  - Technical Gate Review Packs
  - Public Yield Dashboard
  - TAG Technical Risk Assessments

**Frequency:** Continuous data collection; monthly PMO analysis; quarterly Technical Advisory Group validation; deep-dive panels before each major technical gate.

**Responsible Role:** PMO Head of Engineering and Technical Integration, with Technical Advisory Group independent validation

**Adaptation Process:** TAG recommends coverage re-sequencing, process modifications, or additional parallel process chains; PMO implements approved corrective actions; PSC approves strategic changes to coverage sequencing, external input allowance, or descoping options.

**Adaptation Trigger:** Coverage percentage falls more than 5 percentage points below the planned trajectory at a phase gate, first-pass yield for a critical component class remains below the gate threshold for two consecutive quarterly reviews, or a technical milestone is projected to slip more than 12 months.

### 3. Budget Drawdown, Cost Baseline, and Financial Health Monitoring, including real-euro expenditure, annual drawdowns, contingency reserve usage, EUR/CHF hedging, and capital-call accuracy.
**Monitoring Tools/Platforms:**

  - 2026 Real-Euro Cost Baseline
  - Financial Dashboard
  - Capital Call Tracker
  - EUR/CHF Hedging Report
  - Contingency Reserve Register

**Frequency:** Monthly finance review; quarterly Audit and Risk Assurance Committee review; quarterly PSC review of strategic financial risks.

**Responsible Role:** PMO Head of Finance, with Audit and Risk Assurance Committee oversight

**Adaptation Process:** PMO reforecasts and reallocates within delegated limits; ARAC recommends corrective actions and audit adjustments; PSC approves contingency activation, funding structure changes, or five-year re-baselining.

**Adaptation Trigger:** Projected cumulative drawdown variance exceeds 10% of the annual plan, contingency usage exceeds 20% of the reserve in a single year, EUR/CHF moves outside the hedged band for two consecutive quarters, or capital-call accuracy falls below 95%.

### 4. Public-Private Funding Commitment and Political Support Monitoring, tracking acquisition of the EUR 200 billion funding envelope, sovereign pledges, private co-investment, licensing revenue credibility, and political resilience across the four host countries.
**Monitoring Tools/Platforms:**

  - Public Funding Commitment Tracker
  - Private Investor Pipeline CRM/Spreadsheet
  - Licensing Revenue Model Scenarios
  - Intergovernmental Agreement Status Log
  - Political Risk Dashboard

**Frequency:** Monthly during consortium formation and fundraising; quarterly thereafter; quarterly PSC strategic review.

**Responsible Role:** Programme Director and SPV CFO, with Programme Steering Committee for strategic funding decisions

**Adaptation Process:** PSC renegotiates commitment terms, adjusts the consortium structure, activates contingency or downscaling scenarios, extends capital call schedules, or engages sovereign shareholders; PMO implements the revised drawdown and resource plan.

**Adaptation Trigger:** Public commitments fall below the 70% target or private commitments below the 30% target by an agreed milestone date, projected funding shortfall exceeds EUR 10 billion, a sovereign partner signals reduced commitment, or licensing revenue scenarios indicate private investors cannot achieve the 8–10% IRR threshold.

### 5. Enterprise Risk and Major Risk Register Monitoring, covering technical infeasibility, funding shortfalls, integration failure, regulatory gridlock, supply chain disruption, security, and political risks using leading indicators and mitigation status.
**Monitoring Tools/Platforms:**

  - Single Enterprise Risk Register
  - Top-10 Strategic Risk Dashboard
  - Incident and Near-Miss Reports
  - Risk Appetite Statement
  - Mitigation Action Trackers

**Frequency:** Monthly CRO-led risk review; quarterly ARAC and PSC reviews; extraordinary sessions within 10 working days for critical risks.

**Responsible Role:** SPV Chief Risk Officer, with ARAC independent assurance and PSC risk-appetite authority

**Adaptation Process:** Risk owners update mitigation plans and assign corrective actions; material risks are escalated to the PSC; PSC may reset risk appetite, approve contingency deployment, or mandate strategic descoping.

**Adaptation Trigger:** Any top-10 risk crosses the defined risk-appetite threshold, a new critical risk is identified, a mitigation action is overdue by more than 30 days, or a major incident occurs affecting safety, security, or programme integrity.

### 6. Inter-Module Interface Compliance and Integration Readiness Monitoring, tracking controlled interface register compliance, integration-layer performance, joint integration tests, and interface-freeze timing across federated sites.
**Monitoring Tools/Platforms:**

  - Controlled Interface Register
  - Digital Twin Integration Platform
  - Interface Compliance Simulation Reports
  - Integration Test Log
  - Prime Integrator Monthly Report

**Frequency:** Monthly PMO integration review; monthly prime-integrator report; intensive weekly review during integration phases and before interface-freeze gates.

**Responsible Role:** Prime Integrator Programme Manager and PMO Head of Technical Integration

**Adaptation Process:** PMO arbitrates minor interface deviations and updates non-frozen interface items within delegation; unresolved deadlocks or interface-freeze changes are escalated to the PSC with Technical Advisory Group advice.

**Adaptation Trigger:** Interface non-compliance rate exceeds 5% of tested items, a joint integration test fails, or an interface-freeze milestone slips more than 6 months against the master schedule.

### 7. Miniaturization Pathway and Space-Readiness Progress Monitoring, tracking the two-track macro-scale and miniaturized bench-scale prototypes, merge-gate readiness, footprint reduction, and technology readiness toward space-compatible modules.
**Monitoring Tools/Platforms:**

  - Two-Track Prototype Test Reports
  - Merge-Gate Criteria Scorecard
  - TRL Assessment Tracker
  - Miniaturization Metrics Dashboard
  - Technical Advisory Group Assessments

**Frequency:** Monthly PMO engineering review; quarterly TAG review with pre-gate deep dives; formal merge-gate review at the scheduled gate.

**Responsible Role:** PMO Engineering Lead, with Technical Advisory Group independent technical assurance

**Adaptation Process:** PMO rebalances investment and resources between the macro and miniaturized tracks; TAG recommends merging, delaying, or descoping to a modular scalable architecture; PSC approves strategic pathway changes.

**Adaptation Trigger:** One prototype track fails defined performance thresholds, the merge gate is not ready within the 6-month buffer, or projected space-readiness footprint/performance deviates more than 15% from technical targets.

### 8. Regulatory, Permitting, and Export-Control Compliance Monitoring, tracking construction permits, environmental approvals, dual-use export-control classifications with BAFA, CDIU, and SECO, and the technology-transfer matrix across the four host countries.
**Monitoring Tools/Platforms:**

  - Common Permitting Calendar
  - Export-Control License Tracker
  - Technology-Transfer Matrix
  - Joint Compliance Office Reports
  - Compliance Dashboard

**Frequency:** Bi-weekly during the 2026–2027 front-loading phase; monthly thereafter; monthly Ethics and Compliance Committee review.

**Responsible Role:** Ethics and Compliance Committee and Joint Compliance Office

**Adaptation Process:** Joint compliance office expedites filings, quarantines controlled items, re-sequences cross-border movements, and adjusts the permitting calendar; material regulatory risks are escalated to the PSC for political or intergovernmental intervention.

**Adaptation Trigger:** A construction or environmental permit slips more than 3 months from the common calendar, an export-control classification request exceeds 90 days beyond the expected resolution date, or a compliance finding requires corrective action.

### 9. External Input Allowance and Universality Claim Audit Monitoring, tracking residual external inputs, the elimination roadmap, and the auditability of the 95% in-factory manufacturing claim.
**Monitoring Tools/Platforms:**

  - External Input Register
  - Elimination Roadmap
  - Coverage Audit Reports
  - ARAC Audit Sampling Results
  - Certification Evidence Database

**Frequency:** Quarterly PMO review; annual independent audit; ARAC review of audit evidence at each coverage certification milestone.

**Responsible Role:** Audit and Risk Assurance Committee, with PMO Head of Engineering and external auditors

**Adaptation Process:** PMO assigns process-development resources to bring external inputs in-house and updates the elimination roadmap; ARAC directs corrective actions for audit findings; PSC approves any change to the external input allowance.

**Adaptation Trigger:** External input count or complexity exceeds the approved allowance, the elimination roadmap falls more than 12 months behind schedule, or an audit finds that the 95% coverage claim is not supported by sufficient evidence.

### 10. Workforce and Critical Expertise Retention Monitoring, tracking peak staffing, critical-skill redundancy, attrition, mentorship rotation, and documentation currency to protect two decades of institutional knowledge.
**Monitoring Tools/Platforms:**

  - Workforce Dashboard
  - Critical Skill Coverage Matrix
  - Attrition and Retention Tracker
  - Knowledge Management System
  - Digital Twin Documentation Log

**Frequency:** Monthly HR data review; quarterly PMO review; immediate escalation if a critical single-point risk emerges.

**Responsible Role:** PMO Head of Human Resources and Site Operations Leads

**Adaptation Process:** PMO adjusts recruitment, compensation, mentorship rotations, and geographic redundancy assignments; major retention packages or knowledge-preservation investments are escalated to the PSC.

**Adaptation Trigger:** Any critical skill falls below two trained practitioners, attrition in critical roles exceeds an annual threshold of 8%, or documentation lag exceeds 6 months behind live practice.

### 11. Stakeholder Sentiment and Social License Monitoring, tracking community sentiment, political support, media coverage, legal opposition, investor confidence, and ESG/sustainability performance across the three host regions.
**Monitoring Tools/Platforms:**

  - Site-Level Advisory Board Minutes
  - Sentiment Survey Results
  - Media Monitoring Reports
  - ESG and Sustainability Dashboard
  - Community-Benefit Programme Tracker

**Frequency:** Monthly site-level advisory boards; bi-monthly Stakeholder Engagement and Social License Advisory Group reviews; quarterly public reporting.

**Responsible Role:** Stakeholder Engagement and Social License Advisory Group, supported by the Programme Communications Director

**Adaptation Process:** SESLAG advises adjustments to community engagement and allocation of the community-benefit budget; communications teams respond to emerging issues; permit-threatening or reputation-critical issues are escalated to the PSC.

**Adaptation Trigger:** Negative sentiment trend for two consecutive quarterly surveys, formal legal opposition filed at a site, construction delay caused by community opposition exceeding 6 months, or an annual ESG target miss such as water recovery rate or energy intensity.

# Governance Extra

## Governance Validation Checks

1. Completeness Confirmation: All core requested components are present, including audit and integrity arrangements, six internal governance bodies (PSC, PMO, TAG, ECC, ARAC, SESLAG), a sequenced implementation plan from founding mandate to standing cadence, a decision escalation matrix covering seven issue types, and a monitoring plan covering eleven progress areas. No fundamental element of the governance framework appears to be missing.
2. Internal consistency: The implementation plan establishes the six bodies in a logical sequence, the escalation matrix routes issues to bodies whose Stage 2 mandates match the issue type, and the monitoring approaches assign responsibilities to roles that correspond to Stage 2 mandates. No internal body referenced in later stages is absent from Stage 2, and the PMO/PSC delegation thresholds are broadly respected across the matrix.
3. Gap: The ultimate sponsor and arbiter above the PSC is not fully defined. The SPV Founding Shareholder Group appears only in the implementation plan and as an escalation endpoint for treaty-level issues, but it has no terms of reference, decision mechanism, meeting cadence, or defined relationship to the PSC and sovereign shareholders. This creates an authority vacuum for treaty-level or existential programme decisions.
4. Gap: Delegation below the PMO is not defined. The framework gives the PMO annual reallocation authority up to EUR 1 billion and contract authority below EUR 500 million, but there are no explicit approval limits for site operations leads, workstream leads, or the prime integrator. Without a sub-delegation matrix, operational decisions will either bottleneck at the PMO or be taken without clear authority.
5. Gap: A formal change control process is missing. There are thresholds for PSC approval of changes above EUR 1 billion and for changes to strategic levers, but no defined change control board, classification of change types, impact assessment requirements, or configuration management process for the controlled interface register and makeability map. This is particularly important for interface freeze changes, where the matrix describes a deadlock escalation but not the change evaluation procedure.
6. Gap: Conflict-of-interest management is described only at a high level. There is no central conflicts register, no mandatory annual disclosure cadence for all members, no defined recusal procedure during votes, and no ongoing monitoring of post-appointment financial interests, especially for TAG experts, ECC members, and the independent PSC chair. Given the corruption risks identified in Stage 1, this should be specified in detail.
7. Gap: Whistleblower and investigation procedures are not sufficiently defined. The implementation plan establishes an independent multilingual mechanism, but there is no case-management timeline, no defined investigation ownership and evidence standard, no appeal or retaliation-protection process, and no requirement to report substantiated findings to ARAC and, where relevant, regulators. This weakens the integrity framework that Stage 1 identifies as critical.
8. Gap: Several important escalation scenarios are not covered by the decision escalation matrix. The matrix omits major safety incidents, cybersecurity breaches, environmental non-compliance, private capital shortfalls, and critical skilled-personnel attrition. Some are referenced in monitoring triggers, but the escalation pathway and decision authority for these events is not formalised, leaving response to ad hoc treatment.
9. Gap: There is no dedicated monitoring approach for cybersecurity and data integrity, despite Stage 1 audit procedures requiring annual IEC 62443 audits and the risk assessment identifying IP theft valued at EUR 50-100 billion. The PMO includes a Head of Digital and Information Systems, but cybersecurity is not tracked as a distinct monitoring approach with its own KPIs, response triggers, and reporting line.
10. Gap: Escalation decisions lack service-level agreements. The PSC meets quarterly and can meet extraordinarily within 10 working days, but the framework does not specify a maximum response time for escalated decisions. A critical technical, financial, or compliance issue could wait for the next meeting, amplifying delays of 12-36 months in scenarios that the monitoring plan says require rapid adaptation.
11. Gap: Integration between committeees is present through liaison roles but not fully mapped. For example, the ECC has an internal audit liaison from ARAC and ARAC includes the ECC chair, and TAG submits written risk assessments to PSC, but there is no formal information-flow matrix defining which reports, data, and findings are shared among bodies, at what cadence, and in what sanitised form for public transparency.
12. Gap: The Technical Advisory Group's role and limits are clear advisory, but there is no process for documenting and explaining cases where the PSC overrides TAG technical advice on core feasibility questions. Given TAG exists to prevent groupthink on issues such as yield plateaus and descope decisions, an override should require a recorded rationale and disclosure to shareholders.

## Tough Questions

1. What is the current probability-weighted forecast for achieving the auditable 95% component coverage by Q4 2042, and what yield-learning-curve and TRL assumptions for FPGAs and complex electronics underpin it? Show the sensitivity if first-pass yield plateaus at 80% instead of reaching the gate threshold.
2. Is the EUR 200 billion baseline expressed in 2026 real euros with annual indexation, and what is its projected real value at 2046 under current inflation assumptions? What is the EUR/CHF hedge position today, including the tail-risk reserve, and what would a sustained breach of the 1.05-1.10 band cost?
3. Show the current register of signed sovereign and private funding commitments. How many private investors have executed binding agreements, what is the modelled IRR and licensing-revenue scenario, and what is the contingency plan if private capital falls from 30% to 10% of the EUR 200 billion envelope?
4. Provide evidence that BAFa, CDIU, and SECO export-control classification requests and the technology-transfer matrix were submitted by the compliance dates. Which controlled items are currently quarantined, and what is the critical-path impact of any delayed export-control resolution on lithography and propulsion equipment movement?
5. Which critical specialties currently have fewer than two trained practitioners? Show attrition and time-to-competence data for those roles, and present the specific recruitment, rotation, and mentorship actions with owners and deadlines that will restore redundancy within the next 12 months.
6. What is the current interface-register compliance rate across the three sites? What is the definitive freeze date for mechanical, power, fluid, and data interfaces, and what retrofit cost and schedule contingency is held if the freeze slips by more than 6 or 12 months?
7. Name the top three risks currently above the approved risk appetite. For each, what is the leading indicator, which mitigation action is overdue by more than 30 days, and what specific decision is being requested from the PSC at the next quarterly review?
8. If either the macro-scale or miniaturised prototype track fails its merge-gate thresholds by the scheduled date, which descope option is pre-authorised, what is its cost and schedule impact, and who has decision authority to trigger it without waiting for a full PSC cycle?
9. What is the current external input register count and complexity versus the approved allowance? Provide the latest audit evidence supporting the 95% coverage claim, and list any qualifications raised by external auditors or ARAC sampling at the last certification milestone.
10. How many whistleblower reports have been received to date? What is the median investigation time, how many were substantiated, what corrective actions were taken, and what evidence exists that reporters have been protected from retaliation?
11. What is the current cash-burn rate against the real-euro baseline, and how many months of operational runway remain if a sovereign contribution is delayed by 12 months? Show the contingency reserve balance and the activation criteria that would be applied.
12. Show the latest ESG and sustainability dashboard, including water recovery rate, energy intensity, and waste-to-landfill percentage. Which metric is closest to missing its annual target, what remediation is planned, and how will any non-compliance be reflected in the public quarterly report?

## Summary

The governance framework is broad and well-aligned with the programme's distinctive risk profile: it combines strategic oversight, operational integration, independent technical assurance, compliance, audit and risk assurance, and social-license management within a single structure, and it has a credible 14-16 week formation sequence with clear delegation boundaries at the PSC and PMO levels. Its key strengths are the inclusion of independent external chairs and experts, the separation of technical advice from decision authority, and the direct mapping of monitoring approaches to the critical risks such as coverage yield, funding continuity, interface integration, and political support. The main areas requiring further work are definition of the ultimate sponsor authority, granular delegation below the PMO, formal change control and conflicts-of-interest processes, whistleblower investigation procedure, decision service-level agreements, and dedicated cybersecurity and environmental monitoring approaches. If those gaps are closed, the framework provides a resilient basis for governing a EUR 200 billion, 20-year, multi-jurisdiction programme.