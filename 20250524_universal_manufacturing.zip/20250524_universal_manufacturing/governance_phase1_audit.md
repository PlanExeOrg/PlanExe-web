
## Audit - Corruption Risks

- Bribery or kickbacks in awarding multi-billion-euro construction and cleanroom fit-out contracts at the Geneva, Veldhoven, and Oberkochen sites, including collusive bidding among contractors.
- Conflicts of interest in the public-private consortium where board members or module leads have undisclosed financial ties to equipment vendors (lithography, metrology, robotic actuators) or feedstock suppliers, influencing procurement decisions.
- Nepotism and favouritism in hiring and staffing at partner institutions, inflating headcount or billing the SPV for relatives or affiliated personnel.
- Facilitation payments to regulators (BAFA, CDIU, SECO, local authorities) to expedite export-control licences, environmental permits, zoning approvals, or safety certifications.
- Misuse of confidential commercial and technical information—such as the inter-module interface register, makeability map, digital twin data, or IP valuations—by sharing it with competitors or private investors in exchange for personal gain.
- Trading favours in licensing and IP transactions, for example granting undervalued licensing rights to private consortium partners in return for personal benefits or reciprocal contracts.
- Corrupt procurement of basic feedstock, reagents, or specialised materials through shell suppliers at inflated prices with shared margins.

## Audit - Misallocation Risks

- Overstating component coverage or yield results in gate reports to trigger milestone-based funding releases, thereby channelling budget towards non-performing workstreams.
- Duplicate payments or double-billing for the same R&D services, equipment, or materials across the three federated sites due to fragmented ERP/MES systems and the absence of a consolidated ledger.
- Using the EUR 20 billion contingency reserve as a general slush fund for unrelated cost overruns rather than for defined technical, financial, or currency shocks.
- Gold-plating equipment purchases—such as procuring excessive lithography or metrology capability beyond module needs—and inefficiently allocating the 50 MW clean-energy capacity and cleanroom floor space to low-priority modules.
- Key scientists and engineers from CERN, ASML, Zeiss, and Fraunhofer being allocated to non-project or low-value tasks while their full time and overhead are billed to the SPV.
- Unauthorised use of project feedstock, additive manufacturing tools, cleanroom assets, or digital twin access for external sideline projects or personal purposes.
- Poor record-keeping and opaque handling of EUR/CHF hedging, inter-site transfers, and shared infrastructure costs, causing avoidable currency losses and misreported balances.

## Audit - Procedures

- Annual independent external financial audit of the SPV consolidated accounts and each site's cost centre, with findings reported to the Programme Executive Board and host governments.
- Quarterly internal audit of cash drawdowns, capital calls, and milestone-linked funding releases, verifying that expenditures match reported technical progress.
- Pre-award and post-award procurement audits for all contracts above EUR 50 million, reviewing tender documentation, sole-source justifications, conflicts-of-interest declarations, and actual deliverables, supplemented by forensic audits on high-risk procurement categories.
- Semi-annual export-control and compliance audits by the joint compliance office to verify BAFA, CDIU, and SECO licences, adherence to the technology-transfer matrix, and cross-border movement records.
- Periodic technical audits of the 95% component-coverage claim, sampling makeability-map entries, first-pass yield data, measurement-gate results, and certification-matrix evidence, with involvement of an external technical advisory board.
- Annual cybersecurity and data-integrity audits of the digital twin, MES, and ERP systems per IEC 62443, including reviews of access logs, audit trails, and changes to the controlled interface register.
- Annual physical asset and inventory verification audits, reconciling equipment, feedstock, and cleanroom utilisation against ERP records and project plans.

## Audit - Transparency Measures

- A public programme dashboard updated quarterly, showing budget drawdown versus plan, milestone status, component-coverage percentage, yield metrics, and site-level progress.
- Publication of audited annual financial statements, annual ESG metrics (energy intensity, water recovery rate, waste-to-landfill percentage), and executive summaries in English, German, French, and Dutch.
- Publication of non-confidential minutes and decisions of the Programme Executive Board and funding-gate reviews to consortium partners and host governments, with redactions only where required for IP or export-control protection.
- A public register of major contracts, suppliers, and beneficial owners, including vendor selection criteria and award justifications for contracts above EUR 50 million.
- An independent whistleblower mechanism accessible in all project languages and at all three sites, with clear confidentiality protections and published follow-up procedures.
- Publication of a sanitised version of the controlled interface register and component makeability map as open standards, along with technical gate criteria and demonstration results.
- Stakeholder advisory boards at each site with quarterly public reporting and annual demonstration days showcasing actual progress and coverage evidence.