**Purpose:** business

**Purpose Detailed:** A 20-year, EUR 200 billion large-scale industrial research and development initiative focused on advanced manufacturing infrastructure, technology development, and strategic planning for universal manufacturing capability, including electronics, robotics, propulsion, and energy systems production.

**Topic:** Earth-based modular miniaturized factory system as precursor to Space-Based Universal Manufacturing