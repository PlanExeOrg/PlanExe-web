
## Documents to Create

### 1. Project Charter

**ID:** a0282e4e-b02e-4879-861f-2461bcf1b6da

**Description:** High-level project charter defining the 20-year EUR 200 billion programme vision, mission, objectives, scope, budget envelope, timeline, key stakeholders, governance principles, and top-level success criteria.

**Responsible Role Type:** Programme Director & Prime Integrator

**Primary Template:** PMI Project Charter Template

**Secondary Template:** ISO 21500 Guidance on Project Management

**Steps:**

- Draft with Programme Director and central integration office
- Consult cross-border legal lead on SPV governance constraints
- Review with site leads and partner institution representatives
- Present to SPV Board for approval

**Approval Authorities:** Intergovernmental SPV Board and Programme Executive Board

### 2. Baseline Assessment of Universal Manufacturing Capability and Legal Feasibility

**ID:** 4687a518-12ef-458a-ada4-904f8ed4301d

**Description:** Cormprehensive current-state assessment covering the component catalogue with baseline technology readiness levels, first-pass yield estimates, feedstock purity variability, export-control licensability, site readiness, and funding gaps. Includes the initial component makeability map and legal makeability map used to define the auditable 95% component-coverage denominator.

**Responsible Role Type:** Advanced Manufacturing, Materials & Process Engineering Lead

**Primary Template:** NASA Technology Readiness Level Assessment Template

**Secondary Template:** World Bank Project Readiness Assessment

**Steps:**

- Collect and synthesize raw source data from site surveys, regulatory texts, and statistical sources
- Commission expert interviews with technology and legal advisors
- Build component catalogue of at least 5,000 part numbers with TRL, yield, and process modification data
- Integrate export-control licensability classifications into the baseline dataset
- Validate with Programme Director, CTO, and external Technical Advisory Board

**Approval Authorities:** Programme Director, CTO, Intergovernmental SPV Board

### 3. High-Level Budget and Treasury Framework

**ID:** 3dc7ef8f-a30c-412b-9379-795f21839534

**Description:** Financial framework expressing the EUR 200 billion budget in 2026 real euros with annval indexation, 70% public / 30% private funding structure, annual drawdown profiles, EUR20 billion contingency reserve, and EUR/CHF hedging approach for the Geneva site.

**Responsible Role Type:** Strategic Funding & Treasury Lead

**Primary Template:** World Bank Infrastructure Finance Toolkit

**Secondary Template:** European Investment Bank PPP Financing Framework

**Steps:**

- Collect official inflation and currency historical data
- Model real versus nominal budget scenarios using found statistical datasets
- Define capital-call schedule aligned with technical gates
- Set treasury hedging policy and contingency release rules
- Obtain approval from SPV Board and Programme CFO

**Approval Authorities:** SPV Board, Programme CFO, member-state finance representatives

### 4. Funding Commitment Phasing Framework

**ID:** db06c392-c534-46f2-a27a-bbdec6950320

**Description:** High-level strategy for phasing the EUR 200 billion commitment: staged milestones, full binding commitment, or public-private consortium. Links capital releases to technical and measurement gates while preserving long-term stability and flexibility.

**Responsible Role Type:** Strategic Funding & Treasury Lead

**Primary Template:** European Investment Bank Staged Funding Framework

**Secondary Template:** PPP Guidance Note on Investment Phasing

**Steps:**

- Review funding scenario options against programme risks
- Integrate technical gate evidence requirements from metrology and programme controls
- Align with legal lead on consortium and SPV governance constraints
- Model private investor return expectations and licensing revenue scenarios
- Present to SPV Board for strategic approval

**Approval Authorities:** SPV Board and Programme Executive Board

### 5. Funding Agreement Structure and Template

**ID:** 746f9d0a-3308-496a-b282-bb16b615a67e

**Description:** Standard legal template for public and private funding agreements, including capital calls, drawdown conditions, performance-linked gates, default provisions, dispute resolution, and currency adjustment mechanics.

**Responsible Role Type:** Cross-Border Legal, Regulatory & Export Control Lead

**Primary Template:** EIB Loan and Guarantee Template

**Secondary Template:** PPP Project Agreement Template

**Steps:**

- Draft legal terms together with Treasury Lead and SPV governance counsel
- Embed technical stage-gate conditions and evidence requirements
- Include export-control and IP access restrictions
- Review with member-state legal representatives and private investors
- Finalise for signature by funding parties

**Approval Authorities:** SPV Board, member-state governments, private consortium partners

### 6. Intergovernmental SPV and Consortium Governance Framework

**ID:** ae882efe-0a37-4b00-8857-884b7fed529c

**Description:** High-level legal and governance structure for a single European special-purpose vehicle among Switzerland, France, Netherlands, and Germany; includes decision rights, IP ownership, arbitration, contributed technology schedules, and an export-control chapter.

**Responsible Role Type:** Cross-Border Legal, Regulatory & Export Control Lead

**Primary Template:** ITER Joint Implementation Agreement Structure

**Secondary Template:** CERN Convention Governance Patterns

**Steps:**

- Draft governance and decision-rightss sections with site counsel
- Incorporate export-control and technology-transfer obligations
- Run feasibility check on CERN, ASML, Zeiss, and Fraunhofer participation
- Consult member-state negotiating teams
- Obtain intergovernmental endorsement

**Approval Authorities:** Member-state governments and legal counsel

### 7. Export Control and Technology Transfer Compliance Framework

**ID:** 2f2f7ff5-d98b-489c-b932-238cf24d2fa9

**Description:** Compliance framework for dual-use export controls, deemed exports, technology-transfer licensing, and cross-border data movement across Swiss and EU sites; establishes the legal makeability map and route-to-license strategy before any site option, SPV signature, or partner agreement is concluded.

**Responsible Role Type:** Cross-Border Legal, Regulatory & Export Control Lead

**Primary Template:** EU Internal Compliance Programme Template

**Secondary Template:** Wassenaar Arrangement Compliance Best Practices

**Steps:**

- Identify all controlled hardware, software, technical data, and personnel nationalities
- Build technology-transfer matrix mapping each item to national authorities
- Submit preliminary license applications to BAFA, CDIU, SECO, and French SBDU/DGDDI
- Design quarantine workflow for stalled controlled items
- Establish joint compliance office with host-country representatives

**Approval Authorities:** Cross-Border Legal Lead, SPV Board, BAFA/CDIU/SECO/SBDU-DGDDI as applicable

### 8. Risk Register

**ID:** 72ee22ae-b8b7-4f7d-8856-040742e6c6a4

**Description:** Integrated enterprise risk register covering technical, financial, political, integration, supply chain, safety, cybersecurity, and legal risks, with likelihood, impact, mitigation owners, and quarterly review cadence.

**Responsible Role Type:** Programme Controls and Risk Management Lead

**Primary Template:** PMI Risk Register Template

**Secondary Template:** ISO 31000 Risk Management Framework

**Steps:**

- Facilitate risk workshops with programme leadership and site leads
- Codify risks from asumptions, SWOT, and expert review inputs
- Assign risk owners and mitigation plans
- Integrate leading indicators such as coverage percentage, gate slipage, interface compliance, and cash-burn rate
- Present to Programme Board for approval and quarterly review

**Approval Authorities:** Programme Director and SPV Board

### 9. Stakeholder Engagement Plan

**ID:** bef1b808-1e30-43b2-9d3f-35e663ca2dc5

**Description:** Identifies primary and secondary stakeholders, engagement strategies, cadence of engagement, local community activation, political support building, and social license management across the four countries and nearby EU institutions.

**Responsible Role Type:** Stakeholder Engagement and Communications Lead

**Primary Template:** Stakeholder Engagement Planning Matrix (APM/PMI)

**Secondary Template:** AA1000 Stakeholder Engagement Standard

**Steps:**

- Map all stakeholder groups and their interests and influence
- Design engagement cadence and escalation paths
- Align with legal and SPV governance timelines
- Define local community benefit and communication mechanisms
- Approve with Programme Director and SPV commitee

**Approval Authorities:** Programme Director and SPV Board

### 10. Communication Plan

**ID:** df8de599-3e30-445b-8fe5-594e8b6f5989

**Description:** Multilingual public, investor, regulator, and partner communication plan including quarterly public reports, annual demonstration days, board briefing cycles, and crisis-communication procedures.

**Responsible Role Type:** Stakeholder Engagement and Communications Lead

**Primary Template:** PMI Communication Plan Template

**Secondary Template:** GRI Sustainability Reporting Framework

**Steps:**

- Build communication calendar aligned with milestones and gates
- Define messaging for political, investor, scientific, and community audiences
- Set up multilingual reporting channels
- Integrate sustainability KPI disclosures
- Approve with Programme Director

**Approval Authorities:** Programme Director and SPV Communications Committee

### 11. Change Management Plan

**ID:** 8419adcb-891b-4b5a-bfd1-c75ea2cc9467

**Description:** High-level change control and descope governance covering interface freezes, budget re-baselining, schedule changes, gate criteria changes, and descope triggers that preserve programme credibilty.

**Responsible Role Type:** Programme Controls and Risk Management Lead

**Primary Template:** PMI Change Management Plan Template

**Secondary Template:** IIBA Business Analysis Change Framework

**Steps:**

- Define change classification levels and approval rights
- Link change requests to technical gates and risk register
- Establish interface freeze and change-board process
- Define descope trigger criteria from makeability map and yield evidence
- Approve with Programme Director and SPV Board

**Approval Authorities:** Programme Director and SPV Board

### 12. Initial High-Level Schedule and Timeline

**ID:** 0d300b0c-35ea-402a-a99b-3fd54ffbdc30

**Description:** 20-year master schedule from Q4 2026 to Q4 2046 in five phases: site acquisition/design, parallel prototypes, modular production line and integrated demonstration, 95% coverage qualification, and space-readiness validation, including major gates, buffers, and decision points.

**Responsible Role Type:** Programme Controls and Risk Management Lead

**Primary Template:** PMI Master Schedule Template

**Secondary Template:** NASA Phase-Gate Milestone Framework

**Steps:**

- Incorporate dependency dates from project plan and assumptions
- Align with site acquisition, export-control, and prototype development timelines
- Add 12-month buffers before major gates
- Identifycritical-path items and gate exit criteria
- Approve with Programme Director and SPV Board

**Approval Authorities:** Programme Director and SPV Board

### 13. Monitoring, Evaluation and Learning (M&L) Framework

**ID:** 606631be-4818-42c6-b882-139d6bfcf1d9

**Description:** Programme-level M&E framework defining key performance indicators for component coverage, yield, gate compliance, funding drawdown, schedule slipage, sustainability, and stakeholder acceptance, including data sources and reporting cadence.

**Responsible Role Type:** Metrology, Validation & Quality Assurance Lead

**Primary Template:** World Bank Logical Framework Approach

**Secondary Template:** OECD DAC Evaluation Criteria

**Steps:**

- Set indicator definitions and baselines from baseline assessment
- Define measurement methods and data owners
- Link indicators to funding tranches and technical gates
- Build reporting calendar for board and investor reviews
- Approve with Programme Director and SPV Board

**Approval Authorities:** SPV Board and Programme Director

### 14. Miniaturization Pathway Strategy

**ID:** 4474c8d5-ba94-47a5-b778-764021bbb916

**Description:** High-level strategy for the physical scale trajectory of modules: parallel macro-scale and radically miniaturized bench-scale tracks, first technology gate in 2029, formal merge gate in 2032, factory-level metrics such as floor area per function and energy per output, and descope to modular scalable architecture if gates fail.

**Responsible Role Type:** Advanced Manufacturing, Materials & Process Engineering Lead

**Primary Template:** Technology Roadmap Template (Phaal)

**Secondary Template:** NASA Technology Readiness Level Roadmap

**Steps:**

- Use results from baseline assessment to set realistic thresholds
- Define macro-scale and bench-scale performance criteria
- Add factory-level miniaturization metrics beyond part-level dimensions
- Coordinate with contamination and thermal zoning constraints
- Approve with Programme Director and merge-gate board

**Approval Authorities:** Programme Director, CTO, Merge-Gate Review Board

### 15. Component Coverage Sequencing Strategy

**ID:** 11716f35-f0a5-4ea7-8b10-2d3b26e74275

**Description:** Strategy for ordering component families toward 95% coverage using a component-makeability map; stratified coverage targets by material family and by technology family, electronics-first risk retirement, and licensability filters from the legal makeability map.

**Responsible Role Type:** Advanced Manufacturing, Materials & Process Engineering Lead

**Primary Template:** Stake-Gate Innovation Process (Cooper)

**Secondary Template:** Technology Portfolio Sequencing Framework

**Steps:**

- Rank all part numbers by coverage gap, TRL, yield, and process modification cost
- Define stratified coverage targets: structural, electromechanical, board-level electronics, packaged sensors, monolithic ICs
- Incorporate export-control licensability into the 95% denominator
- Align sequence with funding tranches and measurement gates
- Approve with Programme Director and Technical Advisory Board

**Approval Authorities:** Programme Director, CTO, Technical Advisory Board

### 16. Inter-Module Interface Covenant Framework

**ID:** a974b8be-5e89-4968-b403-19289fed19e8

**Description:** Framework for governing the mechanical, power, fluid, and data interfaces among modules built at different European centres; defines the controlled interface register, compliance simulation, freeze timing, and prime-integrator integration layer.

**Responsible Role Type:** Factory Systems, Interface & Digital Integration Architect

**Primary Template:** INCOSE/NASA Interface Control Document Framework

**Secondary Template:** ITER Interface Control Approach

**Steps:**

- Define initial interface database categories and tolerances
- Establish compliance simulation requirement before parallel module development
- Set freeze and iterative review rules to avoid premature lock-in
- Define prime integrator ownership and integration layer architecture
- Approve with Programme Director and Interface Arbitration Board

**Approval Authorities:** Programme Director and Interface Arbitration Board

### 17. External Input Allowance Policy

**ID:** d8dd37c3-6339-4ab8-a34c-f3514543003d

**Description:** Policy defining the credibilty boundary of the 95% in-factory claim: which external inputs remain allowed, review cadence, elimination roadmap, and treatment of standard reagents and basic feedstock.

**Responsible Role Type:** Programme Director & Prime Integrator

**Primary Template:** Public Policy Framework Template

**Secondary Template:** Supply-Chain Dependency Risk Management Framework

**Steps:**

- Categorise component classes and external input types
- Define rotating exception-list review cadence or full-elimination roadmap
- Bound the 95% denominator with legal makeability and licensability constraints
- Sign-off with Validation and Demonstration Protocol and Component Coverage Sequencing leads
- Approve with SPV Board due to universality implications

**Approval Authorities:** SPV Board, Programme Director, external technical auditors

### 18. Feedstock Resilience Architecture Framework

**ID:** f719e4ff-94eb-4cdd-9471-dda88c1c3f80

**Description:** Framework for raw material variability and purity management: adaptive in-line spectroscopy and recalibration, centralised conditioning, tolerant process design, and per-process-family purity specification matrices.

**Responsible Role Type:** Advanced Manufacturing, Materials & Process Engineering Lead

**Primary Template:** NIST Materials Engineering Framework

**Secondary Template:** Six Sigma Process Capability Framework

**Steps:**

- Gather feedstock purity standards and variability datasets from raw sources
- Map per-family purity-to-yield sensitivity
- Choose combination of adaptive control, conditioning, and tolerant design
- Coordinate with measurement-gate rhythm and contamination zoning
- Approve with Programme Director and CTO

**Approval Authorities:** Programme Director, CTO, Metrology Validation Lead

### 19. Electronics Fabriction Sourcing Strategy

**ID:** bf4d6238-bb14-4383-818f-ee82ce049647

**Description:** High-level sourcing strategy for semiconductor manufacturing capability: co-development with ASML/Zeiss, licensing proven process kits, or maskless direct-write; includes a semiconductor reality gate, yield decomposition for representative FPGA and sensor, and descope trigger if monolithic IC fabriction is not feasible.

**Responsible Role Type:** Advanced Manufacturing, Materials & Process Engineering Lead

**Primary Template:** Technology Sourcing Decision Framework

**Secondary Template:** ASML/imec Co-Development Model

**Steps:**

- Commission semiconductor process decomposition with external fab engineers from imec, CEA-Leti, Fraunhofer, or an IDM
- Define representative FPGA and sensor product specifications and yield budgets
- Assess co-development, licensing, and direct-write options
- Set semiconductor reality gate by 2027-06-30
- Approve with Programme Director and CTO

**Approval Authorities:** Programme Director, CTO, Technical Advisory Board

### 20. Site Orchestration Model Framework

**ID:** ae61048d-9720-4ea6-91c6-ac96cd87a089

**Description:** High-level framework for the physical and orgianisational layout of R&D and production sites: federated network with digital-twin coordination, consolidated flagship, or rotating residency, and selection of the model for the CERN, ASML, Zeiss/Fraunhofer nodes.

**Responsible Role Type:** Factory Systems, Interface & Digital Integration Architect

**Primary Template:** Multisite Programme Delivery Framework (APM)

**Secondary Template:** Federated Manufacturing Network Design Framework

**Steps:**

- Assess site capabilities and logistics at CERN, ASML, Zeiss/Fraunhofer
- Define digital-twin coordination and data-sharing rules
- Model federated versus consolidated versus rotating scenarios
- Incorporate export-control and IP access restrictions
- Approve with Programme Director and SPV Board

**Approval Authorities:** Programme Director and SPV Board

### 21. Valiadation and Demonstration Protocol Framework

**ID:** c42c9061-6a17-477e-9586-ed40b924ea59

**Description:** Framework for proving the 95% component-manufacturing claim: certification matrix, continuous performance telemetry, flagship proof-of-principle demonstration, statistical confidence, external stakeholder acceptance, and learning-system design.

**Responsible Role Type:** Metrology, Validation & Quality Assurance Lead

**Primary Template:** ISO 17025 Quality and Certification Framework

**Secondary Template:** NASA Flight Validation Framework

**Steps:**

- Define certification matrix by component class and coverage threshold
- Design continuous performance telemetry and central data repository
- Select flagship demonstration product and success criteria
- Establish statistical confidence requirements for 95% yield by class
- Approve with Programme Director, regulators, and external advisors

**Approval Authorities:** Programme Director, SPV Board, relevant regulators

### 22. Contamination Envelope Zoning Framework

**ID:** 8adcf93e-689e-4b47-a718-fae8dd269a33

**Description:** Framework for factory pressure and airflow architecture: negative-pressure ATEX-compliant dirty zones for powder and subtractive processes, ISO Class 1-2 clean bays or mini-environment for electronics, airlock cascades, buffered transfer ports, and spatial constraints to be frozen before construction.

**Responsible Role Type:** Safety, Environmental & Sustainability Lead

**Primary Template:** ISO 14644 Cleanroom Design Framework

**Secondary Template:** ATEX Hazardous Area Classification Methodology

**Steps:**

- Define zone pressure cascade and clean/dirty boundaries
- Commission CFD particle-dispersion studies for site layouts
- Integrate airlock and transfer-port overhead with module footprint
- Coordinate with factory systems and miniaturization teams
- Approve with Programme Director and central safety authority

**Approval Authorities:** Central Safety Authority, Programme Director

### 23. Thermal Envelope Separation Framework

**ID:** 0a1c45c5-34bd-45df-8e57-fc3604f0868a

**Description:** Framework for isolating high-temperature deposition, sintering, and melting cells from thermally sensitive electronics assembly and metrology; includes radiative barriers, independent in-cell thermal management, and centralised waste-heat recovery.

**Responsible Role Type:** Factory Systems, Interface & Digital Integration Architect

**Primary Template:** Industrial Thermal Design Best Practices

**Secondary Template:** ASHRAE Process Energy Efficiency Framework

**Steps:**

- Map high-emperature and sensitive zones from process definition
- Design radiative and structural isolation boundaries
- Evaluate waste-heat recovery for feedstock preheating and HVAC
- Model footprint and move-time trade-offs
- Approve with Programme Director

**Approval Authorities:** Programme Director and Safety/Environmental Lead

### 24. Toolset Commonality Mandate Framework

**ID:** f5e2acd3-51f0-4259-854b-41293b528bc2

**Description:** Framework for mandating a single multi-process tool family across modules where physically feasible; concentrates commonality at interface and control layers, identifies boundaries for specialised lithography, powder sintering, and subtractive machining, and defines end-effector interchangeability.

**Responsible Role Type:** Factory Systems, Interface & Digital Integration Architect

**Primary Template:** Product Platform Strategy Framework

**Secondary Template:** SEMI Tool Standardisation Playbook

**Steps:**

- Assess process physics across additive, subtractive, and lithography
- Define common tool platform interfaces and control layers
- Identify components requiring bespoke process physics
- Quantify spare-parts and training savings
- Approve with Programme Director and CTO

**Approval Authorities:** Programme Director, CTO, Factory Systems Architect

### 25. Measurement Gate Rhythm Framework

**ID:** 42ac1ed1-8992-40c7-8bf8-14d663782245

**Description:** Framework for cadence and placement of metrology gates: in-situ per-station sensing, at-line critical-interface checks, off-line deep laboratory characterisation, SPC/FDC/R2R loops, and calibration chain, with trade-offs between per-part measurement cost and defect containment.

**Responsible Role Type:** Metrology, Validation & Quality Assurance Lead

**Primary Template:** SEMI Metrology Roadmap

**Secondary Template:** Statistical Process Control and DOE Design

**Steps:**

- Define in-situ, at-line, and off-line gate types per process chain
- Build purity-to-failure correlation data collection plan
- Allocate metrology tool footprint and budget for CD-SEM, OCD, overlay, defect inspection, and electrical test
- Define calibration and traceability partnerships
- Approve with Programme Director and CTO

**Approval Authorities:** Programme Director, CTO, Metrology Lead

### 26. Expertise Lifespan Insurance Framework

**ID:** 522ea08c-3a51-40ed-b6cf-9471b29bacd7

**Description:** Strategy for protecting scarce know-how over two decades: mentorship rotation, exhaustive digital-twin documentation, two trained practitioners per critical skill, geographic redundancy, attrition modelling, retention incentives, and recruitment pipelines from partner institutions.

**Responsible Role Type:** Knowledge, Talent & Workforce Continuity Lead

**Primary Template:** Knowledge Management Strategy Template

**Secondary Template:** Succession Planning Framework (HR)

**Steps:**

- Map critical specialties and current single-point dependencies
- Design rotation and mentorship programme across sites
- Set documentation standards for process decisions and digital twins
- Model attrition scenaries and retention incentives
- Approve with Programme Director

**Approval Authorities:** Programme Director

### 27. Space-Readiness Requirements Definition

**ID:** eea647bd-0d81-4b6c-8c85-79aa41dcd76f

**Description:** High-level definition of space-readiness requirements for a precursor mission: target payload mass, power, vibration, vacuum compatibility, autonomy duration, in-orbit demonstration objectives, and interface to launch vehicle.

**Responsible Role Type:** Space Manufacturing Commercialization Strategist

**Primary Template:** NASA Space Mission Requirements Template

**Secondary Template:** ECSS-E-ST-10C System Requirements Framework

**Steps:**

- Engage ESA, NASA, and other space agency partners for mission input
- Derive high-level physical and operational requirements from precursor vision
- Define validation criteria for a miniaturized manufacturing module
- Coordinate with Validation and Demonstration Protocol
- Approve with Programme Director and SPV Board

**Approval Authorities:** Programme Director, SPV Board, space agency partners

### 28. Environmental Sustainability Strategy

**ID:** 56b9324c-ba55-46a4-a6f3-283cc015d54f

**Description:** Strategy for 100% renewable electricity by 2035, net-zero operational carbon by 2040, 80% waste-heat recovery, 90% water recycling, ESG reporting, community environmental engagement, and alignment with EU Green Deal regulations.

**Responsible Role Type:** Safety, Environmental & Sustainability Lead

**Primary Template:** ISO 14001/EMAS Environmental Framework

**Secondary Template:** EU Green Deal Reporting Framework

**Steps:**

- Define sustainability targets and KPI baselines
- Integrate waste-heat recovery and water recycling into thermal and zoning frameworks
- Set reporting cadence for regulators and communities
- Conduct early environmental impact assessments per site
- Approve with Programme Director and SPV Board

**Approval Authorities:** SPV Board and Programme Director

### 29. Federated Digital Integration and Cybersecurity Framework

**ID:** c9c74ab9-9ab2-47e2-9c1b-ecb16060d428

**Description:** Framework for federated digital-twin coordination, common data model, standardised MES/ERP stack, interface register integration, OPC UA harmonisation, and zero-trust cybersecurity from construction per IEC 62443.

**Responsible Role Type:** Factory Systems, Interface & Digital Integration Architect

**Primary Template:** IEC 62443 Industrial Cybersecurity Framework

**Secondary Template:** Industrial Digital Twin Reference Architecture

**Steps:**

- Define common data model and integration layer for federated sites
- Specify digital-twin and MES/ERP architecture
- Design zero-trust network segmentation and access logging
- Integrate export-control zone access and deemed-export protections
- Approve with Programme Director and CISO

**Approval Authorities:** Programme Director, CISO, SPV Board

### 30. Commercialization and Licensing Strategy

**ID:** 61b2790b-e1e7-4e82-acbc-ea6cb9a386e1

**Description:** Strategy for mobilising 30% private capital through a credible 20-year revenue model, module licensing royalties, component sales, space-contract royalties, commercial subsidiary structure, and private-investor return expectations.

**Responsible Role Type:** Commercialization and Licensing Lead

**Primary Template:** PPP Revenue Model Template

**Secondary Template:** AUTM Technology Transfer Licensing Framework

**Steps:**

- Build 20-year revenue and licensing scenaries
- Define minimum IRR threshold and capital-call structure
- Design commercial subsidiary for non-core IP licensing
- Coordinate with legal lead on IP ownership and export-control carve-outs
- Approve with SPV Board and private investors

**Approval Authorities:** SPV Board, Programme CFO, private investing partners

### 31. Supply Chain and Feedstock Procurement Strategy

**ID:** eb93fb4d-499f-4eba-9cdb-56f3c7211805

**Description:** High-level strategy for supplier qualification, dual sourcing, strategic feedstock stockpiles, logistics across federated sites, feedstock conditioning, and spare-part inventory to sustain continuous production.

**Responsible Role Type:** Supply Chain and Procurement Lead

**Primary Template:** SCOR Supply Chain Strategy Framework

**Secondary Template:** ISO 28000 Supply Chain Security Framework

**Steps:**

- Identify critical materials and feedstocks from baseline assessment
- Define supplier qualification and dual-sourcing criteria
- Model strategic stockpile levels and logistics links
- Coordinate with feedstock resilience and site orchestration
- Approve with Programme Director

**Approval Authorities:** Programme Director

### 32. Site Development and Construction Strategy

**ID:** 20b4d653-920e-4e22-8335-85586724e45b

**Description:** High-level strategy for site acquisition, geotechnical surveys, utility capacity, zoning and permitting calendar, construction sequencing, commissioning readiness, and handover to operations across the three anchor site clusters.

**Responsible Role Type:** Site Development and Construction Lead

**Primary Template:** Capital Projects Delivery Framework (PMI/APM)

**Secondary Template:** EU Construction Site Planning Template

**Steps:**

- Secure option agreements and access for candidate land parcels
- Commission geotechnical and utility capacity studies using found site data
- Integrate zoning, environmental, and export-control permit calendar
- Define construction sequencing aligned with programme master schedule
- Approve with SPV Board and relevant national authorities

**Approval Authorities:** SPV Board, national authorities, Programme Director

### 33. Killer Application Demonstration Task Force Charter

**ID:** c9d12b36-ff63-4c8d-9513-33a88f3f04aa

**Description:** Charter for a flagship demonstration task force to define and deliver a high-value product manufactured end-to-end from raw feedstock, such as a functional FPG A or robotic actuator, as the centrepiece of the 2032 merge-gate review and early investor engagement.

**Responsible Role Type:** Programme Director & Prime Integrator

**Primary Template:** Project Charter Template for Demonstrator Programmes

**Secondary Template:** NASA Technology Demonstration Gate Framework

**Steps:**

- Define flagship product candidate and end-to-end demonstrability criteria
- Set initial budget and team structure reporting to Programme Director and CTO
- Coordinate with Component Coverage Sequencing and Validation Protocol
- Establish success metrics and gate deliverables
- Approve with Programme Executive Board

**Approval Authorities:** Programme Executive Board

## Documents to Find

### 1. EU Dual-Use Export Control Regulation and Implementing Acts (Regulation (EU) 2021/821)

**ID:** 6369718f-7ea0-4657-82f7-0a89b20e75c7

**Description:** Consolidated legal text of the EU dual-use regulation, including annexes and delegated acts. Primary legal input for the export-control compliance framework and legal makeability map.

**Recency Requirement:** Current consolidated version in force

**Responsible Role Type:** Cross-Border Legal, Regulatory & Export Control Lead

**Access Difficulty:** Easy - publicly available on EUR-Lex

**Steps:**

- Search EUR-Lex for CELEX number 32021R0821
- Download consolidated version and annex amendments
- Check delegated and implementing acts on EUR-Lex

### 2. National Export Control Laws and Implementing Regulations (German AWV/Ausfuhrliste, Dutch Dual-Use Implementation, Swiss Goods Control Ordinance, French SBDU/DGDDI Provisions)

**ID:** 0a79a374-bd03-45f5-a466-bb933ca0c9a3

**Description:** National legal texts and implementing rules for export control and customs in Germany, Netherlands, Switzerland, and France. Required to map legal bases and filing routes for each site.

**Recency Requirement:** Current versions in force

**Responsible Role Type:** Cross-Border Legal, Regulatory & Export Control Lead

**Access Difficulty:** Medium - official portals exist but consolidated versions require legal research

**Steps:**

- Search national gazettes and ministry websites
- Contact BAFA, CDIU, SECO, and French SBDU/DGDDI information services
- Consult local dual-use counsel for consolidated versions

### 3. Zoning and Land-Use Plans for Candidate Site Areas (Pays de Gex, Veldhoven/Eindhoven, Oberkochen/Southern Germany)

**ID:** 12eaac70-b5ca-4d25-81bf-2686abc7814e

**Description:** Official municipal zoning maps, land-use designations, building restrictions, and development plans for candidate industrial land parcels near Geneva/CERN, Veldhoven/ASML, and Oberkochen/Zeiss-Fraunhofer.

**Recency Requirement:** Current plan versions

**Responsible Role Type:** Site Development and Construction Lead

**Access Difficulty:** Medium - public records but fragmented across multiple authorities

**Steps:**

- Access municipal planning portals for each candidate commune
- Request pre-application zoning confirmations from local planning authorities
- Review national and regional industrial development plans

### 4. Geotechnical and Utility Infrastructure Capacity Reports for Candidate Industrial Land Parcels

**ID:** 513e8932-9afd-46ce-9d5b-10681bdb8193

**Description:** Existing geotechnical surveys, soil maps, utility capacity statements for power, water, data, and transport, and grid connection headroom data from municipal engineering departments, grid operators, and water authorities.

**Recency Requirement:** Within last 5 years where possible; historical data acceptable for stability assessment

**Responsible Role Type:** Site Development and Construction Lead

**Access Difficulty:** Hard - many reports require formal request, fees, or landowner permission

**Steps:**

- Contact municipal engineering and planning departments
- Request grid connection capacity statements from TSO/DSO operators
- Access national geological survey databases
- Submit formal data requests where reports are not public

### 5. National and Regional Labour Market and Workforce Skill Statistics (France, Netherlands, Germany, Switzerland)

**ID:** f05bb3b5-60e2-4194-8250-c91c7adff8a8

**Description:** Official employment, occupation, education, and engineering workforce datasets from national statistical offices and Eurostat. Needed for workforce planning and site orchestration decisions.

**Recency Requirement:** Most recent year available; trend series for last 10 years

**Responsible Role Type:** Knowledge, Talent & Workforce Continuity Lead

**Access Difficulty:** Easy - open data portals

**Steps:**

- Download datasets from Eurostat, INSEE, CBS, Destatis, and BFS portals
- Query occupation and education categories relevant to advanced manufacturing
- Compile regional data for Pays de Geex, Veldhoven, and Oberkochen

### 6. European Electricity Grid Capacity and Renewable Energy Data (ENTSO-E Transparency Platform and National Grid Operator Data)

**ID:** cdb3ebb3-033a-4c0d-bfe1-302740d96990

**Description:** Raw grid load, available transfer capacity, renewable connection queues, and regional electricity statistics from ENTSO-E and national TSO/DSO operators. Required for utility planning and sustainability strategy.

**Recency Requirement:** Most recent year and latest quarterly data

**Responsible Role Type:** Site Development and Construction Lead

**Access Difficulty:** Medium - much data open, but site-specific connection capacity is on request

**Steps:**

- Access ENTSO-E Transparency Platform
- Query national TSO/DSO open-data portals
- Request grid connection capacity statements for candidate sites

### 7. SEMI Standards and IRDS Roadmap Documents for Semiconductor Manufacturing

**ID:** 022274d4-c3e0-4caa-9e36-699f24bdc960

**Description:** Official semiconductor technology roadmaps and standards covering lithography, metrology, contamination, yield, and packaging. Input for miniaturization strategy and electronics sourcing analysis.

**Recency Requirement:** Latest editions (IRDS 2023/2024 and current SEMI standards)

**Responsible Role Type:** Advanced Manufacturing, Materials & Process Engineering Lead

**Access Difficulty:** Medium - some documents free, many standards require membership or purchase

**Steps:**

- Search SEMI.org for relevant standards
- Download public IRDS chapters
- Review imec, CEA-Leti, and Fraunhofer public roadmaps

### 8. Semiconductor Equipment and Process Chain Technical Specification Data (Lithography, Etch, Deposition, CM P, Metrology Tools)

**ID:** 22a7beb3-9317-4bba-bbe1-6b4a7f5fd825

**Description:** Raw technical datasheets, tool footprints, usility requirements, and capability data for semiconductor manufacturing equipment from suppliers such as ASML, Zeiss, Applied Materials, and others. Needed to asses realisitic miniaturization and makeability.

**Recency Requirement:** Current product generation data; historical data for learning curves

**Responsible Role Type:** Advanced Manufacturing, Materials & Process Engineering Lead

**Access Difficulty:** Hard - proprietary, requires NDAs and established business relationships

**Steps:**

- Submit partnership inquiries to equipment suppliers
- Sign non-disclosure agreements where required
- Request technical datasheets and footprint specifications
- Attend industry briefings or imec/CEA-Leti partnership programmes

### 9. Feedstock Material Purity and Composition Standards and Specification Data (ISO/ASTM Metal Powders, Semiconductor Gases, Chemicals, Ultrapure Water)

**ID:** 6483bddb-b0b1-4fd2-aa7d-b4bc510a2a8c

**Description:** Official material standards, supplier specification sheets, and purity classifications for raw feedstocks and process chemicals. Input for feed stock resilience architecture and per-process purity matrices.

**Recency Requirement:** Current applicable standards and current supplier specifications

**Responsible Role Type:** Advanced Manufacturing, Materials & Process Engineering Lead

**Access Difficulty:** Medium - some standards purchased, some supplier data public

**Steps:**

- Seach ISO/ASTM catalogues for metal powder and materials standards
- Request specification sheets from chemical and gas suppliers
- Consult SEMI standards for semiconductor materials
- Compile from databases such as MatWeb or supplier portals

### 10. ATEX Directive 2014/34/EU and Harmonised Standards; ISO 14644 Cleanroom Standards; ISO 45001 Safety Management Standard

**ID:** f85256ed-6d4b-4ab4-914d-6b48dc92735e

**Description:** Regulatory and standards texts governing explosion protection, cleanroom classifiation, and occupational health and safety. Input for contamination zoning, safety architecture, and compliance framework.

**Recency Requirement:** Current consolidated editions

**Responsible Role Type:** Safety, Environmental & Sustainability Lead

**Access Difficulty:** Medium - official directive is free; ISO standards are paywalled

**Steps:**

- Download directive text from EUR-Lex
- Purchase or access ISO standards through national standards bodies
- Review EU harmonised standard lists for ATEX

### 11. ITER Interface Control Documentation, Industrial Supplier Frameworks, and 2024 Baseline Re-plan Documents

**ID:** b032d3b6-58a3-48bd-9141-b5d164ffb4e5

**Description:** Official technical and governance documents from ITER describing interface registers, factory acceptance tests, trial assembles, stage gates, and multinational integration. Reference source for interface covenant and programme governance design.

**Recency Requirement:** 2021-2025 official documents; especially 2024 re-baseline

**Responsible Role Type:** Factory Systems, Interface & Digital Integration Architect

**Access Difficulty:** Medium - many documents public; internal documents require engagement

**Steps:**

- Search ITER.org public document and newsline archives
- Contact ITER Industrial Relations Directorate for supplier briefing materials
- Review ITER annual reports for interface and integration lessons

### 12. ESS Annual Reports and Supplier/In-Kind Interface Management Documents

**ID:** ab275b1c-edb0-4266-9562-6c098c589e4e

**Description:** Official European Spallation Source annual reports, indus trial liaison briefings, and descriptions of in-kind contribution integration and interface control. Reference for federated European infrastructure delivery.

**Recency Requirement:** Last 5 years (2020-2025)

**Responsible Role Type:** Factory Systems, Interface & Digital Integration Architect

**Access Difficulty:** Easy - annual reports are public

**Steps:**

- Download annual reports from ESS website
- Contact ESS Industrial Liaison Office for supplier briefing materials
- Attend industry supplier days or webinars

### 13. ASML EUV/High-NA Technical Publications and Zeiss SMT Precision Optics Capability Documents

**ID:** 90f531da-939b-4304-b965-09b86fba12af

**Description:** Public technical white papers, system factsheets, and precision optics capability documents from ASML and Zeiss SMT. Input for semiconductor sourcing, miniaturization metrics, and partner engagement.

**Recency Requirement:** Latest published EUV/High-NA documentation

**Responsible Role Type:** Advanced Manufacturing, Materials & Process Engineering Lead

**Access Difficulty:** Easy to Medium - public summaries available, detailed specifications require engagement

**Steps:**

- Download public documents from asml.com and zeiss.com/smt
- Request technical briefings through company contact portals
- Register for partner or supplier info sessions

### 14. NASA OSAM-2 Mission Documentation, Risk Summaries, and Lessons-Learned Reports

**ID:** a57c7304-d078-48fe-9164-5d755214d7af

**Description:** Official NASA/Redwire mission documentation for in-space robotic additive manufacturing and assembly. Input for space-readiness validation and demonstration protocol

**Recency Requirement:** 2019-2025 published documents

**Responsible Role Type:** Space Manufacturing Commercialization Strategist

**Access Difficulty:** Easy to Medium - many reports public; some internal documents require request

**Steps:**

- Search NASA Technical Reports Server (NTRS)
- Review NASA STMD mission pages
- Contact Redwire in-space manufacturing unit for briefing materials

### 15. EU Horizon Europe, Chips Act, and IPC EI Programme Documents and Funding Rules

**ID:** a4a95cf2-4f00-4181-81f6-8d3ca516e7d6

**Description:** Official EU programme regulations, work programmes, funding conditions, and strategic autonomy frameworks relevant to aligning the project with Horizon Europe, the EU Chips Act, and Important Projects of Common European Interest.

**Recency Requirement:** Current multiannual financial framework and latest work programmes

**Responsible Role Type:** Strategic Funding & Treasury Lead

**Access Difficulty:** Easy - public European Commission portals

**Steps:**

- Search EUR-Lex for Horizon Europe and Chips Act legal bases
- Download European Commission work programmes and funding guides
- Check IPC EI communications and member-state notifications

### 16. Eurostat HICP Inflation Indices and Swiss National Bank EUR/CHF Historical Exchange Rate Data

**ID:** 49076577-d9fc-4405-ad09-775df72d8a2f

**Description:** Official monthly inflation indices and daily/monthly EUR/CHF exchange rates. Required for real-euro budgeting, indexation, and hedge baseline.

**Recency Requirement:** Monthly data from programme start; 20-year historical series for modelling

**Responsible Role Type:** Strategic Funding & Treasury Lead

**Access Difficulty:** Easy - public statistical databases

**Steps:**

- Download HICP data from Eurostat database
- Download EUR/CHF series from SNB data portal
- Extract historical consumer price and energy/materials sub-indices

### 17. Patent and Technology Landscape Data for Additive/Subtractive Manufacturing, Lithography, Robotics, and Miniaturization

**ID:** b1e0f199-2871-48a5-b5d4-2fee034bd298

**Description:** Patent filing, assignment, and classification data from patent databases. Needed for freedom-to-operate analysis, IP ownership mapping, and commercial licensing strategy.

**Recency Requirement:** Last 10-20 years for landscape; current filings for ongoing monitoring

**Responsible Role Type:** Commercialization and Licensing Lead

**Access Difficulty:** Easy - public patent databases

**Steps:**

- Search Espacenet and Google Patents
- Run classification queries for additive manufacturing, lithography, robotics, and miniaturization
- Review assignments to identify key IP owners

### 18. Environmental Baseline Data for Candidate Sites (Air, Water, Ecology, Noise)

**ID:** 271b8678-66eb-4c8f-862c-878bfeecb57c

**Description:** Official environmental monitoring data and baselines from national, regional, and local environmental agencies for proposed site areas. Input for environmental impact asessments and permitting.

**Recency Requirement:** Last 3-5 years

**Responsible Role Type:** Safety, Environmental & Sustainability Lead

**Access Difficulty:** Medium - public registers exist but detailed site data often requires request

**Steps:**

- Access national environmental data portals
- Contact regional environmental agencies for site-specific data
- Review public impact asessments for nearby industrial projects

### 19. CERN, ASML, Zeiss, and Fraunhofer Institutional Cooperation and IP Policies

**ID:** 0203094c-4413-47a9-9ebd-d85ceeb25f48

**Description:** Official institutional policies and legal frameworks on knowledge transfer, IP ownership, industrial partnership, and participation constraints. Needed to validate partner engagement and SPV design.

**Recency Requirement:** Current policies in force

**Responsible Role Type:** Cross-Border Legal, Regulatory & Export Control Lead

**Access Difficulty:** Hard - internal policies require institutional engagement and may be confidential

**Steps:**

- Contact knowledge transfer offices at each institution
- Review published IP and collaboration policies
- Request institutional legal guidance on industrial partnership and export-control constraints

### 20. National Construction and Environmental Permiting Legislation for France, Germany, Netherlands, Switzerland

**ID:** 1fe6bc25-9b39-4bb7-bac1-63b946b0cb02

**Description:** Legal texts for construction permits, environmental impact assessments, and permitting timelines in the four host jurisdictions. Input for the permitting calendar and site development strategy.

**Recency Requirement:** Current versions

**Responsible Role Type:** Cross-Border Legal, Regulatory & Export Control Lead

**Access Difficulty:** Medium - official public legal texts require legal interpretation

**Steps:**

- Search national legislation portals
- Obtain national environmental code and construction ordinances
- Consult local counsel for consolidated permitting requirements

### 21. Official Space Agency Technology Roadmaps and Mission Demand Data (ESA, NASA, National Agencies)

**ID:** 1e536369-50c8-4dda-ac8b-3a48b8ec5403

**Description:** Published technology roadmaps, mission architecture studies, and in-orbit servicing/manufacturing requirements from space agencies. Input for space-readiness requirements and killer-application demand definition.

**Recency Requirement:** Latest published roadmaps within last 2-5 years

**Responsible Role Type:** Space Manufacturing Commercialization Strategist

**Access Difficulty:** Easy - many technology roadmaps are public

**Steps:**

- Search ESA and NASA technology roadmap publications
- Review in-orbit servicing and manufacturing mission studies
- Contact national space agencies for strategic outlook documents