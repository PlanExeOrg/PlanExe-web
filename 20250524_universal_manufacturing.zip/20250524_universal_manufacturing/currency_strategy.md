This plan involves money.

## Currencies

- **EUR:** The programme is explicitly budgeted at EUR 200 billion, and the primary sites in France, Germany, and the Netherlands are all in the eurozone, making EUR the natural currency for consolidated budgeting, procurement, and reporting.
- **CHF:** One major site is in the Geneva/Meyrin region near CERN in Switzerland, where local salaries, services, and some operational expenses will be incurred in Swiss francs.

**Primary currency:** EUR

**Currency strategy:** Use EUR as the single consolidated budgeting and reporting currency for the 20-year programme, aligning with the stated EUR 200 billion envelope and the eurozone locations. Denominate major contracts, funding tranches, and inter-site transfers in EUR to minimize conversion costs. Maintain a smaller CHF allocation for Swiss-side operational expenditures near CERN, with periodic hedging or natural offset mechanisms to manage EUR/CHF exchange-rate exposure over the long project horizon.