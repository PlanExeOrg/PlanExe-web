Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 17 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 2 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any laws of physics. The plan focuses on engineering and scaling existing manufacturing techniques, not on novel physics. The plan states a goal to "manufacture 95% of necessary components from basic industrial feedstock".

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (modular factory) + market (space components) + tech/process (95% from basic feedstock) + policy (sustainable space exploration) without independent evidence at comparable scale. There is no credible precedent for this whole system. The plan states a goal to "manufacture 95% of necessary components from basic industrial feedstock".

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Each track must produce one authoritative source or a supervised pilot showing results vs a baseline. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Owner: Project Manager / Deliverable: Validation Report / Date: 2027-12-31.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because no business‑level mechanism‑of‑action is defined for the buzzwords. The plan mentions "modular", "miniaturized", "additive", "subtractive", but lacks a clear mechanism of action (inputs→process→customer value).

**Mitigation**: Project Manager: Create one-pagers for each buzzword, defining the mechanism-of-action, owner, and measurable outcomes, to ensure strategic clarity by 2027-03-31.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major hazard class (safety) is absent or minimized. The plan mentions "safety measures" but lacks specifics. The plan states "The Pioneer's Gambit is the most fitting scenario because its high-risk, high-reward approach aligns with the plan's ambitious goal".

**Mitigation**: Safety Officer: Develop a comprehensive safety plan, including hazard identification, risk assessment, and control measures, with a review cadence, by 2027-03-31.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions "Regulatory and permitting delays" as a risk, but lacks a detailed matrix of required permits and their lead times. The plan states "Start permitting process early, engage with regulators, assess impact, plan contingencies".

**Mitigation**: Permitting Lead: Develop a permit/approval matrix with lead times, dependencies, and responsible parties, and a NO-GO threshold on slip, by 2027-03-31.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed sources/term sheets are absent. The plan mentions a "EUR 200 billion budget over 20 years" but lacks details on funding sources, draw schedule, or covenants. The plan states "Secure Project Funding" but lacks specifics.

**Mitigation**: CFO: Develop a dated financing plan listing sources/status, draw schedule, covenants, and a NO-GO on missed financing gates by 2027-03-31.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions "Regulatory and permitting delays" as a risk, but lacks a detailed matrix of required permits and their lead times. The plan states "Start permitting process early, engage with regulators, assess impact, plan contingencies".

**Mitigation**: Permitting Lead: Develop a permit/approval matrix with lead times, dependencies, and responsible parties, and a NO-GO threshold on slip, by 2027-03-31.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., prototype in 5 years, 50% component manufacturing in 10 years, 95% in 20 years) as single numbers without ranges or alternative scenarios. The plan states "Prototype in 5 years, 50% component manufacturing in 10 years, 95% in 20 years".

**Mitigation**: Project Manager: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the 95% component manufacturing projection by 2027-03-31.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical engineering artifacts—specifications, interface contracts, acceptance tests, integration plans, and non-functional requirements—are absent. The plan lacks detailed documentation for core components, risking project failure.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates by 2027-06-30.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because any critical legal/contract/operational claim lacks a verifiable artifact. The plan states "Secure locations near European innovation centers (CERN, ASML, Zeiss, Fraunhofer)" but lacks evidence of agreements with these centers.

**Mitigation**: Legal Team: Obtain letters of intent or collaboration agreements with CERN, ASML, Zeiss, and Fraunhofer by 2027-03-31.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the abstract deliverable "a new system" is mentioned without specific, verifiable qualities. The plan states "Establish an Earth-based modular, miniaturized factory system capable of additive and subtractive manufacturing..."

**Mitigation**: Project Manager: Define SMART criteria for the factory system, including a KPI for system uptime (e.g., 99% availability) by 2027-03-31.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'Miniaturization Scale' as a key decision, but it does not appear to directly support the core project goals of adaptability or component manufacturing. The plan states "Establish an Earth-based modular, miniaturized factory system capable of additive and subtractive manufacturing..."

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of 'Miniaturization Scale', complete with a KPI, owner, and estimated cost, or move the feature to the project backlog by 2027-03-31.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a 'Manufacturing Process Architect' with expertise in both additive and subtractive manufacturing, materials science, and process optimization. This combination is rare and critical for achieving the project's goals. The plan states "Responsible for designing and optimizing the additive and subtractive manufacturing processes".

**Mitigation**: HR: Conduct a talent market analysis for a Manufacturing Process Architect with additive/subtractive expertise to validate availability within 90 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan omits a regulatory matrix (authority, artifact, lead time, predecessors). The plan mentions "Regulatory and permitting delays" as a risk, but lacks a detailed mapping of required approvals. The plan states "Start permitting process early, engage with regulators, assess impact, plan contingencies".

**Mitigation**: Permitting Lead: Develop a regulatory matrix (authority, artifact, lead time, predecessors) to map required approvals, and a NO-GO on adverse findings, by 2027-03-31.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan lacks a detailed operational sustainability plan. The plan mentions "Maintaining factory requires expertise" as a risk, but lacks a comprehensive strategy for long-term funding, maintenance, scalability, and personnel. The plan states "Training, competitive salaries, preventative maintenance".

**Mitigation**: Operations Team: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms by 2027-06-30.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan omits a regulatory matrix (authority, artifact, lead time, predecessors). The plan mentions "Regulatory and permitting delays" as a risk, but lacks a detailed mapping of required approvals. The plan states "Start permitting process early, engage with regulators, assess impact, plan contingencies".

**Mitigation**: Permitting Lead: Develop a regulatory matrix (authority, artifact, lead time, predecessors) to map required approvals, and a NO-GO on adverse findings, by 2027-03-31.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions diversifying supply and long-term contracts, but lacks evidence of secondary suppliers or tested failover plans for critical vendors/data. The plan states "Diversify supply, long-term contracts, inventory management".

**Mitigation**: Supply Chain Manager: Identify secondary suppliers for critical feedstocks and develop/test a failover plan for each by 2027-06-30.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Finance Department is incentivized by quarterly budget adherence, while the R&D Team is incentivized by long-term innovation, creating a conflict over experimental spending. The plan states "Cost control, contingency plans, cost-benefit analyses".

**Mitigation**: Executive Team: Define a shared, measurable objective (OKR) that aligns both Finance and R&D on a common outcome, such as 'achieve X% ROI within Y years', by 2027-03-31.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Establish a monthly review with a KPI dashboard and a lightweight change board, including owners and thresholds, by 2027-03-31.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because ≥3 High risks are strongly coupled. Technical risk (manufacturing components), financial risk (budget), and regulatory risk (permits) are strongly coupled. Technical challenges can lead to budget overruns and regulatory delays, creating a multi-domain failure. The plan states "Technical challenges in manufacturing components from feedstock".

**Mitigation**: Project Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by 2027-06-30.