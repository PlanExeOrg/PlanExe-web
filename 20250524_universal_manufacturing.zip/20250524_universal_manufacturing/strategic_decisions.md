## Primary Decisions
The vital few decisions that have the most impact.


The five Critical levers—Funding Commitment Phasing, Miniaturization Pathway, Inter-Module Interface Covenant, Component Coverage Sequencing, and External Input Allowance—jointly govern the core tensions: long-term certainty vs staged accountability, early feasibility vs space-ready compactness, parallel development vs integrated design, and universality credibility vs achievable schedule. High-leverage supporting choices on feedstock resilience, electronics sourcing, contamination zoning, measurement gating, and validation determine execution fidelity.

### Decision 1: Miniaturization Pathway
**Lever ID:** `500f4545-fc37-4b9d-85c8-5903fe14ee61`

**The Core Decision:** This lever decides the physical scale trajectory of the manufacturing modules, from macro prototypes to nano-scale systems. It sets the timeline for space-readiness and the risk envelope. Success hinges on achieving the 95% component coverage in increasingly compact footprints without sacrificing yield. The choice also influences the required precision of positioning, thermal control, and material handling systems. It also determines the investment needed in precision robotics and environmental isolation.

**Why It Matters:** Choosing the miniaturization pathway dictates the technology readiness timeline and the risk profile of the entire programme. A macro-first approach lowers early failure risk but may embed design constraints that hinder later shrink; an extreme-miniaturization-first bet accelerates space compatibility but exposes the project to brittle yield problems; an incremental modular strategy spreads risk but extends the integration phase. This decision also influences the metrological challenges and the ability to test components in environments representative of space conditions.

**Strategic Choices:**

1. Launch a two-track development program that simultaneously pursues a macro-scale functional prototype and a radically miniaturized bench-scale unit, with a gate decision to merge them once both meet performance thresholds.
2. Commit directly to extreme miniaturization from the outset by investing in nanoscale additive/subtractive tools, accepting higher technical risk in exchange for maximum portability and space-readiness.
3. Engineer a modular scalable architecture where each module is standardized in physical footprint and interface, enabling incremental miniaturization of individual subsystems without redesigning the whole line.

**Trade-Off / Risk:** The extreme-miniaturization-first path risks accumulating unproven exotic mechanisms, while the macro-first path could crystallize a design that cannot satisfy the 95% coverage within the footprint required for space.

**Strategic Connections:**

**Synergy:** Complements Component Coverage Sequencing, as miniaturization constraints dictate which components can be integrated at each scale; also leverages Thermal Envelope Separation to manage heat dissipation in dense modules.

**Conflict:** Extreme miniaturization demands stricter metrology, which may slow Measurement Gate Rhythm and create bottlenecks unless inspection tools are co-developed in parallel.

**Justification:** *Critical*, Critical: It sets the entire physical-scale trajectory toward space-readiness, determining the programme's risk envelope and timeline. Its synergy with coverage sequencing and thermal/contamination zoning, and its conflict with measurement gating, make it a central hub governing feasibility versus compactness.

### Decision 2: Funding Commitment Phasing
**Lever ID:** `116ef633-7e62-4c49-903f-e2286e462fd0`

**The Core Decision:** This lever determines the financial structure over the 20-year programme: staged milestones, full binding commitment, or public-private consortium. It affects political resilience, supplier confidence, and the ability to pursue high-risk research. Key metrics include the stability of funding flows, the flexibility to reallocate resources, and the alignment of incentives with long-term space goals. The chosen phasing influences whether breakthrough discoveries can survive missed short-term targets.

**Why It Matters:** The funding phasing determines the programme's resilience to political, economic, and technological shifts over its 20-year horizon. Staged milestones preserve accountability but risk losing momentum and key staff if gates are missed; a full commitment ensures continuity but reduces flexibility; a consortium model aligns incentives with commercialisation but may prioritise near-term outputs over long-term space ambitions. This lever affects the confidence of suppliers, partners, and regulators, and influences whether the programme can attract and retain world-class researchers.

**Strategic Choices:**

1. Secure a ten-year interim commitment of €100B with performance-linked releases, forcing the programme to hit staged technical milestones before releasing the remaining funds.
2. Obtain a binding full 20-year funding agreement from member states and private investors, guaranteeing long-term stability but locking in a budget that may become misaligned with evolving priorities.
3. Structure funding as a public-private risk-sharing consortium where private partners co-invest in specific modules in exchange for future licensing rights, reducing upfront public burden but complicating governance and intellectual property.

**Trade-Off / Risk:** Performance-linked gates assume that intellectual progress can be measured in linear milestones, but breakthrough research often comes from serendipity, so overly rigid phasing could starve high-risk, high-reward avenues.

**Strategic Connections:**

**Synergy:** Aligns with Expertise Lifespan Insurance, as longer funding guarantees help retain specialized talent; also complements Measurement Gate Rhythm by providing clear financial checkpoints that synchronize with technical reviews.

**Conflict:** Rigid milestone phasing can conflict with Miniaturization Pathway, which may require sustained investment over long periods before yielding compact, space-ready modules.

**Justification:** *Critical*, Critical: A 20-year, EUR 200B programme cannot survive without a financial structure that balances stability, accountability, and flexibility. It controls supplier confidence, talent retention, and the tolerance for high-risk research, while its staged tranches must accommodate the long, non-linear miniaturization and coverage timelines.

### Decision 3: Inter-Module Interface Covenant
**Lever ID:** `fe197992-15ca-44df-b07a-97468529c649`

**The Core Decision:** Governs the mechanical, power, fluid, and data interfaces that let modules built at different European centres assemble into one factory. Scope includes drafting an open specification, proving compliance, and deciding when to freeze tolerances. Key success metrics are integration lead time, retrofit cost, upgradeability, and supplier competitiveness. The critical design choice is temporal: codifying interfaces too early risks freezing unproven dimensions, while waiting too long prevents parallel development.

**Why It Matters:** Defining mechanical docking, power, fluid, and data interfaces for every module allows the separate innovation centers to develop their pieces in parallel and later assemble them into an integrated factory. An open interface specification also creates a competitive supply market, but publishing it before prototypes reveal actual tolerance needs may freeze flawed dimensions into hardware and force costly retrofits.

**Strategic Choices:**

1. Publish an open interface specification for mechanical docking, fluid and power couplings, and data handshakes, and require every developer to demonstrate compliance before integration.
2. Appoint one prime integrator to own a proprietary integration layer that translates between modules rather than imposing common physical interfaces.
3. Defer interface standardization until prototype modules have been tested jointly, then codify only the interfaces proven necessary for integrated operation.

**Trade-Off / Risk:** Interface contracts allow parallel module development, but premature standardization locks in untested tolerances and makes later module substitution or upgrades prohibitively expensive after hardware exists.

**Strategic Connections:**

**Synergy:** Enables Site Orchestration Model by letting independent innovation centres develop modules in parallel, and supports Toolset Commonality Mandate by standardising tool docking and cable connection points.

**Conflict:** Frozen interface specifications can constrain Miniaturization Pathway by locking in connector sizes and spacing before compact modules are optimised, making later downsizing or substitution expensive.

**Justification:** *Critical*, Critical: It enables parallel module development across independent European centres and defines physical, fluid, and data integration across the factory. The timing of interface freeze controls the trade-off between parallel speed and future miniaturization flexibility, making it a foundational enabler of the modular system.

### Decision 4: Component Coverage Sequencing
**Lever ID:** `9411a2ac-be85-4b0f-a64f-260c07a583b2`

**The Core Decision:** This lever determines the order in which the factory proves manufacturing capability across material families—structural, mechanical, sensors, electronics, propulsion, energy. It shapes technical risk retirement, workforce build-up, and when demonstrable output first exists. Success metrics include coverage percentage over time, process-chain qualification milestones, and time-to-first-integrated-demo. The choice also implicitly ranks which feedstock transformations and toolset adaptations must mature earliest.

**Why It Matters:** Sequencing the factory's growth toward 95% component coverage sets which material families and process chains must be proven first. An electronics-first path retires the highest technical risk early but leaves the integrated system without mechanical products for a long time, while a mechanical-first path yields demonstrable modules quickly and postpones the hardest precision problems to the end.

**Strategic Choices:**

1. Stage capability blocks by material family, delivering structural and mechanical components first, then sensors, electronics, and finally propulsion and energy systems.
2. Prioritize FPGAs and precision electronics in the first phase to retire the highest technical risk before scaling any mechanical production.
3. Derive the sequence from a component-makeability map that ranks every remaining item by coverage gap and process modification cost.

**Trade-Off / Risk:** Sequencing component coverage attacks the hardest precision work first if started with electronics, but the delayed mechanical output leaves the integrated factory without a demonstrable system until late in a very long program.

**Strategic Connections:**

**Synergy:** Sequencing capability blocks by material family gives Funding Commitment Phasing natural tranche gates tied to demonstrated coverage, and anchors Measurement Gate Rhythm's densest instrumentation on the first, highest-risk process chains.

**Conflict:** An electronics-first sequence delays demonstrable integrated output, starving the Validation and Demonstration Protocol of complete modules for years, while deferred hardest classes strain any full-elimination stance in the External Input Allowance.

**Justification:** *Critical*, Critical: It sets the order for proving 95% component coverage, determining risk retirement, workforce ramp-up, and time to first integrated demonstration. It anchors funding tranches and measurement gates, and balances electronics-first risk reduction against early mechanical output and external credibility.

### Decision 5: External Input Allowance
**Lever ID:** `8aeb751f-81b9-4314-a9d3-3d84086f8e61`

**The Core Decision:** This lever draws the credibility boundary of the 95% in-factory claim by defining which component classes may remain externally sourced, and under what review cadence exceptions shrink or persist. It directly scopes process development effort and site build-out. Success metrics include count and complexity of residual external inputs, elimination-roadmap adherence, and defensibility of the universality claim under audit.

**Why It Matters:** The ambition claims over 95% of components are made in-factory, so defining the residual external allowance determines where the credibility boundary sits. Committing to eventual elimination of all external inputs forces the hardest process development and site build-out now, driving cost and schedule risk; keeping a rotating exception list preserves focus on the highest-value coverage but leaves credible doubt about the universality claim. Commoditizing the residual to the simplest possible external inputs shrinks the exposed surface area while honestly acknowledging some outside dependency remains.

**Strategic Choices:**

1. Commit to eventual fabrication of every component class in-factory with a published elimination roadmap for residual external inputs, accepting that the hardest process development must succeed on schedule for the universality claim to hold.
2. Maintain a rotating external exception list re-reviewed every year, deliberately excluding the most exotic component classes from in-factory scope to protect the schedule of the highest-value 95%.
3. Restrict external dependencies to the simplest possible inputs such as standard reagents and basic feedstock, forcing every complex subsystem to be proven in-factory while acknowledging a minimal outside surface remains.

**Trade-Off / Risk:** Committing to full elimination proves universality but bets the programme on its hardest processes meeting schedule; a rotating exception list protects delivery while leaving the 95% claim perpetually contestable.

**Strategic Connections:**

**Synergy:** The rotating exception list bounds Component Coverage Sequencing's terminal scope, telling it which process chains never need qualification, and confining residual dependencies to basic feedstock concentrates Feedstock Resilience Architecture's adaptability work.

**Conflict:** A full-elimination commitment front-loads the hardest process development, straining Funding Commitment Phasing's tranche schedule, while a perpetually rotating exception list undermines the universality claim the Validation and Demonstration Protocol must certify.

**Justification:** *Critical*, Critical: It sets the credibility boundary of the 95% in-factory claim and directly scopes which process chains must be developed and which may remain external. It controls the ambition-versus-schedule trade-off and interacts with coverage sequencing, validation, and funding commitments.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Feedstock Resilience Architecture
**Lever ID:** `22f0028f-5d24-4a71-93f5-d057c08fbf0d`

**The Core Decision:** This lever defines how the factory handles raw material variability and purity. It balances between adaptive process control, centralized conditioning, and tolerant design. Key success metrics include the fraction of feedstock acceptable without pre-treatment, energy and capital cost per module, and the speed at which new material compositions can be qualified. The choice also determines how much metrology and software sophistication must be built in-house versus outsourced.

**Why It Matters:** The chosen feedstock resilience architecture determines the energy and capital expenditure profile across the programme. Adaptive control reduces pre-processing costs but demands a heavy investment in metrology and software; conditioning centralises purity risk but imposes transport logistics; tolerant-process design shifts cost to post-processing and quality assurance. Trade-offs involve throughput, scrap rates, and the time required to validate new materials for each component class.

**Strategic Choices:**

1. Develop an adaptive process control system that performs in-line spectroscopy on every feedstock batch and recalibrates additive and subtractive parameters autonomously to maintain component tolerances across purity swings.
2. Construct a centralized feedstock conditioning facility that performs targeted purification and standardizes input chemistry for every production module, trading energy cost for compositional consistency.
3. Engineer each manufacturing process to operate across wide tolerance windows, accepting lower purity inputs and compensating with more extensive post-processing, measurement, and rework loops.

**Trade-Off / Risk:** Adaptive control promises flexibility but depends on metrology that itself must be manufactured to 95% coverage, potentially importing a reliance on precision tools the project aims to produce.

**Strategic Connections:**

**Synergy:** Aligns with Electronics Fabrication Sourcing, as semiconductor lithography demands tight purity control; also reinforces Measurement Gate Rhythm, which provides the metrology feedback loops needed to validate adaptive process adjustments.

**Conflict:** Tolerant process designs may undermine Toolset Commonality Mandate, as accepting low-purity inputs forces additional purification or rework tools that diverge from standardized equipment sets.

**Justification:** *High*, High: It directly addresses the plan's explicit requirement for adaptability to material purity variation and connects electronics fabrication with measurement gates and thermal heat recovery. However, it is operationalized through coverage and interface choices, making it a critical enabler rather than the controlling strategic decision.

### Decision 7: Electronics Fabrication Sourcing
**Lever ID:** `e9692ac6-7651-4768-abde-6ddffb7d5123`

**The Core Decision:** This lever determines how semiconductor manufacturing capability is acquired: co-development, licensing, or maskless direct-write. It affects the timeline, cost, and strategic independence of the electronics subsystem. Key metrics include time to first custom chip, resolution achieved, throughput, and the degree to which the process tolerates the factory's feedstock variability. The choice shapes the project's credibility in claiming 95% self-sufficiency.

**Why It Matters:** The sourcing of semiconductor fabrication technology determines whether the factory can achieve the required chip complexity from raw feedstock. Co-development yields bespoke capabilities but risks schedule slippage and IP entanglements; licensing accelerates time to capability but imposes dependency on external processes and possibly material constraints; direct-write technology offers design flexibility but may lack the resolution and throughput needed for volume production. This lever strongly influences the credibility of the 95% component coverage claim and the project's self-sufficiency narrative.

**Strategic Choices:**

1. Co-develop with ASML and Zeiss a dedicated lithography and metrology subsystem tailored to the modular factory's footprint, trading external dependency for high confidence in node capability.
2. License proven semiconductor process kits from existing fabs and adapt them to the feedstock tolerance requirements, reducing R&D timeline but paying royalties and accepting process transfer constraints.
3. Pursue a maskless direct-write E-beam lithography approach that avoids conventional reticle supply chains, enabling rapid design changes but requiring substantial investment in beam control and throughput.

**Trade-Off / Risk:** Licensing known processes may conflict with feedstock purity tolerance, while developing a maskless lithography system from scratch could delay electronics manufacturing past every programme milestone.

**Strategic Connections:**

**Synergy:** Works with Feedstock Resilience Architecture to align lithography purity requirements with feedstock conditioning; also supports Toolset Commonality Mandate by standardizing semiconductor tool interfaces across modules.

**Conflict:** Conflicts with Inter-Module Interface Covenant, as licensed semiconductor process kits often come with proprietary interfaces that resist standardization across factory modules.

**Justification:** *High*, High: Semiconductors and FPGAs are the highest-risk component classes and underpin the credibility of the 95% claim. This lever controls whether they can be sourced or co-developed effectively, interacting with feedstock resilience and interface standardization, but it remains one capability decision within the broader coverage strategy.

### Decision 8: Site Orchestration Model
**Lever ID:** `c63e7aa4-4623-47f0-9514-360e5539b805`

**The Core Decision:** This lever shapes the physical and organizational layout of R&D and production sites: federated network, consolidated flagship, or rotating residency. It influences collaboration efficiency, logistics complexity, and access to specialized infrastructure. Success is measured by the speed of knowledge transfer, the reliability of the digital twin coordination, and the ability to attract talent while maintaining IP security. The model also determines how well local supply chains can be tapped.

**Why It Matters:** Site orchestration dictates the efficiency of collaboration and the speed of knowledge transfer across partner institutions. A federated network maximises access to each partner's capabilities but complicates logistics and requires robust integration; a consolidated site simplifies command and control but may alienate partners and limit access to unique facilities; a rotating residency programme builds social capital but incurs relocation costs and risks losing continuity. This lever also shapes the ability to tap into local supply chains and specialised talent pools.

**Strategic Choices:**

1. Create a federated network of specialized centers near each partner institution, with a digital twin coordinating production schedules and knowledge transfer, but relying on high-speed data links and standardised interfaces.
2. Consolidate all critical activities into one flagship site near CERN and ASML, centralizing governance but risking talent scarcity and travel friction for the other collaborators.
3. Stand up a rotating residency program where technical teams move between partner facilities for defined periods, deepening tacit knowledge exchange but adding overhead and potential disruption to existing operations.

**Trade-Off / Risk:** The federated model presumes flawless digital integration, but cross-institutional data sharing and IP regimes could throttle coordination, undermining the network's ability to function as a single factory.

**Strategic Connections:**

**Synergy:** Reinforces Inter-Module Interface Covenant by requiring standardized data and physical interfaces across distributed nodes; also supports Measurement Gate Rhythm through harmonized remote inspection and verification procedures.

**Conflict:** May strain Contamination Envelope Zoning, as federated sites each require separate environmental control and contamination boundaries, increasing cost and complexity.

**Justification:** *High*, High: It determines how the partner centres near CERN, ASML, Zeiss, and Fraunhofer coordinate physically and digitally, influencing knowledge transfer and logistics. It depends on interface standardization and measurement harmonization, so it amplifies but does not define the core technical architecture.

### Decision 9: Validation and Demonstration Protocol
**Lever ID:** `321d14ad-e1f5-4733-b4b4-39c22d5da1e4`

**The Core Decision:** Defines how the programme proves its 95% component-manufacturing claim to regulators and markets. Scope includes certification matrices, continuous performance telemetry, and flagship proof-of-principle demonstrations. Key success metrics are credible coverage evidence, time-to-first-defensible-readiness, and acceptance by external stakeholders. The protocol should be designed as a learning system, not merely a verdict mechanism, so evidence gathered during early module trials shapes later demonstration expectations rather than locking in inflexible targets.

**Why It Matters:** The validation strategy shapes external perception and internal prioritisation of quality assurance efforts. A certification matrix provides regulatory clarity but may over-weight testing infrastructure and delay iteration; agile demonstration accelerates feedback but may struggle to conclusively prove the 95% claim; a single flagship success builds a compelling narrative but leaves the breadth of the 95% target unproven. This lever determines where testing centres, metrology, and quality assurance resources are concentrated and how quickly the programme can credibly claim readiness.

**Strategic Choices:**

1. Develop a comprehensive certification matrix that enumerates every component class and requires a batched demonstration of at least 95% yield per class, creating a defensible compliance baseline but slowing early demonstration.
2. Adopt an agile demonstration model where each production module continuously feeds performance data to a central database, allowing iterative improvement and real-time proof of coverage, but risking doubts about statistical validity.
3. Focus on a single flagship complex component, such as a complete FPGA, and demonstrate end-to-end production from feedstock to functional chip, establishing a proof-of-principle before tackling the full catalogue.

**Trade-Off / Risk:** A flagship demonstration of one complex chip does not actually establish that 95% of components are manufacturable, and the certification matrix could consume decades that the 20-year programme cannot afford.

**Strategic Connections:**

**Synergy:** Works with Measurement Gate Rhythm: every demonstration can feed formal gates, while Component Coverage Sequencing identifies which components to prove first and in what order to substantiate breadth.

**Conflict:** Rigorous certification demands may collide with Funding Commitment Phasing: early tranches expecting rapid market-ready proof can be depleted by compliance infrastructure before statistical validation of 95% coverage is possible.

**Justification:** *High*, High: It supplies the external proof and regulatory credibility for the 95% manufacturing claim, shaping where quality assurance resources concentrate. It depends on measurement gates and coverage sequencing and must balance rigorous certification against early demonstration, making it important but downstream of the core technical decisions.

### Decision 10: Contamination Envelope Zoning
**Lever ID:** `c83cd5dd-46a7-470c-9a50-e6f82f6c29e4`

**The Core Decision:** Determines the factory's pressure and airflow architecture, separating clean electronics bays from powder and subtractive dirty cells. Scope includes airlock design, buffered transfer ports, and single-direction flow sequencing. Key success metrics are electronics yield, contamination incident rate, and floor-area overhead per transfer. Since retrofitting airflow partitions after construction is extremely costly, this lever must be fixed early and treated as a spatial constraint that shapes every later module layout decision.

**Why It Matters:** Partitioning the factory into pressure-differentiated clean zones for electronics and dirty zones for powder, subtractive, and propulsion processes shapes every material flow and air-handling decision. This protects the yield of FPGAs and sensors but adds airlocks, buffered transfer ports, and cleaning procedures that consume the compact floor area the miniaturized factory depends on. Designers must trade defensive segregation against the modular system's need for short, direct material paths.

**Strategic Choices:**

1. Enclose all powder-based additive and subtractive cells in negative-pressure dirty zones separated from clean lithography and electronics bays by sequenced airlocks and buffered transfer ports.
2. Reorganize the production sequence so every subtractive and powder operation occurs before any wafer-level electronics fabrication in a single-direction material flow.
3. Redesign components to tolerate relaxed cleanliness by applying hermetic packaging, protective coatings, and self-test capability instead of expanding cleanroom infrastructure.

**Trade-Off / Risk:** Partitioning clean and dirty processes protects yield, but airlock and buffering overhead grows with each material transfer and may erode throughput gains from relaxed environmental specs.

**Strategic Connections:**

**Synergy:** Co-locating dirty, high-temperature cells means Contamination Envelope Zoning and Thermal Envelope Separation can share physical barriers. Inter-Module Interface Covenant then specifies the sealed, pressure-safe ports those barriers require.

**Conflict:** Airlocks and buffered transfer ports consume the compact floor area and direct material paths that Miniaturization Pathway depends on, forcing a trade-off between defensive segregation and dense modular integration.

**Justification:** *High*, High: It is a must-fix-early spatial constraint that protects electronics yield and dictates airlocks, material flow, and floor-area overhead. It shares barriers with thermal separation and conflicts with dense miniaturization, controlling a fundamental clean/dirty trade-off in the factory design.

### Decision 11: Thermal Envelope Separation
**Lever ID:** `aec01934-c7d3-4c16-b913-71cb66fa2a51`

**The Core Decision:** Isolates high-temperature deposition, sintering, and melting cells from thermally sensitive electronics assembly and metrology to prevent precision drift. Scope covers radiative barriers, independent in-cell thermal management, and centralized heat recovery. Key success metrics are thermal stability inside sensitive zones, energy recovery efficiency, equipment footprint overhead, and inter-cell move time. Captured heat can preheat feedstock and condition buildings, turning waste into an asset.

**Why It Matters:** Separating high-temperature deposition, sintering, and melting cells from low-temperature electronics assembly and metrology reduces thermal drift and protects precision. The same separation creates an opportunity to recover furnace waste heat for HVAC and feedstock preheating, yet the insulation and distance between clusters increase equipment footprint and move time. In a miniaturized factory, every isolation barrier competes with the goal of dense integration.

**Strategic Choices:**

1. Cluster all high-temperature deposition, sintering, and melting processes into thermally isolated cells separated by radiative barriers and independent in-cell thermal management.
2. Redesign low-temperature electronic assembly and metrology processes to tolerate a wider ambient temperature band so they can share floor space with warm process clusters.
3. Integrate a centralized heat recovery loop that captures furnace exhaust and compressor waste heat for building conditioning and feedstock preheating.

**Trade-Off / Risk:** Thermal segregation limits cross-process interference, but the miniaturized footprint raises energy density to the point where adjacency through structural conduction can undermine the barriers despite air-side isolation.

**Strategic Connections:**

**Synergy:** Combines with Contamination Envelope Zoning to let one boundary provide both thermal isolation and clean-dirty separation. Heat recovery also strengthens Feedstock Resilience Architecture by preheating variable feedstock and reducing energy sensitivity.

**Conflict:** Insulation, radiative barriers, and separation distance directly inflate equipment footprint and move times, trading off against Miniaturization Pathway's dense integration and short material chains.

**Justification:** *Medium*, Medium: Thermal isolation and waste-heat recovery support precision and efficiency, but much of the separation burden can be shared with contamination zoning. It affects footprint and move time without governing a primary strategic tension, so it is an optimisation lever rather than a central hub.

### Decision 12: Toolset Commonality Mandate
**Lever ID:** `b012f953-84cb-48ce-9906-331a31d52ab5`

**The Core Decision:** Mandates a single multi-process tool family across modules to reduce spare-parts inventory, training, and integration effort. Scope includes platform selection, interchangeable end-effectors, and process-head compatibility. Key success metrics are cross-module tool portability, inventory SKU count, and cycle-time parity with bespoke equipment. Because process physics differ, commonality should be concentrated at interface and control layers rather than forcing one technology to master every material transformation.

**Why It Matters:** Mandating one multi-process tool family across all modules reduces spare parts, operator training, and software integration effort. Because lithography, powder sintering, and subtractive cutting obey different physical principles, a single platform will run some processes at lower efficiency than bespoke equipment, potentially lengthening cycle times for the exact high-value components the factory must master.

**Strategic Choices:**

1. Procure one vendor-neutral multi-process platform with interchangeable end-effectors and process heads, then restrict every module to that platform family.
2. Maintain specialized tools for each material family and design module sizes around their individual footprints and utility requirements.
3. Begin with additive-only tooling to cover as much of the component catalog as possible, then add minimal subtractive and lithographic cells only where coverage gaps appear.

**Trade-Off / Risk:** A common toolset shrinks spare inventory and training, but lithography, powder sintering, and subtractive machining rest on different physical principles, so commonality may reach only the housing and interface layer.

**Strategic Connections:**

**Synergy:** Reinforces Inter-Module Interface Covenant by making tool docking and changeovers uniform, and enables Miniaturization Pathway by sharing utilities and shrinking per-module logistics overhead.

**Conflict:** Specialized operations such as Electronics Fabrication Sourcing lose efficiency when forced onto a generic platform, and Component Coverage Sequencing may be delayed if high-value components need bespoke process physics the common family cannot provide.

**Justification:** *Medium*, Medium: Standardizing tooling reduces inventory and training costs, but additive, subtractive, and lithographic process physics limit its reach. It reinforces interface and miniaturization goals, yet it is subordinate to decisions about coverage scope and integrated module architecture.

### Decision 13: Measurement Gate Rhythm
**Lever ID:** `6ec84122-291a-4608-b434-5fe3fda3a350`

**The Core Decision:** This lever sets the cadence and placement of metrology gates—from per-station in-situ sensing to critical-interface-only checks—balancing instrumentation cost and cycle time against early defect containment. It defines where adaptive control loops receive feedback on feedstock variation. Success metrics include scrap/rework rates, escaped-defect frequency, throughput penalty per part, and the measured correlation between feedstock purity and process failure.

**Why It Matters:** Denser in-situ metrology at every process step gives real-time feedback for feedstock compensation, catching drift before parts are scrapped, but it adds per-part measurement time and instrumentation cost that can throttle throughput. Placing gates only at critical interfaces reduces inline overhead and suits high-mix production, yet risks letting subtle material variation propagate into downstream assemblies where rework is far costlier than early rejection. The trade-off between measurement cost per part and defect containment cost depends on how tightly feedstock purity correlates with process failures — a correlation the project itself must measure.

**Strategic Choices:**

1. Install in-situ metrology at every process station, feeding adaptive control loops that compensate for feedstock drift in real time and accepting the added per-part measurement time and instrumentation footprint as the price of upstream containment.
2. Place measurement gates only at critical material interfaces and final assemblies, relying on statistical process control and batch sampling to keep inline inspection from becoming a throughput bottleneck.
3. Deploy a hybrid cadence that couples high-frequency at-line sensors on the highest-risk processes with periodic deep laboratory characterization of feedstock lots, tuning gate density dynamically as failure data accumulates.

**Trade-Off / Risk:** More measurement gates catch feedstock drift early but insert per-part time into a line built to prove output breadth; without knowing failure correlation, density choices are guesses that could throttle throughput or miss defects.

**Strategic Connections:**

**Synergy:** Real-time gate data powers Feedstock Resilience Architecture's adaptive compensation for purity drift, and supplies the auditable qualification evidence that the Validation and Demonstration Protocol needs for each proven process chain.

**Conflict:** Inline instruments and per-station dwell time compete with the Miniaturization Pathway for module volume and cycle budget, and dense gating throttles the throughput Component Coverage Sequencing needs to prove breadth quickly.

**Justification:** *High*, High: It drives the feedback loops that make feedstock resilience and validation credible, trading per-part measurement cost against defect containment. Dense or sparse gating affects throughput, footprint, and cycle time, but it executes the coverage sequence and validation protocol rather than defining them.

### Decision 14: Expertise Lifespan Insurance
**Lever ID:** `b2b42a2d-1273-4139-b0fa-280fa0778918`

**The Core Decision:** This lever safeguards scarce, hard-won know-how across a two-decade program through mentorship rotation, exhaustive documentation with digital twin records, and geographic redundancy of critical specialties. It treats attrition as an inevitable engineering constraint rather than an HR afterthought. Success metrics include practitioners per critical specialty, knowledge-decay lag between documentation and live practice, and time-to-competence for newly rotated staff.

**Why It Matters:** A structured mentorship and rotation program across the partner sites builds deep, transferable skill in a technology this novel, but it spreads specialists thin and raises coordination cost on every engineering decision. Exhaustive documentation with digital twin records preserves knowledge if individuals leave, yet documentation lags live practice and twins risk encoding outdated assumptions. Multi-site redundancy of critical skills protects against single-point loss but deliberately duplicates scarce senior talent that the project may be unable to split.

**Strategic Choices:**

1. Institute a structured mentorship and rotation program across all partner sites so every critical skill is held by at least two trained practitioners, accepting higher coordination overhead to harden institutional memory.
2. Build an exhaustive documentation regimen with digital twin records of every process decision, treating written and simulated knowledge as the durable asset even when it lags current shop-floor practice.
3. Redundantly seat each critical specialty at two geographically separate sites and run deliberate common challenges, deliberately paying premium salaries for duplicate senior talent to survive attrition over two decades.

**Trade-Off / Risk:** Rotation builds transferable skill but spreads scarce specialists thin; documentation and twins lag live practice. No retention scheme survives two decades without attrition modeling grounding the choice.

**Strategic Connections:**

**Synergy:** Rotation and geographic redundancy harden the Site Orchestration Model's multi-partner network against single-site loss, while transferable practitioners reinforce the Toolset Commonality Mandate by pressuring process tools toward shared, learnable standards.

**Conflict:** Premium salaries for duplicated senior talent compete directly with hardware capex in every Funding Commitment Phasing tranche, and rotating scarce specialists thins the deep expertise the Miniaturization Pathway's hardest problems demand.

**Justification:** *Medium*, Medium: Retaining scarce expertise across two decades is essential, but this is an organizational safeguard rather than a driver of technical strategy. It interacts with funding and site orchestration, yet rotation, documentation, and redundancy support rather than shape the core manufacturing architecture.
