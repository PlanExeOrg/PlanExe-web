### 1. Programme Steering Committee

**Rationale for Inclusion:** The 20-year, EUR 200 billion public-private consortium spans four sovereign hosts, multiple independent European sites, and strategic decisions that cannot be delegated to management. A strategic-level body is required to approve phase gates, funding releases, scope changes, and to arbitrate conflicts while maintaining political and investor confidence.

**Responsibilities:**

- Approve programme charter, strategic plan, and annual budget in 2026 real euros.
- Approve phase-gate decisions, funding tranche releases above EUR 10 billion, and five-year re-baselining.
- Approve any change in scope, schedule, or budget exceeding EUR 1 billion or affecting the five critical strategic levers.
- Approve major contracts, IP licensing terms, and public-private partnership arrangements above EUR 500 million.
- Set the strategic risk appetite and oversee the top-10 strategic risk register.
- Appoint and review the Programme Director and standing committee memberships.
- Resolve escalated conflicts from the PMO, Technical Advisory Group, Ethics and Compliance Committee, Audit and Risk Assurance Committee, and Stakeholder Engagement Group.

**Initial Setup Actions:**

- Finalise terms of reference and a conflicts-of-interest policy for all members.
- Elect an independent external Chair and appoint a vice-chair.
- Approve the EUR 200 billion real-euro baseline, risk appetite statement, and programme governance charter.
- Confirm the mandate, authority, and membership of the PMO and all standing committees.
- Schedule quarterly meetings, extraordinary meeting protocols, and reporting standards.
- Establish a classified reporting channel for export-control and commercially sensitive decisions.

**Membership:**

- Independent external Chair (non-executive, with no financial interest in project contractors or partners)
- Four senior representatives of sovereign shareholders (Switzerland, France, Netherlands, Germany)
- Two independent non-executive directors appointed on merit
- One elected representative of the private consortium investors
- European Commission observer (non-voting)
- Programme Director (non-voting, for reporting only)
- Co-opted technical and legal experts as required for agenda items (non-voting)

**Decision Rights:** Strategic decisions only: approves annual budgets, phase and funding gates, changes exceeding EUR 1 billion, contracts above EUR 500 million, strategic-lever changes such as miniaturization pathway, funding phasing, interface covenant, coverage sequencing, and external input allowance, plus all matters escalated from lower bodies.

**Decision Mechanism:** Consensus preferred; if not reached, 75% supermajority of voting members. If still deadlocked, the independent Chair has the final casting vote after consulting external advisers. Decisions affecting sovereign commitments additionally require support of at least one independent non-executive director.

**Meeting Cadence:** Quarterly regular meetings, with extraordinary meetings within 10 working days when a critical risk or escalation arises.

**Typical Agenda Items:**

- Strategic risk dashboard and top-10 risk review
- Phase-gate and milestone status against the 2026-2046 master schedule
- Budget drawdown, contingency reserve usage, five-year re-baselining and EUR/CHF hedging results
- Decisions on strategic levers: miniaturization pathway, interface covenant, coverage sequencing, external input allowance
- Major contracts and IP licensing items above EUR 500 million
- Reports from ARAC, Ethics and Compliance Committee, TAG, and Stakeholder Engagement Group
- Political, regulatory, and intergovernmental issues

**Escalation Path:** Final internal authority. No internal escalation for programme-level decisions; treaty-level or shareholder-consent issues are escalated to the intergovernmental shareholder council of the SPV.
### 2. Programme Management Office

**Rationale for Inclusion:** The programme's operational complexity - federated sites near CERN, ASML, Zeiss and Fraunhofer, 18,000 staff, 150,000 m2 of floor space, and a 20-year integrated schedule - requires a dedicated operational management body to execute the approved plan, coordinate module teams, and manage day-to-day risks below strategic thresholds.

**Responsibilities:**

- Maintain the integrated master schedule, cost baseline, and resource plan across all sites.
- Execute the annual plan and phase objectives approved by the Programme Steering Committee.
- Manage the operational risk register, interface register, makeability map, and coverage/yield metrics.
- Allocate budgets, staff, and facility capacity across workstreams within approved delegations.
- Run procurement processes below EUR 500 million and prepare larger contract requests for the PSC.
- Coordinate module development teams and the prime integrator to ensure interface compliance and integration readiness.
- Track technical gate readiness and arrange gate reviews.
- Implement PSC and committee decisions and report progress.

**Initial Setup Actions:**

- Establish PMO charter, reporting standards, and project-management methodology.
- Create the integrated master schedule, 2026 real-euro cost baseline, and single operational risk register.
- Appoint workstream leads, site operations leads, and prime-integrator liaison.
- Define delegation thresholds, escalation criteria, and decision templates.
- Configure digital twin, MES/ERP, and reporting dashboards for federated operation.

**Membership:**

- Programme Director (Chair, executive owner)
- Deputy Programme Director
- Head of Project Controls
- Head of Engineering and Technical Integration
- Site Operations Leads for Geneva/CERN, Veldhoven/ASML, and Oberkochen/Zeiss-Fraunhofer
- Prime Integrator Programme Manager
- Head of Procurement
- Head of Finance
- Head of Risk
- Head of Digital and Information Systems
- Ethics and Compliance liaison (non-voting advisor)

**Decision Rights:** Operational decisions within the approved plan: manages annual budget reallocations up to EUR 1 billion, enters contracts below EUR 500 million, adjusts schedules with no change to final Q4 2046 date, updates non-frozen interface register items, and allocates resources. Cannot change strategic levers, phase gates, total budget, or external input policy.

**Decision Mechanism:** Majority vote of core members. For urgent operational matters, the Programme Director may decide after consultation, with retroactive ratification at the next meeting. If site leads are deadlocked, the Programme Director has the casting vote; if a conflict of interest applies, the Deputy chairs that decision.

**Meeting Cadence:** Weekly operations stand-up and monthly integrated delivery review.

**Typical Agenda Items:**

- Critical-path schedule status and milestone slips
- Budget burn versus plan and contingency usage
- Interface register compliance and integration issues
- Makeability map updates and component coverage percentage
- Operational risk register, top operational risks and mitigation actions
- Procurement pipeline and contract execution
- Site operations: HSE, staffing, logistics, facilities
- Open actions from PSC, ARAC, Ethics and Compliance Committee, and TAG

**Escalation Path:** Escalates to the Programme Steering Committee for scope or budget changes beyond delegation, strategic-lever changes, unresolved cross-site disputes, or risks rated critical. Financial-control and integrity findings are concurrently reported to the Audit and Risk Assurance Committee.
### 3. Technical Advisory Group

**Rationale for Inclusion:** Given unresolved technology risk in miniaturization, semiconductor fabrication, additive and subtractive manufacturing, metrology, and the 95% coverage target, the programme needs independent external technical assurance to test assumptions, validate yield and TRL trajectories, and prevent groupthink. External members with no commercial stake ensure technical credibility.

**Responsibilities:**

- Review and challenge technology readiness levels, first-pass yields, process capability indices, and yield learning curves.
- Validate the component makeability map and coverage sequencing against technical feasibility.
- Assess technical risks of the miniaturization pathway, electronics fabrication sourcing, and feedstock resilience architectures.
- Recommend technical gate criteria, measurement standards, and demonstration protocols.
- Advise on interface-freeze timing and inter-module integration strategy.
- Identify emerging technologies or descoping options to preserve the 20-year schedule.
- Provide a written technical risk assessment to the PSC before each phase gate.

**Initial Setup Actions:**

- Appoint an independent Chair and internationally recognised experts with no commercial ties to project suppliers.
- Approve terms of reference, confidentiality, and conflicts-of-interest guidelines.
- Review the initial makeability map, TRL inventory, and yield assumptions from the project plan.
- Set the technical gate review calendar aligned with the 2026-2046 phases.
- Define metrics for technology risk monitoring that feed the PSC risk dashboard.

**Membership:**

- Independent external Chair (distinguished technologist, non-voting on PSC/PMO)
- 8-12 independent experts from non-partner institutions covering advanced manufacturing, semiconductor fabrication, metrology, robotics, materials science, systems engineering, and aerospace
- Two academic representatives from non-participating universities
- Programme Chief Engineer (technical secretary, non-voting)
- PMO representative (non-voting, attends at TAG invitation)

**Decision Rights:** Advisory and assurance only: issues recommendations on technical gate criteria, makeability map validation, interface-freeze timing, and descoping options. It has no authority to approve budget, schedule, or contracts; the PSC and PMO retain decision authority.

**Decision Mechanism:** Consensus preferred; when no consensus, recommendations are taken by majority and minority opinions are recorded. Dissenting views are submitted to the PSC. There is no casting vote on technical truth; the external Chair ensures the final advice clearly presents the balance of expert evidence.

**Meeting Cadence:** Quarterly full-group meetings, with focused deep-dive panels before each major technical gate and extraordinary sessions for critical technical risks.

**Typical Agenda Items:**

- TRL and yield status for electronics, FPGAs, miniaturized modules, and propulsion cells
- Component coverage percentage and remaining coverage gaps
- Makeability map updates and re-sequencing recommendations
- Readiness assessment for upcoming technical gates
- Interface freeze review and integration risk
- Feedstock variability and metrology data from in-line sensors
- Emerging technology alternatives and descope triggers

**Escalation Path:** Escalates technical risks or disagreements that exceed the PSC risk appetite directly to the Programme Steering Committee, with a copy to the Programme Management Office for immediate mitigation planning.
### 4. Ethics and Compliance Committee

**Rationale for Inclusion:** The programme's multi-jurisdiction footprint in Switzerland, France, the Netherlands and Germany, export-control obligations to BAFA, CDIU and SECO, GDPR requirements, corruption risks, and public-private funding demand a dedicated independent compliance body to own ethics and regulatory compliance oversight and prevent integrity failures that could threaten the EUR 200 billion mandate.

**Responsibilities:**

- Own the compliance and ethics framework, including GDPR and data protection, anti-corruption, conflicts of interest, whistleblower protection, and ethical research conduct.
- Oversee export-control classification and licensing with BAFA, CDIU, and SECO, and the technology-transfer matrix.
- Ensure compliance with ATEX, ISO 14644, ISO 45001, environmental permits, and EU Green Deal requirements.
- Review procurement, contracting, and licensing transactions for corruption risk and conflicts of interest.
- Direct the joint compliance office and cross-border regulatory task force.
- Approve compliance policies and monitor a programme-wide training and awareness programme.
- Investigate compliance breaches and require corrective actions.

**Initial Setup Actions:**

- Adopt terms of reference with a direct reporting line to the Programme Steering Committee.
- Appoint an independent external chair with international compliance and legal expertise.
- Conduct a compliance risk assessment across all Swiss, French, Dutch, and German sites.
- Approve the code of conduct, conflicts-of-interest policy, anti-corruption programme, and GDPR data-governance framework.
- Establish an independent multilingual whistleblower mechanism and joint compliance office.

**Membership:**

- Independent external Chair (compliance/international law, no conflict of interest)
- Two independent external compliance and data-protection experts
- SPV Chief Compliance Officer (executive secretary, non-voting)
- SPV Legal Director (non-voting advisor)
- Export-control liaison officers from the joint compliance office, one per host country
- Internal Audit liaison from ARAC (non-voting)
- Programme Director attends only when invited (non-voting)

**Decision Rights:** Within its compliance mandate, the Committee can stop non-compliant activities, suspend an export transfer or procurement, require remediation, and approve compliance policy. It cannot change technical or commercial objectives; material business-impacting remedies require PSC ratification.

**Decision Mechanism:** Majority vote of voting members; the external Chair has a casting vote on a tie. For material compliance findings, concurrence of at least one independent external member is required. Suspected criminal conduct must be reported unanimously by independent members to the PSC and, where legally required, to competent authorities.

**Meeting Cadence:** Monthly regular meetings, with extraordinary sessions within five working days for potential material compliance breaches.

**Typical Agenda Items:**

- Export-control license status, pending classifications, and technology-transfer movements
- GDPR and data-protection issues in the digital twin, MES/ERP, and cross-border data flows
- Corruption-risk indicators in major procurement and licensing transactions
- Whistleblower reports, investigations, and follow-up actions
- Compliance with ATEX, ISO 14644, ISO 45001, environmental regulations, and EU Green Deal
- Conflicts-of-interest declarations and management actions
- Ethics training completion rates and awareness campaign updates

**Escalation Path:** Escalates material or unresolved compliance issues to the Programme Steering Committee. Suspected fraud or criminal conduct involving PSC members is escalated to the SPV's external auditor and competent national authorities.
### 5. Audit and Risk Assurance Committee

**Rationale for Inclusion:** A EUR 200 billion, 20-year programme requires independent assurance over financial integrity, internal controls, and risk management. This committee protects against financial misallocation, undisclosed risks, and fraud by providing an arms-length oversight layer between the Programme Steering Committee and management.

**Responsibilities:**

- Oversee the enterprise risk management framework and maintain the strategic risk register independent of management.
- Review and challenge risk appetite, contingency reserve usage, and five-year re-baselining.
- Approve the internal audit plan and external audit scope; monitor audit findings and management actions.
- Review financial reporting, capital calls, drawdowns, and EUR/CHF hedging policies.
- Direct audits of the 95% coverage claim, makeability map, yield data, and certification evidence.
- Monitor cybersecurity and data-integrity audits per IEC 62443.
- Coordinate with the Ethics and Compliance Committee on fraud and corruption risk.

**Initial Setup Actions:**

- Establish the committee charter and appoint an independent external chair.
- Approve the risk taxonomy, risk-appetite statement, and single enterprise risk register.
- Appoint external auditors through a PSC-approved procurement.
- Commission the first financial-control audit and EUR/CHF hedging policy review.
- Define the audit sampling plan for coverage and yield claims.

**Membership:**

- Independent external Chair (senior audit/risk professional)
- Two independent external members with financial, audit, or enterprise-risk expertise
- One representative of the sovereign shareholders' audit bodies (non-voting)
- SPV Chief Risk Officer (executive secretary, non-voting)
- SPV Chief Financial Officer (non-voting attendee)
- Internal Audit Director (non-voting)
- Chair of Ethics and Compliance Committee (liaison, non-voting)

**Decision Rights:** Decision rights over assurance activities: approves internal and external audit plans, sets risk methodology, can require corrective actions for control deficiencies, and can recommend rejection of financial statements to the PSC. Cannot approve budget, scope, or contracts; these remain with the PSC and PMO.

**Decision Mechanism:** Decisions by majority of members. The independent Chair holds the casting vote on ties. Audit opinions on the SPV's financial statements require unanimous support of the independent members before being submitted to the PSC.

**Meeting Cadence:** Quarterly, plus extraordinary meetings within 10 working days after a major incident, material audit finding, or emerging strategic risk.

**Typical Agenda Items:**

- Enterprise risk register review: top risks, trends, and mitigation status
- Internal and external audit findings and management action tracking
- Capital calls, drawdown accuracy, and contingency reserve usage
- EUR/CHF hedging outcomes and five-year re-baselining scenarios
- Cybersecurity and data-integrity audit results
- Audit sampling of 95% coverage claims and yield data
- Coordination items with Ethics and Compliance on fraud and corruption

**Escalation Path:** Escalates material control failures, unmitigated critical risks, and suspected fraud to the Programme Steering Committee; illegal acts are reported to external regulators or auditors as required by law.
### 6. Stakeholder Engagement and Social License Advisory Group

**Rationale for Inclusion:** The programme depends on enduring political support and social acceptance across four countries and three local site communities. A dedicated advisory group with external civil-society and investor representation is needed to monitor sentiment, strengthen transparency, and de-risk the one-to-three-year legal and reputational threats identified in the risk assessment.

**Responsibilities:**

- Advise the PSC and PMO on stakeholder engagement, communications, and transparency.
- Oversee site-level stakeholder advisory boards near Geneva, Veldhoven, and Oberkochen.
- Monitor political, community, investor, and NGO sentiment and identify social-license risks.
- Review and advise on the EUR 2 billion community-benefit programme, local employment, education, and infrastructure commitments.
- Review quarterly public reporting and annual ESG and sustainability metrics.
- Support annual demonstration days and multilingual public engagement.
- Escalate reputational and political risks to the PSC.

**Initial Setup Actions:**

- Form site-level advisory boards with local mayors, community representatives, environmental NGOs, and employer representatives.
- Approve the stakeholder engagement and transparency plan.
- Conduct baseline sentiment assessments in all three host regions.
- Define social-license indicators and reporting cadence.
- Agree the community-benefit budget allocation process with the PMO and PSC.

**Membership:**

- Independent external Chair (community engagement/communications expert, non-voting on PSC)
- Representatives from local communities at each site (external)
- NGO representatives from environmental and social organisations (external)
- Private investor and future licensee representatives (external)
- Host-country government liaison officers, one per country (non-voting)
- Programme Communications Director (secretary, non-voting)
- PMO representative (non-voting liaison)

**Decision Rights:** Advisory on programmes and policy, with delegated authority to allocate the annual community-engagement budget up to an agreed threshold such as EUR 20 million per site per year within the PSC-approved plan. It may approve site-level public-reporting formats but cannot change technical scope or schedule.

**Decision Mechanism:** Consensus-based decisions; where consensus fails, a majority recommendation with dissenting views is transmitted to the PSC. The external Chair has a procedural casting vote; substantive disputes are escalated rather than resolved by the Chair.

**Meeting Cadence:** Bi-monthly full-group meetings; site-level advisory boards meet monthly.

**Typical Agenda Items:**

- Community sentiment and issue tracking at the three sites
- Political risk and host-government engagement updates
- Review of quarterly public reports and transparency initiatives
- ESG metrics: energy intensity, water recovery, waste, net-zero progress
- Community-benefit programme commitments and delivery status
- Investor communication and licensing transparency
- Planning for annual demonstration days and public VIP visits

**Escalation Path:** Escalates reputational, political, or community issues that could delay permits or funding to the Programme Steering Committee; urgent communications issues are referred to the Programme Director for immediate action.