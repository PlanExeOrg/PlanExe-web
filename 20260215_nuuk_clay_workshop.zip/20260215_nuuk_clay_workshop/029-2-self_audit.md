Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 20 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 0 | Material risk with plausible path. |
| ✅ Low | 0 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on unvalidated assumptions about Arctic shipping reliability, winter thermal stability, and volunteer instructor safety—each of which could cause operational failure. The expert review explicitly states that 'the workshop will face session cancellations in winter months due to material shortages' if shipping delays are not modeled, and that 'a single accident involving a volunteer could result in fatal injury, massive insurance claims, and permanent closure.' These risks are not mitigated by existing controls but depend on future validation steps, making success contingent on uncertain outcomes.

**Mitigation**: Supply Chain Coordinator: Commission an Arctic shipping risk assessment using historical DMA data and validate with a live simulation by March 31, 2026.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (clay workshop), market (local and tourist demand), tech/process (passive solar, modular kilns), and policy (cultural consent) without independent evidence at comparable scale. The expert review explicitly states that 'the workshop will face session cancellations in winter months due to material shortages' if shipping delays are not modeled, and that 'a single accident involving a volunteer could result in fatal injury, massive insurance claims, and permanent closure.' These risks are not mitigated by existing controls but depend on future validation steps, making success contingent on uncertain outcomes.

**Mitigation**: Supply Chain Coordinator: Commission an Arctic shipping risk assessment using historical DMA data and validate with a live simulation by March 31, 2026.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on unvalidated assumptions about Arctic shipping reliability, winter thermal stability, and volunteer instructor safety—each of which could cause operational failure. The expert review explicitly states that 'the workshop will face session cancellations in winter months due to material shortages' if shipping delays are not modeled, and that 'a single accident involving a volunteer could result in fatal injury, massive insurance claims, and permanent closure.' These risks are not mitigated by existing controls but depend on future validation steps, making success contingent on uncertain outcomes.

**Mitigation**: Supply Chain Coordinator: Commission an Arctic shipping risk assessment using historical DMA data and validate with a live simulation by March 31, 2026.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks explicit controls for cascading risks such as permit delays leading to missed peak season, revenue shortfalls, and cash crunches. The expert review identifies critical unvalidated assumptions—Arctic shipping disruptions, winter thermal failure, and volunteer liability—that directly trigger financial, safety, and reputational harm. Without a formal register mapping these second-order effects or mitigation plans for their cascades, the project faces existential failure modes if any single risk materializes.

**Mitigation**: Project Manager: Expand the risk register to map cascading impacts (e.g., permit delay → missed peak season → revenue shortfall → cash crunch) and assign owners with dated review cadence within 30 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan assumes reliable quarterly clay shipments from Denmark without validating Arctic shipping risks, which could cause 6–12-week delays. The expert review explicitly states that 'the workshop will face session cancellations in winter months due to material shortages' if shipping delays are not modeled. Additionally, the plan lacks formal integration of volunteer instructors into the operational framework, creating a $500,000–1,000,000 DKK liability risk per incident. These unmitigated risks directly threaten operational continuity and financial viability.

**Mitigation**: Supply Chain Coordinator: Commission an Arctic shipping risk assessment using historical DMA data and validate with a live simulation by March 31, 2026.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on unvalidated assumptions about Arctic shipping reliability, winter thermal stability, and volunteer instructor safety—each of which could cause operational failure. The expert review explicitly states that 'the workshop will face session cancellations in winter months due to material shortages' if shipping delays are not modeled, and that 'a single accident involving a volunteer could result in fatal injury, massive insurance claims, and permanent closure.' These risks are not mitigated by existing controls but depend on future validation steps, making success contingent on uncertain outcomes.

**Mitigation**: Supply Chain Coordinator: Commission an Arctic shipping risk assessment using historical DMA data and validate with a live simulation by March 31, 2026.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of 2 million DKK conflicts with vendor quotes and scale-appropriate benchmarks. The plan assumes a fixed quarterly clay shipment from Denmark, but expert review reveals that Arctic shipping delays could cause 6–12-week disruptions, risking session cancellations and revenue loss. The cost of emergency air freight is not included in the budget, and the 100,000 DKK contingency fund is insufficient to cover a single 300,000 DKK emergency shipment. Without a formal risk-adjusted budget or vendor quotes for emergency logistics, the financial model is implausible.

**Mitigation**: Financial Analyst: Benchmark emergency air freight costs with Nordic Cargo and Iceland Air, normalize per-area, and adjust the budget or de-scope by April 15, 2026.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections as single numbers without ranges, confidence intervals, or alternative scenarios. The 'Pragmatic Foundation' scenario assumes a fixed quarterly clay shipment schedule from Denmark without validating Arctic shipping risks, which could cause 6–12-week delays. The expert review explicitly states that 'the workshop will face session cancellations in winter months due to material shortages' if shipping delays are not modeled. Additionally, the plan lacks formal integration of volunteer instructors into the operational framework, creating a $500,000–1,000,000 DKK liability risk per incident. These unmitigated risks directly threaten operational continuity and financial viability.

**Mitigation**: Supply Chain Coordinator: Commission an Arctic shipping risk assessment using historical DMA data and validate with a live simulation by March 31, 2026.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for core components such as technical specs, interface contracts, acceptance tests, integration plans, and non-functional requirements. The absence of these artifacts is critical: without documented system interfaces, testable acceptance criteria, or integration maps, the project cannot ensure reliable software-hardware interactions, validate performance under load, or manage dependencies between subsystems. The expert review confirms that key assumptions—like Arctic shipping reliability and winter thermal stability—are unvalidated, and that volunteer instructors lack formal training and liability coverage, indicating a systemic failure to define and control build-critical elements.

**Mitigation**: Engineering Team: Produce technical specifications, interface definitions, acceptance test plans, and an integration map with owners and dates within 30 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on unvalidated assumptions about Arctic shipping reliability, winter thermal stability, and volunteer instructor safety—each of which could cause operational failure. The expert review explicitly states that 'the workshop will face session cancellations in winter months due to material shortages' if shipping delays are not modeled, and that 'a single accident involving a volunteer could result in fatal injury, massive insurance claims, and permanent closure.' These risks are not mitigated by existing controls but depend on future validation steps, making success contingent on uncertain outcomes.

**Mitigation**: Supply Chain Coordinator: Commission an Arctic shipping risk assessment using historical DMA data and validate with a live simulation by March 31, 2026.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project's final output, 'a sustainable community clay workshop in Nuuk,' is abstract and lacks specific, verifiable qualities. The plan mentions operational readiness by August 1, 2026, but fails to define measurable acceptance criteria for success beyond vague KPIs like 'zero session cancellations' without specifying how they will be validated or what constitutes failure. Critical deliverables such as the 'Inuit Clay Legacy Project' and 'Community Teaching Fellowship' are referenced without SMART criteria, including quantifiable KPIs for cultural authenticity, safety compliance, or financial sustainability.

**Mitigation**: Project Manager: Define SMART acceptance criteria for the workshop launch, including a KPI for session coverage (e.g., 98% coverage during soft launch) and a KPI for cultural approval (e.g., 100% of exhibitions approved by elders) within 30 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes the AI-assisted design tools as a core feature without evidence of technical feasibility or cultural alignment. This feature adds significant complexity and cost to the project, yet it does not directly support the primary goals of operational reliability, cultural authenticity, or year-round sustainability. The expert review explicitly states that '80% express concern about cultural misrepresentation,' indicating a high risk of reputational harm and community backlash. The absence of a benefit case for this tool, combined with its potential to undermine the Cultural Anchoring Framework, makes it a clear example of Gold Plating.

**Mitigation**: Cultural Liaison: Produce a one-page benefit case for AI-assisted design tools, including a KPI (e.g., 75% user satisfaction), owner (Cultural Liaison), and estimated cost (100,000 DKK), or move the feature to the project backlog within 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on unvalidated assumptions about Arctic shipping reliability, winter thermal stability, and volunteer instructor safety—each of which could cause operational failure. The expert review explicitly states that 'the workshop will face session cancellations in winter months due to material shortages' if shipping delays are not modeled, and that 'a single accident involving a volunteer could result in fatal injury, massive insurance claims, and permanent closure.' These risks are not mitigated by existing controls but depend on future validation steps, making success contingent on uncertain outcomes.

**Mitigation**: Supply Chain Coordinator: Commission an Arctic shipping risk assessment using historical DMA data and validate with a live simulation by March 31, 2026.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks mapped regulatory approvals and permits, with no evidence of engagement with Nuuk Municipality or Greenlandic environmental agencies. The expert review explicitly identifies 'failure to secure geothermal drilling permits in Nuuk’s urban zone' as a showstopper risk, and the absence of a formal compliance timeline or authority mapping creates a critical gap. Without documented lead times, predecessors, or early regulator engagement, the project faces a high likelihood of delays or denial, directly threatening operational viability.

**Mitigation**: Project Manager: Draft a regulatory matrix (authority, artifact, lead time, predecessors) and schedule early engagement with Nuuk Municipality and Greenlandic Environmental Protection Agency within 30 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project lacks a sustainable business model post-completion: ongoing operational costs exceed available funding, maintenance requires specialized skills and vendors not guaranteed long-term, and the system cannot adapt to changing conditions. The plan relies on unvalidated assumptions about Arctic shipping reliability, winter thermal stability, and volunteer instructor safety—each of which could cause operational failure. The expert review explicitly states that 'the workshop will face session cancellations in winter months due to material shortages' if shipping delays are not modeled, and that 'a single accident involving a volunteer could result in fatal injury, massive insurance claims, and permanent closure.' These risks are not mitigated by existing controls but depend on future validation steps, making success contingent on uncertain outcomes.

**Mitigation**: Project Manager: Develop an operational sustainability plan including a funding strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms within 30 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because success hinges on non-waivable approvals for zoning, land use, and permits in Nuuk’s urban zone, where geothermal drilling and commercial arts use face untested regulatory hurdles. The expert review explicitly identifies 'failure to secure geothermal drilling permits in Nuuk’s urban zone' as a showstopper risk, and the absence of a formal compliance timeline or authority mapping creates a critical gap. Without written confirmation from Nuuk Municipality and Greenlandic Environmental Protection Agency, the project cannot proceed legally, making this a fatal flaw.

**Mitigation**: Project Manager: Draft a regulatory matrix (authority, artifact, lead time, predecessors) and schedule early engagement with Nuuk Municipality and Greenlandic Environmental Protection Agency within 30 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on unvalidated assumptions about Arctic shipping reliability, winter thermal stability, and volunteer instructor safety—each of which could cause operational failure. The expert review explicitly states that 'the workshop will face session cancellations in winter months due to material shortages' if shipping delays are not modeled, and that 'a single accident involving a volunteer could result in fatal injury, massive insurance claims, and permanent closure.' These risks are not mitigated by existing controls but depend on future validation steps, making success contingent on uncertain outcomes.

**Mitigation**: Supply Chain Coordinator: Commission an Arctic shipping risk assessment using historical DMA data and validate with a live simulation by March 31, 2026.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Finance Department is incentivized by quarterly budget adherence and cost control, while the R&D Team is incentivized by long-term innovation and experimental spending. This creates a conflict over resource allocation: Finance seeks to minimize costs and avoid overspending, whereas R&D may push for higher investment in new materials or processes that could exceed initial budgets. The plan lacks a shared objective to balance these competing incentives.

**Mitigation**: Project Manager: Draft a joint OKR for Finance and R&D teams focused on 'Reducing per-unit material cost by 30% while successfully integrating at least two locally adapted materials into student projects by Q4 2026' within 30 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague 'we will monitor' is insufficient. The expert review explicitly identifies critical unvalidated assumptions—Arctic shipping disruptions, winter thermal failure, and volunteer liability—that could cause operational failure, yet no formal review cadence or decision triggers exist to act on these risks. Without a monthly review with KPI dashboard and a lightweight change board, the project cannot adapt to emerging threats.

**Mitigation**: Project Manager: Establish a monthly review with KPI dashboard and a lightweight change board, including thresholds for re-planning or stopping, within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on unvalidated assumptions about Arctic shipping reliability, winter thermal stability, and volunteer instructor safety—each of which could cause operational failure. The expert review explicitly states that 'the workshop will face session cancellations in winter months due to material shortages' if shipping delays are not modeled, and that 'a single accident involving a volunteer could result in fatal injury, massive insurance claims, and permanent closure.' These risks are not mitigated by existing controls but depend on future validation steps, making success contingent on uncertain outcomes.

**Mitigation**: Supply Chain Coordinator: Commission an Arctic shipping risk assessment using historical DMA data and validate with a live simulation by March 31, 2026.