*Roles Needed & Example People*

# Roles

## 1. Project Manager

**Contract Type**: `part_time_employee`

**Contract Type Justification**: The Project Manager is responsible for overseeing the entire project, ensuring timelines, budgets, and objectives are met. Given the need for consistent, long-term oversight and integration across multiple domains (logistics, safety, cultural compliance), a part-time employee role provides the necessary stability and accountability without full-time commitment. This aligns with the project's low-risk, cost-efficient staffing model while ensuring continuity through Year 1.

**Explanation**:
Oversees the entire project, ensuring timelines, budgets, and objectives are met.

**Consequences**:
Without a project manager, the project may lack direction, leading to missed deadlines and budget overruns.

**People Count**:
1

**Typical Activities**:
Clara's typical activities include coordinating project timelines, managing budgets, liaising with local stakeholders, overseeing the hiring process for instructors, and ensuring compliance with safety and cultural protocols. She also organizes community engagement events and monitors project progress to align with strategic goals.

**Background Story**:
Clara Jensen, a 34-year-old project manager from Nuuk, Greenland, has a degree in Arts Management from the University of Copenhagen. With over ten years of experience in community arts initiatives, Clara has successfully led multiple projects that focus on cultural engagement and sustainability. Her skills in budgeting, team coordination, and stakeholder engagement make her an ideal fit for overseeing the community clay workshop. Clara is familiar with the unique challenges of operating in Greenland, including logistical hurdles and cultural sensitivities, making her a vital asset to ensure the project's success.

**Equipment Needs**:
Digital project management software (e.g., Asana, Trello), laptop with internet access, secure cloud storage for documentation, bilingual communication tools (Danish/Greenlandic)

**Facility Needs**:
Dedicated office space within the workshop facility with reliable Wi-Fi, privacy for stakeholder meetings, and access to shared workstations

## 2. Supply Chain Coordinator

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Supply Chain Coordinator manages logistics and procurement of materials, including coordinating quarterly shipments from Denmark and emergency air freight. This role requires specialized expertise in Arctic shipping, customs clearance, and real-time tracking—skills that are best sourced externally. An independent contractor allows flexibility, access to niche expertise, and avoids long-term commitments, fitting the project’s pragmatic, low-risk approach.

**Explanation**:
Manages logistics and procurement of materials, ensuring timely delivery and cost efficiency.

**Consequences**:
Absence of this role could result in supply shortages, delays in material availability, and increased costs.

**People Count**:
1

**Typical Activities**:
Mikkel's typical activities involve managing the procurement of clay and equipment, coordinating quarterly shipments, tracking inventory levels, and establishing emergency air freight contracts. He also collaborates with local artisans to explore alternative material sourcing and ensures compliance with customs regulations.

**Background Story**:
Mikkel Sørensen, a 29-year-old supply chain coordinator based in Nuuk, has a background in logistics and procurement from the Technical University of Denmark. With five years of experience in managing supply chains for remote locations, Mikkel has developed strong relationships with suppliers in Denmark and Iceland. His expertise in navigating customs and shipping logistics is crucial for the timely delivery of materials to the workshop. Mikkel's familiarity with the unique challenges of Arctic logistics makes him an essential team member for ensuring the workshop's operational continuity.

**Equipment Needs**:
Real-time logistics tracking dashboard (API-integrated), mobile devices with GPS and data connectivity, emergency air freight contract portal, customs clearance documentation system

**Facility Needs**:
Dedicated logistics coordination station with secure access to shipping alerts from Danish Maritime Authority, reliable internet connection, and a climate-controlled storage area for buffer stock

## 3. Facility Manager

**Contract Type**: `part_time_employee`

**Contract Type Justification**: The Facility Manager is responsible for the maintenance, operation, and compliance of the physical workshop space, including safety systems, utilities, and environmental controls. This role demands ongoing presence and deep familiarity with the site’s unique conditions (e.g., thermal management, winter energy demand). A part-time employee ensures consistent oversight and accountability while remaining within budget constraints and supporting the rotating staff model.

**Explanation**:
Responsible for the maintenance and operation of the workshop space, including safety and compliance.

**Consequences**:
Lack of facility management could lead to safety hazards, regulatory non-compliance, and operational inefficiencies.

**People Count**:
1

**Typical Activities**:
Sofia's typical activities include overseeing the maintenance of the workshop facilities, ensuring compliance with safety regulations, managing heating and energy systems, and coordinating with contractors for any necessary repairs or upgrades. She also conducts regular safety audits and implements training programs for staff.

**Background Story**:
Sofia Nilsen, a 40-year-old facility manager from Nuuk, holds a degree in Environmental Engineering from the University of Greenland. With over 15 years of experience in facility management, Sofia has worked on various projects focused on energy efficiency and safety compliance in harsh climates. Her skills in maintaining operational systems and ensuring regulatory compliance are vital for the workshop's success. Sofia's familiarity with the local environment and building codes makes her a key player in creating a safe and efficient workspace.

**Equipment Needs**:
IoT environmental sensors (temperature, humidity, CO₂), thermal monitoring software, HVAC control systems, safety inspection checklists, maintenance scheduling tools

**Facility Needs**:
On-site facility operations hub with direct access to kiln, drying, and work zones; climate-controlled environment for equipment calibration; access to utility panels and emergency shutoffs

## 4. Instructor Team Lead

**Contract Type**: `part_time_employee`

**Contract Type Justification**: The Instructor Team Lead coordinates schedules, ensures teaching quality, and leads cross-training among the four part-time instructors. This role is critical for maintaining session continuity and operational resilience. A part-time employee structure supports the project’s core staffing model—flexible yet reliable—while enabling leadership without overburdening the team or exceeding budget limits.

**Explanation**:
Leads the teaching staff, coordinates schedules, and ensures quality of instruction.

**Consequences**:
Without a lead instructor, there may be inconsistencies in teaching quality and scheduling conflicts.

**People Count**:
1

**Typical Activities**:
Lars's typical activities include leading the teaching staff, coordinating schedules, ensuring quality of instruction, and facilitating cross-training among instructors. He also develops course content, engages with students to enhance their learning experience, and organizes community exhibitions to showcase student work.

**Background Story**:
Lars Thomsen, a 32-year-old instructor team lead from Nuuk, has a background in Fine Arts from the Royal Danish Academy of Fine Arts. With over eight years of teaching experience in ceramics and community arts, Lars is passionate about fostering creativity and cultural expression. His leadership skills and ability to mentor other instructors make him an invaluable asset to the teaching team. Lars is well-versed in both hand-building and wheel-throwing techniques, ensuring high-quality instruction for workshop participants.

**Equipment Needs**:
Digital shift calendar platform (e.g., Google Calendar with automated alerts), cross-training curriculum materials, course content development software, digital feedback collection tools

**Facility Needs**:
Meeting room or flexible workspace for instructor coordination, whiteboard and presentation tools, access to training materials and demonstration stations

## 5. Marketing and Community Engagement Specialist

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Marketing and Community Engagement Specialist develops outreach strategies, manages partnerships with tourism boards and hotels, and fosters community involvement. This role is highly project-specific and outcome-driven, with seasonal peaks in summer and winter campaigns. Engaging an independent contractor allows access to specialized marketing skills and campaign execution without long-term employment obligations, aligning with the project’s flexible, low-risk model.

**Explanation**:
Develops outreach strategies to attract locals and tourists, fostering community involvement.

**Consequences**:
Failure to engage the community could result in low participation rates and diminished workshop visibility.

**People Count**:
1

**Typical Activities**:
Emma's typical activities include developing marketing campaigns, managing social media accounts, fostering partnerships with local tourism boards and hotels, and organizing community events to promote the workshop. She also collects feedback from participants to continuously improve outreach strategies.

**Background Story**:
Emma Kristensen, a 28-year-old marketing and community engagement specialist from Nuuk, has a degree in Marketing from the University of Greenland. With experience in promoting local cultural initiatives, Emma has a knack for creating outreach strategies that resonate with both locals and tourists. Her skills in social media marketing and community engagement are essential for building the workshop's visibility and participation. Emma's understanding of the local culture and tourism dynamics makes her a key player in attracting diverse audiences to the workshop.

**Equipment Needs**:
Social media management tools (e.g., Hootsuite, Canva), marketing campaign analytics dashboard, multilingual content creation software, partnership liaison platforms (email, video conferencing)

**Facility Needs**:
Creative studio space for event planning, access to public display areas for promotional materials, high-speed internet for live streaming and digital outreach

## 6. Safety Officer

**Contract Type**: `part_time_employee`

**Contract Type Justification**: The Safety Officer performs essential duties such as conducting training, enforcing protocols, and leading monthly drills. This role requires regular on-site presence and integration with the instructor team. A part-time employee ensures consistent safety oversight and compliance with Arctic health and safety standards, while maintaining alignment with the rotating instructor schedule and overall staffing strategy.

**Explanation**:
Ensures compliance with safety regulations and oversees training for all staff and participants.

**Consequences**:
Absence of a safety officer could lead to accidents, legal liabilities, and increased insurance costs.

**People Count**:
1

**Typical Activities**:
Jonas's typical activities include conducting safety training for staff and participants, enforcing safety protocols, leading monthly safety drills, and performing regular safety audits of the workshop facilities. He also collaborates with the facility manager to ensure compliance with health and safety regulations.

**Background Story**:
Jonas Madsen, a 35-year-old safety officer from Nuuk, has a background in Occupational Health and Safety from the University of Greenland. With over ten years of experience in safety management, Jonas has worked in various community projects, ensuring compliance with safety regulations and training protocols. His expertise in risk assessment and emergency response is crucial for maintaining a safe environment in the workshop. Jonas's familiarity with local safety standards makes him an essential member of the team.

**Equipment Needs**:
Safety training modules (digital and physical), emergency response kits, fire extinguisher inspection logs, monthly drill scheduling tools, incident reporting software

**Facility Needs**:
Designated safety command center with access to all emergency exits and equipment, visible signage in both Danish and Greenlandic, and a quiet zone for post-drill debriefs

## 7. Cultural Liaison

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Cultural Liaison facilitates partnerships with elders, artists, and Katuaq Cultural Centre, ensuring authentic representation and community consent. This role involves sensitive, high-level coordination that benefits from external neutrality and specialized cultural knowledge. An independent contractor provides access to trusted local networks and ethical frameworks without creating permanent internal roles, supporting the project’s emphasis on authenticity and trust-building.

**Explanation**:
Facilitates partnerships with local artists and cultural organizations to integrate community traditions.

**Consequences**:
Without a cultural liaison, the workshop may fail to authentically represent local heritage, leading to community disconnection.

**People Count**:
1

**Typical Activities**:
Nina's typical activities include facilitating partnerships with local artists and cultural organizations, coordinating community co-creation events, ensuring community consent for traditional motifs, and integrating local narratives into workshop programming. She also organizes exhibitions to showcase local artistry.

**Background Story**:
Nina Pedersen, a 30-year-old cultural liaison from Nuuk, holds a degree in Cultural Studies from the University of Greenland. With a strong background in community engagement and cultural heritage, Nina has worked with various local artists and organizations to promote cultural initiatives. Her role as a cultural liaison is vital for ensuring that the workshop authentically represents local traditions and engages the community. Nina's connections with local artists and elders make her a key player in fostering cultural collaboration.

**Equipment Needs**:
Cultural consent documentation system (digital forms), community engagement platform (e.g., online forums), storytelling recording equipment, exhibition design software

**Facility Needs**:
Cultural collaboration space with seating for elders and artists, private meeting room for advisory council sessions, display wall for co-created artwork prototypes

## 8. Financial Analyst

**Contract Type**: `part_time_employee`

**Contract Type Justification**: The Financial Analyst monitors the 2 million DKK budget, forecasts expenses, and ensures financial sustainability. This role requires ongoing attention to currency volatility, hedging strategies, and contingency fund management. A part-time employee ensures continuous financial oversight while staying within the project’s cost constraints and supporting the low-risk, scalable model.

**Explanation**:
Monitors budget, forecasts expenses, and ensures financial sustainability of the workshop.

**Consequences**:
Lack of financial oversight could result in budget overruns and jeopardize the workshop's viability.

**People Count**:
1

**Typical Activities**:
Frederik's typical activities include monitoring the workshop's budget, forecasting expenses, ensuring financial sustainability, and managing currency volatility risks. He also prepares financial reports and collaborates with the project manager to align financial strategies with operational goals.

**Background Story**:
Frederik Olsen, a 38-year-old financial analyst from Nuuk, has a degree in Finance from the University of Greenland. With over 12 years of experience in financial management, Frederik has worked on various community projects, ensuring financial sustainability and budget compliance. His expertise in forecasting and expense monitoring is crucial for the workshop's financial health. Frederik's understanding of local economic conditions makes him an essential member of the team.

**Equipment Needs**:
Financial forecasting software (e.g., Excel with advanced modeling), currency hedging tools, budget tracking dashboard, audit preparation system

**Facility Needs**:
Secure financial workspace with locked filing cabinets, access to accounting records, and a private area for financial review meetings

---

# Omissions

## 1. Lack of Formal Emergency Response Protocol

The project plan does not include a structured emergency response protocol for incidents such as fire, equipment failure, or severe weather disruptions. Without predefined procedures and roles, the team may struggle to respond effectively during crises, risking safety, operational continuity, and reputational damage.

**Recommendation**:
Develop and document a comprehensive emergency response protocol that includes evacuation routes, communication plans (e.g., SMS alerts), designated emergency contacts, and clear role assignments (e.g., Safety Officer leads response). Conduct at least one full-scale emergency drill before public opening.

## 2. Insufficient Digital Infrastructure for Remote Coordination

While digital tools are used for scheduling and marketing, there is no centralized digital platform for real-time collaboration among remote team members (e.g., independent contractors in Denmark or Iceland). This creates a risk of miscommunication, delayed decision-making, and reduced accountability across geographically dispersed roles.

**Recommendation**:
Implement a secure, cloud-based project hub (e.g., Notion or Microsoft Teams) with shared dashboards for timelines, budgets, safety logs, and cultural consent records. Ensure all team members have access and training, especially for those working remotely.

---

# Potential Improvements

## 1. Clarify Role Overlaps Between Instructor Team Lead and Safety Officer

Both the Instructor Team Lead and Safety Officer have overlapping responsibilities in training and supervision, which could lead to confusion or duplication of effort. Clear delineation of duties is essential to maintain efficiency and avoid burnout.

**Recommendation**:
Create a RACI matrix (Responsible, Accountable, Consulted, Informed) for key tasks such as safety training, shift coordination, and incident reporting. Define that the Safety Officer owns training delivery and compliance, while the Instructor Team Lead oversees instructional quality and schedule alignment.

## 2. Underutilized Potential of IoT Data for Community Engagement

The project plans to deploy IoT sensors for environmental monitoring but does not leverage this data for public engagement. Real-time temperature and humidity data could be used to educate visitors about the science of clay drying and energy use, enhancing the workshop’s educational and cultural value.

**Recommendation**:
Transform sensor data into an interactive public display (e.g., a digital wall near the entrance) showing live conditions and sustainability metrics (e.g., 'Today’s kiln saved 15 kWh'). Use this to tell stories about Arctic resilience and material transformation, deepening visitor connection.