This plan implies one or more physical locations.

## Requirements for physical locations

- Near Katuaq Cultural Centre and Nuuk Center for visibility and cultural alignment
- Proximity to transportation hubs and pedestrian foot traffic
- Space for kilns, worktables, drying zones, storage, and open-studio areas
- Heating and insulation suitable for Greenland’s harsh climate
- Access to utilities (electricity, water, waste) with reliable supply
- Ability to accommodate seasonal demand fluctuations (summer and winter peaks)
- Zoning approval for commercial arts use and public access

## Location 1
Greenland

Nuuk, Central District

Katuaq Cultural Centre Complex, 20-24 Kalaallit Nunaat Street, Nuuk, Greenland

**Rationale**: The proposed workshop is explicitly located near Katuaq Cultural Centre and Nuuk Center, which are central to the city's cultural and social life. This location ensures high visibility, foot traffic, and strong cultural alignment. The area is already zoned for public and cultural institutions, simplifying permitting. Proximity to existing infrastructure (utilities, transport) reduces setup complexity and cost. The site supports year-round operation with access to heating and community engagement.

## Location 2
Greenland

Nuuk, Old Town (Qaanaaq Quarter)

Former Fish Processing Building, 15-17 Qaanaaq Street, Nuuk, Greenland

**Rationale**: This historic industrial building in the heart of Nuuk’s Old Town offers a large, adaptable space ideal for a clay workshop. It is within walking distance of Katuaq and Nuuk Center, ensuring visibility and accessibility. The structure can be retrofitted with passive solar design and thermal insulation to meet energy efficiency needs. Its existing utility connections reduce installation costs. Repurposing a former industrial site aligns with sustainable reuse principles and supports local heritage preservation.

## Location 3
Greenland

Nuuk, Northern Harbor Area

Nuuk Harbour Office Building, 8-10 Havnvejen, Nuuk, Greenland

**Rationale**: Located near the harbor and main transit routes, this site offers excellent accessibility for both locals and tourists. The building is part of a mixed-use development with existing electrical and water infrastructure, reducing fit-out costs. Its proximity to the sea allows for potential future integration with maritime-themed art projects. The northern orientation enables optimal passive solar gain through south-facing windows, supporting the Energy-Efficient Facility Design strategy. It also provides space for seasonal outdoor installations during summer months.

## Location Summary
The plan requires a physical location in Nuuk, Greenland, near Katuaq Cultural Centre and Nuuk Center to ensure visibility, cultural alignment, and accessibility. The three suggested sites—Katuaq Cultural Centre Complex, Old Town Fish Processing Building, and Northern Harbor Office Building—are all viable options that meet core requirements: proximity to key landmarks, access to utilities, adaptability for studio and drying spaces, and support for year-round operation in Greenland’s extreme climate. Each site balances operational feasibility, logistical practicality, and strategic positioning to serve both local residents and seasonal tourists, aligning with the low-risk, resilient model outlined in the Pragmatic Foundation scenario.