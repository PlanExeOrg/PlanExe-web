
## Risk 1 - Regulatory & Permitting
Obtaining zoning approval and permits for a commercial arts space near Katuaq Cultural Centre may face delays due to local regulations, environmental assessments, or community consultation requirements. The workshop’s use of kilns and heating systems could trigger additional scrutiny from municipal authorities regarding emissions, fire safety, and noise.

**Impact:** A delay of 4–8 weeks in opening, potentially pushing the start date beyond the planned Year 1 launch window. This could result in an extra cost of 200,000–350,000 DKK in lost revenue opportunities and extended rental holdover fees.

**Likelihood:** Medium

**Severity:** High

**Action:** Engage with Nuuk Municipality early in the planning phase to pre-qualify permit requirements. Hire a local regulatory consultant familiar with Greenlandic building codes and cultural institution zoning. Submit all documentation in both Danish and Greenlandic to avoid language-related delays.

## Risk 2 - Supply Chain & Logistics
Long lead times (6–12 weeks) for shipping clay and equipment from Denmark/Iceland may result in material shortages during peak demand periods, especially if quarterly shipments are delayed by Arctic weather, port congestion, or customs clearance issues.

**Impact:** Session cancellations or reduced course capacity due to lack of clay; potential loss of tourist bookings. Estimated cost: 150,000–250,000 DKK in missed revenue and reputational damage. A 2–4 week delay in program delivery is possible.

**Likelihood:** High

**Severity:** High

**Action:** Secure a fixed quarterly import schedule with a single trusted Danish supplier using consolidated container shipments. Include a 10% buffer in initial material orders. Establish a real-time tracking system for shipments and designate a local logistics coordinator to monitor customs status and coordinate emergency air freight options if needed.

## Risk 3 - Energy & Facility Operations
Inadequate thermal regulation in the facility could lead to inconsistent drying conditions for clay, causing warping, cracking, or failed firings—especially during winter months when outdoor temperatures drop below -20°C. Poor insulation or inefficient heating systems may also increase utility costs beyond budget.

**Impact:** Up to 30% of student projects may be damaged or unusable due to poor drying control. Extra energy costs could exceed budget by 10–15%, adding 100,000–150,000 DKK in unplanned expenses. Potential safety hazards from overheating kilns or inadequate ventilation.

**Likelihood:** Medium

**Severity:** High

**Action:** Implement passive solar design with south-facing glazing and thermal mass walls. Install temperature and humidity monitoring sensors throughout drying zones. Use modular kilns that only operate during scheduled sessions. Conduct a pre-opening thermal audit with a certified energy engineer to validate insulation performance.

## Risk 4 - Staffing & Human Resources
Despite the rotating instructor schedule, unexpected absences (e.g., illness, personal emergencies) among part-time staff could disrupt course delivery, especially if no backup instructor is available on short notice. Instructors without cross-training may not be able to cover unfamiliar skill levels.

**Impact:** Cancellation of up to two weekly sessions per month, leading to a 15–20% drop in attendance and member retention. Reputational risk and potential refund requests. Estimated cost: 75,000–120,000 DKK in lost membership fees and rebooking efforts.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Enforce mandatory cross-training for all four instructors in core techniques (hand-building, wheel-throwing, glazing). Develop a digital shift calendar accessible via mobile app. Maintain a small pool of vetted volunteer substitutes (retired potters) with formal liability insurance and training records.

## Risk 5 - Financial Management
Unplanned fluctuations in exchange rates between DKK and USD could impact the cost of international shipments, even with USD-denominated contracts. If the DKK weakens significantly against USD, the effective cost of imported materials may rise unexpectedly.

**Impact:** An additional 10–15% increase in material costs, amounting to 200,000–300,000 DKK over the year. This could jeopardize the 2 million DKK budget if not managed proactively.

**Likelihood:** Low

**Severity:** High

**Action:** Use forward contracts or currency hedging instruments for at least 60% of annual import spend. Set a monthly financial review process to track exchange rate trends and adjust procurement timelines accordingly. Maintain a contingency fund of 100,000 DKK within the budget for currency volatility.

## Risk 6 - Cultural & Community Engagement
If cultural collaboration with Katuaq or local artisans is perceived as tokenistic or lacks genuine community input, it may lead to backlash, reduced participation from locals, or reputational harm—particularly if traditional designs are misused or intellectual property rights are not respected.

**Impact:** Lower local engagement (up to 40% reduction in resident participation), negative media coverage, and strained relationships with key cultural partners. Long-term brand damage affecting sustainability.

**Likelihood:** Medium

**Severity:** High

**Action:** Establish a formal advisory council including elders, artists, and community leaders from Katuaq. Co-design exhibitions and curriculum elements through participatory workshops. Secure written consent and benefit-sharing agreements before using any traditional motifs or stories in programming.

## Risk summary
The most critical risks are Supply Chain & Logistics and Energy & Facility Operations, both of which have high likelihood and high severity. These directly threaten Year 1 viability by risking session cancellations and operational failure. The second-tier risk is Regulatory & Permitting, which could delay launch and incur significant costs. While Staffing and Financial risks are more manageable, they require proactive mitigation to maintain trust and budget integrity. The Cultural & Community Engagement risk, though lower in probability, carries high reputational stakes and must be addressed through authentic co-creation. Overall, success hinges on executing the Pragmatic Foundation scenario with strict adherence to supply chain predictability, energy efficiency, and community partnership protocols.