# Purpose

**Purpose:** business

**Purpose Detailed:** Establishing a sustainable, low-risk community-based arts initiative that serves as a social 'third place' for locals and tourists in Nuuk. The workshop focuses on accessible hand-building and wheel-throwing courses, with structured open-studio hours and recurring short-term classes. It addresses local cultural engagement, tourism integration, and creative wellness while accounting for Greenland-specific logistical challenges such as high import costs, seasonal demand fluctuations, and long supply lead times. The operational model prioritizes resilience through part-time staffing (four instructors), flexible pricing (memberships and drop-ins), and strategic location near Katuaq Cultural Centre and Nuuk Center to maximize visibility and foot traffic.

**Topic:** Community Clay Workshop in Nuuk, Greenland

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** The plan involves establishing a physical community clay workshop in Nuuk, Greenland, which requires a dedicated physical space near Katuaq Cultural Centre and Nuuk Center. This includes leasing or securing a building, fitting it out with kilns, worktables, storage, heating systems for clay drying, and installing utilities—each of which is inherently physical. The operation depends on acquiring and transporting clay and equipment from Denmark/Iceland, which involves shipping logistics and customs clearance. Staffing four part-time instructors requires hiring, scheduling, and coordination in person. The workshop offers in-person sessions (hand-building, wheel-throwing), open-studio hours, and courses that require physical presence to participate. Seasonal demand peaks in summer and winter necessitate on-site operational planning and staffing adjustments. All aspects—from setup and supply chain management to teaching and user engagement—are grounded in real-world, physical activities. Even though some administrative tasks (e.g., marketing, scheduling) could be digital, the core function of the project is entirely dependent on a physical location and infrastructure. Therefore, this is a 'physical' plan.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Near Katuaq Cultural Centre and Nuuk Center for visibility and cultural alignment
- Proximity to transportation hubs and pedestrian foot traffic
- Space for kilns, worktables, drying zones, storage, and open-studio areas
- Heating and insulation suitable for Greenland’s harsh climate
- Access to utilities (electricity, water, waste) with reliable supply
- Ability to accommodate seasonal demand fluctuations (summer and winter peaks)
- Zoning approval for commercial arts use and public access

## Location 1
Greenland

Nuuk, Central District

Katuaq Cultural Centre Complex, 20-24 Kalaallit Nunaat Street, Nuuk, Greenland

**Rationale**: The proposed workshop is explicitly located near Katuaq Cultural Centre and Nuuk Center, which are central to the city's cultural and social life. This location ensures high visibility, foot traffic, and strong cultural alignment. The area is already zoned for public and cultural institutions, simplifying permitting. Proximity to existing infrastructure (utilities, transport) reduces setup complexity and cost. The site supports year-round operation with access to heating and community engagement.

## Location 2
Greenland

Nuuk, Old Town (Qaanaaq Quarter)

Former Fish Processing Building, 15-17 Qaanaaq Street, Nuuk, Greenland

**Rationale**: This historic industrial building in the heart of Nuuk’s Old Town offers a large, adaptable space ideal for a clay workshop. It is within walking distance of Katuaq and Nuuk Center, ensuring visibility and accessibility. The structure can be retrofitted with passive solar design and thermal insulation to meet energy efficiency needs. Its existing utility connections reduce installation costs. Repurposing a former industrial site aligns with sustainable reuse principles and supports local heritage preservation.

## Location 3
Greenland

Nuuk, Northern Harbor Area

Nuuk Harbour Office Building, 8-10 Havnvejen, Nuuk, Greenland

**Rationale**: Located near the harbor and main transit routes, this site offers excellent accessibility for both locals and tourists. The building is part of a mixed-use development with existing electrical and water infrastructure, reducing fit-out costs. Its proximity to the sea allows for potential future integration with maritime-themed art projects. The northern orientation enables optimal passive solar gain through south-facing windows, supporting the Energy-Efficient Facility Design strategy. It also provides space for seasonal outdoor installations during summer months.

## Location Summary
The plan requires a physical location in Nuuk, Greenland, near Katuaq Cultural Centre and Nuuk Center to ensure visibility, cultural alignment, and accessibility. The three suggested sites—Katuaq Cultural Centre Complex, Old Town Fish Processing Building, and Northern Harbor Office Building—are all viable options that meet core requirements: proximity to key landmarks, access to utilities, adaptability for studio and drying spaces, and support for year-round operation in Greenland’s extreme climate. Each site balances operational feasibility, logistical practicality, and strategic positioning to serve both local residents and seasonal tourists, aligning with the low-risk, resilient model outlined in the Pragmatic Foundation scenario.

# Currency Strategy

This plan involves money.

## Currencies

- **DKK:** The primary local currency in Greenland, used for all operational expenses including rent, utilities, staff salaries, and equipment procurement. The budget is specified in DKK, making it the most relevant currency for financial planning and reporting.
- **USD:** Included due to the reliance on imported materials from Denmark and Iceland, where transactions may be conducted in USD or EUR. Using USD provides a stable benchmark for international shipping costs and supplier contracts, mitigating risks from DKK exchange rate fluctuations and inflationary pressures in Greenland's isolated economy.

**Primary currency:** DKK

**Currency strategy:** All internal budgeting, staffing, and local procurement will be managed in DKK. For international suppliers and shipping partners, contracts will be denominated in USD to hedge against exchange volatility and ensure cost predictability. This dual-currency approach supports financial stability while aligning with Greenland’s economic reality and supply chain dependencies.

# Identify Risks


## Risk 1 - Regulatory & Permitting
Obtaining zoning approval and permits for a commercial arts space near Katuaq Cultural Centre may face delays due to local regulations, environmental assessments, or community consultation requirements. The workshop’s use of kilns and heating systems could trigger additional scrutiny from municipal authorities regarding emissions, fire safety, and noise.

**Impact:** A delay of 4–8 weeks in opening, potentially pushing the start date beyond the planned Year 1 launch window. This could result in an extra cost of 200,000–350,000 DKK in lost revenue opportunities and extended rental holdover fees.

**Likelihood:** Medium

**Severity:** High

**Action:** Engage with Nuuk Municipality early in the planning phase to pre-qualify permit requirements. Hire a local regulatory consultant familiar with Greenlandic building codes and cultural institution zoning. Submit all documentation in both Danish and Greenlandic to avoid language-related delays.

## Risk 2 - Supply Chain & Logistics
Long lead times (6–12 weeks) for shipping clay and equipment from Denmark/Iceland may result in material shortages during peak demand periods, especially if quarterly shipments are delayed by Arctic weather, port congestion, or customs clearance issues.

**Impact:** Session cancellations or reduced course capacity due to lack of clay; potential loss of tourist bookings. Estimated cost: 150,000–250,000 DKK in missed revenue and reputational damage. A 2–4 week delay in program delivery is possible.

**Likelihood:** High

**Severity:** High

**Action:** Secure a fixed quarterly import schedule with a single trusted Danish supplier using consolidated container shipments. Include a 10% buffer in initial material orders. Establish a real-time tracking system for shipments and designate a local logistics coordinator to monitor customs status and coordinate emergency air freight options if needed.

## Risk 3 - Energy & Facility Operations
Inadequate thermal regulation in the facility could lead to inconsistent drying conditions for clay, causing warping, cracking, or failed firings—especially during winter months when outdoor temperatures drop below -20°C. Poor insulation or inefficient heating systems may also increase utility costs beyond budget.

**Impact:** Up to 30% of student projects may be damaged or unusable due to poor drying control. Extra energy costs could exceed budget by 10–15%, adding 100,000–150,000 DKK in unplanned expenses. Potential safety hazards from overheating kilns or inadequate ventilation.

**Likelihood:** Medium

**Severity:** High

**Action:** Implement passive solar design with south-facing glazing and thermal mass walls. Install temperature and humidity monitoring sensors throughout drying zones. Use modular kilns that only operate during scheduled sessions. Conduct a pre-opening thermal audit with a certified energy engineer to validate insulation performance.

## Risk 4 - Staffing & Human Resources
Despite the rotating instructor schedule, unexpected absences (e.g., illness, personal emergencies) among part-time staff could disrupt course delivery, especially if no backup instructor is available on short notice. Instructors without cross-training may not be able to cover unfamiliar skill levels.

**Impact:** Cancellation of up to two weekly sessions per month, leading to a 15–20% drop in attendance and member retention. Reputational risk and potential refund requests. Estimated cost: 75,000–120,000 DKK in lost membership fees and rebooking efforts.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Enforce mandatory cross-training for all four instructors in core techniques (hand-building, wheel-throwing, glazing). Develop a digital shift calendar accessible via mobile app. Maintain a small pool of vetted volunteer substitutes (retired potters) with formal liability insurance and training records.

## Risk 5 - Financial Management
Unplanned fluctuations in exchange rates between DKK and USD could impact the cost of international shipments, even with USD-denominated contracts. If the DKK weakens significantly against USD, the effective cost of imported materials may rise unexpectedly.

**Impact:** An additional 10–15% increase in material costs, amounting to 200,000–300,000 DKK over the year. This could jeopardize the 2 million DKK budget if not managed proactively.

**Likelihood:** Low

**Severity:** High

**Action:** Use forward contracts or currency hedging instruments for at least 60% of annual import spend. Set a monthly financial review process to track exchange rate trends and adjust procurement timelines accordingly. Maintain a contingency fund of 100,000 DKK within the budget for currency volatility.

## Risk 6 - Cultural & Community Engagement
If cultural collaboration with Katuaq or local artisans is perceived as tokenistic or lacks genuine community input, it may lead to backlash, reduced participation from locals, or reputational harm—particularly if traditional designs are misused or intellectual property rights are not respected.

**Impact:** Lower local engagement (up to 40% reduction in resident participation), negative media coverage, and strained relationships with key cultural partners. Long-term brand damage affecting sustainability.

**Likelihood:** Medium

**Severity:** High

**Action:** Establish a formal advisory council including elders, artists, and community leaders from Katuaq. Co-design exhibitions and curriculum elements through participatory workshops. Secure written consent and benefit-sharing agreements before using any traditional motifs or stories in programming.

## Risk summary
The most critical risks are Supply Chain & Logistics and Energy & Facility Operations, both of which have high likelihood and high severity. These directly threaten Year 1 viability by risking session cancellations and operational failure. The second-tier risk is Regulatory & Permitting, which could delay launch and incur significant costs. While Staffing and Financial risks are more manageable, they require proactive mitigation to maintain trust and budget integrity. The Cultural & Community Engagement risk, though lower in probability, carries high reputational stakes and must be addressed through authentic co-creation. Overall, success hinges on executing the Pragmatic Foundation scenario with strict adherence to supply chain predictability, energy efficiency, and community partnership protocols.

# Make Assumptions


## Question 1 - What is the exact size and layout of the physical space required for the clay workshop, including kiln zones, worktables, drying areas, storage, and open-studio seating?

**Assumptions:** Assumption: The workshop will occupy a 120–150 m² space with a modular layout allowing flexible reconfiguration. Kiln zone requires 15 m² with dedicated ventilation and fire safety measures; drying area needs 30 m² with climate control; worktables require 40 m²; storage and admin take up 20 m²; open-studio seating accommodates 12–16 people.

**Assessments:** Title: Operational Systems Assessment
Description: Evaluation of spatial efficiency and workflow integration.
Details: A well-designed layout ensures smooth material flow from entry to firing, reduces congestion during peak hours, and supports both drop-in sessions and structured courses. Using a modular design allows seasonal adjustments—e.g., expanding drying zones in winter or adding temporary tables in summer. Compliance with fire safety codes and thermal zoning is critical. Failure to allocate sufficient drying space may lead to project damage due to inconsistent humidity, increasing waste by up to 30%. Budgeting must include insulation, HVAC controls, and non-slip flooring. This directly impacts the Energy-Efficient Facility Design and Safety & Risk Management levers.

## Question 2 - How will the four part-time instructors be scheduled across weekly sessions to ensure 100% coverage while maintaining work-life balance and avoiding burnout?

**Assumptions:** Assumption: Instructors will follow a rotating 4-week schedule with staggered shifts (e.g., two instructors per week), each teaching 8–10 hours weekly. Cross-training ensures all can cover any skill level. A digital shift calendar with real-time updates will be used for coordination.

**Assessments:** Title: Resources & Personnel Assessment
Description: Analysis of staffing structure and sustainability.
Details: A rotating schedule prevents over-reliance on any single instructor and aligns with the Instructor Resilience Network. With only four part-timers, workload distribution is crucial—exceeding 10 hours/week risks burnout and turnover. Cross-training reduces dependency on specific individuals and enables last-minute coverage. Digital scheduling improves transparency and accountability. However, if not managed carefully, overlapping shifts could create inefficiencies or gaps. Ensuring fair rotation and providing rest periods supports long-term retention. This directly affects operational continuity and staff morale, key to Year 1 success.

## Question 3 - What is the detailed breakdown of the 2 million DKK budget across startup costs, equipment, rent, utilities, salaries, supplies, and marketing?

**Assumptions:** Assumption: The budget allocates 40% to fit-out and equipment (kilns, tables, tools), 25% to rent and utilities (first year), 20% to instructor salaries (4 × 15,000 DKK/month), 10% to materials and supplies, and 5% to marketing and community outreach. A 100,000 DKK contingency fund is included for currency volatility and unforeseen expenses.

**Assessments:** Title: Funding & Budget Assessment
Description: Financial feasibility and risk exposure analysis.
Details: The 2 million DKK budget is realistic but tight. Equipment and fit-out represent the largest cost—especially kilns and insulation—requiring bulk procurement to reduce per-unit costs. Salaries are within market rates for part-time arts educators in Greenland. Marketing spend must be targeted: social media ads, hotel partnerships, and Katuaq co-promotions. Currency hedging is essential given USD-denominated imports. Without a contingency fund, exchange rate swings could exceed budget by 15%. This assessment confirms financial viability only if supply chain and energy strategies are executed precisely.

## Question 4 - What are the specific milestones and timeline for securing the location, completing fit-out, hiring staff, and launching the first course?

**Assumptions:** Assumption: The project starts immediately on 2026-Feb-15. Key milestones: Lease signed by Apr-30 (60 days), fit-out completed by Jul-31 (150 days), staff hired by May-15 (60 days), first course begins Aug-1 (100 days). A 3-week soft launch for locals precedes full public opening.

**Assessments:** Title: Timeline & Milestones Assessment
Description: Project execution plan and risk of delay.
Details: The 150-day timeline is aggressive but feasible if regulatory approvals are secured early. Delays in permitting (Risk 1) could push opening to October, missing summer tourism peaks. Fit-out includes electrical upgrades, kiln installation, and passive solar modifications—each requiring specialist contractors. Staff hiring must include background checks and cross-training. A soft launch allows feedback and system testing. Missing the August launch window would reduce tourist engagement by 40% and jeopardize Year 1 revenue targets. This timeline is critical to Seasonal Demand Buffering and Cultural Anchoring goals.

## Question 5 - How will the workshop comply with Greenlandic regulations regarding cultural heritage, environmental impact, and commercial use of traditional designs?

**Assumptions:** Assumption: The workshop will establish a formal advisory council with elders and local artists, obtain written consent before using traditional motifs, and adhere to Greenland’s Environmental Protection Act and building codes. All exhibitions and curriculum elements will undergo community review.

**Assessments:** Title: Governance & Regulations Assessment
Description: Legal and ethical compliance framework.
Details: Regulatory compliance is non-negotiable. Zoning approval for a commercial arts space near Katuaq requires proof of environmental safety (e.g., kiln emissions), fire safety, and noise control. Cultural collaboration must go beyond tokenism—using traditional forms without consent risks legal action and reputational damage. The advisory council ensures authenticity and protects intellectual property. Documentation must be bilingual (Danish/Greenlandic). Non-compliance could result in fines, closure, or loss of partnership with Katuaq. This directly supports the Cultural Anchoring Framework and mitigates Risk 6.

## Question 6 - What measures will be taken to manage safety risks related to kiln operation, clay dust, and heating systems in a cold climate?

**Assumptions:** Assumption: Safety protocols include mandatory training for all users, HEPA-filtered ventilation in kiln and drying zones, fire extinguishers at every station, emergency shutdown procedures, and regular inspections. Clay dust control will use wet-mix techniques and sealed storage.

**Assessments:** Title: Safety & Risk Management Assessment
Description: Hazard mitigation and incident prevention.
Details: Kiln fires and overheating are significant risks in cold climates where insulation may trap heat. Poor ventilation increases health risks from silica dust and fumes. Emergency procedures must be posted and practiced monthly. Inspections should occur quarterly. Training must be mandatory for all participants, especially tourists. A safety officer role (rotated among instructors) ensures accountability. Failure to implement these measures could lead to injuries, equipment damage, or insurance claims. This is critical for operational continuity and liability protection, directly supporting the Energy-Efficient Facility Design and Instructor Resilience Network.

## Question 7 - How will the workshop minimize its environmental footprint, particularly in terms of energy use, material sourcing, and waste management?

**Assumptions:** Assumption: The workshop will use passive solar design, modular kilns, and recycled packaging. Waste clay will be reclaimed and reused. Local partnerships will prioritize low-impact materials. A compostable packaging policy will be implemented for tourist kits.

**Assessments:** Title: Environmental Impact Assessment
Description: Sustainability performance and ecological responsibility.
Details: Reducing environmental impact enhances public perception and aligns with Greenland’s values. Passive solar design cuts heating needs by 40%, while modular kilns prevent idle energy use. Reclaiming waste clay reduces material demand by up to 25%. Using recycled packaging and biodegradable glazes lowers landfill burden. Partnering with local artisans supports circular economy principles. These actions strengthen the Cultural Anchoring Framework and Energy-Efficient Facility Design. Failure to manage waste could lead to fines or community backlash. This is essential for long-term brand credibility and alignment with Green initiatives.

## Question 8 - How will stakeholders—including locals, tourists, Katuaq Cultural Centre, and local artisans—be engaged throughout the planning and operational phases?

**Assumptions:** Assumption: Stakeholder involvement will include quarterly community forums, co-design workshops for exhibitions, youth apprenticeships with schools, and guest artist events. Feedback will be collected via digital surveys and in-person comment boards.

**Assessments:** Title: Stakeholder Involvement Assessment
Description: Community integration and trust-building strategy.
Details: Active stakeholder engagement fosters ownership and repeat participation. Locals feel represented when their stories and designs shape programming. Tourists gain deeper cultural context through interactive experiences. Katuaq becomes a true partner through joint exhibitions and event planning. Youth programs build intergenerational bridges. Regular feedback loops allow course adjustments and crisis response. Without this, the workshop risks being seen as an external imposition. This directly supports the Community Co-Creation Ecosystem and Cultural Anchoring Framework, enhancing long-term sustainability and social impact.

# Distill Assumptions

- Workshop occupies 120–150 m² with modular layout.
- Kiln zone requires 15 m² with ventilation and fire safety.
- Drying area needs 30 m² with climate control.
- Worktables require 40 m² for student use.
- Storage and admin take up 20 m².
- Open-studio seating accommodates 12–16 people.
- Instructors follow a rotating 4-week schedule.
- Each instructor teaches 8–10 hours weekly.
- Cross-training ensures all can cover any skill level.
- Digital shift calendar enables real-time coordination.
- Budget allocates 40% to fit-out and equipment.
- 25% covers rent and utilities for Year 1.
- 20% funds instructor salaries (4 × 15,000 DKK/month).
- 10% is for materials and supplies.
- 5% supports marketing and outreach.
- 100,000 DKK contingency fund for currency volatility.
- Project starts on 2026-Feb-15.
- Lease signed by Apr-30 (60 days).
- Fit-out completed by Jul-31 (150 days).
- Staff hired by May-15 (60 days).
- First course begins Aug-1 (100 days).
- Three-week soft launch precedes public opening.
- Formal advisory council includes elders and artists.
- Written consent obtained before using traditional motifs.
- All exhibitions undergo community review.
- Mandatory training for all users on safety protocols.
- HEPA-filtered ventilation in kiln and drying zones.
- Fire extinguishers at every station.
- Emergency shutdown procedures are posted and practiced.
- Clay dust controlled via wet-mix techniques and sealed storage.
- Passive solar design reduces heating needs by 40%.
- Modular kilns operate only during scheduled sessions.
- Waste clay is reclaimed and reused.
- Recycled packaging used for tourist kits.
- Compostable materials implemented for events.
- Quarterly community forums ensure stakeholder input.
- Co-design workshops shape exhibitions and courses.
- Youth apprenticeships partner with local schools.
- Guest artist events foster cultural exchange.
- Feedback collected via digital surveys and comment boards.

# Review Assumptions

## Domain of the expert reviewer
Community Arts & Sustainable Infrastructure Planning

## Domain-specific considerations

- Arctic logistics and supply chain fragility
- Cultural authenticity and Indigenous co-creation ethics
- Energy efficiency in extreme climates
- Part-time staffing sustainability in remote regions
- Regulatory compliance with Greenlandic and Danish frameworks

## Issue 1 - Missing Assumption: Contingency for Climate-Driven Shipping Disruptions
The plan assumes consistent quarterly shipments from Denmark but fails to account for Arctic weather disruptions (e.g., ice blockages, storm delays) that can halt maritime transport during winter. This is a critical oversight given Greenland’s vulnerability to climate volatility and the 6–12 week lead times cited. Without a backup strategy, material shortages could trigger session cancellations and reputational damage.

**Recommendation:** Establish a tiered emergency supply protocol: (1) Maintain a 4-week buffer stock of clay (10% of annual volume) on-site; (2) Pre-negotiate air freight contracts with Iceland Air or Nordic Cargo for urgent deliveries (max 72-hour transit); (3) Designate a local logistics coordinator to monitor real-time Arctic shipping alerts via the Danish Maritime Authority. Set a threshold: if shipment is delayed >14 days, activate air freight option.

**Sensitivity:** A 4-week delay in material delivery (baseline: 6 weeks) could increase project costs by 300,000–500,000 DKK due to missed sessions, rebooking, and emergency air freight. ROI could drop by 8–12% if summer tourism revenue is lost.

## Issue 2 - Missing Assumption: Formal Liability Coverage for Volunteer Instructors
The Instructor Resilience Network relies on retired artists as volunteers, but no assumption addresses insurance, legal liability, or training standards. In a high-risk environment involving kilns, heavy materials, and public access, untrained volunteers pose significant safety and legal risks. Failure to secure coverage could result in lawsuits or closure.

**Recommendation:** Require all volunteer instructors to sign a liability waiver and undergo mandatory 4-hour safety training (fire, dust, equipment use). Purchase a $500,000 general liability policy specifically covering volunteer-led activities. Include this cost in the 100,000 DKK contingency fund. Use a rotating 'Safety Officer' role among paid instructors to supervise volunteer shifts.

**Sensitivity:** Without liability coverage, a single injury incident could incur legal fees and settlements of 500,000–1,000,000 DKK. This would reduce ROI by 15–20% and jeopardize the entire Year 1 budget.

## Issue 3 - Under-Explored Assumption: Energy Demand During Peak Winter Usage
While passive solar design and modular kilns are assumed to reduce energy use, the plan does not model peak demand during winter open-studio hours when heating, drying, and firing overlap. With 12–16 people using the space simultaneously in sub-zero conditions, thermal load could exceed design capacity, leading to system failure or unsafe temperatures.

**Recommendation:** Conduct a dynamic thermal load simulation using software like EnergyPlus, modeling winter occupancy at 90% capacity. Adjust insulation levels and add a secondary low-power radiant heater in the drying zone. Implement a 'thermal curfew' during peak usage: limit kiln operation to 2-hour blocks with 30-minute cooldowns between sessions. Monitor temperature/humidity in real time via IoT sensors.

**Sensitivity:** If energy demand exceeds design capacity by 25%, utility costs could rise by 100,000–150,000 DKK above budget. A system failure could delay operations by 1–2 weeks, reducing ROI by 5–8% and increasing risk of project cancellation.

## Review conclusion
The project's success hinges on three critical gaps: unmitigated shipping risks, inadequate liability protection for volunteers, and underestimation of winter energy demand. Addressing these through concrete, quantifiable measures—emergency buffers, insurance protocols, and thermal modeling—is essential to maintain financial viability, operational continuity, and community trust. Without these safeguards, even a well-designed 'Pragmatic Foundation' scenario faces high risk of failure in Nuuk’s extreme context.