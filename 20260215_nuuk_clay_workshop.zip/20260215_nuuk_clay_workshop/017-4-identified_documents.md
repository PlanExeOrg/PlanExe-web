
## Documents to Create

### 1. Supply Chain Resilience Strategy Framework

**ID:** be177778-dfd5-465c-ab3c-1d50b554494b

**Description:** A high-level strategic document outlining the approach to securing reliable, cost-effective access to clay and equipment in Greenland. It defines the fixed biannual import schedule (April & September), integration of real-time Arctic shipping alerts via API from Danish Maritime Authority, emergency air freight contracts with Nordic Cargo, buffer stock management (50 kg), and risk mitigation protocols for ice blockages and storms. This framework ensures operational continuity and supports Year 1 viability under the Pragmatic Foundation scenario.

**Responsible Role Type:** Supply Chain Coordinator

**Primary Template:** PMI Project Charter Template

**Secondary Template:** World Bank Logical Framework

**Steps:**

- Conduct Arctic shipping risk assessment using DMA and Greenlandic port data (2018–2025)
- Finalize biannual import schedule aligned with Arctic navigation windows
- Negotiate and sign emergency air freight contracts with Nordic Cargo
- Define buffer stock levels and replenishment triggers
- Integrate real-time shipping alerts into logistics dashboard via API
- Obtain approval from Project Manager and Financial Analyst

**Approval Authorities:** Project Manager, Financial Analyst, Clay Workshop Manager

### 2. Winter Thermal Load Validation Report

**ID:** 8846d8f3-d494-411d-97d7-50b66a08f6c4

**Description:** A technical report documenting the results of a full-scale thermal stress test conducted in December 2025, simulating 90% winter occupancy (14 people) with kilns operating at 70% capacity. It includes temperature gradients, humidity levels, CO₂ buildup, and energy consumption data across zones. The report validates or adjusts the EnergyPlus model and recommends insulation upgrades or low-power radiant heaters if needed. Required for compliance with Greenlandic Health and Safety at Work Act.

**Responsible Role Type:** Facility Manager

**Primary Template:** ISO 14001 Environmental Management Report

**Secondary Template:** Arctic Building Compliance Audit Template

**Steps:**

- Schedule and conduct thermal stress test during December 2025 pre-opening period
- Deploy IoT sensors across drying, work, and kiln zones
- Collect and analyze real-time environmental data for 4 hours
- Compare findings against EnergyPlus simulation model
- Recommend and implement necessary upgrades (e.g., radiant heaters)
- Submit signed report to Project Manager and Safety Officer

**Approval Authorities:** Facility Manager, Safety Officer, Arctic-Building Specialist

### 3. Community Teaching Fellowship Program Structure

**ID:** d36ea977-413b-4bb9-9ae1-1cd6f7d1ad43

**Description:** A formalized program framework replacing the volunteer instructor pool. It defines three certification levels (Observer, Assistant, Lead Facilitator), a mandatory 12-hour training curriculum covering safety, cultural sensitivity, curriculum alignment, and emergency response, digital badges upon completion, liability waivers, $500,000 general liability insurance coverage, and a rotating 'Fellowship Coordinator' role. Ensures legal, ethical, and operational integration of community contributors.

**Responsible Role Type:** Cultural Liaison

**Primary Template:** Volunteer Management Framework (Greenlandic Ministry of Social Affairs)

**Secondary Template:** Indigenous Research Ethics Training Curriculum

**Steps:**

- Draft fellowship structure and certification levels
- Develop 12-hour training curriculum with safety and cultural modules
- Create digital badge system and onboarding checklist
- Secure $500,000 liability insurance policy
- Establish rotating Fellowship Coordinator role
- Obtain approval from Project Manager, Safety Officer, and Cultural Liaison

**Approval Authorities:** Project Manager, Safety Officer, Cultural Liaison, National Labour Inspectorate (Greenland)

### 4. Community Intellectual Property Rights (CIPR) Framework

**ID:** b819ae4e-aa54-4386-b6db-53bbd3526d51

**Description:** A legally binding agreement co-developed with the Inuit Cultural Heritage Council and local elders. It establishes a tiered access system for traditional stories and motifs, a cultural protocol document defining who may represent traditions, a requirement for elder committee pre-approval of all curriculum and exhibition content involving sacred narratives, and a process for handling public display and digital reproduction. Prevents cultural misrepresentation and ensures ethical collaboration.

**Responsible Role Type:** Cultural Liaison

**Primary Template:** Indigenous Data Sovereignty Agreement Template

**Secondary Template:** Inuit Research Ethics Guidelines (IIC, 2020)

**Steps:**

- Convene emergency consultation with ICHC and elders
- Draft CIPR framework including access tiers and approval processes
- Obtain written consent from elder committee for all narrative use
- Integrate CIPR checks into all program development stages
- Publish public statement acknowledging past oversights and new process
- Submit final framework for review by Katuaq Cultural Centre and National Labour Inspectorate

**Approval Authorities:** Cultural Liaison, Inuit Cultural Heritage Council, Katuaq Cultural Centre Oversight Committee, National Labour Inspectorate (Greenland)

### 5. Material Co-Creation Working Group Charter

**ID:** d1b85b84-ffe4-4df7-8e7f-af674d573be5

**Description:** A governance document establishing a cross-functional team (elder, master potter, geologist) to oversee the feasibility and ethical use of locally sourced materials like glacial sand and volcanic ash. It defines trial protocols, documentation standards (scientific and oral history), approval thresholds (unanimous consensus), and usage guidelines. Ensures that material adaptation is culturally grounded, technically viable, and community-led.

**Responsible Role Type:** Cultural Liaison

**Primary Template:** Research Ethics Board Charter

**Secondary Template:** Co-Creation Partnership Agreement

**Steps:**

- Form working group with representative from elder council, master potter, and geologist
- Define trial protocols and safety procedures
- Establish documentation requirements for scientific and oral history records
- Set unanimous approval threshold for any new material use
- Document all trial results and elder approvals
- Submit charter for review by Cultural Liaison and Project Manager

**Approval Authorities:** Cultural Liaison, Elder Representative, Master Potter, Geologist, Project Manager

### 6. Emergency Response Protocol

**ID:** fcb731ec-384d-45af-af1f-be30443439ec

**Description:** A comprehensive, documented plan for responding to crises such as fire, equipment failure, or severe weather disruptions. It includes evacuation routes, communication plans (SMS alerts), designated emergency contacts, clear role assignments (e.g., Safety Officer leads response), and a post-incident debrief process. Requires one full-scale drill before public opening to ensure readiness.

**Responsible Role Type:** Safety Officer

**Primary Template:** ISO 22301 Business Continuity Plan

**Secondary Template:** Arctic Emergency Response Guide (Greenlandic Civil Protection)

**Steps:**

- Identify all potential emergency scenarios and risks
- Map evacuation routes and assembly points
- Designate primary and backup communication channels
- Assign specific roles and responsibilities
- Develop incident reporting and debrief templates
- Conduct one full-scale emergency drill before public opening

**Approval Authorities:** Safety Officer, Project Manager, Facility Manager, National Labour Inspectorate (Greenland)

### 7. Public-Facing IoT Dashboard Design

**ID:** a478468f-fd08-46ef-b4a9-76735961a9d4

**Description:** A user interface specification for a live environmental dashboard accessible to staff and visitors. It displays real-time temperature, humidity, CO₂ levels, and energy use metrics from IoT sensors. Features bilingual (Danish/Greenlandic) labels, intuitive visualizations, and alerts for anomalies. Designed to educate visitors about climate resilience and material transformation, enhancing the workshop’s educational and cultural value.

**Responsible Role Type:** Digital Experience Designer

**Primary Template:** UX/UI Design Specification Template

**Secondary Template:** Public Information Display Standard (ISO 21641)

**Steps:**

- Define core data points and visualization types (charts, gauges)
- Design wireframes with multilingual labels and icons
- Prototype interface using Figma or similar tool
- Test usability with target demographics (locals, tourists)
- Integrate with backend sensor data platform
- Obtain approval from Project Manager and Digital Coordinator

**Approval Authorities:** Digital Experience Designer, Project Manager, Digital Coordinator

### 8. Climate & Craft Exhibit Concept

**ID:** d84b871c-9976-4b71-b6b5-b08da5b0574c

**Description:** A conceptual design for an interactive public exhibit using real-time IoT sensor data to tell the story of energy use and material flow in the workshop. It features a digital wall showing live conditions, historical trends, and sustainability metrics (e.g., 'Today’s kiln saved 15 kWh'). Uses storytelling to connect science, culture, and craft, deepening visitor engagement and reinforcing the workshop’s mission of Arctic resilience.

**Responsible Role Type:** Marketing and Community Engagement Specialist

**Primary Template:** Exhibit Design Brief Template

**Secondary Template:** Interactive Museum Exhibit Framework

**Steps:**

- Define core narrative themes: energy, material, community
- Map data visualization concepts to physical space
- Collaborate with Digital Experience Designer on dashboard integration
- Develop bilingual (Danish/Greenlandic) explanatory text
- Plan installation and maintenance schedule
- Present concept to Project Manager and Cultural Liaison for feedback

**Approval Authorities:** Marketing and Community Engagement Specialist, Project Manager, Cultural Liaison

### 9. RACI Matrix for Instructor Team Lead and Safety Officer

**ID:** 86107cc3-3fe7-4450-bd40-994ea7d43481

**Description:** A responsibility assignment chart clarifying overlapping duties between the Instructor Team Lead and Safety Officer. It defines who is Responsible, Accountable, Consulted, and Informed for key tasks like safety training delivery, shift coordination, incident reporting, and curriculum alignment. Prevents duplication of effort and ensures accountability.

**Responsible Role Type:** Project Manager

**Primary Template:** RACI Matrix Template (PMI)

**Secondary Template:** Organizational Responsibility Chart

**Steps:**

- List key tasks where roles overlap (e.g., safety training, incident reporting)
- Assign RACI roles for each task
- Review with Instructor Team Lead and Safety Officer
- Obtain sign-off from both parties
- Distribute to all team members and integrate into onboarding

**Approval Authorities:** Project Manager, Instructor Team Lead, Safety Officer

### 10. Financial Sustainability & Hedging Strategy

**ID:** 2f5f8d04-7028-4121-93e3-db80a5526a23

**Description:** A detailed financial plan ensuring Year 1 budget integrity despite currency volatility. It outlines a 60% forward contract strategy for annual import spend, monthly exchange rate reviews, contingency fund allocation ($100,000 DKK), and a risk-adjusted budget forecast. Includes a hedging performance tracker to monitor effectiveness.

**Responsible Role Type:** Financial Analyst

**Primary Template:** Financial Risk Management Plan

**Secondary Template:** Hedging Strategy Framework (IMF)

**Steps:**

- Calculate total annual import spend in USD
- Negotiate 60% forward contracts with supplier
- Set up monthly exchange rate review process
- Allocate and track contingency fund
- Develop risk-adjusted budget forecast
- Present to Project Manager and Financial Analyst

**Approval Authorities:** Financial Analyst, Project Manager, Clay Workshop Manager

## Documents to Find

### 1. Historical Arctic Shipping Delay Data (2018–2025)

**ID:** b631b54c-96a3-4a36-97c7-c359980f8303

**Description:** Raw data on ice blockages, storm disruptions, and port closures at Nuuk Harbour and Frederikshavn Port, collected from the Danish Maritime Authority (DMA) and Greenlandic Port Authority. Used to validate the probability and duration of winter shipping delays, informing the revised biannual import schedule.

**Recency Requirement:** Most recent available year (2025)

**Responsible Role Type:** Supply Chain Coordinator

**Access Difficulty:** Medium

**Steps:**

- Contact Danish Maritime Authority (DMA) via official inquiry form
- Request access to public shipping logs and delay reports
- Search Greenlandic Port Authority website for annual operational summaries
- Submit Freedom of Information request if data is restricted
- Compile and verify data from multiple sources

### 2. Greenlandic Environmental Protection Act Regulations

**ID:** b441aae4-40d8-475b-9b86-034938651284

**Description:** Official text of the Greenlandic Environmental Protection Act and its implementing regulations. Required for compliance with waste management, emissions, and sustainable operations. Used to audit the workshop's environmental practices and avoid penalties during the pre-compliance audit.

**Recency Requirement:** Current regulations (as of 2026)

**Responsible Role Type:** Sustainability Compliance Officer

**Access Difficulty:** Easy

**Steps:**

- Visit the official Greenlandic government portal (https://www.greenlandic.gov.gl)
- Navigate to the Environment & Climate section
- Download the full text of the Environmental Protection Act
- Search for related regulations and guidelines
- Verify the current version through official publication

### 3. Glacial Sand Composition and Ceramic Properties in Greenland

**ID:** 6bff1972-4409-42d2-8570-9395d3549fa5

**Description:** Scientific data on the mineralogical composition, particle size distribution, and firing behavior of glacial sand found in Greenlandic deposits. Critical for validating the Material Adaptation Strategy and ensuring kiln compatibility. Sourced from geological surveys or university research.

**Recency Requirement:** Published within last 5 years

**Responsible Role Type:** Greenlandic Materials Scientist

**Access Difficulty:** Hard

**Steps:**

- Search academic databases (Google Scholar, ResearchGate) using keywords
- Contact the University of Greenland's Department of Earth Sciences
- Request access to published studies on glacial sand properties
- Check reports from the Greenlandic Geological Survey (GEUS)
- Verify data relevance to Arctic ceramic applications

### 4. Volunteer Liability Waiver Templates (Greenlandic Law)

**ID:** 0713b27c-e5b8-4015-bc73-042bddadc5ad

**Description:** Legally valid waiver forms compliant with Greenlandic civil and labor laws. Essential for protecting the organization when engaging volunteers in high-risk activities. Must be reviewed by a local legal expert to ensure enforceability.

**Recency Requirement:** Valid as of 2026

**Responsible Role Type:** Cultural Liaison

**Access Difficulty:** Medium

**Steps:**

- Contact the Greenlandic Ministry of Justice and Public Administration
- Search online for official legal templates or guidelines
- Consult a local attorney specializing in non-profit law
- Request sample waiver documents used by other organizations
- Verify template compliance with current legislation

### 5. Inuit Storytelling Traditions and Narrative Protocols in Greenland

**ID:** 99ee0a5e-a8b7-4ba9-8880-7e76c40cc3b2

**Description:** Ethnographic and oral history documentation on Inuit storytelling practices, including rules around who can tell which stories, when they can be shared, and what contexts are appropriate. Used to inform the CIPR Framework and prevent cultural misappropriation.

**Recency Requirement:** Recent fieldwork or published research (within last 10 years)

**Responsible Role Type:** Cultural Anthropologist

**Access Difficulty:** Hard

**Steps:**

- Access archives at Katuaq Cultural Centre
- Search academic publications on Inuit epistemology
- Contact the Inuit Circumpolar Council for research resources
- Request interviews with elders through the advisory council
- Compile and verify information from multiple trusted sources

### 6. EnergyPlus Simulation Model for Arctic Buildings

**ID:** 43671f81-4efd-42ba-85f8-17dee0b59130

**Description:** The official EnergyPlus software and its associated climate files for Nuuk, Greenland. Required for accurate dynamic thermal load modeling under extreme winter conditions. Used by the Facility Manager and Energy Systems Engineer to validate the building’s thermal performance.

**Recency Requirement:** Latest version (2026)

**Responsible Role Type:** Facility Manager

**Access Difficulty:** Easy

**Steps:**

- Download EnergyPlus software from the U.S. Department of Energy website
- Download the Nuuk-specific weather file (.epw) from the EnergyPlus Weather Data repository
- Verify the file’s accuracy and recency through official sources
- Install and configure the software on project computer
- Run initial test simulations

### 7. Bilingual (Danish/Greenlandic) Communication Standards

**ID:** ffb98e2d-9122-4a27-a74a-175234abede2

**Description:** Official guidelines for creating bilingual documentation, signage, and digital content in Denmark and Greenland. Ensures all project materials comply with regulatory requirements and are accessible to all stakeholders.

**Recency Requirement:** Current standards (2026)

**Responsible Role Type:** Marketing and Community Engagement Specialist

**Access Difficulty:** Medium

**Steps:**

- Visit the official Nuuk Municipality website
- Search for 'bilingual communication policy' or 'language regulations'
- Contact the Office of the Greenlandic Language Commissioner
- Request access to official style guides and translation standards
- Verify compliance with current regulations