This plan involves money.

## Currencies

- **DKK:** The primary local currency in Greenland, used for all operational expenses including rent, utilities, staff salaries, and equipment procurement. The budget is specified in DKK, making it the most relevant currency for financial planning and reporting.
- **USD:** Included due to the reliance on imported materials from Denmark and Iceland, where transactions may be conducted in USD or EUR. Using USD provides a stable benchmark for international shipping costs and supplier contracts, mitigating risks from DKK exchange rate fluctuations and inflationary pressures in Greenland's isolated economy.

**Primary currency:** DKK

**Currency strategy:** All internal budgeting, staffing, and local procurement will be managed in DKK. For international suppliers and shipping partners, contracts will be denominated in USD to hedge against exchange volatility and ensure cost predictability. This dual-currency approach supports financial stability while aligning with Greenland’s economic reality and supply chain dependencies.