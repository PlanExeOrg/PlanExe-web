**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Majority vote with tie-breaker by Chair; all decisions documented and communicated within 48 hours.
Rationale: Exceeds financial limit for internal governance body, requiring strategic oversight to maintain budget integrity and alignment with the Pragmatic Foundation scenario.
Negative Consequences: Budget overrun, loss of financial control, potential project cancellation due to misaligned expenditures.

**Critical Risk Materialization (e.g., Arctic Shipping Delay)**
Escalation Level: Project Steering Committee
Approval Process: Emergency review meeting convened within 24 hours; decision made via majority vote with immediate implementation authority.
Rationale: Materializes a high-severity risk identified in the risk assessment—Arctic weather disruptions can delay shipments by weeks, threatening session delivery and revenue.
Negative Consequences: Session cancellations, reputational damage, loss of tourist engagement, and potential failure to meet Year 1 viability targets.

**PMO Deadlock on Cultural Content Approval**
Escalation Level: Cultural Anchoring & Compliance Oversight Group
Approval Process: Consensus required; if unresolved, referred to Project Steering Committee for final decision.
Rationale: Conflicts between cultural authenticity and operational feasibility may stall programming; requires independent ethical review to prevent misrepresentation.
Negative Consequences: Cultural misrepresentation, community backlash, loss of trust, and potential legal or regulatory penalties.

**Proposed Major Scope Change (e.g., Adding Geothermal System)**
Escalation Level: Project Steering Committee
Approval Process: Formal review of technical, financial, and strategic impact; approval via majority vote after stakeholder consultation.
Rationale: Deviation from the low-risk 'Pragmatic Foundation' path introduces high complexity and capital risk, requiring strategic validation.
Negative Consequences: Unplanned cost overruns, timeline delays, increased operational risk, and potential breach of the project’s core risk tolerance.

**Reported Ethical Violation (e.g., Unconsented Use of Traditional Design)**
Escalation Level: Operational Risk & Audit Oversight Body
Approval Process: Immediate investigation initiated; findings reported to Project Steering Committee with recommended corrective actions.
Rationale: Requires independent verification and enforcement of consent protocols to protect Indigenous rights and uphold compliance standards.
Negative Consequences: Legal liability, community distrust, reputational harm, and potential termination of partnership with Katuaq Cultural Centre.