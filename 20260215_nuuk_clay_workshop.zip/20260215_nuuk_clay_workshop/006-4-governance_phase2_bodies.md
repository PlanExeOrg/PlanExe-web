### 1. Project Steering Committee

**Rationale for Inclusion:** The project's high operational complexity, reliance on Greenland-specific logistics, and need for strategic alignment across supply chain, energy, staffing, and cultural integration necessitate a central oversight body with authority to resolve cross-functional conflicts and ensure adherence to the Pragmatic Foundation scenario. This committee provides essential strategic direction and escalation control.

**Responsibilities:**

- Approve final selection of core levers (Supply Chain Resilience, Energy-Efficient Facility Design, etc.)
- Review and approve major budget adjustments exceeding 10% of allocated line items
- Oversee implementation of risk mitigation plans (e.g., air freight contracts, liability insurance)
- Resolve conflicts between governance bodies (e.g., Cultural Anchoring vs. Supply Chain decisions)
- Ensure alignment with the 'Pragmatic Foundation' strategic path and low-risk mandate
- Approve changes to the advisory council structure or membership

**Initial Setup Actions:**

- Define Terms of Reference and decision-making protocols
- Identify and appoint members from senior leadership and key stakeholder groups
- Establish a formal escalation process for unresolved issues
- Set initial meeting schedule (bi-weekly during setup phase)

**Membership:**

- Clay Workshop Manager (Chair)
- Head of Finance (from Nuuk Municipality partner)
- Lead Instructor (representing teaching team)
- Cultural Advisor (from Katuaq Cultural Centre advisory council)
- External Arctic Infrastructure Consultant (independent)

**Decision Rights:** Authority to make binding decisions on all strategic levers, budget reallocations above 10%, and conflict resolution involving multiple governance bodies.

**Decision Mechanism:** Majority vote; tie-breaker by Chair. All decisions documented in minutes and communicated to relevant bodies within 48 hours.

**Meeting Cadence:** Bi-weekly during project setup (Feb–Jul 2026); monthly thereafter until Year 1 closure.

**Typical Agenda Items:**

- Review of progress against milestones (lease, staff hire, fit-out)
- Assessment of supply chain disruption risks and emergency response readiness
- Evaluation of financial performance vs. budget forecast
- Resolution of inter-body conflicts (e.g., cultural content vs. material availability)
- Approval of major expenditures or policy changes

**Escalation Path:** Unresolved issues are escalated to the Nuuk Municipality Executive Board or the Greenlandic Ministry of Culture and Social Affairs for final determination.
### 2. Instructor Resilience Network

**Rationale for Inclusion:** With four part-time instructors operating under a rotating schedule, ensuring consistent session coverage and quality requires a dedicated internal body focused on peer coordination, training, and continuity. This network prevents operational failure due to absence and supports long-term staff sustainability.

**Responsibilities:**

- Manage and maintain the digital shift calendar and rotation schedule
- Coordinate and deliver mandatory cross-training sessions across skill levels
- Track completion of safety training and liability waivers for all instructors
- Oversee the volunteer pool and assign supervised shifts during emergencies
- Report session coverage rates and absenteeism trends to the Project Steering Committee

**Initial Setup Actions:**

- Finalize the 4-week rotating schedule template
- Develop and distribute cross-training curriculum and materials
- Conduct first round of safety training and liability waiver collection
- Establish communication channels (e.g., WhatsApp group, shared drive)

**Membership:**

- All four Part-Time Instructors
- Rotating Safety Officer (assigned weekly)
- Local Logistics Coordinator (observer)

**Decision Rights:** Authority to manage instructor schedules, approve training completions, and assign substitute instructors during absences.

**Decision Mechanism:** Consensus-based; if consensus not reached, majority vote with tie-breaker by the rotating Safety Officer.

**Meeting Cadence:** Weekly during active programming; bi-weekly during setup and soft launch.

**Typical Agenda Items:**

- Review upcoming week’s shift assignments
- Update on cross-training progress and skill gaps
- Discuss recent absences and coverage plans
- Share feedback on student experience and session quality
- Plan next safety drill and training module

**Escalation Path:** Issues involving unqualified volunteers or scheduling conflicts beyond scope are escalated to the Project Steering Committee.
### 3. Cultural Anchoring & Compliance Oversight Group

**Rationale for Inclusion:** Given the project’s deep focus on Inuit heritage and community co-creation, and the high risk of cultural misrepresentation, a specialized body is required to ensure ethical engagement, consent processes, and compliance with Indigenous rights frameworks. This group acts as an independent safeguard.

**Responsibilities:**

- Review and approve all use of traditional motifs, stories, and designs before inclusion in courses or exhibitions
- Verify that written consent has been obtained from elders and artists for all cultural content
- Audit all bilingual (Danish/Greenlandic) documentation for accuracy and cultural sensitivity
- Evaluate co-design workshop outcomes for authenticity and inclusivity
- Ensure all public-facing materials (digital, signage, marketing) meet cultural standards

**Initial Setup Actions:**

- Finalize the Community Consent Protocol and checklist
- Establish a review calendar for all cultural content
- Train all instructors and staff on cultural ethics and protocol
- Create a repository of approved traditional designs and narratives

**Membership:**

- Cultural Advisor (Chair)
- Elder Representative (from advisory council)
- Artist Representative (from local collectives)
- Clay Workshop Manager (ex-officio)
- Legal/Compliance Officer (external consultant)

**Decision Rights:** Veto power over any cultural content or program element deemed inappropriate or non-consensual.

**Decision Mechanism:** Consensus required for approval; if consensus not reached, issue referred to the Project Steering Committee for final decision.

**Meeting Cadence:** Monthly during programming; bi-weekly during development and soft launch.

**Typical Agenda Items:**

- Review of proposed course content involving traditional forms
- Approval of exhibition themes and display materials
- Audit of new digital archive entries or QR code content
- Feedback on youth apprenticeship projects
- Assessment of community forum participation and representation

**Escalation Path:** Disputes over cultural authenticity or consent are escalated to the Project Steering Committee and, if necessary, to the Greenlandic Ministry of Culture and Social Affairs.
### 4. Operational Risk & Audit Oversight Body

**Rationale for Inclusion:** To mitigate corruption, misallocation, and procedural failures identified in the audit, a dedicated internal body is needed to enforce transparency, conduct regular checks, and ensure accountability across financial, logistical, and safety systems—critical for maintaining trust and budget integrity.

**Responsibilities:**

- Conduct quarterly audits of inventory logs and purchase orders
- Perform bi-monthly financial reviews against budget breakdown
- Carry out post-milestone audits after lease signing, fit-out, and first course delivery
- Randomly spot-check instructor shift records and training documentation
- Oversee the operation of the whistleblower portal and public dashboard

**Initial Setup Actions:**

- Define audit checklists and procedures
- Assign audit lead and support roles
- Set up access to financial systems and inventory databases
- Launch the whistleblower portal and public dashboard

**Membership:**

- Internal Auditor (appointed from finance/accounting team)
- Safety Officer (rotating role)
- Independent Ethics Monitor (external appointment)
- Clay Workshop Manager (ex-officio observer)

**Decision Rights:** Authority to report findings, recommend corrective actions, and halt processes if fraud or serious non-compliance is detected.

**Decision Mechanism:** Findings reported in writing; recommendations presented to the Project Steering Committee for action. Immediate suspension of non-compliant activities possible.

**Meeting Cadence:** Bi-monthly during setup and programming; ad hoc for urgent issues.

**Typical Agenda Items:**

- Review of last quarter’s inventory audit results
- Analysis of financial variance reports
- Discussion of whistleblower submissions and follow-up actions
- Evaluation of public dashboard data accuracy
- Recommendations for process improvements based on audit findings

**Escalation Path:** Serious findings (e.g., fraud, safety violations) are escalated immediately to the Project Steering Committee and the Nuuk Municipality Ethics Office.