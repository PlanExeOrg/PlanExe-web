## Primary Decisions
The vital few decisions that have the most impact.


The 'Critical' and 'High' levers—Supply Chain Resilience, Energy-Efficient Facility Design, Instructor Resilience Network, and Cultural Anchoring—collectively address the project's core tensions: operational reliability vs. logistical risk, seasonal volatility vs. year-round sustainability, and cultural authenticity vs. commercial scalability. These levers form the backbone of a resilient, low-risk model. Notably absent are explicit levers for digital infrastructure or emergency response planning, which could strengthen the strategy further, especially given Nuuk’s remote context.

### Decision 1: Supply Chain Resilience Strategy
**Lever ID:** `4e22ea8b-e883-4411-bbb1-bb2ed8fe003a`

**The Core Decision:** The Supply Chain Resilience Strategy ensures consistent, cost-effective access to essential clay and equipment despite Greenland's logistical challenges. It mitigates risks from long lead times, high shipping costs, and customs delays by establishing predictable import schedules, fostering local material partnerships, or adopting a hybrid approach. Success is measured by reduced supply disruptions, lower freight costs per unit, and stable inventory levels across seasons. This lever enables reliable course delivery and supports operational continuity, especially during peak demand periods.

**Why It Matters:** Immediate: Secure bulk clay shipments from Denmark via pre-arranged quarterly contracts → Systemic: 30% reduction in per-unit material cost through volume discounts and reduced freight volatility → Strategic: Enables stable course pricing and prevents session cancellations due to supply gaps.

**Strategic Choices:**

1. Establish a fixed quarterly import schedule with a single Danish supplier using consolidated shipping containers to minimize customs delays and freight costs.
2. Partner with local artisans to co-produce low-fire ceramic products using locally sourced materials (e.g., glacial sand) to reduce dependency on imported clay.
3. Adopt a hybrid model: use imported high-quality clay for courses, but develop a secondary line of locally adapted ceramics using recycled or regionally available mineral mixtures.

**Trade-Off / Risk:** Controls Cost Volatility vs. Supply Reliability. Weakness: The options fail to consider the potential for climate-related disruptions in Arctic shipping lanes, which could delay critical imports during winter months.

**Strategic Connections:**

**Synergy:** This lever synergizes strongly with the Material Adaptation Strategy by enabling the use of locally sourced or blended materials without compromising quality. It also enhances the Instructor Resilience Network by ensuring consistent material availability, allowing instructors to plan sessions reliably and reduce last-minute cancellations due to shortages.

**Conflict:** It conflicts with the Energy-Efficient Facility Design when prioritizing large-scale container shipments over smaller, more frequent deliveries that could align better with modular kiln usage. Additionally, investing in local material production may divert resources from importing high-quality clay, potentially conflicting with the Cultural Anchoring Framework’s need for authentic traditional materials.

**Justification:** *Critical*, Critical because it controls the foundational reliability of material access, directly impacting course delivery, cost stability, and operational continuity. Its synergy with multiple levers—especially Instructor Resilience and Material Adaptation—makes it a central hub for mitigating Greenland-specific risks like shipping delays and high costs.

### Decision 2: Energy-Efficient Facility Design
**Lever ID:** `ccd9b03c-f86a-4181-a3f6-79600c362f66`

**The Core Decision:** Energy-Efficient Facility Design reduces operational costs and environmental impact by minimizing heating and kiln energy consumption. Through passive solar orientation, geothermal systems, or on-demand modular kilns, it ensures thermal stability for clay drying and firing while adapting to Greenland’s harsh climate. Key metrics include reduced utility bills, lower carbon footprint, and consistent indoor conditions. This lever supports year-round usability and sustainability, crucial for maintaining open-studio hours and courses through winter months.

**Why It Matters:** Immediate: Install heat-recycling kilns and insulated drying zones → Systemic: 40% lower heating costs through optimized thermal retention and waste heat recovery → Strategic: Reduces utility burden and supports environmental stewardship, enhancing public perception.

**Strategic Choices:**

1. Use passive solar design in the building layout with large south-facing windows and thermal mass walls to naturally regulate temperature.
2. Integrate a small-scale geothermal heating system powered by deep boreholes, leveraging Greenland’s stable underground temperatures.
3. Adopt modular kiln systems that operate only during scheduled sessions, minimizing idle energy consumption.

**Trade-Off / Risk:** Controls Energy Efficiency vs. Upfront Capital. Weakness: The radical option (geothermal) lacks consideration of drilling risks and regulatory hurdles in sensitive Greenlandic terrain.

**Strategic Connections:**

**Synergy:** This lever synergizes powerfully with the Seasonal Demand Buffering Model by enabling efficient operation during low-demand winter months without excessive energy waste. It also complements the Material Adaptation Strategy by supporting on-site processing and drying of locally sourced materials that require controlled environments.

**Conflict:** It may conflict with the Supply Chain Resilience Strategy if geothermal drilling or large-scale passive design requires upfront capital that competes with funds for imported clay or shipping containers. Additionally, relying on modular kilns could limit the ability to run large group sessions, creating tension with the Hybrid Access & Revenue Architecture’s goal of scalable drop-in participation.

**Justification:** *High*, High because it addresses the core trade-off between energy costs and facility usability in Greenland’s harsh climate. It enables year-round operation, supports sustainability goals, and synergizes strongly with Seasonal Demand Buffering and Material Adaptation, making it essential for long-term viability.

### Decision 3: Instructor Resilience Network
**Lever ID:** `6e21bf2f-f5e0-4894-b9b1-bb1955856ab9`

**The Core Decision:** The Instructor Resilience Network ensures uninterrupted teaching through a robust system of shared responsibilities, peer mentorship, and emergency volunteer support. By rotating schedules, training junior staff, and engaging retired artists, it prevents session cancellations due to illness or absence. Success is measured by 100% session coverage, instructor retention, and consistent student experience. This lever strengthens operational reliability and fosters a culture of knowledge sharing and community investment.

**Why It Matters:** Immediate: Cross-train instructors in multiple skill areas to cover absences → Systemic: 90% session continuity even with single staff absence → Strategic: Creates a self-sustaining teaching ecosystem that reduces burnout and turnover.

**Strategic Choices:**

1. Implement a rotating instructor schedule with shared course responsibilities among all four part-timers
2. Develop a peer mentorship program where senior instructors train junior ones in both technique and facilitation
3. Establish a community volunteer pool of retired potters and artists who can step in during emergencies

**Trade-Off / Risk:** Controls Staff Availability vs. Teaching Quality Consistency. Weakness: The third option underestimates the need for formal training and liability coverage when involving non-qualified volunteers.

**Strategic Connections:**

**Synergy:** This lever synergizes closely with the Cultural Anchoring Framework by enabling elders and experienced local artists to contribute as mentors or guest instructors. It also enhances the Supply Chain Resilience Strategy by ensuring that even during supply disruptions, trained instructors can adapt curricula or shift focus to alternative materials without losing instructional continuity.

**Conflict:** It may conflict with the Hybrid Access & Revenue Architecture if volunteer or part-time instructors lack formal training, leading to inconsistent quality in paid drop-in sessions. Additionally, rotating schedules could complicate long-term course planning, potentially undermining the Seasonal Demand Buffering Model’s ability to forecast staffing needs accurately.

**Justification:** *High*, High because it ensures operational continuity through part-time staffing, directly addressing the project’s need for resilience against absences. Its synergy with Cultural Anchoring and Supply Chain strategies makes it vital for maintaining consistent quality and community trust.

### Decision 4: Cultural Anchoring Framework
**Lever ID:** `9b3845fa-d8ea-4e1f-a433-9ce8d6ec7ffc`

**The Core Decision:** The Cultural Anchoring Framework embeds the workshop within Nuuk’s cultural identity by integrating Inuit traditions, narratives, and local artistry into programming. Through collaborations with Katuaq, inclusion of traditional forms in courses, and digital archives, it builds authenticity, relevance, and community ownership. Success is measured by increased local participation, positive feedback from cultural partners, and visible integration of Inuit heritage in student work and exhibitions.

**Why It Matters:** Immediate: Embed local Inuit design motifs and storytelling into course content → Systemic: 50% higher perceived cultural relevance among locals → Strategic: Positions the workshop as a custodian of Greenlandic heritage, enhancing brand loyalty and tourism appeal.

**Strategic Choices:**

1. Collaborate with Katuaq Cultural Centre to co-host quarterly exhibitions featuring student work with Inuit narratives
2. Integrate traditional forms (e.g., qajaq-inspired vessels) into beginner courses with guidance from elders
3. Launch a digital archive of local ceramic traditions accessible via QR codes at the workshop entrance

**Trade-Off / Risk:** Controls Cultural Authenticity vs. Commercialization Risk. Weakness: The digital archive option may prioritize visibility over ethical representation if community consent and intellectual property rights are not formally secured.

**Strategic Connections:**

**Synergy:** This lever synergizes strongly with the Community Co-Creation Ecosystem by inviting locals to co-design courses and contribute stories. It also amplifies the Material Adaptation Strategy by validating the use of local materials like glacial sand or volcanic ash as culturally meaningful alternatives to imported clay.

**Conflict:** It may conflict with the Supply Chain Resilience Strategy if traditional materials are not available in sufficient quantity or consistency, forcing trade-offs between cultural authenticity and operational reliability. Additionally, emphasizing traditional forms could limit flexibility in curriculum design, potentially clashing with the Hybrid Access & Revenue Architecture’s need for scalable, standardized offerings.

**Justification:** *High*, High because it defines the workshop’s identity as a cultural hub, driving local engagement and tourism appeal. Its deep synergy with Community Co-Creation and Material Adaptation positions it as a strategic differentiator that enhances brand loyalty and social impact.

### Decision 5: Material Adaptation Strategy
**Lever ID:** `bef56a81-6740-4e9f-a0de-457708723250`

**The Core Decision:** The Material Adaptation Strategy reduces dependency on expensive imports by developing locally sourced or processed ceramic materials. Options include partnering with artisans, on-site processing, or blending imported clay with regional minerals. This lever lowers costs, shortens lead times, and supports sustainability. Success is measured by reduced import volume, cost savings, and successful integration of adapted materials into student projects without compromising quality.

**Why It Matters:** Immediate: Sourcing clay from local Greenlandic deposits or regional suppliers reduces shipping costs → Systemic: 30% lower material expenses and 40% shorter lead times through localized procurement → Strategic: Enables price stability and faster course scheduling, reducing dependency on Danish/Icelandic imports.

**Strategic Choices:**

1. Prioritize partnerships with Greenlandic artisan collectives to source and co-produce clay materials, integrating local craft traditions.
2. Establish a small-scale on-site clay processing unit using imported raw materials, enabling partial self-sufficiency in shaping and drying.
3. Adopt a hybrid material model: blend imported clay with locally available mineral additives (e.g., volcanic ash) to reduce volume and cost.

**Trade-Off / Risk:** Controls Cost Volatility vs. Cultural Authenticity. Weakness: The options fail to consider the technical feasibility of local clay processing at scale, particularly regarding consistency and kiln compatibility.

**Strategic Connections:**

**Synergy:** This lever synergizes directly with the Cultural Anchoring Framework by enabling the use of regionally significant materials such as glacial sand or volcanic ash, reinforcing cultural authenticity. It also supports the Supply Chain Resilience Strategy by reducing reliance on unpredictable international shipments and providing a buffer during import delays.

**Conflict:** It may conflict with the Energy-Efficient Facility Design if on-site processing requires additional kiln time or specialized drying space, increasing energy demands. Furthermore, using non-standard materials could challenge the Instructor Resilience Network if instructors lack training in handling unfamiliar compositions, risking inconsistent results and student frustration.

**Justification:** *Medium*, Medium because while it reduces dependency on imports, it is largely dependent on the success of the Supply Chain Resilience Strategy and Energy-Efficient Facility Design. It supports cost savings but operates more as an enabling lever than a central control point.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Seasonal Demand Buffering Model
**Lever ID:** `53831d44-6e53-4b46-8820-a548b4d9dbb1`

**The Core Decision:** The Seasonal Demand Buffering Model addresses the workshop's fluctuating demand by aligning programming with Greenland's seasonal rhythms. It introduces themed winter events like 'Winter Pottery Nights' to engage locals during dark months, micro-courses for tourists in summer peaks, and artist-in-residence programs to maintain activity during slow periods. Objectives include stabilizing attendance, maximizing facility utilization, and enhancing community engagement year-round. Success is measured by consistent monthly participation rates, reduced idle capacity, and positive feedback from both locals and tourists across seasons.

**Why It Matters:** Immediate: Shift focus from peak-season-only programming to year-round engagement → Systemic: 25% faster scaling through diversified activity streams (e.g., winter workshops, holiday pop-ups) → Strategic: Reduces financial strain during low-demand periods and strengthens community retention.

**Strategic Choices:**

1. Launch themed seasonal programs (e.g., ‘Winter Pottery Nights’ with storytelling and light installations) to attract locals during dark months.
2. Introduce micro-courses (2–3 sessions) tailored for tourists during summer peaks, offering quick, immersive experiences.
3. Develop a rotating artist-in-residence program that brings in temporary creators to generate buzz and fill open slots during slow periods.

**Trade-Off / Risk:** Controls Seasonality Risk vs. Operational Overhead. Weakness: The options do not account for the added coordination burden of managing rotating artists or event logistics during tight staffing windows.

**Strategic Connections:**

**Synergy:** This lever synergizes strongly with the Hybrid Access & Revenue Architecture by creating diverse revenue streams tied to seasonal activities—e.g., tourist packages during summer and premium experiences in winter. It also amplifies the Cultural Anchoring Framework by embedding local traditions into seasonal events, deepening cultural relevance and community connection.

**Conflict:** It may conflict with the Supply Chain Resilience Strategy due to increased demand spikes requiring last-minute material orders, which can strain long lead times and import logistics. Additionally, it competes with Instructor Resilience Network needs, as temporary artists or event-specific instructors may require onboarding that challenges consistent staffing stability.

**Justification:** *Medium*, Medium because it optimizes utilization across seasons but relies heavily on the Hybrid Access & Revenue Architecture and Instructor Resilience Network to execute effectively. It is important for financial balance but not a standalone strategic driver.

### Decision 7: Hybrid Access & Revenue Architecture
**Lever ID:** `827ce0dd-0258-4ab0-888d-2464fb23832c`

**The Core Decision:** The Hybrid Access & Revenue Architecture creates flexible pricing models to serve diverse user groups: a Clay Pass for residents offering unlimited access, a Tourist Experience Package sold through hotel partnerships, and a pay-what-you-can option for locals in winter. This lever ensures financial sustainability by balancing affordability with revenue generation. Key metrics include membership uptake, package sales, and income stability across seasons. It enables inclusive access while supporting operational resilience through diversified funding.

**Why It Matters:** Immediate: Offer tiered access (drop-in, membership, course bundles) → Systemic: 35% higher revenue predictability through diversified income streams → Strategic: Balances affordability for locals with premium offerings for tourists, supporting long-term financial sustainability.

**Strategic Choices:**

1. Launch a ‘Clay Pass’ membership with unlimited drop-ins and exclusive access to workshops, priced affordably for residents.
2. Design a ‘Tourist Experience Package’ including a 2-hour class, materials kit, and souvenir piece, sold via hotel partnerships.
3. Introduce a pay-what-you-can model for locals during winter months, funded by summer surpluses and sponsorships.

**Trade-Off / Risk:** Controls Accessibility vs. Revenue Stability. Weakness: The options assume consistent tourist inflow but do not include contingency plans for travel disruptions or weather-related cancellations.

**Strategic Connections:**

**Synergy:** This lever has strong synergy with the Seasonal Demand Buffering Model by providing tailored offerings that match seasonal patterns—e.g., tourist packages in summer and subsidized access in winter. It also enhances the Community Co-Creation Ecosystem by enabling low-barrier entry for youth apprenticeships and community projects through affordable or free access tiers.

**Conflict:** It may conflict with the Material Adaptation Strategy, as high-volume access (e.g., unlimited drop-ins) increases clay consumption unpredictably, risking shortages if not aligned with supply forecasts. It also strains the Energy-Efficient Facility Design if open-studio hours expand without corresponding energy management controls, increasing heating costs during peak usage.

**Justification:** *Low*, Low because it is a tactical implementation layer that depends on higher-level levers like Supply Chain Resilience and Instructor Resilience. While it diversifies income, it lacks systemic centrality and is redundant with other revenue-focused strategies already embedded in the plan.

### Decision 8: Community Co-Creation Ecosystem
**Lever ID:** `26ac32f4-85b4-4c68-a2d7-9a5fa734a7ba`

**The Core Decision:** The Community Co-Creation Ecosystem fosters deep local engagement by involving residents in co-designing public art installations, launching youth apprenticeships with schools, and integrating AI-assisted design tools. This lever strengthens social ownership, builds intergenerational connections, and positions the workshop as a cultural hub. Success is measured by participation rates in co-creation events, number of youth involved, and visibility of community artworks. It reinforces the workshop’s identity as a 'third place' beyond just a craft space.

**Why It Matters:** Immediate: Involve locals in design, curation, and event planning → Systemic: 50% increase in repeat attendance through emotional ownership → Strategic: Transforms the workshop from a service provider into a cultural hub, enhancing long-term loyalty and word-of-mouth reach.

**Strategic Choices:**

1. Host quarterly ‘Community Pottery Days’ where residents co-design public installations using workshop clay, displayed at Katuaq.
2. Launch a youth apprenticeship track with school partnerships, providing free access in exchange for community contribution projects.
3. Use AI-assisted design tools (e.g., generative pattern generators) to help users create personalized ceramic pieces, blending tradition with digital innovation.

**Trade-Off / Risk:** Controls Engagement Depth vs. Technological Overreach. Weakness: The radical option introduces AI tools without assessing digital literacy levels among target demographics or infrastructure reliability in Nuuk.

**Strategic Connections:**

**Synergy:** This lever synergizes powerfully with the Cultural Anchoring Framework by embedding local stories and aesthetics into public installations and youth projects. It also supports the Seasonal Demand Buffering Model by generating recurring events like 'Community Pottery Days' that attract visitors and locals alike throughout the year.

**Conflict:** It may conflict with the Instructor Resilience Network, as co-creation projects often require additional supervision and coordination beyond standard teaching duties, potentially overburdening part-time staff. It also risks straining the Supply Chain Resilience Strategy if large-scale community projects demand sudden, bulk material orders without sufficient lead time.

**Justification:** *Low*, Low because it amplifies engagement but is highly dependent on staffing, materials, and funding from other critical levers. Its success hinges on the stability provided by Supply Chain and Instructor Resilience, making it a secondary enabler rather than a strategic pillar.
