# Purpose
# Community Clay Workshop in Nuuk, Greenland

## Purpose
Establish a sustainable, low-risk community-based arts initiative serving as a social 'third place' for locals and tourists in Nuuk.

## Core Activities

- Accessible hand-building and wheel-throwing courses
- Structured open-studio hours
- Recurring short-term classes

## Strategic Goals

- Foster local cultural engagement
- Integrate tourism through creative experiences
- Promote creative wellness and community connection

## Operational Model

- Part-time staffing: four instructors (flexible, cost-efficient)
- Flexible pricing: memberships and drop-in options
- Strategic location near Katuaq Cultural Centre and Nuuk Center for high visibility and foot traffic

## Key Challenges & Mitigations

- High import costs: source materials locally where possible; prioritize durable, reusable supplies
- Seasonal demand fluctuations: design programs to align with tourist seasons; offer off-season workshops and online content
- Long supply lead times: maintain buffer inventory; establish relationships with regional suppliers

## Recommendations

- Partner with local schools, cultural organizations, and tourism boards
- Offer multilingual class materials and signage
- Develop digital presence for outreach and booking
- Monitor attendance trends and adjust programming quarterly


# Plan Type
# Physical Community Clay Workshop in Nuuk, Greenland

## Core Requirements

- Establish a physical clay workshop near Katuaq Cultural Centre and Nuuk Center.
- Secure and lease a building with adequate space for kilns, worktables, storage, drying areas, and heating systems.
- Install utilities (electricity, water, ventilation) and ensure climate control for clay processing.

## Logistics & Operations

- Transport clay, tools, and equipment from Denmark/Iceland via shipping; manage customs clearance and import procedures.
- Hire and coordinate four part-time instructors on-site; manage schedules and in-person training.
- Conduct in-person sessions: hand-building, wheel-throwing, open-studio hours, and courses.
- Adjust staffing and operations seasonally based on demand peaks in summer and winter.

## Infrastructure Needs

- Kilns and drying rooms with reliable heating.
- Workspaces with sinks, storage, and dust control.
- Access to power, water, and waste disposal systems.

## Digital vs. Physical Components

- Administrative tasks (marketing, scheduling, communications) may be digital.
- All core activities—teaching, crafting, material handling, and user engagement—are physically dependent.

## Conclusion
The plan is entirely reliant on a physical location and infrastructure. No aspect can be executed digitally without compromising functionality. Therefore, this is a physical project.

# Physical Locations
## Requirements for Physical Locations

- Near Katuaq Cultural Centre and Nuuk Center for visibility and cultural alignment  
- Proximity to transportation hubs and pedestrian foot traffic  
- Space for kilns, worktables, drying zones, storage, and open-studio areas  
- Heating and insulation suitable for Greenland’s harsh climate  
- Access to reliable electricity, water, and waste utilities  
- Capacity to handle seasonal demand (summer and winter peaks)  
- Zoning approval for commercial arts use and public access  

## Location 1: Katuaq Cultural Centre Complex  
Nuuk, Central District  
20–24 Kalaallit Nunaat Street, Nuuk, Greenland  

- Located within the city’s cultural heart, ensuring high visibility and community engagement  
- Already zoned for public and cultural institutions, simplifying permitting  
- Close to transport links and pedestrian traffic  
- Existing infrastructure reduces setup costs and complexity  
- Supports year-round operation with reliable heating and access to community spaces  

## Location 2: Former Fish Processing Building  
Nuuk, Old Town (Qaanaaq Quarter)  
15–17 Qaanaaq Street, Nuuk, Greenland  

- Large, adaptable industrial space ideal for studio and production needs  
- Within walking distance of Katuaq and Nuuk Center  
- Can be retrofitted with passive solar design and thermal insulation  
- Existing utility connections lower installation costs  
- Repurposing supports sustainable reuse and local heritage preservation  

## Location 3: Nuuk Harbour Office Building  
Nuuk, Northern Harbor Area  
8–10 Havnvejen, Nuuk, Greenland  

- Strategic location near harbor and transit routes, accessible to locals and tourists  
- Part of mixed-use development with established utilities  
- South-facing windows enable passive solar gain, supporting energy efficiency  
- Potential for summer outdoor art installations  
- Offers flexibility for seasonal operations  

## Summary  
All three locations meet core requirements: proximity to key cultural landmarks, access to utilities, adaptability for studio and drying zones, and resilience in Greenland’s extreme climate. Each site supports year-round operation, public access, and seasonal demand fluctuations. They align with the low-risk, resilient model under the Pragmatic Foundation scenario, balancing feasibility, sustainability, and strategic positioning for both local and tourist audiences.

# Currency Strategy
## Currencies

- DKK: Primary local currency for all operational expenses (rent, utilities, salaries, equipment). Budgets are in DKK; used for internal financial planning and reporting.
- USD: Used for international procurement (Denmark, Iceland) to hedge against DKK exchange rate volatility and inflation. Provides cost predictability for shipping and supplier contracts.

Primary currency: DKK  
Currency strategy: Internal operations in DKK; international contracts in USD to mitigate financial risk and ensure stability amid Greenland’s isolated economy and supply chain dependencies.

# Identify Risks
## Risk 1 - Regulatory & Permitting  

- Impact: 4–8 week delay in opening; 200,000–350,000 DKK in lost revenue and holdover fees.  
- Likelihood: Medium  
- Severity: High  
- Action: Engage Nuuk Municipality early. Hire local regulatory consultant. Submit all documents in Danish and Greenlandic.

## Risk 2 - Supply Chain & Logistics  

- Impact: Session cancellations, 2–4 week delays, 150,000–250,000 DKK in lost revenue and reputational damage.  
- Likelihood: High  
- Severity: High  
- Action: Secure fixed quarterly shipments with one trusted supplier. Add 10% buffer to orders. Use real-time tracking and appoint local logistics coordinator. Enable emergency air freight.

## Risk 3 - Energy & Facility Operations  

- Impact: Up to 30% project loss due to drying issues; energy costs exceed budget by 10–15% (100,000–150,000 DKK); safety risks.  
- Likelihood: Medium  
- Severity: High  
- Action: Apply passive solar design. Install sensors for temp/humidity monitoring. Use modular kilns on schedule. Conduct pre-opening thermal audit.

## Risk 4 - Staffing & Human Resources  

- Impact: Up to two weekly sessions canceled monthly; 15–20% drop in attendance; 75,000–120,000 DKK in lost fees and rebooking costs.  
- Likelihood: Medium  
- Severity: Medium  
- Action: Mandate cross-training for all instructors. Use digital shift calendar. Maintain pool of insured volunteer substitutes (retired potters).

## Risk 5 - Financial Management  

- Impact: 10–15% increase in material costs (200,000–300,000 DKK annually); threatens 2 million DKK budget.  
- Likelihood: Low  
- Severity: High  
- Action: Hedge 60% of annual import spend via forward contracts. Monthly exchange rate reviews. Maintain 100,000 DKK contingency fund.

## Risk 6 - Cultural & Community Engagement  

- Impact: Up to 40% drop in local participation; negative media; damaged partnerships; long-term brand harm.  
- Likelihood: Medium  
- Severity: High  
- Action: Form advisory council with elders and artists. Co-design programs through workshops. Obtain written consent and benefit-sharing agreements for traditional content.

## Risk Summary  

- Top Risks: Supply Chain & Logistics (high likelihood, high severity), Energy & Facility Operations (medium likelihood, high severity).  
- Second Tier: Regulatory & Permitting (delay risk), Financial (currency volatility).  
- Critical Success Factors: Reliable supply chain, energy efficiency, authentic community collaboration.  
- Key Strategy: Execute Pragmatic Foundation scenario with strict controls on logistics, operations, and cultural engagement.


# Make Assumptions
## Question 1 - Physical Space Requirements  

- Total space: 120–150 m² with modular layout for flexibility.  
- Kiln zone: 15 m² with ventilation, fire safety, and thermal zoning.  
- Drying area: 30 m² with climate control (humidity/temperature).  
- Worktables: 40 m² for hands-on sessions.  
- Storage & admin: 20 m².  
- Open-studio seating: 12–16 people.  
- Key considerations: Material flow efficiency, seasonal reconfiguration, insulation, HVAC, non-slip flooring.  
- Risks: Insufficient drying space → up to 30% project waste; non-compliance → safety/code violations.

## Question 2 - Instructor Scheduling  

- Rotating 4-week schedule with staggered shifts.  
- Two instructors per week; 8–10 hours/week each.  
- Cross-training ensures coverage across skill levels.  
- Digital shift calendar for real-time updates and transparency.  
- Key considerations: Prevent burnout, ensure fair workload, maintain continuity.  
- Risks: Overlapping shifts or gaps → inefficiency; exceeding 10 hours/week → turnover.

## Question 3 - Budget Breakdown (2 million DKK)  

- Fit-out & equipment: 40% (kilns, tables, tools, insulation).  
- Rent & utilities (Year 1): 25%.  
- Instructor salaries (4 × 15,000 DKK/month): 20%.  
- Materials & supplies: 10%.  
- Marketing & outreach: 5%.  
- Contingency fund: 100,000 DKK (currency volatility, unforeseen costs).  
- Key considerations: Bulk procurement, USD-denominated imports, targeted marketing.  
- Risks: Exchange rate swings → budget overrun by 15% without hedging.

## Question 4 - Milestones & Timeline  

- Project start: 2026-Feb-15.  
- Lease signed: Apr-30 (60 days).  
- Staff hired: May-15 (60 days).  
- Fit-out completed: Jul-31 (150 days).  
- First course: Aug-1 (100 days).  
- Soft launch: 3 weeks before public opening.  
- Key considerations: Early permitting, specialist contractors, background checks, cross-training.  
- Risks: Permit delays → October launch → 40% loss in tourist engagement.

## Question 5 - Regulatory Compliance  

- Advisory council with elders and local artists.  
- Written consent required for traditional motifs.  
- Adherence to Environmental Protection Act, building codes, fire safety, noise control.  
- All exhibitions and curriculum undergo community review.  
- Bilingual documentation (Danish/Greenlandic).  
- Key considerations: Avoid legal action, protect IP, maintain trust.  
- Risks: Non-compliance → fines, closure, loss of Katuaq partnership.

## Question 6 - Safety Risk Management  

- Mandatory training for all users.  
- HEPA-filtered ventilation in kiln and drying zones.  
- Fire extinguishers at every station; emergency shutdown procedures.  
- Regular inspections (quarterly); monthly drills.  
- Clay dust control via wet-mix techniques and sealed storage.  
- Rotated safety officer role among instructors.  
- Key considerations: Cold climate risks (heat trapping, overheating), silica exposure.  
- Risks: Injuries, equipment damage, insurance claims.

## Question 7 - Environmental Sustainability  

- Passive solar design (reduces heating needs by 40%).  
- Modular kilns (prevent idle energy use).  
- Waste clay reclaimed and reused (up to 25% material reduction).  
- Recycled packaging, biodegradable glazes, compostable tourist kits.  
- Local sourcing and partnerships for low-impact materials.  
- Key considerations: Circular economy, brand credibility, alignment with Green initiatives.  
- Risks: Waste mismanagement → fines or community backlash.

## Question 8 - Stakeholder Engagement  

- Quarterly community forums and co-design workshops.  
- Youth apprenticeships with schools.  
- Guest artist events and joint exhibitions with Katuaq.  
- Feedback via digital surveys and in-person comment boards.  
- Key considerations: Build ownership, deepen cultural connection, foster trust.  
- Risks: Exclusion → perception as external imposition → reduced participation.


# Distill Assumptions
# Workshop Project Plan

## Space Requirements

- Workshop: 120–150 m², modular layout  
- Kiln zone: 15 m², with ventilation and fire safety  
- Drying area: 30 m², climate-controlled  
- Worktables: 40 m² for students  
- Storage and admin: 20 m²  
- Open-studio seating: 12–16 people  

## Staffing & Scheduling

- Instructors: Rotating 4-week schedule  
- Weekly teaching load: 8–10 hours per instructor  
- Cross-training: All instructors cover all skill levels  
- Digital shift calendar: Real-time coordination  

## Budget Allocation (Year 1)

- Fit-out and equipment: 40%  
- Rent and utilities: 25%  
- Instructor salaries (4 × 15,000 DKK/month): 20%  
- Materials and supplies: 10%  
- Marketing and outreach: 5%  
- Contingency fund: 100,000 DKK (currency volatility)  

## Timeline

- Project start: 2026-Feb-15  
- Lease signed: Apr-30 (60 days)  
- Staff hired: May-15 (60 days)  
- Fit-out completed: Jul-31 (150 days)  
- First course: Aug-1 (100 days)  
- Three-week soft launch before public opening  

## Governance & Cultural Protocols

- Advisory council: Elders and artists  
- Traditional motifs: Written consent required  
- Exhibitions: Community review mandatory  

## Safety & Sustainability

- Mandatory safety training for all users  
- HEPA-filtered ventilation in kiln and drying zones  
- Fire extinguishers at every station  
- Emergency shutdown procedures: Posted and practiced  
- Clay dust control: Wet-mix techniques, sealed storage  
- Passive solar design: Reduces heating needs by 40%  
- Modular kilns: Operate only during scheduled sessions  
- Waste clay: Reclaimed and reused  
- Recycled packaging: For tourist kits  
- Compostable materials: Used in events  

## Community Engagement

- Quarterly community forums  
- Co-design workshops: Shape exhibitions and courses  
- Youth apprenticeships: Partner with local schools  
- Guest artist events: Foster cultural exchange  
- Feedback collection: Digital surveys and comment boards


# Review Assumptions
## Domain of the Expert Reviewer  
Community Arts & Sustainable Infrastructure Planning

## Domain-Specific Considerations  

- Arctic logistics and supply chain fragility  
- Cultural authenticity and Indigenous co-creation ethics  
- Energy efficiency in extreme climates  
- Part-time staffing sustainability in remote regions  
- Regulatory compliance with Greenlandic and Danish frameworks  

## Issue 1 – Missing Assumption: Climate-Driven Shipping Disruptions  
The plan assumes reliable quarterly shipments from Denmark but ignores Arctic weather risks (ice blockages, storms) that can delay transport by 6–12 weeks. Without contingency, material shortages may cause session cancellations and reputational harm.

Recommendation:  

- Maintain a 4-week buffer stock of clay (10% of annual volume) on-site  
- Pre-negotiate air freight contracts with Iceland Air or Nordic Cargo (max 72-hour transit)  
- Appoint a local logistics coordinator to monitor real-time Arctic shipping alerts via Danish Maritime Authority  
- Activate air freight if shipment delay exceeds 14 days  

Sensitivity:  

- A 4-week delay increases costs by 300,000–500,000 DKK due to missed sessions and emergency freight  
- ROI drops by 8–12% if summer tourism revenue is lost  

## Issue 2 – Missing Assumption: Liability Coverage for Volunteer Instructors  
Volunteer instructors (retired artists) lack formal insurance, training, or legal protection. In high-risk environments (kilns, heavy materials), untrained volunteers pose safety and legal threats.

Recommendation:  

- Require liability waivers and 4-hour mandatory safety training (fire, dust, equipment)  
- Purchase $500,000 general liability policy for volunteer-led activities  
- Allocate cost from 100,000 DKK contingency fund  
- Assign rotating 'Safety Officer' role among paid staff to supervise shifts  

Sensitivity:  

- One injury could incur 500,000–1,000,000 DKK in legal costs  
- ROI reduced by 15–20%; Year 1 budget at risk  

## Issue 3 – Under-Explored Assumption: Winter Energy Demand  
Passive solar and modular kilns are assumed sufficient, but peak winter usage (12–16 people simultaneously in sub-zero temps) may exceed thermal design capacity, risking system failure or unsafe conditions.

Recommendation:  

- Run dynamic thermal load simulation (e.g., EnergyPlus) at 90% winter occupancy  
- Upgrade insulation and add low-power radiant heater in drying zone  
- Enforce 'thermal curfew': 2-hour kiln sessions with 30-minute cooldowns  
- Deploy IoT sensors for real-time temperature/humidity monitoring  

Sensitivity:  

- 25% demand overrun raises utility costs by 100,000–150,000 DKK  
- System failure delays operations by 1–2 weeks, reducing ROI by 5–8%, increasing cancellation risk  

## Review Conclusion  
Success depends on addressing three critical gaps:  
1. Unmitigated shipping disruptions  
2. No liability coverage for volunteers  
3. Underestimated winter energy demand  

Concrete, measurable actions—emergency buffers, insurance protocols, thermal modeling—are essential to ensure financial viability, operational continuity, and community trust. Without them, even a strong 'Pragmatic Foundation' scenario faces high failure risk in Nuuk’s extreme environment.