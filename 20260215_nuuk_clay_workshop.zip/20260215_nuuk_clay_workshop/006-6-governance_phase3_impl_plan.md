### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee, including roles, responsibilities, decision rights, and meeting cadence based on the defined governance bodies.

**Responsible Body/Role:** Clay Workshop Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1
- Initial list of proposed members

**Dependencies:**

- Project Sponsor Identified
- Core Strategic Decisions Finalized (Pragmatic Foundation)
- Internal Governance Bodies Defined in 'governance-phase2-bodies.json'

### 2. Circulate Draft SteerCo ToR for review by nominated members (Head of Finance, Lead Instructor, Cultural Advisor, External Consultant) and collect feedback.

**Responsible Body/Role:** Clay Workshop Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary Report
- Revised ToR v0.2 incorporating input

**Dependencies:**

- Draft SteerCo ToR v0.1 completed
- Nominated Members List Available

### 3. Senior Sponsor formally appoints the Project Steering Committee Chair (Clay Workshop Manager) and confirms all committee members via official email or letter.

**Responsible Body/Role:** Senior Sponsor (Nuuk Municipality representative)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email
- Formal Membership List with Roles

**Dependencies:**

- Approved ToR v0.2 finalized
- All member confirmations received

### 4. Hold first formal meeting of the Project Steering Committee to adopt the final ToR, establish escalation protocols, and set initial bi-weekly meeting schedule.

**Responsible Body/Role:** Project Steering Committee (Chair: Clay Workshop Manager)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Minutes of First Meeting
- Final Adopted ToR v1.0
- Meeting Schedule (Feb–Jul 2026)

**Dependencies:**

- SteerCo Chair appointed
- Final ToR approved
- All members confirmed

### 5. Project Manager drafts initial Terms of Reference (ToR) for the Instructor Resilience Network, outlining responsibilities, decision rights, and meeting cadence.

**Responsible Body/Role:** Clay Workshop Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft IRN ToR v0.1
- Initial schedule template draft

**Dependencies:**

- Internal Governance Bodies Defined
- Instructor Scheduling Model Confirmed

### 6. Circulate Draft IRN ToR to all four part-time instructors and rotating Safety Officer for review and feedback.

**Responsible Body/Role:** Clay Workshop Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary from Instructors
- Revised IRN ToR v0.2

**Dependencies:**

- Draft IRN ToR v0.1 completed
- Instructors available for input

### 7. Project Steering Committee reviews and approves the final version of the Instructor Resilience Network ToR.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Approved IRN ToR v1.0
- Formal endorsement document

**Dependencies:**

- Revised IRN ToR v0.2 submitted
- SteerCo meeting scheduled

### 8. Hold first operational meeting of the Instructor Resilience Network to adopt the ToR, finalize the 4-week rotation schedule, and launch cross-training curriculum.

**Responsible Body/Role:** Instructor Resilience Network (Chair: Rotating Safety Officer)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Published Rotation Schedule (v1.0)
- Cross-Training Curriculum Released

**Dependencies:**

- IRN ToR approved
- All instructors confirmed
- Safety training materials ready

### 9. Project Manager drafts initial Terms of Reference (ToR) for the Cultural Anchoring & Compliance Oversight Group, focusing on consent protocols, audit processes, and review calendar.

**Responsible Body/Role:** Clay Workshop Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft CA&COG ToR v0.1
- Consent Protocol Checklist Draft

**Dependencies:**

- Internal Governance Bodies Defined
- Cultural Advisory Council Established

### 10. Circulate Draft CA&COG ToR to Cultural Advisor, Elder Representative, Artist Representative, and Legal/Compliance Officer for review.

**Responsible Body/Role:** Clay Workshop Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary
- Revised CA&COG ToR v0.2

**Dependencies:**

- Draft CA&COG ToR v0.1 completed
- Key members available

### 11. Project Steering Committee reviews and approves the final version of the Cultural Anchoring & Compliance Oversight Group ToR.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Approved CA&COG ToR v1.0
- Formal approval notice

**Dependencies:**

- Revised CA&COG ToR v0.2 submitted
- SteerCo meeting scheduled

### 12. Hold first formal meeting of the Cultural Anchoring & Compliance Oversight Group to adopt the ToR, establish review calendar, and begin training on cultural ethics and consent.

**Responsible Body/Role:** Cultural Anchoring & Compliance Oversight Group (Chair: Cultural Advisor)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Minutes of First Meeting
- Adopted Review Calendar (Q1–Q4 2026)
- Training Completion Records

**Dependencies:**

- CA&COG ToR approved
- All members confirmed
- Training materials prepared

### 13. Project Manager drafts initial Terms of Reference (ToR) for the Operational Risk & Audit Oversight Body, defining audit scope, procedures, and whistleblower mechanisms.

**Responsible Body/Role:** Clay Workshop Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft ORAOB ToR v0.1
- Audit Checklist Draft

**Dependencies:**

- Internal Governance Bodies Defined
- Whistleblower Portal Concept Approved

### 14. Circulate Draft ORAOB ToR to Internal Auditor, Safety Officer, and Independent Ethics Monitor for feedback.

**Responsible Body/Role:** Clay Workshop Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary
- Revised ORAOB ToR v0.2

**Dependencies:**

- Draft ORAOB ToR v0.1 completed
- Members available

### 15. Project Steering Committee reviews and approves the final version of the Operational Risk & Audit Oversight Body ToR.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Approved ORAOB ToR v1.0
- Formal endorsement document

**Dependencies:**

- Revised ORAOB ToR v0.2 submitted
- SteerCo meeting scheduled

### 16. Hold first operational meeting of the Operational Risk & Audit Oversight Body to adopt the ToR, assign audit leads, and launch the whistleblower portal and public dashboard.

**Responsible Body/Role:** Operational Risk & Audit Oversight Body (Chair: Internal Auditor)

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Whistleblower Portal Live
- Public Dashboard Launched
- First Audit Assignment Assigned

**Dependencies:**

- ORAOB ToR approved
- Portal and dashboard systems ready
- Audit team confirmed