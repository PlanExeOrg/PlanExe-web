
## Audit - Corruption Risks

- Bribery of local logistics coordinator to prioritize emergency air freight contracts with specific carriers, potentially inflating costs and favoring unqualified vendors.
- Nepotism in hiring part-time instructors by favoring relatives or friends without proper qualifications, undermining teaching quality and session continuity.
- Conflict of interest when selecting a Danish clay supplier if an instructor or advisor has a financial stake in the supplier company, leading to inflated prices or substandard materials.
- Kickbacks from equipment suppliers for inflated quotes on kilns or ventilation systems, resulting in budget overruns and poor-quality installations.
- Misuse of community consent processes by bypassing elders' approval for traditional motifs in exchange for personal favors or gifts, risking cultural misrepresentation and community backlash.

## Audit - Misallocation Risks

- Double spending on clay due to poor inventory tracking—ordering new shipments while still using buffer stock, leading to unnecessary freight costs and waste.
- Unplanned use of the contingency fund (100,000 DKK) for non-emergency purposes like marketing upgrades instead of covering currency volatility or supply delays.
- Over-allocation of time and effort toward co-design workshops and youth apprenticeships without clear capacity planning, causing staff burnout and reduced course delivery efficiency.
- Inefficient energy use from modular kilns operating outside scheduled times due to lack of monitoring or enforcement, increasing utility costs beyond projected 25% budget allocation.
- Misreporting of attendance or participation rates in community forums to justify continued funding or grant applications, distorting impact metrics and undermining transparency.

## Audit - Procedures

- Conduct quarterly internal audits of material inventory logs and purchase orders to verify alignment with shipment schedules and prevent double ordering or fraud.
- Perform bi-monthly financial reviews comparing actual expenses against the budget breakdown (e.g., rent, salaries, supplies) with a focus on identifying unauthorized expenditures.
- Carry out post-implementation audits after each major milestone (lease signed, fit-out completed, first course delivered) to assess compliance with project plan and risk mitigation actions.
- Implement a random spot-check audit of instructor shift records and cross-training documentation to ensure 100% session coverage and prevent scheduling gaps.
- Schedule an external audit at year-end by a certified Arctic-focused accounting firm specializing in community projects to validate financial statements, safety protocols, and cultural compliance.

## Audit - Transparency Measures

- Publish a public-facing dashboard showing real-time data on clay inventory levels, energy consumption (via IoT sensors), and session attendance to promote accountability and trust.
- Release quarterly reports in both Danish and Greenlandic detailing budget usage, supply chain performance, and community engagement outcomes to stakeholders and the public.
- Maintain and publish minutes from all advisory council meetings and co-design workshops, including decisions made and feedback received, ensuring inclusive decision-making is visible.
- Create a dedicated whistleblower portal accessible via QR codes at the workshop entrance where staff, volunteers, and visitors can report concerns anonymously and securely.
- Display a live-updating log of all instructor shifts, training completions, and safety drills on a digital screen in the common area, reinforcing operational integrity and team accountability.