**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic review and approval at a higher level.
Negative Consequences: Potential budget overruns and project delays due to insufficient funding or uncontrolled spending.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: The PMO cannot manage the risk with existing resources or approved plans, requiring strategic intervention and resource allocation.
Negative Consequences: Project failure, significant financial losses, and reputational damage due to unmanaged critical risks.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: The PMO is unable to reach a consensus on a key operational decision, requiring impartial arbitration and resolution at a higher level.
Negative Consequences: Project delays, increased costs, and potential legal disputes due to unresolved vendor selection issues.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: A significant change to the project scope impacts strategic objectives, budget, and timeline, requiring approval from the Project Steering Committee.
Negative Consequences: Misalignment with strategic goals, budget overruns, and project delays due to uncontrolled scope creep.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Project Steering Committee
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance with applicable laws and regulations.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust due to unethical behavior or non-compliance.

**Technical Design Change Request with Significant Cost Implications**
Escalation Level: Technical Advisory Group
Approval Process: Technical Advisory Group Review and Recommendation to PMO
Rationale: Ensures technical feasibility and compliance with industry standards while considering cost implications before PMO approval.
Negative Consequences: Compromised technical integrity, increased costs, and potential safety hazards due to poorly vetted design changes.