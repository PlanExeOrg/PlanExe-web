
## Audit - Corruption Risks

- Bribery of shipyard officials to overlook substandard work or expedite timelines.
- Kickbacks from suppliers of materials or equipment in exchange for inflated contracts.
- Conflicts of interest involving project team members with undisclosed financial ties to vendors.
- Misuse of confidential project information for personal gain or to benefit competing shipyards or suppliers.
- Trading favors with regulatory officials to bypass environmental or safety inspections.

## Audit - Misallocation Risks

- Inflated invoices from contractors or suppliers, with the excess funds diverted for personal use.
- Double-billing for services or materials, with the same expenses claimed multiple times.
- Inefficient allocation of resources, such as overspending on luxury amenities while neglecting essential safety equipment.
- Unauthorized use of project funds for personal travel, entertainment, or other non-project-related expenses.
- Misreporting project progress or results to conceal delays or cost overruns, leading to further misallocation of resources.

## Audit - Procedures

- Conduct periodic internal audits of all financial transactions, focusing on high-value contracts and expense reports (quarterly, internal audit team).
- Engage an independent external auditor to review project finances and compliance with regulations (annually, external audit firm).
- Implement a contract review process with multiple levels of approval for all contracts exceeding a specified threshold ($1 million, legal counsel and owner approval).
- Establish a detailed expense workflow with clear documentation requirements and approval limits (all expenses, project controller and project manager).
- Perform regular compliance checks to ensure adherence to international maritime laws, environmental regulations, and safety standards (monthly, compliance officer).

## Audit - Transparency Measures

- Create a project progress dashboard accessible to key stakeholders, including budget tracking, milestone completion, and risk assessments (real-time, project manager).
- Publish minutes of key project meetings, such as shipyard selection meetings and major design review sessions (monthly, project administrator).
- Establish a confidential whistleblower mechanism for reporting suspected fraud, corruption, or ethical violations (ongoing, independent ethics hotline).
- Make relevant project policies and reports, such as the environmental impact assessment and risk management plan, publicly available (upon request, project manager).
- Document the selection criteria and rationale for all major decisions, including shipyard selection, flag state registration, and key vendor appointments (ongoing, project manager).