This plan involves money.

## Currencies

- **EUR:** Potential shipyard locations in Germany, Netherlands, and Italy.
- **USD:** Project budget is defined in USD.

**Primary currency:** USD

**Currency strategy:** The project budget is in USD, which will be used for overall financial planning and reporting. EUR may be used for local transactions with shipyards in Europe. Given the scale of the project, hedging strategies should be considered to mitigate exchange rate fluctuations.