## Positive Constraints

- 180-meter luxury ice-class expedition yacht
- Budget: $500 million
- Timeline: 48 months
- Registered under a flag of convenience
- Permanent, mobile residence and operational headquarters
- Operating primarily in international waters
