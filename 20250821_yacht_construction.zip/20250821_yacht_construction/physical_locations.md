This plan implies one or more physical locations.

## Requirements for physical locations

- Shipyard with experience in ice-class vessels
- Capacity to handle a 180-meter yacht construction
- Access to deep water for launching
- Skilled labor force
- Proximity to suppliers of specialized materials

## Location 1
Germany

Hamburg

Blohm+Voss Shipyard

**Rationale**: Blohm+Voss has extensive experience in building large, luxury yachts and naval vessels, with facilities capable of handling a project of this scale. They are known for high-quality construction and advanced engineering.

## Location 2
Netherlands

Friesland

Feadship Shipyard

**Rationale**: Feadship is renowned for building custom luxury yachts of exceptional quality. Their facilities and skilled workforce are well-suited for constructing a high-end expedition yacht.

## Location 3
Italy

La Spezia

Sanlorenzo Superyacht

**Rationale**: Sanlorenzo is a leading builder of superyachts, with a dedicated division for large, custom projects. La Spezia offers deep-water access and a skilled workforce for yacht construction.

## Location Summary
The plan requires a shipyard capable of constructing a 180-meter luxury ice-class expedition yacht. Blohm+Voss in Hamburg, Germany, Feadship in Friesland, Netherlands, and Sanlorenzo Superyacht in La Spezia, Italy, are all well-equipped and experienced shipyards suitable for this project.