Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 14 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 5 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project involves building a yacht, which is within the realm of known physics and engineering.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan combines a luxury yacht, ice-class expedition capabilities, and use as a mobile business headquarters, a novel combination lacking independent evidence at comparable scale. There is no credible precedent for this specific system combination.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Project Manager: Deliver validation report / 90 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks definitions with business-level mechanisms-of-action, owners, and measurable outcomes for key strategic concepts like "tax optimization" and "mobile headquarters". The plan states goals but omits the inputs→process→customer value chain.

**Mitigation**: Strategic Planning Team: Create one-pagers for "tax optimization" and "mobile headquarters" defining value hypotheses, success metrics, owners, and decision hooks. Due: 60 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies several risks (regulatory, technical, financial, environmental, social, operational, security, supply chain) and mitigation plans. However, it lacks explicit analysis of risk cascades or second-order effects. For example, "Regulatory & Permitting" lists impacts but not cascades.

**Mitigation**: Risk Management Team: For each identified risk, map potential cascade effects and add controls to the risk register. Due: 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a permit/approval matrix and does not include authoritative permit lead times. The timeline assumes a 48-month completion, but there is no evidence that this is feasible given permitting requirements.

**Mitigation**: Project Manager: Create a permit/approval matrix with dated predecessors and authoritative lead times. Establish a NO-GO threshold on slip. Due: 60 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions securing multiple funding sources but does not name them or their status (LOI/term sheet/closed). There is no draw schedule or runway length calculation. The plan lacks evidence of committed funding.

**Mitigation**: CFO: Create a dated financing plan listing funding sources, status, draw schedule, covenants, and a NO-GO on missed financing gates. Due: 30 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget conflicts with the need for scale-appropriate benchmarks and omits contingency. No vendor quotes or comparables are provided to substantiate the budget.

**Mitigation**: Owner: Benchmark against at least three relevant comparables, obtain vendor quotes, normalize costs per area, and adjust budget or de-scope by 30 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents the 48-month completion date as a single number without providing a range or discussing alternative scenarios. There is no sensitivity analysis or discussion of best/worst-case scenarios for the timeline.

**Mitigation**: Project Manager: Conduct a best/worst/base-case scenario analysis for the project timeline, identifying key drivers and potential delays. Due: 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for build-critical components. There are no technical specifications, interface definitions, test plans, or an integration map. The plan does not describe the engineering process.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for all build-critical components. Due: 90 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan states "registered under a flag of convenience for tax and legal optimization" but lacks evidence of legal review. There is no legal opinion letter or compliance checklist.

**Mitigation**: Legal Team: Obtain a legal opinion letter assessing the risks and benefits of the chosen flag state. Due: 30 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "a mobile residence and operational headquarters" without defining specific, verifiable qualities. The plan lacks SMART criteria for the mobile headquarters deliverable.

**Mitigation**: Project Team: Define SMART criteria for the mobile headquarters, including a KPI for operational uptime (e.g., 90% availability). Due: 30 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'Ancillary Vessel Integration' (e.g., tenders, submarines, helicopters). This feature does not directly support the core goals of tax optimization or establishing a mobile business headquarters.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of ancillary vessel integration, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog. Due: 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies the 'Naval Architect & Marine Engineer Team' as critical but does not validate the talent market for ice-class expertise. The plan states, "addressing the complexity of the ice-class requirements," but lacks evidence of talent availability.

**Mitigation**: HR: Validate the availability of naval architects with ice-class vessel design experience by surveying the talent market. Due: 60 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a permit/approval matrix and does not include authoritative permit lead times. The timeline assumes a 48-month completion, but there is no evidence that this is feasible given permitting requirements.

**Mitigation**: Project Manager: Create a permit/approval matrix with dated predecessors and authoritative lead times. Establish a NO-GO threshold on slip. Due: 60 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions long-term sustainability risks but lacks a concrete operational sustainability plan. The plan states, "Sustainability risks: operating costs, regulations, resale value," but does not detail mitigation.

**Mitigation**: CFO: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession plan, technology roadmap, and adaptation mechanisms. Due: 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan does not explicitly address zoning/land-use restrictions, occupancy/egress requirements, fire load limits, structural limits, or noise ordinances at potential shipyard locations. The plan lists potential shipyards but lacks constraint validation.

**Mitigation**: Project Manager: Perform a fatal-flaw screen with authorities/experts for zoning, occupancy, fire, structural, and noise at candidate shipyards. Define NO-GO thresholds. Due: 60 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "Shipyard Selection" but lacks evidence of contracts/SLAs with shipyards or tested failovers. The plan states, "Prioritize shipyards with proven experience," but does not discuss redundancy or continuity.

**Mitigation**: Legal Team: Secure SLAs with the selected shipyard, including clauses for business continuity and disaster recovery. Due: 90 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the Finance Department is incentivized by budget adherence, while the Owner is incentivized by tax optimization and operational efficiency. These incentives conflict when tax strategies increase upfront costs.

**Mitigation**: CFO and Owner: Define a shared OKR focused on maximizing after-tax ROI over 5 years, aligning incentives on long-term financial performance. Due: 30 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Establish a monthly project review with a KPI dashboard, a lightweight change board, and escalation procedures. Due: 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies several high risks (regulatory, financial, security, environmental, technical) but lacks a cross-impact analysis. A regulatory change could trigger financial penalties and technical rework, creating a multi-domain failure.

**Mitigation**: Risk Management Team: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Due: 90 days.