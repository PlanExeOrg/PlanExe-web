A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The shipyard labor force will remain consistently available and skilled throughout the project. | Contact the selected shipyard and obtain a written guarantee of labor availability and skill levels for the duration of the project, including specific numbers of qualified welders, engineers, and electricians. | The shipyard is unable to provide a written guarantee, or the guarantee indicates potential shortages in key skill areas. |
| A2 | The chosen flag state will maintain a stable regulatory environment throughout the project's lifespan. | Engage a maritime law expert to assess the historical regulatory stability of the chosen flag state and identify any pending or anticipated regulatory changes. | The maritime law expert identifies a history of frequent regulatory changes or anticipates significant changes in the near future that could impact the yacht's operation. |
| A3 | Advanced wastewater treatment and waste management systems will reliably meet or exceed all environmental regulations. | Obtain detailed performance specifications and independent certification data for the selected wastewater treatment and waste management systems, verifying their ability to meet or exceed all relevant environmental regulations under realistic operating conditions. | The performance specifications or certification data indicate that the systems may not consistently meet all environmental regulations, or that their performance is highly sensitive to operating conditions. |
| A4 | The yacht's design will effectively balance luxury amenities with operational functionality, meeting the owner's expectations for both comfort and business use. | Conduct a detailed review of the interior design plans with the owner, focusing on the trade-offs between luxury amenities and operational space, and obtain their explicit approval of the design. | The owner expresses significant dissatisfaction with the proposed balance between luxury and functionality, or requests major design changes that would impact the yacht's operational capabilities. |
| A5 | The selected shipyard will effectively manage its supply chain, ensuring timely delivery of all necessary materials and equipment. | Conduct a thorough assessment of the shipyard's supply chain management capabilities, including their relationships with key suppliers, their inventory management systems, and their contingency plans for potential disruptions. | The shipyard demonstrates weaknesses in its supply chain management capabilities, or is unable to provide adequate assurances of timely delivery of critical materials and equipment. |
| A6 | The crew will be readily available and adequately trained to operate all of the yacht's systems, including advanced technologies and security protocols. | Conduct a comprehensive assessment of the available crew pool, including their experience, qualifications, and training needs, and develop a detailed crew training plan that addresses any identified gaps. | The available crew pool lacks the necessary skills and experience to operate the yacht's systems effectively, or the cost of providing adequate training is prohibitively high. |
| A7 | The chosen shipyard will maintain consistent quality control throughout the construction process, adhering to the highest standards of craftsmanship and precision. | Conduct regular, unannounced inspections of the shipyard's facilities and work in progress, focusing on quality control procedures, material handling, and adherence to design specifications. | The inspections reveal significant deviations from quality control standards, substandard workmanship, or improper handling of materials. |
| A8 | The yacht's operational routes will remain accessible and navigable, without significant disruptions from geopolitical events, environmental hazards, or regulatory restrictions. | Conduct a thorough risk assessment of the planned operational routes, considering potential geopolitical hotspots, environmental risks (e.g., ice conditions, piracy), and regulatory restrictions (e.g., port access, environmental regulations). | The risk assessment identifies significant and unavoidable risks that would severely limit the yacht's operational capabilities or pose unacceptable safety hazards. |
| A9 | The owner's personal brand and reputation will benefit from the yacht project, enhancing their business interests and public image. | Conduct a market research study to assess the potential impact of the yacht project on the owner's brand and reputation, considering factors such as public perception, media coverage, and stakeholder sentiment. | The market research indicates that the yacht project is likely to have a negative or neutral impact on the owner's brand and reputation, or that it could generate significant controversy or criticism. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Shipyard Squeeze | Process/Financial | A1 | Project Manager | CRITICAL (16/25) |
| FM2 | The Regulatory Reef | Technical/Logistical | A2 | Flag State & Regulatory Compliance Specialist | CRITICAL (15/25) |
| FM3 | The Greenwash Gambit | Market/Human | A3 | Sustainability & Environmental Impact Officer | HIGH (10/25) |
| FM4 | The Gilded Cage | Process/Financial | A4 | Project Manager | HIGH (12/25) |
| FM5 | The Supply Chain Snarl | Technical/Logistical | A5 | Supply Chain & Logistics Coordinator | CRITICAL (20/25) |
| FM6 | The Unskilled Armada | Market/Human | A6 | Crew Training Manager | CRITICAL (15/25) |
| FM7 | The Cracks Beneath the Surface | Technical/Logistical | A7 | Naval Architect | CRITICAL (15/25) |
| FM8 | The Voyage Interrupted | Market/Human | A8 | Risk Management & Security Consultant | CRITICAL (16/25) |
| FM9 | The Tarnished Image | Process/Financial | A9 | Public Relations Manager | HIGH (10/25) |


### Failure Modes

#### FM1 - The Shipyard Squeeze

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The shipyard's labor force, initially projected to be stable, experiences a sudden and significant shortage of skilled welders due to a competing project offering higher wages. This shortage leads to delays in hull construction, impacting the project timeline. The shipyard demands a higher price to retain existing welders and attract new ones, leading to cost overruns. The project manager attempts to negotiate, but the shipyard leverages its position as the sole provider with ice-class experience. The delays cascade through subsequent phases, impacting interior outfitting and system integration. The project is forced to accept the higher costs to avoid further delays, significantly impacting the overall budget.

##### Early Warning Signs
- Shipyard reports a sudden increase in employee turnover.
- Hull construction progress falls behind schedule by more than 5%.
- Shipyard requests a change order for increased labor costs.

##### Tripwires
- Hull construction is delayed by >= 30 days.
- Shipyard requests a change order exceeding 10% of the original contract value.
- Welder turnover rate at the shipyard exceeds 15% in a single month.

##### Response Playbook
- Contain: Immediately negotiate a revised contract with the shipyard, including performance-based incentives and penalties for further delays.
- Assess: Conduct a thorough assessment of the impact of the delays on the overall project timeline and budget.
- Respond: Explore alternative shipyards, even if less experienced with ice-class vessels, to potentially transfer the project and mitigate further delays and cost overruns.


**STOP RULE:** Total project cost exceeds $600 million due to shipyard-related delays and cost overruns.

---

#### FM2 - The Regulatory Reef

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Flag State & Regulatory Compliance Specialist
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
After the yacht is nearing completion, the chosen flag state enacts a series of unexpected and stringent new environmental regulations, driven by international pressure. These regulations mandate significant modifications to the yacht's waste management and emissions control systems, requiring extensive retrofitting. The required technologies are not readily available, leading to supply chain bottlenecks and further delays. The yacht is unable to obtain the necessary certifications to operate legally, stranding it in port. The owner faces mounting operational costs and reputational damage, as the yacht cannot fulfill its intended purpose as a mobile headquarters. The project team scrambles to find compliant solutions, but the timeline is severely impacted, and the yacht remains unusable.

##### Early Warning Signs
- International maritime organizations issue warnings about potential regulatory changes.
- The chosen flag state announces a review of its environmental regulations.
- Key suppliers of environmental technologies report long lead times for new orders.

##### Tripwires
- New environmental regulations from the flag state require modifications costing >= $10 million.
- The yacht is unable to obtain necessary certifications within 6 months of the original target date.
- Lead times for required environmental technologies exceed 12 months.

##### Response Playbook
- Contain: Immediately halt all non-essential work on the yacht to focus on addressing the regulatory changes.
- Assess: Conduct a thorough assessment of the impact of the new regulations on the yacht's design, systems, and operational capabilities.
- Respond: Explore alternative flag states with more stable regulatory environments, even if it means sacrificing some tax benefits.


**STOP RULE:** The yacht cannot be certified to operate legally within 12 months of the original target date due to regulatory issues.

---

#### FM3 - The Greenwash Gambit

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Sustainability & Environmental Impact Officer
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
Despite claims of advanced wastewater treatment, the yacht's systems fail to consistently meet environmental regulations in practice. A series of high-profile incidents involving illegal waste discharge are leaked to the media, sparking public outrage and accusations of 'greenwashing.' Environmental groups launch boycotts, and potential business partners withdraw their support. The yacht's reputation is severely tarnished, making it difficult to attract clients or secure permits for operation in environmentally sensitive areas. The owner faces intense public scrutiny and legal challenges, undermining the yacht's intended purpose as a symbol of responsible global leadership. The project becomes a public relations disaster, damaging the owner's brand and business interests.

##### Early Warning Signs
- Independent audits reveal inconsistencies in wastewater treatment system performance.
- Environmental monitoring data indicates elevated levels of pollutants in the yacht's wake.
- Negative media coverage begins to surface regarding the yacht's environmental practices.

##### Tripwires
- Independent audits reveal that wastewater discharge exceeds regulatory limits by >= 10%.
- The yacht receives a formal warning from environmental authorities for non-compliance.
- Social media sentiment analysis indicates a >= 20% increase in negative mentions related to the yacht's environmental impact.

##### Response Playbook
- Contain: Immediately suspend all operations in environmentally sensitive areas and launch a full investigation into the wastewater treatment system failures.
- Assess: Conduct a thorough assessment of the extent of the environmental damage and the potential legal and reputational consequences.
- Respond: Publicly acknowledge the failures, commit to implementing corrective actions, and engage with environmental groups to rebuild trust and demonstrate a genuine commitment to sustainability.


**STOP RULE:** The yacht's environmental reputation is so severely damaged that it cannot secure necessary permits to operate in key regions, rendering it unusable for its intended purpose.

---

#### FM4 - The Gilded Cage

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Project Manager
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The owner, initially enthusiastic about a balanced design, becomes increasingly focused on luxury amenities during the interior outfitting phase. They demand the addition of a large spa, a private cinema, and an expanded art gallery, significantly reducing the space available for business operations and scientific equipment. The project team attempts to push back, but the owner insists, citing their personal preferences and the need to impress potential clients. The resulting yacht is lavishly appointed but lacks the functionality required for a mobile headquarters. Business operations are hampered by limited office space, inadequate communication systems, and a lack of privacy. The yacht becomes a floating palace, but fails to fulfill its intended purpose, leading to financial losses and owner dissatisfaction.

##### Early Warning Signs
- The owner requests significant changes to the interior design plans after initial approval.
- The project team reports increasing conflicts between the owner's desires and the yacht's operational requirements.
- The cost of interior outfitting exceeds the original budget by more than 15%.

##### Tripwires
- The area allocated to business operations is reduced by >= 20% compared to the original design.
- The cost of luxury amenities exceeds the budget allocation by >= 25%.
- The owner expresses dissatisfaction with the functionality of the yacht's business systems.

##### Response Playbook
- Contain: Immediately halt all further changes to the interior design and convene a meeting with the owner to discuss the impact of their requests on the yacht's operational capabilities.
- Assess: Conduct a thorough assessment of the impact of the design changes on the yacht's functionality, cost, and timeline.
- Respond: Present the owner with a revised design that balances luxury amenities with operational requirements, and negotiate a compromise that meets their needs while preserving the yacht's intended purpose.


**STOP RULE:** The yacht's functionality as a mobile headquarters is so severely compromised that it cannot effectively support business operations, rendering it a purely recreational vessel.

---

#### FM5 - The Supply Chain Snarl

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Supply Chain & Logistics Coordinator
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The shipyard, despite initial assurances, proves unable to effectively manage its supply chain. A series of unforeseen events, including supplier bankruptcies, transportation delays, and customs clearance issues, disrupt the delivery of critical materials and equipment. The construction timeline is severely impacted, leading to delays in hull construction, system integration, and interior outfitting. The project team scrambles to find alternative suppliers, but the delays continue to mount, and the cost of materials and equipment increases significantly. The yacht is eventually completed, but it is months behind schedule and significantly over budget, undermining its financial viability and operational readiness.

##### Early Warning Signs
- Key suppliers report financial difficulties or production delays.
- Shipments of critical materials are delayed or lost in transit.
- The shipyard experiences difficulties with customs clearance or import regulations.

##### Tripwires
- Delivery of critical materials is delayed by >= 60 days.
- The cost of materials and equipment exceeds the original budget by >= 20%.
- The shipyard reports a significant increase in supply chain disruptions.

##### Response Playbook
- Contain: Immediately activate contingency plans to secure alternative suppliers and expedite the delivery of critical materials and equipment.
- Assess: Conduct a thorough assessment of the impact of the supply chain disruptions on the project timeline and budget.
- Respond: Renegotiate contracts with existing suppliers, explore alternative transportation routes, and implement stricter inventory management controls to mitigate further disruptions.


**STOP RULE:** The project is delayed by more than 12 months due to supply chain disruptions, rendering it financially unviable.

---

#### FM6 - The Unskilled Armada

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Crew Training Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Despite initial optimism, the available crew pool proves to be inadequately trained to operate the yacht's advanced systems and security protocols. A series of near-miss incidents and security breaches reveal critical skill gaps and a lack of preparedness. The project team attempts to provide additional training, but the crew struggles to master the complex technologies and procedures. The yacht's operational efficiency and security are severely compromised, making it difficult to attract clients or operate safely in remote areas. The owner faces reputational damage and potential legal liabilities, undermining the yacht's intended purpose as a symbol of responsible global leadership. The project becomes a cautionary tale of technological ambition outpacing human capabilities.

##### Early Warning Signs
- Crew members demonstrate a lack of understanding of the yacht's advanced systems and security protocols.
- Simulated emergency drills reveal significant deficiencies in crew performance.
- The yacht experiences a series of near-miss incidents or security breaches.

##### Tripwires
- Crew members fail to pass competency assessments for critical systems by >= 20%.
- The yacht experiences a security breach that compromises sensitive data.
- The yacht is involved in a near-miss incident due to crew error.

##### Response Playbook
- Contain: Immediately suspend all non-essential operations and implement a comprehensive retraining program for the crew, focusing on critical systems and security protocols.
- Assess: Conduct a thorough assessment of the crew's skills and identify specific training needs.
- Respond: Recruit additional crew members with the necessary skills and experience, and implement stricter screening procedures to ensure future crew competency.


**STOP RULE:** The crew's lack of skills and training poses an unacceptable risk to the safety and security of the yacht, rendering it unusable for its intended purpose.

---

#### FM7 - The Cracks Beneath the Surface

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Naval Architect
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Despite initial assurances, the shipyard's quality control falters during the later stages of construction. Substandard welding, improper material handling, and deviations from design specifications go unnoticed, leading to structural weaknesses in the hull and critical systems. During sea trials, these weaknesses manifest as leaks, vibrations, and system malfunctions. The yacht requires extensive and costly repairs, delaying its delivery and compromising its long-term reliability. The owner loses confidence in the shipyard, and the project is plagued by ongoing maintenance issues and safety concerns. The yacht, once envisioned as a symbol of excellence, becomes a source of frustration and disappointment.

##### Early Warning Signs
- Increased reports of welding defects or material inconsistencies during construction.
- Delays in inspections or rework requests due to quality control issues.
- A decline in the shipyard's overall safety record or customer satisfaction ratings.

##### Tripwires
- Inspection failure rate exceeds 10% during hull construction.
- Rework requests increase by >= 15% compared to the initial design specifications.
- Significant structural defects are discovered during sea trials.

##### Response Playbook
- Contain: Immediately halt all further construction and conduct a comprehensive audit of the shipyard's quality control procedures.
- Assess: Conduct a thorough assessment of the extent of the structural damage and the potential impact on the yacht's long-term reliability.
- Respond: Implement stricter quality control measures, including independent inspections and enhanced training for shipyard workers, and renegotiate the contract with the shipyard to ensure accountability and compensation for the defects.


**STOP RULE:** The structural integrity of the hull is so severely compromised that the yacht cannot be certified for safe operation, rendering it unusable for its intended purpose.

---

#### FM8 - The Voyage Interrupted

- **Archetype**: Market/Human
- **Root Cause**: Assumption A8
- **Owner**: Risk Management & Security Consultant
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The yacht, designed for global exploration, encounters a series of unforeseen obstacles that severely limit its operational capabilities. Geopolitical tensions escalate in key regions, leading to restricted access and increased security risks. Environmental regulations become more stringent, prohibiting operation in sensitive areas. A surge in piracy incidents forces the yacht to reroute its planned voyages, significantly reducing its appeal to potential clients and limiting its ability to serve as a mobile headquarters. The owner faces mounting operational costs and reputational damage, as the yacht cannot fulfill its intended purpose. The project becomes a symbol of overambition and unrealistic expectations.

##### Early Warning Signs
- Increased geopolitical instability in planned operational areas.
- New or stricter environmental regulations are implemented in key regions.
- A rise in piracy incidents along planned shipping routes.

##### Tripwires
- Planned operational routes are restricted by geopolitical events for >= 30 days.
- New environmental regulations prohibit operation in >= 2 key regions.
- Piracy incidents increase by >= 25% along planned shipping routes.

##### Response Playbook
- Contain: Immediately reroute the yacht to safer and more accessible regions, and implement enhanced security measures to protect against potential threats.
- Assess: Conduct a thorough assessment of the impact of the operational restrictions on the yacht's financial viability and strategic goals.
- Respond: Diversify the yacht's operational focus to include alternative activities, such as scientific research or disaster relief, that are less dependent on specific geographic locations.


**STOP RULE:** The yacht's operational capabilities are so severely limited by external factors that it cannot effectively serve as a mobile headquarters or generate sufficient revenue to justify its continued operation.

---

#### FM9 - The Tarnished Image

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Public Relations Manager
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The yacht project, intended to enhance the owner's brand and reputation, backfires spectacularly. Negative media coverage focuses on the yacht's extravagance, environmental impact, and perceived tax avoidance strategies. Public perception turns sharply negative, leading to boycotts of the owner's businesses and a decline in their overall brand value. Potential business partners withdraw their support, and the owner faces increased scrutiny from regulatory authorities. The yacht, once envisioned as a symbol of success, becomes a liability, damaging the owner's reputation and undermining their business interests. The project serves as a cautionary tale of the risks of conspicuous consumption and the importance of ethical business practices.

##### Early Warning Signs
- Negative media coverage begins to surface regarding the yacht's cost, environmental impact, or tax strategies.
- Social media sentiment analysis indicates a significant increase in negative mentions related to the owner's brand.
- Potential business partners express concerns about the yacht project's impact on the owner's reputation.

##### Tripwires
- Negative media coverage reaches a critical threshold, triggering a public relations crisis.
- Social media sentiment analysis indicates a >= 30% decline in positive mentions related to the owner's brand.
- Key business partners withdraw their support due to reputational concerns.

##### Response Playbook
- Contain: Immediately launch a public relations campaign to address the negative media coverage and highlight the project's positive aspects, such as its commitment to sustainability and community engagement.
- Assess: Conduct a thorough assessment of the damage to the owner's brand and reputation, and identify specific areas of concern.
- Respond: Implement stricter ethical guidelines for all business activities, and engage with stakeholders to rebuild trust and demonstrate a genuine commitment to responsible corporate citizenship.


**STOP RULE:** The damage to the owner's brand and reputation is so severe that it significantly undermines their business interests, rendering the yacht project a financial and reputational disaster.
