### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance for this high-value, high-risk project, ensuring alignment with the owner's objectives and managing strategic risks.

**Responsibilities:**

- Approve overall project strategy and objectives.
- Approve major project milestones and deliverables.
- Approve budget revisions exceeding $5 million.
- Oversee strategic risk management and mitigation.
- Resolve strategic conflicts and escalate issues as needed.
- Monitor project performance against strategic goals.

**Initial Setup Actions:**

- Finalize Terms of Reference and operating procedures.
- Appoint Chair and define reporting lines.
- Establish communication protocols with other governance bodies.
- Review and approve initial project plan and budget.

**Membership:**

- Owner (Chair)
- Project Manager
- Legal Counsel
- Financial Advisor
- Independent Maritime Expert

**Decision Rights:** Strategic decisions related to project scope, budget (above $5 million), timeline, and risk management.

**Decision Mechanism:** Decisions made by majority vote, with the Owner holding the tie-breaking vote. Dissenting opinions are documented.

**Meeting Cadence:** Quarterly, or more frequently as needed for critical decisions or issue resolution.

**Typical Agenda Items:**

- Review of project progress against strategic goals.
- Discussion and approval of major milestones.
- Review of strategic risks and mitigation plans.
- Approval of budget revisions exceeding $5 million.
- Discussion of any strategic issues or conflicts.

**Escalation Path:** Unresolved issues or conflicts are escalated to the Owner for final decision.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day project execution, ensuring adherence to budget, timeline, and quality standards. Provides operational risk management and support to the Project Manager.

**Responsibilities:**

- Develop and maintain project plans, schedules, and budgets.
- Monitor project progress and performance against plan.
- Manage operational risks and issues.
- Coordinate project activities across different teams and stakeholders.
- Ensure adherence to project management standards and best practices.
- Report project status to the Project Steering Committee.

**Initial Setup Actions:**

- Establish project management standards and procedures.
- Develop project communication plan.
- Set up project tracking and reporting systems.
- Recruit and train PMO staff.

**Membership:**

- Project Manager (Head of PMO)
- Project Controller
- Risk Manager
- Quality Assurance Manager
- Communications Manager

**Decision Rights:** Operational decisions related to project execution, budget (below $5 million), timeline adjustments within approved tolerances, and risk mitigation.

**Decision Mechanism:** Decisions made by the Project Manager, with input from PMO staff. Significant deviations from plan are escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly, or more frequently as needed for critical issues.

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of operational risks and issues.
- Review of budget and schedule performance.
- Coordination of project activities.
- Preparation of reports for the Project Steering Committee.

**Escalation Path:** Issues exceeding the Project Manager's authority or impacting strategic goals are escalated to the Project Steering Committee.
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides expert technical advice and assurance on critical aspects of the yacht's design, construction, and operation, ensuring technical feasibility and compliance with industry standards.

**Responsibilities:**

- Review and approve technical specifications and designs.
- Provide technical guidance on complex engineering challenges.
- Assess the technical feasibility of proposed solutions.
- Monitor the quality of construction and installation.
- Ensure compliance with relevant technical standards and regulations.
- Advise on the selection of key technical vendors and suppliers.

**Initial Setup Actions:**

- Define scope of technical expertise required.
- Identify and recruit qualified technical experts.
- Establish communication protocols with the PMO and Project Steering Committee.
- Review initial technical specifications and designs.

**Membership:**

- Naval Architect
- Marine Engineer
- Electrical Engineer
- Cybersecurity Expert
- Independent Maritime Surveyor

**Decision Rights:** Technical approval of designs, specifications, and vendor selections. Recommendations on technical risks and mitigation strategies.

**Decision Mechanism:** Decisions made by consensus of the Technical Advisory Group. Dissenting opinions are documented and escalated to the Project Steering Committee if necessary.

**Meeting Cadence:** Monthly, or more frequently as needed for critical technical reviews.

**Typical Agenda Items:**

- Review of technical specifications and designs.
- Discussion of complex engineering challenges.
- Assessment of technical risks and mitigation strategies.
- Review of construction and installation quality.
- Discussion of compliance with technical standards and regulations.

**Escalation Path:** Technical issues that cannot be resolved within the Technical Advisory Group or that have strategic implications are escalated to the Project Steering Committee.
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures ethical conduct and compliance with all applicable laws and regulations, including GDPR, environmental regulations, and anti-corruption laws. Provides assurance to the Owner and stakeholders that the project is being conducted in a responsible and ethical manner.

**Responsibilities:**

- Develop and implement an ethics and compliance program.
- Monitor compliance with all applicable laws and regulations.
- Investigate allegations of ethical violations or non-compliance.
- Provide training on ethics and compliance to project staff.
- Ensure compliance with GDPR and other data privacy regulations.
- Oversee environmental compliance and sustainability initiatives.
- Monitor and mitigate corruption risks.

**Initial Setup Actions:**

- Develop an ethics and compliance policy.
- Establish a confidential reporting mechanism for ethical violations.
- Conduct a risk assessment to identify key compliance risks.
- Develop a training program on ethics and compliance.

**Membership:**

- Legal Counsel (Chair)
- Compliance Officer
- Data Protection Officer
- Environmental Compliance Officer
- Independent Ethics Advisor

**Decision Rights:** Authority to investigate ethical violations and non-compliance. Recommendations on corrective actions and policy changes. Approval of ethics and compliance training programs.

**Decision Mechanism:** Decisions made by majority vote, with the Legal Counsel holding the tie-breaking vote. Dissenting opinions are documented.

**Meeting Cadence:** Monthly, or more frequently as needed for investigations or urgent compliance matters.

**Typical Agenda Items:**

- Review of compliance with applicable laws and regulations.
- Discussion of ethical issues and concerns.
- Investigation of alleged ethical violations or non-compliance.
- Review of ethics and compliance training programs.
- Review of environmental compliance and sustainability initiatives.
- Review of corruption risks and mitigation measures.

**Escalation Path:** Serious ethical violations or non-compliance issues are escalated to the Owner and the Project Steering Committee.