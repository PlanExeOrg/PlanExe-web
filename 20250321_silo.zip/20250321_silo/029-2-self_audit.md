Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 15 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 4 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project involves engineering and ecological technologies, which are within the realm of known physics. There is no mention of physics-defying concepts.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan combines multiple novel elements (product, market, tech/process, policy) without sufficient real-world evidence at a comparable scale. The plan aims to create a completely self-sustaining underground complex, a combination lacking independent validation. Failure would be existential.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Each track must produce one authoritative source or a supervised pilot showing results vs a baseline. Define NO-GO gates. Owner: Project Lead / Validation Report / Q4 2025


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks definitions of key strategic concepts driving the project. The "Consolidator's Fortress" scenario is chosen, but its mechanism-of-action (inputs→process→customer value), owner, and measurable outcomes are undefined.

**Mitigation**: Project Lead: Create one-pagers for each strategic concept (e.g., Consolidator's Fortress) defining the value hypothesis, success metrics, owner, and decision hooks by Q3 2025.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the risk register minimizes major hazard classes. The plan identifies risks like regulatory delays, technical challenges, and financial risks, but lacks explicit analysis of cascading failures (e.g., permit delay → resource depletion).

**Mitigation**: Risk Management: Expand the risk register to explicitly map cascading failures and add controls with a dated review cadence by Q2 2025.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the timeline for initial habitable floors (20 years) is optimistic given the scale and complexity. Expert review notes: "A 50-year construction timeline for a project of this scale is overly optimistic."

**Mitigation**: Project Manager: Rebuild the critical path with dated predecessors, authoritative permit lead times, and a NO-GO threshold on slip by Q2 2025.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not include a financing plan listing sources/status, draw schedule, or covenants. The plan states, "$500 billion USD (60% government, 40% private)" but lacks details on funding commitments or draw schedules.

**Mitigation**: CFO: Develop a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO-GO on missed financing gates by Q2 2025.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget lacks substantiation against scale-appropriate benchmarks or vendor quotes. The plan assumes "$500 billion USD" without normalizing by area or providing supporting evidence.

**Mitigation**: CFO: Benchmark (≥3), obtain quotes, normalize per-area (cost per m²/ft²), and adjust budget or de-scope by Q3 2025.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., completion dates) as single numbers without providing a range or discussing alternative scenarios. The SMART criteria state: "The project is expected to be completed within 50 years..."

**Mitigation**: Project Manager: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the 50-year completion projection by Q3 2025.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because build‑critical components lack engineering artifacts. The plan mentions "advanced surveillance technology" and "life support systems" but lacks technical specifications, interface definitions, test plans, or an integration map.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components by Q4 2025.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes critical claims without verifiable artifacts. The plan states, "The project is expected to be completed within 50 years, with initial habitable floors ready in 20 years" but lacks evidence of permits.

**Mitigation**: Project Lead: Obtain preliminary commitments from regulatory bodies regarding permit feasibility and timelines, or de-scope the project, by Q4 2024.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project's final outputs are poorly defined. The plan mentions "a fully functional and self-sustaining underground habitat" without specific, verifiable qualities.

**Mitigation**: Engineering Team: Define SMART acceptance criteria for the underground habitat, including a KPI for ecosystem self-sufficiency (e.g., 95% internal resource production) by Q2 2025.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes the feature of "hereditary leadership structure" which does not directly support the core project goals of long-term survival and societal continuity. It may stifle innovation.

**Mitigation**: Governance Council: Produce a one-page benefit case justifying the inclusion of hereditary leadership, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog by Q3 2024.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a "Security Systems Architect" to design and implement advanced surveillance and security systems. This role is critical for maintaining order and preventing external threats, and requires rare expertise.

**Mitigation**: HR: Validate the talent market for Security Systems Architects with experience in large-scale, high-security infrastructure projects by Q2 2025.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because legality is unclear and required approvals are unmapped. The plan mentions "Building Permit, Environmental Impact Permit, Hazardous Materials Handling Permit, Underground Construction Permit" but lacks a regulatory matrix.

**Mitigation**: Legal Team: Create a regulatory matrix (authority, artifact, lead time, predecessors) for all permits and licenses by Q3 2024.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions long-term sustainability but lacks specifics on operational costs, maintenance, and technology obsolescence. The plan states, "Ensure long-term sustainability through responsible resource management" but lacks a detailed operational sustainability plan.

**Mitigation**: Sustainability Strategist: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession planning, and technology roadmap by Q4 2025.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions permits but lacks specifics. The plan lists "Building Permit, Environmental Impact Permit..." but does not address zoning/land-use, occupancy/egress, fire load, structural limits, or noise constraints.

**Mitigation**: Legal Team: Perform a fatal-flaw screen with authorities/experts to identify zoning/land-use, occupancy/egress, fire load, structural limits, and noise constraints within 90 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions external dependencies but lacks details on vendor contracts, SLAs, or tested failover plans. The plan states, "Securing a reliable supply chain is crucial" but lacks specifics on vendor management.

**Mitigation**: Supply Chain Manager: Secure SLAs with key vendors, add a secondary supplier/path for critical resources, and test failover procedures by Q3 2025.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan states goals for stakeholders but does not address conflicting incentives. The 'Governance Council' wants social order, while 'Residents' want individual rights, creating a conflict over control. The plan lacks a shared objective.

**Mitigation**: Governance Council: Define a shared, measurable objective (OKR) that aligns both the Governance Council and Residents on a common outcome, such as a 'Social Harmony Index' by Q2 2025.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a change-control process. The plan mentions "Provide regular updates and progress reports to primary stakeholders" but lacks specifics.

**Mitigation**: Project Manager: Add a monthly review with a KPI dashboard and a lightweight change board with thresholds (when to re-plan/stop) by Q2 2025.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has ≥3 High risks that are strongly coupled. Technical challenges (Risk 2), Financial risks (Risk 3), and Social risks (Risk 5) are coupled. Technical failures can cause cost overruns and social unrest.

**Mitigation**: Risk Management: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by Q3 2025.