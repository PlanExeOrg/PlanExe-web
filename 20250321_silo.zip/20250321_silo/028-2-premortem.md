A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The hereditary leadership structure will be accepted and effective in the long term. | Conduct anonymous surveys among a representative sample of potential silo residents regarding their attitudes towards hereditary leadership. | More than 50% of respondents express strong disapproval of hereditary leadership. |
| A2 | The closed-loop ecosystem can be established and maintained with minimal external inputs after the initial setup. | Create a small-scale prototype of the closed-loop ecosystem and measure its reliance on external inputs (energy, specific nutrients) over a 12-month period. | The prototype requires external inputs exceeding 10% of its total resource needs after the first 6 months. |
| A3 | Advanced surveillance technology will effectively prevent security breaches without causing significant social unrest. | Simulate security breach attempts in a controlled environment with human participants, measuring both the effectiveness of the surveillance and the participants' stress levels and feelings of privacy invasion. | Simulated breaches are successful more than 20% of the time, OR average participant stress levels exceed a predefined threshold (e.g., a score of 7 out of 10 on a standardized stress scale). |
| A4 | The silo's internal culture will remain cohesive and resistant to external cultural influences. | Introduce carefully selected external cultural artifacts (books, music, films) to a test group within the silo and monitor their cultural preferences and values over a 6-month period. | The test group exhibits a significant shift (>= 30% change in survey responses) towards external cultural values and preferences, indicating a weakening of the silo's internal culture. |
| A5 | The silo's physical structure will remain impervious to unforeseen geological events (e.g., earthquakes, sinkholes) beyond the initial risk assessment. | Conduct regular microseismic monitoring of the surrounding geological environment and compare the data against the initial risk assessment models. | Microseismic activity exceeds the thresholds defined in the initial risk assessment models by >= 25%, indicating a potential for unforeseen geological events. |
| A6 | The silo's residents will maintain a high level of technical proficiency and adaptability to operate and maintain the complex systems over multiple generations. | Implement a standardized technical skills assessment for a representative sample of residents across different age groups and professions, and track their performance over a 5-year period. | The average score on the technical skills assessment declines by >= 15% over the 5-year period, indicating a degradation of technical proficiency within the population. |
| A7 | The silo's internal security forces will remain immune to corruption and maintain unwavering loyalty to the established governance. | Conduct regular, randomized integrity audits and psychological evaluations of security personnel, including anonymous surveys assessing their attitudes towards the leadership and their adherence to ethical guidelines. | Integrity audits reveal evidence of corruption (e.g., bribery, abuse of power) among >= 10% of security personnel, OR psychological evaluations indicate a significant decline in loyalty to the established governance (e.g., increased cynicism, questioning of authority) among >= 20% of security personnel. |
| A8 | The silo's resource reserves (minerals, metals, etc.) will be sufficient to meet the needs of the population for at least 200 years, considering projected consumption rates and technological advancements in resource extraction and recycling. | Conduct a comprehensive audit of the silo's resource reserves, updating the initial estimates based on current consumption rates and technological advancements, and project the depletion timelines for each key resource. | The projected depletion timeline for any key resource falls below 150 years, indicating a potential for resource scarcity within the silo's long-term planning horizon. |
| A9 | The silo's residents will maintain a strong sense of purpose and motivation, even in the absence of external challenges and opportunities for personal advancement. | Implement regular surveys and psychological assessments to gauge the residents' sense of purpose, motivation, and overall well-being, and correlate these metrics with their engagement in community activities and their adherence to silo regulations. | The average score on the purpose and motivation assessment falls below a predefined threshold (e.g., a score of 6 out of 10 on a standardized motivation scale), OR a significant decline (>= 20%) is observed in resident engagement in community activities and adherence to silo regulations. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Dynastic Debt Spiral | Process/Financial | A1 | Head of Finance | CRITICAL (20/25) |
| FM2 | The Great Ecosystem Collapse | Technical/Logistical | A2 | Head of Engineering | CRITICAL (15/25) |
| FM3 | The Panopticon Prison Riot | Market/Human | A3 | Head of Security | CRITICAL (15/25) |
| FM4 | The Cultural Contamination Crisis | Process/Financial | A4 | Social Governance Planner | CRITICAL (20/25) |
| FM5 | The Earth's Revenge | Technical/Logistical | A5 | Head of Engineering | HIGH (10/25) |
| FM6 | The Technological Dark Age | Market/Human | A6 | Social Governance Planner | CRITICAL (15/25) |
| FM7 | The Guardians' Graft | Process/Financial | A7 | Head of Finance | CRITICAL (15/25) |
| FM8 | The Veins Run Dry | Technical/Logistical | A8 | Head of Engineering | CRITICAL (15/25) |
| FM9 | The Existential Emptiness | Market/Human | A9 | Social Governance Planner | CRITICAL (20/25) |


### Failure Modes

#### FM1 - The Dynastic Debt Spiral

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Head of Finance
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The hereditary leadership, initially intended to provide stability, becomes entrenched and resistant to change. Nepotism and cronyism become rampant, leading to inefficient resource allocation and financial mismanagement. Dissent is suppressed, preventing any effective oversight or accountability. The silo's economy stagnates as innovative ideas are stifled and resources are diverted to maintain the ruling family's power and privilege. The silo accumulates massive debt, as the leadership prioritizes lavish spending over essential services and long-term investments. Eventually, the silo faces a financial crisis, unable to meet its obligations or provide for its residents. The population, burdened by debt and disillusioned with the leadership, erupts in rebellion, overthrowing the dynasty and plunging the silo into chaos. The financial systems collapse, and the silo struggles to recover, facing long-term economic hardship and instability. The initial goal of stability is completely undermined by the very system designed to achieve it.

##### Early Warning Signs
- Increased spending on non-essential luxury goods for the ruling family.
- Decreasing investment in essential infrastructure and services.
- Rising debt levels and increasing interest rates.
- Suppression of dissent and criticism of the leadership.

##### Tripwires
- Silo debt exceeds 75% of annual revenue.
- Investment in infrastructure decreases by >= 20% year-over-year.
- Approval rating of the leadership falls below 30% in anonymous surveys.

##### Response Playbook
- Contain: Freeze all non-essential spending and initiate an emergency audit.
- Assess: Conduct a thorough review of the silo's finances and governance structure.
- Respond: Implement governance reforms to increase accountability and transparency, and develop a debt reduction plan.


**STOP RULE:** Silo debt exceeds 100% of annual revenue and the leadership refuses to implement governance reforms.

---

#### FM2 - The Great Ecosystem Collapse

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The silo's closed-loop ecosystem, initially believed to be self-sustaining, proves to be far more fragile and complex than anticipated. A seemingly minor disruption, such as a fungal outbreak in the primary crop, triggers a cascading collapse throughout the entire system. The air purification system becomes overloaded, leading to a buildup of toxins. The water recycling system fails, resulting in a shortage of potable water. The food production system grinds to a halt, causing widespread famine. The silo's residents, deprived of essential resources, begin to suffer from malnutrition, disease, and social unrest. The technical teams scramble to find solutions, but their efforts are hampered by a lack of understanding of the complex interactions within the ecosystem. External assistance is impossible due to the silo's isolation and the belief that it should be entirely self-sufficient. The ecosystem collapses completely, rendering the silo uninhabitable and leading to the slow demise of its population. The initial promise of self-sufficiency becomes a deadly trap.

##### Early Warning Signs
- Unexplained fluctuations in air and water quality parameters.
- Decreasing crop yields and increasing plant diseases.
- Unusual animal behavior and increasing mortality rates.
- Shortages of essential resources (food, water, medicine).

##### Tripwires
- Air quality index (AQI) exceeds 150 for >= 7 consecutive days.
- Potable water reserves fall below 30 days' supply.
- Food production falls below 75% of the required caloric intake for the population.

##### Response Playbook
- Contain: Implement emergency rationing of essential resources and isolate affected areas.
- Assess: Conduct a comprehensive analysis of the ecosystem to identify the root cause of the collapse.
- Respond: Implement emergency repairs to the life support systems and introduce alternative food sources.


**STOP RULE:** More than 50% of the primary life support systems are non-functional and cannot be repaired within 30 days.

---

#### FM3 - The Panopticon Prison Riot

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Head of Security
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The advanced surveillance technology, intended to maintain order and prevent security breaches, creates a pervasive sense of unease and resentment among the silo's residents. The constant monitoring and lack of privacy erode trust and create a climate of fear. A small group of dissidents begins to organize, using encrypted communication channels to evade the surveillance systems. They spread messages of rebellion, highlighting the oppressive nature of the silo's governance and the lack of individual freedoms. A seemingly minor incident, such as a security guard abusing their authority, sparks a widespread riot. The residents, fueled by years of pent-up frustration and anger, overwhelm the security forces and seize control of the silo. The surveillance systems are disabled, and the silo descends into chaos. The initial promise of security becomes a tool of oppression, leading to the very unrest it was designed to prevent. The silo's social fabric is torn apart, and its future hangs in the balance.

##### Early Warning Signs
- Increasing use of encrypted communication channels among residents.
- Rising complaints about privacy violations and security overreach.
- Formation of underground resistance groups.
- Escalating tensions between residents and security forces.

##### Tripwires
- The number of residents using encrypted communication apps increases by >= 50% in a month.
- Complaints about privacy violations to the Ethics Committee increase by >= 40% in a quarter.
- Reports of organized resistance activity increase by >= 25% in a year.

##### Response Playbook
- Contain: Deploy additional security forces to quell the riot and isolate the affected areas.
- Assess: Conduct an investigation to identify the root causes of the unrest and the leaders of the rebellion.
- Respond: Implement governance reforms to address the residents' grievances and restore trust in the security systems.


**STOP RULE:** Security forces lose control of more than 50% of the silo's residential areas and are unable to restore order within 72 hours.

---

#### FM4 - The Cultural Contamination Crisis

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Social Governance Planner
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Despite the silo's efforts to maintain a unique internal culture, external influences gradually seep in through various channels (e.g., smuggled data, intercepted communications). These influences, initially subtle, begin to erode the silo's established values and traditions. A new generation, exposed to these external ideas, becomes increasingly dissatisfied with the silo's rigid social norms and limited opportunities. They start demanding greater freedoms and access to information, challenging the authority of the hereditary leadership. This cultural clash leads to social fragmentation and a decline in community cohesion. The silo's economy suffers as productivity declines and resources are diverted to manage the growing social unrest. The leadership, clinging to its traditional values, resists any meaningful change, further exacerbating the situation. The silo's unique cultural identity is lost, replaced by a fragmented and conflicted society, ultimately undermining its long-term stability and purpose.

##### Early Warning Signs
- Increased interest in external media and information among residents.
- Formation of cultural subgroups with conflicting values.
- Decline in participation in traditional silo cultural events.
- Rising social tensions and conflicts between different cultural groups.

##### Tripwires
- Participation in silo-sponsored cultural events drops below 50%.
- Requests for access to external information increase by >= 40% in a quarter.
- The number of identified cultural subgroups within the silo exceeds 5.

##### Response Playbook
- Contain: Implement stricter controls on external information and promote silo cultural events.
- Assess: Conduct a cultural audit to identify the root causes of the cultural contamination.
- Respond: Develop cultural exchange programs to integrate external influences while preserving core silo values.


**STOP RULE:** The silo's unique cultural identity is irretrievably lost, as evidenced by a complete abandonment of traditional values and practices by the majority of the population.

---

#### FM5 - The Earth's Revenge

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Head of Engineering
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
Despite initial geological surveys, an unforeseen geological event, such as a previously undetected fault line shifting or a sinkhole forming beneath a critical infrastructure component, occurs. This event causes significant structural damage to the silo, compromising its integrity and safety. The life support systems are disrupted, leading to air and water contamination. The power grid fails, plunging the silo into darkness. The communication systems are knocked out, isolating different sections of the silo. The residents, trapped and disoriented, panic and struggle to survive. The emergency response teams are overwhelmed by the scale of the disaster. External assistance is impossible due to the silo's remote location and the severity of the damage. The silo, once a symbol of human resilience, becomes a tomb, succumbing to the unpredictable forces of nature. The initial belief in the silo's invulnerability proves to be a fatal flaw.

##### Early Warning Signs
- Increased microseismic activity in the surrounding area.
- Cracks appearing in the silo's walls or floors.
- Unexplained shifts in the silo's structural alignment.
- Disruptions in the life support systems or power grid.

##### Tripwires
- Microseismic activity exceeds pre-defined safety thresholds by >= 30%.
- Structural integrity sensors detect stress levels exceeding design limits by >= 20%.
- Unexplained power outages occur more than 3 times in a month.

##### Response Playbook
- Contain: Activate emergency backup systems and evacuate residents from the affected areas.
- Assess: Conduct a thorough structural assessment to determine the extent of the damage.
- Respond: Implement emergency repairs to stabilize the silo and restore essential services.


**STOP RULE:** The silo's structural integrity is compromised beyond repair, rendering it uninhabitable and posing an imminent threat to the lives of its residents.

---

#### FM6 - The Technological Dark Age

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Social Governance Planner
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Over generations, the silo's residents gradually lose their technical proficiency and adaptability. The silo's educational system, focused on rote memorization and conformity, fails to cultivate critical thinking and problem-solving skills. The silo's culture, prioritizing stability over innovation, discourages experimentation and risk-taking. As the original engineers and technicians pass away, their knowledge is not effectively transferred to the next generation. The silo's complex systems begin to degrade due to lack of maintenance and expertise. Simple repairs become impossible, leading to cascading failures. The silo's residents, increasingly reliant on automated systems they no longer understand, become helpless and vulnerable. The silo, once a marvel of human engineering, descends into a technological dark age, unable to adapt to changing circumstances or maintain its essential functions. The initial promise of long-term sustainability is undermined by the erosion of human capital.

##### Early Warning Signs
- Declining scores on standardized technical skills assessments.
- Decreasing participation in technical training programs.
- Increasing reliance on automated systems and decreasing manual intervention.
- Loss of critical knowledge and expertise due to attrition or lack of succession planning.

##### Tripwires
- Average score on technical skills assessments falls below 70%.
- Enrollment in technical training programs decreases by >= 40% in a year.
- The number of critical system failures increases by >= 25% in a year.

##### Response Playbook
- Contain: Implement emergency training programs to address critical skill gaps.
- Assess: Conduct a skills audit to identify areas where technical proficiency is lacking.
- Respond: Reform the educational system to emphasize critical thinking and problem-solving skills, and promote a culture of innovation and lifelong learning.


**STOP RULE:** The silo loses the ability to repair or maintain its core life support systems, rendering it unsustainable in the long term.

---

#### FM7 - The Guardians' Graft

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Head of Finance
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The silo's security forces, initially established to protect the community, gradually succumb to corruption. Driven by greed and a thirst for power, they begin to exploit their authority for personal gain. They extort businesses, demand bribes from residents, and engage in illicit activities, such as smuggling and black market trading. The silo's economy suffers as legitimate businesses are squeezed and resources are diverted to fuel the security forces' corruption. The leadership, either complicit or unable to control the situation, turns a blind eye to the growing problem. Trust in the security forces erodes, and residents become increasingly fearful and resentful. A parallel power structure emerges, with the security forces wielding significant influence over all aspects of silo life. The silo's financial systems are corrupted, and resources are misallocated to benefit the security forces and their cronies. The initial promise of security becomes a tool of oppression, enriching a select few at the expense of the entire community.

##### Early Warning Signs
- Increased reports of extortion and bribery involving security personnel.
- Unexplained wealth accumulation among security force members.
- Decline in trust and respect for the security forces among residents.
- Emergence of a black market within the silo.

##### Tripwires
- Reports of corruption involving security personnel increase by >= 50% in a year.
- The black market economy accounts for >= 10% of the silo's total economic activity.
- Resident trust in the security forces falls below 40% in anonymous surveys.

##### Response Playbook
- Contain: Launch a secret internal investigation to identify and apprehend corrupt security personnel.
- Assess: Conduct a thorough audit of the security forces' finances and operations.
- Respond: Implement stricter oversight and accountability measures for the security forces, and establish an independent anti-corruption agency.


**STOP RULE:** The security forces are deemed to be irredeemably corrupt, with evidence of widespread collusion and a complete breakdown of ethical standards.

---

#### FM8 - The Veins Run Dry

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Despite initial resource assessments, the silo's mineral and metal reserves prove to be insufficient to meet the long-term needs of the population. Unexpectedly high consumption rates, driven by technological advancements and population growth, accelerate the depletion of key resources. The silo's recycling systems, while efficient, are unable to fully compensate for the dwindling reserves. As resources become scarce, the silo's economy begins to falter. Manufacturing output declines, and essential infrastructure maintenance is neglected. The residents face increasing shortages of essential goods and materials. The leadership, initially optimistic about the silo's resource self-sufficiency, is forced to implement drastic rationing measures. Social unrest erupts as residents compete for dwindling resources. The silo's technological progress grinds to a halt, as innovation is stifled by the lack of essential materials. The initial promise of long-term sustainability is undermined by the unforeseen depletion of finite resources. The silo faces a bleak future, struggling to survive with limited means.

##### Early Warning Signs
- Accelerating depletion rates of key mineral and metal reserves.
- Increasing shortages of essential goods and materials.
- Decline in manufacturing output and infrastructure maintenance.
- Rising social tensions and conflicts over resource allocation.

##### Tripwires
- The projected depletion timeline for any key resource falls below 100 years.
- Shortages of essential goods and materials are reported by >= 30% of the population.
- Manufacturing output declines by >= 20% in a year.

##### Response Playbook
- Contain: Implement strict resource rationing measures and prioritize essential services.
- Assess: Conduct a comprehensive reassessment of the silo's resource reserves and consumption rates.
- Respond: Invest in research and development of alternative materials and resource extraction technologies, and explore options for external resource acquisition (if feasible).


**STOP RULE:** The silo's remaining resource reserves are deemed insufficient to sustain the population for more than 50 years, and no viable alternative resource sources can be identified.

---

#### FM9 - The Existential Emptiness

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Social Governance Planner
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Despite the silo's efforts to provide for its residents' material needs, a pervasive sense of existential emptiness and lack of purpose settles over the community. The absence of external challenges, personal advancement opportunities, and meaningful goals beyond mere survival leads to widespread apathy and disillusionment. The silo's residents, secure in their basic needs but lacking a sense of purpose, become increasingly disengaged and unmotivated. Productivity declines, and innovation stagnates. Social cohesion erodes as residents withdraw into themselves, seeking solace in escapism and superficial pursuits. The silo's culture becomes stagnant and devoid of meaning. The leadership, initially focused on maintaining order and control, fails to address the underlying psychological needs of its residents. The silo, once a beacon of human resilience, becomes a gilded cage, trapping its inhabitants in a state of existential despair. The initial promise of a secure and stable future is undermined by the lack of purpose and meaning in the residents' lives.

##### Early Warning Signs
- Declining participation in community activities and social events.
- Increasing rates of depression, anxiety, and other mental health issues.
- Erosion of ethical standards and a rise in petty crime.
- Widespread apathy and disengagement among residents.

##### Tripwires
- Average score on the purpose and motivation assessment falls below 5 out of 10.
- Participation in community activities declines by >= 50% in a year.
- Rates of depression and anxiety increase by >= 30% in a year.

##### Response Playbook
- Contain: Implement community-building initiatives and promote social interaction.
- Assess: Conduct a psychological assessment to identify the root causes of the existential emptiness.
- Respond: Introduce meaningful goals and challenges for residents, such as scientific research, artistic endeavors, or community service projects, and promote a culture of purpose and meaning.


**STOP RULE:** The silo's residents are deemed to be suffering from widespread existential despair, with no viable means of restoring a sense of purpose and meaning to their lives.
