**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds financial limit set for PMO, requiring strategic oversight and approval at a higher level.
Negative Consequences: Potential budget overrun and misalignment with strategic objectives.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: The risk has strategic implications that require immediate attention and potentially a revised mitigation strategy.
Negative Consequences: Project failure, significant delays, or substantial cost increases.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: Inability to reach consensus within the PMO necessitates a decision from a higher authority to avoid delays.
Negative Consequences: Project delays, increased costs, and potential legal challenges.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: Significant changes to the project scope require strategic review and approval due to potential impacts on budget, timeline, and objectives.
Negative Consequences: Misalignment with strategic goals, budget overruns, and project delays.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Steering Committee
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance with regulations.
Negative Consequences: Legal penalties, reputational damage, and social unrest.

**Technical Design Exceeding Approved Parameters**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Technical Advisory Group Recommendation
Rationale: Technical designs that deviate significantly from approved parameters require strategic review due to potential impacts on project feasibility and objectives.
Negative Consequences: Technical failures, project delays, and increased costs.