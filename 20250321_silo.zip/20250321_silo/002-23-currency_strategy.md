This plan involves money.

## Currencies

- **USD:** Primary currency for the project, given its scale, international funding, and potential location in the USA.
- **RUB:** Potential use for local transactions if the project is located in Russia.
- **CAD:** Potential use for local transactions if the project is located in Canada.

**Primary currency:** USD

**Currency strategy:** Due to the international nature of the funding and the potential locations in different countries, USD is recommended as the primary currency for budgeting and reporting. If local transactions are necessary in Russia or Canada, use RUB or CAD respectively, but hedge against exchange rate fluctuations. For significant projects, the primary currency must be USD.