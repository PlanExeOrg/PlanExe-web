### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Structure Defined

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Structure Defined

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Structure Defined

### 4. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Structure Defined

### 5. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SEG ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Structure Defined

### 6. Circulate Draft SteerCo ToR for review by nominated members (CEO, CFO, CTO, Government Rep, Investor Rep, Ethics Advisor).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on SteerCo ToR

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 7. Circulate Draft PMO ToR for review by Project Director.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on PMO ToR

**Dependencies:**

- Draft PMO ToR v0.1
- Project Director Appointed

### 8. Circulate Draft TAG ToR for review by Chief Engineer.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on TAG ToR

**Dependencies:**

- Draft TAG ToR v0.1
- Chief Engineer Appointed

### 9. Circulate Draft ECC ToR for review by Legal Counsel.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on ECC ToR

**Dependencies:**

- Draft ECC ToR v0.1
- Legal Counsel Appointed

### 10. Circulate Draft SEG ToR for review by Communications Manager.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on SEG ToR

**Dependencies:**

- Draft SEG ToR v0.1
- Communications Manager Appointed

### 11. Project Manager finalizes SteerCo ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary on SteerCo ToR

### 12. Project Manager finalizes PMO ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0

**Dependencies:**

- Feedback Summary on PMO ToR

### 13. Project Manager finalizes TAG ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final TAG ToR v1.0

**Dependencies:**

- Feedback Summary on TAG ToR

### 14. Project Manager finalizes ECC ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final ECC ToR v1.0

**Dependencies:**

- Feedback Summary on ECC ToR

### 15. Project Manager finalizes SEG ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SEG ToR v1.0

**Dependencies:**

- Feedback Summary on SEG ToR

### 16. Senior Sponsor formally appoints Steering Committee Chair.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 17. Project Sponsor formally confirms Steering Committee Members (CEO, CFO, CTO, Government Rep, Investor Rep, Ethics Advisor).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0
- Steering Committee Chair Appointed

### 18. Steering Committee Chair schedules initial kick-off meeting for the Project Steering Committee.

**Responsible Body/Role:** Steering Committee Chair

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Initial Agenda

**Dependencies:**

- Membership Confirmation Email

### 19. Hold initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Project Scope
- Approved Initial Budget
- Approved Initial Timeline

**Dependencies:**

- Meeting Invitation
- Initial Agenda

### 20. Project Director schedules initial kick-off meeting for the Project Management Office (PMO).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Initial Agenda

**Dependencies:**

- Final PMO ToR v1.0

### 21. Hold initial PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- PMO Task Assignments

**Dependencies:**

- Meeting Invitation
- Initial Agenda

### 22. Chief Engineer schedules initial kick-off meeting for the Technical Advisory Group.

**Responsible Body/Role:** Chief Engineer

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Initial Agenda

**Dependencies:**

- Final TAG ToR v1.0

### 23. Hold initial Technical Advisory Group Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- TAG Task Assignments

**Dependencies:**

- Meeting Invitation
- Initial Agenda

### 24. Legal Counsel schedules initial kick-off meeting for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Initial Agenda

**Dependencies:**

- Final ECC ToR v1.0

### 25. Hold initial Ethics & Compliance Committee Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- ECC Task Assignments

**Dependencies:**

- Meeting Invitation
- Initial Agenda

### 26. Communications Manager schedules initial kick-off meeting for the Stakeholder Engagement Group.

**Responsible Body/Role:** Communications Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Initial Agenda

**Dependencies:**

- Final SEG ToR v1.0

### 27. Hold initial Stakeholder Engagement Group Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- SEG Task Assignments

**Dependencies:**

- Meeting Invitation
- Initial Agenda