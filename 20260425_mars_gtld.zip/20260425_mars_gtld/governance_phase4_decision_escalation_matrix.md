**Decision Deadlock on Governance Stance (CPT Level)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Consensus vote required among Project Sponsor, CLO, and CTO, enforced within two meeting cycles.
Rationale: Disagreement within the Core Project Team (CPT) on a fundamental strategic decision (e.g., the exact terms of the Registry Governance neutrality vs. speed trade-off) cannot be resolved by the CPT's PM tie-breaker.
Negative Consequences: Stalls finalization of the ICANN application documentation and delays the 18-month delegation timeline.

**Budget Request for Capital Expenditure Exceeding $5 Million or 10% Quarterly Budget**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Mandatory approval by vote of PSC members (Sponsor, CLO, CTO).
Rationale: Exceeds the delegated financial authority limit set for the Core Project Team ($500,000 operational) and requires strategic oversight given the project's $25M+ total budget.
Negative Consequences: Immediate project funding bottleneck; risk of failing to secure necessary resources for unforseen string contention defense or securing required HSM technology.

**TAG Identifies Critical Security Vulnerability Requiring Immediate Policy or Architecture Change**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Escalated immediately if TAG independent members cannot reach unanimous technical consensus, requiring PSC review and potential budget reallocation.
Rationale: The TAG has the authority to halt deployment if fundamental security prerequisites (DNSSEC/HSM custody) are not met, which supersedes standard execution timelines.
Negative Consequences: If not resolved, risks failure in ICANN technical audit (Risk 7) or loss of primary key custody, causing severe reputational damage and potential 9-15 month ICANN delay.

**SGB Veto on Policy Change Prioritizing Commercial Interest Over Neutrality Mandate**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC reviews the SGB's veto; the PSC can overturn the veto only via consensus if the CPT proves the operational viability mandates the policy change over the neutrality compromise. PSC deferral to sponsor if neutrality conflict persists.
Rationale: Conflict arises when CPT expediency (a CPT decision right) directly clashes with the SGB's mandated role to uphold the 'Builder' strategy's neutrality commitments (Decision 1/2).
Negative Consequences: Erosion of external trust and legitimacy, increasing Political Risk (Risk 5) just as ICANN evaluation is underway.

**Persistent External Review Failure Requiring Re-Submission or Appeal of ICANN Decision**
Escalation Level: Executive Leadership / Project Sponsoring Entity
Approval Process: Mandatory non-consensus arbitration by the Executive Sponsor to authorize major mitigation funding drawdowns ($10M+) or to approve a total strategic pivot/appeal trajectory.
Rationale: This represents the highest risk level—failure of the primary goal path—requiring executive intervention beyond the PSC's chartered authority limits.
Negative Consequences: Project failure, significant financial write-down (up to $100M), and potential loss of early-mover status for Mars digital namespace conventions.

**Disagreement between TAG and CPT on the Interplanetary Latency Resolution Protocol's Required TTL Range**
Escalation Level: Technical Assurance Group (TAG)
Approval Process: TAG recommends a strict technical remit; if CPT cannot build to that specification within budget/timeline, the issue escalates to the PSC for strategic budgetary decision.
Rationale: If CPT cannot meet the stringent technical proof requirements necessary for latency compensation (Decision 3/11 conflict), the technical body must formally flag the risk before it impacts PSC-level project strategy.
Negative Consequences: Risk of serving stale records during live testing, potentially requiring a downgrade in the promised freshness guarantee, impacting ecosystem adoption.