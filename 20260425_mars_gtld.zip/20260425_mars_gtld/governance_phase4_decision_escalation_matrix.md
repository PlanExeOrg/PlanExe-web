**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review and vote based on strategic alignment and budget availability.
Rationale: Exceeds the PMO's delegated financial authority and requires strategic review.
Negative Consequences: Potential project delays, scope reduction, or budget overruns if not addressed.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee assessment of impact and approval of revised mitigation strategy.
Rationale: The risk has a high potential impact on project success and requires strategic-level intervention.
Negative Consequences: Project failure, significant financial losses, or reputational damage if not addressed effectively.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of vendor proposals and selection based on strategic fit and value.
Rationale: Inability to reach consensus within the PMO requires higher-level arbitration to avoid delays.
Negative Consequences: Project delays, suboptimal vendor selection, or increased costs if not resolved.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of the proposed change, impact assessment, and approval based on strategic alignment.
Rationale: Significant changes to project scope require strategic re-evaluation and approval.
Negative Consequences: Project misalignment with strategic goals, budget overruns, or timeline extensions if not properly managed.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee investigation, review of evidence, and determination of appropriate action.
Rationale: Requires independent review and action to ensure ethical conduct and compliance.
Negative Consequences: Legal penalties, reputational damage, or loss of stakeholder trust if not addressed.

**Technical Design Conflict Between PMO and Technical Advisory Group**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee reviews the conflicting recommendations and makes a final decision based on strategic priorities and technical feasibility.
Rationale: Disagreement between the PMO and TAG requires a higher authority to resolve and ensure alignment with project goals.
Negative Consequences: Suboptimal technical design, project delays, or increased costs if the conflict is not resolved.