### 1. Project Sponsor drafts initial Terms of Reference (ToR) for the Project Steering Committee (PSC)

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1

**Dependencies:**


### 2. Project Sponsor circulates Draft PSC ToR for review by nominated members

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on PSC ToR

**Dependencies:**

- Draft PSC ToR v0.1

### 3. Project Sponsor finalizes and approves the PSC ToR

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Finalized PSC ToR

**Dependencies:**

- Feedback Summary on PSC ToR

### 4. Project Sponsor formally appoints the Chair of the PSC

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email for PSC Chair

**Dependencies:**

- Finalized PSC ToR

### 5. Project Sponsor approves the initial $25M capital allocation for Phase 1

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved Capital Allocation Document

**Dependencies:**

- Finalized PSC ToR

### 6. Core Project Team (CPT) finalizes individual role descriptions aligned with key FTE allocations

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Finalized Role Descriptions

**Dependencies:**

- Approved Capital Allocation Document

### 7. CPT establishes Agile/milestone planning tracking against the 18-month deadline

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Agile Planning Document

**Dependencies:**

- Finalized Role Descriptions

### 8. CPT defines and baselines operational KPIs for latency testing

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Operational KPI Baseline Document

**Dependencies:**

- Agile Planning Document

### 9. CPT drafts all technical, legal, and policy documentation for ICANN submission

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Weeks 6-10

**Key Outputs/Deliverables:**

- Draft ICANN Application Dossier

**Dependencies:**

- Operational KPI Baseline Document

### 10. CPT manages the procurement and onboarding of the Registry Service Provider (RSP) contract

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Weeks 6-10

**Key Outputs/Deliverables:**

- Signed RSP Contract

**Dependencies:**

- Draft ICANN Application Dossier

### 11. CPT operationalizes the Abuse Prevention Policy for Planetary Naming

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Weeks 11-12

**Key Outputs/Deliverables:**

- Operational Abuse Prevention Policy Document

**Dependencies:**

- Signed RSP Contract

### 12. Technical Assurance Group (TAG) procures external security auditor for initial DNSSEC compliance review

**Responsible Body/Role:** Technical Assurance Group

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Contract with External Security Auditor

**Dependencies:**


### 13. TAG finalizes specification for Mars-endpoint simulator testing environment

**Responsible Body/Role:** Technical Assurance Group

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Mars-endpoint Simulator Specification Document

**Dependencies:**

- Contract with External Security Auditor

### 14. TAG defines technical failure mode criteria that trigger Fault Tolerance review

**Responsible Body/Role:** Technical Assurance Group

**Suggested Timeframe:** Project Week 14

**Key Outputs/Deliverables:**

- Technical Failure Mode Criteria Document

**Dependencies:**

- Mars-endpoint Simulator Specification Document

### 15. Stewardship Governance Board (SGB) formalizes the SGB Charter and Terms of Reference

**Responsible Body/Role:** Stewardship Governance Board

**Suggested Timeframe:** Project Week 15

**Key Outputs/Deliverables:**

- Finalized SGB Charter and ToR

**Dependencies:**


### 16. SGB elects an independent Chair from the external members

**Responsible Body/Role:** Stewardship Governance Board

**Suggested Timeframe:** Project Week 15

**Key Outputs/Deliverables:**

- Appointment Confirmation Email for SGB Chair

**Dependencies:**

- Finalized SGB Charter and ToR

### 17. SGB contracts the 'Planetary Stewardship Trust' fund mechanism and indexes reporting to the public Earth climate index proxy

**Responsible Body/Role:** Stewardship Governance Board

**Suggested Timeframe:** Project Week 16

**Key Outputs/Deliverables:**

- Contract for Stewardship Trust Fund

**Dependencies:**

- Appointment Confirmation Email for SGB Chair

### 18. Hold initial kick-off meeting for the Project Steering Committee (PSC)

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 17

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Finalized PSC ToR
- Appointment Confirmation Email for PSC Chair

### 19. Hold initial kick-off meeting for the Core Project Team (CPT)

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 17

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Agile Planning Document

### 20. Hold initial kick-off meeting for the Technical Assurance Group (TAG)

**Responsible Body/Role:** Technical Assurance Group

**Suggested Timeframe:** Project Week 17

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Mars-endpoint Simulator Specification Document

### 21. Hold initial kick-off meeting for the Stewardship Governance Board (SGB)

**Responsible Body/Role:** Stewardship Governance Board

**Suggested Timeframe:** Project Week 17

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Finalized SGB Charter and ToR