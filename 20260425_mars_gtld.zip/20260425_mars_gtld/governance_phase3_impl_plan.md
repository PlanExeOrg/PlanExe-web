### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 2. Circulate Draft SteerCo ToR for review by nominated members (CTO, CLO, CFO, VP of Strategic Initiatives, Independent External Advisor).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager finalizes SteerCo ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior Sponsor formally appoints Steering Committee Chair (CTO).

**Responsible Body/Role:** VP of Strategic Initiatives

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Manager formally notifies all Steering Committee members of their appointment.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Appointment Confirmation Email

### 6. Project Manager schedules initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Appointment Confirmation Emails

### 7. Hold initial Project Steering Committee kick-off meeting to review ToR, project goals, and initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 8. Project Manager drafts initial Terms of Reference (ToR) for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 9. Circulate Draft PMO ToR for review by nominated members (Lead DNS Engineer, Legal Counsel, Marketing Manager, Security Manager, Compliance Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft PMO ToR v0.1

### 10. Project Manager finalizes PMO ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0

**Dependencies:**

- Feedback Summary

### 11. Project Manager formally notifies all PMO members of their appointment.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final PMO ToR v1.0

### 12. Project Manager schedules initial PMO kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Appointment Confirmation Emails

### 13. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 14. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 15. Circulate Draft TAG ToR for review by nominated members (Lead DNS Engineer, Senior Network Architect, Cybersecurity Expert, Data Synchronization Specialist, External DNS Expert, External CDN Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft TAG ToR v0.1

### 16. Project Manager finalizes TAG ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Final TAG ToR v1.0

**Dependencies:**

- Feedback Summary

### 17. Project Manager formally notifies all Technical Advisory Group members of their appointment.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final TAG ToR v1.0

### 18. Project Manager schedules initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Appointment Confirmation Emails

### 19. Hold Technical Advisory Group Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 20. Chief Legal Officer (CLO) drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Chief Legal Officer (CLO)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 21. Circulate Draft Ethics & Compliance Committee ToR for review by nominated members (Compliance Officer, Data Protection Officer, Internal Audit Manager, External Ethics Advisor).

**Responsible Body/Role:** Chief Legal Officer (CLO)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 22. Chief Legal Officer (CLO) finalizes Ethics & Compliance Committee ToR based on feedback.

**Responsible Body/Role:** Chief Legal Officer (CLO)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 23. Chief Legal Officer (CLO) formally notifies all Ethics & Compliance Committee members of their appointment.

**Responsible Body/Role:** Chief Legal Officer (CLO)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 24. Chief Legal Officer (CLO) schedules initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Chief Legal Officer (CLO)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Appointment Confirmation Emails

### 25. Hold Ethics & Compliance Committee Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 26. Marketing Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Marketing Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 27. Circulate Draft Stakeholder Engagement Group ToR for review by nominated members (Communications Manager, Community Relations Manager, Partnerships Manager, External Space Community Representative).

**Responsible Body/Role:** Marketing Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1

### 28. Marketing Manager finalizes Stakeholder Engagement Group ToR based on feedback.

**Responsible Body/Role:** Marketing Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 29. Marketing Manager formally notifies all Stakeholder Engagement Group members of their appointment.

**Responsible Body/Role:** Marketing Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0

### 30. Marketing Manager schedules initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Marketing Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Appointment Confirmation Emails

### 31. Hold Stakeholder Engagement Group Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation