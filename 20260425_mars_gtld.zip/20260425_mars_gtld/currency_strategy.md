This plan involves money.

## Currencies

- **USD:** Primary currency for budgeting and reporting, as the project is international and involves significant expenses.
- **EUR:** Relevant for infrastructure in Ireland (Dublin).
- **SGD:** Relevant for infrastructure in Singapore.

**Primary currency:** USD

**Currency strategy:** USD will be used for consolidated budgeting and reporting. EUR and SGD may be used for local transactions in Ireland and Singapore, respectively. Currency exchange rates should be monitored and hedging strategies considered to mitigate risks from exchange rate fluctuations.