This plan involves money.

## Currencies

- **USD:** The project is high-budget ($25M - $100M+), politically sensitive, and involves legal/international coordination, making USD the most likely base currency for contracting and major financial reporting.

**Primary currency:** USD

**Currency strategy:** Given the project's nature (ICANN application, international policy engagement) and high budget, all primary budgeting, high-value contracts (legal, registry services), and financial reporting will be conducted in USD to maintain stability against potential local market fluctuations, even though the service is purely digital.