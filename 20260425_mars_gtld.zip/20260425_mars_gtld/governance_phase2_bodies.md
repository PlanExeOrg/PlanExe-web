### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Required for high-level strategic oversight, mandatory given the political sensitivity (Risk 1/5), high budget ($25M-$100M+), and precedent-setting nature of seeking a planetary namespace via ICANN. It bridges strategic direction with operational execution.

**Responsibilities:**

- Approve major funding disbursements exceeding $5 Million or 10% of the current quarter's budget.
- Provide final sign-off on critical strategic decisions (e.g., Governance Stance, Legitimacy Positioning, Sovereign Engagement framework).
- Approve annual operating budgets and monitor high-level financial health against the $25M+ baseline.
- Oversee strategic risk management, particularly Regulatory, Political, and Financial risks (Risk 1, 3, 5).
- Final decision authority on escalating inter-committee conflicts.

**Initial Setup Actions:**

- Define and sign the PSC Charter outlining authority boundaries.
- Appoint the Project Sponsor as the Chair.
- Approve the initial $25M capital allocation for Phase 1 (Application & Policy Development).

**Membership:**

- Project Sponsor (Chair)
- Chief Legal Officer (CLO)
- Chief Technology Officer (CTO)
- Head of Finance (non-voting member, responsible for reporting)
- Designated Head of Policy/Liaison (to interface with external advisors)

**Decision Rights:** Strategic direction and financial approvals above $5M or 10% budget threshold. Veto power over changes to core governance decisions made by lower bodies.

**Decision Mechanism:** Consensus required among the Project Sponsor, CLO, and CTO. If consensus is not reached within two meeting cycles, the issue escalates directly to the executive leadership sponsoring the project for mandatory arbitration.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of Political Sensitivity status (Risk 1/5 updates).
- Major Milestone Attainment Review (e.g., ICANN application submission readiness).
- Contingency Drawdown Authorization Request.
- Review of findings from the Technical Assurance Group (TAG) regarding security architecture (Decision 4).

**Escalation Path:** Executive Leadership / Project Sponsoring Entity
### 2. Core Project Team (CPT)

**Rationale for Inclusion:** Responsible for day-to-day execution, managing the $25M-$100M project execution timeline (18 months), and implementing the technical standards defined by strategic decisions (e.g., Latency Protocol, DNSSEC).

**Responsibilities:**

- Manage the 18-month ICANN application deadline.
- Develop and test the proprietary tooling for Interplanetary Latency Compensation (Decision 11).
- Draft all technical, legal, and policy documentation for ICANN submission.
- Manage the procurement and onboarding of the Registry Service Provider (RSP) contract.
- Operationalize the Abuse Prevention Policy for Planetary Naming.

**Initial Setup Actions:**

- Finalize individual role descriptions aligned with key FTE allocations.
- Establish Agile/milestone planning tracking against the 18-month deadline.
- Define and baseline operational KPIs for latency testing (Decision 3).

**Membership:**

- Project Manager (Chair)
- GTLD Technical Lead
- Lead Legal Counsel (ICANN/IP focus)
- Policy & Government Relations Specialist (Decision 7 focus)
- Financial Controller (reporting)

**Decision Rights:** All operational decisions, resource allocation below $500,000, tactical risk responses, and finalization of technical specifications pending PSC approval concerning strategic decisions (e.g., specific TTL setting within the mandated Latency Protocol range).

**Decision Mechanism:** Majority vote by CPT membership present. Tie-breaker assigned to the Project Manager.

**Meeting Cadence:** Twice Weekly (Operational Sync)

**Typical Agenda Items:**

- Tracking progress against ICANN submission milestones.
- Review of ongoing legal/trademark escalations (Risk 2 mitigation).
- Status updates on Earth-mirror infrastructure build-out.
- Review of external contractor deliverables (e.g., policy drafting).

**Escalation Path:** Project Steering Committee (PSC) for approvals exceeding $500k deviation, delays impacting major milestones, or conflicts relating to ratified strategic decisions.
### 3. Technical Assurance Group (TAG)

**Rationale for Inclusion:** Crucial for ensuring technical credibility (DNSSEC, Latency Resolution) and mitigating high operational/security risks (Risk 4, 7). Requires specialized, external assurance given the novel nature of interplanetary synchronization standards.

**Responsibilities:**

- Audit the implementation of Technical Security Delegation Model (Decision 4), specifically ensuring internal custody of KSK/ZSK via HSMs, overriding any third-party delegation proposals.
- Verify adherence to the Interplanetary Latency Resolution Protocol (Decision 3) by testing the bifurcated registration system.
- Conduct required quarterly independent verification of synchronization logs (Decision 14) against Martian simulator endpoints.
- Provide technical vetting for all technical RFPs, especially for Earth-mirror infrastructure.

**Initial Setup Actions:**

- Procure external security auditor for initial DNSSEC compliance review.
- Finalize specification for Mars-endpoint simulator testing environment.
- Define technical failure mode criteria that trigger Fault Tolerance review (Decision 12).

**Membership:**

- External DNS Security Expert (Chair—Independent Member)
- External Interplanetary Communications Architect (Independent Member)
- CPT Technical Lead (ensures findings are actionable)
- Accredited Third-Party Auditor (as required by Decision 14)

**Decision Rights:** Ability to halt deployment or deployment sign-off on any component affecting DNSSEC assurance or latency proof-of-concept until CPT or PSC remediation is confirmed. Recommends technical remediation actions.

**Decision Mechanism:** Unanimous agreement among all independent members (External Chair, Architect). If agreement fails, the finding is escalated immediately to the PSC, annotated with conflicting technical rationales.

**Meeting Cadence:** Bi-Weekly during development sprints; Monthly post-delegation audit cycle.

**Typical Agenda Items:**

- Review of synchronization failure rates under stress testing.
- Audit results from the outsourced DNSSEC SLA management (Risk 6 mitigation).
- Assessment of proprietary tooling effectiveness vs. required latency mandates.
- Review of proposed architectural changes related to Fault Tolerance mechanisms (Decision 12).

**Escalation Path:** Project Steering Committee (PSC) if a critical security or synchronization issue is identified that requires immediate re-allocation of budget or strategic policy change (e.g., altering the 60-minute sync window commitment).
### 4. Stewardship Governance Board (SGB)

**Rationale for Inclusion:** Required by Strategy Choice 1 under Decision 1 ('Builder' path) to establish legitimacy and neutrality by insulating core policy decisions from commercial pressure. This body oversees the neutrality commitment and manages the revenue dedication.

**Responsibilities:**

- Vet and approve all major changes to Registry Governance rules, Abuse Prevention Policy, and dispute resolution mechanisms, ensuring alignment with neutrality commitments.
- Oversee compliance reporting, specifically verifying that 50% of net revenue is committed correctly to the Mars environmental/scientific research fund (Decision 2).
- Serve as the final internal arbiter for Dispute Resolution appeals stemming from trademark conflicts or registration disputes.
- Appoint and manage the relationship with the designated external, independent auditors.

**Initial Setup Actions:**

- Formalize the SGB Charter and Terms of Reference, including independence clauses.
- Elect an independent Chair from the external members.
- Contractually establish the 'Planetary Stewardship Trust' fund mechanism and index reporting to the public Earth climate index proxy.

**Membership:**

- External Space Policy Expert (Chair)
- External Academic/Ethicist (Independent Member)
- External Domain Law Specialist (Independent Member)
- Head of Policy/Liaison (CPT liaison, non-voting)
- Financial Controller (reporting on Trust status)

**Decision Rights:** Veto power over any operational policy change proposed by the CPT that could be perceived as unduly prioritizing commercial interests over stewardship/neutrality mandates. Authorizes disbursement from the Stewardship Trust.

**Decision Mechanism:** Qualified majority of 2 out of 3 independent members required for policy veto or fund disbursement decisions. If a tie occurs among independent members (requires 4+ specialized external members for this scenario), the issue is escalated to the PSC, which records the disagreement but defers to the PSC Chair's casting vote only on matters not explicitly tied to neutrality/fund commitment.

**Meeting Cadence:** Quarterly (mandated by revenue review cycle)

**Typical Agenda Items:**

- Review of Trademark Conflict Escalation disposition rates (Decision 6).
- Audit review of 50% revenue commitment calculation (Decision 2).
- Review of the Registry Governance framework's perceived neutrality in external commentary.
- Recommendations for amending the Registration Agreement based on ecosystem feedback.

**Escalation Path:** Project Steering Committee (PSC) for deadlocks on governance alignment or disputes over the interpretation of neutrality requirements impacting essential operations.