**Purpose:** business

**Purpose Detailed:** Establishing a digital namespace for Mars-related activities and infrastructure, aiming to become the default addressing layer for future Mars commerce and settlement.

**Topic:** SpaceX's .mars gTLD proposal