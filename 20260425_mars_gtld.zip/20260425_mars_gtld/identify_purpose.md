**Purpose:** business

**Purpose Detailed:** Strategic control over the digital addressing and naming infrastructure for future Mars-related missions, commerce, and governance, positioning the entity to shape early norms for interplanetary digital coordination and commerce.

**Topic:** Application to operate the .mars generic top-level domain (gTLD) via ICANN.