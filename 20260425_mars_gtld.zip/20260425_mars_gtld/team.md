*Roles Needed & Example People*

# Roles

## 1. ICANN Policy & Regulatory Affairs Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The ICANN Policy Lead is responsible for the core, daily navigation and coordination across the entire 18-month timeline, requiring continuous availability, deep institutional knowledge of ICANN procedures, and direct alignment with internal strategy (The Builder). This high alignment and continuous need favor FTE status.

**Explanation**:
Responsible for navigating the ICANN New gTLD Program application process, managing public comment periods, handling string objections, and ensuring final compliance with global domain name system registry requirements. Crucial for Planning & Preparation and Monitoring phases.

**Consequences**:
Application rejection due to procedural error, failure to meet required compliance deadlines, or inability to successfully mitigate government objections lodged through ICANN channels.

**People Count**:
min 1, max 2, depending on workload during active review cycles

**Typical Activities**:
Drafting and refining the comprehensive ICANN New gTLD application to meet all technical and legal requirements; managing public comment periods and responding to all formal state and stakeholder objections (Risk 1 mitigation); developing the initial Abuse Prevention and UDRP adaptation policy frameworks; liaising directly with ICANN contractual compliance teams throughout the review process.

**Background Story**:
Dr. Alistair Finch, hailing from Geneva, Switzerland, brings a formidable background in international telecommunications law and digital policy, holding a J.S.D. from the University of Geneva and having spent a decade as a senior advisor to a major European government on internet governance harmonization initiatives. His specific expertise lies in navigating the political minefields of root zone delegation, string contention, and crafting defensible compliance narratives for ICANN proceedings, giving him intimate knowledge of the procedural failure points and necessary stakeholder appeasements; he is highly familiar with the delicate balance required for planetary namespace applications, making him essential for ensuring procedural success and mitigating Risk 1 (Regulatory Objections).

**Equipment Needs**:
High-security data connection for submitting confidential ICANN dossiers; Subscription access to specialized legal and GNL compliance databases; Secure communication platform for handling sensitive governmental objection responses.

**Facility Needs**:
Secure, access-controlled office space necessary for handling legally privileged documents and participating in highly sensitive digital policy calls/hearings.

## 2. Namespace Governance & Trust Architect

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Namespace Governance Architect designs and operationalizes the Independent Board of Trustees (Decision 1) and shapes core neutrality positions (Decision 2). This role is central to mitigating major political risk (Risk 1/5) and requires deep integration with internal strategy, making full-time employment necessary.

**Explanation**:
Designs and operationalizes the neutral stewardship model (The Independent Board of Trustees) chosen in Decision 1. This role translates the commitment to neutrality into charter documents, dispute resolution systems, and mechanisms for engaging international policy bodies (COPUOS, ITU).

**Consequences**:
Loss of political legitimacy, resulting in sustained governmental or stakeholder challenges that halt delegation or force operational structure changes post-delegation.

**People Count**:
1

**Typical Activities**:
Drafting the Charter and Terms of Reference for the external Board of Trustees; designing the procedural rules for board elections, quorum, and veto processes; developing the framework for the registry's Dispute Resolution Service independent of commercial interests; ensuring the published operational framework aligns with Sovereign Engagement commitments (Decision 5).

**Background Story**:
Cassandra 'Cass' Valenti grew up in Boston, Massachusetts, where her early fascination with distributed systems quickly led her to pursue degrees in Computer Science and Global Policy from MIT, melding technical rigor with governance theory. She spent seven years at a leading internet standards organization building consensus frameworks for new routing protocols, giving her unparalleled experience in translating abstract political mandates (like 'neutrality') into actionable, auditable charter documents and operational bylaws. Cass is relevant because she is tasked directly with operationalizing Decision 1—establishing the Independent Board of Trustees—and operationalizing Decision 2's commitment to revenue transparency, ensuring the TLD is perceived as a legitimate infrastructure utility.

**Equipment Needs**:
Secure digital platform for drafting and ratifying multi-stakeholder Governance Charters; Legal research subscriptions focused on cooperative international standards and non-profit trust legal frameworks; Secure video conferencing hardware to support remote Trustee onboarding and voting sessions.

**Facility Needs**:
A dedicated, neutral conference facility (virtual or physical) designated for Independent Board of Trustees meetings to ensure perceived impartiality away from corporate headquarters.

## 3. Interplanetary Systems Integration Engineer

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Interplanetary Systems Integration Engineer handles the core technical novelty—developing proprietary tooling for latency compensation (Decisions 3, 11) and fault tolerance (Decision 12). This complex, multi-faceted technical development requires continuous, dedicated engineering effort and control over intellectual property.

**Explanation**:
Designs and validates the technical protocols required to manage light-speed latency (Decisions 3, 11, 12). This includes developing the bifurcated registration logic, defining the metadata schema for status reporting, and leading the design of synchronization tooling and fault tolerance testing.

**Consequences**:
The core value proposition fails: DNS records become unreliable or misleading, leading to high operational error rates for Mars-facing services and ecosystem distrust.

**People Count**:
min 2, max 4, due to complexity of latency modeling

**Typical Activities**:
Designing the technical metadata schema (TXT records) for latency and synchronization status tagging; modeling and testing the bifurcated registration tiers under simulated low-bandwidth conditions; developing the proprietary synchronization tooling required to enforce the Interplanetary Latency Resolution Protocol; leading fault tolerance scenario testing against simulated communication blackouts.

**Background Story**:
Dr. Kenji Tanaka, based in Tsukuba, Japan, is an aerospace communication systems engineer with a Ph.D. from JAXA's institute, specializing in asynchronous data transfer and fault-tolerant networking concepts for deep space missions. His experience includes designing command-and-control systems capable of operating effectively across Mars-Earth light-speed latency buffers, making him intimately familiar with the technical constraints underpinning Decisions 3, 11, and 12. Kenji is critical because the core value proposition of .mars hinges on solving the latency problem through intelligent DNS layering, which he is leading the design and simulation efforts for, ensuring the bifurcated registration system functions reliably.

**Equipment Needs**:
High-performance computational cluster licenses for simulating light-speed latency models and network fault injection testing; Specialized software licenses for developing and validating proprietary DNS synchronization tooling (e.g., time-stamping and bi-directional delta checking); Access to DNS testing harnesses (e.g., DNSSEC validation tools).

**Facility Needs**:
A dedicated cloud computing environment or lab space provisioned with high-availability resources for continuous testing and simulation of interplanetary communication blackouts and synchronization scenarios.

## 4. DNS Security and Root Management Specialist

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The DNS Security Specialist is highly specialized, critical for HSM procurement and DNSSEC root management (Decision 4). Given the niche expertise required and the project's defined goal of needing specialized input rather than continuous management (mitigated by outsourcing signing), an Independent Contractor securing this high-level expertise is efficient.

**Explanation**:
Owns the implementation of DNSSEC (Decision 4) and the security chain of trust. This person is critical for procuring and managing the Hardware Security Modules (HSMs) and overseeing the outsourced signing functions, ensuring cryptographic integrity from day one.

**Consequences**:
Failure to secure root key custody leads to unacceptable political risk (Risk 5/Issue 3 review point), jeopardizing delegation, or severe operational risk if relying solely on third-party SLAs.

**People Count**:
1

**Typical Activities**:
Procuring, commissioning, and managing the physical Hardware Security Modules (HSMs) for primary key storage; establishing and documenting the internal Key Signing Key (KSK) rollover procedures; defining the cryptographic compliance documents required by ICANN for delegation; overseeing the contractual selection and auditing process for the external DNSSEC signing provider.

**Background Story**:
Elara Rossi, originally from Rome, Italy, is a world-renowned cryptographer and DNS root infrastructure security veteran, deeply familiar with the intricacies of the IETF standards and the physical security requirements for root key management, honed during her time consulting on the global DNSSEC root signing ceremony. She possesses the niche, high-level expertise required to implement Decision 4 correctly, specifically managing Hardware Security Modules (HSMs) and ensuring the root keys (KSK) are never surrendered to external entities, directly addressing the highest-priority security risk identified in the review assessment.

**Equipment Needs**:
Acquisition and secure cabinet housing for dedicated Hardware Security Modules (HSMs) for Key Signing Key (KSK) management; Cryptographic auditing software and tools for key ceremony procedure verification; Secure, audited system access for delegated DNSSEC signing operations.

**Facility Needs**:
A physically hardened, access-controlled room (SCIF equivalent or equivalent certified space) physically isolated from general corporate network infrastructure for the sole purpose of housing and operating the HSMs and managing root key ceremonies.

## 5. Financial Controller and Budget Strategist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Financial Controller manages the high, complex budget, models viability for the 50% revenue pledge (Decision 8), and tracks contingency funds against political delays (Risk 3). This sustained fiduciary responsibility requires full organizational integration.

**Explanation**:
Manages the high capital budget ($25M-$100M+), tracks expenditures for compliance/outreach, models the financial viability of the 50% revenue commitment (Decision 8), and manages contingency reserves against string contention and political delay costs.

**Consequences**:
Budget overruns leading to an inability to fund critical political/legal defense (Risk 3), or insolvency due to underestimating maintenance costs for complex interplanetary tooling.

**People Count**:
1

**Typical Activities**:
Developing the Year 1 break-even volume model to validate the feasibility of the 50% revenue pledge; tracking and forecasting expenditures against political lobbying, string contention defense, and CapEx for HSMs; managing the main capital investment portfolio and establishing contingency drawdown authorization processes; ensuring full budgetary compliance for ICANN financial audits.

**Background Story**:
Marcus Chen, based in Singapore, is a seasoned financial strategist who previously managed the treasury and acquisitions budget for a large telecommunications infrastructure rollup, overseeing capital flows exceeding $500 million across multiple jurisdictions. His expertise centers on high-capital allocation modeling, risk-adjusted contingency planning, and structuring non-standard funding commitments like revenue pledges. Marcus is essential for the 'Builder' strategy as he must ensure the massive $25M-$100M+ budget sustains not only technical compliance but also the political/legal outreach required, while guaranteeing the fiscal viability of Decision 8’s 50% revenue commitment to the environmental fund.

**Equipment Needs**:
Enterprise-grade financial modeling and forecasting software capable of scenario stress-testing against large capital expenditure projections ($100M+); Secure transactional platform for managing high-value contract finalizations (e.g., registry provider services, legal retainers); Specialized software for tracking registry utilization vs. revenue commitment benchmarks.

**Facility Needs**:
Secure office environment with strict auditing protocols necessary for handling highly sensitive financial data, budget contingency drawdown approvals, and external financial reporting disclosures to ICANN.

## 6. Space Agency & Diplomatic Liaison

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Space Agency & Diplomatic Liaison executes the Sovereign Engagement strategy (Decision 5) via targeted, high-level outreach. This often involves short, intense periods of engagement (briefings, negotiation rounds) best suited for experienced diplomacy contractors who possess established networks, rather than internal FTEs.

**Explanation**:
Executes the Sovereign Engagement strategy (Decision 5), handling confidential briefings and negotiating observer status with key international space agencies and telecom regulators (ITU). This role manages political relationship timelines for external buy-in.

**Consequences**:
Failure to secure mandatory governmental endorsements results in high-likelihood political objections during ICANN review, causing significant schedule delays and cost overruns.

**People Count**:
1

**Typical Activities**:
Executing confidential, preemptive technical briefings with major space agency policy directors; drafting and negotiating the terms of non-voting observer seats for partner agencies on technical committees; maintaining liaison with ITU regarding naming interoperability; continuously monitoring geopolitical shifts that could impact the political sensitivity profile.

**Background Story**:
Seamus O’Connell, an Irish national who spent two decades navigating EU and UN regulatory frameworks, serves as the project’s diplomatic nexus, specializing in high-level engagement with sovereign actors in the non-commercial policy space. His background involves structuring international consortia and managing multilateral arms control discussions, giving him the necessary sensitivity to execute Decision 5 by approaching space agencies and telecom regulators (ITU) without triggering perceptions of private overreach. Seamus is crucial for ensuring the application progresses past governmental objection thresholds by securing necessary external political cover.

**Equipment Needs**:
High-level diplomatic briefing materials preparation tools (secure presentation software); Encrypted diplomatic communication channels (e.g., secure VOIP/messaging) for coordinating with space agencies and ITU representatives; Travel budget and secure transport logistics for essential face-to-face governmental strategy sessions.

**Facility Needs**:
Access to private, secure meeting spaces capable of hosting sensitive bilateral discussions with government agency officials, ideally near central policy hubs (e.g., Geneva, Brussels, Washington D.C.).

## 7. Registry Operations & Registrar Onboarding Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Registry Operations and Registrar Onboarding is critical immediately upon delegation (post-18 months) and requires establishing and enforcing initial rule sets (Abuse Policy, Decision 10). This long-term operational continuity favors a dedicated, full-time team member.

**Explanation**:
Manages the post-delegation operational readiness phase (Execution/Maintenance). Responsible for architecting the onboarding workflow for external registrars, establishing abuse reporting pipelines (Decision 10), and ensuring the reliability of Earth-mirror infrastructure contracts.

**Consequences**:
Operational chaos immediately post-delegation, leading to high initial customer confusion, failure to meet service obligations, and inability to enforce abuse/trademark policies efficiently.

**People Count**:
min 1, max 2, dependent on speed of registrar uptake

**Typical Activities**:
Designing the operational runbooks for 24/7 Earth-mirror maintenance and patching; architecting the registrar onboarding portal and technical integration guides; establishing the incident response pipeline for Abuse Prevention Policy enforcement; defining key performance indicators (KPIs) for Earth-mirror uptime and initial registrar transaction success rate.

**Background Story**:
Priya Sharma, who trained in systems operations in Bangalore, India, is the specialist tasked with translating delegated authority into reliable, real-world service availability. Her background includes managing DNS infrastructure scaling for major web services, focusing on the difficult transition phases immediately following delegation and onboarding thousands of external commercial registrars. Priya is responsible for the operational stability of the Earth-mirror infrastructure—a core deliverable—and for implementing the initial Abuse Prevention Policy framework (Decision 10) to maintain service quality from day one.

**Equipment Needs**:
Registrar Onboarding Portal development environment; Robust ticketing and service management system for handling initial registrar and registrant inquiries; Contracts (SLAs) with high-availability DNS infrastructure providers (Earth-side mirrors).

**Facility Needs**:
A dedicated operations center workspace equipped for 24/7 monitoring, incident response management, and hosting the customer/registrar integration support staff.

## 8. Data Integrity Auditor & Synchronization Validator

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Data Integrity Auditor role is based on testing complex fault tolerance scenarios (Decision 12, 14). This function requires independence and specialized auditing skills, making a contracted third-party auditor, potentially acting as an extension of the Trustee Board, the most suitable arrangement for perceived objectivity.

**Explanation**:
Responsible for monitoring, testing, and reporting on data fidelity (Decision 14). This role simulates Mars communication outages, executes fault tolerance scenarios (Decision 12), and provides the final validation checks required by the independent Trustee Board before signing off on record synchronization reports.

**Consequences**:
Undetected drift between Earth mirrors and Mars reality leads to catastrophic failure of trust in the namespace when critical records diverge during a communication blackout.

**People Count**:
1

**Typical Activities**:
Conducting independent, scheduled audits of synchronization logs between designated Earth mirrors and simulated Mars endpoints; executing validation scripts to test the quarantine state procedures during simulated deep-space network blackouts; providing monthly cryptographic assurance reports to the Governance Architect confirming data fidelity alignment across the bifurcated registry tiers.

**Background Story**:
Dr. Lena Vogel, based near Darmstadt, Germany (home of the European Space Operations Centre), is a systems assurance expert whose career has focused on validating mission-critical data integrity across highly unreliable communication links, often acting as an independent auditor for European space programs. Her role is purely focused on verification: she is the external check on the technical team's work, validating the synchronization protocols (Decision 14) and testing the fault tolerance logic (Decision 12) under adversarial conditions. Lena’s objectivity is paramount for convincing the Independent Trustee Board that the Earth-based naming structure is reliable.

**Equipment Needs**:
Independent third-party auditing software licenses for synchronization verification; Tools for generating cryptographic proofs of record fidelity for audit reports; Simulation environments capable of replicating network disconnection events to test fault tolerance decision paths.

**Facility Needs**:
A secure, isolated workspace where audit testing can be conducted without interference from the primary engineering or operations teams, ensuring reporting objectivity for the Independent Trustee Board.

---

# Omissions

## 1. Missing Role: Technical Compliance Liaison (ICANN Specific)

While the ICANN Policy & Regulatory Affairs Lead manages the process, the sheer technical complexity involving novel Interplanetary Latency Resolution Protocols, DNSSEC integration, and the bifurcated registration system requires a dedicated resource to translate complex technical requirements (Decisions 3, 4, 11) specifically into the ICANN compliance documentation format, a task distinct from general policy navigation.

**Recommendation**:
Either add a technical requirement specialization to the ICANN Policy Lead's scope, or hire a specialized technical compliance consultant (short-term contract) whose sole deliverable is certifying the technical readiness documentation for ICANN submission, ensuring zero technical ambiguity in the application dossier.

## 2. Missing Role: Public Information & Ecosystem Outreach Specialist

The project depends heavily on positive public perception and broad ecosystem buy-in to mitigate political risk (Risk 1/5) and realize the 'utility' positioning (Decision 2). Current roles focus on high-level diplomacy (Liaison) and governance chartering (Governance Architect), but lack the function to systematically communicate the TLD's value proposition and technical safety nets to the wider community (researchers, smaller space startups, general public).

**Recommendation**:
Integrate a dedicated 'Ecosystem Communications Manager' (potentially part-time contractor or assigned to the Project Manager) responsible for drafting public-facing documentation, managing the FAQ, and creating educational material about the bifurcated latency tiers, thus proactively controlling the narrative identified as critical in Decision 2.

## 3. Missing Technical Assumption: Mars Endpoint Specification

Multiple decisions (3, 11, 12, 14) rely on Mars-side infrastructure providing status updates for reconciliation. The pre-project assessment identified this as a critical missing assumption (Issue 1 in review), meaning the operational plan lacks a defined minimum standard for the Martian actors it intends to serve.

**Recommendation**:
Formally document a Critical Assumption stating the Minimum Operational Specification (MOS) needed from Mars endpoints (e.g., 100 kbps sustained uplink/downlink, specific synchronization commitment window) and specify the contingency plan (e.g., Beta Tier domain restriction) if this MOS is not met by a key milestone.

---

# Potential Improvements

## 1. Clarify DNSSEC Key Custody Responsibility

Decision 4 allows outsourcing full DNSSEC signing authority, which was flagged as an extreme risk (Issue 3 in review) threatening political legitimacy and security independence. The 'Builder' strategy requires strong assertion of control.

**Recommendation**:
Update the chosen strategy for Decision 4 to mandate internal HSM presence and KSK custody (aligning with Pre-Project Assessment advice). The operational workflow (performed by the DNS Security Specialist) must rigorously document joint KSK rollover procedures involving the external provider only for ZSK signing, ensuring ultimate cryptographic control resides internally under Trustee oversight.

## 2. Define 'Net Revenue' for Commitments

Decision 2 commits 50% of 'net registry revenue' to an environmental fund. Given the high operational complexity and large upfront costs ($25M–$100M+), the definition of 'net' (is it after operational costs, string defense costs, or only post-delegation revenue?) is ambiguous and needs immediate clarification to validate the financial model.

**Recommendation**:
The Financial Controller must draft a formal 'Net Revenue Calculation Policy' documenting that the 50% environmental commitment applies only to revenue generated *after* all ICANN compliance costs, established legal defense funds, and the base operational budget (OpEx) for that calendar year have been fully satisfied. This addresses the viability gap identified in the assumption review.

## 3. Formalize Conflict Management Overlap between Governance and Legal Roles

The Namespace Governance Architect (Decision 1) designs dispute resolution, while the ICANN Policy Lead handles legal objections, and the Financial Controller uses trademark mediation (Decision 6). Potential for overlap/conflict exists in how external disputes are managed versus internal governance disputes.

**Recommendation**:
Establish a clear jurisdictional matrix: Policy Lead handles all *ICANN/Governmental* objections/string contention; Governance Architect handles *internal* TLD policy disputes (Bylaws/Trustee conflicts); Trademark Mediation Panel (Decision 6) handles *registrant-to-registrant IP* conflicts. This ensures clean process flow for Dispute Resolution.

## 4. Structuring Latency Compensation for Usability Tiers

The bifurcated protocol (Decision 3) necessitates clear execution guidelines for the Data Integrity Auditor (Role 8) regarding the low-TTL/high-freshness tier versus the flexible-TTL archival tier.

**Recommendation**:
The Interplanetary Systems Integration Engineer and Data Integrity Auditor must jointly publish the 'Latency Interpretation Guide.' This guide specifies that for the High Freshness tier, client software *must* use data even if stale up to 60 minutes; for the Archival tier, client software *must* assume staleness of 4-48 hours and rely only on the explicit timestamp metadata, ensuring the technical trade-offs translate into actionable client behavior.