## Positive Constraints

- Operate the proposed .mars generic top-level domain (gTLD)
- Establish an Earth-based DNS namespace for Mars-related activity
- Make .mars the default digital addressing layer for missions, infrastructure providers, research organizations, commercial operators, communications services, logistics networks, and eventually identity systems for future settlements
- Secure early stewardship over the most obvious planetary namespace
- Shape the conventions by which Mars-related organizations, services, habitats, vehicles, supply chains, research archives, and public-facing institutions become discoverable from Earth
- .mars domains would initially point to Earth-based mirrors, relay gateways, synchronized caches, or authoritative terrestrial versions of Mars-local resources
- Registry rules must define how registrants identify Mars-local endpoints
- Registry rules must specify Earth-side mirror locations
- Registry rules must report synchronization status
- Registry rules must indicate cache freshness
- Registry rules must describe failover behavior
- Registry rules must implement DNSSEC and related security requirements
- Registry rules must resolve conflicts when Earth-side records and Mars-side records fall out of sync
- .mars must function as a stable Earth-accessible directory for Mars operations
- Assume a high-end budget of USD 25M–100M or more
- Position .mars as a first-mover claim on the digital coordination layer of the future Mars economy
- Set norms for later namespaces tied to lunar bases, asteroid mining operations, orbital habitats, and interplanetary commerce
- Project start ASAP

## Negative Constraints

- Do not assert ownership, sovereignty, or legal control over Mars
- Avoid defining the namespace due to competing actors before Mars commerce, settlement, and governance mature
- Avoid pointing domains directly to infrastructure hosted on Mars initially
