## Positive Constraints

- Operate the .mars generic top-level domain
- Establish an Earth-based DNS namespace for Mars-related activity
- Make .mars the default digital addressing layer
- .mars domains should initially point to Earth-based mirrors
- Implement DNSSEC and related security requirements
- High-end budget of USD 25M–100M or more
