### 1. Project Manager drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**


### 2. Project Manager drafts initial Terms of Reference for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Core Team ToR v0.1

**Dependencies:**


### 3. Project Manager drafts initial Terms of Reference for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**


### 4. Project Manager drafts initial Terms of Reference for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**


### 5. Circulate Draft SteerCo ToR for review by Senior Management Representative, CTO, CFO, and Project Manager.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1

### 6. Circulate Draft Core Team ToR for review by Optical Engineer, Mechanical Engineer, Thermal Engineer, Control Systems Engineer, Metrology Specialist, and Lead Technician.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Core Team ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft Core Team ToR v0.1

### 7. Circulate Draft TAG ToR for review by Senior Optical Engineer, Senior Mechanical Engineer, Senior Thermal Engineer, Senior Control Systems Engineer, and Metrology Specialist.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft TAG ToR v0.1

### 8. Circulate Draft Ethics & Compliance Committee ToR for review by Legal Counsel, Compliance Officer, Safety Officer, and Environmental Officer.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 9. Project Manager finalizes the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 10. Project Manager finalizes the Core Project Team Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Core Team ToR v1.0

**Dependencies:**

- Feedback Summary

### 11. Project Manager finalizes the Technical Advisory Group Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final TAG ToR v1.0

**Dependencies:**

- Feedback Summary

### 12. Project Manager finalizes the Ethics & Compliance Committee Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 13. Senior Management Representative formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** Senior Management Representative

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 14. Senior Management Representative confirms Project Steering Committee membership (Senior Management Representative, CTO, CFO, Independent Technical Expert, Project Manager).

**Responsible Body/Role:** Senior Management Representative

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Appointment Confirmation Email

### 15. Project Steering Committee Chair schedules initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Membership Confirmation Email

### 16. Hold initial Project Steering Committee kick-off meeting to review ToR, approve initial project plan, and define escalation paths.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Project Plan v1.0

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 17. Project Manager confirms Core Project Team membership (Project Manager, Optical Engineer, Mechanical Engineer, Thermal Engineer, Control Systems Engineer, Metrology Specialist, Lead Technician).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Final Core Team ToR v1.0

### 18. Project Manager schedules initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Membership Confirmation Email

### 19. Hold initial Core Project Team kick-off meeting to review ToR, define roles and responsibilities, establish communication protocols, and set up project tracking systems.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Defined Roles and Responsibilities
- Communication Protocols
- Project Tracking System Setup

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 20. Project Manager confirms Technical Advisory Group membership (Senior Optical Engineer, Senior Mechanical Engineer, Senior Thermal Engineer, Senior Control Systems Engineer, External Technical Expert, Metrology Specialist).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Final TAG ToR v1.0

### 21. Senior Optical Engineer schedules initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Senior Optical Engineer

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Membership Confirmation Email

### 22. Hold initial Technical Advisory Group kick-off meeting to review ToR and define scope of technical expertise.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Defined Scope of Technical Expertise

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 23. Legal Counsel confirms Ethics & Compliance Committee membership (Legal Counsel, Compliance Officer, Safety Officer, Environmental Officer, Independent Ethics Advisor).

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 24. Legal Counsel schedules initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Membership Confirmation Email

### 25. Hold initial Ethics & Compliance Committee kick-off meeting to review ToR, develop compliance policies and procedures, and identify relevant regulatory requirements.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Compliance Policies and Procedures
- Identified Regulatory Requirements

**Dependencies:**

- Meeting Invitation
- Meeting Agenda