**Primary domain:** Optical Engineering

**Secondary domains:** Thermal-Structural-Optical Modeling, Vibration Testing, Beam Control Systems

**Rationale:** Optical Engineering is selected because the primary success criterion is achieving target operational beam quality (Strehl ratio), which is the core outcome. Beam Control Systems and High-Energy Laser Systems, while related outcomes, are subordinate to the physical optical performance achieved.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Optical Engineering | 5 | 5 | outcome | The core objective is preserving optical coherence and far-field beam quality. |
| Beam Control Systems | 5 | 4 | outcome | The core outcome is maintaining optical coherence and far-field beam quality. |
| Vacuum Technology | 4 | 5 | constraint | Operation in hard vacuum necessitates specific testing and contamination control checks. |
| High-Energy Laser Systems | 5 | 4 | outcome | The project goal is the validation of space-based coherent beam combining performance. |
| Thermal-Structural-Optical Modeling | 4 | 4 | method | The project develops and validates a radial TSO scaling model for larger apertures. |
| Vibration Testing | 4 | 4 | method | Flight-representative vibration spectra are explicitly injected to test disturbance rejection. |
| Metrology and Sensing | 4 | 4 | method | Phase correction, heterodyne detection, and SNR measurement are central to validation. |
| Contamination Control Engineering | 4 | 4 | constraint | Bakeout, certification, witness samples, and cleanliness gates are explicit project requirements. |
| Control Systems Engineering | 4 | 3 | method | Phase correction bandwidth validation, control-structure interaction screening, and seam phasing require control expertise. |