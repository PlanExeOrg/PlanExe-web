This plan implies one or more physical locations.

## Requirements for physical locations

- Hard vacuum environment capability
- High-power optical testing infrastructure
- Precision thermal loading/transient heat injection capability
- Flight-representative vibration testing/shaker tables
- Advanced optical diagnostics and common-path metrology implementation
- Space/facility overhead for control electronics and vacuum pumps

## Location 1
USA

California

Jet Propulsion Laboratory (JPL) / Large Test Facilities

**Rationale**: JPL has extensive heritage, specialized vacuum test chambers (e.g., the Spacecraft Thermal Vacuum Chamber - STV) capable of handling high-flux optical systems, sophisticated vibration platforms, and established protocols for contamination control required for this high-fidelity space-based validation.

## Location 2
USA

Colorado

Air Force Research Laboratory (AFRL) Directed Energy Directorate Facilities

**Rationale**: AFRL facilities, particularly those focused on high-energy laser and adaptive optics research, possess the necessary high-power laser infrastructure, thermal management interfaces, and experienced personnel for complex physics demonstration testing under vacuum.

## Location 3
Europe

Germany

European Space Agency (ESA) Large Vacuum Testing Facilities (e.g., ESTEC)

**Rationale**: ESA facilities offer world-class, massive vacuum chambers and environmental test hardware (thermal/vibration) designed specifically for the qualification of complex flight hardware like optical payloads, ensuring representative space conditions.

## Location Summary
The plan requires a highly specialized facility capable of supporting simultaneous vacuum operation, high-power laser throughput, complex optical metrology, and integrated environmental stress testing (thermal transients and high-bandwidth vibration). Three leading candidates—JPL (USA), AFRL (USA), and ESA facilities in Germany—possess the necessary combination of large-scale vacuum chambers and expertise in high-fidelity optical payload qualification under flight-representative loading.