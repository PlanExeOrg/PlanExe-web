## Primary Decisions
The vital few decisions that have the most impact.


The vital few levers (Critical and High) center on validating and extrapolating the Thermal-Structural-Optical (TSO) model robustness, which is the core purpose. Levers governing the TSO Model Scope (417705ac, cd91e768) and the empirical data used to build it (75895644) are paramount. Concurrently, ensuring dynamic fidelity via the Sampling Frequency (0c97922b) and defining realistic power budgets via WPE Boundaries (a7e58aa6, 4df6bb9f) address the key trade-offs: Model Extrapolation Success vs. Dynamic Stress Rejection vs. Flight Power Budget Compliance.

### Decision 1: Engine Efficiency Measurement Boundary
**Lever ID:** `a7e58aa6-a7b0-4a02-b3b1-4184e1c84d93`

**The Core Decision:** This lever dictates the scope of the Wall-Plug Efficiency (WPE) measurement, specifically whether auxiliary power consumption (phasing, metrology, control) is included in the denominator for the Engine WPE calculation. Choosing a narrower scope simplifies instrumentation but overstates flight-relevant power density. Success relies on achieving the target WPE based on the chosen boundary, critically impacting thermal design margins.

**Why It Matters:** Switching the definition of Wall-Plug Efficiency (WPE) (ii) to only include laser/amplifier tile power (i) drastically simplifies the required instrumentation and reduces overall calibration complexity. However, this neglects the significant parasitic losses associated with the complex phase correction, metrology hardware, and high-speed control electronics, meaning the reported Engine WPE target will appear substantially higher than the true system-level power draw accessible to ground support.

**Strategic Choices:**

1. Certify performance based exclusively on laser/amplifier WPE (i), excluding all necessary phasing and control electronics power from the denominator.
2. Standardize WPE reporting on Engine WPE (ii) but use a simplified, fixed overhead power budget allocation for control electronics instead of metered consumption.
3. Mandate full Engine WPE (ii) measurement but defer the backscatter/SNR burn-down test until after the WPE qualification to prioritize achieving efficiency targets first.

**Trade-Off / Risk:** Reporting only laser WPE risks masking unsustainable heat loads from the control system, which is critical for space-based power budgets; this choice sacrifices true system power validation for measurement simplicity.

**Strategic Connections:**

**Synergy:** It directly relates to Wall-Plug Efficiency Reporting Boundary Definition, clarifying the denominator scope for power metric validation under stress tests.

**Conflict:** It conflicts with Engine Efficiency Measurement Boundary if a simplified definition is chosen, as this simplifies instrumentation at the expense of true system power budgeting.

**Justification:** *High*, This lever dictates the project's power budget credibility. Choosing a simpler boundary risks failing to capture critical subsystem heat loads, compromising the realistic thermal design foundation derived from the WPE target.

### Decision 2: Thermal-Structural-Optical Model Validation Scope
**Lever ID:** `417705ac-8458-493b-8881-53d262ac3d3b`

**The Core Decision:** This strategic choice determines which test conditions feed the Thermal-Structural-Optical (TSO) scaling model for extrapolation to larger apertures. Restricting input to only unconstrained tests simplifies mounting but potentially yields less accurate radial scaling parameters. Success is measured by minimizing the final uncertainty bound on the 19+ aperture performance prediction.

**Why It Matters:** Restricting the TSO model parameter extraction solely to data gathered during the unconstrained boundary condition test significantly simplifies the required mechanical staging and measurement setup stages. This approach, however, introduces high uncertainty into the scaling parameters intended for the 19+ tile multi-ring system, as the thermal and structural coupling effects inherent in the outer six perimeter tiles are not adequately characterized under operational loads.

**Strategic Choices:**

1. Only derive TSO scaling parameters from the dedicated, fully instrumented test runs conducted using the unconstrained perimeter stiffness configuration.
2. Mandate a series of discrete, single-tile thermal soak tests to isolate the material response variables before integrating them into the coupled TSO model.
3. Use extrapolation bounds derived only from the center tile's response to localized heat injection, treating the six surrounding tiles only as passive thermal sponges.

**Trade-Off / Risk:** Ignoring the constrained boundary condition data reduces the required test matrix complexity but artificially shrinks the measured uncertainty bounds on the vital radial scaling model extrapolation for larger apertures.

**Strategic Connections:**

**Synergy:** It critically informs the Radial TSO Model Extrapolation Strategy by limiting the data set used to generate the scaling law for future systems.

**Conflict:** It conflicts with Center Tile Boundary Condition Equivalence, as focusing only on the unconstrained state minimizes the characterization of thermal/structural coupling effects.

**Justification:** *Critical*, This lever controls the accuracy of the central deliverable: the TSO scaling model for 19+ apertures. Limiting inputs introduces high uncertainty into the primary means of extrapolating results beyond the '1+6' demonstration.

### Decision 3: Far-Field Metric Sampling Frequency
**Lever ID:** `0c97922b-5269-4daf-89d6-a1184a2c79b9`

**The Core Decision:** This lever governs the temporal resolution of far-field beam quality assessment. A lower sampling frequency reduces data volume but risks completely missing high-frequency wavefront jitter induced by vibration or rapid thermal changes. Success requires meeting the System Strehl threshold during dynamic stress, necessitating a sampling rate tied to the disturbance rejection bandwidth (>5 kHz).

**Why It Matters:** Switching the far-field metric sampling to capture only the low-frequency power spectral density bins (below 1 kHz) simplifies beam propagation measurements by reducing required detector readout speed and data volume handling. This decision, however, renders the operational beam quality verification incapable of detecting beam degradation induced by the high-frequency, rapidly fluctuating thermal gradients or dynamic wavefront errors above the sampling rate.

**Strategic Choices:**

1. Increase the far-field measurement sampling rate to capture statistical variation across the full >5 kHz local phase correction bandwidth at a reduced duty cycle.
2. Define operational beam quality assessment based on the time-averaged Strehl ratio measured only once per thermal time constant, ignoring transient jitter.
3. Use the low-power sample for high-speed transient capture, while restricting the high-power sample to only long-exposure integration to satisfy the post-last-optic constraint.

**Trade-Off / Risk:** Reducing sampling frequency to manage data volume sidesteps the dynamic validation requirement that the system Strehl must remain above the threshold *during* the defined thermal and vibration stress profiles.

**Strategic Connections:**

**Synergy:** It must align with Optical Coherence Assessment Under Stress to ensure the measurement duration captures transient effects critical for validation.

**Conflict:** It may conflict with Post-Vibration Retention Qualification Timeframe if a low frequency is chosen, as transient beam jitter during vibration will be averaged out, masking stability issues.

**Justification:** *High*, This directly governs whether the validation successfully captures dynamic wavefront errors by tying the measurement sampling rate to the required >5 kHz control bandwidth, which is essential for dynamic disturbance rejection validation.

### Decision 4: Radial TSO Model Extrapolation Strategy
**Lever ID:** `cd91e768-e9fa-4878-adcc-d5df2b0d7fef`

**The Core Decision:** This defines the breadth of experimental data used to train the scaling model for 19+ tiles, using the '1+6' array. Limiting extrapolation to only center-tile constrained data increases uncertainty for models dependent on wider array boundary effects. The success criterion is maintaining acceptably tight uncertainty bounds for the final 19+ performance prediction.

**Why It Matters:** The current design uses the '1+6' topology to emulate a fully surrounded center tile, generating parameters for a radial TSO scaling model targeting 19+ tiles. Choosing to only constrain the radial expansion based on the '1+6' center tile data limits the model's extrapolation fidelity, as second-ring effects (which influence the central boundary conditions in a 19+ array) are only implicitly captured. Downstream, this simplification significantly increases the uncertainty bounds on the predicted Strehl ratio for the full 19-tile system compared to one where boundary conditions representing an intermediate '1+6+12' topology are also derived and characterized.

**Strategic Choices:**

1. Derive TSO scaling parameters solely from center-tile performance under the '1+6' constraint, prioritizing rapid delivery of the basic scaling law for the demonstration milestone.
2. Characterize the center tile performance, then impose calibrated edge-tile boundary conditions derived from finite differences in the existing TSO model to generate synthetic data points for the 19+ extrapolation curve.
3. Characterize the center tile performance under both '1+6' and an artificially created '1+6+12' boundary emulation condition, accepting schedule slippage to reduce the extrapolation uncertainty margin on the final 19+ prediction.

**Trade-Off / Risk:** Focusing only on the 1+6 result minimizes data capture complexity but severely compromises the uncertainty envelope for the 19+ extrapolation, potentially leading to an under-spec'd full system design later.

**Strategic Connections:**

**Synergy:** It provides the core input data set for the Thermal-Structural-Optical Model Validation Scope, determining the quality of the resulting scaling parameters.

**Conflict:** It may conflict with Center Tile Boundary Condition Equivalence, as simplifying the data capture here ignores necessary stress cases required for robust multi-ring emulation.

**Justification:** *Critical*, This defines *how* the 1+6 test informs the 19+ goal. It is intrinsically linked to Lever 417705ac, but this specifically governs the resulting uncertainty bounds of the final extrapolation, making it the foundational choice for future system sizing.

### Decision 5: Center Tile Boundary Condition Equivalence
**Lever ID:** `75895644-30a7-4ca7-9bf5-1d34411d117b`

**The Core Decision:** This lever governs the mechanical interface stiffness applied to the center tile, which is crucial for calibrating the radial TSO scaling model intended for 19+ apertures. The core task is to choose a constraint that robustly emulates multi-ring confinement while allowing measurement of resulting phase stability data. Success hinges on selecting settings that span the uncertainty space required for accurate model extrapolation.

**Why It Matters:** Adjusting the perimeter constraint stiffness directly alters the mechanical coupling felt by the central tile, changing the effective boundary conditions for the TSO radial model. If the selected constraint setting is too loose, the system simulates an unconstrained tile, providing insufficient data for the primary scaling target requiring confinement emulation, leading to high uncertainty in the 19+ tile extrapolation.

**Strategic Choices:**

1. Lock the perimeter constraint stiffness exclusively to the configuration yielding the lowest observed phase jitter during low-power alignment checks to ensure initial optical stability.
2. Execute tests across the full range of stiffness configurations, systematically measuring the resulting center-tile RMS wavefront error variance under thermal load to bound the model input uncertainty.
3. Fix the perimeter constraint stiffness at the statically safest setting predicted by the initial structural model, prioritizing mechanical integrity over accurate emulation of multi-ring confinement.

**Trade-Off / Risk:** Selecting the lowest jitter setting simplifies data collection but fails to calibrate the stiffness parameter required for the scaling model, leaving the primary deliverable unverified against its intended operating range.

**Strategic Connections:**

**Synergy:** It enables the Thermal-Structural-Optical Model Validation Scope by generating the required input variance (stiffness settings) necessary to bound the uncertainty in the TSO scaling extrapolation.

**Conflict:** It conflicts with Center Tile Boundary Condition Equivalence, as focusing on minimizing phase jitter (a consequence) may lead to locking the stiffness in a range that prevents accurate emulation of confinement boundary conditions.

**Justification:** *High*, This lever controls the primary input data generation for the TSO model (via mechanical setup). It is the practical realization of the strategy set by the Extrapolation Strategy lever, directly influencing model accuracy.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: High-Power Qualification Precursor Sequencing
**Lever ID:** `e45e4a88-02ee-46b0-8a44-550a5306a4fc`

**The Core Decision:** This lever mandates the sequence between initial environmental qualification (bakeout/contamination control) and the system-level noise floor assessment (backscatter/SNR burn-down). Prioritizing the burn-down test first exposes the sensitive metering hardware to initial, uncertified operation. Success is defined by qualifying the low-level sensing chain before high-power integration begins, regardless of the precursor sequencing choice.

**Why It Matters:** The plan requires completing the backscatter/SNR burn-down test *before* full array integration to qualify the beam dump and sensing chain. If the bakeout/contamination certification is performed *before* this early burn-down test, any post-bakeout contamination event during setup or initial low-power runs could poison the optics just as the high-power phase begins. Reversing this—performing the backscatter/SNR qualification first—allows the system to 'self-clean' the optics slightly via initial low-power operation before the contamination gate is rigorously enforced, though it risks performing the rigorous noise measurement on slightly contaminated surfaces.

**Strategic Choices:**

1. Execute the full contamination certification (bakeout, witness sample analysis) immediately following mechanical integration, then proceed directly to the initial power-up for the backscatter/SNR burn-down test.
2. Front-load the backscatter/SNR burn-down test immediately after vacuum pump-down to confirm beamline suppression while using lower-power pilot tones, delaying the formal contamination gate until after initial high-power runs.
3. Run the system through three full thermal-transient cycles at 50% power before any strict contamination gate or SNR test, accepting that this accelerates aging to ensure component settling before formal qualification.

**Trade-Off / Risk:** Placing the contamination gate first ensures pristine optics for the sensitive SNR burn-down, but risks contamination occurring during the subsequent high-power integration phase before the final stability checks.

**Strategic Connections:**

**Synergy:** It directly affects High-Power Optical Surface Degradation Oversight by determining if contamination certification occurs before or after initial high-power system exposure.

**Conflict:** It conflicts with Optical Coherence Assessment Under Stress if the burn-down is delayed, as lower-sensitivity measurements might mask stray-light issues before the noise floor is rigorously established.

**Justification:** *Medium*, This is an important operational sequencing choice affecting the cleanliness of the optics during critical noise floor measurement, but it is secondary to the fundamental performance metrics (Strehl, TSO Model) being generated.

### Decision 7: Optical Coherence Assessment Under Stress
**Lever ID:** `ea4324d3-8a38-40b8-95c8-ef0c79fb63c3`

**The Core Decision:** This lever defines the operational criterion for declaring stability, linking 'sustained' operation to either a fixed duration (300s) or the stabilization of the critical optical metric (Strehl). The scope is to ensure wavefront quality remains locked during simultaneous thermal/dynamic stress. Success relies on correctly identifying the governing TSO time constant via measured Strehl settling, which directly dictates the required test duration for final qualification.

**Why It Matters:** Sustained operation is defined by either 300 seconds or three dominant TSO time constants, whichever is longer, assessed via measured Strehl settling. If the team conservatively uses the slowest known thermal time constant (e.g., the chamber wall), the test duration could become excessively long, potentially exceeding the available test facility time. Conversely, defining the required duration based solely on the *measured* Strehl settling might allow the test to conclude quickly if the wavefront stabilizes rapidly, even if critical, slower thermal modes impacting the control electronics have not fully reached equilibrium.

**Strategic Choices:**

1. Define the 'sustained' hold time for all qualification runs solely based on the mathematically derived longest thermal time constant of the primary optical element mounting structure, regardless of observed Strehl settling.
2. Establish the required sustained duration for each test profile dynamically, halting the clock only when the measured system Strehl ratio remains within 1% of its final settled value for 60 continuous seconds.
3. Enforce a fixed minimum hold time of 1200 seconds for every sustained run, irrespective of analytical models or early Strehl settling, to ensure all hardware experiences long-term charging effects.

**Trade-Off / Risk:** Relying solely on observed Strehl settling shortens test duration but risks reporting stability based on an incomplete thermal profile, potentially masking long-term drift in control loop performance.

**Strategic Connections:**

**Synergy:** It synergizes with Thermal-Structural-Optical Model Validation Scope by providing the essential empirical settling time data needed to refine and confirm the model's predicted time constants.

**Conflict:** It directly conflicts with Wall-Plug Efficiency Reporting Boundary Definition, as aggressively short, Strehl-based hold times reduce the total integrated thermal load experienced during WPE measurement periods.

### Decision 8: Wall-Plug Efficiency Reporting Boundary Definition
**Lever ID:** `4df6bb9f-521b-42da-a413-c35eb1635099`

**The Core Decision:** This lever dictates how energy conversion metrics are quantified and presented, directly influencing design emphasis between laser raw performance and full engine power management. The scope is to set the formal boundary for the WPE $\ge 35\%$ requirement. Reporting engine WPE forces efficiency prioritization across metrology, control, and phasing electronics, linking directly to thermal management complexity.

**Why It Matters:** The choice of WPE boundary significantly impacts whether the target of $\ge 35\%$ is met and influences downstream design priorities for peripheral electronics. Reporting only 'laser WPE' (optical power out vs. laser/amplifier power) provides the best headline number but obscures the true system power draw required for flight acceptance, masking inefficiencies in beam control electronics. Including control power as 'engine WPE' imposes a strict requirement on actuator/driver efficiency, which complicates the primary thermal load management task.

**Strategic Choices:**

1. Report only the 'laser WPE' boundary, isolating the thermal contribution solely to the active gain elements and prioritizing optical output efficiency above all else.
2. Report the comprehensive 'engine WPE,' mandating that the efficiency targets drive the design of the narrowband filtering and detector protection electronics.
3. Report both 'laser WPE' and 'engine WPE' but only maintain the $\ge 35\%$ threshold on the 'laser WPE,' treating control overhead as separately managed overhead.

**Trade-Off / Risk:** Focusing solely on laser WPE maximizes the stated metric but fails to fully inform the flight power budget, potentially leading to thermal design compromises necessary to manage the non-optical control system power draw.

**Strategic Connections:**

**Synergy:** It reinforces Engine Efficiency Measurement Boundary by formally defining the precise electrical input reference point, ensuring consistency in the efficiency data used for thermal budget calculations.

**Conflict:** Selecting the comprehensive 'engine WPE' conflicts with High-Power Qualification Precursor Sequencing, as optimizing efficiency across all components may delay the prerequisite backscatter/SNR burn-down test due to control system calibration needs.

**Justification:** *High*, This choice defines the target metric credibility for thermal management. Discrepancy here creates a conflict between lab simplicity and flight hardware relevance, impacting acceptance criteria (WPE >= 35%).

### Decision 9: Post-Vibration Retention Qualification Timeframe
**Lever ID:** `15e98894-10b3-4222-8e0a-2b21fc5f6623`

**The Core Decision:** This lever addresses the required stability duration for the optical alignment and phase solution immediately following exposure to intense flight-representative vibration spectra. The goal is to decouple mechanical shock effects from slower thermal relaxation. Success is achieved by selecting a hold time that isolates mechanical settling physics without allowing time-dependent environmental drift (e.g., chamber air currents) to corrupt the structural retention measurement.

**Why It Matters:** The post-vibration retention requirement mandates that alignment and phasing must hold without tuning, but the maximum allowable time limit for this stability check is undefined in the plan. Allowing a very short hold time (e.g., one structural time constant) validates immediate mechanical settling but fails to capture potential slower relaxation effects or friction-based creep in the mounts after dynamic shock. Conversely, waiting too long risks ambient drift or slow thermal equilibration that compromises the 'vacuum-truth' nature of the measurement.

**Strategic Choices:**

1. Wait the full 300-second window post-vibration before sampling the retention status, ensuring capture of any slower mechanical settling modes impacting alignment.
2. Immediately sample the retention status three seconds after the vibration shaker final shutdown, prioritizing the immediate mechanical response over long-term drift.
3. Execute the retention check only after the payload has achieved thermal equilibrium with the surrounding vacuum chamber walls, guaranteeing a baseline optical stability.

**Trade-Off / Risk:** Waiting the full 300 seconds might include significant thermal relaxation following the vibration soak, potentially confusing structural instability retention with passive thermal re-stabilization effects on alignment.

**Strategic Connections:**

**Synergy:** It works synergistically with Optical Coherence Assessment Under Stress by establishing the minimum post-disturbance criterion for alignment retention that must be met before the sustained run timer begins.

**Conflict:** It creates a subtle trade-off with High-Power Optical Surface Degradation Oversight, as executing the retention check immediately after vibration limits the opportunity to assess long-term contamination build-up during a standard prolonged run.

**Justification:** *Medium*, This establishes a stability check duration following vibration. While important for qualification compliance, the time window chosen is less foundational than the measurement frequency or model inputs.

### Decision 10: High-Power Optical Surface Degradation Oversight
**Lever ID:** `20fa3298-78e8-4316-9a47-517638632297`

**The Core Decision:** This lever sets the cadence for monitoring optical throughput degradation, primarily targeting laser-induced contamination (LIC) or mirror aging under high fluence. The scope is to balance early warning capability against measurement overhead. High frequency allows tight control over the allowable throughput slope, ensuring performance drifts are detected well before the end-of-life qualification criteria are reached.

**Why It Matters:** Monitoring throughput degradation provides an early warning against laser-induced contamination (LIC) or mirror surface deterioration, but the measurement frequency dictates the actionable lead time for intervention. Frequent monitoring establishes a tight control slope that prevents significant throughput loss, but this adds operational overhead to the measurement system setup requiring time-consuming alignments or frequent sensor re-calibration. A less frequent check reduces immediate overhead but risks crossing the allowable degradation slope before the non-conformance is detected.

**Strategic Choices:**

1. Increase monitoring frequency to hourly throughput checks during the first week of high-power runs, allowing near-real-time identification of any surface-related degradation trends.
2. Limit throughput checks to scheduled daily verification gates, minimizing interference with continuous 300-second stability runs but accepting potential delayed detection of LIC onset.
3. Only monitor throughput when the system is actively undergoing thermal transient cycling, linking degradation measurement directly to the period of maximum structural stress.

**Trade-Off / Risk:** Hourly throughput checks provide the best early warning for contamination onset but place a heavy administrative and alignment burden on the short validation campaign timeline.

**Strategic Connections:**

**Synergy:** It is critical for High-Power Qualification Precursor Sequencing, as a successful surface degradation burn-down test directly qualifies the sensitivity and methodology used for this continuous oversight lever.

**Conflict:** It conflicts with Optical Coherence Assessment Under Stress because aggressively frequent monitoring introduces operational pauses and potential alignment perturbations, disrupting the continuous measurement required for accurately determining the sustained Strehl settling time constant.

**Justification:** *Medium*, This defines the diligence applied to monitoring long-term surface integrity under fluence. It is a crucial operational control but an optimization of the required Strehl stability rather than a driver of the core TSO/Dynamic performance.
