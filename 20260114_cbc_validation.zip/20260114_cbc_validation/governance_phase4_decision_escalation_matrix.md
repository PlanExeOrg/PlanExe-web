**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Consensus-driven majority vote
Rationale: Exceeds financial limit for PMO approval, requiring higher authority for budget adjustments.
Negative Consequences: Potential project delays or inability to fund critical testing phases.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Strategic Risk Posture Review
Rationale: Significant risk to project objectives that cannot be mitigated at the Core Project Execution Team level.
Negative Consequences: Increased likelihood of project failure or significant delays.

**PMO Deadlock on Key Operational Decision**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Simple majority vote
Rationale: Operational decisions require consensus that cannot be reached within the Core Project Execution Team.
Negative Consequences: Delays in project execution and potential misalignment on critical testing parameters.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Consensus-driven majority vote
Rationale: Changes to project scope require higher-level approval to assess impacts on budget and timeline.
Negative Consequences: Scope creep leading to budget overruns and extended timelines.

**Reported Ethical Concern**
Escalation Level: Compliance, Assurance, and Metrology Board (CAMB)
Approval Process: Unanimous agreement required for issuing 'Hold' directives
Rationale: Ethical concerns must be independently reviewed to ensure compliance with safety and operational standards.
Negative Consequences: Legal repercussions and damage to project reputation if not addressed properly.