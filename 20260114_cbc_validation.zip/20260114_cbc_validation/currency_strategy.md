This plan involves money.

## Currencies

- **USD:** The project is centered in the USA (JPL/AFRL mentioned as leading candidates) and the budget is significant ($20M), making USD the natural base currency for contracting and high-value equipment procurement.
- **EUR:** One leading potential test site is in Germany (ESA/ESTEC), meaning EUR transactions for local services or facility usage may occur.

**Primary currency:** USD

**Currency strategy:** As the project budget is substantial ($20M) and the primary engineering/procurement base is assumed to be the US, USD will be the primary currency for budgeting and reporting. Transactions involving European test sites (ESTEC) will require management of EUR exposure, likely through operational hedging or utilizing corporate accounts that minimize foreign transaction fees.