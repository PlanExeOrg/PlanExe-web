### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Required for high-level strategic direction, financial authorization ($20M budget), ultimate risk acceptance, and resolving major cross-functional trade-offs identified in the strategic decisions (e.g., prioritizing TSO model fidelity over immediate schedule).

**Responsibilities:**

- Approve major scope changes, budget releases above $1M, and schedule re-baselines.
- Provide strategic arbitration when conflicts arise between technical verification goals and operational constraints.
- Review and accept final TSO Scaling Model uncertainty bounds deliverable.
- Oversight of high-level compliance status (Laser Safety, Facility Access Agreements).

**Initial Setup Actions:**

- Define and formally approve Project Charter and Terms of Reference (ToR).
- Elect the Committee Chair (typically a high-level Sponsor representative).
- Finalize the initial $5M budget release authority levels for the Project Director.
- Review and formally accept the 'Pioneer' strategic path.

**Membership:**

- Program Director (Chair)
- Lead Optical Scientist (Technical Authority)
- Thermal-Structural Analyst (Modeling Authority)
- Project Sponsor Representative (Financial Authority)
- Head of Engineering (Execution Oversight)

**Decision Rights:** Strategic direction, budget approval thresholds (> $1M), acceptance of major project milestones, major scope deviation approval. Has final sign-off on TSO Model uncertainty reduction.

**Decision Mechanism:** Consensus-driven majority vote (75% approval required). Tie-breaker: The Program Director's vote carries the tie broken vote, subject to challenge via Executive Sponsor.

**Meeting Cadence:** Monthly (or bi-weekly during critical integration/testing phases).

**Typical Agenda Items:**

- Review of Milestone Achievement vs. Baseline.
- Strategic Risk Posture Review (focusing on Critical risks).
- Approval of budget spend outside of operational tolerances.
- Review of TSO Model Uncertainty Bounds progress.

**Escalation Path:** Unresolvable conflicts, financial issues exceeding authority, or failure to meet Level 1 Go/No-Go Gates are escalated directly to the Executive Portfolio Management Board.
### 2. Core Project Execution Team (CPET)

**Rationale for Inclusion:** Responsible for the day-to-day execution, technical problem-solving, adherence to test procedures, management of operational risks (e.g., contamination, dynamic tuning), and ensuring all measurements rigorously meet the detailed requirements (e.g., >5kHz sampling, dynamic WPE accounting).

**Responsibilities:**

- Manage the 18-month schedule and resource allocation below strategic thresholds.
- Execute environmental testing (thermal transient injection, vibration profiling) per plan.
- Manage Control-Structure Interaction (CSI) screening and phase correction tuning.
- Oversee contamination control certification procedures and witness sample tracking.
- Execute the early Backscatter/SNR burn-down test and formally report results to the PSC.

**Initial Setup Actions:**

- Finalize detailed 18-month integrated master schedule.
- Establish operational communication rhythm and issue tracking system.
- Formalize interfaces and test procedures with facility operations teams.
- Define and configure the operational baseline for the Engine WPE metering system.

**Membership:**

- Project Director (Chair, Internal PM)
- Lead Optical Scientist (Testing Lead)
- Beam Control Systems Engineer
- Thermal/Structural Lead
- Facility Operations Liaison
- Risk Manager (Non-voting, risk tracking)

**Decision Rights:** Operational decisions, scheduling adjustments within 2-week tolerance, expenditure authority up to $50,000 per event, definition of operational test parameters below strategic thresholds (e.g., specific stiffness lock-in settings, metrology alignment tolerances).

**Decision Mechanism:** Simple majority vote. Decisions requiring trade-offs between technical domains (e.g., time spent on thermal soak vs. dynamic vibration) are immediately escalated if team consensus is not reached within 48 hours.

**Meeting Cadence:** Daily brief (pre-test/post-test checks); Weekly review of technical progress and operational issues.

**Typical Agenda Items:**

- Daily Status & Safety Check (High-Power Laser Handoff).
- Review of operational risks (R&O log).
- Pass/Fail status of last test run vs. required metrics (Strehl/WPE/Sustained time).
- Contamination Status Update (cleanliness gates adherence).

**Escalation Path:** Issues requiring expenditure >$50,000, schedule shifts > 2 weeks, or unresolved multi-domain technical conflicts are escalated immediately to the Project Steering Committee (PSC).
### 3. Compliance, Assurance, and Metrology Board (CAMB)

**Rationale for Inclusion:** Due to the high complexity, mandatory contamination control, requirement for rigorous model validation (TSO), and the audit risks identified, a dedicated assurance body is necessary to provide independent oversight on data integrity, compliance adherence (GDPR/Safety not primary focus, but contamination/laser safety is paramount), and measurement fidelity.

**Responsibilities:**

- Independently audit the implementation of the chosen WPE metering configuration (Decision 8).
- Assure the integrity and uncertainty bounds of the TSO scaling data gathered (Decision 2/4).
- Validate the sampling rate compliance for the >5 kHz bandwidth assessment (Decision 3).
- Oversee and formally sign off on all Contamination Certification Gates (bakeout completion, witness sample results).
- Verify adherence to the required post-vibration retention timeframe (Decision 9).

**Initial Setup Actions:**

- Establish independent audit trail procedures for all metrology data streams.
- Define the internal verification matrices for TSO parameter derivation.
- Review and audit the Backscatter/SNR burn-down test results (early validation gate).
- Establish the standard operating procedure for data retention (90-day minimum retention for auditability).

**Membership:**

- Lead Compliance Officer (Chair)
- Independent Quality Assurance (QA) Auditor (External/Independent Role)
- Lead Metrology Engineer (Data Chain Integrity)
- External TSO Model Expert (for oversight of scaling derivation robustness)

**Decision Rights:** Authority to issue 'Hold Test Run' directives if integrity of compliance/measurement chain is compromised; Authorization to sign-off on contamination certification gates and data reporting methodology fidelity (but not on final mission performance acceptance).

**Decision Mechanism:** Unanimous agreement required for issuing 'Hold' directives or signing off on contamination certification. Tie-breaker: PSC referral if deadlock occurs regarding data integrity.

**Meeting Cadence:** Bi-weekly during active testing; Monthly review of all logged process data integrity checks.

**Typical Agenda Items:**

- Review of WPE Metering Configuration Reconciliation (Engine vs Laser WPE).
- Contamination Control Gate Status (Witness Sample trends).
- Review of TSO Data Acquisition Quality Checks.
- Audit of post-vibration data logs against retention criteria.

**Escalation Path:** Major data integrity failures, non-compliance with contamination protocol causing delays, or unresolved conflict with CPET regarding test procedures are escalated immediately to the Project Steering Committee (PSC).