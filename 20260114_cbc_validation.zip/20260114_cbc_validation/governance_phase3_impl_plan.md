### 1. Project Director drafts official Project Charter, incorporating the 'Pioneer' strategic path and defining the $20M initial budget scope.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Project Charter v0.1
- Initial Financial Authority Documentation

**Dependencies:**

- Project Start ASAP
- Strategic Path ('Pioneer') Confirmed

### 2. Program Director (Sponsor Rep) drafts initial Terms of Reference (ToR) for the Project Steering Committee (PSC), including defining decision thresholds and roles.

**Responsible Body/Role:** Project Sponsor Representative

**Suggested Timeframe:** Project Week 1 - 2

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1
- Draft PSC Membership Roster

**Dependencies:**

- Draft Project Charter v0.1

### 3. Project Sponsor formally appoints the Program Director to serve as PSC Chair and authorizes the Project Director to establish the CPET.

**Responsible Body/Role:** Executive Portfolio Management Board (Implied Sponsor Authority)

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Formal Appointment Letters/Emails for PSC Chair and Project Director
- Confirmed PSC Membership List

**Dependencies:**

- Draft PSC ToR v0.1

### 4. PSC convenes Initiation Meeting: Formally approves the Project Charter and PSC ToR, ratifies the 'Pioneer' strategy, and authorizes the initial $5M budget release.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved Project Charter
- Ratified PSC ToR v1.0
- PSC Meeting Minutes documenting initial decisions

**Dependencies:**

- Confirmed PSC Membership List
- Draft Project Charter v0.1

### 5. Project Director drafts detailed Setup Actions and initial ToR for the Core Project Execution Team (CPET) baseline, including resource assignments and operational procedures.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3 - 4

**Key Outputs/Deliverables:**

- Draft CPET ToR v0.1
- Draft Integrated Master Schedule (IMS) v0.1

**Dependencies:**

- Approved Project Charter

### 6. Project Director officially appoints CPET members and initiates setup of Issue Tracking System and operational communication channels.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- CPET Membership Confirmed
- Issue Tracking System Operational

**Dependencies:**

- Draft CPET ToR v0.1

### 7. CPET holds Kick-off Meeting: Finalizes CPET ToR, reviews IMS, and formally accepts responsibility for detailed procedural planning (test readiness, facility interface).

**Responsible Body/Role:** Core Project Execution Team (CPET)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Approved CPET ToR v1.0
- Finalized CPET interface protocols with Facility Operations

**Dependencies:**

- CPET Membership Confirmed
- Drafted IMS v0.1

### 8. Lead Compliance Officer drafts initial ToR and action plan for the Compliance, Assurance, and Metrology Board (CAMB), focusing on initial audit trails and contamination control requirements.

**Responsible Body/Role:** Lead Compliance Officer

**Suggested Timeframe:** Project Week 5 - 6

**Key Outputs/Deliverables:**

- Draft CAMB ToR v0.1
- Initial Audit Trail Standard Operating Procedure (SOP)

**Dependencies:**

- Contamination Control Certification protocols defined (Dependency from project-plan.json)

### 9. PSC reviews and approves the CAMB ToR and grants authority to the Lead Compliance Officer to nominate the QA Auditor role.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Approved CAMB ToR v1.0
- Nomination/Contract Finalization for External QA Auditor

**Dependencies:**

- Draft CAMB ToR v0.1

### 10. CAMB holds Kick-off Meeting: Finalizes structure, accepts data integrity procedures, and formally accepts responsibility for overseeing contamination gates.

**Responsible Body/Role:** Compliance, Assurance, and Metrology Board (CAMB)

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Approved CAMB operational structure
- Signed acknowledgement of data retention SOP

**Dependencies:**

- Approved CAMB ToR v1.0

### 11. CPET coordinates facility integration, initiating mandatory bakeout procedures and contamination certification processes.

**Responsible Body/Role:** Core Project Execution Team (CPET)

**Suggested Timeframe:** Project Weeks 9 - 12

**Key Outputs/Deliverables:**

- Vibration Injection Profile Qualification Complete
- Thermal Impedance Measurement System Calibrated
- Bakeout Certification Document Signed

**Dependencies:**

- CPET Kick-off Meeting
- Secure Facility Use Agreements (FUAs)

### 12. CPET executes Backscatter/SNR burn-down test to qualify beam dump and sensing chain as a prerequisite for full array integration.

**Responsible Body/Role:** Core Project Execution Team (CPET)

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Backscatter/SNR Burn-down Test Report
- CAMB Review of Sensing Chain Integrity

**Dependencies:**

- Bakeout Certification Document Signed
- CAMB Kick-off Meeting

### 13. CPET configures the optical engine for the '1+6' test, establishing the full range of tunable perimeter constraint stiffness settings for TSO data acquisition.

**Responsible Body/Role:** Lead Optical Scientist (via CPET)

**Suggested Timeframe:** Project Week 14

**Key Outputs/Deliverables:**

- Characterization of all Tunable Stiffness Configurations
- Optical Alignment & Phasing Baseline Achieved (Low Power)

**Dependencies:**

- Characterize and parameterize the tunable perimeter constraint stiffness settings

### 14. CPET executes initial set of TSO parameter extraction tests across the full stiffness range, including the synthesis of required intermediate boundary conditions ('1+6+12' emulation data).

**Responsible Body/Role:** Thermal-Structural Analyst (via CPET)

**Suggested Timeframe:** Project Weeks 15 - 20

**Key Outputs/Deliverables:**

- Draft TSO Parameter Set v0.1 (from combined constrained/unconstrained tests)
- Initial TSO Model Uncertainty Bounds Estimate

**Dependencies:**

- Optical Alignment & Phasing Baseline Achieved
- Characterization of all Tunable Stiffness Configurations

### 15. CAMB reviews Draft TSO Parameter Set v0.1 and the data acquisition methodology to confirm fidelity against the 'Pioneer' strategy requirements (>1+6+12 emulation).

**Responsible Body/Role:** Compliance, Assurance, and Metrology Board (CAMB)

**Suggested Timeframe:** Project Week 21

**Key Outputs/Deliverables:**

- CAMB Quality Sign-off on TSO Data Integrity
- Approved Methodology for Engine WPE Metering Implementation

**Dependencies:**

- Draft TSO Parameter Set v0.1
- Approved Methodology for Engine WPE Metering Implementation (Decision 1 Resolution)

### 16. CPET executes dynamic testing: Inject high-bandwidth vibration spectra while simultaneously using transient heat injection, maintaining WPE measurement across the full Engine WPE boundary.

**Responsible Body/Role:** Core Project Execution Team (CPET)

**Suggested Timeframe:** Project Weeks 22 - 28

**Key Outputs/Deliverables:**

- Dynamic Stress Test Data Logs (Thermal/Vibration/Phase)
- Preliminary Engine WPE Results under combined stress

**Dependencies:**

- Finalized Test Procedures Acceptance by Facility Ops
- Engine WPE Metering System Fully Calibrated

### 17. CPET executes sustained performance runs, dynamically determining stop time based on Strehl settling criteria (1% stability for 60s) to qualify System Strehl/Stretch metrics.

**Responsible Body/Role:** Lead Optical Scientist (via CPET)

**Suggested Timeframe:** Project Weeks 29 - 35

**Key Outputs/Deliverables:**

- Final Qualification Dataset (Strehl/WPE vs. Stress Profile)
- Validated Sustained Duration Times per Stress Condition

**Dependencies:**

- Dynamic Stress Test Data Logs
- High-speed data capture enabled (per Decision 3: increased sampling rate)

### 18. CPET executes and monitors the post-vibration retention check immediately following dynamic testing, logging data based on the defined short retention timeframe.

**Responsible Body/Role:** Beam Control Systems Engineer (via CPET)

**Suggested Timeframe:** Project Week 36

**Key Outputs/Deliverables:**

- Post-Vibration Retention Data Summary
- Alignment/Phasing Hold-Time Verification Report

**Dependencies:**

- Dynamic Stress Test Data Logs

### 19. PSC reviews the comprehensive test results (Strehl, WPE, TSO data) to determine readiness for final model validation and formal acceptance of demonstration milestones.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 37

**Key Outputs/Deliverables:**

- Formal Go/No-Go Decision for Final TSO Model Finalization
- Approval of Final Budget Burn Rate Forecast

**Dependencies:**

- Final Qualification Dataset
- Post-Vibration Retention Data Summary

### 20. Thermal-Structural Analyst integrates validated test data (including all boundary condition variations) to finalize the TSO Scaling Model and associated uncertainty bounds required for 19+ prediction.

**Responsible Body/Role:** Thermal-Structural Analyst

**Suggested Timeframe:** Project Weeks 38 - 42

**Key Outputs/Deliverables:**

- Validated TSO Scaling Model v1.0
- Final Uncertainty Bounds Documentation for 19+ Aperture Prediction

**Dependencies:**

- Formal Go/No-Go Decision for Final TSO Model Finalization
- CAMB Quality Sign-off on TSO Data Integrity

### 21. CAMB independently audits the final TSO Scaling Model and uncertainty documentation against all gathering procedures before acceptance.

**Responsible Body/Role:** Compliance, Assurance, and Metrology Board (CAMB)

**Suggested Timeframe:** Project Week 43

**Key Outputs/Deliverables:**

- CAMB Final Assurance Report on TSO Model Data Fidelity
- Formal Recommendation to PSC on Model Acceptance

**Dependencies:**

- Validated TSO Scaling Model v1.0

### 22. PSC convenes Final Review: Formally accepts the TSO Scaling Model, accepts the final Vacuum-Truth Dataset, and authorizes project closeout procedures (budget reconciliation, documentation archiving).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 44

**Key Outputs/Deliverables:**

- Final Project Acceptance Sign-off
- Archived Vacuum-Truth Dataset

**Dependencies:**

- CAMB Final Assurance Report on TSO Model Data Fidelity
- Final Qualification Dataset