**Purpose:** business

**Purpose Detailed:** Validating optical coherence and beam quality under extreme conditions for space-based applications, including thermal and dynamic loading, with a focus on scalability and efficiency.

**Topic:** Space-based coherent beam combining stress-test validation program