This plan involves money.

## Currencies

- **USD:** Primary currency for budgeting and reporting, given the project's scale and location in the USA.

**Primary currency:** USD

**Currency strategy:** The project will primarily use USD for all transactions. No specific currency risk management is needed as the project is based in the USA.