Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 15 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 4 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the project does not require breaking any physical laws. The goal is to validate coherent beam combining, which is based on known principles of optics. The plan focuses on engineering validation and performance demonstration.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (space-based coherent beam combining) + market (space infrastructure) + tech/process (thermal/dynamic stress testing) + policy (laser safety) without independent evidence at comparable scale. There is no mention of existing systems performing this combination of functions.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Owner: Project Manager / Deliverable: Validation Report / Date: 2027-12-31


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan uses terms like 'Thermal-Structural-Optical (TSO) scaling model' without defining the inputs→process→customer value mechanism of action, owner, or measurable outcomes. The plan mentions 'TSO model predictions' but lacks detail on how the model functions or its strategic impact.

**Mitigation**: Project Manager: Create a one-pager defining the TSO scaling model's mechanism-of-action (inputs→process→customer value), assign an owner, and define measurable outcomes by 2026-03-01.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the risk register identifies several second-order risks (technical, supply chain, operational, financial, regulatory, environmental, social, security), but it does not explicitly analyze cascades or map dependencies between risks. The plan lacks explicit cascade analysis.

**Mitigation**: Project Manager: Conduct a workshop to map risk cascades and dependencies, expanding the risk register to include cascade effects and adding controls with a dated review cadence by 2026-03-15.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies 'Delays in obtaining permits' as a risk with '1-3 month delay'. However, the plan lacks a permit/approval matrix, and there is no evidence that the 1-3 month allocation is realistic for the relevant jurisdictions.

**Mitigation**: Project Manager: Create a permit/approval matrix with authoritative lead times for each jurisdiction, rebuild the critical path, and define a NO-GO threshold on slip by 2026-03-01.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not mention any funding sources, their status (e.g., LOI/term sheet/closed), the draw schedule, or the runway length. Without this information, it is impossible to assess the funding plan and runway integrity.

**Mitigation**: CFO: Create a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO-GO on missed financing gates by 2026-03-01.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not include vendor quotes or scale-appropriate benchmarks for capex/fit-out/opex. There is no normalization by area (cost per m²/ft²) applied to the stated footprint. The $20 million figure is unsubstantiated.

**Mitigation**: CFO: Obtain ≥3 vendor quotes for major capex items, normalize costs per area (m²/ft²), benchmark against similar projects, and adjust the budget or de-scope by 2026-04-01.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key performance indicators (Strehl ratio, wall-plug efficiency) as single numbers (e.g., '≥0.65', '≥35%') without providing a range or discussing alternative scenarios. There is no sensitivity analysis or best/worst-case scenario analysis.

**Mitigation**: Project Manager: Conduct a sensitivity analysis or develop best/worst/base-case scenarios for Strehl ratio and wall-plug efficiency projections, including a rationale for each case, by 2026-04-01.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not include technical specs, interface definitions, test plans, or an integration map with owners/dates. The plan mentions 'optical engine', 'mechanical mount', 'vibration injection system', but lacks engineering artifacts.

**Mitigation**: Engineering Lead: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components by 2026-04-01.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions 'Laser Safety Certification (ANSI Z136.1)' but lacks a verifiable certificate or documented compliance audit. The plan states 'Implement a Class 4 laser safety interlock system' without evidence of design review or approval.

**Mitigation**: Safety Officer: Obtain Laser Safety Certification (ANSI Z136.1) or documented compliance audit and design review approval for the Class 4 laser safety interlock system by 2026-03-15.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions 'a validated Thermal-Structural-Optical (TSO) scaling model for 19+ tile apertures' without defining specific, verifiable qualities. The plan lacks SMART acceptance criteria, including a KPI.

**Mitigation**: Engineering Lead: Define SMART criteria for the TSO scaling model, including a KPI for prediction accuracy (e.g., R-squared > 0.9) by 2026-03-15.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions 'graceful degradation under sparse-array conditions' without defining the value to the customer or the business. The plan's core goals are 'system Strehl of ≥0.65 and wall-plug efficiency ≥35%'.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of 'graceful degradation', complete with a KPI, owner, and estimated cost, or move the feature to the project backlog by 2026-03-01.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a 'Metrology and Instrumentation Specialist' to develop metrology techniques for precise alignment, phasing, and performance measurement. This expertise is critical and likely rare, given the project's ambitious performance targets.

**Mitigation**: HR: Validate the talent market for a 'Metrology and Instrumentation Specialist' with experience in high-precision optical systems and develop a recruitment strategy by 2026-03-01.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions 'Laser Safety Certification (ANSI Z136.1)' but lacks a verifiable certificate or documented compliance audit. The plan states 'Implement a Class 4 laser safety interlock system' without evidence of design review or approval.

**Mitigation**: Safety Officer: Obtain Laser Safety Certification (ANSI Z136.1) or documented compliance audit and design review approval for the Class 4 laser safety interlock system by 2026-03-15.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions scalability and efficiency as goals, but lacks a detailed operational sustainability plan. The plan does not address long-term data storage and accessibility. The options fail to address the calibration and maintenance requirements of the metrology systems.

**Mitigation**: Project Manager: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms by 2026-06-30.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies 'Delays in obtaining permits' as a risk with '1-3 month delay, $100k-$300k'. However, the plan lacks a permit/approval matrix, and there is no evidence that the 1-3 month allocation is realistic.

**Mitigation**: Project Manager: Create a permit/approval matrix with authoritative lead times for each jurisdiction, rebuild the critical path, and define a NO-GO threshold on slip by 2026-03-01.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies 'Delays in obtaining critical components' as a risk, but lacks evidence of contracts, SLAs, or tested failover plans with vendors. The plan mentions 'Establish supplier relationships, implement procurement process, identify alternatives'.

**Mitigation**: Procurement Manager: Secure SLAs with key vendors, add a secondary supplier for critical components, and test failover procedures by 2026-06-30.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the 'Project Manager' is incentivized to deliver on time and within budget, while the 'Lead Optical Engineer' is incentivized to achieve high performance (Strehl ratio), potentially leading to conflicts over scope and resources.

**Mitigation**: Project Manager: Define a shared, measurable objective (OKR) that aligns both stakeholders on a common outcome, such as 'Achieve target Strehl ratio within budget and schedule' by 2026-03-01.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board to the project governance structure by 2026-03-01.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies several high risks (Strehl ratio, CSI instabilities, cost overruns) but lacks a cross-impact analysis. A single dependency (e.g., a supply chain disruption) could trigger multi-domain failure (technical, financial, schedule).

**Mitigation**: Project Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by 2026-04-01.