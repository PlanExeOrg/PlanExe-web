**Budget Overrun Exceeding Core Project Team Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of the overrun, revised budget proposal, and impact assessment, followed by a vote.
Rationale: Exceeds the Core Project Team's financial authority and requires strategic oversight due to potential impact on project scope or timeline.
Negative Consequences: Project scope reduction, delays, or cancellation due to lack of funds.

**Technical Design Change Impacting Performance Targets**
Escalation Level: Technical Advisory Group
Approval Process: TAG reviews the proposed change, assesses its impact on performance, and provides a recommendation to the Core Project Team.
Rationale: Requires expert technical review to ensure the change doesn't compromise the project's key performance indicators (Strehl ratio, WPE).
Negative Consequences: Failure to meet performance targets, requiring costly redesigns or rework.

**Ethical Violation Reported by Team Member**
Escalation Level: Ethics & Compliance Committee
Approval Process: The Ethics & Compliance Committee investigates the report, interviews relevant parties, and determines appropriate corrective action.
Rationale: Requires independent investigation and resolution to ensure ethical conduct and compliance with regulations.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Disagreement Between Core Project Team and Technical Advisory Group on a Critical Technical Issue**
Escalation Level: Project Steering Committee
Approval Process: The Steering Committee reviews the differing viewpoints, considers the recommendations from both groups, and makes a final decision.
Rationale: Requires resolution at a higher level to ensure alignment and prevent project delays.
Negative Consequences: Project delays, suboptimal technical decisions, and increased project costs.

**Proposed Major Scope Change (e.g., altering the number of tiles)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee reviews the proposed change, its impact on budget, schedule, and performance, and approves or rejects the change.
Rationale: Significant scope changes require strategic approval due to their potential impact on project objectives and resources.
Negative Consequences: Project failure, budget overruns, and inability to meet original objectives.