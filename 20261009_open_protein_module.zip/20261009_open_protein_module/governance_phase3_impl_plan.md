### 1. Funder appoints or identifies a Project Sponsor and confirms budget release authority. This is the pre-existing higher authority required to initiate all governance setup.

**Responsible Body/Role:** Funder

**Suggested Timeframe:** Month 0 (2026-10-09)

**Key Outputs/Deliverables:**

- Project Sponsor appointed and confirmed
- Funder's budget release and approval authority documented in writing
- Contact information and escalation path established

**Dependencies:**

- Funding commitment confirmed by funder

### 2. Project Sponsor (or Funder) formally appoints a Project Lead who will chair the Steering Committee and serve as the face of the project during Phase One setup. The Project Lead is typically a senior process engineer or project manager from the host institution.

**Responsible Body/Role:** Project Sponsor / Funder

**Suggested Timeframe:** Month 0 (2026-10-09)

**Key Outputs/Deliverables:**

- Project Lead appointed in writing
- Project Lead charter outlining decision authority, reporting line and key responsibilities
- First Project Lead action: confirm availability and initiate host-institution MoU negotiation

**Dependencies:**

- Project Sponsor identified and confirmed

### 3. Project Lead drafts a written charter for the independent gate-review panel, specifying: recruitment criteria, composition (3-5 members), funding and independence (panel managed by funder, not host), authority (written continue/modify/research-only/stop decisions), and procedure for publishing any funder deviation from panel recommendations.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0 (2026-10-09) to Month 0.5 (2026-10-24)

**Key Outputs/Deliverables:**

- Gate-Review Panel Charter v0.1 (draft)
- Recruitment criteria and desired expertise areas identified (process engineer, ATEX safety, regulatory, adoption, food science)
- Independence and funding mechanism documented

**Dependencies:**

- Project Lead appointed
- Funder confirms EUR 0.30M gate-panel budget ring-fenced and funder-managed

### 4. Funder reviews and approves the gate-review panel charter, confirming separate budget line (EUR 0.30M over 5 years), management structure and panel independence guarantees.

**Responsible Body/Role:** Funder

**Suggested Timeframe:** Month 0.5 (2026-10-24)

**Key Outputs/Deliverables:**

- Gate-Review Panel Charter approved and signed by funder
- EUR 0.30M budget line established (Phase One share EUR 0.06M)
- Funder designates an internal account manager for panel administration

**Dependencies:**

- Gate-Review Panel Charter v0.1 submitted to funder

### 5. Funder (or a funder-designated independent recruiter) initiates recruitment of the independent gate-review panel members using the approved charter criteria. Target: identify and secure 3-5 qualified experts with no conflicts of interest.

**Responsible Body/Role:** Funder

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Recruitment outreach completed to 8-12 candidate experts
- 3-5 panel members confirmed with written letters of engagement
- Panel charter signed by each member

**Dependencies:**

- Approved Gate-Review Panel Charter
- EUR 0.30M budget confirmed

### 6. Funder (or panel account manager) schedules a panel orientation meeting to brief members on the project scope, decision framework, timeline for gate meetings (Phase One ~Month 10 = 2027-08-09, Phase Two ~Month 30 = 2029-04-09, Phase Three ~Month 60 = 2031-10-09) and confidentiality/independence requirements.

**Responsible Body/Role:** Funder

**Suggested Timeframe:** Month 1 (2026-11-09) to Month 1.5 (2026-11-24)

**Key Outputs/Deliverables:**

- Panel orientation meeting held (in-person or virtual)
- Panel members provided project briefing materials, preliminary risk register and timeline
- Each panel member confirms understanding of role and independence obligations

**Dependencies:**

- 3-5 panel members confirmed and signed

### 7. Project Lead negotiates and secures a signed Memorandum of Understanding (MoU) with the Danish host university or research consortium, specifying: dedicated laboratory and container-scale bioreactor facilities, electrolysis capability, ATEX-compliant space, analytical support, key staff protection, facility maintenance responsibility and quarterly resource-conflict resolution.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0 (2026-10-09) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Host institution MoU signed by institution rector/executive director and Project Lead
- MoU specifies: laboratory access, equipment availability, key staff roles and protected time, conflict-resolution escalation
- Host institution confirms budget share or in-kind contributions

**Dependencies:**

- Project Lead appointed
- Project Sponsor identifies host-institution candidates

### 8. Project Lead negotiates and secures a signed partnership agreement with the Kenyan co-development organization, specifying: site access, staffing roles, equipment procurement and installation responsibility, utilities, training commitment, contingency plans for staff or partner changes, logistics and quarterly review schedule.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0 (2026-10-09) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Kenyan partner MoU signed by partner executive director and Project Lead
- Specifies: site access, staffing allocation (minimum 2 FTE), facilities, training participation, quarterly review with Steering Committee
- Contingency for partner or staff change documented

**Dependencies:**

- Project Lead appointed
- Project Sponsor identifies Kenyan partner candidates

### 9. Project Lead recruits or designates a Finance Manager (Cost Controller) who will track Phase One spending against the EUR 5.5M planned and EUR 6M ceiling, manage the EUR 0.65M contingency reserve, handle EUR/KES currency conversion at locked baseline rates and prepare monthly cost-control reports.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Finance Manager appointed or contracted
- Cost-tracking procedures and spreadsheet templates established
- EUR 0.30M contingency earmarked for strain-rights and regulatory work; EUR 0.35M free contingency
- EUR/KES baseline exchange rate locked at Month 0 (2026-10-09) reference rate

**Dependencies:**

- Project Lead appointed
- Phase One planned budget (EUR 5.5M) and contingency (EUR 0.65M) confirmed by funder

### 10. Project Lead recruits a PMO Director (or designates the Project Lead to wear this hat part-time in Month 0-1 = 2026-10-09 to 2026-11-09) to oversee day-to-day execution, establish work schedules, coordinate with workstream leads and manage gate-readiness preparation.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- PMO Director appointed or role assigned
- PMO charter outlining responsibility for schedule, cost, workstream coordination and gate-panel administration
- PMO team structure identified (Phase One work-package owner, cost controller, procurement, gate-panel admin, data manager)

**Dependencies:**

- Project Lead appointed

### 11. PMO Director establishes the detailed Phase One work schedule (Gantt chart with 100+ work packages), identifying critical path, dependencies and deliverables due for the Month 9 (2027-07-09) evidence freeze. Lock all deadlines and assign work-package owners.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Phase One Gantt chart (locked)
- Work packages defined: landscape review (Month 0-3 = 2026-10-09 to 2027-01-09), bench experiments (Month 1-9 = 2026-11-09 to 2027-07-09), HAZOP (Month 1-4 = 2026-11-09 to 2027-02-09), regulatory (Month 0-4 = 2026-10-09 to 2027-02-09), site baseline (Month 1-4 = 2026-11-09 to 2027-02-09), adopter engagement (Month 2-7 = 2026-12-09 to 2027-05-09), gate prep (Month 8-12 = 2027-06-09 to 2027-10-09)
- Critical-path activities identified; critical-path delay >2 weeks flags risk

**Dependencies:**

- PMO Director appointed
- Phase One planned spend and EUR 0.65M contingency confirmed

### 12. Project Lead formally establishes the Steering Committee, appointing its members: Project Lead (chair), Funder Representative, Kenyan Partner Lead, Finance Manager, Safety and Regulatory Lead, and optional external observer. Distribute a written charter specifying decision authority, meeting cadence and escalation rules.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Steering Committee Charter signed by all members
- Charter specifies: decision authority (contingency draws up to EUR 500K, schedule extensions, scope changes), quorum (4 of 6), voting rules (consensus preferred, majority if needed, dissent published), escalation (Funder holds veto, gate panel has override authority on safety)
- Members confirm availability for quarterly meetings (Months 3, 6, 9, 12 = 2027-01-09, 2027-04-09, 2027-07-09, 2027-10-09 in Phase One)

**Dependencies:**

- Project Lead appointed
- Funder Representative designated
- Kenyan Partner Lead confirmed
- Finance Manager appointed
- Safety and Regulatory Lead recruited or assigned

### 13. Steering Committee holds its inaugural meeting to confirm charter, approve Phase One work plan and budget, review risk register and confirm gate-panel independence arrangements. Document decisions and action items.

**Responsible Body/Role:** Steering Committee (led by Project Lead)

**Suggested Timeframe:** Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Inaugural Steering Committee meeting held (in-person or hybrid)
- Minutes documenting: charter approval, Phase One plan and budget approved, risk review completed, gate-panel independence confirmed, next meeting scheduled (Month 3 = 2027-01-09)
- Action items assigned to working groups

**Dependencies:**

- Steering Committee Charter approved and all members appointed
- Phase One Gantt chart locked
- Phase One cost allocation approved by funder

### 14. Project Lead recruits a Safety and Regulatory Lead (typically a senior process-safety engineer or regulatory affairs manager) who will oversee HAZOP, safety design basis, regulatory engagement and strain-rights work.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Safety and Regulatory Lead appointed (senior role, project-direct hire)
- Lead confirms availability to charter working groups: Safety/ATEX, Regulatory/IP/Strain-Rights
- Lead identifies qualified staff to support HAZOP, regulatory contact and strain-rights analysis

**Dependencies:**

- Project Lead appointed
- Budget for safety (EUR 0.25M) and regulatory/IP (EUR 0.20M) work confirmed by Steering Committee

### 15. Safety and Regulatory Lead contracts an independent third-party ATEX and process-safety consultant (external firm, not affiliated with host institution) to facilitate the HAZOP, review interlock logic and provide written compliance assessment.

**Responsible Body/Role:** Safety and Regulatory Lead

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- ATEX consultant contracted with fixed scope: HAZOP facilitation (3-4 workshop sessions), interlock review, written compliance letter
- Consultant contract specifies deliverables, timeline (HAZOP complete by Month 3 = 2027-01-09), and independence clause (no future design work)

**Dependencies:**

- Safety and Regulatory Lead appointed
- EUR 0.25M safety budget confirmed

### 16. Safety and Regulatory Lead formally constitutes the Technical Working Group: Safety, ATEX and Hazard Analysis, appointing members: Safety Lead, Process Engineer, ATEX Consultant, Reactor Specialist, Control Systems Engineer. Distribute charter and schedule HAZOP kickoff for Month 1 (2026-11-09).

**Responsible Body/Role:** Safety and Regulatory Lead

**Suggested Timeframe:** Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Safety Working Group Charter signed by members
- Charter specifies: HAZOP scope (electrolyzer to off-gas), guidewords, node structure, risk-matrix approach, deliverables (Safety Design Basis, Adopter Change Boundary)
- Monthly meeting schedule established (Mondays, 90 min, Months 1-4 = 2026-11-09 to 2027-02-09)
- HAZOP kickoff meeting scheduled (end of Month 1 or early Month 2 = 2026-12-09 to 2026-12-09)

**Dependencies:**

- Safety and Regulatory Lead appointed
- ATEX consultant contracted
- Reactor Specialist and Control Systems Engineer identified

### 17. Safety and Regulatory Lead contracts independent legal counsel (patent specialist and regulatory consultant) to conduct the freedom-to-operate and regulatory landscape review, covering Denmark, EU, Kenya and Bangladesh.

**Responsible Body/Role:** Safety and Regulatory Lead

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Patent specialist contracted (scope: hydrogen fermentation, autotrophic protein, single-cell protein, reference strain; jurisdictions: Denmark/EU, Kenya, Bangladesh)
- Regulatory consultant contracted (scope: contained-use rules, product-safety pathways per category, biosafety classification)
- Contract specifies deliverables: Strain Feasibility Report by Month 4 (2027-02-09), patent landscape summary, regulatory pathway assessment

**Dependencies:**

- Safety and Regulatory Lead appointed
- EUR 0.20M regulatory/IP budget confirmed

### 18. Safety and Regulatory Lead formally constitutes the Technical Working Group: Strain Rights, Regulatory Pathway and Intellectual Property, appointing members: Regulatory Lead, Patent Specialist (legal counsel), Regulatory Consultant (legal counsel), Microbiologist or Operations Lead. Distribute charter and establish bi-weekly meeting cadence.

**Responsible Body/Role:** Safety and Regulatory Lead

**Suggested Timeframe:** Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Regulatory/IP Working Group Charter signed by members
- Charter specifies: deliverables (Strain Feasibility Report, patent landscape summary, regulatory-pathway assessment), timeline (by Month 4 = 2027-02-09), legal-counsel review gates
- Bi-weekly meeting schedule (Mondays, 60 min, Months 1-4 = 2026-11-09 to 2027-02-09)
- Legal-counsel retainer agreements signed

**Dependencies:**

- Safety and Regulatory Lead appointed
- Patent specialist and regulatory consultant contracted

### 19. Project Lead recruits a Reactor Concept Lead (senior process or fermentation engineer) who will oversee the matched bench-scale reactor comparison and scale-up work. Assign responsibility for establishing the measurement framework and pre-registering the comparison protocol.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Reactor Concept Lead appointed (senior role, project-direct hire)
- Lead confirms availability to charter and lead the Reactor/Scale-Up Working Group
- Lead identifies bench-scale experimental lead, gas-transfer specialist, scale-up engineer and data manager

**Dependencies:**

- Project Lead appointed
- EUR 1.00M bench-lab budget confirmed

### 20. Reactor Concept Lead and data manager establish the detailed KPI Framework and Measurement Protocol, locked in writing before any bench-scale experiments begin. Specify definitions (volumetric productivity, energy per kg, kLa, oxygen-uptake rate), system boundary, analytical methods (HPLC, GC, bioreactor sensors) and success thresholds.

**Responsible Body/Role:** Reactor Concept Lead (in collaboration with data manager and external technical auditor)

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1.5 (2026-11-24)

**Key Outputs/Deliverables:**

- KPI Framework and Measurement Protocol v1.0 (locked and signed)
- Specifies: productivity definition (g/L/day), energy per kg (kWh/kg), kLa (h^-1), system boundary (electrolyzer to fermentor headspace), capacity-utilization assumption (assume 100% of theoretical max), measurement methods per instrument
- Published to Steering Committee and gate-review panel for feedback before experiments start

**Dependencies:**

- Reactor Concept Lead appointed
- External technical auditor identified and available for Month 1-2 (2026-11-09 to 2026-12-09) review

### 21. Reactor Concept Lead formally constitutes the Technical Working Group: Reactor Concept and Scale-Up, appointing members: Reactor Lead (chair), Bench-Scale Experimental Lead, Gas-Transfer Specialist, Scale-Up Engineer, Data Manager, Process Safety Engineer. Distribute charter and lock the pre-registered reactor comparison protocol before any experiments begin.

**Responsible Body/Role:** Reactor Concept Lead

**Suggested Timeframe:** Month 1 (2026-11-09) to Month 1.5 (2026-11-24)

**Key Outputs/Deliverables:**

- Reactor Working Group Charter signed by members
- Charter specifies: measurement framework (locked KPI definitions), pre-registered decision rules for reactor selection (<15% productivity gap = simplicity wins; 15-25% = weighted score; >25% = highest productivity unless ATEX blocked or cheaper option meets cost threshold)
- Disproof-experiment protocol locked: bench to pilot scale, kLa decline target <=25%, productivity within 15%, strain stability <10% drift over 16 weeks, external audit required before Phase Two gate
- Weekly meeting schedule (Mondays, 90 min, Months 1-9 = 2026-11-09 to 2027-07-09)

**Dependencies:**

- Reactor Concept Lead appointed
- KPI Framework locked
- External technical auditor identified and confirmed

### 22. PMO Procurement Manager initiates procurement of long-lead-time equipment (bioreactors for bench, pilot-scale reactors, electrolyzers, analytical instruments: HPLC, GC, gas chromatograph, bioreactor sensors). Target delivery Month 3-4 (2027-01-09 to 2027-02-09) to support February/March experiments.

**Responsible Body/Role:** PMO Director / Procurement Manager

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Procurement contracts issued for: 3 bench bioreactors (500 mL–1 L), 1 pilot-scale bioreactor (5–10 L), electrolyzers (bench and pilot scale), HPLC system, gas chromatograph, bioreactor monitoring system
- Delivery targets locked: Month 3 (2027-01-09) for equipment needed in Month 2-3 (2026-12-09 to 2027-01-09); contingency for 4-week delay tracked
- Supplier contracts include warranty, calibration and site-support terms

**Dependencies:**

- Procurement budget (EUR 0.5M of lab EUR 1.00M) approved by Steering Committee
- Facility requirements specified by Reactor Lead and host institution

### 23. Project Lead recruits an Adopter Engagement Lead (adoption strategist, economist or operations specialist) who will identify prospective adopters, conduct structured interviews and consolidate deployment scenarios with locked thresholds.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Adopter Engagement Lead appointed (mid-level role, project-direct or partner staff)
- Lead identifies techno-economic analyst and adoption specialist to support scenario development
- Lead confirms availability for structured adopter interviews (Months 2-7 = 2026-12-09 to 2027-05-09)

**Dependencies:**

- Project Lead appointed
- EUR 0.15M adopter-engagement budget approved

### 24. Adopter Engagement Lead constitutes the Adoption Working Group and conducts landscape research to identify 5-8 candidate prospective adopters (national/regional reserves, feed producers, humanitarian organizations) with stated mandates in food security or agriculture.

**Responsible Body/Role:** Adopter Engagement Lead

**Suggested Timeframe:** Month 1 (2026-11-09) to Month 2 (2026-12-09)

**Key Outputs/Deliverables:**

- Adopter Landscape Report identifying 5-8 candidates with profiles (mission, capacity, budget authority, current supply chains, estimated cost tolerance)
- Shortlist of 2-3 primary candidates with contact information
- Meeting requests sent to primary candidates for Month 2-3 (2026-12-09 to 2027-01-09) interviews

**Dependencies:**

- Adopter Engagement Lead appointed
- Techno-economic analyst and adoption specialist identified

### 25. Adopter Engagement Lead develops a structured interview guide and conducts in-person or virtual interviews with 2-3 prospective adopters, gathering data on: current supply chains and costs, production-capacity needs, cost tolerance, operational constraints (power, water, skills) and timeline.

**Responsible Body/Role:** Adopter Engagement Lead

**Suggested Timeframe:** Month 2 (2026-12-09) to Month 4 (2027-02-09)

**Key Outputs/Deliverables:**

- Interview guide (locked template with open-ended and quantitative questions)
- 2-3 adopter interview summaries documenting: current spend on protein, cost premium tolerance, capacity needs (kg/day or kg/yr), uptime requirements, operational constraints
- Preliminary scenario profiles (A, B, C) with estimated thresholds (cost, capacity, uptime)

**Dependencies:**

- Landscape report completed and candidates prioritized
- Steering Committee approves outreach messaging and interview protocol

### 26. Adopter Engagement Lead presents preliminary scenario profiles to each adopter, gathering feedback and validating thresholds. Iteratively refine profiles and obtain verbal commitment to lock scenarios by Month 9 (2027-07-09).

**Responsible Body/Role:** Adopter Engagement Lead

**Suggested Timeframe:** Month 3 (2027-01-09) to Month 6 (2027-04-09)

**Key Outputs/Deliverables:**

- Validated Scenario Profiles v1.0 incorporating adopter feedback
- Scenario A: reserve agency (<=EUR 12/kg, >=100 kg/day, >=95% uptime) (estimate)
- Scenario B: feed producer (<=EUR 10/kg, >=500 kg/day, >=90% uptime) (estimate)
- Scenario C: humanitarian logistics (<=EUR 15/kg, >=50 kg/day, 40-ft container) (estimate)
- Verbal commitments from adopters to sign by Month 7 (2027-05-09)

**Dependencies:**

- Preliminary scenario profiles from interviews
- Techno-economic cost model version available for sensitivity analysis

### 27. Project Lead initiates contact with Denmark/EU competent authorities (Danish EPA or EU environmental authority) and Kenya's National Biosafety Authority via informal pre-submission consultation, requesting written guidance on: contained-use authorization, strain biosafety classification, product-safety pathways per category and approval timelines.

**Responsible Body/Role:** Safety and Regulatory Lead (on behalf of Project Lead)

**Suggested Timeframe:** Month 2 (2026-12-09) to Month 3 (2027-01-09)

**Key Outputs/Deliverables:**

- Pre-submission inquiry letters sent to Danish EPA and Kenya's National Biosafety Authority
- Inquiry describes: proposed process, strain candidates, operating envelope, candidate product categories (animal feed, feed ingredient, emergency nutrition)
- Requests written preliminary guidance within 4-6 weeks

**Dependencies:**

- Safety and Regulatory Lead appointed
- Regulatory/IP Working Group established
- Strain candidates identified

### 28. Safety and Regulatory Lead and legal counsel initiate direct contact with strain holders (public culture collections, researchers) for primary and backup strain candidates, requesting written confirmation of rights for: research use, commercial production, redistribution, modification and derived strains.

**Responsible Body/Role:** Safety and Regulatory Lead / Regulatory/IP Working Group

**Suggested Timeframe:** Month 1 (2026-11-09) to Month 2 (2026-12-09)

**Key Outputs/Deliverables:**

- Strain-holder contact list prepared (4-5 candidates, prioritizing C. necator H16 and backup strains)
- Formal inquiry emails sent with 2-week response deadline
- Responses logged in regulatory/IP Working Group tracker

**Dependencies:**

- Regulatory/IP Working Group established
- Strain candidates identified by Reactor Lead and Microbiologist

### 29. Patent specialist (legal counsel) conducts freedom-to-operate patent search covering: hydrogen fermentation, autotrophic protein, single-cell protein, reference strain(s), and related processes in Denmark, EU, Kenya and Bangladesh. Compile findings into a ranked patent landscape summary.

**Responsible Body/Role:** Patent Specialist (legal counsel contracted by Safety and Regulatory Lead)

**Suggested Timeframe:** Month 1 (2026-11-09) to Month 3 (2027-01-09)

**Key Outputs/Deliverables:**

- Patent landscape search completed (USPTO, EPO, WIPO, Kenya patent office databases)
- Patent Landscape Summary listing: relevant patents, priority dates, claims, jurisdiction coverage, freedom-to-operate risk assessment (blocking patents vs. design-around-able)
- Preliminary recommendation on IP licensing or design-around options

**Dependencies:**

- Patent specialist contracted
- Strain candidates and process concept identified

### 30. PMO Director (in coordination with host institution) initiates facility setup at the Danish site: confirm laboratory access, install bioreactor utilities (gas supply, cooling water, electrical), set up ATEX-compliant gas-handling area, and complete safety and utility inspections.

**Responsible Body/Role:** PMO Director / Host Institution Facilities Lead

**Suggested Timeframe:** Month 1 (2026-11-09) to Month 3 (2027-01-09)

**Key Outputs/Deliverables:**

- Laboratory space assignment confirmed and cleaned
- Utilities installed: gas supply (N2, H2-compatible lines), cooling water, electrical (3-phase for electrolyzers)
- ATEX-compliant gas-handling fume hood or test cell installed
- Safety inspection completed by host institution and Steering Committee sign-off

**Dependencies:**

- Host institution MoU signed
- Facility requirements specified by Reactor Lead
- Procurement orders placed (delivery Month 3 = 2027-01-09)

### 31. Regulatory/IP Working Group consolidates strain-holder responses, patent search results and regulator feedback into a comprehensive Strain Feasibility Report, documenting: primary and backup strain rights (confirmed for all use cases), lawful Kenyan import pathway, and regulatory approval feasibility.

**Responsible Body/Role:** Safety and Regulatory Lead / Regulatory/IP Working Group

**Suggested Timeframe:** Month 2 (2026-12-09) to Month 4 (2027-02-09)

**Key Outputs/Deliverables:**

- Strain Feasibility Report v1.0 (draft, Month 3 = 2027-01-09)
- Documents: primary strain (e.g. C. necator H16) rights for research, commercial, redistribution, modification, derived strains (confirmed in writing)
- Backup strain rights documented
- Kenyan import feasibility confirmed (contacted Kenya National Biosafety Authority, no blocking restrictions identified or mitigation plan in place)
- Patent landscape summary and freedom-to-operate assessment
- Regulatory consultant review and sign-off (Month 3-4 = 2027-01-09 to 2027-02-09)

**Dependencies:**

- Strain-holder responses received
- Patent search completed
- Kenya biosafety authority feedback received

### 32. Project Lead recruits a Kenyan Site Study Lead (independent consultant, not affiliated with the Kenyan partner organization) to conduct a baseline operating-envelope assessment: power outage history, water quality, spare-parts availability, ambient conditions and local technician skills.

**Responsible Body/Role:** Project Lead / Kenyan Replication Coordination

**Suggested Timeframe:** Month 1 (2026-11-09) to Month 2 (2026-12-09)

**Key Outputs/Deliverables:**

- Kenyan Site Study Lead contracted
- Scope defined: 24-36 months utility-outage records audit, 3-4 months water-quality sampling, spare-parts supplier interviews, technician-cohort census
- Timeline: baseline report due Month 4 (2027-02-09)

**Dependencies:**

- Project Lead appointed
- Kenyan partner MoU signed (grants site access to independent consultant)

### 33. Kenyan Site Study Lead conducts site baseline assessment, collecting power-outage history (>=4 unplanned outages/month target, >=2 h mean duration), water quality variation (turbidity, pH, conductivity, iron/manganese), ambient temperature and humidity range, spare-parts lead times and local technician availability (2-3 per trade).

**Responsible Body/Role:** Kenyan Site Study Lead (independent consultant)

**Suggested Timeframe:** Month 2 (2026-12-09) to Month 4 (2027-02-09)

**Key Outputs/Deliverables:**

- Kenyan Site Baseline Report v1.0 (time-stamped, Month 4 = 2027-02-09)
- Documents: power-outage frequency (last 24-36 months), duration and pattern; water-quality measurements (monthly sampling); ambient temperature and humidity ranges; spare-parts suppliers and lead times (<=2-4 weeks from >=2 suppliers target); technician census and skill levels
- Baseline parameters locked: >20% drift triggers added outage stressors or flagged to gate panel

**Dependencies:**

- Kenyan Site Study Lead contracted
- Site access confirmed by Kenyan partner
- Steering Committee approves baseline report as Phase One gate input

### 34. Project Lead recruits a Kenyan Replication Coordination Lead (or designates an existing staff member) to oversee partnership governance, site logistics, operator training and defect tracking during Phases Two and Three. Establish reporting line to Project Lead and Steering Committee.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 1 (2026-11-09) to Month 2 (2026-12-09)

**Key Outputs/Deliverables:**

- Kenyan Replication Coordinator appointed or identified (mid-level role, may be Kenyan partner staff or project-direct)
- Coordinator charter issued, outlining: partnership oversight, site logistics, training coordination, defect tracking, assistance-log auditing, quarterly Steering Committee reports
- Coordinator confirms monthly meeting schedule with Danish Project Lead (60 min teleconference)

**Dependencies:**

- Project Lead appointed
- Kenyan partner MoU signed

### 35. Project Lead formally constitutes the Kenyan Replication Coordination and Independence Assurance body, appointing members: Kenyan Site Lead (in Kenya), Project Lead or Project Manager (Denmark liaison), Training Coordinator, independent Auditor (external firm), and Kenyan Partner representative. Distribute charter and establish monthly meeting cadence.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 1 (2026-11-09) to Month 2 (2026-12-09)

**Key Outputs/Deliverables:**

- Kenyan Replication Coordination Charter signed by members
- Charter specifies: responsibilities (site logistics, training, defect tracking, assistance-log audit), monthly meetings (60 min), quarterly Steering Committee reports, escalation criteria (assistance >4 h/month, unresolved defects, site-envelope drift >20%)
- Independent auditor contracted (external firm for monthly assistance-log and defect-log reviews)

**Dependencies:**

- Kenyan Replication Coordinator appointed
- Independent auditor identified and available by Month 2-3 (2026-12-09 to 2027-01-09)

### 36. PMO Director establishes a formal defect-tracking system (shared spreadsheet or issue tracker) for: documentation ambiguities found during early Phase Two replication, regulatory feedback log, strain-rights tracking, assistance-log auditing, and cost/schedule variance tracking. Set up access and training for all users.

**Responsible Body/Role:** PMO Director / Data Manager

**Suggested Timeframe:** Month 1 (2026-11-09) to Month 2 (2026-12-09)

**Key Outputs/Deliverables:**

- Defect-tracking system established (shared cloud platform or project management tool)
- Tracking system includes fields: defect location, severity (critical/major/minor), description, resolution, source, date resolved, auditor sign-off
- Assistance-log template prepared (communication date, parties, topic, duration, source of help, logged or flagged)
- User access granted to Kenyan Replication Coordinator, Auditor, PMO, Technical Leads

**Dependencies:**

- PMO Director appointed
- Kenyan Replication Coordinator appointed
- Independent Auditor identified

### 37. Adopter Engagement Lead obtains signed commitments from 2-3 prospective adopters (by Month 7 = 2027-05-09), formally locking their deployment scenarios and thresholds in time-stamped documents. Clause: adopters remain bound to thresholds through Phase Three gate unless all parties formally agree to renegotiate.

**Responsible Body/Role:** Adopter Engagement Lead / Steering Committee liaison

**Suggested Timeframe:** Month 6 (2027-04-09) to Month 7 (2027-05-09)

**Key Outputs/Deliverables:**

- Signed Adopter Commitment Letters (one per adopter, time-stamped Month 7 = 2027-05-09)
- Each letter specifies: scenario profile (cost, capacity, uptime), locked thresholds, adopter business case or mandate supporting the threshold, withdrawal procedure (public disclosure of reason)
- Published to Steering Committee, gate-review panel and all project stakeholders

**Dependencies:**

- Scenario profiles validated with adopters (Month 6 = 2027-04-09)
- Techno-economic model and cost-sensitivity analysis available to justify thresholds

### 38. Safety and Regulatory Lead consolidates the regulatory feedback (from Denmark/EU and Kenya's National Biosafety Authority), strain-rights findings and patent landscape into a provisional product-category recommendation. Prepare documentation for the Phase One gate decision (Month 10 = 2027-08-09).

**Responsible Body/Role:** Safety and Regulatory Lead / Regulatory/IP Working Group

**Suggested Timeframe:** Month 3 (2027-01-09) to Month 5 (2027-03-09)

**Key Outputs/Deliverables:**

- Product Category Recommendation (provisional, for Phase One gate): select one from animal feed, fish feed, food ingredient, emergency nutrition based on regulatory pathway feasibility and adopter interest
- Document rationale: regulatory approval timeline, required safety data, composition thresholds (nucleic acid, protein, moisture), and how Phase Two will validate category choice
- Regulatory Pathway Summary (per jurisdiction): Denmark/EU approval route, Kenya approval route, Bangladesh patent landscape

**Dependencies:**

- Strain Feasibility Report completed
- Regulatory feedback from authorities received
- Patent landscape summary completed

### 39. PMO Director convenes a Phase One gate-readiness checkpoint (Month 7-8 = 2027-05-09 to 2027-06-09) to review evidence freeze schedule, confirm all deliverables are on track for Month 9 (2027-07-09), and prepare gate-panel briefing materials.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Month 7 (2027-05-09) to Month 8 (2027-06-09)

**Key Outputs/Deliverables:**

- Phase One Gate Readiness Report documenting: evidence freeze timeline, outstanding deliverables and owners, risk flags (any delays >2 weeks), gate-panel briefing materials status
- Briefing package outline prepared: landscape review summary, bench-reactor productivity data and analysis (with external audit), safety design basis, strain feasibility, regulatory pathways, scenarios and thresholds, technology risks and mitigation

**Dependencies:**

- All Phase One work packages 80%+ complete by Month 7 (2027-05-09)
- Bench-reactor experiments underway or nearly complete

### 40. Reactor Working Group (with external technical auditor) conducts comprehensive audit of the bench-scale reactor comparison: verify that the measurement protocol was followed, analytical methods were consistent, decision thresholds were applied, and all deviations are documented. Produce audited comparison report with uncertainty ranges and reactor selection recommendation.

**Responsible Body/Role:** Reactor Concept Lead / External Technical Auditor

**Suggested Timeframe:** Month 8 (2027-06-09) to Month 9 (2027-07-09)

**Key Outputs/Deliverables:**

- External Audit Report (signed by independent technical auditor, Month 9 = 2027-07-09)
- Auditor confirms: measurement framework was locked and followed; analytical variation <20%; decision rules were pre-registered and applied consistently; three reactor concepts compared, triplicate runs, mean ± SD reported
- Reactor selection recommendation: specific concept (pneumatic, stirred, or passive-feed) identified based on pre-registered decision rules with full justification

**Dependencies:**

- Triplicate bench-scale experiments completed (all 9 cultures run to steady state)
- All analytical data compiled and processed by single lead analyst
- External technical auditor engaged and available for Month 8-9 (2027-06-09 to 2027-07-09) review

### 41. Safety and Regulatory Lead and HAZOP facilitator (ATEX consultant) complete the formal Process Hazard Analysis (HAZOP or LOPA) covering: electrolyzer, gas lines, fermentor headspace and control systems. Identify all failure modes, rank by severity and likelihood, and document design response (eliminate, reduce, protect). Independent consultant provides written sign-off.

**Responsible Body/Role:** Safety Working Group (led by Safety and Regulatory Lead) with ATEX Consultant

**Suggested Timeframe:** Month 1 (2026-11-09) to Month 4 (2027-02-09), finalized by Month 9 (2027-07-09)

**Key Outputs/Deliverables:**

- HAZOP Final Report (Month 4 = 2027-02-09 draft, Month 9 = 2027-07-09 finalized)
- Documents: hazard register (all identified failure modes, guidewords covered, nodes analyzed), risk matrix (severity x likelihood), high-risk items and design responses, quantitative safety target (probability of uncontrolled ignition <1 per 100,000 operating hours)
- Independent ATEX consultant sign-off letter confirming compliance with ATEX requirements

**Dependencies:**

- Safety Working Group constituted (Month 1 = 2026-11-09)
- ATEX consultant engaged
- Three HAZOP workshop sessions held (Month 1-2 = 2026-11-09 to 2026-12-09)

### 42. Safety and Regulatory Lead drafts the Safety Design Basis (incorporating HAZOP findings, selected inherent limits vs. instrumented protection, quantitative safety targets, Adopter Change Boundary v0.1 and control-system architecture). Obtain independent ATEX consultant review and approval before proceeding to detailed design.

**Responsible Body/Role:** Safety Working Group (led by Safety and Regulatory Lead)

**Suggested Timeframe:** Month 2 (2026-12-09) to Month 4 (2027-02-09)

**Key Outputs/Deliverables:**

- Safety Design Basis v0.1 document (Month 3 = 2027-01-09, final Month 4 = 2027-02-09)
- Specifies: choice of inherent limits (e.g., <4% O2 in H2-rich stream, <0.5 m3 H2 inventory) or layered instrumented protection; control-system architecture (PLC + interlocks or hardwired); emergency-shutdown procedure and interlock logic (preliminary)
- Adopter Change Boundary v0.1: pre-assessed substitutes (e.g., electrode materials, parameter ranges for safe operation) and components requiring full safety re-analysis (pressure rating, interlock logic)
- Independent ATEX consultant approval letter (Month 4 = 2027-02-09)

**Dependencies:**

- HAZOP findings available (Month 4 = 2027-02-09 draft)
- Reactor concept selected and design basis specified

### 43. PMO Director compiles the complete Phase One gate-panel briefing package: landscape review, bench-reactor audited comparison with selection recommendation, HAZOP and safety design basis, strain feasibility and regulatory pathways, deployment scenarios and locked thresholds, productivity and scale-up uncertainty ranges, blueprint v0.1, and identified risks and mitigation. Circulate to panel 4-6 weeks before gate meeting (Month 10 = 2027-08-09).

**Responsible Body/Role:** PMO Director with Technical Leads

**Suggested Timeframe:** Month 8 (2027-06-09) to Month 9 (2027-07-09)

**Key Outputs/Deliverables:**

- Phase One Gate-Panel Briefing Package (complete, Month 9 = 2027-07-09, 'evidence freeze')
- Package includes: Landscape Review summary; Reactor Concept Audited Comparison Report (audited, reactor selected); HAZOP Final Report; Safety Design Basis v0.1; Strain Feasibility Report; Regulatory Pathways (per jurisdiction); Deployment Scenarios and Adopter Commitments (signed); Technical Risk Register and Mitigation Plans; Blueprint v0.1 (preliminary); Measurement Framework (locked); Planned Phase Two work and budget (EUR 13.0M estimate); Gate-Panel Charter and independence confirmation
- Package quality-checked by Steering Committee and circulated to all 3-5 gate-review panel members by Month 10 (2027-08-09) deadline minus 4-6 weeks = ~Month 8.5 (2027-06-24 to June 09)

**Dependencies:**

- All Phase One evidence freeze deliverables complete by Month 9 (2027-07-09)
- Reactor audited comparison available
- Safety design basis finalized
- Strain feasibility, regulatory and scenario documentation all complete

### 44. Independent gate-review panel (3-5 members, funded and managed by funder, not project host) reviews the Phase One briefing package and prepares for gate-decision meeting scheduled for Month 10 (2027-08-09). Each panel member documents 30-40 hours of preparation time (covered by honoraria) and submits preliminary comments/questions to panel chair.

**Responsible Body/Role:** Independent Gate-Review Panel

**Suggested Timeframe:** Month 8.5 (2027-06-24 to 2027-06-09) to Month 10 (2027-08-09)

**Key Outputs/Deliverables:**

- Panel members' preparation completed (individual reviews and preliminary comments)
- Panel chair consolidates preliminary comments and prepares agenda for gate-decision meeting
- Gate-decision meeting scheduled (in-person or hybrid, 1.5-2 days) for Month 10 (2027-08-09)
- Panel members confirm attendance and technical questions/gaps to be addressed at meeting

**Dependencies:**

- Phase One Gate-Panel Briefing Package circulated to panel (Month 8.5 = 2027-06-24 to 2027-06-09)
- Panel members recruited, chartered and funded

### 45. Steering Committee convenes immediately before the gate-review panel meeting (by Month 10 = 2027-08-09 or early Month 11 = 2027-09-09) to review Phase One evidence internally, confirm gate-pass/fail recommendations and ensure alignment with panel. Steering Committee prepares responses to anticipated panel questions.

**Responsible Body/Role:** Steering Committee (led by Project Lead)

**Suggested Timeframe:** Month 9 (2027-07-09) to Month 10 (2027-08-09)

**Key Outputs/Deliverables:**

- Internal Steering Committee gate-readiness review meeting held (2-3 hours)
- Committee reviews: bench-reactor selection, safety design basis, strain and regulatory findings, scenario credibility, identified risks and Phase Two mitigation
- Committee approves Phase Two work plan and budget (EUR 13.0M estimate) conditional on gate pass
- Committee confirms readiness for panel meeting and identifies spokesperson for key topics

**Dependencies:**

- Phase One evidence freeze complete (Month 9 = 2027-07-09)
- Phase One briefing package prepared for Steering Committee review

### 46. Independent gate-review panel convenes for the Phase One gate-decision meeting (Month 10 = 2027-08-09). Panel reviews evidence against pre-defined gate criteria: strain rights documented, productivity criterion met, Kenyan biosafety feasibility confirmed, reference architecture decided, HAZOP complete, safety design basis approved, scenarios locked, product category named, blueprint v0.1 issued. Panel deliberates and produces written continue/modify/research-only/stop decision.

**Responsible Body/Role:** Independent Gate-Review Panel

**Suggested Timeframe:** Month 10 (2027-08-09) (gate meeting) to Month 10-11 (2027-08-09 to 2027-09-09) (written decision)

**Key Outputs/Deliverables:**

- Phase One Gate-Decision Meeting Report (1.5-2 day meeting, Month 10 = 2027-08-09)
- Meeting documents: panel assessment against each gate criterion, evidence strengths and gaps, risks and recommended mitigations, final recommendation (Continue to Phase Two, Modify and retry gate, Research Only, or Stop)
- Written Panel Recommendation (3-5 pages, Month 10-11 = 2027-08-09 to 2027-09-09)
- Signed by all panel members; includes rationale and any dissenting views published verbatim

**Dependencies:**

- All Phase One evidence available and reviewed by panel (complete briefing package, Month 8.5 = 2027-06-24 to 2027-06-09)
- Panel members prepared (30-40 hours each)
- Steering Committee pre-gate review completed

### 47. Funder reviews the independent gate-review panel's written recommendation (Month 10-11 = 2027-08-09 to 2027-09-09) and makes the formal Phase One gate decision: continue to Phase Two, or require modification/research-only/stop. Funder publishes its decision and any deviation from panel recommendation with written justification.

**Responsible Body/Role:** Funder

**Suggested Timeframe:** Month 11 (2027-09-09) to Month 12 (2027-10-09)

**Key Outputs/Deliverables:**

- Funder's Phase One Gate Decision Letter (Month 12 = 2027-10-09)
- Decision: Continue to Phase Two (if criterion met), or Modify and re-gate by Month 13-14 (2027-11-09 to 2027-12-09), or Research Only, or Stop
- If decision deviates from panel recommendation, published written justification (to all stakeholders, Steering Committee, gate panel and funder)
- If Continue decision: Phase Two work-plan and EUR 13.0M budget allocation approved; phase-transition kickoff meeting scheduled (Month 12-13 = 2027-10-09 to 2027-11-09)

**Dependencies:**

- Panel recommendation received (Month 10-11 = 2027-08-09 to 2027-09-09)
- Steering Committee briefed on panel findings

### 48. If Phase One gate decision is 'Continue', Steering Committee and PMO Director initiate Phase Two transition (Month 12-13 = 2027-10-09 to 2027-11-09): recruit Phase Two-specific roles (pilot-scale reactor engineer, downstream-processing lead, early-replication coordinator), finalize Phase Two work schedule (Months 12-30 = 2027-10-09 to 2029-04-09), confirm facilities and equipment procurement for Phase Two (pilot-scale reactors, downstream-processing equipment), and schedule Phase Two kickoff meeting.

**Responsible Body/Role:** Project Lead / Steering Committee / PMO Director

**Suggested Timeframe:** Month 12 (2027-10-09) to Month 13 (2027-11-09)

**Key Outputs/Deliverables:**

- Phase Two Transition Plan (Month 12 = 2027-10-09)
- Phase Two staffing identified (pilot-scale engineer, downstream lead, early-replication coordinator, training lead)
- Phase Two work schedule locked (100+ work packages, critical path, Month 9 = 2027-07-09 evidence freeze, Month 21 = 2028-07-09 gate meeting target Month 30 = 2029-04-09)
- Phase Two EUR 13.0M budget allocation confirmed by funder
- Procurement initiated for Phase Two equipment (pilot-scale reactors, downstream-processing equipment, training materials)

**Dependencies:**

- Phase One gate decision: Continue (from Month 12 = 2027-10-09)
- Funder approves Phase Two budget (EUR 13.0M estimate)

### 49. Steering Committee and PMO convene the Phase One closing meeting (Month 12 = 2027-10-09) to capture lessons learned, document any scope changes or technical pivots from Phase One, confirm Phase Two roles and accountabilities, and transition technical working groups to Phase Two focus. Confirm continuation of Safety, Regulatory, Reactor and Kenyan Coordination working groups; establish new working groups as needed (Downstream Processing, Early Replication).

**Responsible Body/Role:** Steering Committee (led by Project Lead)

**Suggested Timeframe:** Month 12 (2027-10-09)

**Key Outputs/Deliverables:**

- Phase One Closing Report (Month 12 = 2027-10-09)
- Documents: lessons learned (what worked well, what to improve), technical pivots or design changes from Phase One plan, carry-over risks to Phase Two, updated risk register
- Phase Two Technical Working Groups confirmed: Safety, Regulatory, Reactor/Scale-Up, Kenyan Replication, Downstream Processing (new), Early Replication (new)
- Working-group charters updated for Phase Two scope
- Steering Committee confirms Phase Two meeting schedule (quarterly, Months 15, 18, 21, 24, 27, 30 = 2028-01-09, 2028-04-09, 2028-07-09, 2028-10-09, 2029-01-09, 2029-04-09)

**Dependencies:**

- Phase One gate decision released (Month 12 = 2027-10-09)
- Phase Two work plan and budget approved

### 50. If Phase One gate decision is 'Modify', Steering Committee and funder jointly decide on remediation scope and timeline (modify budget or schedule), publish the issue to all stakeholders, and establish a re-gate schedule (target Month 13-14 = 2027-11-09 to 2027-12-09 or later). Assign clear ownership and success criteria for each remediation item. Document assumptions and success thresholds in writing.

**Responsible Body/Role:** Steering Committee / Funder / Project Lead

**Suggested Timeframe:** Month 12 (2027-10-09) to Month 13 (2027-11-09) (if Modify decision)

**Key Outputs/Deliverables:**

- Phase One Remediation Plan (Month 12-13 = 2027-10-09 to 2027-11-09)
- Documents: specific issues requiring remediation (e.g., strain rights blocking, productivity below threshold, regulatory pathway unclear), root cause, remediation steps, owner, timeline, success criteria and re-gate date
- Published to all stakeholders (gate panel, Steering Committee, funder, adopters) with transparent messaging
- Updated risk register and revised Phase One budget (if additional spend needed, draw from EUR 0.65M contingency with contingency-allocation decision by Steering Committee)
- Re-gate-decision meeting scheduled with panel (Month 13-14 = 2027-11-09 to 2027-12-09 or later, depending on remediation timeline)

**Dependencies:**

- Phase One gate decision: Modify (from funder, Month 12 = 2027-10-09)
- Panel recommendation and remediation guidance available

### 51. If Phase One gate decision is 'Research Only' or 'Stop', Steering Committee convenes with Funder and gate-review panel to document findings, capture lessons learned and produce a public-knowledge report summarizing the scientific work, identified barriers and recommendations for future work. Transition project to wind-down (if Stop) or pivot to research-publication mode (if Research Only).

**Responsible Body/Role:** Steering Committee / Funder / Project Lead

**Suggested Timeframe:** Month 12 (2027-10-09) onwards (if Research Only or Stop)

**Key Outputs/Deliverables:**

- Phase One Final Report (Month 12-15 = 2027-10-09 to 2028-01-09)
- Documents: project scope and objectives (from initial plan), evidence generated (landscape review, bench-reactor data, safety analysis, regulatory and strain-rights findings), barriers identified, scientific findings and published data, recommendations for future work or alternative approaches
- Published data package released (open license, per steward-entity governance and freedom-to-operate assessment)
- If Stop: project team transition plan and facility/equipment disposition
- If Research Only: pivot to peer-reviewed publication strategy; confirm funding for 2-3 key publications; update project team roles

**Dependencies:**

- Phase One gate decision: Research Only or Stop (from funder, Month 12 = 2027-10-09)
- Panel recommendation and findings report available

### 52. Throughout Phase Two (Months 12-30 = 2027-10-09 to 2029-04-09), Steering Committee continues to meet quarterly (Months 15, 18, 21, 24, 27, 30 = 2028-01-09, 2028-04-09, 2028-07-09, 2028-10-09, 2029-01-09, 2029-04-09) to review Phase Two progress, cost-control status, technical risks and gate-readiness. PMO maintains weekly workstream coordination and monthly cost-control reports. Technical working groups meet bi-weekly or weekly as appropriate to their workstream phase.

**Responsible Body/Role:** Steering Committee / PMO / Technical Working Groups

**Suggested Timeframe:** Months 15, 18, 21, 24, 27, 30 (2028-01-09 to 2029-04-09)

**Key Outputs/Deliverables:**

- Quarterly Steering Committee meeting minutes and decision logs (Months 15, 18, 21, 24, 27, 30 = 2028-01-09, 2028-04-09, 2028-07-09, 2028-10-09, 2029-01-09, 2029-04-09)
- Monthly PMO cost-control reports (tracking EUR 13.0M Phase Two budget)
- Monthly technical working-group progress reports (reactor scale-up, downstream validation, strain stability, early replication)
- Gate-readiness checkpoint reports (starting Month 25 = 2028-11-09, tracking evidence for Phase Two gate at Month 30 = 2029-04-09)

**Dependencies:**

- Phase One gate decision: Continue (Month 12 = 2027-10-09)
- Phase Two work plan and budget approved

### 53. By Month 30 (2029-04-09), PMO Director compiles Phase Two evidence-freeze deliverables: pilot-scale reactor disproof-experiment results (kLa, productivity, strain stability), downstream-processing validation at pilot scale, early independent replication defect log and resolutions, composition and digestibility data confirming product-category choice, Phase Two-gate briefing package for review panel. Circulate to panel 4-6 weeks before Phase Two gate meeting (Month 30-32 = 2029-04-09 to 2029-06-09, meeting target Month 30 = 2029-04-09).

**Responsible Body/Role:** PMO Director with Technical Leads

**Suggested Timeframe:** Month 28 (2029-02-09) to Month 30 (2029-04-09)

**Key Outputs/Deliverables:**

- Phase Two Gate-Panel Briefing Package (complete, Month 30 = 2029-04-09, 'evidence freeze')
- Package includes: Pilot-scale Disproof-Experiment Results (audited, kLa/productivity/strain stability vs. bench baseline); Downstream-Processing Validation (nucleic acid removal, protein purity, energy per kg); Early Independent Replication Report (defect log and resolutions, documentation readiness assessment); Composition and Digestibility Data; Scale-Up Evidence Ladder (bench to pilot to reference-unit model); Phase III Reference-Unit Design (preliminary); Phase II Risk Summary and Mitigation
- Package reviewed by Steering Committee before circulation to panel

**Dependencies:**

- All Phase Two experiments and early replication work complete by Month 30 (2029-04-09)
- External audits (disproof-experiment validation, early-replication defect-log review) completed

### 54. Independent gate-review panel reviews Phase Two briefing package (Months 30-32 = 2029-04-09 to 2029-06-09), prepares for gate-decision meeting (Month 32 = 2029-06-09 estimate), and produces written continue/modify/research-only/stop decision. If Phase II thresholds are met (kLa decline <=25%, strain stability <10% drift, defects resolved), panel recommends Continue to Phase Three; else Modify or Research Only.

**Responsible Body/Role:** Independent Gate-Review Panel

**Suggested Timeframe:** Month 30 (2029-04-09) to Month 32-33 (2029-06-09 to 2029-07-09)

**Key Outputs/Deliverables:**

- Phase Two Gate-Decision Meeting (Month 32 = 2029-06-09, meeting; Month 33 = 2029-07-09, written decision)
- Panel assessment: disproof thresholds met? Downstream ready? Composition/digestibility confirm category? Early replication defects resolved? Documentation ready? Scale-up evidence credible? Regulatory pathway still open?
- Written Panel Recommendation: Continue to Phase Three, or Modify with remediation plan, or Research Only

**Dependencies:**

- Phase Two briefing package complete and circulated (Month 30 = 2029-04-09)
- Panel members prepared (30-40 hours each)

### 55. Funder reviews Phase Two panel recommendation (Month 33 = 2029-07-09) and makes formal gate decision: Continue to Phase Three, Modify, Research Only, or Stop. Funder publishes decision and any deviation from panel recommendation with justification by Month 34 (2029-08-09). If Continue: approve Phase Three work plan and EUR 22.0M budget; schedule Phase III kickoff (Months 34-35 = 2029-08-09 to 2029-09-09).

**Responsible Body/Role:** Funder

**Suggested Timeframe:** Month 33 (2029-07-09) to Month 34 (2029-08-09)

**Key Outputs/Deliverables:**

- Funder's Phase Two Gate Decision Letter (Month 34 = 2029-08-09)
- Decision: Continue to Phase Three, Modify and re-gate, Research Only, or Stop
- If Continue: Phase Three work-plan (Months 30-60 = 2029-04-09 to 2031-10-09) and EUR 22.0M budget approved; hardware procurement (Danish and Kenyan reference units, EUR 4.0M) conditionally approved with release at Phase II gate
- If deviation from panel recommendation: published written justification

**Dependencies:**

- Panel recommendation received (Month 33 = 2029-07-09)
- Steering Committee briefed

### 56. If Phase II gate decision is Continue, Steering Committee and PMO initiate Phase III transition (Months 34-35 = 2029-08-09 to 2029-09-09): recruit Phase III-specific roles (reference-unit commissioning engineer, operator training lead, replication independence auditor for full-scale build), finalize Phase III detailed schedule (Months 30-60 = 2029-04-09 to 2031-10-09), release hardware procurement (Danish and Kenyan reference units), and confirm facility commissioning plans.

**Responsible Body/Role:** Project Lead / Steering Committee / PMO Director

**Suggested Timeframe:** Months 34-35 (2029-08-09 to 2029-09-09)

**Key Outputs/Deliverables:**

- Phase III Transition Plan (Month 34 = 2029-08-09)
- Phase III staffing identified (reference-unit commissioning lead, operator training lead, auditor for independence assurance)
- Phase III detailed schedule (Months 30-60 = 2029-04-09 to 2031-10-09): Danish unit commissioning Months 40-46 (2030-02-09 to 2030-08-09, six-month run); Kenyan build Months 40-48 (2030-02-09 to 2030-10-09), six-month production Months 48-54 (2030-10-09 to 2031-04-09), fault-injection Months 50-56 (2030-12-09 to 2031-06-09)
- Hardware procurement released (Danish and Kenyan reference-unit equipment, EUR 4.0M from programme reserve)
- Phase III EUR 22.0M budget allocation confirmed by funder

**Dependencies:**

- Phase II gate decision: Continue (Month 34 = 2029-08-09)
- Funder approves Phase III budget and hardware release

### 57. Throughout Phase III (Months 30-60 = 2029-04-09 to 2031-10-09), Steering Committee continues quarterly meetings (Months 36, 42, 48, 54 = 2029-10-09, 2030-04-09, 2030-10-09, 2031-04-09), PMO maintains weekly coordination and monthly cost-control, and technical working groups support commissioning, operation and replication. Kenyan Replication Coordination body meets monthly and conducts quarterly site-envelope baseline monitoring (starting Month 30 = 2029-04-09). Independent auditor reviews assistance log and defect log monthly throughout Phase III.

**Responsible Body/Role:** Steering Committee / PMO / Technical Working Groups / Kenyan Coordination / Independent Auditor

**Suggested Timeframe:** Months 36, 42, 48, 54 (2029-10-09, 2030-04-09, 2030-10-09, 2031-04-09) for Steering Committee; monthly for Kenyan Coordination and audits

**Key Outputs/Deliverables:**

- Quarterly Steering Committee meeting minutes (Months 36, 42, 48, 54 = 2029-10-09, 2030-04-09, 2030-10-09, 2031-04-09)
- Monthly PMO cost-control and schedule reports (tracking EUR 22.0M Phase III budget, programme reserve EUR 4.0M)
- Monthly Kenyan Coordination reports (site logistics, staff, equipment status, assistance-log and defect-log audit summaries)
- Quarterly Kenyan site-envelope baseline-monitoring reports (power outages, water quality, spare-parts availability, technician performance)
- Monthly independent-auditor assistance-log and defect-log reviews with flag for >4 h/month troubleshooting or unresolved critical defects

**Dependencies:**

- Phase II gate decision: Continue
- Phase III transition plan and staffing finalized

### 58. By Month 57 (2031-07-09), PMO Director compiles Phase III evidence-freeze deliverables: Danish reference-unit six-month uptime and productivity data, Kenyan replication unit six-month production data and outage-survival results, operator practical safety assessments (>=90% pass rate), fault-injection test results (100% of safety-critical reach safe state, >=90% recovery of other tests), composition and digestibility confirmation, regulatory feasibility assessment, scale-up evidence summary, assistance-log audit summary (independence assessment), deployment-scenario threshold comparison. Circulate Phase III gate briefing package to panel 4-6 weeks before Phase III gate meeting (Month 57-60 = 2031-07-09 to 2031-10-09).

**Responsible Body/Role:** PMO Director with Technical Leads

**Suggested Timeframe:** Month 55 (2031-05-09) to Month 57 (2031-07-09)

**Key Outputs/Deliverables:**

- Phase III Gate-Panel Briefing Package (complete, Month 57 = 2031-07-09, 'evidence freeze')
- Package includes: Danish Reference-Unit Performance Data (6 months uptime, productivity, energy per kg, any incidents); Kenyan Replication Performance Data (6 months production, outage-survival results, restart time, productivity recovery); Operator Safety Assessment Results (training completion, practical safety test scores >=90%); Fault-Injection Test Results (predefined tests, pass/fail per test, 100% critical, >=90% other); Product Specification Confirmation (composition, nucleic acid content, digestibility); Regulatory Pathway Feasibility (per jurisdiction, approval timeline, blockers if any); Scale-Up Evidence (bench to pilot to reference, uncertainty ranges, disproof experiments, scale-up route); Assistance-Log Audit Summary (independence assessment, help frequency, sources); Deployment-Scenario Threshold Comparison (measured cost, capacity, uptime vs. locked thresholds); Hypotheses A and B Results (separately reported)

**Dependencies:**

- Danish reference-unit operation complete (6 months, Months 40-46 = 2030-02-09 to 2030-08-09)
- Kenyan replication production complete (6 months, Months 48-54 = 2030-10-09 to 2031-04-09)
- Fault-injection tests completed (Months 50-56 = 2030-12-09 to 2031-06-09)
- All final data analysis and audits completed by Month 57 (2031-07-09)

### 59. Independent gate-review panel reviews Phase III briefing package (Months 57-60 = 2031-07-09 to 2031-10-09), prepares for final gate-decision meeting (Month 60 = 2031-10-09), and produces written final decision: Go, Modify, Research Only, or Stop. Panel assesses all Phase III gate criteria: replication from documentation alone? Safety-critical faults all safe? >=90% other fault recovery? Six-month uptime >=90%? >=90% operator safety pass? At least one scenario met? Regulatory and scale-up routes credible?

**Responsible Body/Role:** Independent Gate-Review Panel

**Suggested Timeframe:** Month 57 (2031-07-09) to Month 60 (2031-10-09)

**Key Outputs/Deliverables:**

- Phase III Gate-Decision Meeting (Month 60 = 2031-10-09; May extend to final decision by end of Month 60 = 2031-10-09)
- Panel assessment: replication documentation-independent? Safety pass? Fault injection pass? Uptime >90%? Operator competence >90%? Scenario(s) met? Hypotheses A and B both supported or one failed?
- Written Final Gate Decision: Go (all criteria met, project validated), Modify (weaknesses correctable), Research Only (technology works but no credible deployment case), or Stop (fundamental failure)

**Dependencies:**

- Phase III briefing package complete and circulated (Month 57 = 2031-07-09)
- All Phase III data analysis and audits finalized
- Panel members prepared (30-40 hours each)

### 60. Funder reviews Phase III panel recommendation (Month 60 = 2031-10-09 or shortly after) and makes final project decision: Go, Modify, Research Only, or Stop. Funder publishes the final decision and any deviation from panel recommendation with written justification by Month 60 (2031-10-09). If Go: authorize publication of open-source package, confirm steward-entity governance and long-term funding. If Research Only or Stop: transition to public-knowledge documentation and project wind-down.

**Responsible Body/Role:** Funder

**Suggested Timeframe:** Month 60 (2031-10-09)

**Key Outputs/Deliverables:**

- Funder's Final Phase III Gate Decision Letter (Month 60 = 2031-10-09)
- Decision: Go, Modify, Research Only, or Stop, with written justification
- If Go: publish open-source package (hardware, software, documentation, data) under open licences; confirm steward-entity legal structure and funding; communicate project success and adoption pathway to stakeholders
- If Modify/Research Only/Stop: project transition plan, public-knowledge report publication, team wind-down or re-focus

**Dependencies:**

- Panel recommendation received (Month 60 = 2031-10-09)
- Steering Committee and project team briefed