This plan implies one or more physical locations.

## Requirements for physical locations

- Electrical supply with documented outage patterns for testing
- Water supply with measurable quality constraints
- Ambient temperature and humidity range suitable for fermentation
- Space for laboratory, pilot-scale, and container-scale bioreactors
- Hydrogen production, gas-handling and fermentation infrastructure (ATEX-compliant)
- Spare-part availability and local technical skills for repairs and maintenance
- Capacity to test power outages, restarts and culture continuity
- Capacity for training and competency verification of local technicians
- Access to analytical capability for biological quality assurance and composition testing
- Safety review and process-hazard analysis infrastructure
- Regulatory access (permitting, contained use, product validation)
- Proximity to nitrogen sources and mineral inputs or supplier networks

## Location 1
Denmark

University-based research and industrial site, such as Copenhagen or Aarhus region

Danish university consortium or research institute with bioreactor facilities, electrolysis capability, and ATEX-compliant laboratory and container-scale space

**Rationale**: The plan explicitly designates Denmark as the development and test site. Phase One and Two require laboratory experiments with candidate strains, gas-fermentation prototypes and scale-up testing. Phase Three requires a reference unit demonstrating six months of continuous operation, safety commissioning and ATEX design verification. A university consortium provides access to analytical capability, safety review, regulatory liaison and established infrastructure. The site must support matched reactor comparisons (pneumatic, pressurized stirred, passive-feed) on identical strain and media.

## Location 2
Kenya

Real-world site with documented power outages, limited spare-part access and locally available technical skills, such as Nairobi region or agricultural zone

Kenyan co-development partner organization with capacity for on-site fermentation, commissioning, outage testing and fault-injection trials, separate from Danish developers

**Rationale**: The plan mandates Kenya as the independent replication site and specifies that the site must test the defined operating envelope: electricity availability and outage pattern, water quality, ambient temperature and humidity, spare-part availability and available technical skills. It must not be a well-equipped laboratory. The replication team must be organizationally separate, and the site must support outage-survival testing, documented restart procedures, locally trained technician operation, and a pre-defined audited fault-injection and component-substitution test programme. This is the primary evidence for hypothesis B (decentralized modules under difficult infrastructure).

## Location 3
Global (regulatory and landscape review scope)

Patent, regulatory and market-research offices in Denmark, EU, Kenya and Bangladesh (optional third-country landscape)

Regulatory bodies: Danish Environmental Protection Agency or equivalent EU competent authorities for contained use; Kenya's National Biosafety Authority; Bangladesh regulatory agencies for patent and distribution landscape

**Rationale**: Phase One includes a landscape review of patent and regulatory requirements for experimental operation, product safety validation and commercial distribution in Denmark/EU, Kenya and Bangladesh. The plan requires early informal regulator engagement to surface hard requirements on strain classification, contained-use permits, product safety dossiers and distribution pathways before hardware is committed. This is a desk-based activity supported by site visits and pre-submission dialogue, but the physical locations are the regulatory bodies' offices where applications and consultations occur.

## Location Summary
The Open Protein Module has three primary physical location requirements. Denmark hosts Phase One and Two laboratory and pilot work and the Phase Three reference unit, requiring a university consortium or research institute with bioreactor, electrolysis and ATEX-compliant facilities. Kenya hosts the independent replication team and site, which must test the defined harsh operating envelope (outages, limited supply chains, locally available skills) and is organizationally separate from Danish developers. A third dimension covers regulatory landscape review and early engagement with competent authorities in Denmark/EU and Kenya to identify hard requirements on strain classification, contained use, product safety and distribution before large hardware investment. The plan emphasizes that all funding, partners, sites and permits are treated as uncontrolled until signed, and that the Kenyan site must be chosen for realistic testing, not convenience or good laboratory conditions.