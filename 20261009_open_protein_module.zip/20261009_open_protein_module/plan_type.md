This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** The plan is classified as physical. It sets up a non-profit engineering project that builds and operates real hydrogen-oxidizing bacteria gas-fermentation hardware. The work cannot be done online, and nearly every phase needs a physical site, equipment or materials.

1. Laboratory and container-scale work (Phase One and Two). Initial experiments with candidate strains such as Cupriavidus necator need laboratory facilities, bioreactors, electrolyzers, gas supply, and physical measurement of mass transfer, productivity and energy use. Outage and robustness testing and scale-up experiments are physical tests on real equipment.

2. Reference unit in Denmark (Phase Three). The plan builds a reference unit at the Danish development and test site. This involves construction, procurement, ATEX-compliant installation, commissioning, and six months of continuous operation to measure uptime.

3. Independent replication in Kenya. A separate Kenyan team must obtain the strain, build the system from documentation alone, and produce biomass. The site must be a real-world one that tests the operating envelope: power outages, water quality, temperature and humidity, spare-part availability and local skills. The team also has to run physical fault-injection and component-substitution tests.

4. Safety and the hydrogen-oxygen explosion risk. Process-hazard analysis, interlocks, emergency shutdown and ATEX design are all physical engineering. They must be verified on installed hardware.

5. Physical inputs and logistics. The material and energy balance covers nitrogen sources, minerals, process chemicals, water treatment, cooling and replacement parts such as electrolyzer membranes. All of these must be sourced and shipped, and resupply autonomy has to be tested. Biomass must also be harvested, processed (including nucleic acid reduction) and dried, and then tested for composition and digestibility.

6. In-person activities. The plan includes training and competency verification of local technicians, hosting by a university consortium with a Kenyan partner, regulatory sampling and product validation, and site visits for audits and gate reviews.

Some parts are digital. These are the landscape review, the techno-economic model, the patent and regulatory research, and the open-licence publication of the source package. They support the physical work and do not replace it. Nothing here comes close to being purely digital, so the classification is physical.