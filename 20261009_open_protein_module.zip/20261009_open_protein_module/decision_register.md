**5 open decisions: 4 high and 1 medium severity.** The most urgent decisions are the hardware-release cost rule, which is needed by Month 1.5 (2026-11-24) for the Gate Authority Charter, and the Kenyan envelope rule, which is needed by Month 1 (2026-11-09). The gap-funding route, the Scenario B decision and the meaning of 'scenario met' follow by Months 6-9 (2027-04-09 to 2027-07-09). Until these are made, the plan can safely run the landscape review, strain rights work, HAZOP and bench work, and the panel and host setup. It should not make hardware or scenario-locking commitments.

| # | Decision | Severity | Owner | Decide by | Blocks |
|---|---|---|---|---|---|
| 1 | Gap-funding route | 🔴 High | Funder (release authority), with the Steering Committee and adopters. | Month 7 (2027-05-09): written commitment is needed before scenarios lock at Month 9 (2027-07-09). | Month 7 (2027-05-09) gate check, scenario locking at Month 9 (2027-07-09), and release of EUR 4.0M hardware at the Phase Two gate. |
| 2 | Hardware-release cost rule | 🔴 High | Funder, before the Gate Authority Charter. | Month 1.5 (2026-11-24): the Charter and KPI framework lock then. | Gate Authority Charter and KPI framework (Month 1.5 = 2026-11-24); the Phase Two hardware release. |
| 3 | Scenario B: re-price, drop or keep | 🔴 High | Steering Committee with the named adopters; funder ratifies. | Month 6 (2027-04-09): scenario profiles are due then, before signing at Month 7 (2027-05-09). | Scenario profiles (Month 6 = 2027-04-09), signed adopters (Month 7 = 2027-05-09), locking (Month 9 = 2027-07-09). |
| 4 | Meaning of 'scenario met' | 🔴 High | Funder with the Independent Gate-Review Panel. | Month 9 (2027-07-09): scenarios lock then. | Scenario locking (Month 9 = 2027-07-09) and the Phase Three Go decision (Month 60 = 2031-10-09). |
| 5 | Kenyan site baseline and fixed envelope | 🟡 Medium | Steering Committee with the Kenyan co-development partner; the panel advises. | Month 1 (2026-11-09): the independent site study must start before the partner agreement (Month 3 = 2027-01-09). | Month 4 (2027-02-09) baseline report and the strain and site gate check. |

## 1. Gap-funding route (🔴 High)

**Decision:** Which route closes the EUR 274,820/yr deployment gap: adopter grant (EUR 3.0M capex), operating subsidy, or cost reduction?

**Why it is open:** Gap is not covered by the programme budget. Full cost EUR 19.93/kg vs EUR 12 cap. A EUR 3.0M capex grant leaves a EUR 14,180/yr surplus. The route is undecided.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Capex grant of EUR 3.0M from funder or adopter. | Removes debt service; operating margin EUR 14,180/yr. Reaches Scenario A and probably C, but not B (opex EUR 11.59/kg). Needs written commitment by Month 7 (2027-05-09). | deployment_financing, gap_funding_open_decision, Month 7 (2027-05-09) gate evidence. |
| B. Annual operating subsidy of about EUR 274,820/yr. | Creates a recurring obligation beyond the programme. Needs a named payer with auditable terms. | deployment_chain_gap, adopter agreements, steward funding. |
| C. Rely on cost reduction alone (electricity, downstream energy). | No new funding. High risk at Month 6 (2027-04-09) (tripwire EUR 15/kg). May lead to Research Only or a reduced Phase Three. | energy_per_kg, TEA model, construction_spend_recommendation. |

- **If nobody decides:** No gap route is committed by Month 7 (2027-05-09), so the Phase One gate cannot pass. Recommend Research Only or a reduced Phase Three.
- **Owner:** Funder (release authority), with the Steering Committee and adopters.
- **Decide by:** Month 7 (2027-05-09): written commitment is needed before scenarios lock at Month 9 (2027-07-09).
- **Blocks:** Month 7 (2027-05-09) gate check, scenario locking at Month 9 (2027-07-09), and release of EUR 4.0M hardware at the Phase Two gate.

## 2. Hardware-release cost rule (🔴 High)

**Decision:** What single cost rule (value, and pre- or post-subsidy basis) releases the EUR 4.0M hardware, kept separate from the Phase Three success test?

**Why it is open:** The release trigger is EUR 14/kg. Failure is stated as both 14 and 15. 'EUR 12-14 enables a scenario' conflicts with caps of 12, 10 and 15. The subsidy basis is not stated.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. EUR 14/kg (proposed threshold) judged after the committed grant or subsidy, per scenario. | Aligns with the gap route. Needs a committed route at the Phase Two gate (Month 30 = 2029-04-09). | Gate Authority Charter, phase2_gate_criteria, KPI 1, premortem FM1. |
| B. EUR 14/kg judged before any subsidy. | Stricter. Raises the chance of a reduced Phase Three or Research Only. | Same documents; the capex grant no longer counts. |
| C. Set the release trigger equal to each scenario's cap. | Strictest. Ties release to caps of EUR 12, 10 or 15. Scenario B would likely fail. | Remove the generic 14 trigger; revise KPI 1. |

- **If nobody decides:** The Charter is chartered with an ambiguous rule, which invites post-hoc interpretation at Month 30 (2029-04-09).
- **Owner:** Funder, before the Gate Authority Charter.
- **Decide by:** Month 1.5 (2026-11-24): the Charter and KPI framework lock then.
- **Blocks:** Gate Authority Charter and KPI framework (Month 1.5 = 2026-11-24); the Phase Two hardware release.

## 3. Scenario B: re-price, drop or keep (🔴 High)

**Decision:** Is Scenario B (EUR 10/kg) re-priced, dropped, or kept with an explicit need for cost reduction below opex?

**Why it is open:** Opex alone is EUR 11.59/kg, so no grant can reach EUR 10. The gap is sized only against the EUR 12 cap. Scenario C has a different gap.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Drop Scenario B and lock A and C. | Simpler gate. Removes the 500 kg/day requirement. | scenario_b_thresholds, KPI 1, pitch. |
| B. Re-price B, for example to at least opex plus margin, with the adopter's agreement. | Keeps a feed-producer case. Must be agreed before Month 9 (2027-07-09). | scenario_b_thresholds, gap per scenario. |
| C. Keep B at EUR 10/kg, reachable only by cost reduction. | Probably unreachable, so it adds little to Go. | Document the per-scenario gap; remove 'enables B'. |

- **If nobody decides:** B is locked at EUR 10 and cannot be met, which weakens the scenario set.
- **Owner:** Steering Committee with the named adopters; funder ratifies.
- **Decide by:** Month 6 (2027-04-09): scenario profiles are due then, before signing at Month 7 (2027-05-09).
- **Blocks:** Scenario profiles (Month 6 = 2027-04-09), signed adopters (Month 7 = 2027-05-09), locking (Month 9 = 2027-07-09).

## 4. Meaning of 'scenario met' (🔴 High)

**Decision:** Is 'scenario met' measured on the 10 kg/day reference unit plus modeled scale-up, or does it need a funded deployment-scale unit?

**Why it is open:** Reference units give about 10 kg usable protein/day. Scenario floors are 50-500 kg/day. Deployment-scale units are modeled only and not programme-funded.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Measured cost, uptime and energy on the reference unit, plus an uncertainty-bounded model to scenario capacity. | Fits the EUR 50M ceiling. Capacity is not demonstrated. | phase3_gate_criteria, KPI 3, project plan 'Measurable'. |
| B. A funded deployment-scale unit with a named financier. | Strong evidence, but a large cost beyond the programme (modeled EUR 3.0M each). Delays beyond Month 60 (2031-10-09) are likely. | programme_financed_units, budget, schedule. |
| C. Accept either route, chosen per scenario and written in the lock document. | Flexible, but needs written rules at Month 9 (2027-07-09). | scenario locking document. |

- **If nobody decides:** The Phase Three Go test cannot be applied consistently, because capacity floors exceed built capacity.
- **Owner:** Funder with the Independent Gate-Review Panel.
- **Decide by:** Month 9 (2027-07-09): scenarios lock then.
- **Blocks:** Scenario locking (Month 9 = 2027-07-09) and the Phase Three Go decision (Month 60 = 2031-10-09).

## 5. Kenyan site baseline and fixed envelope (🟡 Medium)

**Decision:** Will the Kenyan envelope stay fixed, with the site changed if it fails, and what does the Month 4 (2027-02-09) baseline contain?

**Why it is open:** The partner is signed at Month 3 (2027-01-09), leaving about 4 weeks before the Month 4 (2027-02-09) baseline. Some documents allow renegotiating the envelope downward, which conflicts with the rule that the envelope is fixed.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Fix the envelope and change the site if it fails. Month 4 (2027-02-09) holds historical records plus spot samples; water sampling continues. Start the site study before signing. | Keeps the test honest. Costs a possible site switch and uses part of the reserve. | kenya_envelope_baseline, Review 8 and 9, site study start date. |
| B. Allow a documented downward envelope revision with panel consent. | Easier siting, but weakens the hypothesis B test. | kenya_envelope_baseline, hypothesis B claims. |

- **If nobody decides:** The site is chosen by convenience and the envelope is eased after the fact.
- **Owner:** Steering Committee with the Kenyan co-development partner; the panel advises.
- **Decide by:** Month 1 (2026-11-09): the independent site study must start before the partner agreement (Month 3 = 2027-01-09).
- **Blocks:** Month 4 (2027-02-09) baseline report and the strain and site gate check.

## Choices made on your behalf

Set when the scenario was selected, not by you. Confirm or change them.

| Lever | Chosen | Strongest alternative | Why it matters | Revisit by |
|---|---|---|---|---|
| Gas-liquid contacting and reactor concept | Run matched pneumatic, stirred and passive-feed reactors, then publish a productivity-versus-simplicity curve before choosing the reference unit. | A single low-pressure pneumatic reactor (Safe Foundation), or a pressurized stirred tank (Pioneer's Gambit). | It sets the Phase One bench cost and the evidence behind the reactor choice. | Month 2.5 (2026-12-24) (pre-registration) and Phase One gate. |
| Strain portfolio and rights strategy | Screen several strains and carry a primary plus a legally clean backup. | A single public-collection strain, or a project-owned strain. | Strain rights failure late could cost EUR 2-4M. | Month 4 (2027-02-09) Strain Feasibility Report. |
| Replication design and gate governance | Early paper-and-bench replication in Months 14-24 (2027-12-09 to 2028-10-09) by an independent group. | One full-scale Kenyan replication only, after the Danish unit. | It finds documentation defects before hardware is released. | Month 11 (2027-09-09) (defect tracker) and Phase Two gate. |
| Deployment scenario anchoring and threshold locking | Two to three scenarios with named adopters, locked and time-stamped at Month 9 (2027-07-09). | An adversarial panel that sets thresholds, or thresholds derived from published alternatives. | Locked thresholds determine Go at Phase Three. | Month 9 (2027-07-09). |
| Inherent safety design basis and adopter change boundary | Layered, independently reviewed interlocks with a short pre-assessed change list. | A machine-readable safety case, or inherently safer limits only. | It sets ATEX cost and how adopters may modify the design. | Month 3 (2027-01-09) (Adopter Change Boundary v0) and Phase One gate. |
