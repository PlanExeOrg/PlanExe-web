This plan involves money.

## Currencies

- **EUR:** Primary currency for budgeting, reporting and consolidated spending across the multi-country, multi-phase R&D programme. Denmark (eurozone) is the development and test site; EUR is used for international procurement, equipment costs and ceiling tracking (EUR 6 million Phase One, EUR 50 million total provisional ceiling).
- **KES:** Secondary currency for local costs in Kenya (replication site salaries, local procurement, utilities, site establishment). Essential for measuring local sourcing share and supply-chain resilience, and for tracking the impact of local sourcing and resupply autonomy on the deployment case. Exchange-rate volatility should be monitored to ensure it does not obscure cost control or exceed budgets.

**Primary currency:** EUR

**Currency strategy:** EUR is the primary currency for consolidated budgeting, large procurement and budget-ceiling tracking. Kenyan costs are tracked separately in KES to measure local sourcing and supply-chain resilience impacts on the deployment case. For multi-currency contracts (equipment, staff, logistics spanning Denmark and Kenya), use forward rates or hedging to protect the budget against currency fluctuations and to ensure the EUR 50 million provisional ceiling is not exceeded by exchange-rate movement. All Phase One and Phase Three spending decisions and gate reviews should reference EUR equivalents to maintain budget discipline.