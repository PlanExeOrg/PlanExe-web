# Purpose
and

# Domain
# Primary domain: Gas Fermentation Engineering

Secondary domains: Process Safety Engineering, Food Regulatory Affairs, Open Source Hardware

## Rationale

Gas Fermentation Engineering is the only outcome-role candidate and owns the core success criterion: a working, scalable hydrogen-oxidizing bacteria process. Process Safety Engineering, Techno-Economic Analysis and other candidates are constraints or methods subordinate to it.

## Disciplines

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Gas Fermentation Engineering | 5 | 5 | outcome | Hydrogen-oxidizing bacteria bioprocess, mass transfer and scale-up define the core success criterion. |
| Process Safety Engineering | 5 | 4 | constraint | Hydrogen-oxygen explosion risk requires hazard analysis, ATEX design and independent interlock review. |
| Techno-Economic Analysis | 4 | 5 | method | Cost model, scale-up uncertainty ranges, and deployment thresholds drive gate decisions and budget justification. |
| Downstream Bioprocessing | 4 | 5 | method | Harvesting, nucleic acid reduction, drying and protein quality of single-cell biomass. |
| Water Electrolysis | 4 | 5 | method | Electrolyzer selection, membranes, outage tolerance and hydrogen supply underpin the gas fermentation. |
| Food Regulatory Affairs | 4 | 4 | constraint | Novel protein needs credible EU, Danish and Kenyan feed or food authorization pathways. |
| Open Source Hardware | 4 | 4 | method | Complete open-licence source package with governance keeping the core open and replicable. |
| Industrial Microbiology | 4 | 4 | method | Reference strain selection, rights, biological quality assurance, and nucleic acid reduction in downstream processing. |
| Intellectual Property Law | 4 | 4 | constraint | Strain rights, patent restrictions per jurisdiction and open-licence governance must be cleared. |

# Plan Type
# Physical Location Requirement

This plan requires one or more physical locations. It cannot be executed digitally.

## Explanation

The plan is classified as physical. It sets up a non-profit engineering project that builds and operates real hydrogen-oxidizing bacteria gas-fermentation hardware. The work cannot be done online, and nearly every phase needs a physical site, equipment or materials.

- Laboratory and container-scale work (Phase One and Two). Initial experiments with candidate strains such as Cupriavidus necator need laboratory facilities, bioreactors, electrolyzers, gas supply, and physical measurement of mass transfer, productivity and energy use. Outage and robustness testing and scale-up experiments are physical tests on real equipment.
- Reference unit in Denmark (Phase Three). The plan builds a reference unit at the Danish development and test site. This involves construction, procurement, ATEX-compliant installation, commissioning, and six months of continuous operation to measure uptime.
- Independent replication in Kenya. A separate Kenyan team must obtain the strain, build the system from documentation alone, and produce biomass. The site must be a real-world one that tests the operating envelope: power outages, water quality, temperature and humidity, spare-part availability and local skills. The team also has to run physical fault-injection and component-substitution tests.
- Safety and the hydrogen-oxygen explosion risk. Process-hazard analysis, interlocks, emergency shutdown and ATEX design are all physical engineering. They must be verified on installed hardware.
- Physical inputs and logistics. The material and energy balance covers nitrogen sources, minerals, process chemicals, water treatment, cooling and replacement parts such as electrolyzer membranes. All of these must be sourced and shipped, and resupply autonomy has to be tested. Biomass must also be harvested, processed (including nucleic acid reduction) and dried, and then tested for composition and digestibility.
- In-person activities. The plan includes training and competency verification of local technicians, hosting by a university consortium with a Kenyan partner, regulatory sampling and product validation, and site visits for audits and gate reviews.

Some parts are digital. These are the landscape review, the techno-economic model, the patent and regulatory research, and the open-licence publication of the source package. They support the physical work and do not replace it. Nothing here comes close to being purely digital, so the classification is physical.

# Physical Locations
# Physical Location Requirements

- Electrical supply with documented outage patterns for testing
- Water supply with measurable quality constraints
- Ambient temperature and humidity range suitable for fermentation
- Space for laboratory, pilot-scale, and container-scale bioreactors
- Hydrogen production, gas-handling and fermentation infrastructure (ATEX-compliant)
- Spare-part availability and local technical skills for repairs and maintenance
- Capacity to test power outages, restarts and culture continuity
- Capacity for training and competency verification of local technicians
- Access to analytical capability for biological quality assurance and composition testing
- Safety review and process-hazard analysis infrastructure
- Regulatory access (permitting, contained use, product validation)
- Proximity to nitrogen sources and mineral inputs or supplier networks

# Location 1: Denmark

University-based research and industrial site, such as Copenhagen or Aarhus region

Danish university consortium or research institute with bioreactor facilities, electrolysis capability, and ATEX-compliant laboratory and container-scale space

## Rationale

The plan designates Denmark as the development and test site. Phase One and Two require laboratory experiments with candidate strains, gas-fermentation prototypes and scale-up testing. Phase Three requires a reference unit demonstrating six months of continuous operation, safety commissioning and ATEX design verification. A university consortium provides access to analytical capability, safety review, regulatory liaison and established infrastructure. The site must support matched reactor comparisons (pneumatic, pressurized stirred, passive-feed) on identical strain and media.

# Location 2: Kenya

Real-world site with documented power outages, limited spare-part access and locally available technical skills, such as Nairobi region or agricultural zone

Kenyan co-development partner organization with capacity for on-site fermentation, commissioning, outage testing and fault-injection trials, separate from Danish developers

## Rationale

The plan mandates Kenya as the independent replication site and specifies testing of the defined operating envelope: electricity availability and outage pattern, water quality, ambient temperature and humidity, spare-part availability and available technical skills. The site must not be a well-equipped laboratory. The replication team must be organizationally separate, and the site must support outage-survival testing, documented restart procedures, locally trained technician operation, and a pre-defined audited fault-injection and component-substitution test programme. This is the primary evidence for hypothesis B (decentralized modules under difficult infrastructure).

# Location 3: Global

Patent, regulatory and market-research offices in Denmark, EU, Kenya and Bangladesh (optional third-country landscape)

Regulatory bodies: Danish Environmental Protection Agency or equivalent EU competent authorities for contained use; Kenya's National Biosafety Authority; Bangladesh regulatory agencies for patent and distribution landscape

## Rationale

Phase One includes a landscape review of patent and regulatory requirements for experimental operation, product safety validation and commercial distribution in Denmark/EU, Kenya and Bangladesh. Early informal regulator engagement surfaces hard requirements on strain classification, contained-use permits, product safety dossiers and distribution pathways before hardware commitment. This is a desk-based activity supported by site visits and pre-submission dialogue, but physical locations are the regulatory bodies' offices where applications and consultations occur.

# Location Summary

Denmark hosts Phase One and Two laboratory and pilot work and the Phase Three reference unit, requiring a university consortium or research institute with bioreactor, electrolysis and ATEX-compliant facilities. Kenya hosts the independent replication team and site, which must test the defined harsh operating envelope (outages, limited supply chains, locally available skills) and is organizationally separate from Danish developers. A third dimension covers regulatory landscape review and early engagement with competent authorities in Denmark/EU and Kenya to identify hard requirements on strain classification, contained use, product safety and distribution before large hardware investment. All funding, partners, sites and permits are treated as uncontrolled until signed. The Kenyan site must be chosen for realistic testing, not convenience or good laboratory conditions.

# Currency Strategy
# Currencies

- EUR: Primary currency for budgeting, reporting and consolidated spending across the multi-country, multi-phase R&D programme. Denmark is the development and test site; EUR is used for international procurement, equipment costs and ceiling tracking (EUR 6 million Phase One, EUR 50 million total provisional ceiling).
- KES: Secondary currency for local costs in Kenya (salaries, local procurement, utilities, site establishment). Tracks local sourcing share and supply-chain resilience impact on the deployment case. Exchange-rate volatility must be monitored to ensure it does not obscure cost control or exceed budgets.

## Currency strategy

- EUR is the primary currency for consolidated budgeting, large procurement and budget-ceiling tracking.
- Kenyan costs tracked separately in KES to measure local sourcing and supply-chain resilience impacts.
- Multi-currency contracts (equipment, staff, logistics spanning Denmark and Kenya) use forward rates or hedging to protect against currency fluctuations and ensure EUR 50 million provisional ceiling is not exceeded.
- All Phase One and Phase Three spending decisions and gate reviews reference EUR equivalents to maintain budget discipline.


# Identify Risks
# Open Protein Module: Project Risk Summary

## Risk 1 – Safety & Hazard Control

Hydrogen-oxygen explosion hazard is the core technical safety risk. The process produces hydrogen and oxygen in proximity; ignition requires process containment, interlocks, emergency shutdown and ATEX compliance. Hydrogen gas inventory, control-system failure, seal rupture under pressure, electrolyzer malfunction or gas-feed backflow during power loss are plausible failure modes. An accident during Danish testing or Kenyan replication could cause serious injury or fatality, invalidate the site permit, or force design re-certification under stricter assumptions.

Likelihood: Medium | Severity: High

## Risk 1 Action

Conduct a rigorous Process Hazard Analysis (HAZOP or LOPA) during Phase One, before detailed design commitment. Specify the safety strategy explicitly: inherent limits (flammable-range composition or minimal gas inventory) or layered instrumented protection (interlocks, multiple sensors, independent emergency shutdown). Commission an independent third-party safety review of interlock logic and emergency-shutdown design before any pressurized or high-gas-inventory configuration is built. Define which components and parameters adopters may change without re-certification (pre-assessed substitutes list) and which require full safety re-analysis. Test the safety design on a small-scale mockup before committing to the Danish reference unit. Document all assumptions on seal integrity, electrolyzer reliability and control-system failure modes with uncertainty ranges, and validate them experimentally.

## Risk 2 – Strain Rights & Regulatory Classification

The project requires a reference strain lawfully obtainable for research, commercial production, redistribution and modification in both Denmark and Kenya. If the primary strain is subject to third-party restrictions, material transfer agreements, or biosafety or import regulations preventing lawful replication in Kenya, the entire open-replication pillar collapses. Patent claims on the strain, its derivatives or its use in hydrogen fermentation could emerge during Phase One, blocking publication or commercial deployment. Strain rights are often opaque: public-collection strains may carry undisclosed restrictions, and biosafety classification can differ between jurisdictions.

Likelihood: Medium | Severity: High

## Risk 2 Action

Begin Phase One with a detailed written rights analysis per candidate strain, covering research use, commercial production, redistribution, modification and derived strains. For each strain, confirm lawful obtainability by direct contact with the strain holder and the relevant regulatory body. Commission a patent search covering hydrogen fermentation, protein production and the specific strain in Denmark, EU and Kenya to identify third-party claims blocking publication or deployment. Carry a primary and a legally clean backup strain through Phase One and Two so neither a rights nor a performance failure stops the project. Confirm strain import permits and biosafety classification in Kenya before any design freeze (by Month 3–4 = 2027-01-09 to 2027-02-09). If the primary strain is subject to restrictions, engage the strain holder early to negotiate freedom-to-operate or identify alternatives. Store cryo-stocks of the reference and backup strains at multiple independent sites (Denmark, Kenya and a third location) so a contamination event does not lose the strain.

## Risk 3 – Regulatory & Permitting

The project must navigate permitting and product-safety pathways in Denmark (national + EU), Kenya and the global patent landscape. Regulatory risk covers: (1) Contained-use authorization for hydrogen-oxidizing bacteria fermentation in Denmark and Kenya; (2) product-safety dossier and classification (animal feed, fish feed, food ingredient, emergency nutrition) in EU and Kenya, which determines safety standards and approval timelines; (3) commercial distribution authorization; (4) patent claims by third parties blocking use or publication; (5) nucleic acid content limits that may be stricter than expected, forcing downstream-processing redesign. Early informal engagement with regulators can identify hard requirements but gives no binding feedback. Late engagement risks discovering a blocking requirement after hardware is built. The product-category choice at the Phase One end gate is irreversible without re-doing regulatory work.

Likelihood: Medium | Severity: High

## Risk 3 Action

Commission a dedicated regulatory-landscape review in Phase One (Month 0–3 = 2026-10-09 to 2027-01-09) covering: (1) contained-use and permitted-organism rules in Denmark/EU and Kenya; (2) product-safety and classification pathways for animal feed, fish feed, food ingredient and emergency nutrition; (3) nucleic acid content limits and composition standards; (4) patent landscape on hydrogen fermentation, autotrophic protein and the reference strain. Open informal pre-submission dialogue with the Danish EPA (or EU equivalent) and Kenya's National Biosafety Authority during Phase One to identify hard requirements and gain written feedback on the proposed operating envelope and product category. Fix the product-category choice at the Phase One kill gate, and do not change it without a full regulatory re-assessment. Appoint an independent regulatory counsel to track changes in national or EU guidance and alert the project to new requirements. Obtain a written feasibility assessment from Kenya's regulatory body confirming a pathway to contained-use authorization before committing to the Kenyan site or partner.

## Risk 4 – Technical & Scale-Up

The project aims to connect bench-scale laboratory experiments to a deployment capacity with uncertain scale-up factors. Principal scale-up assumptions likely include: gas-liquid mass-transfer coefficients scale predictably with reactor geometry and power input; volumetric productivity does not decline with scale; energy per kilogram does not increase with size; downstream-processing yield and throughput are not constrained by large-scale equipment availability. If matched reactor testing in Phase One or Two shows that one or more assumptions fail, the reference-unit design or the deployment-capacity model must be revised, consuming 3–8 months and significant cost in re-engineering and testing. Pre-registered disproof experiments with failure thresholds fixed before data arrive are required; if those thresholds are set too tight, a promising concept can be abandoned prematurely, while if too loose, weak evidence can pass. Hydrogen-oxidizing bacteria are not well-characterized at industrial scale: contamination, strain stability, nucleic acid accumulation and product quality over multi-month runs are not well-published.

Likelihood: Medium | Severity: High

## Risk 4 Action

In Phase One, identify the principal scale-up assumptions (gas-liquid mass-transfer coefficients, volumetric productivity, energy per kilogram, downstream yield and throughput) and state them explicitly with uncertainty ranges derived from published data or conservative engineering estimates. Design matched bench-scale experiments (pneumatic, pressurized stirred, and passive-feed reactors on identical strain and media) to measure these assumptions directly and compare measured values against model predictions. Pre-register the failure thresholds for each assumption before Phase Two experiments begin. Run the disproof experiments in Phase Two using intermediate-scale reactors (0.5–10 L pilot-scale units) and document all deviations from model predictions, with uncertainty ranges. If an assumption fails, conduct a root-cause analysis and either re-design the system or explicitly state that the assumption must remain unproven. For scale-up from Phase Two to the Phase Three reference unit, use validated engineering models with stated uncertainty and experimental validation on the critical dimensions. Commission an independent technical review of the scale-up logic before the reference-unit procurement begins.

## Risk 5 – Organizational & Partnership

The project requires an institutional host (university consortium or non-profit), a Kenyan co-development partner, prospective adopters for scenario anchoring, and independent gate reviewers. The plan states 'all funding, partners, sites and permits are treated as uncontrolled until signed', meaning none of these are committed yet. If a key partner withdraws or delays, the entire programme timeline could slip. University consortia often have competing priorities, slow decision-making and budget constraints; a Kenyan partner may face political or funding instability; prospective adopters may be reluctant to commit before seeing results; independent reviewers with true funding independence may be difficult to recruit.

Likelihood: Medium | Severity: Medium

## Risk 5 Action

Before Phase One begins, secure written institutional commitments from the host university or non-profit, specifying: dedicated laboratory and analytical space, key staff roles and protected time, funding flow and contingency plans for resource conflicts. Ensure the host has explicit leadership buy-in from the rector or executive director, not just a department head. Secure a signed agreement with the Kenyan partner covering: organization, staffing, site access, logistics, and contingency plans for partner-staff loss. Commit prospective adopters to the threshold-locking exercise in writing before Phase One ends, with a clause stating they remain bound to the thresholds even if internal conditions change. Recruit the independent gate-review panel early (Month 0–1 = 2026-10-09 to 2026-11-09) and fund them from a separate budget line that does not depend on project continuation. Specify their independence criteria in writing: no employment or funding from the host institution, no direct involvement in design decisions, authority to recommend Stop or Modify without justification. Establish a quarterly steering committee with clear authority to escalate partner or resource conflicts and trigger contingency plans.

## Risk 6 – Documentation & Replication Independence

A Kenyan team building the system from documentation alone is ambitious and will likely surface gaps and ambiguities in the source package. The plan requires every ambiguity to be logged and resolved, with all external assistance (safety, regulatory, specialist maintenance) recorded in an audited log. If documentation is incomplete or unclear, the replication team faces three choices: (1) infer from context and documentation, risking unsafe or non-functional builds; (2) seek undocumented help from the original developers, invalidating independence; or (3) halt replication and demand documentation fixes, causing schedule slip.

Likelihood: High | Severity: Medium

## Risk 6 Action

Plan for systematic documentation-defect discovery from the Phase II small-scale replication onward. Establish a formal defect-tracking system in which every ambiguity found during build or operation is logged with: (1) location in documentation, (2) description of the ambiguity, (3) resolution (documentation update, design clarification, or work-around), (4) source of resolution (original developer, external expert, or Kenyan team inference), and (5) date resolved. Assign a neutral third-party auditor (external to the project and the host institution) to review the defect log quarterly and certify that resolutions are documented, changes are traceable, and no critical gaps remain. Conduct the Phase II small-scale replication with the understanding that its primary goal is to discover documentation defects before Phase III full-scale build. Allocate at least EUR 100,000 and 2–3 months in Phase II specifically for documentation review and revision after the small-scale build. Before Phase III begins, require the independent gate reviewer to sign off on documentation completeness, with a clause stating what constitutes an acceptable defect rate. Establish a change-control process in which documentation updates during Phase III replication are released only after independent safety and legal review.

## Risk 7 – Financial & Budget Control

The project has a provisional ceiling of EUR 50 million and a Phase One cap of EUR 6 million, neither of which is a spending target but rather a constraint. The plan emphasizes that spending must be justified from the cost model, and unspent money should not trigger extra spending just to avoid underrun. Large technical uncertainties (scale-up, strain rights, safety design) and unsigned partners mean the actual spend profile is unknown, and overruns in one phase could consume flexibility in later phases. Currency volatility between EUR and KES could silently erase budget if not managed.

Likelihood: Medium | Severity: Medium

## Risk 7 Action

Establish a Phase-by-Phase spending plan tied to deliverables, with explicit decision criteria for each phase. Use zero-based budgeting in which every allocation must be justified from the cost model and the evidence roadmap, not from historical spending or organizational inertia. Set aside a 10–15% contingency budget within each phase for technical surprises, but do not spend it by default; use it only for disproof of a critical assumption or resolution of a discovery. Implement quarterly cost-control reviews comparing actual spending against planned burn-rate and deliverables achieved. For multi-currency spending, use forward-rate contracts or currency hedging to lock exchange rates for the major tranches of Kenyan spending and procurement, protecting the EUR 50 million ceiling from FX volatility. Separately fund the independent gate-review panel (budget at EUR 200,000–400,000 across the full 5-year programme) from a budget line outside the main project spend, ensuring their independence and their authority to stop or modify without facing financial pressure. Document all spending assumptions, cost drivers and uncertainty ranges in the cost model, and update the model quarterly as new data emerge. At each gate, require the project to re-estimate the cost to completion and report it transparently to the funder and reviewers.

## Risk 8 – Supply Chain & Logistics

The project must source or produce hydrogen via electrolysis, gas-handling and fermentation equipment, nitrogen and mineral inputs, water treatment, cooling and spare parts. The Kenyan replication explicitly tests local sourcing and supply-chain resilience: how long production continues without resupply during an energy crisis coinciding with a food crisis. If critical components have long lead times or require specialist sourcing, the Kenyan site may face multi-month delays in procurement, forcing project suspension.

Likelihood: Medium | Severity: Medium

## Risk 8 Action

Commission a detailed supply-chain and sourcing assessment during Phase One, identifying: (1) all critical components and their suppliers (electrolyzer membranes, fermentation-grade equipment, seals, analytical reagents); (2) lead times, minimum order quantities and cost; (3) alternative sources for each critical item; (4) local nitrogen and mineral sources in Kenya (suppliers, purity, reliability, lead times). For each critical input, establish a supplier-diversification strategy: no single supplier for any critical component, and at least two alternative sources (one regional, one import-ready) for items with long lead times. Negotiate framework agreements with suppliers covering lead times, inventory availability and force-majeure conditions. Maintain a 3–6 month inventory of critical spare parts at the Danish reference unit before Phase Three commissioning begins, and arrange for a similar stockpile to be built in Kenya before the replication start. In the resupply-autonomy analysis, use conservative assumptions: assume suppliers have only 2–4 weeks of inventory on hand, and set the 'maximum outage survived' metric assuming both Danish and Kenyan supplies are exhausted and shipping is delayed 4 weeks due to crisis conditions. Test the resupply-autonomy claim experimentally during Phase III by simulating a 2–3 month supply cutoff and monitoring how long production can continue and at what cost. Document all substitutions and workarounds in the Kenyan replication, and flag any that reduce the vendor-independence claim.

## Risk 9 – Technical Feasibility & Contamination Control

The project requires maintaining a single pure strain of hydrogen-oxidizing bacteria in an aseptic or contamination-tolerant culture for months of continuous operation, across bench, pilot and full-scale reactors in two countries. Contamination by competing microorganisms would degrade product quality, reduce productivity or outcompete the target strain entirely. The plan considers contamination tolerance (exploiting selective growth conditions of autotrophic hydrogen oxidation) but acknowledges it is unproven. Seed-train procedures, cryo-stock storage and revival, purity verification and the impact of variable local input purity on contamination risk are all unvalidated at the proposed scale.

Likelihood: Medium | Severity: Medium

## Risk 9 Action

Develop and validate strain-continuity procedures during Phase One and Two: establish seed-train protocols (size, frequency, storage conditions for intermediate stocks), cryo-stock preservation methods (cryoprotectant, freezing rate, long-term storage temperature and monitoring), and revival procedures with documented success rates. Deposit cryo-stocks at a minimum of three independent locations: Denmark (primary), Kenya (deployment), and a third neutral location so that loss of one repository does not halt replication. Before shipping cryo-stocks to Kenya, validate the cold-chain logistics (transport time, temperature monitoring, contingency for failures) with a dry run using a non-hazardous surrogate strain. Implement routine purity verification using culture plating, microscopy or molecular methods (e.g., 16S rRNA PCR) at defined intervals (e.g., weekly during normal operation, after every restart). Document the strain's stability over repeated growth cycles and power/medium-starvation cycles by running a long-term continuous or fed-batch experiment (100+ generations) in Phase Two and measuring key productivity parameters (growth rate, biomass yield, oxygen consumption rate) for drift. If contamination tolerance is relied upon, validate it experimentally: run the reactor with intentionally introduced contaminants under the intended selective-growth conditions and confirm that the target strain outcompetes them without productivity loss. Maintain a detailed strain lineage and mutation history; if drift is detected, sequence the genome at regular intervals to track changes. Train the Kenyan team intensively on purity verification and contamination response, and assign a qualified staff member to oversee biological quality assurance, with remote support from an EU-based microbiologist (recorded in the assistance log).

## Risk 10 – Regulatory Pathway for Product Distribution

The plan requires a 'credible regulatory pathway' in Denmark, EU and Kenya for product distribution, but full commercial authorization is not required for research success. The product category (animal feed, fish feed, food ingredient, emergency nutrition) is chosen at the Phase One gate based on provisional data and locked there; if the category is later deemed unsafe or unregulatable by authorities, the project cannot pivot without restarting regulatory work. Different product categories have different approval timelines and evidence requirements. If the Kenyan regulatory authority lacks established pathways for new protein products or takes a precautionary approach, a 'credible pathway' may not exist even if the product is safe.

Likelihood: Medium | Severity: Medium

## Risk 10 Action

Conduct a detailed regulatory-requirements analysis per product category and jurisdiction during Phase One (Month 0–3 = 2026-10-09 to 2027-01-09), distinguishing experimental operation (contained use, site permits), product safety validation and commercial distribution. For each intended product category (animal feed, fish feed, food ingredient, emergency nutrition), document the approval pathway, timeline, required studies and cost in Denmark/EU and Kenya. Obtain written pre-submission feedback from the relevant authority confirming a credible pathway before committing to a category. Fix the product category at the Phase One kill gate in a signed, time-stamped document, and do not change it without approval from all parties and a full regulatory re-assessment. By the Phase Two gate, produce Phase II compositional and digestibility data conforming to the selected category's regulatory dossier requirements, so Phase Three can proceed with minimal additional testing. If Kenya's regulatory pathway requires in-country trials or studies beyond the project scope, either fund them separately or explicitly scope them out of Phase Three and acknowledge the implication for the deployment case. For nucleic acid content and other composition specifications, work with regulators during Phase One to establish acceptable ranges, and design the downstream-processing train to achieve those ranges with documented margins.

## Risk 11 – Downstream Processing & Product Quality

The project must turn raw hydrogen-oxidizing bacteria biomass into a usable, digestible, food-safe protein product through harvesting, cell disruption, nucleic acid reduction and drying. Downstream processing is often underestimated in techno-economic models: energy consumption, equipment complexity, maintenance burden and waste handling can erase fermenter-level gains in cost and energy efficiency. The plan requires a consistent processing boundary for all benchmark comparisons, but the actual processing train (minimal, moderate or comprehensive) is undecided. A comprehensive train increases product-category options and regulatory acceptance but adds equipment, labour and specialist maintenance. A minimal train reduces burden but may restrict product use to less-demanding categories.

Likelihood: Medium | Severity: Medium

## Risk 11 Action

Define the downstream-processing scope and fixed processing boundary early in Phase One, specifying: harvesting method (centrifugation, filtration, settling), cell disruption (if any), nucleic acid reduction step (thermal, enzymatic or physical), drying method (spray, freeze, drum) and final product form (powder, paste, pellet). Use a consistent processing boundary for all benchmark calculations against published alternatives. Conduct a detailed cost and energy analysis of each processing step, with uncertainty ranges and identified bottlenecks. Allocate Phase II experiments specifically to validate the downstream train at pilot scale: test nucleic acid removal efficiency, product yield, energy consumption and equipment operability by trained technicians. If nucleic acid content cannot be consistently achieved below the regulatory limit using the proposed method, re-design the train or select a product category with a higher permissible limit. Document the sensitivity of the total system cost and energy to each downstream parameter; if any parameter has a >20% cost impact, allocate extra Phase II validation to reduce its uncertainty. For the Kenyan replication, match the downstream train to the available local skills and equipment; if the preferred train requires specialist expertise not available locally, design a simplified alternative and measure the product-quality and cost penalty. Validate that the simplified downstream train can be operated by trained technicians with documented procedures and contingency plans for failures.

## Risk 12 – Hypothesis Testing & Threshold Setting

The project tests two hypotheses: (A) the process can be operated by locally trained technicians while keeping acceptable safety and productivity; (B) it can be decentralized into affordable, independently maintained modules under unreliable infrastructure. If either hypothesis fails, the conclusion should be Modify or Research Only, not Go. However, hypothesis testing depends on pre-locked deployment thresholds (maximum cost, minimum capacity, required reliability) set before any prototype evaluation. If thresholds are set from weak data or without real adopter input, the project may pass or fail against a scenario no one would actually use. If thresholds are tightened retrospectively to fit achieved performance, the Go decision is rationalized rather than evidence-based. The plan requires a kill gate at the end of Phase Two, with written continue/modify/research-only/stop decisions; if that gate lacks teeth, the expensive Phase III build and Kenyan replication consume EUR 20–30 million without clear justification.

Likelihood: Medium | Severity: High

## Risk 12 Action

Before Phase One begins, establish a hypothesis-testing framework and a gate-review governance model: (1) Define hypothesis (A) and hypothesis (B) formally with measurable criteria for pass/fail; (2) Identify 2–3 named prospective adopters (e.g., national food reserve, regional feed producer, humanitarian logistics organization) and engage them in setting deployment thresholds: maximum acceptable cost per kilogram of usable protein, minimum useful production capacity, required uptime and outage-survival duration; (3) Lock these thresholds in a signed, time-stamped document before Phase One ends, with a clause stating thresholds are immutable unless all parties formally agree to change them; (4) Recruit an independent gate-review panel with written charters: no employment or funding dependence on the host institution, authority to recommend stop/modify/continue without justification, and a separate budget line ensuring they can operate independently. At each gate (Phase One end, Phase Two end, Phase Three end), require the panel to produce a written decision document addressing: (a) Does the evidence support the hypotheses as stated? (b) Do the measured cost, capacity and reliability meet or exceed the locked thresholds? (c) If not, what specific evidence is missing or failed? (d) Is a continue, modify, research-only or stop decision justified? If the decision is modify or stop, require the project to produce a detailed analysis of why and a plan to address the shortfall. Publish all gate-review documents and decisions transparently to stakeholders and the funder.

## Risk 13 – Kenyan Site Selection & Infrastructure

The Kenyan replication site must be chosen to test the defined operating envelope: documented grid-outage patterns, water-quality constraints, ambient temperature and humidity, spare-part availability and available technical skills. The plan emphasizes 'choose a Kenyan site that actually tests this envelope, not a well-equipped laboratory.' If a site is chosen for convenience rather than harsh-envelope realism, it may pass tests that a real adopter would fail, invalidating hypothesis B evidence. Conversely, a harshly chosen site faces greater risk of logistics-driven failures that obscure whether the design or documentation was at fault. A site's infrastructure can also change mid-project: local power supply reliability may improve, fuel costs may spike, political instability may disrupt access, or competing priorities may reduce partner capacity.

Likelihood: Medium | Severity: Medium

## Risk 13 Action

During Phase One, commission an independent site-selection study in Kenya documenting: (1) grid-outage frequency, duration and pattern; (2) water-supply reliability, seasonal quality variation and treatment constraints; (3) ambient temperature and humidity ranges; (4) local availability of key spare parts and lead times for import; (5) available technical skills in the area (electricians, mechanics, laboratory technicians); (6) political stability, security and accessibility for international staff. Select a site that genuinely tests the envelope, not a showcase site. Document the envelope conditions in writing, and include them in the replication acceptance criteria: the site must remain within the defined envelope for the duration of Phase Three. Establish contingency plans for infrastructure changes: if grid power becomes more reliable mid-project, add controlled outage stressors to maintain the testing burden. Secure a site-use agreement in writing, specifying access rights, contingency for partner or staff changes, and a force-majeure clause. Assign a resident on-site project manager (hired locally, with international support) who can navigate local logistics and flag infrastructure or partner changes early. Monitor the site's operating envelope quarterly, and trigger contingency actions if envelope conditions shift by >20%.

## Risk 14 – Open Licence & Intellectual Property

The project aims to publish the complete source package (hardware, software, data, documentation) under open licences so that independent organizations can build and operate the system. However, open-licence governance is complex: licence choice (reciprocal vs. permissive) affects whether improvements must be shared back and whether commercial forks are possible; third-party IP (patents, strain restrictions, material transfer agreements) can limit what the project can publish; and stewardship (who holds the licences and enforces terms long-term) is needed to prevent forking or closure by a single company.

Likelihood: Low | Severity: Medium

## Risk 14 Action

Commission a comprehensive freedom-to-operate and patent landscape review during Phase One, covering: (1) published patents on hydrogen fermentation, autotrophic protein production, the reference strain and relevant processes in Denmark, EU, Kenya and Bangladesh; (2) third-party IP restrictions embedded in strain material transfer agreements, software licences or published data; (3) regulatory and trademark protection. For each identified IP risk, document: the claim or restriction, the jurisdictions affected, the likelihood and cost of infringement, and mitigation options (design around, license, patent pledge, or publication barrier). Choose a licence stack (e.g., CERN Open Hardware Licence for hardware, GPL or Apache for software, CC-BY for data) that balances openness (requirement for derivative improvements to be shared back) with adoption ease. For safety-critical designs, consider using reciprocal licences to ensure changes remain traceable. Publish a one-page legal summary per jurisdiction detailing: (1) what is licensed under what terms; (2) identified IP restrictions and their implications; (3) what adopters can and cannot do commercially without additional licensing. Establish an independent steward organization (e.g., a non-profit foundation) with sustainable funding to hold and enforce the licences, manage the source repository, and address patent disputes or forking attempts. Include in Phase Three budget at least EUR 100,000–200,000 for steward-entity setup and initial operations.

## Risk 15 – Measurement & Benchmarking

The project requires consistent definitions of productivity, energy use and cost across all benchmark calculations, compared against published data using 'compatible definitions of volumetric productivity, system-level energy use, capacity utilization and processing boundaries.' The plan emphasizes the KPI framework but does not specify how published benchmarks will be sourced or how ambiguities in published definitions will be resolved. If different reactor concepts, published sources or product categories use different definitions, benchmark comparisons become meaningless.

Likelihood: Low | Severity: Medium

## Risk 15 Action

Establish a measurement and KPI framework during Phase One before any bench-scale experiments begin. For each KPI (volumetric productivity, energy per kilogram dry biomass, energy per kilogram usable protein, installed cost per unit capacity, uptime, outage survived and restart time), document: (1) definition (formula and units); (2) system boundary (which components and processes are included); (3) capacity-utilization assumption; (4) operating mode (continuous, fed-batch, intermittent); (5) how it will be measured (instruments, sampling frequency, data processing). For each KPI, identify at least two published benchmarks (from different sources or studies) and document their definitions, boundaries and assumptions. For any KPI where definitions differ significantly, either harmonize the project's definition to match published work or clearly state the difference and justify the choice. Lock this measurement framework in a written document (e.g., a KPI Protocol) and require all bench-scale, pilot-scale and full-scale experiments to report data against these definitions. Before the Phase Two gate, conduct a sensitivity analysis on the locked deployment thresholds: if the thresholds are sensitive to the definition of a KPI, publish the sensitivity and discuss the implication for adopters. Use the same KPI definitions consistently for all scale-up comparisons and published benchmarks.

## Risk 16 – Training & Operator Competence

Hypothesis A claims the process can be operated by locally trained technicians after a 'short, competency-verified training programme.' Operator training content, duration, competency assessment methods and pass criteria are not yet defined. If training is too brief, technicians may lack confidence or competence to handle safety-critical tasks or troubleshoot failures. If training is too long, it may not be sustainable in practice for deploying sites. If competency assessment is subjective or inconsistently applied, replication teams may appear competent but fail during real operation.

Likelihood: Medium | Severity: Low

## Risk 16 Action

Develop a detailed training and competency-verification programme during Phase One and Two, covering: (1) target trainee profile (education level, prior experience, native language); (2) training content (theory, hands-on, emergency procedures, safety); (3) training duration (total hours and schedule); (4) teaching methods (classroom, mentorship, simulator); (5) competency assessment (written exam, practical test, signed competency declaration); (6) pass criteria (minimum score, demonstration of key tasks); (7) trainer qualifications and train-the-trainer protocol. Pilot the training programme with a small cohort in Denmark (during Phase II or early Phase III), and assess whether trainees can operate the system safely and effectively with minimal support after the course. If trainees struggle, redesign the course content or duration. Document the complete training materials (manuals, videos, slides, practical exercises) so that they can be transferred to the Kenyan team. Conduct a formal competency assessment of the Kenyan team before commissioning the replication unit, with independent observers verifying that technicians can perform critical safety tasks without developer help. Define a threshold for acceptable performance (e.g., 90% pass rate on practical safety tasks), and do not proceed with full-scale operation unless the threshold is met. Reassess competency after the first 3 months of operation and after any incident, and revise training if systematic gaps are identified.

## Risk 17 – Political & Regulatory Stability

The project spans Denmark (EU) and Kenya over 5 years, a timeframe during which regulatory requirements, political priorities or international trade rules could change. Changes in Danish, EU or Kenyan food, feed or product-safety regulations could require design re-validation or new approvals. Trade restrictions, tariffs or sanctions could affect equipment procurement or the viability of import/export of inputs or products. A change in EU state-aid rules or green-subsidy policies could alter the competitive landscape for alternative protein technologies, affecting deployment assumptions.

Likelihood: Low | Severity: Medium

## Risk 17 Action

Monitor regulatory and political changes in Denmark, EU and Kenya quarterly throughout the project. Subscribe to regulatory updates from the Danish EPA, EFSA (European Food Safety Authority) and Kenya's National Biosafety Authority and Ministry of Health. If a material change in food, feed or product-safety regulations is announced, conduct a rapid impact assessment: (1) Will the change affect the product category or specification? (2) Will new approvals or re-validations be required? (3) What is the cost and timeline impact? (4) Do thresholds need to be revised? Document findings and alert the steering committee. For Kenya, monitor political stability, government budget allocations to agriculture and food security, and trade policy; if instability is detected, activate contingency plans (e.g., strengthen partner relationships, identify backup sites, accelerate critical milestones). Monitor competitor technologies and government subsidies for alternative proteins; if a competitor technology is heavily subsidized or becomes cheaper faster than expected, re-evaluate whether the deployment scenario remains credible. If a major regulatory change is likely to affect the project, engage regulators early (pre-submission consultations) to understand the implications and plan design adjustments proactively.

## Risk 18 – Talent & Staff Retention

The project requires sustained teams in Denmark and Kenya over 5 years, including senior scientists, process engineers, safety specialists, regulatory experts and local technicians. Turnover of key staff, particularly in specialized roles, could delay milestones or introduce inconsistency. A 50% turnover of the Danish engineering team during Phase One or Two could lose institutional knowledge about design decisions, trade-offs and rationale, slowing Phase Two and Three. A turnover of the Kenyan partner's project manager or lead technician during Phase Three could disrupt operations and delay replication evidence.

Likelihood: Medium | Severity: Low

## Risk 18 Action

Establish competitive salaries and benefits for key roles, commensurate with the skills required and local markets in Denmark and Kenya. For critical roles (senior engineer, safety specialist, Kenyan site manager), recruit early and invest in onboarding and mentoring to increase retention. Document all design decisions, trade-offs, rationale and assumptions in a living 'design rationale' document that new team members can reference, reducing dependence on oral history. Implement a structured knowledge-transfer protocol when departures are expected: require 4–6 weeks of overlap between outgoing and incoming staff, with documented handover meetings and signed-off competency assessments. Build redundancy into critical roles where possible: ensure at least two people are trained in safety analysis, regulatory engagement, and Kenyan site operations so that a departure does not isolate critical knowledge. Monitor turnover rates quarterly and flag any position with >50% turnover or >6 months vacancy as a risk requiring escalation to management. Offer career-development opportunities (publications, international conferences, advanced training) to boost motivation and retention.

## Summary

The Open Protein Module is a high-complexity, high-novelty infrastructure-scale R&D programme with a EUR 50 million provisional ceiling (EUR 6 million Phase One) spanning Denmark and Kenya over approximately 5 years. It combines novel technical challenges (hydrogen-oxygen explosion hazard, gas-liquid mass transfer at scale, hydrogen-oxidizing bacteria fermentation), multiple organizational dependencies (unsigned university consortia, Kenyan co-developer, independent gate reviewers, prospective adopters), unproven strain rights and regulatory pathways, and a demanding replication independence requirement.

The most critical risks are: (1) Hydrogen-oxygen explosion hazard and safety design failure, which could cause serious injury, invalidate ATEX compliance, or force design rework late; (2) Strain rights or biosafety barriers blocking lawful replication in Kenya or delaying product authorization; (3) Documentation gaps discovered during Kenyan replication causing cost overrun, schedule delay, or failed independence evidence; (4) Hypothesis-testing framework and gate-review governance lacking teeth, allowing continuation by momentum despite weak evidence.

Secondary risks include techno-economic model failure, scale-up assumptions collapsing under real-world conditions, regulatory rejection of product category, partner withdrawal or delayed access to facilities, supply-chain disruptions, contamination of cultures, and operator training insufficient for safe operation. The project depends critically on five foundational decisions (Gas-Liquid Contacting and Reactor Concept, Strain Portfolio and Rights Strategy, Replication Design and Gate Governance, Deployment Scenario Anchoring and Threshold Locking, and Inherent Safety Design Basis and Adopter Change Boundary) and several unsigned enablers (university hosts, Kenyan partner, prospective adopters, independent gate reviewers, strain rights holders). Early discovery of blocking issues in regulatory, rights, or partner domains could invalidate months of technical investment.

# Make Assumptions
# Phase One Budget Allocation & Gate Criteria

## Budget Breakdown (EUR 6 million Phase One)

- Landscape review and strain rights analysis: EUR 400,000–600,000 (4–5 FTE, 6–9 months)
- Initial laboratory experiments (2–3 candidate strains, bench-scale reactors): EUR 800,000–1,200,000 (equipment, consumables, staff)
- Techno-economic model and material–energy balance: EUR 200,000–300,000
- Regulatory pre-submission engagement: EUR 150,000–250,000
- Facility setup (laboratory bioreactors, electrolysis, analytical equipment): EUR 2,000,000–2,500,000
- Contingency, administration, management overhead: EUR 1,500,000–2,000,000 (10–15%)

## Essential Phase One Gate Activities

Phase One gate decision requires:

- Landscape review completion
- Strain rights analysis (documented legal review confirming no third-party IP or biosafety barriers for primary and backup strains lawful for import, research use and commercial production in Kenya)
- Preliminary strain-productivity data from bench-scale experiments (pass: ≥90% of published data for C. necator hydrogen fermentation; fail: <70% of benchmark; ±30% uncertainty acceptable)
- Regulatory feasibility assessment from Kenya's National Biosafety Authority (pathway identified with approval timeline vs. regulatory blockage)
- Reference architecture decision (adopt published design, benchmark multiple designs, or clean-sheet approach) with documented rationale

Full matched reactor comparison may extend into Phase Two.

## Contingent Activities & Risk Mitigation

- Front-load landscape review (Month 0–2 = 2026-10-09 to 2026-12-09) and strain rights analysis (Month 0–4 = 2026-10-09 to 2027-02-09) before detailed reactor experiments, allowing Phase One gate to be informed by documented regulatory and IP feasibility.
- Pre-allocate EUR 300,000 of contingency to regulatory and rights work to reduce schedule risk.
- Track Phase One spending monthly against allocation to identify overruns early; if regulatory feedback requires expanded testing or rights negotiation, contingency will be consumed first.
- If strain rights or regulatory barriers emerge late (Month 8–9 = 2027-06-09 to 2027-07-09), insufficient time remains to pursue backup strains; front-loading mitigates this risk.

---

# Phase One Gate: Kill Criteria & Governance

## Kill Gate Decision Framework

The Phase One gate requires all four criteria to be satisfied:

- Documented strain rights for primary and backup strains (pass/fail: legal review confirming no barriers; fail = regulatory or IP blockage identified)
- Preliminary volumetric productivity within benchmark (pass: >90% of published C. necator data; fail: <70%; ±30% uncertainty)
- Written regulatory feasibility from Kenya's National Biosafety Authority (pass: pathway identified; fail: blockage identified)
- Reference architecture decision (pass: decision made with evidence; fail: decision deferred without justification)

If any criterion is not satisfied or credibly on track by Month 10 (2027-08-09), gate reviewers must recommend Modify or Research Only.

## Independent Gate-Review Panel

- Composition: 3–5 external experts with no employment ties to host institution (process engineer, ATEX safety specialist, biotech regulatory consultant, optionally product expert and adoption economist)
- Recruitment: Month 0 (2026-10-09)
- Funding: Separate budget line (EUR 50,000–100,000 total), managed by funder not host institution
- Authority: Recommendation is binding in the sense that deviation requires public written justification from funder/host, published alongside panel's recommendation
- Review cycle: Convene at each gate (Phase One end ~Month 9 = 2027-07-09, Phase Two end ~Month 21 = 2028-07-09, Phase Three end ~Month 54–57 = 2031-04-09 to 2031-07-09); produce written joint recommendation (continue, modify, research-only, or stop) with detailed rationale against pre-defined gate criteria
- Panel members retain no ongoing relationship with host or funder after project ends

## Decision Authority & Transparency

- Host institution and funder retain decision authority but must publish reviewer's recommendation and any deviation from it.
- If panel recommends 'Stop' or 'Modify' but funder continues unchanged, panel recommendation and funder's written justification must be published verbatim to all stakeholders.
- Provisional Phase One decision date: Month 9 (2027-07-09); extension window to Month 10 (2027-08-09) only if single criterion is incomplete but on clear path.

---

# Danish Development Site: Staffing & Facilities

## Host Institutional Arrangement

- Host: Consortium of 2–3 Danish universities (Copenhagen, Aarhus, DTU, AU or GEUS) or public research institute
- Each provides: dedicated laboratory bioreactor facilities (20–50 L capacity), electrolysis capability, ATEX-compliant fume hood or small pressurized test cell, analytical support (gas chromatography, HPLC, composition analysis)
- Facility access secured by signed Memorandum of Understanding specifying space, equipment availability, maintenance responsibility

## Staffing

- Permanent or long-term (3–5 year) roles: 4–6 FTE (senior process engineer, microbiologist, safety engineer, regulatory expert, technician, project manager)
- Temporary roles: 2–3 FTE (phase-specific work, visiting researchers)
- Phase Three expansion needed: 8–10 FTE for reference-unit construction, commissioning, 6-month continuous operation
- Critical roles (senior engineer, safety specialist) hired directly to project (not as host-institution employees) to ensure continuity and accountability

## Governance & Risk Mitigation

- Secure detailed MoU with host by Month 1 (2026-11-09), naming principal investigator, protecting laboratory space and staff time in writing, establishing quarterly resource-conflict resolution process
- Risk: if host institution's priorities shift, laboratory or staff time could be redirected with little notice; MoU written protection mitigates this
- Establish second-institution partnership (private research organization or engineering firm) for ATEX design review and independent safety certification (university consortia may lack in-house ATEX expertise)
- Budget EUR 100,000–200,000 annually (Year 1–3) for facility maintenance, equipment repair, shared analytical services

---

# Process Safety: Hazards & Design Assumptions

## Hazard Scope (HAZOP/LOPA)

Preliminary hazard identification covers:

- Hydrogen production via electrolysis (electrolyzer as source)
- Oxygen as co-product (electrolyzer outlet)
- Hydrogen-oxygen mixing in gas-handling lines and fermentor headspace
- Ignition sources: electrolyzer malfunction (loss of gas separation), fermentor overpressure or rupture, seal failure in pressurized reactors, backflow during power loss, operator error

## Preliminary Safety Strategy & Design Limits

- Keep fermentor gas composition outside flammable range: <4% O₂ in H₂-rich stream, or >60% inert; or <2% H₂ in O₂-rich stream
- Limit maximum gas inventory: <0.5 m³ H₂ and <0.2 m³ O₂ in system at any time
- Interlocks preventing pressurized operation above 2–3 bar without independent overpressure relief
- Design for safe shutdown on power loss: vent fermentor gas, stop electrolysis, purge lines

## Analysis Approach & Scope

- Formal HAZOP/LOPA during Phase One (Month 1–3 = 2026-11-09 to 2027-01-09) essential before committing to reactor design details
- Conducted in collaboration with third-party ATEX consultant (independent scrutiny, not internal)
- Generates ranked lists of failure modes by severity and likelihood
- Defines quantitative safety target: e.g., probability of uncontrolled ignition <1 per 100,000 operating hours
- Specifies design response for each failure mode: eliminate hazard, reduce likelihood through design, or protect via layered control
- 'Safety case' document updated as design evolves; requires independent review before proceeding to pressurized or high-gas-inventory configurations

## Risk: Preliminary Assumptions vs. Productivity Requirements

- Preliminary assumptions (e.g., <4% O₂) are plausible but may conflict with gas-transfer or productivity requirements
- If later design needs richer, more reactive gas mixtures, safety case must be reworked; this could delay Phase Two
- For matched reactor concepts, each evaluated against same hazard checklist (safety not hidden advantage of one concept)
- Define and publish 'adopter change boundary': which design changes (e.g., pressure, electrode material) require full safety re-analysis, so replicators know what they can safely modify

---

# Reactor Concept Comparison: Measurement Framework

## Matched Reactor Comparison Design

Three bench-scale reactors (500 mL–1 L) operated side-by-side using:

- Identical strain (C. necator H16 or backup)
- Identical medium, inoculum density, operating conditions (30°C, pH 7.0–7.2, aeration 0.1–0.5 vvm, ≥7 days to steady state)

## Measured Metrics

- Volumetric productivity (g biomass per liter per day, ±15% uncertainty)
- Volumetric oxygen uptake rate and hydrogen consumption rate (mmol/L/h, from offline gas composition and liquid sampling)
- Calculated mass-transfer coefficient (kLa in h⁻¹, derived from gas balance)
- Energy per kg dry biomass (kWh/kg, including electrolyzer and fermentor power)
- Culture stability over 7–14 days (no contamination, no strain mutation detected by 16S rRNA)

## Success Criteria & Decision Logic

- If productivity differs by <20% between concepts, design simplicity (fewer moving parts, lower ATEX burden) is tiebreaker
- If >20% difference, more productive concept selected unless simpler concept still meets deployment-scenario cost threshold

## Pre-Registration & Governance

- Analysis protocol and decision thresholds locked in writing before any experiments start
- Assign one lead analyst to prepare and analyze all samples identically (single HPLC method, single gas chromatograph, consistent sampling)
- Each reactor concept run in triplicate; report mean ± standard deviation
- If uncertainties >20%, extend run to 2–4 weeks with mid-run measurements to confirm steady-state
- Document all protocol deviations (HPLC malfunction, contamination) and exclude units only with independent justification
- Comparison results (including failure thresholds, measured values, decision logic) published before Phase Two for external audit
- Prevent post-hoc rationalization and analytical-variation confusion (20–30% scatter could obscure true concept differences)

---

# Kenyan Replication Site: Operating Envelope

## Envelope Definition (Phase One, Month 1–3 = 2026-11-09 to 2027-01-09)

Defined during Phase One site-selection study; based on:

- Grid power availability: documented monthly outage duration and frequency for past 2 years (target: ≥1 unplanned outage per week)
- Water supply: seasonal quality variation (turbidity, conductivity, iron/manganese, pH) measured monthly over one year
- Ambient conditions: temperature 15–30°C (not hard requirement), relative humidity 40–80%
- Spare-part availability: confirmed local suppliers (≤2-week lead time) for electrical, mechanical, laboratory consumables
- Available technical skills: confirmed presence of 2–3 local electricians, mechanics, laboratory technicians (high-school/vocational training) willing to undergo project training

## Verification & Selection

- Site-selection consultant (independent of Kenyan partner) verifies envelope through utility records, water quality testing, interviews with suppliers and technicians
- Baseline report time-stamped and signed at Month 4 (2027-02-09), listing all envelope parameters and measured values

## Monitoring During Phase Three

- Monthly monitoring protocol: collect power outage logs, sample water monthly, query suppliers for spare-part availability, interview technicians on training progress
- If any parameter drifts by >20% from baseline (e.g., power outages become less frequent), project reports drift and adjusts planned stressors or documents implication for deployment case
- If power becomes more reliable mid-project, add controlled outage stressors (planned load shedding with agreed advance notice) to maintain testing burden

## Risk Mitigation

- Risk: if site chosen for partner convenience rather than envelope realism (e.g., Nairobi university with reliable power), hypothesis B evidence (decentralized operation under difficult infrastructure) invalidated; if site is chosen for harshness but conditions improve, site no longer tests envelope
- Conduct site selection independently (not via Kenyan partner), using verified data rather than partner assertions
- If any parameter drifts >20%, trigger contingency action to maintain hypothesis B test validity
- Document envelope changes transparently so external reviewers can assess evidence credibility

---

# Deployment Scenarios: Definition & Locking

## Adopter Identification & Engagement

- By Month 4–6 (2027-02-09 to 2027-04-09): Identify 2–3 named prospective adopters representing realistic deployment contexts
- Example scenarios (not committed thresholds):

  - (A) National/regional food-security reserve agency: EUR 10–15/kg usable protein (proposal), ≥100 kg/day capacity, ≥95% uptime
  - (B) Commercial East African animal-feed producer: EUR 8–12/kg usable protein (proposal), ≥500 kg/day capacity, ≥90% uptime
  - (C) Humanitarian logistics organization: EUR 12–18/kg (proposal), ≥50 kg/day capacity, operate from 40-foot container with solar power and borehole water

- Conduct structured interviews with adopters on: current supply chains and costs, production-capacity needs, acceptable cost premium for vendor-independent solution, operational constraints (power, water, space, skills)
- Validate adopter input by presenting scenario profiles and cost-benefit thresholds back to them

## Scenario Locking (Month 9 = 2027-07-09)

- Consolidate adopter input into 2–3 scenario profiles and cost-benefit thresholds
- Lock in signed document by Month 9 (2027-07-09) with all parties: project, adopters, funder, gate reviewers
- Clause: scenarios cannot be changed unilaterally; adopter withdrawal requires public notification and decision on whether remaining scenarios remain credible

## Risk Mitigation

- Risk: if scenarios are hypothetical (no real adopter input), may not reflect actual market; if adopters withdraw after locking, process may restart; if thresholds too tight (EUR 5/kg when cost is EUR 8–12/kg), decision predetermined to fail; if too loose, pass irrelevant to adoption
- Identify adopters during Phase One (Month 1–4 = 2026-11-09 to 2027-02-09) with publicly stated mandates; contact early to gauge interest
- If adopter withdraws, publish reason and assess whether remaining scenarios remain credible; transparency protects final Go decision credibility
- Locked scenarios give Phase Three Go decision meaning by establishing pre-set pass/fail criteria independent of achieved performance


# Distill Assumptions
I'm ready to receive the Markdown document you'd like me to shorten. Please paste the project planning document, and I'll condense it while preserving all topics, structure, headings, and key details according to your requirements.

# Review Assumptions
# Gate-Review Panel Independence & Authority Underspecified

## Governance Structure Incomplete

Independent gate-review panels are mandated at Phase One, Two and Three gates, but the governance structure lacks detail. No written charter specifies reviewer selection, grounds for removal, or procedures if the funder or host institution overrides a 'Stop' recommendation. If panel members' honoraria depend on continued project approval, implicit pressure to approve continuation arises. If recommendations are only advisory, weak gate results can be dismissed without accountability.

## Recommendation

Establish a detailed Gate-Review Charter before Phase One begins:

- Panel recruitment: open, competitive process; no prior collaborators or financial ties
- Funding mechanism: separate budget line managed by funder, not host; EUR 50,000–100,000 total across 5 years, ensuring honoraria do not depend on project approval
- Written charter for each panel member stating sole obligation is evidence assessment against pre-defined criteria, with explicit protection against removal except for cause
- Authority definition: recommendations are binding in the sense that any deviation requires publicly justified written response published alongside the recommendation
- Escalation mechanism: if a reviewer's recommendation conflicts with funder/host decision, a second-stage review determines whether the deviation meets justification standard
- Publish all gate recommendations and funder responses transparently in annual reports
- Document decision threshold for each gate in advance; do not allow post-hoc threshold redefinition

## Sensitivity

If gate-review independence is weak, the EUR 50M ceiling has no binding protection. A momentum-driven continuation despite failed Phase-Two evidence could consume EUR 15–25M (Phase Three cost) without justified evidence. If the gate-review panel recommends Stop at Phase Two but the funder overrides this decision, the project's scientific credibility is compromised, reducing adoption rates by 30–50% and project impact by similar margin. Baseline assumption: gate reviews conducted as planned with independent panels (~60% probability given lack of current governance detail); risk: only 20–30% probability that true independence is maintained if governance is not explicitly specified and monitored.

# Strain Rights & Biosafety Regulatory Pathway Locked Too Late

## Critical Delay Risk

The plan assumes documented strain rights analysis and Kenya biosafety pathway confirmation will be completed by Phase One gate (~Month 9 = 2027-07-09). However, strain rights analysis typically requires 3–6 months, and Kenya's National Biosafety Authority may take 4–8 weeks for pre-submission feedback. If these activities are deferred until Month 5–6 (2027-03-09 to 2027-04-09), a blocking barrier discovered in Month 8 (2027-06-09) leaves only 1 month to identify a backup strain—unrealistic. If discovered after Phase One gate, Phase Two experiments may have committed to the primary strain; switching requires repeating all productivity benchmarking and regulatory work, delaying Phase Two by 6–12 months and consuming EUR 200,000–400,000.

## Recommendation

Front-load strain rights and regulatory engagement to Month 0–4 (2026-10-09 to 2027-02-09) (immediately after project start), in parallel with landscape review:

- Establish dedicated work package with 2 FTE (legal/regulatory specialist and microbiologist/operations liaison)
- By Month 1 (2026-11-09): identify 4–5 candidate reference strains and contact holders to confirm lawful obtainability for research, commercial production, redistribution and modification in Denmark and Kenya
- By Month 2 (2026-12-09): initiate parallel patent and IP search covering hydrogen fermentation, autotrophic protein, single-cell protein and specific strains across Denmark, EU, Kenya and Bangladesh via specialist patent firm (EUR 40,000–60,000 estimate)
- By Month 2.5 (2026-12-24): contact Kenya's National Biosafety Authority informally with summary of proposed process, strain candidates and contained-use requirements; request written feedback on feasibility and red-flag restrictions
- By Month 4 (2027-02-09): consolidate findings into written 'Strain Feasibility Report' naming primary and backup strain with documented rights and confirmed regulatory pathway
- If primary strain has IP or regulatory barriers, complete backup strain analysis before proceeding
- Update Phase One gate criteria to require completion of this report by Month 4 (2027-02-09) as precondition to Phase One continuation; if not complete or barriers unresolved, extend Phase One to Month 5–6 (2027-03-09 to 2027-04-09) with escalation to gate-review panel if barriers cannot be closed

## Sensitivity

Baseline assumption: strain rights and regulatory pathway can be confirmed by Month 4 (2027-02-09) (~70% probability based on university-to-university strain transfer norms and Kenya's typical pre-submission turnaround). Risk if barriers emerge at Month 8–10 (2027-06-09 to 2027-08-09): Phase Two delay of 6–12 months and additional cost of EUR 200,000–400,000. Cost impact on total EUR 50M budget: 0.4–0.8% if barrier identified and resolved by Month 10 (2027-08-09); risk of 2–3% cost overrun if barrier extends Phase Two. If strain barrier not identified until Phase Three (Month 36+), project must halt pending strain substitution and complete re-validation of all Phase Two and Three experiments, potentially consuming EUR 2–4M and delaying completion by 12–24 months.

# Kenyan Site Operating Envelope Not Independently Verified

## Risk of Weak Hypothesis B Evidence

The plan requires the Kenyan replication site to test a defined operating envelope (grid-outage pattern ≥1 unplanned outage per week, water-quality variability, temperature, spare-part availability, local skills). However, the assumption that the site's envelope will be independently verified and monitored is underdeveloped. If site selection is delegated to the Kenyan partner prioritizing convenience, a site may lack true harsh-envelope conditions, invalidating hypothesis B evidence. If harsh-envelope conditions are asserted without documentary evidence and improve mid-Phase-Three (e.g., grid power becomes more reliable), testing conditions no longer match specifications, compromising hypothesis B evidence.

## Recommendation

Conduct independent site-selection study during Phase One (Month 1–3 = 2026-11-09 to 2027-01-09), separate from Kenyan partner input:

- Assign site-selection consultant (not employed by partner) to conduct:

  - Utility-records audit: obtain 24–36 months historical power-outage logs from local electricity utility, documenting date, duration, cause and frequency; establish baseline target (minimum 4 unplanned outages per month, minimum 2-hour average duration estimate)
  - Water-quality baseline: sample water monthly for 3–4 months from proposed site's water source, measuring turbidity, conductivity, pH, iron, manganese; compare against process requirements
  - Infrastructure audit: identify all critical spare-part suppliers within country and lead times; confirm at least 2 alternative suppliers for each critical item
  - Skills inventory: interview 5–10 potential local technicians to confirm availability, experience and willingness to participate in training

- By Month 4 (2027-02-09): document baseline operating envelope in signed, time-stamped 'Kenyan Site Baseline Report', specifying minimum power-outage frequency and duration, water-quality ranges, ambient conditions, spare-part availability and lead times, confirmed technician cohort; this becomes reference against which Phase Three actual conditions are measured
- Establish quarterly monitoring protocol during Phase Three: collect power logs monthly from utility, sample water quarterly, query suppliers on spare-part availability, interview technicians on operational issues
- If any envelope parameter drifts by >20% from baseline, document the drift and trigger contingency response: e.g., add controlled outage stressors (planned, brief load shedding with utility coordination) to maintain testing burden, or explicitly note in final report that site envelope changed and adjust hypothesis B conclusions

## Sensitivity

Baseline assumption: independent site verification confirms envelope alignment before Phase Three starts (~Month 24 = 2028-10-09) (~70% probability); risk if verification is weak: site selection is convenience-based rather than envelope-validated, reducing hypothesis B credibility by 40–50% in adopter eyes. If site envelope degrades mid-Phase-Three (Month 36–50 = 2029-10-09 to 2030-12-09), hypothesis B evidence weakened by 20–30%, potentially reducing adoption rates by 15–30%. Cost impact: if contingency stressors must be added, extra operational cost of EUR 30,000–70,000 (estimate); if site deemed unsuitable late, full re-replication at alternative site would cost EUR 500,000–1,500,000 (estimate) and delay completion by 12–24 months.

# Locked Deployment Scenarios May Not Engage Real Prospective Adopters

## Thresholds May Be Hypothetical

The plan assumes deployment scenarios will be locked by Month 9 (2027-07-09) with input from 2–3 named prospective adopters. However, organizational partners are often reluctant to commit long-term before seeing prototype results. If adopter engagement is delayed until Month 6–8 (2027-04-09 to 2027-06-09), limited time exists to conduct structured interviews, consolidate scenarios and obtain adopter sign-off before Phase One gate. If adopters are not genuinely committed, thresholds become project-derived assumptions rather than real-world requirements. If an adopter withdraws after scenarios are locked, remaining scenarios may no longer represent credible deployment contexts.

## Recommendation

- Identify prospective adopters early (Month 1–2 = 2026-11-09 to 2026-12-09) during landscape review, targeting organizations with publicly stated mandates in food security, livestock, humanitarian logistics or agricultural development; prioritize organizations with decision-making authority and budget
- Conduct structured engagement with 2–3 adopters (Month 2–6 = 2026-12-09 to 2027-04-09): hold in-person meetings covering current supply chains, costs, operational constraints (capacity, power, water, skills), acceptable cost premium and production timeline; provide draft scenario profiles and ask adopters to validate and adjust thresholds
- By Month 6 (2027-04-09): consolidate adopter input into 'Deployment Scenario Specification' document naming each adopter, their thresholds (cost per kg, capacity, uptime) and rationale
- Obtain signed commitment from each adopter by Month 7 (2027-05-09), with clause stating scenarios remain locked through Phase Three gate unless adopter provides written notice of withdrawal (with public disclosure of reason)
- Present locked scenarios to independent gate-review panel at Phase One gate meeting (Month 9 = 2027-07-09) and request assessment: 'Are these scenarios credible and realistic? Do adopters' thresholds represent genuine deployment demand?'
- If adopter withdraws before Phase Three gate, publish withdrawal reason and reassess whether remaining scenarios remain credible deployment targets; if only one scenario remains, or if withdrawal reason indicates broader market shift, re-convene gate panel to advise whether Go decision is still justified

## Sensitivity

Baseline assumption: 2–3 prospective adopters will engage and sign scenarios by Month 7 (2027-05-09) (~60% probability based on early-stage technology adoption norms; many organizations reluctant to commit until prototype results visible). Risk if adopters are hypothetical: deployment-scenario credibility reduced by ~50%, and adopter trust in Go decision reduced by similar margin. If adopter withdraws, credibility of remaining scenarios questioned by 20–30%, adoption rates may fall by 10–25%. Cost of engaging adopters: EUR 40,000–80,000 (estimate); if engagement fails and scenarios must be redesigned, additional cost EUR 50,000–100,000 (estimate) and 2–3 month delay. Impact on total EUR 50M budget: <0.2% if successful, 0.2–0.4% if redesign needed.

# Measurement Framework for Reactor Comparison Not Pre-Registered

## Risk of Post-Hoc Rationalization

The plan requires matched comparison of three reactor concepts (pneumatic, pressurized stirred, passive-feed) on identical strain and media, with measured productivity metrics and pre-registered failure thresholds. However, the measurement framework (exact definitions of volumetric productivity, energy per kg, mass-transfer coefficient, capacity-utilization assumptions, system boundary) is not yet locked. Analytical variation and operator differences could introduce 20–30% scatter. If analysis protocol is not pre-registered before experiments begin, post-hoc decisions about which data to include, how to handle outliers or how to define 'steady state' can bias results. If success thresholds are adjusted after data arrive, the comparison becomes rationalization rather than evidence-driven.

## Recommendation

Establish detailed 'Measurement and KPI Framework' document during Phase One (Month 0–2 = 2026-10-09 to 2026-12-09), before any bench-scale experiments begin:

- For each KPI (volumetric productivity in g/L/day, energy per kg dry biomass in kWh/kg, mass-transfer coefficient kLa in h⁻¹, oxygen-uptake rate in mmol/L/h), specify: definition and formula, system boundary, capacity-utilization assumption, operating mode and measurement method (instruments, sampling frequency, analytical methods)
- For each KPI, identify 2–3 published benchmarks from different sources and document their definitions and assumptions; if definitions differ, note difference and justify choice for this project
- Lock measurement protocol in writing, specifying: sample-preparation method, analytical technique (e.g., HPLC make/model, calibration standards), sampling time and frequency, data-processing method (how outliers handled, how steady state determined)
- Pre-register reactor-concept comparison decision criteria before Phase One experiments begin; e.g., 'If volumetric productivity differs by <15% between concepts, design simplicity is primary selection criterion. If productivity differs by 15–25%, weighted scoring matrix (60% productivity, 30% simplicity, 10% safety) determines selection. If productivity differs by >25%, highest-productivity concept is selected unless safety barriers prevent ATEX compliance.' Lock these thresholds and do not adjust after data arrive
- Assign single lead analyst responsible for all sample preparation and analysis across all three reactor concepts, using identical methods, to minimize inter-analyst variation
- Run each reactor concept in triplicate and report results as mean ± standard deviation
- Before publishing results or proceeding to Phase Two, have measurement framework and results reviewed by external technical auditor (not project member) who verifies protocol was followed and decision thresholds applied consistently
- Publish all raw data, analysis methods and decision logic in supplementary material

## Sensitivity

Baseline assumption: pre-registration of measurement framework prevents post-hoc bias (~75% probability if governance enforced). Risk if measurement framework not locked: researcher degrees of freedom in data analysis could introduce 10–20% bias toward preferred concept. Cost of full re-comparison if selected concept later fails: EUR 300,000–500,000 (estimate) and 4–6 month delay in Phase Two. Impact on total budget: up to 1% if full re-comparison required.

# Early-Stage Replication May Not Catch Critical Documentation Defects

## Risk Before Phase Three Full-Scale Build

The plan assumes early 'paper-and-bench' replication in Phase Two (Month 12–24 = 2027-10-09 to 2028-10-09), in which an independent group builds a small unit from draft documentation. Documented defects are logged and resolved before Phase Three full-scale build begins (~Month 24–36 = 2028-10-09 to 2029-10-09). However, a bench-scale replication (e.g., 1–10 L reactor) may not reveal defects that only emerge at larger scales: e.g., gas-handling manifold design that works at 1 L may not be practical at 100 L; manual pH-probe calibration may be impractical in full-scale continuous operation. If critical defects (missing safety interlock logic, unlabeled wiring diagram, unspecified spare-part source) are not caught until Phase III full-scale Kenyan build begins (Month 36 = 2029-10-09 onwards), the replication team faces choice: infer from context (risking unsafe builds), seek developer help (invalidating independence) or halt and demand fixes (consuming 2–4 months and EUR 200,000–500,000 estimate).

## Recommendation

Plan Phase II early replication with explicit defect-discovery objectives:

- Primary goal is to expose documentation gaps, not prove technology works at pilot scale
- Allocate EUR 100,000–150,000 (estimate) and 4–6 weeks specifically for documentation review and iteration
- Establish formal defect-tracking system before Phase II replication begins: create shared database or issue tracker in which every ambiguity found during build or operation is logged with: exact location in documentation, description of ambiguity, severity (critical for safety/operation or minor), resolution (documentation update, design clarification, work-around or resolved by inference)
- Assign neutral third-party auditor (external to both project and Kenyan partner) to review defect log quarterly during Phase II and flag any critical gaps remaining unresolved; confirm resolutions are documented and traceable
- Before Phase II replication concludes (Month 24 = 2028-10-09), require independent gate-review panel to examine defect log and assess: 'What is residual defect rate? Are remaining defects such that Kenyan team can resolve them independently in Phase III, or do they suggest systematic documentation gaps?' Panel should recommend maximum acceptable defect rate (e.g., 'no more than 5 critical defects, 10–15 minor clarifications') to proceed to Phase III
- If defect rate exceeds panel's threshold, allocate additional time in Phase II (extend to Month 25–26 = 2028-11-09 to 2028-12-09) for documentation remediation before full-scale Phase III build starts
- At Phase II-to-Phase III gate, require independent reviewers to sign off on documentation completeness, with clause stating: 'We have reviewed defect log and project's documentation responses. Documentation is sufficiently clear that trained team can build and operate system independently, with residual defects not exceeding [threshold].'

## Sensitivity

Baseline assumption: Phase II early replication catches 80–90% of critical documentation defects (~60% probability if defect-tracking discipline enforced). Risk if critical defects not caught until Phase III: each defect discovered during full-scale build costs EUR 30,000–100,000 (estimate) to resolve and delays replication by 2–4 weeks. If 10–15 critical defects discovered in Phase III full-scale build, total cost impact EUR 300,000–1,500,000 (estimate) and schedule slip 5–12 weeks. Impact on total budget: 0.6–3% depending on defect severity and timing.

# Organisational Separation Between Design and Replication Teams Requires Explicit Auditing

## Risk of Undocumented Help & Compromised Independence

The plan mandates organizational separation between Danish design team and Kenyan replication team, with audited assistance log recording all external help. Goal is credible evidence that a separate, independent team can build and operate the system without persistent developer dependence. However, auditing this separation is challenging: informal advice may go undocumented; urgent assistance during safety incidents may be provided without prior notification; boundary between acceptable 'documented external assistance' and unacceptable 'developer help' is subjective. If audited log is not maintained rigorously, independence claim cannot be verified.

## Recommendation

Establish detailed Assistance-Log Protocol during Phase One:

- Specify what must be logged: any communication (email, phone, video call, in-person visit) between Kenyan team and Denmark team or third-party specialists providing technical guidance, safety review or operational troubleshooting
- For each assistance event, log: date, parties involved, topic, duration, outcome and whether assistance was pre-planned or emergency response
- Establish third-party audit firm (independent of both project and Kenyan partner) to review assistance log monthly and flag any assistance appearing to exceed acceptable boundaries (e.g., more than 4 hours per month estimate of direct hands-on troubleshooting by Denmark staff would suggest insufficient Kenya team competence)
- Auditor should have authority to recommend extended training or documentation fixes if assistance patterns suggest gaps
- Specify in writing what types of assistance are acceptable without invalidating independence: (a) documented, pre-scheduled safety reviews by qualified ATEX/process-hazard specialist (acceptable, logged); (b) pre-submission regulatory consultation with Kenya's National Biosafety Authority (acceptable, logged); (c) emergency troubleshooting during safety incident (acceptable if logged and post-incident training documented); but NOT routine hands-on operation by Denmark staff or design changes made by Denmark staff without Kenya team participation and documentation
- Publish summary of audited assistance log in Phase III final report, including frequency of assistance, topics covered and auditor's assessment: 'Kenyan team demonstrated sufficient competence to operate system with logged level of external assistance. Assistance level consistent with hypothesis A and B definitions.'
- If auditor identifies concerning patterns, escalate to independent gate-review panel for judgment: 'Does assistance pattern compromise independence claim? Should conclusion be Modify rather than Go?'

## Sensitivity

Baseline assumption: audited assistance log is maintained faithfully and independence is genuine (~70% probability assuming auditor is truly independent and has enforcement authority). Risk if auditing is weak: undocumented assistance could inflate independence claim by 30–50%, meaning final conclusion overstates replicability and local-operation robustness. If external reviewer later discovers significant undocumented help, hypothesis B evidence is invalidated and project credibility damaged, reducing adopter confidence by 40–60%. Cost of implementing rigorous auditing: EUR 50,000–100,000 (estimate) over Phase III (Month 24–54 = 2028-10-09 to 2031-04-09).

# Strain Stability Over 6-Month Phase III Operation Not Validated in Advance

## Risk of Strain Drift Discovered Late

Phase Three success criterion is six months of continuous operation of the reference unit with documented strain stability. However, hydrogen-oxidizing bacteria strain stability over 6 months of continuous or high-frequency fed-batch fermentation under the project's specific conditions (intermittent power, temperature cycling, variable water quality) is unproven. If strain drift emerges during Phase III, the project has limited recourse: it cannot pause for strain investigation and must either accept degraded performance or declare the test failed.

## Recommendation

During Phase II (Month 12–24 = 2027-10-09 to 2028-10-09), conduct long-term strain-stability experiment in selected reactor concept:

- Run 10–16 week continuous or fed-batch culture of reference strain under intended Phase III operating conditions (temperature, pH, aeration, substrate concentration, power cycling)
- Sample weekly for: growth rate (biomass accumulation), oxygen-uptake rate, nucleic acid content (16S rRNA or total RNA extraction and quantification), viability (plate counts or flow cytometry) and mutation detection (genome resequencing at start and end, or RAPD/AFLP fingerprinting at mid-point and end)
- Document any deviation from expected productivity or composition
- If strain stability confirmed over 10–16 weeks with <10% variation in key parameters, proceed to Phase III with confidence that 6-month stability is likely
- If variation exceeds 10% or concerning trend emerges (e.g., nucleic acid content increasing), extend Phase II experiment by 4–8 weeks and increase sampling frequency to identify cause and determine whether it stabilizes or continues
- If strain drift cannot be arrested in Phase II, escalate to gate-review panel: project now faces choice to (a) accept degraded performance (adjust productivity benchmark down), (b) switch to backup strain (requiring restart of Phase II work) or (c) declare strain unsuitable and recommend Research Only conclusion
- In Phase III, collect weekly samples from reference unit and conduct rapid stability checks: growth rate from daily biomass measurements, nucleic acid content from rapid PCR, quarterly genome sequencing or mutation detection
- If any parameter deviates by >15% from Phase II baseline, pause operation, investigate and adjust reference-unit success criterion

## Sensitivity

Baseline assumption: hydrogen-oxidizing bacteria strain is stable over 6 months (~50–60% probability based on published culture work but with uncertainty due to novel Phase III operating conditions). Risk if strain drifts: project must either accept degraded performance (reducing hypothesis A/B credibility and adoption appeal by 20–30%), switch to backup strain (consuming 4–8 weeks and EUR 150,000–300,000 estimate) or conclude Research Only (invalidating EUR 20–30M Phase III investment). Cost of Phase II long-term experiment: EUR 50,000–100,000 (estimate); if this prevents discovery of strain drift in Phase III, it saves EUR 2–4M and reputational damage.

# Pre-Locked Deployment Thresholds May Not Account for Scale-Up Cost or Productivity Penalties

## Risk of Failed Go Decision Due to Underestimated Costs

The plan assumes deployment thresholds (maximum cost EUR X/kg, minimum capacity Y kg/day, uptime Z%) will be locked by Month 9 (2027-07-09), before any Phase II or Phase III data are available. These thresholds are typically derived from landscape research or adopter input. However, techno-economic models often underestimate downstream-processing costs (harvest, cell disruption, nucleic acid removal, drying), energy losses during scale-up and operational overhead. If thresholds are set too tight, the system fails the threshold and Go decision is forced to Modify or Research Only despite the technology working. Conversely, if thresholds are too loose, the project passes a threshold that no real adopter would accept.

## Recommendation

When locking deployment scenarios and thresholds (Month 6–9 = 2027-04-09 to 2027-07-09):

- Require adopters to provide detailed cost-basis documentation: current spend on protein (EUR/kg), breakdown (production, transport, storage, waste treatment), acceptable cost premium for vendor-independent, locally maintainable solution; anchor adopter input in written business cases or budget documents, not verbal assertions
- Commission independent techno-economic model (not done by project team) that includes full cost accounting: (a) fermentor operation (electricity, nitrogen source, minerals, water treatment), (b) downstream processing (harvest, disruption, nucleic acid removal, drying, packaging), (c) facility overhead (equipment depreciation, maintenance, staff), (d) contingency and margin (10–15% estimate); use conservative assumptions for unknowns
- For thresholds with high sensitivity to uncertain parameters, conduct sensitivity analysis: 'If downstream energy is X, cost is Y EUR/kg; if downstream energy is 1.5X (conservative), cost is Z EUR/kg.' Report both base and conservative cost to adopters
- Lock thresholds in writing with each adopter, specifying cost model and key assumptions; e.g., 'EUR 10/kg acceptable based on cost model assuming downstream nucleic acid removal requires 3 kWh/kg. If actual downstream energy exceeds 4 kWh/kg, cost threshold may be exceeded and viability will be reassessed.'
- By Phase III gate, conduct final actuals-vs-model analysis: 'Measured Phase III costs were EUR X/kg against locked threshold of EUR Y/kg. Variance explained by [specific cost drivers]. Does variance invalidate threshold, or are results within original adopter commitment?'

## Sensitivity

Baseline assumption: pre-locked thresholds are realistic and achievable (~50–60% probability given data uncertainty at Month 9 = 2027-07-09 when Phase II bench work not yet complete). Risk if thresholds too tight: 20–30% probability of failed Go decision despite technology working, leading to Research Only or Modify conclusion and wasted EUR 20–30M investment. Risk if thresholds too loose: deployment rates 20–40% lower than projected because adopters don't find economics compelling. Cost of independent techno-economic modeling and sensitivity analysis: EUR 60,000–100,000 (estimate); if this prevents false-negative or false-positive gate decisions, it protects EUR 20–30M investment value.

# Downstream Processing Train Not Validated at Scale

## Risk of Cost & Energy Surprises in Phase III

The plan requires downstream processing (harvest, cell disruption, nucleic acid reduction, drying) to be designed and evaluated with fixed processing boundary used consistently in benchmark calculations. However, downstream processing is often the largest cost and energy burden for bioprocesses and frequently underestimated in early-stage development. Nucleic acid content reduction (key regulatory requirement) can be achieved via thermal, enzymatic or mechanical methods, each with different energy, consumable and equipment costs. If enzymatic digestion is selected at bench scale but proves difficult to scale, the Phase II or Phase III team must pivot to thermal treatment, adding EUR 200,000–500,000 (estimate) and 2–4 months to schedule.

## Recommendation

Establish clear Downstream-Processing Specification during Phase One (Month 1–3 = 2026-11-09 to 2027-01-09):

- Define processing boundary (harvest method, cell disruption method if any, nucleic acid reduction step, drying method, final product form)
- Specify target product specification (nucleic acid content <2%, protein >60%, moisture <8% estimate)
- Identify equipment footprint, power requirements and recurring consumables for each step

During Phase II, allocate dedicated work package to downstream-processing validation at increasing scale:

- Bench scale (10–100 mL harvest volumes): test nucleic acid-reduction methods (thermal at 60–80°C estimate, enzymatic with available proteases, or direct harvesting) for efficiency and product-quality impact
- Pilot scale (1–5 L harvest volume): validate selected nucleic acid-reduction method at larger volume, confirm consumable costs and energy requirements
- Measure product composition (nucleic acid, protein, digestibility) at each scale to confirm consistency
- If nucleic acid reduction proves significantly more energy-intensive or consumable-costly than bench-scale model, escalate to cost model: update total system cost, energy per kg and residual uncertainty

Before Phase III begins (Month 24 = 2028-10-09):

- Require independent gate-review panel to assess downstream-processing readiness: 'Is selected downstream process validated at sufficient scale? Does it fit available skills in Kenya? Does product specification meet regulatory and adopter thresholds?' If answer to any question is 'no' or 'uncertain,' recommend extending Phase II downstream work or adding controlled stressors in Phase III
- In Phase III, collect weekly samples of processed product and analyze for composition stability; if nucleic acid content or digestibility deviates significantly from Phase II baseline, diagnose cause and document corrective action; track downstream-processing labor and consumable costs weekly

## Sensitivity

Baseline assumption: downstream processing is validated by Phase II end and costs are within 10–15% of model (~50–60% probability given typical bioprocess cost-surprises). Risk if downstream processing underestimated: cost could increase by 30–60%, moving total system cost from EUR 10–12/kg to EUR 13–19/kg, potentially exceeding adoption thresholds by 30–50%. If nucleic acid reduction not adequately validated and fails in Phase III, product cannot be sold and deployment case collapses, forcing Research Only or complete redesign (EUR 500,000–1,500,000 estimate, 6–12 month delay). Phase II work to validate downstream: EUR 150,000–250,000 (estimate), well spent if prevents Phase III surprises.

# Currency Volatility Over 5-Year Project May Consume EUR 500K–1.5M

## Risk Without Mitigation

The project operates across Denmark (EUR costs) and Kenya (KES costs) over 5 years (Month 0–60 = 2026-10-09 to 2031-10-09). The plan assumes EUR is primary currency for consolidated budgeting and that forward rates or hedging will protect against currency fluctuations. However, the plan does not specify a hedging strategy, frequency of currency-conversion locks or contingency if KES depreciates significantly. Kenya's KES has historically fluctuated by 10–20% annually; over 5 years, cumulative depreciation of 15–30% is plausible. If EUR 50M is ceiling and EUR 20M (40% estimate) is allocated to Kenyan activities, a 20% KES depreciation would reduce effective KES purchasing power by ~20%, requiring either 20% more EUR to maintain same KES spend or 20% reduction in planned Kenyan scope.

## Recommendation

Establish Currency and Foreign-Exchange Strategy at project start (Month 0 = 2026-10-09):

- Document that EUR is primary accounting currency; define baseline EUR/KES exchange rate (use agreed reference rate from Month 0 = 2026-10-09, not subject to change)
- Commit to hedging or fixed-rate allocation for Kenyan spending
- Estimate total Kenyan spend over 5 years by cost category: staff (salaries in KES, ~60% of Kenyan budget estimate), local procurement (utilities, consumables, ~25% estimate), contingency (15% estimate); convert to KES at Month 0 (2026-10-09) baseline rate; allocate this KES amount to project and manage Kenyan spending in KES, not EUR
- Use forward-rate contracts or currency hedging for tranches of large, scheduled Kenyan spend (adds 0.5–1% transaction cost estimate); alternatively, establish currency-fluctuation contingency fund (2–3% of Kenyan budget, ~EUR 400,000–600,000 estimate) held in reserve; if KES depreciates, draw from fund to maintain planned spending; if KES appreciates, return contingency to project
- Track EUR/KES rates monthly and report variance against baseline-rate assumption in quarterly financial reviews; if cumulative variance exceeds 10%, trigger re-baseline or contingency-fund allocation decision
- Include in partner agreements with Kenyan team clause addressing exchange-rate risk: 'KES budget allocation is fixed at [amount] KES as of Month 0 (2026-10-09). If actual EUR/KES rates fluctuate, KES budget holds constant; Kenyan team manages within allocated KES, or escalates to project if scope reduction required.'

## Sensitivity

Baseline assumption: EUR/KES stays within 10–15% of baseline over 5 years (~50–60% probability; Kenya's currency historically volatile). Risk if not hedged: 20% depreciation of KES would consume additional EUR 3–4M if Kenyan spending not capped in KES, or force 15–20% scope reduction in Kenya if spending capped. Impact on total budget: 6–8% cost variance or scope loss if not hedged. Cost of hedging (forward contracts, contingency fund): EUR 100,000–200,000 (estimate), worthwhile insurance against currency risk.

# Phase One Gate Criteria May Be Misaligned with Deployment-Threshold Sensitivity

## Risk of Advancing Weak Technology or Stopping Viable Technology

The plan assumes Phase One productivity data will be measured with ±30% uncertainty, and gate criterion is that productivity is >70% of published benchmark. However, if deployment scenario thresholds are sensitive to productivity (cost scales with productivity: lower productivity = higher cost per kg), a productivity that is 70% of benchmark could translate to 40–50% cost increase, exceeding adopter threshold. Alternatively, if productivity uncertainty of ±30% spans range from 60% to 100% of benchmark, Phase One data cannot clearly distinguish pass from fail.

## Recommendation

Conduct sensitivity analysis during Phase One (Month 4–6 = 2027-02-09 to 2027-04-09) linking measured productivity to deployment-scenario cost:

- Example: if productivity is 70% of benchmark, what is estimated cost per kg? Is it within locked deployment threshold?
- Use sensitivity analysis to set Phase One productivity gate criterion: e.g., 'Phase One passes if productivity is >75% of published benchmark. At 75% productivity, estimated cost is EUR 11/kg, consistent with locked adopter threshold of EUR 12/kg (with 1 EUR/kg margin for Phase Two and Three refinements). If productivity is 60–70%, estimated cost is EUR 13–15/kg, exceeding threshold; Phase One fails unless cost model is fundamentally revised.'
- If Phase One productivity data show >30% uncertainty, escalate gate decision to independent reviewers with explicit statement: 'Productivity uncertainty is high. Cannot definitively declare pass or fail. Recommend proceeding to Phase II under heightened scrutiny of selected reactor concept, with mandatory productivity re-validation at pilot scale before proceeding to reference-unit design.'
- Include in Phase One gate documentation clear statement: 'Phase One gate criterion for productivity is [X]% of published benchmark. We have verified this productivity level is consistent with deployment-scenario cost thresholds (within [Y] EUR/kg margin). If Phase II or III productivity falls below [X]%, system will not meet cost threshold and Go decision is not possible unless thresholds formally renegotiated with adopters.'

## Sensitivity

Baseline assumption: Phase One productivity data are clear enough to distinguish pass/fail against gate criterion (~65% probability depending on bench-scale experiment noise and selected reactor design clarity). Risk if gate criterion misaligned: 10–20% probability of false-positive gate pass (technology advances despite poor productivity fit with cost threshold) or false-negative gate fail. Cost of failed Phase II or III due to misaligned Phase One gate: EUR 5–15M wasted if technology advanced without adequate productivity data.

# Independent Gate-Review Panel May Lack Sufficient Technical Depth or Availability

## Risk of Rubber-Stamping or Insufficient Scrutiny

The plan requires 3–5 member independent gate-review panel with expertise in process engineering, ATEX safety, biotechnology regulation, adoption/economics and food-safety. However, finding truly independent experts with specific domain knowledge (hydrogen-oxidizing bacteria, electrolysis, ATEX, single-cell protein regulation) in a small technical field is challenging. If pool of qualified reviewers is small, same people may be asked repeatedly, leading to conflicts of interest or review fatigue. If panel members lack deep technical knowledge, they may miss critical gaps and rubber-stamp recommendations. If panel members have limited time availability, they may skim documents.

## Recommendation

At project start (Month 0 = 2026-10-09), conduct targeted search for independent reviewers:

- Prioritize: technical experts from universities or independent research institutes (not affiliated with host institution or major alternative-protein companies); people with published expertise in relevant domains (hydrogen fermentation, ATEX design, microbial fermentation, food-safety regulation); people with prior experience reviewing large technology programs or serving on independent safety committees
- Recruit panel 2–3 months before Phase One gate meeting (by Month 7 = 2027-05-09 for Phase One gate at Month 9 = 2027-07-09); conduct brief scoping meeting (2–4 hours) with each panel member to outline project, clarify role and confirm availability for full project duration (estimated 40–60 hours per panel member spread across gate meetings and document reviews)
- Provide comprehensive briefing materials to panel members at least 4–6 weeks before each gate meeting, including: technical reports, experimental data, safety analyses, regulatory correspondence, cost models and explicit list of gate-pass/fail criteria; require each panel member to document review time and key questions or concerns
- Schedule in-person or virtual gate meetings of 1–2 days, with sufficient time for panel members to present findings, debate disagreements and produce joint recommendation
- Include in panel honoraria 'preparation reserve': pay panel members for estimated review time (e.g., 40 hours × USD 200/hour estimate = USD 8,000 per member per gate), not just for meeting attendance
- After each gate, collect feedback from panel members: 'Did you have sufficient time to review? Did you have all information needed? Were there technical areas you felt less equipped to assess?' Use feedback to improve next gate's materials and timeline

## Sensitivity

Baseline assumption: independent panel conducts adequate technical review (~60% probability dependent on expert availability and preparation time). Risk if review is insufficient: critical technical, safety or regulatory gaps missed, allowing weak technology or unsafe design to advance. Cost of inadequate review: EUR 5–20M if major issue (e.g., hydrogen-oxygen ignition hazard not adequately addressed) discovered late in Phase III and forces re-design. Cost of rigorous panel management: EUR 100,000–150,000 (estimate) over project, well invested in risk reduction.

# Scale-Up Evidence Ladder & Disproof Experiments May Have Misaligned Failure Thresholds

## Risk of False Failures or False Passes

The plan requires pre-registered failure thresholds for disproof experiments, locked before Phase Two data arrive; e.g., 'if mass-transfer coefficient declines by >20% between bench and pilot scale, reactor concept fails.' However, setting these thresholds is challenging: too tight, a promising design may be abandoned due to normal variation; too loose, problematic scale-up assumptions pass unscrutinized. If thresholds are adjusted after Phase Two data arrive, the disproof experiment loses credibility.

## Recommendation

During Phase One (Month 4–6 = 2027-02-09 to 2027-04-09), establish Scale-Up Risk Register identifying principal assumptions and their uncertainty:

- Example: mass-transfer coefficient expected to scale as (power per volume)^0.4 to (power per volume)^0.6; decline of 10–20% from bench to pilot scale acceptable; decline of >30% suggests model is wrong and design needs rework
- Commission independent technical reviewer (not project staff) to scrutinize each assumption and propose failure thresholds; e.g., 'recommend setting kLa failure threshold at 25% decline, based on literature data showing typical scale-up effects of 15–20% in comparable fermentations'
- Document failure thresholds in 'Disproof-Experiment Protocol' and lock before Phase Two experiments begin; include rationale for each threshold
- During Phase Two, if measured scale-up effects approach or exceed thresholds, conduct detailed root-cause analysis before concluding failure: (a) Is effect a real physical phenomenon or experimental artifact? (b) Can design be adjusted to mitigate effect without undermining simplicity or cost goals? (c) If effect is real and cannot be mitigated, does it invalidate deployment case or can threshold (and deployment scenario) be adjusted with adopter consent?
- If threshold is breached, escalate to independent gate-review panel with full documentation of root-cause analysis and proposed response; do not adjust threshold unilaterally; require panel endorsement of any threshold change
- If disproof experiments show scale-up assumption is violated, document finding clearly: 'Mass-transfer coefficient declined 32% from bench to pilot scale, exceeding pre-set failure threshold of 25%. This suggests design's gas-transfer mechanism does not scale as assumed. Recommend [specific design change] before proceeding to reference-unit scale, or accept that reference-unit performance will be limited by gas transfer and adjust cost/productivity forecasts.'

## Sensitivity

Baseline assumption: failure thresholds are set appropriately and followed rigorously (~55–65% probability depending on discipline and panel oversight). Risk if thresholds too tight: 15–20% probability that viable design is abandoned prematurely due to scale-up variation within acceptable limits. Risk if thresholds too loose: 20–25% probability that problematic scale-up assumptions advance to Phase III without adequate testing, leading to cost surprises or performance failures. Cost of additional scale-up validation work if threshold breached and design must be reworked: EUR 200,000–500,000 (estimate) and 4–8 week delay.

# Regulatory Pathway Assumptions Based on Preliminary Data

## Risk of Late-Stage Regulatory Rejection

The plan assumes regulatory pathway will be identified and locked by Month 9 (2027-07-09) based on preliminary Phase One landscape research. However, regulatory approval timelines and safety data requirements for novel protein products vary widely by jurisdiction and product category. Denmark/EU may require 12–24 months of safety testing before granting authorization; Kenya may have less-established pathways and unpredictable timelines. If product category is chosen based on preliminary data and Phase II or III compositional analyses reveal unexpected elements (nucleic acid content of 8% instead of 2%, or unexpected secondary metabolite), regulatory pathway may become blocked. A regulatory re-assessment triggered in Phase III could require 6–12 months of additional safety studies, consuming EUR 500,000–1,500,000 (estimate).

## Recommendation

Conduct detailed Regulatory Requirements Assessment during Phase One (Month 0–4 = 2026-10-09 to 2027-02-09):

- In Denmark/EU: contact EFSA or relevant national authority via pre-submission consultation to obtain written guidance on data required for intended product category (animal feed, food ingredient, emergency nutrition); request clarity on nucleic acid content limits, composition specifications and safety testing thresholds
- In Kenya: contact National Biosafety Authority for contained-use authorization and Kenya Bureau of Standards for product-safety and classification guidance; identify any gaps in established pathways for novel protein products
- Develop Regulatory Data Package template for each product category, specifying: composition analysis required (protein, nucleic acid, amino acid profile, fatty acids, minerals), safety testing required (acute toxicity, allergenicity assessment, 28-day oral toxicity if novel protein) and supporting documentation (manufacturing process, quality control, production controls)
- By Month 6 (2027-04-09): select primary product category and lock in signed document, with clause: 'We have confirmed with [authority name] that this product category has credible regulatory pathway. Following data will be required for authorization: [list]. We commit to generating this data during Phase II and III. If Phase II compositional data reveal values outside safe ranges, we will escalate to authority and reassess pathway.'
- During Phase II, analyze product composition against regulatory specifications; if nucleic acid content or other parameters fall outside acceptable range, conduct root-cause analysis and re-contact authority to confirm acceptability or adjust product category
- Before Phase III begins (Month 24 = 2028-10-09): require independent gate-review panel to assess regulatory readiness: 'Do Phase II data support chosen product category and regulatory pathway? If not, recommend either (a) additional Phase II validation to achieve required composition or (b) selection of different product category with lower safety-data burden.'
- If late regulatory change is announced, escalate to steering committee: assess impact on product and deployment case, decide whether to petition for delayed transition or pivot to different category; document any regulatory pivot in final report as 'lesson learned'

## Sensitivity

Baseline assumption: regulatory pathway established and stable through Phase III (~60–65% probability given long approval timelines and typical regulatory guidance stability). Risk if regulatory rejection occurs late: 15–20% probability of 12–18 month regulatory delay or re-assessment requirement, consuming EUR 500,000–1,500,000 (estimate). Cost of rigorous regulatory engagement and Phase II composition validation: EUR 100,000–200,000 (estimate), justified as insurance against late regulatory surprises.

# Review Conclusion

The Open Protein Module is a highly ambitious, evidence-driven infrastructure programme with substantial technical and organizational complexity. The plan's core governance mechanisms—stage gates with independent review, pre-locked deployment scenarios, hypothesis-testing framework and measured scale-up evidence—are well-designed to manage high uncertainty and prevent continuation by momentum. However, several critical gaps threaten success:

- Gate-review independence is not specified in sufficient detail, risking rubber-stamping of weak evidence
- Strain rights and regulatory pathways must be locked earlier (by Month 4 = 2027-02-09, not Month 9 = 2027-07-09) or they become project-blocking delays
- The Kenyan site's operating envelope must be independently verified and monitored quarterly, or hypothesis B evidence becomes anecdotal
- Deployment thresholds must engage real adopters with signed commitments, not hypothetical scenarios
- Measurement frameworks and disproof-experiment thresholds must be pre-registered to prevent post-hoc rationalization
- Downstream processing is often the largest technical and cost risk in bioprocesses and requires early, dedicated Phase II validation
- Currency volatility over 5 years needs explicit hedging or contingency allocation

The most critical issues are gate-review independence, early regulatory/strain-rights validation and real (not hypothetical) adopter engagement. Addressing these three issues would reduce project risk by an estimated 30–40% and improve credibility of the final Go/Modify/Stop decision. Total cost of recommended governance improvements: EUR 500,000–800,000 (estimate) (3–5% of Phase One budget), well justified as insurance against EUR 20–50M programme-scale investment decisions.