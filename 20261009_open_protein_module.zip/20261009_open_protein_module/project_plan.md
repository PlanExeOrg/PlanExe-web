**Goal Statement:** Establish The Open Protein Module, a non-profit open-source programme that delivers a safe, legally implementable, independently replicated process turning electricity, water, CO2 and a nitrogen source into protein with hydrogen-oxidizing bacteria, developed in Denmark and replicated in Kenya, with a full open source package, within 60 months and a provisional EUR 50 million ceiling (user constraint).

## SMART Criteria

- **Specific:** Produce and openly publish a complete, safety- and legally-reviewed engineering package for single-strain hydrogen-oxidizing bacteria protein production, validated by a Danish reference unit and an organizationally separate Kenyan replication under difficult infrastructure, with hypotheses A (local technician operation) and B (decentralized modules) reported separately.
- **Measurable:** Go requires: on-spec biomass (protein >=60%, nucleic acid <=2% dry matter, moisture <=8%) (estimate) from documentation alone; 100% of safety-critical fault injections reach a safe state; >=90% of other fault tests recovered; six-month uptime >=90% (proposed threshold); operator safety pass >=90%; one locked scenario met; credible regulatory and scale-up routes.
- **Achievable:** Builds on published open work (e.g. electroPioreactor, passive gas feeding) and commercial precedent. Staged gates with a EUR 6 million Phase One ceiling (user constraint) and planned spend of EUR 5.5M (estimate) limit exposure. Partners, funding, sites and permits are unsigned and uncontrolled; the deployment cost chain currently shows a gap (full cost EUR 19.93/kg vs EUR 12 cap) (estimate).
- **Relevant:** Gives countries facing food-supply disruptions a route to local protein production without dependence on one company or exporter. Public-good value is measured by reproducibility, safety, cost and repairability, not revenue.
- **Time-bound:** Project starts ASAP at Month 0 (2026-10-09). Phase One Months 0-12 (2026-10-09 to 2027-10-09), Phase Two Months 12-30 (2027-10-09 to 2029-04-09), Phase Three Months 30-60 (2029-04-09 to 2031-10-09). Phase Three evidence freeze Month 57 (2031-07-09) and final gate decision by Month 60 (2031-10-09). Phase One gate evidence freeze Month 9 (2027-07-09), release decision by Month 12 (2027-10-09).

## Dependencies

- Signed Danish university consortium host MoU and Kenyan co-development partner agreement, with funding treated as uncontrolled until signed
- Independent gate-review panel chartered and funded by the funder, with authority defined before Phase One work
- Reference and backup strain rights, patent freedom-to-operate review and lawful Kenyan import, concluded in a Strain Feasibility Report by Month 4 (2027-02-09)
- Formal hazard analysis (HAZOP/LOPA) with ATEX review and safety design basis before reactor design commitment
- Locked deployment scenarios with named prospective adopters, thresholds fixed before prototype evaluation

## Resources Required

- Bench, laboratory and container-scale bioreactors with electrolyzers and ATEX-compliant gas handling
- Reference strain (e.g. Cupriavidus necator H16, to be evaluated) and backup strain from public culture collections
- Analytical equipment for gas, biomass composition, nucleic acid and digestibility
- Two reference units (Danish and Kenyan), est. EUR 2.0M hardware each (estimate)
- Nitrogen source, minerals, process chemicals, water treatment and spares such as electrolyzer membranes

## Related Goals

- Open-source steward entity keeping the core open
- Credible regulatory pathways in Denmark/EU, Kenya and Bangladesh landscape
- Local technician training and competency verification
- Resilient local protein supply during energy and food crises
- Published open knowledge even if outcome is Research Only

## Tags

- hydrogen-oxidizing bacteria
- single-cell protein
- open-source hardware
- gas fermentation
- food security

## Risk Assessment and Mitigation Strategies


### Key Risks

- Hydrogen-oxygen explosion hazard from electrolyzer, gas lines and headspace
- Strain rights, patent or Kenyan biosafety barriers blocking lawful replication
- Scale-up failure: mass transfer, productivity and energy per kg do not hold; deployment cost chain gap (EUR 7.93/kg above cap) (estimate)
- Product regulatory pathway or nucleic acid limits blocking the chosen category
- Documentation gaps found only at replication, or compromised independence

### Diverse Risks

- Unsigned partners, host priorities or adopter withdrawal
- Gate panel independence weakened, allowing continuation by momentum
- Kenyan site chosen for convenience, or envelope drifting mid-project
- Contamination or strain drift over long runs and power cycling
- EUR/KES volatility; funding route for the EUR 274,820/yr deployment gap undecided (estimate)

### Mitigation Plans

- Engage independent HAZOP/ATEX consultant by Month 1 (2026-11-09); issue safety design basis and Adopter Change Boundary v0 by Month 3 (2027-01-09); independently review interlocks before any pressurized build
- Front-load strain rights, patent search and informal Kenyan biosafety contact; deliver Strain Feasibility Report with primary and legally clean backup by Month 4 (2027-02-09)
- Pre-register reactor selection rules and disproof thresholds; run triplicate matched comparisons with external audit; release reference-unit hardware (EUR 4.0M) only at the Phase Two gate
- Run early independent paper-and-bench replication Months 14-24 (2027-12-09 to 2028-10-09) with defect tracker, auditor and reserved EUR 0.15M; use audited assistance log reviewed monthly
- Charter funder-managed panel (EUR 0.30M) with published deviations; independent Kenyan site baseline by Month 4 (2027-02-09); hold EUR 4.0M programme reserve including EUR 0.5M currency fund; recommend reduced Phase Three or Research Only if cost chain still fails

## Stakeholder Analysis


### Primary Stakeholders

- Danish university consortium project team (process engineers, microbiologist, safety engineer, regulatory expert)
- Kenyan co-development partner and independent replication team
- Independent gate-review panel (3-5 members)
- Funder holding release authority
- Prospective adopters (e.g. reserve agency, feed producer, humanitarian logistics organization)

### Secondary Stakeholders

- Strain holders and culture collections
- Regulators: Danish/EU authorities, Kenya National Biosafety Authority
- Independent ATEX/safety consultants, auditors and patent counsel
- Existing open-hardware and gas fermentation researchers (e.g. AMYBO)
- Equipment, nitrogen and mineral suppliers; local technicians

### Engagement Strategies

- Primary team and partners: quarterly steering committee, monthly progress and spend reports, prompt answers to information requests
- Panel: written charter, briefing packs 4-6 weeks before each gate, published recommendations and any funder deviation
- Adopters: structured interviews, scenario profiles by Month 6 (2027-04-09), signed commitments by Month 7 (2027-05-09), locked at Month 9 (2027-07-09), publish any withdrawal
- Regulators and strain holders: early informal pre-submission dialogue, written feedback logged as design inputs
- Researchers and suppliers: collaboration agreements, milestone updates, notice of scope or timeline changes

## Regulatory and Compliance Requirements


### Permits and Licenses

- Contained-use authorization for the production organism in Denmark/EU
- Kenyan biosafety approval and strain import permit
- Site and ATEX-related operating permits for hydrogen systems in Denmark and Kenya
- Feed or food product registration (category-dependent), not required for research success
- Material transfer agreements and strain licences

### Compliance Standards

- ATEX and hydrogen process safety design, HAZOP/LOPA
- Feed/food safety and novel protein composition requirements per category
- Biosafety and contained-use rules
- Electrical and pressure equipment codes
- Open licence terms consistent with third-party patents and strain terms

### Regulatory Bodies

- Danish authorities and EU competent authorities (including EFSA for product safety)
- Kenya National Biosafety Authority
- Kenya Bureau of Standards and Ministry of Health
- Patent offices in Denmark/EU, Kenya and Bangladesh (landscape)

### Compliance Actions

- Commission regulatory and patent landscape in Months 0-4 (2026-10-09 to 2027-02-09) and open informal authority dialogue
- Complete HAZOP and independent interlock review before pressurized builds
- Document strain rights and Kenyan import before design freeze
- Publish per-jurisdiction patent restrictions; release operating instructions only after safety and legal review
- Name provisional product category at Phase One gate; confirm at Phase Two gate on composition data