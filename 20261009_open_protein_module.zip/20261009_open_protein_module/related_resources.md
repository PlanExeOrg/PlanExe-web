## Suggestion 1 - Solar Foods – Solein (Factory 01 and Pilot 'Factory 01' in Vantaa, Finland)

Finnish company producing Solein, a protein from hydrogen-oxidizing bacteria grown on hydrogen, CO2 and minerals using electricity. Pilot operation since about 2019-2020; a larger Factory 01 in Vantaa was built to demonstrate commercial scale. Strain and process are proprietary. Scale and timelines are approximate and should be confirmed from company publications.

### Success Metrics

Operating pilot and factory facilities (confirm current status from company reports).
Regulatory approvals obtained in some jurisdictions (e.g. Singapore; EU status not verified).
Published energy and productivity claims (approximate, not independently verified).

### Risks and Challenges Faced

Novel-food authorization is slow; the company pursued EU and other national routes stepwise and used early regulator dialogue.
Hydrogen-oxygen safety at scale; handled by industrial gas-safety practice and staged pilot-to-factory scaling.
Electricity cost drives economics; addressed by siting and renewable power sourcing.

### Where to Find More Information

https://solarfoods.com
Company investor and annual reports (Nasdaq First North Helsinki)
EFSA novel food register and opinions on Solein (search EFSA OpenEFSA)

### Actionable Steps

Contact Solar Foods' regulatory affairs or science team via the contact form on their website to ask about publicly shareable benchmark definitions.
Search LinkedIn for their process engineering and regulatory leads and send a brief public-good project inquiry.
Review published scientific papers by company-affiliated authors (e.g. with LUT University) and contact corresponding authors.

### Rationale for Suggestion

Same biological route and a Nordic regulatory and safety context close to Denmark. It is the main proprietary benchmark for productivity, energy per kg, nucleic acid handling and novel-food authorization. It also defines what the open design must differ from: vendor independence, repairability and openly published process data.
## Suggestion 2 - AMYBO electroPioreactor and Open-Source Gas Fermentation for Resource-Limited Regions

AMYBO is an open-source initiative developing the electroPioreactor and low-resource gas-fermentation methods, including passive gas feeding research (Green Chemistry, 2025, doi:10.1039/D5GC01564B, cited in the brief). Scale is bench to small pilot. Details on licences and results should be confirmed from their publications.

### Success Metrics

Peer-reviewed publication and open hardware documentation.
Measured productivity under simplified gas feeding (see paper; values not reproduced here).
Community adoption of the open design (not verified).

### Risks and Challenges Faced

Small scale limits industrial relevance; addressed by positioning it as a data source and baseline for scale-up experiments.
Hydrogen safety for low-resource users; handled via passive feeding and low gas inventory (verify specifics in paper).
Licence compatibility; check before inheriting designs.

### Where to Find More Information

https://doi.org/10.1039/D5GC01564B
AMYBO project website and repositories (search 'AMYBO electroPioreactor')

### Actionable Steps

Email the corresponding author listed on the Green Chemistry paper to propose collaboration and a benchmark protocol.
Contact AMYBO via the contact channel on its website for hardware licence terms.
Offer a joint KPI-definition exercise so benchmarks use compatible boundaries.

### Rationale for Suggestion

Directly named in the brief as an existing open reference. It is the primary candidate for the Phase One reference-architecture decision and for researcher collaboration, and shows the productivity cost of simplified low-resource designs. Limits: small scale and not tested against ATEX or Kenyan field conditions.
## Suggestion 3 - Kenyan insect-protein feed production (icipe, Nairobi) – local alternative protein in East Africa

The International Centre of Insect Physiology and Ecology (icipe) in Nairobi has worked for years on black soldier fly and cricket protein for feed and food, including training, technology transfer and Kenyan feed-regulation engagement. Scale and results should be confirmed from icipe publications.

### Success Metrics

Number of trained producers and adopters (see icipe reports; figures not verified).
Regulatory standards or guidelines for insect feed in Kenya (confirm current status).
Price competitiveness against conventional protein.

### Risks and Challenges Faced

Feed regulation for novel ingredients; addressed by working with Kenyan standards and ministry bodies.
Scaling local producers with variable skills; addressed through training programmes and farmer cooperatives.
Feedstock and cost competitiveness versus soy and fishmeal.

### Where to Find More Information

https://www.icipe.org
Kenya Bureau of Standards and Ministry of Agriculture publications on insect feed

### Actionable Steps

Contact icipe's insect-for-feed programme via the website contact form.
Request an introduction to Kenyan feed-industry associations to inform Scenario B thresholds.
Ask KEBS about the feed-ingredient registration route used as a precedent.

### Rationale for Suggestion

Closest East African precedent for taking an alternative-protein process through Kenyan feed regulation, local technician training, and adopter engagement. It also provides a Kenyan competitor benchmark for the cost thresholds in the deployment scenarios. Technology differs completely from gas fermentation.
## Suggestion 4 - SECONDARY: Open Source Ecology / Global Village Construction Set and OSHWA certification

Open Source Ecology documents open-hardware machines with the intent of independent replication; OSHWA runs an open-source hardware certification. Both are real but not comparable in safety criticality or scale.

### Success Metrics

Number of certified or replicated designs (not verified).

### Risks and Challenges Faced

Incomplete documentation hampered replicators; relevant lesson for the defect-tracking approach.

### Where to Find More Information

https://www.oshwa.org/
https://www.opensourceecology.org/

### Actionable Steps

Contact OSHWA through its website regarding certification suitability for safety-critical hardware.

### Rationale for Suggestion

Secondary reference for documentation practice, defect tracking of build instructions and open-hardware licensing and certification. It does not cover hazardous processes or biology.

## Summary

Reference projects for The Open Protein Module (hydrogen-oxidizing bacteria protein, Denmark development, Kenya replication). Commercial hydrogen-based protein exists but is proprietary, and no independently replicated open implementation is confirmed. The closest real references are: Solar Foods' Solein (Finland, hydrogenotrophic bacteria at pilot and factory scale), Calysta/Unibio-style gas fermentation (methane, not hydrogen, so only a process analogue), and AMYBO's open electroPioreactor (open hardware for low-resource settings). Open hardware governance is informed by the Open Source Ecology/OSHWA model, and Kenyan food-technology precedent comes from Kenyan insect-protein work. Geographically close Nordic precedent is strongest for regulation and safety; East African precedent is thin. Figures below are approximate or not verified. Confirm all contacts via official organisation channels.