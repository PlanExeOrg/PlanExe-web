# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** Infrastructure-scale public-good R&D programme over about 5 years with a provisional ceiling of EUR 50 million (user constraint), of which Phase One is up to EUR 6 million (user constraint). It spans Denmark and Kenya, with Bangladesh in the patent and regulatory landscape. The aim is an open, independently replicable protein process for food-supply disruptions, not a commercial product.

**Risk and Novelty:** High novelty and high technical, safety and legal risk. No publicly documented, independently replicated, industrially relevant implementation is known (claim taken from the plan, not verified). Main risks are hydrogen-oxygen explosion hazard, gas-liquid mass transfer and scale-up, strain rights, nucleic acid content, product regulation, and documentation gaps found only at replication. The plan expects failure to be possible: it has kill gates and Go, Modify, Research Only and Stop outcomes.

**Complexity and Constraints:** Very high complexity. It has two separately tested hypotheses (A: operation by local technicians; B: decentralised modules) and a measured operating envelope. It needs outage survival, a full material and energy balance, ATEX-compliant design, and pre-locked deployment thresholds. The Kenyan replication team must be organisationally separate, with an audited assistance log. It also needs independent gate reviewers with no funding dependence, and funding, partners, sites and permits are treated as uncontrolled until signed. Prescribed comparisons (high-productivity vs simplified designs, the productivity cost of simplification) and a requirement for a lawfully obtainable reference strain constrain the design space.

**Domain and Tone:** Engineering and biotechnology (electrolysis, hydrogen-oxidizing bacteria gas fermentation) with public-good, open-source governance. The tone is rigorous and evidence-driven, sceptical of its own results, and explicit that examples are starting points and not decisions.

**Holistic Profile:** A high-ambition, high-uncertainty, gated open-engineering programme whose strategy is to let measurement decide. It explicitly asks for a landscape review, a measured comparison of reactor concepts, a reference strain with a rights-clean fallback, thresholds locked before testing, layered and independently reviewed safety with a defined adopter change boundary, and independent replication. It rewards staged evidence and early discovery of failure over bold early commitment or minimal-cost conservatism.

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Evidence-First Builder
**Strategic Logic:** Let measurements, not early commitment, decide the design. Run matched reactor comparisons and carry a primary and a legally clean backup strain, so that neither a performance failure nor a rights failure stops the project. Anchor the pass/fail thresholds in named prospective adopters, and use an early small-scale replication to catch documentation gaps cheaply. Layered, independently reviewed protection with a short pre-assessed change list keeps safety rigorous and adopter modification manageable, at moderate cost and schedule.

**Fit Score:** 9/10

**Why This Path Was Chosen:** Matched reactor comparisons deliver the plan's required productivity-cost-of-simplification result. A primary and a backup strain address rights risk, and named-adopter thresholds are locked before testing. An early small-scale replication finds documentation defects cheaply, and layered reviewed interlocks with a short change list match the plan's ATEX and adopter-boundary wording. The main weaknesses are moderate extra cost and unsigned adopters.

**Key Strategic Decisions:**

- **Gas-Liquid Contacting and Reactor Concept:** Run matched pneumatic, stirred and passive-feed reactors on identical strain and media, then publish a measured productivity-versus-simplicity curve before choosing the Phase Three reference unit.
- **Strain Portfolio and Rights Strategy:** Screen several candidate strains in Phase One for productivity and rights, and carry a primary and a legally clean backup strain through Phase Two so a rights or performance failure does not stop the project.
- **Replication Design and Gate Governance:** Add an early paper-and-bench replication in Phase Two, in which an independent group builds a small unit from draft documents, to find documentation defects before committing to full-scale construction.
- **Deployment Scenario Anchoring and Threshold Locking:** Define two or three candidate scenarios with named prospective adopters, such as a national reserve agency or a regional feed producer, and lock their thresholds in a signed, time-stamped document before any prototype evaluation.
- **Inherent Safety Design Basis and Adopter Change Boundary:** Adopt layered instrumented protection with independently reviewed interlocks and emergency shutdown, and publish a short list of pre-assessed substitutable components and adjustable parameters for adopters.

**The Decisive Factors:**

- **Fits the plan's core logic:** the plan wants measurement to decide. It requires a landscape review, a comparison of high-productivity and simplified designs, and a measured productivity cost of simplification. Only matched reactor testing delivers this.
- **Manages risk without over-spending:** a primary and a rights-clean backup strain meet the requirement for a lawfully obtainable strain. Layered, independently reviewed interlocks plus a short pre-assessed change list match the ATEX and adopter-boundary requirements.
- **Gives gates meaning:** thresholds locked with named adopters, and an early bench replication, expose failure before the large construction spend, which supports the kill gates.
- **Pioneer's Gambit:** a pressurized reactor and a project-owned strain pre-commit and risk budget overrun.
- **Safe Foundation:** a single pneumatic design cannot test hypothesis B or the simplification trade-off, and it finds documentation defects late.
- Gate reviewers should still be independently funded (add-on from the plan).

---
## Alternative Paths
### The Pioneer's Gambit
**Strategic Logic:** Maximise technical and legal independence and productivity at once. Use a high-transfer pressurised reactor, a project-owned open strain, and a machine-readable safety case so that adopters can modify the design with checked safety. Replication starts early in Phase Two and thresholds are held by an adversarial panel, so documentation, safety-envelope and scenario weaknesses surface early. The cost is higher spend, specialist-qualified service, and a risk that strain development and ATEX work exceed the Phase One and Two budgets. This pathway also tests hypothesis A less directly than hypothesis B.

**Fit Score:** 3/10

**Assessment of this Path:** Commits early to a pressurized stirred reactor and a project-owned strain, which pre-empts the plan's required comparison of simplified and high-productivity designs. It also adds years of strain and biosafety work that conflicts with a lawfully obtainable public reference strain and the Phase One budget. It is weak on hypothesis A and on local repairability. Its early replication and adversarial thresholds do match the plan.

**Key Strategic Decisions:**

- **Gas-Liquid Contacting and Reactor Concept:** Develop a pressurized stirred-tank reactor with high-productivity gas transfer, and accept ATEX certification, seal maintenance and specialist-qualified service as part of the design.
- **Strain Portfolio and Rights Strategy:** Isolate or evolve a project-owned strain from environmental samples or adaptive laboratory evolution, deposit it in a public collection under open terms, and compare it against the public reference strain.
- **Replication Design and Gate Governance:** Add an early paper-and-bench replication in Phase Two, in which an independent group builds a small unit from draft documents, to find documentation defects before committing to full-scale construction.
- **Deployment Scenario Anchoring and Threshold Locking:** Appoint an independent adversarial review panel that sets and holds the scenario thresholds, and allow it to add a harsher scenario once Phase Two data are available but never to relax any existing one.
- **Inherent Safety Design Basis and Adopter Change Boundary:** Publish a machine-readable safety case in which each parameter and component carries a computed safe-change envelope, so adopters can check a proposed modification against the hazard analysis before building it.

### The Safe Foundation
**Strategic Logic:** Prioritise stability, low cost and reduced legal and safety risk. Commit to one public-collection strain and a simple low-pressure pneumatic reactor, and design for inherently safer limits so that most failures cannot ignite without relying on instrumentation. Fund a single full-scale Kenyan replication only after gate reviewers confirm documentation readiness, and set thresholds from published alternatives. This is the cheapest and most defensible route to hypothesis A. It accepts lower productivity and a risk of late-found documentation defects, and it may end in Research Only if no deployment case clears the margin.

**Fit Score:** 5/10

**Assessment of this Path:** It is cheap, legally simple and safe, and suits hypothesis A. It commits to one pneumatic design and one strain without measuring alternatives, so it cannot report the simplification cost or support hypothesis B. A late-only replication risks discovering documentation defects after construction, and thresholds taken only from published data lack adopter input.

**Key Strategic Decisions:**

- **Gas-Liquid Contacting and Reactor Concept:** Develop a low-pressure pneumatic loop or bubble-column reactor with no mechanical agitation, and accept lower volumetric productivity in exchange for simpler repair and a smaller hazardous zone.
- **Strain Portfolio and Rights Strategy:** Commit to a single public-collection reference strain, document its rights for research, commercial use, redistribution and modification, and confirm lawful import into Kenya before any design freeze.
- **Replication Design and Gate Governance:** Run one full-scale Kenyan replication after the Danish reference unit is complete, using a separate team under an audited assistance log, and fund it only after the gate reviewers confirm documentation readiness.
- **Deployment Scenario Anchoring and Threshold Locking:** Derive scenarios from published cost data on protein reserves, legumes and proprietary systems, and lock thresholds as the margin the open design needs over the best defensible alternative in each case.
- **Inherent Safety Design Basis and Adopter Change Boundary:** Design the process around inherently safer limits, such as keeping gas mixtures outside flammable ranges and minimizing gas inventory, so most failures cannot reach an ignitable state without relying on instrumentation.
