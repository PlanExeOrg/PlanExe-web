
## Documents to Create

### 1. Project Charter

**ID:** e1fc9ced-7427-462c-8f26-cb3daa261772

**Description:** Formal authorization document establishing project authority, objectives, success criteria, scope boundaries, and stakeholder roles for The Open Protein Module programme. Intended audience: funder, host institution, Kenyan partner, independent gate-review panel. Establishes the EUR 50M ceiling, Month 60 (2031-10-09) end date, two hypotheses (A: local technician operation; B: decentralized modules), kill-gate framework, and the requirement that all partners and permits remain unsigned until formally committed.

**Responsible Role Type:** Project Director

**Primary Template:** PMI Project Charter Template

**Secondary Template:** World Bank Project Charter for Infrastructure R&D

**Steps:**

- Confirm funder, host institution and Kenyan partner authorization to issue charter
- Consolidate goal statement, scope, constraints (EUR 50M ceiling, Month 60 = 2031-10-09 end, kill gates), success criteria and stakeholder roles from strategic-decisions and project-plan documents
- Document the two hypotheses (A: local technician operation; B: decentralized modules) as explicit testing objectives
- List all assumptions on unsigned partners, permits, and funding; state that continuation is conditional on signed agreements
- Include the kill-gate framework: Phase One gate Month 10 (2027-08-09), Phase Two gate Month 30 (2029-04-09), Phase Three gate Month 60 (2031-10-09), with written continue/modify/research-only/stop decisions
- Define role boundaries: project director, lead process engineer, Kenyan co-development partner, independent gate-review panel (3–5 members, funder-managed)

**Approval Authorities:** Funder, host institution director, Kenyan partner organizational head

### 2. Strain Feasibility Report

**ID:** d05b6f63-7049-481d-98d1-52444b0230aa

**Description:** Comprehensive analysis of candidate reference strains' lawful obtainability, intellectual property status, biosafety classification, and provisional productivity performance. Deliverable at Month 4 (2027-02-09). Intended audience: funder, gate-review panel, Kenyan co-developer, regulators. Names primary and legally clean backup strain with documented rights for research, commercial production, redistribution, modification and derived strains in Denmark, EU and Kenya; includes written Kenyan biosafety authority feedback and contingency decision rules.

**Responsible Role Type:** Strain Rights and Regulatory Affairs Specialist (with support from legal counsel and biotech regulatory consultant)

**Primary Template:** Biotech IP Rights and Regulatory Feasibility Assessment Template

**Secondary Template:** Strain Material Transfer Agreement Analysis Template

**Steps:**

- By Month 0.5 (2026-10-24), initiate direct contact with holders of 4–5 candidate strains (C. necator H16, C. metallidurans, Hydrogenovibrio, and fallbacks); request written confirmation of lawful rights per use (research, commercial, redistribution, modification, derived strains) in Denmark, EU and Kenya
- By Month 1 (2026-11-09), commission a specialized patent-search firm to conduct a landscape search across Denmark/EU, Kenya and Bangladesh identifying third-party claims on hydrogen fermentation, autotrophic protein production and each candidate strain; deliver report by Month 2 (2026-12-09)
- By Month 2.5 (2026-12-24), contact Kenya's National Biosafety Authority with a 5-page process summary and candidate-strain list; request written pre-submission feedback on biosafety classification, contained-use requirements and import restrictions by Month 4 (2027-02-09)
- By Month 3.5 (2027-01-24), consolidate all strain-holder responses, patent findings and Kenya biosafety feedback; if primary strain shows barriers (medium or high freedom-to-operate risk), immediately initiate bench comparison of primary and backup strain (2–3 week run)
- By Month 4 (2027-02-09), deliver final report naming primary strain and at least one legally clean backup strain with: written rights per use and jurisdiction, documented Kenyan import feasibility, patent risk assessment (low/medium/high per jurisdiction), and contingency decision rule (e.g., if primary moves to medium risk, trigger backup switch; if high risk, escalate to gate panel)
- Include preliminary bench productivity data (growth rate, oxygen-uptake rate, nucleic acid content) for at least primary and backup strains under standard conditions to ensure backup is performance-viable, not just legal-clean
- If unresolved barriers remain at Month 4 (2027-02-09), escalate immediately to funder and independent gate panel with named barrier and fallback strategy; do not proceed to Phase One gate without strain confirmation

**Approval Authorities:** Funder, independent gate-review panel (strain rights assessment); Kenya National Biosafety Authority (biosafety classification, import feasibility)

### 3. Process Hazard Analysis (HAZOP) and Safety Design Basis Document

**ID:** 73ca7ba8-653d-44cd-8a15-44bc56e2012e

**Description:** Formal Process Hazard and Operability Analysis (HAZOP) or Layers of Protection Analysis (LOPA) identifying all failure modes in hydrogen-oxidizing bacteria fermentation (electrolyzer, gas handling, ignition sources), ranking them by severity and likelihood, and specifying design responses. Establishes quantitative 'Design Basis for Safety' with gas composition and inventory limits, pressure ceilings, safe-shutdown protocols and independent interlock requirements. Deliverable by Month 2.5 (2026-12-24). Intended audience: design engineers, safety regulators, ATEX compliance reviewers, gate-review panel.

**Responsible Role Type:** Process Safety Engineer (ATEX-certified independent consultant, not employed by host institution or project)

**Primary Template:** HAZOP Study Report Template (IEC 61882 / CCPS Guidelines)

**Secondary Template:** LOPA Worksheet Template (IEC 61511 / CCPS)

**Steps:**

- By Month 1 (2026-11-09), commission an independent, ATEX-certified safety consultant (no prior project involvement, no employment ties to host or funder) with written scope of work and deliverable date Month 2 (2026-12-09)
- Conduct a structured HAZOP using standard methodology (IEC 61882), covering: hydrogen production and storage in electrolyzer, oxygen co-product stream, hydrogen-oxygen mixing in gas-handling lines and fermentor headspace, ignition sources (electrolyzer malfunction, gas-line rupture, seal failure, backflow on power loss, operator error), and failure-mode consequences (ignition, pressure excursion, toxic exposure, environmental release)
- Rank each failure mode by severity (catastrophic, critical, major, minor) and likelihood (frequent, probable, occasional, rare); identify design responses (inherent elimination, design change, layered protection, procedures/training)
- Translate HAZOP findings into quantitative 'Design Basis for Safety' by Month 2.5 (2026-12-24) specifying: gas composition limits (e.g., <4% O₂ in H₂-rich stream, or >60% inert), gas-inventory limits (e.g., <0.5 m³ H₂ and <0.2 m³ O₂ system-wide), pressure limits (no operation >2 bar without independent overpressure relief), safe-shutdown logic (vent fermentor gas, stop electrolysis, purge within 30 seconds on power loss), and independent interlock and emergency-shutdown specifications
- Quantify a residual-risk target (e.g., probability of uncontrolled ignition <1 per 100,000 operating hours) and verify the proposed control strategy meets this target
- Ensure the Design Basis for Safety applies consistently to all three reactor concepts (pneumatic, stirred, passive-feed) so that safety is not a hidden design advantage of one concept
- Document all assumptions on seal integrity, electrolyzer reliability, control-system failure modes and human error with uncertainty ranges
- Obtain written sign-off from the independent safety consultant confirming the design basis is adequate and consistent with ATEX Directive 2014/34/EU (or equivalent)

**Approval Authorities:** Independent ATEX-certified safety consultant; host institution safety officer; potential regulatory contact (Danish EPA or equivalent)

### 4. Adopter Change Boundary Document

**ID:** 98fed0a7-9522-46be-8d51-84e4873942f1

**Description:** Explicit, detailed guidance specifying which design components and parameters adopters may safely change or substitute without requiring full safety re-analysis, and which are safety-critical and require formal re-certification. Deliverable by Month 3 (2027-01-09). Intended audience: replicators, deployers, regulatory authorities, project team. Protects both adopters (clear guidance on modification scope) and the project (liability protection against unsafe local adaptation).

**Responsible Role Type:** Process Safety Engineer (with lead process engineer)

**Primary Template:** Safety Change Boundary and Conformity Assessment Template

**Steps:**

- Use the HAZOP findings and Design Basis for Safety to categorize all major design elements (gas-handling components, electrolyzer type, reactor type, seals, pressure relief, control system, sensors, interlocks, emergency shutdown)
- For each element, determine: (a) Is it safety-critical (directly linked to the residual-risk target)? (b) Is it performance-critical (affects productivity or cost beyond ±10% tolerance)? (c) Is it substitutable (equivalent components available with documented specifications)?
- Classify elements into three categories: (1) Safety-locked (cannot be changed; examples: gas composition targets, pressure limits, electrolyzer type, seal materials for H₂/O₂ exposure); (2) Pre-assessed substitutes (adopter may use equivalent items on a documented pre-approved list; examples: electrode material if electrical conductivity ≥95% of reference, pump brand if rated for identical flow/head); (3) Open (adopter may adapt within documented design margin; examples: PLC software confined to parameter-input layer, local nitrogen-source substitution if purity confirmed)
- For each pre-assessed substitute, document the acceptance criteria (specification, testing procedure, failure mode if exceeded)
- State explicitly: 'Any change not listed as pre-assessed or open requires formal safety re-analysis by a qualified safety engineer before implementation.'
- Publish the Change Boundary in at least two formats: (1) a tabular reference guide (component/parameter, category, acceptance criteria if applicable); (2) a narrative guidance document for non-technical adopters
- Cross-reference the boundary to the HAZOP findings and the Design Basis for Safety so every constraint is traceable to a specific hazard or performance requirement
- Obtain sign-off from the independent safety consultant confirming the boundary is consistent with the HAZOP and the intended adopter skill level (locally trained technicians per Hypothesis A)

**Approval Authorities:** Independent safety consultant; host institution; potentially Kenya National Biosafety Authority if contained-use classification depends on design limits

### 5. Measurement and KPI Framework

**ID:** a952b7d3-da46-4426-864b-c37710d342b6

**Description:** Locked specifications for all key performance indicators (KPIs) used to benchmark the technology against published alternatives and to evaluate hypothesis testing. Defines exact definitions, system boundaries, measurement methods, analytical standards, sampling frequency and capacity-utilization assumptions for volumetric productivity, mass-transfer coefficient (kLa), energy per kg dry biomass, oxygen-uptake rate, nucleic acid content, and digestibility. Aligned with at least two published benchmarks to ensure defensible comparison. Locked by Month 1.5 (2026-11-24) with external auditor sign-off before any bench experiments begin. Intended audience: process engineers, analysts, gate-review panel, adopters.

**Responsible Role Type:** Techno-Economic Modeler and Lead Process Engineer (with external auditor)

**Primary Template:** ISO 20915 and bioprocess KPI definition standard

**Secondary Template:** NREL Hydrogen and Bioprocess Techno-Economic Analysis Templates

**Steps:**

- For each KPI, document: (a) name and units; (b) definition and formula; (c) system boundary (which components included: electrolyzer only, fermenter only, fermenter+downstream, or full system); (d) capacity-utilization assumption (% of nameplate capacity at which the metric is measured); (e) operating mode (continuous, fed-batch, intermittent); (f) measurement method (instruments, sampling frequency, data processing)
- Identify at least two published benchmarks (from peer-reviewed literature or industrial reports) for each KPI and document their definitions and boundaries; if definitions differ significantly, justify why the project's definition is preferred or note the incompatibility
- For KPIs with high sensitivity to definition (e.g., 'energy per kg' can vary 2–3× depending on whether downstream processing is included), state this explicitly and explain which definition is locked for this programme
- Specify measurement uncertainty ranges (e.g., ±15% for productivity, ±10% for kLa) based on typical analytical precision for the method
- Lock this framework in writing by Month 1.5 (2026-11-24); do not adjust measurement methods after bench experiments begin
- Have an external auditor (not employed by the project) review and sign off on the framework, confirming alignment with published benchmarks and internal consistency
- Distribute to all team members and publish a summary on the project website

**Approval Authorities:** Lead process engineer, techno-economic modeler, external auditor (sign-off required before Phase One bench work begins)

### 6. Matched Reactor Selection Decision Protocol

**ID:** 8c195df4-98b0-44e6-8730-54a250e1065e

**Description:** Pre-registered written protocol specifying the exact decision thresholds and methodology for selecting which of three reactor concepts (pneumatic loop, pressurized stirred, passive-feed) will be the basis for the Phase Three reference unit. Locked by Month 2.5 (2026-12-24) before bench data arrive. Specifies: productivity and simplicity comparison rules, ATEX compliance check, cost-impact analysis, decision criteria (if productivity gap <15% choose simpler; 15–25% weighted score; >25% choose highest unless ATEX barriers), and explicit prohibition on post-hoc threshold adjustment. Intended audience: process engineer, gate-review panel, external auditors.

**Responsible Role Type:** Lead Process Engineer (with TEA lead and independent technical auditor)

**Primary Template:** Design Selection and Evaluation Decision Matrix Template

**Steps:**

- Specify the three reactor concepts and their key design trade-offs: pneumatic (simplicity, lower power, but potentially capped productivity); stirred (high productivity, but ATEX complexity, sealing burden); passive-feed (simplicity, but unproven mass transfer at scale)
- State the identical test conditions for all three concepts: reference strain (C. necator H16 or confirmed alternative), identical medium, identical inoculum density, identical operating conditions (30°C, pH 7.0–7.2, aeration 0.1–0.5 vvm), minimum 7 days to steady state, triplicate runs
- Lock the comparison metrics: volumetric productivity (g/L/day), specific growth rate (1/h), kLa (h⁻¹), oxygen-uptake rate (mmol/L/h), energy per kg dry biomass, nucleic acid content
- Pre-register decision thresholds in writing: 'If volumetric productivity differs by <15% between concepts, design simplicity (fewer moving parts, lower ATEX burden, faster local repair) is the primary selection criterion. If 15–25%, use weighted scoring: 60% productivity, 30% simplicity, 10% safety. If >25%, highest-productivity concept is selected unless ATEX compliance barriers prevent certification or the simpler concept still meets the locked cost threshold EUR 12/kg usable protein.'
- Specify ATEX compliance check: which reactor concept(s) can meet the Design Basis for Safety? Are there trade-offs (e.g., stirred design meets productivity but requires expensive seals)? If a concept cannot meet the safety basis, rule it out before cost comparison
- Assign a single lead analyst responsible for all sample preparation, analysis, and data processing across the three concepts to minimize inter-operator variation (typical scatter 20–30%)
- Conduct independent external technical audit of protocol adherence and decision-threshold application before publishing results
- Commit that thresholds are not adjusted after data arrive; if early results suggest a threshold is inappropriate, escalate to the independent gate-review panel for revision before proceeding, but do not unilaterally change the criterion

**Approval Authorities:** Lead process engineer; external auditor; independent gate-review panel (must endorse thresholds before bench data arrive)

### 7. Deployment Scenario Specification

**ID:** 90bac15f-8f87-4c5d-9a08-b631774b8fbf

**Description:** Time-stamped, signed document naming 2–3 prospective adopters and their locked deployment thresholds (maximum cost per kg usable protein, minimum capacity, required uptime, operating-envelope constraints). Each scenario includes: adopter name and mandate, cost basis (current supply chain cost, cost benchmark used to derive the threshold), capacity need and uptime requirement, any co-funding or subsidy commitment, and a withdrawal clause. Locked by Month 9 (2027-07-09). Intended audience: gate-review panel, funder, adopter organizations, project team. Provides the binding reference for the Phase Three Go decision: at least one scenario must be met for Go to be justified.

**Responsible Role Type:** Adoption Economist and Kenyan Co-Development Partner Lead

**Primary Template:** Stakeholder Engagement and Commitment Letter Template

**Secondary Template:** Scenario Development and Threshold-Locking Template

**Steps:**

- By Month 2 (2026-12-09), identify 2–3 named candidate adopters with published mandates in food security, emergency nutrition, or regional livestock feed (examples: national grain-reserve authority, humanitarian logistics organization, East African feed producer)
- By Month 4 (2027-02-09), conduct structured in-person or virtual interviews with each adopter: current protein supply source and cost (with audited documentation if possible), required production capacity (kg/day), required uptime (%), power and water constraints, willingness to adopt an open design, cost premium for vendor independence, and any subsidy or co-funding availability
- By Month 6 (2027-04-09), consolidate adopter input into 2–3 scenario profiles; for each scenario, present: (1) adopter name; (2) current supply chain baseline (cost EUR X/kg, source, capacity Y, uptime Z%); (3) proposed threshold (cost EUR A/kg, capacity B, uptime C%, operating envelope); (4) cost sensitivity ('would you adopt at EUR 12/kg? EUR 15/kg? What is your threshold?'); (5) co-funding availability or subsidy commitment
- By Month 7 (2027-05-09), obtain signed written commitment from each adopter stating: 'We commit to these thresholds for Scenario [name]: cost ≤EUR X/kg, capacity ≥Y kg/day, uptime ≥Z%, provided that [any condition, e.g., government subsidy is available]. These thresholds are immutable unless [named parties] formally agree in writing to change them. We acknowledge that failure to meet these thresholds may result in a Modify or Research Only gate decision.'
- Include a withdrawal clause: 'If circumstances change and this scenario is no longer feasible, we will provide 30 days' written notice to the project. The project will publish our withdrawal and request the independent gate-review panel to re-assess whether remaining scenarios remain viable for a credible Go decision.'
- By Month 9 (2027-07-09), finalize the 'Deployment Scenario Specification' document consolidating all three scenarios with adopter signatures, locked thresholds, cost basis, and withdrawal clauses. Time-stamp and publish to all stakeholders.
- Present to the independent gate-review panel by Month 9 (2027-07-09) for assessment: 'Are these scenarios credible? Do the adopters' thresholds align with their stated mandates and financial constraints? Are the scenarios realistic given the modeled costs?'

**Approval Authorities:** Named adopter organizations (signatures required); funder (acknowledgment); independent gate-review panel (credibility assessment)

### 8. Gate-Review Panel Charter and Authority Delegation

**ID:** b5c9a321-fd14-4c09-ad1f-82471d1f9b43

**Description:** Formal written charter establishing the independent gate-review panel's composition, recruitment, conflict-of-interest protocols, funding source and separation, decision authority, publication and override procedures, and escalation rules. Signed by the funder by Month 1.5 (2026-11-24) before any panel members are named. Intended audience: funder, host institution, panel members, stakeholders. Ensures panel independence, binding authority and transparency of gate decisions.

**Responsible Role Type:** Funder (with project director and legal counsel)

**Primary Template:** Independent Review Panel Charter and Authority Delegation Template

**Secondary Template:** Research Programme Governance and Conflict-of-Interest Protocol

**Steps:**

- Specify panel composition: 3–5 members with diverse expertise (process engineer, ATEX safety specialist, biotech regulatory consultant, adoption economist, optionally product expert). Each member must have: (a) no employment or funding ties to the host institution; (b) no prior involvement in the project design; (c) published expertise or track record in the relevant domain; (d) no financial stake in the project's outcome (honoraria only, capped)
- Specify recruitment process: open call via established scientific networks, competitive selection, conflict-of-interest screening, and written vetting by the funder (not the host)
- Define funding source and separation: EUR 0.30M total over 5 years (Phase One share EUR 0.06M) held in a separate funder-managed account, not flowing through the host institution or project budget; prevents implicit pressure on panel members to recommend continuation to protect their own employment
- Define each panel member's term: fixed 5-year term (all phases), no renewal, no ongoing relationship after project end; provides independence and prevents 'renewal bias' toward continuation
- Specify decision authority: 'The panel produces a joint written recommendation (continue, modify, research-only, or stop) at each gate [Phase One Month 10 = 2027-08-09, Phase Two Month 30 = 2029-04-09, Phase Three Month 60 = 2031-10-09]. The recommendation is based on evidence against pre-defined gate-pass criteria locked by Month 2 (2026-12-09) and not changeable retroactively. All panel members sign the recommendation.'
- Specify funder's obligation: 'The funder's default action is to release funds if the panel recommends 'continue' and to withhold funds if the panel recommends 'stop' or 'modify.' Any deviation requires funder board decision and public written justification within 5 working days, published alongside the panel's recommendation.'
- Specify panel's rebuttal right: 'The panel may issue a joint rebuttal to the funder's justification within 10 working days, also published, if the panel judges the funder's reasoning to be unsupported by evidence.'
- Specify escalation for repeated overrides: 'If the funder overrides a 'stop' or 'modify' recommendation at any gate, a second independent panel review (separate panel, same charter) is required before funds are released at the next gate. This prevents systematic momentum-driven continuation.'
- Specify publication requirements: 'All gate recommendations, funder decisions, and any deviations or rebuttals are published on the project website and in annual reports to all stakeholders within 10 working days of the decision.'
- Include conflict-of-interest clause: 'Each panel member signs a written declaration stating: (a) no employment or ongoing funding dependence on the host, funder or project; (b) no financial interest in the project's outcome; (c) no prior involvement in design decisions. Panel members are required to recuse themselves from votes on any matter where a conflict exists and to notify the panel chair immediately if a conflict arises mid-project.'
- Obtain funder's signature and board approval by Month 1.5 (2026-11-24) before any gate-panel recruitment begins

**Approval Authorities:** Funder (board or executive decision authority); host institution (acknowledgment of the funder's independent authority); panel members (signature on charter and conflict-of-interest declaration)

### 9. Kenyan Operating Envelope Baseline Study Report

**ID:** d7712d5c-eca8-4a70-b579-fa04aafc5b9a

**Description:** Independent, time-stamped baseline assessment of the Kenyan replication site's operating conditions across six dimensions: grid power outage frequency and duration, water supply quality, ambient temperature and humidity, local spare-part availability and lead times, available technician skills, and security/access. Deliverable by Month 4 (2027-02-09). Intended audience: project team, gate-review panel, Kenyan partner, hypothesis B evidence assessors. Documents the baseline against which Phase Three measurements are compared to assess whether the site truly tests the defined operating envelope.

**Responsible Role Type:** Independent Site-Selection Consultant (not employed by the Kenyan partner or host institution)

**Primary Template:** Infrastructure Assessment and Site Baseline Report Template

**Secondary Template:** Utility Supply and Logistics Feasibility Study Template

**Steps:**

- Commission the independent site-selection consultant by Month 1 (2026-11-09) with a written scope and Month 4 (2027-02-09) deliverable deadline
- For grid power: obtain 24–36 months of historical outage logs from the local utility or via interview with utility staff, documenting each outage's date, duration, cause and whether it was planned or unplanned. Calculate frequency (target ≥4 unplanned outages/month), mean duration (target ≥2 h) and extreme events (≥1 outage/quarter lasting >8 h). Document reliability trend (improving, stable, or degrading)
- For water supply: conduct 3–4 months of monthly sampling for turbidity, conductivity, pH, iron and manganese content; compare against the process requirement (estimated: <10 NTU turbidity, conductivity within ±20% of medium specification, pH 6.5–7.5, iron <1 mg/L). Document seasonal variation if any
- For ambient conditions: record temperature (target 15–30°C, 10–50°C acceptable with caveats) and relative humidity (target 40–80%) over at least 2–4 months covering any seasonal extremes. Document if cooling water or heat rejection will be challenged
- For spare parts: interview 10+ potential local suppliers (electrical, mechanical, laboratory consumables, membrane, gas equipment) to identify what is available locally, lead times for regional or import items, minimum order quantities and costs. Confirm availability of at least 2 alternative suppliers for each critical component (spare estimate: electrolyzer membranes, gas-line fittings, seals, pump components, PLC modules). Target lead time ≤2–4 weeks; flag any lead time >8 weeks as a risk
- For technician skills: identify and interview 5–10 prospective local technicians (electricians, mechanics, laboratory technicians) confirming education level, prior experience, languages, availability for training and willingness to commit for 1–2 years. Assess current capabilities (can they use a multimeter? read schematics?) and training need (weeks or months to reach competency?)
- For security and access: assess political stability, security environment, accessibility for international staff, communication (mobile, internet reliability), and any regulatory or permitting barriers specific to the site
- Consolidate findings into a signed, time-stamped baseline report documenting: (a) which envelope targets (outage frequency, water quality, spare-part availability, technician skills) are met, not met, or borderline; (b) for any shortfall, describe contingency (e.g., if local spare-part availability is poor, design for longer stock-holding or supplier relationships); (c) baseline values for each parameter to be tracked quarterly in Phase Three; (d) consultant's independence statement and conflicts-of-interest declaration
- Establish a 'Quarterly Site Envelope Monitoring Protocol' specifying: monthly power-outage logs collected from utility, quarterly water quality sampling, quarterly check-ins with technicians on training progress, semi-annual supplier queries on lead times and availability, semi-annual security assessment. Delegate monitoring to the Kenyan site manager and report to the project director quarterly

**Approval Authorities:** Independent site-selection consultant (sign-off required); Kenyan site chosen based on this report; funder and gate-review panel review before commitment to Phase III

### 10. Documentation Defect Tracker and Audited Assistance Log

**ID:** e9f23f96-16bf-44ca-9583-9b8ecb31b8eb

**Description:** Electronic database (or shared issue-tracking system) recording every documentation gap, ambiguity or error discovered during Phase II early replication and Phase III full-scale Kenyan build, plus all external assistance provided to the Kenyan team. Operational by Month 11 (2027-09-09). For each defect: location in documentation, description, severity (critical/major/minor), resolution method, responsible party, resolution date, auditor sign-off. For each assistance event: date, parties involved, topic, duration, outcome, whether pre-planned or emergency response, auditor verification. Intended audience: project team, independent auditor, gate-review panel, replication team.

**Responsible Role Type:** Project Manager (tracker administration) and Independent Third-Party Auditor (monthly review and sign-off)

**Primary Template:** Engineering Defect Tracking and Compliance Log Template

**Secondary Template:** Project Assistance Log and External Engagement Register

**Steps:**

- By Month 11 (2027-09-09), establish an electronic defect tracker accessible to Danish and Kenyan teams and the independent auditor (shared cloud database or issue-tracking software such as Jira or Asana). Define field structure: defect ID, location in documentation (drawing name, section, page), description, severity (critical = halts work or safety risk; major = unclear but workaround found; minor = typographical), source (replicator encounter during build, design engineer observation, auditor review), resolution method (documentation fix, design clarification, work-around, or inference), responsible party, target resolution date, actual resolution date, auditor sign-off
- Establish severity thresholds: critical defects (safety-critical gaps, unsigned dimensions, missing component specifications) must be resolved before proceeding; major defects (ambiguous prose, out-of-sequence drawings) must be resolved before Phase III full-scale; minor defects (typographic errors, formatting) resolved before publication
- By Month 13 (2027-11-09), begin Phase II early replication (1–10 L pilot reactor) with Kenyan team building from documentation alone without developer hands-on guidance. Assign the replicator to log every ambiguous or missing instruction in the tracker immediately, with time-stamp and proposed resolution
- Establish an 'audited assistance log' within the same tracker for recording all external help: date, people involved (Danish staff, third-party specialists), topic (safety review, equipment troubleshooting, regulatory consultation, design clarification), duration, outcome, whether pre-planned or emergency, auditor verification that assistance stayed within the 'acceptable' category (planned safety reviews, regulatory consultation; not routine hands-on operation)
- By Month 16 (2028-02-09), appoint an independent auditor (not employed by project, host or Kenyan partner) to review the defect log monthly, assess resolution adequacy, flag patterns (e.g., all electrical drawings ambiguous) and report to the project director
- Monthly auditor review includes: (a) count of defects by severity; (b) average time-to-resolution per severity; (c) assessment of resolution quality (was the fix actually sufficient, or just a band-aid?); (d) patterns suggesting systematic documentation gaps (all reactor drawings vague, all software procedures missing); (e) any unresolved critical defects blocking Phase III
- By Month 20 (2028-06-09), produce a 'Documentation Readiness Assessment' signed by the auditor, stating: number and severity of unresolved defects, assessment of whether Kenyan team can build Phase III unit from documentation, recommended maximum acceptable defect rate for gate approval (e.g., '0 safety-critical, ≤3 critical, ≤10 minor'), and any process or documentation categories requiring re-work before Phase III proceeds
- Present the audited defect log and readiness assessment to the independent gate-review panel at the Phase Two-to-Phase Three gate (Month 30 = 2029-04-09). Require the panel to explicitly approve documentation readiness with a written clause confirming acceptable defect threshold before Phase III proceeds

**Approval Authorities:** Independent auditor (monthly certification of defect log and assistance log); gate-review panel (Phase Two gate: approval of documentation readiness based on audited defect assessment)

### 11. Regulatory Pathway and Freedom-to-Operate Report

**ID:** 0c5e674c-945d-4bbe-a3d6-b44c7a013325

**Description:** Jurisdiction-by-jurisdiction assessment of regulatory requirements and patent landscape for experimental operation (contained-use permits), product-safety validation (composition and digestibility dossiers), commercial distribution, and strain biosafety classification. Covers Denmark/EU, Kenya and Bangladesh. Deliverable by Month 4 (2027-02-09) with follow-up updates as regulations change. Intended audience: project team, gate-review panel, product strategy stakeholders. Identifies hard blocking requirements early and informs product-category selection and regulatory engagement sequencing.

**Responsible Role Type:** Strain Rights and Regulatory Affairs Specialist (with biotech regulatory consultant)

**Primary Template:** Regulatory Requirements and Freedom-to-Operate Assessment Template

**Secondary Template:** Multi-Jurisdiction Product Safety Approval Pathway Comparison

**Steps:**

- Commission a specialist regulatory and patent-landscape firm by Month 1 (2026-11-09) to conduct detailed analysis across Denmark, EU (EFSA competent authority, national food/feed authorities), Kenya and Bangladesh
- For each jurisdiction, document: (a) organism/strain classification (wild-type, genetically modified, contained-use approval required?); (b) experimental operation permits (contained-use authorization timelines and requirements); (c) product-safety approval pathway per category (animal feed, fish feed, food ingredient, emergency nutrition), including required composition studies, digestibility testing, allergenicity assessment, microbial safety limits; (d) commercial distribution authorization timeline and conditions; (e) any tariffs or trade restrictions on novel proteins; (f) patent landscape (claims on hydrogen fermentation, autotrophic protein production, strain-specific use)
- Quantify risk per pathway: identify any hard blockers (e.g., 'EU will not authorize novel protein without 90-day mammalian toxicity study = 6 month lead time and EUR 100k cost'), conditional pathways (e.g., 'Kenya has established animal-feed approval route; novel feedstuff submitted to KEBS, decision within 6 months if composition is documented'), and unestablished pathways (e.g., 'emergency nutrition category is not yet defined in Kenya, requiring pilot discussions with Ministry of Health')
- For each candidate product category (animal feed, fish feed, food ingredient, emergency nutrition), specify the data package required to enter formal review: composition analysis (protein, nucleic acid, amino acids, minerals, fatty acids), digestibility study (in-vitro or feeding trial), safety tests if applicable (acute toxicity, allergenicity, microbial limits), manufacturing process description, quality control plan, labeling, and post-market surveillance
- Consolidate findings into a matrix: jurisdiction vs. product category, with pathway type (established, conditional, unestablished), required data, timeline (in months from application to authorization) and cost estimate (EUR)
- Identify the highest-risk pathways (e.g., 'food ingredient in EU requires 2 years and EUR 500k for full safety dossier') and the lowest-risk pathways (e.g., 'animal feed in Kenya via KEBS if composition is documented, 6 months, EUR 50k')
- Specifically document strain/organism biosafety requirements: is the reference strain wild-type (lower barrier) or modified (higher barrier)? Does it require contained-use authorization before any scale-up? Can it be imported into Kenya, or does import require special permission? Are there any material transfer agreement restrictions on commercialization or redistribution?
- Include a patent landscape summary: identify any third-party patents on hydrogen fermentation, autotrophic protein, or the specific strain in Denmark, EU, Kenya and Bangladesh, scored by likelihood of infringement and impact (blocking vs. negotiable)
- Deliver a final 'Regulatory Feasibility Assessment' by Month 4 (2027-02-09) naming which product categories are realistically achievable in which jurisdictions, which require long lead times or high cost, and which are blocked or very high-risk. Use this to inform the provisional product-category choice at the Phase One gate
- Establish a quarterly regulatory monitoring process: assign responsibility for tracking new government guidance, regulatory changes or court decisions that could affect the project's product category or strain classification. Alert the project and gate panel immediately if a material change is announced

**Approval Authorities:** Strain rights and regulatory specialist; biotech regulatory consultant; potentially informal pre-submission feedback from Danish EPA or Kenya National Biosafety Authority

### 12. Techno-Economic Cost Model and Sensitivity Analysis Report

**ID:** 14bd70e5-98d3-4346-8463-fd5f9228e74c

**Description:** Comprehensive cost model connecting bench-scale productivity to deployment-scenario feasibility at 100 kg/day usable protein capacity (or alternative deployment units). Quantifies system-level cost per kg (electrolyzer + fermenter + downstream + capex + overhead + financing) under base-case assumptions and sensitivity scenarios (electricity price EUR 0.05–0.15/kWh, downstream energy reduction, module scaling). Identifies the EUR 7.93/kg cost gap versus EUR 12 scenario cap and assesses whether credible reduction paths exist. Deliverable by Month 9 (2027-07-09) with interim findings Month 6 (2027-04-09). Intended audience: funder, adopters, gate-review panel, project leadership.

**Responsible Role Type:** Techno-Economic Modeler and Cost Analyst

**Primary Template:** Techno-Economic Analysis and Sensitivity Model Template (NREL, IEA biotech cost-analysis frameworks)

**Secondary Template:** Monte Carlo Cost Uncertainty and Probability Distribution Template

**Steps:**

- By Month 3 (2027-01-09), consolidate baseline cost assumptions from bench productivity data, equipment specifications and published benchmarks: electrolyzer capex and efficiency, fermenter capex and operating cost, downstream processing (harvest, nucleic acid reduction, drying) capex and energy, staff cost, nitrogen source, minerals, water treatment, membrane replacement cycles, waste handling. Specify the system boundary (which components included: fermenter only, fermenter+downstream, full electrolyzer+fermenter+downstream?)
- Model the base-case deployment unit: 100 kg usable protein/day (200 kg dry biomass/day nameplate), ~50% utilization = 34,675 kg usable protein/year. Calculate: annual electricity consumption (dry biomass 34,675 × 2 kg dry per kg usable × 40 kWh/kg dry = 2,774,000 kWh/year), annual electricity cost (2,774,000 kWh × EUR 0.08/kWh = EUR 221,920), non-electric opex (staff EUR 100k, inputs EUR 50k, maintenance EUR 30k), capex installed cost (EUR 3.0M estimated), debt service at 5% / 15 years (EUR 289k/year), total annual cost = EUR 601,920, unit cost = EUR 12.27/kg usable protein
- Note: base-case model shows full cost EUR 19.93/kg per the canonical facts; reconcile difference (if any) by identifying which cost driver is underestimated (downstream energy, capex, or other). If reconciliation is impossible, flag the discrepancy and revise the model
- Conduct sensitivity analysis on key cost drivers: (a) electricity price: from EUR 0.05/kWh (solar, best-case) to EUR 0.15/kWh (grid, worst-case); note the impact on total cost per kg (estimated sensitivity ~EUR 3–4/kg per EUR 0.01/kWh change); (b) downstream energy: from 40 kWh/kg current assumption to 20 kWh/kg (thermal nucleic acid reduction) or 60 kWh/kg (enzymatic); (c) scaling: model 50 kg/day and 200 kg/day units and assess how fixed capex leverage affects total cost; (d) capacity utilization: model 70%, 85%, and 95% annual utilization and assess impact on unit cost
- Present interim sensitivity findings at Month 6 (2027-04-09): 'Under best-case assumptions (EUR 0.05/kWh electricity, downstream energy 20 kWh/kg, 95% utilization, scaled learning on capex), estimated cost is EUR 11–12/kg, meeting Scenario A threshold. Under conservative assumptions (EUR 0.12/kWh, downstream energy 60 kWh/kg, 70% utilization, no learning), estimated cost is EUR 18–24/kg, exceeding all scenario thresholds.' Identify which assumptions are controllable (solar coupling, downstream design) vs. uncontrollable (grid electricity price)
- By Month 9 (2027-07-09), produce final report with: (a) base-case cost model and sensitivity matrix; (b) credible cost-reduction pathways: identify which levers (electricity price, downstream energy, scale) can close the EUR 7.93/kg gap and at what confidence; (c) residual gap after all identified reductions; (d) funding-route recommendation: if gap cannot be closed to EUR 12/kg, recommend either (i) a named adopter or government subsidy to cover the EUR 274,820/yr operational gap, (ii) redesign to a smaller-capacity unit (50 kg/day) that might fit the cap, or (iii) a reduced Phase Three (Danish unit only, Research Only outcome) if no funding route is credible
- Document all assumptions, cost drivers and uncertainty ranges; specify which are from published sources vs. project estimates vs. contractor quotes. Include a scenario where the deployment cost remains EUR 19.93/kg (worst-case), showing the implications (no adopter without subsidy)

**Approval Authorities:** Funder (decision on gap-funding strategy); independent gate-review panel (assessment of cost-reduction credibility and deployment-scenario viability)

### 13. Phase One Gate Review Report

**ID:** d941574f-e84e-4667-bc35-ff8482145aff

**Description:** Comprehensive evidence summary presented to the independent gate-review panel at the Phase One gate (Month 10 = 2027-08-09) for the continue/modify/research-only/stop decision. Consolidates all Phase One deliverables: strain feasibility, HAZOP and safety design basis, matched reactor productivity results, regulatory pathway assessment, Kenyan site envelope baseline, locked deployment scenarios, KPI framework, cost model, blueprint v0.1 outline, and gate-pass criteria assessment. Intended audience: independent panel, funder, host institution, Kenyan partner, stakeholders.

**Responsible Role Type:** Project Director (with technical leads and project manager)

**Primary Template:** Research Programme Gate Review Evidence Summary Template

**Secondary Template:** Technology Development Stage-Gate Assessment Report

**Steps:**

- By Month 9 (2027-07-09), assemble all Phase One deliverable documents: Strain Feasibility Report, HAZOP report and Design Basis for Safety, matched reactor results, regulatory pathway assessment, Kenyan site baseline, deployment scenarios, KPI framework, cost model, and preliminary blueprint outline
- Assess against pre-defined Phase One gate criteria (locked by Month 2 = 2026-12-09): (a) Strain rights: primary and backup documented? (b) Productivity: >=90% of published C. necator benchmark, or 70–90% for panel decision? (c) Kenyan biosafety: written feedback received and import feasible? (d) Reference-architecture: reactor selection rule applied to matched data; decision justified? (e) Safety: HAZOP complete, no open critical findings? (f) Scenarios: locked with named adopter signatures and immutability clause? (g) Product category: provisional category chosen with regulatory pathway identified? (h) Blueprint: v0.1 outline released with major subsystems and safety-critical components specified?
- For each criterion, document: criterion name, evidence provided, pass/fail/conditional, confidence level (high/medium/low), any caveats or residual risks
- Include a summary of key risks and contingencies: if strain becomes unavailable in Phase Two, EUR 0.15–0.30M fallback exists; if cost remains >EUR 12/kg, gap-funding route is [named]; if reactor scaling assumptions fail, Phase Two includes disproof experiments with pre-set failure thresholds; if Kenyan site envelope drifts, contingency stressors [specified]
- For cost gap specifically: state whether the EUR 3.0M capex gap (for Scenario A at EUR 12/kg cap) has a named funding route (adopter subsidy, government reserve fund, researcher grant) or whether Phase Three scope is approved as reduced (Danish only) or Research Only pending cost reduction; state the funder's binding decision
- Prepare a short (5–10 page) executive summary for the panel, consolidating the evidence and assessment; prepare detailed technical annexes (>50 pages) with all supporting data and analyses
- Schedule the Phase One gate panel meeting for Month 10 (2027-08-09) in-person or virtual, minimum 1–2 days, with all panel members, the project director, key technical leads and the funder present. Distribute all materials to panel members at least 4 weeks in advance (by Month 8.5 = 2027-06-24)

**Approval Authorities:** Independent gate-review panel (continue/modify/research-only/stop recommendation); funder (release decision)

### 14. Risk Register and Mitigation Plan

**ID:** 9639cc36-e13a-4607-88b4-1662f6a8461c

**Description:** Living document identifying all material project risks (safety hazard, strain rights barrier, regulatory block, scale-up failure, partner withdrawal, etc.), their likelihood (high/medium/low), severity (catastrophic/critical/major/minor), current mitigation status, and owner responsibility. Established by Month 2 (2026-12-09) and updated quarterly. Intended audience: project director, steering committee, independent gate-review panel, funder.

**Responsible Role Type:** Project Manager (with process safety engineer and risk-owner leads)

**Primary Template:** ISO 31000 Risk Register and Mitigation Plan Template

**Secondary Template:** Research Programme Risk Dashboard and Escalation Protocol

**Steps:**

- Identify high-consequence risks across five categories: (1) safety and hazard control (hydrogen-oxygen ignition, pressure rupture, contamination); (2) technical and scale-up (mass-transfer failure, productivity decline, energy-cost overrun); (3) organizational and partnership (partner withdrawal, host-priority shift, staff turnover); (4) regulatory and legal (strain rights barriers, product approval rejection, patent claims); (5) financial and schedule (cost overrun, EUR/KES volatility, schedule slippage, funder commitment)
- For each risk, document: risk name, description, causes (root drivers), likelihood (high >60%, medium 20–60%, low <20% estimate), severity (catastrophic = project stops, critical = major rework, major = significant delay/cost, minor = manageable within contingency), current mitigation (what is being done now), residual risk after mitigation, owner (person accountable for tracking and mitigation)
- Establish risk thresholds: risks with high likelihood × critical severity = immediate escalation to steering committee and gate panel (e.g., strain barriers discovered in Month 8 = 2027-06-09, late regulator feedback blocking product category); medium likelihood × major severity = monthly review with owner and escalation if mitigation is not on track (e.g., site envelope drifting, downstream cost rising); low likelihood or low severity = quarterly review
- Assign owners: strain and regulatory risks → regulatory specialist; safety risks → safety engineer and lead process engineer; partnership risks → Kenyan partner lead and project director; technical risks → lead process engineer and TEA lead; financial/schedule → project manager and funder liaison
- By Month 1.5 (2026-11-24), populate the initial risk register with at least 15–20 material risks identified from the pre-project assessment, strategic decisions and canonical facts
- Establish a quarterly risk-review cycle: month-end (e.g., Month 3 end = 2027-01-09) risk-owner updates; Month 2 (2026-12-09) steering-committee review; escalation to gate panel if any high-×-critical risks are identified. Publish a summary risk dashboard to stakeholders (identifying active risks, owners and status, without detailed mitigation tactics)
- Include contingency triggers: e.g., 'If strain barrier is confirmed at medium risk by Month 3 (2027-01-09), activate backup-strain bench comparison by Month 4 = 2027-02-09 (2-week run, EUR 0.05M, 40 days to first results); if results show backup is viable, proceed with fallback; if backup is also problematic, escalate to gate panel for recommendation by Month 5 = 2027-03-09'
- Maintain a quantified impact model: for each high-consequence risk, estimate the cost and schedule impact if the risk occurs unmitigated (e.g., strain switch in Phase Two = EUR 0.2M + 8 weeks; in Phase Three = EUR 2–4M + 12–24 months) and compare against the EUR 3.2M free technical reserve and the 3-month Phase-to-Phase float

**Approval Authorities:** Funder, independent gate-review panel (risk assessment and mitigation adequacy); steering committee (approval of risk thresholds and escalation protocols)

### 15. Communication and Stakeholder Engagement Plan

**ID:** 030f9d0c-203d-4204-b1c3-56308a7f66ca

**Description:** Strategy for regular, transparent communication with funders, partners, adopters, regulators, and the public. Specifies content types (monthly progress reports, quarterly cost and risk updates, annual scientific summaries, gate-review publications), audiences, distribution channels (website, email, stakeholder meetings) and decision-escalation protocols. Deliverable by Month 2 (2026-12-09). Intended audience: project management, funder, host institution leadership.

**Responsible Role Type:** Project Manager and Communication Specialist

**Primary Template:** Research Programme Stakeholder Communication and Engagement Plan Template

**Secondary Template:** Transparency and Public Reporting Protocol for Public-Good R&D

**Steps:**

- Define stakeholder groups and their information needs: (a) funder and steering committee (monthly spend and milestone status, quarterly risk and decision escalations, annual strategic updates); (b) independent gate panel (pre-gate briefing 4 weeks in advance, written gate recommendation process); (c) host institution leadership (monthly progress, quarterly strategic decisions, annual highlight); (d) Kenyan partner (weekly operational updates during phases, monthly cost and defect tracking); (e) named adopters (quarterly scenario and threshold validation, annual results); (f) regulators (pre-submission updates when engagement occurs, annual regulatory landscape summary); (g) public and researchers (annual scientific report, open-access publications of key Phase Two and Three results)
- Establish monthly reporting cadence: (1) Month-end project director's note to steering committee (milestones completed, spend versus plan, top three risks with current mitigation status); (2) Quarterly detailed financial report (spend by work package, cum. vs. plan variance >10%, EUR/KES conversion tracking, contingency draw); (3) Quarterly risk dashboard (active risks, owners, status; escalation flags if any risk threshold exceeded); (4) Semi-annual science summary (Phase One: strain productivity results, safety design basis, reactor decision rationale; Phase Two: kLa validation, strain stability, downstream progress; Phase Three: replication build status, uptime and composition results)
- Specify gate-review communication: (a) 4 weeks before each gate, distribute comprehensive briefing packet (technical reports, data, decision criteria); (b) 1 week after panel recommendation, publish panel's written recommendation and any funder deviation with written justification; (c) 2 weeks after gate decision, publish 'gate decision summary' (continue/modify/research-only/stop, key evidence, approved actions for next phase) on project website
- Establish annual stakeholder engagement events: (a) adopter consultation call (Q2 = May/June estimate, reviewing scenario progress and cost/capacity trajectories); (b) regulator pre-submission meeting (Q3 = Aug/Sept estimate, presenting composition data and regulatory dossier status if applicable); (c) annual research consortium meeting (Q4 = Oct/Nov estimate, open to researchers, reviewing publications and open-source package status)
- Define publication and open-access strategy: (a) all Phase One and Two productivity, strain stability and scale-up data published in peer-reviewed open-access journals (estimated 3–5 papers by Month 30 = 2029-04-09); (b) source package (hardware designs, software, operating procedures, safety case) released under open licence (CC-BY-SA or reciprocal licence per governance decision) by Month 39 (2030-01-09) after safety and legal review; (c) lessons-learned summary published at project end (Month 60 = 2031-10-09 or Month 62 = 2031-12-09), including both successes and failures, to contribute to the public good even if Go decision is not reached
- Establish data management and confidentiality: (a) all project data (lab notebooks, test results, cost data, site monitoring) stored in a secure, versioned repository accessible to the team and independent auditors; (b) confidential information (partner financial data, regulator correspondence) segregated and shared only with authorized parties; (c) interim project data embargoed from external publication until gate decision (prevents interim results from biasing interpretation); (d) no delay in publishing final results (all Phase III data published within 6 months of evidence freeze, even if gate decision is Research Only)

**Approval Authorities:** Funder (approval of reporting cadence and public communication); host institution (approval of messaging on behalf of the institution)

### 16. Change Management and Contingency Protocol

**ID:** a0fb02ca-3911-4045-83e9-9f367139b2b4

**Description:** Framework for managing design changes, scope adjustments, or contingency activations during the programme. Specifies triggers for major decisions (e.g., strain switch, cost-reduction pivot, site replacement), decision authorities (project director for <EUR 100k, steering committee for EUR 100k–EUR 1M, funder for >EUR 1M or schedule >2 months), required evidence and documentation, and publication of changes to all stakeholders. Deliverable by Month 2 (2026-12-09).

**Responsible Role Type:** Project Director and Project Manager

**Primary Template:** Change Management and Contingency Activation Protocol Template

**Secondary Template:** Decision Authority Matrix and Escalation Process

**Steps:**

- Establish decision authorities by cost and schedule impact: (a) project director (Director) authority: design clarifications, minor documentation fixes, contingency activation <EUR 50k and <1 month schedule; (b) steering committee (SC) authority: strain switch in Phase One/Two, scenario threshold adjustment, cost reduction or phase-scope redesign, contingency activation EUR 50k–EUR 1M or 1–4 months schedule; (c) funder authority: programme-level scope reduction (e.g., Danish-only replication, Research Only outcome, deployment-target removal), contingency activation >EUR 1M or >4 months schedule, gate-decision override
- Specify change-request process: (1) proposer (technical lead or partner) documents the proposed change: rationale, options evaluated, cost/schedule/risk impact, recommended option; (2) technical review (2 people minimum, not the proposer) assesses feasibility and risk; (3) steering committee reviews and approves or escalates; (4) if cost/schedule exceeds director or SC authority, escalate to funder with recommendation; (5) once decision is made, publish the decision, rationale and impact to all stakeholders within 5 working days
- Define change categories with expedited protocols: (a) safety-critical changes (e.g., HAZOP reveals an oversight, new interlock required): approve immediately by safety engineer + director, no delay; (b) regulatory-triggered changes (e.g., Kenya biosafety authority requires new study): approve immediately if cost/schedule acceptable, escalate otherwise; (c) performance-improvement changes (e.g., improved downstream method discovered): approve if budget/schedule available, defer otherwise to next phase; (d) cost-reduction pivots (e.g., electricity cost drops, deployment cost falls below EUR 12/kg): approve immediately as it reduces risk
- Establish contingency-activation rules: (a) if the strain switch trigger is met (primary strain barrier confirmed), activate the backup-strain work within 2 weeks and escalate to gate panel by 4 weeks; (b) if the cost-reduction target is not met by Month 9 (2027-07-09), approve a Phase One extension (by 1–2 months maximum) to finalize cost-bridge (adopter subsidy) or recommend reduced Phase Three; (c) if Kenyan site envelope degradation exceeds 20% (power improves, or spares become scarce), re-assess hypothesis B testability and decide whether to add stressors, replace the site, or adjust hypothesis B criteria; (d) if any gate-pass criterion is not met by the scheduled date, trigger a formal gate delay (not to exceed 1–2 months) with funder and panel review, or recommend stopping the phase
- Specify what decisions require a public gate-panel review before activation: major scope changes (e.g., reduce Phase Three to Danish unit only), deployment-scenario withdrawal (adopter pulls out), contingency draws >EUR 0.5M, programme-end-date slippage >2 months, or any funder override of steering committee recommendation
- Document all changes, decisions and approvals in a 'Programme Change Log' with date, description, decision authority, cost/schedule/risk impact, approval, and publication date; publish summary in quarterly progress reports

**Approval Authorities:** Project director (for <EUR 50k, <1 month); steering committee (EUR 50k–EUR 1M, 1–4 months); funder (>EUR 1M, >4 months, or strategic scope changes)

### 17. Phase One Strategic Blueprint (v0.1)

**ID:** b7ffbb50-9783-435e-8f3b-9cb3c45684aa

**Description:** High-level schematic design document outlining the Danish reference unit at Phase One conclusion, specifying major subsystems (electrolyzer design, gas-handling and mixing, fermenter type selected, downstream processing train outline), safety-critical components (interlocks, emergency shutdown, overpressure relief), and key design parameters (gas composition limits, inventory ceilings, operating pressure, temperature range). Intended for gate review and Phase Two detailed engineering, not a construction-ready design. Deliverable by Month 12 (2027-10-09). Intended audience: design engineers, gate-review panel, Kenyan replication team.

**Responsible Role Type:** Lead Process Engineer (with safety engineer and downstream specialist)

**Steps:**

- Consolidate matched reactor comparison results and HAZOP findings into a preliminary system schematic showing: electrolyzer (type, capacity), gas-feed lines, fermenter (type, volume, orientation), gas/liquid separation, culture outlet, safety interlocks and emergency-shutdown valve positions
- Annotate schematic with design basis limits: gas composition at fermenter inlet (e.g., <4% O₂), total H₂ and O₂ inventory, operating pressure (e.g., 2 bar max), safe-shutdown logic (vent path and time target ≤30 s)
- Include block diagram of control system architecture: sensors (pressure, temperature, O₂, flow), PLC or controller with defined software functions, interlocks (pressure cutoff, low-O₂ detection) and emergency shutdown (solenoid valve, horn/light alarm)
- Specify major components (electrolyzer model, fermenter type, gas-line materials and fittings, seals and gaskets compatible with H₂/O₂), subsystem interconnections (plumbing, electrical, control)
- Include a one-page text summary describing: the selected reactor concept (pneumatic, stirred, or passive-feed), justification (productivity vs. simplicity trade-off), design margin vs. safety basis, and any deviations or exceptions from the pre-set Design Basis for Safety
- Do NOT include detailed engineering drawings, component specifications, materials of construction lists, or manufacturing procedures; these are Phase Two detailed-design outputs
- Cross-reference the blueprint to the HAZOP findings and Adopter Change Boundary to ensure all safety constraints are reflected

**Approval Authorities:** Lead process engineer; safety engineer (HAZOP review); independent gate-review panel (Phase One gate review)

### 18. Provisional Product Category and Regulatory Pathway Decision Document

**ID:** c793aab6-d464-4b1a-9d54-a0c245bcf2a0

**Description:** Written decision document specifying the product category (animal feed, fish feed, food ingredient, emergency nutrition) selected at the Phase One gate for the reference strain and reference unit. Includes: choice rationale based on regulatory feasibility, adopter demand, and composition/digestibility predictions from Phase One data; regulatory pathway timeline and data-package requirements per jurisdiction (Denmark/EU, Kenya); and immutability clause stating the category is locked until Phase Two composition data either confirm viability or trigger a formal re-assessment. Deliverable by Month 12 (2027-10-09). Intended audience: regulatory specialist, gate-review panel, funder.

**Responsible Role Type:** Strain Rights and Regulatory Affairs Specialist (with lead process engineer)

**Steps:**

- Review the regulatory pathway assessment (Month 4 = 2027-02-09 report) and adopter scenario profiles to identify which product categories are most feasible (lowest regulatory burden, highest demand from named adopters)
- For the recommended category, document: (1) regulatory pathway in Denmark/EU (approval timeline, required studies, precedent for similar novel proteins); (2) Kenya pathway (if known; may be conditional on Phase II composition data); (3) any product-category-specific barriers or opportunities (e.g., 'animal feed has established approval route via KEBS; food ingredient requires longer EFSA review')
- Specify the data package that will be generated in Phase Two to support the chosen category: composition analysis (protein, nucleic acid, amino acids, minerals), digestibility (in-vitro protocol, species if animal feed), safety testing if applicable
- State clearly: 'The product category is locked at this gate and will not be changed without (a) completion of Phase II compositional data showing the category is no longer viable, (b) a formal regulatory change that blocks the chosen category, or (c) a written agreement by all parties (funder, host, adopters, Kenyan partner) to pivot to a different category, with published justification.' Include an exception: 'If Phase Two composition or digestibility data indicate the chosen category is not achievable (e.g., nucleic acid content >3%, digestibility <60%), category pivot is triggered immediately with panel review.'
- Obtain sign-off from regulatory specialist, lead process engineer and gate-review panel

**Approval Authorities:** Regulatory affairs specialist; lead process engineer; independent gate-review panel (Phase One gate); funder (final authorization)

### 19. Operational Technology Transfer and Deployment Toolkit

**ID:** af21146b-51b7-4fcc-b752-309fb9c0b55c

**Description:** Practical, non-technical guidance package for prospective adopters covering: site selection and preparation, equipment procurement and sourcing, assembly and commissioning procedures, routine operation (daily checks, culture management, pH and temperature control), troubleshooting common failures, maintenance schedules and spare-parts management, training curriculum and competency checklists, cost tracking spreadsheet template, and reference to the safety case and Adopter Change Boundary. Designed for adopters with limited technical background. Deliverable by Month 54 (2031-04-09) for publication at project end. Intended audience: prospective deployers, country-level implementing organizations, humanitarian logistics entities.

**Responsible Role Type:** Kenyan Co-Development Partner Lead (with lead process engineer and downstream specialist, in consultation with Phase III replication team)

**Primary Template:** Technical and Operations Manual for Resource-Limited Settings Template

**Secondary Template:** Deployment Playbook for Open-Source Hardware Template

**Steps:**

- By Month 48 (2030-10-09, Phase III start), compile a detailed 'Deployment Playbook' (50–100 pages) covering: site selection criteria (power availability, water source, physical space 200–500 m², local skills, regulatory environment), site preparation (electrical and water infrastructure, facility layout, safety equipment), equipment procurement (list of suppliers with contact info for major components, cost ranges), assembly checklist (sequence of assembly, inspection points, safety verification before startup)
- Document routine operation: daily checks (visual inspection, culture color/clarity, temperature, pH), feeding procedure (media preparation, sterilization, inoculation), gas feed (pressure setting, flow rate monitoring, O₂/H₂ analysis), sampling for composition (weekly protocol, sample preparation, storage), emergency response (power loss, contamination, overpressure alarm), and shutdown procedure
- Include troubleshooting table: common symptoms (e.g., 'culture white/opaque, not growing'), likely causes (contamination, incorrect pH, insufficient aeration), verification steps (visual check, sample plate, composition analysis) and corrective actions (reinoculate from cryo-stock, adjust feeds, call support)
- Maintenance schedule (daily, weekly, monthly, quarterly): equipment checks (seal integrity, electrolyzer function, thermostatic control), spare-parts replacement (electrolyzer membranes, seals, gas-line tubing, if applicable), calibration (sensors, controllers, pH probe)
- Competency framework and training curriculum: target trainee profile (technical background required), training duration (estimated weeks or months), training content (modules: safety, microbiology basics, equipment operation, troubleshooting, regulatory compliance), assessment method (written test, practical demonstration) and pass criteria (e.g., ≥90% on safety module, independently troubleshoot a failure scenario)
- Competency checklist: tasks (e.g., 'Start up the unit from cryo-stock,' 'respond to a pressure alarm,' 'restart after 24-hour power loss'), performer (technician name, date), observer/sign-off, and confidence rating ('independent,' 'with guidance,' 'needs more training')
- Cost-tracking spreadsheet template: categories (labor, electricity, nitrogen source, minerals, water, spares, consumables), monthly entries, running annual total, cost per kg usable protein calculation, comparison to projected cost model
- Safety summary: one-page reminder of gas composition and inventory limits, where to find the full safety case, which changes require re-certification, emergency shutdown sequence, who to contact for safety questions
- Regulatory reference: summary of which authorizations/permits are required by jurisdiction, where to find templates, contact information for regulatory bodies, and typical timeline for approval
- Produce the toolkit in multiple formats: (a) comprehensive PDF manual (~100 pages, printable); (b) web-based interactive version (modules linked, searchable) for online access; (c) short 'quick-reference' cards (laminated, waterproof) for bedside operation sheets at the site
- Translate toolkit into at least one regional language relevant to deployment (e.g., Swahili for East African adopters) if feasible within project resources

**Approval Authorities:** Lead process engineer (technical accuracy); Kenyan co-development partner (feasibility for local implementers); safety engineer (safety chapter accuracy); project director (release authorization)

### 20. Open Licence Stack and Stewardship Model Documentation

**ID:** eccf4e37-f0bc-4106-8c15-6cf995dddda4

**Description:** Comprehensive specification of the licence terms (hardware, software, documentation, data), the steward entity structure (non-profit foundation, consortium, or equivalent), and the governance model that keeps the core design open and prevents closed forks post-publication. Addresses freedom-to-operate review per jurisdiction, third-party IP restrictions inherited from the design, and a plan for the steward entity's sustainable funding and operations beyond the EUR 50M programme end. Deliverable by Month 54 (2031-04-09) before Phase Three results are published. Intended audience: funder, host institution, steward entity leadership, future adopters and developers.

**Responsible Role Type:** Open Source Hardware Governance Lead and IP Counsel

**Primary Template:** Open Licence Stack and Governance Charter Template

**Secondary Template:** OSHWA (Open Source Hardware Association) Certification and Stewardship Plan

**Steps:**

- By Month 30 (2029-04-09, Phase Two gate), commission a dedicated open-source governance specialist to work with IP counsel and the project team to design the licence stack
- Choose a primary licence for hardware designs: options include CERN Open Hardware Licence (reciprocal, requires improvements to be shared), Creative Commons Licenses (if appropriate for drawings/documentation), or a hybrid model combining different licences per component type
- Choose licences for software (e.g., GPL, Apache, or permissive) and data/documentation (CC-BY-SA or CC-BY)
- Conduct a final freedom-to-operate review: identify any third-party patents, material transfer agreement restrictions, or strain-use rights that constrain what can be published openly; for each constraint, document: (1) the restriction, (2) affected component or subsystem, (3) proposed resolution (design around, negotiate license, mark as proprietary exception, or patent pledge), and (4) impact on adopters
- Publish a 'Freedom-to-Operate and Licence Compliance Summary' (2–5 pages per jurisdiction: Denmark, EU, Kenya, Bangladesh, optionally others) stating: (1) which parts of the design are fully open-licence; (2) which parts have third-party IP constraints and how they are managed; (3) what adopters can and cannot do commercially without additional licensing
- Establish or designate a steward entity (proposed: non-profit foundation, university consortium spin-off, or existing open-hardware collective) with written charter specifying: mission (maintain the open design, manage repositories, coordinate updates), governance (board composition, voting rights, conflict resolution), funding model (endowment target, membership fees, licensing platform revenue, donor commitments), and key functions (repository hosting and version control, licence enforcement if needed, adopter coordination and support)
- Secure funding commitments for the steward entity's first 3–5 years of operations (estimated EUR 0.2–0.5M for staff, repository hosting, legal support); include as a line item in the EUR 50M programme budget
- Publish the complete governance documentation on the project website and in the open-source package, so adopters understand the steward's role and can hold them accountable

**Approval Authorities:** Funder (agreement on steward model and funding), host institution (if the host serves as initial steward), legal counsel (IP and licence review), steward-entity board (adoption and governance)

### 21. Hypothesis A and Hypothesis B Testing Framework and Evidence Evaluation Criteria

**ID:** 37238cff-f0ad-400b-b553-0a921dcb9136

**Description:** Detailed specification of how hypotheses A (operation by locally trained technicians) and B (decentralized, independently maintained modules) are tested during Phase II and Phase III, what evidence constitutes 'pass' or 'fail' for each hypothesis, and how the evidence is integrated into the Phase Three gate decision. Distinguishes between technical success (design works) and hypothesis success (design works under the intended conditions with the intended users/architecture). Deliverable by Month 3 (2027-01-09). Intended audience: project team, gate-review panel, evaluators.

**Responsible Role Type:** Project Director (with lead process engineer, Kenyan co-development partner lead, and independent gate-review panel)

**Primary Template:** Hypothesis Testing and Evaluation Criteria Framework Template

**Steps:**

- Define Hypothesis A: 'The hydrogen-oxidizing bacteria fermentation process can be safely and productively operated by locally trained technicians with high-school or vocational education, after a short (6–12 week) competency-verified training programme, without requiring specialist external support for routine operation.' Success means: (a) the trained Kenyan technician team operates the Phase III unit independently for six consecutive months, achieving ≥90% uptime, with zero safety-critical incidents, and meeting or exceeding locked productivity targets; (b) post-incident investigations show that incidents are operator error or documented maintenance, not design flaws or inadequate training; (c) the assistance log shows <4 hours/month average developer troubleshooting (routine operation is truly independent).
- Define Hypothesis B: 'The open-design process can be implemented as decentralized 50–100 kg/day modules suitable for deployment in low-income countries or regions facing food-supply disruptions, with local sparing, maintenance and eventual operation by country-level teams, without dependence on the original developers or a single commercial provider.' Success means: (a) the Kenyan replication team builds a full-scale unit from documentation alone (with audited external assistance limited to safety and regulatory consultation), demonstrating document clarity; (b) the unit survives defined outages (≥8 hours without power) with safe shutdown and documented restart, achieving ≥90% uptime in Month 48–54 (2030-10-09 to 2031-04-09); (c) local sourcing of nitrogen, minerals and spares achieves ≥60% of inputs from local/regional suppliers with ≥60-day resupply autonomy; (d) no single external dependency (no proprietary software lock-in, no required specialist maintenance, no manufacturer control of key components); (e) cost model at full adoption capacity (100 kg/day, 10 units deployed) shows a path toward the locked scenario threshold (EUR 12/kg or lower) within 2–5 years (allows learning curve and scale).
- Specify Phase II evidence for hypotheses: (1) Hypothesis A: Phase II small-scale replication (1–10 L pilot) operated by Kenyan team or independent engineer, demonstrating document clarity and trainee competence progression; (2) Hypothesis B: Phase II supply-chain mapping showing local nitrogen and spares availability, pilot-scale defect log and documented assistance (expected to be minimal beyond planned regulatory consultation).
- Specify Phase III evidence: (1) Hypothesis A: six-month uptime logs (≥90% target), weekly composition data confirming consistency, zero safety incidents, operator competency verification by independent observer, and post-incident documentation for any failures; (2) Hypothesis B: full documentation defect log with audited closure, quarterly site-envelope monitoring confirming operating conditions, quarterly supply-chain verification (resupply autonomy), and cost accounting comparing actual to modeled cost.
- Define 'fail' criteria: Hypothesis A fails if uptime <85%, a safety incident occurs, or post-incident investigation shows inadequate training or design flaw; Hypothesis B fails if defect rate exceeds auditor-approved threshold, local sourcing falls below 40% of inputs, or resupply autonomy <30 days, or cost modeling shows no credible path to EUR 12/kg even at 10 units deployed.
- Specify the Phase Three gate process: (a) present separate evidence for Hypotheses A and B; (b) gate-review panel assesses each hypothesis independently; (c) Go recommendation requires both hypotheses to Pass (or possibly Pass for A + Modify for B if cost path is credible); (d) Modify recommendation if one hypothesis fails but the other passes and the design is recoverable (e.g., if B fails due to supply-chain dependency, recommend a Phase III extension to develop backup suppliers); (d) Research Only or Stop if both hypotheses fail, or if cost chain is unaffordable for all scenarios.

**Approval Authorities:** Lead process engineer; Kenyan co-development partner lead; independent gate-review panel (criteria endorsement before Phase II work begins)

## Documents to Find

### 1. Cupriavidus necator H16 Strain Rights and Material Transfer Agreements

**ID:** 0e5b23bc-25e9-45d3-ad20-1062e75628e8

**Description:** Original material transfer agreements, strain-deposit certificates and rights documentation from culture collections (e.g., DSMZ, ATCC, NCCB) holding Cupriavidus necator H16 or related hydrogen-oxidizing bacteria. Required to confirm lawful obtainability for research, commercial production, redistribution, modification and derived strains in Denmark and Kenya. Purpose: input to Strain Feasibility Report (Month 4 = 2027-02-09). Intended audience: strain rights specialist, regulatory counsel.

**Recency Requirement:** Current (agreements valid as of Month 0 = 2026-10-09); historical amendments and restrictions that affect commercial use must be included

**Responsible Role Type:** Strain Rights and Regulatory Affairs Specialist

**Access Difficulty:** Medium—culture collections will provide strain information sheets publicly, but material transfer agreements and commercial-use restrictions may require direct contact and negotiation. DSMZ and ATCC typically respond to email requests within 2–4 weeks. Kenya import restrictions may require additional Kenyan biosafety authority contact (see separate entry).

**Steps:**

- Contact DSMZ (Deutsche Sammlung von Mikroorganismen und Zellkulturen) culture collection and request the strain information sheet, material transfer agreement and any restrictions on commercial use for C. necator H16 or C. metallidurans
- Contact ATCC (American Type Culture Collection) and request equivalent documentation for candidate strains
- Contact NCCB (National Collection of Cell and Tissue Cultures, UK) or equivalent European collections if H16 is held
- Request copies of any publications by the original strain depositors outlining restrictions on use, derived strains or commercial applications
- Search for any patents filed by strain depositors on C. necator hydrogen oxidation or applications to protein production, covering Denmark, EU and Kenya

### 2. Patent Landscape on Hydrogen Fermentation, Autotrophic Protein Production and Candidate Strains

**ID:** ea7c86d8-889a-4bb7-bc45-a56a234bf970

**Description:** Comprehensive freedom-to-operate analysis covering hydrogen fermentation processes, single-cell protein production from hydrogen and CO₂, and specific candidate strain (C. necator H16, C. metallidurans, Hydrogenovibrio, Ralstonia eutropha) use in protein production. Includes patent claims in Denmark, EU, Kenya and Bangladesh, with risk assessment per jurisdiction. Required to identify third-party IP blocking or licensing requirements before design commitment. Purpose: input to Strain Feasibility Report and Open Licence Stack and Stewardship Model decisions. Intended audience: legal counsel, regulatory specialist, IP advisors.

**Recency Requirement:** Current (patent databases searched as of Month 2 = 2026-12-09); includes recently published patent applications and granted patents; excludes expired or lapsed patents unless they indicate prior art or competing commercial interest

**Responsible Role Type:** Intellectual Property Counsel or Patent Search Firm

**Access Difficulty:** Medium to Hard—professional patent search requires paid access to patent databases (EPO, USPTO cost EUR 100–300/search) and specialized expertise. Typical timeline 4–8 weeks for full analysis and report. Small firms (e.g., universities) may face budgetary constraints; recommend procurement by funder or as part of regulatory/legal consulting budget (EUR 80k–120k estimate for comprehensive search across four jurisdictions and four candidate strains).

**Steps:**

- Commission a specialized biotech patent-search firm (e.g., FJC or equivalent) to conduct full landscape search across patent offices: European Patent Office (EPO), Danish Patent Office, German Patent Office (DPMA), UK IPO, US Patent Office (USPTO), Kenya Patent Office, WIPO (World IP Organization)
- Specify search terms: 'hydrogen fermentation,' 'hydrogenotrophic bacteria,' 'autotrophic protein,' 'single-cell protein + hydrogen,' 'Cupriavidus necator + commercial' or 'Cupriavidus necator + protein,' and equivalent terms in relevant languages (Danish, English, German)
- Request output: list of relevant patents with filing/grant dates, assignees (companies or institutions), claim scope (claiming the organism, the process, the product, or combinations), and country-specific enforcement risk (is the assignee actively asserting the patent?)
- Rank claims by freedom-to-operate impact: (a) high impact = claims on hydrogen-oxidizing bacteria protein production in the target jurisdictions, likely blocking; (b) medium impact = claims on related processes or strains, negotiable or design-around possible; (c) low impact = claims in non-target jurisdictions or expired
- Search for any patent pledges, defensive publications or open-source declarations by major players (e.g., Solar Foods, Calysta, academic institutions) that may provide design freedom

### 3. Kenya National Biosafety Authority Guidelines and Strain Classification Database

**ID:** 7c465094-ab00-48bd-af41-5853d3613d2c

**Description:** Current regulations, guidelines and classification decisions from Kenya's National Biosafety Authority (or equivalent competent body) for: (1) classification of hydrogen-oxidizing bacteria (wild-type Cupriavidus necator, other candidates) for contained-use research; (2) import restrictions and permit requirements for microorganisms by biosafety class; (3) requirements for commercial production authorization of novel organisms in Kenya. Purpose: input to Strain Feasibility Report (Month 4 = 2027-02-09) and Regulatory Engagement Sequencing decisions. Intended audience: regulatory specialist, Kenyan partner, project leadership.

**Recency Requirement:** Current as of Month 2–3 (2026-12-09 to 2027-01-09); includes any recent guidance updates or clarifications issued after 2024; historical precedent for similar novel organisms approved in Kenya (if any)

**Responsible Role Type:** Strain Rights and Regulatory Affairs Specialist (with Kenyan co-development partner liaison)

**Access Difficulty:** Hard—Kenya's National Biosafety Authority may have limited published guidance (unlike EU/EFSA), particularly for novel organisms not previously approved. Email requests may take 4–8 weeks to receive response. Pre-submission consultations require in-country engagement (Nairobi office visit likely needed) or engagement via Kenyan partner. Language is English, but bureaucratic processes may be slower than European counterparts. Recommend establishing Kenyan partner relationships early (Month 0 = 2026-10-09) to facilitate contacts.

**Steps:**

- Contact Kenya's National Biosafety Authority (or successor agency; confirm correct name and contact via Ministry of Health website) via email requesting: (1) guidelines on contained-use authorization for hydrogen-oxidizing bacteria; (2) strain classification or pre-assessment for C. necator H16 and alternatives; (3) import permit requirements for live cultures; (4) commercial production authorization pathway for novel microorganisms (if defined)
- Search Kenya Bureau of Standards (KEBS) website for any published standards on novel feedstuff or protein product composition, digestibility and safety testing, as these inform regulatory pathways
- Review Kenya's Biosafety Act (2009) and subsequent regulations (gazetted regulations, statutory instruments) for contained-use requirements and organism classification scheme
- If no published guidance exists (Kenya biosafety regime may be less formalized than EU/Denmark), request a pre-submission consultation meeting with the National Biosafety Authority; provide a 5-page outline of the project (organism, contained-use design, proposed operating envelope) and request informal feedback on feasibility
- Search for any recent government decisions on novel organisms approved for use in Kenya (e.g., prior approvals for GMO or novel microorganism research) to establish precedent for approval timeline and data requirements

### 4. Published Hydrogen-Oxidizing Bacteria Fermentation Data (Cupriavidus necator H16 and Alternatives)

**ID:** b9108e99-aa87-4532-87dd-ef702a7db48f

**Description:** Academic publications and technical reports documenting measured productivity, growth rates, oxygen-uptake rates, gas-transfer coefficients (kLa), nucleic acid content, and amino acid profiles for Cupriavidus necator H16 and candidate alternative strains (C. metallidurans, Hydrogenovibrio, Ralstonia) under hydrogen and CO₂ conditions. Required to benchmark Phase One productivity criterion (≥90% of published C. necator H16 performance) and to validate the KPI Framework. Purpose: input to Measurement and KPI Framework and matched reactor comparison design. Intended audience: process engineer, analyst, gate-review panel.

**Recency Requirement:** Most recent available (prioritize publications from 2018 onwards for modern process control and analytical methods); includes both peer-reviewed open-access papers and technical reports from research groups with established protocols

**Responsible Role Type:** Lead Process Engineer and Techno-Economic Modeler

**Access Difficulty:** Easy to Medium—academic publications are widely available via PubMed and Google Scholar (most recent papers open-access); institutional repositories accessible via university affiliations or direct author contact. Expect to find 10–20 relevant publications within 2–3 weeks. Proprietary data from commercial companies (Solar Foods, Calysta) less accessible (may require company contact or conference presentations).

**Steps:**

- Search PubMed, Google Scholar, ResearchGate and institutional repositories (University of Copenhagen, Aarhus University, DTU) using search terms: 'Cupriavidus necator hydrogen,' 'H16 growth rate,' 'autotrophic bacteria productivity,' 'hydrogenotrophic fermentation' and equivalent terms
- Identify key research groups publishing on H-oxidizing bacteria (e.g., Annika Carlsson group at Lund University, groups at DTU and RUC in Denmark, Gössner et al. group in Germany) and retrieve their publications
- Request copies of published datasets or supplementary tables showing: volumetric productivity (g/L/day), specific growth rate (1/h), oxygen-uptake rate (mmol/L/h), energy efficiency, nucleic acid content, amino acid composition
- For each publication, document: organism strain, medium composition, culture conditions (temperature, pH, aeration), measured values with uncertainty ranges, and system description (bioreactor type, size, gas-feed method)
- Identify and retrieve any technical reports or datasets from Solar Foods (Solein production), though proprietary details may be limited

### 5. European and Danish Food/Feed Regulatory Pathways for Novel Proteins

**ID:** 20b88562-b332-498f-a25c-6c841d6f2555

**Description:** Current European Food Safety Authority (EFSA) and Danish national regulatory guidance on approval of novel proteins (single-cell protein, alternative proteins) for food and animal feed. Includes required composition analysis, digestibility studies, allergenicity assessment, microbial safety limits, dossier contents and approval timelines. Required to inform provisional product-category selection and regulatory engagement sequencing. Purpose: input to Regulatory Pathway and Freedom-to-Operate Report and product-category choice. Intended audience: regulatory specialist, project leadership, adopters.

**Recency Requirement:** Current regulations and guidance as of Month 1–2 (2026-11-09 to 2026-12-09), including any recent clarifications on novel proteins or single-cell organisms published by EFSA or EU Commission within the past 12 months (2024–2026 estimate)

**Responsible Role Type:** Regulatory Affairs Specialist

**Access Difficulty:** Easy—EFSA and Danish regulatory guidance are publicly available on government websites and downloadable as PDFs. EU regulations are freely accessible. Typical retrieval time 1–2 weeks. Direct contact with regulatory authorities (DVFA) may take 2–4 weeks for detailed written guidance.

**Steps:**

- Visit EFSA website (www.efsa.europa.eu) and search for 'novel foods,' 'single-cell protein,' 'alternative proteins' guidance documents and published opinions (many available as open-access PDFs)
- Download EFSA's 'Technical Guidance for the Preparation and Presentation of the Notification and Application for Authorisation of Novel Foods' (most recent version)
- Review EU Regulation 2015/2283 on novel foods (current framework) and any implementing regulations or technical annexes
- Contact Danish Veterinary and Food Administration (DVFA, under Ministry of Food, Agriculture and Fisheries) requesting guidance on novel feed or food ingredient authorization pathways in Denmark
- Retrieve any published EFSA scientific opinions on similar novel proteins (e.g., insect protein, fungal protein) to understand typical approval timelines and data requirements by analogy
- Document for each product category (animal feed, fish feed, food ingredient): required composition analysis, digestibility testing protocol, allergenicity testing if applicable, microbial safety limits (for novel organisms), approval timeline (in months), and typical cost of dossier preparation and regulatory review

### 6. Kenya Feed or Food Regulatory Standards and Approval Pathways for Novel Ingredients

**ID:** 88b0e1e3-0381-4f93-9ed3-6ed74733bbfd

**Description:** Kenya Bureau of Standards (KEBS) and Kenya Ministry of Health/Agriculture guidance on feed or food ingredient registration, safety testing requirements, composition standards and approval timelines for novel ingredients (particularly alternative or novel proteins). Required to inform regulatory engagement strategy and product-category feasibility in Kenya. Purpose: input to Regulatory Pathway Report and Kenyan deployment scenario validation. Intended audience: regulatory specialist, Kenyan partner, project leadership.

**Recency Requirement:** Current as of Month 1–3 (2026-11-09 to 2027-01-09); includes Kenya Standards (KS) documents relevant to feedstuff (KS 1776, KS 1777 or equivalent for animal feed), or Kenya Food Regulations if food ingredient is the target category; any recent amendments or guidance issued after 2023

**Responsible Role Type:** Regulatory Affairs Specialist (with Kenyan co-development partner input)

**Access Difficulty:** Hard—Kenya's regulatory guidance may be less comprehensively published than EU/Danish standards. KEBS standards require purchase (cost EUR 20–50 per standard typically). Ministry website may have limited English-language guidance. Pre-submission consultation with KFDA or Ministry officials requires direct contact, possibly in-country engagement. Recommend Kenyan partner facilitate contact. Timeline 4–8 weeks for obtaining documents and formal feedback.

**Steps:**

- Contact Kenya Bureau of Standards (KEBS) website or directly requesting published standards for: animal feed (composition, additives, safety), feed ingredients, or food ingredients (if food category is target); obtain PDF copies or hardcopy of standards
- Contact Kenya Ministry of Agriculture / Directorate of Veterinary Services requesting approval procedures for novel feedstuff and any precedent for similar novel ingredients approved in Kenya
- Contact Kenya Food and Drugs Authority (KFDA) if the product is intended for human food (rather than animal feed), requesting guidance on novel protein authorization pathway
- Search for any government notices, gazette publications or advisory circulars on import or use of novel microorganisms or genetically modified organisms in food/feed production
- Review any past approvals for alternative protein products in Kenya (e.g., insect protein from local producers, or imported soy alternatives) to establish precedent for approval timeline and data required

### 7. Bangladesh Patent Office and Regulatory Landscape on Novel Proteins

**ID:** 36806c25-b8b7-4718-9be0-a16ad16f1d66

**Description:** Patents granted or pending in Bangladesh on hydrogen fermentation, autotrophic protein or alternative protein production; Bangladesh regulatory framework for food/feed ingredients if Bangladesh is considered as an alternative or expansion market. Purpose: input to multi-jurisdiction freedom-to-operate assessment and potential deployment-scenario expansion. Intended audience: IP counsel, regulatory specialist, funder strategic planning.

**Recency Requirement:** Current as of Month 2–3 (2026-12-09 to 2027-01-09); priority is European and Kenyan IP, but Bangladesh landscape included for completeness if multi-country licensing is contemplated

**Responsible Role Type:** Intellectual Property Counsel

**Access Difficulty:** Hard—Bangladesh patent office and regulatory guidance less developed than EU/Denmark/Kenya. English-language information limited. Recommend prioritizing European and Kenyan landscapes; Bangladesh treated as secondary unless strategic interest is confirmed.

**Steps:**

- Contact Bangladesh Patent, Designs and Trademarks Organization (BPDTO) requesting search results for patents on 'hydrogen fermentation,' 'autotrophic bacteria,' 'single-cell protein' and candidate strain names
- Use WIPO Patentscope database (international patent search) to identify patents designating Bangladesh
- If Bangladesh deployment is considered, identify regulatory authority (e.g., Bangladesh Food Safety Authority) and contact for guidance on novel protein approval pathway

### 8. Solar Foods Solein Regulatory Approvals and Public Technical Data

**ID:** 24fdbf0d-3877-4447-9460-9df908d4e25c

**Description:** Published and publicly available information from Solar Foods on Solein production (hydrogen-oxidizing bacteria protein): regulatory approvals obtained, composition data, energy efficiency claims, production capacity achieved, commercial deployment status. Required for benchmarking and as a competitive reference for deployment scenario credibility. Purpose: input to competitive landscape, scenario thresholds, and adoption-likelihood assessment. Intended audience: project leadership, adopters, gate-review panel.

**Recency Requirement:** Most recent available (company websites, press releases, regulatory dossiers lodged with EFSA or national authorities); prioritize published 2023–2026 documents

**Responsible Role Type:** Adoption Economist or Project Director

**Access Difficulty:** Easy to Medium—Solar Foods is a transparent public company; most data freely available on their website and in EFSA or national regulatory dossiers. Scientific papers accessible via university repositories or direct author request. Investor data available from NASDAQ First North filings. Timeline 1–2 weeks to compile.

**Steps:**

- Visit Solar Foods website (www.solarfoods.com) and review company profile, technology description, production data and regulatory status
- Search for EFSA published opinions or novel-food application summaries for Solein (regulatory dossiers may be public or available via EFSA Freedom of Information)
- Retrieve any published scientific papers authored by Solar Foods researchers or collaborators (e.g., with Lappeenranta-Lahti University of Technology, LUT) on Solein production, composition and economics
- Search company investor reports or earnings presentations (if publicly traded on NASDAQ First North) for production volumes, cost data and deployment timelines
- Contact Solar Foods directly via website contact form requesting publicly shareable data on energy efficiency (kWh/kg), feedstock costs, production timeline, and any approved markets

### 9. AMYBO ElectroPioreactor and Open Gas-Fermentation Publications and Designs

**ID:** bebc6013-bee3-4e80-8fed-50e73426b710

**Description:** Published papers, open-hardware documentation, and design files for the AMYBO electroPioreactor and passive gas-feeding research (cited in brief: Green Chemistry 2025 or equivalent). Required to evaluate whether published open design should become the Phase Three reference-unit base or remain a data-source-only benchmark. Purpose: input to Reference Architecture Sourcing decision and matched reactor comparison. Intended audience: lead process engineer, gate-review panel.

**Recency Requirement:** Most recent available, prioritizing the Green Chemistry paper cited in the brief and any follow-up work; includes all open-hardware files (CAD, component lists, assembly instructions) and operational data published under open licence

**Responsible Role Type:** Lead Process Engineer

**Access Difficulty:** Easy to Medium—Green Chemistry paper is peer-reviewed open-access (freely downloadable). AMYBO hardware designs released under open licence (typically CC-BY or similar) and available on project repositories. Direct author contact via ResearchGate typically yields response within 1–2 weeks. Timeline 1–3 weeks to compile.

**Steps:**

- Retrieve the Green Chemistry paper cited (doi:10.1039/D5GC01564B or equivalent) from the journal website or ResearchGate
- Visit AMYBO project website (search 'AMYBO electroPioreactor' on GitHub, ResearchGate, and project repositories) and download all available hardware designs (CAD files, wiring diagrams, bill of materials), operating procedures and experimental data
- Contact the corresponding author(s) of the Green Chemistry paper requesting the complete design package (hardware, software if any, raw experimental data, characterization results)
- Search for any follow-up publications, thesis work or conference presentations by AMYBO team describing scale-up attempts, performance validation or design improvements

### 10. Calysta or Unibio Hydrogen/Methane Fermentation Technology and Public Cost Data

**ID:** 04f24ad7-e809-4a1f-bf87-d0414408b0ec

**Description:** Published technical and business information from Calysta (methane fermentation, similar process architecture) or Unibio (methane-based protein, now acquired) on fermentation process design, safety approach, regulatory status, production costs and scale-up learnings. Not directly comparable (methane ≠ hydrogen) but relevant for process-safety and scale-up analogies. Purpose: competitive benchmarking and safety-design validation. Intended audience: lead process engineer, safety engineer, gate-review panel.

**Recency Requirement:** Most recent available (2022–2026); includes academic publications by company founders or researchers, company press releases, regulatory filings (SEC if US-listed, or European filing equivalents), acquisition or partnership announcements

**Responsible Role Type:** Lead Process Engineer

**Access Difficulty:** Medium—Calysta and Unibio are or were private/smaller companies with less public disclosure than Solar Foods. Press releases and academic papers available via internet search and ResearchGate. Company websites may be inactive or outdated. SEC filings (if US-incorporated) available via EDGAR. Recommend searching industry reports and conference presentations as proxy for technical detail. Timeline 2–4 weeks.

**Steps:**

- Search Calysta Inc. website (if still active; company status as of 2024–2026 may be acquisition, closure or rebranding; confirm via SEC EDGAR, company LinkedIn or industry news)
- Retrieve any published technical papers by Calysta founders or employees on gas-fermentation process design, safety or scale-up
- Search for Calysta's regulatory submissions or approvals in EFSA novel-food database or equivalent
- For Unibio: search company website (if accessible) and acquisition press releases (acquired by Calysta, then merged or divested; trace final owner/status); retrieve any technical publications or process descriptions
- Search for industry reports or analyst summaries (e.g., from biotech consulting firms) that document Calysta/Unibio process design, costs, scale-up experience

### 11. ICIPe (International Centre of Insect Physiology and Ecology) Insect Protein for Feed: Regulatory Pathway, Production Data and Kenyan Implementation

**ID:** 7d7da77f-8958-4011-918c-ee844ede3dfb

**Description:** Published and publicly available information from ICIPE Nairobi on insect protein (black soldier fly, cricket) for feed production: regulatory approvals obtained in Kenya, production at scale, composition and digestibility data, Kenyan feed-industry partnerships and adoption rates. Serves as a proxy for Kenyan adopter landscape and regulatory precedent for novel protein in animal feed. Purpose: competitive benchmarking for deployment scenarios, Kenyan regulatory-pathway validation. Intended audience: adoption economist, regulatory specialist, gate-review panel.

**Recency Requirement:** Most recent available (2023–2026), including ICIPE annual reports, scientific publications by ICIPE staff, Kenya Bureau of Standards approval documents for insect-based feeds, and industry case studies of insect-protein adoption in Kenya

**Responsible Role Type:** Adoption Economist

**Access Difficulty:** Medium—ICIPE is a well-established research institution; publications and annual reports available on website. KEBS approvals may be less formally published. Direct contact with ICIPE programme staff (via website) likely to yield response within 2–4 weeks. Kenyan feed-producer contacts may require ICIPE intermediation but can provide valuable adopter cost and capability data. Timeline 2–4 weeks.

**Steps:**

- Visit ICIPE website (www.icipe.org) and search for 'insect for feed,' 'black soldier fly,' 'cricket protein' programme pages, reports and publications
- Retrieve ICIPE project reports or annual reports documenting production volumes, adopter numbers, farm-level economics and market penetration in Kenya
- Search for scientific publications by ICIPE researchers on insect-protein composition, digestibility and feed-industry performance in Kenya (PubMed, Google Scholar)
- Contact ICIPE directly requesting: contact details for Kenyan feed producers using insect protein (to solicit threshold and cost-basis data for Scenario B), details of regulatory approvals obtained from Kenya Bureau of Standards, and any cost or adoption data shareable for benchmarking
- Search Kenya Bureau of Standards (KEBS) published standards or approvals for insect-based feed ingredients (may exist as KS document or precedent for novel protein approval)

### 12. Kenyan Electrical Grid Outage and Utility Supply Data (2024–2026 Historical Logs)

**ID:** 4eed8ee9-eaae-4552-b813-222cc20d5251

**Description:** Historical power-outage records from Kenya's main electricity utility (Kenya Power and Lighting Company [KPLC] or equivalent) for Nairobi and proposed rural sites, documenting frequency, duration and timing of unplanned outages over 24–36 months. Required to validate Kenyan Operating Envelope Baseline (target ≥4 unplanned outages/month) and to assess real-world outage survival and resilience testing conditions. Purpose: input to site-selection decision and hypothesis B (decentralized modules) feasibility. Intended audience: project team, site-selection consultant.

**Recency Requirement:** Historical data covering 24–36 months immediately preceding Month 0 (2026-10-09)—i.e., outage records from approximately 2023–2026; includes both planned and unplanned outages with date, time, duration and geographic coverage area

**Responsible Role Type:** Site-Selection Consultant or Kenyan Co-Development Partner

**Access Difficulty:** Hard—Kenya Power is a public utility, but historical outage data is not routinely published in open format. Direct corporate contact (via formal letter or Kenyan partner intermediation) is required. Government agencies may have better availability of data but consolidation across regions is incomplete. Typical response time 4–8 weeks. Some data may be provided as preliminary estimates rather than verified logs. Recommend Kenyan partner or site consultant conduct this search given local relationships.

**Steps:**

- Contact Kenya Power and Lighting Company (KPLC) customer service or corporate office requesting historical outage data for specific grid zones (Nairobi Central, proposed rural deployment site); requests may require formal letter from project on host-institution letterhead
- Request outage data from KPLC's System Operations Centre or Distribution unit; data may be available as: (a) monthly outage reports (if published), (b) tabular historical database (requires direct query), or (c) aggregated reliability metrics (System Average Interruption Frequency Index [SAIFI], System Average Interruption Duration Index [SAIDI])
- Contact Nairobi City County or regional county government (if deployment site is rural) for utility outage records from their power-distribution data
- Search KPLC website for published reliability reports or annual reports documenting outage statistics by region
- Interview utility staff or site technicians at candidate Kenyan location(s) regarding observed outage patterns, seasonal variation and any recent infrastructure improvements (improving power reliability would necessitate adding artificial stressors)

### 13. Kenya National Water Quality Standards and Borehole/Surface-Water Quality Data (Proposed Replication Sites)

**ID:** 7d2d006c-0896-407f-8c64-a4d8bc5c468d

**Description:** Kenya Bureau of Standards (KEBS) water-quality standards for industrial/agricultural use; water-quality baseline data (turbidity, conductivity, pH, iron, manganese) for Nairobi and proposed rural deployment site collected monthly over 3–4 months to establish seasonal variation. Required to assess process-water requirements and treatment needs for Phase III Kenyan replication. Purpose: input to Kenyan Operating Envelope Baseline and site-selection decision. Intended audience: site-selection consultant, process engineer, Kenyan co-developer.

**Recency Requirement:** Current water-quality standards as published by KEBS (valid as of Month 1–2 = 2026-11-09 to 2026-12-09); baseline water-quality data collected during Month 1–4 (2026-11-09 to 2027-02-09), covering at least one seasonal cycle if feasible (e.g., dry and wet seasons)

**Responsible Role Type:** Site-Selection Consultant and Kenyan Co-Development Partner

**Access Difficulty:** Medium—KEBS standards available via official channels (purchase or government website). Water-quality sampling requires on-site access and analytical capability (local laboratory or contracted analysis). Baseline data collection (3–4 months) is time-intensive but necessary for realistic assessment. Recommend delegating to Kenyan partner with local connections. Timeline 4–8 weeks for data collection and compilation.

**Steps:**

- Contact Kenya Bureau of Standards (KEBS) requesting published standards for water quality in agricultural/industrial use (may exist as KS document, e.g., KS 1496 on drinking water or equivalent for process water)
- Contact candidate Kenyan site (e.g., university, research institute, or community water provider) requesting access to water source and permission to conduct quarterly water-quality sampling (turbidity, conductivity, pH, iron, manganese); arrange for sampling via local laboratory (KPLC may provide utilities data or partner institute)
- Search Kenya Ministry of Water, Sanitation and Irrigation publications for regional water-quality data or hydrogeological reports that may characterize water availability and quality at candidate sites
- Request data from Kenya Meteorological Department on seasonal rainfall, dry-season water availability and climate patterns that affect water supply reliability

### 14. Local Nitrogen Source Suppliers and Landed Costs in Kenya (Ammonia, Ammonium Salts, Urea)

**ID:** 83afe491-6a74-41a1-a80d-5c479217b4dc

**Description:** Contact information and pricing for nitrogen-source suppliers (ammonia gas, ammonium nitrate, ammonium sulfate, urea) available locally or regionally in Kenya (e.g., agricultural suppliers, chemical distributors in Nairobi, Kisumu), including landed cost (cost per kg including transport and customs if import-dependent), minimum order quantities, lead times and reliability. Required to assess local sourcing feasibility and resupply autonomy for hypothesis B. Purpose: input to material and energy balance, deployment-scenario cost modeling, and supply-chain resilience assessment. Intended audience: project leadership, Kenyan partner, TEA analyst.

**Recency Requirement:** Current as of Month 2–3 (2026-12-09 to 2027-01-09); includes 2024–2026 pricing and supplier contact information

**Responsible Role Type:** Kenyan Co-Development Partner (with TEA analyst)

**Access Difficulty:** Medium—Kenyan agricultural suppliers are accessible via internet or local business directories (e.g., LinkedIn, Yellow Pages Kenya). In-person or phone contact with supplier representatives is necessary to obtain detailed pricing and reliability. Recommend Kenyan partner conduct supplier engagement given local language and relationship familiarity. Timeline 2–4 weeks to compile supplier list and obtain initial quotes.

**Steps:**

- Contact Kenyan agricultural suppliers (e.g., major chemical/fertilizer distributors in Nairobi, regional agricultural centers) via phone, email or in-person visit requesting pricing for: ammonia (if available as compressed gas), ammonium salts (ammonium nitrate, ammonium sulfate) and urea, in 25–100 kg quantities
- Obtain quotes for both local availability (fertilizer-grade salts commonly stocked by agricultural suppliers) and higher-purity laboratory-grade materials if required by process specifications
- Document for each supplier: company name, contact, location, product purity/grade, unit price (EUR/kg), minimum order quantity, lead time, payment terms
- Query import-dependent scenarios: if local supply is insufficient, obtain cost for importing ammonia or salts from regional suppliers (e.g., Tanzania, Uganda, or Egyptian chemical producers with regional distribution) or from overseas (India, Europe), including freight and customs costs
- Interview suppliers on reliability of supply during economic stress or regional crisis (relevant to 'food-supply disruption' scenario); e.g., 'If regional conflict disrupts normal supply chains, can you maintain at least 60 days of inventory at the customer site?'

### 15. Published Benchmarks for Single-Cell Protein Energy Efficiency and Productivity (Yeast, Algae, Insect Protein References)

**ID:** 3471215d-17d3-4aa5-9f99-e5bb7124e57e

**Description:** Peer-reviewed publications and technical reports quantifying energy per kg dry biomass and volumetric productivity for established single-cell protein production routes (bakers' yeast from sugar, algae from photosynthesis or heterotrophic fermentation, insect protein from black soldier fly or cricket), reported with consistent system boundaries and capacity-utilization assumptions. Required to establish defensible energy and productivity benchmarks against which the hydrogen-oxidizing bacteria process is compared. Purpose: input to techno-economic model validation and KPI Framework alignment. Intended audience: TEA analyst, process engineer, gate-review panel.

**Recency Requirement:** Most recent available (prioritize 2020–2026 publications for modern energy accounting and efficiency standards); includes both academic studies and industrial technical reports

**Responsible Role Type:** Techno-Economic Modeler

**Access Difficulty:** Easy to Medium—academic publications available via Google Scholar and university repositories (most recent papers open-access). Industrial reports may require direct company contact or conference presentations. NREL and IVL reports typically open-access. Timeline 2–3 weeks to compile.

**Steps:**

- Search Google Scholar and PubMed for: 'single-cell protein energy,' 'yeast fermentation energy per kg,' 'algae cultivation energy efficiency,' 'insect protein production energy,' 'alternative protein benchmarking' and related terms
- Retrieve published techno-economic analyses or lifecycle-assessment (LCA) studies comparing energy and cost across multiple protein production routes (e.g., NREL reports, ETH Zurich LCA studies, ICIPE reports on insect protein)
- Identify key publications likely to have energy-per-kg data: (a) yeast production (from industrial biotech companies like ABF Sugar or AB Enzymes); (b) algae (NREL algae research program, ETH aquatic biotech groups); (c) insect protein (ICIPE, companies like Agriprotein or InnovaFeed); (d) comparative meta-analyses (e.g., IVL Swedish Environmental Research Institute comparative protein LCAs)
- Extract from each publication: volumetric productivity (g/L/h or g/day), specific energy (kWh/kg dry biomass), system boundary (what is included: fermentation only, or harvest + downstream processing), capacity-utilization assumption, and reactor type (fed-batch, continuous, open, closed)

### 16. Electrolyzer Capex and Efficiency Data (Green Hydrogen Production)

**ID:** 466f6746-7ae4-4d8c-a05e-15f2615c0ab2

**Description:** Current capital costs and electrical efficiencies for water electrolyzers (Proton Exchange Membrane [PEM], Alkaline, Solid Oxide) at scales 1–100 kW, including specific capex (EUR/kW), electrical efficiency (% conversion of electricity to H₂ lower heating value), and cost learning curves or projections to 2030. Required to estimate electrolyzer capex for the deployment unit and to assess cost-reduction sensitivity to electrolyzer technology advances. Purpose: input to techno-economic model and cost-reduction roadmap. Intended audience: TEA analyst, process engineer, gate-review panel.

**Recency Requirement:** Most recent available (2024–2026 data preferred for current market prices); includes capex from commercial suppliers (if available) and projections from hydrogen industry reports and IEA/IRENA cost databases

**Responsible Role Type:** Techno-Economic Modeler

**Access Difficulty:** Easy to Medium—IEA and IRENA data free to download. Electrolyzer manufacturer data sheets publicly available on websites. Academic reports searchable via Google Scholar. Direct manufacturer contact typically yields response within 2–4 weeks. Timeline 2–3 weeks to compile.

**Steps:**

- Search IEA (International Energy Agency) Technology Collaboration Programme reports on hydrogen and electrolyzer technology costs (typically published annually, free download)
- Search IRENA (International Renewable Energy Agency) database on renewable hydrogen cost and electrolysis technology maturation
- Contact major electrolyzer manufacturers (e.g., Plug Power, Cummins/Hydrogenics, ITM Power, Nel Hydrogen, Giner Electrochemistry) via their websites requesting public data on specific capex for units in the 1–100 kW range; commercial data sheets often available online
- Retrieve academic papers or industry reports on hydrogen cost roadmaps (e.g., Carbon Trust, FCHEA, DNV GL) projecting electrolyzer cost to 2030 and beyond
- For comparison: search for any published data from hydrogen-protein projects (Solar Foods, if disclosed) or hydrogen-based chemicals production (e.g., ammonia, methanol synthesis) on electrolyzer costs at industrial scale