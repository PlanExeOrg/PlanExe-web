_Consistency: first pass found 3 high / 7 medium / 0 low contradictions. Repair: round 1: 50 edits → 1 high / 8 medium; round 2: 16 edits → 0 high / 8 medium. Published: round 2 (fewest high-severity issues). Shown below: the final check of the repaired documents (0 high / 8 medium / 0 low)._

## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Are the Danish host MoU signed (Month 1), the Kenyan partner agreement signed (Month 3), and the independent gate panel chartered with at least 3 conflict-free members and a written funder commitment to publish any deviation (Month 1.5)? | Danish MoU signed by Month 1; panel of 3-5 conflict-free members and Gate Authority Charter by Month 1.5; Kenyan agreement by Month 3; no Danish host with protected lab space by Month 4 means halt Phase One spend beyond committed items. | Signed MoUs, signed charter, panel conflict-of-interest statements and the funder's written deviation-publication commitment (Months 1-3). | DELAY: pause new commitments to facility setup (EUR 2.0M planned), open parallel talks with a second host or partner, and escalate to the funder. Do not let work continue by momentum without an independent panel. |
| 2 | Does the Month 4 evidence show a primary and a legally clean backup strain that are lawful for commercial use, redistribution, modification and import into Kenya, with written Kenyan biosafety feedback, and a Kenyan site baseline that meets the fixed operating envelope? | At least 2 strains confirmed lawful (research, commercial, redistribution, modification, derived) with Kenyan import; written Kenyan biosafety feedback; baseline report with >=4 unplanned outages/month, mean >=2 h, >=1 outage/quarter >8 h, spares lead time <=2-4 weeks from >=2 suppliers. | Strain Feasibility Report and signed Kenyan Site Baseline Report (Month 4; internal draft Month 3). Hard tripwire at Month 6. | DELAY or SWITCH: absorb a strain switch in the EUR 0.30M earmark and re-select the site rather than lowering the envelope. If no strain is lawfully importable for commercial use by Month 6, stop or pivot to Research Only. |
| 3 | By Month 7, is a gap-funding route committed in writing and have at least 2 named adopters signed with auditable cost data, on thresholds that the modeled cost can plausibly meet? | Written funder or adopter commitment covering the EUR 274,820/yr gap (or EUR 3.0M capex grant); >=2 signed adopters by Month 7; modeled full cost below EUR 15/kg at Month 6 (tripwire). Scenario B (EUR 10/kg) is below opex-only EUR 11.59/kg, so a grant alone cannot meet it. | Funder gap-funding decision document, signed adopter commitments with cost-basis data, cost-reduction study results (Months 6-7); locks time-stamped at Month 9. | DOWNSIZE or STOP: the Phase One gate cannot pass with fewer than 2 signed adopters. Recommend Research Only, or a reduced Phase Three (Danish unit plus documentation-based replication), instead of locking unreachable scenarios. |
| 4 | At the Phase One gate, does measured bench productivity within the pre-registered safety limits, with the HAZOP complete, justify releasing Phase Two funding? | Productivity >=90% of the published C. necator H2 benchmark = pass; 70% to <90% = panel decision; <70% = fail; measurement uncertainty above 30% means the panel cannot declare a pass. HAZOP complete; reactor chosen by the pre-registered rule; O2 <4% in H2-rich stream and H2 inventory <0.5 m3 held. | Triplicate matched-reactor results audited externally (results about Month 6), evidence freeze Month 9, panel meeting Month 10, release decision by Month 12. | MODIFY or STOP: below 70% inside the safety limits, stop or pivot to Research Only. Do not relax safety limits ad hoc; a revised envelope needs an independent ATEX review. The 70-90% band is a panel decision, not automatic continuation. |
| 5 | At the Phase Two gate, are the scale-up, stability, downstream and documentation criteria met and the cost chain closed enough to release the EUR 4.0M reference-unit hardware? | kLa decline bench to pilot <=25%; 16-week strain-stability run with <10% variation; nucleic acid <=2% of dry matter (or category limit) with the downstream train validated; composition and digestibility confirm the category; defects 0 safety-critical, <=3 critical, <=10 minor; modeled cost <=EUR 14/kg (proposed threshold, pre- or post-subsidy basis unresolved) AND a committed gap-funding route. | Pre-registered disproof experiments, stability run, pilot downstream data, early replication defect log and auditor readiness assessment (Month 26), panel decision at Month 30. | DOWNSIZE or STOP: withhold the EUR 4.0M hardware and recommend a reduced Phase Three (Danish unit plus documentation-based replication) or Research Only. A failed gate needs an explicit funder decision, never automatic continuation. |
| 6 | At the Phase Three gate (evidence freeze Month 57, decision by Month 60), has the independent replication met every Go criterion, with hypotheses A and B reported separately? | On-spec biomass from documentation alone; 100% of safety-critical fault injections reach a safe state; >=90% of other fault tests recovered; six consecutive months uptime >=90% (and the chosen scenario's own requirement); operator practical safety pass >=90%; assistance log with developer troubleshooting <=4 h/month flagged; at least one locked scenario met; credible regulatory pathway and scale-up route. Failure of A or B excludes Go. | Danish 6-month run (Months 40-46), Kenyan production (Months 48-54), fault-injection results (Months 50-56), audited assistance log, panel recommendation. | MODIFY (correctable weaknesses, including a first documentation-traced failure), RESEARCH ONLY (technology works but no scenario or scale-up route), or STOP (repeated replication failure or fundamental safety, legal or reproducibility failure). Findings are published as open knowledge either way. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: repaired_review_plan Review 6 KPI 1 / Review 7; executive summary Feedback 4; premortem FM1; self-audit 6, 12
    canonical: construction_spend_recommendation = Hardware released only at the Phase Two gate; if the deployment cost chain still fails, reduced Phase Three or Research Only
    observed:  Trigger <=EUR 14/kg; failure at 14 and at 15; '12-14/kg enables Scenario A or B'
HIGH CF-002  document: repaired_review_plan Review 6 KPI 1; premortem A2/FM1; pitch
    canonical: scenario_b_thresholds = <=EUR 10/kg, >=500 kg usable protein/day as 5 x 100 kg/day modules, >=90% uptime
    observed:  'EUR 12-14/kg ... enables Scenario A or B'; gap defined only vs EUR 12
HIGH CF-003  document: repaired_review_plan Review 6 KPI 3 and project plan Measurable
    canonical: programme_financed_units = 2 reference units (EUR 4.0M); deployment-scale units modeled only, not programme-funded
    observed:  Scenario capacity thresholds treated as met and 'verified' at the Phase Three gate
MEDIUM CF-004  document: executive summary; repaired_review_plan Review 1, 3, 15
    canonical: gate_panel_governance = Funder holds release authority; deviation from panel needs published written justification
    observed:  'binding authority', 'binding stop authority', 'binding veto'
MEDIUM CF-005  document: repaired_review_plan Review 3, 4, 6; self-audit item 2
    canonical: energy_per_kg = 40 kWh/kg dry biomass (range 25-60) = ~80 kWh/kg usable protein, system boundary electrolyzer + fermenter + downstream
    observed:  Downstream baseline 20 vs tripwire 15 kWh/kg dry; 'assumed 15'; 'EUR 30/kg'
MEDIUM CF-006  document: repaired_review_plan Review 4 item 3; self-audit item 9
    canonical: product_specification = nucleic acid <=2% of dry matter (category-dependent)
    observed:  <3% contingency; <=2.5% pass example
MEDIUM CF-007  document: repaired_pitch
    canonical: strain_feasibility_report = Month 4 report names primary and backup strain with rights per use (proposed threshold)
    observed:  'requires no proprietary strains'; 'pre-assessed in detail'; steward 'indefinitely'
MEDIUM CF-008  document: premortem FM1; self-audit item 3
    canonical: scenario_a_thresholds = <=EUR 12/kg, >=100 kg usable protein/day, >=95% uptime
    observed:  '50 kg/day unit fitting EUR 12/kg'
MEDIUM CF-009  document: self-audit item 14; repaired_review_plan Review 10 item 2
    canonical: product_category_timing = Provisional at Phase One gate (Month 10); confirmed at the Phase Two gate
    observed:  'locked at Phase One gate'
MEDIUM CF-010  document: premortem A4, A7
    canonical: phase1_kickoff_milestones = Month 2.5: reactor decision rules pre-registered, safety design basis issued
    observed:  Bench test of all three concepts at Month 2.5; nucleic acid trials at Month 3
MEDIUM CF-011  document: repaired_review_plan Review 6 KPI 3; self-audit item 2
    canonical: phase3_schedule = Fault-injection Months 50-56; evidence freeze Month 57; decision by Month 60
    observed:  Final results to panel at Month 55
MEDIUM CF-012  document: repaired_review_plan Review 8 item 3 / Review 9 item 2
    canonical: kenya_envelope_baseline = >=4 unplanned outages/month, mean >=2 h, >=1 outage/quarter >8 h; drift >20% triggers added stressors (proposed threshold)
    observed:  're-negotiate the envelope downward'; baseline in about 4 weeks after Month 3
```

### 1. Hardware-release trigger, failure line and KPI cost bands have no consistent basis (🔴 High) — needs a project decision

- **Executive summary Feedback 4; premortem FM1 stop rule; self-audit items 6 and 12:** Release EUR 4M hardware if model predicts <=EUR 14/kg AND gap route committed; stop rule uses the same 14
- **Repaired review plan, Review 6 KPI 1; Review 7 item 3; Review 11 item 3 (trigger undefined):** KPI 1: 'Failure to reach EUR 14/kg forces Research Only' but also 'Failure EUR >15/kg' and 'EUR 12-14/kg ... enables at least one scenario'; Go test is the locked scenario cap (12, 10 or 15)
- **Why it conflicts:** The Phase Two release trigger (14) is reused as a Phase Three success target. The failure line is 14 in one sentence and 15 in another. EUR 12-14/kg cannot satisfy Scenario A (12) or B (10). It is not stated whether 14 is judged before or after a capex grant (about EUR 3.0M would remove about EUR 8.3/kg of debt service), and Review 11 says the trigger is still undefined.
- **Suggested resolution:** Define one hardware-release rule (state whether pre- or post-subsidy, per scenario) and keep it separate from Phase Three success, which is the locked scenario cap. Use one failure line and remove 12-14 'enables a scenario'. The funder must decide the basis before the Gate Authority Charter (Month 1.5).

### 2. Scenario B cap is below opex and gap sizing covers only Scenario A (🔴 High) — needs a project decision

- **Canonical facts (scenario_b_thresholds, deployment_opex):** Scenario B (feed producer) <=EUR 10/kg full cost; opex-only EUR 11.59/kg at EUR 0.08/kWh
- **Review 2-3, 6, 9, 14; premortem A2/FM1; self-audit 6-8; pitch ('EUR 12/kg cap'):** Gap EUR 7.93/kg is sized only against the EUR 12 cap, and a EUR 3.0M capex grant is offered as the fix. KPI 1 says EUR 12-14/kg enables 'Scenario A or B'.
- **Why it conflicts:** No grant can bring Scenario B to EUR 10/kg when opex alone is EUR 11.59/kg; only deep cost reduction (electricity, downstream energy) could. Scenario C (EUR 15) has a different gap. Locking all three scenarios against a single gap number leaves B and C untreated.
- **Suggested resolution:** Compute the gap per scenario (A, B, C), state which are reachable by grant and which only by cost reduction, and do not describe B as enabled at EUR 12-14/kg. Either re-price or drop B before locking, or say B needs cost reduction below opex.

### 3. 'Scenario met' at Phase Three vs capacity of the built reference units (🔴 High) — needs a project decision

- **Canonical facts (reference_unit_capacity, programme_financed_units):** Reference unit 20 kg dry biomass/day (~10 kg usable protein/day); programme finances only 2 reference units; deployment-scale units are modeled only and not programme-funded
- **Review 6 KPI 3; project plan Measurable; exec summary; pitch Metrics:** Go needs at least one locked scenario met on cost, capacity (>=100 / >=500 / >=50 kg usable protein/day) and uptime, 'verified' from Phase III production
- **Why it conflicts:** The built units produce 10 kg/day usable protein, below every scenario's minimum capacity (50-500). No document says whether 'met' means measured or modeled at nameplate, or who finances and tests a deployment-scale unit.
- **Suggested resolution:** Decide and state what 'scenario met' means: (a) measured on the reference unit for cost, uptime and energy plus a modeled, uncertainty-bounded scale-up to the scenario capacity, or (b) a funded deployment-scale unit with named financier. Fix the rule before locking scenarios at Month 9.

### 4. Panel 'binding' authority vs funder release authority (🟡 Medium)

- **Canonical facts (gate_panel_governance):** Funder holds release authority; any deviation from the panel needs published written justification
- **Executive summary (Risks, Overall Takeaway); Review 1 item 3; Review 3 item 1; Review 15 item 2:** Charter with 'binding authority' / 'binding stop authority'; 'panel recommendation is binding and cannot be rationalized away', yet in the same items funders may deviate with written justification in 5 working days
- **Why it conflicts:** A binding veto and a funder who may deviate with published justification are different mechanisms. 'Binding' also contradicts the funder's release authority.
- **Suggested resolution:** Use the canonical wording everywhere: the panel issues an independent written recommendation, the funder holds release authority, and any deviation is published with justification (5 working days). Remove 'binding' and 'veto'.

### 5. Downstream-only energy: baseline above tripwire, mixed denominators, opex vs full-cost caps (🟡 Medium)

- **Review 3 item 2; premortem FM1/FM8 tripwires:** Downstream baseline 20 kWh/kg dry biomass (downstream only); tripwire 15 kWh/kg dry biomass (= 30 kWh/kg usable protein)
- **Review 4 item 3; Review 6 KPI 1; self-audit item 2:** Review 4 item 3: assumed 15, rising to 25 'instead of 15'; cost jumps 'from EUR 11.59/kg opex to EUR 14-16/kg, exceeding all three scenario caps'; self-audit item 2 cites 'nucleic-acid removal cost >EUR 30/kg usable protein'
- **Why it conflicts:** A 20 kWh/kg baseline already exceeds the 15 kWh/kg tripwire, while Review 4 assumes 15. 25 kWh/kg dry equals 50 kWh/kg usable protein, not 30. Opex of EUR 14 does not exceed Scenario C's EUR 15, and opex-only figures are compared with full-cost caps. The EUR 30/kg unit appears to be a kWh figure.
- **Suggested resolution:** Fix one downstream-only baseline (state basis), express all triggers per kg dry biomass with a stated conversion (x2 for usable protein), compare full cost with caps and opex with opex, and correct the unit in self-audit item 2.

### 6. Nucleic acid threshold differs by document (🟡 Medium)

- **Canonical product_specification; premortem FM8 stop rule; project plan Measurable:** Product spec and stop rule: nucleic acid <=2% of dry matter (or category limit)
- **Review 4 item 3; premortem A7/FM8 tripwires (3%); self-audit item 9:** Contingency/trigger at 3% ('cannot be reliably met at <3%'); pass example '<=2.5%'; 'achieved 2.8%' proceeds to Phase III plan
- **Why it conflicts:** Three different cut-offs (2%, 2.5%, 3%) are used for what the Phase Two gate must accept. If 3% is the gate trigger, a product failing the 2% spec could pass the gate.
- **Suggested resolution:** Use <=2% (or the category limit set in writing by the authority) as the Phase Two gate pass criterion. Treat 3% only as an early-warning tripwire and label it so.

### 7. Pitch states open items as settled facts (🟡 Medium)

- **Review 14, self-audit 3 and 11, premortem A1/A4, canonical safety_design_limits:** Strain rights unconfirmed until Month 4; steward running cost (EUR 65-130k/yr, estimate) unfunded; Adopter Change Boundary v0 only due Month 3; safety limits are preliminary and may conflict with productivity (premortem A4)
- **Pitch (Overview, Stakeholder Benefits, Ethical Considerations, Long-term Vision):** Pitch: 'requires no proprietary strains'; adopters build 'without licensing fees'; 'Adopter Change Boundary is pre-assessed in detail'; steward 'will be managing ... indefinitely'; regulators 'will have confirmed' pathways
- **Why it conflicts:** Outcomes the plan treats as hypotheses or unfunded are presented as facts. Patent restrictions per jurisdiction are still unknown, the boundary document does not yet exist, and the steward has no funding.
- **Suggested resolution:** Reword as targets conditional on gate evidence ('aims to', 'subject to the Strain Feasibility Report'); label the safety limits 'preliminary (proposed threshold)'; state that steward funding and licence terms per jurisdiction are open.

### 8. '50 kg/day redesign' vs Scenario A minimum capacity (🟡 Medium)

- **Canonical scenario_a_thresholds, deployment_capacity_model:** Scenario A requires >=100 kg usable protein/day; installed cost modeled linearly (EUR 15,000 per kg/day dry biomass)
- **Premortem FM1 playbook; self-audit item 3 mitigation:** Respond with 'a 50 kg/day redesign' / 'a redesigned 50 kg/day unit fitting EUR 12/kg'
- **Why it conflicts:** A 50 kg/day unit fails Scenario A's capacity floor. Under linear capex scaling it is not shown to lower cost per kg. Review 3 already limits 50 kg/day to Scenario C.
- **Suggested resolution:** State that a 50 kg/day unit is relevant only to Scenario C and only if a cost model shows a lower cost per kg. Otherwise replace with 'cost-reduction lever'.

### 9. Product category 'locked' at Phase One vs provisional until Phase Two (🟡 Medium)

- **Canonical product_category_timing; project plan Compliance Actions:** Provisional category chosen at Phase One gate (Month 10); confirmed only at Phase Two gate on composition and digestibility
- **Self-audit item 14; Review 10 item 2:** Category 'locked at Phase One gate (Month 10)'; 'selected ... and locked before Phase Two work begins'
- **Why it conflicts:** A locked category cannot be re-evaluated at the Phase Two gate, which is when composition and digestibility data exist. The 'locked' wording follows the old assumptions.
- **Suggested resolution:** Use 'provisional category named at Phase One gate, confirmed at Phase Two gate'. Reserve 'locked' for scenario thresholds.

### 10. Bench tests scheduled before the rules and safety basis exist (🟡 Medium)

- **Canonical phase1_kickoff_milestones; Review 13 item 1:** Month 2.5: reactor decision rules pre-registered and safety design basis issued; bench results due about Month 6, evidence freeze Month 9
- **Premortem A4 and A7 validation methods:** Premortem A4: run bench test of all three reactor concepts inside safety limits at Month 2.5; A7: nucleic-acid reduction trials on Phase One biomass at Month 3
- **Why it conflicts:** Triplicate matched runs with a steady state of 7 days or more cannot be finished at Month 2.5, when the protocol and safety limits are only being locked. Month 3 downstream trials need biomass that reactors have not yet produced.
- **Suggested resolution:** Move these validations after pre-registration (start after Month 2.5, results about Month 6 as in Review 13), or call the Month 2.5/3 checks early screening runs that do not decide the gate.

### 11. Final results to panel at Month 55, before fault-injection ends at Month 56 (🟡 Medium)

- **Canonical phase3_schedule, phase3_gate_criteria:** Fault-injection Months 50-56; evidence freeze Month 57; Go depends on fault-injection results
- **Review 6 KPI 3 monitoring:** Present final results to the panel with pass/fail per scenario at Month 55 (2031-05-09), before the evidence freeze
- **Why it conflicts:** A final pass/fail declaration at Month 55 precedes the end of the fault-injection programme (Month 56) and the evidence freeze (Month 57). Self-audit item 2 also puts outage and resupply results 'by Month 54'.
- **Suggested resolution:** Make Month 55 an interim review, with the final scenario pass/fail presented after the Month 57 evidence freeze and the decision by Month 60. Align the 'by Month 54' items with the Months 50-56 programme.

### 12. Kenyan baseline timeline and 'renegotiate envelope downward' (🟡 Medium) — needs a project decision

- **User brief; canonical kenya_envelope_baseline; assumptions review:** Envelope is defined before choosing sites and tested by the site, not adjusted to suit it; baseline report due Month 4 with 24-36 months of outage logs and monthly water sampling
- **Review 8 item 3; Review 9 item 2; exec summary:** Partner and site secured only at Month 3, leaving about 4 weeks for the baseline study; if baseline target is unlikely, 're-negotiate the envelope downward'
- **Why it conflicts:** Seasonal water data need several months of sampling, which cannot start at Month 3 and finish at Month 4. Lowering the envelope to fit the chosen site is the convenience-driven choice the plan forbids and a post-hoc threshold change.
- **Suggested resolution:** Keep the envelope fixed and change the site if it does not meet it. Specify what the Month 4 baseline contains (historical records plus spot samples) and that water sampling continues under monitoring. Start the independent site study before the partner is signed.

## Summary

The plan is largely aligned with the canonical facts. Phase windows, budget split, gate dates, panel budget, defect thresholds, the fault-injection threshold and the arithmetic of the energy sensitivity have been repaired. What remains is mostly economic and governance coherence: the cost thresholds (release trigger of 14 against scenario caps of 12, 10 and 15), what a 'met scenario' means when the built units produce 10 kg/day against capacity floors of 50-500 kg/day, and a Scenario B cap below opex. Several downstream-energy, nucleic-acid and timing items still need correction to the established values. Three items (the cost basis for hardware release, Scenario B, and the meaning of 'scenario met') need project decisions rather than rewording.