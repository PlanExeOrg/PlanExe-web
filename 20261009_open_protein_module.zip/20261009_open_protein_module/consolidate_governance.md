# Governance Audit


## Audit - Corruption Risks

- Strain rights agreements concealed or misrepresented by strain holders or developer staff to avoid disclosing third-party restrictions, enabling unauthorized commercial use or derived-strain redistribution and blocking independent Kenyan replication.
- Selective reporting of reactor-concept comparison results: post-hoc adjustment of measurement definitions, exclusion of unfavorable data, or cherry-picking of sample replicates to make a favored reactor concept appear superior to rivals and justify early design lock-in.
- Conflict of interest in gate-review panel selection: researcher or funder appointing panel members with undisclosed financial ties to alternative-protein companies, ATEX consultants, or strain holders, compromising independence and creating bias toward continuation or approval.
- Misallocation of programme contingency to non-disclosed organizational overhead or staff perks (e.g., travel, consulting fees to connected firms) instead of technical work, under cover of 'management and administration' budget line.
- Collusion between Kenyan partner and developer team to simulate independence: undocumented developer assistance recorded as 'local team effort' in audited logs, or assistance log auditor bribed or influenced to overlook excessive developer involvement.
- Regulatory pathway misrepresented to funder and adopters: informal pre-submission feedback from authorities characterized as 'pathway approved' when feedback was non-binding and preliminary, leading to inflated Go decision credibility.

## Audit - Misallocation Risks

- Budget overrun in Phase One landscape review and regulatory work exceeds the EUR 0.30M pre-allocated contingency through scope creep (e.g., adding patent searches in additional jurisdictions, extended strain-rights negotiation) without formal change control, forcing deferral of reactor experiments to Phase Two.
- Planned Phase One facility setup cost (EUR 2.0M) exceeds budget due to long lead times on bioreactor equipment, utility upgrades or ATEX-compliant construction; EUR 0.35M free contingency consumed, and no reallocation mechanism to reduce other Phase One work.
- KES spending in Kenya inflates silently due to currency depreciation (EUR/KES drifts >20% from baseline) without explicit hedging or contingency drawdown, consuming an untracked additional EUR 0.4–0.8M in effective spend against the EUR 50M ceiling.
- Independent gate-review panel hours and expertise systematically underestimated: actual honoraria and preparation time required EUR 0.40–0.50M (vs. budgeted EUR 0.30M) to attract qualified reviewers and support full technical depth, deferring other Phase One work or reducing contingency.
- Kenyan replication defect-tracking and auditing work (EUR 0.15M, 8 weeks) deferred from Phase Two into Phase Three, consuming time when full-scale build is underway, forcing either rushed documentation fixes or extended Phase III schedule beyond Month 60 (2031-10-09) limit.
- Phase One planned spend EUR 5.5M allocated without time-phasing: all work front-loaded (Months 0–4 = 2026-10-09 to 2027-02-09) creates cash-flow mismatch, strains host institution's ability to manage spending and invoicing, and obscures monthly cost control.

## Audit - Procedures

- Quarterly external audit of programme finances by an independent firm: verify actual vs. planned spend against the EUR 50M ceiling (including KES converted at locked baseline rate), reconcile all invoices and reimbursements against approved work packages, confirm contingency reserves (EUR 4.0M total, EUR 0.5M currency fund) are tracked and released only by documented funder decision; report to funder monthly with variance analysis and trend forecast.
- Semi-annual review of the audited assistance log (Kenyan replication): independent auditor (not project team, not host institution) examines all logged assistance to Denmark-team members and third-party experts; measures frequency (target <4 h/month hands-on troubleshooting), type (acceptable: scheduled safety review, regulatory consultation; unacceptable: routine operation or design help), and flags any patterns suggesting insufficient Kenyan-team competence or undisclosed developer involvement; findings escalated to gate-review panel if threshold breached.
- Pre-gate independent technical review of all measurement frameworks, disproof-experiment protocols and success thresholds: external auditor (independent of project) verifies that reactor-concept comparison methods lock measurement definitions and decision rules before experiments begin, that scale-up disproof thresholds are pre-registered and linked to deployment-scenario sensitivity, and that any post-hoc threshold adjustment (if proposed) requires documented justification and panel approval before proceeding.
- Annual site-envelope baseline monitoring in Kenya (Phase Three): independent third-party audit confirms that the Kenyan site's operating conditions (power-outage frequency and duration, water quality, spare-part availability, local technician skills) remain within the documented baseline (Month 4 = 2027-02-09 Kenyan Site Baseline Report); if any parameter drifts >20%, document drift and trigger contingency action (controlled stressors or re-assessment of hypothesis B evidence); report findings to gate-review panel at end of Year 4 (Month 48 = 2030-10-09).
- Regulatory correspondence audit (quarterly): verify that all informal pre-submission feedback from Danish, EU and Kenyan authorities is documented in writing (email, signed meeting minutes); confirm that feedback is logged as 'non-binding preliminary guidance' (not characterized as 'approval') in project records; audit for any misrepresentation of regulatory status to funder or adopters; flag any undisclosed authority requests for additional data or formal applications.
- Strain-rights and patent-freedom-to-operate review audit (Month 4 = 2027-02-09, pre-Phase-One gate): independent legal counsel (not employed by project team) verifies that the Strain Feasibility Report includes: (a) written confirmation from strain holders for research, commercial, redistribution and modification uses; (b) patent search results per jurisdiction covering hydrogen fermentation, autotrophic protein, single-cell protein and the reference strain; (c) documented Kenyan biosafety import feasibility; (d) identified IP restrictions and their implications; audit confirms no concealed third-party claims or restrictions blocking independent replication.

## Audit - Transparency Measures

- Monthly financial dashboard (internal to funder and host institution): track actual vs. planned spend by work package and phase, show remaining contingency reserves (total, earmarked to strain/regulatory, free, and currency fund), flag any variance >10% in a cost category or >5% in cumulative spend, include KES spending converted at locked baseline rate and note FX variance; dashboard published to steering committee and internal auditors.
- Published gate-review panel recommendations and funder responses: after each gate (Phase One Month 12 = 2027-10-09, Phase Two Month 30 = 2029-04-09, Phase Three Month 60 = 2031-10-09), publicly release the independent panel's full written recommendation (continue, modify, research-only, or stop) including rationale against pre-defined criteria, measured evidence (e.g., productivity data, strain stability, documentation defects), and any uncertainties or dissenting views; if funder's decision deviates from the panel recommendation, publish the funder's written justification alongside the panel's recommendation; make both documents publicly available on project website.
- Quarterly transparency report to adopters and stakeholders: summarize progress against locked deployment scenarios and thresholds, publish measured KPIs (cost per kg, capacity, uptime, resupply autonomy), document any scenario-threshold renegotiation or adopter withdrawal with reason, include regulatory milestones and any changes in regulatory feedback; report energy per kg and cost per kg with uncertainty ranges; flag any risk that a locked scenario may not be achievable and the basis for concern.
- Open defect-tracking system for documentation: publish the audited assistance log (summary, not raw details) and the Phase II defect tracker (all logged documentation ambiguities, severity, resolution, source of resolution) as appendices to the Phase II gate report and Phase III final report; enable external reviewers to assess whether documentation gaps were systematic or residual, and whether Kenyan team independence was credibly maintained.
- Regulatory correspondence and strain-rights summary: publish a one-page summary per jurisdiction (Denmark/EU, Kenya) documenting: (a) regulatory contacts and pre-submission feedback received (dates, topics, non-binding status); (b) strain rights confirmed for each reference and backup strain (research, commercial, redistribution, modification uses and jurisdictions); (c) identified IP restrictions and their implications; (d) any changes in regulatory guidance or IP landscape discovered post-Phase-One; this is released after safety and legal review but before the Phase One gate decision, so external reviewers can assess regulatory feasibility.
- Annual public progress report (Years 1–5): document completed milestones by phase, measured productivity and safety results, reactor concept selection rationale and measured gap vs. benchmarks, scale-up evidence and disproof-experiment outcomes, downstream-processing validation status, Kenyan site conditions (baseline vs. actual), operator training and competency results, cost and energy per kg trajectory vs. deployment thresholds, and identified risks and mitigation actions; include raw experimental data (anonymized where sensitive), analysis methods and uncertainty ranges; facilitate independent review and external credibility assessment.

# Internal Governance Bodies

### 1. Project Steering Committee

**Rationale for Inclusion:** This is an infrastructure-scale, multi-country, high-complexity R&D programme with five critical decision levers (reactor concept, strain rights, replication independence, threshold locking, safety design) and substantial technical, legal, financial and organizational risk. The Steering Committee provides strategic oversight, escalation authority and rapid decision-making for cross-functional issues that affect project direction, risk posture or gate readiness. It bridges the independent gate-review panel (external authority) with operational management and ensures alignment of technical, regulatory, financial and partnership decisions.

**Responsibilities:**

- Approve Phase One and Two work plans, budgets and gate criteria before execution begins
- Escalate and resolve conflicts between technical design choices and safety, regulatory, partnership or financial constraints
- Review quarterly cost-control reports and authorize spending from contingency reserves (technical contingency and currency fund)
- Approve all gate-extension requests and contingency activations; track impact on schedule and budget
- Monitor unsigned partner commitments, site access and permit status; trigger contingency plans if commitments slip
- Approve recruitment and dismissal of independent gate-review panel members; ensure funder-managed independence
- Approve changes to locked deployment scenarios or product-category choice, in writing with all stakeholder notification
- Address personnel, organizational or partnership issues that could affect team continuity or independence

**Initial Setup Actions:**

- Establish written charter specifying decision thresholds (e.g., contingency draw, schedule extension, scope change authority) and conflict-resolution process
- Confirm membership roles, accountability and meeting schedule (quarterly minimum, monthly as needed)
- Define escalation criteria and trigger conditions (e.g., cost variance >5%, schedule slip >3 weeks, safety finding, partner withdrawal)
- Establish procedure for publishing deviation from gate-review panel recommendations, with justification, to all stakeholders
- Secure separate budget line for gate-review panel operations, independent of project team spending authority
- Schedule first meeting by Month 0.5 (2026-10-24) to confirm charter, roles and initial action items

**Membership:**

- Project Lead (host institution, process or project engineer; chair)
- Funder Representative (budget authority, release decisions, contingency approval)
- Kenyan Partner Lead (co-development partner; partnership and site governance)
- Finance Manager (cost control, budget tracking, FX management, contingency oversight)
- Safety and Regulatory Lead (ATEX, hazard analysis, permitting and compliance risk)
- Independent Observer or External Advisor (optional; non-voting, ensuring transparency and identifying blind spots)

**Decision Rights:** Authority to make or escalate any decision affecting Phase One or Two work scope, budget (draws from contingency reserve up to thresholds per charter), personnel (project-direct staff, not host-institution staff), schedule (within the Month 60 = 2031-10-09 hard constraint and subject to gate approval), gate criteria and locked deployment scenarios. Authority does not extend to approval of individual scientific or engineering design choices (delegated to Project Management Office and technical working groups) or to unilateral override of gate-review panel recommendations (requires published justification). Decisions on spending >EUR 500,000 from contingency, schedule extensions >4 weeks, or changes to locked scenarios require documented consensus or majority vote with dissent published.

**Decision Mechanism:** Quarterly meetings with written agenda and pre-circulated materials 2 weeks in advance. Decisions by consensus where possible; if consensus cannot be reached, majority vote (>50% of voting members present, minimum 4 of 6 quorum) with dissenting views documented. For urgent escalations (e.g., safety incident, unexpected barrier), chair may convene ad hoc meeting with 48-hour notice. All decisions recorded in written minutes with rationale, options considered and any dissenting view. Tie-breaker: Project Lead holds deciding vote only if consensus and majority voting fail; all tie-breaker decisions published to steering committee members and the independent gate-review panel with justification.

**Meeting Cadence:** Quarterly steering committee meetings (Month 3, 6, 9, 12 = 2027-01-09, 2027-04-09, 2027-07-09, 2027-10-09 in Phase One; then Months 15, 18, 21, 24, 27, 30 = 2028-01-09, 2028-04-09, 2028-07-09, 2028-10-09, 2029-01-09, 2029-04-09 in Phase Two; then Months 36, 42, 48, 54 = 2029-10-09, 2030-04-09, 2030-10-09, 2031-04-09 in Phase Three). Additional monthly one-hour updates or teleconferences as needed during active gate-review periods (Months 9-12 = 2027-07-09 to 2027-10-09, 24-27, 48-54) or contingency-activation phases. Extended meetings (half-day) scheduled at each gate decision point (Month 10 = 2027-08-09 Phase One gate, Month 30 = 2029-04-09 Phase Two gate, Month 60 = 2031-10-09 Phase Three gate) to review evidence and approve gate-transition actions.

**Typical Agenda Items:**

- Financial and schedule progress against Phase plan (actual vs. forecast, variance trends, contingency draw status, FX impact)
- Risk and issue log review (safety incidents, regulatory feedback, partnership or access concerns, technical uncertainties)
- Gate-readiness assessment: evidence freeze status, panel briefing materials preparation, decision-path clarity for upcoming gate
- Personnel, staffing and organizational continuity (key departures, recruitment status, training completion)
- Partner and funder alignment: confirming commitment status, addressing unresolved dependencies, publishing transparency reports
- Deployment scenario and threshold status (any renegotiation requests from adopters, changes in regulatory guidance affecting scenarios)

**Escalation Path:** Issues not resolvable by consensus within the Steering Committee escalate to the Funder (via the Funder Representative), who holds final release authority and can invoke external mediation or expert review. Safety-related escalations go directly to the independent gate-review panel, which has authority to recommend project modification or stop. Partnership or organizational conflicts (e.g., host-institution priority shift affecting dedicated staff) escalate to the host-institution rector or executive director (via the Project Lead), with a written escalation document and 2-week resolution window; if unresolved, escalate to the Funder. Gate-review panel recommendations that conflict with Steering Committee preference are published transparently; the Funder makes the final release decision and publishes any deviation from panel advice.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** This complex programme requires rigorous day-to-day execution across multiple technical workstreams (reactor comparison, strain validation, safety analysis, regulatory engagement), two physical sites (Denmark and Kenya), multiple partners, a tight Phase One budget (EUR 6M ceiling) and a critical Phase One gate at Month 9 (2027-07-09). The PMO ensures consistent planning discipline, cost and schedule tracking, work-package completion, and readiness for each gate. It also manages operational risk (equipment procurement, facility setup, team coordination) and coordinates the independent gate-review panel's information needs. Without tight PMO discipline, the EUR 50M programme could drift early through scope creep or slow mobilization, consuming the 3-month Phase One float.

**Responsibilities:**

- Maintain Phase One and Two detailed work schedules with critical path, resource allocation and dependency tracking; update weekly and report monthly to Steering Committee
- Track Phase One spending by work package against EUR 5.5M planned and EUR 6M ceiling; monthly cost-control report reconciling actual invoices against approved allocations; flag variance >10% in any cost category or >5% cumulative
- Manage procurement for laboratory equipment, bioreactors, analytical instruments and facility setup; track lead times, contracts, delivery status and risk of schedule impact
- Coordinate with host-institution facilities, Danish partner technical staff and Kenyan co-development partner on site access, utilities, equipment installation and training schedules
- Manage Phase One work packages: landscape review (Month 0-3 = 2026-10-09 to 2027-01-09), bench experiments (Month 1-9 = 2026-11-09 to 2027-07-09), HAZOP and safety analysis (Month 1-4 = 2026-11-09 to 2027-02-09), regulatory engagement (Month 0-4 = 2026-10-09 to 2027-02-09), Kenyan site baseline study (Month 1-4 = 2026-11-09 to 2027-02-09), adopter engagement (Month 2-7 = 2026-12-09 to 2027-05-09), gate-panel chartering (Month 0-1 = 2026-10-09 to 2026-11-09.5)
- Prepare gate-panel briefing materials (technical reports, raw data, analysis methods, measurement frameworks, decision criteria) 4-6 weeks before each gate meeting
- Maintain defect-tracking systems: audited assistance log (Kenyan replication), documentation-defect log (Phase Two onwards), regulatory-feedback log, strain-rights and patent-freedom-to-operate tracking
- Coordinate with the independent gate-review panel: schedule meetings, provide secure document-sharing access, handle confidential correspondence, publish final panel recommendations and funder responses

**Initial Setup Actions:**

- By Month 0.5 (2026-10-24): establish detailed Phase One work schedule (Gantt chart) with 100+ work packages, assigned owners, dependencies and critical path; lock all deadlines tied to the Month 9 (2027-07-09) evidence freeze
- By Month 0.5 (2026-10-24): establish cost-tracking procedure (invoicing, cost categories, contingency reserve tracking, currency conversion at locked baseline rate); set up monthly cost-control reporting template and dashboard
- By Month 1 (2026-11-09): procure all long-lead-time equipment (bioreactors, electrolyzers, analytical instruments) with contracts specifying delivery by Month 3-4 (2027-01-09 to 2027-02-09)
- By Month 1 (2026-11-09): establish measurable KPI framework locked in writing (volumetric productivity definition, energy per kg formula, system boundary, capacity-utilization assumption, measurement methods per instrument)
- By Month 1.5 (2026-11-24): establish and lock measurement and disproof-experiment protocols for reactor comparison (pre-registered decision thresholds, analytical methods, success criteria)
- By Month 2 (2026-12-09): establish defect-tracking systems (issue tracker or shared database) for documentation gaps, assistance log auditing, regulatory feedback and strain-rights tracking; assign auditor contacts

**Membership:**

- PMO Director or Programme Manager (overall PMO accountability, Steering Committee interface)
- Phase One Work-Package Owner (Phase One schedule, cost tracking, workstream coordination)
- Cost Controller or Finance Coordinator (monthly cost-control reports, contingency-reserve tracking, invoicing)
- Procurement Manager (equipment lead times, contracts, supplier management)
- Gate-Panel Administrator (panel scheduling, document repository, confidential correspondence, publication of recommendations)
- Technical Coordinator or Data Manager (measurement framework, defect-tracking system administration, KPI reporting)

**Decision Rights:** PMO has authority to manage work-package planning, schedule, procurement and cost-tracking decisions within the approved Phase One plan and budget allocations. PMO can authorize work-package-level changes (e.g., shifting tasks between months, re-allocating within a cost category) if total cost and critical-path schedule are unaffected. PMO cannot approve spending from contingency reserves (escalates to Steering Committee if variance triggers contingency draw). PMO cannot change locked deliverables, measurement frameworks, disproof thresholds or gate criteria (escalates to Steering Committee if change is justified). PMO provides recommendations to Steering Committee on cost-control or schedule-risk mitigation, but Steering Committee retains approval authority.

**Decision Mechanism:** Weekly PMO coordination meetings (30-60 min) with Phase One workstream leads and cost controller; written action-item tracker maintained. Monthly cost-control report generated by 5th working day of month; if variance >10% in a category, root-cause analysis and mitigation plan required. Procurement decisions made by PMO Director and Procurement Manager based on pre-approved contracts and cost authority. Gate-panel administration handled by Gate-Panel Administrator with written scheduling confirmation and document-access verification. Escalations to Steering Committee documented in writing with decision recommendation and rationale.

**Meeting Cadence:** Weekly PMO coordination (Monday, 60 min, standing meeting); monthly cost-control review (1st week of each month, 60 min); monthly gate-readiness check-in (4th week of each month, starting Month 7 = 2027-05-09, focusing on evidence freeze and panel-briefing material preparation). Increased frequency (biweekly or ad hoc) during critical periods (Months 0-3 = 2026-10-09 to 2027-01-09 for initial setup, Months 8-12 = 2027-06-09 to 2027-10-09 for Phase One gate preparation).

**Typical Agenda Items:**

- Work-package status by phase and owner (on track, at risk, delayed); critical-path items; dependencies blocking other work
- Monthly cost-control: actual vs. forecast by category, cumulative variance, contingency-draw requests and approvals, currency-conversion status
- Procurement and equipment delivery status (long-lead items, contract negotiations, site-access constraints, installation schedule)
- Schedule risk and mitigation: any threats to evidence freeze deadlines (Month 9 = 2027-07-09, Month 21 = 2028-07-09, Month 57 = 2031-07-09); proposed float usage or timeline adjustments
- Gate-readiness: briefing-material drafts due, panel-communication status, decision-criteria clarity for upcoming gate

**Escalation Path:** Work-package delays or cost overruns exceeding thresholds (>2 weeks schedule slip, >10% cost variance in a category) escalate to Steering Committee for contingency or schedule decision. Safety-related findings (e.g., HAZOP results requiring design rework) escalate directly to Safety and Regulatory Lead (Steering Committee member) and independent gate-review panel. Procurement risks (e.g., critical equipment delivery at risk) escalate to Steering Committee if mitigation cannot be completed within the phase schedule. Disputes over work-package scope or resource allocation escalate to the Project Lead (Steering Committee chair) for mediation.
### 3. Technical Working Group: Reactor Concept and Scale-Up

**Rationale for Inclusion:** Gas-liquid contacting and reactor concept is the first critical decision lever and directly determines hydrogen transfer rate, volumetric productivity, explosion hazard, ATEX burden, repair skill and energy per kilogram. The plan requires matched bench-scale comparison of three concepts (pneumatic, pressurized stirred, passive-feed) using identical strain, media and measurement framework, with pre-registered failure thresholds. This technical group manages the experiments, measurement rigor and decision logic. It also designs and oversees the scale-up evidence ladder (bench to pilot to reference unit) with pre-registered disproof experiments. Without a dedicated technical group focused on measurement rigor and pre-registration discipline, post-hoc rationalization of results and selection bias toward a favored concept could undermine the comparisons and compromise the Phase Two gate.

**Responsibilities:**

- Define measurement and KPI framework before bench experiments begin: locked definitions for volumetric productivity, mass-transfer coefficient (kLa), energy per kg, system boundary, capacity-utilization assumption, measurement methods per analytical instrument; consistent use across all reactor concepts
- Pre-register reactor-concept comparison decision rules before Phase One experiments: e.g., 'If productivity gap <15% between concepts, choose simpler; 15-25% use weighted scoring; >25% choose highest unless ATEX is blocked'
- Conduct triplicate matched bench-scale experiments (pneumatic, stirred, passive-feed) on identical C. necator strain and media; assign single lead analyst to minimize inter-analyst variation
- Perform external audit of measurement framework and data analysis before Phase One gate (independent technical reviewer verifies protocol was followed, outliers handled consistently, decision thresholds applied)
- Document all deviations from protocol, analytical variation, and uncertainty ranges in results; publish raw data and analysis methods in supplementary material
- Establish pre-registered disproof experiments for Phase Two scale-up (bench to pilot scale): e.g., mass-transfer coefficient decline <25%, volumetric productivity within 15% of bench, strain stability <10% drift over 10-16 week run
- Conduct long-term strain-stability validation in Phase Two (10-16 week culture at intended operating conditions with weekly sampling for growth rate, nucleic-acid content, viability)
- Manage scale-up evidence ladder: intermediate-scale experiments, validated engineering models with stated uncertainty, and critical-assumption testing; gate release of reference-unit hardware (EUR 4.0M) only at Phase Two gate if disproof thresholds are met
- Coordinate with Safety and Regulatory Working Group on hazard-analysis implications of each reactor concept; publish safety-gap analysis (e.g., pressure rating, seal requirements, ignition exposure)

**Initial Setup Actions:**

- Month 0-1 (2026-10-09 to 2026-11-09): Establish written KPI Framework and Measurement Protocol document, locked and signed by lead analysts, project manager and an external technical auditor; specify all definitions, system boundaries, analytical methods and success thresholds
- Month 1 (2026-11-09): Pre-register Reactor Concept Comparison Protocol with decision rules, success thresholds (e.g., <15% productivity gap = simplicity wins), analytical-variation tolerance and exclusion criteria; publish to Steering Committee and gate-review panel for feedback before experiments begin
- Month 1 (2026-11-09): Recruit external technical auditor (independent of project team) to perform pre-Phase-One-gate audit of measurement framework and data analysis; confirm auditor's availability and timeline
- Month 2 (2026-12-09): Finalize analytical equipment setup (HPLC, gas chromatograph, bioreactor sensors) and calibration; run test samples on all three reactors to confirm analytical consistency
- Month 3 (2027-01-09): Initiate bench-scale experiments (3 reactor concepts x 3 replicates = 9 cultures); confirm inoculation source, medium composition and baseline parameters are identical across all cultures

**Membership:**

- Reactor Concept Lead or Principal Investigator (overall technical direction, decision-making on reactor selection)
- Bench-Scale Experimental Lead (day-to-day experiment management, culture maintenance, sampling)
- Gas-Transfer and Fermentation Specialist (mass-transfer coefficient measurement, gas-balance analysis, productivity calculations)
- Process Safety Engineer (hazard implications of each reactor concept, ATEX compliance assessment)
- Scale-Up and Modeling Engineer (disproof-experiment design, scale-up models, pilot-scale and reference-unit design)
- Data Manager or Analytical Coordinator (HPLC, GC, bioreactor software, data processing, uncertainty quantification)

**Decision Rights:** Group decides: final KPI definitions and measurement protocols (locked before experiments); reactor-concept comparison decision rules and success thresholds (pre-registered and published); analytical methods and data-quality criteria; interpretation of results and flagging of outliers or protocol deviations; recommendation to Steering Committee on reactor selection. Group cannot unilaterally change the locked measurement framework or disproof thresholds after experiments begin; any proposed change requires documented justification and approval from Steering Committee and independent technical auditor. Group does not decide on funding allocation or gate criteria (those are Steering Committee decisions), but provides technical evidence and recommendations to inform those decisions.

**Decision Mechanism:** Weekly technical meetings (60-90 min) with all workstream members to review experimental progress, address analytical issues and track against schedule. Pre-experiment meeting to confirm protocol alignment and baseline parameter checks. Mid-run review (Week 3-4 of each culture) to confirm steady-state and assess productivity trends. Post-experiment analysis meeting to review raw data, apply decision rules and document results. External auditor review scheduled for Month 9 (2027-07-09) before Phase One gate evidence freeze. Decisions on protocol interpretation or threshold application made by consensus; if disagreement arises, documented and escalated to Steering Committee with evidence and rationale from each perspective.

**Meeting Cadence:** Weekly technical working group meetings (Mondays, 90 min) during active bench-scale work (Months 1-9 = 2026-11-09 to 2027-07-09 in Phase One); biweekly or as-needed during Phase Two scale-up experiments (Months 12-24 = 2027-10-09 to 2028-10-09). Additional monthly technical reviews with Steering Committee starting Month 7 (2027-05-09) for gate-readiness updates.

**Typical Agenda Items:**

- Culture status: viability, contamination checks, growth rate, oxygen-uptake rate measurements; any deviations from protocol
- Analytical results (HPLC, GC): data quality, calibration status, any re-runs or outliers; comparison of results across the three reactor concepts
- Preliminary productivity and energy calculations; gap analysis vs. pre-registered success thresholds
- Safety and regulatory implications of each reactor concept (pressure, seal stress, flammable-range exposure)
- Scale-up disproof-experiment design (bench to pilot scale); assumptions being tested and pre-registered failure thresholds
- Documentation and publication planning (raw data, analysis methods, uncertainty ranges, supplementary material for external audit)

**Escalation Path:** Technical disagreements over measurement interpretation or threshold application escalate to the independent technical auditor (Month 9 = 2027-07-09) for binding review. If audit identifies protocol deviations or analytical-variation issues that invalidate results, escalate to Steering Committee for decision: re-run experiments or accept uncertainty and proceed with caveats. Safety findings that suggest a reactor concept poses unacceptable hazard escalate to Safety and Regulatory Working Group and then Steering Committee. Results suggesting all three reactor concepts fail the pre-registered thresholds escalate to Steering Committee with recommendation: accept higher productivity loss from simplification, re-define the thresholds (with external audit), or escalate to gate-review panel for pathway advice.
### 4. Technical Working Group: Safety, ATEX and Hazard Analysis

**Rationale for Inclusion:** Hydrogen-oxygen explosion hazard is the core technical safety risk and the fifth critical decision lever (Inherent Safety Design Basis and Adopter Change Boundary). The plan requires formal Process Hazard Analysis (HAZOP or LOPA), ATEX-compliant design, independently reviewed interlocks and emergency shutdown, and definition of which components and parameters adopters may change without full safety reassessment. A dedicated safety working group conducts and documents the hazard analysis early (Month 1-4 = 2026-11-09 to 2027-02-09), engages an independent ATEX consultant for review, and maintains the 'Adopter Change Boundary' document that controls what replicators can safely modify. Without early, rigorous hazard analysis, late discovery of a design flaw could force re-certification, schedule delay or project stop.

**Responsibilities:**

- Conduct formal Process Hazard Analysis (HAZOP or LOPA) covering electrolyzer, gas lines, fermentor headspace and control systems; identify all failure modes (seal rupture, electrolyzer malfunction, backflow, overpressure, operator error) by severity and likelihood
- Develop and document the safety design basis: selection of inherent limits (flammable-range composition, minimal gas inventory) or layered instrumented protection (interlocks, sensors, independent emergency shutdown); define quantitative safety target (e.g., probability of uncontrolled ignition <1 per 100,000 operating hours)
- Specify design response for each failure mode: eliminate hazard, reduce likelihood through design, or protect via layered control
- Engage an independent third-party ATEX consultant (not project staff, not host institution) to review interlock logic, emergency-shutdown design and control-system failure assumptions; obtain written sign-off before pressurized builds or high-gas-inventory configurations are committed
- Define and publish the Adopter Change Boundary: a short list of pre-assessed components and parameters that adopters may substitute or modify without re-certification (e.g., electrode material, medium pH limits within documented range), and which require full safety re-analysis (pressure rating, interlock logic, emergency-shutdown system)
- Create a machine-readable safety case or parametric model (if feasible) in which adopters can check proposed modifications against the hazard analysis; publish per-jurisdiction patent restrictions and safe-change envelopes
- Design and test the safety design on a small-scale mockup (e.g., 1-5 L) before committing to the 20 L reference unit; validate all interlocks, emergency shutdown and gas-composition control experimentally
- Maintain a safety-incident log; document any near-miss, actual incident or anomaly during Phase One, Two and Three operation; investigate root cause and implement corrective action
- Prepare safety chapters for the Phase One gate report (HAZOP findings closed, safety design basis rationale, ATEX consultant sign-off, Adopter Change Boundary v0.1)
- Update safety design basis iteratively as reactor concept selection and scale-up tests provide new data (pressure rating, seal-stress analysis, control-system complexity)

**Initial Setup Actions:**

- Month 0.5 (2026-10-24): Identify and contract an independent ATEX and process-safety consultant (external firm or specialist, not affiliated with host institution); scope HAZOP facilitation, independent interlock review and sign-off
- Month 1 (2026-11-09): Convene HAZOP team (process engineer, safety engineer, ATEX consultant, bioreactor specialist); establish HAZOP scope (electrolyzer to fermentor headspace to off-gas), guidewords and node structure
- Month 1-2 (2026-11-09 to 2026-12-09): Conduct formal HAZOP or LOPA sessions, documented in writing; identify and rank failure modes by severity (S: catastrophic, major, minor, negligible) and likelihood (L: frequent, occasional, rare, remote); develop risk matrix (S x L) and assess acceptability
- Month 2 (2026-12-09): Draft Safety Design Basis document outlining choice of inherent vs. instrumented protection, quantitative safety target, design response to each failure mode, and preliminary Adopter Change Boundary
- Month 2-3 (2026-12-09 to 2027-01-09): Independent ATEX consultant reviews Safety Design Basis, interlock logic (draft), control-system assumptions and compliance pathway; provides written feedback and sign-off on feasibility
- Month 3 (2027-01-09): Publish Adopter Change Boundary v0.1 as part of blueprint v0.1; specify which components/parameters adopters may change without re-assessment and which require full analysis

**Membership:**

- Safety and Regulatory Lead or Safety Engineer (group lead, HAZOP coordination, design-basis documentation)
- Process Safety Specialist or HAZOP Facilitator (HAZOP facilitation, risk-matrix development, failure-mode ranking)
- Independent ATEX Consultant or Third-Party Safety Reviewer (external, unaffiliated; interlock review, compliance assessment, sign-off)
- Reactor and Fermentation Specialist (process design details, gas-handling constraints, operational control logic)
- Control Systems and Automation Engineer (interlock design, emergency-shutdown logic, PLC/hardwired architecture, sensor redundancy)

**Decision Rights:** Group decides: HAZOP scope and structure; severity/likelihood rankings and risk matrix; design response to each failure mode; choice of inherent limits vs. instrumented protection; quantitative safety targets; Adopter Change Boundary (pre-assessed substitutes and parameter ranges); control-system architecture and interlock logic. Group cannot approve the final safety design without independent ATEX consultant sign-off. Group provides recommendations to Steering Committee on design trade-offs (e.g., safety margin vs. productivity); Steering Committee approves the Safety Design Basis as a project constraint. Any change to the Adopter Change Boundary after the Phase One gate requires independent review and Steering Committee approval.

**Decision Mechanism:** Monthly safety working group meetings (90 min) with all members to review HAZOP progress, control-system design and independent consultant feedback. HAZOP sessions conducted in facilitated workshops (typically 2-3 full-day sessions) with documented outputs (hazard register, risk matrix, design-response matrix). Independent consultant review scheduled for Month 2-3 (2026-12-09 to 2027-01-09), with formal written feedback and sign-off letter. Decisions on hazard severity, design response or control-system configuration made by consensus; if disagreement arises, documented with options and escalated to independent consultant for advisory judgment. Final Safety Design Basis approved by consensus of group + independent consultant + Steering Committee.

**Meeting Cadence:** Monthly safety working group meetings (60-90 min) during hazard-analysis phase (Months 1-4 = 2026-11-09 to 2027-02-09); weekly meetings during control-system design and interlock validation (Months 3-5 = 2027-01-09 to 2027-03-09). Formal HAZOP workshops scheduled for Month 1-2 (2026-11-09 to 2026-12-09) (typically 3-4 separate half-day or full-day sessions spread over 2-3 weeks). Independent consultant engagement and sign-off by end of Month 3 (2027-01-09). Thereafter, monthly reviews of any design changes or incident investigations (Months 6 onwards). Escalated agenda time at Steering Committee meetings (quarterly) for safety-status updates and any issues requiring Steering Committee decision.

**Typical Agenda Items:**

- HAZOP progress: guidewords reviewed, nodes assessed, failure modes identified, severity/likelihood assigned
- Risk-matrix results: high-risk failure modes and proposed design responses
- Control-system and interlock design: logic flow, sensor redundancy, emergency-shutdown sequence, validation approach
- Independent consultant feedback: comments on design basis, compliance pathway clarification, questions for project team
- Adopter Change Boundary: candidate substitutes for components, parametric ranges for safe operation, documentation of rationale

**Escalation Path:** If HAZOP identifies a failure mode of unacceptable risk (rank: Catastrophic + Frequent, or Major + Occasional), escalate to Steering Committee for design decision: eliminate hazard, invest in more-complex protection, or reduce the hazard to acceptable risk. If independent ATEX consultant identifies a compliance barrier (e.g., proposed design does not meet ATEX Directive requirements), escalate to Steering Committee with consultant's recommended mitigation. If during Phase Two or Three testing a safety anomaly is discovered (near-miss or incident), conduct root-cause investigation and escalate findings + corrective action to the independent gate-review panel for assessment of design adequacy. Any proposed change to Adopter Change Boundary after Phase One gate escalates to independent consultant and Steering Committee for approval.
### 5. Technical Working Group: Strain Rights, Regulatory Pathway and Intellectual Property

**Rationale for Inclusion:** Strain rights and regulatory classification is the second critical decision lever. The plan requires a reference strain lawfully obtainable for research, commercial production, redistribution and modification in both Denmark and Kenya; confirmation of Kenyan biosafety import feasibility; a patent-freedom-to-operate landscape review; and a credible regulatory pathway for the chosen product category. These activities must be completed early (by Month 4 = 2027-02-09) to avoid Phase One delays, yet they require legal expertise and regulator contact that cannot be rushed. A dedicated regulatory and IP working group ensures consistent tracking of strain rights, regulatory feedback and IP restrictions, and prevents mischaracterization of non-binding regulator guidance as 'approval' to Steering Committee or adopters.

**Responsibilities:**

- Conduct comprehensive strain-rights analysis for primary and backup reference strains: contact strain holders, confirm rights for research use, commercial production, redistribution, modification and derived strains; document all restrictions in writing
- Conduct patent and freedom-to-operate landscape review covering: hydrogen fermentation, autotrophic protein production, single-cell protein, the specific reference strain, and any existing patents or pending claims in Denmark, EU, Kenya and Bangladesh; identify IP risks and mitigation options (design-around, license, patent pledge, publication barrier)
- Confirm lawful strain import into Kenya: contact Kenya National Biosafety Authority and strain holder to verify any import restrictions, permits or material-transfer-agreement terms; document feasibility and timeline
- Engage with Danish/EU and Kenyan regulatory bodies via informal pre-submission dialogue to identify hard requirements for: contained-use authorization, biosafety classification of the organism, product safety and classification (animal feed, food ingredient, emergency nutrition), distribution pathway, and timeline for approval
- Log all regulatory feedback in writing (email, meeting minutes) with date and source; distinguish non-binding preliminary guidance from binding requirements; flag any authority requests for additional data or formal applications
- Select and lock the provisional product category at the Phase One gate based on regulatory pathway feasibility and preliminary composition data; document regulatory requirements for that category and timeline to full authorization
- Develop freedom-to-operate summary per jurisdiction: published one-page summary stating: (1) what is licensed under what terms; (2) identified IP restrictions and implications; (3) what adopters can and cannot do commercially without additional licensing
- Establish steward-entity governance: design the legal entity that will hold and enforce open licences, manage patent pledges and prevent closed forks; ensure it is independent of the host institution and can operate long-term with sustainable funding
- Prepare regulatory chapters for Phase One gate report (Strain Feasibility Report with primary and backup strains, patent landscape summary, regulatory pathways, product-category recommendation)

**Initial Setup Actions:**

- Month 0.5 (2026-10-24): Contract independent legal counsel (patent specialist and regulatory consultant) to conduct landscape review and strain-rights analysis; define scope covering Denmark, EU, Kenya and Bangladesh; establish timeline for Phase One completion
- Month 1 (2026-11-09): Identify 4-5 candidate reference strains (prioritize public-collection strains such as C. necator H16, ATCC, DSMZ); compile list of strain holders and contact information
- Month 1 (2026-11-09): Initiate direct contact with strain holders via email/phone: request documented confirmation of rights for research, commercial production, redistribution, modification and derived strains; any material-transfer-agreement terms; Kenyan import restrictions
- Month 1-2 (2026-11-09 to 2026-12-09): Engage patent specialist to conduct freedom-to-operate search in patent databases (USPTO, EPO, WIPO, Kenya patent office); compile list of relevant patents, publication dates, claims and jurisdiction coverage
- Month 2 (2026-12-09): Send formal inquiry to Kenya's National Biosafety Authority: describe the proposed contained-use process, strain candidates and operating envelope; request preliminary written feedback on import restrictions, biosafety classification and contained-use authorization pathway
- Month 2 (2026-12-09): Initiate informal pre-submission consultation with Danish Environmental Protection Agency or competent EU authority: describe proposed process, strain, operating envelope and candidate product categories; request written guidance on hard requirements per category

**Membership:**

- Regulatory Lead or Regulatory Affairs Manager (group coordination, authority liaison, regulatory strategy)
- Independent Legal Counsel – Patent Specialist (freedom-to-operate search, patent landscape interpretation, licensing terms)
- Independent Legal Counsel – Regulatory Specialist (jurisdictional requirements, product-safety pathways, contained-use classification)
- Intellectual Property Coordinator (IP-restriction tracking, licensing terms summary, steward-entity design)
- Microbiologist or Operations Lead (strain characteristics, biosafety concerns, technical questions for authorities)

**Decision Rights:** Group decides: selection of primary and backup reference strains with documented rights confirmation; interpretation of patent landscape (which patents are blocking and which are design-around-able); identification of regulatory-pathway requirements per product category; recommendation for provisional product-category selection; steward-entity governance structure. Group cannot approve the final Strain Feasibility Report without sign-off from legal counsel on IP and strain-rights accuracy. Group provides recommendations to Steering Committee on regulatory risk (e.g., pathway approval timeline, data requirements); Steering Committee approves product-category selection and regulatory strategy. Any change to the locked product category after the Phase One gate requires independent regulatory review and full re-assessment of data requirements.

**Decision Mechanism:** Bi-weekly regulatory working group meetings (60 min) to track strain-holder responses, patent search progress and regulatory feedback. Conference calls with legal counsel (monthly or as needed) to discuss findings and next steps. Formal written Strain Feasibility Report drafted by Month 3 (2027-01-09) and reviewed by independent legal counsel for accuracy and completeness. Regulatory feedback log maintained in shared spreadsheet (updated weekly) with columns: authority, date, topic, feedback summary, binding or preliminary status, implications, project response. Decisions on strain-rights interpretation, patent-risk assessment or regulatory-pathway selection made by consensus of group + legal counsel; any disagreement documented with perspectives and escalated to Steering Committee for final judgment.

**Meeting Cadence:** Bi-weekly regulatory working group meetings (60 min) during Months 1-4 (2026-11-09 to 2027-02-09); monthly thereafter. Formal legal-counsel review meetings scheduled for Month 2 (2026-12-09) and Month 3 (2027-01-09). Strain Feasibility Report finalized and signed by Month 4 (2027-02-09). Thereafter, monthly monitoring of regulatory guidance changes and log updates (Months 5 onwards).

**Typical Agenda Items:**

- Strain-holder responses: received confirmations, pending replies, any restrictions identified
- Patent search progress: patents identified, relevant claims, jurisdiction coverage, freedom-to-operate assessment
- Regulatory feedback: communications from Danish/EU/Kenyan authorities, preliminary guidance vs. binding requirements, timeline for formal applications
- Strain-rights and IP-restriction summary for Strain Feasibility Report
- Product-category recommendation: regulatory pathway, approval timeline, data requirements per category

**Escalation Path:** If strain-holder imposes restrictions blocking commercial production or Kenyan import, escalate to Steering Committee immediately: activate backup-strain pathway and adjust timeline. If patent search identifies a blocking patent in Kenya or Denmark, escalate to Steering Committee with legal counsel for options: design-around, license negotiation, or patent challenge. If Kenyan biosafety authority indicates contained-use authorization is unlikely, escalate to Steering Committee: assess whether to proceed with alternative site or product category. If regulatory feedback conflicts with other project assumptions (e.g., authority recommends a product category different from current plan), escalate to Steering Committee with full context and implications for scale-up and deployment thresholds. Any misrepresentation of regulatory status (e.g., preliminary feedback characterized as approval) is flagged immediately to Steering Committee and independent gate-review panel as a governance or integrity risk.
### 6. Technical Working Group: Deployment Scenarios, Thresholds and Adopter Engagement

**Rationale for Inclusion:** Deployment Scenario Anchoring and Threshold Locking is the fourth critical decision lever. The plan requires 2-3 named prospective adopters, locked cost/capacity/reliability thresholds fixed before prototype evaluation, and published decisions at each gate that clearly pass or fail against these locked thresholds. This working group identifies and engages prospective adopters during Phase One (Months 2-7 = 2026-12-09 to 2027-05-09), conducts structured interviews on deployment constraints and cost tolerance, consolidates scenarios and locks them in writing by Month 9 (2027-07-09). Without this group, scenarios remain hypothetical, thresholds are adjusted post-hoc to fit results, and the final Go/Modify/Stop decision loses credibility. The group also tracks any adopter withdrawal or renegotiation and escalates to Steering Committee and gate-review panel.

**Responsibilities:**

- Identify 2-3 prospective adopters representing realistic deployment contexts (e.g., national food-security reserve agency, regional feed producer, humanitarian logistics organization); prioritize organizations with publicly stated mandates in food security or agriculture and decision-making authority over budget
- Conduct structured engagement with each adopter: in-person meetings covering current supply chains and costs, production-capacity needs, acceptable cost premium for vendor-independent solution, operational constraints (power reliability, water quality, technical skills, space), timeline expectations
- Validate adopter input by presenting scenario profiles and cost/capacity/reliability thresholds back to them; obtain feedback and refine scenarios iteratively
- Consolidate adopter input into 2-3 formalized deployment scenarios with locked thresholds: maximum production cost per kg usable protein, minimum useful capacity, required uptime and outage-survival duration; document rationale and data sources
- Obtain signed commitment from each adopter by Month 7 (2027-05-09), specifying: scenarios remain locked through Phase Three gate unless all parties formally agree to renegotiate; adopter withdrawal triggers public disclosure of reason; thresholds are used to evaluate Go/Modify/Stop decisions
- Lock scenarios in time-stamped document at Phase One gate (Month 9 = 2027-07-09); publish to all stakeholders, Steering Committee, gate-review panel and funder
- Monitor adopter status quarterly: flag any signals of withdrawal or renegotiation; report to Steering Committee and publish any formal withdrawals with stated reason
- Track regulatory, market and competitive changes affecting adopter interest (e.g., new policy on alternative proteins, competitor technology progress); assess impact on scenario credibility and recommend Steering Committee action if needed
- Prepare scenarios and thresholds chapters for Phase One gate report; include adopter interview summaries, scenario profiles, locked thresholds, and signed adopter commitments

**Initial Setup Actions:**

- Month 1-2 (2026-11-09 to 2026-12-09): Conduct landscape research on prospective adopter profiles (national reserves, feed producers, humanitarian organizations, regional agricultural agencies); identify 5-8 candidates with stated mandates in food security or livestock
- Month 2 (2026-12-09): Initiate outreach to 2-3 leading candidates; request in-person meetings or calls to explore project interest and data-gathering willingness
- Month 2-3 (2026-12-09 to 2027-01-09): Develop structured interview guide covering: current protein supply chain and cost, capacity needs, cost tolerance for new/alternative sources, operational constraints, timeline and decision-making process
- Month 3-4 (2027-01-09 to 2027-02-09): Conduct in-person or virtual interviews with each adopter; document responses in write-ups; develop preliminary scenario profiles

**Membership:**

- Adopter Engagement Lead or Deployment Strategy Manager (overall engagement, adopter relationship management)
- Techno-Economic Analyst or Cost-Model Lead (scenario cost and capacity assumptions, sensitivity analysis, threshold feasibility)
- Adoption Specialist or Social Science Researcher (adopter motivation, constraint validation, market-landscape analysis)
- Project Lead or Steering Committee Representative (governance liaison, escalation oversight)

**Decision Rights:** Group decides: selection and ranking of prospective adopters; scenario profiles (cost, capacity, uptime thresholds); threshold recommendations based on adopter input and cost-model sensitivity analysis. Steering Committee approves final locked scenarios and obtains adopter sign-off. Group cannot unilaterally adjust thresholds after Month 9 (2027-07-09); any renegotiation requires Steering Committee approval and all-party written agreement. Group recommends to Steering Committee how to handle adopter withdrawal or scenario-credibility threats.

**Decision Mechanism:** Monthly adoption working group meetings (60 min) during Phase One to coordinate interviews, discuss adopter feedback and refine scenarios. Adopter interviews conducted by 2-3 team members (interviewer + note-taker) to ensure accuracy and consistency. Interview summaries drafted and reviewed by group before next adopter meeting to identify convergent themes. Scenario profiles developed iteratively and validated with adopters via follow-up calls or meetings. Final locked scenarios approved by consensus of group + Steering Committee + all adopter signatories.

**Meeting Cadence:** Monthly adoption working group meetings (60 min) during Months 2-7 (2026-12-09 to 2027-05-09); increased frequency (biweekly) during final scenario-locking period (Months 6-9 = 2027-04-09 to 2027-07-09). Adopter interviews and follow-ups scheduled as needed within meeting-planning calendar.

**Typical Agenda Items:**

- Adopter-engagement status: interviews completed, pending, responses received and analyzed
- Scenario profiles emerging from adopter input: cost tolerance, capacity needs, uptime expectations
- Threshold sensitivity analysis: if productivity or downstream-processing cost exceeds model, what is impact on scenario viability?
- Adopter commitment and signing readiness (for Month 7 = 2027-05-09 target)
- Scenario-locking preparation: final drafts, time-stamping, publication plan

**Escalation Path:** If an adopter is reluctant to commit in writing or signals withdrawal, escalate to Steering Committee immediately: assess whether remaining scenarios remain credible or if additional adopter recruitment is needed. If adopter cost tolerance is lower than the cost-model forecast, escalate to Steering Committee for decision: accept a looser threshold, commit to cost-reduction work in Phase Two, or acknowledge the scenario may not be met. If regulatory changes or competitive developments threaten adopter interest mid-project, report to Steering Committee and gate-review panel; assess credibility of locked scenarios and recommend contingency action (e.g., scenario renegotiation or pivot to new adopter). Any adopter withdrawal after scenarios are locked triggers publication of reason to all stakeholders and reassessment of remaining scenarios' credibility by Steering Committee and gate-review panel.
### 7. Kenyan Replication Coordination and Independence Assurance

**Rationale for Inclusion:** Independent replication by a separate Kenyan team is a core proof point for the project's openness and reproducibility claims. The plan requires the team to obtain the strain, build the system from documentation alone and produce on-spec biomass under difficult infrastructure conditions (power outages, limited supply chains, local technician skills). Replication independence is audited via an assistance log (tracking all help from Danish developers or external experts) and a documentation-defect log (tracking every ambiguity found during build and its resolution). An early small-scale replication in Phase Two identifies documentation gaps cheaply before the full-scale Phase Three build. A dedicated coordination body ensures that the Kenyan team is truly separate from the Danish team, that assistance is logged transparently, that defects are tracked and resolved, and that gate reviews can credibly assess reproducibility.

**Responsibilities:**

- Manage institutional and partnership governance with the Kenyan co-development partner: confirm signed MoU covering staffing, site access, logistics, contingency plans for staff or partner changes; establish quarterly partnership reviews with Steering Committee
- Coordinate early paper-and-bench replication (Phase Two, Months 14-24 = 2027-12-09 to 2028-10-09): independent group builds a small (1-10 L) unit from draft documentation; track all issues found and document resolutions
- Maintain audited assistance log: document all communications and assistance between Kenyan team and Denmark team or third-party experts (safety review, regulatory consultation, specialist maintenance, emergency troubleshooting); auditor reviews log monthly and flags any assistance exceeding acceptable thresholds (target: <4 h/month hands-on troubleshooting)
- Maintain documentation-defect tracking system: log every ambiguity in documentation found during build or operation (location in docs, severity, resolution, source); auditor reviews defects and resolutions to confirm documentation gaps are being closed systematically
- Conduct quarterly site-envelope baseline monitoring (Phase Three): verify that Kenyan site operating conditions remain within documented baseline (power-outage frequency, water quality, spare-part availability, technician skills); if any parameter drifts >20%, document and trigger contingency stressors
- Manage Kenyan site logistics: coordinate equipment shipment, cold-chain for cryo-stocks, spare-parts procurement, utility setup and safety inspections; flag any risks to timeline or operating envelope
- Coordinate operator training and competency verification: implement training curriculum designed in Phase One-Two; assess technician competence on safety-critical tasks before commissioning; re-assess after incidents or long shutdowns
- Support documentation finalization and release: collect defects and improvements from Phase II early replication; facilitate documentation updates before release (after safety and legal review); coordinate with gate-review panel on documentation readiness assessment
- Prepare Kenyan replication chapters for Phase Two and Phase Three gate reports: defect-log summary, assistance-log audit summary, site-envelope status, operator training results, any safety incidents or issues

**Initial Setup Actions:**

- Month 0-1 (2026-10-09 to 2026-11-09): Finalize signed MoU with Kenyan partner covering staffing, site access, equipment installation, training commitment and contingency plans; establish quarterly review schedule
- Month 1-3 (2026-11-09 to 2027-01-09): Recruit independent auditor (external firm, not affiliated with Danish project or Kenyan partner) to conduct monthly assistance-log and defect-log reviews
- Month 2-4 (2026-12-09 to 2027-02-09): Conduct Kenyan site baseline study (independent site-selection consultant, not Kenyan partner): document power-outage patterns, water quality, ambient conditions, spare-part availability, local technician cohort; deliver Kenyan Site Baseline Report by Month 4 (2027-02-09)
- Month 3-4 (2027-01-09 to 2027-02-09): Establish assistance-log and defect-tracking systems (shared spreadsheet or issue tracker); train Kenyan team and auditor on logging procedures and escalation criteria
- Month 8-10 (2027-06-09 to 2027-08-09): Identify independent group to conduct early Phase II replication; confirm group's organizational separation from Danish team and baseline capability
- Month 11 (2027-09-09): Establish defect-tracking system for early replication, pre-loaded with expected-gap template from Danish experiences

**Membership:**

- Kenyan Site Lead or Replication Project Manager (based in Kenya; day-to-day site coordination, Kenyan partner liaison, UK team coordination)
- Independent Auditor (external firm reviewing assistance log and defect log monthly; flag patterns suggesting insufficient Kenyan team competence)
- Kenyan Partner Organization Lead (partnership governance, staff allocation, site access, local logistics)
- Training and Competency Coordinator (operator training delivery, competency assessment, re-assessment scheduling)
- Documentation and Defect Manager (defect-tracking system administration, resolution follow-up, documentation-update coordination)

**Decision Rights:** The Kenyan Replication Coordination body has authority to manage day-to-day site and partnership operations within the approved Phase Two-Three plan. Authority to approve replication timeline and budget allocations rests with Steering Committee. Authority to assess Kenyan team competence and operator readiness rests with independent auditor and gate-review panel. Body recommends to Steering Committee on: site-envelope changes, assistance-log patterns suggesting competence gaps, documentation-defect severity and resolution adequacy, any partnerships or logistics risks. Body cannot unilaterally declare replication ready for full-scale build or commissioning; Steering Committee and gate-review panel must approve based on Phase II-gate evidence.

**Decision Mechanism:** Monthly Kenyan coordination meetings (60 min teleconference, Denmark-Kenya timezone accommodation) with Kenyan Site Lead, Danish Project Lead, Training Coordinator and Auditor. Assistance log and defect tracker reviewed by auditor monthly; formal audit report generated by 10th of following month. Quarterly partnership reviews with Steering Committee (Month 6, 12, 18, 24, 36, 48 = 2027-04-09, 2027-10-09, 2028-04-09, 2028-10-09, 2029-10-09, 2030-10-09 estimate). Site-envelope baseline-monitoring reports generated quarterly starting Month 30 (2029-04-09). Decisions on site logistics, training curriculum, or assistance-log escalation made by consensus; disputes escalate to Project Lead and Steering Committee.

**Meeting Cadence:** Monthly Kenyan coordination meetings (60 min) during Months 1-60 (2026-11-09 to 2031-10-09). Monthly auditor reports on assistance-log and defect-log status. Quarterly partnership reviews with Steering Committee (Months 6, 12, 18, 24, 36, 48 = 2027-04-09, 2027-10-09, 2028-04-09, 2028-10-09, 2029-10-09, 2030-10-09). Site-envelope baseline-monitoring reports quarterly during Phase Three (Months 30, 36, 42, 48, 54 = 2029-04-09, 2029-10-09, 2030-04-09, 2030-10-09, 2031-04-09 minimum). Additional ad-hoc communication as needed (e.g., emergency troubleshooting, logistics issue, safety incident).

**Typical Agenda Items:**

- Site and logistics status: equipment delivery, utilities setup, cryo-stock storage, spare-parts procurement
- Assistance-log audit: communications logged, assistance frequency and type, any flags or patterns, mitigation actions
- Defect-log status: ambiguities found and resolved, open items, severity trends, progress toward documentation v1.0
- Operator training and competency: cohort progress, assessment results, any concerns or re-training needs
- Site-envelope monitoring (Phase Three): power outages, water quality, spare-part availability trends, any drifts or stressors
- Partnership and staffing: any changes in partner capacity, staff departures or contingency activations

**Escalation Path:** If assistance log shows hands-on developer troubleshooting >4 h/month, escalate to independent auditor and Steering Committee: assess whether Kenyan team needs additional training or documentation is insufficient. If defects are not being closed systematically or categories indicate gaps (e.g., repeated missing safety-interlock details), escalate to Steering Committee and independent gate-review panel: assess documentation readiness for Phase III build or recommend extended Phase II refinement. If site-envelope drifts >20% from baseline (e.g., power becomes more reliable), escalate to Steering Committee: trigger contingency stressors or document change in hypothesis B testing conditions. If partner-organization stability is threatened (staff turnover, funding change), escalate to Project Lead and Steering Committee: activate contingency plans and assess risk to Phase III schedule.

# Governance Implementation Plan

### 1. Funder appoints or identifies a Project Sponsor and confirms budget release authority. This is the pre-existing higher authority required to initiate all governance setup.

**Responsible Body/Role:** Funder

**Suggested Timeframe:** Month 0 (2026-10-09)

**Key Outputs/Deliverables:**

- Project Sponsor appointed and confirmed
- Funder's budget release and approval authority documented in writing
- Contact information and escalation path established

**Dependencies:**

- Funding commitment confirmed by funder

### 2. Project Sponsor (or Funder) formally appoints a Project Lead who will chair the Steering Committee and serve as the face of the project during Phase One setup. The Project Lead is typically a senior process engineer or project manager from the host institution.

**Responsible Body/Role:** Project Sponsor / Funder

**Suggested Timeframe:** Month 0 (2026-10-09)

**Key Outputs/Deliverables:**

- Project Lead appointed in writing
- Project Lead charter outlining decision authority, reporting line and key responsibilities
- First Project Lead action: confirm availability and initiate host-institution MoU negotiation

**Dependencies:**

- Project Sponsor identified and confirmed

### 3. Project Lead drafts a written charter for the independent gate-review panel, specifying: recruitment criteria, composition (3-5 members), funding and independence (panel managed by funder, not host), authority (written continue/modify/research-only/stop decisions), and procedure for publishing any funder deviation from panel recommendations.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0 (2026-10-09) to Month 0.5 (2026-10-24)

**Key Outputs/Deliverables:**

- Gate-Review Panel Charter v0.1 (draft)
- Recruitment criteria and desired expertise areas identified (process engineer, ATEX safety, regulatory, adoption, food science)
- Independence and funding mechanism documented

**Dependencies:**

- Project Lead appointed
- Funder confirms EUR 0.30M gate-panel budget ring-fenced and funder-managed

### 4. Funder reviews and approves the gate-review panel charter, confirming separate budget line (EUR 0.30M over 5 years), management structure and panel independence guarantees.

**Responsible Body/Role:** Funder

**Suggested Timeframe:** Month 0.5 (2026-10-24)

**Key Outputs/Deliverables:**

- Gate-Review Panel Charter approved and signed by funder
- EUR 0.30M budget line established (Phase One share EUR 0.06M)
- Funder designates an internal account manager for panel administration

**Dependencies:**

- Gate-Review Panel Charter v0.1 submitted to funder

### 5. Funder (or a funder-designated independent recruiter) initiates recruitment of the independent gate-review panel members using the approved charter criteria. Target: identify and secure 3-5 qualified experts with no conflicts of interest.

**Responsible Body/Role:** Funder

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Recruitment outreach completed to 8-12 candidate experts
- 3-5 panel members confirmed with written letters of engagement
- Panel charter signed by each member

**Dependencies:**

- Approved Gate-Review Panel Charter
- EUR 0.30M budget confirmed

### 6. Funder (or panel account manager) schedules a panel orientation meeting to brief members on the project scope, decision framework, timeline for gate meetings (Phase One ~Month 10 = 2027-08-09, Phase Two ~Month 30 = 2029-04-09, Phase Three ~Month 60 = 2031-10-09) and confidentiality/independence requirements.

**Responsible Body/Role:** Funder

**Suggested Timeframe:** Month 1 (2026-11-09) to Month 1.5 (2026-11-24)

**Key Outputs/Deliverables:**

- Panel orientation meeting held (in-person or virtual)
- Panel members provided project briefing materials, preliminary risk register and timeline
- Each panel member confirms understanding of role and independence obligations

**Dependencies:**

- 3-5 panel members confirmed and signed

### 7. Project Lead negotiates and secures a signed Memorandum of Understanding (MoU) with the Danish host university or research consortium, specifying: dedicated laboratory and container-scale bioreactor facilities, electrolysis capability, ATEX-compliant space, analytical support, key staff protection, facility maintenance responsibility and quarterly resource-conflict resolution.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0 (2026-10-09) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Host institution MoU signed by institution rector/executive director and Project Lead
- MoU specifies: laboratory access, equipment availability, key staff roles and protected time, conflict-resolution escalation
- Host institution confirms budget share or in-kind contributions

**Dependencies:**

- Project Lead appointed
- Project Sponsor identifies host-institution candidates

### 8. Project Lead negotiates and secures a signed partnership agreement with the Kenyan co-development organization, specifying: site access, staffing roles, equipment procurement and installation responsibility, utilities, training commitment, contingency plans for staff or partner changes, logistics and quarterly review schedule.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0 (2026-10-09) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Kenyan partner MoU signed by partner executive director and Project Lead
- Specifies: site access, staffing allocation (minimum 2 FTE), facilities, training participation, quarterly review with Steering Committee
- Contingency for partner or staff change documented

**Dependencies:**

- Project Lead appointed
- Project Sponsor identifies Kenyan partner candidates

### 9. Project Lead recruits or designates a Finance Manager (Cost Controller) who will track Phase One spending against the EUR 5.5M planned and EUR 6M ceiling, manage the EUR 0.65M contingency reserve, handle EUR/KES currency conversion at locked baseline rates and prepare monthly cost-control reports.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Finance Manager appointed or contracted
- Cost-tracking procedures and spreadsheet templates established
- EUR 0.30M contingency earmarked for strain-rights and regulatory work; EUR 0.35M free contingency
- EUR/KES baseline exchange rate locked at Month 0 (2026-10-09) reference rate

**Dependencies:**

- Project Lead appointed
- Phase One planned budget (EUR 5.5M) and contingency (EUR 0.65M) confirmed by funder

### 10. Project Lead recruits a PMO Director (or designates the Project Lead to wear this hat part-time in Month 0-1 = 2026-10-09 to 2026-11-09) to oversee day-to-day execution, establish work schedules, coordinate with workstream leads and manage gate-readiness preparation.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- PMO Director appointed or role assigned
- PMO charter outlining responsibility for schedule, cost, workstream coordination and gate-panel administration
- PMO team structure identified (Phase One work-package owner, cost controller, procurement, gate-panel admin, data manager)

**Dependencies:**

- Project Lead appointed

### 11. PMO Director establishes the detailed Phase One work schedule (Gantt chart with 100+ work packages), identifying critical path, dependencies and deliverables due for the Month 9 (2027-07-09) evidence freeze. Lock all deadlines and assign work-package owners.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Phase One Gantt chart (locked)
- Work packages defined: landscape review (Month 0-3 = 2026-10-09 to 2027-01-09), bench experiments (Month 1-9 = 2026-11-09 to 2027-07-09), HAZOP (Month 1-4 = 2026-11-09 to 2027-02-09), regulatory (Month 0-4 = 2026-10-09 to 2027-02-09), site baseline (Month 1-4 = 2026-11-09 to 2027-02-09), adopter engagement (Month 2-7 = 2026-12-09 to 2027-05-09), gate prep (Month 8-12 = 2027-06-09 to 2027-10-09)
- Critical-path activities identified; critical-path delay >2 weeks flags risk

**Dependencies:**

- PMO Director appointed
- Phase One planned spend and EUR 0.65M contingency confirmed

### 12. Project Lead formally establishes the Steering Committee, appointing its members: Project Lead (chair), Funder Representative, Kenyan Partner Lead, Finance Manager, Safety and Regulatory Lead, and optional external observer. Distribute a written charter specifying decision authority, meeting cadence and escalation rules.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Steering Committee Charter signed by all members
- Charter specifies: decision authority (contingency draws up to EUR 500K, schedule extensions, scope changes), quorum (4 of 6), voting rules (consensus preferred, majority if needed, dissent published), escalation (Funder holds veto, gate panel has override authority on safety)
- Members confirm availability for quarterly meetings (Months 3, 6, 9, 12 = 2027-01-09, 2027-04-09, 2027-07-09, 2027-10-09 in Phase One)

**Dependencies:**

- Project Lead appointed
- Funder Representative designated
- Kenyan Partner Lead confirmed
- Finance Manager appointed
- Safety and Regulatory Lead recruited or assigned

### 13. Steering Committee holds its inaugural meeting to confirm charter, approve Phase One work plan and budget, review risk register and confirm gate-panel independence arrangements. Document decisions and action items.

**Responsible Body/Role:** Steering Committee (led by Project Lead)

**Suggested Timeframe:** Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Inaugural Steering Committee meeting held (in-person or hybrid)
- Minutes documenting: charter approval, Phase One plan and budget approved, risk review completed, gate-panel independence confirmed, next meeting scheduled (Month 3 = 2027-01-09)
- Action items assigned to working groups

**Dependencies:**

- Steering Committee Charter approved and all members appointed
- Phase One Gantt chart locked
- Phase One cost allocation approved by funder

### 14. Project Lead recruits a Safety and Regulatory Lead (typically a senior process-safety engineer or regulatory affairs manager) who will oversee HAZOP, safety design basis, regulatory engagement and strain-rights work.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Safety and Regulatory Lead appointed (senior role, project-direct hire)
- Lead confirms availability to charter working groups: Safety/ATEX, Regulatory/IP/Strain-Rights
- Lead identifies qualified staff to support HAZOP, regulatory contact and strain-rights analysis

**Dependencies:**

- Project Lead appointed
- Budget for safety (EUR 0.25M) and regulatory/IP (EUR 0.20M) work confirmed by Steering Committee

### 15. Safety and Regulatory Lead contracts an independent third-party ATEX and process-safety consultant (external firm, not affiliated with host institution) to facilitate the HAZOP, review interlock logic and provide written compliance assessment.

**Responsible Body/Role:** Safety and Regulatory Lead

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- ATEX consultant contracted with fixed scope: HAZOP facilitation (3-4 workshop sessions), interlock review, written compliance letter
- Consultant contract specifies deliverables, timeline (HAZOP complete by Month 3 = 2027-01-09), and independence clause (no future design work)

**Dependencies:**

- Safety and Regulatory Lead appointed
- EUR 0.25M safety budget confirmed

### 16. Safety and Regulatory Lead formally constitutes the Technical Working Group: Safety, ATEX and Hazard Analysis, appointing members: Safety Lead, Process Engineer, ATEX Consultant, Reactor Specialist, Control Systems Engineer. Distribute charter and schedule HAZOP kickoff for Month 1 (2026-11-09).

**Responsible Body/Role:** Safety and Regulatory Lead

**Suggested Timeframe:** Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Safety Working Group Charter signed by members
- Charter specifies: HAZOP scope (electrolyzer to off-gas), guidewords, node structure, risk-matrix approach, deliverables (Safety Design Basis, Adopter Change Boundary)
- Monthly meeting schedule established (Mondays, 90 min, Months 1-4 = 2026-11-09 to 2027-02-09)
- HAZOP kickoff meeting scheduled (end of Month 1 or early Month 2 = 2026-12-09 to 2026-12-09)

**Dependencies:**

- Safety and Regulatory Lead appointed
- ATEX consultant contracted
- Reactor Specialist and Control Systems Engineer identified

### 17. Safety and Regulatory Lead contracts independent legal counsel (patent specialist and regulatory consultant) to conduct the freedom-to-operate and regulatory landscape review, covering Denmark, EU, Kenya and Bangladesh.

**Responsible Body/Role:** Safety and Regulatory Lead

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Patent specialist contracted (scope: hydrogen fermentation, autotrophic protein, single-cell protein, reference strain; jurisdictions: Denmark/EU, Kenya, Bangladesh)
- Regulatory consultant contracted (scope: contained-use rules, product-safety pathways per category, biosafety classification)
- Contract specifies deliverables: Strain Feasibility Report by Month 4 (2027-02-09), patent landscape summary, regulatory pathway assessment

**Dependencies:**

- Safety and Regulatory Lead appointed
- EUR 0.20M regulatory/IP budget confirmed

### 18. Safety and Regulatory Lead formally constitutes the Technical Working Group: Strain Rights, Regulatory Pathway and Intellectual Property, appointing members: Regulatory Lead, Patent Specialist (legal counsel), Regulatory Consultant (legal counsel), Microbiologist or Operations Lead. Distribute charter and establish bi-weekly meeting cadence.

**Responsible Body/Role:** Safety and Regulatory Lead

**Suggested Timeframe:** Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Regulatory/IP Working Group Charter signed by members
- Charter specifies: deliverables (Strain Feasibility Report, patent landscape summary, regulatory-pathway assessment), timeline (by Month 4 = 2027-02-09), legal-counsel review gates
- Bi-weekly meeting schedule (Mondays, 60 min, Months 1-4 = 2026-11-09 to 2027-02-09)
- Legal-counsel retainer agreements signed

**Dependencies:**

- Safety and Regulatory Lead appointed
- Patent specialist and regulatory consultant contracted

### 19. Project Lead recruits a Reactor Concept Lead (senior process or fermentation engineer) who will oversee the matched bench-scale reactor comparison and scale-up work. Assign responsibility for establishing the measurement framework and pre-registering the comparison protocol.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Reactor Concept Lead appointed (senior role, project-direct hire)
- Lead confirms availability to charter and lead the Reactor/Scale-Up Working Group
- Lead identifies bench-scale experimental lead, gas-transfer specialist, scale-up engineer and data manager

**Dependencies:**

- Project Lead appointed
- EUR 1.00M bench-lab budget confirmed

### 20. Reactor Concept Lead and data manager establish the detailed KPI Framework and Measurement Protocol, locked in writing before any bench-scale experiments begin. Specify definitions (volumetric productivity, energy per kg, kLa, oxygen-uptake rate), system boundary, analytical methods (HPLC, GC, bioreactor sensors) and success thresholds.

**Responsible Body/Role:** Reactor Concept Lead (in collaboration with data manager and external technical auditor)

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1.5 (2026-11-24)

**Key Outputs/Deliverables:**

- KPI Framework and Measurement Protocol v1.0 (locked and signed)
- Specifies: productivity definition (g/L/day), energy per kg (kWh/kg), kLa (h^-1), system boundary (electrolyzer to fermentor headspace), capacity-utilization assumption (assume 100% of theoretical max), measurement methods per instrument
- Published to Steering Committee and gate-review panel for feedback before experiments start

**Dependencies:**

- Reactor Concept Lead appointed
- External technical auditor identified and available for Month 1-2 (2026-11-09 to 2026-12-09) review

### 21. Reactor Concept Lead formally constitutes the Technical Working Group: Reactor Concept and Scale-Up, appointing members: Reactor Lead (chair), Bench-Scale Experimental Lead, Gas-Transfer Specialist, Scale-Up Engineer, Data Manager, Process Safety Engineer. Distribute charter and lock the pre-registered reactor comparison protocol before any experiments begin.

**Responsible Body/Role:** Reactor Concept Lead

**Suggested Timeframe:** Month 1 (2026-11-09) to Month 1.5 (2026-11-24)

**Key Outputs/Deliverables:**

- Reactor Working Group Charter signed by members
- Charter specifies: measurement framework (locked KPI definitions), pre-registered decision rules for reactor selection (<15% productivity gap = simplicity wins; 15-25% = weighted score; >25% = highest productivity unless ATEX blocked or cheaper option meets cost threshold)
- Disproof-experiment protocol locked: bench to pilot scale, kLa decline target <=25%, productivity within 15%, strain stability <10% drift over 16 weeks, external audit required before Phase Two gate
- Weekly meeting schedule (Mondays, 90 min, Months 1-9 = 2026-11-09 to 2027-07-09)

**Dependencies:**

- Reactor Concept Lead appointed
- KPI Framework locked
- External technical auditor identified and confirmed

### 22. PMO Procurement Manager initiates procurement of long-lead-time equipment (bioreactors for bench, pilot-scale reactors, electrolyzers, analytical instruments: HPLC, GC, gas chromatograph, bioreactor sensors). Target delivery Month 3-4 (2027-01-09 to 2027-02-09) to support February/March experiments.

**Responsible Body/Role:** PMO Director / Procurement Manager

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Procurement contracts issued for: 3 bench bioreactors (500 mL–1 L), 1 pilot-scale bioreactor (5–10 L), electrolyzers (bench and pilot scale), HPLC system, gas chromatograph, bioreactor monitoring system
- Delivery targets locked: Month 3 (2027-01-09) for equipment needed in Month 2-3 (2026-12-09 to 2027-01-09); contingency for 4-week delay tracked
- Supplier contracts include warranty, calibration and site-support terms

**Dependencies:**

- Procurement budget (EUR 0.5M of lab EUR 1.00M) approved by Steering Committee
- Facility requirements specified by Reactor Lead and host institution

### 23. Project Lead recruits an Adopter Engagement Lead (adoption strategist, economist or operations specialist) who will identify prospective adopters, conduct structured interviews and consolidate deployment scenarios with locked thresholds.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0.5 (2026-10-24) to Month 1 (2026-11-09)

**Key Outputs/Deliverables:**

- Adopter Engagement Lead appointed (mid-level role, project-direct or partner staff)
- Lead identifies techno-economic analyst and adoption specialist to support scenario development
- Lead confirms availability for structured adopter interviews (Months 2-7 = 2026-12-09 to 2027-05-09)

**Dependencies:**

- Project Lead appointed
- EUR 0.15M adopter-engagement budget approved

### 24. Adopter Engagement Lead constitutes the Adoption Working Group and conducts landscape research to identify 5-8 candidate prospective adopters (national/regional reserves, feed producers, humanitarian organizations) with stated mandates in food security or agriculture.

**Responsible Body/Role:** Adopter Engagement Lead

**Suggested Timeframe:** Month 1 (2026-11-09) to Month 2 (2026-12-09)

**Key Outputs/Deliverables:**

- Adopter Landscape Report identifying 5-8 candidates with profiles (mission, capacity, budget authority, current supply chains, estimated cost tolerance)
- Shortlist of 2-3 primary candidates with contact information
- Meeting requests sent to primary candidates for Month 2-3 (2026-12-09 to 2027-01-09) interviews

**Dependencies:**

- Adopter Engagement Lead appointed
- Techno-economic analyst and adoption specialist identified

### 25. Adopter Engagement Lead develops a structured interview guide and conducts in-person or virtual interviews with 2-3 prospective adopters, gathering data on: current supply chains and costs, production-capacity needs, cost tolerance, operational constraints (power, water, skills) and timeline.

**Responsible Body/Role:** Adopter Engagement Lead

**Suggested Timeframe:** Month 2 (2026-12-09) to Month 4 (2027-02-09)

**Key Outputs/Deliverables:**

- Interview guide (locked template with open-ended and quantitative questions)
- 2-3 adopter interview summaries documenting: current spend on protein, cost premium tolerance, capacity needs (kg/day or kg/yr), uptime requirements, operational constraints
- Preliminary scenario profiles (A, B, C) with estimated thresholds (cost, capacity, uptime)

**Dependencies:**

- Landscape report completed and candidates prioritized
- Steering Committee approves outreach messaging and interview protocol

### 26. Adopter Engagement Lead presents preliminary scenario profiles to each adopter, gathering feedback and validating thresholds. Iteratively refine profiles and obtain verbal commitment to lock scenarios by Month 9 (2027-07-09).

**Responsible Body/Role:** Adopter Engagement Lead

**Suggested Timeframe:** Month 3 (2027-01-09) to Month 6 (2027-04-09)

**Key Outputs/Deliverables:**

- Validated Scenario Profiles v1.0 incorporating adopter feedback
- Scenario A: reserve agency (<=EUR 12/kg, >=100 kg/day, >=95% uptime) (estimate)
- Scenario B: feed producer (<=EUR 10/kg, >=500 kg/day, >=90% uptime) (estimate)
- Scenario C: humanitarian logistics (<=EUR 15/kg, >=50 kg/day, 40-ft container) (estimate)
- Verbal commitments from adopters to sign by Month 7 (2027-05-09)

**Dependencies:**

- Preliminary scenario profiles from interviews
- Techno-economic cost model version available for sensitivity analysis

### 27. Project Lead initiates contact with Denmark/EU competent authorities (Danish EPA or EU environmental authority) and Kenya's National Biosafety Authority via informal pre-submission consultation, requesting written guidance on: contained-use authorization, strain biosafety classification, product-safety pathways per category and approval timelines.

**Responsible Body/Role:** Safety and Regulatory Lead (on behalf of Project Lead)

**Suggested Timeframe:** Month 2 (2026-12-09) to Month 3 (2027-01-09)

**Key Outputs/Deliverables:**

- Pre-submission inquiry letters sent to Danish EPA and Kenya's National Biosafety Authority
- Inquiry describes: proposed process, strain candidates, operating envelope, candidate product categories (animal feed, feed ingredient, emergency nutrition)
- Requests written preliminary guidance within 4-6 weeks

**Dependencies:**

- Safety and Regulatory Lead appointed
- Regulatory/IP Working Group established
- Strain candidates identified

### 28. Safety and Regulatory Lead and legal counsel initiate direct contact with strain holders (public culture collections, researchers) for primary and backup strain candidates, requesting written confirmation of rights for: research use, commercial production, redistribution, modification and derived strains.

**Responsible Body/Role:** Safety and Regulatory Lead / Regulatory/IP Working Group

**Suggested Timeframe:** Month 1 (2026-11-09) to Month 2 (2026-12-09)

**Key Outputs/Deliverables:**

- Strain-holder contact list prepared (4-5 candidates, prioritizing C. necator H16 and backup strains)
- Formal inquiry emails sent with 2-week response deadline
- Responses logged in regulatory/IP Working Group tracker

**Dependencies:**

- Regulatory/IP Working Group established
- Strain candidates identified by Reactor Lead and Microbiologist

### 29. Patent specialist (legal counsel) conducts freedom-to-operate patent search covering: hydrogen fermentation, autotrophic protein, single-cell protein, reference strain(s), and related processes in Denmark, EU, Kenya and Bangladesh. Compile findings into a ranked patent landscape summary.

**Responsible Body/Role:** Patent Specialist (legal counsel contracted by Safety and Regulatory Lead)

**Suggested Timeframe:** Month 1 (2026-11-09) to Month 3 (2027-01-09)

**Key Outputs/Deliverables:**

- Patent landscape search completed (USPTO, EPO, WIPO, Kenya patent office databases)
- Patent Landscape Summary listing: relevant patents, priority dates, claims, jurisdiction coverage, freedom-to-operate risk assessment (blocking patents vs. design-around-able)
- Preliminary recommendation on IP licensing or design-around options

**Dependencies:**

- Patent specialist contracted
- Strain candidates and process concept identified

### 30. PMO Director (in coordination with host institution) initiates facility setup at the Danish site: confirm laboratory access, install bioreactor utilities (gas supply, cooling water, electrical), set up ATEX-compliant gas-handling area, and complete safety and utility inspections.

**Responsible Body/Role:** PMO Director / Host Institution Facilities Lead

**Suggested Timeframe:** Month 1 (2026-11-09) to Month 3 (2027-01-09)

**Key Outputs/Deliverables:**

- Laboratory space assignment confirmed and cleaned
- Utilities installed: gas supply (N2, H2-compatible lines), cooling water, electrical (3-phase for electrolyzers)
- ATEX-compliant gas-handling fume hood or test cell installed
- Safety inspection completed by host institution and Steering Committee sign-off

**Dependencies:**

- Host institution MoU signed
- Facility requirements specified by Reactor Lead
- Procurement orders placed (delivery Month 3 = 2027-01-09)

### 31. Regulatory/IP Working Group consolidates strain-holder responses, patent search results and regulator feedback into a comprehensive Strain Feasibility Report, documenting: primary and backup strain rights (confirmed for all use cases), lawful Kenyan import pathway, and regulatory approval feasibility.

**Responsible Body/Role:** Safety and Regulatory Lead / Regulatory/IP Working Group

**Suggested Timeframe:** Month 2 (2026-12-09) to Month 4 (2027-02-09)

**Key Outputs/Deliverables:**

- Strain Feasibility Report v1.0 (draft, Month 3 = 2027-01-09)
- Documents: primary strain (e.g. C. necator H16) rights for research, commercial, redistribution, modification, derived strains (confirmed in writing)
- Backup strain rights documented
- Kenyan import feasibility confirmed (contacted Kenya National Biosafety Authority, no blocking restrictions identified or mitigation plan in place)
- Patent landscape summary and freedom-to-operate assessment
- Regulatory consultant review and sign-off (Month 3-4 = 2027-01-09 to 2027-02-09)

**Dependencies:**

- Strain-holder responses received
- Patent search completed
- Kenya biosafety authority feedback received

### 32. Project Lead recruits a Kenyan Site Study Lead (independent consultant, not affiliated with the Kenyan partner organization) to conduct a baseline operating-envelope assessment: power outage history, water quality, spare-parts availability, ambient conditions and local technician skills.

**Responsible Body/Role:** Project Lead / Kenyan Replication Coordination

**Suggested Timeframe:** Month 1 (2026-11-09) to Month 2 (2026-12-09)

**Key Outputs/Deliverables:**

- Kenyan Site Study Lead contracted
- Scope defined: 24-36 months utility-outage records audit, 3-4 months water-quality sampling, spare-parts supplier interviews, technician-cohort census
- Timeline: baseline report due Month 4 (2027-02-09)

**Dependencies:**

- Project Lead appointed
- Kenyan partner MoU signed (grants site access to independent consultant)

### 33. Kenyan Site Study Lead conducts site baseline assessment, collecting power-outage history (>=4 unplanned outages/month target, >=2 h mean duration), water quality variation (turbidity, pH, conductivity, iron/manganese), ambient temperature and humidity range, spare-parts lead times and local technician availability (2-3 per trade).

**Responsible Body/Role:** Kenyan Site Study Lead (independent consultant)

**Suggested Timeframe:** Month 2 (2026-12-09) to Month 4 (2027-02-09)

**Key Outputs/Deliverables:**

- Kenyan Site Baseline Report v1.0 (time-stamped, Month 4 = 2027-02-09)
- Documents: power-outage frequency (last 24-36 months), duration and pattern; water-quality measurements (monthly sampling); ambient temperature and humidity ranges; spare-parts suppliers and lead times (<=2-4 weeks from >=2 suppliers target); technician census and skill levels
- Baseline parameters locked: >20% drift triggers added outage stressors or flagged to gate panel

**Dependencies:**

- Kenyan Site Study Lead contracted
- Site access confirmed by Kenyan partner
- Steering Committee approves baseline report as Phase One gate input

### 34. Project Lead recruits a Kenyan Replication Coordination Lead (or designates an existing staff member) to oversee partnership governance, site logistics, operator training and defect tracking during Phases Two and Three. Establish reporting line to Project Lead and Steering Committee.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 1 (2026-11-09) to Month 2 (2026-12-09)

**Key Outputs/Deliverables:**

- Kenyan Replication Coordinator appointed or identified (mid-level role, may be Kenyan partner staff or project-direct)
- Coordinator charter issued, outlining: partnership oversight, site logistics, training coordination, defect tracking, assistance-log auditing, quarterly Steering Committee reports
- Coordinator confirms monthly meeting schedule with Danish Project Lead (60 min teleconference)

**Dependencies:**

- Project Lead appointed
- Kenyan partner MoU signed

### 35. Project Lead formally constitutes the Kenyan Replication Coordination and Independence Assurance body, appointing members: Kenyan Site Lead (in Kenya), Project Lead or Project Manager (Denmark liaison), Training Coordinator, independent Auditor (external firm), and Kenyan Partner representative. Distribute charter and establish monthly meeting cadence.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 1 (2026-11-09) to Month 2 (2026-12-09)

**Key Outputs/Deliverables:**

- Kenyan Replication Coordination Charter signed by members
- Charter specifies: responsibilities (site logistics, training, defect tracking, assistance-log audit), monthly meetings (60 min), quarterly Steering Committee reports, escalation criteria (assistance >4 h/month, unresolved defects, site-envelope drift >20%)
- Independent auditor contracted (external firm for monthly assistance-log and defect-log reviews)

**Dependencies:**

- Kenyan Replication Coordinator appointed
- Independent auditor identified and available by Month 2-3 (2026-12-09 to 2027-01-09)

### 36. PMO Director establishes a formal defect-tracking system (shared spreadsheet or issue tracker) for: documentation ambiguities found during early Phase Two replication, regulatory feedback log, strain-rights tracking, assistance-log auditing, and cost/schedule variance tracking. Set up access and training for all users.

**Responsible Body/Role:** PMO Director / Data Manager

**Suggested Timeframe:** Month 1 (2026-11-09) to Month 2 (2026-12-09)

**Key Outputs/Deliverables:**

- Defect-tracking system established (shared cloud platform or project management tool)
- Tracking system includes fields: defect location, severity (critical/major/minor), description, resolution, source, date resolved, auditor sign-off
- Assistance-log template prepared (communication date, parties, topic, duration, source of help, logged or flagged)
- User access granted to Kenyan Replication Coordinator, Auditor, PMO, Technical Leads

**Dependencies:**

- PMO Director appointed
- Kenyan Replication Coordinator appointed
- Independent Auditor identified

### 37. Adopter Engagement Lead obtains signed commitments from 2-3 prospective adopters (by Month 7 = 2027-05-09), formally locking their deployment scenarios and thresholds in time-stamped documents. Clause: adopters remain bound to thresholds through Phase Three gate unless all parties formally agree to renegotiate.

**Responsible Body/Role:** Adopter Engagement Lead / Steering Committee liaison

**Suggested Timeframe:** Month 6 (2027-04-09) to Month 7 (2027-05-09)

**Key Outputs/Deliverables:**

- Signed Adopter Commitment Letters (one per adopter, time-stamped Month 7 = 2027-05-09)
- Each letter specifies: scenario profile (cost, capacity, uptime), locked thresholds, adopter business case or mandate supporting the threshold, withdrawal procedure (public disclosure of reason)
- Published to Steering Committee, gate-review panel and all project stakeholders

**Dependencies:**

- Scenario profiles validated with adopters (Month 6 = 2027-04-09)
- Techno-economic model and cost-sensitivity analysis available to justify thresholds

### 38. Safety and Regulatory Lead consolidates the regulatory feedback (from Denmark/EU and Kenya's National Biosafety Authority), strain-rights findings and patent landscape into a provisional product-category recommendation. Prepare documentation for the Phase One gate decision (Month 10 = 2027-08-09).

**Responsible Body/Role:** Safety and Regulatory Lead / Regulatory/IP Working Group

**Suggested Timeframe:** Month 3 (2027-01-09) to Month 5 (2027-03-09)

**Key Outputs/Deliverables:**

- Product Category Recommendation (provisional, for Phase One gate): select one from animal feed, fish feed, food ingredient, emergency nutrition based on regulatory pathway feasibility and adopter interest
- Document rationale: regulatory approval timeline, required safety data, composition thresholds (nucleic acid, protein, moisture), and how Phase Two will validate category choice
- Regulatory Pathway Summary (per jurisdiction): Denmark/EU approval route, Kenya approval route, Bangladesh patent landscape

**Dependencies:**

- Strain Feasibility Report completed
- Regulatory feedback from authorities received
- Patent landscape summary completed

### 39. PMO Director convenes a Phase One gate-readiness checkpoint (Month 7-8 = 2027-05-09 to 2027-06-09) to review evidence freeze schedule, confirm all deliverables are on track for Month 9 (2027-07-09), and prepare gate-panel briefing materials.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Month 7 (2027-05-09) to Month 8 (2027-06-09)

**Key Outputs/Deliverables:**

- Phase One Gate Readiness Report documenting: evidence freeze timeline, outstanding deliverables and owners, risk flags (any delays >2 weeks), gate-panel briefing materials status
- Briefing package outline prepared: landscape review summary, bench-reactor productivity data and analysis (with external audit), safety design basis, strain feasibility, regulatory pathways, scenarios and thresholds, technology risks and mitigation

**Dependencies:**

- All Phase One work packages 80%+ complete by Month 7 (2027-05-09)
- Bench-reactor experiments underway or nearly complete

### 40. Reactor Working Group (with external technical auditor) conducts comprehensive audit of the bench-scale reactor comparison: verify that the measurement protocol was followed, analytical methods were consistent, decision thresholds were applied, and all deviations are documented. Produce audited comparison report with uncertainty ranges and reactor selection recommendation.

**Responsible Body/Role:** Reactor Concept Lead / External Technical Auditor

**Suggested Timeframe:** Month 8 (2027-06-09) to Month 9 (2027-07-09)

**Key Outputs/Deliverables:**

- External Audit Report (signed by independent technical auditor, Month 9 = 2027-07-09)
- Auditor confirms: measurement framework was locked and followed; analytical variation <20%; decision rules were pre-registered and applied consistently; three reactor concepts compared, triplicate runs, mean ± SD reported
- Reactor selection recommendation: specific concept (pneumatic, stirred, or passive-feed) identified based on pre-registered decision rules with full justification

**Dependencies:**

- Triplicate bench-scale experiments completed (all 9 cultures run to steady state)
- All analytical data compiled and processed by single lead analyst
- External technical auditor engaged and available for Month 8-9 (2027-06-09 to 2027-07-09) review

### 41. Safety and Regulatory Lead and HAZOP facilitator (ATEX consultant) complete the formal Process Hazard Analysis (HAZOP or LOPA) covering: electrolyzer, gas lines, fermentor headspace and control systems. Identify all failure modes, rank by severity and likelihood, and document design response (eliminate, reduce, protect). Independent consultant provides written sign-off.

**Responsible Body/Role:** Safety Working Group (led by Safety and Regulatory Lead) with ATEX Consultant

**Suggested Timeframe:** Month 1 (2026-11-09) to Month 4 (2027-02-09), finalized by Month 9 (2027-07-09)

**Key Outputs/Deliverables:**

- HAZOP Final Report (Month 4 = 2027-02-09 draft, Month 9 = 2027-07-09 finalized)
- Documents: hazard register (all identified failure modes, guidewords covered, nodes analyzed), risk matrix (severity x likelihood), high-risk items and design responses, quantitative safety target (probability of uncontrolled ignition <1 per 100,000 operating hours)
- Independent ATEX consultant sign-off letter confirming compliance with ATEX requirements

**Dependencies:**

- Safety Working Group constituted (Month 1 = 2026-11-09)
- ATEX consultant engaged
- Three HAZOP workshop sessions held (Month 1-2 = 2026-11-09 to 2026-12-09)

### 42. Safety and Regulatory Lead drafts the Safety Design Basis (incorporating HAZOP findings, selected inherent limits vs. instrumented protection, quantitative safety targets, Adopter Change Boundary v0.1 and control-system architecture). Obtain independent ATEX consultant review and approval before proceeding to detailed design.

**Responsible Body/Role:** Safety Working Group (led by Safety and Regulatory Lead)

**Suggested Timeframe:** Month 2 (2026-12-09) to Month 4 (2027-02-09)

**Key Outputs/Deliverables:**

- Safety Design Basis v0.1 document (Month 3 = 2027-01-09, final Month 4 = 2027-02-09)
- Specifies: choice of inherent limits (e.g., <4% O2 in H2-rich stream, <0.5 m3 H2 inventory) or layered instrumented protection; control-system architecture (PLC + interlocks or hardwired); emergency-shutdown procedure and interlock logic (preliminary)
- Adopter Change Boundary v0.1: pre-assessed substitutes (e.g., electrode materials, parameter ranges for safe operation) and components requiring full safety re-analysis (pressure rating, interlock logic)
- Independent ATEX consultant approval letter (Month 4 = 2027-02-09)

**Dependencies:**

- HAZOP findings available (Month 4 = 2027-02-09 draft)
- Reactor concept selected and design basis specified

### 43. PMO Director compiles the complete Phase One gate-panel briefing package: landscape review, bench-reactor audited comparison with selection recommendation, HAZOP and safety design basis, strain feasibility and regulatory pathways, deployment scenarios and locked thresholds, productivity and scale-up uncertainty ranges, blueprint v0.1, and identified risks and mitigation. Circulate to panel 4-6 weeks before gate meeting (Month 10 = 2027-08-09).

**Responsible Body/Role:** PMO Director with Technical Leads

**Suggested Timeframe:** Month 8 (2027-06-09) to Month 9 (2027-07-09)

**Key Outputs/Deliverables:**

- Phase One Gate-Panel Briefing Package (complete, Month 9 = 2027-07-09, 'evidence freeze')
- Package includes: Landscape Review summary; Reactor Concept Audited Comparison Report (audited, reactor selected); HAZOP Final Report; Safety Design Basis v0.1; Strain Feasibility Report; Regulatory Pathways (per jurisdiction); Deployment Scenarios and Adopter Commitments (signed); Technical Risk Register and Mitigation Plans; Blueprint v0.1 (preliminary); Measurement Framework (locked); Planned Phase Two work and budget (EUR 13.0M estimate); Gate-Panel Charter and independence confirmation
- Package quality-checked by Steering Committee and circulated to all 3-5 gate-review panel members by Month 10 (2027-08-09) deadline minus 4-6 weeks = ~Month 8.5 (2027-06-24 to June 09)

**Dependencies:**

- All Phase One evidence freeze deliverables complete by Month 9 (2027-07-09)
- Reactor audited comparison available
- Safety design basis finalized
- Strain feasibility, regulatory and scenario documentation all complete

### 44. Independent gate-review panel (3-5 members, funded and managed by funder, not project host) reviews the Phase One briefing package and prepares for gate-decision meeting scheduled for Month 10 (2027-08-09). Each panel member documents 30-40 hours of preparation time (covered by honoraria) and submits preliminary comments/questions to panel chair.

**Responsible Body/Role:** Independent Gate-Review Panel

**Suggested Timeframe:** Month 8.5 (2027-06-24 to 2027-06-09) to Month 10 (2027-08-09)

**Key Outputs/Deliverables:**

- Panel members' preparation completed (individual reviews and preliminary comments)
- Panel chair consolidates preliminary comments and prepares agenda for gate-decision meeting
- Gate-decision meeting scheduled (in-person or hybrid, 1.5-2 days) for Month 10 (2027-08-09)
- Panel members confirm attendance and technical questions/gaps to be addressed at meeting

**Dependencies:**

- Phase One Gate-Panel Briefing Package circulated to panel (Month 8.5 = 2027-06-24 to 2027-06-09)
- Panel members recruited, chartered and funded

### 45. Steering Committee convenes immediately before the gate-review panel meeting (by Month 10 = 2027-08-09 or early Month 11 = 2027-09-09) to review Phase One evidence internally, confirm gate-pass/fail recommendations and ensure alignment with panel. Steering Committee prepares responses to anticipated panel questions.

**Responsible Body/Role:** Steering Committee (led by Project Lead)

**Suggested Timeframe:** Month 9 (2027-07-09) to Month 10 (2027-08-09)

**Key Outputs/Deliverables:**

- Internal Steering Committee gate-readiness review meeting held (2-3 hours)
- Committee reviews: bench-reactor selection, safety design basis, strain and regulatory findings, scenario credibility, identified risks and Phase Two mitigation
- Committee approves Phase Two work plan and budget (EUR 13.0M estimate) conditional on gate pass
- Committee confirms readiness for panel meeting and identifies spokesperson for key topics

**Dependencies:**

- Phase One evidence freeze complete (Month 9 = 2027-07-09)
- Phase One briefing package prepared for Steering Committee review

### 46. Independent gate-review panel convenes for the Phase One gate-decision meeting (Month 10 = 2027-08-09). Panel reviews evidence against pre-defined gate criteria: strain rights documented, productivity criterion met, Kenyan biosafety feasibility confirmed, reference architecture decided, HAZOP complete, safety design basis approved, scenarios locked, product category named, blueprint v0.1 issued. Panel deliberates and produces written continue/modify/research-only/stop decision.

**Responsible Body/Role:** Independent Gate-Review Panel

**Suggested Timeframe:** Month 10 (2027-08-09) (gate meeting) to Month 10-11 (2027-08-09 to 2027-09-09) (written decision)

**Key Outputs/Deliverables:**

- Phase One Gate-Decision Meeting Report (1.5-2 day meeting, Month 10 = 2027-08-09)
- Meeting documents: panel assessment against each gate criterion, evidence strengths and gaps, risks and recommended mitigations, final recommendation (Continue to Phase Two, Modify and retry gate, Research Only, or Stop)
- Written Panel Recommendation (3-5 pages, Month 10-11 = 2027-08-09 to 2027-09-09)
- Signed by all panel members; includes rationale and any dissenting views published verbatim

**Dependencies:**

- All Phase One evidence available and reviewed by panel (complete briefing package, Month 8.5 = 2027-06-24 to 2027-06-09)
- Panel members prepared (30-40 hours each)
- Steering Committee pre-gate review completed

### 47. Funder reviews the independent gate-review panel's written recommendation (Month 10-11 = 2027-08-09 to 2027-09-09) and makes the formal Phase One gate decision: continue to Phase Two, or require modification/research-only/stop. Funder publishes its decision and any deviation from panel recommendation with written justification.

**Responsible Body/Role:** Funder

**Suggested Timeframe:** Month 11 (2027-09-09) to Month 12 (2027-10-09)

**Key Outputs/Deliverables:**

- Funder's Phase One Gate Decision Letter (Month 12 = 2027-10-09)
- Decision: Continue to Phase Two (if criterion met), or Modify and re-gate by Month 13-14 (2027-11-09 to 2027-12-09), or Research Only, or Stop
- If decision deviates from panel recommendation, published written justification (to all stakeholders, Steering Committee, gate panel and funder)
- If Continue decision: Phase Two work-plan and EUR 13.0M budget allocation approved; phase-transition kickoff meeting scheduled (Month 12-13 = 2027-10-09 to 2027-11-09)

**Dependencies:**

- Panel recommendation received (Month 10-11 = 2027-08-09 to 2027-09-09)
- Steering Committee briefed on panel findings

### 48. If Phase One gate decision is 'Continue', Steering Committee and PMO Director initiate Phase Two transition (Month 12-13 = 2027-10-09 to 2027-11-09): recruit Phase Two-specific roles (pilot-scale reactor engineer, downstream-processing lead, early-replication coordinator), finalize Phase Two work schedule (Months 12-30 = 2027-10-09 to 2029-04-09), confirm facilities and equipment procurement for Phase Two (pilot-scale reactors, downstream-processing equipment), and schedule Phase Two kickoff meeting.

**Responsible Body/Role:** Project Lead / Steering Committee / PMO Director

**Suggested Timeframe:** Month 12 (2027-10-09) to Month 13 (2027-11-09)

**Key Outputs/Deliverables:**

- Phase Two Transition Plan (Month 12 = 2027-10-09)
- Phase Two staffing identified (pilot-scale engineer, downstream lead, early-replication coordinator, training lead)
- Phase Two work schedule locked (100+ work packages, critical path, Month 9 = 2027-07-09 evidence freeze, Month 21 = 2028-07-09 gate meeting target Month 30 = 2029-04-09)
- Phase Two EUR 13.0M budget allocation confirmed by funder
- Procurement initiated for Phase Two equipment (pilot-scale reactors, downstream-processing equipment, training materials)

**Dependencies:**

- Phase One gate decision: Continue (from Month 12 = 2027-10-09)
- Funder approves Phase Two budget (EUR 13.0M estimate)

### 49. Steering Committee and PMO convene the Phase One closing meeting (Month 12 = 2027-10-09) to capture lessons learned, document any scope changes or technical pivots from Phase One, confirm Phase Two roles and accountabilities, and transition technical working groups to Phase Two focus. Confirm continuation of Safety, Regulatory, Reactor and Kenyan Coordination working groups; establish new working groups as needed (Downstream Processing, Early Replication).

**Responsible Body/Role:** Steering Committee (led by Project Lead)

**Suggested Timeframe:** Month 12 (2027-10-09)

**Key Outputs/Deliverables:**

- Phase One Closing Report (Month 12 = 2027-10-09)
- Documents: lessons learned (what worked well, what to improve), technical pivots or design changes from Phase One plan, carry-over risks to Phase Two, updated risk register
- Phase Two Technical Working Groups confirmed: Safety, Regulatory, Reactor/Scale-Up, Kenyan Replication, Downstream Processing (new), Early Replication (new)
- Working-group charters updated for Phase Two scope
- Steering Committee confirms Phase Two meeting schedule (quarterly, Months 15, 18, 21, 24, 27, 30 = 2028-01-09, 2028-04-09, 2028-07-09, 2028-10-09, 2029-01-09, 2029-04-09)

**Dependencies:**

- Phase One gate decision released (Month 12 = 2027-10-09)
- Phase Two work plan and budget approved

### 50. If Phase One gate decision is 'Modify', Steering Committee and funder jointly decide on remediation scope and timeline (modify budget or schedule), publish the issue to all stakeholders, and establish a re-gate schedule (target Month 13-14 = 2027-11-09 to 2027-12-09 or later). Assign clear ownership and success criteria for each remediation item. Document assumptions and success thresholds in writing.

**Responsible Body/Role:** Steering Committee / Funder / Project Lead

**Suggested Timeframe:** Month 12 (2027-10-09) to Month 13 (2027-11-09) (if Modify decision)

**Key Outputs/Deliverables:**

- Phase One Remediation Plan (Month 12-13 = 2027-10-09 to 2027-11-09)
- Documents: specific issues requiring remediation (e.g., strain rights blocking, productivity below threshold, regulatory pathway unclear), root cause, remediation steps, owner, timeline, success criteria and re-gate date
- Published to all stakeholders (gate panel, Steering Committee, funder, adopters) with transparent messaging
- Updated risk register and revised Phase One budget (if additional spend needed, draw from EUR 0.65M contingency with contingency-allocation decision by Steering Committee)
- Re-gate-decision meeting scheduled with panel (Month 13-14 = 2027-11-09 to 2027-12-09 or later, depending on remediation timeline)

**Dependencies:**

- Phase One gate decision: Modify (from funder, Month 12 = 2027-10-09)
- Panel recommendation and remediation guidance available

### 51. If Phase One gate decision is 'Research Only' or 'Stop', Steering Committee convenes with Funder and gate-review panel to document findings, capture lessons learned and produce a public-knowledge report summarizing the scientific work, identified barriers and recommendations for future work. Transition project to wind-down (if Stop) or pivot to research-publication mode (if Research Only).

**Responsible Body/Role:** Steering Committee / Funder / Project Lead

**Suggested Timeframe:** Month 12 (2027-10-09) onwards (if Research Only or Stop)

**Key Outputs/Deliverables:**

- Phase One Final Report (Month 12-15 = 2027-10-09 to 2028-01-09)
- Documents: project scope and objectives (from initial plan), evidence generated (landscape review, bench-reactor data, safety analysis, regulatory and strain-rights findings), barriers identified, scientific findings and published data, recommendations for future work or alternative approaches
- Published data package released (open license, per steward-entity governance and freedom-to-operate assessment)
- If Stop: project team transition plan and facility/equipment disposition
- If Research Only: pivot to peer-reviewed publication strategy; confirm funding for 2-3 key publications; update project team roles

**Dependencies:**

- Phase One gate decision: Research Only or Stop (from funder, Month 12 = 2027-10-09)
- Panel recommendation and findings report available

### 52. Throughout Phase Two (Months 12-30 = 2027-10-09 to 2029-04-09), Steering Committee continues to meet quarterly (Months 15, 18, 21, 24, 27, 30 = 2028-01-09, 2028-04-09, 2028-07-09, 2028-10-09, 2029-01-09, 2029-04-09) to review Phase Two progress, cost-control status, technical risks and gate-readiness. PMO maintains weekly workstream coordination and monthly cost-control reports. Technical working groups meet bi-weekly or weekly as appropriate to their workstream phase.

**Responsible Body/Role:** Steering Committee / PMO / Technical Working Groups

**Suggested Timeframe:** Months 15, 18, 21, 24, 27, 30 (2028-01-09 to 2029-04-09)

**Key Outputs/Deliverables:**

- Quarterly Steering Committee meeting minutes and decision logs (Months 15, 18, 21, 24, 27, 30 = 2028-01-09, 2028-04-09, 2028-07-09, 2028-10-09, 2029-01-09, 2029-04-09)
- Monthly PMO cost-control reports (tracking EUR 13.0M Phase Two budget)
- Monthly technical working-group progress reports (reactor scale-up, downstream validation, strain stability, early replication)
- Gate-readiness checkpoint reports (starting Month 25 = 2028-11-09, tracking evidence for Phase Two gate at Month 30 = 2029-04-09)

**Dependencies:**

- Phase One gate decision: Continue (Month 12 = 2027-10-09)
- Phase Two work plan and budget approved

### 53. By Month 30 (2029-04-09), PMO Director compiles Phase Two evidence-freeze deliverables: pilot-scale reactor disproof-experiment results (kLa, productivity, strain stability), downstream-processing validation at pilot scale, early independent replication defect log and resolutions, composition and digestibility data confirming product-category choice, Phase Two-gate briefing package for review panel. Circulate to panel 4-6 weeks before Phase Two gate meeting (Month 30-32 = 2029-04-09 to 2029-06-09, meeting target Month 30 = 2029-04-09).

**Responsible Body/Role:** PMO Director with Technical Leads

**Suggested Timeframe:** Month 28 (2029-02-09) to Month 30 (2029-04-09)

**Key Outputs/Deliverables:**

- Phase Two Gate-Panel Briefing Package (complete, Month 30 = 2029-04-09, 'evidence freeze')
- Package includes: Pilot-scale Disproof-Experiment Results (audited, kLa/productivity/strain stability vs. bench baseline); Downstream-Processing Validation (nucleic acid removal, protein purity, energy per kg); Early Independent Replication Report (defect log and resolutions, documentation readiness assessment); Composition and Digestibility Data; Scale-Up Evidence Ladder (bench to pilot to reference-unit model); Phase III Reference-Unit Design (preliminary); Phase II Risk Summary and Mitigation
- Package reviewed by Steering Committee before circulation to panel

**Dependencies:**

- All Phase Two experiments and early replication work complete by Month 30 (2029-04-09)
- External audits (disproof-experiment validation, early-replication defect-log review) completed

### 54. Independent gate-review panel reviews Phase Two briefing package (Months 30-32 = 2029-04-09 to 2029-06-09), prepares for gate-decision meeting (Month 32 = 2029-06-09 estimate), and produces written continue/modify/research-only/stop decision. If Phase II thresholds are met (kLa decline <=25%, strain stability <10% drift, defects resolved), panel recommends Continue to Phase Three; else Modify or Research Only.

**Responsible Body/Role:** Independent Gate-Review Panel

**Suggested Timeframe:** Month 30 (2029-04-09) to Month 32-33 (2029-06-09 to 2029-07-09)

**Key Outputs/Deliverables:**

- Phase Two Gate-Decision Meeting (Month 32 = 2029-06-09, meeting; Month 33 = 2029-07-09, written decision)
- Panel assessment: disproof thresholds met? Downstream ready? Composition/digestibility confirm category? Early replication defects resolved? Documentation ready? Scale-up evidence credible? Regulatory pathway still open?
- Written Panel Recommendation: Continue to Phase Three, or Modify with remediation plan, or Research Only

**Dependencies:**

- Phase Two briefing package complete and circulated (Month 30 = 2029-04-09)
- Panel members prepared (30-40 hours each)

### 55. Funder reviews Phase Two panel recommendation (Month 33 = 2029-07-09) and makes formal gate decision: Continue to Phase Three, Modify, Research Only, or Stop. Funder publishes decision and any deviation from panel recommendation with justification by Month 34 (2029-08-09). If Continue: approve Phase Three work plan and EUR 22.0M budget; schedule Phase III kickoff (Months 34-35 = 2029-08-09 to 2029-09-09).

**Responsible Body/Role:** Funder

**Suggested Timeframe:** Month 33 (2029-07-09) to Month 34 (2029-08-09)

**Key Outputs/Deliverables:**

- Funder's Phase Two Gate Decision Letter (Month 34 = 2029-08-09)
- Decision: Continue to Phase Three, Modify and re-gate, Research Only, or Stop
- If Continue: Phase Three work-plan (Months 30-60 = 2029-04-09 to 2031-10-09) and EUR 22.0M budget approved; hardware procurement (Danish and Kenyan reference units, EUR 4.0M) conditionally approved with release at Phase II gate
- If deviation from panel recommendation: published written justification

**Dependencies:**

- Panel recommendation received (Month 33 = 2029-07-09)
- Steering Committee briefed

### 56. If Phase II gate decision is Continue, Steering Committee and PMO initiate Phase III transition (Months 34-35 = 2029-08-09 to 2029-09-09): recruit Phase III-specific roles (reference-unit commissioning engineer, operator training lead, replication independence auditor for full-scale build), finalize Phase III detailed schedule (Months 30-60 = 2029-04-09 to 2031-10-09), release hardware procurement (Danish and Kenyan reference units), and confirm facility commissioning plans.

**Responsible Body/Role:** Project Lead / Steering Committee / PMO Director

**Suggested Timeframe:** Months 34-35 (2029-08-09 to 2029-09-09)

**Key Outputs/Deliverables:**

- Phase III Transition Plan (Month 34 = 2029-08-09)
- Phase III staffing identified (reference-unit commissioning lead, operator training lead, auditor for independence assurance)
- Phase III detailed schedule (Months 30-60 = 2029-04-09 to 2031-10-09): Danish unit commissioning Months 40-46 (2030-02-09 to 2030-08-09, six-month run); Kenyan build Months 40-48 (2030-02-09 to 2030-10-09), six-month production Months 48-54 (2030-10-09 to 2031-04-09), fault-injection Months 50-56 (2030-12-09 to 2031-06-09)
- Hardware procurement released (Danish and Kenyan reference-unit equipment, EUR 4.0M from programme reserve)
- Phase III EUR 22.0M budget allocation confirmed by funder

**Dependencies:**

- Phase II gate decision: Continue (Month 34 = 2029-08-09)
- Funder approves Phase III budget and hardware release

### 57. Throughout Phase III (Months 30-60 = 2029-04-09 to 2031-10-09), Steering Committee continues quarterly meetings (Months 36, 42, 48, 54 = 2029-10-09, 2030-04-09, 2030-10-09, 2031-04-09), PMO maintains weekly coordination and monthly cost-control, and technical working groups support commissioning, operation and replication. Kenyan Replication Coordination body meets monthly and conducts quarterly site-envelope baseline monitoring (starting Month 30 = 2029-04-09). Independent auditor reviews assistance log and defect log monthly throughout Phase III.

**Responsible Body/Role:** Steering Committee / PMO / Technical Working Groups / Kenyan Coordination / Independent Auditor

**Suggested Timeframe:** Months 36, 42, 48, 54 (2029-10-09, 2030-04-09, 2030-10-09, 2031-04-09) for Steering Committee; monthly for Kenyan Coordination and audits

**Key Outputs/Deliverables:**

- Quarterly Steering Committee meeting minutes (Months 36, 42, 48, 54 = 2029-10-09, 2030-04-09, 2030-10-09, 2031-04-09)
- Monthly PMO cost-control and schedule reports (tracking EUR 22.0M Phase III budget, programme reserve EUR 4.0M)
- Monthly Kenyan Coordination reports (site logistics, staff, equipment status, assistance-log and defect-log audit summaries)
- Quarterly Kenyan site-envelope baseline-monitoring reports (power outages, water quality, spare-parts availability, technician performance)
- Monthly independent-auditor assistance-log and defect-log reviews with flag for >4 h/month troubleshooting or unresolved critical defects

**Dependencies:**

- Phase II gate decision: Continue
- Phase III transition plan and staffing finalized

### 58. By Month 57 (2031-07-09), PMO Director compiles Phase III evidence-freeze deliverables: Danish reference-unit six-month uptime and productivity data, Kenyan replication unit six-month production data and outage-survival results, operator practical safety assessments (>=90% pass rate), fault-injection test results (100% of safety-critical reach safe state, >=90% recovery of other tests), composition and digestibility confirmation, regulatory feasibility assessment, scale-up evidence summary, assistance-log audit summary (independence assessment), deployment-scenario threshold comparison. Circulate Phase III gate briefing package to panel 4-6 weeks before Phase III gate meeting (Month 57-60 = 2031-07-09 to 2031-10-09).

**Responsible Body/Role:** PMO Director with Technical Leads

**Suggested Timeframe:** Month 55 (2031-05-09) to Month 57 (2031-07-09)

**Key Outputs/Deliverables:**

- Phase III Gate-Panel Briefing Package (complete, Month 57 = 2031-07-09, 'evidence freeze')
- Package includes: Danish Reference-Unit Performance Data (6 months uptime, productivity, energy per kg, any incidents); Kenyan Replication Performance Data (6 months production, outage-survival results, restart time, productivity recovery); Operator Safety Assessment Results (training completion, practical safety test scores >=90%); Fault-Injection Test Results (predefined tests, pass/fail per test, 100% critical, >=90% other); Product Specification Confirmation (composition, nucleic acid content, digestibility); Regulatory Pathway Feasibility (per jurisdiction, approval timeline, blockers if any); Scale-Up Evidence (bench to pilot to reference, uncertainty ranges, disproof experiments, scale-up route); Assistance-Log Audit Summary (independence assessment, help frequency, sources); Deployment-Scenario Threshold Comparison (measured cost, capacity, uptime vs. locked thresholds); Hypotheses A and B Results (separately reported)

**Dependencies:**

- Danish reference-unit operation complete (6 months, Months 40-46 = 2030-02-09 to 2030-08-09)
- Kenyan replication production complete (6 months, Months 48-54 = 2030-10-09 to 2031-04-09)
- Fault-injection tests completed (Months 50-56 = 2030-12-09 to 2031-06-09)
- All final data analysis and audits completed by Month 57 (2031-07-09)

### 59. Independent gate-review panel reviews Phase III briefing package (Months 57-60 = 2031-07-09 to 2031-10-09), prepares for final gate-decision meeting (Month 60 = 2031-10-09), and produces written final decision: Go, Modify, Research Only, or Stop. Panel assesses all Phase III gate criteria: replication from documentation alone? Safety-critical faults all safe? >=90% other fault recovery? Six-month uptime >=90%? >=90% operator safety pass? At least one scenario met? Regulatory and scale-up routes credible?

**Responsible Body/Role:** Independent Gate-Review Panel

**Suggested Timeframe:** Month 57 (2031-07-09) to Month 60 (2031-10-09)

**Key Outputs/Deliverables:**

- Phase III Gate-Decision Meeting (Month 60 = 2031-10-09; May extend to final decision by end of Month 60 = 2031-10-09)
- Panel assessment: replication documentation-independent? Safety pass? Fault injection pass? Uptime >90%? Operator competence >90%? Scenario(s) met? Hypotheses A and B both supported or one failed?
- Written Final Gate Decision: Go (all criteria met, project validated), Modify (weaknesses correctable), Research Only (technology works but no credible deployment case), or Stop (fundamental failure)

**Dependencies:**

- Phase III briefing package complete and circulated (Month 57 = 2031-07-09)
- All Phase III data analysis and audits finalized
- Panel members prepared (30-40 hours each)

### 60. Funder reviews Phase III panel recommendation (Month 60 = 2031-10-09 or shortly after) and makes final project decision: Go, Modify, Research Only, or Stop. Funder publishes the final decision and any deviation from panel recommendation with written justification by Month 60 (2031-10-09). If Go: authorize publication of open-source package, confirm steward-entity governance and long-term funding. If Research Only or Stop: transition to public-knowledge documentation and project wind-down.

**Responsible Body/Role:** Funder

**Suggested Timeframe:** Month 60 (2031-10-09)

**Key Outputs/Deliverables:**

- Funder's Final Phase III Gate Decision Letter (Month 60 = 2031-10-09)
- Decision: Go, Modify, Research Only, or Stop, with written justification
- If Go: publish open-source package (hardware, software, documentation, data) under open licences; confirm steward-entity legal structure and funding; communicate project success and adoption pathway to stakeholders
- If Modify/Research Only/Stop: project transition plan, public-knowledge report publication, team wind-down or re-focus

**Dependencies:**

- Panel recommendation received (Month 60 = 2031-10-09)
- Steering Committee and project team briefed

# Decision Escalation Matrix

**Strain Rights or Biosafety Barrier Blocking Kenyan Replication**
Escalation Level: Project Steering Committee and Independent Gate-Review Panel
Approval Process: Steering Committee convenes within 48 hours; evaluates mitigation (activate legally clean backup strain, extend Phase One, or recommend Modify gate). Independent panel assesses impact on replication independence and project viability. Funder holds final release authority for any timeline or budget adjustment.
Rationale: Strain rights confirmation by Month 4 (2027-02-09) is a hard constraint. If a primary strain has third-party restrictions or Kenya biosafety authority blocks import, the entire open-replication pillar and reproducibility claim collapses. Late discovery (after Phase One) forces 6-12 month remediation and EUR 0.2-0.4M spend, consuming the contingency. Escalation ensures rapid assessment and allows backup strain activation before design is committed.
Negative Consequences: If barrier is not resolved by Phase One gate (Month 10 = 2027-08-09), the project cannot proceed to Phase Two with confidence that the reference strain is legally obtainable in Kenya. Failure to resolve by Phase Two forces strain switch (EUR 0.2-0.4M, 4-8 weeks) and full re-validation of productivity benchmarks. If barrier emerges in Phase Three, cost and delay (EUR 2-4M, 12-24 months) exceed the programme reserve and push project completion past Month 60 (2031-10-09), forcing project stop or major scope reduction.

**Safety Design Basis or ATEX Compliance Barrier Preventing Reactor Build Commitment**
Escalation Level: Project Steering Committee, Safety and ATEX Working Group, and Independent Gate-Review Panel
Approval Process: Safety and ATEX consultant (independent third party) produces written assessment of the barrier: can it be eliminated by design change, or does it block the chosen reactor concept? Steering Committee reviews consultant's recommendation and decides: redesign the reactor, accept lower productivity with inherently safer limits, or escalate to panel for pathway advice. Panel assesses whether design constraint has invalidated the productivity vs. simplicity trade-off that underpins reactor selection.
Rationale: Formal HAZOP and independent interlock review (Months 1-4 = 2026-11-09 to 2027-02-09) are required before committing EUR 4.0M to hardware procurement. If ATEX consultant identifies a non-waivable compliance barrier late (e.g., pressure requirement or seal stress that cannot be achieved with the selected reactor), reference-unit design must be reworked or cancelled. Early escalation allows design pivot before procurement lock.
Negative Consequences: Late discovery of ATEX barrier (Month 8 onwards = 2027-06-09) forces either 8-12 week design rework (delaying Phase Three hardware by 2-3 months, consuming float and risking gate slip to Month 13 = 2027-11-09) or project pivot to inherently safer but lower-productivity design (reducing hypothesis-A credibility and cost threshold fit). If barrier is discovered during Phase Three build (Month 40+ = 2030-02-09+), the reference unit cannot be commissioned as designed, forcing retrofit (EUR 0.3-0.8M, 3-6 months) or declaring Phase Three evidence compromised.

**Reactor Concept Productivity Falls Below Pre-Registered Success Threshold, Blocking Advancement**
Escalation Level: Project Steering Committee and Independent Gate-Review Panel
Approval Process: Reactor Working Group documents measured productivity vs. pre-registered benchmark; if failure threshold is crossed (productivity <70% of published C. necator baseline), escalates to Steering Committee with external auditor's recommendation. Steering Committee decides: (a) accept lower productivity and adjust cost model downward for Phase Two gate, (b) request extended Phase One and additional bench work, or (c) recommend to panel that gate be deferred for remediation. Panel assesses whether failure invalidates the reference-architecture or reactor-selection decision and advises on path forward.
Rationale: Pre-registered comparison thresholds (productivity >=90% benchmark = pass; 70-90% = panel call; <70% = fail) are locked before experiments begin (Month 1.5 = 2026-11-24) to prevent post-hoc rationalization. If all three reactor concepts fall short, the project must either accept degraded economics (raising cost per kg, stressing deployment-scenario fit) or revisit the reference architecture (adding 4-6 weeks). Panel input ensures the decision is evidence-based, not optimism-driven.
Negative Consequences: If productivity benchmark is missed (70-90% range or lower) and no cause is identified, the project enters Phase Two with unknown cost model and cannot confidently project the deployment economics. This risks Phase Two gate failure (Month 30 = 2029-04-09) when cost model is finalized and compared to locked scenarios. If discovered at Phase Two gate that productivity shortfall makes cost threshold impossible to meet, recommendation could be Modify or Research Only, invalidating EUR 13.0M Phase Two spend.

**Kenyan Site Operating Envelope Materially Drifts (Power Becomes More Reliable, or Water Quality Degrades) Undermining Hypothesis B Test**
Escalation Level: Kenyan Replication Coordination body, Project Steering Committee, and Independent Gate-Review Panel
Approval Process: Kenyan Site Study baseline (Month 4 = 2027-02-09) establishes reference parameters (power outages, water quality, spare-parts availability). Quarterly monitoring (Phase Three, Months 30, 36, 42, 48, 54 = 2029-04-09, 2029-10-09, 2030-04-09, 2030-10-09, 2031-04-09) flags drift >20%. If drift is identified, Steering Committee decides: (a) add controlled outage stressors or water-quality interventions to maintain test burden, (b) document site-envelope change and adjust hypothesis B conclusions, or (c) escalate to panel for assessment of whether hypothesis B evidence is still credible. Panel judges whether the changed envelope invalidates reproducibility claims or merely shifts the deployment scenario profile.
Rationale: Hypothesis B (decentralized operation under difficult infrastructure) requires the site to test a defined harsh envelope throughout Phase Three (Months 30-60 = 2029-04-09 to 2031-10-09). If grid power becomes reliably available mid-project or water quality improves significantly, the site no longer tests the harsh conditions that justify the design choices. Quarterly monitoring allows early detection and contingency activation (controlled stressors) before evidence is compromised.
Negative Consequences: If envelope drifts >20% without documented contingency, hypothesis B evidence weakens by 20-40% in external credibility, reducing adopter confidence in decentralization claims by similar margin. If drift is discovered late (Month 54 onwards = 2031-04-09+), there is insufficient time to add stressors or re-run tests, forcing the final gate decision to downgrade hypothesis B result from 'pass' to 'partial' or 'conditional', potentially blocking Go and forcing Modify. If envelope changes are attributed to project management error (not external change), reputational damage to programme credibility.

**Deployment Scenario Adopter Withdrawal or Threshold Renegotiation After Scenarios Are Locked**
Escalation Level: Adopter Engagement Working Group, Project Steering Committee, and Independent Gate-Review Panel
Approval Process: If an adopter formally withdraws or requests threshold change after Month 9 (2027-07-09) lock, Adopter Engagement Lead documents reason and notifies Steering Committee within 5 days. Steering Committee assesses: (a) is the withdrawn scenario essential to the project's public-value case, or are remaining scenarios sufficient? (b) do remaining scenarios remain credible without this adopter? (c) is a replacement adopter available quickly? Panel is notified and invited to advise whether the scenario-credibility change affects the gate decision pathway. Any threshold change requires written agreement by all remaining parties and panel consent.
Rationale: Locked scenarios (Month 9 = 2027-07-09) with signed adopter commitments establish the pass/fail criteria for the final Go decision. If an adopter withdraws (due to internal budget change, shifting priorities, or competitive threat), the project must either find a replacement adopter or proceed with fewer scenarios. A threshold renegotiation after lock defeats the whole purpose of pre-locking (preventing post-hoc rationalization to fit results). Escalation ensures transparency and allows the panel to judge whether the project's public-value case remains credible.
Negative Consequences: If an adopter withdraws without documented reason and the project accepts it silently, the final Go decision may be based on fewer or weaker scenarios than originally planned, reducing adoptability and real-world impact. Public disclosure of adopter withdrawal without credible replacement signals market doubt and may reduce other adopters' confidence. If thresholds are loosened after lock to accommodate failure (e.g., cost cap raised from EUR 12/kg to EUR 14/kg), the gate decision becomes post-hoc rationalization, damaging project credibility and potential adoption by 30-50%.

**Phase One Gate Evidence Freeze Delayed Beyond Month 9 (2027-07-09) or Gate Decision Cannot Be Made by Month 12 (2027-10-09)**
Escalation Level: Project Steering Committee, PMO Director, and Funder
Approval Process: PMO Director flags any work package running >2 weeks late by Month 7 (2027-05-09). If delay threatens the Month 9 (2027-07-09) evidence freeze, Steering Committee convenes within 48 hours to decide: (a) extend the evidence-freeze deadline to Month 10 (2027-08-09), compressing the gate-panel review window (not recommended as it reduces panel preparation time), or (b) declare the late deliverable a condition of the gate (gate proceeds, but panel notes the missing evidence as a risk). If gate decision cannot be rendered by Month 12 (2027-10-09), the Funder and panel jointly decide whether to extend the decision window to Month 13 (2027-11-09) or recommend Modify and re-gate after remediation.
Rationale: The Phase One gate evidence freeze (Month 9 = 2027-07-09) is a hard constraint to allow 4-6 weeks for panel preparation and a 1-month decision window (Month 10-12 = 2027-08-09 to 2027-10-09) before Phase Two kickoff (Month 12-13 = 2027-10-09 to 2027-11-09). A slip >1 month (to Month 13 = 2027-11-09 decision) cascades into Phase Two schedule compression and risks delaying the Phase Two gate from Month 30 (2029-04-09) to Month 32 (2029-06-09). Early escalation allows decision on schedule trade-offs before critical path is broken.
Negative Consequences: If Phase One gate is delayed by 4-6 weeks without mitigation, Phase Two start slips from Month 12-13 (2027-10-09 to 2027-11-09) to Month 14-16 (2027-12-09 to 2028-02-09), consuming the 3-month float and pushing Phase Two gate from Month 30 (2029-04-09) to Month 32-34 (2029-06-09 to 2029-08-09). If slippage continues into Phase Three, the final gate decision could be delayed past Month 60 (2031-10-09), the hard project completion constraint, forcing either an incomplete Phase Three or a project stop before final evidence is collected. Cost impact: each month of delay at USD 400K/month (estimate) = USD 4.8M annual run rate, consuming 10-15% of contingency per month.

# Monitoring Progress

### 1. Key Performance Indicator (KPI) Tracking Against Project Plan and Deployment Thresholds
**Monitoring Tools/Platforms:**

  - KPI Dashboard (shared spreadsheet or BI tool tracking volumetric productivity, energy per kg, cost per kg, uptime, outage survival, operator competence scores)
  - Monthly PMO Cost-Control Report (actual spending vs. allocated budget, variance by work package, contingency draw status, currency conversion tracking)
  - Phase-Gate Evidence Freeze Package (comprehensive deliverables checklist: strain rights, reactor productivity data, safety design basis, regulatory feedback, scenario thresholds, blueprint versions)

**Frequency:** Weekly for active bench/pilot experiments (Months 1-9 = 2026-11-09 to 2027-07-09 Phase One, Months 12-24 = 2027-10-09 to 2028-10-09 Phase Two); biweekly during commissioning and operation (Phase Three); monthly PMO reports and gate-readiness checkpoints throughout all phases. Steering Committee quarterly reviews (Months 3, 6, 9, 12 = 2027-01-09, 2027-04-09, 2027-07-09, 2027-10-09 Phase One; Months 15, 18, 21, 24, 27, 30 = 2028-01-09, 2028-04-09, 2028-07-09, 2028-10-09, 2029-01-09, 2029-04-09 Phase Two; Months 36, 42, 48, 54 = 2029-10-09, 2030-04-09, 2030-10-09, 2031-04-09 Phase Three)

**Responsible Role:** PMO Director and Cost Controller (monthly cost control); Reactor Concept Lead and Technical Working Groups (weekly experiment progress and KPI calculations); Project Lead and Steering Committee (quarterly strategic review and variance interpretation)

**Adaptation Process:** Monthly PMO cost-control report flags variance >10% in any cost category or >5% cumulative; Steering Committee reviews root cause within 1 week and authorizes corrective action (schedule adjustment, contingency draw, scope reduction). If actual productivity or cost trajectory deviates from Phase One benchmark by >20%, escalate to the independent reactor/scale-up working group and Steering Committee to recommend design review or threshold revision. If a locked deployment scenario becomes unattainable (measured cost exceeds threshold by >15%), escalate to Adopter Engagement Working Group and Steering Committee to assess whether scenario remains credible or whether an adopter contingency needs activation. All KPI method changes require independent technical auditor approval before gate progression.

**Adaptation Trigger:** KPI variance >10% in cost, >20% in measured productivity vs. benchmark, >15% cost-scenario shortfall, schedule slip >2 weeks on any critical-path work package, or >10% cumulative budget variance. Additionally, if the Phase One productivity gate criterion is close (70-90% of benchmark), escalate early to the independent gate-review panel for guidance on threshold and decision pathway. If Phase Three uptime, operator safety pass-rate or fault-injection results fall short of the >=90% target mid-Phase-Three (Month 48-54 = 2030-10-09 to 2031-04-09), escalate to the panel immediately for assessment of whether the unit can still meet the gate threshold or whether phase extension is needed.

### 2. Critical Success Factor Monitoring: Strain Rights, Biosafety and Regulatory Pathway Feasibility
**Monitoring Tools/Platforms:**

  - Strain Feasibility Report (signed at Month 4 = 2027-02-09, documenting primary and backup strain rights for all use cases, Kenyan import feasibility, biosafety classification)
  - Regulatory Feedback Log (shared spreadsheet tracking all authority communications, dates, feedback type (binding vs. preliminary), implications, project response, categorized by jurisdiction: Denmark/EU, Kenya, Bangladesh patent landscape)
  - Freedom-to-Operate Patent Landscape Summary (patent search results, jurisdictional coverage, blocking vs. design-around-able, patent pledge status)

**Frequency:** Weekly regulatory/IP working-group meetings (Months 0-4 = 2026-10-09 to 2027-02-09, Phase One front-load); monthly monitoring thereafter (Months 5-60 = 2027-03-09 to 2031-10-09) to catch regulatory guidance changes or new patent filings. Immediate escalation if strain holder changes terms or Kenya authority signals new restrictions.

**Responsible Role:** Safety and Regulatory Lead (group chair, regulatory strategy); Regulatory/IP Working Group (strain-holder contact, patent search, authority dialogue, document log); independent legal counsel (freedom-to-operate assessment, strain-rights interpretation, binding vs. non-binding feedback distinction)

**Adaptation Process:** If strain-holder imposes restrictions blocking commercial use or Kenyan import, immediately activate the legally clean backup strain (identified by Month 4 = 2027-02-09): conduct emergency productivity and rights validation of backup within 2-3 weeks; escalate to Steering Committee with impact assessment (EUR cost, schedule delay, design implications). If Kenya's National Biosafety Authority requests additional containment data or signals a biosafety classification higher than anticipated, conduct rapid impact assessment: does the new classification require design rework (e.g., higher-grade biocontainment)? Flag to Steering Committee for contingency activation (EUR 0.1-0.3M estimate, 2-6 week delay). If a third-party patent is identified that blocks the reference process or strain in Denmark or Kenya, escalate to patent counsel for design-around analysis or licensing feasibility; if no route is viable and patent is enforceable in target jurisdiction, prepare to escalate to gate-review panel for pathfinding (Research Only outcome or deployment-region pivot).

**Adaptation Trigger:** Strain-holder denies commercial rights or Kenyan import (discovered by Month 4 = 2027-02-09 gate); new Kenya biosafety authority feedback changing classification or requiring additional data; third-party patent claim blocking the reference strain or core process in Denmark or Kenya (discovered by Month 3 = 2027-01-09 patent search); regulatory authority requests data or authorization delay extending beyond the planned Phase gate timeline by >4 weeks. If regulatory or patent barrier emerges after Phase One gate (Month 12 = 2027-10-09 decision), escalate immediately to Steering Committee and gate-review panel, as impact on Phase Two cost and timeline could be substantial.

### 3. Safety, ATEX Compliance and Hazard-Analysis Progress Monitoring
**Monitoring Tools/Platforms:**

  - HAZOP Final Report and Risk Matrix (Month 4 = 2027-02-09, documenting all identified failure modes, severity/likelihood rankings, design responses and safety targets)
  - Safety Design Basis Document and Adopter Change Boundary (locked v0.1 by Month 3 = 2027-01-09; updated as design evolves, gated on independent ATEX consultant approval)
  - Safety-Incident and Near-Miss Log (all Phase One-Three incidents, anomalies, investigation findings and corrective actions, reviewed monthly by Safety Working Group and quarterly by Steering Committee)
  - Interlock Logic Review and Test Results (independent ATEX consultant approval; test results from small-scale safety mockup Months 3-4 = 2027-01-09 to 2027-02-09)

**Frequency:** Monthly Safety Working Group meetings (Months 1-4 = 2026-11-09 to 2027-02-09 during HAZOP; then weekly during control-system design Months 3-5 = 2027-01-09 to 2027-03-09; then quarterly throughout Phases Two and Three or after any incident). Incident log reviewed within 48 hours of any safety anomaly and escalated to Steering Committee within 1 week. Independent ATEX consultant engaged at key gates: Month 3 (2027-01-09) for design-basis approval, Month 5 (2027-03-09) for interlock review, and before any pressurized >2 bar(g) or high-gas-inventory build.

**Responsible Role:** Safety and Regulatory Lead (Safety Working Group chair, hazard-analysis strategy, incident investigation lead); independent third-party ATEX consultant (HAZOP facilitation, interlock review, compliance assessment, written sign-off authority); Control Systems Engineer (interlock logic design and testing); Process Safety Specialist (risk matrix and design-response documentation)

**Adaptation Process:** If HAZOP identifies a high-risk failure mode (Catastrophic + Frequent or Major + Occasional) that cannot be adequately controlled by the selected reactor concept, escalate immediately to Steering Committee with the independent ATEX consultant's recommended design response: (a) eliminate the hazard (e.g., reduce inventory or pressure limits, reduce productivity/cost implication), (b) redesign to mitigate (cost and schedule implication), or (c) escalate to gate-review panel if response would materially change the project scope or assumptions. If independent interlock review uncovers compliance gaps in the proposed control-system architecture, Safety Working Group must redesign the logic or hardwired protection before hardware procurement (EUR 0.1-0.3M estimate, 2-4 week delay). If a safety incident or near-miss occurs during Phase One bench work, conduct root-cause investigation within 1 week; if the cause reveals a design flaw not captured in the HAZOP, update the Safety Design Basis and risk matrix immediately, and escalate to Steering Committee and gate-review panel if the design flaw could affect scale-up or Kenyan replication.

**Adaptation Trigger:** HAZOP finding of uncontrolled high-risk failure mode (Catastrophic x Frequent or Major x Occasional); independent ATEX consultant identifies a compliance barrier to the proposed design (pressure rating, seal requirements, control-system architecture); any safety incident or near-miss during Phase One-Three operation (investigate within 48 hours, escalate if root cause is design-related); discovery of a new failure mode during detailed design or commissioning that was not in the HAZOP (indicator: HAZOP was incomplete or guidewords did not cover the new mode). Trigger threshold for design response decision: if risk mitigation cost is >5% of phase budget or timeline impact >4 weeks, requires Steering Committee and panel consideration.

### 4. Reactor Concept Selection and Scale-Up Evidence Ladder: Pre-Registered Disproof-Experiment Monitoring
**Monitoring Tools/Platforms:**

  - KPI Framework and Measurement Protocol (locked v1.0 by Month 1 = 2026-11-09, specifying definitions, analytical methods, system boundary, capacity-utilization assumption and success thresholds for volumetric productivity, energy per kg, mass-transfer coefficient kLa, oxygen-uptake rate)
  - Reactor Concept Comparison Audited Report (Month 9 = 2027-07-09, external technical auditor review; raw data, analysis methods, uncertainty ranges, decision-rules application, reactor selection recommendation)
  - Scale-Up Evidence Ladder and Disproof-Experiment Protocol (pre-registered before Phase Two begins; bench to pilot scale with measured kLa, productivity and strain stability; failure thresholds fixed, not adjusted post-hoc; external audit of Phase Two results Month 24-26 = 2028-10-09 to 2028-12-09)
  - Bench-Scale and Pilot-Scale Experiment Logs (weekly progress, sampling data, analytical results, deviations from protocol, contingency actions, triplicate run tracking)

**Frequency:** Weekly Reactor Working Group meetings during bench and pilot experiments (Months 1-9 = 2026-11-09 to 2027-07-09 Phase One, Months 12-24 = 2027-10-09 to 2028-10-09 Phase Two); biweekly during early-replication Phase Two overlap; monthly during Phase Three data analysis. External audits scheduled at evidence-freeze gates: Month 9 (2027-07-09) for Phase One bench comparison, Month 24-26 (2028-10-09 to 2028-12-09) for Phase Two disproof experiments.

**Responsible Role:** Reactor Concept Lead (experimental strategy and decision authority); Bench-Scale and Pilot-Scale Experimental Leads (day-to-day culture maintenance and sampling); Gas-Transfer Specialist (mass-transfer coefficient calculations and bench-to-pilot scaling analysis); external technical auditor (independent audit of protocol adherence, analytical consistency and decision-rule application); Data Manager (HPLC, GC, bioreactor-data processing, uncertainty quantification)

**Adaptation Process:** If measured bench-scale productivity deviates from pre-registered success criterion (>=90% of published benchmark = pass; 70-90% = panel decision call; <70% = fail), Reactor Working Group documents deviation with root-cause analysis: (a) is the deviation real or an analytical artifact? (b) if real, what process parameter is responsible? (c) can tuning or redesign improve productivity without invalidating the comparison? If productivity is 70-90% of benchmark, escalate to the independent gate-review panel by Month 8 (2027-06-09) with the group's recommendation (pass with caveat, modify benchmark, or re-run with tuning). If a disproof experiment in Phase Two shows that a principal scale-up assumption is violated (kLa decline >25%, strain stability drift >10% over 16 weeks, or productivity decline >15% bench to pilot), conduct detailed root-cause analysis and design-response assessment within 2 weeks: (a) is the effect expected physical behavior or an anomaly? (b) can the design be adjusted to mitigate? (c) must the deployment model be revised downward and cost threshold reassessed? Escalate to Steering Committee and gate-review panel with evidence and mitigation options. If all three reactor concepts fail the productivity benchmark, escalate to Steering Committee with recommendation: (i) accept lower productivity and adjust cost model downward, (ii) extend Phase One and pursue additional bench work or alternative concepts, or (iii) request panel guidance on pathway forward.

**Adaptation Trigger:** Bench-scale productivity <90% of published benchmark, or if 70-90%, escalate to panel by Month 8 (2027-06-09) for gate-criteria decision. Phase Two disproof-experiment failure (kLa decline >25%, strain stability >10% drift, productivity decline >15%); measurement uncertainty exceeds the +/-15% tolerance (flag by Month 2-3 = 2026-12-09 to 2027-01-09 for analytical methods review); single lead analyst deviates from locked measurement protocol; more than one triplicate run is excluded from analysis (trigger review of exclusion criteria); external auditor identifies analytical-variation or protocol-adherence issues that invalidate the comparison. Any detected deviation from the locked pre-registered protocol requires documented justification and independent auditor approval before proceeding past the gate.

### 5. Kenyan Site Operating Envelope and Replication Independence Assurance: Assistance-Log and Defect-Tracking Monitoring
**Monitoring Tools/Platforms:**

  - Kenyan Site Baseline Report (time-stamped Month 4 = 2027-02-09; power-outage frequency/duration, water-quality variation, spare-parts lead times, technician cohort census; establishes reference envelope against which Phase III drift is measured)
  - Audited Assistance Log (shared spreadsheet tracking all communications between Kenyan team and Denmark team or external experts: date, parties, topic, duration, outcome, assistance source; reviewed monthly by independent auditor; threshold: >4 h/month hands-on troubleshooting triggers flag)
  - Documentation-Defect Tracking System (issues log for documentation ambiguities found during build/operation: location, severity, description, resolution, source, auditor sign-off; active from Phase II early replication through Phase III)
  - Quarterly Site-Envelope Baseline-Monitoring Reports (Phase III Months 30, 36, 42, 48, 54 = 2029-04-09, 2029-10-09, 2030-04-09, 2030-10-09, 2031-04-09; power-outage logs, water-quality samples, spare-parts supplier feedback, technician performance notes; drift >20% from baseline triggers contingency stressor or documented change notification)

**Frequency:** Monthly assistance-log and defect-log reviews by independent auditor (Months 14 onwards = 2027-12-09, Phase II early replication start through Phase III). Quarterly Kenyan site-envelope baseline-monitoring reports (starting Month 30 = 2029-04-09, Phase III); triggered immediately if any parameter shows >20% drift. Monthly Kenyan Replication Coordination meetings (60 min teleconference, Denmark-Kenya coordination) and quarterly Steering Committee partnership-governance reviews (Months 6, 12, 18, 24, 36, 48 = 2027-04-09, 2027-10-09, 2028-04-09, 2028-10-09, 2029-10-09, 2030-10-09 estimate).

**Responsible Role:** Independent third-party auditor (external firm, reviewing assistance log and defect log monthly, flagging patterns suggesting insufficient Kenyan competence or undocumented help); Kenyan Replication Coordination Lead (day-to-day site oversight, assistance tracking, defect resolution); Kenyan Partner Organization Lead (staffing, site access, facility maintenance); Project Lead and Steering Committee (partnership governance and escalation authority)

**Adaptation Process:** If assistance log shows hands-on developer troubleshooting or design help from Denmark team exceeding the 4 h/month threshold, independent auditor flags the pattern to Steering Committee within 2 days of the monthly review: assess whether Kenyan team competence is inadequate (trigger extended training or documentation fixes) or whether the issue is project-created (emergency incident). If the pattern persists for 2 consecutive months (flags in Months X and X+1), escalate to gate-review panel for assessment of whether independence claim remains credible or whether the gate conclusion should be downgraded from Go to Modify. If documentation defects are not being resolved systematically (critical defects unresolved >2 weeks, major defects unresolved >4 weeks), escalate to Steering Committee: assess whether additional documentation refinement is needed before Phase III full-scale build or whether defect-resolution process is inadequate. If Kenyan site operating envelope drifts >20% from baseline (e.g., power outages become more frequent or less frequent, water quality degrades unexpectedly, spare-parts availability changes), Steering Committee decides: (a) add controlled outage stressors or water-quality interventions to maintain test burden (cost EUR 30-70K estimate, 2-4 weeks), or (b) document the drift and adjust hypothesis B conclusions (transparency to gate panel). If partner organization experiences staff turnover or funding disruption, Kenyan Replication Coordination Lead escalates immediately with contingency-activation plan (backup staff identified, timeline to recovery, and mitigation for Phase III schedule).

**Adaptation Trigger:** Assistance log shows >4 h/month hands-on troubleshooting for 1 month, or any pattern of design help from developers; critical documentation defects (safety-related, blocking build/operation) unresolved >2 weeks; major defects unresolved >4 weeks; Kenyan site envelope parameter drifts >20% from Month 4 (2027-02-09) baseline (power outages +/-30% of baseline frequency, water-quality pH shift >1 unit, spare-parts lead time increases from 2-4 weeks to >6 weeks, technician cohort turnover >50%); partner-organization instability (staff loss >2 key roles, funding delay, or statement of withdrawal); any safety incident in Kenya requiring external emergency support or regulatory notification (immediate escalation to gate panel). If replication passes a Phase II-III gate but assistance log or defect log later reveals systematic underdocumented help, the gate decision is escalated to the panel for review of whether independence claim has been retroactively invalidated.

### 6. Deployment Scenario Threshold Locking and Adopter Commitment Monitoring
**Monitoring Tools/Platforms:**

  - Adopter Interview Summaries and Scenario Profiles (consolidated by Month 6 = 2027-04-09, documenting adopter input on current supply chains, cost tolerance, capacity needs, uptime requirements and operational constraints; used to develop draft scenarios)
  - Signed Adopter Commitment Letters (locked by Month 7 = 2027-05-09, time-stamped, specifying scenario profile and thresholds per adopter; immutable except by all parties' written agreement)
  - Deployment Scenario and Threshold Document (finalized by Month 9 = 2027-07-09, published to Steering Committee, gate-review panel and all stakeholders; includes adopter names, scenario profiles, locked cost/capacity/uptime thresholds, rationale, and withdrawal procedure)
  - Adopter Status Tracking Log (quarterly updates Months 12, 24, 36, 48, 60 = 2027-10-09, 2028-10-09, 2029-10-09, 2030-10-09, 2031-10-09; flags any signals of withdrawal, renegotiation request, or market/competitive changes affecting adopter interest; published to Steering Committee)

**Frequency:** Bi-weekly or monthly Adopter Engagement Working Group meetings (Months 2-7 = 2026-12-09 to 2027-05-09, Phase One for scenario definition and adopter signing); quarterly adopter-status reviews thereafter (Months 12, 24, 36, 48, 60 = 2027-10-09, 2028-10-09, 2029-10-09, 2030-10-09, 2031-10-09) to monitor for withdrawal or interest changes. Immediate escalation if an adopter signals withdrawal or renegotiation request.

**Responsible Role:** Adopter Engagement Lead (adopter relationship management, scenario development, commitment obtaining); Techno-Economic Analyst (scenario cost and sensitivity analysis, threshold feasibility assessment); Project Lead and Steering Committee (governance authority for threshold changes, adopter withdrawal response)

**Adaptation Process:** If an adopter signals a threshold renegotiation or questions the scenario's credibility (e.g., cost tolerance shifting downward, capacity requirement increasing), Adopter Engagement Lead conducts immediate engagement conversation to understand the driver (internal budget change, competitive pressure, market shift). If renegotiation is requested after Month 9 (2027-07-09) lock, escalate to Steering Committee and gate-review panel with full context: is the renegotiation justified by external market change (e.g., new EU subsidy or competitor technology)? If justified, the panel may recommend re-negotiating thresholds with all parties' written agreement; if not justified, recommend holding to locked thresholds. If an adopter formally withdraws (due to internal change, withdrawal of mandate, or dissolution of the organization), Adopter Engagement Lead publishes the withdrawal reason to all stakeholders within 5 days; Steering Committee assesses: are the remaining scenarios (if any) sufficient for the project's public-value case? If yes, proceed; if no, activate contingency to recruit a replacement adopter (target 4-6 weeks, from pre-qualified backup list if available, or open new landscape search). If withdrawal stems from the project's failure to meet an earlier commitment (e.g., unmet productivity or cost forecast), document the issue and escalate to gate-review panel for assessment of whether it reflects a credible technical or economic shortfall requiring a gate outcome other than Go.

**Adaptation Trigger:** Adopter signals interest in threshold renegotiation or questions scenario credibility (investigate within 1 week); adopter formally withdraws (publish reason immediately); if two or more of three adopters withdraw, the scenario portfolio becomes insufficient (requires contingency activation and panel re-advising); measured Phase III cost exceeds a locked threshold by >15% for a primary scenario (likely Scenario A or B), triggering scenario failure and gate Modify or Research Only outcome; new market development or regulatory change affects the relevance of a locked scenario (e.g., new EU feed-safety rule invalidates animal-feed category, or competitor technology becomes heavily subsidized, or a regional food-security crisis shifts urgency). If a gate-decision delay is required to resolve an adopter issue, flag to Steering Committee and funder for timeline implications (extension pushes Phase Two gate from Month 30 = 2029-04-09 or Phase Three gate from Month 60 = 2031-10-09).

### 7. Phase-Gate Evidence Readiness and Independent Gate-Review Panel Decision Monitoring
**Monitoring Tools/Platforms:**

  - Phase-Gate Evidence Freeze Checklist (per gate: Phase One Month 9 = 2027-07-09, Phase Two Month 30 = 2029-04-09, Phase Three Month 57 = 2031-07-09; tracks completion status of all required deliverables: strain rights, reactor selection, safety design, regulatory pathways, scenarios, technical data, audits)
  - Gate-Panel Briefing Package (comprehensive evidence document with technical reports, raw data, analysis methods, uncertainty ranges, gate-pass/fail criteria assessment; circulated to panel 4-6 weeks before gate meeting)
  - Independent Gate-Review Panel Recommendation Report (written decision document per gate: continue, modify, research-only, or stop; rationale, evidence assessment, and any dissenting views published verbatim)
  - Funder Gate-Decision Letter (funder's formal go/no-go decision; if deviation from panel recommendation, published justification provided to all stakeholders)

**Frequency:** Gate-readiness checkpoint reviews begin 4-6 weeks before each gate (Phase One Month 7-8 = 2027-05-09 to 2027-06-09; Phase Two Month 26-28 = 2028-12-09 to 2029-02-09; Phase Three Month 53-55 = 2031-03-09 to 2031-05-09). Evidence-freeze date is hard (Month 9, 30, 57 = 2027-07-09, 2029-04-09, 2031-07-09); gate-panel meeting typically 4 weeks after freeze. Funder decision target 4-6 weeks after panel meeting (Phase One decision by Month 12 = 2027-10-09; Phase Two by Month 33 = 2029-07-09; Phase Three by Month 60 = 2031-10-09).

**Responsible Role:** PMO Director (evidence-freeze tracking, gate-readiness checkpoint, briefing-package preparation); Independent Gate-Review Panel (evidence assessment, written recommendation); Funder or Project Sponsor (final gate decision authority and deviation justification if any); Steering Committee (pre-gate internal review and alignment)

**Adaptation Process:** If any evidence-freeze deliverable is not on track by Month 7-8 (2027-05-09 to 2027-06-09) (Phase One = 2027-05-09 to 2027-06-09) or equivalent pre-gate checkpoint, PMO Director flags the gap and escalates to Steering Committee within 1 week: assess whether the gap can be closed before the evidence-freeze deadline (Month 9, 30, 57 = 2027-07-09, 2029-04-09, 2031-07-09) or whether an extension is needed. Extensions beyond the scheduled evidence-freeze date compress the panel-review window (4-6 weeks to 2-3 weeks, reducing panel preparation quality) and delay the funder decision, pushing Phase advancement back 2-4 weeks. If a critical deliverable cannot be completed before the evidence freeze without significant rework (e.g., reactor productivity data is incomplete or defective, HAZOP unfinished, strain rights unclear), Steering Committee decides: (a) request a gate extension (Month 10 = 2027-08-09 instead of Month 9 = 2027-07-09 instead of 2027-07-09, acceptable once per phase if justified), or (b) proceed with the evidence gap as a documented condition (flag to panel, panel factors gap into risk assessment, funder is informed). If the independent gate-review panel identifies critical evidence gaps in the briefing package (e.g., raw data missing, analysis methods not transparent, uncertainty ranges not calculated), the panel chair requests supplemental materials from the project within 1-2 weeks; project must provide or acknowledge the gap cannot be closed by gate date. If the panel's recommendation deviates significantly from the project's internal assessment (e.g., project expects Continue but panel recommends Modify), the Steering Committee and funder meet immediately to understand the panel's rationale and assess whether the project's assumptions are flawed. If the funder's decision deviates from the panel's recommendation, the funder publishes written justification to all stakeholders (Steering Committee, adopters, partners, gate panel) within 5 days; the deviation is documented in the project archive as a governance decision.

**Adaptation Trigger:** Evidence-freeze deliverable is >5 days late by Month 7-8 (2027-05-09 to 2027-06-09) checkpoint; critical evidence gap identified (raw data missing, analysis method unclear, no uncertainty calculated, audit incomplete); panel recommendation conflicts with project expectation (triggers post-gate review of assumptions); funder decision deviates from panel recommendation (published justification required); if any gate decision is Modify (project must remediate and re-gate within 4 weeks typically, escalate timeline impacts to Steering Committee immediately); if any gate decision is Research Only or Stop (project winds down or transitions to publication-only mode; not a project advancement).

# Governance Extra

## Governance Validation Checks

1. Completeness Confirmation: All core governance components are present—Steering Committee charter, five dedicated technical working groups (Reactor, Safety, Regulatory/IP, Adoption, Kenyan Coordination), Project Management Office structure, gate-review panel framework (chartered by Month 1.5 = 2026-11-24, EUR 0.30M budget ring-fenced by funder), decision-escalation matrix covering 12 issue types, and detailed monitoring and KPI framework. Implementation plan is sequenced from Month 0 (2026-10-09) through Month 60 (2031-10-09) with 45+ initialization and transition steps. However, three components remain underspecified: (1) steward-entity governance and long-term IP stewardship (mentioned as 'designate steward' but no charter, legal structure or funding mechanism defined); (2) post-project governance (no succession plan if funder or host institution withdraws); (3) conflict-of-interest procedures (gate-panel charter specifies no employment ties, but no disclosure process, removal grounds or post-project restrictions documented).
2. Internal Consistency Check: Logical alignment across governance components is strong. Implementation plan correctly references the decision-escalation matrix (escalations for strain-rights barriers, ATEX noncompliance, productivity shortfalls map to Steering Committee and gate-review panel authority per the matrix). Technical working groups feed evidence to gates on schedule (bench reactors → Phase One gate Month 10 = 2027-08-09; pilot disproof experiments → Phase Two gate Month 30 = 2029-04-09; Phase Three operation → final gate Month 60 = 2031-10-09). Kenyan Replication Coordination reports monthly to Steering Committee and quarterly to gate-review panel, enabling independence assurance at each gate. KPI framework is locked before experiments (Month 1.5 = 2026-11-24) and used consistently for reactor selection and deployment-threshold comparison. However, three alignment gaps are detected: (1) gate-panel charter (Month 0-1 = 2026-10-09 to 2026-11-09) specifies 3-5 members and published-decision authority, but implementation plan assigns panel only a 'recommend' role (Month 10 = 2027-08-09 onwards), creating ambiguity about whether panel decision is binding or advisory (escalation matrix states 'panel has override authority on safety' but does not clarify if panel can block a Continue decision); (2) assistance-log auditor is 'independent' but accountable directly to the Kenyan Replication Coordination body (which reports to Steering Committee), not to the gate-review panel, so audit independence may be compromised if the Steering Committee dislikes audit findings; (3) 'adopt pre-registered disproof thresholds' is specified (Month 1.5 = 2026-11-24) but no procedure is documented for what happens if post-hoc analysis shows that a threshold was unrealistic or that external context has shifted (e.g., a published benchmark becomes outdated).
3. Potential Gaps and Areas for Enhancement—Adopter Engagement: Scenario locking (Month 9 = 2027-07-09) requires 'named prospective adopters' to be identified and signed by Month 7 (2027-05-09), but the implementation plan does not specify how adopters are pre-qualified or vetted for credibility. 'Prospective adopter' could mean a letter of interest or a formal mandate; the difference is material (a food-security agency's ministerial mandate is credible; a startup's stated interest is not). The signed commitment letters should specify a penalty or cost to the adopter for withdrawal, or alternatively, a process by which withdrawal triggers a re-gate assessment. Currently, the framework states 'adopter withdrawal triggers public disclosure and panel re-advising,' but this is weak governance if an adopter can withdraw cost-free, leading to a scenario-failure-at-gate that was foreseeable in Month 7 (2027-05-09) but not escalated to the Steering Committee. Recommend: (1) define 'named prospective adopter' as a signatory with organizational mandate or budget allocation, not a letter of interest; (2) include in the signed commitment a statement of material consequence (e.g., reputational cost of public withdrawal, or stake in a follow-on commercial opportunity); (3) establish a contingency-adopter recruitment tracker (e.g., three backup adopters pre-identified by Month 6 = 2027-04-09) so that a primary adopter's withdrawal does not require a full new landscape search.
4. Potential Gaps and Areas for Enhancement—Gate-Panel Independence and Decision Authority: The gate-review panel charter (Month 0.5 = 2026-10-24) is drafted by the Project Lead and approved by the funder but is not yet negotiated with panel members or published. The charter specifies that 'panel's recommendation is binding in the sense that deviation requires published justification,' but this is vague—does 'binding' mean that the funder cannot override without public explanation, or does it mean the funder is legally required to follow the panel's recommendation? The escalation matrix states 'funder holds release authority' and 'any deviation [from panel recommendation] requires public written justification,' implying the funder can override. This is appropriate for a funder role, but the governance framework should explicitly state: (1) what constitutes a sufficient published justification (e.g., 'funder's justification must address each point in the panel's recommendation' vs. 'funder may cite proprietary business reasons'); (2) under what circumstances a funder override is acceptable (e.g., only for non-technical reasons such as funding availability or sponsor mandate change, not for technical judgment); (3) what recourse the panel has if it believes the funder's override is unjustified (does the panel publish a dissent letter? Can it request a second-opinion review?). Additionally, the gate-panel charter specifies that the panel is independent from the host institution and funded by the funder, but no conflict-of-interest disclosure process is documented. Recommend: (1) add a signed conflict-of-interest declaration to the gate-panel charter, covering employment, funding, intellectual property ownership and prior affiliations with project participants; (2) define 'sufficient justification' for a funder override in the gate-panel charter (e.g., justification must be non-technical or must explicitly acknowledge the panel's technical findings and state the reason for divergence); (3) establish a panel-dissent-publication procedure: if the funder overrides the panel, the panel may publish a brief statement explaining its recommendation and the specific grounds on which it disagrees with the funder's override; (4) schedule an annual gate-panel-funder alignment meeting (e.g., Month 6 = 2027-04-09, Month 18 = 2028-04-09, Month 42 = 2030-04-09) to review how well the panel-funder relationship is functioning and address any tensions.
5. Potential Gaps and Areas for Enhancement—Assistance-Log Audit and Replication Independence Assurance: The framework specifies that an 'independent auditor' reviews the Kenyan assistance log monthly and flags hands-on troubleshooting >4 h/month, and that the auditor reports to the Kenyan Replication Coordination body. However, the auditor's independence is not defined: Can the Kenyan Replication Coordination body direct the auditor's findings or suppress unfavorable reports? Does the auditor have direct reporting access to the gate-review panel or the Steering Committee if the Kenyan team appears to be receiving undisclosed help? The assistance-log framework also does not specify what constitutes 'hands-on troubleshooting' vs. 'acceptable external assistance.' Examples: if a Danish safety specialist conducts a 2-hour remote interlock audit and writes a sign-off report, is that acceptable help (scheduled, safety-critical) or troubleshooting (undocumented design involvement)? If the Kenyan team emails the Danish team with a technical question and receives a 30-minute response with a diagnostic hypothesis, is that 8 instances of 30 minutes = 4 hours/month flagged? The framework should clarify: 'routine operation or design help from developers is not allowed; safe operation always overrides independence' is a principle, but in practice, the boundary is fuzzy. Recommend: (1) add to the auditor's charter a requirement that the auditor is contracted by the funder (not the host or Kenyan partner), operates on a separate budget line, and has a direct-escalation path to the Steering Committee and gate-review panel if it identifies patterns of undisclosed help; (2) define 'acceptable assistance' categories in the assistance-log charter (pre-scheduled safety reviews = yes; routine operation support = red flag; design changes initiated by developers = no; emergency troubleshooting during incident = yes if post-incident training documented); (3) establish a 'log audit readiness' checkpoint at the Phase II gate (Month 30 = 2029-04-09): the auditor produces a summary report assessing whether the Kenyan team's assistance pattern is consistent with 'independence for hypothesis B' or whether it suggests insufficient competence or documentation; the gate-review panel uses the auditor's assessment to advise on Phase III readiness.
6. Potential Gaps and Areas for Enhancement—Contingency Reserve and Alternative Funding for Deployment Gap: The framework allocates EUR 4.0M programme reserve (EUR 3.5M technical + EUR 0.5M currency), but the deployment-cost model shows a gap of EUR 274,820/yr (or EUR 3.0M equivalent to cover the deployment-scenario cost target). The implementation plan notes 'gap funding route is an open decision' and recommends 'reduced Phase Three if cost chain fails.' However, the governance framework does not specify who makes the decision to reduce Phase Three scope, on what timeline, or how the reduction is authorized. If, for example, the Phase II gate evidence shows that the deployment cost cannot be brought below EUR 15/kg (vs. the EUR 12/kg cap), and the programme's free technical reserve is EUR 3.2M, the Steering Committee would need to decide by Month 30 (2029-04-09) whether to: (1) proceed with Phase III reference unit (consume EUR 4.0M of the EUR 4.0M reserve) and accept that the Kenyan replication is therefore zero-contingency, (2) reduce to Danish unit only (release EUR 1-2M to other work), or (3) escalate to the gate-review panel that the deployment case is not credible and recommend 'Research Only.' This decision should be anticipated and explicit in the governance framework. Recommend: (1) add a decision rule to the Steering Committee charter: 'At the Phase II gate, if the measured cost is >15% above the locked scenario threshold and the programme reserve is insufficient to fund all planned activities and contingencies, the Steering Committee shall escalate to the independent gate-review panel with three options: (a) proceed with full Phase Three and accept zero margin for unbudgeted technical risk, (b) reduce Phase III to Danish unit and documentation-based replication, or (c) recommend Modify or Research Only. The panel shall assess whether the deployment case remains credible under the reduced scenario.' (2) include in the Phase II gate briefing a reserve-burn forecast: 'remaining free technical contingency after Phase II completion: EUR X; forecasted Phase III cost: EUR Y; margin for risk >20% of Phase III cost: required EUR Z; deficit: EUR Y - Z + EUR X'.

## Tough Questions

1. By Month 4 (2027-02-09), will the independent patent-freedom-to-operate review and strain-holder legal confirmations unambiguously document that a primary and backup strain are both lawfully importable into Kenya for commercial production and redistributable to independent implementers, with no third-party IP blocking publication? What specific evidence (signed letters from strain holders, written Kenyan biosafety authority confirmation, patent search results with no blocking claims identified) will constitute 'documented' in the Strain Feasibility Report, and who will sign off that the evidence is sufficient?
2. The matched bench-scale reactor comparison is pre-registered with a 70% productivity benchmark as a 'fail' threshold. If measured productivity across all three reactor concepts is 65-75% of the published C. necator baseline (within the ±15% analytical uncertainty), how will the gate-review panel distinguish between (1) the project's measurements being genuinely representative and the published benchmark being an outlier, and (2) the project's measurement framework or analytical method being flawed? What independent evidence or external validation will the panel require before judging the gate outcome?
3. By Month 9 (2027-07-09) Phase One gate, are all three 'named prospective adopters' confirmed to be organizations with explicit decision-making authority and budget allocation for protein procurement (not merely letters of interest or research partnerships)? For each adopter, can you provide the organizational mandate, annual food-security or feed-supply budget, and a signed executive commitment that thresholds will hold through the Phase III gate (Month 60 = 2031-10-09) unless all parties renegotiate in writing?
4. The Kenyan site baseline (Month 4 = 2027-02-09) is required to show >=4 unplanned grid outages per month with mean duration >=2 h and at least one >8 h per quarter. If the measured baseline shows fewer or shorter outages (e.g., 2-3 outages/month, <1.5 h mean), will the project (a) add controlled outage stressors to maintain the test burden (cost and complexity), (b) document that the actual site envelope does not test hypothesis B as planned and adjust the final conclusion accordingly, or (c) trigger a site replacement (6-12 month delay)? Specify the decision rule and the Steering Committee authority to invoke it.
5. By Month 10 (2027-08-09) Phase One gate, the independent gate-review panel will receive the bench-scale reactor audited comparison, the HAZOP with safety design basis, and the Strain Feasibility Report. If the HAZOP identifies a safety issue (e.g., a control-system failure mode that cannot be adequately mitigated without reducing productivity by >30%), what is the panel's decision authority? Can the panel recommend that the project redesign the reactor concept and re-gate, even if this adds 8-12 weeks to the schedule and consumes EUR 0.2-0.3M of Phase One contingency? Or does the panel only 'recommend,' leaving the final design decision to the Steering Committee and funder?
6. The deployment-scenario cost model shows a gap of EUR 7.93/kg (measured cost EUR 19.93/kg vs. locked threshold EUR 12/kg), corresponding to an annual funding need of EUR 274,820. By the Phase II gate (Month 30 = 2029-04-09), will the project have identified a funding route for this gap (subsidy, grant, operating cost reduction, or adopter market acceptance of higher cost), or will the gap remain unresolved? If unresolved and the measured cost trajectory in Phase II does not narrow the gap, what is the cascade of decisions: does the Phase II gate become a 'Modify' recommendation (reduce Phase III scope)? Does the final Phase Three Go decision require that at least one locked scenario is achievable without gap funding, or is gap funding assumed to exist outside the EUR 50M programme budget?

## Summary

The Open Protein Module's governance framework combines stage gates with independent review, pre-locked deployment scenarios, measured evidence and kill-gate authority into a high-rigor structure suited to a EUR 50 million, 60-month R&D programme with two hypothesis tests and substantial technical, regulatory and organizational risk. Core strengths are the separation of gate-panel funding and authority from the host institution, early front-loading of strain rights and regulatory engagement (Month 4 = 2027-02-09), pre-registered measurement frameworks and disproof-experiment thresholds, and explicit defect tracking for Kenyan replication independence. The framework's effectiveness depends critically on five unresolved dependencies: (1) signed partnership agreements and host-institution commitment, (2) genuine prospective-adopter engagement with formal threshold lock-in, (3) independent gate-panel recruitment and sustained funding independence, (4) rigorous external auditing of measurement protocols and assistance logs, and (5) funder authority to enforce Modify or Stop decisions against project-team momentum. Governance documentation is detailed but several critical implementation details remain underdeveloped—particularly gate-panel charter enforcement mechanisms, assistance-log auditor independence standards, and contingency-activation decision rights under EUR 3.5M technical reserve conditions. The framework's credibility rests on transparent publication of all gate recommendations and any funder deviations, which is specified but not yet operationalized.