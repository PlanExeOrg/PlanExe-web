## Primary Decisions
The vital few decisions that have the most impact.


The five Critical levers are the reactor concept, the safety design basis, the strain rights strategy, replication and gate governance, and deployment threshold locking. As a group they address productivity versus safety and repairability, openness versus lawful strain access, and evidence credibility versus cost and schedule. High levers cover outage handling, automation, downstream processing, the host site and scale-up. No major dimension is missing, though funding and partner agreements are only implicit.

### Decision 1: Gas-Liquid Contacting and Reactor Concept
**Lever ID:** `acd340f7-7592-4494-bfed-58a0c57225c8`

**The Core Decision:** Determines how hydrogen is transferred into the culture and what that implies for hazardous-zone size, seals, energy per kilogram and repair skill. Scope covers pneumatic loop, pressurized stirred and passive-feed concepts, plus the measured productivity cost of simplification. Success metrics: volumetric productivity and mass-transfer coefficients with uncertainty ranges, kWh per kg dry biomass, and qualification level needed for repair.

**Why It Matters:** Reactor choice sets hydrogen transfer rate, energy per kilogram, explosion exposure and the skill needed to operate and repair the unit. Pneumatic loop designs have fewer moving parts but may cap productivity. Pressurized stirred designs raise productivity but add ATEX burden, seals and specialist maintenance. The productivity cost of simplification is itself a headline result, so both ends need measuring.

**Strategic Choices:**

1. Develop a low-pressure pneumatic loop or bubble-column reactor with no mechanical agitation, and accept lower volumetric productivity in exchange for simpler repair and a smaller hazardous zone.
2. Develop a pressurized stirred-tank reactor with high-productivity gas transfer, and accept ATEX certification, seal maintenance and specialist-qualified service as part of the design.
3. Run matched pneumatic, stirred and passive-feed reactors on identical strain and media, then publish a measured productivity-versus-simplicity curve before choosing the Phase Three reference unit.

**Trade-Off / Risk:** Testing all three concepts gives the strongest evidence but consumes Phase One and Two budget and time, while committing early to one concept risks locking in a design whose scale-up assumptions fail late.

**Strategic Connections:**

**Synergy:** Supplies the measurements that Scale-Up Evidence Ladder and Disproof Experiments needs to test extrapolation, and informs Automation Depth and Operator Skill Boundary by defining how many moving parts, sensors and interlocks the unit requires.

**Conflict:** Pressurized stirred designs raise productivity but add ATEX burden, conflicting with Inherent Safety Design Basis and Adopter Change Boundary and with local repairability under Automation Depth and Operator Skill Boundary. Matched testing of all concepts also competes with Strain Portfolio and Rights Strategy for Phase One budget.

**Justification:** *Critical*, Central hub: sets mass transfer, energy per kilogram, hazardous-zone size and repair skill. It conflicts with safety, change boundary and automation, and supplies the data for scale-up. It controls the core productivity-versus-simplicity trade-off behind hypotheses A and B.

### Decision 2: Strain Portfolio and Rights Strategy
**Lever ID:** `a991eeee-72d9-4e6c-88fe-40bd04f3c9b3`

**The Core Decision:** Selects the reference strain and a backup, and documents its rights for research, commercial production, redistribution, modification and derived strains. It also covers biosafety class, import permissibility into Kenya and nucleic acid content. Success metrics: written rights analysis per strain, confirmed lawful obtainability by independent implementers in target countries, and comparative productivity under identical conditions.

**Why It Matters:** The reference strain determines productivity, nucleic acid content, biosafety class and above all legal reproducibility. A public-collection strain such as C. necator H16 eases lawful access but may carry restrictions on commercial use or derived strains. Alternatives could perform better but weaken the requirement that independent implementers can lawfully obtain the strain in target countries.

**Strategic Choices:**

1. Commit to a single public-collection reference strain, document its rights for research, commercial use, redistribution and modification, and confirm lawful import into Kenya before any design freeze.
2. Screen several candidate strains in Phase One for productivity and rights, and carry a primary and a legally clean backup strain through Phase Two so a rights or performance failure does not stop the project.
3. Isolate or evolve a project-owned strain from environmental samples or adaptive laboratory evolution, deposit it in a public collection under open terms, and compare it against the public reference strain.

**Trade-Off / Risk:** A project-owned strain could remove legal dependence on third parties, but it adds years of characterization, biosafety and regulatory work that may exceed the Phase One budget, and it may never match the reference's productivity.

**Strategic Connections:**

**Synergy:** Underpins Open Licence Stack and Stewardship Model, since publishable strain instructions depend on clear rights, and supports Replication Design and Gate Governance by letting the Kenyan team obtain the strain without developer help.

**Conflict:** Carrying a backup or project-owned strain adds characterization and biosafety work that competes with Gas-Liquid Contacting and Reactor Concept testing and with Regulatory Engagement Sequencing. A rights-clean strain may also be less productive than alternatives.

**Justification:** *Critical*, Foundational pillar: lawful strain access for independent implementers is a hard project requirement. It underpins the open licence stack, enables replication without developer help, and links to regulation and contamination control. A rights or performance failure could stop the whole project.

### Decision 3: Replication Design and Gate Governance
**Lever ID:** `46bf5862-3ae2-48f5-bb1a-0f0a5fc459a4`

**The Core Decision:** Defines how independence of the Kenyan replication is secured and who controls money at each gate. Scope covers team separation, the audited assistance log, documentation-defect tracking, reviewer funding independence, and written continue/modify/research-only/stop decisions. Success metrics: defects found per documentation release, share resolved before construction, reviewer independence verified, and no gate passed by default or momentum.

**Why It Matters:** This lever sets how independent the Kenyan replication is, how documentation gaps are discovered, and who can release or stop funding. A stricter separation yields more credible evidence of reproducibility, but it risks unsafe or wasted attempts if documentation is poor. Gate design determines whether the EUR 50 million ceiling is spent in stages or committed by momentum.

**Strategic Choices:**

1. Run one full-scale Kenyan replication after the Danish reference unit is complete, using a separate team under an audited assistance log, and fund it only after the gate reviewers confirm documentation readiness.
2. Add an early paper-and-bench replication in Phase Two, in which an independent group builds a small unit from draft documents, to find documentation defects before committing to full-scale construction.
3. Fund an independent reviewer panel with its own budget and authority to release or withhold each phase's money, and require a written continue, modify, research-only or stop decision at every gate.

**Trade-Off / Risk:** An early documentation-only replication catches gaps cheaply, but it adds cost and schedule, and a small-scale success may give false confidence about full-scale builds, outage behavior and local sourcing.

**Strategic Connections:**

**Synergy:** Amplifies Scale-Up Evidence Ladder and Disproof Experiments, since pre-set gate criteria give disproof results binding force. Also strengthens Open Licence Stack and Stewardship Model, because logged ambiguities feed documentation fixes before publication.

**Conflict:** Strict separation and staged funding slow Kenyan Host Site and Partner Configuration, because a harsh site needs developer support that the assistance log restricts. It also competes with Inherent Safety Design Basis and Adopter Change Boundary where safe operation needs intervention.

**Justification:** *Critical*, Controls the independence of the replication and who releases funding at each gate. It gives disproof results and thresholds binding force and prevents continuation by momentum. It governs the trade-off between credible reproducibility evidence and cost, schedule and safe operation.

### Decision 4: Deployment Scenario Anchoring and Threshold Locking
**Lever ID:** `69832a26-b5ef-4c64-b6e7-0e767bbe9057`

**The Core Decision:** Defines the user scenarios the design must beat and fixes maximum production cost, minimum useful capacity and required reliability before any prototype evaluation. It gives the Phase Three Go decision its meaning. Key metrics are the number of locked scenarios, the quality of the benchmark data behind them, evidence of adopter input, and the absence of any post-hoc threshold change.

**Why It Matters:** Choosing which user scenarios the design must beat, and fixing maximum cost, minimum capacity and reliability before testing, determines whether the final Go decision means anything. Scenarios close to real adopters give the most credible evidence but depend on partners who are not yet signed. Hypothetical scenarios are easier to define but are easier to adjust to fit results.

**Strategic Choices:**

1. Define two or three candidate scenarios with named prospective adopters, such as a national reserve agency or a regional feed producer, and lock their thresholds in a signed, time-stamped document before any prototype evaluation.
2. Derive scenarios from published cost data on protein reserves, legumes and proprietary systems, and lock thresholds as the margin the open design needs over the best defensible alternative in each case.
3. Appoint an independent adversarial review panel that sets and holds the scenario thresholds, and allow it to add a harsher scenario once Phase Two data are available but never to relax any existing one.

**Trade-Off / Risk:** Pre-set thresholds protect the Go decision from rationalization, but if they are set from weak cost data or without real adopter input, the project may pass or fail against a scenario no one would actually use.

**Strategic Connections:**

**Synergy:** Gives Replication Design and Gate Governance fixed pass/fail criteria for Go/Modify/Stop decisions, and gives Scale-Up Evidence Ladder and Disproof Experiments a concrete target capacity and cost to test against.

**Conflict:** Locking thresholds early restricts Gas-Liquid Contacting and Reactor Concept and Automation Depth and Operator Skill Boundary, which may later prove better with different trade-offs. Named adopters are also unsigned and may withdraw, forcing rework.

**Justification:** *Critical*, Gives the Phase Three Go decision its meaning by fixing cost, capacity and reliability thresholds before testing. It supplies pass/fail criteria to gates and targets to scale-up, and constrains reactor and automation choices. It governs the public-value case and prevents post-hoc rationalization.

### Decision 5: Inherent Safety Design Basis and Adopter Change Boundary
**Lever ID:** `2aa84815-ce55-481c-b5f3-85b0e9261da3`

**The Core Decision:** Determines how the hydrogen-oxygen ignition hazard is controlled: through inherent limits on gas composition and inventory, layered instrumented protection, or a machine-readable safety case. It also defines which parts and parameters adopters may change without reassessment. Metrics include hazard-analysis findings closed, independent interlock review results, safety incidents, and the productivity penalty measured against the safety margin.

**Why It Matters:** This lever sets how hydrogen-oxygen explosion risk is controlled: by gas-composition and inventory limits designed into the process, or by layered instrumented protection. It also fixes which components and parameters adopters may change without a full safety reassessment. A tighter boundary lowers the risk of unsafe local adaptation but reduces the repairability and substitution freedom that hypothesis B depends on.

**Strategic Choices:**

1. Design the process around inherently safer limits, such as keeping gas mixtures outside flammable ranges and minimizing gas inventory, so most failures cannot reach an ignitable state without relying on instrumentation.
2. Adopt layered instrumented protection with independently reviewed interlocks and emergency shutdown, and publish a short list of pre-assessed substitutable components and adjustable parameters for adopters.
3. Publish a machine-readable safety case in which each parameter and component carries a computed safe-change envelope, so adopters can check a proposed modification against the hazard analysis before building it.

**Trade-Off / Risk:** Inherently safer limits may cut productivity because gas-liquid transfer often improves with richer, more reactive mixtures, so the safety margin and the productivity benchmark pull against each other and the cost must be measured, not assumed.

**Strategic Connections:**

**Synergy:** Supports Outage Survival and Hydrogen Buffering Strategy by bounding safe gas inventory during shutdown and restart, and underpins Open Licence Stack and Stewardship Model by letting operating instructions pass safety and legal review for release.

**Conflict:** Tighter limits can reduce gas-liquid transfer and productivity, conflicting with Gas-Liquid Contacting and Reactor Concept. A narrow adopter change boundary also limits the substitution freedom that Kenyan Host Site and Partner Configuration and hypothesis B depend on.

**Justification:** *Critical*, Hub controlling the hydrogen-oxygen explosion risk and what adopters may change. It trades safety margin against productivity and repairability, and conflicts with reactor, host site and licence choices. It supports outage handling and release of operating instructions, so it is a non-negotiable design constraint.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Reference Architecture Sourcing
**Lever ID:** `856adffe-4bbc-41ac-8941-72d93379b50c`

**The Core Decision:** Sets the Phase One decision on whether published open work (for example the electroPioreactor or passive gas-feeding research) becomes the base design or is only a data source. Scope includes benchmark protocol, selection criteria and the licence status of inherited material. Success metrics: decision evidence recorded before blueprint v0.1, measured productivity and safety gaps versus requirements, and researcher collaboration agreements signed.

**Why It Matters:** This lever decides whether the project adopts an existing open design, such as the electroPioreactor or passive gas-feeding work, or defines its own architecture. Building on existing work shortens Phase One and builds researcher goodwill, but it inherits that work's scale and safety limits. A clean-sheet design gives control over safety and replicability but risks duplicating published effort and delaying measurements.

**Strategic Choices:**

1. Adopt one published open design as the reference architecture, then extend it with safety engineering, product-quality control and documentation for independent builders.
2. Run a short head-to-head benchmark of two or three published designs in Phase One, then select or hybridize on measured productivity, safety and buildability.
3. Commission a clean-sheet process design from a safety-first specification, treating published designs only as data sources, to avoid inherited limits on scale and certification.

**Trade-Off / Risk:** Adopting an existing design saves time, but its assumptions about scale, gas safety and component availability may not hold in Kenya, so the Phase One decision needs measured evidence rather than familiarity or collaboration convenience.

**Strategic Connections:**

**Synergy:** Feeds Gas-Liquid Contacting and Reactor Concept by supplying candidate designs and baseline data, and strengthens Open Licence Stack and Stewardship Model when the inherited design carries compatible open licences that keep the core publishable.

**Conflict:** Adopting a published design early can pre-empt Gas-Liquid Contacting and Reactor Concept testing and bind Inherent Safety Design Basis and Adopter Change Boundary to another group's safety assumptions. Benchmarking several designs also consumes Phase One time and budget.

**Justification:** *High*, Decides in Phase One whether published open work becomes the base design. Feeds the reactor concept and licence stack, but can bind safety assumptions to another group. Important early and time-bound, though its influence is largely absorbed by the reactor and safety choices.

### Decision 7: Outage Survival and Hydrogen Buffering Strategy
**Lever ID:** `f132b399-c700-490e-bce8-ba01610786fe`

**The Core Decision:** Defines how the unit behaves when grid or solar power fails without mandated hydrogen storage: safe shutdown, culture hold, documented restart and the maximum outage survived. It also drives electrolyzer sizing, battery needs and the energy-crisis resilience claim. Success metrics: outage duration survived, restart time, post-restart productivity recovery, and strain stability over repeated cycles.

**Why It Matters:** Because hydrogen storage is not mandated, the process must be designed for grid or solar interruptions through safe shutdown, culture hold and documented restart. This choice sets how much downtime the culture and product quality can tolerate and how much battery, storage or duplication is needed. It also changes the electrolyzer sizing and the energy-crisis resilience claim.

**Strategic Choices:**

1. Design for on-demand electrolysis with no hydrogen storage, using automatic safe shutdown, a culture-hold protocol and a documented restart sequence, and measure the maximum outage the culture survives.
2. Add a small, independently reviewed hydrogen buffer or battery bridge that rides through short outages, and keep the long-outage protocol identical to the no-storage design.
3. Treat intermittent supply as the normal operating mode by coupling the electrolyzer directly to variable solar power and running the culture in deliberate on-off cycles, then test productivity loss against steady-state operation.

**Trade-Off / Risk:** Surviving outages without storage keeps hazards low, but repeated stress cycles may degrade strain stability and productivity, and intermittent operation could undercut the cost and uptime thresholds that make a deployment case credible.

**Strategic Connections:**

**Synergy:** Supports Kenyan Host Site and Partner Configuration, because a site with a measured outage pattern gives realistic test cases, and supports Deployment Scenario Anchoring and Threshold Locking by establishing the reliability that scenarios must meet.

**Conflict:** A hydrogen buffer or battery bridge adds hazard and cost, pulling against Inherent Safety Design Basis and Adopter Change Boundary. Repeated stress cycles can also undermine Contamination Control and Culture Continuity Regime and the strain's productivity stability.

**Justification:** *High*, Defines behaviour under power failure without mandated storage, driving electrolyzer sizing, safety exposure and the resilience claim. It links to the Kenyan site, scenario thresholds, safety and culture stability. Strong interactions, but narrower than the foundational design levers.

### Decision 8: Automation Depth and Operator Skill Boundary
**Lever ID:** `acc4906f-7eb6-4b83-985b-d48d6910d181`

**The Core Decision:** Places the line between automated control and human judgement, determining which tasks locally trained technicians may do and which need defined qualifications. It governs controller choice, interlock architecture, software openness and training burden. Success metrics: operator competence after a short verified programme, mean time to repair with local parts, no interlock bypass, and fault-injection pass rates by operator level.

**Why It Matters:** Automation reduces the training needed for routine operation but increases the controller, sensor and software complexity that independent teams must source and repair. Too little automation raises operator error near hydrogen and oxygen. Choosing where the line sits between locally trained technicians and qualified specialists defines the evidence for hypothesis A and the repairability claim in hypothesis B.

**Strategic Choices:**

1. Build a PLC-based system with interlocks and a documented parameter envelope on widely available commodity hardware, so routine runs need only short, competency-verified training.
2. Use a deliberately minimal, mostly hardwired and mechanical safety layer with few software functions, and rely on stricter operator procedures and checklists for routine control.
3. Split the system into a sealed, independently reviewed safety module that only qualified staff may service, and an open, modifiable process-control layer that local technicians may adapt within defined limits.

**Trade-Off / Risk:** Splitting safety from process control clarifies who may change what, but it creates a specialist dependency that conflicts with the goal of local repairability, especially where certified service is far away.

**Strategic Connections:**

**Synergy:** Provides the operational evidence for Inherent Safety Design Basis and Adopter Change Boundary by making change rights explicit, and helps Replication Design and Gate Governance by giving the Kenyan team a clear competence boundary to test.

**Conflict:** A sealed safety module creates specialist dependency that conflicts with Kenyan Host Site and Partner Configuration constraints on service access and spare parts. Deeper automation also adds software complexity that tension with open, independently repairable hardware.

**Justification:** *High*, Sets the line between automation and technician judgement, which is the direct evidence for hypothesis A and repairability in B. Connects to safety, reactor, downstream, contamination and the Kenyan site. It largely follows from the reactor and safety choices.

### Decision 9: Nitrogen and Mineral Supply Localization
**Lever ID:** `432d7737-4969-4c79-9137-1a6fb38c81cf`

**The Core Decision:** Decides which nitrogen compound and mineral medium the process uses, and how far each can be sourced locally or regionally. It governs hazard class, storage, purity tolerance and the days of production sustained without resupply. Success metrics: resupply-autonomy days per input, share of inputs sourced locally or regionally, and growth and biomass-quality variation across supplier purity ranges.

**Why It Matters:** The nitrogen source (ammonia, ammonium salts, urea or other forms) and the mineral medium determine hazard class, transport needs, and how many days production continues without resupply. Local or regional sourcing improves vendor independence but may bring variable purity that affects growth and biomass quality. Imported, standardized inputs make results reproducible but weaken the independence argument.

**Strategic Choices:**

1. Standardize on a single commodity nitrogen compound with documented specifications and at least two alternative regional suppliers, and test growth across the purity range those suppliers deliver.
2. Design the medium around locally producible nitrogen and minerals, such as fertilizer-grade salts or recovered streams, and measure the productivity and quality penalty relative to laboratory-grade inputs.
3. Run a staged input-substitution programme in which each critical input is progressively replaced by a locally sourced equivalent, with the resupply-autonomy figure for each input recorded and published at each step.

**Trade-Off / Risk:** Substituting cheaper local inputs can quietly shift biomass composition and contaminant load, so savings in sourcing may reappear as extra downstream processing or regulatory burden if quality is not tracked alongside autonomy.

**Strategic Connections:**

**Synergy:** Supports Deployment Scenario Anchoring and Threshold Locking by supplying the local-sourcing and autonomy figures that scenario thresholds rely on. Also supports Kenyan Host Site and Partner Configuration, since the site tests real supply chains.

**Conflict:** Variable local input purity strains Contamination Control and Culture Continuity Regime and can burden the Downstream Protein Purification Train with extra contaminant or nucleic acid handling, offsetting sourcing savings.

**Justification:** *Medium*, Determines resupply autonomy and local sourcing share, which support scenario thresholds and the Kenyan site. Its effects are mostly input-level optimization, with side effects on contamination and downstream load. Less connected to the core strategic conflicts.

### Decision 10: Downstream Protein Purification Train
**Lever ID:** `5e133b86-6e5d-455f-815e-2260b25c2aad`

**The Core Decision:** Covers harvesting, cell disruption, nucleic acid reduction and drying, which turn raw biomass into usable, digestible protein. It sets the equipment, energy and labour burden beyond the fermenter and the range of eligible product categories. Success metrics: nucleic acid content, protein digestibility, energy and cost per kilogram of usable protein, and technician competence on each step, all measured on one fixed processing boundary.

**Why It Matters:** Harvesting, cell disruption, nucleic acid reduction and drying decide whether biomass is usable protein and how much equipment and energy sit beyond the fermenter. A heavier train raises protein quality and the range of eligible product categories but adds maintenance burden for local technicians. A lighter train protects simplicity but may restrict the product to uses with lower purity demands.

**Strategic Choices:**

1. Build a minimal train of centrifugation or filtration and low-complexity drying, and accept a limited product range pending composition and digestibility data from Phase Two.
2. Include a validated nucleic acid reduction step, such as thermal or enzymatic treatment, in the reference design and test whether technicians can run it within the defined competency envelope.
3. Develop the downstream train as separable tiers, with a core tier for all adopters and optional upgrade modules, so that the fermenter design is not constrained by the most demanding product category.

**Trade-Off / Risk:** Downstream steps are often underestimated in techno-economic models, and the energy and labour they add can erase fermenter-level gains, so the same processing boundary must be used for every benchmark comparison.

**Strategic Connections:**

**Synergy:** Enables Regulatory Engagement Sequencing, since validated composition and purity data define the product-safety dossier. Also reinforces Deployment Scenario Anchoring and Threshold Locking by showing which product categories meet cost and quality thresholds.

**Conflict:** A heavier train conflicts with Automation Depth and Operator Skill Boundary by adding maintenance tasks beyond routine technician skills. It also competes with Scale-Up Evidence Ladder and Disproof Experiments for budget and test capacity.

**Justification:** *High*, Decides whether biomass becomes usable, digestible protein and how much energy, cost and maintenance sit beyond the fermenter. It shapes product category, regulatory dossier and operator burden. Often underestimated, so it needs a fixed processing boundary for benchmarks.

### Decision 11: Kenyan Host Site and Partner Configuration
**Lever ID:** `7f1b38e0-d840-43ba-9493-cc044ad848c6`

**The Core Decision:** Determines where and with whom the replication takes place, and so whether it truly tests unreliable power, water quality, climate, spares and local skills. It covers site selection, co-development partner roles, logistics and access to analytics and safety review. Success metrics: documented envelope measurements for the site, commissioning time, outage-survival results, and the share of failures attributable to logistics rather than design.

**Why It Matters:** The site and partner arrangement determines whether the replication really tests unreliable power, water, climate and supply chains, or becomes a showcase. A harsh site yields credible evidence but raises the risk of delays, failed tests and safety exposure. A better-supported site lowers risk but weakens the claim that the design works under difficult infrastructure.

**Strategic Choices:**

1. Select a site in an area with documented frequent grid outages and limited spare-part access, and accept longer commissioning and higher logistics effort in return for stronger evidence on Hypothesis B.
2. Select a mid-tier site with measurable but moderate infrastructure limits, and add controlled stressors such as induced outages and degraded water to reach the harsher envelope in a safer setting.
3. Run a two-site design in which a harsh-infrastructure site does the unsupported build and fault-injection tests while a better-equipped partner site provides independent analytics and safety review.

**Trade-Off / Risk:** A site chosen for convenience will pass tests that a real adopter would fail, but a site chosen for hardship may fail for logistical reasons that obscure whether the documentation or the design was at fault.

**Strategic Connections:**

**Synergy:** Strengthens Outage Survival and Hydrogen Buffering Strategy by providing a real outage pattern against which to validate it. Also amplifies Nitrogen and Mineral Supply Localization, since real local supply chains expose true resupply autonomy.

**Conflict:** A harsh site raises safety exposure, which pushes against Inherent Safety Design Basis and Adopter Change Boundary. It also strains Replication Design and Gate Governance, since logistics failures can obscure whether documentation or design caused a test failure.

**Justification:** *High*, Determines whether the replication truly tests the harsh operating envelope or becomes a showcase. Links outage patterns, real supply chains, safety exposure and gate governance. Very important for the hypothesis B evidence, but depends on design choices and unsigned partners.

### Decision 12: Open Licence Stack and Stewardship Model
**Lever ID:** `0c5f4dfa-77fa-47d3-999b-e0c3794c1c13`

**The Core Decision:** Sets the licences for hardware, software, data and documentation, and the legal body that holds and enforces them. It governs whether the core stays open, whether adopters can build commercially without legal risk, and how conformity to the tested reference is shown. Success metrics: freedom-to-operate review completed per jurisdiction before release, adopter uptake, closed-fork incidents, and stewardship funding continuity.

**Why It Matters:** The licence mix for hardware, software, data and documentation, together with the legal body that holds them, decides whether the core stays open and whether adopters can build commercially without legal risk. Strong reciprocal terms protect openness but may deter industrial adopters. Permissive terms spread the design widely but allow closed forks, including by a single company, which the project aims to avoid.

**Strategic Choices:**

1. Use reciprocal open licences across hardware, software and documentation so that improvements by adopters must be shared back, with a non-profit steward enforcing them.
2. Use permissive licences for data and documentation and reciprocal licences only for safety-critical designs and control software, so that safety changes remain traceable.
3. Place the design under a defensive-publication and patent-pledge structure managed by a neutral foundation, with a certification mark that lets adopters show conformity to the tested reference.

**Trade-Off / Risk:** Licence terms cannot override patents or strain restrictions held by third parties, so the governance model gives little protection unless the freedom-to-operate review is completed per jurisdiction before the release.

**Strategic Connections:**

**Synergy:** Amplifies Strain Portfolio and Rights Strategy, since clear strain rights allow the full package to be released under consistent terms. Also supports Replication Design and Gate Governance by giving the audited documentation a controlled, versioned home.

**Conflict:** Strong reciprocal terms may deter industrial adopters, working against Deployment Scenario Anchoring and Threshold Locking. Releasing operating instructions openly also pressures Inherent Safety Design Basis and Adopter Change Boundary, since uncontrolled forks may alter safety-critical parameters.

**Justification:** *Medium*, Keeps the core open and prevents closed forks, which fits the mission. However it depends on strain rights, freedom-to-operate review and safety review, and it cannot override third-party patents. Mostly an enabling layer rather than a driver of technical outcomes.

### Decision 13: Regulatory Engagement Sequencing
**Lever ID:** `8fa32114-4c8e-4bfa-9ffe-b2f3e7cb0501`

**The Core Decision:** Sets when and in what form the project approaches Danish, EU and Kenyan authorities, separating experimental operation (contained use, site permits), product safety validation and commercial distribution. Success is measured by the number of hard requirements identified before hardware is committed, written feedback logged as design inputs, and a documented regulatory pathway per jurisdiction by the Phase One gate.

**Why It Matters:** The timing and form of contact with Danish, EU and Kenyan authorities determines how early the project learns about hard requirements on strain classification, contained use, product safety and distribution. Early engagement can reshape the design before costs are sunk but exposes immature data. Late engagement protects focus but risks discovering a blocking requirement after hardware is built.

**Strategic Choices:**

1. Open informal pre-submission dialogue with the competent authorities in Denmark/EU and Kenya during Phase One and use their written feedback as design inputs for the blueprint.
2. Engage regulators only for experimental operation and contained-use permits until Phase Two data exist, then open product-safety discussions with a complete composition and digestibility dossier.
3. Commission an independent regulatory firm to build a jurisdiction-by-jurisdiction requirements map, including routes in a third country such as Bangladesh, and rank the design options by regulatory friction before talking to any authority.

**Trade-Off / Risk:** Early regulator contact can surface a blocking requirement cheaply, but informal feedback is not binding, so a favourable signal could be mistaken for a pathway that formal review later closes.

**Strategic Connections:**

**Synergy:** Feeds Strain Portfolio and Rights Strategy with early strain-classification and contained-use rulings, and informs Deployment Scenario Anchoring and Threshold Locking by showing which product categories can realistically be distributed in each target jurisdiction.

**Conflict:** Early dialogue competes with Downstream Protein Purification Train and Scale-Up Evidence Ladder and Disproof Experiments for immature data and staff time. Regulators may demand dossiers before processing and composition data are stable, so design freedom can narrow prematurely.

**Justification:** *Medium*, Timing of authority contact affects how early blocking requirements surface, informing strain and scenario choices. Informal feedback is non-binding, and the lever mainly sequences effort. A credible pathway is required, but this lever is subordinate to product and strain decisions.

### Decision 14: Scale-Up Evidence Ladder and Disproof Experiments
**Lever ID:** `6412e8f5-30eb-40c3-9617-77ae0e3d0968`

**The Core Decision:** Connects the reference-unit capacity to the modeled deployment capacity through measured steps and experiments designed to disprove the main scale-up assumptions. Success means pre-registered failure thresholds, uncertainty ranges on every extrapolation, and consistent definitions of volumetric productivity and system energy use against published benchmarks. It guards against treating a working reference unit as proof of industrial viability.

**Why It Matters:** This lever defines how the reference-unit capacity and the modeled deployment capacity are connected, and which principal scale-up assumptions are tested to failure before Phase Two. A ladder of intermediate scales gives measured uncertainty ranges but consumes schedule and budget. Skipping rungs saves money but leaves extrapolation resting on models rather than measurements, which the plan rules out.

**Strategic Choices:**

1. Build a stepwise ladder of bench, container-scale and reference-unit tests, with each rung required to reproduce the previous rung's mass-transfer and productivity numbers within stated uncertainty before proceeding.
2. Run scale-down experiments that deliberately reproduce large-scale gradients in small reactors, so the scale-up assumptions are attacked cheaply in the laboratory before any larger hardware is committed.
3. Commission an independent modeling group to build a competing scale-up model from the published data and to design the experiments most likely to falsify the project's own model.

**Trade-Off / Risk:** Disproof experiments only help if their failure thresholds are fixed before data arrive, and a competing model costs real money; without pre-registration, the ladder becomes a story told after the fact.

**Strategic Connections:**

**Synergy:** Supplies measured mass-transfer and productivity data to Gas-Liquid Contacting and Reactor Concept and Downstream Protein Purification Train, and gives Replication Design and Gate Governance evidence for the Phase Two kill gate.

**Conflict:** Extra rungs and competing models consume budget and schedule, constraining Replication Design and Gate Governance timelines and Kenyan Host Site and Partner Configuration. Pre-registered failure thresholds can also force early stops of promising reactor concepts.

**Justification:** *High*, Connects reference-unit data to modeled deployment capacity through pre-registered disproof experiments, guarding against treating a working unit as industrial proof. It strengthens the Phase Two gate and draws on reactor data. Important, but it largely operationalizes other choices.

### Decision 15: Contamination Control and Culture Continuity Regime
**Lever ID:** `dcbb34d4-efea-4c0e-863e-4840687b04c7`

**The Core Decision:** Governs how the single pure strain is protected from contamination and kept viable, covering seed-train procedures, cryo-stock storage and revival, purity verification, and the limit on sterility requirements the operating envelope allows. Key metrics are batch loss rate, time to restore a lost line, purity-test pass rate, and whether product specification holds when sterility is relaxed.

**Why It Matters:** This lever governs how a single pure strain is kept uncontaminated and viable in settings with limited sterile infrastructure, including how seed cultures are stored, revived and verified. A strict aseptic regime protects product quality and safety but demands skills and consumables that may not exist locally. A relaxed regime fits the operating envelope but raises batch-loss and product-safety risk.

**Strategic Choices:**

1. Specify a full aseptic protocol with sterilizable reactors, validated seed-train procedures and routine purity checks, with biological quality assurance reserved for explicitly qualified staff.
2. Design for contamination tolerance by exploiting the selective growth conditions of autotrophic hydrogen-oxidizing growth, and test how far sterility requirements can be relaxed without failing product specification.
3. Create a distributed seed-culture continuity scheme in which certified cryo-stocks are held at several independent sites, so a lost or contaminated line can be restored without the original developers.

**Trade-Off / Risk:** Relying on selective growth conditions to tolerate contamination is plausible but unproven for this configuration, and a single undetected contaminant in a food or feed product could outweigh any simplification gain.

**Strategic Connections:**

**Synergy:** Strengthens Strain Portfolio and Rights Strategy through lawful cryo-stock distribution and traceable strain provenance, and supports Replication Design and Gate Governance by letting the Kenyan team recover lost lines without developer help.

**Conflict:** A strict aseptic regime conflicts with Automation Depth and Operator Skill Boundary and Kenyan Host Site and Partner Configuration, since it needs skills, consumables and sterilizable equipment that may be scarce locally. Tolerance-based approaches risk product safety.

**Justification:** *Medium*, Protects a single pure strain and enables recovery of lost lines without developers. It trades product safety against skills and consumables, touching automation and the Kenyan site. Mostly an operational optimization, reasonably contained within the strain and automation decisions.
