## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Is the independent gate panel chartered, with at least 3 conflict-free members and a written funder commitment to publish any deviation? | Charter signed by the funder (not the host) by Month 1.5 (2026-11-24); >=3 conflict-free qualified members; EUR 0.30M ring-fenced; funder deviations published with written justification within 5 working days | Signed Gate Authority Charter, conflict-of-interest statements and the funder's written deviation-publication commitment, at Month 1.5 (2026-11-24) (the Danish host MoU is due at Month 1 = 2026-11-09) | Delay: do not commit Phase One spend beyond committed items. If fewer than 3 conflict-free members exist, the funder must reform governance first. Repeated unjustified overrides suspend the programme. |
| 2 | Is there at least one lawfully usable reference strain, plus a clean backup, that can be imported into Kenya? | >=2 strains with documented rights for research, commercial use, redistribution, modification and derived strains; lawful Kenyan import; written Kenyan biosafety feedback; no blocking patent (Strain Feasibility Report at Month 4 = 2027-02-09) | Strain Feasibility Report and patent search at Month 4 (2027-02-09), with written strain-holder and Kenyan biosafety responses | Switch to the backup using the EUR 0.30M earmark before Month 4 (2027-02-09). If no strain is lawfully importable into Kenya by Month 6 (2027-04-09), stop or pivot to Research Only. |
| 3 | Is a gap-funding route committed and have at least 2 named adopters signed, so that scenarios can be locked? | Written gap-funding commitment (grant, operating subsidy or cost reduction) by Month 7 (2027-05-09); >=2 signed adopters with auditable cost data; modeled full cost not stuck at or above EUR 15/kg at Month 6 (2027-04-09) (current EUR 19.93/kg vs EUR 12 cap) | Funder's written gap-route decision, signed adopter commitments (Month 7 = 2027-05-09), cost-reduction study and the independent cost-model audit; scenarios locked at Month 9 (2027-07-09) | Do not lock scenarios or let the Phase One gate pass. Downsize to a Danish-only or documentation-based Phase Three, or recommend Research Only. Withdrawals are published. |
| 4 | Does the Phase One gate evidence show a safe, productive reactor concept? | Bench productivity >=90% of the published C. necator benchmark (70% to <90% = panel decision; <70% = fail; uncertainty +/-15%, no pass above 30%); HAZOP complete with O2 <4% in H2-rich stream, <0.5 m3 H2 inventory, <=2 bar(g) without independent overpressure relief; reference architecture decided | Triplicate matched-reactor results with external audit and the independent HAZOP/design basis, at evidence freeze Month 9 (2027-07-09), panel Month 10 (2027-08-09) (extension to Month 11 = 2027-09-09 only for a single incomplete criterion), release decision by Month 12 (2027-10-09) | Modify (extend within the one-month limit, or change reactor concept) or, if no concept reaches 70% inside the safety limits, Research Only. Phase Two funding is not released. |
| 5 | Should the EUR 4.0M reference-unit hardware be released at the Phase Two gate? | kLa decline bench to pilot <=25%; 16-week strain run <10% variation in growth, O2 uptake and nucleic acid; downstream train meets protein >=60%, nucleic acid <=2%, moisture <=8% (estimate); composition/digestibility confirm the category; defects 0 safety-critical, <=3 critical, <=10 minor; model cost <=EUR 14/kg with gap route committed (basis to be fixed) | Pre-registered disproof results, strain-stability run, downstream pilot data, defect log and auditor readiness assessment (Month 26 = 2028-12-09), panel decision at Month 30 (2029-04-09) | Withhold the hardware. Recommend a reduced Phase Three (Danish unit plus documentation-based replication), a lower-bar product category, or Research Only. |
| 6 | Does the independent Kenyan replication meet the Go criteria at the Phase Three gate? | On-spec biomass from documentation alone; 100% of safety-critical and >=90% of other fault injections recovered; six consecutive months uptime >=90% (and the scenario's own floor, e.g. 95% for A); operator practical safety pass >=90%; assistance log hands-on help <=4 h/month; >=1 locked scenario met; credible regulatory and scale-up routes; hypotheses A and B both pass | Six-month production (Months 48–54 = 2030-10-09 to 2031-04-09), fault injection (Months 50–56 = 2030-12-09 to 2031-06-09), audited assistance log, evidence freeze Month 57 (2031-07-09), decision by Month 60 (2031-10-09) | Modify if failures are correctable (e.g. documentation); Research Only if the technology works but no scenario or scale-up route holds; Stop on repeated replication failure or fundamental safety, legal or reproducibility failure. Either hypothesis failing excludes Go. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: pitch.md
    canonical: deployment_chain_gap = full cost EUR 19.93/kg vs EUR 12 cap (gap EUR 7.93/kg) (estimate)
    observed:  credible path to EUR 12/kg production cost
HIGH CF-002  document: review_plan.md Review 8 and 10
    canonical: deployment_opex = EUR 401,920/yr = EUR 11.59/kg usable protein (estimate); full cost EUR 19.93/kg
    observed:  cost per kg from EUR 19.93/kg to EUR 13.8–15.8/kg; electricity 53% of opex
HIGH CF-003  document: review_plan.md Review 8.1; premortem.md FM8
    canonical: energy_per_kg = 40 kWh electricity per kg dry biomass (range 25-60) = ~80 kWh per kg usable protein, system boundary electrolyzer + fermenter + downstream
    observed:  Downstream energy 40 kWh/kg dry biomass baseline
HIGH CF-004  document: review_plan.md Review 6/11; premortem.md FM1
    canonical: construction_spend_recommendation = EUR 4.0M released only at the Phase Two gate; if the deployment cost chain still fails, reduced Phase Three or Research Only (no numeric trigger set)
    observed:  <= EUR 14/kg (premortem) vs <=12/<=15 undefined (Review 11) vs failure > EUR 15 / Research Only > EUR 14 (Review 6)
MEDIUM CF-005  document: review_plan.md Review 3; premortem.md FM1
    canonical: scenario_a_thresholds = <=EUR 12/kg usable protein full cost, >=100 kg usable protein/day, >=95% uptime (proposed threshold)
    observed:  redesign to 50 kg/day unit fitting EUR 12/kg
MEDIUM CF-006  document: pitch.md
    canonical: scenario_thresholds_locking = locked and time-stamped at Month 9 (2027-07-09); immutable except by all parties' written agreement
    observed:  lock adoption thresholds (in Phase Three)
MEDIUM CF-007  document: self_audit.md
    canonical: gap_funding_open_decision = OPEN DECISION; scenario commitments signed Month 7 (2027-05-09), locked Month 9 (2027-07-09)
    observed:  written gap-funding decision by Month 1.5 (2026-11-24) / by Month 6 (2027-04-09)
MEDIUM CF-008  document: review_plan.md / self_audit.md / executive_summary.md Feedback
    canonical: strain_feasibility_report = Month 4 (2027-02-09): Strain Feasibility Report naming a primary and a legally clean backup strain (proposed threshold)
    observed:  Month 3 (2027-01-09) report; patent search at Month 0.5 (2026-10-24)
MEDIUM CF-009  document: review_plan.md; pitch.md; executive_summary.md
    canonical: phase1_kickoff_milestones = Month 1.5 (2026-11-24) KPI framework locked and panel chartered; Month 2 (2026-12-09) HAZOP report; Month 2.5 (2026-12-24) safety design basis
    observed:  Charter Month 1 (2026-11-09); KPI framework Month 2.5 (2026-12-24); Kenyan site signed Month 7 (2027-05-09)
MEDIUM CF-010  document: review_plan.md Review 11
    canonical: gate_panel_budget = EUR 0.30M over 5 years (Phase One share EUR 0.06M)
    observed:  EUR 96,000 exceeds EUR 0.30M; adjust to EUR 0.45–0.55M
MEDIUM CF-011  document: review_plan.md; self_audit.md
    canonical: fallback_strain_switch = Phase Three EUR 2-4M = 57-114% of EUR 3.5M technical reserve and 63-125% of ~EUR 3.2M free reserve
    observed:  57–114% of the EUR 3.2M free reserve for EUR 0.2–0.4M; 50–125% of EUR 3.2M for EUR 2–4M
MEDIUM CF-012  document: self_audit.md
    canonical: phase2_gate_criteria = Phase Two gate at Month 30 (2029-04-09): disproof thresholds, 16-week strain run, downstream train validated, composition/digestibility confirm category, defects 0/<=3/<=10
    observed:  full dossier by Month 50 (2030-12-09) as Phase Two gate criterion
```

### 1. Pitch asserts a credible EUR 12/kg path while the modeled full cost is EUR 19.93/kg (🔴 High)

- **pitch.md – Project Overview, Metrics for Success, Long-term Vision:** Pitch overview: "full safety certification and a credible path to EUR 12/kg production cost"; Economic metric: "Cost trajectory toward EUR 12/kg"; vision: three independent deployments within two years of release
- **canonical_facts deployment_chain_gap / gap_funding_open_decision; pitch.md – Risks section; project_plan.md – Achievable:** Modeled full cost EUR 19.93/kg vs EUR 12 cap (gap EUR 7.93/kg); gap-funding route is an OPEN DECISION; deployment-scale units are modeled only and not programme-funded; pitch's own risk section recommends Research Only if the gap persists
- **Why it conflicts:** A route to EUR 12/kg and certified safety are presented as established facts to funders, but the plan treats them as unproven (estimate, open decision). Predicting deployments also ignores that nobody has funded deployment units or the gap.
- **Suggested resolution:** Reword the pitch: current modeled full cost is EUR 19.93/kg (estimate); a route to the EUR 12 cap is a hypothesis to be tested, closable only by cost reduction or a funded gap route. Replace 'safety certification' with 'independently reviewed safety design'. Present the deployments as an aspiration, not an expectation.

### 2. Opex-only cost per kg presented as a rise in full cost from EUR 19.93/kg (🔴 High)

- **review_plan.md – Review 8 item 1, Review 10 item 3:** Review 8.1 / 10.3: opex rises to EUR 480–550k (484–550k) per year and 'cost per kg jumps from EUR 19.93/kg to EUR 13.8–15.8/kg', breaching all three scenario caps; electricity is '53% of opex'
- **canonical_facts deployment_opex, deployment_chain_gap:** EUR 401,920 opex = EUR 11.59/kg; full cost incl. annualized debt service is EUR 19.93/kg. Recomputed: EUR 480–550k opex = EUR 13.8–15.9/kg opex-only; tariff EUR 0.10–0.12/kWh gives opex ~EUR 457–513k, i.e. full cost ~EUR 21.5–23.1/kg. Electricity share is 221,920/401,920 = 55%
- **Why it conflicts:** Going 'from 19.93 to 13.8–15.8' is a cost decrease, and the 13.8–15.8 range is an opex-only figure, not full cost. It also does not breach Scenario C's EUR 15 cap in the way claimed. The opex range does not match the stated tariff range either, and 53% does not match 55%.
- **Suggested resolution:** Restate all sensitivities on one basis. Keep full cost (incl. annualized capex) as the headline comparison with scenario caps. Opex-only: EUR 11.59/kg base, EUR 13.2–14.8/kg at EUR 0.10–0.12/kWh. Full cost: ~EUR 21.5–23.1/kg. Use 55% for the electricity share.

### 3. System-level energy figure used as downstream-only energy (🔴 High)

- **review_plan.md Review 8.1, Review 3.2; premortem.md FM8:** Review 8.1 'Downstream energy 40 kWh/kg dry biomass (range 25–60)'; premortem FM8 'downstream energy rises above the 40 kWh/kg dry biomass baseline'; review 3.2 nucleic-acid reduction cut 'from 20 to 10–15 kWh/kg'
- **canonical_facts energy_per_kg; premortem.md tripwire 'downstream energy >= 30 kWh/kg usable protein':** 40 kWh/kg dry biomass (range 25–60) = ~80 kWh/kg usable protein is the system boundary electrolyzer + fermenter + downstream
- **Why it conflicts:** The 40 kWh/kg figure covers the whole system, yet it is labelled the downstream baseline. Downstream tripwires (30 kWh/kg usable protein) and levers (10–20 kWh/kg) use unspecified or mixed denominators (dry biomass vs usable protein). Tripwires can therefore trigger wrongly or never.
- **Suggested resolution:** Define downstream energy separately, with a stated boundary and a per-kg-dry-biomass and per-kg-usable-protein conversion (x2). Keep 40 kWh/kg dry biomass strictly as the total system value. Re-express the tripwires and levers on the same basis.

### 4. Hardware-release cost trigger and KPI cost bands lack an agreed basis (🔴 High) — needs a project decision

- **premortem.md FM1; executive_summary.md Feedback 4; review_plan.md Review 11 item 3:** Premortem FM1 / exec feedback / self-audit: release EUR 4.0M only if model predicts <= EUR 14/kg AND gap funding committed; Review 11.3 says the trigger is undefined (<=15, <=14 or <=12; 'release if cost >= 15' for Danish-only)
- **review_plan.md Review 6 KPI 1; canonical_facts scenario_a/b_thresholds, deployment_price_value:** Review 6 KPI 1: success <= EUR 12, corrective 12–15, failure > 15, yet 'failure to reach EUR 14/kg forces Research Only' and 'enables Scenario A or B'. Scenario A cap EUR 12 and Scenario B cap EUR 10 are full-cost caps; modeled opex alone is EUR 11.59/kg
- **Why it conflicts:** EUR 14 (Phase Two release trigger) is used as a Phase Three success target, and the failure band is 14 in one sentence and 15 in another. It is not stated whether a trigger is judged before or after a gap subsidy or capex grant. Scenario B's EUR 10 cap is below opex alone (EUR 11.59), so it cannot be met even with a full capex grant.
- **Suggested resolution:** Decision needed. Options: (a) trigger on unsubsidized full cost <= EUR 14/kg plus a written gap route; (b) trigger on post-subsidy full cost <= scenario cap; (c) hardware released for the Danish unit only. Keep Phase Three success tied to the locked scenario's own cap. Recheck whether Scenario B is realistic.

### 5. Proposed '50 kg/day redesign' conflicts with locked Scenario A minimum capacity (🟡 Medium) — needs a project decision

- **review_plan.md Review 3 item 2; premortem.md FM1:** Redesign deployment to a 50 kg/day unit 'fitting EUR 12/kg' (Review 3.2); premortem FM1 respond option '50 kg/day redesign'; modular scale test of 50/100/200 kg/day
- **canonical_facts scenario_a_thresholds, scenario_thresholds_locking:** Scenario A: <= EUR 12/kg AND >= 100 kg usable protein/day; thresholds are immutable except by all parties' written agreement; only Scenario C accepts >= 50 kg/day (cap EUR 15)
- **Why it conflicts:** A 50 kg/day unit does not meet Scenario A's capacity floor, so it cannot 'fit' the EUR 12 cap without changing the locked scenario. Smaller scale is also not shown to lower cost per kg.
- **Suggested resolution:** Decision needed: either drop the 50 kg/day route for Scenario A, or treat it as a formal threshold renegotiation requiring written agreement of all parties (published, panel re-advised). Alternatively target Scenario C (cap EUR 15, 50 kg/day).

### 6. Pitch locks adoption thresholds in Phase Three (🟡 Medium)

- **pitch.md – Project Phases and Timeline:** Phase Three: 'Commission two reference units..., conduct safety and fault testing, lock adoption thresholds and publish final open-source documentation'
- **canonical_facts scenario_thresholds_locking; pitch.md – Call to Action:** Scenarios locked and time-stamped at Month 9 (2027-07-09), before prototype evaluation, and immutable except by all parties' written agreement; Phase One call to action also says 'Lock deployment scenarios... at Month 9 (2027-07-09)'
- **Why it conflicts:** Thresholds fixed after the prototype is evaluated would breach the user's rule never to adjust them to match achieved performance. The pitch contradicts itself.
- **Suggested resolution:** Replace with 'evaluate against the locked adopter thresholds' in Phase Three; keep the Month 9 (2027-07-09) lock.

### 7. Deadline for the gap-funding decision (🟡 Medium)

- **self_audit.md items 3 and 4:** Self-audit item 3: assign owner and deliver written gap-funding decision by Month 1.5 (2026-11-24); self-audit item 4: funder decides in writing by Month 6 (2027-04-09)
- **executive_summary.md; premortem.md A2/FM1; review_plan.md Review 3, 15:** Gap-funding route locked by Month 7 (2027-05-09) (exec, review plan, premortem, self-audit items 6/7); cost-reduction study runs Months 1/3–6 (premortem A2, review 15); premortem tripwire: modeled cost >= EUR 15/kg at Month 6 (2027-04-09)
- **Why it conflicts:** A decision at Month 1.5 (2026-11-24) precedes the cost-reduction study it depends on. Month 6 (2027-04-09) vs Month 7 (2027-05-09) is also inconsistent for the same decision.
- **Suggested resolution:** Keep Month 7 (2027-05-09) as the decision deadline (before signed commitments at Month 7 = 2027-05-09 and the lock at Month 9 = 2027-07-09). Month 1.5 (2026-11-24) is the deadline to name an owner. Month 6 (2027-04-09) is the interim cost-path checkpoint only.

### 8. Strain Feasibility Report and patent search dates (🟡 Medium)

- **executive_summary.md Feedback 2; review_plan.md Review 1/3/7/13; self_audit.md items 5, 17; premortem.md A1:** Deliver the Strain Feasibility Report by Month 3 (2027-01-09) and commission the patent search at Month 0.5 (2026-10-24) (RFPs by Month 0.5 = 2026-10-24)
- **canonical_facts strain_feasibility_report, phase1_kickoff_milestones; project_plan.md; pitch.md:** Strain Feasibility Report at Month 4 (2027-02-09); patent search commissioned at Month 2 (2026-12-09) (pitch also Month 4 = 2027-02-09 and Month 2 = 2026-12-09); exec summary says Month 4 (2027-02-09) in Risks/Action but Month 3 (2027-01-09) in Feedback
- **Why it conflicts:** Two versions of the same milestone circulate (Month 3 = 2027-01-09 vs 4, patent search Month 0.5 = 2026-10-24 vs 2). Review 13 also calls Month 4 (2027-02-09) to the Month 12 (2027-10-09) decision an '8-week float', which is eight months. Premortem A1's failure trigger (Month 3.5 = 2027-01-24) falls before the canonical report date.
- **Suggested resolution:** Keep the canonical Month 4 (2027-02-09) report and Month 2 (2026-12-09) patent commissioning. If earlier delivery is wanted, make it an internal target (draft Month 3 = 2027-01-09) and update the canonical facts explicitly. Correct the float statement.

### 9. Kickoff and Kenya milestone dates deviate from canonical (🟡 Medium)

- **review_plan.md; pitch.md; executive_summary.md:** Gate Authority Charter signed by Month 1 (2026-11-09) (review plan 1, 3, 7); pitch: KPI framework locked at Month 2.5 (2026-12-24); exec: HAZOP and design basis both at Month 2.5 (2026-12-24); pitch: 'identify and sign Kenyan site and adopters by Month 7 (2027-05-09)'
- **canonical_facts phase1_kickoff_milestones, gate_panel_governance; premortem.md A5; review_plan.md Review 9:** Panel chartered and KPI framework locked at Month 1.5 (2026-11-24); HAZOP report Month 2 (2026-12-09), safety design basis Month 2.5 (2026-12-24); Kenyan partner agreement by Month 3 (2027-01-09) and Kenyan site baseline report at Month 4 (2027-02-09)
- **Why it conflicts:** The same milestones carry different months. A Kenyan site signed at Month 7 (2027-05-09) comes after the baseline report that needs it (Month 4 = 2027-02-09). A charter at Month 1 (2026-11-09) precedes panel recruitment at Month 1.5 (2026-11-24).
- **Suggested resolution:** Use canonical dates: charter and KPI framework Month 1.5 (2026-11-24); HAZOP Month 2 (2026-12-09); design basis and reactor rules Month 2.5 (2026-12-24). Kenyan partner and site by Month 3 (2027-01-09); only the adopter signatures at Month 7 (2027-05-09).

### 10. Gate-panel honorarium arithmetic (🟡 Medium)

- **review_plan.md Review 11 item 2:** Review 11.2: EUR 200 x 40 h x 4 members x 3 gates = EUR 96,000 'exceeds EUR 0.30M'; Phase One share EUR 0.06M leaves 'only EUR 15k'; recommends EUR 0.45–0.55M
- **canonical_facts gate_panel_budget; executive_summary.md; pitch.md:** Gate panel budget EUR 0.30M over 5 years, Phase One share EUR 0.06M (ring-fenced)
- **Why it conflicts:** EUR 96,000 is well below EUR 300,000, and the Phase One share is EUR 60,000, not 15k. The recommended increase to EUR 0.45–0.55M exceeds the canonical figure on a faulty basis.
- **Suggested resolution:** Recompute: EUR 96,000 of honoraria fits inside EUR 0.30M, with ~EUR 0.2M for chair, admin and a 50 h per gate preparation allowance. Keep EUR 0.30M unless a documented need arises.

### 11. Reserve-consumption percentages for fallback costs (🟡 Medium)

- **review_plan.md Review 1, 2; self_audit.md items 5 and 17:** Phase Two/post-gate strain switch (EUR 0.2–0.4M) 'consumes 50–125%' of the EUR 0.35M free Phase One contingency; or 57–114% of the EUR 3.2M free technical reserve; Phase Three EUR 2–4M = '57–125%' or '50–125%' of EUR 3.2M
- **canonical_facts fallback_strain_switch, programme_reserve_free_technical:** EUR 0.2–0.4M after the Phase One gate fits the reserve (6–12.5% of EUR 3.2M); Phase Three EUR 2–4M = 63–125% of the ~EUR 3.2M free reserve (57–114% of the EUR 3.5M technical part)
- **Why it conflicts:** Percentages are mixed across denominators. 0.2–0.4M is 57–114% of 0.35M, not of 3.2M. The Phase One contingency is not the funding source after the gate.
- **Suggested resolution:** Use canonical figures: post-gate switch 6–12.5% of free technical reserve; Phase Three switch 63–125% of the free reserve (57–114% of 3.5M) with the upper end unfundable.

### 12. Full regulatory dossier by Month 50 (2030-12-09) set as a Phase Two gate criterion (🟡 Medium)

- **self_audit.md items 14 and 16:** Add Phase Two gate criterion: if the full regulatory dossier cannot be completed by Month 50 (2030-12-09), recommend modified Phase Three or Research Only; also require written Kenyan product-pathway feasibility before hardware release
- **canonical_facts phase2_gate_criteria; project plan/user constraint:** Phase Two gate is at Month 30 (2029-04-09) with defined criteria (kLa, 16-week stability, downstream spec, composition, defects); full commercial authorization is not required for research success, only a credible pathway
- **Why it conflicts:** A Month 50 (2030-12-09) condition cannot be assessed at a Month 30 (2029-04-09) gate. Requiring a completed dossier goes beyond the 'credible regulatory pathway' standard.
- **Suggested resolution:** Replace with a Phase Two criterion of written authority feedback on the pathway and minimum safety-data package. Keep the dossier completion check out of the gates, or place it at the Phase Three gate as 'credible pathway' only.

## Summary

The plan is largely coherent on structure. Phase windows, gate dates, the EUR 50M allocation (5.5 + 13 + 22 + 4 + 5.5), the function split (40.5) and the deployment cost chain (opex 401,920; debt service ~289,000; gap 274,820/yr; EUR 19.93 vs EUR 12) all recompute correctly against the canonical facts. The inconsistencies sit in the downstream documents. They are: (1) the pitch presents a EUR 12/kg path as fact and moves the threshold lock into Phase Three; (2) the review plan mixes opex-only and full-cost per-kg figures, mislabels the system-level 40 kWh/kg as downstream energy, and contains percentage and honorarium arithmetic errors; (3) several kickoff and decision dates differ from the canonical values; (4) two decisions are missing: the basis of the hardware-release cost trigger, and how a smaller-capacity redesign can coexist with locked scenario thresholds. Most items are repairable text fixes. The two needs_decision items affect the gap-funding and hardware-release logic and should be settled before the Month 7 (2027-05-09) commitments.