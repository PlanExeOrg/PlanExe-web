### 1. Project Steering Committee

**Rationale for Inclusion:** This is an infrastructure-scale, multi-country, high-complexity R&D programme with five critical decision levers (reactor concept, strain rights, replication independence, threshold locking, safety design) and substantial technical, legal, financial and organizational risk. The Steering Committee provides strategic oversight, escalation authority and rapid decision-making for cross-functional issues that affect project direction, risk posture or gate readiness. It bridges the independent gate-review panel (external authority) with operational management and ensures alignment of technical, regulatory, financial and partnership decisions.

**Responsibilities:**

- Approve Phase One and Two work plans, budgets and gate criteria before execution begins
- Escalate and resolve conflicts between technical design choices and safety, regulatory, partnership or financial constraints
- Review quarterly cost-control reports and authorize spending from contingency reserves (technical contingency and currency fund)
- Approve all gate-extension requests and contingency activations; track impact on schedule and budget
- Monitor unsigned partner commitments, site access and permit status; trigger contingency plans if commitments slip
- Approve recruitment and dismissal of independent gate-review panel members; ensure funder-managed independence
- Approve changes to locked deployment scenarios or product-category choice, in writing with all stakeholder notification
- Address personnel, organizational or partnership issues that could affect team continuity or independence

**Initial Setup Actions:**

- Establish written charter specifying decision thresholds (e.g., contingency draw, schedule extension, scope change authority) and conflict-resolution process
- Confirm membership roles, accountability and meeting schedule (quarterly minimum, monthly as needed)
- Define escalation criteria and trigger conditions (e.g., cost variance >5%, schedule slip >3 weeks, safety finding, partner withdrawal)
- Establish procedure for publishing deviation from gate-review panel recommendations, with justification, to all stakeholders
- Secure separate budget line for gate-review panel operations, independent of project team spending authority
- Schedule first meeting by Month 0.5 (2026-10-24) to confirm charter, roles and initial action items

**Membership:**

- Project Lead (host institution, process or project engineer; chair)
- Funder Representative (budget authority, release decisions, contingency approval)
- Kenyan Partner Lead (co-development partner; partnership and site governance)
- Finance Manager (cost control, budget tracking, FX management, contingency oversight)
- Safety and Regulatory Lead (ATEX, hazard analysis, permitting and compliance risk)
- Independent Observer or External Advisor (optional; non-voting, ensuring transparency and identifying blind spots)

**Decision Rights:** Authority to make or escalate any decision affecting Phase One or Two work scope, budget (draws from contingency reserve up to thresholds per charter), personnel (project-direct staff, not host-institution staff), schedule (within the Month 60 = 2031-10-09 hard constraint and subject to gate approval), gate criteria and locked deployment scenarios. Authority does not extend to approval of individual scientific or engineering design choices (delegated to Project Management Office and technical working groups) or to unilateral override of gate-review panel recommendations (requires published justification). Decisions on spending >EUR 500,000 from contingency, schedule extensions >4 weeks, or changes to locked scenarios require documented consensus or majority vote with dissent published.

**Decision Mechanism:** Quarterly meetings with written agenda and pre-circulated materials 2 weeks in advance. Decisions by consensus where possible; if consensus cannot be reached, majority vote (>50% of voting members present, minimum 4 of 6 quorum) with dissenting views documented. For urgent escalations (e.g., safety incident, unexpected barrier), chair may convene ad hoc meeting with 48-hour notice. All decisions recorded in written minutes with rationale, options considered and any dissenting view. Tie-breaker: Project Lead holds deciding vote only if consensus and majority voting fail; all tie-breaker decisions published to steering committee members and the independent gate-review panel with justification.

**Meeting Cadence:** Quarterly steering committee meetings (Month 3, 6, 9, 12 = 2027-01-09, 2027-04-09, 2027-07-09, 2027-10-09 in Phase One; then Months 15, 18, 21, 24, 27, 30 = 2028-01-09, 2028-04-09, 2028-07-09, 2028-10-09, 2029-01-09, 2029-04-09 in Phase Two; then Months 36, 42, 48, 54 = 2029-10-09, 2030-04-09, 2030-10-09, 2031-04-09 in Phase Three). Additional monthly one-hour updates or teleconferences as needed during active gate-review periods (Months 9-12 = 2027-07-09 to 2027-10-09, 24-27, 48-54) or contingency-activation phases. Extended meetings (half-day) scheduled at each gate decision point (Month 10 = 2027-08-09 Phase One gate, Month 30 = 2029-04-09 Phase Two gate, Month 60 = 2031-10-09 Phase Three gate) to review evidence and approve gate-transition actions.

**Typical Agenda Items:**

- Financial and schedule progress against Phase plan (actual vs. forecast, variance trends, contingency draw status, FX impact)
- Risk and issue log review (safety incidents, regulatory feedback, partnership or access concerns, technical uncertainties)
- Gate-readiness assessment: evidence freeze status, panel briefing materials preparation, decision-path clarity for upcoming gate
- Personnel, staffing and organizational continuity (key departures, recruitment status, training completion)
- Partner and funder alignment: confirming commitment status, addressing unresolved dependencies, publishing transparency reports
- Deployment scenario and threshold status (any renegotiation requests from adopters, changes in regulatory guidance affecting scenarios)

**Escalation Path:** Issues not resolvable by consensus within the Steering Committee escalate to the Funder (via the Funder Representative), who holds final release authority and can invoke external mediation or expert review. Safety-related escalations go directly to the independent gate-review panel, which has authority to recommend project modification or stop. Partnership or organizational conflicts (e.g., host-institution priority shift affecting dedicated staff) escalate to the host-institution rector or executive director (via the Project Lead), with a written escalation document and 2-week resolution window; if unresolved, escalate to the Funder. Gate-review panel recommendations that conflict with Steering Committee preference are published transparently; the Funder makes the final release decision and publishes any deviation from panel advice.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** This complex programme requires rigorous day-to-day execution across multiple technical workstreams (reactor comparison, strain validation, safety analysis, regulatory engagement), two physical sites (Denmark and Kenya), multiple partners, a tight Phase One budget (EUR 6M ceiling) and a critical Phase One gate at Month 9 (2027-07-09). The PMO ensures consistent planning discipline, cost and schedule tracking, work-package completion, and readiness for each gate. It also manages operational risk (equipment procurement, facility setup, team coordination) and coordinates the independent gate-review panel's information needs. Without tight PMO discipline, the EUR 50M programme could drift early through scope creep or slow mobilization, consuming the 3-month Phase One float.

**Responsibilities:**

- Maintain Phase One and Two detailed work schedules with critical path, resource allocation and dependency tracking; update weekly and report monthly to Steering Committee
- Track Phase One spending by work package against EUR 5.5M planned and EUR 6M ceiling; monthly cost-control report reconciling actual invoices against approved allocations; flag variance >10% in any cost category or >5% cumulative
- Manage procurement for laboratory equipment, bioreactors, analytical instruments and facility setup; track lead times, contracts, delivery status and risk of schedule impact
- Coordinate with host-institution facilities, Danish partner technical staff and Kenyan co-development partner on site access, utilities, equipment installation and training schedules
- Manage Phase One work packages: landscape review (Month 0-3 = 2026-10-09 to 2027-01-09), bench experiments (Month 1-9 = 2026-11-09 to 2027-07-09), HAZOP and safety analysis (Month 1-4 = 2026-11-09 to 2027-02-09), regulatory engagement (Month 0-4 = 2026-10-09 to 2027-02-09), Kenyan site baseline study (Month 1-4 = 2026-11-09 to 2027-02-09), adopter engagement (Month 2-7 = 2026-12-09 to 2027-05-09), gate-panel chartering (Month 0-1 = 2026-10-09 to 2026-11-09.5)
- Prepare gate-panel briefing materials (technical reports, raw data, analysis methods, measurement frameworks, decision criteria) 4-6 weeks before each gate meeting
- Maintain defect-tracking systems: audited assistance log (Kenyan replication), documentation-defect log (Phase Two onwards), regulatory-feedback log, strain-rights and patent-freedom-to-operate tracking
- Coordinate with the independent gate-review panel: schedule meetings, provide secure document-sharing access, handle confidential correspondence, publish final panel recommendations and funder responses

**Initial Setup Actions:**

- By Month 0.5 (2026-10-24): establish detailed Phase One work schedule (Gantt chart) with 100+ work packages, assigned owners, dependencies and critical path; lock all deadlines tied to the Month 9 (2027-07-09) evidence freeze
- By Month 0.5 (2026-10-24): establish cost-tracking procedure (invoicing, cost categories, contingency reserve tracking, currency conversion at locked baseline rate); set up monthly cost-control reporting template and dashboard
- By Month 1 (2026-11-09): procure all long-lead-time equipment (bioreactors, electrolyzers, analytical instruments) with contracts specifying delivery by Month 3-4 (2027-01-09 to 2027-02-09)
- By Month 1 (2026-11-09): establish measurable KPI framework locked in writing (volumetric productivity definition, energy per kg formula, system boundary, capacity-utilization assumption, measurement methods per instrument)
- By Month 1.5 (2026-11-24): establish and lock measurement and disproof-experiment protocols for reactor comparison (pre-registered decision thresholds, analytical methods, success criteria)
- By Month 2 (2026-12-09): establish defect-tracking systems (issue tracker or shared database) for documentation gaps, assistance log auditing, regulatory feedback and strain-rights tracking; assign auditor contacts

**Membership:**

- PMO Director or Programme Manager (overall PMO accountability, Steering Committee interface)
- Phase One Work-Package Owner (Phase One schedule, cost tracking, workstream coordination)
- Cost Controller or Finance Coordinator (monthly cost-control reports, contingency-reserve tracking, invoicing)
- Procurement Manager (equipment lead times, contracts, supplier management)
- Gate-Panel Administrator (panel scheduling, document repository, confidential correspondence, publication of recommendations)
- Technical Coordinator or Data Manager (measurement framework, defect-tracking system administration, KPI reporting)

**Decision Rights:** PMO has authority to manage work-package planning, schedule, procurement and cost-tracking decisions within the approved Phase One plan and budget allocations. PMO can authorize work-package-level changes (e.g., shifting tasks between months, re-allocating within a cost category) if total cost and critical-path schedule are unaffected. PMO cannot approve spending from contingency reserves (escalates to Steering Committee if variance triggers contingency draw). PMO cannot change locked deliverables, measurement frameworks, disproof thresholds or gate criteria (escalates to Steering Committee if change is justified). PMO provides recommendations to Steering Committee on cost-control or schedule-risk mitigation, but Steering Committee retains approval authority.

**Decision Mechanism:** Weekly PMO coordination meetings (30-60 min) with Phase One workstream leads and cost controller; written action-item tracker maintained. Monthly cost-control report generated by 5th working day of month; if variance >10% in a category, root-cause analysis and mitigation plan required. Procurement decisions made by PMO Director and Procurement Manager based on pre-approved contracts and cost authority. Gate-panel administration handled by Gate-Panel Administrator with written scheduling confirmation and document-access verification. Escalations to Steering Committee documented in writing with decision recommendation and rationale.

**Meeting Cadence:** Weekly PMO coordination (Monday, 60 min, standing meeting); monthly cost-control review (1st week of each month, 60 min); monthly gate-readiness check-in (4th week of each month, starting Month 7 = 2027-05-09, focusing on evidence freeze and panel-briefing material preparation). Increased frequency (biweekly or ad hoc) during critical periods (Months 0-3 = 2026-10-09 to 2027-01-09 for initial setup, Months 8-12 = 2027-06-09 to 2027-10-09 for Phase One gate preparation).

**Typical Agenda Items:**

- Work-package status by phase and owner (on track, at risk, delayed); critical-path items; dependencies blocking other work
- Monthly cost-control: actual vs. forecast by category, cumulative variance, contingency-draw requests and approvals, currency-conversion status
- Procurement and equipment delivery status (long-lead items, contract negotiations, site-access constraints, installation schedule)
- Schedule risk and mitigation: any threats to evidence freeze deadlines (Month 9 = 2027-07-09, Month 21 = 2028-07-09, Month 57 = 2031-07-09); proposed float usage or timeline adjustments
- Gate-readiness: briefing-material drafts due, panel-communication status, decision-criteria clarity for upcoming gate

**Escalation Path:** Work-package delays or cost overruns exceeding thresholds (>2 weeks schedule slip, >10% cost variance in a category) escalate to Steering Committee for contingency or schedule decision. Safety-related findings (e.g., HAZOP results requiring design rework) escalate directly to Safety and Regulatory Lead (Steering Committee member) and independent gate-review panel. Procurement risks (e.g., critical equipment delivery at risk) escalate to Steering Committee if mitigation cannot be completed within the phase schedule. Disputes over work-package scope or resource allocation escalate to the Project Lead (Steering Committee chair) for mediation.
### 3. Technical Working Group: Reactor Concept and Scale-Up

**Rationale for Inclusion:** Gas-liquid contacting and reactor concept is the first critical decision lever and directly determines hydrogen transfer rate, volumetric productivity, explosion hazard, ATEX burden, repair skill and energy per kilogram. The plan requires matched bench-scale comparison of three concepts (pneumatic, pressurized stirred, passive-feed) using identical strain, media and measurement framework, with pre-registered failure thresholds. This technical group manages the experiments, measurement rigor and decision logic. It also designs and oversees the scale-up evidence ladder (bench to pilot to reference unit) with pre-registered disproof experiments. Without a dedicated technical group focused on measurement rigor and pre-registration discipline, post-hoc rationalization of results and selection bias toward a favored concept could undermine the comparisons and compromise the Phase Two gate.

**Responsibilities:**

- Define measurement and KPI framework before bench experiments begin: locked definitions for volumetric productivity, mass-transfer coefficient (kLa), energy per kg, system boundary, capacity-utilization assumption, measurement methods per analytical instrument; consistent use across all reactor concepts
- Pre-register reactor-concept comparison decision rules before Phase One experiments: e.g., 'If productivity gap <15% between concepts, choose simpler; 15-25% use weighted scoring; >25% choose highest unless ATEX is blocked'
- Conduct triplicate matched bench-scale experiments (pneumatic, stirred, passive-feed) on identical C. necator strain and media; assign single lead analyst to minimize inter-analyst variation
- Perform external audit of measurement framework and data analysis before Phase One gate (independent technical reviewer verifies protocol was followed, outliers handled consistently, decision thresholds applied)
- Document all deviations from protocol, analytical variation, and uncertainty ranges in results; publish raw data and analysis methods in supplementary material
- Establish pre-registered disproof experiments for Phase Two scale-up (bench to pilot scale): e.g., mass-transfer coefficient decline <25%, volumetric productivity within 15% of bench, strain stability <10% drift over 10-16 week run
- Conduct long-term strain-stability validation in Phase Two (10-16 week culture at intended operating conditions with weekly sampling for growth rate, nucleic-acid content, viability)
- Manage scale-up evidence ladder: intermediate-scale experiments, validated engineering models with stated uncertainty, and critical-assumption testing; gate release of reference-unit hardware (EUR 4.0M) only at Phase Two gate if disproof thresholds are met
- Coordinate with Safety and Regulatory Working Group on hazard-analysis implications of each reactor concept; publish safety-gap analysis (e.g., pressure rating, seal requirements, ignition exposure)

**Initial Setup Actions:**

- Month 0-1 (2026-10-09 to 2026-11-09): Establish written KPI Framework and Measurement Protocol document, locked and signed by lead analysts, project manager and an external technical auditor; specify all definitions, system boundaries, analytical methods and success thresholds
- Month 1 (2026-11-09): Pre-register Reactor Concept Comparison Protocol with decision rules, success thresholds (e.g., <15% productivity gap = simplicity wins), analytical-variation tolerance and exclusion criteria; publish to Steering Committee and gate-review panel for feedback before experiments begin
- Month 1 (2026-11-09): Recruit external technical auditor (independent of project team) to perform pre-Phase-One-gate audit of measurement framework and data analysis; confirm auditor's availability and timeline
- Month 2 (2026-12-09): Finalize analytical equipment setup (HPLC, gas chromatograph, bioreactor sensors) and calibration; run test samples on all three reactors to confirm analytical consistency
- Month 3 (2027-01-09): Initiate bench-scale experiments (3 reactor concepts x 3 replicates = 9 cultures); confirm inoculation source, medium composition and baseline parameters are identical across all cultures

**Membership:**

- Reactor Concept Lead or Principal Investigator (overall technical direction, decision-making on reactor selection)
- Bench-Scale Experimental Lead (day-to-day experiment management, culture maintenance, sampling)
- Gas-Transfer and Fermentation Specialist (mass-transfer coefficient measurement, gas-balance analysis, productivity calculations)
- Process Safety Engineer (hazard implications of each reactor concept, ATEX compliance assessment)
- Scale-Up and Modeling Engineer (disproof-experiment design, scale-up models, pilot-scale and reference-unit design)
- Data Manager or Analytical Coordinator (HPLC, GC, bioreactor software, data processing, uncertainty quantification)

**Decision Rights:** Group decides: final KPI definitions and measurement protocols (locked before experiments); reactor-concept comparison decision rules and success thresholds (pre-registered and published); analytical methods and data-quality criteria; interpretation of results and flagging of outliers or protocol deviations; recommendation to Steering Committee on reactor selection. Group cannot unilaterally change the locked measurement framework or disproof thresholds after experiments begin; any proposed change requires documented justification and approval from Steering Committee and independent technical auditor. Group does not decide on funding allocation or gate criteria (those are Steering Committee decisions), but provides technical evidence and recommendations to inform those decisions.

**Decision Mechanism:** Weekly technical meetings (60-90 min) with all workstream members to review experimental progress, address analytical issues and track against schedule. Pre-experiment meeting to confirm protocol alignment and baseline parameter checks. Mid-run review (Week 3-4 of each culture) to confirm steady-state and assess productivity trends. Post-experiment analysis meeting to review raw data, apply decision rules and document results. External auditor review scheduled for Month 9 (2027-07-09) before Phase One gate evidence freeze. Decisions on protocol interpretation or threshold application made by consensus; if disagreement arises, documented and escalated to Steering Committee with evidence and rationale from each perspective.

**Meeting Cadence:** Weekly technical working group meetings (Mondays, 90 min) during active bench-scale work (Months 1-9 = 2026-11-09 to 2027-07-09 in Phase One); biweekly or as-needed during Phase Two scale-up experiments (Months 12-24 = 2027-10-09 to 2028-10-09). Additional monthly technical reviews with Steering Committee starting Month 7 (2027-05-09) for gate-readiness updates.

**Typical Agenda Items:**

- Culture status: viability, contamination checks, growth rate, oxygen-uptake rate measurements; any deviations from protocol
- Analytical results (HPLC, GC): data quality, calibration status, any re-runs or outliers; comparison of results across the three reactor concepts
- Preliminary productivity and energy calculations; gap analysis vs. pre-registered success thresholds
- Safety and regulatory implications of each reactor concept (pressure, seal stress, flammable-range exposure)
- Scale-up disproof-experiment design (bench to pilot scale); assumptions being tested and pre-registered failure thresholds
- Documentation and publication planning (raw data, analysis methods, uncertainty ranges, supplementary material for external audit)

**Escalation Path:** Technical disagreements over measurement interpretation or threshold application escalate to the independent technical auditor (Month 9 = 2027-07-09) for binding review. If audit identifies protocol deviations or analytical-variation issues that invalidate results, escalate to Steering Committee for decision: re-run experiments or accept uncertainty and proceed with caveats. Safety findings that suggest a reactor concept poses unacceptable hazard escalate to Safety and Regulatory Working Group and then Steering Committee. Results suggesting all three reactor concepts fail the pre-registered thresholds escalate to Steering Committee with recommendation: accept higher productivity loss from simplification, re-define the thresholds (with external audit), or escalate to gate-review panel for pathway advice.
### 4. Technical Working Group: Safety, ATEX and Hazard Analysis

**Rationale for Inclusion:** Hydrogen-oxygen explosion hazard is the core technical safety risk and the fifth critical decision lever (Inherent Safety Design Basis and Adopter Change Boundary). The plan requires formal Process Hazard Analysis (HAZOP or LOPA), ATEX-compliant design, independently reviewed interlocks and emergency shutdown, and definition of which components and parameters adopters may change without full safety reassessment. A dedicated safety working group conducts and documents the hazard analysis early (Month 1-4 = 2026-11-09 to 2027-02-09), engages an independent ATEX consultant for review, and maintains the 'Adopter Change Boundary' document that controls what replicators can safely modify. Without early, rigorous hazard analysis, late discovery of a design flaw could force re-certification, schedule delay or project stop.

**Responsibilities:**

- Conduct formal Process Hazard Analysis (HAZOP or LOPA) covering electrolyzer, gas lines, fermentor headspace and control systems; identify all failure modes (seal rupture, electrolyzer malfunction, backflow, overpressure, operator error) by severity and likelihood
- Develop and document the safety design basis: selection of inherent limits (flammable-range composition, minimal gas inventory) or layered instrumented protection (interlocks, sensors, independent emergency shutdown); define quantitative safety target (e.g., probability of uncontrolled ignition <1 per 100,000 operating hours)
- Specify design response for each failure mode: eliminate hazard, reduce likelihood through design, or protect via layered control
- Engage an independent third-party ATEX consultant (not project staff, not host institution) to review interlock logic, emergency-shutdown design and control-system failure assumptions; obtain written sign-off before pressurized builds or high-gas-inventory configurations are committed
- Define and publish the Adopter Change Boundary: a short list of pre-assessed components and parameters that adopters may substitute or modify without re-certification (e.g., electrode material, medium pH limits within documented range), and which require full safety re-analysis (pressure rating, interlock logic, emergency-shutdown system)
- Create a machine-readable safety case or parametric model (if feasible) in which adopters can check proposed modifications against the hazard analysis; publish per-jurisdiction patent restrictions and safe-change envelopes
- Design and test the safety design on a small-scale mockup (e.g., 1-5 L) before committing to the 20 L reference unit; validate all interlocks, emergency shutdown and gas-composition control experimentally
- Maintain a safety-incident log; document any near-miss, actual incident or anomaly during Phase One, Two and Three operation; investigate root cause and implement corrective action
- Prepare safety chapters for the Phase One gate report (HAZOP findings closed, safety design basis rationale, ATEX consultant sign-off, Adopter Change Boundary v0.1)
- Update safety design basis iteratively as reactor concept selection and scale-up tests provide new data (pressure rating, seal-stress analysis, control-system complexity)

**Initial Setup Actions:**

- Month 0.5 (2026-10-24): Identify and contract an independent ATEX and process-safety consultant (external firm or specialist, not affiliated with host institution); scope HAZOP facilitation, independent interlock review and sign-off
- Month 1 (2026-11-09): Convene HAZOP team (process engineer, safety engineer, ATEX consultant, bioreactor specialist); establish HAZOP scope (electrolyzer to fermentor headspace to off-gas), guidewords and node structure
- Month 1-2 (2026-11-09 to 2026-12-09): Conduct formal HAZOP or LOPA sessions, documented in writing; identify and rank failure modes by severity (S: catastrophic, major, minor, negligible) and likelihood (L: frequent, occasional, rare, remote); develop risk matrix (S x L) and assess acceptability
- Month 2 (2026-12-09): Draft Safety Design Basis document outlining choice of inherent vs. instrumented protection, quantitative safety target, design response to each failure mode, and preliminary Adopter Change Boundary
- Month 2-3 (2026-12-09 to 2027-01-09): Independent ATEX consultant reviews Safety Design Basis, interlock logic (draft), control-system assumptions and compliance pathway; provides written feedback and sign-off on feasibility
- Month 3 (2027-01-09): Publish Adopter Change Boundary v0.1 as part of blueprint v0.1; specify which components/parameters adopters may change without re-assessment and which require full analysis

**Membership:**

- Safety and Regulatory Lead or Safety Engineer (group lead, HAZOP coordination, design-basis documentation)
- Process Safety Specialist or HAZOP Facilitator (HAZOP facilitation, risk-matrix development, failure-mode ranking)
- Independent ATEX Consultant or Third-Party Safety Reviewer (external, unaffiliated; interlock review, compliance assessment, sign-off)
- Reactor and Fermentation Specialist (process design details, gas-handling constraints, operational control logic)
- Control Systems and Automation Engineer (interlock design, emergency-shutdown logic, PLC/hardwired architecture, sensor redundancy)

**Decision Rights:** Group decides: HAZOP scope and structure; severity/likelihood rankings and risk matrix; design response to each failure mode; choice of inherent limits vs. instrumented protection; quantitative safety targets; Adopter Change Boundary (pre-assessed substitutes and parameter ranges); control-system architecture and interlock logic. Group cannot approve the final safety design without independent ATEX consultant sign-off. Group provides recommendations to Steering Committee on design trade-offs (e.g., safety margin vs. productivity); Steering Committee approves the Safety Design Basis as a project constraint. Any change to the Adopter Change Boundary after the Phase One gate requires independent review and Steering Committee approval.

**Decision Mechanism:** Monthly safety working group meetings (90 min) with all members to review HAZOP progress, control-system design and independent consultant feedback. HAZOP sessions conducted in facilitated workshops (typically 2-3 full-day sessions) with documented outputs (hazard register, risk matrix, design-response matrix). Independent consultant review scheduled for Month 2-3 (2026-12-09 to 2027-01-09), with formal written feedback and sign-off letter. Decisions on hazard severity, design response or control-system configuration made by consensus; if disagreement arises, documented with options and escalated to independent consultant for advisory judgment. Final Safety Design Basis approved by consensus of group + independent consultant + Steering Committee.

**Meeting Cadence:** Monthly safety working group meetings (60-90 min) during hazard-analysis phase (Months 1-4 = 2026-11-09 to 2027-02-09); weekly meetings during control-system design and interlock validation (Months 3-5 = 2027-01-09 to 2027-03-09). Formal HAZOP workshops scheduled for Month 1-2 (2026-11-09 to 2026-12-09) (typically 3-4 separate half-day or full-day sessions spread over 2-3 weeks). Independent consultant engagement and sign-off by end of Month 3 (2027-01-09). Thereafter, monthly reviews of any design changes or incident investigations (Months 6 onwards). Escalated agenda time at Steering Committee meetings (quarterly) for safety-status updates and any issues requiring Steering Committee decision.

**Typical Agenda Items:**

- HAZOP progress: guidewords reviewed, nodes assessed, failure modes identified, severity/likelihood assigned
- Risk-matrix results: high-risk failure modes and proposed design responses
- Control-system and interlock design: logic flow, sensor redundancy, emergency-shutdown sequence, validation approach
- Independent consultant feedback: comments on design basis, compliance pathway clarification, questions for project team
- Adopter Change Boundary: candidate substitutes for components, parametric ranges for safe operation, documentation of rationale

**Escalation Path:** If HAZOP identifies a failure mode of unacceptable risk (rank: Catastrophic + Frequent, or Major + Occasional), escalate to Steering Committee for design decision: eliminate hazard, invest in more-complex protection, or reduce the hazard to acceptable risk. If independent ATEX consultant identifies a compliance barrier (e.g., proposed design does not meet ATEX Directive requirements), escalate to Steering Committee with consultant's recommended mitigation. If during Phase Two or Three testing a safety anomaly is discovered (near-miss or incident), conduct root-cause investigation and escalate findings + corrective action to the independent gate-review panel for assessment of design adequacy. Any proposed change to Adopter Change Boundary after Phase One gate escalates to independent consultant and Steering Committee for approval.
### 5. Technical Working Group: Strain Rights, Regulatory Pathway and Intellectual Property

**Rationale for Inclusion:** Strain rights and regulatory classification is the second critical decision lever. The plan requires a reference strain lawfully obtainable for research, commercial production, redistribution and modification in both Denmark and Kenya; confirmation of Kenyan biosafety import feasibility; a patent-freedom-to-operate landscape review; and a credible regulatory pathway for the chosen product category. These activities must be completed early (by Month 4 = 2027-02-09) to avoid Phase One delays, yet they require legal expertise and regulator contact that cannot be rushed. A dedicated regulatory and IP working group ensures consistent tracking of strain rights, regulatory feedback and IP restrictions, and prevents mischaracterization of non-binding regulator guidance as 'approval' to Steering Committee or adopters.

**Responsibilities:**

- Conduct comprehensive strain-rights analysis for primary and backup reference strains: contact strain holders, confirm rights for research use, commercial production, redistribution, modification and derived strains; document all restrictions in writing
- Conduct patent and freedom-to-operate landscape review covering: hydrogen fermentation, autotrophic protein production, single-cell protein, the specific reference strain, and any existing patents or pending claims in Denmark, EU, Kenya and Bangladesh; identify IP risks and mitigation options (design-around, license, patent pledge, publication barrier)
- Confirm lawful strain import into Kenya: contact Kenya National Biosafety Authority and strain holder to verify any import restrictions, permits or material-transfer-agreement terms; document feasibility and timeline
- Engage with Danish/EU and Kenyan regulatory bodies via informal pre-submission dialogue to identify hard requirements for: contained-use authorization, biosafety classification of the organism, product safety and classification (animal feed, food ingredient, emergency nutrition), distribution pathway, and timeline for approval
- Log all regulatory feedback in writing (email, meeting minutes) with date and source; distinguish non-binding preliminary guidance from binding requirements; flag any authority requests for additional data or formal applications
- Select and lock the provisional product category at the Phase One gate based on regulatory pathway feasibility and preliminary composition data; document regulatory requirements for that category and timeline to full authorization
- Develop freedom-to-operate summary per jurisdiction: published one-page summary stating: (1) what is licensed under what terms; (2) identified IP restrictions and implications; (3) what adopters can and cannot do commercially without additional licensing
- Establish steward-entity governance: design the legal entity that will hold and enforce open licences, manage patent pledges and prevent closed forks; ensure it is independent of the host institution and can operate long-term with sustainable funding
- Prepare regulatory chapters for Phase One gate report (Strain Feasibility Report with primary and backup strains, patent landscape summary, regulatory pathways, product-category recommendation)

**Initial Setup Actions:**

- Month 0.5 (2026-10-24): Contract independent legal counsel (patent specialist and regulatory consultant) to conduct landscape review and strain-rights analysis; define scope covering Denmark, EU, Kenya and Bangladesh; establish timeline for Phase One completion
- Month 1 (2026-11-09): Identify 4-5 candidate reference strains (prioritize public-collection strains such as C. necator H16, ATCC, DSMZ); compile list of strain holders and contact information
- Month 1 (2026-11-09): Initiate direct contact with strain holders via email/phone: request documented confirmation of rights for research, commercial production, redistribution, modification and derived strains; any material-transfer-agreement terms; Kenyan import restrictions
- Month 1-2 (2026-11-09 to 2026-12-09): Engage patent specialist to conduct freedom-to-operate search in patent databases (USPTO, EPO, WIPO, Kenya patent office); compile list of relevant patents, publication dates, claims and jurisdiction coverage
- Month 2 (2026-12-09): Send formal inquiry to Kenya's National Biosafety Authority: describe the proposed contained-use process, strain candidates and operating envelope; request preliminary written feedback on import restrictions, biosafety classification and contained-use authorization pathway
- Month 2 (2026-12-09): Initiate informal pre-submission consultation with Danish Environmental Protection Agency or competent EU authority: describe proposed process, strain, operating envelope and candidate product categories; request written guidance on hard requirements per category

**Membership:**

- Regulatory Lead or Regulatory Affairs Manager (group coordination, authority liaison, regulatory strategy)
- Independent Legal Counsel – Patent Specialist (freedom-to-operate search, patent landscape interpretation, licensing terms)
- Independent Legal Counsel – Regulatory Specialist (jurisdictional requirements, product-safety pathways, contained-use classification)
- Intellectual Property Coordinator (IP-restriction tracking, licensing terms summary, steward-entity design)
- Microbiologist or Operations Lead (strain characteristics, biosafety concerns, technical questions for authorities)

**Decision Rights:** Group decides: selection of primary and backup reference strains with documented rights confirmation; interpretation of patent landscape (which patents are blocking and which are design-around-able); identification of regulatory-pathway requirements per product category; recommendation for provisional product-category selection; steward-entity governance structure. Group cannot approve the final Strain Feasibility Report without sign-off from legal counsel on IP and strain-rights accuracy. Group provides recommendations to Steering Committee on regulatory risk (e.g., pathway approval timeline, data requirements); Steering Committee approves product-category selection and regulatory strategy. Any change to the locked product category after the Phase One gate requires independent regulatory review and full re-assessment of data requirements.

**Decision Mechanism:** Bi-weekly regulatory working group meetings (60 min) to track strain-holder responses, patent search progress and regulatory feedback. Conference calls with legal counsel (monthly or as needed) to discuss findings and next steps. Formal written Strain Feasibility Report drafted by Month 3 (2027-01-09) and reviewed by independent legal counsel for accuracy and completeness. Regulatory feedback log maintained in shared spreadsheet (updated weekly) with columns: authority, date, topic, feedback summary, binding or preliminary status, implications, project response. Decisions on strain-rights interpretation, patent-risk assessment or regulatory-pathway selection made by consensus of group + legal counsel; any disagreement documented with perspectives and escalated to Steering Committee for final judgment.

**Meeting Cadence:** Bi-weekly regulatory working group meetings (60 min) during Months 1-4 (2026-11-09 to 2027-02-09); monthly thereafter. Formal legal-counsel review meetings scheduled for Month 2 (2026-12-09) and Month 3 (2027-01-09). Strain Feasibility Report finalized and signed by Month 4 (2027-02-09). Thereafter, monthly monitoring of regulatory guidance changes and log updates (Months 5 onwards).

**Typical Agenda Items:**

- Strain-holder responses: received confirmations, pending replies, any restrictions identified
- Patent search progress: patents identified, relevant claims, jurisdiction coverage, freedom-to-operate assessment
- Regulatory feedback: communications from Danish/EU/Kenyan authorities, preliminary guidance vs. binding requirements, timeline for formal applications
- Strain-rights and IP-restriction summary for Strain Feasibility Report
- Product-category recommendation: regulatory pathway, approval timeline, data requirements per category

**Escalation Path:** If strain-holder imposes restrictions blocking commercial production or Kenyan import, escalate to Steering Committee immediately: activate backup-strain pathway and adjust timeline. If patent search identifies a blocking patent in Kenya or Denmark, escalate to Steering Committee with legal counsel for options: design-around, license negotiation, or patent challenge. If Kenyan biosafety authority indicates contained-use authorization is unlikely, escalate to Steering Committee: assess whether to proceed with alternative site or product category. If regulatory feedback conflicts with other project assumptions (e.g., authority recommends a product category different from current plan), escalate to Steering Committee with full context and implications for scale-up and deployment thresholds. Any misrepresentation of regulatory status (e.g., preliminary feedback characterized as approval) is flagged immediately to Steering Committee and independent gate-review panel as a governance or integrity risk.
### 6. Technical Working Group: Deployment Scenarios, Thresholds and Adopter Engagement

**Rationale for Inclusion:** Deployment Scenario Anchoring and Threshold Locking is the fourth critical decision lever. The plan requires 2-3 named prospective adopters, locked cost/capacity/reliability thresholds fixed before prototype evaluation, and published decisions at each gate that clearly pass or fail against these locked thresholds. This working group identifies and engages prospective adopters during Phase One (Months 2-7 = 2026-12-09 to 2027-05-09), conducts structured interviews on deployment constraints and cost tolerance, consolidates scenarios and locks them in writing by Month 9 (2027-07-09). Without this group, scenarios remain hypothetical, thresholds are adjusted post-hoc to fit results, and the final Go/Modify/Stop decision loses credibility. The group also tracks any adopter withdrawal or renegotiation and escalates to Steering Committee and gate-review panel.

**Responsibilities:**

- Identify 2-3 prospective adopters representing realistic deployment contexts (e.g., national food-security reserve agency, regional feed producer, humanitarian logistics organization); prioritize organizations with publicly stated mandates in food security or agriculture and decision-making authority over budget
- Conduct structured engagement with each adopter: in-person meetings covering current supply chains and costs, production-capacity needs, acceptable cost premium for vendor-independent solution, operational constraints (power reliability, water quality, technical skills, space), timeline expectations
- Validate adopter input by presenting scenario profiles and cost/capacity/reliability thresholds back to them; obtain feedback and refine scenarios iteratively
- Consolidate adopter input into 2-3 formalized deployment scenarios with locked thresholds: maximum production cost per kg usable protein, minimum useful capacity, required uptime and outage-survival duration; document rationale and data sources
- Obtain signed commitment from each adopter by Month 7 (2027-05-09), specifying: scenarios remain locked through Phase Three gate unless all parties formally agree to renegotiate; adopter withdrawal triggers public disclosure of reason; thresholds are used to evaluate Go/Modify/Stop decisions
- Lock scenarios in time-stamped document at Phase One gate (Month 9 = 2027-07-09); publish to all stakeholders, Steering Committee, gate-review panel and funder
- Monitor adopter status quarterly: flag any signals of withdrawal or renegotiation; report to Steering Committee and publish any formal withdrawals with stated reason
- Track regulatory, market and competitive changes affecting adopter interest (e.g., new policy on alternative proteins, competitor technology progress); assess impact on scenario credibility and recommend Steering Committee action if needed
- Prepare scenarios and thresholds chapters for Phase One gate report; include adopter interview summaries, scenario profiles, locked thresholds, and signed adopter commitments

**Initial Setup Actions:**

- Month 1-2 (2026-11-09 to 2026-12-09): Conduct landscape research on prospective adopter profiles (national reserves, feed producers, humanitarian organizations, regional agricultural agencies); identify 5-8 candidates with stated mandates in food security or livestock
- Month 2 (2026-12-09): Initiate outreach to 2-3 leading candidates; request in-person meetings or calls to explore project interest and data-gathering willingness
- Month 2-3 (2026-12-09 to 2027-01-09): Develop structured interview guide covering: current protein supply chain and cost, capacity needs, cost tolerance for new/alternative sources, operational constraints, timeline and decision-making process
- Month 3-4 (2027-01-09 to 2027-02-09): Conduct in-person or virtual interviews with each adopter; document responses in write-ups; develop preliminary scenario profiles

**Membership:**

- Adopter Engagement Lead or Deployment Strategy Manager (overall engagement, adopter relationship management)
- Techno-Economic Analyst or Cost-Model Lead (scenario cost and capacity assumptions, sensitivity analysis, threshold feasibility)
- Adoption Specialist or Social Science Researcher (adopter motivation, constraint validation, market-landscape analysis)
- Project Lead or Steering Committee Representative (governance liaison, escalation oversight)

**Decision Rights:** Group decides: selection and ranking of prospective adopters; scenario profiles (cost, capacity, uptime thresholds); threshold recommendations based on adopter input and cost-model sensitivity analysis. Steering Committee approves final locked scenarios and obtains adopter sign-off. Group cannot unilaterally adjust thresholds after Month 9 (2027-07-09); any renegotiation requires Steering Committee approval and all-party written agreement. Group recommends to Steering Committee how to handle adopter withdrawal or scenario-credibility threats.

**Decision Mechanism:** Monthly adoption working group meetings (60 min) during Phase One to coordinate interviews, discuss adopter feedback and refine scenarios. Adopter interviews conducted by 2-3 team members (interviewer + note-taker) to ensure accuracy and consistency. Interview summaries drafted and reviewed by group before next adopter meeting to identify convergent themes. Scenario profiles developed iteratively and validated with adopters via follow-up calls or meetings. Final locked scenarios approved by consensus of group + Steering Committee + all adopter signatories.

**Meeting Cadence:** Monthly adoption working group meetings (60 min) during Months 2-7 (2026-12-09 to 2027-05-09); increased frequency (biweekly) during final scenario-locking period (Months 6-9 = 2027-04-09 to 2027-07-09). Adopter interviews and follow-ups scheduled as needed within meeting-planning calendar.

**Typical Agenda Items:**

- Adopter-engagement status: interviews completed, pending, responses received and analyzed
- Scenario profiles emerging from adopter input: cost tolerance, capacity needs, uptime expectations
- Threshold sensitivity analysis: if productivity or downstream-processing cost exceeds model, what is impact on scenario viability?
- Adopter commitment and signing readiness (for Month 7 = 2027-05-09 target)
- Scenario-locking preparation: final drafts, time-stamping, publication plan

**Escalation Path:** If an adopter is reluctant to commit in writing or signals withdrawal, escalate to Steering Committee immediately: assess whether remaining scenarios remain credible or if additional adopter recruitment is needed. If adopter cost tolerance is lower than the cost-model forecast, escalate to Steering Committee for decision: accept a looser threshold, commit to cost-reduction work in Phase Two, or acknowledge the scenario may not be met. If regulatory changes or competitive developments threaten adopter interest mid-project, report to Steering Committee and gate-review panel; assess credibility of locked scenarios and recommend contingency action (e.g., scenario renegotiation or pivot to new adopter). Any adopter withdrawal after scenarios are locked triggers publication of reason to all stakeholders and reassessment of remaining scenarios' credibility by Steering Committee and gate-review panel.
### 7. Kenyan Replication Coordination and Independence Assurance

**Rationale for Inclusion:** Independent replication by a separate Kenyan team is a core proof point for the project's openness and reproducibility claims. The plan requires the team to obtain the strain, build the system from documentation alone and produce on-spec biomass under difficult infrastructure conditions (power outages, limited supply chains, local technician skills). Replication independence is audited via an assistance log (tracking all help from Danish developers or external experts) and a documentation-defect log (tracking every ambiguity found during build and its resolution). An early small-scale replication in Phase Two identifies documentation gaps cheaply before the full-scale Phase Three build. A dedicated coordination body ensures that the Kenyan team is truly separate from the Danish team, that assistance is logged transparently, that defects are tracked and resolved, and that gate reviews can credibly assess reproducibility.

**Responsibilities:**

- Manage institutional and partnership governance with the Kenyan co-development partner: confirm signed MoU covering staffing, site access, logistics, contingency plans for staff or partner changes; establish quarterly partnership reviews with Steering Committee
- Coordinate early paper-and-bench replication (Phase Two, Months 14-24 = 2027-12-09 to 2028-10-09): independent group builds a small (1-10 L) unit from draft documentation; track all issues found and document resolutions
- Maintain audited assistance log: document all communications and assistance between Kenyan team and Denmark team or third-party experts (safety review, regulatory consultation, specialist maintenance, emergency troubleshooting); auditor reviews log monthly and flags any assistance exceeding acceptable thresholds (target: <4 h/month hands-on troubleshooting)
- Maintain documentation-defect tracking system: log every ambiguity in documentation found during build or operation (location in docs, severity, resolution, source); auditor reviews defects and resolutions to confirm documentation gaps are being closed systematically
- Conduct quarterly site-envelope baseline monitoring (Phase Three): verify that Kenyan site operating conditions remain within documented baseline (power-outage frequency, water quality, spare-part availability, technician skills); if any parameter drifts >20%, document and trigger contingency stressors
- Manage Kenyan site logistics: coordinate equipment shipment, cold-chain for cryo-stocks, spare-parts procurement, utility setup and safety inspections; flag any risks to timeline or operating envelope
- Coordinate operator training and competency verification: implement training curriculum designed in Phase One-Two; assess technician competence on safety-critical tasks before commissioning; re-assess after incidents or long shutdowns
- Support documentation finalization and release: collect defects and improvements from Phase II early replication; facilitate documentation updates before release (after safety and legal review); coordinate with gate-review panel on documentation readiness assessment
- Prepare Kenyan replication chapters for Phase Two and Phase Three gate reports: defect-log summary, assistance-log audit summary, site-envelope status, operator training results, any safety incidents or issues

**Initial Setup Actions:**

- Month 0-1 (2026-10-09 to 2026-11-09): Finalize signed MoU with Kenyan partner covering staffing, site access, equipment installation, training commitment and contingency plans; establish quarterly review schedule
- Month 1-3 (2026-11-09 to 2027-01-09): Recruit independent auditor (external firm, not affiliated with Danish project or Kenyan partner) to conduct monthly assistance-log and defect-log reviews
- Month 2-4 (2026-12-09 to 2027-02-09): Conduct Kenyan site baseline study (independent site-selection consultant, not Kenyan partner): document power-outage patterns, water quality, ambient conditions, spare-part availability, local technician cohort; deliver Kenyan Site Baseline Report by Month 4 (2027-02-09)
- Month 3-4 (2027-01-09 to 2027-02-09): Establish assistance-log and defect-tracking systems (shared spreadsheet or issue tracker); train Kenyan team and auditor on logging procedures and escalation criteria
- Month 8-10 (2027-06-09 to 2027-08-09): Identify independent group to conduct early Phase II replication; confirm group's organizational separation from Danish team and baseline capability
- Month 11 (2027-09-09): Establish defect-tracking system for early replication, pre-loaded with expected-gap template from Danish experiences

**Membership:**

- Kenyan Site Lead or Replication Project Manager (based in Kenya; day-to-day site coordination, Kenyan partner liaison, UK team coordination)
- Independent Auditor (external firm reviewing assistance log and defect log monthly; flag patterns suggesting insufficient Kenyan team competence)
- Kenyan Partner Organization Lead (partnership governance, staff allocation, site access, local logistics)
- Training and Competency Coordinator (operator training delivery, competency assessment, re-assessment scheduling)
- Documentation and Defect Manager (defect-tracking system administration, resolution follow-up, documentation-update coordination)

**Decision Rights:** The Kenyan Replication Coordination body has authority to manage day-to-day site and partnership operations within the approved Phase Two-Three plan. Authority to approve replication timeline and budget allocations rests with Steering Committee. Authority to assess Kenyan team competence and operator readiness rests with independent auditor and gate-review panel. Body recommends to Steering Committee on: site-envelope changes, assistance-log patterns suggesting competence gaps, documentation-defect severity and resolution adequacy, any partnerships or logistics risks. Body cannot unilaterally declare replication ready for full-scale build or commissioning; Steering Committee and gate-review panel must approve based on Phase II-gate evidence.

**Decision Mechanism:** Monthly Kenyan coordination meetings (60 min teleconference, Denmark-Kenya timezone accommodation) with Kenyan Site Lead, Danish Project Lead, Training Coordinator and Auditor. Assistance log and defect tracker reviewed by auditor monthly; formal audit report generated by 10th of following month. Quarterly partnership reviews with Steering Committee (Month 6, 12, 18, 24, 36, 48 = 2027-04-09, 2027-10-09, 2028-04-09, 2028-10-09, 2029-10-09, 2030-10-09 estimate). Site-envelope baseline-monitoring reports generated quarterly starting Month 30 (2029-04-09). Decisions on site logistics, training curriculum, or assistance-log escalation made by consensus; disputes escalate to Project Lead and Steering Committee.

**Meeting Cadence:** Monthly Kenyan coordination meetings (60 min) during Months 1-60 (2026-11-09 to 2031-10-09). Monthly auditor reports on assistance-log and defect-log status. Quarterly partnership reviews with Steering Committee (Months 6, 12, 18, 24, 36, 48 = 2027-04-09, 2027-10-09, 2028-04-09, 2028-10-09, 2029-10-09, 2030-10-09). Site-envelope baseline-monitoring reports quarterly during Phase Three (Months 30, 36, 42, 48, 54 = 2029-04-09, 2029-10-09, 2030-04-09, 2030-10-09, 2031-04-09 minimum). Additional ad-hoc communication as needed (e.g., emergency troubleshooting, logistics issue, safety incident).

**Typical Agenda Items:**

- Site and logistics status: equipment delivery, utilities setup, cryo-stock storage, spare-parts procurement
- Assistance-log audit: communications logged, assistance frequency and type, any flags or patterns, mitigation actions
- Defect-log status: ambiguities found and resolved, open items, severity trends, progress toward documentation v1.0
- Operator training and competency: cohort progress, assessment results, any concerns or re-training needs
- Site-envelope monitoring (Phase Three): power outages, water quality, spare-part availability trends, any drifts or stressors
- Partnership and staffing: any changes in partner capacity, staff departures or contingency activations

**Escalation Path:** If assistance log shows hands-on developer troubleshooting >4 h/month, escalate to independent auditor and Steering Committee: assess whether Kenyan team needs additional training or documentation is insufficient. If defects are not being closed systematically or categories indicate gaps (e.g., repeated missing safety-interlock details), escalate to Steering Committee and independent gate-review panel: assess documentation readiness for Phase III build or recommend extended Phase II refinement. If site-envelope drifts >20% from baseline (e.g., power becomes more reliable), escalate to Steering Committee: trigger contingency stressors or document change in hypothesis B testing conditions. If partner-organization stability is threatened (staff turnover, funding change), escalate to Project Lead and Steering Committee: activate contingency plans and assess risk to Phase III schedule.