### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] The project proposes to make protein for countries in an energy-and-food crisis from electrolytic hydrogen, a process that depends on the scarcest input in that crisis and on hazardous-gas skills the target sites lack, and its EUR 50 million ceiling cannot show that this beats the legumes and reserves it names as rivals.**

**Bottom Line:** REJECT: A hydrogen-fed single-strain protein plant is the wrong answer to a crisis in which energy is short, and an open design package does not change that.


#### Reasons for Rejection

- The stated use case is an energy crisis coinciding with a food crisis, yet every kilogram of biomass requires electrolysis, gas compression or mass-transfer power and cooling, so the design consumes the failing resource, and the brief's own requirement to state how long production runs without resupply admits that the answer may be 'not long'.
- The brief demands both routine operation by 'locally trained technicians after a short programme' and ATEX-grade hydrogen/oxygen design with independently reviewed interlocks, but these goals pull against each other, because a short course cannot make operators competent to run a flammable-gas plant on an unreliable grid.
- A EUR 6 million Phase One and EUR 50 million total ceiling are set against a commercial precedent that needed a purpose-built plant (Solar Foods Factory 01 with 20,000-litre bioreactors, about 160 tonnes a year design capacity), so the open project cannot reach a deployment-relevant scale with the funds named, and the gate only confirms a small reference unit that the brief itself says 'does not establish industrial viability'.
- The brief names no scenario in which this beats protein reserves, legumes or proprietary systems and defers that question to the end of Phase Three after the money has been spent, so the existence of a user is assumed while Kenya and Denmark are already fixed as sites.
- The mission says the project 'does not aim to improve any one country's food security', yet it fixes Kenya as the replication site and Bangladesh as a regulatory target, and it chooses a single pure strain, which removes the robustness a failing-infrastructure setting would need and leaves the project without an accountable beneficiary.

#### Second-Order Effects

- 0–6 months: Strain-rights, host-institution and Kenyan-partner negotiations absorb the Phase One budget, and the landscape review likely confirms that the proprietary-versus-open gap is mostly about funding and not about missing science.
- 1–3 years: Container-scale outage and robustness tests probably show a steep productivity and energy penalty for the simplified designs, which pushes the team towards a more complex plant that fails the technician-operability target.
- 5–10 years: The published package is a design for a flammable-gas plant that third parties may build without the safety review, local regulators, or insurers the brief assumes, and the likely outcome is a Research Only verdict with no adopter, or a poorly built copy that causes an incident and harms the open-source label.

#### Evidence

- Case/Incident — Solar Foods Factory 01, Vantaa, Finland (2024): the first commercial hydrogen-oxidizing-bacteria protein plant uses 20,000-litre bioreactors and a design capacity of roughly 160 tonnes a year, which shows the scale and capital a deployment-relevant plant needs.
- Law/Standard — ATEX Directive 2014/34/EU and Directive 1999/92/EC (2014/1999): these set equipment and workplace rules for explosive atmospheres, which apply directly to the hydrogen/oxygen hazard in the Danish reference unit.
- Law/Standard — EU Novel Food Regulation (EU) 2015/2283 (2015): bacterial biomass for food needs pre-market authorization in the EU, which means the food-ingredient product category has a long regulatory route.



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[STRATEGIC] — The Electrons-for-Dinner Fallacy: the plan promises food security for countries in a food crisis by burning scarce electricity, in an energy crisis, through a hydrogen-and-oxygen plant that untrained local technicians must keep from exploding, while insisting the project does not aim to improve any country's food security.**

**Bottom Line:** REJECT: The Electrons-for-Dinner Fallacy builds a food-security tool that needs the one resource a food-and-energy crisis removes, and hands its explosion risk to the people it claims to serve. A premise that denies any country's food security as its aim, while justifying itself by countries' food security, has no honest reason to exist.


#### Reasons for Rejection

- The people asked to run explosive hydrogen-and-oxygen equipment (Kenyan technicians after a 'short' training course) and to eat or feed an unproven single-strain protein never consented to being the proving ground, and the rule barring the original designers from helping them when something goes wrong puts the test's purity ahead of their safety.
- A project spanning a Danish test site, a Kenyan replication team, a Bangladesh patent review, EU and Kenyan product rules, and funding, partners and permits that are all 'uncontrolled until signed' leaves no single body that answers for an injury or a contaminated batch once the open files are in other people's hands.
- Publishing complete build and operating instructions for a gas fermenter, with a stated list of parts adopters may change without a safety review, invites thousands of uncontrolled copies in places with no inspectors, and one explosion or one toxic feed batch cannot be recalled once the files are out.
- The core promise is hollow: it spends electricity that is scarcest exactly when the plan says it is needed, relies on imported parts such as electrolyzer membranes, and competes against stored grain, legumes and protein reserves that need no electrolysis, so the 'no dependence on a single exporter' goal just swaps one dependency for several.

#### Second-Order Effects

- **T+0–6 months — The Cracks Appear:** Strain rights, three-jurisdiction patent reviews and funder promises collide, and the 'independent' reviewers turn out to be a small circle of the same gas-fermentation researchers.
- **T+1–3 years — Copycats Arrive:** Universities, start-ups and hobbyists copy the published hardware without the safety package, and the first hydrogen incident gets attributed to 'the open protein reactor' regardless of who built it.
- **T+5–10 years — Norms Degrade:** Governments cite the project as proof that a food crisis can be solved with hydrogen plants, diverting money and power from grain storage, legume supply chains and cash transfers.
- **T+10+ years — The Reckoning:** The record shows a replication that passed only because documentation was patched after each failure, a regulatory 'pathway' that never produced an approved product, and a Kenyan site left with equipment nobody can safely run or afford to power.

#### Evidence

- Case/Report — Green Chemistry 2025, vol. 27 (doi:10.1039/D5GC01564B): the passive gas-feeding work with Cupriavidus necator H16 reported about 58 mg per litre per hour at bench scale and small-scale use at atmospheric pressure. That is a laboratory result, far from an industrial, outage-tolerant plant, and it shows the plan's own best precedent has not been scaled.
- Case/Report — AMYBO's open-source electroPioreactor, an add-on kit to the Pioreactor bioreactor for hydrogen-oxidizing bacteria, with grant funding reported for an aseptic version: open work exists but is small, early and laboratory-scale, so the claimed gap is a gap in proven scale and safety, not in publication.
- Law/Standard — EU ATEX Directives 2014/34/EU (equipment in explosive atmospheres) and 1999/92/EC (worker protection in explosive atmospheres): they put duties on manufacturers and employers, and an open design handed to many unrelated builders has no one who carries those duties.
- Narrative — Front-Page Test: 'Open-source protein reactor explodes at a Kenyan site; technicians were trained for weeks and the Danish designers were barred from advising.' No later 'lessons learned' appendix undoes that headline.



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] The premise offers an electricity-hungry, explosion-prone protein plant as food security for places where food crises coincide with energy crises, and publishing the blueprint cannot repair that contradiction.**

**Bottom Line:** REJECT: A protein process whose key input is electricity and whose key hazard is hydrogen cannot be a credible answer to food-supply disruptions in places that lack both, and no amount of open documentation changes that.


#### Reasons for Rejection

- Economics and need collide: electrolysis turns scarce electricity into protein (energy per kilogram likely in the tens of kWh, estimate), so the plant stops being useful in the very energy-crisis-plus-food-crisis scenario the brief says it must survive, while Kenyan industrial tariffs are reported at roughly US$0.18–0.23 per kWh.
- The brief names protein reserves, legumes and proprietary systems as the rivals, yet requires at least one scenario where the open design beats them, so a favourable answer is built into the premise while soybeans and stockpiles need no electrolyzer, no pure culture and no hydrogen safety case.
- Hypothesis B asks for hydrogen–oxygen fermentation modules that are affordable, independently maintained and run by locally trained technicians after a short training programme in regions with unreliable infrastructure, which puts an explosive-atmosphere plant in the hands of the people with the least spare parts, specialist support and regulatory backstop.
- A non-profit that explicitly refuses to improve any one country's food security has no accountable beneficiary, and open licensing of a single Cupriavidus necator H16 strain and process cannot grant freedom to operate across Denmark, Kenya and Bangladesh, where patents on hydrogen-oxidizing biomass processes already exist.
- The EUR 50 million ceiling ends in a Danish reference unit and one Kenyan replication, yet the brief concedes that a working reference unit does not establish industrial viability, and the only commercial benchmark found is Solar Foods' Factory 01 at a maximum of 160 tonnes per year, so the money buys a demonstration that cannot answer the question it was funded to answer.

#### Second-Order Effects

- 0–6 months: Phase One spends part of its EUR 6 million ceiling (user constraint) on landscape reviews and strain-rights opinions, and the review shows that the 'gap' is a gap in openly published commercial know-how rather than in scientific knowledge. Partners and funders then read the kill gate as a formality.
- 1–3 years: Container-scale outage tests in Denmark and Kenya show productivity falling in simplified designs, such as the passive-feed approach reported at 58 mg per litre per hour, while the safety case demands ATEX-grade parts that are neither cheap nor locally available. The project is then pushed to choose between a hazardous simple design and an expensive safe one.
- 5–10 years: A published blueprint exists, but no government, feed company or relief agency has staked its food supply on it, since cheaper legumes and reserves are still available and the commercial plants already operate. The open design becomes a well-documented academic artifact, and a poorly built copy causing a hydrogen incident would tarnish open-source food technology in general.

#### Evidence

- Case/Incident — Solar Foods Factory 01, Vantaa, Finland (2024): the first commercial hydrogen-oxidizer protein plant has a stated maximum output of 160 tonnes per year, showing how small even a flagship commercial facility is against national protein needs.
- Report/Guidance — Green Chemistry, passive gas feeding with Cupriavidus necator H16 (2025, doi:10.1039/D5GC01564B): the reported 58 mg per litre per hour productivity and the need for a dual-chamber design to separate H2 from O2 show that simplification costs output and safety is built into the geometry.
- Report/Guidance — World Bank Enterprise Surveys, Kenya (survey year not verified): firms reported about 11 days of outages per year and 65.6% owned generators, showing that unreliable power is the baseline condition for an electricity-fed protein plant.



### Premise Attack 4 — Cascade
_Tracks second/third-order effects and copycat propagation._

**Strategic flaw: the plan puts an unsolved biology, chemical-safety, regulatory and economic problem inside one bundle and then requires a Kenyan team to reproduce it blind, from documents alone, in a hard environment. It tests documentation rather than technology. The unfixable assumption is that hard-won tacit knowledge in a hazardous H2/O2 gas-fermentation process can be written down completely enough for an independent crew to run it safely, so the design's central feature (independence from any single expert or company) is also the thing most likely to fail.**

**Bottom Line:** Abandon the premise: do not build a single programme that must invent, certify and blind-replicate a hazardous hydrogen gas-fermentation plant in Denmark and Kenya at once. The premise itself guarantees that failures cannot be traced to their cause, and nothing in the brief shows that this process can beat reserves, legumes or imports where an energy crisis hits.


#### Reasons for Rejection

- The Tacit-Knowledge Firewall: the replication rule bars undocumented help from the developers. Gas fermentation depends on tacit skills: foam and contamination handling, strain drift, and recognising a culture that is about to crash. A first Kenyan failure is therefore close to guaranteed, and the 'Modify' verdict then absorbs it. A failed first replication tells the project very little, because it cannot separate bad documents from a bad process, a bad site or a bad team. The project pays for the independence and cannot interpret the result.
- The Seven-Gate Pileup: the plan fuses an open-hardware project, strain-rights research, a techno-economic study, a safety case, EU and Kenyan regulatory work, a scale-up programme and a blind-replication trial. Each is a research programme in its own right. The Phase One 'ceiling' of EUR 6 million (user constraint) must also cover a landscape review, strain work, a patent and regulatory review in three countries (Denmark, Kenya, Bangladesh) and a v0.1 blueprint. Phase One therefore produces broad, shallow output, and the kill gate will be decided on thin evidence in either direction.
- The Hazard-Dilution Paradox: it is ruled that manual controls never bypass interlocks, that H2 storage is not mandated, and that locally trained technicians run routine production after a short course. Yet the plant continuously combines electrolytic H2 and O2 with a flammable-gas process, in regions with unreliable power and scarce spare parts. A safety design that tolerates outages, component substitution and fault-injection by non-specialists works against the ATEX discipline that makes the process safe. 'Simplified enough for locals' and 'safe enough for H2/O2 at pressure' pull in opposite directions, and Hypothesis A may be self-contradictory.
- The Reference-Strain Mirage: the process depends on one pure strain (C. necator H16 is offered only as an example, and is not a decision). The plan wants one lawfully obtainable strain with rights for commercial production, redistribution, modification and sharing of derivatives. Culture-collection deposits usually carry material-transfer terms, and industrial strains and their patents are proprietary. Nobody can promise a clean freedom-to-operate in Denmark, Kenya and Bangladesh at the start. A single-strain, no-mixed-culture rule also makes the process less resilient to contamination precisely where sterility is hardest to hold.
- The Deployment-Case Vacuum: the project requires a deployment scenario in which an open, locally maintained gas-fermentation plant beats stockpiled protein, legumes, imports or proprietary units, and it must fix cost, capacity and reliability thresholds before testing. Electrolytic H2 costs a lot of electricity per kilogram of protein. In the very energy-crisis scenario the plan names, that power competes with households and industry. Legumes, soy imports and reserves are cheap and robust, so the realistic outcome is 'Research Only'. The plan costs EUR 50 million (user-set ceiling) to find that out, with a Kenyan replication phase that no one may need.

#### Second-Order Effects

- Within Months 0-6 (2026-10-09 to 2027-04-09): Funding, partner and permit status are all 'uncontrolled until signed', and the plan has no fixed host, funder or independent reviewer. Staff are hired before the gate authority exists. Early reviewer selection becomes a fight over who counts as 'funding-independent' in a niche where the few experts are all researchers, startups or their collaborators. Review panels of a small, conflicted field delay or weaken Gate 1.
- Months 6-12 (2027-04-09 to 2027-10-09): The Phase One landscape review probably finds that commercial operators and published pilots already hold most process knowledge. The strain-rights work turns up restrictions on commercial use or redistribution. The kill gate arrives with the safety case, regulatory paths and unit economics still unquantified. Pressure to continue is strong because the Danish and Kenyan partners have been hired and promised work.
- Months 12-36 (2027-10-09 to 2029-10-09): Container-scale units meet the first hard limits: gas-liquid mass transfer, cooling, nucleic-acid reduction (RNA) in product, batch contamination and foam. Simplification cuts volumetric productivity, and the cost model then moves against the pre-set thresholds. The 'no adjusting the thresholds afterwards' rule is sound, but it makes a 'Research Only' result likely, and teams under funding pressure will want to relabel it as 'Modify'. Product category choice and digestibility data slip, so regulatory work is based on a provisional category.
- Months 36-60 (2029-10-09 to 2031-10-09): The Danish reference unit works, and it still proves nothing about the Kenyan site. Building it needs ATEX engineering, permits and commissioning that run past the schedule. The Kenyan replication then stalls on imported parts, customs, a membrane or sensor not locally stocked, and an ambiguity log that records hundreds of 'missing instructions' (estimate). Either independence is quietly given up, or the trial fails and the failure cannot be attributed. Operator injury or an H2 incident, in even a small number of cases, would end the open-hardware effort and bring reputational and legal exposure to the host institution and to the licence regime.
- Years 5-10: If the outcome is Go, the open documents are adopted by actors who skip the safety review and run non-compliant H2/O2 plants. The project cannot control this. Open licences give a safe-operation regime no legal force. If the outcome is Stop or Research Only, EUR tens of millions (up to the EUR 50 million ceiling, user constraint) leave a data set whose reuse value is limited because the commercial leaders hold the useful knowledge. Funders would be less willing to back the next open-science attempt in food security.

#### Evidence

- Calysta (methane-based gas-fermentation protein): per AgFunderNews, it wound down pilot plants and R&D labs in the US and UK after taking its process to commercial scale in China, and a separate report says demonstration-scale production in China was halted when the joint-venture partner ended financial support. Even a well-funded firm with a proprietary, closely held process depended on its partner and was slowed by it. Dates not verified. The open, reproducible version of this process has far fewer resources.
- Solar Foods (Solein, hydrogen-oxidising bacteria): Factory 01 in Vantaa, Finland has a stated capacity of 160 tonnes a year (company-reported), after years of work as a funded company with its own proprietary strain and plant know-how. Its first approval came from Singapore in 2022, and EU novel food authorisation was still described as 'expected in 2026' in the sources found. Confirmation that it has been granted was not found. The regulatory path in the EU alone takes years for the best-resourced operator, before Kenya or Bangladesh are added.
- Gas-fermentation and alternative-protein failures: the sources found list Novonutrients and Arkeon as having gone out of business. Unibio built a commercial U-Loop plant in Denmark with a stated capacity of up to 80 tonnes a year, while its large-scale plans (Saudi Arabia, Qatar) were announced years ahead of any confirmed output (not verified). Small output, long timelines and funding gaps are normal in this sector, even for firms with commercial investors.
- AMYBO's open-source electroPioreactor and the 2025 Green Chemistry paper on passive gas feeding (doi:10.1039/D5GC01564B, cited by the brief) are bench and low-resource studies. They show interest in the topic, and they leave an enormous gap between a laboratory reactor and a safe, certified, outage-tolerant container plant. No directly comparable open, independently replicated H2/CO2 protein plant is known to the brief, so a direct precedent for the full plan does not exist; it is dangerously unprecedented in its combined scope.



### Premise Attack 5 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[STRATEGIC] — Blueprint Transfer Illusion: The plan stakes a flammable hydrogen-oxygen bioprocess on the belief that published documents can replace tacit operating knowledge, while a rule barring undocumented help from the designers guarantees that the first hard failure is also the first unaided one.**

**Bottom Line:** REJECT: The premise treats a published document package as a safe substitute for supervised engineering of an explosive-gas process, and it releases that package to builders nobody can hold to account. The gate is closed.


#### Reasons for Rejection

- Rights and dignity: Kenyan technicians, trained briefly and competency-verified, would be asked to run a process whose gas mixtures can be explosive, so the people with the least say in the design carry the most bodily risk. A "short training programme" does not make that risk acceptable, and the plan counts a field of volunteers as a test population.
- Accountability and oversight: The plan splits responsibility between a Danish design group, a Kenyan co-development partner, a separate replication team, and unnamed external professionals. No single party owns a fatal incident, and the rule that independence must not override safe operation leaves unresolved who may call the designers in an emergency. It also leaves open who is liable when they do. All hosts, funders, partners and permits are unsigned, so this accountability exists only on paper.
- Systemic risk at scale: An open-licensed package for building electrolysis plus pressurized or pneumatic H2/O2/CO2 fermentation will be copied by actors the project cannot see, certify or recall. It also invites substitution of components, which the plan itself anticipates. Once published, "which parameters adopters may change without reassessment" cannot be enforced, and the first lethal hydrogen accident anywhere will be traced back to the project.
- Value-proposition rot: The pitch of national protein independence rests on an unproven niche. Protein reserves, legumes and proprietary suppliers already exist, and the plan admits that no independently replicated, industrially relevant implementation is known. It also admits that simplification costs productivity, and that cost has not been measured. The plan asks for up to EUR 50 million (user constraint) before it knows whether any deployment scenario beats the alternatives, and it commits to pre-set thresholds only after the framing is chosen. Describing the work as "not aiming to help any one country" while naming Kenya, Denmark and Bangladesh shows that the beneficiary is undefined.

#### Second-Order Effects

- T+0–6 months (Months 0–6 = 2026-10-09 to 2027-04-09) — The Cracks Appear: The landscape review shows that the useful strain, process and reactor knowledge is held under proprietary or patented claims, or locked inside researchers' heads. The strain rights audit finds that no single strain is cleanly free for commercial use, redistribution and modification. Partners, sites and permits remain unsigned. The Phase One budget (provisional ceiling EUR 6 million, user constraint) then funds paperwork and survey work rather than evidence.
- T+1–3 years (Months 12–36 = 2027-10-09 to 2029-10-09) — Copycats Arrive: Early lab data and the "open protocol" attract hobbyists, start-ups and under-resourced institutions to build partial versions. They skip the process-hazard analysis because the published reactor design looks routine. Pressure builds to release operating instructions before legal and safety review, since the research data is already out. Gate reviewers face a funder that wants continuation.
- T+5–10 years (Months 60–120 = 2031-10-09 to 2036-10-09) — Norms Degrade: Home-grown variants and unreviewed component substitutions become standard practice, and the project's safety envelope turns into a suggestion that people cite to justify improvisation. Governments that adopted the design as a food-security hedge find that the real constraints are spare parts, electrolyzer membranes and microbiological QA. The open-source label, which implied low cost, becomes a liability when something goes wrong, because no one answers for it.
- T+10+ years (Months 120+) — The Reckoning: A hydrogen-handling fatality or a contaminated feed or food batch from a copied unit sets off investigations. Regulators in Denmark, the EU and Kenya respond by restricting small-scale gas fermentation and by barring open publication of operating details. The project is remembered for pushing explosive-gas biotechnology into the least supervised settings, and not for the food security it promised.

#### Evidence

- Principle/Analogue — Sociology of Science (Harry Collins, replication of the TEA laser): Replicators could build a working laser only through personal contact with people who had built one, not from published papers. The plan's ban on undocumented help from the designers rests on the assumption that tacit knowledge can be fully written down.
- Case/Report — Solar Foods (Finland): This company has been developing hydrogen-oxidising bacterial protein (Solein) since the late 2010s. It submitted its EU Novel Food application on 29 October 2021 and, as of the search consulted, was still awaiting a final EFSA opinion, with approval expected in 2026 (not verified beyond that). Its Factory 01 is rated at up to 160 tonnes a year. A well-funded commercial firm with proprietary strains and professional engineers took about five years on the regulatory route alone, which weakens any claim that a non-profit can hand a small team a credible pathway.
- Case/Report — Cupriavidus necator cultivation on H2/CO2/O2: Peer-reviewed work on lab-scale growth on explosive gas mixtures (PMC9138072) states that H2/O2 mixtures above roughly 4 mol% H2 and 6 mol% O2 pose an explosion risk, which is why explosion-proof bioreactors are used. A separate point in the same literature is that C. necator shows oxygen inhibition and a narrow oxygen optimum. The process therefore sits between a lethal regime and a growth-limiting one, and the plan expects non-expert operators to hold that window through outages.
- Law/Standard — EU ATEX Directives 2014/34/EU (equipment) and 1999/92/EC (workplace explosive atmospheres): ATEX requires certified equipment and a documented explosion-protection assessment for each workplace. An open design cannot carry that certification to builders who swap components, and the plan has no mechanism to bind them to it.