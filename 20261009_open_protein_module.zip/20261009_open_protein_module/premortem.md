A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The Month 4 (2027-02-09) Strain Feasibility Report will confirm a primary and legally clean backup strain lawfully importable into Kenya, with no blocking patent or biosafety barrier. | At Month 0.5 (2026-10-24), send written rights requests to at least 4 strain holders and commission the patent search. Open informal contact with Kenya's biosafety authority by Month 2.5 (2026-12-24). | Fewer than 2 strains confirmed lawful for commercial use, redistribution and Kenyan import by Month 3.5 (2027-01-24), or a blocking patent or import restriction on the primary strain. |
| A2 | The EUR 7.93/kg deployment cost gap (EUR 19.93/kg vs EUR 12 cap) will be closed by cost reduction or a committed gap-funding route before scenarios are locked. | Start the cost-reduction study at Month 1 (2026-11-09). Test electricity price, downstream energy and module scale, and ask the funder and prospective adopters for a written funding position. | Modeled cost stays above EUR 15/kg under optimistic inputs, and no funder or adopter commits written gap funding by Month 7 (2027-05-09). |
| A3 | Named adopters will sign locked scenario thresholds by Month 7 (2027-05-09) and stay committed through the Phase Three gate, giving the Go decision real demand behind it. | By Month 2 (2026-12-09), approach 2-3 decision-making adopters with draft scenario profiles. Request written cost-basis data and a signature intent letter. | Fewer than 2 adopters provide auditable cost data and sign by Month 7 (2027-05-09), or any signatory conditions its commitment on a cost below the modeled floor. |
| A4 | Hydrogen-oxygen hazard can be held inside the preliminary safety limits (O2 <4% in H2-rich stream, gas inventory <0.5 m3 H2) without a productivity penalty that breaks the Phase One productivity gate. | Run a bench test at Month 2.5 (2026-12-24) of all three reactor concepts inside the safety limits, with productivity measured against the C. necator benchmark by the single lead analyst. | Any concept inside the limits shows productivity below 70% of the published benchmark (proposed threshold), or a loss above 20% relative to the unconstrained design. |
| A5 | The Danish university consortium and the Kenyan partner will sign agreements and keep staff and facilities protected through Phase Three, despite unsigned status today. | Request draft MoU terms from both parties by Month 0.5 (2026-10-24). Confirm named principal investigator, protected lab space and a site manager candidate. | No signed Danish MoU by Month 1 (2026-11-09), no signed Kenyan partner agreement by Month 3 (2027-01-09), or a key partner refuses protected staff time in writing. |
| A6 | The independent gate panel and auditors can be recruited with genuine funding independence, enough technical depth and willingness to issue a Stop that the funder will respect. | Issue an open call at Month 0.5 (2026-10-24). Screen candidates for conflicts. Ask the funder to state in writing how a Stop recommendation will be handled. | Fewer than 3 conflict-free qualified members confirmed by Month 1.5 (2026-11-24), or the funder declines to commit in writing to publishing and justifying any deviation. |
| A7 | Downstream processing can reach the product specification (protein >=60%, nucleic acid <=2% of dry matter, moisture <=8%) (estimate) at an energy and cost within the cost model, using steps local technicians can run. | At Month 3 (2027-01-09), run bench nucleic acid reduction trials (thermal and enzymatic) on Phase One biomass. Measure nucleic acid, recovery yield and kWh per kg usable protein. | Nucleic acid stays above 3% of dry matter (proposed threshold) in triplicate trials, or downstream energy is at or above 30 kWh/kg usable protein (proposed threshold). |
| A8 | The Kenyan site can be commissioned and supplied (spares, inputs, cryo-stocks) within the local envelope, and the EUR/KES rate stays inside the currency fund, without logistics hiding design results. | By Month 3 (2027-01-09), survey at least 2 suppliers per critical item in Kenya for lead time and landed cost. Run a dry-run cold-chain shipment with a non-hazardous surrogate strain. Compute EUR/KES exposure on about EUR 4M KES spend (estimate). | Any critical item has lead time above 4 weeks or a single source, the surrogate shipment fails temperature limits, or a 20% KES move would exceed the EUR 0.5M currency fund. |
| A9 | Regulators and the public will accept a hydrogen-oxidizing single-cell protein from an open, non-profit programme in the chosen product category, with nucleic acid limits and safety data requirements the project can meet. | By Month 2.5 (2026-12-24), send written pre-submission questions to the Danish/EU authorities and Kenya's biosafety authority on category, nucleic acid limits and the minimum safety-data package. Survey 10 potential feed and food users on acceptance. | An authority requires a nucleic acid limit below 2% of dry matter or a safety-data package costing more than EUR 0.4M (estimate), or fewer than half of surveyed users accept the product. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Bridge to Nowhere | Process/Financial | A2 | Funder Representative and Techno-Economic Lead | CRITICAL (20/25) |
| FM2 | The Strain That Could Not Cross the Border | Technical/Logistical | A1 | Strain Rights and Regulatory Affairs Specialist | CRITICAL (15/25) |
| FM3 | The Customers Who Never Signed | Market/Human | A3 | Adoption Economist | CRITICAL (16/25) |
| FM4 | The Safe Reactor That Would Not Grow | Technical/Logistical | A4 | Lead Process Engineer | CRITICAL (15/25) |
| FM5 | The Partners Who Never Signed | Process/Financial | A5 | Project Director | HIGH (12/25) |
| FM6 | The Panel That Said Yes | Market/Human | A6 | Funder Representative and Panel Chair | CRITICAL (15/25) |
| FM7 | The Shilling Slide and the Stalled Shipment | Process/Financial | A8 | Programme Finance Lead | HIGH (12/25) |
| FM8 | The Protein That Failed the Spec | Technical/Logistical | A7 | Downstream Bioprocessing Engineer | HIGH (12/25) |
| FM9 | The Protein Nobody Would Approve or Eat | Market/Human | A9 | Strain Rights and Regulatory Affairs Specialist | HIGH (12/25) |


### Failure Modes

#### FM1 - The Bridge to Nowhere

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: Funder Representative and Techno-Economic Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Full cost EUR 19.93/kg vs EUR 12 cap; gap EUR 274,820/yr (estimate).
- Gap-funding route stays an open decision past Month 9 (2027-07-09).
- Phase Two proceeds on momentum; EUR 4.0M reference hardware is released.
- Phase Three gate finds no scenario affordable.
- Outcome: Research Only after about EUR 35M is committed.

##### Early Warning Signs
- Cost-reduction study has no named owner by Month 3 (2027-01-09)
- No written funder position on gap funding by Month 6 (2027-04-09)
- Interim modeled cost still above EUR 15/kg at Month 6 (2027-04-09)
- Adopters make signatures conditional on a subsidy

##### Tripwires
- Modeled full cost >= EUR 15/kg at Month 6 (2027-04-09)
- No signed gap-funding commitment by Month 7 (2027-05-09)
- Downstream energy measured >= 30 kWh/kg usable protein

##### Response Playbook
- Contain: Freeze release of the EUR 4.0M reference-unit hardware budget until a cost path is documented.
- Assess: Commission an independent audit of the cost model with Monte Carlo sensitivity on electricity, downstream energy and capex.
- Respond: Have the panel choose between a funded grant, a 50 kg/day redesign or a reduced Phase Three (Danish unit only) or Research Only.


**STOP RULE:** Do not release Phase Three hardware unless the model predicts <= EUR 14/kg and a gap-funding route is committed in writing.

---

#### FM2 - The Strain That Could Not Cross the Border

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A1
- **Owner**: Strain Rights and Regulatory Affairs Specialist
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Primary strain (C. necator H16) carries commercial-use or derived-strain limits, or Kenya blocks import.
- Barrier surfaces after reactor tests are locked to that strain.
- Backup strain is legally clean but less productive and uncharacterized.
- Phase One gate delays and the Kenyan replication cannot lawfully obtain the strain.
- Phase Three switch costs EUR 2-4M and 12-24 months (estimate).

##### Early Warning Signs
- Strain holders silent after 6 weeks
- Patent search flags a third-party claim on the primary strain
- Biosafety authority asks for formal dossier or full risk assessment
- Backup strain has no bench productivity data

##### Tripwires
- Fewer than 3 of 4 strain holders respond in writing by Month 2 (2026-12-09)
- No Kenyan biosafety written feedback by Month 3.5 (2027-01-24)
- Backup strain productivity < 70% of the C. necator benchmark

##### Response Playbook
- Contain: Pause design commitments and reactor builds tied to the blocked strain.
- Assess: Run a 2-3 week bench comparison of the backup strain against the primary and score the freedom-to-operate risk.
- Respond: Switch to the backup using the EUR 0.30M earmark, or escalate to the panel for a schedule decision.


**STOP RULE:** If no strain is lawfully importable into Kenya for commercial use by Month 6 (2027-04-09), stop or pivot to Research Only.

---

#### FM3 - The Customers Who Never Signed

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Adoption Economist
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Prospective adopters engage informally but will not commit before prototype results.
- Scenarios are locked on project-derived thresholds with no real cost-basis data.
- An adopter withdraws mid-project, so remaining scenarios lose credibility.
- Soy, insect protein or proprietary hydrogen protein undercut the thresholds.
- A technical Go is reached, but no one will deploy.

##### Early Warning Signs
- Adopters decline to share invoices or budgets
- Interview follow-ups unanswered for 4 weeks
- Adopter asks to renegotiate thresholds after Phase Two data
- Competitor protein price drops

##### Tripwires
- Fewer than 2 adopters with auditable cost data by Month 4 (2027-02-09)
- Fewer than 2 signed commitments by Month 7 (2027-05-09)
- Any adopter withdrawal after Month 9 (2027-07-09)

##### Response Playbook
- Contain: Do not lock scenarios without signatures; publish withdrawals within 10 working days.
- Assess: Re-brief the panel on whether remaining scenarios are credible and re-survey adopter willingness to pay.
- Respond: Recruit replacement adopters or recommend Modify or Research Only at the next gate.


**STOP RULE:** If fewer than 2 named adopters have signed locked thresholds by Month 9 (2027-07-09), the Phase One gate cannot pass.

---

#### FM4 - The Safe Reactor That Would Not Grow

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A4
- **Owner**: Lead Process Engineer
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Safety limits (O2 <4% in H2-rich stream, low gas inventory) cut gas-liquid transfer.
- All three concepts fall short of productivity once held inside the limits.
- Relaxing limits late forces HAZOP rework and ATEX re-review.
- Cost per kg rises above the EUR 19.93/kg baseline (estimate).
- Phase Two starts late or on a weak design.

##### Early Warning Signs
- Bench productivity below 90% of benchmark in first triplicate
- kLa lower than model by more than 20% inside safety limits
- Pressure above 2 bar(g) requested to recover rate
- HAZOP findings reopened after Month 2.5 (2026-12-24)

##### Tripwires
- Productivity < 70% of C. necator benchmark in any triplicate run
- Productivity loss > 20% versus unconstrained design
- Request to raise gas inventory above 0.5 m3 H2

##### Response Playbook
- Contain: Hold all safety limits fixed and block any ad hoc relaxation of gas composition, inventory or pressure.
- Assess: Quantify the productivity penalty per concept and rerun the cost model with the measured values.
- Respond: Commission an independent ATEX review of a revised envelope, or take the panel decision for Modify or Research Only.


**STOP RULE:** If no concept reaches 70% of the benchmark inside the locked safety limits by Month 9 (2027-07-09), stop or pivot to Research Only.

---

#### FM5 - The Partners Who Never Signed

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A5
- **Owner**: Project Director
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Host MoU and Kenyan agreement stay unsigned or are signed without protected resources.
- Lab space and staff are redirected by host priorities.
- Site baseline, defect tracker and early replication slip.
- Phase One spend (EUR 5.5M planned) continues while milestones stall.
- Float of 3 months is consumed; Phase Two gate misses its date.

##### Early Warning Signs
- MoU redlines unresolved after 4 weeks
- Key roles unfilled
- Host asks to share lab time with other projects
- Kenyan partner changes its named lead

##### Tripwires
- Danish MoU unsigned at Month 1 (2026-11-09)
- Kenyan agreement unsigned at Month 3 (2027-01-09)
- More than 2 critical roles vacant at Month 4 (2027-02-09)

##### Response Playbook
- Contain: Pause new commitments of facility setup spend (EUR 2.0M planned) until the MoU is signed.
- Assess: Map the critical path impact of each missing agreement and the remaining float.
- Respond: Open parallel talks with a second Danish host and a second Kenyan partner, and escalate to the funder.


**STOP RULE:** If no Danish host with protected lab space is signed by Month 4 (2027-02-09), halt Phase One spending beyond committed items.

---

#### FM6 - The Panel That Said Yes

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Funder Representative and Panel Chair
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Panel members have hidden ties or limited time and skim evidence.
- Weak Phase One evidence is passed as Modify and continued.
- Funder overrides a Stop with thin justification.
- Adopters and regulators read the gates as ceremonial.
- Credibility loss reduces uptake of the open design.

##### Early Warning Signs
- Panel candidates hold host or project funding
- Briefing packs sent less than 4 weeks before a gate
- Panel minutes lack criterion-by-criterion findings
- Funder resists committing to publish deviations

##### Tripwires
- Fewer than 3 conflict-free members at Month 1.5 (2026-11-24)
- Briefing materials delivered < 28 days before a gate
- Any Stop or Modify recommendation overridden without published justification within 5 working days

##### Response Playbook
- Contain: Suspend release of the next phase budget until the panel recommendation and any deviation are published.
- Assess: Commission an independent check of panel conflicts, review time and evidence coverage.
- Respond: Replace conflicted members, re-run the gate review, and invoke a second review panel for repeated overrides.


**STOP RULE:** If a Stop recommendation is overridden twice without published justification, the programme is suspended pending funder governance reform.

---

#### FM7 - The Shilling Slide and the Stalled Shipment

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A8
- **Owner**: Programme Finance Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Kenya-side spend est. EUR 8M, about EUR 4M in KES (estimate).
- KES depreciates beyond the EUR 0.5M currency fund.
- Single-source spares and cold-chain failures delay Kenyan procurement.
- Funder must cut Kenyan scope or add budget.
- Hypothesis B evidence is delayed or incomplete.

##### Early Warning Signs
- Cumulative EUR/KES variance near 10%
- Quotes from only one supplier for critical items
- Surrogate shipment logger shows excursions
- Kenyan procurement approvals lag by more than 4 weeks

##### Tripwires
- Cumulative EUR/KES variance >= 10% against the Month 0 (2026-10-09) baseline
- Currency fund drawn >= 50% (EUR 0.25M) before Month 36 (2029-10-09)
- Critical-item lead time > 4 weeks from any supplier

##### Response Playbook
- Contain: Freeze new KES-denominated commitments and hedge the next scheduled Kenyan tranches with forward contracts.
- Assess: Re-run the Kenyan budget at current rates and list items with lead time above 4 weeks or a single source.
- Respond: Re-baseline with the funder, draw on the free technical reserve, or reduce Kenyan scope with the panel.


**STOP RULE:** If the currency fund and free technical reserve cannot cover the Kenyan build by Month 40 (2030-02-09), stop the Kenyan build and recommend a reduced Phase Three.

---

#### FM8 - The Protein That Failed the Spec

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Downstream Bioprocessing Engineer
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Nucleic acid reduction is harder than bench assumptions.
- Downstream energy rises above the 40 kWh/kg dry biomass baseline (estimate).
- Product misses nucleic acid <=2% of dry matter (estimate).
- Redesign costs EUR 0.2-0.5M and 2-4 months (estimate).
- Category pivot invalidates locked scenarios.

##### Early Warning Signs
- Bench nucleic acid above 3% after treatment
- Downstream step needs specialist skills
- Enzyme consumable cost above model
- Drying throughput limits batch output

##### Tripwires
- Nucleic acid > 3% of dry matter in any triplicate
- Downstream energy >= 30 kWh/kg usable protein
- Technician pass rate on downstream tasks < 90%

##### Response Playbook
- Contain: Fix the processing boundary and stop switching methods between batches.
- Assess: Measure yield, energy and nucleic acid for thermal and enzymatic routes on pilot biomass.
- Respond: Redesign the train, or have the panel approve a lower-bar product category at the Phase Two gate.


**STOP RULE:** If no method meets nucleic acid <=2% (or the category limit) at <=EUR 0.5M extra by the Phase Two gate (Month 30, 2029-04-09), recommend Research Only.

---

#### FM9 - The Protein Nobody Would Approve or Eat

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Strain Rights and Regulatory Affairs Specialist
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Authorities set stricter nucleic acid or safety-data limits.
- Kenya has no established pathway for the novel protein.
- Users distrust single-cell protein from a new programme.
- Cheaper soy, insect protein or proprietary hydrogen protein win.
- Category is rejected after hardware is built.

##### Early Warning Signs
- Authorities request a full formal dossier
- No written answer within 10 weeks
- User survey shows low acceptance
- Competitor price falls below locked thresholds

##### Tripwires
- No written authority feedback by Month 4 (2027-02-09)
- Stated nucleic acid limit < 2% of dry matter
- Fewer than 5 of 10 surveyed users accept the product

##### Response Playbook
- Contain: Hold the provisional product category lock until written authority feedback is logged.
- Assess: Map required safety data, cost and timeline per category and jurisdiction.
- Respond: Switch to a category with a lower regulatory bar or reposition the scenarios with the adopters and panel.


**STOP RULE:** If no category has a credible written pathway in Denmark/EU or Kenya by the Phase Two gate (Month 30, 2029-04-09), stop Phase Three hardware release.
