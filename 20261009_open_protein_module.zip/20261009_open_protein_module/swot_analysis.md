
## Strengths 👍💪🦾
- Clear public-good mission with open-source output; no dependence on one company or exporter.
- Staged design with kill gates, Go/Modify/Research Only/Stop outcomes and a EUR 50 million ceiling that is not a spending target (user constraint).
- Independent gate panel (3-5 members, EUR 0.30M, funder-managed) and published deviations guard against continuation by momentum.
- Pre-registered reactor selection rule, locked scenario thresholds and an audited assistance log make evidence credible.
- Proven route: commercial hydrogen-oxidizing protein exists and open work (AMYBO, passive gas feeding) gives a starting point.
- Conservative safety basis: gas inventory limits, <4% O2 in H2-rich stream, no hydrogen storage mandated.
- Strong risk mapping: strain rights, hazard analysis and Kenyan site baseline are front-loaded to Months 0-4 (2026-10-09 to 2027-02-09).

## Weaknesses 👎😱🪫⚠️
- KILLER APPLICATION MISSING: no single flagship use-case is yet proven to pull adoption. Three scenarios (reserve agency, feed producer, humanitarian container) are proposed but unsigned, and none is shown to beat protein reserves, legumes or insect protein.
- Deployment cost chain fails: full cost EUR 19.93/kg vs EUR 12 cap, a gap of EUR 7.93/kg (estimate). The EUR 274,820/yr gap has no funding route (open decision).
- High energy demand: about 40 kWh per kg dry biomass (range 25-60) (estimate) makes electricity price decisive.
- Partners, host, adopters, site, funding and permits are all unsigned.
- Strain, scale-up and nucleic acid performance remain unmeasured; downstream cost is likely underestimated.
- Hypothesis B (decentralized modules) demands specialist safety help, which conflicts with local repairability and the independence rules.
- Governance load (panel, auditors, defect tracker, site monitoring) is heavy for a small team.

## Opportunities 🌈🌐
- KILLER APPLICATION CANDIDATE: a containerized 50-100 kg/day module that gives governments or humanitarian agencies energy-independent emergency protein reserves. The unique pull is vendor independence plus local repairability during coinciding energy and food crises, where legumes and stored reserves are weak. Obstacles: cost gap vs EUR 12-15/kg caps, unsigned adopters, regulatory category for emergency nutrition, safety under a hydrogen-oxygen hazard, and unproven six-month uptime.
- Premium animal or fish feed in East Africa may tolerate higher cost than food, offering a second flagship route (Scenario B).
- Cheaper renewable electricity or solar coupling could cut the largest cost line.
- Collaboration with AMYBO, Solar Foods contacts, icipe and KEBS gives data, benchmarks and regulatory precedent.
- Open documentation and a certification mark could build a standard others adopt.
- Even a Research Only result yields valuable open knowledge on the cost of simplification.

## Threats ☠️🛑🚨☢︎💩☣︎
- Hydrogen-oxygen explosion or serious incident would halt permits and credibility.
- Strain, patent or Kenyan biosafety barriers could block lawful replication; a late strain switch (Phase Three) costs EUR 2-4M and 12-24 months, exceeding the Month 60 (2031-10-09) limit (estimate).
- Scale-up may fail on mass transfer, productivity or energy per kg; a successful reference unit does not prove industrial viability.
- Nucleic acid limits or novel-food rules may block the chosen product category.
- Adopter withdrawal, host priority shifts or reviewer fatigue.
- Falling prices of soy, fishmeal, insect protein or subsidised proprietary hydrogen protein.
- EUR/KES volatility on about EUR 4M of KES spend (estimate); Kenyan grid improving and weakening the stress test.

## Recommendations 💡✅
- Month 1 (2026-11-09): sign the Danish host MoU and engage an independent HAZOP/ATEX consultant; owner: project director. Issue the safety design basis by Month 2.5 (2026-12-24) and Adopter Change Boundary v0 by Month 3 (2027-01-09).
- Month 1.5 (2026-11-24): charter the funder-managed gate panel and lock the KPI framework; owners: funder and lead analyst.
- Months 0-4 (2026-10-09 to 2027-02-09): commission the patent search and strain-holder contacts, then deliver the Strain Feasibility Report (primary plus clean backup, Kenyan biosafety feedback) by Month 4 (2027-02-09); owner: legal/regulatory lead.
- Months 1-9 (2026-11-09 to 2027-07-09): pursue a killer-application test. Engage 2-3 named adopters, prioritising a reserve agency and a humanitarian container case. Obtain written cost-basis data, sign commitments by Month 7 (2027-05-09) and lock thresholds by Month 9 (2027-07-09); owner: adoption economist.
- Months 3-9 (2027-01-09 to 2027-07-09): run a cost-reduction study (electricity price, solar coupling, downstream energy) and decide the gap-funding route (adopter grant, subsidy or cost cut) before the Phase One release decision at Month 12 (2027-10-09); owners: TEA lead and funder.
- Hold hardware for the two reference units (EUR 4.0M) until the Phase Two gate; recommend a reduced Phase Three or Research Only if the cost chain still fails; owner: funder.

## Strategic Objectives 🎯🔭⛳🏅
- By Month 4 (2027-02-09), deliver a Strain Feasibility Report naming a primary and a legally clean backup strain with documented rights and written Kenyan biosafety feedback.
- By Month 9 (2027-07-09), lock 2-3 scenarios with named, signed adopters, each with cost, capacity and uptime thresholds, with at least one designated flagship killer-application scenario.
- By Month 9 (2027-07-09), show matched-reactor bench productivity of at least 90% of the published C. necator benchmark (pass; 70% to under 90% is a panel decision) and a modeled full cost path from EUR 19.93/kg toward the EUR 12 cap with uncertainty ranges (proposed threshold).
- By Month 10 (2027-08-09), complete the HAZOP, the independent interlock review and the reference-architecture decision, with panel recommendation published and release decision by Month 12 (2027-10-09).
- By Month 30 (2029-04-09), meet the Phase Two gate: kLa decline of 25% or less, 16-week strain stability within 10% variation, and 0 safety-critical unresolved documentation defects (proposed threshold).

## Assumptions 🤔🧠🔍
- Funding, host, Kenyan partner, adopters, sites and permits are uncontrolled until signed.
- Canonical figures apply: reference unit 20 kg dry biomass/day; deployment unit 100 kg usable protein/day at about EUR 3.0M (estimate).
- C. necator H16 or a similar public-collection strain is lawfully obtainable in Kenya (to be verified).
- Electricity at EUR 0.08/kWh is achievable at the deployment site (estimate).
- Gate reviewers can be recruited with real funding independence.
- Scenario thresholds (EUR 12, 10, 15/kg) are proposals, not requirements.

## Missing Information 🧩🤷‍♂️🤷‍♀️
- Signed host, Kenyan partner and funder agreements.
- Rights and patent status per candidate strain and jurisdiction.
- Measured bench productivity, kLa and energy per kg for each reactor concept.
- Adopter cost-basis data and willingness to pay a vendor-independence premium.
- Kenyan and EU regulator positions on nucleic acid limits and the emergency nutrition category.
- Downstream train energy and cost at pilot scale.
- Landed cost of imported inputs and electrolyzer membranes in Kenya.
- Verified benchmarks from Solar Foods and AMYBO with compatible boundaries.

## Questions 🙋❓💬📌
- Which single scenario would a named adopter actually pay for, and what evidence beats stored reserves, legumes or insect protein there?
- If the EUR 7.93/kg cost gap persists, who funds it, or should the project plan a reduced Phase Three or Research Only?
- What productivity loss from safety limits (<4% O2, low gas inventory) would you accept before the design no longer meets the thresholds?
- How will the panel's independence be verified, and what happens if the funder overrides a Stop recommendation?
- Which Kenyan site conditions would make the replication too harsh to attribute failures to design rather than logistics?