## 1. Strain Rights, Patent Freedom-to-Operate and Kenyan Biosafety Feasibility

Strain rights and Kenyan biosafety feasibility are project-blocking risks. A late discovery that the primary strain is not lawfully obtainable in Kenya or faces third-party patent claims forces a fallback strain switch in Phase Two or Three, costing EUR 0.2–4M and 6–24 months. Front-loading this work to Months 0–4 (2026-10-09 to 2027-02-09) de-risks the critical-path item and allows contingency activation before design is committed.

### Data to Collect

- Written confirmation from ≥4 candidate strain holders on lawful use rights per jurisdiction (research, commercial production, redistribution, modification, derived strains)
- Patent landscape search results covering hydrogen fermentation, autotrophic protein, and each candidate strain in Denmark/EU, Kenya and Bangladesh with third-party claims identified and freedom-to-operate risk scored
- Written pre-submission feedback from Kenya's National Biosafety Authority on strain classification, contained-use permitting and import restrictions for each candidate strain
- Strain productivity baseline (volumetric productivity, growth rate, oxygen-uptake rate, nucleic acid content %) for primary and backup candidates under identical conditions
- Contingency decision rule naming fallback strain and trigger conditions (e.g., 'if primary moves to medium risk by Month 8 = 2027-06-09, switch to backup without panel review; if high risk, escalate immediately')

### Simulation Steps

- Use patent office databases (WIPO, USPTO, EPO, Kenya's IP office) and patent-search software (e.g., Espacenet, Google Patents) to search hydrogen fermentation, autotrophic protein and strain-specific patents; compile a freedom-to-operate risk score per strain and jurisdiction by Month 2 (2026-12-09)
- Contact strain holders via email and telephone to request written confirmation of use-rights; model response time using publicly available strain-holder contact data; consolidate responses in a legal spreadsheet by Month 1.5 (2026-11-24)
- Conduct bench-scale growth experiments on candidate strains under 30°C, pH 7.0–7.2, defined medium, measuring specific growth rate (1/h), volumetric productivity (g/L/day) and nucleic acid content (% dry matter) over 7–10 days to steady state using standard analytical methods (OD600, HPLC, 16S rRNA qPCR); compare results to published C. necator H16 data

### Expert Validation Steps

- Commission a specialized biotech patent-search firm (e.g., a Danish or European law firm with biotech and African IP experience) to deliver a formal freedom-to-operate landscape report by Month 2 (2026-12-09); firm must assess likelihood of third-party blocking in each jurisdiction
- Engage Kenya's National Biosafety Authority via informal pre-submission consultation (Month 2.5 = 2026-12-24); request written feedback on strain classification and import feasibility by Month 4 (2027-02-09); use a Kenya-based regulatory advisor or lawyer to interpret feedback and assess biosafety risk
- Appoint an independent biotech counsel (not employed by the project or host institution) to review all strain-holder responses, patent-search findings and biosafety feedback by Month 3.5 (2027-01-24) and consolidate into a 'Strain Feasibility Report' by Month 4 (2027-02-09) with written sign-off on legal clearance

### Responsible Parties

- Strain Rights and Regulatory Affairs Specialist (lead, 60% FTE in Phase One)
- Biotech patent-search firm (external consultant, commissioned Month 1 = 2026-11-09)
- Kenya-based regulatory advisor or lawyer (external consultant, Month 2 = 2026-12-09)
- Independent biotech counsel (external, non-project-employed, review and sign-off)

### Assumptions

- **High:** Strain holders respond to written requests within 4–6 weeks and provide explicit written confirmation of use-rights or identify barriers that trigger contingency activation.
- **High:** Kenya's National Biosafety Authority provides pre-submission feedback within 8–10 weeks of informal submission; feedback is binding or near-binding for determining import feasibility.
- **High:** At least one candidate strain (primary or backup) has no blocking patent claims and is lawfully importable into Kenya for contained use and commercial research.
- **Medium:** Candidate strain productivity (volumetric yield, growth rate, nucleic acid content) is measurable under standardized conditions and published data for C. necator H16 provide an adequate benchmark for comparison.
- **Medium:** A legally clean backup strain exists and can be activated within 3–4 weeks if the primary strain is blocked, without re-running the full Phase One productivity comparison.

### SMART Validation Objective

By Month 4 (2027-02-09), deliver a signed 'Strain Feasibility Report' naming a primary and a legally clean backup strain with: (1) written strain-holder confirmation of lawful use in Denmark and Kenya; (2) patent-search findings confirming freedom-to-operate or identifying third-party claims; (3) written Kenya biosafety pre-submission feedback confirming import and contained-use feasibility; (4) productivity baseline for each strain relative to published C. necator H16 data (within ±20% uncertainty); (5) contingency trigger rule. Gate entry prohibited without this report or explicit escalation to the independent panel.

### Notes

- Front-load strain-holder contact to Month 0–1 (2026-10-09 to 2026-11-09) to allow response time; do not wait until Month 2–3 (2026-12-09 to 2027-01-09) to initiate contact.
- Patent search must include jurisdiction-specific restrictions (e.g., royalty obligations, derived-strain limitations) not just binary patent existence.
- Kenya biosafety feedback may take 8–10 weeks; submit informal inquiry by Month 2 (2026-12-09) to meet Month 4 (2027-02-09) deadline.
- If primary strain is blocked, activate backup and set trigger for contingency fund allocation (EUR 0.1–0.2M, Months 3–5 = 2027-01-09 to 2027-03-09) before the Phase One gate.
- Document all strain-holder, patent and regulatory correspondence in a shared repository accessible to the independent gate-review panel for transparency.


## 2. Safety Design Basis and ATEX Compliance Strategy (Hydrogen-Oxygen Hazard Control)

Hydrogen-oxygen explosion hazard is the single highest-consequence safety risk and must be managed by a locked design basis, not evolved reactively. A formal HAZOP/LOPA before reactor selection prevents a design (e.g., pressurized stirred reactor) being chosen for productivity, then discovering ATEX complexity that makes it unsuitable. Pre-locked limits ensure all three reactor concepts operate within the same safety envelope, making the comparison fair on productivity alone. Independent ATEX validation protects the project and the replicators from liability if an unsafe local adaptation occurs.

### Data to Collect

- Formal Process Hazard and Operability Analysis (HAZOP) or Layers of Protection Analysis (LOPA) identifying all failure modes (electrolyzer malfunction, gas-line rupture, seal failure, backflow on power loss, operator error) and assigned design responses
- Quantified safety targets (e.g., probability of uncontrolled ignition <1 per 100,000 operating hours) and derived gas composition limits (e.g., <4% O₂ in H₂-rich stream) and inventory ceilings (e.g., <0.5 m³ H₂, <0.2 m³ O₂) that keep the process outside flammable ranges without relying on instrumentation
- Independent ATEX design-basis review confirming gas limits are consistent across all three matched reactor concepts (pneumatic, stirred, passive-feed) so safety is not a hidden advantage of one design
- Preliminary Adopter Change Boundary document explicitly naming which design components and parameters are safe for local modification without re-certification and which require full safety re-analysis
- Pre-operational safety audit of the Danish reference unit (Month 38 = 2029-12-09) and the Kenyan replication unit (Month 50 = 2030-12-09) before production runs begin

### Simulation Steps

- Commission a formal HAZOP or LOPA workshop (Month 1 = 2026-11-09) using industry-standard methodology (e.g., guided-keyword approach per IEC 61882 or LOPA per ANSI/ISA 84.00.1); document all failure modes, consequences (severity) and likelihood, then assign design responses (inherent elimination, design change, or layered control)
- Use published hydrogen-oxygen flammability envelopes (Khovakh diagram or similar) to map safe gas-composition limits (stoichiometry, lower/upper flammable limits); model gas-mixing scenarios in fermentor headspace using CFD or simplified mass-balance to confirm that the designed limits prevent ignitable mixtures without instrumentation
- Run simplified bench-scale experiments to verify that the preliminary gas-composition and inventory limits do not prevent target volumetric productivity; measure gas-phase composition, hold-up volume and gas residence time in each of the three reactor concepts under operating conditions; confirm all three can operate within the safety envelope without >20% productivity penalty

### Expert Validation Steps

- Engage an independent, ATEX-certified safety consultant (no prior project involvement, no employment ties to host institution) to conduct the formal HAZOP/LOPA by Month 2 (2026-12-09) and issue a signed report identifying all hazards, ranked failure modes and recommended design basis
- Appoint a second independent ATEX reviewer (or have the primary consultant arrange independent peer review) to assess whether the derived gas limits are defensible and consistent with ATEX Annex II or Annex III machinery-safety requirements and pressure-equipment directive for EU; produce a written compliance opinion by Month 2.5 (2026-12-24)
- Convene a technical review with the lead process engineer, the ATEX consultant and the safety engineer (internal) to confirm that all three reactor concepts are designed within the gas-composition and inventory limits and that the safety design basis is locked before reactor selection rules are applied (Month 2.5 = 2026-12-24); document consensus in writing

### Responsible Parties

- Independent ATEX-certified safety consultant (external, commissioned Month 0.5 = 2026-10-24)
- Internal Process Safety Engineer (40–50% FTE in Phase One, oversees HAZOP and design basis integration)
- Lead Process Engineer (ensures reactor designs conform to safety limits; 50% FTE Phase One)
- Independent ATEX peer reviewer or second ATEX consultant (external, Month 2 = 2026-12-09)

### Assumptions

- **Medium:** A formal HAZOP/LOPA identifying all failure modes and design responses can be completed within 4–6 weeks (Month 1–2 = 2026-11-09 to 2026-12-09) by an experienced team.
- **High:** The gas composition and inventory limits derived from hazard analysis are sufficient to keep the process outside flammable ranges under all normal and abnormal operating conditions (e.g., backflow on power loss, seal failure, temperature excursion).
- **Medium:** All three reactor concepts (pneumatic, stirred, passive-feed) can operate within the derived safety limits without >20% loss of volumetric productivity relative to the unconstrained design.
- **Medium:** An independent ATEX reviewer can confirm compliance with EU machinery safety and pressure-equipment directives; this is a necessary step before releasing the design to adopters, but does not require formal CE marking unless a commercial unit is built.
- **Low:** The Adopter Change Boundary (which components and parameters are safe to modify) can be defined in Month 2.5 (2026-12-24) based on preliminary reactor designs and the safety basis; it may be refined after Phase II pilot data, but the core list is locked before replicators begin.

### SMART Validation Objective

By Month 2.5 (2026-12-24), deliver a signed 'Design Basis for Safety' document specifying: (1) quantified safety targets (e.g., ignition probability <1/100,000 h); (2) gas composition limits (e.g., <4% O₂ in H₂-rich or >60% inert); (3) gas inventory limits (e.g., <0.5 m³ H₂, <0.2 m³ O₂); (4) safe-shutdown protocol (vent within 30 s, interlocks defined); (5) statement that all three reactor concepts can operate within these limits without >20% productivity penalty; (6) independent ATEX reviewer's compliance opinion. Freeze this document before reactor selection or detailed design begins.

### Notes

- HAZOP must be conducted by experienced facilitators using guideword methodology (e.g., ISO 61882 or ASME/ANSI approach); assign 3–5 days for workshop plus 2–3 weeks for report documentation.
- Gas-composition and inventory limits are the core design constraints; all subsequent design decisions (reactor type, control strategy, component selection) must respect these limits, not override them.
- Document all HAZOP findings (failure modes, consequences, design responses) in a traceability matrix so each design decision can be traced back to a hazard mitigation.
- Independent ATEX validation is non-negotiable; do not proceed without external sign-off from an ATEX-certified consultant independent of the project team.
- Publish the Design Basis for Safety as part of Phase One gate deliverables so the independent gate-review panel can assess whether safety governance is credible.


## 3. Matched Reactor Concept Comparison (Bench-Scale Productivity and Mass-Transfer Validation)

The matched reactor comparison is central to the plan's claim that measurement decides between high-productivity (pressurized stirred) and simple (pneumatic) designs. A credible comparison requires identical conditions, a single analyst to minimize variation, pre-registered decision thresholds, and external audit. Without these controls, researcher degrees of freedom in data interpretation could bias the result toward a preferred concept. The volumetric productivity and mass-transfer coefficient data feed into the scale-up model and the deployment cost; without this evidence, the scale-up assumptions remain unvalidated.

### Data to Collect

- Volumetric productivity (g dry biomass per liter per day) for pneumatic loop, pressurized stirred, and passive-feed reactors under identical conditions (identical strain, media, 30°C, pH 7.0–7.2, 7–14 days to steady state)
- Mass-transfer coefficient (kLa in h⁻¹) for each reactor derived from gas balance (inlet H₂ and O₂ flow rates, gas-phase composition analysis, liquid-phase dissolved O₂ measurement) and oxygen-uptake rate (mmol/L/h) measured via gas chromatography
- Energy per kg dry biomass (kWh/kg) for electrolyzer, aeration and mixing for each reactor concept; system boundary defined and locked before experiments begin
- Culture purity verification (>99% target strain, confirmed by culture plating, microscopy or 16S rRNA PCR) and strain stability over 7–14 day run (no morphology change, no productivity decline)
- Reactor concept selection decision with pre-registered thresholds applied and external audit signed

### Simulation Steps

- Set up three bench-scale bioreactors (500 mL–1 L each): one pneumatic loop (sparger-only gas delivery), one pressurized stirred tank (mechanically agitated, controlled O₂/H₂ inlet), one passive bubble-column or diffusion-fed reactor. Inoculate each with the same reference strain culture (10% v/v inoculum, OD600 ~0.5–1.0 at start) into identical medium (inorganic medium with H₂/CO₂/air gas phase, pH buffered). Operate all three at 30°C ±1°C for ≥7 days (or until steady-state growth is observed, typically day 5–7); measure dissolved O₂, pH, gas outlet composition (H₂, O₂, CO₂) every 12–24 h using gas chromatography; measure culture density (OD600) daily; plate culture samples (day 0, 4, 7) to verify purity.
- Calculate volumetric productivity as (biomass concentration at day 7 – biomass at day 1) / 6 days / reactor volume in g/L/day. Derive kLa from oxygen balance: measure inlet and outlet gas flows and O₂ concentrations; assume oxygen-uptake rate is the difference (corrected for gas solubility and reactor volume); fit a first-order kinetic model to dissolved O₂ time-course data if dynamic methods are available. Energy per kg = (electrolyzer power + aeration power + stirring power) / (biomass produced) in kWh/kg. Assign a single analyst responsible for all sampling and measurements across all three reactors to minimize inter-operator variation.
- Use standard laboratory tools: gas chromatography (GC) with thermal conductivity or flame ionization detector for H₂, O₂, CO₂; dissolved-O₂ probe (calibrated daily); pH meter; OD600 spectrophotometer; balance for dry-biomass gravimetry (samples collected, washed, dried at 105°C for 24 h); 16S rRNA PCR (if purity verification by plating is equivocal). Run each reactor concept in triplicate (n=3) so results can be reported as mean ± standard deviation.

### Expert Validation Steps

- Appoint an external technical auditor (not employed by the project or host institution) to review the experimental protocol before Months 2–3 (2026-12-09 to 2027-01-09) experiments begin; auditor must sign off on KPI definitions, reactor-selection decision rule (pre-registered thresholds), analytical methods and sampling frequency.
- Have the auditor conduct a mid-experiment review (Month 5 = 2027-03-09) to verify that protocol deviations (contamination, equipment malfunction, analytical drift) are documented and that exclusion decisions follow the pre-registered rule (e.g., 'exclude a run only if contamination confirmed; do not exclude for productivity outliers without investigation').
- Require the auditor to produce a written 'Protocol Compliance and Decision Audit' by Month 6 (2027-04-09) confirming that: (1) all three reactor concepts were run in triplicate under identical conditions; (2) the single lead analyst maintained consistent methods; (3) all deviations are documented; (4) the pre-registered decision rule was applied without retroactive adjustment; (5) the results are defensible for gate-review panel presentation.

### Responsible Parties

- Lead Process Engineer (owns the reactor-selection decision, 50% FTE in Phase One, supervises experiments)
- Single Lead Analyst (100% for Months 2–6 = 2026-12-09 to 2027-04-09, all sample preparation and analysis)
- Biotech Microbiologist or Fermentation Specialist (50% FTE, strain preparation, inoculation, culture monitoring)
- External Technical Auditor (commissioned Month 1.5 = 2026-11-24, protocol sign-off, mid-experiment review, final compliance audit)

### Assumptions

- **Medium:** Volumetric productivity of the reference strain (C. necator H16 or backup) under standardized conditions is measurable within ±15% uncertainty and can be compared against published data with a clear pass/fail threshold (≥90% of published benchmark = pass).
- **Medium:** Mass-transfer coefficient (kLa) is derivable from gas-phase composition and oxygen-balance measurements without resort to complex dynamic methods; uncertainty ±20% is acceptable for design comparison.
- **Medium:** The three reactor concepts (pneumatic, stirred, passive-feed) can be run side-by-side under identical conditions without cross-contamination or mutual interference; 500 mL–1 L scale is large enough for reliable measurement but small enough to commission in 4–6 weeks.
- **High:** The pre-registered decision rule (if productivity differs <15%, choose simpler; 15–25%, weighted score; >25%, highest productivity) is defensible and will not require retroactive adjustment after data arrive.
- **Low:** External audit of the protocol and decision threshold application is feasible and does not delay publication of results by >1–2 weeks; auditor's recommendation can be accommodated in the Phase One gate timeline (Month 9 = 2027-07-09).

### SMART Validation Objective

By Month 6 (2027-04-09), execute three bench-scale reactor concepts in triplicate (n=3 each) under identical conditions (strain, media, 30°C, pH 7.0–7.2, 7–14 days); measure volumetric productivity (g/L/day, target ≥90% of C. necator H16 published data with ±15% uncertainty), kLa (h⁻¹), oxygen-uptake rate (mmol/L/h) and culture purity (>99%); report results as mean ± SD with external audit confirmation that protocol was followed and decision thresholds applied without adjustment; announce reactor selection via the independent gate-review panel recommendation by Month 9 (2027-07-09).

### Notes

- Lock the 'Measurement and KPI Framework' (exact definitions, methods, analytical standards) by Month 1.5 (2026-11-24) before experiments begin; do not adjust definitions or methods after data arrive.
- Assign a single lead analyst (dedicated 100% to this task Months 2–6 = 2026-12-09 to 2027-04-09) to prepare and analyze all samples for all three reactors, minimizing inter-operator variation (typical source of 20–30% scatter in fermentation data).
- Run each reactor concept in triplicate (not single runs); report mean ± standard deviation; exclude outliers only if a clear experimental reason exists (contamination, instrument malfunction) documented in the audit trail.
- Document all protocol deviations (e.g., equipment downtime, analytical drift, missed sampling) in a daily lab notebook; escalate any deviation that could affect data quality to the external auditor immediately.
- Publish all raw data (daily measurements, sample identities, analytical certificates) in supplementary material; ensure full transparency so external reviewers can re-analyze if needed.


## 4. Kenyan Operating Envelope Baseline and Quarterly Monitoring

The Kenyan site must genuinely test the defined harsh operating envelope (grid outages, water-quality variability, local supply chains, available skills) for hypothesis B evidence to be credible. A site chosen for convenience (e.g., a university with stable power) will pass tests that a real deployer under difficult infrastructure would fail, invalidating the claim that the design works for food-supply disruptions. Independent baseline measurement and quarterly monitoring ensure envelope conditions are documented and drift is detected early, allowing contingency adjustments (e.g., controlled stressor outages) to maintain testing realism.

### Data to Collect

- Grid power outage frequency, duration and seasonal pattern over 24–36 months historical utility records; target baseline: ≥4 unplanned outages per month, mean ≥2 h, ≥1 outage per quarter >8 h
- Water supply quality (turbidity, conductivity, pH, iron and manganese content, seasonal variation) measured monthly for 3–4 months; required range: turbidity <10 NTU, pH 6.5–7.5, conductivity ±20% of process medium specification
- Ambient temperature and relative humidity measured quarterly or continuously; target range: 15–30°C (not hard requirement, but documented)
- Spare-part availability and lead times for critical items (electrolyzer membranes, fermentor seals, PLC components, analytical consumables) from local and regional suppliers; target: ≤2–4 week lead time from ≥2 suppliers per critical item
- Inventory of locally available technical skills (electricians, mechanics, laboratory technicians) with education level, prior experience and willingness to participate in project training; target: ≥2–3 technicians per trade (electrical, mechanical, laboratory)

### Simulation Steps

- Contact Kenya's primary utility (Kenya Power and Lighting Company) and obtain 24–36 months of documented outage logs; extract outage dates, times, durations and causes if available. Use publicly available meteorological data (e.g., Kenya Meteorological Department) to assess seasonal patterns (rainy season effects on supply reliability). Model outage frequency distribution (histogram of duration) to confirm target of ≥4 outages/month and mean duration ≥2 h; if baseline data show better reliability, plan to add controlled stressor outages (brief planned load shedding) in Phase III to maintain testing realism.
- Conduct water-quality sampling from the proposed Kenyan site's water source (borehole, municipal supply, or rainwater) monthly for 3–4 months; measure turbidity (nephelometer), conductivity (conductivity meter), pH (pH meter), and iron/manganese (atomic absorption spectroscopy or colorimetric method). Compare results to process medium requirements (e.g., if demineralized water is needed, assess pre-treatment feasibility and cost). If seasonal variation exceeds ±20% on key parameters, plan for water pre-treatment or assess impact on culture stability.
- Identify all critical spares and consumables needed for the Phase III reference unit (electrolyzer replacement membranes, fermentor O-rings and seals, PLC components, HPLC columns and mobile phases, gas chromatography supplies) and conduct a supplier-availability survey: contact ≥2 potential suppliers (local Nairobi, regional East Africa, international import) for each item; record lead time, minimum order quantity, cost and reliability. For items with >4 week lead time or single-source risk, plan for Phase III stockpiling (3–6 month inventory) or alternative-supplier negotiation.

### Expert Validation Steps

- Commission an independent site-selection consultant (not employed by the Kenyan partner, with experience in East African site evaluation and infrastructure assessment) to conduct the Kenyan Operating Envelope Baseline Study during Months 1–4 (2026-11-09 to 2027-02-09); consultant must verify utility records, conduct water-quality testing and interview local suppliers and technician candidates in person.
- Require the consultant to produce a signed, time-stamped 'Kenyan Operating Envelope Baseline Report' by Month 4 (2027-02-09) stating measured values for each envelope parameter and assessment of whether the site meets defined targets (≥4 outages/month, water quality within range, spares lead time ≤2–4 weeks, ≥2–3 technicians/trade available). Explicitly state any shortfalls and contingency actions (e.g., 'power is more reliable than target; plan to add controlled stressor outages').
- Establish a 'Quarterly Site Envelope Monitoring Protocol' by Month 6 (2027-04-09) to be executed by the Kenyan site manager and audited by the independent auditor: (1) monthly collection of power outage logs from the utility; (2) quarterly water-quality sampling; (3) quarterly technician competence checks; (4) semi-annual supplier queries on spare-part availability and lead times. Flag any parameter that drifts >20% from baseline and trigger contingency actions (e.g., add controlled outages if power becomes more reliable; adjust cost model if spares become more expensive).

### Responsible Parties

- Independent Site-Selection Consultant (external, Month 1–4 = 2026-11-09 to 2027-02-09, baseline study and report)
- Kenyan Co-Development Partner Site Manager (50% FTE from Month 6 = 2027-04-09 onward, executes quarterly monitoring)
- Independent Auditor (external, reviews defect tracker and site-envelope data monthly, assesses patterns)

### Assumptions

- **Medium:** Kenya's utility company maintains and provides 24–36 months of outage logs with dates, times and durations; records are accurate and representative of conditions the replication team will experience.
- **High:** The proposed Kenyan site is accessible for water-quality sampling and supplier interviews; conditions at the site are representative of the target deployment environment (not a showcase location with unusual advantages).
- **Medium:** Spare-part suppliers in Nairobi and East Africa can deliver critical items (electrolyzer membranes, PLC components, analytical consumables) within 2–4 weeks; if lead times are longer, Phase III will stock consumables or identify backup sources.
- **Medium:** At least 2–3 technicians per trade (electrical, mechanical, laboratory) are available locally, have basic training (secondary education or vocational diploma), and are willing to participate in project-sponsored training.
- **Low:** Site envelope conditions remain stable ±20% during the Phase II–III period (Months 12–54 = 2027-10-09 to 2031-04-09); if conditions drift significantly (e.g., grid power becomes more reliable, supplier lead times increase), contingency actions (controlled stressors or cost updates) are feasible within the project timeline.

### SMART Validation Objective

By Month 4 (2027-02-09), deliver a signed 'Kenyan Operating Envelope Baseline Report' specifying: (1) grid outage frequency ≥4/month and mean duration ≥2 h (measured from utility logs); (2) water-quality ranges (turbidity, pH, conductivity, iron); (3) spare-part lead times ≤2–4 weeks from ≥2 suppliers for critical items; (4) confirmed available local technicians (≥2–3 per trade). Implement 'Quarterly Site Envelope Monitoring Protocol' by Month 6 (2027-04-09); flag any drift >20% from baseline; document all contingency actions (stressor outages, cost adjustments) transparently in annual reports.

### Notes

- Site selection should be independent of the Kenyan partner's organizational location; prioritize a site that genuinely tests the defined envelope, not a convenient or well-equipped location.
- Baseline report must be time-stamped and signed by the independent consultant; it becomes the reference against which Phase III actual conditions are measured and reported to external reviewers.
- Quarterly monitoring data (power logs, water samples, technician feedback) are the responsibility of the Kenyan site manager and are audited monthly by the independent auditor; delays in data collection or analysis are escalated as risks.
- If power becomes more reliable mid-project (e.g., grid improvements), add controlled stressor outages (brief planned load shedding with utility coordination) to maintain the intended stress test; document the decision and publish it in annual reports.
- If spare-part lead times exceed 4 weeks or prices increase significantly, update the cost model and escalate to the funder; assess whether the deployment scenario assumptions need revision.


## 5. Deployment Scenario Definition and Adopter Engagement (Locked Thresholds with Named Signatories)

Deployment scenarios locked to hypothetical thresholds without real adopter signatures are vulnerable to post-hoc rationalization. If a scenario is unsigned, thresholds can be adjusted after Phase III results to declare success. Named adopters with signed commitments anchor the thresholds and make a Go decision evidence-based: either the technology meets locked thresholds with a named adopter's commitment, or it does not and the outcome is Modify or Research Only. Adopter cost-basis data (current supply cost, willingness to pay a premium) validates that the thresholds reflect real deployment economics, not internal assumptions.

### Data to Collect

- Cost-basis data from prospective adopters: current protein supply cost (EUR/kg), supply-chain documentation, production-capacity need (kg usable protein/day), required uptime (%), acceptable cost premium for vendor independence and local repairability
- Written scenario profiles naming 2–3 prospective adopters, specifying locked cost, capacity and uptime thresholds, and stating the adopter's willingness to use the open design at each cost level (e.g., EUR 12/kg, EUR 15/kg) and any conditions (subsidy availability, regulatory category)
- Signed Deployment Scenario Specification document time-stamped at Month 9 (2027-07-09) with immutability clause stating scenarios are locked unless all parties formally agree in writing to change them
- Adopter withdrawal clause specifying that any adopter withdrawal is published to all stakeholders and the independent gate-review panel is re-briefed on whether remaining scenarios remain credible for a Go decision
- Transparency note on threshold derivation for each scenario: whether thresholds are based on adopter cost-basis data, published benchmarks on protein reserves or legumes, or other sources

### Simulation Steps

- Identify 2–3 candidate prospective adopters with published mandates in food security, livestock nutrition or humanitarian logistics (e.g., Kenya Strategic Food Reserve, an East African feed producer cooperative, World Food Programme logistics operation). Search for organizational reports, government food-security policies, or humanitarian logistics plans; target organizations with decision-making authority and a track record of technology adoption.
- Conduct structured in-person or virtual interviews with each adopter (Months 2–4 = 2026-12-09 to 2027-02-09) to capture: (1) current protein-supply source and cost (EUR/kg), with supporting documentation (procurement invoices, annual budgets, supply-chain maps); (2) production-capacity requirement (kg usable protein/day or annual tonnes); (3) required uptime (% of 365 days/year); (4) operating-environment constraints (power reliability, water availability, technician skills, spare-part access in the target region); (5) willingness to pay a premium for vendor independence and local repairability, and any conditions (e.g., 'we can adopt at EUR 12/kg; at EUR 15/kg only if a government subsidy covers the gap'; 'we need ≥90% uptime for deployment viability').
- Create scenario profiles from adopter input: e.g., Scenario A (reserve agency): EUR 12/kg cap, ≥100 kg/day, ≥95% uptime; Scenario B (feed producer): EUR 10/kg, ≥500 kg/day (5 modules × 100 kg/day), ≥90% uptime; Scenario C (humanitarian): EUR 15/kg, ≥50 kg/day, 40-foot container compatible. For each scenario, compute cost sensitivity: 'If cost is EUR 12/kg, adoption is viable. If EUR 15/kg, adoption requires [subsidy / government support / reduced capacity]. If EUR 19/kg, adoption is not credible.'

### Expert Validation Steps

- Assign an adoption economist or scenario lead (50% FTE in Phase One) to identify candidate adopters, conduct interviews, consolidate adopter input and draft scenario profiles.
- Present draft scenario profiles to each adopter for validation and feedback (Month 6 = 2027-04-09); request written response confirming their cost-basis data, threshold accuracy and willingness to proceed to signed commitment.
- Require each adopter to sign a scenario commitment document by Month 7 (2027-05-09) stating: (1) their locked cost, capacity and uptime thresholds; (2) their understanding that thresholds are immutable through Phase Three unless all parties formally agree in writing to change them; (3) a withdrawal clause specifying that any withdrawal is published and the gate panel is re-briefed. Publish all signed commitments to the independent gate-review panel and to all project stakeholders.
- Convene the independent gate-review panel for a specialized assessment of adopter credibility and scenario realism (Month 9 = 2027-07-09); require the panel to produce a written opinion: 'Are these scenarios realistic and credible? Are the adopters genuinely committed or hypothetically engaged? Are the thresholds defensible against published alternatives?' Panel opinion is published alongside the locked scenarios.

### Responsible Parties

- Adoption Economist or Scenario Lead (50% FTE Phase One, identify adopters, conduct interviews, consolidate profiles, manage signed commitments)
- Kenyan Co-Development Partner (identifies locally-embedded adopter contacts and provides introductions)
- Independent Gate-Review Panel (Month 9 = 2027-07-09, assesses adopter credibility and scenario realism)

### Assumptions

- **Medium:** 2–3 prospective adopters with published food-security or logistics mandates can be identified and are willing to participate in confidential cost-basis and threshold discussions (Months 2–7 = 2026-12-09 to 2027-05-09).
- **High:** Adopter cost-basis data (current protein cost, capacity need, uptime requirement) are accurately documented or auditable, allowing thresholds to be derived from real deployment economics rather than assumptions.
- **Medium:** Named adopters commit in writing to locked thresholds and remain committed through Phase Three unless they formally withdraw; withdrawals are published and do not silently invalidate the scenario.
- **Low:** The independent gate-review panel can assess adopter credibility and scenario realism and produce a written opinion that gives external stakeholders confidence in the scenarios' validity.
- **Medium:** If an adopter withdraws before Phase Three, remaining scenarios (if any) remain credible for a Go decision, or the withdrawal is treated as grounds for reconsidering the recommendation (Modify, Research Only, or Stop).

### SMART Validation Objective

By Month 7 (2027-05-09), obtain signed scenario commitments from 2–3 named adopters specifying locked cost, capacity and uptime thresholds; by Month 9 (2027-07-09), finalize and time-stamp the 'Deployment Scenario Specification' document with all adopter signatures, rationale for thresholds and immutability clause. Present scenarios to the independent gate-review panel for credibility assessment; require panel's written opinion that scenarios are realistic and adopters are credibly committed. Scenarios are immutable except by all parties' written agreement, which is published to all stakeholders.

### Notes

- Identify adopter candidates by Month 1 (2026-11-09) and confirm interest by Month 2 (2026-12-09); conduct cost-basis interviews Months 2–4 (2026-12-09 to 2027-02-09); present scenario profiles Month 6 (2027-04-09); obtain signatures Month 7 (2027-05-09); lock and publish Month 9 (2027-07-09).
- Cost-basis data must be auditable (invoices, budget documents, supplier quotes) or at least documented by the adopter in writing; do not use internal assumptions or published averages as substitutes for real adopter data.
- Signed commitment document should include a clause: 'We understand that by signing this scenario we commit to participating in gate-review discussions and to providing feedback on the design as it matures; we will withdraw only if our organizational mandate or capability fundamentally changes, and we will notify the project immediately with written notice.'
- Designate at least one scenario as the 'killer-application' case that is most likely to pull adoption (e.g., a reserve agency with explicit government backing or a humanitarian organization with pre-committed funding).
- If any adopter withdraws, publish the withdrawal reason and date; the panel is re-convened to assess whether remaining scenarios suffice for a Go decision at the Phase Three gate.


## 6. Cost-Reduction Study and Gap-Funding Route Decision (Deployment Economics Validation)

The EUR 7.93/kg cost gap is the single largest threat to project viability; without a credible cost-reduction path or a named gap-funding source, all three locked scenarios fail and the Phase Three Go decision becomes impossible despite technical success. A cost-reduction study conducted in Phase One (Months 3–9 = 2027-01-09 to 2027-07-09) identifies which levers are most sensitive and achievable, allowing funder and adopters to make an informed decision before Phase Two design commitment. If solar electricity or downstream simplification can credibly close the gap, Phase Two can prioritize validation of those assumptions. If not, the project can recommend Research Only and preserve credibility rather than forcing Phase III on a failed business case.

### Data to Collect

- Current cost model baseline: full production cost EUR 19.93/kg usable protein (Scenario A cap EUR 12/kg), cost gap EUR 7.93/kg (EUR 274,820/yr for modeled 100 kg/day unit), no funding route assigned
- Sensitivity analysis on major cost drivers: electricity cost (range EUR 0.05–0.15/kWh); downstream energy (harvest, cell disruption, nucleic acid reduction, drying); modular-deployment scale (10 units of 10 kg/day vs. 1 unit of 100 kg/day)
- Cost-reduction pathways identified: (1) solar-coupled electricity with battery or demand-shifting (target EUR 0.05–0.06/kWh vs. assumed EUR 0.08/kWh); (2) simplified downstream processing (target 10–15 kWh/kg usable protein vs. assumed 20 kWh/kg); (3) modular capex leverage for smaller deployment units
- Gap-funding route decision: either (a) a named grant provider and signed commitment to cover EUR 3.0M capex gap, or (b) a redesigned lower-capacity unit that fits EUR 12/kg cap, or (c) acknowledgment that a Research Only outcome is credible if neither option materializes
- Uncertainty ranges on all cost assumptions; sensitivity of the EUR 12/kg threshold to ±10%, ±20% variations in major cost drivers

### Simulation Steps

- Build a detailed techno-economic model (spreadsheet-based) incorporating: electrolyzer capex and efficiency (kWh H₂ per kWh electricity input), fermenter capex and operating cost, downstream processing (harvest energy, cell disruption energy, nucleic acid reduction energy, drying energy), nitrogen source and mineral costs, water treatment, analytical consumables, labour, facility overhead (depreciation, maintenance), debt service (assume 100% of capex, 5%, 15-year term). Baseline values from canonical facts: 40 kWh electricity per kg dry biomass, EUR 0.08/kWh, EUR 3.0M capex. Run the model for 100 kg/day deployment unit at 95% utilization (34,675 kg usable protein/yr).
- Conduct Monte Carlo sensitivity analysis on major cost drivers: (1) vary electricity price from EUR 0.05 to 0.15/kWh (±0.03/kWh range, representing on-site solar vs. grid worst-case); (2) vary downstream energy from 10 to 30 kWh/kg usable protein (±50% range, representing simplified vs. comprehensive processing); (3) vary capex from EUR 2.0M to 8.0M (±60% range, representing learning curve and modular scaling); (4) vary utilization from 80% to 98% (seasonal variation). For each sensitivity case, recalculate total production cost per kg and distance to the EUR 12/kg cap.
- Model three deployment scenarios: (A) 100 kg/day single unit (capex EUR 3.0M, efficiency assumption); (B) 10 units of 10 kg/day each (capex per unit EUR 0.5M × 10 = EUR 5.0M total = 67% higher due to loss of scale economy, per canonical facts); (C) 50 kg/day module x 2 (capex EUR 1.8M × 2 = EUR 3.6M, intermediate scale). For each scenario, calculate cost per kg usable protein under base-case assumptions and under cost-reduction assumptions.

### Expert Validation Steps

- Assign a Techno-Economic Modeler (40% FTE in Phase One, 60% in Phase Two) to build and maintain the cost model and sensitivity analyses.
- Commission a second independent cost-analysis review by an external techno-economic consultant (not employed by the project, EUR 40,000–60,000 estimate) to audit the model structure, validate assumptions against published data on hydrogen fermentation, electrolyzer costs and protein purification, and identify cost drivers that may be underestimated (e.g., downstream processing often 30–50% of total bioprocess cost in industrial practice).
- By Month 9 (2027-07-09), present the cost-reduction study findings to the funder and prospective adopters, specifying: (1) current baseline cost EUR 19.93/kg and the gap to the EUR 12/kg cap; (2) cost-reduction paths and their probability ('solar electricity could reduce cost to EUR 17/kg if available at target site; downstream optimization could achieve EUR 14–15/kg with validation; modular deployment at 50 kg/day scale could reduce capex per unit and approach EUR 13/kg'); (3) funder decision required: commit to a EUR 3.0M capex grant for gap-funding, redesign the deployment unit for a lower capacity that fits EUR 12/kg, or recommend Research Only at Phase One gate if neither path is available.

### Responsible Parties

- Techno-Economic Modeler or Cost Analyst (40% FTE Phase One, owns model build and sensitivity analysis)
- External Independent Cost-Analysis Reviewer (commissioned Month 3 = 2027-01-09, delivers audit report by Month 8 = 2027-06-09)
- Lead Process Engineer (provides technical cost data: electricity use, energy per kg, labor requirements)
- Downstream Specialist (provides harvest and purification energy and cost estimates)
- Funder (decides on gap-funding route by Month 9 = 2027-07-09)

### Assumptions

- **High:** The canonical cost model (EUR 19.93/kg, EUR 3.0M capex, 40 kWh/kg electricity, EUR 0.08/kWh) is based on realistic assumptions and can be validated against published data on hydrogen fermentation and alternative-protein systems.
- **Medium:** Solar-coupled electricity at the Kenyan site is feasible at EUR 0.05–0.06/kWh (after capex amortization and inverter/battery cost); this assumption is validated during Phase III site commissioning, not Phase One modelling.
- **Medium:** Downstream-processing energy (nucleic acid reduction, drying, harvest) can be reduced from an assumed 20 kWh/kg to 10–15 kWh/kg via simplified methods (e.g., thermal instead of enzymatic reduction, freeze-drying instead of spray-drying); Phase II validation tests this assumption.
- **High:** A credible cost-reduction path exists that can reduce the full cost to EUR 12–14/kg with a 60–70% confidence level (based on preliminary modelling); if modelling shows cost will remain ≥EUR 16/kg even under optimistic assumptions, a Research Only recommendation is credible.
- **High:** The funder or a prospective adopter is willing to commit to a EUR 3.0M capex grant or subsidy by Month 9 (2027-07-09) if gap-funding is the only viable path; if no such commitment materializes, the recommendation defaults to Research Only at Phase One gate.

### SMART Validation Objective

By Month 9 (2027-07-09), deliver a written 'Cost-Reduction Study and Gap-Funding Route Decision' document specifying: (1) baseline cost EUR 19.93/kg with scenario analysis (EUR 12, 15, 10 caps); (2) sensitivity to electricity price (EUR 0.05–0.15/kWh), downstream energy (10–30 kWh/kg), capex (EUR 2–8M), and utilization (80–98%); (3) identified cost-reduction paths with feasibility assessment and probability of closing the EUR 7.93/kg gap; (4) funder's decision: commit to gap-funding (EUR 3.0M grant), redesign to lower capacity, or recommend Research Only. Gate entry prohibited without a named funding route or an explicit acknowledgment that Research Only is credible if no gap-funding materializes.

### Notes

- Model structure must be transparent and defensible; publish all assumptions, cost data sources and uncertainty ranges in the report so external reviewers can assess credibility.
- Sensitivity analysis should cover the top 5–7 cost drivers (typically: electricity, downstream energy, capex, labour, nitrogen source, facility overhead); do not over-parameterize (>20 variables makes the model hard to interpret).
- Independent cost-analysis reviewer must have published expertise in bioprocess or hydrogen-fermentation economics; avoid selecting a reviewer with a conflict of interest (e.g., employed by a competing technology).
- If cost-reduction modelling shows EUR 19.93/kg is a hard floor (i.e., all three scenarios fail regardless of optimizations), this is a candid finding that should trigger a recommendation for Research Only or Modify (reduced Phase III scope) at the Phase One gate, protecting the project's credibility.
- Publish the cost-reduction study as part of the Phase One gate deliverables so the independent gate-review panel and all stakeholders understand the economic viability case and the funder's decision on gap-funding.

## Summary

The Open Protein Module project (EUR 50M provisional ceiling, 60-month horizon) requires six critical data-collection areas to reduce project-blocking risks: (1) **Strain Rights & Kenyan Biosafety** (Months 0–4 = 2026-10-09 to 2027-02-09): secure written confirmation of lawful strain use in Denmark and Kenya, resolve patent barriers and Kenyan import restrictions before design commitment; (2) **Safety Design Basis** (Months 0–2 = 2026-10-09 to 2026-12-09.5): establish gas composition and inventory limits via HAZOP/LOPA with independent ATEX validation before reactor selection, preventing costly safety re-certification; (3) **Matched Reactor Comparison** (Months 2–6 = 2026-12-09 to 2027-04-09): measure volumetric productivity, mass-transfer coefficients and energy per kg for three reactor concepts in triplicate with pre-registered decision rules and external audit, validating the productivity-cost-of-simplification trade-off; (4) **Kenyan Operating Envelope** (Months 1–4 = 2026-11-09 to 2027-02-09): document grid outage frequency, water quality, spare-part lead times and available technician skills via independent site study, ensuring replication tests genuine difficult infrastructure; (5) **Deployment Scenarios with Named Adopters** (Months 1–9 = 2026-11-09 to 2027-07-09): secure signed commitments from 2–3 prospective adopters (reserve agency, feed producer, humanitarian logistics) with locked cost, capacity and uptime thresholds, anchoring the Phase Three Go decision to real demand; (6) **Cost-Reduction Study & Gap-Funding** (Months 3–9 = 2027-01-09 to 2027-07-09): model how electricity price, downstream energy and modular scaling affect the EUR 7.93/kg cost gap, with funder decision on gap-funding (grant, redesign, or Research Only) before Phase Two. **Immediate actionable tasks**: (A) By Month 0.5 (2026-10-24), commission the ATEX consultant, strain-holder contacts and patent search; engage the independent gate-review panel charter by Month 1.5 (2026-11-24). (B) By Month 4 (2027-02-09), deliver the Strain Feasibility Report and Kenyan Site Baseline Report as hard gate prerequisites. (C) By Month 9 (2027-07-09), lock the reactor selection, the three deployment scenarios with named adopter signatures, and the gap-funding route decision. These data-collection items are sequenced to allow early escalation of blocking risks (strain rights, safety, cost) before design hardware is committed, protecting the EUR 50M investment and the project's credibility with adopters and regulators.