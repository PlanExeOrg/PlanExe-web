**Primary domain:** Gas Fermentation Engineering

**Secondary domains:** Process Safety Engineering, Food Regulatory Affairs, Open Source Hardware

**Rationale:** Gas Fermentation Engineering is the only outcome-role candidate and owns the core success criterion: a working, scalable hydrogen-oxidizing bacteria process. Process Safety Engineering, Techno-Economic Analysis and the other candidates are constraints or methods subordinate to it.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Gas Fermentation Engineering | 5 | 5 | outcome | Hydrogen-oxidizing bacteria bioprocess, mass transfer and scale-up define the core success criterion. |
| Process Safety Engineering | 5 | 4 | constraint | Hydrogen-oxygen explosion risk requires hazard analysis, ATEX design and independent interlock review. |
| Techno-Economic Analysis | 4 | 5 | method | Cost model, scale-up uncertainty ranges, and deployment thresholds drive gate decisions and budget justification. |
| Downstream Bioprocessing | 4 | 5 | method | Harvesting, nucleic acid reduction, drying and protein quality of single-cell biomass. |
| Water Electrolysis | 4 | 5 | method | Electrolyzer selection, membranes, outage tolerance and hydrogen supply underpin the gas fermentation. |
| Food Regulatory Affairs | 4 | 4 | constraint | Novel protein needs credible EU, Danish and Kenyan feed or food authorization pathways. |
| Open Source Hardware | 4 | 4 | method | Complete open-licence source package with governance keeping the core open and replicable. |
| Industrial Microbiology | 4 | 4 | method | Reference strain selection, rights, biological quality assurance, and nucleic acid reduction in downstream processing. |
| Intellectual Property Law | 4 | 4 | constraint | Strain rights, patent restrictions per jurisdiction and open-licence governance must be cleared. |