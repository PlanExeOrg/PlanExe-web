Persuasive elevator pitch.

# Open Protein Module: A Five-Year Programme for Open-Source, Resilient Food Production

## Project Overview

When the next global food crisis hits, will your nation have to depend on imports that may never arrive? The **Open Protein Module** turns electricity, water, CO₂ and a nitrogen source into protein through hydrogen-oxidizing bacteria—a process no single company owns, that any independent team can build and repair, and that works even when supply chains fail.

Over five years, this EUR 50 million programme will deliver a complete open-source engineering package, tested in Denmark and independently replicated in Kenya under difficult infrastructure, with an independently reviewed safety design. Current modeled full cost is EUR 19.93/kg (estimate); a route to the EUR 12/kg cap is a hypothesis to be tested, closable only by cost reduction or a funded gap route. It aims to show that critical food technology can be genuinely open, locally repairable, and ready before crisis strikes.

The technology converts hydrogen gas and oxygen (from water electrolysis) into single-cell protein using naturally occurring bacteria. The process is **vendor-independent**, can be documented openly, and requires no proprietary strains or closed-source designs. A reference unit will produce approximately 20 kg of dry biomass per day (~10 kg usable protein/day) at an estimated 33 kW average electrical load.

## Target Audience

**Primary:** Government ministries and multilateral funders responsible for food security, disaster resilience, and food-supply independence (e.g. EU, bilateral development agencies, African Union, WFP).

**Secondary:** Impact investors, open-hardware advocates and academic institutions seeking high-risk, high-value research with clear public benefit.

**Tertiary:** Prospective adopters (reserve agencies, regional feed producers, humanitarian logistics organizations) who will lock in deployment scenarios and help validate thresholds.

The pitch avoids venture-capital language and speaks to institutional risk tolerance and public-good mandates.

## Project Phases and Timeline

The programme spans **60 months** (Month 0 = 2026-10-09 through Month 60 = 2031-10-09) across three phases:

- **Phase One (Months 0–12 = 2026-10-09 to 2027-10-09):** Settle foundational decisions on reactor concept, strain rights, safety design, deployment scenarios and replication governance. Budget: EUR 6 million provisional ceiling (EUR 5.5M planned).
- **Phase Two (Months 12–30 = 2027-10-09 to 2029-04-09):** Scale from bench to pilot, validate cost chain, confirm regulatory pathways and early independent replication. Budget: EUR 13 million planned.
- **Phase Three (Months 30–60 = 2029-04-09 to 2031-10-09):** Commission two reference units (Denmark and Kenya), conduct safety and fault testing, evaluate against the locked adopter thresholds and publish final open-source documentation. Budget: EUR 22 million planned.
- **Programme reserve:** EUR 4 million (EUR 3.5M technical/scheduling contingency + EUR 0.5M currency fund).
- **Unreleased headroom:** EUR 5.5 million.

**Total provisional ceiling:** EUR 50 million.

## Risks and Mitigation Strategies

### Hydrogen-Oxygen Explosion Hazard

**Mitigation:** Independent HAZOP analysis by Month 2 (2026-12-09), inherent safety limits locked before reactor selection, and layered interlocks independently reviewed before any pressurized build.

### Strain Rights or Biosafety Blocking Replication

**Mitigation:** A Strain Feasibility Report (Month 4, 2027-02-09) naming a primary and a legally clean backup strain with written Kenyan biosafety feedback. All strain rights documented for research, commercial use, redistribution, modification, and derived strains.

### Scale-Up Failure and Cost-Chain Gap

**Mitigation:** Pre-registered disproof experiments on mass transfer, matched reactor comparisons, and techno-economic sensitivity analysis by Month 9 (2027-07-09). If the EUR 7.93/kg gap persists, recommend Research Only outcome rather than forced deployment. (Current gap: full production cost modeled at EUR 19.93/kg vs. EUR 12/kg target; gap-funding route is an open decision.)

### Documentation Gaps Found Only at Replication

**Mitigation:** An early paper-and-bench replication (Months 14–24, 2027-12-09 to 2028-10-09) with a live defect tracker and auditor assessment before full-scale build. Defect tracker goes live by Month 11 (2027-09-09). EUR 0.15M and 8 weeks reserved for documentation fixes.

## Metrics for Success

### Technical

- On-spec biomass (protein ≥60%, nucleic acid ≤2% of dry matter, moisture ≤8%) reproducible from documentation alone in the Kenyan unit.
- 100% of safety-critical fault injections reach a safe state.
- ≥90% of operational fault tests recover within pre-set limits.

### Operational

- Six consecutive months uptime ≥90%.
- ≥8 h outage survived with safe shutdown within 30 s and restart within 2 h.
- Resupply autonomy ≥60 days per input (nitrogen source, minerals, chemicals); ≥90 days for critical spares.

### Evidence Quality

- Zero unresolved safety-critical documentation defects.
- Independent replication defects logged and resolved.
- Gate-panel independence verified.
- At least one locked scenario met (cost, capacity, reliability).

### Adoption

- Confirmation that at least one prospective adopter can lawfully obtain strain, secure permits, and proceed within 12 months of release.

### Economic

- Cost trajectory toward the EUR 12/kg cap (current modeled full cost EUR 19.93/kg, estimate); a route to the cap remains a hypothesis to be tested.
- Gap-funding source identified or justified as Research Only.

## Stakeholder Benefits

### Governments and Multilateral Funders

Demonstrable resilience infrastructure with zero vendor lock-in, replicable by any nation or region facing supply disruptions. Peer-reviewed science on hydrogen-based protein production.

### Adopters (Reserve Agencies, Feed Producers)

A complete, independently safety-reviewed, open design they can build and service locally without licensing fees or dependency on a single company. Operator training and competency frameworks included.

### Researchers and Open-Hardware Communities

Published, audited process data; peer-reviewed studies on scale-up, safety and replication; open data and analysis code; collaboration agreements with academic institutions.

### Independent Technicians in Kenya and Beyond

Demonstrated path to skilled, local employment in protein production with clear competency boundaries and pre-assessed change rights.

### Strain Custodians and Culture Collections

Defined chain of custody for cryo-stocks; reciprocal licensing ensures improvements feed back to the global research community.

## Ethical Considerations

This project commits to **democratic governance**: an independent gate-review panel (not the developer team) controls continue/modify/research-only/stop decisions at each phase, with written public justification for any funder deviation. The panel will be composed of 3–5 members, recruited and chartered by Month 1.5 (2026-11-24), funded and managed by the funder (not the host). The funder holds release authority, and any deviation from the panel's recommendation requires published written justification.

**Strain choice** privileges lawful access over proprietary performance, so independent implementers in Kenya and other nations can build without vendor approval.

**Safety decisions** prioritize local adopter protection: the Adopter Change Boundary is pre-assessed in detail, and safety-critical modifications require hazard re-analysis, not unilateral builder choice. We acknowledge that hydrogen-oxygen systems carry intrinsic hazard; we manage it through layered, independently reviewed protection and tight inventory limits (no operation above 2 bar(g) without independent overpressure relief; gas inventory <0.5 m³ H₂ and <0.2 m³ O₂; O₂ <4% in H₂-rich stream), not through black-box automation that disempowers local technicians.

**Commercialization** is not prohibited, but reciprocal open licences prevent closed forks and require improvements to be shared back.

The project will **not claim success** if replication fails or adopters cannot lawfully operate the design; we treat failure discovery as evidence-based progress, not a defeat.

## Collaboration Opportunities

- **With commercial hydrogen-protein producers (e.g. Solar Foods):** Public benchmark exchange on productivity, energy, nucleic acid handling and novel-food authorization timelines (not proprietary margins).
- **With existing open-hardware gas-fermentation research (e.g. AMYBO):** Co-authored scale-up methodology; joint KPI framework; candidate design evaluation.
- **With Kenyan food-technology and feed-regulation bodies (e.g. icipe, Kenya Bureau of Standards, Ministry of Agriculture):** Co-hosted regulatory pre-submission dialogue; Kenyan site and partner identification; adopter engagement and scenario validation.
- **With independent ATEX and safety consultants:** Joint hazard analyses; interlock-design review; published safety-case methodology.
- **With non-profit steward entities (e.g. Open Source Ecology, OSHWA):** Licence-stack and certification frameworks; defect-tracking and community governance models.
- **With academic institutions:** Phase One reactor benchmark collaborative agreements; peer review and co-publication of scale-up and replication findings.

Open invitations to all groups to engage at Month 1.5 (2026-11-24) when the independent panel is chartered.

## Long-term Vision

By Month 60 (2031-10-09), a complete **open-source protein process** will exist, independently replicated under difficult infrastructure, with zero vendor lock-in and publicly documented safety and economic limits.

Within two years post-release, the aspiration is at least **three independent deployments** in Africa, Asia or elsewhere, each training local technicians and reporting real cost and uptime data.

Within five years, the open design will have become a **reference point for food-resilience policy** in jurisdictions facing supply risk. Regulators in Denmark, the EU, Kenya and other nations will have confirmed product-safety pathways for open-source biological processes.

A **non-profit steward entity** will be managing version releases, processing adopter feedback and enforcing reciprocal open licences indefinitely.

The project's greatest legacy is not the protein output, but the **proof that critical infrastructure can be designed for independence, published openly, and replicated rigorously**—setting a precedent for open-source medicine, water treatment and energy systems in under-resourced regions.

## Call to Action

**Commit EUR 6 million to Phase One (Months 0–12 = 2026-10-09 to 2027-10-09)** to settle the five foundational decisions: reactor concept, strain rights, safety design basis, deployment scenarios and replication governance.

By **Month 12 (2027-10-09)**, you will hold:

- An independent gate recommendation.
- Measured evidence of which reactor concept beats the cost-simplicity trade-off.
- Confirmed legal clearance for Kenyan replication.
- Locked adopter thresholds.

A single decision point at **Month 12 (2027-10-09)** will show whether to advance to a EUR 13 million Phase Two with confidence.

**Key actions required:**

- Commit EUR 6 million Phase One budget (EUR 5.5M planned spend, EUR 0.65M contingency).
- Recruit and charter an independent gate-review panel (3–5 members) by Month 1.5 (2026-11-24); funding EUR 0.06M in Phase One.
- Sign a Danish host institution MoU by Month 1 (2026-11-09).
- Engage a HAZOP/LOPA safety consultant by Month 1 (2026-11-09).
- Commission a patent search and strain-rights feasibility study by Month 2 (2026-12-09).
- Lock the KPI framework by Month 1.5 (2026-11-24); deliver the HAZOP report by Month 2 (2026-12-09); issue the safety design basis and reactor decision rules by Month 2.5 (2026-12-24).
- Deliver the Strain Feasibility Report by Month 4 (2027-02-09).
- Identify the Kenyan partner and site by Month 3 (2027-01-09); sign prospective adopters by Month 7 (2027-05-09).
- Lock deployment scenarios and time-stamp them at Month 9 (2027-07-09).
- Hold Phase One evidence freeze by Month 9 (2027-07-09) and gate panel decision by Month 12 (2027-10-09).

**Governance safeguards:**

- Unsigned partners and sites carry risk; we recommend a steering committee with authority to pause or redirect if adoption signals weaken.
- Any funder deviation from the independent panel's recommendation must be published in writing and justified publicly.
- Release of Phase Two and Phase Three budgets is conditional on the preceding gate decision.
