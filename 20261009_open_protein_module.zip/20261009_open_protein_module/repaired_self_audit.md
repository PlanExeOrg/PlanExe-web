Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 13 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 6 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is an engineering and research project to develop open-source hydrogen-fed microbial protein production. The core mechanism—electrolysis producing hydrogen, aerobic bacterial conversion of hydrogen and CO₂ to biomass, and downstream processing—is grounded entirely in established physics and biochemistry (energy conservation, mass balance, thermodynamically feasible pathways). The plan includes explicit kill gates, pre-registered disproof thresholds, and fallback scenarios; no non-physical mechanism is invoked for success. Scale-up, operability, and cost viability are engineering and empirical questions, not physics violations.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan integrates five novel elements—hydrogen fermentation, nucleic-acid control, local technician operation, open-source decentralization, and independent Kenyan replication under documented outage/supply constraints—into a single system combination with no publicly documented independent replication at comparable scale. Solar Foods operates proprietary Solein at pilot scale, and AMYBO's electroPioreactor exists at bench scale only. The failure of any one element (strain instability >10%, nucleic-acid removal cost >EUR 30/kg usable protein, operator competency <90%, legal barriers on strain rights, or hypothesis B logistical failure) invalidates the deployment case despite technical proof-of-concept, risking a Research Only outcome after EUR 20–30M Phase Two–Three spend.

**Mitigation**: Establish five parallel validation tracks by Month 2 (2026-12-09): (1) Gas Fermentation & Nucleic Acid Control (pre-registered kLa decline ≤25%, strain stability <10%, nucleic acid ≤2%), (2) Local Technician Operation (≥90% practical safety pass, 0 safety-critical and ≤3 critical defects, hands-on troubleshooting >4 h/month flagged), (3) Strain Rights & Regulatory Compliance (zero blocking legal barriers, ≥2 strains confirmed by Month 4 = 2027-02-09), (4) Cost & Scenario Viability (≥2 signed adopters, funder gap-funding route locked by Month 7 = 2027-05-09), (5) Decentralized Operability & Harsh Infrastructure (≥90% uptime, ≥8 h outage survival, ≥60 day resupply autonomy by Month 54 = 2031-04-09). Define two NO-GO gates: (1) empirical validity (Phase Two Month 30 = 2029-04-09) and (2) legal/compliance (Phase One Month 4 = 2027-02-09). Failure in any critical track ⇒ overall Modify or Research Only recommendation.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan defines 15 named strategic decisions with explicit inputs, processes and customer-value targets (e.g., Gas-Liquid Contacting: reactor choice → mass transfer and energy per kg → ATEX compliance and productivity). Measurable outcomes are specified for most decisions (e.g., strain rights documented, volumetric productivity ≥90% benchmark, defects tracked and resolved). However, three critical gaps weaken strategic clarity: (1) the EUR 7.93/kg deployment cost gap is explicitly marked "OPEN DECISION" with no assigned owner or committed funding route, leaving flagship adoption scenarios locked against unresolved cost thresholds; (2) the Adopter Change Boundary strategy lists only placeholder examples ("e.g. electrode material") without a published pre-assessed component list (due Month 3, 2027-01-09, unconfirmed); (3) Hypothesis A and B testing separation is stated but not operationalized in Phase Three gate criteria—failure of hypothesis A alone does not clearly block a Go decision, creating ambiguity on strategic success/failure boundaries.

**Mitigation**: By Month 1.5 (2026-11-24), assign an explicit owner (e.g., Funder Representative + Techno-Economic Lead) to the cost-gap strategy; the written gap-funding decision is due by Month 7 (2027-05-09): either a committed EUR 3.0M capex grant/adopter subsidy, a redesigned 50 kg/day unit fitting EUR 12/kg, or acknowledgment that Research Only is credible if neither materializes. By Month 3 (2027-01-09), publish a final Adopter Change Boundary document naming all pre-assessed substitutable components with vendor names, specifications, and safety rationale (not placeholders). By Month 2 (2026-12-09), revise the Phase Three gate criteria to specify separate go/modify/research-only/stop decisions for Hypothesis A (local technician operation: ≥90% competency pass) and Hypothesis B (decentralized modules: ≥90% uptime, ≥60 day resupply autonomy); make explicit that failure of either excludes Go; the panel gives its own written Modify recommendation with credible remediation, and the funder publishes any deviation with written justification.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies nine major second-order risks (strain rights, cost-gap funding, regulatory pathway, hydrogen-oxygen hazard, contamination, scale-up failure, partner withdrawal, gate-panel independence, and cash-flow contingency) with owners and phase-gate triggers assigned to each. However, cascading-failure linkages between these risks are mapped only partially. Three critical cascade gaps remain unmitigated: (1) If strain barriers emerge at Month 4 (2027-02-09), the fallback strain requires re-characterization (EUR 0.2–0.4M, 6–12 months, consuming Phase-One float), and if that fallback is less productive, the cost model breaks (cost per kg rises from EUR 19.93 to EUR 23–26) and all three locked scenarios fail simultaneously—this cascade is identified but no contingent scenario-renegotiation protocol is specified. (2) If the cost-gap funding route is not locked by Month 7 (2027-05-09) and Phase-Two hardware release consumes EUR 4.0M without a gap-funded path, the project is sunk-cost-committed to Phase Three on a failed business case (cascade unmitigated). (3) Hydrogen-oxygen hazard, if inadequately analyzed, could cascade: late HAZOP findings (after Month 2.5 = 2026-12-24) force design rework (EUR 0.2–0.5M, 4–8 weeks), ATEX recertification on redesigned units (2–4 months), and safety-critical defects discovered in Phase-II early replication (Months 14–24 = 2027-12-09 to 2028-10-09) cannot be resolved before the Phase-II gate (Month 30 = 2029-04-09), forcing a gate slip or incomplete evidence base (cascade partially mitigated by early HAZOP, but late defects are not addressed).

**Mitigation**: By Month 1 (2026-11-09), establish a "Cascade-Failure Register" identifying the three highest-consequence linkages: (1) Strain-Rights Cascade: Month-4 barrier triggers fallback evaluation within 2 weeks; if fallback productivity <80% of primary, automatically trigger a cost-model re-run and adopter-scenario re-negotiation by Month 5 (2027-03-09); gate-panel pre-approval for modified scenarios by Month 8 (2027-06-09). (2) Cost-Gap Cascade: By Month 6 (2027-04-09), an interim cost-path checkpoint is held; the funder must decide on the gap-funding route in writing by Month 7 (2027-05-09); if no route is committed by Month 7 (2027-05-09), the Phase-Two gate recommendation defaults to Modify (reduced Phase-Three scope: Danish unit only, hypothesis-A evidence only, Kenyan replication deferred) or Research-Only, and EUR 4.0M hardware budget is held pending a credible path. (3) Safety-Hazard Cascade: Complete HAZOP by Month 2.5 (2026-12-24); any late findings (discovered after Month 2.5 = 2026-12-24) trigger an immediate design-review and a cost/schedule escalation assessment; if safety redesign is needed, extend Phase-One by up to 4 weeks (delay into Month 5 = 2027-03-09) and re-plan the reactor bench-test timeline. Document all cascades in monthly steering-committee reports and flag any threshold exceedance for immediate panel escalation.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies strain rights, patent freedom-to-operate, and Kenyan biosafety feasibility as critical gate criteria due at Month 4 (2027-02-09), but the execution sequencing is underdeveloped. Strain-holder contact and patent search are assigned to Months 0–4 (2026-10-09 to 2027-02-09) but not explicitly resourced or scheduled. A late discovery of a blocking barrier (commercial-use restriction, third-party patent claim, or Kenya import ban) at Month 4 (2027-02-09) forces a fallback strain switch consuming EUR 0.2–0.4M and 6–12 months in Phase Two, which exceeds the 3-month Phase One–to–Two float and erodes the EUR 0.35M free contingency. A Phase Three strain barrier costs EUR 2–4M and 12–24 months, consuming 63–125% of the ~EUR 3.2M free technical reserve (57–114% of the EUR 3.5M technical reserve; the upper end is unfundable) and likely exceeding the Month 60 (2031-10-09) deadline. The plan lacks an explicit contingency trigger rule and a fallback-strain readiness condition before the Phase One gate (Month 12 = 2027-10-09).

**Mitigation**: By Month 1.5 (2026-11-24), appoint a named strain-rights and regulatory affairs lead with 60% FTE through Month 4 (2027-02-09) and commission the patent search by Month 2 (2026-12-09) (budget EUR 40k–60k from the EUR 0.30M earmark). Deliver the Strain Feasibility Report by Month 4 (2027-02-09) (internal draft target Month 3 = 2027-01-09), naming primary and clean-backup strains with documented rights per use and written Kenyan biosafety feedback. Pre-register a contingency decision rule: 'If primary strain is reclassified as medium risk by Month 6 (2027-04-09), activate fallback strain without panel review; if high risk, escalate immediately.' Do not proceed to the Phase One gate without strain confirmation and a viable fallback.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the deployment cost chain shows a EUR 7.93/kg gap (EUR 19.93/kg full cost vs EUR 12/kg cap) with no assigned funding route. The provisional EUR 50M ceiling and EUR 40.5M planned spend are stated, but all funding sources (partners, adopters, gap-funding) are unsigned. The gap-funding mechanism is explicitly marked "OPEN DECISION" with no committed path. Financing gates and pre-registered covenants exist, but are conditional outcomes (Modify/Research Only if thresholds fail), not binding commitments ensuring continuation.

**Mitigation**: Funder and Techno-Economic Lead: Resolve the gap-funding route (adopter subsidy, capex grant, cost reduction, or reduced Phase Three scope) and commit it in writing by Month 7 (2027-05-09). Release the EUR 4M reference-unit hardware budget only at the Phase Two gate if cost modeling predicts ≤EUR 14/kg and the gap route is named. Publish the funding decision alongside locked scenarios by Month 9 (2027-07-09).


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the deployment cost chain shows EUR 19.93/kg full cost vs. EUR 12/kg Scenario A cap (EUR 7.93/kg shortfall, 41% gap), unsupported by ≥3 external benchmarks or vendor quotes. The plan lacks documented contingency or gap-funding commitment; the gap-funding route remains "OPEN DECISION" past the Phase One gate (Month 10 = 2027-08-09), leaving locked scenarios unachievable without a funded mitigation path yet to be determined.

**Mitigation**: Techno-Economic Lead and Funder: Obtain ≥3 vendor quotes for major equipment (electrolyzer, fermenter, downstream) by Month 4 (2027-02-09); benchmark against published alternatives (Solar Foods Solein, insect protein) by Month 6 (2027-04-09); resolve gap-funding route (adopter subsidy, capex grant, cost reduction, or scope reduction) and commit in writing by Month 7 (2027-05-09). If cost remains ≥EUR 15/kg at the Phase Two gate, recommend reduced Phase Three or Research Only before releasing the EUR 4M hardware budget.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key deployment-cost projections (EUR 19.93/kg full cost, EUR 12/kg Scenario A cap, EUR 7.93/kg gap) as single-point estimates without confidence intervals, ranges, or alternative scenarios. Ranges exist in the canonical facts (energy 25–60 kWh/kg, capex EUR 2.0–8.0M) but are not integrated into the locked scenario thresholds or gate-decision criteria. The cost-reduction study with sensitivity analysis is a Phase One deliverable (due Month 7 = 2027-05-09), not yet completed. Lock-in of scenarios at Month 9 (2027-07-09) without published uncertainty could force Research Only if Phase II or III data reveal cost is EUR 15–19/kg rather than EUR 12–14/kg modeled.

**Mitigation**: Techno-Economic Lead: Deliver a Cost and Performance Uncertainty Register by Month 6 (2027-04-09) with ±15–20% confidence intervals on cost per kg, energy per kg, and deployment capacity. Publish three scenarios (conservative/base/optimistic) for the top 5 cost drivers. Lock projections and uncertainty ranges at the Phase One gate (Month 10 = 2027-08-09) so scenarios remain credible if Phase II data vary ±15%.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires that bench-scale matched reactor comparisons (pneumatic, stirred, passive-feed), strain-stability validation (16 weeks under Phase III operating conditions), downstream-processing train validation (harvest, nucleic-acid reduction, drying to meet specification), and a scale-up evidence ladder (pre-registered disproof experiments with locked failure thresholds on mass-transfer coefficient and energy per kilogram) all be completed and locked before major hardware (EUR 4.0M reference units) are released at the Phase Two gate (Month 30 = 2029-04-09). However, no detailed engineering specifications, interface contracts, acceptance-test protocols, or integration plans for these critical systems are documented in the plan. The matched-reactor protocol is specified only as 'triplicate runs, single lead analyst, pre-registered decision rule' (Month 2.5 = 2026-12-24); the downstream train is sketched as 'harvest, cell disruption, nucleic-acid reduction, drying' with no component selection, material balance, or stage-gate acceptance criteria; the scale-up ladder references 'bench, container-scale, reference-unit' runs but does not name the intermediate scales, the measurement equipment needed, or the integration sequence (which bench kLa data feed into which pilot design, which pilot results feed into which reference-unit procurement decision). The strain-stability experiment (10–16 weeks, weekly sampling, weekly growth rate, oxygen-uptake rate, nucleic-acid content and viability) is outlined but lacks acceptance criteria (e.g., 'if variation in growth rate exceeds 10% week-to-week over 4 weeks, halt and investigate'), integration with the fermenter control system (feedback loops, sensor specifications), or a documented decision rule for halting production if drift is detected late (Month 48–54 = 2030-10-09 to 2031-04-09 during Phase III production). Acceptance tests are mentioned only for hypotheses A and B (operator competency ≥90%, fault-injection pass rates ≥90%) and for the locked scenario thresholds (cost ≤cap, capacity ≥minimum, uptime ≥target), not for individual component systems (kLa target ±15%, energy per kilogram scaling within ±15% model, nucleic-acid reduction yield ≥X%, digestibility ≥Y%).

**Mitigation**: Engineering Lead and Phase Lead: By Month 1 (2026-11-09), establish a 'Build-Critical Components Engineering Specification' document defining: (1) Matched-Reactor Protocol (name three concepts, define identical strain/media/inoculum, specify inoculation procedure, sampling frequency [e.g., daily dissolved-O₂, twice-weekly OD₆₀₀, gas composition analysis weekly], and acceptance criteria [e.g., 'all three triplicates pass if mean productivity ≥90% benchmark within ±15% standard deviation']); (2) Downstream Processing Train (define harvest method [centrifuge specifications or filtration cutoff], nucleic-acid reduction method [thermal, enzymatic, or passive], product specification [protein ≥60%, nucleic acid ≤2%, moisture ≤8%], and entry/exit criteria per stage [e.g., 'nucleic-acid reduction pass if final product ≤2.5% nucleic acid dry matter from ≥3 replicates']); (3) Scale-Up Evidence Ladder (name intermediate scales [e.g., bench 1 L, pilot 10–50 L, reference 200 L equivalent], identify critical measurements per scale [kLa, energy per kg, oxygen-uptake rate], pre-register failure thresholds [e.g., 'kLa decline bench to pilot ≤25%, or scale-up assumption is disproven'], and assign responsibility/timeline for measurement and analysis); (4) Strain-Stability Acceptance Test (specify halt criterion [e.g., 'if growth-rate variation exceeds 10% over any 4-week window during the 16-week run, halt, investigate and document root cause'], decision rule for Kenyan Phase III [e.g., 'if Month-48 to -49 stability data show drift >10%, escalate to gate panel and recommend Modify (extended training or strain switch) before production continues']); (5) Integration Plan and Owners/Dates (chart showing which components feed into which decisions, who owns each stage, when each decision is locked, and how results flow into the scale-up model and gate criteria). Publish this specification by Month 2 (2026-12-09) and lock it with external-auditor sign-off by Month 2.5 (2026-12-24). By Month 30 (2029-04-09, Phase Two gate), require engineering documentation to demonstrate that all critical-component tests meet their pre-registered acceptance criteria or explicitly document gaps and the mitigation plan (e.g., 'nucleic-acid reduction achieved 2.8% in Phase II; specification is ≤2.0%; Phase Three plan is [thermal method redesign, operator retraining, or category pivot to lower limit]; re-test scheduled Month 42 = 2030-04-09'). Do not release Phase III hardware (EUR 4.0M) without complete acceptance-test sign-off from the Lead Process Engineer, Downstream Specialist, and independent auditor.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes five critical claims (strain rights lawful in Kenya, Kenyan biosafety pathway exists, cost model defensible, adopter scenarios credible, independent gate-panel governance credible) without verifiable artifacts. The Strain Feasibility Report is due Month 4 (2027-02-09)—a future deliverable, not an existing document. Written adopter scenario commitments are locked at Month 9 (2027-07-09)—still future. The cost model (EUR 19.93/kg vs EUR 12 cap) rests on unvalidated assumptions (EUR 0.08/kWh electricity, 40 kWh/kg energy) with no published sensitivity analysis, benchmark comparison, or vendor quotes as evidence. The gate-review charter is a planned document (Month 1.5 = 2026-11-24), not yet signed. The only artifact mentioned as existing is the canonical-facts table and the pre-project assessment, neither of which confirms the core claims. Without verifiable evidence that (a) at least one strain is lawfully importable into Kenya, (b) cost is achievable at the locked EUR 12/kg threshold, and (c) named adopters commit to the scenarios before the Phase One gate, the project risks proceeding on assumptions that may not hold.

**Mitigation**: Before the Phase One gate (Month 12 = 2027-10-09), obtain and time-stamp: (1) Strain Feasibility Report (Month 4 = 2027-02-09) with written strain-holder rights confirmation and Kenyan biosafety authority feedback. (2) Cost-model audit by an independent techno-economic consultant (Month 7 = 2027-05-09) comparing the EUR 19.93/kg projection against vendor quotes, published benchmarks (Solar Foods, insect protein), and published sensitivity studies. (3) Signed scenario commitments from ≥2 named adopters (Month 7 = 2027-05-09) documenting their cost-basis data and locked thresholds. (4) Gate Authority Charter signed by the funder (Month 1.5 = 2026-11-24) specifying panel independence and authority. Bundle these into a Phase One gate evidence package and require independent auditor sign-off that evidence quality meets the plan's gate criteria before continuation to Phase Two.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because four major deliverables are mentioned without specific, verifiable acceptance criteria: "Safe Hydrogen-Oxygen System Design" (Adopter Change Boundary v0 promised Month 3 = 2027-01-09, content unspecified), "Credible Regulatory Pathway" (no numerical or written-authority sign-off criteria defined), "Independent Replication Evidence" (defect-severity thresholds proposed only for Phase II gate, not locked in advance), and "Operator Competency" (training framework, pass criteria, and assessment method undefined). These abstract deliverables risk post-hoc rationalization at gate reviews if criteria are missing or adjusted to match results.

**Mitigation**: Project Director: By Month 1 (2026-11-09), draft SMART acceptance criteria for the four abstract deliverables, specifying measurable outcomes per criterion (e.g., Adopter Change Boundary: list ≥20 pre-assessed substitutes with vendor names, specifications, and hazard-analysis justification; Competency: ≥90% pass on 10 named safety-critical practical tasks; Regulatory Pathway: written authority feedback on classification and minimum safety-data package; Defect Severity: zero unresolved safety-critical, ≤3 critical, ≤10 minor by Phase II gate Month 30 = 2029-04-09). Lock criteria with external-auditor sign-off by Month 2.5 (2026-12-24). Use criteria to assess deliverables at each gate.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan defers deployment-scenario locking to Month 9 (2027-07-09) despite naming a EUR 7.93/kg cost gap (full cost EUR 19.93/kg vs. EUR 12 cap) with no assigned funding route. Scenarios are locked against unachievable thresholds without credible gap-funding commitment or real adopter signatures. If cost remains EUR 19.93/kg and no subsidy materializes, all three locked scenarios fail simultaneously at the Phase Three gate, forcing Research Only despite technical success. The plan states 'gap funding route is an OPEN DECISION,' meaning EUR 274,820/yr operational shortfall (or EUR 3.0M capex grant equivalent) is unresolved. Phase Two hardware release (EUR 4.0M) proceeds on momentum if scenarios are locked without cost certainty, consuming budget before the gap is addressed.

**Mitigation**: Funder Representative and Techno-Economic Lead: Deliver written gap-funding route decision (adopter subsidy, capex grant, cost-reduction lever, or reduced Phase Three scope) by Month 7 (2027-05-09). Lock scenarios only after the gap route is committed. Release EUR 4.0M reference-unit hardware at Phase Two gate only if modeled cost is ≤EUR 14/kg and gap funding is named.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project depends on a gas-fermentation engineer with hydrogen-organism expertise, bench-to-pilot scale-up track record, and open-source credibility—a rare combination of skills. The plan names a fictional example (Dr. Henrik Larsen) but does not document: (1) whether this or an equivalent person exists and is available, (2) salary/benefits competitive with private biotech, or (3) recruitment timeline (must hire by Month 0–1 = 2026-10-09 to 2026-11-09 to lead Phase One experiments). Without early recruitment validation, a 2–4 month hiring delay consumes the Phase One float and delays critical reactor experiments, straining the schedule to the Phase One gate (Month 10 = 2027-08-09).

**Mitigation**: Recruitment Team: By Month 0 (2026-10-09), conduct a rapid 30-day talent-market validation: contact 10–15 senior process engineers with hydrogen-fermentation or high-gas-transfer expertise (via LinkedIn, conference networks, and referral from Solar Foods/AMYBO contacts); confirm at least 2 are genuinely available and interested, document their salary expectations, and secure written offers or strong letters of intent by Month 1 (2026-11-09). If talent search fails, escalate to the funder within 10 days with a mitigation plan (e.g., co-hire a strong bioprocess engineer + external hydrogen consultant, adjust Phase One timeline).


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies strain rights, biosafety classification, and product-safety pathways as critical-path risks with explicit resource allocation (EUR 0.30M earmark) and timelines (Phase One landscape Month 0–4 = 2026-10-09 to 2027-02-09, Strain Feasibility Report Month 4 = 2027-02-09). A regulatory-engagement workstream exists covering Kenya import permits, contained-use authorization, and product-category pathways. However, three material gaps remain unmitigated: (1) no written regulatory-authority confirmation is required before Phase One gate—only informal pre-submission feedback; (2) product-category choice is locked at Phase One gate (Month 10 = 2027-08-09) based on preliminary data, before full safety-data and regulatory requirements are validated; (3) contingency escalation rules for strain-rights or regulatory barriers discovered late are implicit in cost/schedule fallback estimates, not locked in gate criteria.

**Mitigation**: Regulatory Affairs Lead and Funder: By Month 4 (2027-02-09), deliver the Strain Feasibility Report with written Kenyan biosafety authority feedback on strain import permissibility and contained-use authorization (not informal pre-submission only). By Month 6 (2027-04-09), obtain written preliminary guidance from competent authorities on the proposed product category and minimum safety-data requirements. Add explicit Phase Two gate criterion: written authority feedback on the regulatory pathway and minimum safety-data package; dossier completion is checked at the Phase Three gate only as a 'credible pathway'.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies operational sustainability gaps across funding, maintenance, personnel dependency, and technology obsolescence, but mitigation strategies lack detail and specificity. Critical example: "the EUR 274,820/yr operational shortfall (or EUR 3.0M capex grant equivalent) ... is undecided" and explicitly marked "OPEN DECISION." No named gap-funding source, adopter subsidy mechanism, or cost-reduction path is committed before Phase Three. Operator training framework is mentioned but lacks duration, curriculum, or competency re-assessment schedules. Post-deployment stewardship entity is planned but lacks sustainable funding model, governance structure, or operational-cost estimates beyond "EUR 0.2M setup." These gaps create material risk that Phase Three produces a technically working system with no credible long-term deployment pathway or operator viability.

**Mitigation**: Funder and Techno-Economic Lead: Resolve and lock the gap-funding route (named adopter subsidy, government capex grant, or cost-reduction lever yielding ≤EUR 14/kg) by Month 7 (2027-05-09). Regulatory Affairs and Operations Lead: Develop a detailed post-deployment Operator Competency and Training Framework (curriculum, duration, re-certification schedule, supplier-availability plan for spare parts) by Month 12 (2027-10-09). Steward Entity Lead: Draft a post-project Stewardship and Sustainability Plan (estimated annual costs: EUR 65k–130k for strain curation, regulatory monitoring, licence management; identify sustainable revenue sources—endowment, membership model, or institutional anchor) by Month 54 (2031-04-09), reviewed and endorsed by the gate panel before Phase Three conclusion.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies hard constraints (Kenyan biosafety import permit, ATEX hydrogen compliance, product-category regulatory pathway, zoning/site constraints) as project-critical and allocates Phase One resources (EUR 0.30M earmark, regulatory-engagement workstream Months 0–4 = 2026-10-09 to 2027-02-09) to validate them. However, three material gaps remain unmitigated: (1) no written authority pre-approval is required before the Phase One gate; only informal pre-submission feedback by Month 4 (2027-02-09) is mandated—if written clearance is denied at Month 5–8 (2027-03-09 to 2027-06-09), fallback actions consume the Phase One float and the EUR 0.35M free contingency; (2) the Kenyan site envelope baseline (grid outages, water quality, spares, structural fit) is a proposed-threshold study with no written site-selection authority sign-off before design commit; (3) product-category regulatory pathway is provisional (locked Month 10 = 2027-08-09) based on preliminary data, not final authority feedback. Late-discovered hard-constraint barriers (strain import ban, ATEX re-certification required, site zoning or structural unsuitability) would force a scale 2–4 (EUR 2–4M, 12–24 months) fallback in Phase Two or Three, consuming 63–125% of the free technical reserve and exceeding the Month 60 (2031-10-09) deadline.

**Mitigation**: Regulatory Affairs Lead and Kenyan Co-Development Partner: Deliver a written "Regulatory Hard-Constraint Clearance Report" by Month 4 (2027-02-09) confirming (1) Kenyan biosafety authority's written position on strain import and contained-use authorization (not informal feedback; actual approval or identified barrier with mitigation path), (2) ATEX compliance confirmation for the locked safety design basis with no non-waivable barriers flagged, (3) Product-category regulatory pathway in Kenya with documented feasibility and authority pre-submission feedback, (4) Kenyan site zoning, occupancy, structural and utility fit based on the independent baseline study (signed by the site-selection consultant). Require gate-panel review and written sign-off that hard constraints do not block Phase Two before releasing EUR 4.0M hardware budget at Phase Two gate (Month 30 = 2029-04-09).


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because strain rights and Kenyan biosafety classification are project-blocking dependencies due at Month 4 (2027-02-09) with no recovery buffer if barriers emerge. Discovery at Month 4–6 (2027-02-09 to 2027-04-09) forces a fallback strain switch consuming EUR 0.2–0.4M and 6–12 months, eroding the 3-month Phase One float and using 6–12.5% of the free technical reserve. Phase Three discovery costs EUR 2–4M and 12–24 months, exceeding the Month 60 (2031-10-09) deadline and consuming 63–125% of the ~EUR 3.2M free reserve (57–114% of EUR 3.5M), so the upper end is unfundable.

**Mitigation**: Regulatory Affairs Lead: Move strain-holder contact, patent search and Kenya biosafety pre-submission to Months 0–2 (2026-10-09 to 2026-12-09), in parallel with landscape review. Deliver Strain Feasibility Report by Month 4 (2027-02-09) (internal draft target Month 3 = 2027-01-09) naming primary and legally clean backup strain with productivity baseline. This front-loading reserves EUR 0.30M contingency for fallback activation and preserves Phase One float, reducing critical-path risk by 75%.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Independent Gate-Review Panel (process safety engineer, regulatory consultant, adoption economist, independently funded EUR 0.30M) is incentivized to enforce evidence standards and recommend stop/modify to protect credibility, while the Funder/Host Institution is incentivized to continue to Phase Three to justify sunk-cost EUR 5.5M Phase One spend and preserve organizational commitment narrative. This creates structural pressure to rationalize weak evidence: if strand rights unconfirmed by Month 4 (2027-02-09) or cost model shows EUR 19.93/kg with no gap-funding route locked by Month 7 (2027-05-09), the Panel recommends stop/modify, but the Funder faces organizational pressure to override and continue. The conflict is unstated because both sides publicly claim commitment to evidence-driven decisions, but their underlying incentives diverge on what counts as \"acceptable evidence\" and \"acceptable risk of failure.\"

**Mitigation**: Funder and Gate Panel Chair: Establish a \"Shared Go-Decision OKR\" by Month 1 (2026-11-09) requiring the Panel to give its own written decision at each phase gate, with the Funder holding release authority. Any deviation from the Panel's recommendation must be published with written justification by the Funder within 5 working days. This forces both stakeholders to defend the decision publicly, aligning their incentives toward evidence rigor over momentum.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan establishes three major phase gates with pre-registered criteria and independent panel review, and specifies KPI measurements (productivity, kLa, energy per kg, strain stability, uptime, cost per kg) locked by Month 1.5 (2026-11-24). However, the operational feedback loop between gates is under-specified: monthly financial and progress reporting is mentioned but lacks a defined KPI dashboard, alert thresholds, or automated escalation criteria. A lightweight change-control board with authority to redirect spend or adjust scope mid-phase is not documented, leaving in-flight decision-making ambiguous when contingency triggers are hit (e.g., \"if cost model shows EUR 15/kg by Month 6 = 2027-04-09, escalate\")—escalate to whom, with what authority, on what timeline? Quarterly steering meetings are named, but no chairperson, decision authority, or corrective-action approval process is specified. Without explicit mid-phase governance, the project risks momentum-driven continuation despite variances exceeding thresholds, or a delayed gate review due to uncertainty about who owns course-correction decisions during execution.

**Mitigation**: Programme Manager: Establish and lock a written \"Operational Feedback and Change-Control Charter\" by Month 1 (2026-11-09) specifying: (1) monthly KPI dashboard with automated alerts if any metric drifts >10% from plan (cost per kg, volumetric productivity, kLa, strain stability, uptime, defect closure rate); (2) quarterly steering-committee meeting schedule with a named chair and decision authority to approve scope/budget adjustments up to EUR 0.1M without re-gating (for items within the programme reserve); (3) escalation rules for in-flight variances (variance >10% → steering committee within 10 days; variance >20% → gate-panel escalation within 15 days; decision authority, timeline to correct or revise plan); (4) change-control board with representation from project director, lead engineer, funder liaison, and panel chair, meeting monthly to review defects, cost variances and schedule risks; publish a monthly Change Log with decisions and rationale. Operationalize this by Month 3 (2027-01-09) and report compliance quarterly to the gate panel.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies 18 distinct first-order risks (strain rights, HAZOP completion, reactor selection, cost-gap funding, adopter commitment, gate-panel independence, site envelope, downstream processing, regulatory pathway, contamination, strain stability, competency verification, currency volatility, partner agreement, documentation defects, scale-up assumptions, nucleic-acid specification, and stewardship sustainability) with individual mitigation actions assigned per risk. However, three critical multi-node failure cascades remain unmitigated: (1) Strain-Barrier Cascade: if the primary strain is blocked at Month 4 (2027-02-09) and the backup strain is 30% less productive, deployment cost jumps from EUR 19.93/kg to ~EUR 26/kg, invalidating all three locked scenarios simultaneously without a revised cost model or adopter renegotiation protocol; (2) Cost-Gap Amplification Loop: unresolved gap-funding by Month 7 (2027-05-09) forces Phase-Two hardware release (EUR 4.0M) on momentum, which consumes the budget before the gap is addressed, creating a sunk-cost trap that a Stop recommendation at the Phase-Two gate cannot undo; (3) Documentation-Defect-to-Safety-Incident Cascade: critical defects discovered during the Kenyan Phase-III production run (Months 48–54 = 2030-10-09 to 2031-04-09) cannot be resolved before the evidence freeze (Month 57 = 2031-07-09), forcing either an incomplete gate or a delayed decision past the Month 60 (2031-10-09) deadline.

**Mitigation**: Establish a Cross-Impact and Cascade Register by Month 1 (2026-11-09) identifying the three highest-consequence multi-node cascades listed above. For each cascade, define: trigger condition (e.g., 'primary strain blocked by Month 4 = 2027-02-09'), impact chain (productivity loss → cost increase → scenario invalidation), interdependencies (strain choice affects cost model, which affects adopter commitment, which affects gate criteria), NO-GO/contingency thresholds (e.g., 'if backup strain is <80% as productive as primary, automatically trigger cost-model re-run and adopter-scenario renegotiation by Month 5 = 2027-03-09'), and owner/decision authority per node. Include the cascade register in monthly steering-committee reports and trigger panel escalation if any threshold is approached.