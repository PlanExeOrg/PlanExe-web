### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and direction for the Eurovision 2026 project, given its high budget, multiple stakeholders, and significant impact on Austria's international image.

**Responsibilities:**

- Approve the overall project plan and budget.
- Provide strategic guidance and direction to the Project Management Office.
- Approve major project milestones and deliverables.
- Monitor project progress and performance against key performance indicators (KPIs).
- Oversee risk management and ensure appropriate mitigation strategies are in place.
- Resolve escalated issues and conflicts.
- Approve budget changes exceeding €500,000.
- Approve significant changes to project scope or objectives.

**Initial Setup Actions:**

- Finalize the Committee's Terms of Reference.
- Appoint the Committee Chair.
- Establish a regular meeting schedule.
- Review and approve the initial project plan and budget.

**Membership:**

- ORF Director-General (Chair)
- EBU Representative
- Vienna City Government Representative
- Independent Financial Expert
- Project Management Office Director

**Decision Rights:** Strategic decisions related to project scope, budget, timeline, and key risks. Approval of budget changes exceeding €500,000.

**Decision Mechanism:** Decisions are made by majority vote. In the event of a tie, the ORF Director-General (Chair) has the casting vote.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against KPIs.
- Discussion of key risks and mitigation strategies.
- Approval of major project milestones and deliverables.
- Review of budget performance and approval of budget changes.
- Discussion of strategic issues and challenges.

**Escalation Path:** ORF Director-General
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages the day-to-day execution of the Eurovision 2026 project, ensuring efficient resource allocation, risk management, and communication across all project teams.

**Responsibilities:**

- Develop and maintain the project plan.
- Manage the project budget and track expenses.
- Coordinate the activities of all project teams.
- Monitor project progress and performance.
- Identify and manage project risks.
- Communicate project status to stakeholders.
- Implement project governance processes and procedures.
- Manage budget items below €500,000.

**Initial Setup Actions:**

- Establish the PMO structure and staffing.
- Develop project management processes and procedures.
- Implement project management software.
- Develop a communication plan.

**Membership:**

- PMO Director
- Project Managers (Venue, Production, Marketing, Security)
- Finance Manager
- Communications Manager
- Risk Manager

**Decision Rights:** Operational decisions related to project execution, resource allocation, and risk management within the approved budget. Management of budget items below €500,000.

**Decision Mechanism:** Decisions are made by the PMO Director in consultation with the relevant Project Managers. Conflicts are resolved through discussion and consensus.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against the project plan.
- Discussion of key risks and issues.
- Review of budget performance.
- Coordination of activities across project teams.
- Communication of project status to stakeholders.

**Escalation Path:** Project Steering Committee
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and guidance on venue renovation, broadcast technology, and digital engagement strategies, ensuring the project leverages the latest innovations and meets the highest technical standards.

**Responsibilities:**

- Provide technical advice and guidance on venue renovation.
- Evaluate and recommend broadcast technology solutions.
- Advise on digital engagement strategies.
- Review technical specifications and designs.
- Assess the feasibility of new technologies.
- Ensure compliance with technical standards and regulations.

**Initial Setup Actions:**

- Identify and recruit technical experts.
- Define the scope of the Technical Advisory Group's responsibilities.
- Establish a communication protocol with the PMO.
- Review the initial venue renovation plans and broadcast technology proposals.

**Membership:**

- Senior Broadcast Engineer (ORF)
- Venue Architect
- Digital Technology Expert
- Sound and Lighting Specialist
- Independent Technical Consultant

**Decision Rights:** Provides recommendations on technical aspects of the project. Does not have direct decision-making authority but its recommendations are strongly considered by the PMO and Steering Committee.

**Decision Mechanism:** Recommendations are made by consensus. If consensus cannot be reached, the Independent Technical Consultant's opinion prevails.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of venue renovation plans.
- Evaluation of broadcast technology proposals.
- Discussion of digital engagement strategies.
- Assessment of new technologies.
- Review of technical specifications and designs.

**Escalation Path:** Project Steering Committee
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures the project adheres to the highest ethical standards, complies with all relevant laws and regulations (including GDPR), and mitigates risks related to corruption, fraud, and conflicts of interest.

**Responsibilities:**

- Develop and implement an ethics and compliance program.
- Ensure compliance with Austrian laws, EBU regulations, and GDPR.
- Investigate allegations of fraud, corruption, or ethical violations.
- Provide training on ethics and compliance to project staff.
- Review and approve contracts and agreements to ensure compliance.
- Monitor project activities for potential conflicts of interest.
- Oversee data protection and privacy measures.

**Initial Setup Actions:**

- Develop an ethics and compliance policy.
- Establish a reporting mechanism for ethical violations.
- Conduct a risk assessment to identify potential compliance issues.
- Develop a training program on ethics and compliance.

**Membership:**

- Legal Counsel (ORF)
- Compliance Officer (ORF)
- Data Protection Officer (ORF)
- Independent Ethics Expert
- EBU Compliance Representative

**Decision Rights:** Authority to investigate ethical violations and recommend corrective actions. Authority to approve contracts and agreements from a compliance perspective. Authority to halt project activities if there is a significant compliance risk.

**Decision Mechanism:** Decisions are made by majority vote. The Independent Ethics Expert must be in agreement for any decision related to ethical violations.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of compliance with laws and regulations.
- Investigation of ethical violations.
- Review of contracts and agreements.
- Discussion of data protection and privacy issues.
- Training on ethics and compliance.

**Escalation Path:** ORF Director-General
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Facilitates effective communication and collaboration with key stakeholders, including local communities, sponsors, participating countries, and tourism agencies, ensuring their needs and concerns are addressed throughout the project lifecycle.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct regular meetings and consultations with stakeholders.
- Address stakeholder concerns and feedback.
- Communicate project updates to stakeholders.
- Manage relationships with key stakeholders.
- Ensure stakeholder satisfaction.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop a stakeholder engagement plan.
- Establish communication channels with stakeholders.
- Conduct initial meetings with key stakeholders.

**Membership:**

- Communications Manager (PMO)
- Community Relations Manager
- Sponsorship Manager
- Participating Countries Liaison
- Tourism Agency Representative

**Decision Rights:** Provides recommendations on stakeholder engagement strategies. Does not have direct decision-making authority but its recommendations are strongly considered by the PMO and Steering Committee.

**Decision Mechanism:** Recommendations are made by consensus. If consensus cannot be reached, the Communications Manager has the final say.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of stakeholder feedback.
- Discussion of stakeholder concerns.
- Communication of project updates.
- Planning of stakeholder engagement activities.
- Review of stakeholder satisfaction.

**Escalation Path:** Project Steering Committee