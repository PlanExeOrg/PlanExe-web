# Governance Audit


## Audit - Corruption Risks

- Bribery of city officials to expedite permitting processes for venue renovation.
- Kickbacks from contractors selected for venue infrastructure upgrades.
- Conflicts of interest in the selection of sponsors, favoring companies with personal connections to project team members.
- Misuse of confidential information regarding ticketing strategies to benefit scalpers or related parties.
- Nepotism in the hiring of personnel for key project roles, compromising competence and accountability.

## Audit - Misallocation Risks

- Inflated invoices from contractors for venue renovation, with the excess funds diverted for personal use.
- Double-billing for marketing expenses, with the same costs claimed from both ORF and EBU.
- Inefficient allocation of resources to sustainability initiatives, prioritizing symbolic gestures over impactful measures.
- Unauthorized use of project funds for personal travel or entertainment expenses.
- Misreporting of progress on venue renovation to conceal delays and cost overruns.

## Audit - Procedures

- Conduct quarterly internal audits of all financial transactions, focusing on high-value contracts and expense claims.
- Engage an external auditor to perform a comprehensive review of project finances and compliance with EBU regulations after the event.
- Implement a contract review threshold of €50,000, requiring independent legal review for all contracts exceeding this amount.
- Establish a detailed expense workflow with mandatory approval levels for all expenditures, ensuring proper documentation and justification.
- Perform regular compliance checks to ensure adherence to Austrian building codes, safety regulations, and environmental standards.

## Audit - Transparency Measures

- Publish a project progress dashboard on the ORF website, providing real-time updates on key milestones, budget expenditures, and risk mitigation efforts.
- Publish minutes of key meetings of the Project Management Office (PMO) on the ORF website, documenting decisions and action items.
- Establish a confidential whistleblower mechanism for reporting suspected fraud, corruption, or ethical violations.
- Make relevant project policies and reports (e.g., environmental impact assessment, risk management plan) publicly accessible on the ORF website.
- Document and publish the selection criteria for major decisions, including venue selection, contractor selection, and sponsor selection.

# Internal Governance Bodies

### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and direction for the Eurovision 2026 project, given its high budget, multiple stakeholders, and significant impact on Austria's international image.

**Responsibilities:**

- Approve the overall project plan and budget.
- Provide strategic guidance and direction to the Project Management Office.
- Approve major project milestones and deliverables.
- Monitor project progress and performance against key performance indicators (KPIs).
- Oversee risk management and ensure appropriate mitigation strategies are in place.
- Resolve escalated issues and conflicts.
- Approve budget changes exceeding €500,000.
- Approve significant changes to project scope or objectives.

**Initial Setup Actions:**

- Finalize the Committee's Terms of Reference.
- Appoint the Committee Chair.
- Establish a regular meeting schedule.
- Review and approve the initial project plan and budget.

**Membership:**

- ORF Director-General (Chair)
- EBU Representative
- Vienna City Government Representative
- Independent Financial Expert
- Project Management Office Director

**Decision Rights:** Strategic decisions related to project scope, budget, timeline, and key risks. Approval of budget changes exceeding €500,000.

**Decision Mechanism:** Decisions are made by majority vote. In the event of a tie, the ORF Director-General (Chair) has the casting vote.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against KPIs.
- Discussion of key risks and mitigation strategies.
- Approval of major project milestones and deliverables.
- Review of budget performance and approval of budget changes.
- Discussion of strategic issues and challenges.

**Escalation Path:** ORF Director-General
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages the day-to-day execution of the Eurovision 2026 project, ensuring efficient resource allocation, risk management, and communication across all project teams.

**Responsibilities:**

- Develop and maintain the project plan.
- Manage the project budget and track expenses.
- Coordinate the activities of all project teams.
- Monitor project progress and performance.
- Identify and manage project risks.
- Communicate project status to stakeholders.
- Implement project governance processes and procedures.
- Manage budget items below €500,000.

**Initial Setup Actions:**

- Establish the PMO structure and staffing.
- Develop project management processes and procedures.
- Implement project management software.
- Develop a communication plan.

**Membership:**

- PMO Director
- Project Managers (Venue, Production, Marketing, Security)
- Finance Manager
- Communications Manager
- Risk Manager

**Decision Rights:** Operational decisions related to project execution, resource allocation, and risk management within the approved budget. Management of budget items below €500,000.

**Decision Mechanism:** Decisions are made by the PMO Director in consultation with the relevant Project Managers. Conflicts are resolved through discussion and consensus.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against the project plan.
- Discussion of key risks and issues.
- Review of budget performance.
- Coordination of activities across project teams.
- Communication of project status to stakeholders.

**Escalation Path:** Project Steering Committee
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and guidance on venue renovation, broadcast technology, and digital engagement strategies, ensuring the project leverages the latest innovations and meets the highest technical standards.

**Responsibilities:**

- Provide technical advice and guidance on venue renovation.
- Evaluate and recommend broadcast technology solutions.
- Advise on digital engagement strategies.
- Review technical specifications and designs.
- Assess the feasibility of new technologies.
- Ensure compliance with technical standards and regulations.

**Initial Setup Actions:**

- Identify and recruit technical experts.
- Define the scope of the Technical Advisory Group's responsibilities.
- Establish a communication protocol with the PMO.
- Review the initial venue renovation plans and broadcast technology proposals.

**Membership:**

- Senior Broadcast Engineer (ORF)
- Venue Architect
- Digital Technology Expert
- Sound and Lighting Specialist
- Independent Technical Consultant

**Decision Rights:** Provides recommendations on technical aspects of the project. Does not have direct decision-making authority but its recommendations are strongly considered by the PMO and Steering Committee.

**Decision Mechanism:** Recommendations are made by consensus. If consensus cannot be reached, the Independent Technical Consultant's opinion prevails.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of venue renovation plans.
- Evaluation of broadcast technology proposals.
- Discussion of digital engagement strategies.
- Assessment of new technologies.
- Review of technical specifications and designs.

**Escalation Path:** Project Steering Committee
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures the project adheres to the highest ethical standards, complies with all relevant laws and regulations (including GDPR), and mitigates risks related to corruption, fraud, and conflicts of interest.

**Responsibilities:**

- Develop and implement an ethics and compliance program.
- Ensure compliance with Austrian laws, EBU regulations, and GDPR.
- Investigate allegations of fraud, corruption, or ethical violations.
- Provide training on ethics and compliance to project staff.
- Review and approve contracts and agreements to ensure compliance.
- Monitor project activities for potential conflicts of interest.
- Oversee data protection and privacy measures.

**Initial Setup Actions:**

- Develop an ethics and compliance policy.
- Establish a reporting mechanism for ethical violations.
- Conduct a risk assessment to identify potential compliance issues.
- Develop a training program on ethics and compliance.

**Membership:**

- Legal Counsel (ORF)
- Compliance Officer (ORF)
- Data Protection Officer (ORF)
- Independent Ethics Expert
- EBU Compliance Representative

**Decision Rights:** Authority to investigate ethical violations and recommend corrective actions. Authority to approve contracts and agreements from a compliance perspective. Authority to halt project activities if there is a significant compliance risk.

**Decision Mechanism:** Decisions are made by majority vote. The Independent Ethics Expert must be in agreement for any decision related to ethical violations.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of compliance with laws and regulations.
- Investigation of ethical violations.
- Review of contracts and agreements.
- Discussion of data protection and privacy issues.
- Training on ethics and compliance.

**Escalation Path:** ORF Director-General
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Facilitates effective communication and collaboration with key stakeholders, including local communities, sponsors, participating countries, and tourism agencies, ensuring their needs and concerns are addressed throughout the project lifecycle.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct regular meetings and consultations with stakeholders.
- Address stakeholder concerns and feedback.
- Communicate project updates to stakeholders.
- Manage relationships with key stakeholders.
- Ensure stakeholder satisfaction.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop a stakeholder engagement plan.
- Establish communication channels with stakeholders.
- Conduct initial meetings with key stakeholders.

**Membership:**

- Communications Manager (PMO)
- Community Relations Manager
- Sponsorship Manager
- Participating Countries Liaison
- Tourism Agency Representative

**Decision Rights:** Provides recommendations on stakeholder engagement strategies. Does not have direct decision-making authority but its recommendations are strongly considered by the PMO and Steering Committee.

**Decision Mechanism:** Recommendations are made by consensus. If consensus cannot be reached, the Communications Manager has the final say.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of stakeholder feedback.
- Discussion of stakeholder concerns.
- Communication of project updates.
- Planning of stakeholder engagement activities.
- Review of stakeholder satisfaction.

**Escalation Path:** Project Steering Committee

# Governance Implementation Plan

### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Structure Defined

### 2. Project Manager circulates Draft SteerCo ToR v0.1 for review by proposed members (ORF Director-General, EBU Representative, Vienna City Government Representative, Independent Financial Expert, Project Management Office Director).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Circulation Email
- Review Feedback

**Dependencies:**

- Draft SteerCo ToR v0.1
- Proposed Members List Available

### 3. Project Manager consolidates feedback and revises the SteerCo ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- SteerCo ToR v0.2
- Feedback Summary

**Dependencies:**

- Review Feedback Received

### 4. ORF Director-General (as the highest authority) formally approves the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** ORF Director-General

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- SteerCo ToR v0.2

### 5. ORF Director-General formally appoints the Chair of the Project Steering Committee (ORF Director-General themselves).

**Responsible Body/Role:** ORF Director-General

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SteerCo ToR v1.0

### 6. Project Manager formally confirms the membership of the Project Steering Committee with all nominated members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Membership Confirmation Emails
- Confirmed Members List

**Dependencies:**

- Appointment Confirmation Email
- Approved SteerCo ToR v1.0

### 7. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Confirmed Members List

### 8. Hold the initial Project Steering Committee kick-off meeting to review project goals, governance structure, and initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation Sent

### 9. Project Steering Committee approves the initial project plan and budget.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved Project Plan
- Approved Budget

**Dependencies:**

- Initial Project Steering Committee kick-off meeting held

### 10. Project Steering Committee delegates the establishment of the PMO to the PMO Director.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Delegation Letter

**Dependencies:**

- Initial Project Steering Committee kick-off meeting held

### 11. PMO Director establishes the PMO structure and staffing.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- PMO Structure Chart
- Staffing Plan

**Dependencies:**

- Delegation Letter

### 12. PMO Director develops project management processes and procedures.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Project Management Handbook

**Dependencies:**

- PMO Structure Chart
- Staffing Plan

### 13. PMO Director implements project management software.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Project Management Software Implementation
- User Training Materials

**Dependencies:**

- Project Management Handbook

### 14. PMO Director develops a communication plan.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Communication Plan

**Dependencies:**

- Project Management Software Implementation

### 15. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Approved Project Plan

### 16. Project Manager circulates Draft Technical Advisory Group ToR v0.1 for review by PMO Director.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Circulation Email
- Review Feedback

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1

### 17. Project Manager consolidates feedback and revises the Technical Advisory Group ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Technical Advisory Group ToR v0.2
- Feedback Summary

**Dependencies:**

- Review Feedback Received

### 18. PMO Director formally approves the Technical Advisory Group Terms of Reference.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved Technical Advisory Group ToR v1.0

**Dependencies:**

- Technical Advisory Group ToR v0.2

### 19. PMO Director identifies and recruits technical experts for the Technical Advisory Group (Senior Broadcast Engineer (ORF), Venue Architect, Digital Technology Expert, Sound and Lighting Specialist, Independent Technical Consultant).

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Nominated Members List

**Dependencies:**

- Approved Technical Advisory Group ToR v1.0

### 20. Project Manager formally confirms the membership of the Technical Advisory Group with all nominated members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Membership Confirmation Emails
- Confirmed Members List

**Dependencies:**

- Nominated Members List

### 21. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Confirmed Members List

### 22. Hold the initial Technical Advisory Group kick-off meeting to review project goals, governance structure, and initial priorities.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation Sent

### 23. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Approved Project Plan

### 24. Project Manager circulates Draft Ethics & Compliance Committee ToR v0.1 for review by Legal Counsel (ORF) and Compliance Officer (ORF).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Circulation Email
- Review Feedback

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 25. Project Manager consolidates feedback and revises the Ethics & Compliance Committee ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee ToR v0.2
- Feedback Summary

**Dependencies:**

- Review Feedback Received

### 26. Legal Counsel (ORF) formally approves the Ethics & Compliance Committee Terms of Reference.

**Responsible Body/Role:** Legal Counsel (ORF)

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Approved Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Ethics & Compliance Committee ToR v0.2

### 27. Legal Counsel (ORF) and Compliance Officer (ORF) identify and recruit members for the Ethics & Compliance Committee (Data Protection Officer (ORF), Independent Ethics Expert, EBU Compliance Representative).

**Responsible Body/Role:** Legal Counsel (ORF)

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Nominated Members List

**Dependencies:**

- Approved Ethics & Compliance Committee ToR v1.0

### 28. Project Manager formally confirms the membership of the Ethics & Compliance Committee with all nominated members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Membership Confirmation Emails
- Confirmed Members List

**Dependencies:**

- Nominated Members List

### 29. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Confirmed Members List

### 30. Hold the initial Ethics & Compliance Committee kick-off meeting to review project goals, governance structure, and initial priorities.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation Sent

### 31. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Approved Project Plan

### 32. Project Manager circulates Draft Stakeholder Engagement Group ToR v0.1 for review by Communications Manager (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Circulation Email
- Review Feedback

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1

### 33. Project Manager consolidates feedback and revises the Stakeholder Engagement Group ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 14

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group ToR v0.2
- Feedback Summary

**Dependencies:**

- Review Feedback Received

### 34. Communications Manager (PMO) formally approves the Stakeholder Engagement Group Terms of Reference.

**Responsible Body/Role:** Communications Manager (PMO)

**Suggested Timeframe:** Project Week 14

**Key Outputs/Deliverables:**

- Approved Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Stakeholder Engagement Group ToR v0.2

### 35. Communications Manager (PMO) identifies and recruits members for the Stakeholder Engagement Group (Community Relations Manager, Sponsorship Manager, Participating Countries Liaison, Tourism Agency Representative).

**Responsible Body/Role:** Communications Manager (PMO)

**Suggested Timeframe:** Project Week 15

**Key Outputs/Deliverables:**

- Nominated Members List

**Dependencies:**

- Approved Stakeholder Engagement Group ToR v1.0

### 36. Project Manager formally confirms the membership of the Stakeholder Engagement Group with all nominated members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 16

**Key Outputs/Deliverables:**

- Membership Confirmation Emails
- Confirmed Members List

**Dependencies:**

- Nominated Members List

### 37. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 16

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Confirmed Members List

### 38. Hold the initial Stakeholder Engagement Group kick-off meeting to review project goals, governance structure, and initial priorities.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 17

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation Sent

# Decision Escalation Matrix

**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic oversight.
Negative Consequences: Potential budget overruns and financial instability.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: Requires strategic decision-making and resource allocation beyond the PMO's capacity.
Negative Consequences: Project delays, increased costs, and potential failure to meet objectives.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: Requires higher-level arbitration to resolve conflicting priorities or perspectives.
Negative Consequences: Delays in procurement, potential selection of a suboptimal vendor, and internal conflicts.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: Significantly alters project objectives, budget, or timeline, requiring strategic alignment.
Negative Consequences: Scope creep, budget overruns, and failure to deliver intended benefits.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to ORF Director-General
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Technical Advisory Group Recommendation Rejected by PMO**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of TAG Recommendation and PMO Rationale; Final Decision
Rationale: Ensures technical expertise is appropriately considered and that deviations are justified.
Negative Consequences: Suboptimal technical solutions, increased risks, and potential project delays.

# Monitoring Progress

### 1. Tracking Key Performance Indicators (KPIs) against Project Plan
**Monitoring Tools/Platforms:**

  - Project Management Software Dashboard
  - KPI Tracking Spreadsheet
  - Monthly Progress Reports

**Frequency:** Monthly

**Responsible Role:** Project Manager

**Adaptation Process:** PMO proposes adjustments via Change Request to Steering Committee

**Adaptation Trigger:** KPI deviates >10% from target, or significant milestone delay

### 2. Regular Risk Register Review
**Monitoring Tools/Platforms:**

  - Risk Register Document
  - Project Management Software

**Frequency:** Bi-weekly

**Responsible Role:** Risk Manager

**Adaptation Process:** Risk mitigation plan updated by Risk Manager, approved by PMO

**Adaptation Trigger:** New critical risk identified, existing risk likelihood or impact increases significantly, or mitigation plan proves ineffective

### 3. Funding Model Performance Monitoring
**Monitoring Tools/Platforms:**

  - Financial Tracking Spreadsheet
  - Sponsorship Pipeline CRM/Spreadsheet
  - Ticketing Sales Data Platform

**Frequency:** Monthly

**Responsible Role:** Finance Manager

**Adaptation Process:** Finance Manager proposes adjustments to funding strategy, reviewed by PMO and Steering Committee

**Adaptation Trigger:** Projected revenue shortfall >5% from budget, sponsorship acquisition behind schedule, or ticketing sales below projections

### 4. Venue Renovation Progress Monitoring
**Monitoring Tools/Platforms:**

  - Construction Schedule (e.g., Gantt Chart)
  - Site Inspection Reports
  - Budget Tracking Spreadsheet

**Frequency:** Weekly

**Responsible Role:** Venue Project Manager

**Adaptation Process:** Venue Project Manager implements corrective actions, escalating significant delays or cost overruns to PMO and Steering Committee

**Adaptation Trigger:** Construction milestone delayed by >1 week, budget variance >5%, or critical path impacted

### 5. Host City Agreement Compliance Monitoring
**Monitoring Tools/Platforms:**

  - Host City Agreement Document
  - Meeting Minutes with Vienna City Government
  - Infrastructure Upgrade Tracking Spreadsheet

**Frequency:** Monthly

**Responsible Role:** Project Manager

**Adaptation Process:** Project Manager negotiates adjustments with Vienna City Government, escalating unresolved issues to Steering Committee

**Adaptation Trigger:** Vienna City Government fails to meet agreed-upon obligations (e.g., financial contributions, infrastructure upgrades, permitting timelines)

### 6. Stakeholder Engagement Effectiveness Monitoring
**Monitoring Tools/Platforms:**

  - Stakeholder Feedback Surveys
  - Meeting Minutes with Stakeholders
  - Communication Log

**Frequency:** Quarterly

**Responsible Role:** Stakeholder Engagement Group

**Adaptation Process:** Stakeholder Engagement Group adjusts communication strategies and engagement activities based on feedback, escalating significant concerns to PMO and Steering Committee

**Adaptation Trigger:** Negative feedback trend from key stakeholders, unresolved stakeholder concerns, or lack of stakeholder participation

### 7. Sustainability Initiatives Performance Monitoring
**Monitoring Tools/Platforms:**

  - Waste Diversion Tracking System
  - Carbon Emissions Report
  - Sustainability Audit Reports

**Frequency:** Quarterly

**Responsible Role:** Sustainability Manager

**Adaptation Process:** Sustainability Manager implements corrective actions, escalating significant deviations from sustainability goals to PMO and Steering Committee

**Adaptation Trigger:** Failure to meet waste diversion targets, carbon emissions exceeding acceptable levels, or negative publicity related to environmental impact

### 8. Security Protocol Effectiveness Monitoring
**Monitoring Tools/Platforms:**

  - Security Incident Reports
  - Attendee Perception Surveys
  - Security Audit Reports

**Frequency:** Monthly

**Responsible Role:** Security Manager

**Adaptation Process:** Security Manager updates security protocols and training programs, escalating significant security breaches or vulnerabilities to PMO and Steering Committee

**Adaptation Trigger:** Security incident occurs, attendee perception of safety declines, or security audit identifies significant vulnerabilities

### 9. Broadcast Rights Revenue Tracking
**Monitoring Tools/Platforms:**

  - Contract Database
  - Financial Statements
  - Viewership Data

**Frequency:** Monthly

**Responsible Role:** Finance Manager

**Adaptation Process:** Finance Manager adjusts broadcast rights strategy, escalating significant revenue shortfalls to PMO and Steering Committee

**Adaptation Trigger:** Broadcast rights revenue falls below projected targets, viewership numbers are lower than expected, or key broadcast partners express dissatisfaction

### 10. Legacy Planning Progress Monitoring
**Monitoring Tools/Platforms:**

  - Legacy Plan Document
  - Progress Reports on Legacy Initiatives
  - Stakeholder Feedback on Legacy Impact

**Frequency:** Quarterly

**Responsible Role:** Project Manager

**Adaptation Process:** Project Manager adjusts legacy plan based on progress and feedback, escalating significant challenges to PMO and Steering Committee

**Adaptation Trigger:** Legacy initiatives are not progressing as planned, stakeholder feedback on legacy impact is negative, or funding for legacy initiatives is at risk

# Governance Extra

## Governance Validation Checks

1. Point 1: Completeness Confirmation: All core requested components (internal_governance_bodies, governance_implementation_plan, decision_escalation_matrix, monitoring_progress) appear to be generated.
2. Point 2: Internal Consistency Check: The Implementation Plan uses defined governance bodies. The Escalation Matrix aligns with the governance hierarchy. Monitoring roles are defined and linked to specific bodies. The components appear logically consistent.
3. Point 3: Potential Gaps / Areas for Enhancement: The role and authority of the ORF Director-General, particularly as the Project Steering Committee Chair, needs further clarification. While they have a casting vote, the potential for bias or undue influence should be addressed with additional checks and balances.
4. Point 4: Potential Gaps / Areas for Enhancement: The Ethics & Compliance Committee's authority to 'halt project activities' needs more specific definition. What constitutes a 'significant compliance risk' that triggers this action? What is the process for resuming activities after a halt?
5. Point 5: Potential Gaps / Areas for Enhancement: The Stakeholder Engagement Group's recommendations are 'strongly considered' but lack direct decision-making authority. The process for addressing situations where the PMO or Steering Committee consistently disregards their input should be defined.
6. Point 6: Potential Gaps / Areas for Enhancement: The adaptation processes in the Monitoring Progress plan often end with escalation to the Steering Committee. More granular delegation of authority to the PMO or specific project managers for certain types of adjustments (e.g., minor budget reallocations within pre-defined limits) would improve efficiency.
7. Point 7: Potential Gaps / Areas for Enhancement: The 'Independent Ethics Expert' role within the Ethics & Compliance Committee needs further definition. What are the criteria for selecting this expert? What specific qualifications or experience are required to ensure their independence and impartiality?

## Tough Questions

1. What is the current probability-weighted forecast for total ticket revenue, considering potential fluctuations in demand and external factors?
2. Show evidence of completed due diligence on all major sponsors to ensure alignment with the project's ethical and sustainability values.
3. What contingency plans are in place to address a potential security breach or terrorist threat during the event?
4. What is the detailed plan for managing potential conflicts of interest among project team members, particularly regarding vendor selection and contract negotiations?
5. What specific measures are being taken to ensure accessibility for disabled attendees at the venue and related events?
6. What is the process for verifying the accuracy and completeness of financial reports submitted by contractors and vendors?
7. What is the plan for addressing potential negative impacts on local communities, such as noise pollution and traffic congestion, during the event?

## Summary

The Eurovision 2026 governance framework establishes a multi-tiered structure with clear roles and responsibilities for strategic oversight, project management, technical guidance, ethical compliance, and stakeholder engagement. The framework emphasizes proactive monitoring and risk management, with defined escalation paths for critical issues. A key focus area is ensuring ethical conduct and compliance with relevant laws and regulations, as well as maintaining effective communication and collaboration with key stakeholders.