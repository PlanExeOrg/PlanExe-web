**Purpose:** business

**Purpose Detailed:** Planning and execution of a large-scale international event with significant economic and infrastructural implications.

**Topic:** Eurovision 2026 in Austria