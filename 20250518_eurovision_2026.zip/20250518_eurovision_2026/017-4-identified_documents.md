
## Documents to Create

### 1. Eurovision 2026 Project Charter

**ID:** 85e92990-7e51-49bc-8498-1d9490d2ee26

**Description:** A formal document authorizing the Eurovision 2026 project, outlining its objectives, scope, stakeholders, and governance structure. It serves as a high-level agreement among key stakeholders (EBU, ORF, Vienna City Government).

**Responsible Role Type:** Project Director

**Primary Template:** PMI Project Charter Template

**Steps:**

- Define project objectives and scope based on Austria's win and EBU requirements.
- Identify key stakeholders and their roles and responsibilities.
- Outline the project's governance structure and decision-making processes.
- Estimate the project budget and secure initial funding commitments.
- Obtain formal approval from the EBU, ORF, and Vienna City Government.

**Approval Authorities:** EBU Executive Supervisor, ORF Director General, Vienna Mayor

### 2. Eurovision 2026 Funding Model Strategy

**ID:** 825d7308-89d3-4ff6-9bb9-a5623ea0afb4

**Description:** A strategic plan outlining the approach to securing funding for Eurovision 2026, including revenue sources (sponsorships, ticketing, merchandise, tourism), funding targets, and risk mitigation strategies. Aligns with the 'Builder's Foundation' scenario.

**Responsible Role Type:** Financial Controller

**Steps:**

- Analyze potential revenue streams and estimate revenue potential for each source.
- Develop a tiered sponsorship package structure with varying levels of benefits and pricing.
- Create a detailed budget breakdown with cost estimates for all project activities.
- Identify potential funding gaps and develop strategies to address them.
- Establish financial controls and reporting mechanisms to track revenue and expenses.

**Approval Authorities:** ORF Director General, EBU Finance Committee

### 3. Eurovision 2026 Venue Infrastructure Framework

**ID:** e915f447-384b-4a7b-818d-4d030c6166ca

**Description:** A framework outlining the approach to venue selection, renovation, and infrastructure upgrades, including technical specifications, safety requirements, and accessibility standards. Aligns with the 'Builder's Foundation' scenario, focusing on renovating an existing stadium.

**Responsible Role Type:** Venue & Infrastructure Manager

**Steps:**

- Conduct a feasibility study to assess the suitability of existing venues in Vienna.
- Develop technical specifications for venue renovation and infrastructure upgrades.
- Ensure compliance with safety regulations, building codes, and accessibility standards.
- Develop a detailed renovation plan with timelines and cost estimates.
- Obtain necessary permits and approvals from the Vienna Building Authority.

**Approval Authorities:** Vienna Building Authority, ORF Technical Director

### 4. Eurovision 2026 Production Scale Strategy

**ID:** 24449b90-7b6e-4e0b-890e-fe24d487cf3e

**Description:** A strategy outlining the scope and complexity of the Eurovision 2026 performances, including the use of visual effects, stage design, and artistic collaborations. Aligns with the 'Builder's Foundation' scenario, showcasing Austria's natural beauty.

**Responsible Role Type:** Project Director

**Steps:**

- Define the artistic vision for the Eurovision 2026 performances.
- Develop a stage design concept that showcases Austrian culture and innovation.
- Identify potential artistic collaborations and partnerships.
- Estimate the cost of production elements, including visual effects, stage design, and artist fees.
- Ensure compliance with technical specifications and safety regulations.

**Approval Authorities:** ORF Entertainment Director, EBU Executive Supervisor

### 5. Eurovision 2026 Ticketing Strategy Plan

**ID:** cebce18a-6a40-4481-98ff-98c3ea66638b

**Description:** A plan outlining the approach to pricing, distributing, and selling tickets for Eurovision 2026, including revenue targets, accessibility considerations, and anti-scalping measures. Includes bundled packages with travel agencies.

**Responsible Role Type:** Ticketing & Hospitality Manager

**Steps:**

- Conduct market research to determine optimal ticket prices and demand.
- Develop a tiered pricing system with VIP packages, standard tickets, and budget options.
- Establish partnerships with travel agencies and hotels to create bundled packages.
- Implement anti-scalping measures, such as personalized tickets and purchase limits.
- Select a ticketing platform with robust security and reporting capabilities.

**Approval Authorities:** ORF Commercial Director, EBU Ticketing Committee

### 6. Eurovision 2026 Host City Agreement Framework

**ID:** 30b0d149-461e-44e4-a357-d6c684d5bfaf

**Description:** A framework outlining the terms and conditions of the agreement between ORF and the City of Vienna, including financial contributions, infrastructure upgrades, and permitting processes. Aims to minimize ORF's costs and streamline logistics.

**Responsible Role Type:** Project Director

**Steps:**

- Define the scope of the agreement, including financial contributions, infrastructure upgrades, and permitting processes.
- Negotiate favorable terms with the City of Vienna.
- Ensure compliance with legal and regulatory requirements.
- Obtain formal approval from the Vienna City Council and ORF Board.
- Establish a monitoring mechanism to track compliance with the agreement.

**Approval Authorities:** Vienna Mayor, ORF Director General

### 7. Eurovision 2026 Risk Register

**ID:** e72ecea7-b95d-40b0-8d87-a91f24fcae78

**Description:** A comprehensive register identifying potential risks to the Eurovision 2026 project, including security threats, logistical challenges, budget overruns, and reputational risks. Includes likelihood, impact, and mitigation strategies.

**Responsible Role Type:** Security & Risk Manager

**Primary Template:** PMI Risk Register Template

**Steps:**

- Identify potential risks through brainstorming sessions and expert consultations.
- Assess the likelihood and impact of each risk.
- Develop mitigation strategies to reduce the likelihood or impact of each risk.
- Assign responsibility for monitoring and managing each risk.
- Regularly review and update the risk register.

**Approval Authorities:** Project Director, ORF Risk Management Committee

### 8. Eurovision 2026 Communication Plan

**ID:** de3d11e9-52c1-4b3a-84c6-341e01baedad

**Description:** A plan outlining the communication strategy for Eurovision 2026, including target audiences, communication channels, messaging, and frequency of communication. Ensures regular updates to stakeholders and the public.

**Responsible Role Type:** Marketing & Communications Director

**Primary Template:** PMI Communication Plan Template

**Steps:**

- Identify key stakeholders and their communication needs.
- Define communication channels and messaging for each stakeholder group.
- Establish a communication schedule and frequency.
- Develop a crisis communication plan to address potential negative publicity.
- Monitor communication effectiveness and make adjustments as needed.

**Approval Authorities:** Project Director, ORF Public Relations Director

### 9. Eurovision 2026 Stakeholder Engagement Plan

**ID:** 9227a333-4490-4843-97f5-50f40f358ace

**Description:** A plan outlining the approach to engaging with key stakeholders, including the EBU, ORF, Vienna City Government, participating countries, sponsors, and local communities. Addresses concerns and builds support for the event.

**Responsible Role Type:** Marketing & Communications Director

**Steps:**

- Identify key stakeholders and their interests and concerns.
- Develop engagement strategies for each stakeholder group.
- Establish a communication plan to keep stakeholders informed.
- Conduct regular meetings and consultations with stakeholders.
- Address stakeholder concerns and build consensus.

**Approval Authorities:** Project Director, ORF Stakeholder Relations Director

### 10. Eurovision 2026 Change Management Plan

**ID:** 66d15a4b-06cc-4794-8012-2bd7cac218b9

**Description:** A plan outlining the process for managing changes to the Eurovision 2026 project, including change request procedures, impact assessment, and approval processes. Ensures changes are managed effectively and efficiently.

**Responsible Role Type:** Project Director

**Primary Template:** PMI Change Management Plan Template

**Steps:**

- Establish a change control board to review and approve change requests.
- Develop a change request form and process.
- Assess the impact of each change request on the project scope, schedule, and budget.
- Obtain approval from the change control board before implementing any changes.
- Communicate changes to stakeholders and update project documentation.

**Approval Authorities:** Change Control Board (Project Director, Financial Controller, Technical Director)

### 11. Eurovision 2026 High-Level Budget and Funding Framework

**ID:** bbcb7f03-b90f-4197-ad3e-f267fca945e4

**Description:** A high-level framework outlining the overall budget for Eurovision 2026, including revenue sources, cost categories, and funding allocation. Provides a financial overview of the project.

**Responsible Role Type:** Financial Controller

**Steps:**

- Identify all potential revenue sources, including ticket sales, sponsorships, merchandise, and tourism.
- Estimate the revenue potential for each source.
- Identify all cost categories, including venue, security, logistics, marketing, and personnel.
- Estimate the cost for each category.
- Allocate funding to each category based on priorities and revenue projections.

**Approval Authorities:** ORF Director General, EBU Finance Committee

### 12. Eurovision 2026 Funding Agreement Structure/Template

**ID:** 37d9fe22-94ad-41a5-8a3f-432470e81f01

**Description:** A template for structuring funding agreements with sponsors, the host city, and other funding sources. Ensures clear terms and conditions for all funding arrangements.

**Responsible Role Type:** Legal Counsel

**Steps:**

- Develop a standard funding agreement template with legal counsel.
- Define the terms and conditions for each funding source.
- Ensure compliance with legal and regulatory requirements.
- Negotiate agreements with sponsors, the host city, and other funding sources.
- Obtain formal approval from all parties.

**Approval Authorities:** ORF Legal Counsel, EBU Legal Department

### 13. Eurovision 2026 Initial High-Level Schedule/Timeline

**ID:** 096982f1-7214-4eb7-a2cb-8da5d9f58354

**Description:** An initial high-level schedule outlining key milestones and deadlines for Eurovision 2026, including venue selection, renovation, artist selection, and event promotion. Provides a roadmap for the project.

**Responsible Role Type:** Project Director

**Primary Template:** Gantt Chart Template

**Steps:**

- Identify key milestones and deadlines for the project.
- Develop a high-level schedule outlining the sequence of activities.
- Estimate the duration of each activity.
- Assign responsibility for completing each activity.
- Regularly review and update the schedule.

**Approval Authorities:** Project Director, ORF Program Director

### 14. Eurovision 2026 M&E Framework

**ID:** 75da0954-b36d-46df-851a-a7209ad634dc

**Description:** A framework outlining the monitoring and evaluation approach for Eurovision 2026, including key performance indicators (KPIs), data collection methods, and reporting frequency. Tracks progress and measures success.

**Responsible Role Type:** Project Director

**Primary Template:** World Bank Logical Framework

**Steps:**

- Identify key performance indicators (KPIs) for measuring project success.
- Develop data collection methods to track progress against KPIs.
- Establish a reporting frequency and format.
- Analyze data and identify areas for improvement.
- Communicate findings to stakeholders and make adjustments as needed.

**Approval Authorities:** Project Director, ORF Research Director, EBU Monitoring Committee

## Documents to Find

### 1. Participating Nations Eurovision Viewership Data

**ID:** 954070ec-dddc-4574-bbc4-35b2a1b21a43

**Description:** Historical Eurovision viewership data from participating nations. Used to estimate potential audience size and inform marketing strategies. Intended audience: Marketing & Communications team.

**Recency Requirement:** Past 5 years

**Responsible Role Type:** Marketing & Communications Director

**Access Difficulty:** Medium: Requires contacting EBU and searching broadcasting archives.

**Steps:**

- Contact EBU for historical viewership data.
- Search national broadcasting archives for viewership statistics.
- Review academic studies on Eurovision viewership.

### 2. Participating Nations Economic Indicators

**ID:** 0c2dab54-3e81-4df5-9478-a905282f9645

**Description:** Economic indicators (GDP, tourism revenue) from participating nations. Used to assess the potential economic impact of Eurovision 2026. Intended audience: Financial Controller.

**Recency Requirement:** Most recent available year

**Responsible Role Type:** Financial Controller

**Access Difficulty:** Easy: Publicly available data from World Bank and national statistical offices.

**Steps:**

- Access World Bank Open Data.
- Consult national statistical offices for economic data.
- Review reports from international economic organizations.

### 3. Existing Vienna Building Codes and Regulations

**ID:** 22018dd2-eb99-4383-b46b-f6ed95efd97f

**Description:** Current building codes and regulations in Vienna. Used to ensure compliance during venue renovation. Intended audience: Venue & Infrastructure Manager.

**Recency Requirement:** Current regulations essential

**Responsible Role Type:** Venue & Infrastructure Manager

**Access Difficulty:** Medium: Requires contacting the Vienna Building Authority and navigating government websites.

**Steps:**

- Contact Vienna Building Authority.
- Search the Vienna city government website.
- Consult with local architects and engineers.

### 4. Existing Vienna Event Permitting Processes

**ID:** 7fbdfee7-9cd3-4451-8b4e-3d7394fa55a3

**Description:** Information on the event permitting processes in Vienna. Used to streamline the permitting process for Eurovision 2026. Intended audience: Project Director.

**Recency Requirement:** Current processes essential

**Responsible Role Type:** Project Director

**Access Difficulty:** Medium: Requires contacting the Vienna city government and navigating government websites.

**Steps:**

- Contact Vienna city government.
- Search the Vienna city government website.
- Consult with local event organizers.

### 5. Existing Austrian Safety Regulations

**ID:** 74c7b72c-d360-4a93-b135-f8352330ba7b

**Description:** Current safety regulations in Austria. Used to ensure the safety of attendees and performers. Intended audience: Security & Risk Manager.

**Recency Requirement:** Current regulations essential

**Responsible Role Type:** Security & Risk Manager

**Access Difficulty:** Medium: Requires contacting the Austrian Ministry of Interior and navigating government websites.

**Steps:**

- Contact Austrian Ministry of Interior.
- Search the Austrian government website.
- Consult with local security experts.

### 6. Existing EBU Broadcasting Standards

**ID:** b0b398ad-3a97-475c-9ad0-5741df842073

**Description:** Current broadcasting standards from the EBU. Used to ensure compliance with broadcasting requirements. Intended audience: ORF Technical Director.

**Recency Requirement:** Current standards essential

**Responsible Role Type:** ORF Technical Director

**Access Difficulty:** Medium: Requires contacting the EBU and accessing their website.

**Steps:**

- Contact EBU Technical Department.
- Access EBU website for broadcasting standards.
- Consult with broadcasting engineers.

### 7. Historical Eurovision Ticketing Data

**ID:** 02882a33-7dc4-4bc1-b0fe-a2442d0cd7c8

**Description:** Historical data on Eurovision ticket sales, pricing, and demand. Used to inform ticketing strategies and revenue projections. Intended audience: Ticketing & Hospitality Manager.

**Recency Requirement:** Past 5 years

**Responsible Role Type:** Ticketing & Hospitality Manager

**Access Difficulty:** Medium: Requires contacting the EBU and searching online communities.

**Steps:**

- Contact EBU Ticketing Committee.
- Search Eurovision fan forums and online communities.
- Review reports from previous host cities.

### 8. Existing Vienna Tourism Statistics

**ID:** 748fbf56-d2fa-4a9d-9c0e-3507337f96ab

**Description:** Current tourism statistics for Vienna. Used to assess the potential economic impact of Eurovision 2026 on tourism. Intended audience: Financial Controller.

**Recency Requirement:** Most recent available year

**Responsible Role Type:** Financial Controller

**Access Difficulty:** Easy: Publicly available data from Vienna Tourist Board and government websites.

**Steps:**

- Contact Vienna Tourist Board.
- Search the Vienna city government website.
- Review reports from tourism organizations.

### 9. Existing Austrian Environmental Regulations

**ID:** 13e45abe-bb66-4f7d-8127-d5cfac26ece4

**Description:** Current environmental regulations in Austria. Used to ensure compliance with environmental requirements. Intended audience: Sustainability Officer.

**Recency Requirement:** Current regulations essential

**Responsible Role Type:** Sustainability Officer

**Access Difficulty:** Medium: Requires contacting the Austrian Ministry of Environment and navigating government websites.

**Steps:**

- Contact Austrian Ministry of Environment.
- Search the Austrian government website.
- Consult with environmental consultants.