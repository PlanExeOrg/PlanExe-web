Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 15 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 4 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project focuses on event management, logistics, and entertainment, which are all within the bounds of known physics.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (Eurovision) + market (Austria) + tech/process (renovation & digital engagement) + policy (host city agreement) without independent evidence at comparable scale. There is no mention of precedent for this specific combination.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Owner: Project Director / Deliverable: Validation Report / Date: 2025-06-30


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions buzzwords like "sustainability" and "community engagement" without defining a business-level mechanism-of-action, owner, or measurable outcomes. The plan states, "We're crafting an event that blends Austrian charm with world-class entertainment, all while staying true to our values of sustainability and community engagement."

**Mitigation**: Project Director: Create one-pagers for 'sustainability' and 'community engagement' defining inputs→process→customer value, owners, measurable outcomes, value hypotheses, success metrics, and decision hooks. Date: 2025-07-01


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies risks (regulatory, technical, financial, etc.) and mitigation strategies. However, it lacks explicit analysis of risk cascades. The plan mentions "Robust contingency plans" but doesn't map out how one risk event triggers others.

**Mitigation**: Risk Manager: Create a risk cascade diagram illustrating how initial risks (e.g., permit delays) trigger subsequent financial, legal, or reputational impacts. Due: 2025-07-01.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions "streamlined permitting processes" in the Host City Agreement, but there is no evidence of a permit matrix or lead time analysis.

**Mitigation**: Project Director: Create a permit/approval matrix with all required permits, responsible parties, typical lead times in Vienna, and scheduled dates. Due: 2025-07-01.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions funding sources (EBU, ORF, sponsorships, ticketing, crowdfunding) but lacks specifics on their status (LOI/term sheet/closed), draw schedule, covenants, and runway length. The plan states, "Dedicated funding from EBU, ORF, and host city contributions."

**Mitigation**: Project Director: Create a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates. Due: 2025-07-01.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget conflicts with vendor quotes or scale-appropriate benchmarks. The plan lacks evidence of cost per m²/ft² applied to the stated footprint, which is critical for validation.

**Mitigation**: Owner: Financial Controller, Deliverable: Obtain ≥3 relevant comparables and quotes, normalize per-area, and adjust budget or de-scope by 2025-09-30.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (budget, venue capacity) as single numbers without ranges or alternative scenarios. The plan states, "within a budget of €30-40 million" and "Venue capable of accommodating 10,000-15,000 spectators."

**Mitigation**: Financial Controller: Conduct a sensitivity analysis for the budget and venue capacity, creating best/worst/base-case scenarios. Due: 2025-07-01.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because build‑critical components lack engineering artifacts. The plan mentions "Venue Infrastructure" and "Production Scale" but lacks technical specifications, interface definitions, test plans, and integration maps. The plan states, "Finalize venue renovation plans" without detailing the engineering process.

**Mitigation**: Venue & Infrastructure Manager and Production Manager: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components by 2025-09-30.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes critical claims without verifiable artifacts. For example, the plan states, "Secure funding from the EBU, ORF, and host city." There is no evidence of signed agreements or commitment letters.

**Mitigation**: Project Director: Obtain commitment letters or signed agreements from the EBU, ORF, and host city by 2025-07-01, or change scope.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project mentions "a high-quality event" without defining specific, verifiable qualities. The goal statement is "Host the Eurovision Song Contest 2026 in Vienna, Austria, delivering a high-quality event within a budget of €30-40 million."

**Mitigation**: Project Director: Define SMART criteria for 'high-quality event,' including a KPI for audience satisfaction (e.g., 90% positive feedback). Due: 2025-07-01.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes "augmented reality and virtual production techniques" without demonstrating how this demonstrably supports the core project goals of "showcasing Austrian culture" or "maximizing economic benefits".

**Mitigation**: Technology Team: Produce a one-page benefit case justifying AR/VR inclusion, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog. Due: 2025-07-01


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a "Project Director" with 15+ years of experience in leading large-scale projects, strategic planning, stakeholder management, and risk mitigation. This role is essential and likely difficult to fill.

**Mitigation**: HR: Validate the talent market for a Project Director with 15+ years of relevant experience and a track record of success in similar large-scale events. Due: 2025-07-01.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a regulatory matrix (authority, artifact, lead time, predecessors) for permits and licenses. The plan states, "streamlined permitting processes" without evidence of feasibility.

**Mitigation**: Legal Team: Create a regulatory matrix identifying all required permits/licenses, authorities, artifacts, lead times, and predecessors. Flag showstoppers. Due: 2025-07-01.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "sustainability initiatives" and "legacy planning" but lacks a concrete plan for long-term operational sustainability. The plan focuses on the event itself, not post-event operations.

**Mitigation**: Project Director: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms. Due: 2025-09-30.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks evidence of zoning or land-use compliance for venue construction/renovation. The plan states, "Renovate and expand an existing indoor stadium in Vienna" without evidence of zoning compliance.

**Mitigation**: Legal Team: Conduct a fatal-flaw screen with Vienna authorities to confirm zoning/land-use compliance for venue renovation. Due: 2025-07-01.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions vendors and facilities but lacks details on redundancy, tested failover, SLAs, or contracts. The plan states, "Secure funding from the EBU, ORF, and host city." but does not address vendor resilience.

**Mitigation**: Operations Team: Secure SLAs with key vendors (e.g., power, water, internet) including redundancy and tested failover procedures. Due: 2025-09-30.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the 'Finance Department' is incentivized by budget adherence, while the 'Marketing Team' is incentivized by maximizing event attendance and revenue, creating a conflict over marketing spend. The plan lacks a shared objective.

**Mitigation**: Project Director: Define a shared, measurable objective (OKR) that aligns both the Finance Department and the Marketing Team on a common outcome, such as ROI. Due: 2025-07-01.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a change-control process. The plan mentions "Regular meetings with stakeholders" but lacks specifics.

**Mitigation**: Project Director: Implement a monthly review with a KPI dashboard and a lightweight change board with thresholds for re-planning. Due: 2025-07-01.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has ≥3 High risks (Funding Model, Venue Infrastructure, Talent Acquisition) that are strongly coupled. A Funding Model shortfall can cascade to Venue Infrastructure and Talent Acquisition, triggering multi-domain failure.

**Mitigation**: Project Director: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO‑GO/contingency thresholds. Due: 2025-09-30.