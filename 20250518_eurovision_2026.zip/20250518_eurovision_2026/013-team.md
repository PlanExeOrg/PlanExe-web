*Roles Needed & Example People*

# Roles

## 1. Project Director

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Critical leadership role requiring full commitment and long-term involvement in strategic decision-making.

**Explanation**:
Provides overall leadership, strategic direction, and ensures alignment with the EBU and ORF's vision.

**Consequences**:
Lack of clear leadership, strategic drift, and failure to meet project goals.

**People Count**:
1

**Typical Activities**:
Providing strategic direction, overseeing all project activities, managing key stakeholders (EBU, ORF, Vienna City Government), ensuring alignment with project goals, and making critical decisions to keep the project on track.

**Background Story**:
Klaus Richter, a native of Vienna, Austria, has dedicated his career to event management. With a master's degree in Business Administration from the Vienna University of Economics and Business, Klaus has over 15 years of experience in leading large-scale projects, including international conferences and cultural festivals. He is highly skilled in strategic planning, stakeholder management, and risk mitigation. Klaus is familiar with the Eurovision Song Contest, having attended several editions and studied its organizational structure. His deep understanding of Austrian culture and his extensive network within the local business community make him the ideal Project Director for Eurovision 2026.

**Equipment Needs**:
Laptop with project management software (e.g., Asana, Jira), communication tools (email, video conferencing), and access to relevant databases. Mobile phone.

**Facility Needs**:
Dedicated office space with reliable internet access, meeting rooms for stakeholder meetings, and access to administrative support.

## 2. Venue & Infrastructure Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires dedicated oversight of venue and infrastructure, demanding consistent availability and control over the renovation process.

**Explanation**:
Oversees venue selection, renovation, and ensures it meets all technical and safety requirements.

**Consequences**:
Venue not ready on time, safety issues, and failure to meet technical requirements for the broadcast.

**People Count**:
min 1, max 2, depending on the complexity of the renovation and the number of venues used.

**Typical Activities**:
Overseeing venue selection and renovation, ensuring compliance with safety and technical requirements, managing construction teams, coordinating with architects and engineers, and resolving any infrastructure-related issues.

**Background Story**:
Ingrid Steiner, originally from Graz, Austria, is a seasoned Venue & Infrastructure Manager with a background in civil engineering and architecture from the Technical University of Graz. Ingrid has spent the last decade working on major construction and renovation projects across Austria, including sports arenas and concert halls. She possesses strong technical skills in structural analysis, building codes, and project management. Ingrid is familiar with the Wiener Stadthalle, having previously worked on a minor renovation project there. Her expertise in venue infrastructure and her meticulous attention to detail make her the perfect choice to oversee the venue renovation for Eurovision 2026.

**Equipment Needs**:
Laptop with CAD software, building information modeling (BIM) software, and project management tools. Mobile phone, surveying equipment (if needed).

**Facility Needs**:
Office space at the venue during renovation, access to construction site, meeting rooms for coordinating with construction teams, architects, and engineers.

## 3. Financial Controller

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Essential for managing the budget and ensuring financial compliance throughout the project lifecycle.

**Explanation**:
Manages the budget, tracks expenses, and ensures financial compliance and transparency.

**Consequences**:
Budget overruns, financial mismanagement, and potential legal issues.

**People Count**:
1

**Typical Activities**:
Managing the project budget, tracking expenses, ensuring financial compliance, preparing financial reports, identifying cost-saving opportunities, and mitigating financial risks.

**Background Story**:
Franz Huber, born and raised in Salzburg, Austria, is a highly experienced Financial Controller with a degree in accounting from the University of Salzburg and a Certified Public Accountant (CPA) certification. Franz has over 20 years of experience in financial management, including budgeting, forecasting, and financial reporting for large organizations. He is proficient in financial software and has a strong understanding of Austrian financial regulations. Franz has no direct experience with Eurovision, but his expertise in financial management and his meticulous attention to detail make him the ideal Financial Controller for Eurovision 2026.

**Equipment Needs**:
Laptop with accounting software (e.g., SAP, Oracle), financial modeling tools, and access to financial databases. Mobile phone.

**Facility Needs**:
Dedicated office space with secure access to financial systems, meeting rooms for financial reporting and budget reviews.

## 4. Security & Risk Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Critical for developing and implementing security protocols, requiring full commitment to ensuring safety and mitigating risks.

**Explanation**:
Develops and implements security protocols, risk mitigation strategies, and emergency response plans.

**Consequences**:
Security breaches, safety incidents, and potential harm to attendees and performers.

**People Count**:
min 1, max 3, depending on the scale of security operations and the number of venues. More people are needed to cover different areas and shifts.

**Typical Activities**:
Developing and implementing security protocols, conducting risk assessments, coordinating with law enforcement agencies, training security personnel, managing emergency response plans, and ensuring the safety of attendees and performers.

**Background Story**:
Lena Schmidt, hailing from Innsbruck, Austria, is a dedicated Security & Risk Manager with a background in criminology and security studies from the University of Innsbruck. Lena has spent the last 12 years working in security management for major events and organizations, including the Winter Olympics and international conferences. She is highly skilled in risk assessment, security protocol development, and emergency response planning. Lena has no direct experience with Eurovision, but her expertise in security management and her proactive approach to risk mitigation make her the perfect choice to oversee security for Eurovision 2026.

**Equipment Needs**:
Laptop with security management software, risk assessment tools, and communication devices (e.g., radios). Mobile phone.

**Facility Needs**:
Office space with access to security monitoring systems, meeting rooms for coordinating with law enforcement and security personnel, on-site presence during events.

## 5. Ticketing & Hospitality Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires dedicated management of ticket sales and hospitality arrangements to maximize revenue and attendee satisfaction.

**Explanation**:
Manages ticket sales, pricing strategies, and VIP hospitality arrangements to maximize revenue and attendee satisfaction.

**Consequences**:
Lost revenue, dissatisfied attendees, and potential for scalping and fraud.

**People Count**:
min 1, max 2, depending on the complexity of the ticketing system and the scale of hospitality operations.

**Typical Activities**:
Managing ticket sales, developing pricing strategies, coordinating VIP hospitality arrangements, ensuring attendee satisfaction, preventing scalping and fraud, and maximizing revenue from ticketing and hospitality.

**Background Story**:
Maximilian Vogel, a Vienna native, is a dynamic Ticketing & Hospitality Manager with a degree in marketing and hospitality management from the MODUL University Vienna. Maximilian has over 8 years of experience in ticketing and hospitality for major events, including concerts, sports games, and festivals. He is skilled in pricing strategies, customer service, and VIP hospitality arrangements. Maximilian has attended several Eurovision Song Contests and is passionate about creating a memorable experience for attendees. His expertise in ticketing and hospitality and his passion for Eurovision make him the perfect choice to manage ticketing and hospitality for Eurovision 2026.

**Equipment Needs**:
Laptop with ticketing software, CRM system, and sales analytics tools. Mobile phone.

**Facility Needs**:
Office space with access to ticketing and hospitality systems, meeting rooms for coordinating with travel agencies and hospitality partners.

## 6. Marketing & Communications Director

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Essential for leading marketing campaigns and promoting the event to a global audience, requiring full commitment and strategic oversight.

**Explanation**:
Leads marketing campaigns, public relations efforts, and digital engagement strategies to promote the event and attract a global audience.

**Consequences**:
Low ticket sales, limited viewership, and failure to generate excitement and buzz around the event.

**People Count**:
min 1, max 2, depending on the breadth of the marketing campaign and the number of channels used.

**Typical Activities**:
Leading marketing campaigns, managing public relations efforts, developing digital engagement strategies, promoting the event to a global audience, generating excitement and buzz, and increasing ticket sales and viewership.

**Background Story**:
Sophie Weber, originally from Linz, Austria, is a creative Marketing & Communications Director with a degree in communications and marketing from the University of Vienna. Sophie has over 10 years of experience in leading marketing campaigns, public relations efforts, and digital engagement strategies for major brands and events. She is skilled in social media marketing, content creation, and media relations. Sophie has no direct experience with Eurovision, but her expertise in marketing and communications and her passion for promoting Austrian culture make her the perfect choice to lead marketing and communications for Eurovision 2026.

**Equipment Needs**:
Laptop with marketing automation software, social media management tools, and content creation software. Mobile phone.

**Facility Needs**:
Office space with access to marketing and communication systems, meeting rooms for campaign planning and media relations.

## 7. Volunteer Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires dedicated coordination of volunteers, ensuring adequate support for event operations and a positive attendee experience.

**Explanation**:
Recruits, trains, and manages volunteers to support various event operations and enhance the attendee experience.

**Consequences**:
Understaffed event operations, reduced efficiency, and negative impact on attendee experience.

**People Count**:
min 1, max 2, depending on the number of volunteers needed and the complexity of their roles.

**Typical Activities**:
Recruiting, training, and managing volunteers, coordinating volunteer schedules, assigning tasks, providing support and guidance, ensuring volunteer satisfaction, and enhancing the attendee experience through volunteer efforts.

**Background Story**:
Lukas Bauer, born and raised in Klagenfurt, Austria, is a dedicated Volunteer Coordinator with a background in social work and community engagement from the University of Klagenfurt. Lukas has spent the last 5 years working with non-profit organizations and community groups, recruiting, training, and managing volunteers for various events and initiatives. He is skilled in volunteer management, communication, and event coordination. Lukas has no direct experience with Eurovision, but his passion for community engagement and his expertise in volunteer management make him the perfect choice to coordinate volunteers for Eurovision 2026.

**Equipment Needs**:
Laptop with volunteer management software, communication tools, and database access. Mobile phone.

**Facility Needs**:
Office space with access to volunteer database, meeting rooms for volunteer training and coordination.

## 8. Sustainability Officer

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires dedicated focus on sustainability initiatives, ensuring the event minimizes its environmental impact and promotes responsible practices.

**Explanation**:
Develops and implements sustainability initiatives to minimize the environmental impact of the event and promote responsible practices.

**Consequences**:
Negative publicity, failure to meet sustainability goals, and damage to Austria's reputation as an environmentally conscious nation.

**People Count**:
1

**Typical Activities**:
Developing and implementing sustainability initiatives, conducting environmental impact assessments, promoting responsible practices, reducing waste, sourcing sustainable materials, offsetting carbon emissions, and engaging stakeholders in sustainability efforts.

**Background Story**:
Anna Leitner, a Salzburg native, is a passionate Sustainability Officer with a degree in environmental science from the University of Salzburg and a certification in sustainable event management. Anna has over 7 years of experience in developing and implementing sustainability initiatives for organizations and events, including waste reduction, recycling, and carbon offsetting programs. She is skilled in environmental impact assessment, sustainability reporting, and stakeholder engagement. Anna has no direct experience with Eurovision, but her expertise in sustainability and her commitment to promoting responsible practices make her the ideal Sustainability Officer for Eurovision 2026.

**Equipment Needs**:
Laptop with environmental impact assessment software, sustainability reporting tools, and access to environmental databases. Mobile phone.

**Facility Needs**:
Office space with access to sustainability data and reporting systems, meeting rooms for stakeholder engagement and sustainability planning.

---

# Omissions

## 1. Accessibility Coordinator

The current team lacks a dedicated role to ensure the event is accessible to people with disabilities. This is crucial for inclusivity and compliance with accessibility standards.

**Recommendation**:
Assign an existing team member (e.g., the Volunteer Coordinator or Ticketing & Hospitality Manager) to also act as the Accessibility Coordinator. Their responsibilities would include reviewing venue plans for accessibility, coordinating with disability advocacy groups, and ensuring accessible ticketing and transportation options.

## 2. Local Community Liaison

There is no specific role focused on managing relationships with the local community. This is important for addressing concerns, mitigating negative impacts, and fostering community support.

**Recommendation**:
Designate the Marketing & Communications Director or the Volunteer Coordinator to also serve as the Local Community Liaison. Their responsibilities would include organizing community meetings, addressing concerns about noise and traffic, and promoting local business involvement.

## 3. Digital Content Creator

While there's a Marketing & Communications Director, a dedicated role for creating engaging digital content is missing. This is crucial for maximizing online engagement and promoting the event through social media.

**Recommendation**:
Task the Marketing & Communications Director with delegating digital content creation tasks to a volunteer or intern. This person would be responsible for creating social media posts, short videos, and other engaging content to promote the event.

---

# Potential Improvements

## 1. Clarify Security & Risk Manager Responsibilities

The Security & Risk Manager role is broad. Clarifying the division of responsibilities between security and risk mitigation will improve focus and effectiveness.

**Recommendation**:
Specifically define the Security & Risk Manager's responsibilities. For example, security protocols, law enforcement coordination, and emergency response plans should be their primary focus, while financial and reputational risk mitigation could be a shared responsibility with the Financial Controller and Marketing & Communications Director, respectively.

## 2. Define Sustainability Officer Metrics

The Sustainability Officer role is well-defined, but lacks specific, measurable goals. Defining these will allow for better tracking of progress and impact.

**Recommendation**:
Establish specific, measurable, achievable, relevant, and time-bound (SMART) goals for the Sustainability Officer. Examples include reducing waste by a certain percentage, sourcing a specific amount of materials locally, or achieving a certain level of carbon offsetting.

## 3. Enhance Volunteer Coordinator Training

The Volunteer Coordinator role is crucial for event support, but the description lacks detail on training for handling diverse situations and attendee needs.

**Recommendation**:
Expand the Volunteer Coordinator's training program to include customer service skills, conflict resolution techniques, and information on assisting attendees with disabilities. This will improve the overall attendee experience.