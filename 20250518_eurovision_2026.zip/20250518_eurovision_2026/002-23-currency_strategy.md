This plan involves money.

## Currencies

- **EUR:** Euro is the official currency of Austria and the currency mentioned in the budget.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for all transactions. No additional international risk management is needed.