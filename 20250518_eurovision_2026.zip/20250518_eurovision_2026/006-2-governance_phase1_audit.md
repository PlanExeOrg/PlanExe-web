
## Audit - Corruption Risks

- Bribery of city officials to expedite permitting processes for venue renovation.
- Kickbacks from contractors selected for venue infrastructure upgrades.
- Conflicts of interest in the selection of sponsors, favoring companies with personal connections to project team members.
- Misuse of confidential information regarding ticketing strategies to benefit scalpers or related parties.
- Nepotism in the hiring of personnel for key project roles, compromising competence and accountability.

## Audit - Misallocation Risks

- Inflated invoices from contractors for venue renovation, with the excess funds diverted for personal use.
- Double-billing for marketing expenses, with the same costs claimed from both ORF and EBU.
- Inefficient allocation of resources to sustainability initiatives, prioritizing symbolic gestures over impactful measures.
- Unauthorized use of project funds for personal travel or entertainment expenses.
- Misreporting of progress on venue renovation to conceal delays and cost overruns.

## Audit - Procedures

- Conduct quarterly internal audits of all financial transactions, focusing on high-value contracts and expense claims.
- Engage an external auditor to perform a comprehensive review of project finances and compliance with EBU regulations after the event.
- Implement a contract review threshold of €50,000, requiring independent legal review for all contracts exceeding this amount.
- Establish a detailed expense workflow with mandatory approval levels for all expenditures, ensuring proper documentation and justification.
- Perform regular compliance checks to ensure adherence to Austrian building codes, safety regulations, and environmental standards.

## Audit - Transparency Measures

- Publish a project progress dashboard on the ORF website, providing real-time updates on key milestones, budget expenditures, and risk mitigation efforts.
- Publish minutes of key meetings of the Project Management Office (PMO) on the ORF website, documenting decisions and action items.
- Establish a confidential whistleblower mechanism for reporting suspected fraud, corruption, or ethical violations.
- Make relevant project policies and reports (e.g., environmental impact assessment, risk management plan) publicly accessible on the ORF website.
- Document and publish the selection criteria for major decisions, including venue selection, contractor selection, and sponsor selection.