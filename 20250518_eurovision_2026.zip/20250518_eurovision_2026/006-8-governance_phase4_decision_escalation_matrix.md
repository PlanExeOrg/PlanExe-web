**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic oversight.
Negative Consequences: Potential budget overruns and financial instability.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: Requires strategic decision-making and resource allocation beyond the PMO's capacity.
Negative Consequences: Project delays, increased costs, and potential failure to meet objectives.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: Requires higher-level arbitration to resolve conflicting priorities or perspectives.
Negative Consequences: Delays in procurement, potential selection of a suboptimal vendor, and internal conflicts.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: Significantly alters project objectives, budget, or timeline, requiring strategic alignment.
Negative Consequences: Scope creep, budget overruns, and failure to deliver intended benefits.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to ORF Director-General
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Technical Advisory Group Recommendation Rejected by PMO**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of TAG Recommendation and PMO Rationale; Final Decision
Rationale: Ensures technical expertise is appropriately considered and that deviations are justified.
Negative Consequences: Suboptimal technical solutions, increased risks, and potential project delays.