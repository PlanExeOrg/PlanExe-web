### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Structure Defined

### 2. Project Manager circulates Draft SteerCo ToR v0.1 for review by proposed members (ORF Director-General, EBU Representative, Vienna City Government Representative, Independent Financial Expert, Project Management Office Director).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Circulation Email
- Review Feedback

**Dependencies:**

- Draft SteerCo ToR v0.1
- Proposed Members List Available

### 3. Project Manager consolidates feedback and revises the SteerCo ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- SteerCo ToR v0.2
- Feedback Summary

**Dependencies:**

- Review Feedback Received

### 4. ORF Director-General (as the highest authority) formally approves the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** ORF Director-General

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- SteerCo ToR v0.2

### 5. ORF Director-General formally appoints the Chair of the Project Steering Committee (ORF Director-General themselves).

**Responsible Body/Role:** ORF Director-General

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SteerCo ToR v1.0

### 6. Project Manager formally confirms the membership of the Project Steering Committee with all nominated members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Membership Confirmation Emails
- Confirmed Members List

**Dependencies:**

- Appointment Confirmation Email
- Approved SteerCo ToR v1.0

### 7. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Confirmed Members List

### 8. Hold the initial Project Steering Committee kick-off meeting to review project goals, governance structure, and initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation Sent

### 9. Project Steering Committee approves the initial project plan and budget.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved Project Plan
- Approved Budget

**Dependencies:**

- Initial Project Steering Committee kick-off meeting held

### 10. Project Steering Committee delegates the establishment of the PMO to the PMO Director.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Delegation Letter

**Dependencies:**

- Initial Project Steering Committee kick-off meeting held

### 11. PMO Director establishes the PMO structure and staffing.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- PMO Structure Chart
- Staffing Plan

**Dependencies:**

- Delegation Letter

### 12. PMO Director develops project management processes and procedures.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Project Management Handbook

**Dependencies:**

- PMO Structure Chart
- Staffing Plan

### 13. PMO Director implements project management software.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Project Management Software Implementation
- User Training Materials

**Dependencies:**

- Project Management Handbook

### 14. PMO Director develops a communication plan.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Communication Plan

**Dependencies:**

- Project Management Software Implementation

### 15. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Approved Project Plan

### 16. Project Manager circulates Draft Technical Advisory Group ToR v0.1 for review by PMO Director.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Circulation Email
- Review Feedback

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1

### 17. Project Manager consolidates feedback and revises the Technical Advisory Group ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Technical Advisory Group ToR v0.2
- Feedback Summary

**Dependencies:**

- Review Feedback Received

### 18. PMO Director formally approves the Technical Advisory Group Terms of Reference.

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved Technical Advisory Group ToR v1.0

**Dependencies:**

- Technical Advisory Group ToR v0.2

### 19. PMO Director identifies and recruits technical experts for the Technical Advisory Group (Senior Broadcast Engineer (ORF), Venue Architect, Digital Technology Expert, Sound and Lighting Specialist, Independent Technical Consultant).

**Responsible Body/Role:** PMO Director

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Nominated Members List

**Dependencies:**

- Approved Technical Advisory Group ToR v1.0

### 20. Project Manager formally confirms the membership of the Technical Advisory Group with all nominated members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Membership Confirmation Emails
- Confirmed Members List

**Dependencies:**

- Nominated Members List

### 21. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Confirmed Members List

### 22. Hold the initial Technical Advisory Group kick-off meeting to review project goals, governance structure, and initial priorities.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation Sent

### 23. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Approved Project Plan

### 24. Project Manager circulates Draft Ethics & Compliance Committee ToR v0.1 for review by Legal Counsel (ORF) and Compliance Officer (ORF).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Circulation Email
- Review Feedback

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 25. Project Manager consolidates feedback and revises the Ethics & Compliance Committee ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee ToR v0.2
- Feedback Summary

**Dependencies:**

- Review Feedback Received

### 26. Legal Counsel (ORF) formally approves the Ethics & Compliance Committee Terms of Reference.

**Responsible Body/Role:** Legal Counsel (ORF)

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Approved Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Ethics & Compliance Committee ToR v0.2

### 27. Legal Counsel (ORF) and Compliance Officer (ORF) identify and recruit members for the Ethics & Compliance Committee (Data Protection Officer (ORF), Independent Ethics Expert, EBU Compliance Representative).

**Responsible Body/Role:** Legal Counsel (ORF)

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Nominated Members List

**Dependencies:**

- Approved Ethics & Compliance Committee ToR v1.0

### 28. Project Manager formally confirms the membership of the Ethics & Compliance Committee with all nominated members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Membership Confirmation Emails
- Confirmed Members List

**Dependencies:**

- Nominated Members List

### 29. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Confirmed Members List

### 30. Hold the initial Ethics & Compliance Committee kick-off meeting to review project goals, governance structure, and initial priorities.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation Sent

### 31. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Approved Project Plan

### 32. Project Manager circulates Draft Stakeholder Engagement Group ToR v0.1 for review by Communications Manager (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Circulation Email
- Review Feedback

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1

### 33. Project Manager consolidates feedback and revises the Stakeholder Engagement Group ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 14

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group ToR v0.2
- Feedback Summary

**Dependencies:**

- Review Feedback Received

### 34. Communications Manager (PMO) formally approves the Stakeholder Engagement Group Terms of Reference.

**Responsible Body/Role:** Communications Manager (PMO)

**Suggested Timeframe:** Project Week 14

**Key Outputs/Deliverables:**

- Approved Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Stakeholder Engagement Group ToR v0.2

### 35. Communications Manager (PMO) identifies and recruits members for the Stakeholder Engagement Group (Community Relations Manager, Sponsorship Manager, Participating Countries Liaison, Tourism Agency Representative).

**Responsible Body/Role:** Communications Manager (PMO)

**Suggested Timeframe:** Project Week 15

**Key Outputs/Deliverables:**

- Nominated Members List

**Dependencies:**

- Approved Stakeholder Engagement Group ToR v1.0

### 36. Project Manager formally confirms the membership of the Stakeholder Engagement Group with all nominated members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 16

**Key Outputs/Deliverables:**

- Membership Confirmation Emails
- Confirmed Members List

**Dependencies:**

- Nominated Members List

### 37. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 16

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Confirmed Members List

### 38. Hold the initial Stakeholder Engagement Group kick-off meeting to review project goals, governance structure, and initial priorities.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 17

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation Sent