Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 17 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 2 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any laws of physics. The project focuses on mapping and preserving neural connectomes, which are within the realm of known physics.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (neural data), market (brain emulation), tech/process (nanoscale probes, cryopreservation), and policy (Uruguayan regulations) without independent evidence at comparable scale. There is no proof that this combination will work.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Project Lead / Deliverable: Validation Report / Date: Q2 2026


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan uses strategic concepts like "Pioneer's Gambit" without defining their business-level mechanism-of-action, owner, or measurable outcomes. The plan states, "This scenario aligns well with the plan's ambition," but lacks a one-pager.

**Mitigation**: Project Lead: Create one-pagers for each strategic scenario (Pioneer's Gambit, Builder's Foundation, Consolidator's Approach) defining value hypotheses, success metrics, and decision hooks by Q2 2026.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major hazard class (ethical/reputational) is minimized: "permissive biomedical research laws and limited ethics oversight." The plan lacks explicit cascade analysis (e.g., ethical breach → funding withdrawal → project termination).

**Mitigation**: Project Lead: Expand the risk register to include ethical/reputational risks, map potential cascade effects, add controls, and establish a dated review cadence by Q2 2026.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions "Biomedical research permits,
Ethics review board approvals,
Data protection and privacy compliance" but lacks a timeline or responsible party.

**Mitigation**: Project Lead: Create a permit/approval matrix with lead times, dependencies, and owners for all required approvals. Include a NO-GO threshold on slip by Q2 2026.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan states "$10 billion from private investment (60%) and philanthropic grants (40%)." The plan does not name the funding sources, their status (e.g., LOI/term sheet/closed), the draw schedule, or runway length.

**Mitigation**: CFO: Create a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates by Q2 2026.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan states "$10 billion investment over 5 years." The plan lacks scale-appropriate benchmarks (capex/fit-out/opex) or contingency. There are no vendor quotes or per-area math.

**Mitigation**: CFO: Benchmark (≥3), obtain quotes, normalize per-area (m²/ft²), and adjust budget or de-scope by Q2 2026.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents the overall project timeline as a single 5-year timeframe without discussing alternative scenarios or providing a range. The plan lacks contingency planning for potential delays.

**Mitigation**: Project Lead: Conduct a scenario analysis (best/worst/base case) for the project completion date, identifying key dependencies and potential delays by Q2 2026.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "nanoscale neural probes" and "multi-modal ultrafast imaging equipment" but lacks technical specifications, interface definitions, test plans, or an integration map. The plan does not describe how these components will work together.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components by Q3 2026.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan states, "Uruguay's permissive biomedical research laws." There is no artifact showing that the project has secured the necessary permits or approvals to operate in Uruguay.

**Mitigation**: Legal Team: Obtain copies of all required permits and approvals from Uruguayan authorities, or a legal opinion confirming that no permits are required, by Q2 2026.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "Mapped connectome datasets" as a deliverable. The plan does not define SMART acceptance criteria, including a KPI for data fidelity (e.g., synapse mapping accuracy).

**Mitigation**: Project Lead: Define SMART criteria for 'Mapped connectome datasets,' including a KPI for synapse mapping accuracy (e.g., 99% accuracy) by Q2 2026.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes "revolutionizing AI" as a goal, but this does not directly support the core project goals of mapping and preserving neural connectomes. It adds complexity without clear benefit.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of "revolutionizing AI" as a project goal, complete with a KPI, owner, and estimated cost, or move it to the project backlog. Owner: Project Lead / Deliverable: Benefit Case / Date: Q2 2026


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a "Nanotechnology Probe Specialist" to ensure "biocompatibility, targeting accuracy, and data acquisition performance." This role is critical and requires rare expertise in nanotechnology, neuroscience, and biomedical engineering.

**Mitigation**: HR: Validate the talent market for Nanotechnology Probe Specialists by surveying potential candidates and assessing their availability and salary expectations within 90 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "Biomedical research permits,
Ethics review board approvals,
Data protection and privacy compliance" but lacks a timeline or responsible party. The permit/approval matrix is absent.

**Mitigation**: Project Lead: Create a permit/approval matrix with lead times, dependencies, and owners for all required approvals. Include a NO-GO threshold on slip by Q2 2026.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions a "sustainability plan" but lacks details on funding/resource strategy, maintenance schedule, succession planning, technology roadmap, or adaptation mechanisms. "Uncertain long-term sustainability" is listed as a risk.

**Mitigation**: Project Lead: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms by Q3 2026.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not address zoning/land-use, occupancy/egress, fire load, structural limits, noise, or other hard constraints. There is no evidence that the chosen sites are suitable for the intended activities.

**Mitigation**: Facilities Team: Perform a fatal-flaw screen with authorities/experts for each proposed site, seeking written confirmation where feasible. Define fallback designs/sites and dated NO-GO thresholds tied to constraint outcomes by Q3 2026.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "Infrastructure Redundancy Level" but lacks details on specific vendors, SLAs, failover testing, or secondary suppliers. The plan states, "rely on cloud-based data storage and processing services with built-in redundancy features."

**Mitigation**: IT Team: Secure SLAs with cloud providers guaranteeing uptime and data recovery. Schedule annual failover tests and document results by Q4 2026.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Finance Department is incentivized by quarterly budget adherence, while the R&D Team is incentivized by long-term innovation, creating a conflict over experimental spending.

**Mitigation**: Project Lead: Define a shared, measurable objective (OKR) that aligns both the Finance Department and the R&D Team on a common outcome by Q2 2026.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a change-control process. The plan states, "Regular updates and progress reports to primary stakeholders," but lacks specifics.

**Mitigation**: Project Lead: Add a monthly review with KPI dashboard and a lightweight change board. Define thresholds for when to re-plan/stop by Q2 2026.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has ≥3 High risks (Ethical, Technical, Financial) that are strongly coupled. Ethical lapses can trigger funding withdrawal, leading to technical compromises and project failure. There is no cross-impact analysis.

**Mitigation**: Project Lead: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by Q3 2026.