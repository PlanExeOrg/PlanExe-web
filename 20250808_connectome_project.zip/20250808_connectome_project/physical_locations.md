This plan implies one or more physical locations.

## Requirements for physical locations

- Permissive biomedical research laws
- Little ethics oversight
- Facilities for nanoscale neural probes
- Facilities for multi-modal ultrafast imaging
- Facilities for molecular tagging
- Facilities for harvesting, stabilizing, and digitizing human brains
- High-performance computing infrastructure
- Secure data storage

## Location 1
Uruguay

Montevideo

Science Park in Montevideo

**Rationale**: Montevideo is the capital and largest city of Uruguay, offering existing infrastructure and potential for establishing a science park dedicated to biomedical research. It provides access to skilled labor, transportation, and potential partnerships with local universities.

## Location 2
Uruguay

Free Trade Zone near Colonia del Sacramento

A new facility within the Free Trade Zone

**Rationale**: Free Trade Zones in Uruguay offer tax incentives and streamlined regulations, potentially reducing operational costs. Colonia del Sacramento provides a strategic location with access to international transportation routes and a relatively stable environment.

## Location 3
Uruguay

Punta del Este

Purpose-built research facility

**Rationale**: Punta del Este is known for its high-quality infrastructure and international connections. Establishing a purpose-built research facility here could attract international talent and investment, while still benefiting from Uruguay's permissive regulatory environment.

## Location Summary
The plan requires a location in Uruguay due to its permissive biomedical research laws and limited ethics oversight. Montevideo, a Free Trade Zone near Colonia del Sacramento, and Punta del Este are suggested due to their infrastructure, access to talent, and potential for attracting international investment.