## Positive Constraints

- Pilot project 'Upload Intelligence'
- 5-year initiative
- Budget: $10 billion
- Location: Uruguay
- Map and preserve complete neural connectomes
- Use nanoscale neural probes
- Use multi-modal ultrafast imaging
- Use molecular tagging
- <1 ms temporal resolution
- Sub-micron spatial precision
- Build a pipeline for harvesting, stabilizing, and digitizing the entire human brain
- Produce checksum-verifiable datasets
- Create at least three complete, error-checked human neural datasets
- Datasets must meet predefined resolution and fidelity standards

## Negative Constraints

- Avoid reckless speed
