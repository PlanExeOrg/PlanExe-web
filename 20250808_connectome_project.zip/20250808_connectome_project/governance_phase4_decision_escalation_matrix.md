**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic oversight.
Negative Consequences: Potential budget overruns and financial instability.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: The PMO cannot handle the risk with existing resources or approved plans, requiring strategic intervention.
Negative Consequences: Project delays, cost increases, or project failure.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: The PMO cannot reach a consensus on a key operational decision, requiring higher-level arbitration.
Negative Consequences: Delays in procurement and potential impact on project timelines.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Strategic Alignment
Rationale: A significant change to the project's objectives or deliverables requires strategic re-evaluation.
Negative Consequences: Misalignment with strategic goals, budget overruns, or project failure.

**Reported Ethical Concern**
Escalation Level: Ethics and Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Steering Committee
Rationale: Requires independent review and assessment to ensure ethical integrity and compliance.
Negative Consequences: Reputational damage, legal penalties, or project shutdown.

**Ethics and Compliance Committee Deadlock on Ethical Violation**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: The Ethics and Compliance Committee cannot reach a consensus on a key ethical decision, requiring higher-level arbitration.
Negative Consequences: Reputational damage, legal penalties, or project shutdown.

**Technical Advisory Group Recommendation Rejected by PMO**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Technical Recommendation and PMO Rationale
Rationale: Disagreement between technical experts and project management requires strategic arbitration.
Negative Consequences: Suboptimal technology choices, data quality issues, or project delays.