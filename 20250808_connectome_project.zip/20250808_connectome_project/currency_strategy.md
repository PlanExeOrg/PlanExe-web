This plan involves money.

## Currencies

- **UYU:** The local currency of Uruguay, necessary for all local transactions and expenses.
- **USD:** A stable international currency recommended for budgeting and reporting to mitigate risks from potential currency instability.

**Primary currency:** USD

**Currency strategy:** The primary currency for budgeting and reporting will be USD to mitigate risks associated with local currency fluctuations. Local transactions will be conducted in UYU, ensuring compliance with local regulations while maintaining financial stability.