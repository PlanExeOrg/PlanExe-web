### 1. Project Steering Committee

**Rationale for Inclusion:** Provides high-level strategic direction and oversight for this complex, high-risk, and high-budget project. Ensures alignment with overall organizational goals and manages strategic risks.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic guidance and direction.
- Monitor project progress against strategic objectives.
- Approve major changes to scope, budget, or timeline (>$50 million or >3 months delay).
- Oversee strategic risk management and mitigation.
- Resolve strategic conflicts and escalate issues as needed.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define escalation paths.
- Approve initial project plan.

**Membership:**

- Chief Science Officer
- Chief Financial Officer
- Chief Technology Officer
- External Ethics Advisor (Independent)
- Project Lead

**Decision Rights:** Strategic decisions related to project scope, budget, timeline, and strategic risks. Approval authority for changes exceeding $50 million or 3-month delay.

**Decision Mechanism:** Majority vote, with the Chief Science Officer having the tie-breaking vote.

**Meeting Cadence:** Quarterly, or more frequently as needed for critical decisions.

**Typical Agenda Items:**

- Review project progress against strategic objectives.
- Review and approve budget and timeline updates.
- Review and approve major changes to scope, budget, or timeline.
- Review strategic risk register and mitigation plans.
- Discuss and resolve strategic conflicts.
- Review compliance reports.

**Escalation Path:** Chief Executive Officer (CEO)
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day execution, operational risk management, and decisions below strategic thresholds. Ensures project activities are aligned with the project plan and strategic objectives.

**Responsibilities:**

- Develop and maintain project plan.
- Manage project budget and resources.
- Track project progress and report on key performance indicators (KPIs).
- Identify and manage operational risks.
- Coordinate project activities across different teams.
- Manage project communications.
- Ensure adherence to project standards and procedures.
- Manage changes below strategic thresholds (<$50 million and <3 months delay).

**Initial Setup Actions:**

- Establish project management methodology.
- Develop project plan template.
- Set up project tracking and reporting systems.
- Define roles and responsibilities within the PMO.
- Establish communication protocols.

**Membership:**

- Project Manager
- Lead Neuroscientist
- Lead Technologist
- Finance Manager
- Communications Manager

**Decision Rights:** Operational decisions related to project execution, resource allocation, and risk management below strategic thresholds (<$50 million and <3 months delay).

**Decision Mechanism:** Consensus-based decision-making, with the Project Manager having the final decision-making authority.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review project progress against plan.
- Review and approve budget and resource allocation.
- Identify and manage operational risks.
- Discuss and resolve project issues.
- Review and approve change requests.
- Review communication plan.

**Escalation Path:** Project Steering Committee
### 3. Ethics and Compliance Committee

**Rationale for Inclusion:** Provides specialized input and assurance on ethical and compliance aspects of the project, given the sensitive nature of human subject research and the location in a country with limited ethics oversight. Ensures adherence to international ethical standards and data privacy regulations.

**Responsibilities:**

- Review and approve research protocols to ensure ethical compliance.
- Monitor informed consent processes.
- Oversee data privacy and security measures.
- Ensure compliance with relevant regulations (e.g., GDPR, HIPAA).
- Investigate and resolve ethical concerns or complaints.
- Provide training on ethical conduct and compliance.
- Review and approve data release plans.
- Ensure adherence to data anonymization protocols.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop ethical guidelines and procedures.
- Establish reporting mechanisms for ethical concerns.

**Membership:**

- Independent Ethics Expert (Chair)
- Legal Counsel
- Data Protection Officer
- Community Representative (Uruguay)
- Project Lead (ex-officio, non-voting)

**Decision Rights:** Decisions related to ethical compliance, data privacy, and adherence to relevant regulations. Authority to halt research activities if ethical concerns are not adequately addressed.

**Decision Mechanism:** Majority vote, with the Independent Ethics Expert having the tie-breaking vote.

**Meeting Cadence:** Monthly, or more frequently as needed for critical ethical issues.

**Typical Agenda Items:**

- Review and approve research protocols.
- Review and monitor informed consent processes.
- Review and approve data privacy and security measures.
- Review and approve data release plans.
- Investigate and resolve ethical concerns or complaints.
- Review compliance reports.
- Review data anonymization protocols.

**Escalation Path:** Project Steering Committee
### 4. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and guidance on the project's cutting-edge technologies, ensuring feasibility, scalability, and data quality. Mitigates technical risks associated with unproven technologies.

**Responsibilities:**

- Evaluate and recommend probe technologies.
- Advise on data acquisition modalities.
- Review and approve data processing pipeline design.
- Assess computational resource needs.
- Monitor technical risks and develop mitigation plans.
- Provide guidance on data storage and accessibility.
- Review and approve technical specifications for equipment and infrastructure.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define technical standards and specifications.
- Establish communication protocols with the PMO.

**Membership:**

- Lead Technologist (Chair)
- Nanotechnology Expert
- Imaging Expert
- Data Science Expert
- Computational Resource Expert

**Decision Rights:** Technical decisions related to technology selection, data acquisition, data processing, and computational resources. Authority to recommend changes to technical specifications to ensure data quality and project feasibility.

**Decision Mechanism:** Consensus-based decision-making, with the Lead Technologist having the final decision-making authority.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review and evaluate probe technologies.
- Review and approve data acquisition modalities.
- Review and approve data processing pipeline design.
- Assess computational resource needs.
- Monitor technical risks and develop mitigation plans.
- Review data storage and accessibility plans.
- Review technical specifications for equipment and infrastructure.

**Escalation Path:** Project Steering Committee