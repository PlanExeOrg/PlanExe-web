**Purpose:** business

**Purpose Detailed:** Large-scale biomedical research initiative focused on mapping and digitizing human brains for future emulation, involving significant financial investment and infrastructure development.

**Topic:** Pilot project 'Upload Intelligence' - Phase 1: Neural connectome mapping and preservation