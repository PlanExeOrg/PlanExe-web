**Verdict:** 🟢 USABLE

**Rationale:** The prompt describes a concrete, albeit ethically questionable, project with specific details about budget, timeline, location, and technical objectives. It provides enough information to generate a multi-step plan, even if the project itself is ambitious and controversial.