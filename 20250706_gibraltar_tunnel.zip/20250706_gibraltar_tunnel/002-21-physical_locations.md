This plan implies one or more physical locations.

## Requirements for physical locations

- Deep sea construction capabilities
- Proximity to the Strait of Gibraltar
- Access to high-speed rail networks in Spain and Morocco
- Stable geological conditions
- Minimal marine ecosystem disruption

## Location 1
Spain

Tarifa, Cádiz

Coastal areas near Tarifa

**Rationale**: Tarifa is the closest point in Spain to Morocco, offering the shortest distance for the tunnel. It also provides access to existing infrastructure and potential construction sites.

## Location 2
Morocco

Tangier

Coastal areas near Tangier

**Rationale**: Tangier is a major Moroccan city located on the Strait of Gibraltar, providing a strategic location for the tunnel's terminus and access to Moroccan infrastructure.

## Location 3
International Waters

Strait of Gibraltar

Submerged tunnel route within the Strait of Gibraltar

**Rationale**: The tunnel itself will be located within the Strait of Gibraltar, requiring specialized construction and anchoring technologies for submerged structures.

## Location Summary
The project requires locations in both Spain (Tarifa) and Morocco (Tangier) to serve as entry and exit points for the tunnel, as well as the submerged tunnel route within the Strait of Gibraltar itself. These locations are strategically chosen for their proximity, existing infrastructure, and suitability for deep-sea construction.