## 1. Geotechnical & Seismic Risk Assessment

The complete absence of site-specific seismic and geotechnic data is the most critical foundational gap in the project. The entire structural architecture — pillar penetration depths, anchoring methodologies, and seismic isolation specifications — rests on unvalidated assumptions about clay, sand, and weathered bedrock strata near one of Europe's most active seismic transform zones. A moderate earthquake (M5.5-6.5) could cause €3-8 billion in repairs; a major event (M7.0+) could cause catastrophic total loss of segments valued at €10-20 billion. This data collection is the absolute prerequisite for all subsequent engineering decisions.

### Data to Collect

- Deep-sea borehole samples at minimum 5 locations spanning the 14 km Strait of Gibraltar corridor, each reaching 200m below seabed to characterize clay, sand, and weathered bedrock strata
- 3D seismic reflection profiling data across the full tunnel alignment calibrated to the Azores-Gibraltar seismic transform fault zone
- Probabilistic seismic hazard analysis (PSHA) results with site-specific ground motion parameters including peak ground acceleration and liquefaction potential
- Subsurface geology verification data comparing actual conditions against assumed clay, sand, and weathered bedrock strata
- Seismic isolation bearing specifications and deepened foundation penetration depth requirements based on real geotechnical data

### Simulation Steps

- Use finite element analysis software (e.g., PLAXIS 3D, ABAQUS) to model pillar-tunnel load transfer using borehole-derived soil profiles and simulate seismic loading cases at 2% probability of exceedance in 50 years
- Run computational fluid dynamics simulations of ocean current interactions with proposed pillar geometries using ANSYS Fluent or OpenFOAM, calibrated against real bathymetric and current data from the Strait of Gibraltar
- Conduct 1:50 scale physical model testing in deep-water basins (e.g., at the FloWave Ocean Energy Research facility in Edinburgh or the Danish Hydraulic Institute) under simulated Gibraltar Strait currents up to 2.5 m/s lateral flow, using geotechnically representative seabed conditions
- Perform probabilistic seismic hazard analysis using OpenQuake or similar open-source PSHA tools calibrated to the Azores-Gibraltar fault zone, incorporating the borehole-derived Vs30 profiles

### Expert Validation Steps

- Commission independent seismic review panel (recommended: independent panel including experts from the Japan Geotechnical Society, Institution of Civil Engineers, and European Seismic Safety Committee) to review and sign off on all geotechnical data, PSHA results, and structural design loading cases by September 2027
- Engage Dr. Kenji Tanaka (Geotechnical & Seismic Engineering Director) and his team to validate borehole interpretations and seismic profiling data against the Azores-Gibraltar fault zone characteristics
- Require formal geotechnical validation gate sign-off from the independent seismic review panel before any construction mobilization permits are issued, with hard stop date of June 2027
- Consult with the International Tunnelling and Underground Space Association (ITA-AITES) for peer review of geotechnical methodology and validation approach

### Responsible Parties

- Geotechnical & Seismic Engineering Director (Dr. Kenji Tanaka)
- Independent Seismic Review Panel
- Program Director & Cross-Border Governance Lead (Elena Vargas)
- Chief Geotechnical Engineer
- International legal counsel team (Madrid, Rabat, The Hague)

### Assumptions

- **High:** The seabed at 100m depth across the 14 km corridor consists of clay, sand, and weathered bedrock suitable for pillar anchoring without requiring extraordinary foundation depths
- **High:** The Azores-Gibraltar seismic transform fault zone poses a moderate seismic hazard (M5.5-6.5, 10% probability in 20 years) that can be mitigated with seismic isolation bearings and deepened foundations
- **Medium:** Deep-sea borehole sampling at 5 locations will be sufficient to characterize the full 14 km corridor geology with adequate spatial resolution for structural design
- **Medium:** 3D seismic reflection profiling can accurately identify fault zones, liquefaction-prone layers, and bedrock depth variations across the tunnel alignment

### SMART Validation Objective

Commission and complete deep-sea borehole sampling at minimum 5 locations (each reaching 200m below seabed) and 3D seismic reflection profiling across the full 14 km tunnel alignment by March 2027; deliver probabilistic seismic hazard analysis calibrated to the Azores-Gibraltar fault zone by April 2027; obtain independent seismic review panel sign-off on all structural loading cases incorporating site-specific seismic data with minimum 2% probability of exceedance in 50 years by September 2027; establish formal geotechnical validation gate with hard stop date of June 2027 before any construction mobilization permits are issued.

### Notes

- The Azores-Gibraltar seismic transform fault zone is one of Europe's most active seismic regions — the entire structural design cannot proceed without site-specific data
- The 1:50 scale physical model testing must use geotechnically representative seabed conditions derived from actual borehole data, not assumed profiles
- Budget €500 million-€1.5 billion for seismic mitigation measures including deepened foundations to bedrock at minimum 30-meter penetration and seismic isolation bearings at all pillar-tunnel connections
- The expert review identified this as the single most critical issue — the project is designing blind without this data
- Borehole sampling campaigns are weather-dependent and may require multiple seasons to complete across all 5 locations


## 2. Hybrid Floating-Pillar Architecture Validation

The hybrid floating-pillar architecture is unprecedented at this scale and depth — no existing precedent exists for a buoyant concrete tunnel system anchored at 100 meters below open ocean. The interaction between buoyant tunnel segments, vertical pillar members, and hydrodynamic lift creates force dynamics that cannot be fully validated through computational models alone. A single miscalculation in buoyancy equilibrium or lateral load distribution could necessitate segment replacement at €500 million-€2 billion per incident. The expert review identified this as the largest technical uncertainty with catastrophic structural failure risks. Validation through scaled physical model testing and a fully instrumented prototype is the only way to de-risk this fundamental architectural choice.

### Data to Collect

- Scaled physical model test results (1:50 scale) of the hybrid floating-pillar system under simulated Gibraltar Strait current conditions (maximum 2.5 m/s lateral flow)
- Finite element analysis results validating buoyant segment, pillar, and hydrodynamic force interactions at 100m equivalent depth
- Fully instrumented 50-meter prototype segment deployment data including buoyancy equilibrium readings, pillar load transfer measurements, and hydrodynamic response under simulated storm conditions
- Minimum 6 months of continuous stable operation data from the prototype segment under real-world equivalent conditions
- Validation data comparing computational model predictions against physical model and prototype measurements to identify model gaps

### Simulation Steps

- Conduct 1:50 scale physical model testing in deep-water basins (e.g., FloWave Ocean Energy Research facility, Edinburgh) under simulated Gibraltar Strait currents up to 2.5 m/s lateral flow, measuring buoyancy equilibrium, pillar load distribution, and hydrodynamic forces on the hybrid floating-pillar configuration
- Run validated finite element analysis using ABAQUS or ANSYS Mechanical, incorporating real oceanographic data to model the complex interaction between buoyant concrete segments, vertical pillar members, and hydrodynamic lift at 100m depth
- Deploy a fully instrumented 50-meter prototype segment at 100m equivalent depth (or shallower equivalent with scaled loading) by March 2028, monitoring buoyancy equilibrium, pillar load transfer, and structural deformation for minimum 6 months of continuous operation under simulated storm conditions
- Use computational fluid dynamics (ANSYS Fluent or OpenFOAM) to simulate deep-water current interactions with the hybrid pillar-tunnel configuration, validating against physical model results

### Expert Validation Steps

- Engage Dr. Kenji Tanaka (Geotechnical & Seismic Engineering Director) and his team to validate all physical model test results and finite element analysis against real-world oceanographic data
- Commission independent structural review by the Institution of Civil Engineers (ICE) and the International Tunnelling and Underground Space Association (ITA-AITES) to validate the hybrid floating-pillar architecture before mass production approval
- Require formal validation gate sign-off from the neutral third-party consortium's technical steering committee confirming that prototype data validates all structural parameters before approving mass production
- Consult with the Deep-Sea Structural Engineer expert (identified in expert-review.md) to review prototype deployment results and confirm structural integrity under simulated storm conditions

### Responsible Parties

- Deep-Sea Structural Engineer (external expert)
- Geotechnical & Seismic Engineering Director (Dr. Kenji Tanaka)
- Marine Construction & Offshore Engineering Lead (Marcus Dubois)
- Neutral third-party consortium technical steering committee
- Institution of Civil Engineers (ICE) independent reviewers
- Research, Innovation & Prototype Validation Lead (proposed role)

### Assumptions

- **High:** The hybrid floating-pillar architecture (buoyant segments partially supported by vertical members and partially by hydrodynamic lift) is technically viable and can achieve stable buoyancy equilibrium at 100m depth
- **Medium:** 1:50 scale physical model testing will provide sufficient validation of full-scale structural behavior, with scaling laws accurately capturing the complex force interactions at 100m depth
- **High:** The 50-meter prototype segment will demonstrate stable buoyancy equilibrium and pillar load transfer under simulated storm conditions for minimum 6 months, validating the architecture for mass production
- **Medium:** Computational models can be validated against physical model and prototype data to identify and close model gaps before mass production decisions are made

### SMART Validation Objective

Complete 1:50 scale physical model testing of the hybrid floating-pillar architecture in deep-water basins under simulated Gibraltar Strait currents (maximum 2.5 m/s lateral flow) by June 2027; deliver validated finite element analysis results by September 2027; deploy a fully instrumented 50-meter prototype segment at 100m equivalent depth by March 2028; achieve minimum 6 months of continuous stable operation data from the prototype under simulated storm conditions by September 2028; obtain formal validation gate sign-off from the neutral third-party consortium's technical steering committee confirming all structural parameters are validated before mass production begins.

### Notes

- The expert review identified this as the largest technical uncertainty — the project is committing €40 billion to an architecture with no precedent at this scale and depth
- The validation gate must be a hard prerequisite before any construction mobilization — do not proceed to mass production until prototype data confirms stable buoyancy equilibrium and pillar load transfer
- The 1:50 scale model testing must use geotechnically representative seabed conditions derived from actual borehole data (Item 1)
- Budget for prototype development and deployment: €200-500 million
- The Builder's Foundation strategy's 'deliberate equilibrium between innovation and proven engineering' philosophy depends entirely on successful prototype validation


## 3. Cross-Border Governance & Legal Framework Establishment

Cross-border governance misalignment is the highest-likelihood risk that could add 2-5 years and €2-5 billion in costs before construction begins. The neutral third-party consortium model requires sophisticated bilateral diplomatic negotiation, yet the governance strategy lacks any substantive international treaty law foundation. There is no analysis of existing BITs, no determination of the consortium's legal personality, no assessment of EU law constraints, and no analysis of the tunnel's legal classification under UNCLOS. The project also fails to address the legal status of the seabed at 100m depth — whether it falls within Spain's continental shelf, Morocco's exclusive economic zone, or the high seas. Without a legally sound governance foundation, the entire €40 billion investment is vulnerable to challenge at any stage.

### Data to Collect

- Comprehensive Bilateral Investment Treaty (BIT) analysis between Spain and Morocco identifying all investment protection provisions, ISDS mechanisms, and sunset clauses applicable to the €40 billion investment
- Maritime law analysis addressing UNCLOS classification of the tunnel (artificial installation vs. submarine cable/pipeline vs. permanent installation), jurisdictional status of the seabed at 100m depth, Barcelona Convention obligations (SPA/BD Protocol, LBS Protocol), and SOLAS/MARPOL compliance requirements
- EU law impact assessment evaluating how TFEU provisions and the European Convention on Human Rights constrain the governance structure, given Spain's EU membership
- Legal opinion on the consortium entity's legal personality under Spanish, Moroccan, and international law — whether structured as a treaty-based international organization, contractual joint venture, or special purpose vehicle
- Pre-negotiated ICC arbitration framework for all dispute categories (investor-state, state-to-state, commercial, employment, environmental)
- Bilateral treaty ratification timeline analysis accounting for realistic parliamentary calendars in both the Spanish Cortes Generales and Moroccan Parliament

### Simulation Steps

- Use legal research databases (e.g., LexisNexis, Westlaw, UN Treaty Collection) to analyze all existing BITs between Spain and Morocco, identifying relevant investment protection provisions and ISDS mechanisms
- Conduct UNCLOS legal classification analysis using international maritime law databases and precedent cases from the International Tribunal for the Law of the Sea, assessing whether the tunnel constitutes an artificial installation under UNCLOS Part V
- Model the treaty ratification timeline using project scheduling software (e.g., Microsoft Project or Primavera P6), incorporating realistic parliamentary calendar constraints, consultation periods, and potential political delays for both Spain and Morocco
- Simulate dispute resolution scenarios using ICC arbitration case law databases to assess enforcement risks and timeline implications for each governance structure option

### Expert Validation Steps

- Retain specialized international treaty law team (minimum 4 attorneys) to conduct comprehensive BIT analysis and provide legal opinions on consortium legal personality, enforcement mechanisms, and EU law interactions
- Commission maritime law analysis from an international law firm specializing in UNCLOS and Mediterranean maritime law (recommended: Freshfields Bruckhaus Deringer or Allen & Overy with dedicated maritime practice)
- Engage EU legal counsel to assess how EU law (TFEU provisions, European Convention on Human Rights) constrains the governance structure
- Consult with the International Maritime Organization (IMO) Legal Committee and Marine Environment Protection Committee for preliminary regulatory guidance on the tunnel's classification and applicable regulatory framework
- Engage the International Chamber of Commerce (ICC) International Court of Arbitration to pre-negotiate dispute resolution framework specifics
- Consult with the Strait of Gibraltar Joint Coordination Center for legal agreements on maritime traffic management and liability allocation

### Responsible Parties

- Program Director & Cross-Border Governance Lead (Elena Vargas)
- International treaty law team (minimum 4 attorneys)
- Maritime law firm (Freshfields Bruckhaus Deringer or Allen & Overy)
- EU legal counsel
- ICC International Court of Arbitration
- Bilateral diplomatic task force (Spain-Morocco)
- International legal counsel team (Madrid, Rabat, The Hague)

### Assumptions

- **High:** A neutral third-party consortium led by a neutral engineering firm can be legally established with technical decision-making authority while both Spain and Morocco retain financial oversight and veto rights
- **High:** The bilateral treaty can be ratified through both the Spanish Cortes Generales and Moroccan Parliament within 18 months of initiation, despite competing legislative calendars and potential political transitions
- **High:** The tunnel's legal classification under UNCLOS will not create insurmountable sovereignty or jurisdictional challenges between Spain and Morocco
- **Medium:** ICC arbitration enforcement will be effective across both Spanish and Moroccan jurisdictions for dispute resolution

### SMART Validation Objective

Complete comprehensive BIT analysis between Spain and Morocco identifying all investment protection provisions and ISDS mechanisms by December 2026; deliver maritime law analysis addressing UNCLOS classification, Barcelona Convention obligations, and SOLAS/MARPOL compliance by March 2027; obtain EU legal counsel assessment of governance structure constraints by June 2027; establish pre-negotiated ICC arbitration framework for all dispute categories by September 2027; schedule first ministerial-level meeting of bilateral diplomatic task force no later than November 2026; ratify bilateral treaty through both parliaments with binding commitments and penalty clauses by Q4 2028 at the latest.

### Notes

- The expert review identified the governance legal architecture as fundamentally incomplete — the project treats governance as a political negotiation rather than a legal architecture requiring treaty law expertise
- The 18-month ratification timeline is unrealistic for infrastructure projects of this magnitude; treaty negotiation typically takes 3-5 years
- The project must address whether the consortium has international legal personality, how its decisions will be enforced across two sovereign jurisdictions, and how EU law constrains the governance structure
- The maritime legal classification of the tunnel under UNCLOS has massive implications for sovereignty, jurisdiction, permitting authority, and environmental regulation
- The bilateral diplomatic task force must be elevated to include chief legal negotiators with treaty-making authority, not just diplomatic envoys
- Budget: €10-20 million for international legal counsel engagement across Madrid, Rabat, and The Hague


## 4. Environmental Compliance & Marine Ecosystem Baseline Studies

Environmental permitting across two sovereign jurisdictions with conflicting marine protection standards could add 1-3 years and €500 million-€1.5 billion in compliance costs. The Strait of Gibraltar is one of the world's most ecologically sensitive marine corridors — home to critical cetacean migratory routes and fragile benthic habitats. The project's elevated pillar configuration integrates habitat preservation into core engineering design, but this must be validated against real ecosystem data. Without comprehensive baseline studies, the project cannot obtain environmental permits, and environmental organizations could file legal challenges at any stage. The independent environmental oversight board with binding authority to halt construction is a critical governance mechanism that must be established before construction begins.

### Data to Collect

- Comprehensive marine ecosystem baseline data covering cetacean migration patterns, benthic habitat mapping, water quality parameters, and sediment dynamics across the full 14 km Strait of Gibraltar corridor
- 24 months of field data collection using research vessels, acoustic monitoring equipment, water quality sampling systems, and sediment dynamics measurement systems
- Real-time acoustic monitoring buoy deployment data at minimum 10 locations along the tunnel corridor for marine mammal disturbance detection
- Independent environmental oversight board establishment data including governance structure, binding authority protocols, and threshold definitions for marine mammal disturbance
- Ecosystem restoration program design data including artificial reef structure specifications, placement locations, and projected ecosystem development timelines
- Transboundary environmental impact assessment framework negotiated through the IMO with preliminary agreement timeline and fallback arbitration mechanisms
- Seasonal construction restriction data for cetacean migration periods (spring March-May and autumn September-November)

### Simulation Steps

- Use marine ecosystem modeling software (e.g., Ecopath with Ecosim, Atlantis modeling framework) to simulate the impact of elevated pillar configurations and offshore construction activities on cetacean migration corridors and benthic habitats across the Strait of Gibraltar
- Deploy real-time acoustic monitoring buoys at minimum 10 locations along the tunnel corridor using specialized hydrophone arrays (e.g., SoundTrap or similar), with data transmission to surface buoys via acoustic modem, to establish baseline marine mammal disturbance levels
- Conduct computational fluid dynamics simulations of construction-induced sediment plume dispersion using ANSYS Fluent or OpenFOAM, calibrated against real water quality and sediment data from the Strait of Gibraltar
- Model artificial reef structure deployment scenarios using marine habitat simulation tools to project ecosystem development timelines and habitat connectivity improvements along the tunnel corridor

### Expert Validation Steps

- Commission comprehensive marine ecosystem baseline studies through Dr. Fatima Al-Rashid (Environmental Compliance & Marine Ecology Director) and her team, coordinating 24 months of field data collection with research vessels and acoustic monitoring equipment
- Establish the independent environmental oversight board with binding authority to halt construction if marine mammal disturbance thresholds are exceeded, with members from IUCN, CMS, and Mediterranean Marine Protected Areas network
- Engage the International Maritime Organization (IMO) Marine Environment Protection Committee for transboundary environmental impact assessment framework negotiation, targeting preliminary framework agreement by June 2027
- Consult with the Convention on Migratory Species (CMS) and the International Union for Conservation of Nature (IUCN) for validation of cetacean migration impact assessments and mitigation measures
- Commission independent environmental impact assessment review from the Mediterranean Marine Protected Areas network and local environmental NGOs in Tarifa and Tangier
- Validate artificial reef structure designs with marine ecologists from the University of Barcelona and Mohammed V University in Rabat

### Responsible Parties

- Environmental Compliance & Marine Ecology Director (Dr. Fatima Al-Rashid)
- Independent environmental oversight board
- International Maritime Organization (IMO) Marine Environment Protection Committee
- Convention on Migratory Species (CMS)
- International Union for Conservation of Nature (IUCN)
- Mediterranean Marine Protected Areas network
- Local environmental NGOs in Tarifa and Tangier
- University of Barcelona marine ecology researchers
- Mohammed V University marine biology researchers

### Assumptions

- **High:** Elevated pillar configurations that preserve benthic habitats underneath will satisfy environmental permitting requirements in both Spanish and Moroccan jurisdictions
- **Medium:** 24 months of field data collection will be sufficient to establish comprehensive marine ecosystem baselines including cetacean migration patterns, benthic habitat mapping, water quality, and sediment dynamics
- **High:** The IMO transboundary environmental impact assessment can achieve preliminary framework agreement by June 2027, with fallback ICC arbitration available if negotiations stall
- **Medium:** Artificial reef structures will successfully establish functional ecosystems along the tunnel corridor within a reasonable timeframe, providing adequate mitigation for construction impacts

### SMART Validation Objective

Begin comprehensive marine ecosystem baseline studies (cetacean migration, benthic habitats, water quality, sediment dynamics) with field data collection by November 2026, completing within 24 months by November 2028; deploy real-time acoustic monitoring buoys at minimum 10 locations along the tunnel corridor by June 2027; establish the independent environmental oversight board with binding authority by March 2027; achieve IMO preliminary framework agreement for transboundary environmental impact assessment by June 2027; commission ecosystem restoration program with artificial reef structures and €200-500 million marine mitigation fund capitalized at project inception.

### Notes

- The expert review identified environmental permitting delays as a significant risk — duplicative national reviews and environmental organization litigation could add 1-3 years and €500 million-€1.5 billion in costs
- Seasonal construction restrictions during cetacean migration periods (spring March-May and autumn September-November) will reduce already limited weather windows by an additional 15-20%
- The oversight board provides a critical check but could become a bottleneck if threshold definitions are too sensitive
- Artificial reefs take years to establish functional ecosystems — this is a long-term mitigation strategy, not an immediate offset
- The Barcelona Convention's SPA/BD Protocol and LBS Protocol must be specifically incorporated into the environmental compliance strategy, not treated as a generic framework
- Budget: €200-500 million marine mitigation fund


## 5. Energy Supply Infrastructure Assessment

The project specifies massive energy demands — pressurized rail climate control, ventilation, structural surveillance, cathodic protection, buoyancy adjustment, and rail propulsion — but no energy supply strategy is articulated. At 100m depth, terrestrial grid connection requires submarine cables of extraordinary length and capacity. Offshore tidal generators alone are insufficient for full operational load. Without reliable power, the tunnel cannot operate, resulting in zero revenue and €500 million-€1 billion in annual lost revenue. The expert review identified this as one of the three most critical issues threatening the project's viability. The €1-2 billion energy infrastructure budget has no dedicated owner, and this gap must be resolved before the tunnel can function.

### Data to Collect

- Comprehensive energy audit quantifying total operational energy demand (estimated 50-100 MW continuous) for pressurized rail climate control, ventilation, structural surveillance, cathodic protection, buoyancy adjustment systems, and rail propulsion
- Submarine HVDC cable specifications including cable route, capacity, voltage rating, and landing station requirements for connections to Spanish and Moroccan national grids
- Offshore renewable energy generation capacity assessment including wind and tidal resource data for the Strait of Gibraltar corridor
- Energy storage system requirements including battery storage capacity, duration, and response time specifications for grid stabilization and backup power
- Diesel backup power system specifications including fuel storage capacity, generator ratings, and emissions compliance requirements
- Total operational energy budget and cost projections over the 20-year lifespan
- Energy infrastructure budget allocation of €1-2 billion with detailed cost breakdown

### Simulation Steps

- Use energy modeling software (e.g., HOMER Energy, RETScreen) to model the hybrid energy strategy combining submarine HVDC cables, offshore wind/tidal generation with battery storage, and diesel backup, simulating 20-year operational energy demand profiles
- Conduct computational fluid dynamics simulations of offshore wind and tidal energy resource potential in the Strait of Gibraltar using ANSYS Fluent or specialized marine energy tools (e.g., WAVEWATCH III), calibrated against real oceanographic data
- Model submarine HVDC cable transmission losses and grid interconnection stability using power system simulation software (e.g., PSCAD, MATLAB/Simulink), assessing the impact of 100-meter depth cable routing on transmission efficiency
- Simulate energy system reliability and redundancy scenarios using Monte Carlo simulation to assess the probability of energy supply failures and their impact on tunnel operations

### Expert Validation Steps

- Appoint an Energy Infrastructure Director responsible for conducting the comprehensive energy audit, developing the hybrid energy strategy, and overseeing the €1-2 billion energy infrastructure budget
- Negotiate energy supply agreements with both Spanish (Red Eléctrica de España) and Moroccan (ONEE) national grid operators before construction begins
- Commission offshore energy resource assessment from specialized marine energy consultancies (e.g., Wave Energy Scotland, Offshore Renewable Energy Catapult) for wind and tidal resource data
- Engage submarine HVDC cable manufacturers (e.g., Nexans, Prysmian, NKT) for technical specifications, cost estimates, and delivery timelines
- Consult with the European Investment Bank and African Development Bank for financing of the energy infrastructure component
- Validate energy system design with the Structural Integrity & Lifecycle Maintenance Director to ensure energy infrastructure integrates with corrosion protection, surveillance, and buoyancy systems

### Responsible Parties

- Energy Infrastructure Director (proposed role)
- Spanish national grid operator (Red Eléctrica de España)
- Moroccan national grid operator (ONEE)
- European Investment Bank
- African Development Bank
- Submarine HVDC cable manufacturers (Nexans, Prysmian, NKT)
- Offshore renewable energy consultancies
- Structural Integrity & Lifecycle Maintenance Director (Dr. Anika Petrov)

### Assumptions

- **High:** The total operational energy demand can be accurately estimated at 50-100 MW continuous, and this estimate will be validated through the comprehensive energy audit
- **High:** Submarine HVDC cable connections to both Spanish and Moroccan national grids can be technically and economically feasible at the required distances and depths
- **Medium:** Offshore wind and tidal energy generation in the Strait of Gibraltar can provide a meaningful portion of the tunnel's energy needs, with battery storage providing grid stabilization
- **Medium:** Diesel backup power can provide reliable emergency power without violating environmental compliance requirements or creating unacceptable emissions at the tunnel corridor

### SMART Validation Objective

Complete comprehensive energy audit quantifying total operational demand (estimated 50-100 MW continuous) by June 2027; develop hybrid energy strategy combining submarine HVDC cables, offshore wind/tidal generation with battery storage, and diesel backup by September 2027; negotiate energy supply agreements with both national grid operators by December 2027; establish dedicated energy infrastructure budget of €1-2 billion with detailed cost breakdown by March 2028; secure financing commitments from European Investment Bank and African Development Bank for energy infrastructure by June 2028.

### Notes

- The expert review identified this as one of the three most critical issues — without reliable power, the tunnel cannot operate, rendering the entire €40 billion investment inoperable
- The project lacks a dedicated Energy Infrastructure Director role — this must be appointed immediately
- Energy infrastructure must be designed into the tunnel architecture from the beginning, not added later
- Submarine HVDC cable routing at 100m depth presents unique engineering challenges including cable tension, fatigue, and repair access
- Budget: €1-2 billion dedicated energy infrastructure budget
- Energy costs over 20 years could reach significant levels and must be factored into the overall financial model


## 6. Rail Systems Integration & Gauge Interoperability Resolution

Rail gauge incompatibility between Spain (Iberian 1,668mm) and Morocco (standard 1,435mm) fundamentally threatens the core purpose of seamless transcontinental rail connectivity. Failure to resolve this would require passenger train changes, potentially cutting ridership by 30-50% and reducing revenue by €500 million-€1.5 billion annually over 20 years. Signaling systems (Spain: 25kV AC vs. Morocco: 3kV DC) and safety protocols also differ. The pressurized rail corridor at 100m depth introduces unprecedented engineering challenges — maintaining terrestrial-grade track precision under 10 atmospheres of external hydrostatic pressure while managing thermal expansion, marine-induced vibration, and pressurization-induced stress distributions. Track geometry deviations could cut projected revenue by 20-40%, and pressurization failures could endanger passenger safety — an existential risk.

### Data to Collect

- Comprehensive systems interoperability study data covering rail gauge compatibility (Spain: Iberian 1,668mm vs. Morocco: standard 1,435mm), signaling systems (Spain: 25kV AC vs. Morocco: 3kV DC), electrification standards, and safety protocol alignment
- Full-scale pressurized rail prototype testing results under simulated deep-sea conditions at 10 atmospheres external pressure for minimum 1,000 hours of continuous operation
- Track geometry precision measurement data demonstrating terrestrial-grade rail precision under 10 atmospheres of external hydrostatic pressure
- Modular track section active compensation system test data for thermal expansion and pressure-induced deformation management
- Emergency evacuation protocol validation data including specialized submersible rescue vehicle specifications and deployment procedures
- Gauge transition infrastructure cost estimates (€200-500 million) and timeline data for both terminal stations
- Unified standard gauge (1,435mm) commitment documentation from both Spanish and Moroccan national rail operators

### Simulation Steps

- Use rail dynamics simulation software (e.g., VI-Rail, OpenTrack) to model track geometry precision under pressurized conditions at 10 atmospheres external hydrostatic pressure, simulating thermal expansion and marine-induced vibration effects
- Conduct full-scale pressurized rail prototype testing at a pressure simulation facility (e.g., Deep Sea Systems International or similar) capable of simulating 10 atmospheres for minimum 1,000 hours of continuous operation, measuring track geometry deviations, pressurization system performance, and ventilation effectiveness
- Model gauge transition infrastructure requirements using railway engineering software (e.g., Siemens Rail Systems, Alstom Rail planning tools), simulating the interface between Iberian gauge (1,668mm) and standard gauge (1,435mm) at both terminal stations
- Simulate emergency evacuation scenarios using specialized submersible rescue vehicle deployment models, assessing evacuation time, passenger capacity, and safety under pressurized conditions

### Expert Validation Steps

- Engage Dr. Sarah Chen (Rail Systems & Transportation Engineering Lead) to oversee the full-scale pressurized rail prototype testing program and validate track geometry precision under simulated deep-sea conditions
- Require both Spanish (Renfe) and Moroccan (ONCF) national rail operators to commit to a unified standard gauge (1,435mm) for the tunnel and both connecting networks, with formal documentation by June 2027
- Conduct comprehensive systems interoperability study covering gauge, signaling (ERTMS), electrification (unified 25kV AC), and safety protocols, with results validated by both national rail operators by September 2027
- Commission independent safety certification of the pressurized rail corridor from an accredited rail safety authority (e.g., European Union Agency for Railways or equivalent Moroccan authority) before operational commencement
- Consult with the International Union of Railways (UIC) for validation of pressurized rail corridor design standards and emergency evacuation protocols
- Engage existing rail operators from both Spain and Morocco as joint interface teams from project inception, conducting comprehensive compatibility studies

### Responsible Parties

- Rail Systems & Transportation Engineering Lead (Dr. Sarah Chen)
- Spanish national rail operator (Renfe)
- Moroccan national rail operator (ONCF)
- European Union Agency for Railways (ERA)
- International Union of Railways (UIC)
- Joint interface teams with existing rail operators
- Accredited rail safety authority for safety certification

### Assumptions

- **High:** Both Spain and Morocco will commit to a unified standard gauge (1,435mm) for the tunnel and both connecting networks, with manageable transition costs of €200-500 million
- **High:** The sealed pressurized rail corridor can maintain terrestrial-grade track precision under 10 atmospheres of external hydrostatic pressure, with active compensation systems managing thermal expansion and pressure-induced deformation
- **High:** Full-scale pressurized rail prototype testing at 10 atmospheres for minimum 1,000 hours will validate all rail system parameters before mass production of tunnel segments
- **Medium:** Unified signaling (ERTMS) and electrification (25kV AC) standards can be agreed upon by both national rail operators without unacceptable cost or timeline implications

### SMART Validation Objective

Mandate unified standard gauge (1,435mm) commitment from both Spanish and Moroccan national rail operators by June 2027; complete comprehensive systems interoperability study covering gauge, signaling (ERTMS), electrification (unified 25kV AC), and safety protocols by September 2027; complete full-scale pressurized rail prototype testing under simulated deep-sea conditions at 10 atmospheres for minimum 1,000 hours of continuous operation by December 2027; budget €200-500 million for gauge transition infrastructure at both terminal stations; obtain independent safety certification from accredited rail safety authority before operational commencement.

### Notes

- The expert review identified rail gauge incompatibility as a fundamental threat to the project's core purpose — the killer application of transcontinental high-speed rail connectivity depends on seamless rail operations
- The dual-mode rail system mentioned in the strategic decisions is not committed to — a definitive gauge resolution is required
- Pressurization failure risk is existential for passenger safety — redundant pressurization systems with emergency depressurization protocols are essential
- The full-scale pressurized rail prototype must be tested under simulated deep-sea conditions before any tunnel segments are mass-produced
- Budget: €200-500 million for gauge transition infrastructure
- Track geometry deviations could require speed restrictions, cutting projected revenue by 20-40%


## 7. Maritime Traffic Integration & Collision Risk Assessment

The Strait of Gibraltar sees over 100,000 vessel transits annually, including massive tankers and container ships, making it one of the world's busiest shipping lanes. The tunnel structure could create current deflection effects altering shipping lane conditions and increasing collision risk. The assumption that dedicated maritime transport corridors can be established without disrupting this critical chokepoint is dangerously optimistic. A collision could cause €500 million-€2 billion in damage, potential environmental disaster, and 6-12 months of repair shutdown costing €1-3 billion in lost revenue. Current deflection could increase wave heights by 5-15%, increasing collision risk by 10-30%. Failure to secure shipping lane agreements could halt construction transport, adding 6-12 months and €500 million-€1 billion in costs.

### Data to Collect

- Comprehensive maritime traffic impact study data including computational fluid dynamics modeling of tunnel-induced current changes across the Strait of Gibraltar shipping corridor
- Collision probability analysis data for the tunnel structure considering 100,000+ annual vessel transits including massive tankers and container ships
- Temporary Traffic Management Plan (TTMP) with international authorities (IMO, Strait of Gibraltar Joint Coordination Center) including shipping lane adjustments and traffic control protocols
- AIS monitoring and collision avoidance system specifications and deployment plans
- Permanent shipping lane adjustment agreements negotiated with international maritime authorities
- 24/7 maritime traffic control center operational specifications and staffing requirements
- Computational fluid dynamics modeling of tunnel-induced current changes and wave height alterations (5-15% potential increase) affecting collision risk

### Simulation Steps

- Use computational fluid dynamics software (ANSYS Fluent or OpenFOAM) to model tunnel-induced current changes and wave height alterations across the Strait of Gibraltar shipping corridor, calibrated against real maritime traffic data and oceanographic conditions
- Conduct collision probability analysis using maritime risk assessment software (e.g., MITRE Collision Risk Assessment Tool or custom Monte Carlo simulation), incorporating vessel traffic data from the Strait of Gibraltar Joint Coordination Center (100,000+ annual transits)
- Model Temporary Traffic Management Plan scenarios using maritime traffic simulation tools, assessing the impact of shipping lane adjustments on traffic flow, congestion, and collision risk
- Simulate AIS monitoring and collision avoidance system performance using maritime navigation simulation software, validating detection ranges, alert accuracy, and response times

### Expert Validation Steps

- Appoint a Maritime Traffic & Navigation Safety Director (proposed role) responsible for commissioning the comprehensive maritime traffic impact study and developing the TTMP
- Engage the Strait of Gibraltar Joint Coordination Center for maritime traffic data, collision risk analysis collaboration, and negotiation of permanent shipping lane adjustments
- Commission the maritime traffic impact study from a specialized maritime consultancy with expertise in strait navigation and collision risk assessment (recommended: Lloyd's Register or DNV)
- Negotiate Temporary Traffic Management Plan with IMO and the Strait of Gibraltar Joint Coordination Center, targeting agreement by June 2027
- Install AIS monitoring and collision avoidance systems at minimum 10 locations along the tunnel corridor, validated by the Joint Coordination Center
- Establish a 24/7 maritime traffic control center with joint Spain-Morocco staffing, operational before the first tunnel segment is placed
- Consult with the International Maritime Organization (IMO) for regulatory guidance on maritime traffic management around submerged structures in international straits

### Responsible Parties

- Maritime Traffic & Navigation Safety Director (proposed role)
- Strait of Gibraltar Joint Coordination Center
- International Maritime Organization (IMO)
- Lloyd's Register or DNV (maritime risk assessment consultancy)
- Spanish and Moroccan maritime authorities
- Joint Spain-Morocco security coordination center
- International shipping industry representatives

### Assumptions

- **High:** Dedicated maritime transport corridors can be established through negotiation with international authorities without disrupting the Strait of Gibraltar's 100,000+ annual vessel transits
- **Medium:** Computational fluid dynamics modeling will accurately predict tunnel-induced current changes and wave height alterations, enabling effective collision risk mitigation
- **Medium:** AIS monitoring and collision avoidance systems will provide sufficient detection and alert capability to prevent collisions with the tunnel structure
- **High:** Permanent shipping lane adjustments can be negotiated with international maritime authorities without unacceptable disruption to global shipping routes

### SMART Validation Objective

Commission comprehensive maritime traffic impact study including computational fluid dynamics modeling and collision probability analysis by March 2027; develop Temporary Traffic Management Plan with IMO and Strait of Gibraltar Joint Coordination Center by June 2027; install AIS monitoring and collision avoidance systems at minimum 10 locations by September 2027; negotiate permanent shipping lane adjustments with international authorities by December 2027; establish 24/7 maritime traffic control center with joint Spain-Morocco staffing by March 2028; establish dedicated maritime legal compliance unit with at least 6 attorneys specializing in international maritime law.

### Notes

- The expert review identified inadequate maritime traffic integration as a critical issue — the tunnel structure could create current deflection effects altering shipping lane conditions
- The assumption that dedicated maritime transport corridors can be established without disrupting the Strait of Gibraltar's 100,000+ annual vessel transits is unvalidated and potentially dangerous
- A collision could cause €500 million-€2 billion in damage, potential environmental disaster, and 6-12 months of repair shutdown
- Current deflection could increase wave heights by 5-15%, increasing collision risk by 10-30%
- The project must negotiate with the Strait of Gibraltar Joint Coordination Center, IMO, and international shipping authorities
- Budget: €50-100 million for maritime traffic management infrastructure and systems


## 8. Flooding Risk Management & Emergency Response Protocol Development

The project describes a pressurized sealed rail corridor within a submerged tunnel but has no emergency flooding protocol for hull breach scenarios. At 100m depth with 10 atmospheres of external pressure, even a small breach could flood at catastrophic rates. With thousands of passengers submerged, flooding represents an existential safety risk. A major flooding event could result in total loss of tunnel sections valued at €5-15 billion, potential loss of life creating unlimited liability, and permanent project cancellation. A minor breach requiring section isolation could cost €200-500 million in repairs and 3-6 months of partial shutdown, reducing annual revenue by 15-30%. Absence of flooding protocols could make the project uninsurable, preventing financing. The expert review identified this as one of the three most critical issues threatening the project.

### Data to Collect

- Comprehensive flooding risk assessment data including hull breach scenario modeling at 100m depth with 10 atmospheres of external pressure, flood propagation rates, and compartmentalization effectiveness
- Redundant hull integrity monitoring system specifications including automated breach detection sensors at minimum 500-point intervals along the tunnel
- Emergency flooding containment compartment design data including every 200-meter segment interval specifications, rapid-deployment flood barrier systems, and sealing mechanism performance data
- Specialized submersible rescue vehicle specifications including passenger capacity (minimum 50 per vehicle), deployment time, and operational depth capability
- Emergency response vessel specifications including minimum 2 vessels permanently stationed within 30 minutes of the tunnel corridor, with 24/7 standby capability
- Pressurized corridor evacuation system data including redundant pathways, emergency depressurization protocols, and passenger evacuation time estimates
- Full-scale flooding simulation exercise results and annual exercise schedule data
- Insurance and liability framework data for flooding events including coverage terms and risk transfer mechanisms

### Simulation Steps

- Use computational fluid dynamics software (ANSYS Fluent or OpenFOAM) to model flooding scenarios at 100m depth with 10 atmospheres of external pressure, simulating hull breach rates, flood propagation through tunnel compartments, and the effectiveness of emergency flood barriers and containment compartments
- Conduct structural integrity simulation under flooding conditions using finite element analysis (ABAQUS or ANSYS Mechanical), assessing the impact of hydrostatic pressure on tunnel segments, pillar foundations, and rail infrastructure during a breach event
- Model emergency response vessel deployment and rescue operations using maritime simulation tools, assessing response times, passenger evacuation capacity, and coordination with the joint Spain-Morocco emergency coordination center
- Simulate pressurized corridor evacuation scenarios using specialized evacuation modeling software, assessing depressurization rates, passenger flow through emergency pathways, and time-to-safety estimates

### Expert Validation Steps

- Engage Dr. Anika Petrov (Structural Integrity & Lifecycle Maintenance Director) to oversee the development of the comprehensive flooding risk management plan, including redundant hull integrity monitoring and automated breach detection systems
- Commission full-scale flooding simulation exercises annually starting 2028, with joint Spain-Morocco emergency coordination center activation, validated by independent safety assessors
- Require specialized submersible rescue vehicle specifications to be validated by an independent naval architecture firm, with minimum 50-passenger capacity and deployment within 15 minutes of alert
- Engage the Offshore Workforce & Safety Director (Captain James O'Brien) to integrate flooding emergency protocols with the comprehensive safety framework including 24/7 emergency response vessels
- Consult with the International Maritime Organization (IMO) for regulatory guidance on emergency response requirements for submerged rail tunnels carrying passengers
- Obtain insurance coverage specifically for flooding events from major marine insurance providers (e.g., Lloyd's of London, Swiss Re), with coverage terms validated by independent risk assessors
- Commission independent safety certification of the flooding risk management plan from an accredited safety authority before operational commencement

### Responsible Parties

- Structural Integrity & Lifecycle Maintenance Director (Dr. Anika Petrov)
- Offshore Workforce & Safety Director (Captain James O'Brien)
- Joint Spain-Morocco emergency coordination center
- Specialized submersible rescue vehicle manufacturers
- International Maritime Organization (IMO)
- Major marine insurance providers (Lloyd's of London, Swiss Re)
- Accredited safety authority for independent certification
- Independent naval architecture firm for rescue vehicle validation

### Assumptions

- **High:** Redundant hull integrity monitoring with automated breach detection at 500-point intervals can reliably detect hull breaches within minutes, enabling timely emergency response
- **High:** Emergency flooding containment compartments at every 200-meter segment interval can effectively limit flood propagation, preventing catastrophic flooding of the entire tunnel
- **High:** Specialized submersible rescue vehicles with minimum 50-passenger capacity can be deployed within 15 minutes of alert and operate effectively at 100m depth
- **High:** Insurance coverage for flooding events at €500 million-€2 billion per incident can be obtained from major marine insurance providers, making the project financeable

### SMART Validation Objective

Develop comprehensive flooding risk management plan including redundant hull integrity monitoring with automated breach detection at 500-point intervals, emergency flooding containment compartments at every 200-meter segment, rapid-deployment flood barriers, and specialized submersible rescue vehicles (minimum 50 passengers per vehicle) by December 2027; budget €100-300 million for flooding prevention and response infrastructure; establish dedicated emergency response vessels (minimum 2) on 24/7 standby within 30 minutes of the tunnel corridor by March 2028; conduct first full-scale flooding simulation exercise by June 2028; obtain insurance coverage specifically for flooding events before construction mobilization.

### Notes

- The expert review identified this as one of the three most critical issues — a major flooding event could result in total loss of tunnel sections valued at €5-15 billion and potential loss of life creating unlimited liability
- Absence of flooding protocols could make the project uninsurable, preventing financing — this is a gating factor for the entire project
- At 100m depth with 10 atmospheres of external pressure, even a small breach could flood at catastrophic rates — the physics are unforgiving
- The €100-300 million budget for flooding prevention and response infrastructure must be included in the overall €40 billion budget envelope
- Full-scale flooding simulation exercises must be conducted annually starting 2028, with joint Spain-Morocco emergency coordination center activation
- The pressurized corridor evacuation system must have redundant pathways and emergency depressurization protocols — pressurization failure is an existential risk


## 9. Offshore Workforce Composition & Retention Strategy Validation

Offshore workforce resilience over a 20-year isolated construction period presents profound human capital challenges. The isolated offshore environment at 100 meters depth, combined with the project's duration, creates extreme retention difficulties. Even with permanent residential platforms or generous equity incentives, specialized workers may leave due to burnout, family considerations, or better opportunities. High turnover forces repeated training cycles, eroding institutional knowledge and increasing the likelihood of human error during critical installation phases. Workforce turnover exceeding 20% annually could add €500 million-€1.5 billion in repeated recruitment and training costs. Loss of institutional knowledge during critical phases could increase error rates by 15-30%, leading to rework, delays, and safety incidents. Safety incident frequency could increase by 25-50% during high turnover periods.

### Data to Collect

- Workforce composition data including peak construction personnel requirements (8,000-12,000), tiered rotational fly-in-fly-out model specifications, and permanent offshore residential platform capacity requirements
- Workforce turnover rate data and retention strategy effectiveness metrics, including equity-sharing and long-term performance bonus structures tied to operational milestones
- Maritime training institution partnership data including at least 500 qualified trainees annually from institutions in Cadiz province (Spain) and Tanger-Tetouan-Al Hoceima region (Morocco)
- Knowledge management system specifications for capturing structural engineering expertise independent of individual workers
- Offshore residential platform specifications including family accommodation, schools, recreational facilities, and healthcare services
- Safety incident frequency data and target metrics (below 0.5 per 200,000 work hours), including automated shutdown protocol activation statistics
- Workforce cost projections including recruitment, training, retention, and turnover costs over the 20-year construction period

### Simulation Steps

- Use workforce planning simulation software (e.g., SAP SuccessFactors, Workday Workforce Planning) to model the tiered rotational fly-in-fly-out model supplemented by permanent offshore residential platforms, simulating peak construction periods, crew rotation schedules, and workforce turnover scenarios over 20 years
- Conduct retention strategy effectiveness modeling using human capital analytics tools, simulating the impact of equity-sharing, family accommodation, career progression pathways, and competitive compensation on workforce turnover rates, targeting below 15% annually
- Model offshore residential platform capacity requirements using facility planning software, simulating family accommodation needs, recreational facility utilization, and healthcare service demand for 8,000-12,000 personnel
- Simulate safety incident scenarios using risk assessment tools, modeling the impact of workforce turnover on safety incident frequency (25-50% increase during high turnover periods) and the effectiveness of automated shutdown protocols

### Expert Validation Steps

- Engage Captain James O'Brien (Offshore Workforce & Safety Director) to oversee workforce recruitment, retention, training, and safety programs, implementing the tiered rotational fly-in-fly-out model supplemented by permanent offshore residential platforms
- Partner with maritime training institutions in Cadiz province (Spain) and Tanger-Tetouan-Al Hoceima region (Morocco) to establish a continuous pipeline of at least 500 qualified trainees annually, with program effectiveness validated by independent workforce analytics
- Commission independent workforce retention study from a specialized offshore workforce consultancy (e.g., Mercer, Aon Hewitt) to validate retention strategy effectiveness and turnover projections
- Engage the International Marine Contractors Association (IMCA) for validation of offshore safety standards, workforce retention best practices, and rotational model effectiveness
- Require annual safety audits and monthly safety audits conducted by the Offshore Workforce & Safety Director, with results reported to the Program Director and independent safety certification body
- Validate knowledge management system effectiveness through independent assessment of expertise capture and transfer capabilities

### Responsible Parties

- Offshore Workforce & Safety Director (Captain James O'Brien)
- Maritime training institutions in Cadiz province (Spain) and Tanger-Tetouan-Al Hoceima region (Morocco)
- International Marine Contractors Association (IMCA)
- Independent workforce retention consultancy (Mercer, Aon Hewitt)
- Program Director & Cross-Border Governance Lead (Elena Vargas)
- Joint Spain-Morocco security coordination center

### Assumptions

- **High:** Peak construction requires 8,000-12,000 personnel, which can be sustained through a tiered rotational fly-in-fly-out model supplemented by permanent offshore residential platforms with family amenities
- **High:** Workforce turnover can be maintained below 15% annually through a combination of competitive compensation, family accommodation, career progression pathways, and equity-sharing
- **Medium:** Maritime training institutions in Spain and Morocco can produce at least 500 qualified trainees annually, providing a continuous pipeline of personnel for the 20-year construction period
- **Medium:** Permanent offshore residential platforms with family amenities will effectively retain specialized workers despite the extreme isolation of the 100-meter depth environment

### SMART Validation Objective

Establish tiered rotational fly-in-fly-out model with permanent offshore residential platforms by March 2027; partner with maritime training institutions in Spain and Morocco to produce at least 500 qualified trainees annually by June 2027; implement equity-sharing and long-term performance bonus structures tied to operational milestones by September 2027; achieve workforce turnover below 15% annually as validated by independent workforce retention study by December 2027; maintain safety incident frequency below 0.5 per 200,000 work hours as validated by annual safety audits throughout construction.

### Notes

- The expert review identified workforce resilience as a significant risk — high turnover forces repeated training cycles, erodes institutional knowledge, and increases safety incident risk by 25-50%
- Permanent offshore housing creates fixed-cost burdens conflicting with consortium financing constraints — equity-sharing reduces investor returns creating governance tension
- The project must balance workforce retention costs against the €40 billion budget envelope and investor return expectations
- Knowledge management system is critical — expertise must be captured independent of individual workers to prevent institutional knowledge loss during turnover
- Budget: workforce costs over 20 years could reach €500 million-€1.5 billion in repeated recruitment and training if turnover exceeds 20% annually
- The tiered model (3,000-4,000 core permanent staff supplemented by rotational specialists) is recommended as a more cost-effective approach


## 10. Financial Structuring, Currency Risk & Contingency Reserve Validation

The €40 billion budget faces significant exposure to cost escalation over a 20-year construction horizon. Material costs for buoyant concrete, marine-grade steel, and specialized mooring systems are subject to commodity price volatility. Labor costs in offshore construction are projected to rise. The neutral third-party consortium governance model may introduce administrative overhead and decision-making delays that extend the timeline and increase carrying costs. A 10-15% cost overrun would represent €4-6 billion in additional funding. Cost overruns could trigger covenant breaches, investor withdrawal, or forced restructuring. Each additional year of construction could add €300-600 million in interest and overhead. Currency exchange rate risk between EUR and MAD could erode the budget by €200-800 million over 20 years if unhedged. A funding gap of 6-12 months could halt construction, costing €500 million-€1 billion in idle workforce and equipment costs.

### Data to Collect

- Detailed cost breakdown by functional subsystem across the €40 billion budget, including pillar architecture, construction deployment, rail systems, environmental compliance, and operational readiness allocations
- Currency hedging program specifications covering at least 70% of projected MAD-denominated expenditures, including forward contracts, swaps, and monthly FX exposure monitoring
- €4-6 billion contingency reserve allocation with automated escalation triggers at 5%, 10%, and 15% budget utilization
- 12-month operational reserve fund specifications and funding mechanism
- Tranche-based financing disbursement schedule tied to geological and marine milestones from multilateral government bonds, public-private partnerships, and development bank funds
- Cost escalation risk analysis including material cost volatility for buoyant concrete, marine-grade steel, and specialized mooring systems, and labor cost projections for offshore construction
- Investor confidence metrics and funding continuity risk assessment including funding cliff scenarios (6-12 month funding gaps costing €500 million-€1 billion)
- 20-year lifecycle cost analysis including maintenance trust fund (€3-8 billion) and decommissioning reserve fund (€2-4 billion) capitalization schedules

### Simulation Steps

- Use financial modeling software (e.g., MATLAB Financial Toolbox, Excel with @RISK) to model the €40 billion budget allocation across functional subsystems, simulating cost escalation scenarios (10-15% potential overrun = €4-6 billion), currency risk (€200-800 million), and funding continuity threats (€500 million-€1 billion per 6-12 month funding gap)
- Conduct currency risk simulation using Monte Carlo methods in @RISK or Crystal Ball, modeling EUR/MAD exchange rate fluctuations over 20 years and assessing the impact of hedging coverage (70% vs. 100%) on budget exposure
- Model tranche-based financing disbursement scenarios using project finance modeling tools (e.g., Promoter, eValuation), simulating milestone-based disbursements tied to geological and marine milestones and assessing funding cliff risks
- Simulate contingency reserve depletion scenarios using risk analysis software, modeling automated escalation triggers at 5%, 10%, and 15% budget utilization and assessing the probability of reserve exhaustion

### Expert Validation Steps

- Engage Hans Mueller (International Finance & Capital Director) to structure and manage the sourcing of the €40 billion capital through multilateral government bonds, public-private partnerships, and development bank funds
- Commission independent financial risk assessment from a specialized megaproject finance consultancy (e.g., McKinsey Infrastructure, PwC Infrastructure) to validate cost breakdown, contingency reserve adequacy, and currency hedging strategy
- Negotiate financing terms with the European Investment Bank, African Development Bank, and multilateral development banks, ensuring tranche-based disbursements align with geological and marine milestones
- Engage the International Finance & Capital Director to implement comprehensive currency hedging program covering at least 70% of projected MAD-denominated expenditures using forward contracts and swaps
- Require quarterly financial reviews with investor groups to maintain investor confidence and unlock successive funding tranches, with automated escalation triggers at 5%, 10%, and 15% budget utilization
- Consult with the International Chamber of Commerce (ICC) for validation of financing structure and tranche-based disbursement mechanisms
- Commission 20-year lifecycle cost analysis during design phase to inform budget allocation, validated by independent cost consultancy

### Responsible Parties

- International Finance & Capital Director (Hans Mueller)
- European Investment Bank
- African Development Bank
- Multilateral development banks
- Private equity investors and institutional lenders
- Independent financial risk consultancy (McKinsey Infrastructure, PwC Infrastructure)
- Program Director & Cross-Border Governance Lead (Elena Vargas)
- International Chamber of Commerce (ICC)

### Assumptions

- **High:** The €40 billion budget is sufficient to complete the project, including a 10-15% contingency reserve (€4-6 billion), a 12-month operational reserve fund, and currency hedging covering 70% of MAD-denominated expenditures
- **High:** Tranche-based financing disbursements tied to geological and marine milestones will maintain investor confidence and provide continuous funding without unacceptable gaps
- **Medium:** Currency hedging covering 70% of projected MAD-denominated expenditures will adequately protect the budget from EUR/MAD fluctuations over 20 years
- **Medium:** Cost escalation can be contained within 10-15% through fixed-price contracts, penalty clauses, and rigorous cost tracking with automated escalation triggers

### SMART Validation Objective

Establish €4-6 billion contingency reserve with automated escalation triggers at 5%, 10%, and 15% budget utilization by September 2026; implement comprehensive currency hedging program covering at least 70% of projected MAD-denominated expenditures by December 2026; secure tranche-based financing commitments from multilateral government bonds, public-private partnerships, and development bank funds by June 2027; complete detailed cost breakdown by functional subsystem by March 2027; establish 12-month operational reserve fund by December 2026; commission 20-year lifecycle cost analysis during design phase by September 2027; establish dedicated maintenance trust fund of €3-8 billion and decommissioning reserve fund of €2-4 billion capitalized at project inception.

### Notes

- The expert review identified financial sustainability as one of the three most critical risks — cost escalation, currency risk, and funding continuity threats could erode the €40 billion budget envelope
- Each additional year of construction adds €300-600 million in carrying costs — timeline delays directly compound financial exposure
- The 30% of MAD exposure not covered by hedging (potentially €200-800 million) is accepted as a manageable risk but must be actively monitored
- Funding cliffs — if a milestone is delayed or disputed, subsequent funding may be withheld, creating cascading cash flow crises
- The project must diversify funding sources across sovereign bonds, development bank facilities, and private capital to mitigate funding cliff risks
- Budget: €4-6 billion contingency reserve, €12-month operational reserve fund, €3-8 billion maintenance trust fund, €2-4 billion decommissioning reserve fund


## 11. Corrosion & Durability Management Validation

Corrosion and durability over a 20-year submerged lifespan is a fundamental challenge for the aggressive saline environment at 100 meters depth. The complex hybrid floating-pillar joints and articulated flexible connections create numerous pathways for saline ingress. Unmanaged corrosion could reduce structural lifespan below the 20-year horizon, requiring premature rehabilitation costing €3-8 billion. Cathodic protection failure could accelerate degradation by 3-5x, potentially necessitating full replacement within 15 years. Polymer encapsulation can be breached during installation or degraded by UV exposure; sacrificial anodes require periodic replacement in inaccessible locations; active cathodic protection depends on reliable power at depth. The multi-layer approach combining polymer encapsulation, sacrificial anodes, and active cathodic protection as redundant systems is essential, but each layer introduces complexity, cost, and potential failure points.

### Data to Collect

- Multi-layer corrosion protection system specifications including seamless polymer encapsulation, sacrificial zinc anodes within the concrete mix, and active cathodic protection grid powered by offshore tidal energy generators
- Accelerated life-cycle testing data under simulated 20-year saline exposure conditions for all corrosion protection materials and systems
- Accessible inspection and maintenance port specifications at regular intervals along the tunnel for corrosion monitoring and protection system maintenance
- Corrosion monitoring program specifications including predictive analytics models and real-time degradation tracking systems
- Cathodic protection power supply specifications including offshore tidal energy generator capacity and reliability data
- Polymer encapsulation integrity testing data including breach detection capabilities and internal carbonation risk assessment
- 20-year maintenance cost projections (€3-8 billion) with detailed breakdown by corrosion protection system component
- Sacrificial anode replacement schedule and accessibility data for inaccessible locations

### Simulation Steps

- Use corrosion modeling software (e.g., COMSOL Multiphysics with corrosion modules, or specialized software like CorrCAD) to simulate multi-layer corrosion protection system performance over 20 years under saline exposure at 100m depth, modeling polymer encapsulation degradation, sacrificial anode consumption rates, and cathodic protection effectiveness
- Conduct accelerated life-cycle testing of corrosion protection materials in simulated saline environments using environmental testing chambers, validating 20-year performance predictions against accelerated test results
- Model predictive analytics for corrosion progression using machine learning tools (e.g., Python with scikit-learn, TensorFlow), training on simulated degradation data to predict corrosion rates and maintenance intervals
- Simulate cathodic protection system performance using electrochemical modeling software, assessing power supply requirements from offshore tidal energy generators and system reliability under varying ocean conditions

### Expert Validation Steps

- Engage Dr. Anika Petrov (Structural Integrity & Lifecycle Maintenance Director) to oversee the implementation of multi-layer corrosion protection systems and the corrosion monitoring program with predictive analytics
- Commission independent corrosion assessment from a specialized marine corrosion consultancy (e.g., DNV, Bureau Veritas) to validate multi-layer protection system specifications and 20-year performance predictions
- Require accelerated life-cycle testing of all corrosion protection materials under simulated 20-year saline exposure conditions before mass production of tunnel segments
- Engage the IEEE standards committee for validation of cathodic protection system design and underwater power transmission standards
- Consult with the Structural Integrity & Lifecycle Maintenance Director to ensure corrosion protection systems integrate with structural surveillance data for predictive maintenance
- Validate polymer encapsulation integrity testing data with independent materials testing laboratory, assessing breach detection capabilities and internal carbonation risk
- Establish dedicated corrosion monitoring program with predictive analytics, validated by independent assessment of analytics model accuracy

### Responsible Parties

- Structural Integrity & Lifecycle Maintenance Director (Dr. Anika Petrov)
- Independent marine corrosion consultancy (DNV, Bureau Veritas)
- IEEE standards committee
- Offshore tidal energy generator manufacturers
- Independent materials testing laboratory
- Polymer encapsulation system manufacturers
- Sacrificial anode suppliers

### Assumptions

- **High:** Multi-layer corrosion protection combining polymer encapsulation, sacrificial anodes, and active cathodic protection as redundant systems will achieve 20+ year structural durability in the aggressive saline environment at 100m depth
- **Medium:** Accelerated life-cycle testing under simulated 20-year saline exposure will accurately predict real-world corrosion protection performance, with scaling factors validated by independent assessment
- **High:** Polymer encapsulation can maintain integrity over 20 years without breach, and any breach can be detected and repaired before internal carbonation accelerates degradation
- **Medium:** Active cathodic protection powered by offshore tidal energy generators will provide reliable power at 100m depth for 20+ years, with redundancy for power failure scenarios

### SMART Validation Objective

Complete multi-layer corrosion protection system specifications (polymer encapsulation, sacrificial anodes, active cathodic protection) by June 2027; conduct accelerated life-cycle testing under simulated 20-year saline exposure for all protection materials by December 2027; deploy accessible inspection and maintenance ports at regular intervals along the tunnel by March 2028; establish dedicated corrosion monitoring program with predictive analytics by June 2028; validate 20-year maintenance cost projections (€3-8 billion) through independent assessment by September 2028; commission sacrificial anode replacement schedule and accessibility assessment by December 2028.

### Notes

- Unmanaged corrosion could reduce structural lifespan below the 20-year horizon, requiring premature rehabilitation costing €3-8 billion
- Cathodic protection failure could accelerate degradation by 3-5x, potentially necessitating full replacement within 15 years
- Polymer encapsulation can be breached during installation — the installation process must not compromise the protection system
- Sacrificial anodes require periodic replacement in inaccessible locations — maintenance access design is critical
- Active cathodic protection depends on reliable power at depth — energy infrastructure (Item 5) must be resolved first
- Budget: €3-8 billion for 20-year maintenance including corrosion protection
- The corrosion monitoring program with predictive analytics must be validated for accuracy before relying on it for maintenance decisions


## 12. Climate Change Adaptation & Long-Term Oceanographic Projections

The project is designed for a 20-year lifespan but makes no reference to climate change projections — sea level rise, ocean current changes, storm intensity increases, or water temperature changes. The Strait of Gibraltar is vulnerable to Atlantic climate variability. Sea levels may rise 0.3-0.6m by 2043 (IPCC projections). These changes could alter hydrodynamic forces, buoyancy equilibrium, and the corrosion environment. The design assumes static oceanographic conditions, which is scientifically indefensible for a 20-year infrastructure project. Unaccounted sea level rise of 0.5m could alter depth profile and buoyancy equilibrium, requiring modifications costing €1-3 billion. Increased storm intensity of 20% could increase hydrodynamic forces by 15-25%, risking damage costing €500 million-€2 billion per severe event. Without climate adaptation, design life could be reduced from 20 to 12-15 years, requiring premature rehabilitation costing €3-6 billion.

### Data to Collect

- IPCC climate projection data (SSP2-4.5 and SSP5-8.5 scenarios) including sea level rise projections (0.3-0.6m by 2043), storm intensity increases (10-20%), and potential ocean current changes for the Strait of Gibraltar region
- Oceanographic monitoring data establishing baseline conditions for the Strait of Gibraltar including current patterns, water temperature, and wave characteristics
- Adaptive buoyancy system design specifications to compensate for sea level changes over the 20-year operational lifespan
- Hydrodynamic load model updates incorporating climate change projections into structural design parameters
- Climate adaptation budget allocation of €200-400 million with detailed cost breakdown
- Ongoing oceanographic monitoring program specifications with 5-year design parameter update cycles
- Storm intensity impact analysis on hydrodynamic forces, buoyancy equilibrium, and corrosion environment over the 20-year lifespan

### Simulation Steps

- Use IPCC climate projection data (SSP2-4.5 and SSP5-8.5) to model sea level rise (0.3-0.6m), storm intensity increases (10-20%), and ocean current changes for the Strait of Gibraltar region through 2043, using climate modeling software (e.g., NOAA CESM, IPCC AR6 scenario tools)
- Conduct hydrodynamic load simulations incorporating climate change projections using ANSYS Fluent or OpenFOAM, assessing the impact of increased storm intensity and altered current patterns on tunnel structural loads, buoyancy equilibrium, and pillar foundation forces
- Model adaptive buoyancy system performance under sea level change scenarios using buoyancy simulation tools, validating the system's ability to compensate for 0.3-0.6m sea level rise while maintaining 100m depth positioning
- Simulate corrosion environment changes under climate change projections using corrosion modeling software, assessing the impact of increased water temperature and altered ocean chemistry on corrosion rates over the 20-year lifespan

### Expert Validation Steps

- Engage the Chief Engineer / Technical Director (proposed role) to oversee the climate adaptation workstream, integrating IPCC climate projections into all structural design parameters
- Commission oceanographic monitoring program from specialized marine research institutions (e.g., Spanish Institute of Oceanography, Moroccan National Institute of Oceanography) to establish baseline conditions and ongoing monitoring
- Consult with the IPCC working group on sea level rise projections and storm intensity forecasts specific to the Mediterranean and Strait of Gibraltar region
- Engage the Environmental Compliance & Marine Ecology Director (Dr. Fatima Al-Rashid) to contribute marine ecosystem impact data for climate change adaptation planning
- Require all structural designs to incorporate climate change projections (sea level rise of 0.3-0.6m, increased storm intensity of 10-20%) as validated by the independent seismic review panel
- Validate adaptive buoyancy system design with the Geotechnical & Seismic Engineering Director (Dr. Kenji Tanaka) to ensure compatibility with pillar architecture and hydrodynamic load mitigation
- Commission ongoing oceanographic monitoring with 5-year design parameter update cycles, validated by independent assessment of monitoring data quality

### Responsible Parties

- Chief Engineer / Technical Director (proposed role)
- Environmental Compliance & Marine Ecology Director (Dr. Fatima Al-Rashid)
- Structural Integrity & Lifecycle Maintenance Director (Dr. Anika Petrov)
- Geotechnical & Seismic Engineering Director (Dr. Kenji Tanaka)
- Spanish Institute of Oceanography
- Moroccan National Institute of Oceanography
- IPCC working group on sea level rise projections
- Independent oceanographic monitoring assessment body

### Assumptions

- **High:** IPCC climate projections (SSP2-4.5 and SSP5-8.5) can be reliably applied to the Strait of Gibraltar region, with sea level rise of 0.3-0.6m and increased storm intensity of 10-20% over the 20-year lifespan
- **High:** Adaptive buoyancy systems can be designed to compensate for sea level changes of 0.3-0.6m while maintaining precise 100m depth positioning without compromising structural integrity
- **Medium:** Increased storm intensity of 10-20% will increase hydrodynamic forces by 15-25%, which can be accommodated within the structural design margins without requiring redesign
- **Medium:** Ongoing oceanographic monitoring with 5-year design parameter update cycles will provide sufficient data to adapt the tunnel's operational parameters to changing climate conditions

### SMART Validation Objective

Integrate IPCC climate projections (SSP2-4.5 and SSP5-8.5) into structural design incorporating sea level rise of 0.3-0.6m and increased storm intensity of 10-20% by June 2027; design adaptive buoyancy systems to compensate for sea level changes by September 2027; commission ongoing oceanographic monitoring program with 5-year design parameter update cycles by December 2027; budget €200-400 million for climate adaptation measures; validate all structural designs against climate change projections through the independent seismic review panel by March 2028.

### Notes

- The project design assumes static oceanographic conditions, which is scientifically indefensible for a 20-year infrastructure project in a climate-vulnerable region
- Unaccounted sea level rise of 0.5m could alter depth profile and buoyancy equilibrium, requiring modifications costing €1-3 billion
- Increased storm intensity of 20% could increase hydrodynamic forces by 15-25%, risking damage costing €500 million-€2 billion per severe event
- Without climate adaptation, design life could be reduced from 20 to 12-15 years, requiring premature rehabilitation costing €3-6 billion
- The climate adaptation workstream should be assigned to the Chief Engineer / Technical Director (proposed role) with a dedicated climate adaptation workstream
- Budget: €200-400 million for climate adaptation measures
- Ongoing oceanographic monitoring must be established to update design parameters every 5 years throughout the operational lifespan


## 13. Decommissioning & End-of-Life Planning

The project specifies a 20-year operational lifespan but provides zero detail on end-of-life. Decommissioning a submerged tunnel at 100m depth across international waters between two nations is unprecedented. Who bears the cost? How are materials disposed of without further marine damage? What happens to seabed pillars? The €3-8 billion maintenance trust fund addresses operational costs but not decommissioning, creating a massive unfunded liability. Unplanned decommissioning costs could reach €5-15 billion depending on method. Failure to plan could result in the tunnel becoming an artificial reef with unknown ecological consequences, triggering environmental liability claims of €1-5 billion. Regulatory requirements could change over 20 years, imposing unanticipated standards. The absence of a decommissioning plan is a significant secondary risk that compounds the primary issues identified in the project.

### Data to Collect

- Comprehensive decommissioning plan including environmental remediation protocols, material recovery strategies, and seabed restoration requirements for the submerged tunnel at end of 20-year lifespan
- Decommissioning cost estimates ranging from €5-15 billion depending on method, with detailed breakdown by decommissioning phase
- €2-4 billion decommissioning reserve fund capitalization schedule and investment strategy
- Bilateral treaty provisions for decommissioning obligations negotiated between Spain and Morocco
- IMO framework provisions for decommissioning of submerged structures in international waters
- Full lifecycle assessment (LCA) of construction and decommissioning environmental footprint
- Material recovery feasibility study including buoyant concrete segment recovery, steel recycling, and pillar removal strategies
- Seabed restoration requirements and timeline for pillar removal and habitat recovery

### Simulation Steps

- Use lifecycle assessment software (e.g., SimaPro, OpenLCA) to model the full environmental footprint of construction and decommissioning, comparing different decommissioning methods (partial removal, full removal, in-situ conversion to artificial reef) and their environmental impacts
- Model decommissioning cost scenarios using financial modeling tools, simulating different decommissioning approaches (mechanical removal, controlled abandonment, conversion to artificial reef) and their cost implications over the 20-year horizon
- Simulate decommissioning reserve fund growth using investment modeling software, assessing different capitalization schedules and investment strategies to ensure €2-4 billion is available at end of lifespan
- Model seabed restoration scenarios using marine habitat simulation tools, assessing the environmental impact of pillar removal and the timeline for habitat recovery after decommissioning

### Expert Validation Steps

- Appoint a Decommissioning & End-of-Life Director (proposed role, initially concurrent within Structural Integrity Director's portfolio) responsible for developing the comprehensive decommissioning plan
- Commission full lifecycle assessment (LCA) of construction and decommissioning environmental footprint from independent environmental consultancy (e.g., AECOM, Jacobs)
- Negotiate decommissioning obligations in the bilateral treaty between Spain and Morocco, with IMO framework provisions for submerged structures in international waters
- Engage the International Maritime Organization (IMO) for regulatory guidance on decommissioning of submerged structures at 100m depth in international waters
- Consult with the Environmental Compliance & Marine Ecology Director (Dr. Fatima Al-Rashid) to ensure decommissioning plan incorporates marine ecosystem restoration requirements
- Validate decommissioning cost estimates (€5-15 billion) through independent cost consultancy assessment
- Establish €2-4 billion decommissioning reserve fund capitalization schedule, validated by independent financial assessment
- Conduct material recovery feasibility study with specialized marine construction and recycling firms

### Responsible Parties

- Decommissioning & End-of-Life Director (proposed role)
- Structural Integrity & Lifecycle Maintenance Director (Dr. Anika Petrov)
- Environmental Compliance & Marine Ecology Director (Dr. Fatima Al-Rashid)
- International Maritime Organization (IMO)
- Independent environmental consultancy (AECOM, Jacobs)
- Independent cost consultancy
- Bilateral diplomatic task force (Spain-Morocco)
- Specialized marine construction and recycling firms

### Assumptions

- **High:** Decommissioning costs can be estimated at €5-15 billion depending on method, with a €2-4 billion decommissioning reserve fund capitalized at project inception providing adequate funding
- **High:** Decommissioning obligations can be negotiated in the bilateral treaty and IMO framework, with clear allocation of responsibility between Spain and Morocco
- **Medium:** Material recovery (buoyant concrete segments, steel, pillar removal) is technically feasible at 100m depth without causing further marine damage
- **Medium:** Seabed restoration after decommissioning can achieve acceptable habitat recovery within a reasonable timeframe, avoiding long-term ecological liability

### SMART Validation Objective

Develop comprehensive decommissioning plan during design phase including environmental remediation protocols, material recovery strategies, and seabed restoration requirements by December 2028; establish €2-4 billion decommissioning reserve fund capitalized at project inception by March 2029; negotiate decommissioning obligations in bilateral treaty and IMO framework by June 2029; conduct full lifecycle assessment (LCA) of construction and decommissioning environmental footprint by September 2029; validate decommissioning cost estimates (€5-15 billion) through independent assessment by December 2029.

### Notes

- The absence of a decommissioning plan creates a massive unfunded liability of €5-15 billion — this is a significant secondary risk that compounds the primary issues
- Decommissioning a submerged tunnel at 100m depth across international waters between two nations is unprecedented — there is no existing precedent to reference
- The €2-4 billion decommissioning reserve fund must be capitalized at project inception, not deferred to end of lifespan
- Regulatory requirements could change over 20 years, imposing unanticipated standards that could increase decommissioning costs
- Failure to plan could result in the tunnel becoming an artificial reef with unknown ecological consequences, triggering environmental liability claims of €1-5 billion
- The decommissioning plan should be developed during the design phase, not deferred to the end of the operational period
- Material recovery feasibility must be validated — recovery at 100m depth presents unique engineering challenges


## 14. Supply Chain Resilience & Distributed Manufacturing Validation

The supply chain depends on enormous quantities of specialized materials — buoyant concrete, marine-grade steel, mooring systems, and corrosion protection materials — delivered to remote offshore locations across international waters. A single mega-hub in southern Spain creates a catastrophic single point of failure. A port strike, facility fire, or logistics disruption at the hub could halt all construction simultaneously, costing €1-3 billion for a 2-4 month disruption. Material shortages could force design compromises that reduce structural integrity or operational capability. Concentration at a single hub makes the project vulnerable to terrorism, piracy, or geopolitical disruption. The distributed supply chain with two regional fabrication yards is essential for resilience, but it also increases procurement complexity and inventory holding costs. The blockchain-based tracking system provides real-time visibility but adds implementation complexity.

### Data to Collect

- Distributed supply chain architecture data including at least two regional fabrication yards (southern Spain near Tarifa/Algeciras and northern Morocco near Tangier-Med) for redundancy
- Strategic inventory levels of critical materials (buoyant concrete, marine-grade steel, mooring systems, corrosion protection materials) at offshore staging areas (3-6 month supply)
- Pre-qualified alternative supplier data for all critical material categories, including qualification criteria and backup supplier activation protocols
- Blockchain-based supply chain tracking system specifications for real-time procurement visibility
- Single mega-hub risk assessment data quantifying the catastrophic single point of failure risk at the centralized southern Spain hub
- Port strike, facility fire, and logistics disruption scenario modeling and cost impact data (€1-3 billion for 2-4 month disruption)
- Maritime transport corridor logistics data including dedicated transport vessel specifications, weather window dependencies, and maritime traffic coordination requirements

### Simulation Steps

- Use supply chain modeling software (e.g., AnyLogistix, SAP Supply Chain Management) to model the distributed supply chain architecture with two regional fabrication yards, simulating disruption scenarios (port strike, facility fire, logistics disruption) and assessing the impact on construction schedule and costs
- Conduct Monte Carlo simulation of supply chain disruption scenarios using @RISK or Crystal Ball, modeling the probability and impact of single-point-of-failure events at the centralized mega-hub versus the distributed architecture
- Model maritime transport logistics using specialized maritime simulation tools, simulating transport vessel operations, weather window dependencies, and maritime traffic coordination in the Strait of Gibraltar
- Simulate blockchain-based supply chain tracking system performance using blockchain simulation tools, validating real-time visibility, data integrity, and traceability of critical materials

### Expert Validation Steps

- Engage the Marine Construction & Offshore Engineering Lead (Marcus Dubois) to oversee the distributed supply chain architecture and regional fabrication yard operations
- Commission supply chain risk assessment from a specialized supply chain consultancy (e.g., McKinsey Operations, Accenture Supply Chain) to validate the distributed architecture and redundancy provisions
- Establish pre-qualified alternative suppliers for all critical material categories, with qualification validated by independent procurement audit
- Engage blockchain technology providers (e.g., IBM Blockchain, SAP Blockchain) for supply chain tracking system implementation and validation
- Negotiate maritime transport corridor agreements with the Strait of Gibraltar Joint Coordination Center and international maritime authorities
- Validate 3-6 month strategic inventory levels at offshore staging areas through independent logistics assessment
- Conduct port strike and logistics disruption scenario planning with the bilateral diplomatic task force and international legal counsel

### Responsible Parties

- Marine Construction & Offshore Engineering Lead (Marcus Dubois)
- Supply chain risk consultancy (McKinsey Operations, Accenture Supply Chain)
- Blockchain technology providers (IBM Blockchain, SAP Blockchain)
- Strait of Gibraltar Joint Coordination Center
- Pre-qualified alternative suppliers for critical materials
- Regional fabrication yards in southern Spain and northern Morocco
- Bilateral diplomatic task force (Spain-Morocco)
- International legal counsel

### Assumptions

- **High:** A distributed supply chain with at least two regional fabrication yards (Spain and Morocco) provides sufficient redundancy to mitigate single-point-of-failure risks without unacceptable cost increases
- **Medium:** 3-6 month strategic inventory of critical materials at offshore staging areas can be maintained without excessive holding costs or material degradation
- **Medium:** Pre-qualified alternative suppliers can be activated within acceptable timeframes during a disruption, with qualification standards maintained across all suppliers
- **Medium:** Blockchain-based supply chain tracking will provide sufficient real-time visibility and data integrity to support procurement decisions and disruption response

### SMART Validation Objective

Establish distributed supply chain with at least two regional fabrication yards (southern Spain near Tarifa/Algeciras and northern Morocco near Tangier-Med) by December 2027; maintain 3-6 month strategic inventory of critical materials at offshore staging areas by March 2028; pre-qualify alternative suppliers for all critical material categories by June 2028; implement blockchain-based supply chain tracking system by September 2028; complete supply chain risk assessment validating the distributed architecture by March 2027; negotiate maritime transport corridor agreements with international authorities by June 2027.

### Notes

- The centralized mega-hub in southern Spain creates a catastrophic single point of failure — a port strike, facility fire, or logistics disruption could halt all construction simultaneously
- A disruption lasting 2-4 months could cost €1-3 billion in idle costs, contract penalties, and accelerated recovery costs
- The distributed architecture increases procurement complexity and inventory holding costs but provides essential resilience
- Blockchain-based tracking provides real-time visibility but adds implementation complexity and cost
- The project must develop pre-qualified alternative suppliers for all critical material categories
- Maritime transport in the Strait of Gibraltar is subject to weather windows, ocean currents, and heavy shipping traffic — transport delays could cascade through the construction schedule at €10-30 million per week
- Budget: supply chain resilience measures should be factored into the overall €40 billion budget

## Summary

This project plan identifies 14 critical data collection areas for the €40 billion, 20-year pillar-supported transoceanic submerged tunnel connecting Spain and Morocco at 100m depth across the Strait of Gibraltar. The plan addresses the most critical gaps identified across all project documents: (1) the complete absence of site-specific seismic and geotechnic data near the Azores-Gibraltar fault zone, (2) the unprecedented hybrid floating-pillar architecture requiring validation through scaled physical model testing and a fully instrumented prototype, (3) the fundamentally incomplete cross-border governance legal architecture lacking treaty law foundation, (4) the missing energy supply infrastructure plan without which the tunnel cannot operate, (5) the rail gauge incompatibility threatening the core purpose of seamless transcontinental connectivity, (6) the inadequate maritime traffic integration in one of the world's busiest shipping lanes, (7) the missing flooding emergency protocols representing an existential safety risk, (8) the offshore workforce resilience challenges over a 20-year isolated construction period, (9) the financial structuring and currency risk management requirements, (10) the corrosion and durability management for 20-year submerged lifespan, (11) the absent climate change adaptation in design assumptions, (12) the massive unfunded decommissioning liability, (13) the supply chain single-point-of-failure risk, and (14) the environmental compliance and marine ecosystem baseline requirements. Each data collection area includes specific simulation steps using industry-standard software tools, expert validation steps identifying specific human experts or authoritative bodies, SMART validation objectives, sensitivity-scored assumptions, and identified risks. The immediate priority is the geotechnical and seismic validation gate (Item 1) and the hybrid floating-pillar architecture validation (Item 2), as these are the foundational prerequisites for all subsequent engineering decisions.