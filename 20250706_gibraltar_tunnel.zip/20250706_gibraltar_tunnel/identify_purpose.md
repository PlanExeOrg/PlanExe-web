**Purpose:** business

**Purpose Detailed:** Large-scale infrastructure construction and transportation initiative involving the engineering and deployment of buoyant concrete tunnels anchored 100 meters below sea level to enable high-speed rail connectivity between two nations. This is a massive governmental/societal infrastructure project with significant economic, commercial, and public welfare implications.

**Topic:** 20-year, €40 billion transoceanic submerged tunnel infrastructure project connecting Spain and Morocco for high-speed rail traffic