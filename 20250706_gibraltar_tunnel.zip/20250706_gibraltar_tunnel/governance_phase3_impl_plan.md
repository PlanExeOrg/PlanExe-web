### 1. Project Sponsor (Joint Spanish-Moroccan Government) initiates governance framework design by commissioning a senior governance advisor to draft the overall governance architecture document, defining the hierarchy, reporting lines, and authority boundaries for all six governance bodies

**Responsible Body/Role:** Project Sponsor (Joint Spanish-Moroccan Government) via designated Senior Governance Advisor

**Suggested Timeframe:** Project Week 1-2

**Key Outputs/Deliverables:**

- Governance Architecture Document v0.1
- Initial governance body hierarchy map
- Draft authority and reporting framework

**Dependencies:**

- Project formally authorized and funded
- Bilateral government commitment secured

### 2. Bilateral Diplomatic Task Force drafts and negotiates the foundational bilateral treaty framework that establishes the legal basis for the project governance structure, including provisions for the Steering Committee's sovereign authority and the neutral third-party consortium model

**Responsible Body/Role:** Bilateral Diplomatic Task Force (Spain-Morocco)

**Suggested Timeframe:** Project Week 1-8 (ongoing negotiation)

**Key Outputs/Deliverables:**

- Draft Bilateral Treaty Framework
- Treaty provisions for governance structure
- Pre-negotiated dispute resolution clauses

**Dependencies:**

- Governance Architecture Document approved by both governments
- Political commitment from both sovereign nations

### 3. Senior Governance Advisor drafts the initial Terms of Reference (ToR) for the Project Steering Committee, including membership criteria, decision rights, meeting cadence, and escalation protocols, based on the approved governance architecture

**Responsible Body/Role:** Senior Governance Advisor (designated by Project Sponsor)

**Suggested Timeframe:** Project Week 2-3

**Key Outputs/Deliverables:**

- Draft Steering Committee ToR v0.1
- Proposed membership roster with role descriptions
- Draft decision rights matrix

**Dependencies:**

- Governance Architecture Document approved
- Bilateral Treaty Framework initial draft available

### 4. Project Sponsor circulates the Draft Steering Committee ToR to nominated members and key stakeholders (Ministry of Transport Spain, Ministry of Equipment and Transport Morocco, nominated independent members) for review and feedback

**Responsible Body/Role:** Project Sponsor (Joint Spanish-Moroccan Government)

**Suggested Timeframe:** Project Week 3-4

**Key Outputs/Deliverables:**

- Circulated Draft SteerCo ToR for review
- Feedback summary from nominated members
- List of required revisions

**Dependencies:**

- Draft Steering Committee ToR v0.1 completed
- Nominated members list confirmed

### 5. Project Sponsor finalizes the Steering Committee ToR incorporating feedback, and formally requests both parliaments (Spanish Cortes Generales and Moroccan Parliament) to ratify the governance charter as part of the bilateral treaty

**Responsible Body/Role:** Project Sponsor (Joint Spanish-Moroccan Government) via International Legal Counsel

**Suggested Timeframe:** Project Week 4-6

**Key Outputs/Deliverables:**

- Finalized Steering Committee ToR v1.0
- Formal parliamentary ratification request
- International legal opinion on governance charter

**Dependencies:**

- Review feedback incorporated
- Bilateral Treaty Framework sufficiently advanced
- International legal counsel retained

### 6. Project Sponsor formally appoints the Steering Committee Chair (senior Spanish representative) and Vice-Chair (senior Moroccan representative) through official government designation, establishing initial leadership for the governance body

**Responsible Body/Role:** Project Sponsor (Joint Spanish-Moroccan Government)

**Suggested Timeframe:** Project Week 5-7 (concurrent with parliamentary ratification)

**Key Outputs/Deliverables:**

- Official appointment of Steering Committee Chair
- Official appointment of Steering Committee Vice-Chair
- Appointment confirmation communications

**Dependencies:**

- Finalized Steering Committee ToR approved by Project Sponsor
- Bilateral government agreement on Chair/Vice-Chair candidates

### 7. Project Sponsor confirms and formally notifies all nominated Steering Committee members (Ministers, consortium Chair, diplomatic task force head, independent external members, regional governors) of their appointments and the governance charter obligations

**Responsible Body/Role:** Project Sponsor (Joint Spanish-Moroccan Government)

**Suggested Timeframe:** Project Week 6-8

**Key Outputs/Deliverables:**

- Confirmed Steering Committee membership roster
- Formal appointment letters to all members
- Governance charter acceptance acknowledgments

**Dependencies:**

- Steering Committee Chair and Vice-Chair appointed
- All nominated members identified and approached
- Parliamentary ratification process initiated

### 8. Steering Committee holds its formal inaugural kick-off meeting, ratifies its own ToR, defines financial approval thresholds, and establishes the strategic direction and governance framework for all subordinate bodies

**Responsible Body/Role:** Project Steering Committee (formally constituted)

**Suggested Timeframe:** Project Week 8-9

**Key Outputs/Deliverables:**

- Steering Committee inaugural meeting minutes
- Ratified Steering Committee ToR
- Defined financial approval thresholds
- Strategic framework approval
- Formal establishment of all reporting lines

**Dependencies:**

- All Steering Committee members confirmed and appointed
- Finalized ToR ratified by both parliaments (or interim authorization)
- Chair and Vice-Chair formally designated

### 9. Steering Committee approves the Terms of Reference for the Project Management Office (PMO), including its organizational structure, delegated authority thresholds, and reporting lines to the Steering Committee

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 9-10

**Key Outputs/Deliverables:**

- Approved PMO Terms of Reference
- PMO organizational structure chart
- Delegated authority matrix (up to €50 million)

**Dependencies:**

- Steering Committee formally constituted and operational
- PMO ToR drafted by Interim PMO Formation Lead

### 10. Interim PMO Formation Lead (designated by Project Sponsor) drafts the initial PMO ToR, organizational structure, and key operational protocols, including CPM master schedule framework and automated budget escalation trigger specifications

**Responsible Body/Role:** Interim PMO Formation Lead (designated by Project Sponsor)

**Suggested Timeframe:** Project Week 3-5 (parallel with Steering Committee setup)

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1
- Proposed PMO organizational structure
- Draft CPM master schedule framework
- Budget escalation trigger specifications

**Dependencies:**

- Governance Architecture Document approved
- Project phase-gate strategy defined

### 11. Steering Committee appoints the Project Director and Deputy Project Director for the PMO, and formally constitutes the PMO with all functional leads (Phase 1, 2, 3, Logistics, Workforce, HSE, etc.)

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 10-11

**Key Outputs/Deliverables:**

- Appointed Project Director and Deputy Director
- Confirmed PMO functional leads
- Formally constituted PMO membership roster

**Dependencies:**

- PMO ToR approved by Steering Committee
- Candidate shortlist for Project Director prepared
- Steering Committee operational

### 12. PMO holds its inaugural kick-off meeting, assigns initial operational tasks, establishes the weekly coordination meeting cadence, and begins setting up the automated budget tracking and escalation trigger system

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 11-12

**Key Outputs/Deliverables:**

- PMO inaugural meeting minutes
- Operational task assignments
- Weekly coordination meeting schedule established
- Budget tracking system initialization

**Dependencies:**

- PMO formally constituted with all members
- PMO ToR approved
- Project Director appointed

### 13. Steering Committee approves the Terms of Reference for the Technical Advisory Group (TAG), defining its independent authority to challenge engineering decisions, mandatory review gates, and relationship protocols with the neutral third-party engineering consortium

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 10-12

**Key Outputs/Deliverables:**

- Approved TAG Terms of Reference
- TAG independence protocols
- Technical review gate schedule aligned with phase-gates

**Dependencies:**

- Steering Committee formally constituted
- TAG ToR drafted by designated formation lead
- TAG member candidate list developed

### 14. Interim TAG Formation Lead (designated by Project Sponsor with Steering Committee oversight) recruits independent external members with expertise in deep-sea engineering, buoyancy systems, pressurized enclosures, and seismic engineering, and drafts the TAG's technical review scope

**Responsible Body/Role:** Interim TAG Formation Lead (designated by Project Sponsor)

**Suggested Timeframe:** Project Week 5-10 (parallel with other setups)

**Key Outputs/Deliverables:**

- TAG member recruitment completed
- TAG ToR v0.1 drafted
- Technical review scope document
- Conflict-of-interest protocols

**Dependencies:**

- TAG ToR framework approved by Steering Committee
- Candidate profiles for external experts defined
- Budget allocated for TAG operations

### 15. Steering Committee formally appoints the TAG Chair (independent deep-sea structural engineering expert) and confirms all TAG members, establishing the group's operational independence from the project's own engineering teams

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 12-13

**Key Outputs/Deliverables:**

- TAG Chair formally appointed
- Confirmed TAG membership roster
- TAG independence declaration signed
- TAG formally constituted

**Dependencies:**

- TAG ToR approved
- All TAG members recruited and vetted
- TAG member acceptance confirmed

### 16. TAG holds its inaugural kick-off meeting, establishes the technical review schedule aligned with phase-gate milestones, sets up secure data sharing protocols, and defines the relationship with the neutral third-party engineering consortium

**Responsible Body/Role:** Technical Advisory Group (TAG)

**Suggested Timeframe:** Project Week 13-14

**Key Outputs/Deliverables:**

- TAG inaugural meeting minutes
- Technical review schedule
- Data sharing protocols established
- TAG-Consortium relationship framework

**Dependencies:**

- TAG formally constituted
- TAG Chair appointed
- TAG ToR ratified

### 17. Steering Committee approves the Terms of Reference for the Ethics & Compliance Committee, defining its anti-corruption authority, whistleblower mechanisms, procurement audit thresholds, and reporting lines to both sovereign governments

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 12-14

**Key Outputs/Deliverables:**

- Approved Ethics & Compliance Committee ToR
- Whistleblower mechanism framework
- Procurement audit threshold definitions
- Reporting protocols to sovereign governments

**Dependencies:**

- Steering Committee formally constituted
- Ethics Committee ToR drafted by designated formation lead

### 18. Interim Ethics & Compliance Formation Lead (designated by Project Sponsor) drafts the initial Ethics & Compliance Committee ToR, Code of Ethics and Anti-Corruption Policy framework, and whistleblower mechanism specifications

**Responsible Body/Role:** Interim Ethics & Compliance Formation Lead (designated by Project Sponsor)

**Suggested Timeframe:** Project Week 4-8 (parallel with other setups)

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1
- Code of Ethics and Anti-Corruption Policy draft
- Whistleblower mechanism design
- Quarterly audit schedule framework

**Dependencies:**

- Governance Architecture Document approved
- International legal counsel retained
- OECD/FCPA compliance requirements identified

### 19. Steering Committee formally appoints the Ethics & Compliance Committee Chair (independent international anti-corruption expert) and confirms all members, including external auditors and the whistleblower ombudsman

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 14-15

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Chair appointed
- Confirmed membership roster
- Committee formally constituted
- Anti-retaliation protections established

**Dependencies:**

- Ethics & Compliance Committee ToR approved
- All members recruited and vetted
- Independent auditor engagement confirmed

### 20. Ethics & Compliance Committee holds its inaugural kick-off meeting, ratifies the Code of Ethics and Anti-Corruption Policy, activates the whistleblower mechanism, and establishes the quarterly ethics audit schedule

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 15-16

**Key Outputs/Deliverables:**

- Inaugural meeting minutes
- Ratified Code of Ethics and Anti-Corruption Policy
- Active whistleblower mechanism
- Quarterly audit schedule confirmed

**Dependencies:**

- Committee formally constituted
- Chair appointed
- ToR ratified

### 21. Steering Committee approves the Terms of Reference for the Environmental Oversight Board, defining its binding authority to halt construction, environmental threshold parameters, and relationship with the IMO and national environmental agencies

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 14-16

**Key Outputs/Deliverables:**

- Approved Environmental Oversight Board ToR
- Environmental threshold parameters defined
- Binding halt-authority provisions formalized
- IMO coordination protocols established

**Dependencies:**

- Steering Committee formally constituted
- Environmental Oversight Board ToR drafted by designated formation lead

### 22. Interim Environmental Oversight Formation Lead (designated by Project Sponsor) drafts the Environmental Oversight Board ToR, defines environmental threshold parameters for cetacean disturbance and sediment plumes, and establishes the marine mitigation fund oversight framework

**Responsible Body/Role:** Interim Environmental Oversight Formation Lead (designated by Project Sponsor)

**Suggested Timeframe:** Project Week 6-12 (parallel with other setups)

**Key Outputs/Deliverables:**

- Draft Environmental Oversight Board ToR v0.1
- Environmental threshold parameter document
- Marine mitigation fund oversight framework
- Emergency response protocol draft

**Dependencies:**

- Environmental Compliance Strategy defined
- IMO engagement framework established
- Marine ecosystem baseline study plan approved

### 23. Steering Committee formally appoints the Environmental Oversight Board Chair (independent marine ecosystem expert) and confirms all members, including cetacean specialists, oceanographers, and IMO representative

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 16-17

**Key Outputs/Deliverables:**

- Environmental Oversight Board Chair appointed
- Confirmed membership roster
- Board formally constituted
- Binding halt-authority activated

**Dependencies:**

- Environmental Oversight Board ToR approved
- All members recruited and vetted
- IMO representative confirmed

### 24. Environmental Oversight Board holds its inaugural kick-off meeting, establishes real-time monitoring data sharing protocols from acoustic buoys, defines emergency halt procedures, and publishes the first environmental compliance framework

**Responsible Body/Role:** Environmental Oversight Board

**Suggested Timeframe:** Project Week 17-18

**Key Outputs/Deliverables:**

- Inaugural meeting minutes
- Real-time monitoring data sharing protocols
- Emergency halt procedures documented
- Environmental compliance framework published

**Dependencies:**

- Board formally constituted
- Chair appointed
- ToR ratified

### 25. Steering Committee approves the Terms of Reference for the Risk Management Committee, defining its enterprise risk oversight authority, contingency reserve management protocols, and automated escalation trigger linkages to the PMO budget system

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 16-18

**Key Outputs/Deliverables:**

- Approved Risk Management Committee ToR
- Risk appetite statement (approved by Steering Committee)
- Contingency reserve management protocols
- Automated escalation trigger linkages defined

**Dependencies:**

- Steering Committee formally constituted
- Risk Management Committee ToR drafted by designated formation lead
- Risk register framework developed

### 26. Interim Risk Management Formation Lead (designated by Project Sponsor) drafts the Risk Management Committee ToR, establishes the comprehensive enterprise risk register with all 18 identified risks, and defines the Monte Carlo simulation schedule and risk interconnectivity mapping

**Responsible Body/Role:** Interim Risk Management Formation Lead (designated by Project Sponsor)

**Suggested Timeframe:** Project Week 8-14 (parallel with other setups)

**Key Outputs/Deliverables:**

- Draft Risk Management Committee ToR v0.1
- Comprehensive enterprise risk register
- Risk interconnectivity mapping
- Monte Carlo simulation schedule

**Dependencies:**

- Risk assessment and mitigation strategies defined
- PMO budget tracking system initialized
- Financial risk parameters established

### 27. Steering Committee formally appoints the Risk Management Committee Chair (independent enterprise risk management expert) and confirms all members, including specialists for financial, technical, geopolitical, and environmental risk domains

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 18-19

**Key Outputs/Deliverables:**

- Risk Management Committee Chair appointed
- Confirmed membership roster
- Committee formally constituted
- Risk appetite statement ratified

**Dependencies:**

- Risk Management Committee ToR approved
- All members recruited and vetted
- Risk register validated

### 28. Risk Management Committee holds its inaugural kick-off meeting, establishes the automated risk escalation trigger system linked to the PMO budget tracking, and initiates the first comprehensive risk assessment using Monte Carlo simulation

**Responsible Body/Role:** Risk Management Committee

**Suggested Timeframe:** Project Week 19-20

**Key Outputs/Deliverables:**

- Inaugural meeting minutes
- Automated escalation trigger system activated
- First Monte Carlo simulation results
- Risk register distributed to all governance bodies

**Dependencies:**

- Committee formally constituted
- Chair appointed
- ToR ratified
- PMO budget tracking system operational

### 29. All six governance bodies hold a joint inaugural governance summit to align on the Builder's Foundation strategic path, establish cross-body coordination protocols, and formalize the overall governance operational framework

**Responsible Body/Role:** Project Steering Committee (coordinating), all governance bodies

**Suggested Timeframe:** Project Week 20-21

**Key Outputs/Deliverables:**

- Joint governance summit minutes
- Cross-body coordination protocols
- Overall governance operational framework
- Strategic alignment confirmation on Builder's Foundation path

**Dependencies:**

- All six governance bodies formally constituted
- All inaugural kick-off meetings completed
- Steering Committee operational

### 30. Steering Committee reviews and approves the complete governance implementation status, confirms all delegated authority thresholds are operational, and authorizes the PMO to commence full-scale operational activities including construction mobilization preparation

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 22-24

**Key Outputs/Deliverables:**

- Governance implementation completion report
- Approved authority threshold confirmation
- Authorization for construction mobilization
- Operational governance framework certified

**Dependencies:**

- All governance bodies fully operational
- Joint governance summit completed
- All ToRs ratified and implemented
- PMO operational with budget tracking active