## Suggestion 1 - Channel Tunnel (Eurotunnel)

The Channel Tunnel is a 50.45 km railway tunnel linking Folkestone, United Kingdom, with Coquelles, France, beneath the English Channel. It includes three parallel tunnels: two 7.6 m diameter rail tunnels and a 4.8 m diameter service tunnel. The undersea section spans approximately 37.9 km, with the deepest point reaching 75 meters below sea level. Construction commenced in 1988 and the tunnel opened to freight services in 1994 and passenger Eurostar services later that year. The project cost approximately £9.5 billion (roughly €15 billion in current euros), representing one of the largest and most expensive infrastructure undertakings in history. It is operated by Getlink (formerly Groupe Eurotunnel). The tunnel carries high-speed Eurostar passenger trains, Eurotunnel Le Shuttle freight shuttles, and international freight services, transporting over 20 million passengers and millions of tonnes of freight annually.

### Success Metrics

Operational for nearly 30 years with continuous rail service between two sovereign nations
Carries over 20 million passengers and millions of tonnes of freight annually
Reduced cross-Channel travel time from ferry crossings of 90+ minutes to approximately 35 minutes
Enabled direct high-speed rail connectivity between the UK and continental Europe
Generated cumulative revenues exceeding €20 billion since opening
Achieved structural integrity across 37.9 km of undersea tunnel for nearly three decades

### Risks and Challenges Faced

Massive cost overruns: Original estimates of £5.5 billion escalated to £9.5 billion due to geological surprises including unexpected water inflows and unstable chalk marl conditions, requiring revised tunnel boring machine specifications and grouting operations
Cross-border governance complexity: Required unprecedented bilateral treaty frameworks between the UK and France covering safety standards, customs arrangements, immigration controls, and operational jurisdiction, negotiated over several years before construction could begin
Financial restructuring: The project nearly collapsed financially in the early 2000s, requiring multiple debt restructurings and equity injections; the company entered administration in 2006 before emerging as Getlink
Geological and hydrological risks: Unexpected water inflows from the chalk aquifer delayed construction by months and required extensive grouting and waterproofing interventions at depth
Safety incidents: A fire in the service tunnel in 1996 and a lorry fire in a shuttle in 2006 highlighted the risks of a submerged rail tunnel carrying hazardous cargo, leading to enhanced safety protocols
Environmental opposition: Marine ecosystem concerns regarding the impact of tunnel construction on the seabed and marine life required extensive environmental impact assessments and mitigation measures

### Where to Find More Information

Official website: https://www.getlink.com/en/channel-tunnel
UK National Archives - Channel Tunnel documentation: https://webarchive.nationalarchives.gov.uk/ukgwa/20121205150424/http://www.nationalarchives.gov.uk/PRONOM/channel-tunnel.htm
European Commission - Trans-European Transport Networks: https://transport.ec.europa.eu/topics/trans-european-transport-networks_en
Wikipedia - Channel Tunnel: https://en.wikipedia.org/wiki/Channel_Tunnel
Academic paper: 'The Channel Tunnel: Lessons Learned' - Institution of Civil Engineers publications

### Actionable Steps

Contact Getlink Investor Relations and Corporate Strategy teams via https://www.getlink.com/en/contact to request detailed post-construction performance data, financial restructuring history, and lessons learned documentation
Reach out to the UK Department for Transport (DfT) Cross-Border Infrastructure Division at dft.crossborder@transport.gov.uk for bilateral governance framework documentation and treaty templates
Contact the International Chamber of Commerce (ICC) International Court of Arbitration in Paris (arbitration@iccwbo.org) for dispute resolution case studies related to the Channel Tunnel's financial restructuring
Engage with the Institution of Civil Engineers (ICE) at publications@ice.org.uk for technical case studies on undersea tunnel construction methodology, waterproofing systems, and geological risk management
Contact Eurostar Group at press@eurostar.com for operational data on high-speed rail performance through the tunnel, including passenger volumes, punctuality metrics, and safety records

### Rationale for Suggestion

The Channel Tunnel is the most directly comparable reference project for the Spain-Morocco transoceanic submerged tunnel. It shares the critical characteristics of being a cross-border, undersea, rail-based tunnel connecting two sovereign nations at significant depth (75m below sea level). The project faced nearly identical challenges: massive cost overruns from geological uncertainty, complex cross-border governance requiring bilateral treaties, financial restructuring risks, and environmental permitting across jurisdictions. The Channel Tunnel's 30-year operational history provides invaluable data on long-term structural integrity, maintenance requirements, and operational performance of a submerged rail tunnel. Its cost escalation from £5.5 billion to £9.5 billion (a 73% overrun) directly parallels the financial risks facing the €40 billion project. The bilateral governance framework negotiated between the UK and France provides a template for the Spain-Morocco governance structure, including the need for pre-negotiated framework agreements, shared operational authority, and dispute resolution mechanisms. The project's financial restructuring history offers critical lessons on funding continuity, investor confidence management, and the risks of tranche-based financing.
## Suggestion 2 - Seikan Tunnel

The Seikan Tunnel is a 53.85 km railway tunnel connecting Honshu and Hokkaido, Japan's two main islands, beneath the Tsugaru Strait. It holds the distinction of being the world's longest undersea tunnel section, with 23.3 km of its total length running beneath the seabed at a depth of approximately 240 meters below sea level. Construction began in 1971 and the tunnel opened for conventional rail services in 1988, with the Hokkaido Shinkansen high-speed rail service commencing in 2016. The project cost approximately ¥700 billion (roughly €5-6 billion in current euros). The tunnel was constructed using a combination of tunnel boring machines and drill-and-blast methods through extremely challenging geological conditions including volcanic rock, fault zones, and methane gas deposits. It is operated by JR Hokkaido and JR East. The tunnel was designed to withstand earthquakes, tsunamis, and extreme weather conditions, incorporating seismic joints and advanced monitoring systems.

### Success Metrics

World's longest undersea tunnel section (23.3 km), a record held since 1988
Operational for over 35 years, enabling direct Shinkansen high-speed rail service to Hokkaido
Withstood multiple significant seismic events including the 2011 Tohoku earthquake (M9.0) without structural failure
Reduced travel time between Tokyo and Hokkaido by approximately 1 hour compared to previous rail routes
Successfully integrated with Japan's national Shinkansen high-speed rail network
Demonstrated the feasibility of deep undersea rail construction in one of the world's most seismically active regions

### Risks and Challenges Faced

Extreme geological conditions: Construction encountered unexpected methane gas deposits that caused explosions in 1985, killing 33 workers and halting construction for over a year, requiring complete redesign of ventilation and gas monitoring systems
Seismic risk: Located near multiple active fault zones, the tunnel required extensive seismic reinforcement including flexible joints and shock-absorbing structures, adding significant cost and complexity
Massive cost overruns: Original estimates of ¥200 billion escalated to ¥700 billion due to geological surprises, safety upgrades after the 1985 explosion, and extended construction timelines
Technical challenges at depth: Operating at 240m below sea level required pioneering deep-sea construction techniques, including advanced waterproofing, pressure management, and ventilation systems that had no precedent
Workforce safety: The 1985 methane explosion highlighted the extreme dangers of deep undersea construction, leading to comprehensive safety protocol reforms across the global tunneling industry
Long construction timeline: 17 years from start to opening (1971-1988) demonstrated the difficulty of predicting and managing timelines for unprecedented deep-sea infrastructure projects

### Where to Find More Information

Official website (JR Hokkaido): https://www.jrhokkaido.co.jp/english/
Japan Railway & Transport Review: https://www.jrtreview.com/
Wikipedia - Seikan Tunnel: https://en.wikipedia.org/wiki/Seikan_Tunnel
Japan Ministry of Land, Infrastructure, Transport and Tourism (MLIT): https://www.mlit.go.jp/english/
Academic papers on Seikan Tunnel construction methodology available through the Japan Society of Civil Engineers (JSCE): https://www.jsce.jp/

### Actionable Steps

Contact JR Hokkaido Corporate Planning Division at jrhq@jrhokkaido.co.jp for operational data, maintenance records, and seismic performance documentation from the Seikan Tunnel
Reach out to the Japan Society of Civil Engineers (JSCE) at info@jsce.jp for technical papers on deep undersea tunnel construction, methane gas management, and seismic reinforcement techniques
Contact the Japan Ministry of Land, Infrastructure, Transport and Tourism (MLIT) at global@mlit.go.jp for regulatory frameworks governing deep-sea construction, safety standards, and cross-island infrastructure governance
Engage with the International Tunnelling and Underground Space Association (ITA-AITES) at ita@aides.org for case study databases on undersea tunnel construction, risk management, and long-term operational performance
Contact the Geotechnical Engineering Society of Japan (GESJ) at gesj@gesj.org for detailed geotechnical data on the Tsugaru Strait seabed conditions, drilling methodologies, and fault zone navigation

### Rationale for Suggestion

The Seikan Tunnel is the most relevant reference for the depth and undersea rail challenges of the Spain-Morocco project. At 240 meters below sea level, it is the deepest operational undersea rail tunnel in the world, directly paralleling the 100-meter depth requirement of the Gibraltar tunnel. The Seikan Tunnel's experience with seismic risk is particularly valuable, as the Strait of Gibraltar sits near the Azores-Gibraltar seismic transform fault zone, one of Europe's most active seismic regions. The tunnel's survival of the 2011 M9.0 Tohoku earthquake provides critical validation data for deep-sea tunnel seismic resilience. The methane explosion disaster of 1985 offers a cautionary tale about geological hazards at depth and the necessity of comprehensive pre-construction geotechnical surveys. The Seikan Tunnel's 17-year construction timeline demonstrates the reality of extended megaproject durations for unprecedented undersea infrastructure, directly informing the 20-year timeline assumption. The tunnel's integration with the Shinkansen high-speed rail network provides a model for how the Gibraltar tunnel could integrate with both Spanish and Moroccan high-speed rail systems. The project's experience with methane gas management, deep-sea waterproofing, and seismic joint design are directly transferable technical lessons.
## Suggestion 3 - Marmaray Submerged Tube Tunnel (Istanbul, Turkey)

The Marmaray Tunnel is a submerged tube railway tunnel running beneath the Bosphorus strait in Istanbul, Turkey, connecting the European and Asian continents by rail. It is part of the larger Marmaray commuter rail project, which spans 76 km from Halkalı (European side) to Gebze (Asian side). The tunnel section is 13.6 km in total length, with 1.4 km running beneath the Bosphorus strait at a depth of approximately 60 meters below sea level. Construction began in 2004 and the tunnel opened to service in 2013. The project cost approximately $4.5 billion (roughly €4 billion). The tunnel was constructed using immersed tube method, where pre-fabricated tunnel segments were sunk into a dredged trench on the seabed and connected. The project was led by a Turkish-Japanese consortium and is operated by Turkish State Railways (TCDD). The Marmaray Tunnel represents the first direct rail connection between Europe and Asia beneath the Bosphorus, carrying over 1 million passengers daily.

### Success Metrics

First direct rail connection between Europe and Asia beneath the Bosphorus strait
Carries over 1 million passengers daily, exceeding initial ridership projections
Reduced cross-Bosphorus commute times from 90+ minutes by bridge to approximately 15 minutes by rail
Successfully integrated with Istanbul's existing rail network and national high-speed rail plans
Operational since 2013 with consistent service and no major structural incidents
Demonstrated the feasibility of immersed tube tunnel construction beneath a major international strait

### Risks and Challenges Faced

Archaeological discoveries: Construction uncovered extensive Byzantine-era artifacts including a 9th-century harbor, medieval walls, and thousands of historical objects, requiring years of archaeological excavation and causing significant construction delays
Geological complexity: The Bosphorus seabed consists of complex sedimentary layers with varying hardness and water permeability, requiring extensive ground improvement and waterproofing measures
Seismic risk: Istanbul sits near the North Anatolian Fault, one of the world's most dangerous fault lines, requiring the tunnel to be designed for extreme seismic events including potential fault rupture
Cross-Bosphorus construction challenges: Building a tunnel beneath one of the world's busiest waterways, with over 100,000 vessel transits annually, required sophisticated marine traffic management and collision prevention systems
Cost escalation: Original estimates of $2.5 billion escalated to $4.5 billion due to archaeological delays, geological surprises, and infrastructure upgrades required for the connecting rail lines
Political and regulatory complexity: The project required coordination between multiple Turkish government agencies, Istanbul Metropolitan Municipality, and international financing institutions

### Where to Find More Information

Official website (TCDD - Turkish State Railways): https://www.tcddtasimacilik.gov.tr/
Istanbul Metropolitan Municipality: https://www.ibb.gov.tr/
Wikipedia - Marmaray: https://en.wikipedia.org/wiki/Marmaray
World Bank - Turkey Infrastructure Projects: https://www.worldbank.org/en/country/turkey/overview
Academic papers on immersed tube tunnel construction available through the Turkish Chamber of Civil Engineers (TMMOB): https://www.tmmob.org.tr/

### Actionable Steps

Contact TCDD (Turkish State Railways) Infrastructure Department at infra@tcddtasimacilik.gov.tr for operational data, maintenance records, and immersed tube construction methodology documentation
Reach out to the Istanbul Metropolitan Municipality Urban Projects Directorate at iletisim@ibb.gov.tr for regulatory frameworks, archaeological management protocols, and cross-strait construction permits
Contact the World Bank Infrastructure and Urban Development Division for project financing structures, risk assessment reports, and post-completion evaluation data
Engage with the International Tunnelling and Underground Space Association (ITA-AITES) at ita@aides.org for case studies on immersed tube tunnel construction beneath active waterways
Contact the Turkish Chamber of Civil Engineers (TMMOB) at info@tmmob.org.tr for technical standards, geological data, and construction methodology guidelines for underwater tunnel projects

### Rationale for Suggestion

The Marmaray Tunnel is the closest analog to the Spain-Morocco project in terms of being a submerged rail tunnel beneath an international strait connecting two continents. While the Marmaray uses immersed tube construction rather than pillar-supported buoyant tunnels, it shares the fundamental challenge of constructing a rail tunnel beneath a major international waterway at significant depth. The archaeological discovery challenge during Marmaray construction directly parallels the environmental and geological uncertainty risks facing the Gibraltar project, demonstrating that even extensive pre-construction surveys cannot fully anticipate subsurface conditions. The Marmaray's experience with seismic risk near the North Anatolian Fault provides a direct analogy to the Azores-Gibraltar seismic zone risk. The project's cost escalation from $2.5 billion to $4.5 billion (an 80% overrun) due to archaeological and geological surprises offers a critical financial risk benchmark. The immersed tube construction method, where pre-fabricated segments are placed on the seabed, shares conceptual similarities with the buoyant concrete tunnel segment approach planned for Gibraltar. The Marmaray's daily ridership of over 1 million passengers validates the demand potential for cross-continental rail connections through submerged tunnels.
## Suggestion 4 - Gotthard Base Tunnel (Switzerland)

The Gotthard Base Tunnel is a 57.1 km railway tunnel through the Swiss Alps, holding the distinction of being the world's longest railway tunnel since its opening in 2016. The tunnel reaches a maximum depth of 2,300 meters below the mountain surface, making it the deepest railway tunnel in the world. Construction began in 1999 and the tunnel opened in 2016 after 17 years of construction. The project cost approximately CHF 12.2 billion (roughly €12 billion). The tunnel was constructed using tunnel boring machines through complex geological conditions including granite, gneiss, and fault zones. It is operated by SBB CFF FFS (Swiss Federal Railways). The tunnel connects northern Switzerland (near Zurich) with southern Switzerland (near Lugano), reducing travel time across the Alps from approximately 1 hour to 20 minutes.

### Success Metrics

World's longest railway tunnel (57.1 km), a record that may stand for decades
Operational since 2016 with over 25,000 daily passengers
Reduced cross-Alpine travel time by approximately 75%, transforming Swiss transportation
Constructed with exceptional precision, with the two boring ends meeting within 2 cm of alignment
Achieved world-class safety standards with advanced ventilation and emergency response systems
Generated significant economic benefits for Swiss logistics and tourism sectors

### Risks and Challenges Faced

Extreme geological conditions: Construction encountered unexpected rock types, high water inflows, and fault zones that required revised tunnel boring machine specifications and additional ground reinforcement
Massive cost management: Despite being one of the best-managed megaprojects, costs still reached CHF 12.2 billion, requiring strict cost controls and contingency management throughout the 17-year construction period
Long construction timeline: 17 years from start to opening demonstrated the inherent difficulty of predicting timelines for unprecedented tunnel projects
Workforce management: Coordinating thousands of workers across multiple construction sites over 17 years required sophisticated workforce planning and retention strategies
Environmental permitting: Construction required extensive environmental impact assessments and mitigation measures for alpine ecosystems, water resources, and noise pollution
Technical complexity: The extreme depth (2,300m) created challenges with temperature, pressure, ventilation, and logistics that required pioneering engineering solutions

### Where to Find More Information

Official website (SBB CFF FFS): https://www.sbb.ch/en/the-sbb/about-us/projects/gotthard-base-tunnel.html
Swiss Federal Office of Transport (BAV): https://www.bav.admin.ch/bav/en/home.html
Wikipedia - Gotthard Base Tunnel: https://en.wikipedia.org/wiki/Gotthard_Base_Tunnel
Academic papers available through the Swiss Society of Engineers (SIA): https://www.sia.ch/

### Actionable Steps

Contact SBB CFF FFS Project Management at gotthard@sbb.ch for operational data, construction methodology documentation, and long-term maintenance records
Reach out to the Swiss Federal Office of Transport (BAV) at info@bav.admin.ch for regulatory frameworks governing mega-tunnel construction, cost management strategies, and timeline management
Contact the Swiss Society of Engineers (SIA) at info@sia.ch for technical papers on deep tunnel construction, geological risk management, and precision engineering at extreme depths
Engage with the International Tunnelling and Underground Space Association (ITA-AITES) at ita@aides.org for case studies on the world's longest railway tunnel construction and management

### Rationale for Suggestion

The Gotthard Base Tunnel serves as a secondary reference for the massive scale, long construction timeline, and precision engineering challenges of the Spain-Morocco project. While it is a terrestrial rather than submerged tunnel, its 57.1 km length and 17-year construction timeline provide a benchmark for managing a €40 billion megaproject over a comparable duration. The Gotthard's exceptional precision engineering—achieving alignment within 2 cm across 57 km—demonstrates the level of technical precision required for the Gibraltar tunnel's 14 km span at 100m depth. The project's cost management approach, which maintained relatively tight cost controls over a 17-year period despite geological surprises, offers a model for the €40 billion budget management. The Gotthard's workforce management strategies over a 17-year construction period provide insights into the offshore workforce resilience challenges facing the Gibraltar project. The tunnel's advanced ventilation and emergency response systems at extreme depth offer relevant precedents for the pressurized rail corridor safety systems required at 100m depth.
## Suggestion 5 - Øresund Fixed Link (Denmark-Sweden)

The Øresund Fixed Link is a combined bridge and tunnel infrastructure connecting Denmark and Sweden across the Øresund strait. Opened in 2000, the total link spans 16 km, comprising the Øresund Bridge (7.8 km) and the Drogden Tunnel (4.05 km), with an artificial island (Peberholm) serving as the transition point. The Drogden Tunnel is a 40-meter-wide, four-lane immersed tube tunnel carrying the Øresund Line railway and a four-lane motorway. The project cost approximately DKK 30 billion (roughly €4 billion). Construction began in 1995 and the link opened in 2000. The project was a joint venture between the Danish and Swedish governments, with construction led by a consortium including Skanska, Hochtief, and others. The link carries over 20 million vehicle crossings and millions of rail passengers annually, serving as a major transport artery between Scandinavia and continental Europe.

### Success Metrics

First fixed link between Denmark and Sweden, transforming regional transportation and economic integration
Carries over 20 million vehicle crossings and millions of rail passengers annually
Reduced travel time between Copenhagen and Malmö from 55 minutes by ferry to approximately 35 minutes by train
Successfully integrated Scandinavian and continental European transport networks
Operational since 2000 with consistent service and no major structural incidents
Generated significant economic benefits including the development of the Öresund Region as a unified economic zone

### Risks and Challenges Faced

Cross-border governance complexity: Required unprecedented bilateral cooperation between Denmark and Sweden on design standards, safety regulations, toll collection, and operational management, negotiated through the Øresund Consortium Agreement
Environmental concerns: Construction of the artificial island Peberholm and the tunnel trench caused significant marine ecosystem disturbance, requiring extensive environmental mitigation and monitoring
Cost management: The project was completed on budget but required careful management of the dual-purpose design (rail and road) and the complex interface between bridge and tunnel sections
Geological challenges: The Øresund seabed consists of glacial deposits and bedrock requiring specialized foundation and trench preparation techniques
Political coordination: The project required sustained political commitment across multiple government terms in both countries, with changes in government potentially threatening funding and support
Integration challenges: Coordinating the bridge-tunnel transition on the artificial island required precise engineering and construction sequencing

### Where to Find More Information

Official website (Øresundsbro Konsortiet): https://www.oresundsbrokonsortiet.se/
Wikipedia - Øresund Fixed Link: https://en.wikipedia.org/wiki/%C3%96resund_Fixed_Link
Swedish Transport Administration (Trafikanalys): https://www.trafikanalys.se/en/
Danish Road Directorate (Vejdirektoratet): https://www.vejdirektoratet.dk/
Academic papers on cross-border infrastructure governance available through the Nordic Centre for Spatial Development (NORDREGIO): https://nordregio.org/

### Actionable Steps

Contact Øresundsbro Konsortiet at info@oresundsbrokonsortiet.se for operational data, governance framework documentation, and cross-border management protocols
Reach out to Swedish Transport Administration (Trafikanalys) at info@trafikanalys.se for regulatory frameworks governing cross-border infrastructure, toll management, and operational standards
Contact Danish Road Directorate (Vejdirektoratet) at info@vejdirektoratet.dk for bilateral agreement templates, environmental compliance frameworks, and infrastructure maintenance standards
Engage with NORDREGIO at info@nordregio.org for research on cross-border infrastructure governance, economic integration impacts, and regional development strategies
Contact Skanska Infrastructure Development at info@skanska.com for construction methodology documentation, consortium management practices, and project delivery lessons

### Rationale for Suggestion

The Øresund Fixed Link serves as a secondary reference for the cross-border governance and dual-mode infrastructure challenges of the Spain-Morocco project. While it is a bridge-tunnel combination rather than a purely submerged tunnel, it shares the critical characteristic of being a cross-border infrastructure project connecting two sovereign nations across an international strait. The Øresund Consortium Agreement, which established joint governance between Denmark and Sweden, provides a direct template for the bilateral governance framework required between Spain and Morocco. The project's experience with environmental mitigation during construction, including the creation of the artificial island Peberholm as an environmental buffer, parallels the environmental integration strategies planned for the Gibraltar tunnel. The dual-mode design (rail and road) offers insights into the multi-modal infrastructure challenges that the Gibraltar tunnel must address, particularly the integration of high-speed rail with existing surface networks. The project's sustained political commitment across multiple government terms in both countries demonstrates the importance of embedding the project in binding international treaties, a key recommendation for the Gibraltar project. The Øresund link's economic integration impact, transforming the Copenhagen-Malmö region into a unified economic zone, provides a compelling model for the economic benefits the Gibraltar tunnel could deliver to the Spain-Morocco corridor.

## Summary

The Spain-Morocco transoceanic submerged tunnel project at 100m depth across the Strait of Gibraltar is unprecedented in scale, depth, and cross-border complexity. Five real-world reference projects have been identified: (1) The Channel Tunnel (Eurotunnel) is the most directly comparable, being a cross-border undersea rail tunnel connecting two sovereign nations, with a 30-year operational history providing invaluable data on structural integrity, cost escalation (73% overrun), financial restructuring, and bilateral governance frameworks. (2) The Seikan Tunnel is the world's deepest operational undersea rail tunnel at 240m depth, providing critical precedent for seismic resilience, geological hazard management (including the 1985 methane explosion), and long construction timelines (17 years). (3) The Marmaray Tunnel is the closest analog for submerged rail tunnel construction beneath an international strait connecting two continents, with lessons on archaeological/geological surprises (80% cost overrun), immersed tube construction methodology, and seismic risk near the North Anatolian Fault. (4) The Gotthard Base Tunnel provides a benchmark for massive-scale tunnel construction (57.1 km, 17 years) with exceptional precision engineering and cost management. (5) The Øresund Fixed Link offers a model for cross-border governance between two sovereign nations, dual-mode infrastructure integration, and sustained political commitment across government terms. Collectively, these references provide actionable guidance on cost management, geological risk mitigation, cross-border governance frameworks, environmental compliance, workforce management, and long-term operational sustainability for the €40 billion Gibraltar tunnel project.