**Primary domain:** Marine Engineering

**Secondary domains:** Transportation Engineering, Structural Engineering, Geotechnical Engineering

**Rationale:** Marine Engineering is the primary discipline because the project's core success criterion — constructing a submerged tunnel at 100 meters below sea level across the Strait of Gibraltar — is fundamentally a marine environment construction challenge. Transportation Engineering, while relevant for the high-speed rail component, addresses a subordinate aspect of the system rather than the overarching marine construction problem that defines the project.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Marine Engineering | 5 | 5 | outcome | The submerged tunnel at 100m below sea level between Spain and Morocco is fundamentally a marine environment construction challenge. |
| Geotechnical Engineering | 5 | 5 | method | Pillar anchoring at 100m depth into the Strait of Gibraltar seabed requires deep understanding of subsurface geology, soil mechanics, and foundation design. |
| Offshore Engineering | 5 | 5 | method | Buoyant concrete tunnels anchored at controlled depth are offshore structures requiring specialized offshore design, installation, and mooring techniques. |
| Materials Engineering | 4 | 5 | method | Buoyant concrete and specialized marine-grade materials are core to the tunnel's construction and long-term submersion durability. |
| Transportation Engineering | 4 | 4 | outcome | The tunnel is specifically engineered for high-speed rail traffic, making rail systems design central to the project. |
| Structural Engineering | 4 | 4 | method | Buoyant concrete tunnel design and pillar-supported anchoring require specialized structural analysis and design expertise. |
| Coastal Engineering | 4 | 4 | method | Coastal hydrodynamics, wave forces, and sediment transport directly affect the pillar-supported structure and shoreline connection points. |
| Naval Architecture | 4 | 4 | method | The buoyant submerged tunnels require naval architectural principles for stability, buoyancy control, and mooring system design at 100m depth. |
| Environmental Engineering | 4 | 3 | constraint | A transoceanic tunnel crossing international waters demands extensive environmental impact assessments and marine ecosystem compliance. |