## Primary Decisions
The vital few decisions that have the most impact.


The five vital levers—Pillar Architecture, Construction Deployment, and Cross-Border Governance as Critical, and Phasing and Risk Strategy and Environmental Compliance Strategy as High—address the fundamental tensions of this transoceanic tunnel project: structural integrity versus seabed disturbance (Pillar Architecture), speed versus cost containment (Phasing), national sovereignty versus project efficiency (Cross-Border Governance), and regulatory approval versus construction velocity (Environmental Compliance). These levers collectively govern whether the project can proceed at all, how fast it can be built, and whether it remains politically and legally viable over its 20-year horizon. The remaining nine Medium-rated levers are important operational and engineering enablers but are largely downstream consequences of these five strategic choices.

### Decision 1: Pillar Architecture
**Lever ID:** `67dbe525-04b7-4874-998e-f333c57dc322`

**The Core Decision:** Pillar Architecture defines the foundational structural system that supports the entire submerged tunnel at 100 meters below sea level across the Strait of Gibraltar. It determines how loads distribute across the seabed, how the structure resists lateral ocean current forces, and the degree of seabed disturbance during installation. The chosen pillar type cascades into material specifications, construction methodology, and long-term maintenance schedules, making it one of the earliest and most consequential architectural decisions for the project.

**Why It Matters:** The pillar-supported design determines load distribution across the Strait of Gibraltar seabed and dictates the maximum tolerable ocean current forces; changing this architecture cascades into material requirements, construction methodology, and long-term maintenance schedules. The choice of pillar type also governs how much seabed disturbance occurs during installation, which directly affects environmental permitting timelines.

**Strategic Choices:**

1. Deploy tension-leg pillar foundations drilled into bedrock to minimize seabed disturbance and maximize lateral stability against Gibraltar Strait currents.
2. Construct gravity-based pillar structures that rely on their own mass and seabed friction, accepting higher sediment displacement during installation.
3. Implement a hybrid floating-pillar system where buoyant tunnel segments are partially supported by vertical members and partially by hydrodynamic lift, reducing seabed penetration depth.

**Trade-Off / Risk:** Switching from gravity-based to tension-leg pillars reduces seabed disturbance but requires precision drilling at 100m depth where rig stability is compromised by wave-induced motion, increasing installation failure risk.

**Strategic Connections:**

**Synergy:** Pillar Architecture directly enables Geotechnical Anchoring Methodology, as the pillar type must interface with the anchoring system to achieve stable seabed penetration. It also amplifies Hydrodynamic Load Mitigation, since pillar geometry and spacing are the primary mechanism for resisting Gibraltar Strait currents.

**Conflict:** Pillar Architecture constrains Environmental Compliance Strategy because gravity-based pillars cause significant sediment displacement that complicates marine habitat permitting. It also trades off against Construction Deployment, as tension-leg pillars require precision drilling at depth where wave motion increases installation failure risk.

**Justification:** *Critical*, Pillar Architecture is the central structural hub connecting geotechnical anchoring, hydrodynamic load mitigation, environmental compliance, rail integration, buoyancy engineering, and subsea surveillance. Its choice cascades into material specifications, construction methodology, permitting timelines, and maintenance schedules, making it the foundational architectural decision from which all other levers derive constraints.

### Decision 2: Construction Deployment
**Lever ID:** `5dba75a3-15fc-4437-84ff-6297bb16cd18`

**The Core Decision:** Construction Deployment defines the end-to-end methodology for fabricating, transporting, and installing tunnel segments at 100-meter depth in open ocean conditions. It determines the overall project timeline, required offshore fabrication capacity, weather window dependencies, and whether construction can proceed continuously or is subject to seasonal interruption. A single misstep in segment placement can compromise the entire tunnel alignment, making this lever critical to schedule integrity.

**Why It Matters:** The deployment method determines the construction timeline, the required offshore fabrication capacity, and the weather windows available for installation; a single misstep in segment placement at 100m depth can compromise the entire tunnel alignment. The choice also affects whether construction can proceed continuously or is subject to seasonal interruption.

**Strategic Choices:**

1. Fabricate all tunnel segments in dry-dock facilities along the Spanish and Moroccan coasts, then tow and submerge them into prepared pillar positions during optimized weather windows.
2. Construct tunnel segments using offshore floating platforms positioned directly above the installation sites, eliminating long-distance towing but requiring permanent offshore construction infrastructure.
3. Deploy a modular prefabrication strategy where short tunnel sections are assembled on-site using robotic underwater welding and positioning systems, enabling continuous progress regardless of surface weather.

**Trade-Off / Risk:** Offshore construction platforms eliminate towing risks but require years of permitting and infrastructure setup before the first segment can be placed, compressing the already tight installation schedule.

**Strategic Connections:**

**Synergy:** Construction Deployment amplifies Subsea Logistics and Supply Chain because the deployment method dictates material delivery schedules, staging areas, and transport routes across international waters. It also enables Offshore Workforce Resilience, as the deployment approach determines the sustained personnel presence and living infrastructure required on-site.

**Conflict:** Construction Deployment constrains Phasing and Risk Strategy because the deployment method locks in certain phasing constraints and weather dependencies that limit schedule flexibility. It also conflicts with Environmental Compliance Strategy, as deployment activities cause marine disturbance that must be mitigated within permitting boundaries.

**Justification:** *Critical*, Construction Deployment is the operational execution hub that gates all on-site activities. It directly amplifies logistics and workforce resilience, constrains phasing and environmental compliance, and is itself constrained by buoyancy and corrosion requirements. A single misstep in segment placement compromises the entire tunnel alignment.

### Decision 3: Cross-Border Governance
**Lever ID:** `5c9b4b1e-0aab-4449-b206-bcac50c27696`

**The Core Decision:** Cross-Border Governance establishes the political, administrative, and legal framework for managing a €40 billion infrastructure project spanning two sovereign nations. It determines permitting timelines, funding allocation mechanisms, dispute resolution pathways, and decision-making authority between Spain and Morocco. Governance misalignment at the project midpoint—where both jurisdictions must simultaneously contribute resources—can stall the entire initiative and undermine investor confidence.

**Why It Matters:** The governance structure determines permitting timelines, funding allocation mechanisms, and dispute resolution pathways; a misalignment between Spain and Morocco's priorities can stall construction at the midpoint where both jurisdictions must simultaneously contribute resources. Governance choice also affects investor confidence and the willingness of international lenders to commit capital.

**Strategic Choices:**

1. Establish a bilateral treaty organization with equal voting power, joint capital contribution, and shared operational authority modeled on cross-border pipeline agreements.
2. Create an international consortium led by a neutral third-party engineering firm that holds technical decision-making authority while both governments retain financial oversight.
3. Structure the project as a build-own-transfer arrangement where a private multinational consortium finances construction in exchange for long-term operational toll rights before transferring to both governments.

**Trade-Off / Risk:** A private consortium model accelerates funding and construction speed but transfers long-term revenue to external shareholders, potentially creating political backlash when public infrastructure profits flow abroad.

**Strategic Connections:**

**Synergy:** Cross-Border Governance enables International Consortium Financing, as the governance structure directly affects lender confidence and the willingness of international capital to commit. It also amplifies Environmental Compliance Strategy, since a unified transboundary governance framework can streamline environmental approvals that would otherwise face duplicative national reviews.

**Conflict:** Cross-Border Governance conflicts with Phasing and Risk Strategy because governance delays and diplomatic disagreements cascade into schedule risks that are difficult to recover. It also trades off against Construction Deployment, as governance decisions on jurisdiction and permitting must be resolved before deployment activities can commence.

**Justification:** *Critical*, Cross-Border Governance is the political and administrative gatekeeper for a €40 billion project spanning two sovereign nations. It enables international financing, amplifies environmental compliance, and conflicts with phasing and deployment. Governance misalignment at the midpoint can stall the entire initiative regardless of engineering soundness.

### Decision 4: Environmental Compliance Strategy
**Lever ID:** `55d29a38-5b46-4ee4-8a8c-dac3a6d1ea00`

**The Core Decision:** Environmental Compliance Strategy manages the regulatory, ecological, and permitting requirements for constructing a transoceanic tunnel crossing international waters and sensitive marine ecosystems in the Strait of Gibraltar. It determines mitigation approaches, ongoing operational monitoring requirements, and the project's legal vulnerability to challenges from environmental organizations or coastal communities. Permitting delays from this lever can add years to the overall timeline.

**Why It Matters:** Environmental permitting for a transoceanic tunnel crossing international waters and sensitive marine ecosystems can add years to the timeline; the mitigation approach chosen directly affects construction methodology restrictions and ongoing operational monitoring requirements. The strategy also determines whether the project faces legal challenges from environmental organizations or coastal communities.

**Strategic Choices:**

1. Conduct a proactive ecosystem restoration program that exceeds compliance requirements, creating artificial reef structures along the tunnel corridor to offset marine habitat disruption.
2. Design the tunnel alignment to minimize seabed contact area using elevated pillar configurations that preserve benthic habitats underneath while accepting higher structural costs.
3. Negotiate a transboundary environmental impact assessment through the International Maritime Organization, establishing a unified regulatory framework that replaces duplicative national review processes.

**Trade-Off / Risk:** A unified IMO framework eliminates duplicative reviews but requires consensus among multiple sovereign nations with competing maritime interests, and the negotiation timeline alone could exceed five years.

**Strategic Connections:**

**Synergy:** Environmental Compliance Strategy synergizes with Pillar Architecture because the environmental mitigation approach directly influences pillar type selection—elevated or tension-leg pillars minimize seabed disturbance and ease permitting. It also amplifies Cross-Border Governance, as a unified transboundary environmental framework requires coordinated diplomatic effort between Spain and Morocco.

**Conflict:** Environmental Compliance Strategy constrains Construction Deployment because environmental restrictions limit deployment methods, timing, and geographic zones where work can proceed. It also trades off against Pillar Architecture, as gravity-based pillars that maximize structural simplicity cause the seabed disturbance that environmental permitting seeks to avoid.

**Justification:** *High*, Environmental Compliance Strategy governs permitting timelines that can add years to the project and determines legal vulnerability to challenges. It synergizes with pillar architecture and cross-border governance but constrains construction deployment and trades off against gravity-based pillar simplicity, making it a major regulatory gate.

### Decision 5: Phasing and Risk Strategy
**Lever ID:** `5fe21aa9-baba-4a09-b014-83248564e8c1`

**The Core Decision:** This lever determines the temporal architecture of the entire 20-year construction program, deciding whether to build sequentially, in parallel from both coasts, or by functional subsystem. It governs when economic returns begin, how construction risk is distributed across time, and whether early segments can serve as validated proof-of-concept for later phases. Success is measured by balancing timeline compression against cost containment and political sustainability.

**Why It Matters:** The phasing approach determines when the project begins generating economic returns, how construction risk is distributed across time, and whether early segments can serve as proof-of-concept for later phases. Phasing also affects the political sustainability of the project, as delays or cost overruns in early phases can erode public support before completion.

**Strategic Choices:**

1. Construct a single pilot tunnel segment spanning several kilometers as a proof-of-concept, validating all engineering assumptions before committing to the full transoceanic span.
2. Build the tunnel in simultaneous parallel sections from both the Spanish and Moroccan coasts, meeting at a central construction node to compress the overall timeline.
3. Phase construction by functional subsystem — first deploying pillars and buoyancy systems, then installing rail infrastructure, then completing sealing and pressurization — to enable early-stage testing and course correction.

**Trade-Off / Risk:** Parallel construction from both coasts halves the timeline but doubles the required workforce and fabrication capacity simultaneously, creating resource competition that can inflate costs beyond the €40 billion envelope.

**Strategic Connections:**

**Synergy:** Phasing and Risk Strategy enables Construction Deployment by defining the sequencing and scheduling logic that governs all on-site building activities. It also reinforces International Consortium Financing, as phased milestones create natural disbursement checkpoints that maintain investor confidence and unlock successive funding tranches.

**Conflict:** Phasing and Risk Strategy constrains Subsea Logistics and Supply Chain because parallel construction from both coasts doubles simultaneous material demands, overwhelming centralized procurement models. It also conflicts with Offshore Workforce Resilience, as compressed timelines require larger concurrent workforces, intensifying accommodation, transportation, and crew rotation challenges in remote offshore environments.

**Justification:** *High*, Phasing and Risk Strategy determines the temporal architecture of the entire 20-year program, governing when economic returns begin and how construction risk is distributed. It enables construction deployment and reinforces financing but constrains logistics and workforce resilience, representing the fundamental speed-versus-cost trade-off.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Buoyancy Engineering
**Lever ID:** `03db117c-d15d-4999-a4a1-2a03d75e7214`

**The Core Decision:** Buoyancy Engineering governs the vertical positioning stability and depth control of the tunnel segments throughout the tunnel's operational life. It determines the equilibrium between buoyant forces and gravitational loading at the target 100-meter depth, directly affecting how much load each pillar bears and the tunnel's behavior during storm events. The buoyancy strategy also dictates material composition of tunnel segments, which in turn governs corrosion resistance and structural lifespan under sustained submersion.

**Why It Matters:** Buoyancy control determines the tunnel's vertical positioning stability and the load borne by each pillar; inadequate buoyancy management leads to either excessive seabed contact or uncontrolled surfacing during storm events. The buoyancy strategy also dictates the material composition of the tunnel segments, which in turn governs corrosion resistance and structural lifespan under sustained submersion.

**Strategic Choices:**

1. Engineer variable-ballast buoyant concrete sections that actively adjust displacement in response to real-time depth sensors and ocean condition data.
2. Fabricate rigid-buoyancy modules with fixed displacement calibrated for the mean 100-meter depth, accepting seasonal positional variance of several meters.
3. Integrate pneumatic buoyancy bladders alongside the concrete structure to provide emergency surfacing capability and active depth correction during extreme weather.

**Trade-Off / Risk:** Active ballast systems add mechanical complexity and maintenance burden to a submerged structure where access is limited, potentially creating failure points that passive fixed-buoyancy designs avoid entirely.

**Strategic Connections:**

**Synergy:** Buoyancy Engineering synergizes with Pillar Architecture because buoyancy loads transfer directly into pillar supports, requiring coordinated design of both systems. It also enables Corrosion and Durability Management, as the material choices driven by buoyancy requirements determine the corrosion exposure profile of submerged concrete.

**Conflict:** Buoyancy Engineering conflicts with Subsea Structural Surveillance because active ballast systems add mechanical complexity and failure points that make continuous structural monitoring more difficult. It also trades off against Construction Deployment, since active buoyancy adjustment systems require additional commissioning time before segments can be placed.

**Justification:** *Medium*, Buoyancy Engineering is important for depth stability and material selection but is largely downstream of Pillar Architecture, which dictates load transfer into buoyant segments. Its connections to corrosion, surveillance, and construction are significant but secondary to the foundational structural choice.

### Decision 7: Rail Systems Integration
**Lever ID:** `3681f080-253d-4c84-9ff8-05549fa1b512`

**The Core Decision:** This lever governs the design, engineering, and interface specifications for the high-speed rail system operating within the submerged tunnel at 100 meters depth. It encompasses track precision standards, pressurization and ventilation architecture, emergency evacuation protocols, and the critical transition points between surface rail networks and the underwater corridor. Success is measured by achieving terrestrial-grade rail performance while maintaining structural integrity under extreme hydrostatic pressure and marine environmental conditions.

**Why It Matters:** The rail system design determines track precision requirements, ventilation and pressurization needs, and emergency evacuation protocols; marine environment constraints impose challenges that terrestrial high-speed rail systems never face. The rail choice also governs the interface between the submerged tunnel and the surface rail networks on both coasts.

**Strategic Choices:**

1. Engineer a sealed pressurized rail corridor within the tunnel with climate-controlled track beds, maintaining terrestrial-grade rail precision despite the underwater environment and external water pressure.
2. Deploy magnetic levitation rail technology that eliminates physical track contact, reducing wear from marine-induced vibration and thermal expansion while requiring entirely new propulsion infrastructure.
3. Construct a dual-mode rail system where trains transition between conventional high-speed rail on land and a marine-adapted undercarriage system within the submerged section.

**Trade-Off / Risk:** Maglev systems eliminate track wear but require complete infrastructure replacement if the tunnel is ever adapted for conventional rail, locking the project into a single-technology future.

**Strategic Connections:**

**Synergy:** Rail Systems Integration amplifies Pillar Architecture because rail corridor dimensions and load distributions must align precisely with pillar spacing and structural capacity. It also enables Hydrodynamic Load Mitigation, as the sealed rail envelope's geometry directly influences how ocean forces interact with the tunnel cross-section.

**Conflict:** Rail Systems Integration constrains Buoyancy Engineering because a sealed pressurized rail corridor adds significant mass and reduces the tunnel's net buoyancy, requiring compensation through additional flotation systems. It also conflicts with Corrosion and Durability Management, as pressurized climate-controlled environments introduce complex humidity and condensation challenges that accelerate material degradation over the 20-year lifespan.

**Justification:** *Medium*, Rail Systems Integration is critical to the tunnel's core function but is more of a domain-specific engineering lever. It amplifies pillar architecture and hydrodynamic mitigation while constraining buoyancy and corrosion, but it does not govern cross-cutting strategic trade-offs like governance, phasing, or deployment.

### Decision 8: Subsea Logistics and Supply Chain
**Lever ID:** `08eac509-fe49-48a6-a1dd-4f341832fa1b`

**The Core Decision:** This lever manages the end-to-end flow of materials, components, and equipment across international waters for the tunnel construction program. It encompasses procurement centralization versus distribution, offshore staging area placement, and the transportation of buoyant concrete segments, marine-grade steel, and mooring systems to installation sites. Success is measured by minimizing transit delays while maintaining supply chain resilience against single-point failures.

**Why It Matters:** Centralizing material procurement across international waters reduces shipping delays but creates a single point of failure if a major port closes. Decentralizing storage increases resilience but drives up inventory holding costs across multiple offshore staging areas.

**Strategic Choices:**

1. Establish a single mega-hub in southern Spain to consolidate all buoyant concrete segments before offshore transfer.
2. Distribute manufacturing across multiple regional yards in Spain and Morocco to minimize offshore transit distances.
3. Deploy a fleet of autonomous semi-submersible barges that manufacture and position segments directly at the installation site.

**Trade-Off / Risk:** Consolidating materials at one hub lowers procurement overhead but risks catastrophic project delays if a single port strike halts the entire supply line.

**Strategic Connections:**

**Synergy:** Subsea Logistics and Supply Chain enables Construction Deployment because material availability directly gates the pace and feasibility of all on-site construction activities. It also supports Phasing and Risk Strategy, as supply chain architecture must be designed to deliver materials in synchronization with the chosen phasing approach and its associated milestones.

**Conflict:** Subsea Logistics and Supply Chain constrains Environmental Compliance Strategy because centralized mega-hub operations concentrate environmental impact at single locations, making mitigation more difficult than with distributed staging. It also conflicts with Subsea Structural Surveillance, as consolidated logistics reduce the number of physical access points and monitoring stations available for ongoing structural health assessment across the tunnel span.

**Justification:** *Medium*, Subsea Logistics and Supply Chain is an important operational enabler that gates construction deployment and supports phasing, but it is itself downstream of deployment and phasing decisions. Its trade-offs around centralization versus resilience are significant but tactical relative to the core strategic pillars.

### Decision 9: Hydrodynamic Load Mitigation
**Lever ID:** `da4dc179-5c1e-4c42-bb96-ed7a4f1b6e00`

**The Core Decision:** This lever addresses the engineering challenge of managing ocean currents, wave kinetic energy, and hydrodynamic pressures acting on the submerged tunnel structure at 100 meters depth. It involves designing the tunnel's external profile, joint interfaces, and auxiliary systems to deflect, absorb, or neutralize the forces generated by deep-water marine environments. Success is measured by minimizing structural stress while maintaining tunnel geometry and operational stability under extreme hydrodynamic conditions.

**Why It Matters:** Designing the tunnel cross-section to deflect deep-water currents minimizes lateral structural stress but increases the overall tunnel diameter and material requirements. Absorbing hydrodynamic forces through flexible joint interfaces reduces material mass but introduces complex maintenance requirements for seals over a 20-year lifespan.

**Strategic Choices:**

1. Shape the tunnel exterior with aerodynamic ridges to slice through deep-water currents and reduce drag forces.
2. Incorporate articulated flexible joints between tunnel segments to absorb wave-induced kinetic energy without transferring stress to the pillars.
3. Install a passive counter-oscillating outer shell that generates opposing hydrodynamic forces to neutralize wave impact.

**Trade-Off / Risk:** Deflecting deep-water currents via aerodynamic shaping reduces structural mass but demands deeper pillar anchoring to resist the increased vertical buoyancy forces.

**Strategic Connections:**

**Synergy:** Hydrodynamic Load Mitigation amplifies Pillar Architecture because the tunnel's hydrodynamic profile determines the magnitude and direction of forces transmitted to the pillar system, directly influencing pillar design parameters. It also reinforces Geotechnical Anchoring Methodology, as the lateral and vertical loads from ocean forces must be comprehensively resisted by the anchoring system's structural capacity.

**Conflict:** Hydrodynamic Load Mitigation constrains Buoyancy Engineering because aerodynamic shaping that deflects deep-water currents alters the tunnel's displacement characteristics, requiring recalibration of the buoyancy equilibrium. It also conflicts with Corrosion and Durability Management, as articulated flexible joints designed to absorb hydrodynamic forces create complex seal interfaces that are highly vulnerable to corrosion and degradation over the 20-year operational lifespan.

**Justification:** *Medium*, Geotechnical Anchoring Methodology is closely redundant with Pillar Architecture as both address the foundational structural system. The anchoring method is largely determined by pillar type selection, making it a supporting detail rather than an independent strategic lever. Its environmental and buoyancy conflicts are real but derivative.

### Decision 10: Geotechnical Anchoring Methodology
**Lever ID:** `dd160a01-e55a-43b6-8049-a6a7d83ffa57`

**The Core Decision:** This lever defines the foundational approach by which the tunnel's pillar-supported structure is secured to the Gibraltar seabed and bedrock. It determines whether the system relies on mechanically drilled reinforced shafts, gravity-based concrete mattresses, or high-pressure cement slurry injection, each carrying distinct implications for structural stability, ecological disruption, and material mass balance. Success is measured by achieving unwavering structural lock against lateral sliding and vertical displacement while maintaining the tunnel's designed buoyancy depth.

**Why It Matters:** Utilizing drilled shafts into the Gibraltar bedrock provides unparalleled structural stability but requires extensive marine drilling operations that disrupt local seabed ecology. Employing gravity-based foundations eliminates the need for deep drilling but demands massive concrete volumes that compromise the buoyancy equilibrium of the tunnel.

**Strategic Choices:**

1. Drill deep reinforced shafts into the bedrock to mechanically lock the pillar foundations against lateral sliding.
2. Construct massive gravity-based concrete mattresses on the seabed to anchor the pillars through sheer downward mass.
3. Inject high-pressure cement slurry into the seabed to create a composite soil-cement foundation that bonds with the pillars.

**Trade-Off / Risk:** Relying on gravity-based mattresses avoids seabed drilling but requires such immense concrete mass that it fundamentally alters the tunnel's neutral buoyancy depth.

**Strategic Connections:**

**Synergy:** Geotechnical Anchoring Methodology enables Pillar Architecture because the anchoring method directly determines the pillar foundation design, depth penetration, and load-bearing capacity. It also reinforces Hydrodynamic Load Mitigation, as the anchoring system must possess sufficient structural resistance to counteract the lateral forces generated by ocean currents that the hydrodynamic mitigation strategies address.

**Conflict:** Geotechnical Anchoring Methodology constrains Environmental Compliance Strategy because drilled shafts into bedrock cause significant seabed ecological disruption, potentially violating marine habitat protection regulations. It also conflicts with Buoyancy Engineering, as gravity-based anchoring approaches require immense concrete masses that fundamentally alter the tunnel's neutral buoyancy depth and compromise the carefully engineered flotation equilibrium.

**Justification:** *Medium*, Hydrodynamic Load Mitigation is an engineering detail that flows from Pillar Architecture, as the tunnel's profile determines forces transmitted to pillars. While it reinforces anchoring methodology and constrains buoyancy and corrosion, it is largely a downstream consequence of the foundational structural design choice.

### Decision 11: Corrosion and Durability Management
**Lever ID:** `bc3297d2-1384-47ee-922b-6a8733905b0c`

**The Core Decision:** Corrosion and Durability Management addresses the protection of the submerged concrete tunnel structure against the aggressive saline environment over a 20+ year operational horizon. It encompasses the selection and implementation of protective systems—polymer encapsulation, sacrificial anodes, and active cathodic protection—balancing significant upfront material costs against long-term structural integrity and lifespan extension. Key success metrics include achieving structural durability beyond the initial 20-year design life, minimizing maintenance interventions, and preventing saline ingress that could compromise internal reinforcement.

**Why It Matters:** Applying advanced polymer coatings to the submerged concrete extends the structural lifespan beyond the initial 20-year horizon but introduces significant upfront material costs. Implementing sacrificial anode systems passively protects the steel reinforcements but requires continuous monitoring and periodic anode replacement throughout the project's life.

**Strategic Choices:**

1. Encapsulate the concrete structure in a seamless polymer membrane that isolates the structure from saline water penetration entirely.
2. Install a network of sacrificial zinc anodes within the concrete mix that corrodes preferentially to protect the internal steel reinforcement.
3. Embed an active cathodic protection grid powered by offshore tidal energy generators to continuously neutralize electrochemical corrosion.

**Trade-Off / Risk:** Encapsulating the tunnel in a polymer membrane eliminates saline ingress but traps moisture during construction, accelerating internal carbonation if the seal is breached.

**Strategic Connections:**

**Synergy:** This lever amplifies Subsea Structural Surveillance, as monitoring systems detect early corrosion progression while corrosion protection reduces the degradation surveillance must track. It also synergizes with Hydrodynamic Load Mitigation, since corrosion-weakened structural elements are more vulnerable to ocean forces.

**Conflict:** This lever constrains Construction Deployment, as applying advanced polymer membranes or installing cathodic protection grids adds complexity and time to the build schedule. It also conflicts with Subsea Logistics and Supply Chain, because specialized corrosion materials increase procurement burden and cost at depth.

**Justification:** *Medium*, Corrosion and Durability Management is a critical lifecycle concern for a 20-year submerged structure but is downstream of design and construction choices. It amplifies surveillance and synergizes with hydrodynamic mitigation but constrains deployment and logistics as an operational cost rather than a strategic driver.

### Decision 12: International Consortium Financing
**Lever ID:** `2c59a59f-4678-49e0-bb91-6cf66590ab4c`

**The Core Decision:** International Consortium Financing structures the sourcing and governance of the €40 billion capital required for the transoceanic tunnel. It navigates multilateral government bonds, public-private partnerships, and development bank funds to secure stable long-term capital while managing political risk and aligning investor return timelines with the 20-year construction horizon. Key success metrics include cost of capital, capital availability across phases, and the degree of alignment between investor expectations and project milestones.

**Why It Matters:** Structuring the €40 billion funding through multilateral government bonds secures long-term capital stability but subjects the project to shifting political priorities across administrations. Leveraging private equity accelerates initial capital deployment but imposes strict return-on-investment timelines that may conflict with the 20-year construction horizon.

**Strategic Choices:**

1. Issue sovereign-backed infrastructure bonds jointly guaranteed by the Spanish and Moroccan governments to secure low-interest, long-term capital.
2. Form a public-private partnership that sells operational toll revenues to private investors to front-load construction capital.
3. Establish a multilateral development bank fund that provides tranched disbursements tied to specific geological and marine milestones.

**Trade-Off / Risk:** Securing private equity accelerates initial capital deployment but imposes strict return-on-investment timelines that may conflict with the 20-year construction horizon.

**Strategic Connections:**

**Synergy:** This lever enables Phasing and Risk Strategy, as tranched disbursements tied to geological and marine milestones create natural project phases and risk gates. It also synergizes with Cross-Border Governance, since bilateral government guarantees and international development bank involvement require coordinated diplomatic and regulatory frameworks.

**Conflict:** This lever conflicts with Environmental Compliance Strategy, because strict private-equity return timelines may pressure accelerated construction that shortcuts thorough environmental assessments. It also constrains Offshore Workforce Resilience, as financing cost pressures can limit budgets for worker retention, amenities, and long-term talent stability.

**Justification:** *Medium*, International Consortium Financing enables phasing and risk strategy through tranched disbursements and synergizes with cross-border governance, but it is itself an enabler downstream of governance structure and phasing milestones. Its conflicts with environmental compliance and workforce resilience are significant but secondary to the core strategic architecture.

### Decision 13: Offshore Workforce Resilience
**Lever ID:** `73d14659-1b3d-4aaf-a298-35aae213ef1d`

**The Core Decision:** Offshore Workforce Resilience tackles the challenge of maintaining a stable, highly skilled workforce across a 20-year isolated offshore construction environment. It addresses worker retention, quality of life, institutional knowledge preservation, and safety through strategies ranging from permanent residential platforms to rotational models and equity-based incentives. Key success metrics include workforce turnover rates, safety incident frequency, training efficiency, and retention of specialized expertise through critical installation phases.

**Why It Matters:** Maintaining a stable, highly skilled workforce across a 20-year project requires mitigating the harsh realities of isolated offshore living, which directly impacts construction quality and safety records. The downstream implication is that high turnover forces repeated training cycles, eroding institutional knowledge and increasing the likelihood of human error during critical installation phases.

**Strategic Choices:**

1. Construct permanent, luxury-grade offshore residential platforms with comprehensive recreational and family amenities to retain talent for the project's full duration.
2. Implement a rotational fly-in-fly-out model using dedicated high-speed marine shuttles from coastal hubs to minimize time workers spend at sea.
3. Offer equity-sharing and long-term performance bonuses tied to the tunnel's operational milestones to incentivize workers to stay through the two-decade lifecycle.

**Trade-Off / Risk:** Permanent offshore housing stabilizes the workforce but creates a massive fixed-cost burden during periods of reduced construction activity, whereas rotational models lose vital specialized expertise.

**Strategic Connections:**

**Synergy:** This lever amplifies Construction Deployment, as a stable and experienced workforce directly improves build quality, safety compliance, and installation efficiency across all phases. It also synergizes with Subsea Structural Surveillance, because experienced personnel are better equipped to interpret monitoring data and respond to structural alerts.

**Conflict:** This lever conflicts with International Consortium Financing, because permanent offshore housing and equity-sharing incentives create substantial fixed costs and reduce investor returns. It also constrains Phasing and Risk Strategy, as workforce stability requirements limit the ability to flex labor capacity up or down across different project phases.

**Justification:** *Medium*, Offshore Workforce Resilience amplifies construction deployment and synergizes with structural surveillance, but it is constrained by financing cost pressures and phasing flexibility requirements. It is an important operational enabler rather than a strategic driver of the project's fundamental outcomes.

### Decision 14: Subsea Structural Surveillance
**Lever ID:** `4b34170e-9bd8-4166-9fec-bc2d4a2426a7`

**The Core Decision:** Subsea Structural Surveillance deploys continuous real-time monitoring systems across the submerged tunnel and pillar infrastructure to detect micro-fractures, sediment shifts, and structural deformation before they escalate into catastrophic failures. It overcomes the challenge of transmitting enormous data volumes from 100 meters depth through resilient underwater communication infrastructure. Key success metrics include detection sensitivity, data accuracy, system uptime, and time-to-alert for structural anomalies.

**Why It Matters:** Deploying continuous real-time monitoring systems across the submerged tunnel and pillars detects micro-fractures and sediment shifts before they become catastrophic failures. However, the downstream trade-off is the enormous data bandwidth and processing power required at 100 meters depth, which demands a resilient and expensive underwater communication infrastructure.

**Strategic Choices:**

1. Install a dense mesh of fiber-optic acoustic sensors along the entire tunnel length to detect structural deformation through changes in light transmission.
2. Deploy autonomous underwater vehicles on fixed patrol routes to conduct daily high-resolution sonar scans of the pillar foundations and tunnel hull.
3. Embed wireless piezoelectric pressure sensors within the concrete matrix that transmit structural health data via acoustic modem to surface buoys.

**Trade-Off / Risk:** Continuous fiber-optic monitoring provides precise deformation data but requires complex waterproof splicing at extreme depths, whereas autonomous vehicles offer flexibility at the cost of delayed data retrieval.

**Strategic Connections:**

**Synergy:** This lever amplifies Corrosion and Durability Management, as surveillance detects early corrosion signs enabling proactive intervention while protection systems reduce the degradation surveillance must monitor. It also synergizes with Pillar Architecture and Buoyancy Engineering, since monitoring data validates the structural performance of these foundational design elements over time.

**Conflict:** This lever constrains Subsea Logistics and Supply Chain, as deploying dense sensor meshes, autonomous underwater vehicles, and underwater communication infrastructure adds significant logistical complexity and cost at depth. It also conflicts with Offshore Workforce Resilience, because maintaining surveillance systems requires additional specialized technical personnel stationed at sea, increasing workforce demands and costs.

**Justification:** *Medium*, Subsea Structural Surveillance amplifies corrosion management and validates pillar and buoyancy performance, but it is a downstream monitoring function dependent on all prior design and construction decisions. Its logistical and workforce constraints are real but it does not govern the core strategic trade-offs.
