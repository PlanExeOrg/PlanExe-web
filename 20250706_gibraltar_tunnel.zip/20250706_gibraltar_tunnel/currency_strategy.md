This plan involves money.

## Currencies

- **EUR:** Spain is a Eurozone member and the project is explicitly denominated in euros (€40 billion). EUR serves as the primary currency for consolidated budgeting, reporting, and the majority of procurement and financing activities.
- **MAD:** Morocco's official currency (Moroccan Dirham) is required for local transactions on the Moroccan side, including labor, local materials, permitting fees, and coastal staging operations near Tangier.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting and reporting across the entire 20-year project lifecycle, as the project is denominated in euros. MAD will be used for local Moroccan transactions. Exchange rate risk between EUR and MAD must be actively managed through hedging instruments (e.g., forward contracts or currency swaps) to protect the €40 billion budget envelope from cross-border currency fluctuations. International payments and financing should leverage cards or banking facilities with minimal foreign transaction fees.