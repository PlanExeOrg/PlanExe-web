
## Audit - Corruption Risks

- Bribery in major procurement contracts for buoyant concrete, marine-grade steel, and mooring systems, where suppliers may offer illicit payments to secure contracts within the €40 billion budget envelope.
- Nepotism in the selection of the neutral third-party engineering consortium leadership or key technical personnel, where unqualified relatives or associates of decision-makers are appointed to critical design and oversight roles.
- Conflicts of interest within the international consortium governance structure, where the neutral engineering firm may have undisclosed financial ties to construction contractors or material suppliers, compromising objective technical decision-making.
- Kickbacks in offshore platform construction and fabrication yard contracts, where inflated costs are agreed upon in exchange for personal payments to project officials or government representatives.
- Trading of diplomatic or regulatory favors in cross-border permitting processes, where officials may exchange expedited environmental approvals or construction permits for personal or political benefits.
- Misuse of sensitive project information, including geotechnical survey data or financial details, for insider trading or to benefit external parties with interests in the project's success or failure.

## Audit - Misallocation Risks

- Embezzlement or misuse of the €40 billion capital budget or the €4-6 billion contingency reserve for personal gain or unauthorized purposes by project officials or consortium members.
- Double spending of tranche-based funding disbursements, where the same milestone-based funds are claimed or allocated to multiple purposes before verification of actual expenditure.
- Misreporting of construction progress to international financing entities to unlock successive funding tranches prematurely, despite incomplete or substandard work on functional-subsystem phases.
- Inefficient allocation of resources between the three construction phases (pillars/buoyancy, rail infrastructure, sealing/pressurization), such as over-investing in Phase 1 while leaving insufficient budget for critical Phase 2 rail systems integration.
- Unauthorized use of project assets, including offshore floating platforms, fabrication yards, or specialized materials, for non-project purposes or by third parties without proper authorization or compensation.
- Poor record keeping and lack of audit trails for expenditures related to MAD-denominated local costs in Morocco, enabling untraceable fund diversion or currency manipulation.
- Overpayment to contractors and suppliers due to lack of competitive bidding oversight or inflated invoicing, particularly in specialized areas like corrosion protection systems and buoyancy engineering components.

## Audit - Procedures

- Quarterly internal financial audits of all project expenditures against the €40 billion budget envelope, with automated escalation triggers at 5%, 10%, and 15% budget utilization to detect anomalies early.
- Annual external audits of the neutral third-party consortium's governance decisions, technical approvals, and financial management to ensure compliance with the bilateral treaty and ICC arbitration rules.
- Mandatory independent audit of all procurement contracts exceeding €50 million (covering buoyant concrete, marine-grade steel, mooring systems, and offshore platform construction) before contract finalization and payment release.
- Environmental compliance audits conducted by the independent environmental oversight board to verify adherence to marine ecosystem protection standards, cetacean migration restrictions, and mitigation measures throughout construction.
- Phase-gate external audits upon completion of each functional-subsystem phase (pillars/buoyancy, rail infrastructure, sealing/pressurization) before releasing subsequent funding tranches from multilateral development banks and sovereign bonds.
- Supply chain audits utilizing blockchain-based tracking systems to verify material provenance, prevent double-spending of materials, and ensure all buoyant concrete and steel components meet specified standards.
- Cross-border governance audits verifying compliance with bilateral treaty obligations, parliamentary ratification requirements, and diplomatic task force decisions, conducted by international legal counsel specializing in transboundary infrastructure.

## Audit - Transparency Measures

- Public transparency portal with real-time project updates, budget utilization dashboards, environmental monitoring data, and construction progress reports accessible to both governments, investors, and the general public.
- Quarterly investor briefings with transparent financial reporting, including detailed expenditure breakdowns, contingency reserve status, and milestone achievement verification to maintain investor confidence and unlock funding tranches.
- Published meeting minutes of the bilateral diplomatic task force, consortium governance body, and independent environmental oversight board to ensure accountability in cross-border decision-making and environmental compliance.
- Documented selection criteria and evaluation matrices for major vendor and contractor procurement decisions (buoyant concrete suppliers, offshore platform constructors, rail systems integrators) to prevent nepotism and ensure fair competition.
- Established whistleblower mechanisms with anonymous reporting channels for project personnel and contractors to report corruption, misallocation of funds, or non-compliance with environmental and safety standards without fear of retaliation.
- Community liaison offices in Tarifa and Tangier with bilingual (Spanish/Arabic) communications teams publishing regular reports on local hiring quotas, environmental impacts, and community benefit agreements.
- Independent environmental oversight board with public reporting requirements on marine mammal disturbance levels, sediment plume monitoring, and benthic habitat preservation status along the tunnel corridor.