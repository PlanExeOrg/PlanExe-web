# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Deep-Sea Structural Engineer

**Knowledge**: subsea tunnel engineering, buoyant concrete structures, hydrodynamic load analysis, deep-sea structural integrity at 100m depth

**Why**: The unprecedented hybrid floating-pillar architecture at 100m depth is the largest technical uncertainty; structural failure risks are catastrophic at €500M-€2B per incident

**What**: Validate the hybrid floating-pillar architecture through scaled physical model testing and finite element analysis of buoyant segment, pillar, and hydrodynamic force interactions

**Skills**: deep-sea structural analysis, finite element modeling, hydrodynamic simulation, buoyancy engineering, subsea construction methodology

**Search**: deep-sea structural engineer subsea tunnel buoyant concrete 100m depth hydrodynamic load

## 1.1 Primary Actions

- Establish a Geotechnical and Structural Validation Gate as a hard prerequisite before any construction mobilization. Commission deep-sea borehole sampling at minimum 5 locations across the 14 km corridor (200m below seabed each), 3D seismic reflection profiling calibrated to the Azores-Gibraltar fault zone, and probabilistic seismic hazard analysis. Complete by June 2027.
- Complete 1:50 scale physical model testing of the hybrid floating-pillar architecture in deep-water basins under simulated Gibraltar Strait currents (max 2.5 m/s lateral flow) by June 2027. Do not proceed to mass production until this validation is complete.
- Build and deploy a fully instrumented 50-meter prototype segment at 100m equivalent depth by March 2028. Monitor for minimum 6 months of continuous stable operation under simulated storm conditions before approving mass production.
- Commission a comprehensive energy audit quantifying total operational demand (50-100 MW continuous). Develop hybrid energy strategy (submarine HVDC cables, offshore wind/tidal with battery storage, diesel backup). Establish €1-2 billion energy infrastructure budget and negotiate supply agreements with both national grid operators before construction begins.
- Develop comprehensive flooding risk management plan including redundant hull integrity monitoring (500-point sensor intervals), emergency flooding containment compartments (every 200m), rapid-deployment flood barriers, and specialized submersible rescue vehicles (50+ passengers per vehicle). Budget €100-300 million. Establish dedicated emergency response vessels on 24/7 standby.
- Require all structural designs to incorporate site-specific seismic loading cases with minimum 2% probability of exceedance in 50 years, including deepened foundation specifications and seismic isolation bearings at all pillar-tunnel connections. Budget €500 million-€1.5 billion for seismic mitigation.
- Establish formal geotechnical validation gate with hard stop date of June 2027 before any construction mobilization permits are issued. Require sign-off from independent seismic review panel by September 2027.

## 1.2 Secondary Actions

- Resolve rail gauge incompatibility between Spain (Iberian 1,668mm) and Morocco (standard 1,435mm) by mandating unified standard gauge (1,435mm) for tunnel and both connecting networks. Conduct comprehensive systems interoperability study covering gauge, signaling (ERTMS), electrification (unified 25kV AC), and safety protocols. Budget €200-500 million for gauge transition infrastructure.
- Commission comprehensive marine ecosystem baseline studies covering cetacean migration patterns, benthic habitat mapping, water quality parameters, and sediment dynamics across the full Strait of Gibraltar corridor. Begin field data collection by November 2026, complete within 24 months.
- Establish independent environmental oversight board with binding authority to halt construction if marine mammal disturbance thresholds are exceeded. Deploy real-time acoustic monitoring buoys at minimum 10 locations along tunnel corridor by June 2027.
- Develop comprehensive decommissioning plan during design phase including environmental remediation protocols and material recovery strategies. Establish €2-4 billion decommissioning reserve fund capitalized at project inception.
- Integrate IPCC climate projections (SSP2-4.5 and SSP5-8.5) into structural design incorporating sea level rise of 0.3-0.6m and increased storm intensity of 10-20%. Design adaptive buoyancy systems to compensate for sea level changes. Budget €200-400 million for climate adaptation.
- Establish distributed supply chain with at least two regional fabrication yards (southern Spain near Tarifa/Algeciras and northern Morocco near Tangier-Med) for redundancy. Maintain 3-6 month strategic inventory of critical materials at offshore staging areas.
- Implement multi-layer corrosion protection combining polymer encapsulation, sacrificial anodes, and active cathodic protection as redundant systems. Design accessible inspection and maintenance ports at regular intervals. Budget €3-8 billion for 20-year maintenance.
- Establish bilateral diplomatic task force with pre-negotiated framework agreements. Schedule first ministerial-level meeting no later than November 2026. Ratify bilateral treaty through both Spanish Cortes Generales and Moroccan Parliament within 18 months, embedding binding commitments with penalty clauses that survive changes in government.
- Engage International Maritime Organization (IMO) with pre-agreed timeline for transboundary environmental impact assessment, targeting preliminary framework agreement by June 2027, with fallback arbitration under ICC rules already negotiated.
- Develop and brand the transcontinental high-speed rail corridor as the world's first submerged intercontinental rail connection ('The Intercontinental Express'). Launch global marketing campaign positioning the tunnel as the backbone of Euro-African connectivity. Target 1 million passengers annually within 5 years of operational commencement.

## 1.3 Follow Up Consultation

Focus on three critical validation milestones: (1) Geotechnical validation gate status—have the deep-sea borehole samples been collected and analyzed? What does the seabed geology actually look like? Are the pillar penetration depths and anchoring methodologies still viable given the real data? (2) Prototype segment progress—has the 50-meter instrumented prototype been deployed at 100m equivalent depth? What are the initial buoyancy equilibrium readings? Are there any unexpected hydrodynamic interactions between the buoyant segments and pillar members? (3) Energy and flooding protocol development—has the energy audit been completed? What is the actual continuous power demand? Have the submarine HVDC cable specifications been defined? What is the status of the flooding risk management plan and emergency response vessel procurement? These three areas represent the highest-risk gaps that could invalidate the entire project if not resolved. The next consultation should also review the rail gauge resolution progress and the cross-border governance treaty ratification timeline, as these are gating factors for the project's core purpose and political viability.

## 1.4.A Issue - Unvalidated Hybrid Floating-Pillar Architecture at 100m Depth

The project commits €40 billion to a hybrid floating-pillar system that has no precedent at this scale and depth. The strategic documents acknowledge this is 'unprecedented' and cannot be 'fully validated through existing computational models alone,' yet the plan proceeds with mass production timelines. The interaction between buoyant concrete segments, vertical pillar members, and hydrodynamic lift at 100m depth creates force dynamics that are fundamentally unknown. A single miscalculation in buoyancy equilibrium or lateral load distribution could necessitate segment replacement at €500 million-€2 billion per incident. The plan relies on scaled physical model testing (1:50) and a 50-meter prototype, but these validation steps are scheduled after key construction decisions have already been locked in. This is putting the cart before the horse—you are designing a €40 billion structure on engineering assumptions that have not been proven.

### 1.4.B Tags

- structural_integrity
- unvalidated_design
- buoyancy_engineering
- hydrodynamic_loads
- prototype_gap

### 1.4.C Mitigation

Immediately establish a Geotechnical and Structural Validation Gate as a hard prerequisite before any construction mobilization. Commission deep-sea borehole sampling at minimum 5 locations across the 14 km corridor, each reaching 200m below seabed. Conduct 3D seismic reflection profiling calibrated to the Azores-Gibraltar fault zone. Complete 1:50 scale physical model testing in deep-water basins under simulated Gibraltar Strait currents (max 2.5 m/s lateral flow) by June 2027. Build and deploy a fully instrumented 50-meter prototype segment at 100m equivalent depth by March 2028. Require all structural designs to incorporate site-specific seismic loading cases with minimum 2% probability of exceedance in 50 years. Do not proceed to mass production until the prototype segment has demonstrated stable buoyancy equilibrium and pillar load transfer under simulated storm conditions for a minimum of 6 months of continuous monitoring.

### 1.4.D Consequence

Without validation, the project faces medium-probability but catastrophic structural failure risks. A buoyancy miscalculation could cause uncontrolled surfacing during storm events or excessive seabed contact. A pillar load transfer failure could trigger progressive collapse across multiple segments. The financial exposure is €500 million-€2 billion per incident, with 6-18 months of redesign and reconstruction delay. At worst, a major structural failure could result in total loss of segments valued at €10-20 billion and permanent project cancellation.

### 1.4.E Root Cause

The strategic ambition to balance innovation with proven engineering has led to a hybrid architecture that is neither fully innovative nor fully proven. The team is treating scaled model testing as a formality rather than a genuine validation gate, and the timeline pressures are pushing decisions before data is available.

## 1.5.A Issue - Complete Absence of Site-Specific Seismic and Geotechnical Data

The entire structural design rests on unvalidated assumptions about the Gibraltar seabed. There is no deep-sea borehole sampling, no 3D seismic reflection profiling, and no probabilistic seismic hazard analysis (PSHA) calibrated to the Azores-Gibraltar seismic transform fault zone. This is not a minor data gap—it is a foundational absence that invalidates every structural assumption in the project. The Azores-Gibraltar fault zone is an active seismic transform boundary. A moderate earthquake (M5.5-6.5) could cause €3-8 billion in repairs; a major event (M7.0+) could cause catastrophic failure with total segment loss valued at €10-20 billion. The plan acknowledges this risk but schedules the geotechnical validation gate for 2027-2028, after construction mobilization is already planned to begin. You cannot design pillars, anchoring systems, or seismic isolation bearings without knowing what you are anchoring into.

### 1.5.B Tags

- seismic_risk
- geotechnical_unknown
- fault_zone_proximity
- foundational_data_gap
- design_invalidated

### 1.5.C Mitigation

Commission a comprehensive geotechnical and seismic risk assessment as the absolute first action, before any design finalization or construction mobilization. This must include: (1) Deep-sea borehole sampling at minimum 5 locations spanning the full 14 km corridor, each reaching 200m below seabed to characterize clay, sand, and weathered bedrock strata; (2) 3D seismic reflection profiling across the full tunnel alignment with data processing completed by March 2027; (3) Probabilistic seismic hazard analysis calibrated to the Azores-Gibraltar fault zone, with the PSHA report delivered by April 2027; (4) All structural designs must incorporate site-specific seismic loading cases with minimum 2% probability of exceedance in 50 years. Establish a formal geotechnical validation gate with a hard stop date of June 2027 before any construction mobilization permits are issued. Budget €500 million-€1.5 billion for seismic mitigation measures including deepened foundations to bedrock at minimum 30-meter penetration and seismic isolation bearings at all pillar-tunnel connections.

### 1.5.D Consequence

Without site-specific data, the project is designing blind. Pillar penetration depths, anchoring methodologies, and seismic isolation specifications are all based on assumptions that could be wrong by orders of magnitude. If the seabed geology is weaker or more complex than assumed, the entire pillar architecture may need redesign. A seismic event during construction or operation could cause catastrophic failure. The financial exposure is €3-20 billion depending on seismic severity, with potential total project loss.

### 1.5.E Root Cause

The project timeline is driving decisions before data collection. The team is treating geotechnical investigation as a parallel activity rather than a prerequisite. There is a fundamental misunderstanding that computational models can substitute for site-specific data in a seismically active transform fault zone.

## 1.6.A Issue - Missing Energy Supply Infrastructure and Flooding Emergency Protocols

Two critical operational gaps threaten the project's viability: (1) No energy supply infrastructure plan exists. The tunnel requires 50-100 MW continuous power for pressurized rail climate control, ventilation, structural surveillance, cathodic protection, and rail propulsion. No energy audit has been conducted, no submarine HVDC cable specifications have been defined, no offshore renewable generation capacity has been planned, and no backup power strategy exists. Without reliable power, the tunnel cannot operate, rendering the entire €40 billion investment inoperable. (2) No flooding emergency protocols exist for hull breach scenarios at 100m depth with 10 atmospheres of external pressure. There is no redundant hull integrity monitoring, no emergency flooding containment compartments, no rapid-deployment flood barriers, and no specialized submersible rescue vehicles specified. A small hull breach at this depth could flood at catastrophic rates, representing an existential safety risk for thousands of passengers. These are not minor omissions—they are fundamental operational requirements that must be resolved before the tunnel can function or safely carry passengers.

### 1.6.B Tags

- energy_infrastructure_missing
- flooding_protocols_missing
- operational_viability
- passenger_safety
- critical_gap

### 1.6.C Mitigation

For energy: Conduct a comprehensive energy audit quantifying total demand (estimated 50-100 MW continuous) immediately. Develop a hybrid energy strategy combining submarine HVDC cable connections to Spanish and Moroccan grids, offshore wind/tidal generation with battery storage, and diesel backup. Establish a dedicated energy infrastructure budget of €1-2 billion. Negotiate energy supply agreements with both national grid operators before construction begins. For flooding: Develop a comprehensive flooding risk management plan including redundant hull integrity monitoring with automated breach detection sensors at minimum 500-point intervals along the tunnel, emergency flooding containment compartments at every 200-meter segment interval, rapid-deployment flood barriers at both tunnel entrance portals, and passenger evacuation protocols using specialized submersible rescue vehicles with capacity for minimum 50 passengers per vehicle. Establish dedicated emergency response vessels on 24/7 standby within 30 minutes of the tunnel corridor. Budget €100-300 million for flooding prevention and response infrastructure. Conduct full-scale flooding simulation exercises annually starting 2028.

### 1.6.D Consequence

Without energy infrastructure, the tunnel is inoperable—zero revenue, €500 million-€1 billion in annual lost revenue, and potential total project failure. Without flooding protocols, a hull breach at 100m depth could result in total loss of tunnel sections valued at €5-15 billion, potential loss of life creating unlimited liability, and permanent project cancellation. These gaps also create massive insurance and regulatory compliance vulnerabilities that could prevent the tunnel from ever receiving operational certification.

### 1.6.E Root Cause

The project focus on structural and architectural decisions has overshadowed fundamental operational requirements. Energy and safety protocols are being treated as downstream concerns rather than parallel prerequisites. There is a tendency to assume these systems can be 'added later' rather than recognizing they must be designed into the tunnel from the beginning.

---

# 2 Expert: International Infrastructure Governance Lawyer

**Knowledge**: cross-border treaty law, international infrastructure arbitration, IMO regulatory frameworks, bilateral investment agreements

**Why**: Cross-border governance misalignment is the highest-likelihood risk adding 2-5 years and €2-5 billion in costs; the neutral third-party consortium requires sophisticated bilateral diplomatic negotiation

**What**: Establish the bilateral treaty framework, engage IMO for transboundary environmental assessment, and structure neutral third-party consortium governance with binding ICC dispute resolution

**Skills**: international treaty negotiation, cross-border infrastructure law, IMO regulatory frameworks, ICC arbitration, diplomatic negotiation

**Search**: international infrastructure lawyer cross-border treaty bilateral governance IMO arbitration

## 2.1 Primary Actions

- Immediately retain a specialized international treaty law team (minimum 4 attorneys) to conduct a comprehensive Bilateral Investment Treaty analysis between Spain and Morocco, assessing all investment protection provisions, ISDS mechanisms, and the legal personality of the proposed consortium entity.
- Commission a comprehensive maritime law analysis from an international law firm specializing in UNCLOS and Mediterranean maritime law, addressing the tunnel's legal classification, jurisdictional status of the seabed at 100m depth, Barcelona Convention obligations, and SOLAS/MARPOL compliance requirements.
- Engage the IMO's Legal Committee and Marine Environment Protection Committee proactively to seek preliminary regulatory guidance on the tunnel's classification and applicable regulatory framework before any construction activities commence.
- Commission a critical path analysis from a megaproject scheduling specialist to establish true sequencing dependencies among all pre-project actions, replacing the current parallel workstream assumption with a sequential phase-gate methodology.
- Establish the bilateral diplomatic task force within 30 days as the highest-priority action, with chief legal negotiators possessing treaty-making authority, not just diplomatic envoys.
- Revise the project start date from 'ASAP September 2026' to a realistic mobilization date no earlier than 2030-2031, based on the sequential phase-gate analysis.
- Engage EU legal counsel to assess how EU law (TFEU provisions, European Convention on Human Rights) constrains the governance structure, given Spain's EU membership.
- Establish a dedicated maritime legal compliance unit with at least 6 attorneys specializing in international maritime law within the project team.
- Commission a legal opinion on whether the tunnel constitutes an 'artificial installation' under UNCLOS Part V and the legal implications of that classification for sovereignty, jurisdiction, and permitting.
- Revise the environmental compliance strategy to incorporate specific Barcelona Convention provisions (SPA/BD Protocol, LBS Protocol) rather than treating it as a generic environmental framework.

## 2.2 Secondary Actions

- Analyze existing BITs between Spain and Morocco to identify all investment protection provisions, minimum standard of treatment obligations, and expropriation clauses that may apply to the €40 billion investment.
- Determine the precise geographic coordinates of the tunnel alignment and assess whether the seabed at 100m depth falls within Spain's continental shelf, Morocco's exclusive economic zone, or the high seas under UNCLOS Article 76.
- Negotiate pre-agreed fallback arbitration mechanisms under ICC rules for all potential dispute categories: investor-state, state-to-state, commercial, employment, and environmental disputes.
- Establish a currency hedging program that addresses Morocco's foreign exchange controls and the non-convertibility of the MAD, including analysis of repatriation rights for foreign investors.
- Commission a security and defense law analysis addressing NATO obligations, defense cooperation agreements between Spain and Morocco, and the legal framework for security of critical subsea infrastructure.
- Develop a data protection and cybersecurity legal framework addressing GDPR implications for surveillance data collected in international waters, and the legal status of autonomous underwater vehicle data collection.
- Establish a comprehensive insurance and liability framework addressing the Barcelona Convention's liability protocol, UNCLOS liability for oil pollution and hazardous substance release, and the allocation of liability between Spain, Morocco, the consortium, and contractors.
- Conduct a detailed cost-benefit analysis of the three strategic paths (Builder's Foundation, Pioneer's Gambit, Consolidator's Anchor) incorporating legal risk premiums for each governance and regulatory approach.
- Engage the Strait of Gibraltar Joint Coordination Center to negotiate legal agreements for maritime traffic management, including liability allocation for any disruption to the 100,000+ annual vessel transits.
- Establish a formal treaty negotiation timeline with both governments that accounts for realistic parliamentary calendars, targeting treaty initiation by Q1 2027 with ratification by Q4 2028 at the earliest.

## 2.3 Follow Up Consultation

The next consultation must focus on three critical areas: (1) The legal architecture for the consortium entity — specifically whether it should be structured as a treaty-based international organization, a contractual joint venture, or a special purpose vehicle, and the legal implications of each classification for liability, immunity, and enforcement across Spanish, Moroccan, and international jurisdictions; (2) The maritime legal classification of the tunnel under UNCLOS — whether it constitutes an artificial installation, a submarine cable/pipeline, or a permanent installation, and the specific regulatory obligations that each classification triggers under the Barcelona Convention, SOLAS, and MARPOL; (3) The revised project timeline based on sequential phase-gate analysis — specifically the realistic mobilization date, the sequencing of governance establishment before permitting, and the hard milestones that must be achieved before each subsequent phase can commence. The client must bring the current pre-project assessment.json, the strategic_decisions.md, and any existing BIT analysis between Spain and Morocco to the next consultation.

## 2.4.A Issue - The Cross-Border Governance Legal Architecture is Fundamentally Incomplete

The project's governance strategy — a neutral third-party consortium with technical decision-making authority — is described in operational terms but lacks any substantive international treaty law foundation. There is no analysis of existing Bilateral Investment Treaties (BITs) between Spain and Morocco, their investment protection provisions, or whether the proposed consortium qualifies as an 'investment' triggering ISDS mechanisms under existing treaties. The project does not address whether the consortium will have international legal personality, how its decisions will be enforced across two sovereign jurisdictions, or how EU law (as Spain is an EU member state) constrains or enables the governance structure. The bilateral treaty ratification timeline (18 months through both parliaments) ignores the reality that treaty negotiation typically takes 3-5 years for infrastructure projects of this magnitude, and the Spanish Cortes Generales and Moroccan Parliament have competing legislative calendars that make an 18-month ratification window unrealistic. Furthermore, the project fails to address the legal status of the consortium entity itself — is it a treaty-based international organization, a contractual joint venture, or a special purpose vehicle? Each classification carries fundamentally different legal consequences for liability, immunity, and enforcement.

### 2.4.B Tags

- treaty law gap
- bilateral investment treaty analysis missing
- consortium legal personality undefined
- EU law interaction unaddressed
- enforcement mechanism absent
- ratification timeline unrealistic

### 2.4.C Mitigation

Immediately retain a specialized team of international treaty lawyers (minimum 4 attorneys) to conduct a comprehensive BIT analysis between Spain and Morocco, identifying all relevant investment protection provisions, ISDS mechanisms, and sunset clauses. Engage the Permanent Court of Arbitration or ICC to pre-negotiate a dispute resolution framework specifically tailored to the consortium structure. Commission a legal opinion on the consortium's legal personality under both Spanish and Moroccan law, and under international law if structured as a treaty-based entity. Establish a formal treaty negotiation timeline with both governments that accounts for realistic parliamentary calendars — target treaty initiation by Q1 2027 with ratification by Q4 2028 at the earliest. Engage EU legal counsel to assess how EU law (including TFEU provisions on transboundary infrastructure and the European Convention on Human Rights) constrains the governance structure. The bilateral diplomatic task force must be elevated to include chief legal negotiators with treaty-making authority, not just diplomatic envoys.

### 2.4.D Consequence

Without a legally sound governance foundation, the entire project is vulnerable to challenge at any stage. A change in government could void the bilateral treaty, the consortium could face jurisdictional challenges in multiple courts simultaneously, and investors could lose confidence if the legal framework for dispute resolution is unclear. The project could face injunctions from environmental NGOs or competing stakeholders before construction even begins, and the €40 billion investment could be stranded if the governance structure is legally invalidated.

### 2.4.E Root Cause

The governance strategy was developed from an engineering and operational perspective rather than a legal treaty perspective. The project team treated governance as a political negotiation rather than a legal architecture requiring treaty law expertise. The absence of any reference to existing BITs, international legal personality, or enforcement mechanisms reveals a fundamental gap in the legal reasoning underlying the entire project structure.

## 2.5.A Issue - The Maritime Legal and Regulatory Framework is Entirely Absent

The project constructs a permanent artificial structure in the Strait of Gibraltar — one of the most legally complex waterways in the world — yet there is no analysis of the applicable maritime law regime. The project crosses international waters at 100m depth, but the legal status of the seabed at this depth is ambiguous: it may fall within Spain's continental shelf under UNCLOS Article 76, within Morocco's exclusive economic zone, or in the high seas depending on the precise geographic coordinates. This ambiguity has massive implications for sovereignty, jurisdiction, permitting authority, and environmental regulation. The project references IMO engagement but fails to address the specific regulatory frameworks that will govern construction: UNCLOS provisions on artificial islands and installations (Part V), the Barcelona Convention for the Protection of the Marine Environment of the Mediterranean Sea and its Protocols Concerning Specially Protected Areas (SPA/BD Protocol) and Pollution from Land-Based Sources (LBS Protocol), SOLAS regulations for submerged structures, and MARPOL for environmental protection. The project also ignores the legal implications of the 1958 Geneva Convention on the High Seas and the 1982 UNCLOS regime as applied to the Strait of Gibraltar's unique geographic circumstances — it is a strait used for international navigation, which triggers specific legal obligations under UNCLOS Part III (Archipelagic Sea Routes Passage). No analysis exists for how the tunnel will be classified legally — as a permanent installation, an artificial island, or a submarine cable/pipeline — as each classification carries different legal obligations and permitting requirements.

### 2.5.B Tags

- UNCLOS analysis missing
- Barcelona Convention unaddressed
- seabed sovereignty ambiguous
- artificial structure classification undefined
- SOLAS/MARPOL compliance absent
- high seas vs continental shelf legal status unclear

### 2.5.C Mitigation

Immediately commission a comprehensive maritime law analysis from an international law firm specializing in UNCLOS and Mediterranean maritime law (recommend Freshfields Bruckhaus Deringer or Allen & Overy with a dedicated maritime practice team). The analysis must address: (1) the precise legal classification of the tunnel under UNCLOS and whether it constitutes an artificial installation subject to coastal state jurisdiction; (2) the applicable provisions of the Barcelona Convention and its protocols, including the SPA/BD Protocol's restrictions on benthic habitat disturbance; (3) SOLAS and MARPOL compliance requirements for a submerged structure in an international strait; (4) the legal status of the seabed at the tunnel's precise coordinates under both Spanish and Moroccan domestic law and international law; (5) the implications of the strait's status as a route for international navigation under UNCLOS Part III. Engage the IMO's Legal Committee and Marine Environment Protection Committee proactively to seek preliminary guidance on the regulatory classification. Establish a dedicated maritime legal compliance unit within the project team with at least 6 attorneys specializing in international maritime law. The environmental compliance strategy must be revised to incorporate the Barcelona Convention's specific provisions rather than treating it as a generic environmental framework.

### 2.5.D Consequence

Without a clear maritime legal framework, the project faces existential legal risk. Construction in ambiguous jurisdictional waters could trigger sovereignty disputes between Spain and Morocco, or challenge the project's legality under international law. Environmental permits obtained under one jurisdiction may be invalid under another. The project could face injunctions from the International Tribunal for the Law of the Sea or regional courts, and the €40 billion investment could be exposed to unlimited liability if the structure is classified as an unauthorized artificial installation. Insurance coverage may be voided if the project operates outside the legal framework assumed in the policy.

### 2.5.E Root Cause

The project team approached the maritime dimension from an engineering perspective (ocean currents, hydrodynamic forces, installation methodology) rather than a legal perspective (jurisdiction, sovereignty, regulatory classification). The strategic decisions document treats the Strait of Gibraltar as a geographic corridor rather than a legally complex waterway governed by multiple overlapping international and domestic legal regimes. The absence of any reference to UNCLOS, the Barcelona Convention, or SOLAS in the strategic decisions or project plan reveals a fundamental gap in the legal reasoning.

## 2.6.A Issue - The Pre-Project Assessment Creates a Logical Impossibility and Ignores Sequencing Dependencies

The pre-project assessment.json identifies eight critical action items with hard deadlines, but these deadlines create a logical impossibility when analyzed against the project's 'ASAP' start date of September 2026. The assessment requires: geotechnical validation by September 2027, governance establishment by November 2026, offshore fabrication infrastructure by January 2027, workforce recruitment by March 2027, prototype testing by March 2028, and environmental compliance by March 2027. However, these workstreams have strict sequencing dependencies that the assessment ignores: (1) you cannot commission offshore fabrication infrastructure (requiring construction permits) before governance is established (which enables permitting authority); (2) you cannot validate the architecture through prototype testing before fabrication infrastructure exists to build the prototype; (3) you cannot recruit a specialized workforce before the governance structure and construction methodology are legally defined; (4) you cannot obtain environmental permits before the governance structure can legally engage with regulatory authorities. The assessment treats these as parallel workstreams when they are fundamentally sequential. Furthermore, the assessment's hard deadlines (e.g., '2027-03-15 at 17:00' for seismic data processing) are arbitrary and lack any basis in the actual time required for deep-sea borehole sampling, 3D seismic reflection profiling, or treaty ratification. The assessment also ignores the 12-18 month lead time required for international legal counsel retention, the 6-12 month period for IMO engagement to yield any preliminary framework, and the 24-month minimum for comprehensive marine ecosystem baseline studies — yet sets environmental compliance deadlines that assume these can be completed in parallel with construction preparation.

### 2.6.B Tags

- sequencing logic inverted
- parallel workstream assumption invalid
- hard deadlines arbitrary
- lead time ignored
- governance-permitting dependency unaddressed
- logical impossibility in timeline

### 2.6.C Mitigation

Immediately commission a critical path analysis from a megaproject scheduling specialist (recommend Arup or Mott MacDonald with megaproject experience) to establish the true sequencing dependencies among all pre-project actions. Revise the pre-project assessment to reflect a sequential logic: Phase 0 (Governance and Legal Foundation, Sept 2026 - Dec 2027): bilateral treaty negotiation, IMO engagement, legal counsel retention, consortium establishment; Phase 1 (Geotechnical and Environmental Validation, Jan 2027 - Dec 2028): deep-sea borehole sampling, seismic profiling, marine ecosystem baseline studies, prototype design; Phase 2 (Infrastructure and Workforce Preparation, Jan 2028 - Dec 2029): fabrication yard construction, platform fabrication, workforce recruitment and training; Phase 3 (Prototype Validation and Permitting, Jan 2029 - Dec 2030): prototype testing, full permitting, final design validation. Each phase must have a formal gate review before the next phase can commence. The hard deadlines in the assessment must be replaced with milestone-based gates that reflect actual lead times. The project start date must be revised from 'ASAP September 2026' to a realistic mobilization date no earlier than 2030-2031, given the sequencing requirements. The bilateral diplomatic task force must be established immediately (within 30 days) as the highest-priority action, as all other workstreams depend on it.

### 2.6.D Consequence

If the project proceeds with the current assessment timeline, it will face cascading delays as each workstream encounters dependencies that were not anticipated. The 'ASAP' start date will be pushed back by 2-4 years as the sequencing reality becomes apparent, eroding investor confidence and potentially triggering funding cliff provisions. The hard deadlines will be missed, creating a pattern of failed milestones that undermines the project's credibility with both governments and international lenders. The €40 billion budget envelope will be insufficient if the timeline extends by 2-4 years, as carrying costs of €300-600 million per year will add €600 million-€2.4 billion in unbudgeted expenses.

### 2.6.E Root Cause

The pre-project assessment was developed by listing critical actions without analyzing their interdependencies. The assessment treats complex legal, geotechnical, environmental, and infrastructure workstreams as if they can proceed simultaneously, ignoring the fundamental reality that governance must precede permitting, permitting must precede construction, and construction methodology must precede prototype testing. The arbitrary hard deadlines (with specific times like '17:00') suggest the assessment was created by a project manager unfamiliar with the actual time required for deep-sea geotechnical work, international treaty negotiation, or marine ecosystem studies.

---

# The following experts did not provide feedback:

# 3 Expert: Marine Geotechnical Engineer

**Knowledge**: deep-sea geotechnical investigation, seismic hazard analysis, seabed characterization, liquefaction potential assessment

**Why**: Complete absence of site-specific seismic data near the Azores-Gibraltar fault zone invalidates structural design assumptions and exposes the project to €3-20 billion in earthquake damage

**What**: Commission geotechnical validation including deep-sea borehole sampling, 3D seismic reflection profiling, and probabilistic seismic hazard analysis calibrated to the Azores-Gibraltar fault zone

**Skills**: seismic hazard analysis, deep-sea borehole investigation, geotechnical characterization, liquefaction assessment, probabilistic seismic hazard analysis

**Search**: marine geotechnical engineer seismic hazard assessment deep-sea borehole Azores-Gibraltar fault zone

# 4 Expert: Marine Environmental Scientist

**Knowledge**: marine ecosystem assessment, cetacean migration patterns, benthic habitat mapping, environmental impact assessment, marine mitigation design

**Why**: Environmental permitting across two jurisdictions could add 1-3 years and €500M-€1.5 billion in costs; elevated pillar design must preserve benthic habitats while meeting regulatory requirements

**What**: Commission marine ecosystem baseline studies, establish the independent environmental oversight board, and design ecosystem restoration with artificial reef structures along the tunnel corridor

**Skills**: marine ecology, cetacean behavioral studies, benthic habitat mapping, environmental impact assessment, marine mitigation design, regulatory compliance

**Search**: marine environmental scientist transboundary EIA cetacean migration benthic habitat Strait of Gibraltar

# 5 Expert: Rail Systems Integration Engineer

**Knowledge**: high-speed rail interoperability, pressurized rail corridor design, gauge transition engineering, ERTMS signaling, electrification standards

**Why**: Rail gauge incompatibility between Spain (Iberian 1,668mm) and Morocco (standard 1,435mm) fundamentally threatens the core purpose of seamless transcontinental rail connectivity; pressurized rail corridor design at 100m depth introduces unprecedented engineering challenges

**What**: Resolve rail gauge and systems interoperability by mandating unified standard gauge, conducting comprehensive signaling and electrification compatibility studies, and designing the sealed pressurized rail corridor with climate-controlled track beds

**Skills**: rail systems engineering, gauge transition design, pressurized enclosure engineering, ERTMS signaling, electrification systems, tunnel rail integration

**Search**: rail systems integration engineer high-speed rail pressurized tunnel gauge interoperability ERTMS

# 6 Expert: Offshore Energy Infrastructure Engineer

**Knowledge**: submarine HVDC transmission, offshore renewable energy, deep-sea power distribution, energy storage systems, marine electrical engineering

**Why**: The project specifies massive energy demands (50-100 MW continuous) for pressurized rail, ventilation, surveillance, and cathodic protection but has no articulated energy supply plan, making this a critical missing infrastructure component

**What**: Develop a comprehensive energy supply infrastructure plan combining submarine HVDC cable connections, offshore wind/tidal generation with battery storage, and backup power systems with a dedicated €1-2 billion budget

**Skills**: submarine HVDC cable design, offshore wind/tidal energy, marine electrical systems, energy storage integration, deep-sea power distribution, grid interconnection

**Search**: offshore energy infrastructure engineer submarine HVDC deep-sea power marine renewable energy

# 7 Expert: Offshore Construction Program Manager

**Knowledge**: offshore megaproject construction management, floating platform deployment, modular prefabrication logistics, weather window optimization, workforce coordination at sea

**Why**: Construction Deployment is a Critical lever that gates all on-site activities; the offshore floating platform approach requires permanent infrastructure deployment, weather-dependent installation windows, and coordination of 8,000-12,000 personnel across international waters

**What**: Define the end-to-end construction deployment methodology using offshore floating platforms, establish regional fabrication yards in Spain and Morocco, and coordinate the phased installation of tunnel segments at 100m depth

**Skills**: offshore construction management, floating platform deployment, modular prefabrication, weather window planning, workforce logistics, marine operations coordination

**Search**: offshore construction program manager floating platform deployment modular prefabrication deep-sea tunnel

# 8 Expert: Megaproject Finance and Risk Analyst

**Knowledge**: infrastructure project finance, tranche-based disbursement modeling, currency hedging, cost escalation risk, contingency reserve management, sovereign bond structuring

**Why**: The €40 billion budget faces 10-15% cost escalation potential (€4-6 billion), currency risk (€200-800 million), and funding continuity threats (€500M-€1B per funding gap) over a 20-year horizon requiring sophisticated financial structuring

**What**: Structure the international consortium financing through multilateral government bonds, public-private partnerships, and development bank funds with tranche-based disbursements tied to geological and marine milestones, while implementing comprehensive currency hedging and contingency reserve management

**Skills**: infrastructure project finance, tranche-based disbursement modeling, currency hedging, cost escalation analysis, sovereign bond structuring, contingency reserve management

**Search**: megaproject finance analyst infrastructure bond structuring currency hedging tranche disbursement risk