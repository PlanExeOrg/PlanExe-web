# Purpose
# Purpose
## Purpose Detailed

- Business
- Large-scale infrastructure initiative to engineer and deploy buoyant concrete tunnels anchored 100 meters below sea level for high-speed rail connectivity between two nations.
- Massive governmental/societal project with significant economic, commercial, and public welfare implications.

# Topic

- 20-year, €40 billion transoceanic submerged tunnel infrastructure project connecting Spain and Morocco for high-speed rail traffic.


# Domain
# Primary Domain

- Marine Engineering

## Secondary Domains

- Transportation Engineering
- Structural Engineering
- Geotechnical Engineering

## Rationale

- Marine Engineering is the primary discipline because the project's core success criterion — constructing a submerged tunnel at 100 meters below sea level across the Strait of Gibraltar — is fundamentally a marine environment construction challenge.
- Transportation Engineering addresses a subordinate aspect of the system rather than the overarching marine construction problem that defines the project.

## Disciplines

- Marine Engineering: Importance 5, Specificity 5, Role outcome. The submerged tunnel at 100m below sea level between Spain and Morocco is fundamentally a marine environment construction challenge.
- Geotechnical Engineering: Importance 5, Specificity 5, Role method. Pillar anchoring at 100m depth into the Strait of Gibraltar seabed requires deep understanding of subsurface geology, soil mechanics, and foundation design.
- Offshore Engineering: Importance 5, Specificity 5, Role method. Buoyant concrete tunnels anchored at controlled depth are offshore structures requiring specialized offshore design, installation, and mooring techniques.
- Materials Engineering: Importance 4, Specificity 5, Role method. Buoyant concrete and specialized marine-grade materials are core to the tunnel's construction and long-term submersion durability.
- Transportation Engineering: Importance 4, Specificity 4, Role outcome. The tunnel is specifically engineered for high-speed rail traffic, making rail systems design central to the project.
- Structural Engineering: Importance 4, Specificity 4, Role method. Buoyant concrete tunnel design and pillar-supported anchoring require specialized structural analysis and design expertise.
- Coastal Engineering: Importance 4, Specificity 4, Role method. Coastal hydrodynamics, wave forces, and sediment transport directly affect the pillar-supported structure and shoreline connection points.
- Naval Architecture: Importance 4, Specificity 4, Role method. The buoyant submerged tunnels require naval architectural principles for stability, buoyancy control, and mooring system design at 100m depth.
- Environmental Engineering: Importance 4, Specificity 3, Role constraint. A transoceanic tunnel crossing international waters demands extensive environmental impact assessments and marine ecosystem compliance.


# Plan Type
# Physical Location Requirement
This plan requires physical locations and cannot be executed digitally. It involves constructing a massive submerged tunnel system 100 meters below sea level across the Strait of Gibraltar, connecting Spain and Morocco.

## Key Requirements

- Construction of buoyant concrete tunnels and pillar-supported anchoring structures in a deep marine environment
- Acquisition of specialized materials including buoyant concrete, marine-grade steel, and mooring systems
- Physical labor from thousands of engineers, marine workers, and construction personnel on-site
- Heavy equipment deployment and installation in open ocean conditions
- Geotechnical drilling and foundation work into the seabed
- Physical testing under real-world marine conditions including hydrodynamic forces, pressure, and corrosion
- Extensive transportation of materials and personnel across international waters
- On-site marine ecosystem research for environmental assessments

Every critical phase demands physical presence, physical resources, and real-world construction activity.

# Physical Locations
# Physical Locations Plan

## Requirements for physical locations

- Span or be situated within the Strait of Gibraltar
- Connect Spain and Morocco across international waters
- Support construction and anchoring at 100 meters below sea level
- Accommodate buoyant concrete tunnel segment fabrication, transport, and submersion
- Support pillar-supported structural foundations on the seabed
- Enable high-speed rail traffic through the submerged corridor
- Account for sensitive marine ecosystems in the Strait of Gibraltar
- Allow cross-border coordination between two sovereign nations
- Provide coastal staging areas for fabrication, logistics, and workforce deployment
- Be geologically suitable for deep-sea pillar anchoring at 100m depth

## Location 1
Spain/Morocco (International Waters)
Strait of Gibraltar, between Tarifa (Spain) and Tangier (Morocco)

- Approximately 14 km wide at narrowest point, depth 300m to 900m, tunnel corridor at 100m below sea level
- Only viable crossing point and narrowest span of the Atlantic between Europe and Africa
- Geology of clay, sand, and weathered bedrock suitable for pillar anchoring
- Strategic position on the Europe-Africa maritime corridor

## Location 2
Spain (Southern Coast, Andalusia region)
Coastal zone near Tarifa and Algeciras, Province of Cádiz, Andalusia, Spain

- Optimal staging area for tunnel segment fabrication, dry-dock construction, and workforce deployment
- Existing port infrastructure and proximity to the Strait's narrowest crossing point
- Well-developed road and rail networks connecting to Spain's high-speed rail system
- Established industrial zones for large-scale construction operations

## Location 3
Morocco (Northern Coast, Tanger-Tetouan-Al Hoceima region)
Coastal zone near Tangier-Med port, Tanger-Tetouan-Al Hoceima region, Morocco

- Counterpart staging and portal location for the Moroccan terminus
- Tangier-Med port offers world-class logistics and fabrication capacity
- Available industrial land and existing transportation infrastructure connecting to Morocco's rail network
- Strategic position at the western entrance of the Mediterranean

## Location Summary

- The plan requires physical locations spanning the Strait of Gibraltar for a pillar-supported transoceanic submerged tunnel at 100 meters below sea level
- Location 1: Strait of Gibraltar tunnel corridor (~14 km span)
- Location 2: Southern Spanish coast near Tarifa/Algeciras (European fabrication and portal hub)
- Location 3: Northern Moroccan coast near Tangier (Moroccan staging and portal hub)
- These three locations form the complete physical footprint for the €40 billion, 20-year infrastructure initiative


# Currency Strategy
## Currencies

- EUR: Eurozone member Spain's currency; primary currency for consolidated budgeting, reporting, and the majority of procurement and financing activities across the €40 billion project.
- MAD: Morocco's official currency (Moroccan Dirham); required for local transactions including labor, local materials, permitting fees, and coastal staging operations near Tangier.

Primary currency: EUR

Currency strategy: EUR is used for consolidated budgeting and reporting across the 20-year project lifecycle. MAD is used for local Moroccan transactions. Exchange rate risk between EUR and MAD must be actively managed through hedging instruments (e.g., forward contracts or currency swaps) to protect the €40 billion budget envelope from cross-border currency fluctuations. International payments and financing should leverage cards or banking facilities with minimal foreign transaction fees.

# Identify Risks
## Risk 1 - Regulatory & Permitting
Cross-border governance misalignment between Spain and Morocco could cause severe permitting delays. The neutral third-party consortium model requires diplomatic negotiation to establish legal frameworks, and disagreements over jurisdiction or dispute resolution could stall initiation. The IMO transboundary environmental impact assessment could take five or more years, during which political priorities may shift.

- Impact: 2-5 year delay could push start beyond optimal weather windows and inflate costs by €2-5 billion from extended pre-construction overhead, inflation, and financing carry costs. Investor confidence may erode.
- Likelihood: High
- Severity: High
- Action: Establish a bilateral diplomatic task force with pre-negotiated framework agreements. Engage the IMO early with a pre-agreed timeline and fallback arbitration. Retain international legal counsel specializing in transboundary infrastructure.

## Risk 2 - Regulatory & Permitting
Environmental permitting across two sovereign jurisdictions with conflicting marine protection standards could create duplicative review processes. National-level agencies may impose additional requirements regarding sensitive benthic habitats in the Strait of Gibraltar. Environmental organizations could file legal challenges at any stage.

- Impact: Litigation or additional permitting could add 1-3 years and incur €500 million-€1.5 billion in compliance costs, including redesigned tunnel segments or modified pillar configurations.
- Likelihood: Medium
- Severity: High
- Action: Proactively engage environmental NGOs and local communities in the design phase. Incorporate elevated pillar configurations that preserve benthic habitats as a design feature. Commission independent environmental baseline studies early.

## Risk 3 - Technical
The hybrid floating-pillar architecture is unprecedented at this scale and depth. At 100 meters below sea level, the interaction between buoyant tunnel segments, vertical pillar members, and hydrodynamic lift creates complex force dynamics that cannot be fully validated through existing models. The pillar-tunnel interface must simultaneously manage vertical buoyancy loads, lateral current forces, and dynamic storm loading while maintaining precise rail alignment.

- Impact: Structural miscalculations could cause tunnel segment misalignment or uncontrolled depth variation. A single failure could necessitate replacement of entire segments at €500 million-€2 billion per incident, with 6-18 months of redesign and reconstruction delay.
- Likelihood: Medium
- Severity: High
- Action: Invest in comprehensive scaled physical model testing in deep-water basins. Conduct finite element analysis validated against real-world oceanographic data. Build a fully instrumented prototype segment before mass production.

## Risk 4 - Technical
Buoyancy engineering at 100-meter depth presents extreme challenges. The variable-ballast system must function reliably for 20+ years in a corrosive saline environment with limited access. Mechanical failure could cause the tunnel to ascend beyond design depth (risking collision with surface shipping) or descend and contact the seabed (risking structural damage). Active ballast systems add mechanical complexity and failure points.

- Impact: Complete ballast failure could require emergency intervention costing €200-800 million per section, with potential total loss. Partial failure causing depth variance could compromise rail operations, requiring service suspension and repairs at €50-200 million per incident.
- Likelihood: Medium
- Severity: High
- Action: Design redundant ballast systems with passive fail-safe mechanisms defaulting to safe neutral buoyancy. Implement real-time depth monitoring with automated ballast correction. Conduct accelerated life-cycle testing under simulated 20-year saline exposure.

## Risk 5 - Technical
Corrosion and durability over a 20-year submerged lifespan is a fundamental challenge. The aggressive saline environment at 100 meters, combined with complex hybrid floating-pillar joints and articulated flexible connections, creates numerous pathways for saline ingress. Polymer encapsulation can be breached during installation or degraded by UV exposure; sacrificial anodes require periodic replacement in inaccessible locations; active cathodic protection depends on reliable power at depth.

- Impact: Unmanaged corrosion could reduce structural lifespan below the 20-year horizon, requiring premature rehabilitation costing €3-8 billion. Cathodic protection failure could accelerate degradation by 3-5x, potentially necessitating full replacement within 15 years.
- Likelihood: High
- Severity: High
- Action: Implement multi-layer corrosion protection combining polymer encapsulation with sacrificial anodes and active cathodic protection as redundant systems. Design accessible inspection and maintenance ports at regular intervals. Establish a dedicated corrosion monitoring program with predictive analytics.

## Risk 6 - Technical
Rail systems integration within a pressurized, submerged environment introduces unprecedented challenges. The sealed pressurized rail corridor must maintain terrestrial-grade track precision while subjected to external hydrostatic pressure of approximately 10 atmospheres at 100 meters depth. Thermal expansion from pressurization and temperature variations, combined with marine-induced vibration, creates complex stress distributions. Transition points between surface rail and the submerged section are critical failure points.

- Impact: Track geometry deviations could require speed restrictions, cutting projected revenue by 20-40%. Pressurization failures could endanger passenger safety. Transition zone failures could isolate sections, with remediation costs of €100-500 million per incident.
- Likelihood: Medium
- Severity: High
- Action: Develop and test a full-scale pressurized rail prototype under simulated deep-sea conditions. Design modular track sections with active compensation systems for thermal and pressure-induced deformation. Implement redundant pressurization systems with emergency depressurization protocols.

## Risk 7 - Financial
The €40 billion budget faces significant exposure to cost escalation over a 20-year construction horizon. Material costs for buoyant concrete, marine-grade steel, and specialized mooring systems are subject to commodity price volatility. Labor costs in offshore construction are projected to rise. The neutral third-party consortium governance model may introduce administrative overhead and decision-making delays that extend the timeline and increase carrying costs.

- Impact: A 10-15% cost overrun would represent €4-6 billion in additional funding. Cost overruns could trigger covenant breaches, investor withdrawal, or forced restructuring. Each additional year of construction could add €300-600 million in interest and overhead.
- Likelihood: High
- Severity: High
- Action: Establish a €4-6 billion contingency reserve. Use fixed-price contracts with penalty clauses for major suppliers. Implement rigorous cost tracking with quarterly reviews and automated escalation triggers. Structure financing with flexible disbursement tranches to accommodate timeline adjustments without triggering default.

## Risk 8 - Financial
Currency exchange rate risk between EUR (primary project currency) and MAD (Moroccan local currency) could erode the budget over 20 years. Morocco's local costs—including labor, permits, local materials, and coastal staging near Tangier—are denominated in MAD. Significant MAD depreciation against EUR would increase Moroccan-side costs, while MAD appreciation would increase costs for Spanish entities paying MAD-denominated contracts.

- Impact: Unhedged fluctuations of 10-20% could translate to €200 million-€800 million in additional costs. This is particularly acute during construction when Moroccan-side expenditures peak.
- Likelihood: Medium
- Severity: Medium
- Action: Implement a comprehensive currency hedging program using forward contracts and swaps covering at least 70% of projected MAD expenditures. Establish a dedicated treasury function for monthly FX exposure monitoring. Consider negotiating some Moroccan-side contracts in EUR.

## Risk 9 - Financial
The international consortium financing model introduces risks related to investor confidence and funding continuity. Tranche-based disbursements tied to geological and marine milestones create funding cliffs—if a milestone is delayed or disputed, subsequent funding may be withheld, creating cascading cash flow crises. Political shifts in either Spain or Morocco could alter government guarantees or development bank commitments.

- Impact: A funding gap of 6-12 months could halt construction, costing €500 million-€1 billion in idle workforce, equipment demobilization, and remobilization. Loss of government bond guarantees could increase the cost of capital by 200-400 basis points, adding €1-3 billion in total interest payments.
- Likelihood: Medium
- Severity: High
- Action: Diversify funding sources across sovereign bonds, development bank facilities, and private capital. Establish a reserve fund covering at least 12 months of operational costs. Negotiate milestone definitions with sufficient specificity and dispute resolution mechanisms to prevent funding withholding.

## Risk 10 - Environmental
Construction activities in the Strait of Gibraltar will disturb sensitive marine ecosystems, including cetacean migratory routes, benthic habitats, and water quality during dredging and pillar installation. The elevated pillar configuration still requires significant offshore platform construction and segment placement that generate noise, sediment plumes, and physical disruption.

- Impact: Environmental damage could trigger regulatory shutdowns, fines of €50-500 million, and mandatory remediation costing €200 million-€1 billion. Reputational damage could erode public support and political backing, potentially leading to project cancellation. Long-term ecosystem damage could affect fisheries and tourism.
- Likelihood: Medium
- Severity: High
- Action: Conduct comprehensive marine ecosystem baseline studies before construction. Implement seasonal construction restrictions during cetacean migration periods. Deploy real-time acoustic monitoring to detect and mitigate marine mammal disturbance. Establish an independent environmental oversight board with authority to halt construction if thresholds are exceeded.

## Risk 11 - Social
Offshore workforce resilience over a 20-year construction period presents profound human capital challenges. The isolated offshore environment at 100 meters depth, combined with the project's duration, creates extreme retention difficulties. Even with permanent residential platforms or generous equity incentives, specialized workers may leave due to burnout, family considerations, or better opportunities. High turnover forces repeated training cycles and erodes institutional knowledge precisely when it is most needed during critical installation phases.

- Impact: Workforce turnover exceeding 20% annually could add €500 million-€1.5 billion in repeated recruitment and training costs. Loss of institutional knowledge during critical phases could increase error rates by 15-30%, leading to rework, delays, and safety incidents. Safety incident frequency could increase by 25-50% during high turnover periods.
- Likelihood: High
- Severity: Medium
- Action: Implement a tiered retention strategy combining competitive compensation, family accommodation options, career progression pathways, and equity participation. Establish a knowledge management system that captures expertise independent of individual workers. Partner with maritime training institutions to create a continuous pipeline of qualified personnel.

## Risk 12 - Operational
Construction deployment using offshore floating platforms positioned directly above installation sites requires years of permitting and infrastructure setup before the first segment can be placed. These permanent offshore platforms are exposed to extreme weather conditions, including storms common in the Strait of Gibraltar. A single severe weather event during installation could damage platforms, displace tunnel segments, or injure personnel.

- Impact: Platform damage from a severe storm could cost €200-800 million to repair and cause 3-6 months of delay. Displaced or damaged tunnel segments could cost €100-500 million to recover and replace. Personnel safety incidents could result in project shutdowns, legal liability, and reputational damage.
- Likelihood: Medium
- Severity: High
- Action: Design offshore platforms to withstand 100-year storm events with redundant structural systems. Develop detailed weather monitoring and evacuation protocols. Pre-position emergency response equipment and vessels. Construct platforms during favorable weather windows with accelerated timelines.

## Risk 13 - Supply Chain
The supply chain depends on enormous quantities of specialized materials—buoyant concrete, marine-grade steel, mooring systems, and corrosion protection materials—delivered to remote offshore locations across international waters. A single mega-hub in southern Spain creates a catastrophic single point of failure. A port strike, facility fire, or logistics disruption at the hub could halt all construction simultaneously.

- Impact: A disruption lasting 2-4 months could cost €1-3 billion in idle costs, contract penalties, and accelerated recovery costs. Material shortages could force design compromises that reduce structural integrity or operational capability. Concentration at a single hub makes the project vulnerable to terrorism, piracy, or geopolitical disruption.
- Likelihood: Medium
- Severity: High
- Action: Establish a distributed supply chain with at least two regional fabrication yards (one in Spain, one in Morocco) for redundancy. Maintain a 3-6 month strategic inventory of critical materials at offshore staging areas. Develop pre-qualified alternative suppliers for all critical material categories. Implement blockchain-based supply chain tracking for real-time visibility.

## Risk 14 - Supply Chain
Transportation of massive buoyant concrete tunnel segments from fabrication yards to offshore installation sites across international waters presents unique logistical challenges. Towing operations at 100-meter depth are subject to weather windows, ocean currents, and maritime traffic in one of the world's busiest shipping lanes. The Strait of Gibraltar's narrow width and heavy shipping traffic create congestion and collision risks during segment transport.

- Impact: Transport delays could cascade through the construction schedule, with each week costing €10-30 million in idle workforce and equipment costs. A collision or loss of a tunnel segment during transport could result in total loss (€50-200 million) and potential environmental disaster. Maritime traffic delays could add weeks to transport schedules.
- Likelihood: Medium
- Severity: High
- Action: Develop dedicated maritime transport corridors with temporary traffic management agreements. Use purpose-built semi-submersible transport vessels with enhanced stability and positioning systems. Schedule transport during low-traffic periods and favorable weather windows. Maintain insurance coverage for total loss during transit.

## Risk 15 - Security
The tunnel infrastructure spanning international waters between two sovereign nations presents a high-value target for physical security threats, including sabotage, terrorism, or unauthorized access. The submerged structure at 100 meters depth is difficult to monitor and protect. Subsea structural surveillance systems relying on fiber-optic sensors, acoustic modems, and underwater communication infrastructure are vulnerable to cyber attacks that could disable monitoring or feed false data.

- Impact: A successful sabotage event could cause catastrophic structural failure with potential loss of life, environmental disaster, and total project loss valued at €40 billion. A cyber attack on surveillance systems could go undetected for weeks or months, allowing structural degradation to progress unchecked. Security breach remediation could cost €500 million-€2 billion and require complete system replacement.
- Likelihood: Low
- Severity: High
- Action: Implement a multi-layered physical security system including underwater barriers, surveillance drones, and naval patrols. Deploy encrypted, air-gapped communication networks for critical structural monitoring. Conduct regular penetration testing and cybersecurity audits. Establish a joint Spain-Morocco security coordination center.

## Risk 16 - Geopolitical
The project spans two sovereign nations with distinct political systems, legal frameworks, and strategic interests. Changes in government in either Spain or Morocco could fundamentally alter political commitment to the project, funding guarantees, or governance structure. Diplomatic tensions between the two nations—whether related to migration, territorial disputes, or broader geopolitical dynamics—could escalate to the point of project suspension or cancellation.

- Impact: A change in government or diplomatic crisis could result in project suspension lasting 1-3 years, costing €2-6 billion in carrying costs, contract termination penalties, and remobilization expenses. In the worst case, project cancellation could result in total loss of invested capital and significant reputational damage.
- Likelihood: Medium
- Severity: High
- Action: Embed the project in binding international treaties that survive changes in government. Establish a neutral dispute resolution mechanism with enforcement authority. Diversify political support by demonstrating economic benefits to constituencies in both nations. Maintain continuous diplomatic engagement at multiple levels of government.

## Risk 17 - Operational
Integration with existing surface rail networks on both the Spanish and Moroccan sides presents significant interface challenges. The tunnel must connect to existing high-speed rail infrastructure at Tarifa/Algeciras and Tangier, requiring modifications to existing stations, signaling systems, and power supply. The transition between surface rail and the submerged pressurized corridor introduces complex engineering and operational challenges.

- Impact: Interface failures could limit throughput capacity, reducing projected revenue by 15-30%. Signaling system incompatibilities could force operational speed restrictions. Station modifications could cost €200-800 million per terminal if not properly coordinated with existing infrastructure operators.
- Likelihood: Medium
- Severity: Medium
- Action: Establish joint interface teams with existing rail operators from the project's inception. Conduct comprehensive gauge, signaling, and power system compatibility studies. Design modular transition infrastructure that can be adapted to existing systems without requiring complete replacement.

## Risk 18 - Long-term Sustainability
The 20-year operational lifespan requires sustained maintenance funding, technological relevance, and structural integrity over an extremely long horizon. Maintenance costs for a submerged structure at 100 meters depth are orders of magnitude higher than terrestrial infrastructure. Technological obsolescence—particularly in rail systems, surveillance technology, and corrosion protection—could render the tunnel functionally outdated before its structural lifespan expires.

- Impact: Maintenance costs over 20 years could reach €3-8 billion, potentially exceeding initial construction cost projections if not properly budgeted. Technological obsolescence could require major system upgrades costing €1-4 billion. Failure to budget for long-term maintenance could lead to progressive structural degradation and eventual safety-critical failures.
- Likelihood: High
- Severity: Medium
- Action: Establish a dedicated maintenance trust fund capitalized at project inception, funded by a percentage of operational revenues. Design the tunnel with modular systems that can be upgraded without complete replacement. Commission a 20-year lifecycle cost analysis during the design phase to inform budget allocation.

## Risk summary
The most critical risks that could jeopardize this €40 billion, 20-year transoceanic submerged tunnel project are: (1) Cross-border governance and regulatory delays—the high likelihood of permitting delays, diplomatic misalignment, and environmental litigation could add 2-5 years and €2-5 billion in costs, potentially stalling the project before construction begins. (2) Technical uncertainty of the hybrid floating-pillar architecture—the unprecedented nature of this design at 100-meter depth creates medium-probability but high-severity structural failure risks that could cost billions and cause catastrophic safety incidents. (3) Financial sustainability over 20 years—cost escalation, currency risk, and funding continuity threats could erode the €40 billion budget envelope, with each additional year of construction adding €300-600 million in carrying costs. These three risks are interconnected: governance delays compound financial exposure, technical failures trigger cost overruns, and financial constraints limit the ability to address technical and governance challenges. The Builder's Foundation strategy mitigates some risks through its balanced approach, but the unprecedented scale and complexity of this project demand continuous risk monitoring and adaptive management throughout the 20-year horizon.

# Make Assumptions
## Question 1 - Budget Allocation and Contingency Reserves

- 10-15% contingency reserve (€4-6 billion) distributed across functional-subsystem phases; remaining 85-90% divided among pillar architecture, construction deployment, rail systems, environmental compliance, and operational readiness
- Currency hedging covers at least 70% of projected MAD-denominated expenditures; 30% remains exposed, potentially adding €200-800 million over 20 years
- Dedicated reserve fund covers 12 months of operational costs to buffer against tranche-based funding cliffs
- Financial Feasibility Assessment: 10-15% contingency aligns with megaproject benchmarks and addresses cost escalation and currency fluctuation risks; tranche-based financing tied to geological/marine milestones creates natural checkpoints but introduces funding cliff risks; overruns exceeding 15% may trigger covenant breaches with private equity investors; automated escalation triggers recommended at 5%, 10%, and 15% budget utilization

## Question 2 - Milestones and Phase Durations

- 20-year timeline divided into approximately 4-5 year phases per functional subsystem; weather-dependent windows account for 20-30% of annual working time in the Strait of Gibraltar
- Phase 1 (pillars and buoyancy): 6-7 years; Phase 2 (rail infrastructure): 5-6 years; Phase 3 (sealing, pressurization, commissioning): 4-5 years; 2-3 years schedule contingency remaining
- 6-12 month inter-phase buffers for validation testing, course correction, and stakeholder review
- Timeline & Milestones Assessment: functional-subsystem phasing aligns with Builder's Foundation strategy; Atlantic storm patterns can reduce effective construction time by 30-40% annually; Phase 1 overruns could cascade and compress subsequent phases beyond feasible limits; 6-12 month buffers may be insufficient if structural testing reveals fundamental design issues; CPM schedule with Monte Carlo simulation and go/no-go decision gates recommended

## Question 3 - Workforce Composition and Offshore Accommodation

- Peak construction requires 8,000-12,000 personnel; tiered rotational fly-in-fly-out model supplemented by permanent offshore residential platforms with family accommodation and amenities
- Training pipeline through maritime institutions in Spain and Morocco; equity-sharing and long-term performance bonuses incentivize retention; turnover targeted below 15% annually
- Resources & Personnel Assessment: workforce estimate consistent with comparable megaprojects but must account for 100-meter depth challenges; permanent housing creates fixed-cost burdens conflicting with consortium financing constraints; equity-sharing reduces investor returns creating governance tension; turnover exceeding 20% annually could add €500 million-€1.5 billion in costs and increase safety incidents by 25-50%; dynamic workforce model with 3,000-4,000 core permanent staff supplemented by rotational specialists recommended

## Question 4 - Consortium Governance and Legal Frameworks

- Neutral third-party consortium established through bilateral treaty ratified by Spanish and Moroccan parliaments; technical decision-making vested in consortium led by neutral engineering firm; both governments retain financial oversight and veto rights on major budget decisions
- Dispute resolution through binding international arbitration under ICC rules; dedicated bilateral diplomatic task force with pre-negotiated framework agreements accelerates permitting; transboundary environmental impact assessment negotiated through IMO with pre-agreed timeline and fallback arbitration
- Governance & Regulations Assessment: neutral consortium model resolves cross-border governance challenge but faces establishment risks; parliamentary ratification could be delayed by political shifts or diplomatic tensions; IMO environmental assessment alone could exceed five years; ICC enforcement across sovereign borders remains challenging if one party refuses compliance; governance stability directly tied to investor confidence; binding commitments with penalty clauses and preliminary IMO engagement within first 12 months recommended

## Question 5 - Safety Protocols and Emergency Response

- Multi-layered safety framework including real-time structural monitoring with automated shutdown protocols triggered by micro-fracture detection or depth deviation beyond tolerance limits
- Dedicated emergency response vessels on 24/7 standby within 30 minutes of tunnel corridor; pressurized corridor evacuation systems with redundant pathways and emergency depressurization protocols
- Comprehensive insurance program covering structural failure (€500 million-€2 billion per incident), environmental damage, and personnel incidents; safety incident frequency target below 0.5 per 200,000 work hours
- Safety & Risk Management Assessment: pressurized submerged environment complicates evacuation due to depth, pressure, and limited access; automated shutdown protocols depend on sensor reliability—false positives cost €10-30 million per incident, false negatives allow unchecked structural degradation; saturation diving limits are 300-500 meters but sustained presence at 100 meters requires specialized decompression; pressurization failure risk is existential for passenger safety; insurers may demand rigorous structural validation proof before offering coverage; annual full-scale emergency simulations, joint Spain-Morocco emergency coordination center, and third-party safety certification before each phase transition recommended

## Question 6 - Environmental Baseline Studies and Mitigation

- Comprehensive marine ecosystem baseline studies conducted 2-3 years before construction: cetacean migration patterns, benthic habitat mapping, water quality parameters, sediment dynamics across Strait of Gibraltar corridor
- Seasonal construction restrictions during cetacean migration periods (spring and autumn); real-time acoustic monitoring for marine mammal disturbance detection and mitigation; elevated pillar configuration preserves benthic habitats underneath tunnel
- Independent environmental oversight board with authority to halt construction if thresholds exceeded; ecosystem restoration program creating artificial reef structures along tunnel corridor
- Environmental Impact Assessment: elevated pillar design integrates habitat preservation but does not eliminate all impact; offshore construction generates noise, sediment plumes, and physical disruption affecting cetacean migration; seasonal restrictions reduce already limited weather windows by additional 15-20%; oversight board provides critical check but could become bottleneck; artificial reefs take years to establish functional ecosystems; environmental litigation remains significant risk; baseline studies commissioned immediately upon approval, pre-construction environmental covenants, and €200-500 million marine mitigation fund recommended

## Question 7 - Stakeholder Engagement Strategy

- Multi-tiered engagement framework: bilateral government coordination committees (quarterly), quarterly investor briefings with transparent financial reporting, community liaison offices in Tarifa and Tangier, structured dialogue with environmental NGOs through advisory panels, public transparency portal with real-time project updates and environmental monitoring data
- Dedicated bilingual (Spanish/Arabic) communications teams; community benefit agreements guaranteeing local hiring quotas and infrastructure improvements
- Stakeholder Involvement Assessment: stakeholder landscape spans two sovereign governments, international financial institutions, local communities, environmental organizations, maritime authorities, and general public; community expectations may exceed project delivery capacity; transparency portal builds trust but creates reputational risk if negative developments are disclosed before mitigation is ready; environmental NGO panels provide early warning but can slow decision-making; stakeholder sentiment directly tied to investor confidence and funding stability; stakeholder advisory council, annual satisfaction surveys, and crisis communication protocols recommended

## Question 8 - Operational Systems and Technology Infrastructure

- Sealed pressurized rail corridor with climate-controlled track beds maintaining terrestrial-grade precision under 10 atmospheres of external hydrostatic pressure; redundant ventilation and pressurization systems powered by offshore tidal energy generators
- Dense fiber-optic acoustic sensor mesh along entire tunnel length for continuous structural surveillance; autonomous underwater vehicles on fixed patrol routes for periodic inspection; multi-layer corrosion protection combining polymer encapsulation, sacrificial anodes, and active cathodic protection
- Dedicated maintenance trust fund capitalized at project inception covering 20-year lifecycle costs estimated at €3-8 billion; modular system design enabling upgrades without complete replacement
- Operational Systems Assessment: most technologically demanding project aspect; sealed corridor must maintain track precision against thermal expansion, marine-induced vibration, and saltwater corrosion; pressurization system failure is existential requiring redundant systems; fiber-optic sensors require complex waterproof splicing at extreme depths and resilient underwater communication; multi-layer corrosion protection adds significant upfront costs and maintenance complexity—polymer encapsulation can be breached during installation, sacrificial anodes require inaccessible replacement, active cathodic protection depends on reliable power; €3-8 billion maintenance estimate must be factored into overall financial model; modular design may introduce interface vulnerabilities; full-scale pressurized rail prototype tested under simulated deep-sea conditions, dedicated operational technology research program, and 20-year lifecycle cost analysis validation during design phase recommended


# Distill Assumptions
# Project Overview

- A €40 billion, 20-year pillar-supported transoceanic submerged tunnel connecting Spain and Morocco at 100m depth for high-speed rail.
- The 20-year timeline uses functional-subsystem phasing (pillars/buoyancy, then rail, then sealing), approximately 4-5 years per phase, with weather windows consuming 20-30% of annual working time.
- The €40 billion budget includes a 10-15% contingency reserve (€4-6 billion), a 12-month operational reserve fund, and currency hedging covering 70% of MAD-denominated expenditures.

# Construction & Workforce

- Peak construction requires 8,000-12,000 personnel using a tiered rotational fly-in-fly-out model supplemented by permanent offshore residential platforms.
- A neutral third-party consortium led by an engineering firm holds technical decision-making authority while Spain and Morocco retain financial oversight and veto rights.

# Governance & Legal Framework

- A bilateral treaty ratified by both Spanish and Moroccan parliaments establishes governance, with ICC arbitration for dispute resolution and a dedicated diplomatic task force for permitting.
- Transboundary environmental assessment is negotiated through the IMO with a pre-agreed timeline and fallback arbitration.

# Financing

- Tranche-based financing disbursements are tied to geological and marine milestones from multilateral government bonds, public-private partnerships, and development bank funds.

# Environmental Considerations

- Elevated pillar configurations preserve benthic habitats.
- Comprehensive marine ecosystem baseline studies covering cetacean migration, benthic habitats, and water quality are conducted 2-3 years before construction begins.

# Technical Design & Engineering

- A sealed pressurized rail corridor maintains terrestrial-grade track precision under 10 atmospheres of external hydrostatic pressure with redundant ventilation systems.
- Multi-layer corrosion protection combines polymer encapsulation, sacrificial anodes, and active cathodic protection powered by offshore tidal energy generators.
- Real-time structural surveillance via fiber-optic acoustic sensors and autonomous underwater vehicles enables automated shutdown protocols and continuous micro-fracture detection.

# Maintenance & Lifecycle

- A €3-8 billion maintenance trust fund capitalized at project inception covers 20-year lifecycle costs including corrosion protection, structural surveillance, and operational systems.

# Safety & Emergency Response

- Safety framework includes 24/7 emergency response vessels within 30 minutes, pressurized corridor evacuation systems, and insurance covering €500 million to €2 billion per incident.

# Stakeholder Engagement

- Multi-tiered stakeholder engagement spans both governments, international investors, communities in Tarifa and Tangier, environmental NGOs, and the general public.


# Review Assumptions
## Domain of the Expert Reviewer
Megaproject Infrastructure Planning & Risk Management

## Domain-Specific Considerations

- Transboundary infrastructure governance across sovereign nations
- Deep-sea structural engineering at unprecedented scale and depth
- Seismic and geotechnic risk in the Azores-Gibraltar seismic zone
- Marine ecosystem sensitivity and cetacean migration corridor impacts
- Long-term operational sustainability of pressurized submerged systems
- Currency and financing risk across EUR/MAD dual-currency operations
- Maritime traffic integration in one of the world's busiest shipping lanes
- 20-year lifecycle cost modeling and decommissioning obligations

## Issue 1 - Absence of Seismic and Detailed Geotechnic Risk Assessment
The project assumes pillar anchoring at 100m depth in clay, sand, and weathered bedrock, but no geotechnical survey data, seismic hazard analysis, or fault line mapping is referenced. The Strait of Gibraltar sits near the Azores-Gibraltar seismic transform fault, one of Europe's most active zones. Without site-specific seismic parameters (peak ground acceleration, liquefaction potential, fault rupture probability), the entire structural architecture rests on unvalidated assumptions.

Recommendation: Commission a comprehensive geotechnical and seismic risk assessment including deep-sea borehole sampling, 3D seismic reflection profiling, and probabilistic seismic hazard analysis (PSHA) calibrated to the Azores-Gibraltar fault zone. Require all designs to incorporate site-specific seismic loading cases with minimum 2% probability of exceedance in 50 years. Establish a geotechnical validation gate before construction mobilization.

Sensitivity: A moderate earthquake (M5.5-6.5, 10% probability in 20 years) could cause €3-8 billion in repairs and 12-24 months of reconstruction. A major event (M7.0+, 2% probability) could cause catastrophic failure with total loss of segments valued at €10-20 billion. Seismic mitigation (deepened foundations, seismic joints) could add €500 million-€1.5 billion but reduce expected annual loss by 60-80%.

## Issue 2 - Missing Energy Supply and Operational Power Infrastructure Plan
The project specifies massive energy demands—pressurized rail climate control, ventilation, structural surveillance, cathodic protection, buoyancy adjustment, and rail propulsion—but no energy supply strategy is articulated. At 100m depth, terrestrial grid connection requires submarine cables of extraordinary length and capacity. Offshore tidal generators alone are insufficient for full operational load. No mention of energy storage, grid interconnection, backup power, or total operational energy budget.

Recommendation: Conduct a comprehensive energy audit quantifying total demand (estimated 50-100 MW continuous). Develop a hybrid strategy combining submarine HVDC cable connections to Spanish and Moroccan grids, offshore wind/tidal generation with battery storage, and diesel backup. Establish a dedicated energy infrastructure budget of €1-2 billion. Negotiate energy supply agreements with both national grid operators before construction begins.

Sensitivity: Without reliable power, the tunnel cannot operate, resulting in zero revenue and €500 million-€1 billion in annual lost revenue. Energy cost overruns of 30-50% could add €300-600 million to 20-year operational costs, reducing ROI by 2-4 percentage points. A submarine HVDC cable failure could cause complete shutdown, costing €50-100 million per incident.

## Issue 3 - Inadequate Maritime Traffic Integration and Collision Risk Management
The Strait of Gibraltar sees over 100,000 vessel transits annually, including massive tankers and container ships. No detailed maritime traffic management plan, collision risk assessment, or navigational safety framework is provided. The tunnel structure could create current deflection effects altering shipping lane conditions. The assumption that dedicated maritime transport corridors can be established without disrupting this critical chokepoint is dangerously optimistic.

Recommendation: Commission a comprehensive maritime traffic impact study including computational fluid dynamics modeling of tunnel-induced current changes, collision probability analysis, and a Temporary Traffic Management Plan (TTMP) with international authorities (IMO, Strait of Gibraltar Joint Coordination Center). Install AIS monitoring and collision avoidance systems. Negotiate permanent shipping lane adjustments and establish a 24/7 maritime traffic control center.

Sensitivity: A collision could cause €500 million-€2 billion in damage, potential environmental disaster, and 6-12 months of repair shutdown costing €1-3 billion in lost revenue. Current deflection could increase wave heights by 5-15%, increasing collision risk by 10-30%. Failure to secure shipping lane agreements could halt construction transport, adding 6-12 months and €500 million-€1 billion in costs.

## Issue 4 - No Decommissioning and End-of-Life Plan
The project specifies a 20-year operational lifespan but provides zero detail on end-of-life. Decommissioning a submerged tunnel at 100m depth across international waters between two nations is unprecedented. Who bears the cost? How are materials disposed of without further marine damage? What happens to seabed pillars? The €3-8 billion maintenance trust fund addresses operational costs but not decommissioning, creating a massive unfunded liability.

Recommendation: Develop a comprehensive decommissioning plan during design, including environmental remediation protocols, material recovery strategies, and seabed restoration requirements. Establish a decommissioning reserve fund of €2-4 billion capitalized at project inception. Negotiate decommissioning obligations in the bilateral treaty and IMO framework. Conduct a full lifecycle assessment (LCA) of construction and decommissioning environmental footprint.

Sensitivity: Unplanned decommissioning costs could reach €5-15 billion depending on method. Failure to plan could result in the tunnel becoming an artificial reef with unknown ecological consequences, triggering environmental liability claims of €1-5 billion. Regulatory requirements could change over 20 years, imposing unanticipated standards.

## Issue 5 - Rail Gauge and Systems Interoperability Gap
Spain uses Iberian gauge (1,668mm) while Morocco uses standard gauge (1,435mm). The project assumes seamless high-speed rail connectivity without addressing fundamental gauge incompatibility. Signaling systems, electrification standards (Spain: 25kV AC, Morocco: 3kV DC), and safety protocols also differ. "Dual-mode rail" is mentioned but not committed to. This fundamentally determines whether the tunnel achieves its core purpose.

Recommendation: Mandate a unified gauge standard (likely standard gauge 1,435mm) for the tunnel and both connecting networks. Conduct a comprehensive systems interoperability study covering gauge, signaling (ERTMS), electrification, and safety protocols. Budget €200-500 million for gauge transition infrastructure. Require both national rail operators to commit to a unified standard before construction begins.

Sensitivity: Failure to resolve gauge incompatibility would require passenger train changes, potentially cutting ridership by 30-50% and reducing revenue by €500 million-€1.5 billion annually over 20 years. Dual-gauge solutions add €50-100 million per year in maintenance. Signaling incompatibility could force speed restrictions reducing throughput by 20-40%.

## Issue 6 - Climate Change and Long-Term Oceanographic Projections Absent
The project is designed for a 20-year lifespan but makes no reference to climate change projections—sea level rise, ocean current changes, storm intensity increases, or water temperature changes. The Strait of Gibraltar is vulnerable to Atlantic climate variability. Sea levels may rise 0.3-0.6m by 2043 (IPCC projections). These changes could alter hydrodynamic forces, buoyancy equilibrium, and corrosion environment. The design assumes static oceanographic conditions, which is scientifically indefensible.

Recommendation: Integrate IPCC climate projections (SSP2-4.5 and SSP5-8.5) into structural design, incorporating sea level rise of 0.3-0.6m, increased storm intensity of 10-20%, and potential ocean current changes into hydrodynamic load models. Design adaptive buoyancy systems to compensate for sea level changes. Budget €200-400 million for climate adaptation. Commission ongoing oceanographic monitoring to update design parameters every 5 years.

Sensitivity: Unaccounted sea level rise of 0.5m could alter depth profile and buoyancy equilibrium, requiring modifications costing €1-3 billion. Increased storm intensity of 20% could increase hydrodynamic forces by 15-25%, risking damage costing €500 million-€2 billion per severe event. Without climate adaptation, design life could be reduced from 20 to 12-15 years, requiring premature rehabilitation costing €3-6 billion.

## Issue 7 - Water Intrusion and Catastrophic Flooding Protocols Missing
The project describes a pressurized sealed rail corridor within a submerged tunnel but no emergency flooding protocol for hull breach scenarios. At 100m depth with 10 atmospheres of external pressure, even a small breach could flood at catastrophic rates. Emergency depressurization protocols for the rail corridor are mentioned, but the far more fundamental risk of seawater intrusion into the tunnel structure itself is unaddressed. With thousands of passengers submerged, flooding represents an existential safety risk.

Recommendation: Develop a comprehensive flooding risk management plan including: (1) redundant hull integrity monitoring with automated breach detection; (2) emergency flooding containment compartments within the tunnel design; (3) rapid-deployment flood barriers at tunnel entrances; (4) passenger evacuation protocols including specialized submersible rescue vehicles; (5) insurance coverage specifically for flooding events. Conduct full-scale flooding simulation exercises annually. Budget €100-300 million for flooding prevention and response infrastructure.

Sensitivity: A major flooding event could result in total loss of tunnel sections valued at €5-15 billion, potential loss of life creating unlimited liability, and permanent project cancellation. A minor breach requiring section isolation could cost €200-500 million in repairs and 3-6 months of partial shutdown, reducing annual revenue by 15-30%. Absence of flooding protocols could make the project uninsurable, preventing financing.

## Review Conclusion
The three most critical issues threatening this €40 billion project are: (1) the complete absence of seismic and detailed geotechnic risk assessment, which could invalidate the entire structural design and expose the project to €3-20 billion in earthquake damage; (2) the missing energy supply infrastructure plan, without which the tunnel cannot operate, resulting in zero revenue; and (3) the inadequate maritime traffic integration strategy, where a collision could cause €500 million-€2 billion in damage and halt construction. These three issues are interconnected—seismic events could damage energy infrastructure, and maritime incidents could disrupt energy supply logistics. The project's unprecedented scale, depth, and cross-border complexity demand that these foundational gaps be addressed before any construction begins. Additionally, the absence of decommissioning plans, rail gauge incompatibility, climate change projections, and flooding protocols represent significant secondary risks that compound the primary issues. The Builder's Foundation strategy provides a sound conceptual framework, but it is built on assumptions lacking the geotechnical, energy, and maritime specificity required for a project of this magnitude and risk profile.