# Governance Audit


## Audit - Corruption Risks

- Bribery of regulatory officials in Spain or Morocco to expedite permit approvals or overlook non-compliance issues.
- Kickbacks from construction companies or suppliers in exchange for being awarded contracts.
- Conflicts of interest involving project personnel with financial ties to companies bidding for contracts.
- Misuse of confidential project information for personal gain or to benefit favored contractors.
- Nepotism in hiring practices, favoring unqualified relatives or friends for key project positions.

## Audit - Misallocation Risks

- Inflated invoices from contractors or suppliers, with the excess funds diverted for personal use.
- Double billing for services or materials, with the same expenses claimed multiple times.
- Misuse of project funds for unauthorized expenses, such as personal travel or entertainment.
- Inefficient allocation of resources, leading to delays and cost overruns.
- Poor record-keeping and documentation, making it difficult to track project expenses and identify potential fraud.

## Audit - Procedures

- Conduct regular internal audits of project finances and contracts, at least quarterly, with a focus on high-value transactions and potential conflicts of interest. Responsibility: Internal Audit Department.
- Engage an independent external auditor to conduct an annual audit of the project's financial statements and compliance with relevant regulations. Responsibility: Audit Committee.
- Implement a whistleblower mechanism that allows employees and stakeholders to report suspected fraud or corruption anonymously. Responsibility: Ethics Officer.
- Establish clear contract review thresholds, requiring multiple levels of approval for contracts exceeding a certain value. Responsibility: Procurement Department.
- Conduct periodic compliance checks to ensure adherence to environmental regulations and ethical guidelines. Responsibility: Compliance Officer.

## Audit - Transparency Measures

- Publish a project progress dashboard online, updated monthly, showing key milestones, budget expenditures, and risk assessments.
- Publish minutes of key decision-making meetings of the binational authority overseeing the project.
- Establish a publicly accessible register of all contracts awarded, including the names of the contractors, the value of the contracts, and the selection criteria used.
- Implement a whistleblower protection policy that ensures the confidentiality and protection of individuals who report suspected wrongdoing.
- Make relevant project policies and reports, such as environmental impact assessments and risk management plans, available to the public online.

# Internal Governance Bodies

### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and direction for this large-scale, high-risk, and politically sensitive infrastructure project.  Ensures alignment with strategic goals and effective risk management.

**Responsibilities:**

- Approve project scope, budget, and schedule baselines.
- Provide strategic direction and guidance to the Project Management Office.
- Review and approve major project changes and deviations from the baseline plan (above €5 million).
- Oversee risk management and mitigation strategies for strategic risks.
- Resolve strategic conflicts and escalate issues as needed.
- Monitor project performance against strategic objectives.
- Approve key strategic decisions, including those related to the Funding Model, Geopolitical Risk Management, and International Collaboration Framework.

**Initial Setup Actions:**

- Finalize Terms of Reference and membership.
- Establish decision-making protocols and escalation paths.
- Define financial thresholds for strategic decisions.
- Review and approve the initial project plan and risk register.

**Membership:**

- Senior representatives from the Spanish Ministry of Transport, Mobility and Urban Agenda
- Senior representatives from the Moroccan Ministry of Equipment, Transport, Logistics and Water
- Representative from the Sovereign Wealth Fund Consortium (independent)
- Independent Expert in Submerged Tunnel Construction
- Project Director
- Chief Financial Officer

**Decision Rights:** Strategic decisions related to project scope, budget, schedule, and risk management. Approval of changes exceeding €5 million. Approval of key strategic decisions as defined in the strategic decisions document.

**Decision Mechanism:** Decisions are made by majority vote. In the event of a tie, the representative from the Sovereign Wealth Fund Consortium will cast the deciding vote.

**Meeting Cadence:** Quarterly, with ad-hoc meetings as needed for critical decisions.

**Typical Agenda Items:**

- Review of project progress against plan.
- Review of project financials and budget performance.
- Review of risk register and mitigation strategies.
- Discussion and approval of proposed changes to project scope, budget, or schedule.
- Escalated issues from the Project Management Office or other governance bodies.
- Review of compliance reports.

**Escalation Path:** Escalate to the Ministers of Transport of Spain and Morocco for unresolved issues or decisions exceeding the Committee's authority.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages the day-to-day execution of the project, ensuring adherence to the project plan, budget, and schedule. Provides operational risk management and support to the project team.

**Responsibilities:**

- Develop and maintain the project plan, budget, and schedule.
- Manage project resources and track project progress.
- Identify, assess, and manage operational risks.
- Implement project management processes and procedures.
- Provide regular project status reports to the Project Steering Committee.
- Manage contracts and procurement activities.
- Ensure compliance with project requirements and standards.
- Manage day-to-day stakeholder communication.

**Initial Setup Actions:**

- Establish project management processes and tools.
- Develop the project plan, budget, and schedule.
- Establish a risk management framework.
- Recruit and train project team members.

**Membership:**

- Project Director
- Project Manager
- Chief Engineer
- Chief Financial Officer
- Risk Manager
- Stakeholder Engagement Manager
- Compliance Officer

**Decision Rights:** Operational decisions related to project execution, resource allocation, and risk management within the approved budget and schedule. Approval of changes up to €5 million.

**Decision Mechanism:** Decisions are made by the Project Director, with input from the PMO team. Conflicts are resolved through discussion and consensus. If consensus cannot be reached, the Project Director makes the final decision.

**Meeting Cadence:** Weekly.

**Typical Agenda Items:**

- Review of project progress against plan.
- Review of project financials and budget performance.
- Review of risk register and mitigation strategies.
- Discussion and resolution of project issues.
- Approval of change requests (below €5 million).
- Planning for upcoming activities.

**Escalation Path:** Escalate to the Project Steering Committee for issues exceeding the PMO's authority or requiring strategic guidance.
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and assurance on critical engineering aspects of the project, ensuring the tunnel's structural integrity, safety, and long-term performance.

**Responsibilities:**

- Review and approve technical designs and specifications.
- Provide expert advice on technical challenges and risks.
- Assess the feasibility and reliability of proposed technologies.
- Monitor the quality of construction and materials.
- Conduct independent technical audits and assessments.
- Advise on technical risk mitigation strategies.
- Ensure compliance with relevant technical standards and regulations.

**Initial Setup Actions:**

- Finalize Terms of Reference and membership.
- Establish communication protocols with the PMO.
- Review key technical documents and designs.
- Identify critical technical risks and challenges.

**Membership:**

- Independent Expert in Submerged Tunnel Construction (Chair)
- Geotechnical Engineer
- Structural Engineer
- Marine Engineer
- Materials Scientist
- Seismic Expert
- Representative from the Chief Engineer's Office

**Decision Rights:** Technical approval of designs, specifications, and construction methods.  Authority to recommend changes to technical aspects of the project to ensure safety and performance.

**Decision Mechanism:** Decisions are made by consensus. If consensus cannot be reached, the Chair makes the final decision, based on expert opinion and technical evidence.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical technical reviews.

**Typical Agenda Items:**

- Review of technical designs and specifications.
- Discussion of technical challenges and risks.
- Assessment of proposed technologies and materials.
- Review of construction quality and compliance.
- Review of technical audit reports.
- Discussion of technical risk mitigation strategies.

**Escalation Path:** Escalate to the Project Steering Committee for unresolved technical issues or decisions with significant strategic implications.
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures the project adheres to the highest ethical standards and complies with all relevant regulations, including GDPR, environmental regulations, and anti-corruption laws.  Provides independent oversight and assurance on ethical and compliance matters.

**Responsibilities:**

- Develop and implement an ethics and compliance program.
- Monitor compliance with relevant laws, regulations, and ethical standards.
- Investigate allegations of fraud, corruption, and other ethical violations.
- Provide training and guidance on ethics and compliance matters.
- Conduct regular compliance audits and assessments.
- Report compliance issues to the Project Steering Committee.
- Ensure compliance with GDPR and data privacy regulations.
- Oversee environmental compliance and sustainability initiatives.

**Initial Setup Actions:**

- Finalize Terms of Reference and membership.
- Develop an ethics and compliance program.
- Establish reporting mechanisms for ethical violations.
- Conduct a risk assessment to identify potential compliance issues.

**Membership:**

- Independent Ethics Officer (Chair)
- Legal Counsel
- Compliance Officer
- Representative from the Internal Audit Department
- Representative from the Stakeholder Engagement Team
- Data Protection Officer

**Decision Rights:** Authority to investigate ethical violations and recommend corrective actions.  Authority to halt project activities that violate ethical standards or compliance requirements.  Approval of ethics and compliance policies and procedures.

**Decision Mechanism:** Decisions are made by majority vote. In the event of a tie, the Ethics Officer casts the deciding vote.

**Meeting Cadence:** Monthly.

**Typical Agenda Items:**

- Review of compliance reports.
- Discussion of ethical issues and concerns.
- Investigation of alleged ethical violations.
- Review of ethics and compliance policies and procedures.
- Training on ethics and compliance matters.
- Review of GDPR compliance activities.
- Review of environmental compliance activities.

**Escalation Path:** Escalate to the Project Steering Committee for unresolved ethical or compliance issues or decisions with significant strategic implications.  Serious violations are reported to the relevant regulatory authorities.
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Manages communication and engagement with all stakeholders, including local communities, environmental groups, and regulatory bodies. Ensures that stakeholder concerns are addressed and that the project is implemented in a socially responsible manner.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct regular consultations with stakeholders.
- Address stakeholder concerns and grievances.
- Provide regular project updates to stakeholders.
- Manage media relations and public communications.
- Monitor stakeholder perceptions and attitudes.
- Ensure that stakeholder feedback is incorporated into project decisions.
- Manage community relations and social responsibility initiatives.

**Initial Setup Actions:**

- Finalize Terms of Reference and membership.
- Develop a stakeholder engagement plan.
- Identify key stakeholders and their concerns.
- Establish communication channels with stakeholders.

**Membership:**

- Stakeholder Engagement Manager (Chair)
- Community Relations Officer
- Environmental Liaison Officer
- Public Relations Officer
- Representative from the Spanish Government
- Representative from the Moroccan Government
- Representative from Local Communities (Spain)
- Representative from Local Communities (Morocco)

**Decision Rights:** Authority to make decisions related to stakeholder engagement activities.  Authority to recommend changes to project plans to address stakeholder concerns.  Approval of communication materials and public statements.

**Decision Mechanism:** Decisions are made by consensus. If consensus cannot be reached, the Stakeholder Engagement Manager makes the final decision, based on stakeholder feedback and project objectives.

**Meeting Cadence:** Bi-weekly.

**Typical Agenda Items:**

- Review of stakeholder engagement activities.
- Discussion of stakeholder concerns and grievances.
- Review of communication materials and public statements.
- Planning for upcoming stakeholder consultations.
- Monitoring of stakeholder perceptions and attitudes.
- Review of community relations and social responsibility initiatives.

**Escalation Path:** Escalate to the Project Steering Committee for unresolved stakeholder issues or decisions with significant strategic implications.

# Governance Implementation Plan

### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Structure Defined

### 2. Project Manager circulates Draft SteerCo ToR v0.1 for review by Senior representatives from the Spanish Ministry of Transport, Mobility and Urban Agenda and the Moroccan Ministry of Equipment, Transport, Logistics and Water.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager incorporates feedback and finalizes the Project Steering Committee ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Project Sponsor formally appoints the Project Steering Committee Chair (Senior representative from either the Spanish Ministry of Transport, Mobility and Urban Agenda or the Moroccan Ministry of Equipment, Transport, Logistics and Water).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Sponsor formally appoints Project Steering Committee members.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final SteerCo ToR v1.0
- SteerCo Chair Appointed

### 6. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- All SteerCo Members Appointed

### 7. Hold the initial Project Steering Committee kick-off meeting to review ToR, decision-making processes, and initial project plan.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- SteerCo Members Appointed
- SteerCo ToR Approved

### 8. Project Director establishes project management processes and tools for the Project Management Office (PMO).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Project Management Process Documentation
- List of Project Management Tools

**Dependencies:**

- Project Plan Approved

### 9. Project Director develops the initial project plan, budget, and schedule for the PMO.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Initial Project Plan
- Budget
- Schedule

**Dependencies:**

- Project Management Process Documentation

### 10. Project Director establishes a risk management framework for the PMO.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Risk Management Framework

**Dependencies:**

- Initial Project Plan

### 11. Project Director recruits and trains project team members for the PMO.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Project Team Members Recruited
- Training Materials

**Dependencies:**

- Risk Management Framework

### 12. Project Director schedules the initial PMO kick-off meeting.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- PMO Team Members Recruited

### 13. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- PMO Team Members Recruited
- Project Management Process Documentation

### 14. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Structure Defined

### 15. Project Manager circulates Draft TAG ToR v0.1 for review by the Chief Engineer's Office.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft TAG ToR v0.1

### 16. Project Manager incorporates feedback and finalizes the Technical Advisory Group ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Final TAG ToR v1.0

**Dependencies:**

- Feedback Summary

### 17. Project Sponsor formally appoints the Independent Expert in Submerged Tunnel Construction as the Technical Advisory Group Chair.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final TAG ToR v1.0

### 18. Technical Advisory Group Chair, in consultation with the Project Director, formally appoints Technical Advisory Group members.

**Responsible Body/Role:** Technical Advisory Group Chair

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final TAG ToR v1.0
- TAG Chair Appointed

### 19. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- All TAG Members Appointed

### 20. Hold the initial Technical Advisory Group kick-off meeting to review ToR, communication protocols, and key technical documents.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- TAG Members Appointed
- TAG ToR Approved

### 21. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Structure Defined

### 22. Project Manager circulates Draft ECC ToR v0.1 for review by Legal Counsel and Compliance Officer.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft ECC ToR v0.1

### 23. Project Manager incorporates feedback and finalizes the Ethics & Compliance Committee ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Final ECC ToR v1.0

**Dependencies:**

- Feedback Summary

### 24. Project Sponsor formally appoints the Independent Ethics Officer as the Ethics & Compliance Committee Chair.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final ECC ToR v1.0

### 25. Ethics & Compliance Committee Chair, in consultation with the Project Director, formally appoints Ethics & Compliance Committee members.

**Responsible Body/Role:** Ethics & Compliance Committee Chair

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final ECC ToR v1.0
- ECC Chair Appointed

### 26. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- All ECC Members Appointed

### 27. Hold the initial Ethics & Compliance Committee kick-off meeting to review ToR, reporting mechanisms, and conduct a risk assessment.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- ECC Members Appointed
- ECC ToR Approved

### 28. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft SEG ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Structure Defined

### 29. Project Manager circulates Draft SEG ToR v0.1 for review by the Stakeholder Engagement Manager.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SEG ToR v0.1

### 30. Project Manager incorporates feedback and finalizes the Stakeholder Engagement Group ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Final SEG ToR v1.0

**Dependencies:**

- Feedback Summary

### 31. Project Director formally appoints the Stakeholder Engagement Manager as the Stakeholder Engagement Group Chair.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SEG ToR v1.0

### 32. Stakeholder Engagement Group Chair, in consultation with the Project Director, formally appoints Stakeholder Engagement Group members.

**Responsible Body/Role:** Stakeholder Engagement Group Chair

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final SEG ToR v1.0
- SEG Chair Appointed

### 33. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- All SEG Members Appointed

### 34. Hold the initial Stakeholder Engagement Group kick-off meeting to review ToR, develop a stakeholder engagement plan, and identify key stakeholders.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- SEG Members Appointed
- SEG ToR Approved

# Decision Escalation Matrix

**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic oversight and approval at a higher level.
Negative Consequences: Potential budget overruns, project delays, and financial instability.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: Materialization of a critical risk (e.g., geopolitical instability, major technical failure) requires strategic reassessment and resource allocation beyond the PMO's capacity.
Negative Consequences: Project failure, significant financial losses, and reputational damage.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: Inability of the PMO to reach a consensus on a key vendor selection necessitates a higher-level decision to ensure project progress.
Negative Consequences: Project delays, increased costs, and potential legal challenges.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote on Scope Change Request
Rationale: Significant alterations to the project scope require strategic evaluation and approval to ensure alignment with project objectives and budget.
Negative Consequences: Scope creep, budget overruns, and project delays.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Steering Committee
Rationale: Allegations of ethical violations require independent investigation and appropriate action to maintain project integrity and reputation.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Unresolved Technical Design Conflict**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Decision based on TAG Recommendation
Rationale: If the Technical Advisory Group cannot resolve a critical technical design conflict, the Steering Committee must provide strategic direction.
Negative Consequences: Compromised tunnel integrity, safety risks, and potential project failure.

**Significant Stakeholder Opposition**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Stakeholder Engagement Plan and Mitigation Strategies
Rationale: If the Stakeholder Engagement Group cannot mitigate significant opposition from key stakeholders, the Steering Committee must intervene to ensure project viability.
Negative Consequences: Project delays, legal challenges, and reputational damage.

# Monitoring Progress

### 1. Tracking Key Performance Indicators (KPIs) against Project Plan
**Monitoring Tools/Platforms:**

  - Project Management Software Dashboard
  - KPI Tracking Spreadsheet
  - Monthly Progress Reports

**Frequency:** Monthly

**Responsible Role:** Project Manager

**Adaptation Process:** PMO proposes adjustments via Change Request to Steering Committee

**Adaptation Trigger:** KPI deviates >10% from baseline, or significant schedule slippage

### 2. Regular Risk Register Review
**Monitoring Tools/Platforms:**

  - Risk Register Document
  - Risk Assessment Matrix
  - Project Management Software

**Frequency:** Bi-weekly

**Responsible Role:** Risk Manager

**Adaptation Process:** Risk mitigation plan updated by Risk Manager, reviewed by PMO, escalated to Steering Committee if significant

**Adaptation Trigger:** New critical risk identified, existing risk likelihood or impact increases significantly, or mitigation plan proves ineffective

### 3. Funding Disbursement Monitoring
**Monitoring Tools/Platforms:**

  - Financial Tracking System
  - Sovereign Wealth Fund Consortium Agreements
  - Project Budget Spreadsheet

**Frequency:** Monthly

**Responsible Role:** Chief Financial Officer

**Adaptation Process:** CFO proposes adjustments to funding strategy, PMO updates project plan, Steering Committee approves changes

**Adaptation Trigger:** Funding disbursement delayed by >1 month, projected funding shortfall >5% of budget, or Sovereign Wealth Fund commitment wavers

### 4. Geopolitical Risk Monitoring
**Monitoring Tools/Platforms:**

  - Political Risk Insurance Policy
  - Geopolitical News Feeds
  - Intelligence Reports

**Frequency:** Weekly

**Responsible Role:** Risk Manager

**Adaptation Process:** Risk Manager updates risk mitigation plan, PMO adjusts project plan, Steering Committee reviews and approves changes, insurance policy adjusted if needed

**Adaptation Trigger:** Significant political instability in Spain or Morocco, increased threat of terrorism, or adverse changes in international relations

### 5. International Collaboration Framework Effectiveness Review
**Monitoring Tools/Platforms:**

  - Joint Governance Meeting Minutes
  - Communication Logs
  - Stakeholder Feedback Surveys

**Frequency:** Quarterly

**Responsible Role:** Stakeholder Engagement Manager

**Adaptation Process:** Stakeholder Engagement Group proposes adjustments to collaboration framework, PMO updates project plan, Steering Committee reviews and approves changes

**Adaptation Trigger:** Significant disputes between Spanish and Moroccan representatives, delays in joint decision-making, or negative feedback from stakeholders

### 6. Technical Performance Monitoring
**Monitoring Tools/Platforms:**

  - Technical Design Documents
  - Construction Progress Reports
  - Quality Control Data

**Frequency:** Monthly

**Responsible Role:** Chief Engineer

**Adaptation Process:** Technical Advisory Group recommends design changes, PMO updates project plan, Steering Committee reviews and approves changes

**Adaptation Trigger:** Significant technical challenges encountered, design flaws identified, or quality control issues arise

### 7. Environmental Impact Monitoring
**Monitoring Tools/Platforms:**

  - Environmental Monitoring Reports
  - Marine Ecosystem Surveys
  - Compliance Audit Reports

**Frequency:** Monthly

**Responsible Role:** Environmental Liaison Officer

**Adaptation Process:** Environmental Liaison Officer proposes mitigation measures, PMO updates project plan, Ethics & Compliance Committee reviews and approves changes

**Adaptation Trigger:** Significant negative impacts on the marine ecosystem, non-compliance with environmental regulations, or complaints from environmental groups

### 8. Stakeholder Engagement Effectiveness Monitoring
**Monitoring Tools/Platforms:**

  - Stakeholder Feedback Surveys
  - Community Meeting Minutes
  - Media Coverage Analysis

**Frequency:** Monthly

**Responsible Role:** Stakeholder Engagement Manager

**Adaptation Process:** Stakeholder Engagement Group adjusts engagement plan, PMO updates project plan, Steering Committee reviews and approves changes

**Adaptation Trigger:** Significant opposition from local communities, negative media coverage, or unresolved stakeholder concerns

### 9. Tunnel Material Performance Monitoring
**Monitoring Tools/Platforms:**

  - Material Testing Reports
  - Corrosion Monitoring Data
  - Structural Integrity Assessments

**Frequency:** Quarterly

**Responsible Role:** Materials Scientist

**Adaptation Process:** Technical Advisory Group recommends material changes, PMO updates project plan, Steering Committee reviews and approves changes

**Adaptation Trigger:** Material degradation detected, corrosion rates exceed acceptable levels, or structural integrity compromised

### 10. Seismic Activity Monitoring
**Monitoring Tools/Platforms:**

  - Seismic Sensor Data
  - Geological Survey Reports
  - Emergency Response Protocols

**Frequency:** Daily

**Responsible Role:** Geotechnical Engineer

**Adaptation Process:** Emergency response protocols activated, Technical Advisory Group assesses structural integrity, PMO updates project plan, Steering Committee reviews and approves changes

**Adaptation Trigger:** Seismic event exceeding predetermined magnitude threshold, geological instability detected, or risk of tunnel collapse

### 11. Ethics and Compliance Monitoring
**Monitoring Tools/Platforms:**

  - Compliance Audit Reports
  - Ethics Violation Reports
  - Training Records

**Frequency:** Monthly

**Responsible Role:** Compliance Officer

**Adaptation Process:** Ethics & Compliance Committee recommends corrective actions, PMO updates project plan, Steering Committee reviews and approves changes

**Adaptation Trigger:** Ethical violations reported, non-compliance with regulations detected, or audit findings require action

# Governance Extra

## Governance Validation Checks

1. Point 1: Completeness Confirmation: All core requested components (internal_governance_bodies, governance_implementation_plan, decision_escalation_matrix, monitoring_progress) appear to be generated.
2. Point 2: Internal Consistency Check: The Implementation Plan uses defined governance bodies. The Escalation Matrix aligns with the governance hierarchy. Monitoring roles are defined within the governance structure. The components appear logically consistent.
3. Point 3: Potential Gaps / Areas for Enhancement: The role and authority of the Project Sponsor, while mentioned in the Implementation Plan, lacks clear definition within the overall governance structure. The Sponsor's decision rights and responsibilities should be explicitly stated in relation to the Project Steering Committee and other bodies.
4. Point 4: Potential Gaps / Areas for Enhancement: The Ethics & Compliance Committee's responsibilities are well-defined, but the process for whistleblower investigations (beyond simply 'investigating allegations') needs more detail. Specific steps, timelines, and protections for whistleblowers should be outlined.
5. Point 5: Potential Gaps / Areas for Enhancement: The adaptation triggers in the Monitoring Progress plan are primarily reactive (e.g., 'KPI deviates >10%'). More proactive triggers based on leading indicators or early warning signs could strengthen the framework. For example, for 'Funding Disbursement Monitoring', a trigger could be 'preliminary indications of potential delays in fund commitments' rather than waiting for a delay of >1 month.
6. Point 6: Potential Gaps / Areas for Enhancement: The decision-making mechanism for the Project Steering Committee relies on a majority vote, with the Sovereign Wealth Fund Consortium representative casting the deciding vote in case of a tie. This could create a potential conflict of interest or undue influence. Consider alternative tie-breaking mechanisms or supermajority requirements for critical decisions.
7. Point 7: Potential Gaps / Areas for Enhancement: The Stakeholder Engagement Group's membership includes representatives from local communities, but the process for selecting these representatives and ensuring they genuinely represent diverse community interests is not specified. A clear selection process is needed to avoid accusations of tokenism or bias.

## Tough Questions

1. What is the current probability-weighted forecast for project completion within the €40 billion budget and 20-year timeframe, considering the identified risks and assumptions?
2. Show evidence of independent verification of the geological surveys and risk assessments, ensuring they adequately address potential seismic activity and seabed instability.
3. What contingency plans are in place to address potential withdrawal of a major sovereign wealth fund from the consortium, and how would this impact the project's financial viability and timeline?
4. How will the project ensure that the selection process for local community representatives in the Stakeholder Engagement Group is fair, transparent, and representative of diverse community interests?
5. What specific metrics will be used to measure the effectiveness of the ethics and compliance program, and how will these metrics be reported to the Project Steering Committee and relevant regulatory authorities?
6. What are the specific, measurable targets for marine ecosystem impact mitigation, and how will progress towards these targets be tracked and reported?
7. What is the detailed plan for managing currency risk, including specific hedging instruments and strategies, and how will the effectiveness of this plan be monitored and adjusted over the project's 20-year lifespan?

## Summary

The governance framework establishes a multi-tiered structure with clear roles and responsibilities for strategic oversight, project management, technical expertise, ethics and compliance, and stakeholder engagement. The framework emphasizes proactive risk management and monitoring, with defined escalation paths for critical issues. A key focus area is ensuring ethical conduct and compliance with regulations, alongside effective stakeholder engagement to address community concerns and maintain project viability.