Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 16 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 3 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the project does not inherently violate any laws of physics. The goal statement specifies a "pillar-supported transoceanic submerged tunnel... anchored at a controlled depth of 100 meters below sea level," which is physically plausible.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (transoceanic tunnel) + market (Europe-Africa) + tech/process (self-healing concrete, real-time monitoring) + policy (binational authority) without independent evidence at comparable scale. There is no credible precedent for this system combination.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Project Manager / Deliverable: Validation Report / Date: 2026-06-30


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (transoceanic tunnel) + market (Europe-Africa) + tech/process (self-healing concrete, real-time monitoring) + policy (binational authority) without independent evidence at comparable scale. There is no credible precedent for this system combination.

**Mitigation**: Project Manager: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Date: 2026-06-30


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies several second-order risks (regulatory, technical, financial, environmental, social, geopolitical) and proposes mitigation plans. However, the analysis of risk cascades is not explicit, and the mitigation plans lack detail.

**Mitigation**: Risk Management Specialist: Expand the risk register to map risk cascades explicitly (e.g., permit delay → revenue shortfall) and add controls with a dated review cadence. Date: 2026-07-01


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions obtaining permits but does not include a detailed matrix identifying required permits, lead times, and responsible parties. Without this, timeline realism cannot be assessed.

**Mitigation**: Project Manager: Create a permit/approval matrix with all required permits, typical lead times in each jurisdiction, and assigned owners. Date: 2026-06-30


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the funding model is undefined. The plan states, "Establish a sovereign wealth fund consortium, pooling capital from multiple nations," but does not specify which nations, the status of commitments, draw schedule, or covenants.

**Mitigation**: Project Finance Team: Develop a dated financing plan listing funding sources, their status (LOI/term sheet/closed), draw schedule, covenants, and a NO-GO on missed financing gates. Date: 2026-06-30


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of €40 billion lacks substantiation. There are no benchmarks or vendor quotes normalized by area (cost per m²/ft²) to justify the figure. The plan omits contingency planning, increasing the risk of cost overruns.

**Mitigation**: Project Finance Team: Benchmark at least three comparable tunnel projects, normalize costs per square meter, obtain vendor quotes for key components, and adjust the budget with a 10-20% contingency by 2026-06-30.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents the goal as a single number: "Construct... within 20 years, at a cost of €40 billion... anchored at a controlled depth of 100 meters." There is no range, confidence interval, or discussion of alternative scenarios.

**Mitigation**: Project Manager: Conduct a sensitivity analysis for the project's completion date, budget, and depth, including best-case, worst-case, and base-case scenarios. Date: 2026-06-30


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks essential engineering artifacts such as specifications, interface contracts, acceptance tests, and an integration plan. Their absence creates a critical failure mode.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners and dates by 2026-06-30.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes several critical claims without providing verifiable evidence. For example, it states, "Secure political risk insurance to protect against losses..." but lacks the actual insurance policy or a binder.

**Mitigation**: Risk Management Specialist: Obtain a copy of the political risk insurance policy or a legally binding commitment from the insurer, including coverage details and exclusions, by 2026-06-30.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the major deliverable, 'the tunnel', is mentioned without specific, verifiable qualities. The goal statement says, "Construct a pillar-supported transoceanic submerged tunnel..." but lacks SMART acceptance criteria.

**Mitigation**: Engineering Team: Define SMART criteria for tunnel acceptance, including a KPI for structural integrity (e.g., maximum allowable deflection under load) by 2026-06-30.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'Develop a self-healing concrete composite' which does not directly support the core project goals of improving trade/transport and enhancing international relations. It adds complexity without clear benefit.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of self-healing concrete, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog. Date: 2026-07-01


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies several roles, but the 'Tunneling and Subsea Construction Engineer' is the most specialized and critical. Their expertise is essential for the project's success, and qualified engineers are likely rare.

**Mitigation**: HR Team: Validate the talent market for Tunneling and Subsea Construction Engineers, including salary expectations and availability, to assess the feasibility of filling this critical role by 2026-06-30.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a regulatory matrix mapping required permits, authorities, artifacts, and lead times. The plan mentions permits but lacks specifics, making legality unclear. This is a potential showstopper.

**Mitigation**: Project Manager: Develop a regulatory matrix identifying all required permits, authorities, artifacts, lead times, and predecessors. Conduct a fatal-flaw analysis and NO-GO on adverse findings. Date: 2026-06-30


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions long-term sustainability as a risk and proposes developing a financial model and exploring revenue streams. However, it lacks a detailed operational sustainability plan addressing funding, maintenance, and technology obsolescence.

**Mitigation**: Project Finance Team: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms. Date: 2026-07-01


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks evidence of zoning or land-use approvals for construction sites in Spain and Morocco. The plan mentions coastal areas near Tarifa and Tangier, but lacks evidence of suitability.

**Mitigation**: Real Estate Team: Perform a fatal-flaw screen with authorities in Tarifa and Tangier to confirm zoning/land-use approvals for construction sites. Define fallback sites. Date: 2026-06-30


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks evidence of tested failover plans for critical external dependencies. The plan mentions diversifying supply chains, but lacks evidence of SLAs or tested failover procedures for key vendors.

**Mitigation**: Supply Chain Team: Secure SLAs with key vendors, add a secondary supplier/path for critical dependencies, and test failover procedures by 2026-09-30.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions 'High-Speed Rail Integration Specialist' and 'Environmental Protection Agency' as primary stakeholders. Finance wants ROI, EPA wants minimal impact, creating tension. The plan lacks a shared objective.

**Mitigation**: Project Leadership: Define a shared OKR for Finance and EPA: 'Achieve X% ROI while maintaining Marine Disturbance Index below Y' by 2026-07-01.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a change-control process. Vague ‘we will monitor’ is insufficient to ensure course correction.

**Mitigation**: Project Manager: Add a monthly review with a KPI dashboard and a lightweight change board to ensure continuous monitoring and adaptation. Date: 2026-07-01


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because ≥3 High risks are strongly coupled. Funding Model (Critical) conflicts with Geological Risk Mitigation (High), Emergency Egress Protocol (High), and Marine Ecosystem Impact Mitigation (High). A funding shortfall could cascade into multiple failures.

**Mitigation**: Project Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Date: 2026-07-01