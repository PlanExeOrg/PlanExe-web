
## Risk 1 - Regulatory & Permitting
Cross-border governance misalignment between Spain and Morocco could cause severe permitting delays. The chosen neutral third-party consortium model requires diplomatic negotiation to establish legal frameworks, and disagreements over jurisdiction, regulatory standards, or dispute resolution mechanisms could stall project initiation. Additionally, the transboundary environmental impact assessment through the International Maritime Organization (IMO) could take five or more years to negotiate, during which political administrations may shift priorities.

**Impact:** A 2–5 year delay in permitting and governance establishment could push the project start beyond optimal weather windows and inflate total costs by an estimated €2–5 billion due to extended pre-construction overhead, inflation, and financing carry costs. Investor confidence may erode during prolonged uncertainty.

**Likelihood:** High

**Severity:** High

**Action:** Establish a dedicated bilateral diplomatic task force with pre-negotiated framework agreements before formal project launch. Engage the IMO early with a pre-agreed timeline and fallback arbitration mechanism. Retain international legal counsel specializing in transboundary infrastructure to accelerate treaty drafting.

## Risk 2 - Regulatory & Permitting
Environmental permitting across two sovereign jurisdictions with potentially conflicting marine protection standards could create duplicative review processes. Even with a unified IMO framework, national-level environmental agencies in Spain and Morocco may impose additional requirements, particularly regarding sensitive benthic habitats in the Strait of Gibraltar. Environmental organizations could file legal challenges at any stage.

**Impact:** Environmental litigation or additional national-level permitting requirements could add 1–3 years to the timeline and incur €500 million–€1.5 billion in additional compliance costs, including redesigned tunnel segments or modified pillar configurations to meet stricter habitat protection standards.

**Likelihood:** Medium

**Severity:** High

**Action:** Proactively engage environmental NGOs and local communities in the design phase. Incorporate elevated pillar configurations that preserve benthic habitats as a design feature rather than a retrofit. Commission independent environmental baseline studies early to establish defensible ecological benchmarks.

## Risk 3 - Technical
The hybrid floating-pillar architecture chosen under the Builder's Foundation strategy is unprecedented at this scale and depth. At 100 meters below sea level, the interaction between buoyant tunnel segments, vertical pillar members, and hydrodynamic lift creates complex force dynamics that cannot be fully validated through existing models or small-scale testing. The pillar-tunnel interface must simultaneously manage vertical buoyancy loads, lateral current forces, and dynamic storm loading—all while maintaining precise rail alignment.

**Impact:** Structural miscalculations could lead to tunnel segment misalignment, excessive pillar loading, or uncontrolled depth variation during extreme weather. A single structural failure could necessitate replacement of entire tunnel segments at an estimated cost of €500 million–€2 billion per incident, with 6–18 months of schedule delay for redesign and reconstruction.

**Likelihood:** Medium

**Severity:** High

**Action:** Invest in a comprehensive scaled physical model testing program in deep-water basins before full-scale deployment. Conduct finite element analysis validated against real-world oceanographic data from the Strait of Gibraltar. Build a full-scale prototype segment and instrument it extensively before committing to mass production.

## Risk 4 - Technical
Buoyancy engineering at 100-meter depth presents extreme challenges. The variable-ballast system chosen to maintain precise depth must function reliably for 20+ years in a corrosive saline environment with limited access. Mechanical failure of ballast systems could cause the tunnel to ascend beyond its design depth (risking collision with surface shipping) or descend and contact the seabed (risking structural damage). Active ballast systems add mechanical complexity and failure points that passive designs avoid.

**Impact:** Complete ballast system failure could require emergency intervention costing €200–800 million per tunnel section, with potential loss of the section entirely. Partial failure causing depth variance of several meters could compromise rail operations and safety, requiring service suspension and repairs costing €50–200 million per incident.

**Likelihood:** Medium

**Severity:** High

**Action:** Design redundant ballast systems with passive fail-safe mechanisms that default to a safe neutral buoyancy state. Implement real-time depth monitoring with automated ballast correction. Conduct accelerated life-cycle testing of ballast components under simulated 20-year saline exposure conditions.

## Risk 5 - Technical
Corrosion and durability over a 20-year submerged lifespan represents a fundamental challenge. The aggressive saline environment at 100 meters depth, combined with the complex geometry of hybrid floating-pillar joints and articulated flexible connections, creates numerous potential pathways for saline ingress. Polymer encapsulation can be breached during installation or degraded by UV exposure during pre-construction storage; sacrificial anodes require periodic replacement in inaccessible locations; active cathodic protection systems depend on reliable power generation at depth.

**Impact:** Unmanaged corrosion could reduce the structural lifespan below the 20-year design horizon, requiring premature rehabilitation costing €3–8 billion across the tunnel system. Cathodic protection system failure could accelerate degradation by 3–5x, potentially necessitating full tunnel replacement within 15 years.

**Likelihood:** High

**Severity:** High

**Action:** Implement a multi-layer corrosion protection strategy combining polymer encapsulation with sacrificial anodes and active cathodic protection as redundant systems. Design accessible inspection and maintenance ports at regular intervals. Establish a dedicated corrosion monitoring program with predictive analytics to schedule interventions before critical degradation occurs.

## Risk 6 - Technical
Rail systems integration within a pressurized, submerged environment introduces unprecedented engineering challenges. The sealed pressurized rail corridor must maintain terrestrial-grade track precision while subjected to external hydrostatic pressure of approximately 10 atmospheres at 100 meters depth. Thermal expansion from pressurization and temperature variations, combined with marine-induced vibration, creates complex stress distributions that could compromise track geometry over time. Transition points between surface rail and the submerged section represent critical failure points for passenger safety and operational continuity.

**Impact:** Track geometry deviations could require speed restrictions reducing the tunnel's commercial viability, potentially cutting projected revenue by 20–40%. Pressurization system failures could endanger passenger safety, requiring evacuation and potentially causing structural damage. Transition zone failures could isolate sections of the tunnel, with remediation costs of €100–500 million per incident.

**Likelihood:** Medium

**Severity:** High

**Action:** Develop and test a full-scale pressurized rail prototype under simulated deep-sea conditions before tunnel construction. Design modular track sections with active compensation systems for thermal and pressure-induced deformation. Implement redundant pressurization systems with emergency depressurization protocols.

## Risk 7 - Financial
The €40 billion budget envelope faces significant exposure to cost escalation over a 20-year construction horizon. Material costs for buoyant concrete, marine-grade steel, and specialized mooring systems are subject to commodity price volatility. Labor costs in the offshore construction sector are projected to rise significantly. Additionally, the neutral third-party consortium governance model may introduce administrative overhead and decision-making delays that extend the timeline and increase carrying costs.

**Impact:** A 10–15% cost overrun would represent €4–6 billion in additional funding requirements. If financing is structured through private equity with strict return timelines, cost overruns could trigger covenant breaches, investor withdrawal, or forced restructuring. Extended timelines compound financing costs—each additional year of construction could add €300–600 million in interest and overhead.

**Likelihood:** High

**Severity:** High

**Action:** Establish a €4–6 billion contingency reserve within the initial budget. Use fixed-price contracts with penalty clauses for major material suppliers. Implement rigorous cost tracking with quarterly reviews and automated escalation triggers. Structure financing with flexible disbursement tranches that can accommodate timeline adjustments without triggering default provisions.

## Risk 8 - Financial
Currency exchange rate risk between EUR (primary project currency) and MAD (Moroccan local currency) could erode the budget envelope over 20 years. Morocco's local costs—including labor, permits, local materials, and coastal staging operations near Tangier—are denominated in MAD. Significant MAD depreciation against EUR would increase the effective cost of Moroccan-side expenditures, while MAD appreciation would increase costs for Spanish-side entities paying MAD-denominated contracts.

**Impact:** Unhedged currency fluctuations of 10–20% over the project lifecycle could translate to €200 million–€800 million in additional costs, depending on the direction and magnitude of exchange rate movements. This is particularly acute during the construction phase when Moroccan-side expenditures peak.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Implement a comprehensive currency hedging program using forward contracts and currency swaps covering at least 70% of projected MAD-denominated expenditures. Establish a dedicated treasury function to monitor and manage FX exposure monthly. Consider negotiating some Moroccan-side contracts in EUR to transfer currency risk to counterparties.

## Risk 9 - Financial
The international consortium financing model, while enabling capital deployment, introduces risks related to investor confidence and funding continuity. Tranche-based disbursements tied to geological and marine milestones create funding cliffs—if a milestone is delayed or disputed, subsequent funding may be withheld, creating a cascading cash flow crisis. Political shifts in either Spain or Morocco could alter government guarantees or development bank commitments.

**Impact:** A funding gap of even 6–12 months could halt construction entirely, costing €500 million–€1 billion in idle workforce, equipment demobilization, and remobilization costs. Loss of government bond guarantees could increase the cost of capital by 200–400 basis points, adding €1–3 billion in total interest payments over the project lifecycle.

**Likelihood:** Medium

**Severity:** High

**Action:** Diversify funding sources across sovereign bonds, development bank facilities, and private capital to avoid single-point-of-failure dependencies. Establish a reserve fund covering at least 12 months of operational costs. Negotiate milestone definitions with sufficient specificity and dispute resolution mechanisms to prevent funding withholding over technical disagreements.

## Risk 10 - Environmental
Construction activities in the Strait of Gibraltar will disturb sensitive marine ecosystems, including migratory routes for cetaceans (whales and dolphins), benthic habitats on the seabed, and water quality during dredging and pillar installation. The elevated pillar configuration chosen to minimize seabed contact still requires significant offshore platform construction and segment placement activities that generate noise, sediment plumes, and physical disruption.

**Impact:** Environmental damage could trigger regulatory shutdowns, fines of €50–500 million, and mandatory remediation costing €200 million–€1 billion. Reputational damage could erode public support and political backing, potentially leading to project cancellation. Long-term ecosystem damage could affect fisheries and tourism industries in the region.

**Likelihood:** Medium

**Severity:** High

**Action:** Conduct comprehensive marine ecosystem baseline studies before construction begins. Implement seasonal construction restrictions during cetacean migration periods. Deploy real-time acoustic monitoring to detect and mitigate marine mammal disturbance. Establish an independent environmental oversight board with authority to halt construction if thresholds are exceeded.

## Risk 11 - Social
Offshore workforce resilience over a 20-year construction period presents profound human capital challenges. The isolated offshore environment at 100 meters depth, combined with the project's duration, creates extreme retention difficulties. Even with permanent residential platforms or generous equity incentives, specialized workers may leave due to burnout, family considerations, or better opportunities. High turnover forces repeated training cycles and erodes institutional knowledge precisely when it is most needed during critical installation phases.

**Impact:** Workforce turnover exceeding 20% annually could add €500 million–€1.5 billion in repeated recruitment and training costs over the project lifecycle. Loss of institutional knowledge during critical installation phases could increase error rates by 15–30%, leading to rework, delays, and safety incidents. Safety incident frequency could increase by 25–50% during periods of high turnover.

**Likelihood:** High

**Severity:** Medium

**Action:** Implement a tiered retention strategy combining competitive compensation, family accommodation options, career progression pathways, and equity participation. Establish a knowledge management system that captures and institutionalizes expertise independent of individual workers. Partner with maritime training institutions to create a continuous pipeline of qualified personnel.

## Risk 12 - Operational
Construction deployment using offshore floating platforms positioned directly above installation sites requires years of permitting and infrastructure setup before the first segment can be placed. These permanent offshore platforms are exposed to extreme weather conditions, including storms that are common in the Strait of Gibraltar. A single severe weather event during installation could damage platforms, displace tunnel segments, or injure personnel.

**Impact:** Platform damage from a severe storm could cost €200–800 million to repair and cause 3–6 months of construction delay. Displaced or damaged tunnel segments could cost €100–500 million to recover and replace. Personnel safety incidents could result in project shutdowns, legal liability, and reputational damage.

**Likelihood:** Medium

**Severity:** High

**Action:** Design offshore platforms to withstand 100-year storm events with redundant structural systems. Develop detailed weather monitoring and evacuation protocols. Pre-position emergency response equipment and vessels. Construct platforms during favorable weather windows with accelerated timelines to minimize exposure during vulnerable periods.

## Risk 13 - Supply Chain
The supply chain for this project depends on enormous quantities of specialized materials—buoyant concrete, marine-grade steel, mooring systems, and corrosion protection materials—delivered to remote offshore locations across international waters. A single mega-hub in southern Spain, while efficient, creates a catastrophic single point of failure. A port strike, facility fire, or logistics disruption at the hub could halt all construction simultaneously.

**Impact:** A supply chain disruption lasting 2–4 months could cost €1–3 billion in idle costs, contract penalties, and accelerated costs to recover the schedule. Material shortages could force design compromises that reduce structural integrity or operational capability. The concentration of materials at a single hub makes the project vulnerable to terrorism, piracy, or geopolitical disruption.

**Likelihood:** Medium

**Severity:** High

**Action:** Establish a distributed supply chain with at least two regional fabrication yards (one in Spain, one in Morocco) to provide redundancy. Maintain a 3–6 month strategic inventory of critical materials at offshore staging areas. Develop pre-qualified alternative suppliers for all critical material categories. Implement blockchain-based supply chain tracking for real-time visibility.

## Risk 14 - Supply Chain
The transportation of massive buoyant concrete tunnel segments from fabrication yards to offshore installation sites across international waters presents unique logistical challenges. Towing operations at 100-meter depth are subject to weather windows, ocean currents, and maritime traffic in one of the world's busiest shipping lanes. The Strait of Gibraltar's narrow width and heavy shipping traffic create congestion and collision risks during segment transport.

**Impact:** Transport delays could cascade through the entire construction schedule, with each week of delay costing €10–30 million in idle workforce and equipment costs. A collision or loss of a tunnel segment during transport could result in total loss of the segment (€50–200 million) and potential environmental disaster. Maritime traffic delays in the Strait could add weeks to transport schedules.

**Likelihood:** Medium

**Severity:** High

**Action:** Develop dedicated maritime transport corridors with temporary traffic management agreements with maritime authorities. Use purpose-built semi-submersible transport vessels with enhanced stability and positioning systems. Schedule transport during low-traffic periods and favorable weather windows. Maintain insurance coverage for total loss during transit.

## Risk 15 - Security
The tunnel infrastructure spanning international waters between two sovereign nations presents a high-value target for physical security threats, including sabotage, terrorism, or unauthorized access. The submerged structure at 100 meters depth is difficult to monitor and protect. Additionally, the subsea structural surveillance systems relying on fiber-optic sensors, acoustic modems, and underwater communication infrastructure are vulnerable to cyber attacks that could disable monitoring or feed false data.

**Impact:** A successful sabotage event could cause catastrophic structural failure with potential loss of life, environmental disaster, and total project loss valued at €40 billion. A cyber attack on surveillance systems could go undetected for weeks or months, allowing structural degradation to progress unchecked. Security breach remediation could cost €500 million–€2 billion and require complete system replacement.

**Likelihood:** Low

**Severity:** High

**Action:** Implement a multi-layered physical security system including underwater barriers, surveillance drones, and naval patrols. Deploy encrypted, air-gapped communication networks for critical structural monitoring systems. Conduct regular penetration testing and cybersecurity audits. Establish a joint Spain-Morocco security coordination center for the tunnel corridor.

## Risk 16 - Geopolitical
The project spans two sovereign nations with distinct political systems, legal frameworks, and strategic interests. Changes in government in either Spain or Morocco could fundamentally alter the political commitment to the project, funding guarantees, or governance structure. Diplomatic tensions between the two nations—whether related to migration, territorial disputes, or broader geopolitical dynamics—could escalate to the point of project suspension or cancellation.

**Impact:** A change in government or diplomatic crisis could result in project suspension lasting 1–3 years, costing €2–6 billion in carrying costs, contract termination penalties, and remobilization expenses. In the worst case, project cancellation could result in total loss of invested capital and significant reputational damage to both nations and all participating entities.

**Likelihood:** Medium

**Severity:** High

**Action:** Embed the project in binding international treaties that survive changes in government. Establish a neutral dispute resolution mechanism with enforcement authority. Diversify political support by demonstrating economic benefits to constituencies in both nations. Maintain continuous diplomatic engagement at multiple levels of government.

## Risk 17 - Operational
Integration with existing surface rail networks on both the Spanish and Moroccan sides presents significant interface challenges. The tunnel must connect to existing high-speed rail infrastructure at Tarifa/Algeciras and Tangier, requiring modifications to existing stations, signaling systems, and power supply. The transition between surface rail and the submerged pressurized corridor introduces complex engineering and operational challenges.

**Impact:** Interface failures could limit the tunnel's throughput capacity, reducing projected revenue by 15–30%. Signaling system incompatibilities could force operational speed restrictions. Station modifications could cost €200–800 million per terminal if not properly coordinated with existing infrastructure operators.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish joint interface teams with existing rail operators from the project's inception. Conduct comprehensive gauge, signaling, and power system compatibility studies. Design modular transition infrastructure that can be adapted to existing systems without requiring complete replacement.

## Risk 18 - Long-term Sustainability
The 20-year operational lifespan of the tunnel requires sustained maintenance funding, technological relevance, and structural integrity over an extremely long horizon. Maintenance costs for a submerged structure at 100 meters depth are orders of magnitude higher than terrestrial infrastructure. Technological obsolescence—particularly in rail systems, surveillance technology, and corrosion protection—could render the tunnel functionally outdated before its structural lifespan expires.

**Impact:** Maintenance costs over 20 years could reach €3–8 billion, potentially exceeding initial construction cost projections if not properly budgeted. Technological obsolescence could require major system upgrades costing €1–4 billion. Failure to budget for long-term maintenance could lead to progressive structural degradation and eventual safety-critical failures.

**Likelihood:** High

**Severity:** Medium

**Action:** Establish a dedicated maintenance trust fund capitalized at project inception, funded by a percentage of operational revenues. Design the tunnel with modular systems that can be upgraded without complete replacement. Commission a 20-year lifecycle cost analysis during the design phase to inform budget allocation.

## Risk summary
The most critical risks that could jeopardize this €40 billion, 20-year transoceanic submerged tunnel project are: (1) **Cross-border governance and regulatory delays**—the high likelihood of permitting delays, diplomatic misalignment, and environmental litigation could add 2–5 years and €2–5 billion in costs, potentially stalling the project before construction even begins. (2) **Technical uncertainty of the hybrid floating-pillar architecture**—the unprecedented nature of this design at 100-meter depth creates medium-probability but high-severity structural failure risks that could cost billions and cause catastrophic safety incidents. (3) **Financial sustainability over 20 years**—cost escalation, currency risk, and funding continuity threats could erode the €40 billion budget envelope, with each additional year of construction adding €300–600 million in carrying costs. These three risks are interconnected: governance delays compound financial exposure, technical failures trigger cost overruns, and financial constraints limit the ability to address technical and governance challenges. The Builder's Foundation strategy mitigates some risks through its balanced approach, but the unprecedented scale and complexity of this project demand continuous risk monitoring and adaptive management throughout the 20-year horizon.