# Governance Audit


## Audit - Corruption Risks

- Bribery in major procurement contracts for buoyant concrete, marine-grade steel, and mooring systems, where suppliers may offer illicit payments to secure contracts within the €40 billion budget envelope.
- Nepotism in the selection of the neutral third-party engineering consortium leadership or key technical personnel, where unqualified relatives or associates of decision-makers are appointed to critical design and oversight roles.
- Conflicts of interest within the international consortium governance structure, where the neutral engineering firm may have undisclosed financial ties to construction contractors or material suppliers, compromising objective technical decision-making.
- Kickbacks in offshore platform construction and fabrication yard contracts, where inflated costs are agreed upon in exchange for personal payments to project officials or government representatives.
- Trading of diplomatic or regulatory favors in cross-border permitting processes, where officials may exchange expedited environmental approvals or construction permits for personal or political benefits.
- Misuse of sensitive project information, including geotechnical survey data or financial details, for insider trading or to benefit external parties with interests in the project's success or failure.

## Audit - Misallocation Risks

- Embezzlement or misuse of the €40 billion capital budget or the €4-6 billion contingency reserve for personal gain or unauthorized purposes by project officials or consortium members.
- Double spending of tranche-based funding disbursements, where the same milestone-based funds are claimed or allocated to multiple purposes before verification of actual expenditure.
- Misreporting of construction progress to international financing entities to unlock successive funding tranches prematurely, despite incomplete or substandard work on functional-subsystem phases.
- Inefficient allocation of resources between the three construction phases (pillars/buoyancy, rail infrastructure, sealing/pressurization), such as over-investing in Phase 1 while leaving insufficient budget for critical Phase 2 rail systems integration.
- Unauthorized use of project assets, including offshore floating platforms, fabrication yards, or specialized materials, for non-project purposes or by third parties without proper authorization or compensation.
- Poor record keeping and lack of audit trails for expenditures related to MAD-denominated local costs in Morocco, enabling untraceable fund diversion or currency manipulation.
- Overpayment to contractors and suppliers due to lack of competitive bidding oversight or inflated invoicing, particularly in specialized areas like corrosion protection systems and buoyancy engineering components.

## Audit - Procedures

- Quarterly internal financial audits of all project expenditures against the €40 billion budget envelope, with automated escalation triggers at 5%, 10%, and 15% budget utilization to detect anomalies early.
- Annual external audits of the neutral third-party consortium's governance decisions, technical approvals, and financial management to ensure compliance with the bilateral treaty and ICC arbitration rules.
- Mandatory independent audit of all procurement contracts exceeding €50 million (covering buoyant concrete, marine-grade steel, mooring systems, and offshore platform construction) before contract finalization and payment release.
- Environmental compliance audits conducted by the independent environmental oversight board to verify adherence to marine ecosystem protection standards, cetacean migration restrictions, and mitigation measures throughout construction.
- Phase-gate external audits upon completion of each functional-subsystem phase (pillars/buoyancy, rail infrastructure, sealing/pressurization) before releasing subsequent funding tranches from multilateral development banks and sovereign bonds.
- Supply chain audits utilizing blockchain-based tracking systems to verify material provenance, prevent double-spending of materials, and ensure all buoyant concrete and steel components meet specified standards.
- Cross-border governance audits verifying compliance with bilateral treaty obligations, parliamentary ratification requirements, and diplomatic task force decisions, conducted by international legal counsel specializing in transboundary infrastructure.

## Audit - Transparency Measures

- Public transparency portal with real-time project updates, budget utilization dashboards, environmental monitoring data, and construction progress reports accessible to both governments, investors, and the general public.
- Quarterly investor briefings with transparent financial reporting, including detailed expenditure breakdowns, contingency reserve status, and milestone achievement verification to maintain investor confidence and unlock funding tranches.
- Published meeting minutes of the bilateral diplomatic task force, consortium governance body, and independent environmental oversight board to ensure accountability in cross-border decision-making and environmental compliance.
- Documented selection criteria and evaluation matrices for major vendor and contractor procurement decisions (buoyant concrete suppliers, offshore platform constructors, rail systems integrators) to prevent nepotism and ensure fair competition.
- Established whistleblower mechanisms with anonymous reporting channels for project personnel and contractors to report corruption, misallocation of funds, or non-compliance with environmental and safety standards without fear of retaliation.
- Community liaison offices in Tarifa and Tangier with bilingual (Spanish/Arabic) communications teams publishing regular reports on local hiring quotas, environmental impacts, and community benefit agreements.
- Independent environmental oversight board with public reporting requirements on marine mammal disturbance levels, sediment plume monitoring, and benthic habitat preservation status along the tunnel corridor.

# Internal Governance Bodies

### 1. Project Steering Committee

**Rationale for Inclusion:** This €40 billion, 20-year transoceanic tunnel spanning two sovereign nations demands a apex strategic oversight body capable of aligning Spanish and Moroccan national interests, approving billion-euro budget allocations, and providing unified strategic direction across an unprecedented engineering endeavor. The project's cross-border governance complexity, geopolitical risk exposure, and the need for parliamentary ratification of bilateral treaties require a body with sovereign-level authority that transcends purely operational management. Without it, strategic misalignment between nations could stall the project at the midpoint where both jurisdictions must simultaneously contribute resources.

**Responsibilities:**

- Provide high-level strategic direction and approve the project's overall vision, mission, and strategic framework
- Approve budgets exceeding €50 million and any modifications to the €40 billion total capital envelope
- Ratify major milestone approvals and phase-gate go/no-go decisions across all functional subsystems
- Oversee cross-border diplomatic alignment between Spain and Morocco, including bilateral treaty compliance
- Approve selection and oversight of the neutral third-party engineering consortium leadership
- Review and endorse the project's risk appetite statement and major risk mitigation strategies
- Ensure alignment with IMO transboundary environmental frameworks and bilateral parliamentary commitments
- Approve changes to project scope, timeline, or governance structure
- Oversee investor relations and ensure confidence in tranche-based financing disbursements

**Initial Setup Actions:**

- Establish the bilateral treaty foundation by ratifying the governance charter through both Spanish Cortes Generales and Moroccan Parliament
- Elect a joint Chair and Vice-Chair from senior representatives of Spain and Morocco respectively
- Define and formalize the financial approval thresholds distinguishing strategic from operational decisions
- Appoint independent external members to ensure impartial oversight and prevent sovereign dominance
- Establish the terms of reference including decision rights, escalation protocols, and meeting cadence
- Convene the first strategic session to align both nations on the Builder's Foundation strategic path
- Formalize the relationship and reporting lines between the Steering Committee and all subordinate governance bodies

**Membership:**

- Minister of Transport, Spain (or designated delegate)
- Minister of Equipment and Transport, Morocco (or designated delegate)
- Chair of the Neutral Third-Party Engineering Consortium
- Head of the Bilateral Diplomatic Task Force
- Chief Financial Officer of the International Consortium Financing Entity
- Independent External Member - Former Head of International Maritime Organization (IMO)
- Independent External Member - Senior Megaproject Governance Expert (non-aligned nation)
- Regional Governor of Andalusia (Spain) - representative of local stakeholder interests
- Regional Governor of Tanger-Tetouan-Al Hoceima (Morocco) - representative of local stakeholder interests
- Secretary General of the Strait of Gibraltar Joint Coordination Center (non-voting advisor)

**Decision Rights:** Approve all strategic decisions including: budgets exceeding €50 million; changes to project scope, timeline exceeding 6 months, or governance structure; appointment/removal of the neutral third-party consortium leadership; approval of phase-gate milestones; ratification of bilateral treaty amendments; authorization of contingency reserve drawdowns exceeding €250 million; and any decisions affecting cross-border sovereignty arrangements or international treaty obligations. Decisions require consensus or qualified majority (2/3 of voting members including at least one representative from each sovereign nation).

**Decision Mechanism:** Decisions are made by qualified majority vote requiring at least two-thirds of voting members, with the mandatory condition that at least one representative from each sovereign nation (Spain and Morocco) votes in favor. In the event of a deadlock where consensus cannot be reached, the matter is escalated to the Bilateral Diplomatic Task Force for mediation within 30 days. If mediation fails, the dispute is referred to binding international arbitration under ICC rules. The Chair holds a casting vote only on procedural matters, not substantive decisions, to prevent unilateral dominance.

**Meeting Cadence:** Quarterly formal meetings (minimum 4 per year), with additional extraordinary sessions convened within 14 days if triggered by any of the following: a risk event exceeding €500 million in potential impact; a governance dispute between Spain and Morocco; a critical phase-gate decision; or a request from the Project Management Office for strategic escalation. Pre-meeting briefing packages distributed 21 days in advance.

**Typical Agenda Items:**

- Review of quarterly financial performance against the €40 billion budget envelope and contingency reserve status
- Approval of phase-gate milestones for functional-subsystem transitions (pillars/buoyancy → rail → sealing/pressurization)
- Cross-border diplomatic alignment update and bilateral treaty compliance status
- Review of major risk register updates and mitigation strategy effectiveness
- Approval of major procurement contracts exceeding €50 million threshold
- Investor confidence briefing and tranche-based financing disbursement authorization
- Review of IMO transboundary environmental assessment progress
- Strategic risk oversight: geopolitical, financial sustainability, and governance alignment
- Review of independent external audit findings and ethics compliance reports

**Escalation Path:** Unresolved strategic disputes between Spain and Morocco that cannot be resolved by the Steering Committee are escalated to the Bilateral Diplomatic Task Force for mediation. If mediation fails within 30 days, the matter is referred to binding ICC arbitration. Financial disputes exceeding the €40 billion envelope or requiring additional sovereign capital commitments are escalated to the respective national parliaments. Technical disputes regarding the unprecedented hybrid floating-pillar architecture are escalated to the Technical Advisory Group for independent validation before returning to the Steering Committee for final decision.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** A dedicated operational management body is essential to coordinate the day-to-day execution of a 20-year, €40 billion construction program involving thousands of personnel, multiple functional subsystems, offshore platforms, and cross-border logistics. The project's functional-subsystem phasing approach requires continuous operational coordination between pillar/buoyancy, rail infrastructure, and sealing/pressurization workstreams. Without a centralized PMO, operational decisions would bottleneck at the strategic level, and the complex interdependencies between construction deployment, subsea logistics, workforce management, and environmental compliance would create coordination failures.

**Responsibilities:**

- Manage day-to-day execution of all construction activities across the three functional-subsystem phases
- Operationalize the functional-subsystem phasing strategy with 4-5 year phase cycles
- Coordinate offshore floating platform operations, fabrication yard activities, and subsea logistics
- Manage operational risks below the €50 million strategic threshold
- Oversee the 8,000-12,000 personnel workforce including rotational and permanent staff management
- Coordinate with the neutral third-party engineering consortium on technical implementation
- Manage weather window scheduling and seasonal construction restrictions
- Maintain the master project schedule with CPM methodology and Monte Carlo simulation updates
- Implement automated budget escalation triggers at 5%, 10%, and 15% utilization thresholds
- Coordinate subsea logistics including material delivery, transport corridors, and offshore staging
- Manage interface coordination with existing surface rail networks on both Spanish and Moroccan sides
- Oversee the deployment and operation of subsea structural surveillance systems

**Initial Setup Actions:**

- Establish the PMO organizational structure with dedicated leads for each functional subsystem (pillars/buoyancy, rail, sealing/pressurization)
- Recruit a Project Director and Deputy Project Director with megaproject offshore construction experience
- Develop the detailed CPM master schedule with phase-gate milestones and inter-phase buffers
- Set up the automated budget tracking and escalation trigger system across all cost centers
- Establish communication protocols and reporting lines to the Steering Committee, Technical Advisory Group, and Risk Management Committee
- Create the operational risk register with defined thresholds for escalation to strategic bodies
- Establish coordination protocols with the neutral third-party engineering consortium
- Set up the knowledge management system for institutional knowledge preservation across the 20-year horizon

**Membership:**

- Project Director (reports to the Steering Committee Chair)
- Deputy Project Director
- Phase 1 Lead (Pillars and Buoyancy Systems)
- Phase 2 Lead (Rail Infrastructure)
- Phase 3 Lead (Sealing, Pressurization, and Commissioning)
- Head of Subsea Logistics and Supply Chain
- Head of Offshore Workforce Management
- Head of Construction Deployment and Offshore Platforms
- Head of Environmental Compliance and Permitting
- Head of Finance and Budget Control
- Head of Quality Assurance and Inspection
- Head of Health, Safety, and Environment (HSE)
- Head of Technical Surveillance and Monitoring Systems
- Bilateral Coordination Manager (Spain-Morocco interface)
- Risk Manager (reporting line to Risk Management Committee)

**Decision Rights:** Make all operational decisions with financial authority up to €50 million per contract or expenditure, including procurement of materials, services, and equipment; manage workforce deployment and rotational schedules; approve weather-dependent construction scheduling adjustments; authorize operational risk mitigation actions below the €50 million threshold; manage day-to-day subsea logistics and supply chain operations; and implement phase-gate validation procedures. Decisions exceeding €50 million or affecting project scope/timeline by more than 6 months must be escalated to the Project Steering Committee.

**Decision Mechanism:** Operational decisions are made by the relevant Phase Lead or functional head within their delegated authority, with consultation from affected workstreams. Decisions requiring cross-functional input are resolved through the PMO weekly coordination meeting, chaired by the Project Director. In case of disagreement between functional leads, the Project Director makes the final call within 7 days. If the decision involves cross-border implications or exceeds operational authority, it is escalated to the Steering Committee within 48 hours.

**Meeting Cadence:** Weekly coordination meetings (all functional leads), monthly executive review meetings (PMO leadership and key stakeholders), and quarterly strategic reviews with the Steering Committee. Ad-hoc meetings convened within 48 hours for critical operational issues including weather emergencies, supply chain disruptions, or safety incidents.

**Typical Agenda Items:**

- Weekly construction progress update across all three functional subsystems
- Offshore platform operational status and weather window utilization
- Subsea logistics and material delivery status from fabrication yards
- Workforce headcount, turnover rates, and retention metrics
- Budget utilization tracking against automated escalation triggers
- Operational risk register updates and mitigation action status
- Environmental compliance monitoring including cetacean disturbance levels
- Phase-gate readiness assessment and validation testing results
- Interface coordination updates with surface rail networks
- Subsea structural surveillance system performance and anomaly reports
- Supply chain resilience assessment and alternative supplier status

**Escalation Path:** Operational issues exceeding €50 million financial authority or affecting project scope/timeline by more than 6 months are escalated to the Project Steering Committee. Technical disputes regarding the hybrid floating-pillar architecture or buoyancy engineering are escalated to the Technical Advisory Group for independent validation. Operational risks exceeding the defined risk appetite are escalated to the Risk Management Committee. Environmental compliance breaches or threshold exceedances are escalated to the Environmental Oversight Board, which has binding authority to halt construction.
### 3. Technical Advisory Group (TAG)

**Rationale for Inclusion:** The unprecedented nature of this project — a hybrid floating-pillar submerged tunnel at 100 meters below sea level with no existing precedent — demands independent technical validation that cannot be provided by the project's own engineering teams. The interaction between buoyant tunnel segments, vertical pillar members, and hydrodynamic lift at extreme depth creates complex force dynamics that cannot be fully validated through existing models. An independent Technical Advisory Group with external deep-sea engineering expertise is essential to validate the hybrid floating-pillar architecture, review buoyancy engineering designs, assess rail systems integration under pressurized conditions, and provide impartial technical assurance to both the Steering Committee and PMO.

**Responsibilities:**

- Provide independent technical validation of the hybrid floating-pillar architecture at 100-meter depth
- Review and approve scaled physical model testing results (1:50 scale) and finite element analysis
- Validate buoyancy engineering designs including variable-ballast systems and depth control mechanisms
- Assess rail systems integration within the sealed pressurized corridor under 10 atmospheres of external pressure
- Review hydrodynamic load mitigation strategies and their interaction with pillar architecture
- Validate geotechnical anchoring methodology and seismic loading case designs
- Provide independent assessment of corrosion and durability management systems
- Review subsea structural surveillance system design and detection sensitivity specifications
- Validate the fully instrumented prototype segment before mass production approval
- Provide technical opinions on design modifications or unforeseen engineering challenges
- Assess the technical adequacy of climate change adaptation measures (sea level rise, storm intensity)
- Review and certify the 20-year lifecycle cost analysis and maintenance strategy

**Initial Setup Actions:**

- Recruit independent external members with proven expertise in deep-sea marine engineering, buoyancy systems, and pressurized enclosure design
- Establish the Terms of Reference defining the TAG's independent authority to challenge project engineering decisions
- Define the technical review scope including mandatory review gates for prototype testing, model validation, and design certification
- Establish protocols for the TAG to commission independent supplementary testing or analysis at project expense
- Create the technical review schedule aligned with phase-gate milestones and prototype testing timelines
- Establish the relationship between the TAG and the neutral third-party engineering consortium to prevent conflicts of interest
- Set up secure data sharing protocols for accessing sensitive geotechnical, oceanographic, and structural data

**Membership:**

- Chair - Independent Deep-Sea Structural Engineering Expert (external, non-project-affiliated)
- Deep-Sea Marine Engineering Specialist (external, 20+ years offshore experience)
- Buoyancy and Hydrodynamics Expert (external, specialized in submerged structures)
- Pressurized Enclosure and Rail Systems Engineer (external, high-pressure systems expertise)
- Geotechnical and Seismic Engineering Specialist (external, Azores-Gibraltar fault zone experience)
- Corrosion and Materials Science Expert (external, marine environment specialization)
- Structural Health Monitoring and Surveillance Systems Expert (external)
- Climate Adaptation and Oceanographic Projection Specialist (external)
- Representative of the Neutral Third-Party Engineering Consortium (non-voting, technical advisor)
- Head of PMO Technical Division (non-voting, internal liaison)

**Decision Rights:** The TAG has binding authority to approve, conditionally approve, or reject technical designs and engineering decisions related to: the hybrid floating-pillar architecture; buoyancy engineering systems; rail systems integration within the pressurized corridor; geotechnical anchoring methodology; hydrodynamic load mitigation strategies; corrosion protection systems; and subsea structural surveillance system specifications. The TAG can mandate design modifications, require additional testing, or halt technical progress until concerns are resolved. The TAG does not approve financial or strategic decisions, which remain with the Steering Committee and PMO.

**Decision Mechanism:** Technical decisions are made by consensus where possible. In the event of a technical disagreement, the TAG Chair facilitates resolution through independent technical analysis. If consensus cannot be reached within 30 days, the TAG votes by simple majority. In case of a tie, the matter is escalated to the Project Steering Committee with the TAG's technical opinion attached. The TAG maintains the right to commission independent supplementary analysis at project expense when internal data is insufficient for validation.

**Meeting Cadence:** Monthly technical review meetings during active design and construction phases; bi-monthly meetings during operational phases. Additional extraordinary sessions convened within 7 days for critical technical decisions including prototype validation, design modifications, or unforeseen engineering challenges. Pre-meeting technical briefing packages distributed 14 days in advance.

**Typical Agenda Items:**

- Review of 1:50 scale physical model testing results under simulated Gibraltar Strait current conditions
- Validation of hybrid floating-pillar force dynamics at 100-meter depth including buoyancy-pillar interaction
- Assessment of variable-ballast buoyancy system reliability and fail-safe mechanisms
- Review of sealed pressurized rail corridor integrity under 10 atmospheres external hydrostatic pressure
- Validation of geotechnical anchoring methodology against site-specific seismic loading cases
- Review of hydrodynamic load mitigation effectiveness and tunnel profile optimization
- Assessment of multi-layer corrosion protection system performance under accelerated life-cycle testing
- Review of subsea structural surveillance system detection sensitivity and data accuracy
- Validation of fully instrumented prototype segment deployment results
- Assessment of climate change adaptation measures including sea level rise and storm intensity projections
- Review of 20-year lifecycle cost analysis and maintenance strategy technical adequacy

**Escalation Path:** Technical disagreements between the TAG and the neutral third-party engineering consortium that cannot be resolved are escalated to the Project Steering Committee with the TAG's technical opinion attached. If the Steering Committee disagrees with the TAG's technical assessment, the matter is referred to an independent international panel of deep-sea engineering experts for final adjudication. Technical findings indicating imminent structural risk are escalated immediately to the Steering Committee and PMO with authority to halt construction pending resolution.
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** The €40 billion budget envelope, cross-border nature involving two sovereign nations, and the identified corruption risks — including bribery in procurement contracts for buoyant concrete and marine-grade steel, nepotism in consortium leadership selection, conflicts of interest within the neutral engineering firm, kickbacks in offshore platform construction, and trading of diplomatic favors in permitting — create an exceptionally high-risk environment for ethical breaches. A dedicated Ethics & Compliance Committee is essential to proactively prevent, detect, and address corruption, ensure compliance with international anti-corruption standards, and maintain the integrity of governance decisions across both jurisdictions.

**Responsibilities:**

- Establish and enforce the project's code of ethics and anti-corruption policies across all governance bodies and personnel
- Oversee compliance with international anti-corruption regulations including OECD Convention and FCPA standards
- Monitor and audit procurement processes for buoyant concrete, marine-grade steel, mooring systems, and offshore platform construction contracts
- Investigate allegations of bribery, nepotism, conflicts of interest, and kickbacks in project decisions
- Ensure the neutral third-party engineering consortium maintains independence from construction contractors and material suppliers
- Oversee the integrity of the selection process for the neutral consortium leadership and key technical personnel
- Monitor cross-border permitting processes for evidence of trading diplomatic or regulatory favors
- Manage the whistleblower mechanism and anonymous reporting channels with anti-retaliation protections
- Conduct quarterly ethics audits of all project expenditures and governance decisions
- Ensure compliance with GDPR and data protection regulations for sensitive project information
- Oversee the integrity of tranche-based financing disbursements to prevent double-spending or misallocation
- Coordinate with international legal counsel specializing in transboundary infrastructure law

**Initial Setup Actions:**

- Draft and ratify the project's Code of Ethics and Anti-Corruption Policy with input from international legal counsel
- Establish the whistleblower mechanism with anonymous reporting channels and guaranteed anti-retaliation protections
- Define the mandatory independent audit threshold for all procurement contracts exceeding €50 million
- Recruit independent external members with expertise in international anti-corruption law and megaproject governance
- Establish protocols for investigating conflicts of interest within the neutral third-party engineering consortium
- Create the quarterly ethics audit schedule and define audit scope covering all financial and governance activities
- Establish information barriers and conflict-of-interest disclosure requirements for all committee members and project personnel
- Set up secure document handling protocols for sensitive geotechnical and financial information to prevent misuse

**Membership:**

- Chair - Independent International Anti-Corruption Expert (external, non-project-affiliated)
- International Anti-Corruption Law Specialist (external, OECD/FCPA expertise)
- Former Senior Government Ethics Official (external, independent)
- Representative of Spanish Ministry of Finance / Anti-Fraud Office (internal, non-voting advisor)
- Representative of Moroccan Ministry of Finance / Anti-Corruption Agency (internal, non-voting advisor)
- Head of PMO (internal, reporting on procurement and expenditure compliance)
- Head of International Consortium Financing (internal, reporting on fund disbursement integrity)
- Independent External Auditor - Big Four Firm Representative (external, rotating annually)
- Whistleblower Ombudsman (external, independent, handling anonymous reports)
- Data Protection Officer (internal, ensuring GDPR compliance)

**Decision Rights:** The Ethics & Compliance Committee has authority to: halt any procurement process suspected of corruption or conflicts of interest pending investigation; mandate independent audits of any contract or expenditure; recommend removal of personnel or consortium members found to have violated ethical standards; refer criminal matters to appropriate judicial authorities in Spain, Morocco, or international jurisdictions; and require the Steering Committee to reconsider any governance decision found to be compromised by ethical violations. The Committee can issue binding compliance directives that all project personnel and contractors must follow.

**Decision Mechanism:** Investigations and compliance determinations are made by the Committee Chair in consultation with relevant members. Formal findings of ethical violations require a two-thirds majority vote of the Committee. The Committee operates independently of the Steering Committee and PMO in its investigations, with direct reporting lines to both sovereign governments and international oversight bodies. In case of a tie or deadlock, the matter is referred to the independent external auditor for a binding determination.

**Meeting Cadence:** Monthly compliance review meetings; quarterly formal ethics audit sessions; ad-hoc sessions convened within 48 hours for whistleblower reports or suspected corruption incidents. Annual comprehensive ethics review report submitted to the Steering Committee and both sovereign governments.

**Typical Agenda Items:**

- Review of quarterly ethics audit findings across all procurement contracts and expenditure categories
- Investigation status update on whistleblower reports and alleged corruption incidents
- Conflict-of-interest disclosure review for neutral consortium leadership and key personnel
- Procurement compliance review for contracts exceeding €50 million threshold
- Assessment of cross-border permitting processes for evidence of diplomatic favor trading
- Review of tranche-based financing disbursement integrity and prevention of double-spending
- GDPR and data protection compliance status for sensitive project information
- Whistleblower mechanism effectiveness report and anonymous report statistics
- Anti-retaliation protection status for whistleblowers and reporting personnel
- Update on international anti-corruption regulation changes affecting project compliance
- Review of independent external auditor findings and recommended corrective actions

**Escalation Path:** Evidence of criminal corruption is escalated immediately to the relevant judicial authorities in Spain and Morocco, as well as to the OECD Anti-Bribery Convention monitoring body. Ethical violations involving the neutral third-party engineering consortium leadership are escalated to the Project Steering Committee with authority to remove and replace the consortium. Systematic corruption findings that threaten project viability are escalated to both sovereign governments with authority to suspend the project pending investigation. The Committee reports directly to both governments and the international community through the public transparency portal.
### 5. Environmental Oversight Board

**Rationale for Inclusion:** The project crosses international waters and sensitive marine ecosystems in the Strait of Gibraltar, including cetacean migratory routes and benthic habitats. The environmental compliance strategy is one of the five critical strategic levers, and permitting delays can add years to the timeline. The project's elevated pillar configuration, offshore platform construction, and segment placement activities generate noise, sediment plumes, and physical disruption that could trigger regulatory shutdowns, fines of €50-500 million, and mandatory remediation costing €200 million-€1 billion. An independent Environmental Oversight Board with binding authority to halt construction is essential to ensure that environmental thresholds are not exceeded and that the project maintains its social license to operate across both nations and the international community.

**Responsibilities:**

- Exercise binding authority to halt construction if marine mammal disturbance thresholds are exceeded
- Oversee compliance with the IMO transboundary environmental impact assessment framework
- Monitor real-time acoustic monitoring buoy data for cetacean disturbance detection across minimum 10 locations
- Verify adherence to seasonal construction restrictions during cetacean migration periods (spring March-May, autumn September-November)
- Oversee the €200-500 million marine mitigation fund and ecosystem restoration program
- Monitor sediment plume levels, water quality parameters, and benthic habitat preservation status
- Review and approve environmental monitoring data before public disclosure through the transparency portal
- Oversee the independent environmental baseline studies covering cetacean migration, benthic habitats, and water quality
- Verify compliance with artificial reef structure deployment and ecosystem restoration milestones
- Assess the effectiveness of elevated pillar configurations in preserving benthic habitats underneath the tunnel
- Coordinate with the International Maritime Organization on environmental compliance matters
- Publish independent environmental compliance reports accessible to both governments, investors, and the public

**Initial Setup Actions:**

- Establish the Board's binding authority to halt construction through the bilateral treaty and IMO framework
- Recruit independent marine biologists, oceanographers, and environmental scientists with no project affiliation
- Define environmental threshold parameters for cetacean disturbance, sediment plumes, and water quality
- Establish protocols for real-time data sharing from acoustic monitoring buoys and environmental sensors
- Create the environmental baseline study commissioning plan with 24-month field data collection timeline
- Define the marine mitigation fund disbursement criteria and oversight procedures
- Establish the public reporting framework and transparency portal integration for environmental data
- Create emergency response protocols for environmental incidents including cetacean stranding events

**Membership:**

- Chair - Independent Marine Ecosystem Expert (external, international reputation, non-project-affiliated)
- Cetacean Migration and Behavior Specialist (external, independent research institution)
- Deep-Sea Marine Ecologist (external, benthic habitat expertise)
- Oceanographer specializing in Strait of Gibraltar current dynamics and sediment transport (external)
- Environmental Lawyer specializing in international maritime environmental law (external)
- Representative of the International Maritime Organization (IMO) (non-voting advisor)
- Representative of the Spanish National Environmental Agency (internal, non-voting advisor)
- Representative of the Moroccan National Environmental Agency (internal, non-voting advisor)
- Independent Acoustic Monitoring Specialist (external, marine mammal detection technology)
- Representative of Environmental NGOs (non-voting, advisory role)

**Decision Rights:** The Environmental Oversight Board has binding authority to: halt all construction activities immediately if cetacean disturbance thresholds are exceeded; mandate seasonal construction restrictions beyond the standard migration periods if environmental conditions warrant; require modifications to construction methodology that cause excessive seabed disturbance; approve or reject environmental monitoring data before public release; and recommend penalties or remediation orders for environmental non-compliance. The Board's halt-authority is absolute and cannot be overridden by the Steering Committee or PMO without unanimous Board consent and IMO concurrence.

**Decision Mechanism:** Environmental threshold decisions are made by the Board Chair based on real-time monitoring data and established threshold parameters. For non-emergency compliance decisions, the Board votes by simple majority. In the event of a tie, the Chair casts the deciding vote. Emergency halt decisions (e.g., cetacean distress detected) can be made unilaterally by the Chair with immediate effect, followed by Board ratification within 72 hours. All decisions are documented and published through the transparency portal.

**Meeting Cadence:** Weekly environmental monitoring review meetings during construction phases; monthly formal Board sessions; quarterly public environmental compliance reports. Emergency sessions convened immediately upon detection of threshold exceedances or environmental incidents. Real-time monitoring data reviewed continuously through automated alert systems.

**Typical Agenda Items:**

- Review of real-time acoustic monitoring data from all 10+ buoy locations for cetacean disturbance detection
- Assessment of sediment plume levels and water quality parameters along the tunnel corridor
- Verification of seasonal construction restriction compliance during cetacean migration periods
- Review of benthic habitat preservation status underneath elevated pillar configurations
- Monitoring of artificial reef structure deployment progress and ecosystem establishment
- Review of marine mitigation fund disbursements and ecosystem restoration program effectiveness
- Assessment of construction methodology environmental impact including noise and vibration levels
- Review of environmental baseline study findings and updates
- Coordination with IMO on transboundary environmental compliance matters
- Publication of quarterly environmental compliance reports through the public transparency portal
- Review of any environmental incidents, near-misses, or threshold exceedances and corrective actions

**Escalation Path:** Environmental incidents exceeding the Board's authority to remediate (e.g., major cetacean mortality events, significant ecosystem damage) are escalated to the Project Steering Committee and the IMO for immediate review. Systematic environmental non-compliance patterns are escalated to the Ethics & Compliance Committee for investigation of potential regulatory violations. Environmental data suggesting fundamental design flaws (e.g., pillar configuration causing unexpected habitat destruction) are escalated to the Technical Advisory Group for design review. The Board maintains direct communication channels with both sovereign governments and the international community.
### 6. Risk Management Committee

**Rationale for Inclusion:** This project faces an extraordinary risk profile spanning 18 identified risks across technical, financial, environmental, geopolitical, operational, and supply chain domains — including the complete absence of site-specific seismic assessment near the Azores-Gibraltar fault zone, missing energy supply infrastructure, inadequate maritime traffic integration, and the unprecedented nature of the hybrid floating-pillar architecture at 100m depth. The interconnected nature of these risks (governance delays compound financial exposure, technical failures trigger cost overruns, financial constraints limit technical and governance solutions) demands a dedicated enterprise risk management body that transcends individual functional areas and provides holistic risk oversight to all governance bodies.

**Responsibilities:**

- Maintain and update the comprehensive enterprise risk register covering all 18 identified risks and emerging risks
- Conduct quantitative risk assessments including Monte Carlo simulations for cost and schedule impacts
- Monitor the interconnected risk landscape and identify cascading risk scenarios across governance, technical, financial, and environmental domains
- Oversee the €4-6 billion contingency reserve allocation and automated escalation trigger system
- Coordinate risk mitigation actions across all functional subsystems and governance bodies
- Assess the effectiveness of risk mitigation strategies including seismic mitigation, climate adaptation, and flooding protocols
- Monitor currency exchange rate risk between EUR and MAD and the effectiveness of hedging programs
- Track geopolitical risk including changes in government, diplomatic tensions, and treaty compliance
- Oversee the 12-month operational reserve fund and funding cliff prevention strategies
- Coordinate the comprehensive risk assessment for the unprecedented hybrid floating-pillar architecture
- Monitor supply chain resilience risks including single-point-of-failure at centralized mega-hub
- Assess long-term sustainability risks including technological obsolescence and maintenance cost escalation over 20 years

**Initial Setup Actions:**

- Establish the comprehensive enterprise risk register with all 18 identified risks, quantified impacts, and likelihood assessments
- Define the risk appetite statement approved by the Project Steering Committee
- Set up the automated risk escalation trigger system linked to the PMO budget tracking and contingency reserve
- Define risk interconnectivity mapping showing cascading scenarios across governance, technical, financial, and environmental domains
- Establish the Monte Carlo simulation schedule for cost and schedule risk modeling
- Create the risk mitigation tracking system with assigned owners, timelines, and effectiveness metrics
- Define the currency hedging program monitoring framework for EUR/MAD exposure
- Establish protocols for emerging risk identification and assessment

**Membership:**

- Chair - Independent Enterprise Risk Management Expert (external, megaproject risk specialization)
- Chief Risk Officer (internal, reporting to both PMO and Steering Committee)
- Financial Risk Specialist (internal/external, currency, funding continuity, and cost escalation expertise)
- Technical Risk Specialist (internal/external, hybrid floating-pillar and buoyancy engineering risk)
- Geopolitical Risk Specialist (external, cross-border governance and diplomatic risk)
- Environmental Risk Specialist (external, climate change and marine ecosystem risk)
- Supply Chain Risk Specialist (internal/external, logistics and single-point-of-failure risk)
- Insurance and Actuarial Specialist (external, catastrophic risk modeling)
- Head of PMO (internal, operational risk reporting)
- Head of Finance and Budget Control (internal, financial risk reporting)
- Representative of International Consortium Financing (internal, funding continuity risk)

**Decision Rights:** The Risk Management Committee has authority to: mandate risk mitigation actions across all functional subsystems; require additional contingency reserve allocation for specific risk categories; recommend project phase-gate hold decisions if risk levels exceed the approved risk appetite; mandate additional insurance coverage or hedging instruments; and require the PMO to modify construction schedules or methodologies based on risk assessment findings. The Committee can escalate risk findings to the Steering Committee with recommendations for strategic decisions including project scope modification or timeline adjustment.

**Decision Mechanism:** Risk assessments are conducted using quantitative models (Monte Carlo simulation, expected monetary value analysis) supplemented by expert judgment. Risk mitigation priorities are set by consensus, with the Committee Chair breaking ties. When risk interconnectivity creates cascading scenarios that exceed the Committee's mitigation capacity, the matter is escalated to the Steering Committee with a comprehensive risk assessment report and recommended strategic response. Emergency risk situations (e.g., imminent seismic event, major supply chain disruption) can trigger immediate escalation to the Steering Committee and PMO.

**Meeting Cadence:** Bi-monthly risk review meetings; quarterly comprehensive risk assessment reports to the Steering Committee; monthly risk register updates distributed to all governance bodies. Ad-hoc sessions convened within 24 hours for emergency risk situations. Annual comprehensive risk reassessment aligned with the project's phase-gate milestones.

**Typical Agenda Items:**

- Enterprise risk register update including new emerging risks and changes to existing risk assessments
- Monte Carlo simulation results for cost and schedule risk with updated probability distributions
- Assessment of seismic and geotechnic risk including Azores-Gibraltar fault zone monitoring data
- Review of contingency reserve utilization against automated escalation triggers (5%, 10%, 15%)
- Currency exchange rate risk assessment (EUR/MAD) and hedging program effectiveness
- Supply chain resilience assessment including single-point-of-failure analysis and alternative supplier status
- Geopolitical risk update including government changes, diplomatic tensions, and treaty compliance
- Technical risk assessment for hybrid floating-pillar architecture including prototype testing results
- Climate change adaptation progress including sea level rise and storm intensity projection updates
- Maritime traffic integration risk assessment including collision probability and current deflection analysis
- Long-term sustainability risk assessment including technological obsolescence and maintenance cost escalation
- Funding continuity risk assessment including tranche-based financing cliff prevention
- Flooding and water intrusion risk assessment including hull integrity monitoring system status

**Escalation Path:** Risk events exceeding the approved risk appetite or requiring strategic-level decisions (e.g., project scope modification, timeline adjustment, additional sovereign capital) are escalated to the Project Steering Committee. Technical risks requiring independent validation are escalated to the Technical Advisory Group. Financial risks requiring contingency reserve drawdowns exceeding €250 million are escalated to the Steering Committee for approval. Environmental risks exceeding established thresholds are escalated to the Environmental Oversight Board. Geopolitical risks requiring diplomatic intervention are escalated to the Bilateral Diplomatic Task Force. The Committee maintains a direct emergency escalation channel to the Steering Committee Chair for imminent catastrophic risks.

# Governance Implementation Plan

### 1. Project Sponsor (Joint Spanish-Moroccan Government) initiates governance framework design by commissioning a senior governance advisor to draft the overall governance architecture document, defining the hierarchy, reporting lines, and authority boundaries for all six governance bodies

**Responsible Body/Role:** Project Sponsor (Joint Spanish-Moroccan Government) via designated Senior Governance Advisor

**Suggested Timeframe:** Project Week 1-2

**Key Outputs/Deliverables:**

- Governance Architecture Document v0.1
- Initial governance body hierarchy map
- Draft authority and reporting framework

**Dependencies:**

- Project formally authorized and funded
- Bilateral government commitment secured

### 2. Bilateral Diplomatic Task Force drafts and negotiates the foundational bilateral treaty framework that establishes the legal basis for the project governance structure, including provisions for the Steering Committee's sovereign authority and the neutral third-party consortium model

**Responsible Body/Role:** Bilateral Diplomatic Task Force (Spain-Morocco)

**Suggested Timeframe:** Project Week 1-8 (ongoing negotiation)

**Key Outputs/Deliverables:**

- Draft Bilateral Treaty Framework
- Treaty provisions for governance structure
- Pre-negotiated dispute resolution clauses

**Dependencies:**

- Governance Architecture Document approved by both governments
- Political commitment from both sovereign nations

### 3. Senior Governance Advisor drafts the initial Terms of Reference (ToR) for the Project Steering Committee, including membership criteria, decision rights, meeting cadence, and escalation protocols, based on the approved governance architecture

**Responsible Body/Role:** Senior Governance Advisor (designated by Project Sponsor)

**Suggested Timeframe:** Project Week 2-3

**Key Outputs/Deliverables:**

- Draft Steering Committee ToR v0.1
- Proposed membership roster with role descriptions
- Draft decision rights matrix

**Dependencies:**

- Governance Architecture Document approved
- Bilateral Treaty Framework initial draft available

### 4. Project Sponsor circulates the Draft Steering Committee ToR to nominated members and key stakeholders (Ministry of Transport Spain, Ministry of Equipment and Transport Morocco, nominated independent members) for review and feedback

**Responsible Body/Role:** Project Sponsor (Joint Spanish-Moroccan Government)

**Suggested Timeframe:** Project Week 3-4

**Key Outputs/Deliverables:**

- Circulated Draft SteerCo ToR for review
- Feedback summary from nominated members
- List of required revisions

**Dependencies:**

- Draft Steering Committee ToR v0.1 completed
- Nominated members list confirmed

### 5. Project Sponsor finalizes the Steering Committee ToR incorporating feedback, and formally requests both parliaments (Spanish Cortes Generales and Moroccan Parliament) to ratify the governance charter as part of the bilateral treaty

**Responsible Body/Role:** Project Sponsor (Joint Spanish-Moroccan Government) via International Legal Counsel

**Suggested Timeframe:** Project Week 4-6

**Key Outputs/Deliverables:**

- Finalized Steering Committee ToR v1.0
- Formal parliamentary ratification request
- International legal opinion on governance charter

**Dependencies:**

- Review feedback incorporated
- Bilateral Treaty Framework sufficiently advanced
- International legal counsel retained

### 6. Project Sponsor formally appoints the Steering Committee Chair (senior Spanish representative) and Vice-Chair (senior Moroccan representative) through official government designation, establishing initial leadership for the governance body

**Responsible Body/Role:** Project Sponsor (Joint Spanish-Moroccan Government)

**Suggested Timeframe:** Project Week 5-7 (concurrent with parliamentary ratification)

**Key Outputs/Deliverables:**

- Official appointment of Steering Committee Chair
- Official appointment of Steering Committee Vice-Chair
- Appointment confirmation communications

**Dependencies:**

- Finalized Steering Committee ToR approved by Project Sponsor
- Bilateral government agreement on Chair/Vice-Chair candidates

### 7. Project Sponsor confirms and formally notifies all nominated Steering Committee members (Ministers, consortium Chair, diplomatic task force head, independent external members, regional governors) of their appointments and the governance charter obligations

**Responsible Body/Role:** Project Sponsor (Joint Spanish-Moroccan Government)

**Suggested Timeframe:** Project Week 6-8

**Key Outputs/Deliverables:**

- Confirmed Steering Committee membership roster
- Formal appointment letters to all members
- Governance charter acceptance acknowledgments

**Dependencies:**

- Steering Committee Chair and Vice-Chair appointed
- All nominated members identified and approached
- Parliamentary ratification process initiated

### 8. Steering Committee holds its formal inaugural kick-off meeting, ratifies its own ToR, defines financial approval thresholds, and establishes the strategic direction and governance framework for all subordinate bodies

**Responsible Body/Role:** Project Steering Committee (formally constituted)

**Suggested Timeframe:** Project Week 8-9

**Key Outputs/Deliverables:**

- Steering Committee inaugural meeting minutes
- Ratified Steering Committee ToR
- Defined financial approval thresholds
- Strategic framework approval
- Formal establishment of all reporting lines

**Dependencies:**

- All Steering Committee members confirmed and appointed
- Finalized ToR ratified by both parliaments (or interim authorization)
- Chair and Vice-Chair formally designated

### 9. Steering Committee approves the Terms of Reference for the Project Management Office (PMO), including its organizational structure, delegated authority thresholds, and reporting lines to the Steering Committee

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 9-10

**Key Outputs/Deliverables:**

- Approved PMO Terms of Reference
- PMO organizational structure chart
- Delegated authority matrix (up to €50 million)

**Dependencies:**

- Steering Committee formally constituted and operational
- PMO ToR drafted by Interim PMO Formation Lead

### 10. Interim PMO Formation Lead (designated by Project Sponsor) drafts the initial PMO ToR, organizational structure, and key operational protocols, including CPM master schedule framework and automated budget escalation trigger specifications

**Responsible Body/Role:** Interim PMO Formation Lead (designated by Project Sponsor)

**Suggested Timeframe:** Project Week 3-5 (parallel with Steering Committee setup)

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1
- Proposed PMO organizational structure
- Draft CPM master schedule framework
- Budget escalation trigger specifications

**Dependencies:**

- Governance Architecture Document approved
- Project phase-gate strategy defined

### 11. Steering Committee appoints the Project Director and Deputy Project Director for the PMO, and formally constitutes the PMO with all functional leads (Phase 1, 2, 3, Logistics, Workforce, HSE, etc.)

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 10-11

**Key Outputs/Deliverables:**

- Appointed Project Director and Deputy Director
- Confirmed PMO functional leads
- Formally constituted PMO membership roster

**Dependencies:**

- PMO ToR approved by Steering Committee
- Candidate shortlist for Project Director prepared
- Steering Committee operational

### 12. PMO holds its inaugural kick-off meeting, assigns initial operational tasks, establishes the weekly coordination meeting cadence, and begins setting up the automated budget tracking and escalation trigger system

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 11-12

**Key Outputs/Deliverables:**

- PMO inaugural meeting minutes
- Operational task assignments
- Weekly coordination meeting schedule established
- Budget tracking system initialization

**Dependencies:**

- PMO formally constituted with all members
- PMO ToR approved
- Project Director appointed

### 13. Steering Committee approves the Terms of Reference for the Technical Advisory Group (TAG), defining its independent authority to challenge engineering decisions, mandatory review gates, and relationship protocols with the neutral third-party engineering consortium

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 10-12

**Key Outputs/Deliverables:**

- Approved TAG Terms of Reference
- TAG independence protocols
- Technical review gate schedule aligned with phase-gates

**Dependencies:**

- Steering Committee formally constituted
- TAG ToR drafted by designated formation lead
- TAG member candidate list developed

### 14. Interim TAG Formation Lead (designated by Project Sponsor with Steering Committee oversight) recruits independent external members with expertise in deep-sea engineering, buoyancy systems, pressurized enclosures, and seismic engineering, and drafts the TAG's technical review scope

**Responsible Body/Role:** Interim TAG Formation Lead (designated by Project Sponsor)

**Suggested Timeframe:** Project Week 5-10 (parallel with other setups)

**Key Outputs/Deliverables:**

- TAG member recruitment completed
- TAG ToR v0.1 drafted
- Technical review scope document
- Conflict-of-interest protocols

**Dependencies:**

- TAG ToR framework approved by Steering Committee
- Candidate profiles for external experts defined
- Budget allocated for TAG operations

### 15. Steering Committee formally appoints the TAG Chair (independent deep-sea structural engineering expert) and confirms all TAG members, establishing the group's operational independence from the project's own engineering teams

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 12-13

**Key Outputs/Deliverables:**

- TAG Chair formally appointed
- Confirmed TAG membership roster
- TAG independence declaration signed
- TAG formally constituted

**Dependencies:**

- TAG ToR approved
- All TAG members recruited and vetted
- TAG member acceptance confirmed

### 16. TAG holds its inaugural kick-off meeting, establishes the technical review schedule aligned with phase-gate milestones, sets up secure data sharing protocols, and defines the relationship with the neutral third-party engineering consortium

**Responsible Body/Role:** Technical Advisory Group (TAG)

**Suggested Timeframe:** Project Week 13-14

**Key Outputs/Deliverables:**

- TAG inaugural meeting minutes
- Technical review schedule
- Data sharing protocols established
- TAG-Consortium relationship framework

**Dependencies:**

- TAG formally constituted
- TAG Chair appointed
- TAG ToR ratified

### 17. Steering Committee approves the Terms of Reference for the Ethics & Compliance Committee, defining its anti-corruption authority, whistleblower mechanisms, procurement audit thresholds, and reporting lines to both sovereign governments

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 12-14

**Key Outputs/Deliverables:**

- Approved Ethics & Compliance Committee ToR
- Whistleblower mechanism framework
- Procurement audit threshold definitions
- Reporting protocols to sovereign governments

**Dependencies:**

- Steering Committee formally constituted
- Ethics Committee ToR drafted by designated formation lead

### 18. Interim Ethics & Compliance Formation Lead (designated by Project Sponsor) drafts the initial Ethics & Compliance Committee ToR, Code of Ethics and Anti-Corruption Policy framework, and whistleblower mechanism specifications

**Responsible Body/Role:** Interim Ethics & Compliance Formation Lead (designated by Project Sponsor)

**Suggested Timeframe:** Project Week 4-8 (parallel with other setups)

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1
- Code of Ethics and Anti-Corruption Policy draft
- Whistleblower mechanism design
- Quarterly audit schedule framework

**Dependencies:**

- Governance Architecture Document approved
- International legal counsel retained
- OECD/FCPA compliance requirements identified

### 19. Steering Committee formally appoints the Ethics & Compliance Committee Chair (independent international anti-corruption expert) and confirms all members, including external auditors and the whistleblower ombudsman

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 14-15

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Chair appointed
- Confirmed membership roster
- Committee formally constituted
- Anti-retaliation protections established

**Dependencies:**

- Ethics & Compliance Committee ToR approved
- All members recruited and vetted
- Independent auditor engagement confirmed

### 20. Ethics & Compliance Committee holds its inaugural kick-off meeting, ratifies the Code of Ethics and Anti-Corruption Policy, activates the whistleblower mechanism, and establishes the quarterly ethics audit schedule

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 15-16

**Key Outputs/Deliverables:**

- Inaugural meeting minutes
- Ratified Code of Ethics and Anti-Corruption Policy
- Active whistleblower mechanism
- Quarterly audit schedule confirmed

**Dependencies:**

- Committee formally constituted
- Chair appointed
- ToR ratified

### 21. Steering Committee approves the Terms of Reference for the Environmental Oversight Board, defining its binding authority to halt construction, environmental threshold parameters, and relationship with the IMO and national environmental agencies

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 14-16

**Key Outputs/Deliverables:**

- Approved Environmental Oversight Board ToR
- Environmental threshold parameters defined
- Binding halt-authority provisions formalized
- IMO coordination protocols established

**Dependencies:**

- Steering Committee formally constituted
- Environmental Oversight Board ToR drafted by designated formation lead

### 22. Interim Environmental Oversight Formation Lead (designated by Project Sponsor) drafts the Environmental Oversight Board ToR, defines environmental threshold parameters for cetacean disturbance and sediment plumes, and establishes the marine mitigation fund oversight framework

**Responsible Body/Role:** Interim Environmental Oversight Formation Lead (designated by Project Sponsor)

**Suggested Timeframe:** Project Week 6-12 (parallel with other setups)

**Key Outputs/Deliverables:**

- Draft Environmental Oversight Board ToR v0.1
- Environmental threshold parameter document
- Marine mitigation fund oversight framework
- Emergency response protocol draft

**Dependencies:**

- Environmental Compliance Strategy defined
- IMO engagement framework established
- Marine ecosystem baseline study plan approved

### 23. Steering Committee formally appoints the Environmental Oversight Board Chair (independent marine ecosystem expert) and confirms all members, including cetacean specialists, oceanographers, and IMO representative

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 16-17

**Key Outputs/Deliverables:**

- Environmental Oversight Board Chair appointed
- Confirmed membership roster
- Board formally constituted
- Binding halt-authority activated

**Dependencies:**

- Environmental Oversight Board ToR approved
- All members recruited and vetted
- IMO representative confirmed

### 24. Environmental Oversight Board holds its inaugural kick-off meeting, establishes real-time monitoring data sharing protocols from acoustic buoys, defines emergency halt procedures, and publishes the first environmental compliance framework

**Responsible Body/Role:** Environmental Oversight Board

**Suggested Timeframe:** Project Week 17-18

**Key Outputs/Deliverables:**

- Inaugural meeting minutes
- Real-time monitoring data sharing protocols
- Emergency halt procedures documented
- Environmental compliance framework published

**Dependencies:**

- Board formally constituted
- Chair appointed
- ToR ratified

### 25. Steering Committee approves the Terms of Reference for the Risk Management Committee, defining its enterprise risk oversight authority, contingency reserve management protocols, and automated escalation trigger linkages to the PMO budget system

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 16-18

**Key Outputs/Deliverables:**

- Approved Risk Management Committee ToR
- Risk appetite statement (approved by Steering Committee)
- Contingency reserve management protocols
- Automated escalation trigger linkages defined

**Dependencies:**

- Steering Committee formally constituted
- Risk Management Committee ToR drafted by designated formation lead
- Risk register framework developed

### 26. Interim Risk Management Formation Lead (designated by Project Sponsor) drafts the Risk Management Committee ToR, establishes the comprehensive enterprise risk register with all 18 identified risks, and defines the Monte Carlo simulation schedule and risk interconnectivity mapping

**Responsible Body/Role:** Interim Risk Management Formation Lead (designated by Project Sponsor)

**Suggested Timeframe:** Project Week 8-14 (parallel with other setups)

**Key Outputs/Deliverables:**

- Draft Risk Management Committee ToR v0.1
- Comprehensive enterprise risk register
- Risk interconnectivity mapping
- Monte Carlo simulation schedule

**Dependencies:**

- Risk assessment and mitigation strategies defined
- PMO budget tracking system initialized
- Financial risk parameters established

### 27. Steering Committee formally appoints the Risk Management Committee Chair (independent enterprise risk management expert) and confirms all members, including specialists for financial, technical, geopolitical, and environmental risk domains

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 18-19

**Key Outputs/Deliverables:**

- Risk Management Committee Chair appointed
- Confirmed membership roster
- Committee formally constituted
- Risk appetite statement ratified

**Dependencies:**

- Risk Management Committee ToR approved
- All members recruited and vetted
- Risk register validated

### 28. Risk Management Committee holds its inaugural kick-off meeting, establishes the automated risk escalation trigger system linked to the PMO budget tracking, and initiates the first comprehensive risk assessment using Monte Carlo simulation

**Responsible Body/Role:** Risk Management Committee

**Suggested Timeframe:** Project Week 19-20

**Key Outputs/Deliverables:**

- Inaugural meeting minutes
- Automated escalation trigger system activated
- First Monte Carlo simulation results
- Risk register distributed to all governance bodies

**Dependencies:**

- Committee formally constituted
- Chair appointed
- ToR ratified
- PMO budget tracking system operational

### 29. All six governance bodies hold a joint inaugural governance summit to align on the Builder's Foundation strategic path, establish cross-body coordination protocols, and formalize the overall governance operational framework

**Responsible Body/Role:** Project Steering Committee (coordinating), all governance bodies

**Suggested Timeframe:** Project Week 20-21

**Key Outputs/Deliverables:**

- Joint governance summit minutes
- Cross-body coordination protocols
- Overall governance operational framework
- Strategic alignment confirmation on Builder's Foundation path

**Dependencies:**

- All six governance bodies formally constituted
- All inaugural kick-off meetings completed
- Steering Committee operational

### 30. Steering Committee reviews and approves the complete governance implementation status, confirms all delegated authority thresholds are operational, and authorizes the PMO to commence full-scale operational activities including construction mobilization preparation

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 22-24

**Key Outputs/Deliverables:**

- Governance implementation completion report
- Approved authority threshold confirmation
- Authorization for construction mobilization
- Operational governance framework certified

**Dependencies:**

- All governance bodies fully operational
- Joint governance summit completed
- All ToRs ratified and implemented
- PMO operational with budget tracking active

# Decision Escalation Matrix

**Budget Request Exceeding PMO Financial Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee qualified majority vote requiring at least two-thirds of voting members, with the mandatory condition that at least one representative from each sovereign nation (Spain and Morocco) votes in favor
Rationale: The PMO's delegated financial authority is strictly capped at €50 million per contract or expenditure; any request exceeding this threshold directly impacts the €40 billion total capital envelope and requires strategic-level sovereign approval beyond operational management
Negative Consequences: Unauthorized spending, budget overrun, covenant breaches with private equity investors, and potential loss of tranche-based financing due to lack of strategic oversight

**Technical Deadlock on Unprecedented Hybrid Floating-Pillar Architecture Validation**
Escalation Level: Project Steering Committee
Approval Process: Technical Advisory Group (TAG) provides independent technical opinion; Steering Committee makes final decision based on TAG's binding technical assessment; if Steering Committee disagrees with TAG, referred to an independent international panel of deep-sea engineering experts for final adjudication
Rationale: The unprecedented nature of the hybrid floating-pillar architecture at 100-meter depth creates complex force dynamics that cannot be fully validated through existing models; requires independent technical validation and sovereign-level authority to mandate design modifications or halt construction
Negative Consequences: Structural miscalculations causing tunnel segment misalignment or uncontrolled depth variation, catastrophic safety incidents, €500 million-€2 billion per incident replacement costs, and 6-18 months of redesign delay per failure

**Critical Environmental Threshold Exceedance Requiring Sovereign Intervention**
Escalation Level: Project Steering Committee and International Maritime Organization (IMO)
Approval Process: Environmental Oversight Board exercises binding authority to halt construction; if incident exceeds Board's remediation authority (e.g., major cetacean mortality event), escalated to Steering Committee and IMO for immediate review; Board's halt-authority cannot be overridden without unanimous Board consent and IMO concurrence
Rationale: Major environmental incidents exceed the Board's operational authority to remediate and require sovereign diplomatic intervention and international regulatory compliance under the IMO transboundary environmental framework
Negative Consequences: Regulatory shutdown, fines of €50-500 million, mandatory remediation costing €200 million-€1 billion, severe reputational damage, loss of social license to operate, and potential project cancellation

**Evidence of Criminal Corruption or Systematic Ethical Violations**
Escalation Level: Relevant Judicial Authorities (Spain and Morocco) and Project Steering Committee
Approval Process: Ethics & Compliance Committee investigates and refers criminal matters to appropriate judicial authorities in Spain, Morocco, or international jurisdictions; Steering Committee receives recommendations to remove neutral consortium leadership or reconsider governance decisions compromised by ethical violations
Rationale: Criminal matters require judicial authority beyond the Committee's internal power; systematic corruption threatens project viability and requires sovereign-level intervention to maintain governance integrity and investor confidence
Negative Consequences: Legal penalties and criminal prosecution, project suspension lasting 1-3 years, loss of investor confidence, erosion of public support, and potential total loss of invested capital

**Unresolved Cross-Border Governance Deadlock Between Spain and Morocco**
Escalation Level: Bilateral Diplomatic Task Force and International Chamber of Commerce (ICC) Arbitration
Approval Process: Steering Committee deadlock (unable to reach consensus or qualified majority with both sovereign nations) is escalated to Bilateral Diplomatic Task Force for mediation within 30 days; if mediation fails, dispute is referred to binding international arbitration under ICC rules
Rationale: Sovereign diplomatic disputes between Spain and Morocco cannot be resolved by the Steering Committee alone; require diplomatic negotiation and binding international arbitration to prevent project stall at the midpoint where both jurisdictions must simultaneously contribute resources
Negative Consequences: Project stall of 1-3 years, €2-6 billion in carrying costs, erosion of investor confidence, potential treaty violation, and project cancellation due to diplomatic crisis

**Risk Event Exceeding Approved Risk Appetite or Requiring Major Contingency Drawdown**
Escalation Level: Project Steering Committee
Approval Process: Risk Management Committee monitors enterprise risk register and mandates mitigation actions; if risk exceeds approved risk appetite or requires contingency reserve drawdown exceeding €250 million, escalated to Steering Committee for approval of strategic decisions including project scope modification or timeline adjustment
Rationale: Risk Management Committee's authority is limited to risk mitigation within the approved risk appetite; major contingency drawdowns require strategic-level approval of the €40 billion budget envelope and sovereign capital commitments
Negative Consequences: Financial exposure exceeding €4-6 billion contingency reserve, inability to mitigate cascading interconnected risks, covenant breaches, investor withdrawal, and forced restructuring of the €40 billion financing

# Monitoring Progress

### 1. Overall Project Schedule and KPI Tracking Against 20-Year Master Plan
**Monitoring Tools/Platforms:**

  - Project Management Software Dashboard
  - CPM Master Schedule with Monte Carlo Simulation
  - KPI Tracking Spreadsheet
  - Phase-Gate Readiness Reports

**Frequency:** Weekly (PMO coordination meeting), Monthly (executive review)

**Responsible Role:** Project Management Office (PMO)

**Adaptation Process:** PMO proposes schedule adjustments, resource reallocations, and phase-gate go/no-go decisions via Change Request to the Steering Committee. The Steering Committee approves major timeline modifications exceeding 6 months and validates functional-subsystem phase transitions.

**Adaptation Trigger:** Any phase-gate milestone deviation exceeding 10%, cumulative schedule slip exceeding 6 months, or automated escalation triggers at 5%, 10%, and 15% budget utilization. Weather window utilization falling below 70% of planned also triggers adjustment.

### 2. Cross-Border Governance and Diplomatic Alignment Monitoring
**Monitoring Tools/Platforms:**

  - Bilateral Treaty Compliance Tracker
  - Steering Committee Meeting Minutes and Decision Logs
  - Bilateral Diplomatic Task Force Status Reports
  - Parliamentary Ratification Progress Dashboard

**Frequency:** Quarterly (Steering Committee formal meetings), with extraordinary sessions within 14 days for disputes

**Responsible Role:** Project Steering Committee, supported by Bilateral Diplomatic Task Force

**Adaptation Process:** Steering Committee escalates unresolved sovereign disputes to the Bilateral Diplomatic Task Force for mediation within 30 days. If mediation fails, disputes are referred to binding ICC arbitration. Treaty amendments are ratified through both Spanish Cortes Generales and Moroccan Parliament. Emergency diplomatic interventions are activated for crises threatening project continuity.

**Adaptation Trigger:** Governance deadlock where consensus cannot be reached within 30 days, any risk event exceeding €500 million in potential impact, diplomatic tensions between Spain and Morocco affecting project commitments, or changes in government in either nation altering political support or funding guarantees.

### 3. Hybrid Floating-Pillar Architecture Technical Validation and Monitoring
**Monitoring Tools/Platforms:**

  - 1:50 Scale Physical Model Testing Results
  - Finite Element Analysis Reports
  - Fully Instrumented Prototype Segment Data
  - TAG Technical Review Reports
  - Deep-Water Basin Test Data

**Frequency:** Monthly (TAG technical review meetings), with extraordinary sessions within 7 days for critical technical decisions

**Responsible Role:** Technical Advisory Group (TAG), with neutral third-party engineering consortium support

**Adaptation Process:** TAG mandates design modifications or requires additional testing when force dynamics exceed validated parameters. If TAG and the neutral consortium disagree, the matter is escalated to the Steering Committee with TAG's technical opinion attached. If the Steering Committee disagrees with TAG, it is referred to an independent international panel of deep-sea engineering experts for final adjudication. Prototype testing results directly inform mass production approval gates.

**Adaptation Trigger:** Prototype testing reveals structural miscalculations or force dynamics exceeding design parameters, finite element analysis shows unacceptable risk of segment misalignment or uncontrolled depth variation, any structural anomaly detected during instrumentation at 100m equivalent depth, or hydrodynamic load measurements exceeding design tolerances.

### 4. Environmental Compliance and Permitting Progress Monitoring
**Monitoring Tools/Platforms:**

  - IMO Transboundary Environmental Assessment Progress Tracker
  - Real-Time Acoustic Monitoring Buoy Data (10+ locations)
  - Environmental Oversight Board Meeting Records
  - Marine Mitigation Fund Disbursement Reports
  - Cetacean Disturbance Detection Logs

**Frequency:** Weekly (environmental monitoring review during construction), Monthly (formal Board sessions), Quarterly (public compliance reports)

**Responsible Role:** Environmental Oversight Board, with IMO coordination and independent marine biologists

**Adaptation Process:** The Board exercises binding authority to halt construction if thresholds are exceeded, mandates seasonal construction restrictions beyond standard migration periods, and requires methodology modifications. Major incidents exceeding the Board's remediation authority are escalated to the Steering Committee and IMO for immediate review. Systematic non-compliance patterns are escalated to the Ethics & Compliance Committee. The Board's halt-authority cannot be overridden without unanimous Board consent and IMO concurrence.

**Adaptation Trigger:** Cetacean disturbance thresholds exceeded, sediment plume levels exceeding established limits, permitting delays exceeding 12 months, environmental litigation filed by NGOs or coastal communities, any threshold exceedance detected by real-time monitoring buoys, or seasonal construction restriction violations.

### 5. Financial Performance, Budget Contingency, and Tranche Financing Monitoring
**Monitoring Tools/Platforms:**

  - Automated Budget Tracking and Escalation Trigger System
  - Quarterly Financial Performance Reports
  - Contingency Reserve Utilization Dashboard (€4-6 billion)
  - Tranche-Based Financing Disbursement Tracker
  - Monte Carlo Cost Risk Simulation Results

**Frequency:** Monthly (budget tracking), Quarterly (financial reviews), with automated real-time escalation triggers

**Responsible Role:** Project Management Office (PMO) with Risk Management Committee oversight; Steering Committee approval for drawdowns exceeding €250 million

**Adaptation Process:** PMO implements automated escalation triggers at 5%, 10%, and 15% budget utilization. Risk Management Committee mandates additional contingency allocation for specific risk categories. Steering Committee approves scope/timeline adjustments and contingency drawdowns exceeding €250 million. Funding cliff prevention strategies are activated when tranche disbursements are at risk, including reserve fund deployment covering 12 months of operational costs.

**Adaptation Trigger:** Budget utilization reaching automated trigger thresholds (5%, 10%, 15%), cost overrun exceeding 10-15% of the €40 billion envelope (€4-6 billion), funding gap of 6-12 months threatening construction continuity, contingency reserve drawdown exceeding €250 million, or cost escalation adding €300-600 million per additional year of construction.

### 6. Construction Deployment and Offshore Platform Operations Monitoring
**Monitoring Tools/Platforms:**

  - Offshore Platform Operational Status Dashboard
  - Weather Window Utilization Reports
  - Segment Placement Accuracy Logs
  - Construction Deployment Schedule Tracker
  - Platform Structural Integrity Reports

**Frequency:** Weekly (coordination meetings), Daily (platform operational monitoring during active construction)

**Responsible Role:** Project Management Office (PMO), specifically Head of Construction Deployment and Offshore Platforms

**Adaptation Process:** PMO adjusts weather-dependent scheduling and deploys emergency response protocols for platform damage. Deployment methodology is modified based on installation feedback and prototype validation results. Platform damage or segment displacement incidents are escalated to the Steering Committee with repair cost estimates and timeline impacts. Platforms are designed to withstand 100-year storm events with redundant structural systems.

**Adaptation Trigger:** Platform damage from severe storm events (€200-800 million repair cost), tunnel segment displacement or loss during placement (€100-500 million), weather window utilization falling below planned thresholds, installation precision deviations exceeding tolerance limits, or any safety incident requiring project shutdown.

### 7. Buoyancy Engineering and Structural Integrity Monitoring at 100m Depth
**Monitoring Tools/Platforms:**

  - Real-Time Depth Monitoring and Ballast Control Systems
  - Fiber-Optic Acoustic Sensor Mesh Data
  - Pillar-Tunnel Interface Force Measurements
  - Hydrodynamic Load Monitoring Data
  - Accelerated Life-Cycle Testing Results

**Frequency:** Monthly (TAG technical review), Continuous (real-time monitoring systems)

**Responsible Role:** Technical Advisory Group (TAG), with PMO operational monitoring support

**Adaptation Process:** TAG mandates buoyancy system modifications or redundant system additions when performance degrades. PMO implements operational adjustments to ballast settings based on real-time depth data. Structural integrity concerns trigger construction halts pending TAG resolution. Passive fail-safe mechanisms defaulting to safe neutral buoyancy are activated upon detection of active system failure. Accelerated life-cycle testing under simulated 20-year saline exposure informs maintenance schedules.

**Adaptation Trigger:** Depth variance exceeding design tolerance, ballast system mechanical failure or degradation, pillar-tunnel interface force measurements exceeding design parameters, uncontrolled surfacing or seabed contact detected, active ballast system failure requiring emergency passive fail-safe activation, or accelerated life-cycle testing revealing failure before the 20-year horizon.

### 8. Rail Systems Integration and Pressurized Corridor Validation Monitoring
**Monitoring Tools/Platforms:**

  - Pressurized Rail Prototype Test Data
  - Track Geometry Precision Measurements
  - Ventilation and Pressurization System Performance Logs
  - Surface Rail Interface Compatibility Studies
  - Emergency Depressurization System Test Results

**Frequency:** Monthly (TAG technical review), Quarterly (full-scale prototype testing)

**Responsible Role:** Technical Advisory Group (TAG) with PMO and joint interface teams from Spanish and Moroccan rail operators

**Adaptation Process:** TAG mandates rail system design modifications when track geometry deviations or pressurization failures are detected. Joint interface teams coordinate gauge, signaling (ERTMS), and electrification compatibility studies with national rail operators. Pressurization failures trigger emergency depressurization protocols and system redesign. Modular track sections with active compensation systems are deployed to address thermal and pressure-induced deformation. Gauge transition infrastructure (€200-500 million) is budgeted for Iberian-to-standard gauge conversion.

**Adaptation Trigger:** Track geometry deviations requiring speed restrictions (cutting projected revenue by 20-40%), pressurization failure endangering passenger safety, transition zone failures isolating tunnel sections (€100-500 million per incident), signaling or gauge incompatibility preventing seamless rail operation, or surface rail interface modifications exceeding €200-800 million per terminal.

### 9. Supply Chain Resilience and Subsea Logistics Monitoring
**Monitoring Tools/Platforms:**

  - Blockchain-Based Supply Chain Tracking Platform
  - Regional Fabrication Yard Status Reports (Spain and Morocco)
  - Offshore Staging Area Inventory Dashboard
  - Alternative Supplier Status Reports
  - Maritime Transport Corridor Utilization Data

**Frequency:** Weekly (PMO logistics coordination), Real-time (blockchain tracking)

**Responsible Role:** Project Management Office (PMO), specifically Head of Subsea Logistics and Supply Chain

**Adaptation Process:** PMO activates pre-qualified alternative suppliers and redistributes material flows between the two regional fabrication yards when disruptions occur. Strategic inventory (3-6 months) is deployed from offshore staging areas. Logistics routes are modified in response to disruptions. Single-point-of-failure risks at centralized mega-hubs are escalated to the Risk Management Committee. Blockchain tracking provides real-time visibility across all procurement categories.

**Adaptation Trigger:** Supply chain disruption lasting 2-4 months (€1-3 billion in idle costs), single mega-hub failure (port strike, facility fire, or geopolitical disruption), material shortages forcing design compromises that reduce structural integrity, inventory levels falling below 3-month strategic threshold, or transport delays cascading through the construction schedule (€10-30 million per week).

### 10. Offshore Workforce Resilience, Safety, and Retention Monitoring
**Monitoring Tools/Platforms:**

  - Workforce Turnover and Retention Dashboard
  - Safety Incident Tracking System
  - Training Pipeline Progress Reports
  - Knowledge Management System Logs
  - Offshore Accommodation and Amenities Utilization Data

**Frequency:** Monthly (PMO workforce review), Quarterly (comprehensive workforce assessment)

**Responsible Role:** Project Management Office (PMO), specifically Head of Offshore Workforce Management

**Adaptation Process:** PMO implements tiered retention strategy adjustments including competitive compensation, family accommodation options, career progression pathways, and equity-sharing. Additional recruitment and training resources are deployed when turnover exceeds targets. Knowledge management systems capture expertise independent of individual workers. Turnover exceeding 20% annually or safety incident increases are escalated to the Steering Committee and Risk Management Committee. Maritime training institution partnerships ensure a continuous pipeline of 500+ qualified personnel annually.

**Adaptation Trigger:** Workforce turnover exceeding 20% annually (€500 million-€1.5 billion in repeated training costs), safety incident frequency increasing by 25-50%, loss of institutional knowledge during critical installation phases, training pipeline failing to produce 500+ qualified personnel annually, or workforce-related cost overruns exceeding €500 million-€1.5 billion.

### 11. Currency Exchange Rate (EUR/MAD) and Financial Risk Monitoring
**Monitoring Tools/Platforms:**

  - Currency Hedging Program Dashboard (covering 70%+ of MAD expenditures)
  - EUR/MAD Exchange Rate Tracking System
  - Tranche-Based Financing Continuity Monitor
  - Investor Confidence Index Reports
  - Reserve Fund Status Dashboard (12-month operational reserve)

**Frequency:** Monthly (dedicated treasury function monitoring), Quarterly (Risk Management Committee review)

**Responsible Role:** Risk Management Committee, with dedicated treasury function and Head of International Consortium Financing

**Adaptation Process:** Treasury adjusts hedging instruments (forward contracts, currency swaps) based on exposure analysis, targeting 70%+ coverage of MAD-denominated expenditures. Risk Management Committee mandates additional hedging or reserve fund allocations when exposure exceeds thresholds. Steering Committee approves additional sovereign capital commitments if funding continuity is threatened. Funding cliff prevention strategies are activated when tranche disbursements are at risk due to milestone disputes or political shifts.

**Adaptation Trigger:** EUR/MAD fluctuation exceeding 10-20% (€200-800 million impact), hedging coverage falling below 70% of projected MAD expenditures, funding gap of 6-12 months threatening construction continuity, investor confidence erosion triggering capital withdrawal, cost of capital increase of 200-400 basis points adding €1-3 billion in interest payments, or loss of government bond guarantees.

### 12. Maritime Traffic Integration and Collision Risk Management Monitoring
**Monitoring Tools/Platforms:**

  - Computational Fluid Dynamics (CFD) Modeling Results
  - AIS Monitoring and Collision Avoidance System Data
  - Temporary Traffic Management Plan (TTMP) Compliance Reports
  - Strait of Gibraltar Joint Coordination Center Data
  - Maritime Traffic Impact Study Updates

**Frequency:** Quarterly (comprehensive review), Continuous (AIS and collision avoidance monitoring)

**Responsible Role:** Project Management Office (PMO) with Strait of Gibraltar Joint Coordination Center and IMO coordination

**Adaptation Process:** PMO adjusts transport schedules and vessel routing based on real-time traffic data. Permanent shipping lane adjustments are negotiated with international authorities (IMO, Joint Coordination Center). Additional collision avoidance systems are deployed when probability increases. CFD modeling is updated to reflect tunnel-induced current changes. Current deflection effects on wave heights are monitored and mitigated through tunnel profile adjustments.

**Adaptation Trigger:** Collision probability increasing by 10-30% due to tunnel current deflection, maritime traffic disruption adding weeks to transport schedules (€10-30 million per week), shipping lane agreements not secured, CFD modeling showing wave height increases of 5-15%, a collision or near-miss incident involving tunnel segments during transport (€50-200 million total loss), or failure to secure permanent traffic management agreements.

### 13. Corrosion Protection, Durability, and Long-Term Sustainability Monitoring
**Monitoring Tools/Platforms:**

  - Multi-Layer Corrosion Protection Performance Dashboard
  - Polymer Encapsulation Integrity Monitoring System
  - Sacrificial Anode Consumption Tracking
  - Active Cathodic Protection System Data (tidal-powered)
  - Climate Change Adaptation Progress Reports (IPCC SSP2-4.5 and SSP5-8.5)
  - Maintenance Trust Fund Status Dashboard (€3-8 billion)
  - 20-Year Lifecycle Cost Analysis Updates

**Frequency:** Quarterly (TAG technical review), Annually (comprehensive lifecycle assessment)

**Responsible Role:** Technical Advisory Group (TAG) with Risk Management Committee oversight; dedicated corrosion monitoring program with predictive analytics

**Adaptation Process:** TAG mandates corrosion protection system modifications or additional layers when degradation accelerates. Maintenance trust fund contributions are adjusted based on lifecycle cost analysis updates. Climate adaptation measures are updated based on IPCC projection revisions (sea level rise 0.3-0.6m, storm intensity +10-20%). Modular system upgrades are planned to prevent technological obsolescence. Accessible inspection and maintenance ports are deployed at regular intervals for ongoing monitoring.

**Adaptation Trigger:** Corrosion degradation accelerating 3-5x beyond design expectations, polymer encapsulation breached during installation or degraded by UV exposure, maintenance costs exceeding €3-8 billion estimate, climate change impacts requiring design modifications (sea level rise >0.5m, storm intensity +20%), technological obsolescence requiring major system upgrades exceeding €1-4 billion, or cathodic protection failure accelerating degradation.

### 14. Seismic and Geotechnical Risk Monitoring Near Azores-Gibraltar Fault Zone
**Monitoring Tools/Platforms:**

  - Deep-Sea Borehole Sampling Data (minimum 5 samples)
  - 3D Seismic Reflection Profiling Results
  - Probabilistic Seismic Hazard Analysis (PSHA) Models
  - Geotechnical Validation Gate Reports
  - Seismic Monitoring Station Data
  - Foundation Settlement and Deformation Sensors

**Frequency:** Quarterly (TAG geotechnical review), Continuous (seismic monitoring stations)

**Responsible Role:** Technical Advisory Group (TAG) with independent seismic review panel; PMO operational monitoring

**Adaptation Process:** TAG mandates foundation design modifications based on updated seismic data. Geotechnical validation gate triggers construction halts if subsurface conditions differ from assumed clay/sand/weathered bedrock profiles. Seismic mitigation budgets (€500 million-€1.5 billion) are adjusted based on monitoring results. Additional borehole sampling is commissioned when unexpected geotechnical conditions are encountered. All designs incorporate site-specific seismic loading cases with minimum 2% probability of exceedance in 50 years.

**Adaptation Trigger:** Seismic event exceeding M5.5-6.5 (10% probability in 20 years) causing €3-8 billion in repairs and 12-24 months of reconstruction, major earthquake (M7.0+, 2% probability) threatening catastrophic failure with total loss of segments valued at €10-20 billion, geotechnical conditions differing significantly from initial assumptions, foundation settlement or deformation exceeding tolerance limits, or PSHA showing higher risk than initially modeled.

### 15. Decommissioning and End-of-Life Planning Progress Monitoring
**Monitoring Tools/Platforms:**

  - Decommissioning Plan Progress Tracker
  - Decommissioning Reserve Fund Status Dashboard (€2-4 billion)
  - Environmental Remediation Protocol Documents
  - Seabed Restoration Requirements Documentation
  - Full Lifecycle Assessment (LCA) Reports

**Frequency:** Annual (Steering Committee review), with milestone-based updates during design and construction phases

**Responsible Role:** Project Steering Committee, with PMO and Technical Advisory Group support

**Adaptation Process:** Steering Committee approves decommissioning plan amendments and reserve fund contribution adjustments based on lifecycle cost analysis. Environmental remediation protocols are updated based on evolving regulatory requirements over the 20-year horizon. Seabed restoration strategies are modified based on structural monitoring data. Decommissioning obligations are negotiated in the bilateral treaty and IMO framework. Full LCA of construction and decommissioning environmental footprint is updated periodically.

**Adaptation Trigger:** Decommissioning costs estimated to exceed €5-15 billion depending on method, regulatory requirements changing over the 20-year horizon imposing unanticipated standards, tunnel becoming an unintended artificial reef with unknown ecological consequences triggering environmental liability claims of €1-5 billion, failure to plan resulting in the tunnel becoming a massive unfunded liability, or maintenance costs over 20 years reaching €3-8 billion exceeding initial projections.

# Governance Extra

## Governance Validation Checks

1. Completeness Confirmation: All core requested governance components have been generated across the five stages — (1) Audit Details (corruption/misallocation lists, audit procedures, transparency measures), (2) Internal Governance Bodies (6 bodies: Steering Committee, PMO, TAG, Ethics & Compliance Committee, Environmental Oversight Board, Risk Management Committee), (3) Governance Implementation Plan (24 steps spanning Weeks 1–24), (4) Decision Escalation Matrix (6 issue types with defined escalation paths), and (5) Monitoring Progress (14 distinct monitoring approaches). The framework is structurally complete and covers strategic, operational, technical, ethical, environmental, and risk management dimensions.
2. Internal Consistency Check: The governance framework demonstrates strong logical alignment across stages. The Implementation Plan correctly references all six governance bodies in their establishment sequence, with the Steering Committee appearing as the approving authority for TAG, Ethics & Compliance, Environmental Oversight Board, and Risk Management Committee ToRs. The Decision Escalation Matrix aligns with the hierarchy defined in the bodies — PMO escalates to Steering Committee for >€50M decisions, Steering Committee deadlocks escalate to Bilateral Diplomatic Task Force then ICC arbitration, and Environmental Oversight Board's binding halt authority is preserved in the escalation path. Monitoring Progress correctly assigns responsible roles to the same bodies defined in Stage 2 (PMO for operational monitoring, TAG for technical validation, Steering Committee for strategic oversight). Audit procedures from Stage 1 align with the Ethics & Compliance Committee's responsibilities and the PMO's budget tracking role. No structural discrepancies were identified.
3. Gap 1 — Project Sponsor Role Ambiguity: The Project Sponsor (Joint Spanish-Moroccan Government) is referenced as the initiating authority in the Implementation Plan (Weeks 1–24), commissioning governance advisors, appointing committee chairs, and ratifying frameworks. However, the Sponsor's ongoing role after governance establishment is undefined. Does the Sponsor dissolve into the Steering Committee, retain a separate oversight function, or serve as a permanent sovereign guarantor? The Sponsor's relationship to the Steering Committee — which includes ministers from both governments — is unclear, creating potential confusion about whether sovereign authority resides in the Sponsor, the Steering Committee, or both. This ambiguity could cause jurisdictional overlap in crisis situations.
4. Gap 2 — Insufficient Process Depth for Conflict of Interest Management: While the Ethics & Compliance Committee is tasked with investigating conflicts of interest within the neutral third-party engineering consortium, the specific process for identifying, disclosing, and managing conflicts is not detailed. The TAG's terms mention 'conflict-of-interest protocols' but these are undefined. For a €40 billion project where the neutral consortium holds technical decision-making authority, a robust, ongoing conflict-of-interest disclosure regime is essential — including mandatory annual disclosures by all consortium personnel, independent verification of financial ties to contractors/suppliers, and a defined recusal process when conflicts are identified. The current framework mentions the problem but lacks the procedural machinery to address it.
5. Gap 3 — No Defined Change Control Process: The governance framework lacks an explicit change control process for managing modifications to the hybrid floating-pillar architecture design, construction methodology, or project scope after the prototype validation phase. While the Decision Escalation Matrix addresses technical deadlocks and the TAG has authority to mandate design modifications, there is no defined workflow for how proposed changes are submitted, evaluated, approved, and implemented. A formal change control process — including change request forms, impact assessment protocols, approval thresholds, and implementation tracking — is missing. This is critical given the unprecedented nature of the architecture where design evolution is likely.
6. Gap 4 — Delegation Granularity Below PMO Level: The PMO has a clear €50 million financial delegation threshold, but there is no further delegation framework for Phase Leads, functional heads, or coordinators below the PMO Director. How much can a Phase 1 Lead (Pillars and Buoyancy) decide independently versus requiring PMO Director approval? Are there sub-delegation thresholds for procurement of specific material categories (e.g., buoyant concrete contracts)? Without granular delegation, operational decision-making may bottleneck at the PMO Director level, creating delays in a project requiring rapid responses to weather windows, supply chain disruptions, and technical challenges.
7. Gap 5 — Information Flow Protocols Between Governance Bodies: The Monitoring Progress plan defines 14 distinct monitoring approaches, each assigned to specific bodies, but there are no explicit protocols governing how information flows between these bodies. For example, how does real-time acoustic buoy data from the Environmental Oversight Board reach the Risk Management Committee for cascading risk assessment? How does TAG's technical validation data feed into the Steering Committee's strategic decisions versus the PMO's operational adjustments? The framework defines what each body monitors but not how cross-body information sharing is structured, creating potential for siloed decision-making in a project where interconnected risks demand integrated responses.
8. Gap 6 — Whistleblower Investigation Process Undefined: The Ethics & Compliance Committee establishes whistleblower mechanisms with anonymous reporting channels and anti-retaliation protections, but the investigation process itself is not detailed. How are whistleblower reports triaged upon receipt? What is the investigation timeline? Who conducts investigations — the Committee Chair, the Whistleblower Ombudsman, or external investigators? What evidence standards apply? How are findings enforced across sovereign jurisdictions when the implicated parties include consortium members or government officials? The framework identifies the need for whistleblower mechanisms but lacks the procedural specificity to ensure they are effective and credible.
9. Gap 7 — Stakeholder Communication Protocol Absence: While the assumptions document describes a multi-tiered stakeholder engagement strategy (bilateral committees, investor briefings, community liaison offices, NGO advisory panels, public transparency portal), there is no formal communication protocol defining what information is disclosed to which stakeholder groups, through what channels, at what frequency, and by whom. The distinction between mandatory disclosures (e.g., quarterly investor briefings), advisory communications (e.g., NGO panel updates), and public transparency (e.g., real-time environmental data) is not codified. This gap is significant for a project where information management directly affects investor confidence, public support, and regulatory compliance.

## Tough Questions

1. What is the current probability-weighted forecast for the project's completion date, incorporating Monte Carlo simulation results that account for the 2-5 year governance delay risk, the medium-probability technical failure risk of the hybrid floating-pillar architecture, and the high-likelihood financial cost escalation of 10-15%? What specific confidence interval does this forecast provide, and what is the worst-case scenario date?
2. Show evidence that the hybrid floating-pillar architecture has been validated through 1:50 scale physical model testing and finite element analysis. What specific force dynamics — vertical buoyancy loads, lateral current forces, and dynamic storm loading — have been confirmed through these tests, and which force interactions remain unvalidated? What is the specific acceptance criteria for prototype segment deployment at 100m equivalent depth before mass production is approved?
3. What are the exact numerical thresholds for cetacean disturbance, sediment plume concentration, and water quality parameters that trigger the Environmental Oversight Board's binding authority to halt construction? How are these thresholds calibrated against baseline studies, and what is the protocol for real-time data verification before a halt is declared?
4. How is the €4-6 billion contingency reserve allocated across the three functional-subsystem phases (pillars/buoyancy, rail infrastructure, sealing/pressurization), and what is the specific decision-making process when automated escalation triggers at 5%, 10%, and 15% budget utilization are hit? Who has authority to approve contingency drawdowns between €250 million and the full reserve, and what justification is required?
5. What is the detailed investigation and resolution timeline for whistleblower reports received by the Ethics & Compliance Committee? How are reports triaged upon receipt, what evidence standards apply during investigation, who conducts the investigation (internal vs. external), and what enforcement mechanisms exist when findings of ethical violations involve parties in sovereign jurisdictions or the neutral consortium?
6. How is information from the 14 distinct monitoring approaches integrated and disseminated across the six governance bodies? What specific protocols govern the flow of technical data from TAG to the Steering Committee versus the PMO? How does real-time environmental monitoring data from the Environmental Oversight Board reach the Risk Management Committee for cascading risk assessment, and what is the latency requirement for critical alerts?
7. What is the specific change control process for modifying the hybrid floating-pillar architecture design after prototype validation? How are proposed design changes submitted, what impact assessment protocols apply, what approval thresholds exist for different categories of change (minor vs. major vs. fundamental), and how are approved changes tracked through implementation?
8. What is the detailed currency hedging strategy specifying which financial instruments (forward contracts, currency swaps, options) cover which percentage of MAD-denominated expenditures, and who has authority to adjust hedging positions? What is the specific trigger for increasing hedging coverage above 70%, and what is the maximum allowable unhedged exposure at any point?
9. What is the specific process for how the Project Sponsor's role transitions after the governance framework is fully established at Week 24? Does the Sponsor retain any ongoing authority (e.g., sovereign guarantee, treaty enforcement), or is it fully absorbed into the Steering Committee? What happens if a governance dispute arises between the Sponsor and the Steering Committee?
10. What are the specific numerical thresholds for the automated budget escalation triggers at 5%, 10%, and 15% utilization of the €40 billion envelope, and how does the PMO's €50 million delegation interact with these triggers? Can the PMO continue to approve contracts up to €50 million when the overall budget has reached the 10% trigger, or are all expenditures subject to additional scrutiny at trigger points?

## Summary

The governance framework for this €40 billion, 20-year transoceanic submerged tunnel project establishes a comprehensive six-body structure — spanning strategic oversight (Steering Committee), operational management (PMO), independent technical validation (TAG), ethical integrity (Ethics & Compliance Committee), environmental protection (Environmental Oversight Board), and enterprise risk management (Risk Management Committee) — implemented through a 24-week establishment plan and supported by a six-path decision escalation matrix and 14 monitoring approaches. The framework's key strength lies in its balanced distribution of authority across sovereign, technical, ethical, and environmental dimensions, with the neutral third-party consortium model elegantly resolving cross-border governance complexity. However, critical gaps remain in the definition of the Project Sponsor's ongoing role, the procedural depth of conflict-of-interest management and whistleblower investigations, the absence of a formal change control process, insufficient delegation granularity below the PMO level, undefined information flow protocols between governance bodies, and the lack of codified stakeholder communication standards. These gaps, while not structurally fatal, represent areas where additional detail and process definition would significantly strengthen the framework's operational credibility and risk mitigation capacity for a project of unprecedented scale and complexity.