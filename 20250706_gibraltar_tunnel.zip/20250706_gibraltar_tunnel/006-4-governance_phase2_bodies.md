### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and direction for this large-scale, high-risk, and politically sensitive infrastructure project.  Ensures alignment with strategic goals and effective risk management.

**Responsibilities:**

- Approve project scope, budget, and schedule baselines.
- Provide strategic direction and guidance to the Project Management Office.
- Review and approve major project changes and deviations from the baseline plan (above €5 million).
- Oversee risk management and mitigation strategies for strategic risks.
- Resolve strategic conflicts and escalate issues as needed.
- Monitor project performance against strategic objectives.
- Approve key strategic decisions, including those related to the Funding Model, Geopolitical Risk Management, and International Collaboration Framework.

**Initial Setup Actions:**

- Finalize Terms of Reference and membership.
- Establish decision-making protocols and escalation paths.
- Define financial thresholds for strategic decisions.
- Review and approve the initial project plan and risk register.

**Membership:**

- Senior representatives from the Spanish Ministry of Transport, Mobility and Urban Agenda
- Senior representatives from the Moroccan Ministry of Equipment, Transport, Logistics and Water
- Representative from the Sovereign Wealth Fund Consortium (independent)
- Independent Expert in Submerged Tunnel Construction
- Project Director
- Chief Financial Officer

**Decision Rights:** Strategic decisions related to project scope, budget, schedule, and risk management. Approval of changes exceeding €5 million. Approval of key strategic decisions as defined in the strategic decisions document.

**Decision Mechanism:** Decisions are made by majority vote. In the event of a tie, the representative from the Sovereign Wealth Fund Consortium will cast the deciding vote.

**Meeting Cadence:** Quarterly, with ad-hoc meetings as needed for critical decisions.

**Typical Agenda Items:**

- Review of project progress against plan.
- Review of project financials and budget performance.
- Review of risk register and mitigation strategies.
- Discussion and approval of proposed changes to project scope, budget, or schedule.
- Escalated issues from the Project Management Office or other governance bodies.
- Review of compliance reports.

**Escalation Path:** Escalate to the Ministers of Transport of Spain and Morocco for unresolved issues or decisions exceeding the Committee's authority.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages the day-to-day execution of the project, ensuring adherence to the project plan, budget, and schedule. Provides operational risk management and support to the project team.

**Responsibilities:**

- Develop and maintain the project plan, budget, and schedule.
- Manage project resources and track project progress.
- Identify, assess, and manage operational risks.
- Implement project management processes and procedures.
- Provide regular project status reports to the Project Steering Committee.
- Manage contracts and procurement activities.
- Ensure compliance with project requirements and standards.
- Manage day-to-day stakeholder communication.

**Initial Setup Actions:**

- Establish project management processes and tools.
- Develop the project plan, budget, and schedule.
- Establish a risk management framework.
- Recruit and train project team members.

**Membership:**

- Project Director
- Project Manager
- Chief Engineer
- Chief Financial Officer
- Risk Manager
- Stakeholder Engagement Manager
- Compliance Officer

**Decision Rights:** Operational decisions related to project execution, resource allocation, and risk management within the approved budget and schedule. Approval of changes up to €5 million.

**Decision Mechanism:** Decisions are made by the Project Director, with input from the PMO team. Conflicts are resolved through discussion and consensus. If consensus cannot be reached, the Project Director makes the final decision.

**Meeting Cadence:** Weekly.

**Typical Agenda Items:**

- Review of project progress against plan.
- Review of project financials and budget performance.
- Review of risk register and mitigation strategies.
- Discussion and resolution of project issues.
- Approval of change requests (below €5 million).
- Planning for upcoming activities.

**Escalation Path:** Escalate to the Project Steering Committee for issues exceeding the PMO's authority or requiring strategic guidance.
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and assurance on critical engineering aspects of the project, ensuring the tunnel's structural integrity, safety, and long-term performance.

**Responsibilities:**

- Review and approve technical designs and specifications.
- Provide expert advice on technical challenges and risks.
- Assess the feasibility and reliability of proposed technologies.
- Monitor the quality of construction and materials.
- Conduct independent technical audits and assessments.
- Advise on technical risk mitigation strategies.
- Ensure compliance with relevant technical standards and regulations.

**Initial Setup Actions:**

- Finalize Terms of Reference and membership.
- Establish communication protocols with the PMO.
- Review key technical documents and designs.
- Identify critical technical risks and challenges.

**Membership:**

- Independent Expert in Submerged Tunnel Construction (Chair)
- Geotechnical Engineer
- Structural Engineer
- Marine Engineer
- Materials Scientist
- Seismic Expert
- Representative from the Chief Engineer's Office

**Decision Rights:** Technical approval of designs, specifications, and construction methods.  Authority to recommend changes to technical aspects of the project to ensure safety and performance.

**Decision Mechanism:** Decisions are made by consensus. If consensus cannot be reached, the Chair makes the final decision, based on expert opinion and technical evidence.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical technical reviews.

**Typical Agenda Items:**

- Review of technical designs and specifications.
- Discussion of technical challenges and risks.
- Assessment of proposed technologies and materials.
- Review of construction quality and compliance.
- Review of technical audit reports.
- Discussion of technical risk mitigation strategies.

**Escalation Path:** Escalate to the Project Steering Committee for unresolved technical issues or decisions with significant strategic implications.
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures the project adheres to the highest ethical standards and complies with all relevant regulations, including GDPR, environmental regulations, and anti-corruption laws.  Provides independent oversight and assurance on ethical and compliance matters.

**Responsibilities:**

- Develop and implement an ethics and compliance program.
- Monitor compliance with relevant laws, regulations, and ethical standards.
- Investigate allegations of fraud, corruption, and other ethical violations.
- Provide training and guidance on ethics and compliance matters.
- Conduct regular compliance audits and assessments.
- Report compliance issues to the Project Steering Committee.
- Ensure compliance with GDPR and data privacy regulations.
- Oversee environmental compliance and sustainability initiatives.

**Initial Setup Actions:**

- Finalize Terms of Reference and membership.
- Develop an ethics and compliance program.
- Establish reporting mechanisms for ethical violations.
- Conduct a risk assessment to identify potential compliance issues.

**Membership:**

- Independent Ethics Officer (Chair)
- Legal Counsel
- Compliance Officer
- Representative from the Internal Audit Department
- Representative from the Stakeholder Engagement Team
- Data Protection Officer

**Decision Rights:** Authority to investigate ethical violations and recommend corrective actions.  Authority to halt project activities that violate ethical standards or compliance requirements.  Approval of ethics and compliance policies and procedures.

**Decision Mechanism:** Decisions are made by majority vote. In the event of a tie, the Ethics Officer casts the deciding vote.

**Meeting Cadence:** Monthly.

**Typical Agenda Items:**

- Review of compliance reports.
- Discussion of ethical issues and concerns.
- Investigation of alleged ethical violations.
- Review of ethics and compliance policies and procedures.
- Training on ethics and compliance matters.
- Review of GDPR compliance activities.
- Review of environmental compliance activities.

**Escalation Path:** Escalate to the Project Steering Committee for unresolved ethical or compliance issues or decisions with significant strategic implications.  Serious violations are reported to the relevant regulatory authorities.
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Manages communication and engagement with all stakeholders, including local communities, environmental groups, and regulatory bodies. Ensures that stakeholder concerns are addressed and that the project is implemented in a socially responsible manner.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct regular consultations with stakeholders.
- Address stakeholder concerns and grievances.
- Provide regular project updates to stakeholders.
- Manage media relations and public communications.
- Monitor stakeholder perceptions and attitudes.
- Ensure that stakeholder feedback is incorporated into project decisions.
- Manage community relations and social responsibility initiatives.

**Initial Setup Actions:**

- Finalize Terms of Reference and membership.
- Develop a stakeholder engagement plan.
- Identify key stakeholders and their concerns.
- Establish communication channels with stakeholders.

**Membership:**

- Stakeholder Engagement Manager (Chair)
- Community Relations Officer
- Environmental Liaison Officer
- Public Relations Officer
- Representative from the Spanish Government
- Representative from the Moroccan Government
- Representative from Local Communities (Spain)
- Representative from Local Communities (Morocco)

**Decision Rights:** Authority to make decisions related to stakeholder engagement activities.  Authority to recommend changes to project plans to address stakeholder concerns.  Approval of communication materials and public statements.

**Decision Mechanism:** Decisions are made by consensus. If consensus cannot be reached, the Stakeholder Engagement Manager makes the final decision, based on stakeholder feedback and project objectives.

**Meeting Cadence:** Bi-weekly.

**Typical Agenda Items:**

- Review of stakeholder engagement activities.
- Discussion of stakeholder concerns and grievances.
- Review of communication materials and public statements.
- Planning for upcoming stakeholder consultations.
- Monitoring of stakeholder perceptions and attitudes.
- Review of community relations and social responsibility initiatives.

**Escalation Path:** Escalate to the Project Steering Committee for unresolved stakeholder issues or decisions with significant strategic implications.