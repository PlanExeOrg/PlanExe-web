A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The self-healing concrete will perform as expected in the harsh marine environment. | Fabricate a prototype tunnel segment using the self-healing concrete and subject it to accelerated aging tests simulating marine conditions (seawater exposure, pressure, cyclic loading). | The prototype segment exhibits significant cracking, corrosion, or degradation exceeding pre-defined acceptable thresholds within the testing period. |
| A2 | The joint governance structure will effectively mitigate potential political disputes and ensure shared ownership of the project. | Conduct a series of facilitated workshops with representatives from both Spain and Morocco to simulate potential conflict scenarios and assess the effectiveness of the dispute resolution mechanisms within the joint governance structure. | The workshops reveal significant disagreements or impasses that cannot be resolved through the established mechanisms, indicating a lack of effective dispute resolution. |
| A3 | Sufficient funding will be secured from sovereign wealth funds from Spain, Morocco, and Gulf states. | Obtain legally binding commitments from at least three sovereign wealth funds, specifying investment amounts, disbursement schedules, and acceptable risk levels. | Failure to secure legally binding commitments for at least 50% of the required funding (€20 billion) by a specified date (e.g., six months from now). |
| A4 | The existing high-speed rail infrastructure in Spain and Morocco can seamlessly integrate with the tunnel's rail system without significant upgrades or modifications. | Conduct a detailed compatibility assessment of the existing rail infrastructure, including track gauge, signaling systems, and power supply, with the tunnel's proposed rail system specifications. | The assessment reveals significant incompatibilities requiring upgrades exceeding 15% of the tunnel's rail system budget or causing a delay of more than 6 months to the integration timeline. |
| A5 | The marine ecosystem in the Strait of Gibraltar will not be significantly and irreversibly damaged by the tunnel construction and operation. | Conduct a comprehensive environmental impact assessment (EIA) including baseline studies of marine life, water quality, and seabed habitats, and model the potential impacts of construction activities (noise, sediment plumes, habitat disturbance) and long-term operation (altered currents, pollution). | The EIA predicts irreversible damage to critical marine habitats or significant decline in keystone species populations exceeding pre-defined acceptable thresholds, or fails to meet international environmental standards. |
| A6 | The local communities in Tarifa (Spain) and Tangier (Morocco) will generally support the project and not engage in significant protests or legal challenges that could delay construction. | Conduct thorough stakeholder engagement activities including public forums, surveys, and consultations to gauge community sentiment, address concerns, and incorporate feedback into the project plan. | Surveys reveal that more than 30% of the local population opposes the project, or significant legal challenges are filed by community groups that could halt construction. |
| A7 | The cost of key construction materials (steel, concrete, specialized equipment) will remain within the projected budget throughout the 20-year project lifecycle. | Obtain long-term price guarantees from key suppliers for critical materials and equipment, factoring in potential inflation and market fluctuations. | Suppliers refuse to provide price guarantees, or the guaranteed prices exceed the project's budgeted amounts by more than 10%. |
| A8 | The tunnel design will effectively mitigate the risk of terrorist attacks or sabotage, ensuring the safety and security of passengers and infrastructure. | Conduct a comprehensive threat assessment and vulnerability analysis, engaging security experts and intelligence agencies to identify potential attack scenarios and weaknesses in the tunnel design. | The threat assessment reveals significant vulnerabilities in the tunnel design that cannot be mitigated without major redesigns or exceeding the security budget by more than 15%. |
| A9 | The project will generate sufficient revenue from tolls and other sources to cover operational costs, debt servicing, and future maintenance expenses, ensuring long-term financial sustainability. | Conduct a detailed market analysis and develop a comprehensive financial model, projecting future traffic volumes, toll rates, and operating expenses, factoring in potential economic downturns and competition from alternative transportation modes. | The financial model projects that the project will not be able to cover its operational costs and debt servicing obligations within the first 10 years of operation, or that the projected return on investment (ROI) falls below a pre-defined acceptable threshold (e.g., 5%). |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Empty Coffers Catastrophe | Process/Financial | A3 | Project Financier | CRITICAL (20/25) |
| FM2 | The Concrete Jungle Debacle | Technical/Logistical | A1 | Head of Engineering | CRITICAL (15/25) |
| FM3 | The Strait Divide Meltdown | Market/Human | A2 | International Relations Coordinator | CRITICAL (15/25) |
| FM4 | The Rail Integration Riddle | Technical/Logistical | A4 | High-Speed Rail Integration Planner | CRITICAL (20/25) |
| FM5 | The Environmental Backlash | Market/Human | A5 | Marine Ecosystem Specialist | CRITICAL (15/25) |
| FM6 | The Community Revolt | Process/Financial | A6 | Community Liaison Officer | HIGH (12/25) |
| FM7 | The Inflation Inferno | Process/Financial | A7 | Project Financier | CRITICAL (20/25) |
| FM8 | The Security Breach Nightmare | Market/Human | A8 | Tunnel Security Expert | HIGH (10/25) |
| FM9 | The Revenue Rut | Technical/Logistical | A9 | Project Financier | CRITICAL (15/25) |


### Failure Modes

#### FM1 - The Empty Coffers Catastrophe

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A3
- **Owner**: Project Financier
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project relies heavily on securing substantial funding from sovereign wealth funds (SWFs). If these funds fail to materialize, the project will face a severe financial crisis. 

*   Initial commitments from SWFs are delayed due to shifting investment priorities or economic downturns in the Gulf region.
*   Construction milestones are missed due to lack of funds, triggering penalty clauses in contracts.
*   Private investors become hesitant, further reducing available capital.
*   The project is unable to meet its financial obligations, leading to default and potential abandonment.

##### Early Warning Signs
- Delays in disbursement of committed funds exceeding 30 days.
- Public announcements from SWFs indicating a change in investment strategy.
- Increased difficulty in securing bridge financing to cover short-term funding gaps.

##### Tripwires
- Committed SWF funding falls below 75% of the required amount.
- Interest rates on bridge loans exceed 8%.
- Construction milestones are delayed by more than 90 days due to funding shortages.

##### Response Playbook
- Contain: Immediately halt all non-essential expenditures and renegotiate payment terms with contractors.
- Assess: Conduct a thorough review of the project's financial model and identify potential cost-cutting measures.
- Respond: Actively pursue alternative funding sources, including private equity, infrastructure bonds, and government subsidies.


**STOP RULE:** Failure to secure at least 90% of the required funding within 180 days of hitting the first tripwire.

---

#### FM2 - The Concrete Jungle Debacle

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A1
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project hinges on the innovative use of self-healing concrete to ensure the tunnel's longevity and minimize maintenance. However, if the concrete fails to perform as expected, the consequences could be dire.

*   Accelerated aging tests reveal that the self-healing concrete is susceptible to cracking and corrosion in the marine environment.
*   The self-healing mechanism proves ineffective in repairing larger cracks, leading to water ingress and structural weakening.
*   The tunnel segments become unstable, requiring extensive and costly repairs.
*   The project faces significant delays and budget overruns, jeopardizing its completion.

##### Early Warning Signs
- Cracking observed in prototype tunnel segments during accelerated aging tests exceeds acceptable thresholds.
- Corrosion rates in self-healing concrete samples are higher than predicted.
- The self-healing mechanism fails to activate in response to simulated damage.

##### Tripwires
- Tensile strength of self-healing concrete decreases by more than 15% after 1 year of simulated marine exposure.
- Corrosion rates in self-healing concrete exceed 0.1 mm/year.
- Self-healing mechanism fails to repair cracks wider than 0.5 mm within 30 days.

##### Response Playbook
- Contain: Immediately halt further production of tunnel segments using the self-healing concrete.
- Assess: Conduct a comprehensive review of the tunnel design and identify alternative materials and construction methods.
- Respond: Implement a phased rollout of the tunnel, starting with segments constructed using conventional concrete, while continuing to research and develop improved self-healing concrete formulations.


**STOP RULE:** If more than 20% of the deployed tunnel segments exhibit significant structural defects within the first 5 years of operation, abandon the project.

---

#### FM3 - The Strait Divide Meltdown

- **Archetype**: Market/Human
- **Root Cause**: Assumption A2
- **Owner**: International Relations Coordinator
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's success depends on strong collaboration and shared ownership between Spain and Morocco. However, if political disputes or conflicting national interests undermine the joint governance structure, the project could unravel.

*   Disagreements arise over resource allocation, project management, or benefit sharing.
*   One country attempts to exert undue influence over the project, leading to resentment and mistrust.
*   The binational authority becomes paralyzed by internal conflicts, delaying critical decisions.
*   The project loses political support and public confidence, ultimately leading to its demise.

##### Early Warning Signs
- Public disagreements between Spanish and Moroccan officials regarding project priorities.
- Delays in approving key project milestones due to political gridlock.
- Increased media coverage highlighting tensions between the two countries.

##### Tripwires
- Key decisions within the binational authority are delayed by more than 60 days due to disagreements.
- Public approval ratings for the project in either Spain or Morocco fall below 40%.
- One country unilaterally withdraws from a major project agreement.

##### Response Playbook
- Contain: Immediately initiate high-level diplomatic talks to address the underlying political tensions.
- Assess: Conduct a thorough review of the joint governance structure and identify potential areas for improvement.
- Respond: Implement a revised governance framework that ensures equitable representation, transparent decision-making, and effective dispute resolution mechanisms.


**STOP RULE:** If the joint governance structure collapses and cannot be restored within 90 days, abandon the project.

---

#### FM4 - The Rail Integration Riddle

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A4
- **Owner**: High-Speed Rail Integration Planner
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The tunnel's economic viability hinges on seamless integration with existing high-speed rail networks. If the existing infrastructure proves incompatible, the project could face significant setbacks.

*   Compatibility assessment reveals major differences in track gauge, signaling systems, and power supply.
*   Upgrades to existing rail lines become necessary, exceeding budget and timeline.
*   Trains are forced to operate at reduced speeds within the tunnel, negating the benefits of high-speed rail.
*   Freight transport is severely limited, impacting revenue projections.

##### Early Warning Signs
- Compatibility assessment reveals more than 3 major incompatibilities.
- Cost estimates for rail infrastructure upgrades exceed initial projections by 20%.
- Negotiations with rail operators stall due to technical disagreements.

##### Tripwires
- Rail infrastructure upgrade costs exceed €2 billion.
- Integration timeline is delayed by more than 9 months.
- Throughput capacity is reduced by more than 25% due to integration issues.

##### Response Playbook
- Contain: Immediately freeze all further investment in the tunnel's internal rail systems.
- Assess: Conduct a comprehensive review of the integration plan and identify alternative solutions.
- Respond: Negotiate with rail operators to share the cost of upgrades or explore alternative transportation modes for freight.


**STOP RULE:** If rail integration costs exceed €3 billion or the integration timeline is delayed by more than 12 months, abandon the project.

---

#### FM5 - The Environmental Backlash

- **Archetype**: Market/Human
- **Root Cause**: Assumption A5
- **Owner**: Marine Ecosystem Specialist
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Public perception and regulatory approvals depend on minimizing environmental impact. If the project causes significant damage to the marine ecosystem, it could face severe consequences.

*   The EIA reveals irreversible damage to critical marine habitats and decline in keystone species.
*   Environmental groups launch legal challenges and public campaigns against the project.
*   Regulatory approvals are delayed or revoked due to environmental concerns.
*   The project loses public support and faces international condemnation.

##### Early Warning Signs
- EIA predicts significant decline in marine species populations.
- Environmental groups file lawsuits challenging the project's environmental permits.
- Public protests against the project increase in frequency and intensity.

##### Tripwires
- The Marine Disturbance Index exceeds 0.7 within the first year of construction.
- A keystone species population declines by more than 30% during construction.
- Major environmental permits are revoked by regulatory agencies.

##### Response Playbook
- Contain: Immediately halt all construction activities that are causing environmental damage.
- Assess: Conduct a thorough review of the environmental impact mitigation plan and identify areas for improvement.
- Respond: Implement enhanced mitigation measures, including habitat restoration, noise reduction technologies, and relocation of sensitive species.


**STOP RULE:** If irreversible damage to critical marine habitats is confirmed, or major environmental permits are permanently revoked, abandon the project.

---

#### FM6 - The Community Revolt

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A6
- **Owner**: Community Liaison Officer
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
Local community support is crucial for smooth project execution. If the project faces significant opposition, it could lead to delays, increased costs, and reputational damage.

*   Stakeholder engagement activities fail to address community concerns about noise, disruption, and environmental impact.
*   Local residents organize protests and file lawsuits against the project.
*   Construction is disrupted by blockades and demonstrations.
*   The project faces significant delays and increased security costs.

##### Early Warning Signs
- Surveys reveal that more than 25% of the local population opposes the project.
- Community groups file lawsuits challenging the project's permits.
- Construction sites are disrupted by protests and demonstrations.

##### Tripwires
- Construction is halted for more than 30 days due to community protests.
- Legal challenges result in significant delays or cost increases.
- Public approval ratings for the project in local communities fall below 50%.

##### Response Playbook
- Contain: Immediately suspend construction activities in areas where protests are occurring.
- Assess: Conduct a thorough review of the stakeholder engagement plan and identify areas for improvement.
- Respond: Implement enhanced community outreach programs, offer additional compensation for disruptions, and address specific community concerns.


**STOP RULE:** If construction is permanently blocked by community opposition or legal challenges, abandon the project.

---

#### FM7 - The Inflation Inferno

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Project Financier
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's financial viability is threatened by escalating material costs. If the cost of steel, concrete, and specialized equipment surges beyond projections, the budget could spiral out of control.

*   Global demand for construction materials increases, driving up prices.
*   Geopolitical events disrupt supply chains, leading to shortages and price spikes.
*   Inflation erodes the purchasing power of the project's budget.
*   The project is forced to scale back its scope or seek additional funding, jeopardizing its completion.

##### Early Warning Signs
- Steel and concrete prices increase by more than 10% within a 6-month period.
- Key equipment suppliers announce price increases due to rising raw material costs.
- Inflation rates exceed projected levels by more than 2% per year.

##### Tripwires
- Material costs exceed budgeted amounts by more than 15%.
- The project's contingency fund is depleted by more than 50% due to cost overruns.
- Debt servicing costs increase by more than 10% due to rising interest rates.

##### Response Playbook
- Contain: Immediately renegotiate contracts with suppliers to secure better pricing.
- Assess: Conduct a thorough review of the project's budget and identify potential cost-cutting measures.
- Respond: Explore alternative materials and construction methods to reduce reliance on expensive resources.


**STOP RULE:** If material costs exceed budgeted amounts by more than 25% and no viable cost-cutting measures can be identified, abandon the project.

---

#### FM8 - The Security Breach Nightmare

- **Archetype**: Market/Human
- **Root Cause**: Assumption A8
- **Owner**: Tunnel Security Expert
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The tunnel's safety and security are paramount. If the design proves vulnerable to terrorist attacks or sabotage, the consequences could be catastrophic.

*   A comprehensive threat assessment reveals weaknesses in the tunnel's security protocols.
*   Terrorist groups develop new tactics that exploit these vulnerabilities.
*   A successful attack disrupts transportation services, causes significant damage, and results in loss of life.
*   Public confidence in the tunnel's safety plummets, impacting ridership and revenue.

##### Early Warning Signs
- Intelligence agencies report increased terrorist activity in the region.
- Security experts identify potential vulnerabilities in the tunnel's design.
- Public concern about tunnel security increases following a terrorist attack elsewhere.

##### Tripwires
- A credible terrorist threat targeting the tunnel is identified by intelligence agencies.
- Security audits reveal significant breaches in the tunnel's security protocols.
- Public confidence in the tunnel's safety falls below 50%.

##### Response Playbook
- Contain: Immediately implement enhanced security measures, including increased surveillance, stricter access control, and deployment of additional security personnel.
- Assess: Conduct a thorough review of the tunnel's security protocols and identify areas for improvement.
- Respond: Implement design modifications to address identified vulnerabilities, enhance emergency response capabilities, and conduct regular security drills.


**STOP RULE:** If a successful terrorist attack compromises the tunnel's structural integrity or results in significant loss of life, abandon the project.

---

#### FM9 - The Revenue Rut

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A9
- **Owner**: Project Financier
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's long-term financial sustainability depends on generating sufficient revenue. If traffic volumes and toll rates fall short of projections, the project could face a financial crisis.

*   Economic downturns reduce demand for transportation services.
*   Competition from alternative transportation modes (ferries, airlines) erodes market share.
*   Toll rates are set too high, deterring potential users.
*   The project is unable to cover its operational costs and debt servicing obligations.

##### Early Warning Signs
- Traffic volumes are significantly lower than projected during the initial years of operation.
- Toll revenue falls short of projections by more than 10%.
- Operating expenses exceed budgeted amounts due to unforeseen maintenance costs.

##### Tripwires
- Traffic volumes fall below 75% of projected levels for two consecutive years.
- The project is unable to meet its debt servicing obligations.
- The project requires government subsidies to cover operational costs.

##### Response Playbook
- Contain: Immediately implement cost-cutting measures to reduce operating expenses.
- Assess: Conduct a thorough review of the project's financial model and identify potential revenue-generating opportunities.
- Respond: Adjust toll rates to attract more users, implement targeted marketing campaigns, and explore alternative revenue streams (e.g., advertising, concessions).


**STOP RULE:** If the project is unable to achieve financial self-sufficiency within 5 years of operation and requires ongoing government subsidies, abandon the project.
