Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 13 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 6 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is a large-scale civil engineering infrastructure project — specifically a transoceanic submerged tunnel using buoyant concrete tubes anchored at depth for high-speed rail. While ambitious and expensive, every described mechanism (buoyancy management, structural anchoring at 100m depth, rail transport through a submerged tube) operates within well-understood physical principles. No named law of physics is violated, and no non-physical causal mechanism is invoked. The plan is analogous to studied proposals like the Gibraltar Strait crossing, which are engineering challenges, not physics violations.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination — a hybrid floating-pillar buoyant concrete tunnel anchored at 100m depth across the Strait of Gibraltar connecting two continents — for which no credible precedent exists at comparable scale. The plan itself states: 'No existing precedent for a buoyant concrete tunnel system anchored at 100 meters below open ocean at this scale.' While five reference projects (Channel Tunnel, Seikan Tunnel, Marmaray, Gotthard Base Tunnel, Øresund Fixed Link) are cited, none validates the whole system: each uses different construction methods, depths, or geographies, and none combines buoyant concrete segments with pillar-supported anchoring at 100m depth in an ocean strait. The expert review identifies this as 'the largest technical uncertainty' with catastrophic failure risks (€500M–€2B per incident, total segment loss valued at €10–20B). The plan also lacks independent evidence for the foundational geotechnical assumptions (no borehole data, no seismic profiling), the energy supply infrastructure, and the flooding emergency protocols — all of which are prerequisites for the novel combination to function. Failure would be existential: total project cancellation with €40B in stranded capital.

**Mitigation**: Run parallel validation tracks across four critical subdomains: (1) Market/Demand — commission an independent ridership study benchmarking against Channel Tunnel and Øresund Fixed Link, with a hard NO-GO if projections fall below 600,000 passengers/year; (2) Legal/IP/Regulatory — retain a specialized international treaty law team (minimum 4 attorneys) to conduct comprehensive BIT analysis, UNCLOS classification, and EU law assessment, with a hard NO-GO if the bilateral treaty cannot be ratified with binding penalty clauses surviving government changes; (3) Technical/Operational/Safety — complete 1:50 scale physical model testing by June 2027, deploy a fully instrumented 50-meter prototype segment by March 2028, and require minimum 6 months of continuous stable operation data before mass production, with a hard NO-GO if buoyancy equilibrium variance exceeds ±5 meters or pillar load transfer fails; (4) Ethics/Societal — establish an independent environmental oversight board with binding authority to halt construction if marine mammal disturbance thresholds are exceeded, with a hard NO-GO if the IMO transboundary environmental assessment cannot achieve preliminary framework agreement. Reject domain-mismatched PoCs (e.g., Channel Tunnel geological data applied to Gibraltar seismic conditions). End with: Program Director & Cross-Border Governance Lead (Elena Vargas) / Geotechnical and Structural Validation Gate sign-off / June 2027.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because while the plan defines several named strategic frameworks (Builder's Foundation, Pioneer's Gambit, Consolidator's Anchor) with mechanism-of-action, owners, and measurable outcomes, multiple strategic concepts driving the plan remain undefined. The SWOT analysis explicitly identifies that the project 'lacks a clearly articulated and branded killer application' — no value hypothesis, owner, or success metrics exist for the core transcontinental rail value proposition. The energy infrastructure strategy (50-100 MW continuous demand) has no dedicated owner, no articulated supply mechanism, and no defined budget allocation process. Flooding emergency protocols, decommissioning strategy, cybersecurity strategy, and maritime traffic management are all identified as critical gaps yet remain undefined with no mechanism-of-action, owner, or measurable outcomes. Per the rubric, HIGH applies when any strategic concept driving the plan is undefined — and the killer application, energy infrastructure, flooding protocols, and decommissioning are all strategic concepts the plan depends on.

**Mitigation**: Program Director & Cross-Border Governance Lead (Elena Vargas): Assign dedicated owners to produce one-pagers for each undefined strategic concept — (1) Killer Application value hypothesis with ridership targets and revenue model, (2) Energy Infrastructure strategy with supply mechanism and €1-2B budget owner, (3) Flooding Emergency Protocol with safety certification pathway, (4) Decommissioning & End-of-Life plan with €2-4B reserve capitalization schedule, (5) Cybersecurity & Digital Infrastructure framework with air-gapped monitoring specifications. Each one-pager must include inputs→process→customer value mechanism, named owner, and measurable KPIs. Complete within 90 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan's risk register identifies major second-order hazards across legal, safety, financial, and reputational dimensions with named owners and mitigation actions for many risks. However, several critical hazard classes remain partially treated: flooding emergency protocols, energy infrastructure, cybersecurity, and decommissioning are acknowledged as critical gaps but lack dedicated owners, active controls, or implemented mitigation. Cascading effects such as governance delay → permitting delay → cost escalation → funding cliff are analyzed but not all have corresponding controls.

**Mitigation**: Structural Integrity & Lifecycle Maintenance Director: Develop comprehensive flooding risk management plan with redundant hull integrity monitoring at 500-point intervals, emergency containment compartments every 200m, rapid-deployment flood barriers, and specialized submersible rescue vehicles by December 2027, with annual simulation exercises and independent safety certification.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan's timeline is logically impossible: it treats fundamentally sequential dependencies (governance → permitting → construction) as parallel workstreams with arbitrary hard deadlines. The bilateral treaty ratification timeline (18 months) is unrealistic — infrastructure treaties typically require 3-5 years, exceeding the scheduled allocation by far more than 20%. The 'ASAP September 2026' mobilization date cannot be met because governance must precede permitting, permitting must precede construction, and construction methodology must precede prototype testing. Critical predecessors are unmapped and contradictory, and the permit/approval matrix lacks substantive legal foundation (no BIT analysis, no UNCLOS classification, no EU law assessment).

**Mitigation**: Program Director & Cross-Border Governance Lead (Elena Vargas): Commission a critical path analysis from a megaproject scheduling specialist (e.g., Arup or Mott MacDonald) within 30 days to establish true sequencing dependencies. Replace parallel workstream assumptions with sequential phase-gate methodology: Phase 0 (Governance and Legal Foundation, Sept 2026-Dec 2027), Phase 1 (Geotechnical and Environmental Validation, Jan 2027-Dec 2028), Phase 2 (Infrastructure and Workforce Preparation, Jan 2028-Dec 2029), Phase 3 (Prototype Validation and Permitting, Jan 2029-Dec 2030). Revise the project start date to a realistic mobilization date no earlier than 2030-2031. Each phase must have a formal gate review before the next phase can commence.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed funding sources do not cover the required runway and financing gates/covenants are undefined. The plan identifies multilateral government bonds, public-private partnerships, and development bank funds as strategic choices, but no source is signed, committed, or backed by a term sheet. The expert review states: 'Without confirmed financing commitments and agreed-upon milestone definitions, the project cannot fund construction.' No draw schedule, covenant definitions, or runway calculation (≥ X months) exist in the plan.

**Mitigation**: International Finance & Capital Director (Hans Mueller): Produce a dated financing plan within 60 days listing each funding source with its current status (LOI/term sheet/closed), a tranche draw schedule tied to geological and marine milestones, defined covenant thresholds, and a runway calculation covering at least 12 months of construction costs, with a NO-GO trigger on any missed financing gate.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan cites five comparable projects (Channel Tunnel at ~€396M/km undersea, Seikan at ~€236M/km, Marmaray at ~€2,857M/km, Gotthard at ~€210M/km, Øresund at ~€250M/km) and includes a 10–15% contingency reserve (€4–6B), but the €40B figure is not substantiated by vendor quotes or normalized per-area cost analysis. The Gibraltar tunnel at ~€2,857M/km far exceeds most undersea benchmarks, and the plan itself acknowledges that mitigation measures totaling €2.2–9.4B (seismic, energy, flooding, climate, gauge, decommissioning) may be excluded from the base envelope, potentially pushing true costs to €42–49B. No detailed cost breakdown by functional subsystem or market-validated quotes exist to confirm adequacy.

**Mitigation**: International Finance & Capital Director (Hans Mueller): Commission an independent bottom-up cost breakdown by functional subsystem from a megaproject finance consultancy (e.g., McKinsey Infrastructure or PwC Infrastructure) within 60 days; obtain vendor quotes for at least three major cost categories (buoyant concrete, marine-grade steel, HVDC submarine cables); normalize all comparable project costs per km and per m² of tunnel footprint; reconcile the €40B envelope against all identified mitigation measures; and establish a revised budget with explicit allocation of the €4–6B contingency weighted by risk exposure (35% geotechnical, 25% construction, 20% rail, 10% environmental, 10% operational).


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections as single-point estimates without ranges, confidence intervals, or alternative scenarios. The 1 million passenger target, €40 billion budget envelope, and 20-year completion timeline are all stated as definitive numbers. While the plan includes three strategic paths (Builder's Foundation, Pioneer's Gambit, Consolidator's Anchor) in scenarios.md, these are strategic alternatives rather than sensitivity analyses of critical projections. The expert review notes ridership could fall 50% below projections and costs could overrun 10-15%, yet the plan itself lacks formal worst-case/base-case scenario analysis for its most critical projections, indicating optimism bias.

**Mitigation**: Program Director & Cross-Border Governance Lead (Elena Vargas): Commission a sensitivity analysis for the most critical projection (ridership/revenue) within 90 days, developing best-case (1.5M passengers/year), base-case (1M passengers/year), and worst-case (500K passengers/year) scenarios with corresponding revenue models, budget implications, and timeline adjustments. Require all key projections (completion dates, budget, ridership) to include confidence intervals and contingency ranges in the revised plan.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the core build-critical components — hybrid floating-pillar architecture, sealed pressurized rail corridor, buoyancy engineering, multi-layer corrosion protection, subsea structural surveillance, energy supply infrastructure, and flooding prevention systems — are described only at a strategic/conceptual level across the plan documents. No detailed technical specifications, formal interface contracts, defined acceptance test criteria, comprehensive integration maps, or codified non-functional requirements exist for any of these components. The plan documents (strategic_decisions.md, scenarios.md, assumptions.md, project-plan.md, data-collection.md, expert-review.md) are rich in risk identification and high-level architecture but fundamentally lack the engineering artifacts required to actually build. The expert review explicitly states the project is 'designing blind' — the floating-pillar architecture is 'unvalidated,' the energy infrastructure plan is entirely absent, flooding protocols are missing, and the geotechnical foundation is unverified. Per the rubric, HIGH applies when core components lack these artifacts, which is the case here across every major subsystem.

**Mitigation**: Chief Engineer / Technical Director (proposed role): Produce a unified engineering artifact package for each core component within 90 days, including: (1) detailed technical specifications for the hybrid floating-pillar system (segment dimensions, material specs, buoyancy equilibrium parameters, pillar load-transfer equations); (2) formal interface contracts defining all subsystem interfaces (pillar-rail, buoyancy-structure, corrosion-surveillance, energy-structure); (3) acceptance test plans with pass/fail criteria for each component (prototype buoyancy validation, rail precision under pressure, corrosion accelerated life-cycle testing); (4) a comprehensive integration map showing how all subsystems interconnect with owners and milestones; and (5) codified non-functional requirements (safety factors, redundancy levels, maintenance intervals, environmental thresholds). Base all artifacts on validated geotechnical and physical model data, not assumed profiles.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan claims a bilateral treaty will be ratified within 18 months, yet no BIT analysis, treaty text, or legal opinion on consortium legal personality exists. Financing, IMO engagement, and rail operator partnership claims also lack verifiable artifacts.

**Mitigation**: Program Director & Cross-Border Governance Lead (Elena Vargas): Deliver a comprehensive BIT analysis, drafted bilateral treaty text with binding penalty clauses, and legal opinion on consortium legal personality by Q1 2027, plus written financing commitments from two development banks within 90 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the project's core final output — a 14 km pillar-supported submerged tunnel at 100m depth connecting Spain and Morocco for high-speed rail — and its key milestones (three functional-subsystem phases with specific durations, geotechnical validation gate by June 2027, prototype deployment by March 2028) are defined with specific, verifiable qualities including quantified success metrics (1 million passengers/year, €40B budget with 10-15% contingency, <0.5 safety incidents per 200,000 work hours). However, several critical supporting deliverables lack specific, verifiable qualities: the 'killer application' is explicitly identified as a weakness in the SWOT analysis ('the project lacks a clearly articulated and branded killer application'), the energy infrastructure plan (50-100 MW continuous demand) has no defined supply mechanism, owner, or budget allocation process, and flooding emergency protocols, decommissioning strategy, cybersecurity framework, and maritime traffic management are all identified as critical gaps without defined deliverables or acceptance criteria.

**Mitigation**: Program Director & Cross-Border Governance Lead (Elena Vargas): Define SMART acceptance criteria for the project's most critical undefined strategic deliverable — the killer application (branded as 'The Intercontinental Express') — including a specific quantifiable KPI such as '1 million passengers annually within 5 years of operational commencement' and a revenue model with minimum annual revenue floor of €500 million. Complete within 90 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes a proactive ecosystem restoration program that explicitly 'exceeds compliance requirements,' creating artificial reef structures along the tunnel corridor at a cost of €200-500 million. This activity adds significant cost and complexity without demonstrably supporting the project's primary stated objectives—constructing the pillar-supported submerged tunnel and enabling high-speed rail connectivity between Spain and Morocco. The plan itself confirms this program goes beyond binding legal/contractual requirements, making it a clear case of gold plating: spending €200-500 million on voluntary ecological enhancement that is not essential to the tunnel's structural function, rail operation, or cross-border connectivity. While environmental stewardship is commendable, it is a secondary related goal, not a primary objective, and the elevated pillar configuration already integrates habitat preservation into the core design without requiring the additional restoration program.

**Mitigation**: Environmental Compliance & Marine Ecology Director (Dr. Fatima Al-Rashid): Produce a one-page benefit case review for the ecosystem restoration program and artificial reef structures, including a specific KPI (e.g., benthic habitat recovery rate or cetacean population trend), estimated cost (€200-500 million), and named owner. If the benefit case cannot demonstrate measurable support for the project's primary objectives of tunnel construction and rail connectivity, move the program to the project backlog. Complete within 60 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Deep-Sea Structural Engineer is the unicorn role: validating the unprecedented 100m-depth hybrid floating-pillar architecture is the largest technical uncertainty with catastrophic €500M–€2B failure risk; no precedent exists for this expertise.

**Mitigation**: Program Director & Cross-Border Governance Lead (Elena Vargas): Commission a talent market validation study for the Deep-Sea Structural Engineer role—identifying available experts, assessing market capacity, and establishing a go/no-go checkpoint—within 60 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the governance legal architecture lacks any treaty law foundation — no BIT analysis, UNCLOS classification, or consortium legal personality exists. The maritime legal framework is entirely absent, and the 18-month ratification timeline is unrealistic for infrastructure treaties requiring 3-5 years.

**Mitigation**: Program Director & Cross-Border Governance Lead (Elena Vargas): Retain a specialized international treaty law team (minimum 4 attorneys) to conduct comprehensive BIT analysis, UNCLOS classification, and EU law assessment; commission maritime law analysis from a specialized firm; and establish a bilateral diplomatic task force with chief legal negotiators within 30 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan establishes a €3-8 billion maintenance trust fund and €2-4 billion decommissioning reserve capitalized at project inception, providing a clear funding mechanism for long-term sustainability. However, material gaps remain: the revenue model underpinning the maintenance trust fund is undefined (the plan states funding comes from 'a percentage of operational revenues' but no ridership projections, pricing strategy, or revenue-sharing agreement exists), the killer application is explicitly identified as a weakness ('the project lacks a clearly articulated and branded killer application'), technology obsolescence could require €1-4 billion in upgrades with no defined roadmap, and personnel turnover exceeding 20% annually could add €500 million-€1.5 billion in costs despite retention strategies. These concerns are addressable with planning but represent significant untested assumptions about post-completion viability.

**Mitigation**: Program Director & Cross-Border Governance Lead (Elena Vargas): Develop a comprehensive operational sustainability plan within 90 days covering: (1) a defined revenue model with minimum annual revenue floor of €500 million to sustain the maintenance trust fund, (2) a 20-year technology roadmap with upgrade cycles and €1-4 billion obsolescence budget, (3) a succession planning framework with knowledge management systems and 500+ annual trainees from maritime institutions, (4) a modular system upgrade protocol enabling component replacement without complete tunnel replacement, and (5) an ongoing environmental/social impact monitoring program with the independent oversight board.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies significant permitting challenges across multiple jurisdictions and acknowledges incomplete legal foundations (no BIT analysis, undefined consortium legal personality), but has mitigation strategies including bilateral diplomatic task force and IMO engagement.

**Mitigation**: Program Director & Cross-Border Governance Lead (Elena Vargas): Perform a fatal-flaw screen with authorities and experts; seek written confirmation of permitting feasibility; define fallback designs and dated NO-GO thresholds tied to constraint outcomes within 90 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project has multiple critical external dependencies that are single points of failure with no tested fallback. The supply chain depends on a centralized mega-hub in southern Spain that the plan itself identifies as a 'catastrophic single point of failure'—the proposed distributed supply chain with two regional fabrication yards and 3-6 month strategic inventory is recommended but not yet established or tested. Energy infrastructure (50-100 MW continuous demand) has no articulated supply strategy, no submarine HVDC cable specifications, and no backup power plan—rendering the tunnel inoperable without fallback. Maritime traffic management depends on the unvalidated assumption that dedicated transport corridors can be established across one of the world's busiest shipping lanes (100,000+ annual transits) without disruption. Cross-border governance depends on a bilateral treaty that has not been ratified and lacks any BIT analysis or UNCLOS classification. No contracts, SLAs, or tested failover mechanisms exist for any of these critical external dependencies.

**Mitigation**: Program Director & Cross-Border Governance Lead (Elena Vargas): Establish a distributed supply chain with at least two regional fabrication yards (Spain and Morocco) and pre-qualified alternative suppliers for all critical material categories by December 2027; maintain 3-6 month strategic inventory at offshore staging areas. Simultaneously, appoint an Energy Infrastructure Director to develop the hybrid energy strategy (submarine HVDC cables, offshore wind/tidal with battery storage, diesel backup) and negotiate energy supply agreements with both national grid operators before construction begins. Commission maritime traffic impact study and negotiate dedicated transport corridor agreements with the Strait of Gibraltar Joint Coordination Center by June 2027. Establish bilateral diplomatic task force with pre-negotiated framework agreements within 30 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Finance Department is incentivized by quarterly budget adherence, contingency reserve preservation (€4-6B), and investor confidence maintenance—prioritizing cost containment and on-time disbursement. R&D Team is incentivized by technological innovation leadership, thorough prototype validation, and first-mover advantage in subsea technology—prioritizing extensive iterative testing regardless of budget pressure. The unstated conflict: Finance views R&D's €200-500M prototype program and iterative validation cycles as a direct threat to the €40B envelope and 10-15% overrun tolerance, while R&D views Finance's rigid tranche milestones and contingency triggers as a threat to technical rigor. Each stakeholder's success metric (budget variance vs. validation completeness) is mutually undermining without a shared objective.

**Mitigation**: Program Director & Cross-Border Governance Lead (Elena Vargas): Co-create a shared OKR with Finance and R&D leads: 'Validate the hybrid floating-pillar architecture at 100m depth—achieving stable buoyancy equilibrium (±2m variance) and pillar load transfer sign-off by the Geotechnical Validation Gate (June 2027) while maintaining contingency reserve utilization below 50% at project midpoint.' Define joint KPIs: prototype validation milestone completion (R&D) and budget variance ≤10% (Finance), with shared accountability for both. Establish a joint Innovation-Investment Review Board that approves validation scope changes only when paired with offsetting cost reductions elsewhere. Complete within 60 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan has partial feedback elements (quarterly reviews, some KPIs, escalation triggers) but lacks a consolidated monthly review cadence, KPI dashboard, lightweight change board, and clear re-plan/stop thresholds.

**Mitigation**: Program Director & Cross-Border Governance Lead (Elena Vargas): Establish a monthly project review cadence with a KPI dashboard tracking structural integrity, financial discipline, timeline adherence, and ridership targets, plus a lightweight change board with defined thresholds for re-plan or stop decisions, within 60 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because governance misalignment cascades into permitting delays, cost escalation, and workforce demobilization across ≥3 domains. The plan states governance misalignment 'can stall the entire initiative.' Dependency triggers multi-domain failure.

**Mitigation**: Program Director & Cross-Border Governance Lead (Elena Vargas): Develop an interdependency map, bow-tie/FTA, and combined risk heatmap with owners, dates, and NO-GO/contingency thresholds for coupled High risks within 60 days.