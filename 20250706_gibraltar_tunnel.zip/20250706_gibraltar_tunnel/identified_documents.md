
## Documents to Create

### 1. Project Charter

**ID:** 74037638-6e60-448e-8954-468c39766b8b

**Description:** Formal authorization document establishing the €40 billion, 20-year transoceanic submerged tunnel project connecting Spain and Morocco at 100m depth across the Strait of Gibraltar. Defines the project purpose, measurable objectives, high-level scope, key stakeholders, Program Director authority, and initial success criteria. Establishes the Builder's Foundation strategic path as the chosen approach and provides the foundational mandate for all subsequent planning activities.

**Responsible Role Type:** Program Director & Cross-Border Governance Lead

**Primary Template:** PMI Project Charter Template

**Secondary Template:** World Bank Project Charter Framework

**Steps:**

- Define project purpose and measurable objectives aligned with SMART criteria
- Identify and document key stakeholders across both sovereign nations
- Establish high-level scope including the 14 km tunnel span, 100m depth, and functional-subsystem phasing approach
- Define Program Director authority and decision-making boundaries
- Establish initial success criteria including cross-border rail service commencement by ~2046
- Secure formal sign-off from both Spanish and Moroccan government representatives

**Approval Authorities:** Spanish Ministry of Transport, Moroccan Ministry of Equipment and Transport, Bilateral Diplomatic Task Force

### 2. Cross-Border Governance Framework

**ID:** bb320dc7-ba1e-4bcb-9292-a5fd09e0e814

**Description:** High-level governance architecture document establishing the political, administrative, and legal framework for managing the €40 billion project across two sovereign nations. Defines the neutral third-party consortium structure with technical decision-making authority, bilateral treaty ratification pathway through Spanish Cortes Generales and Moroccan Parliament, IMO engagement strategy for transboundary environmental assessment, ICC arbitration mechanisms for dispute resolution, and the diplomatic task force structure. Addresses sovereignty concerns, funding allocation mechanisms, and decision-making authority distribution between Spain and Morocco.

**Responsible Role Type:** Program Director & Cross-Border Governance Lead

**Primary Template:** Bilateral Infrastructure Treaty Framework Template

**Secondary Template:** IMO Transboundary Environmental Assessment Guidelines

**Steps:**

- Analyze existing Bilateral Investment Treaties between Spain and Morocco for applicable investment protection provisions
- Define consortium legal personality and structure (treaty-based organization vs. contractual joint venture vs. special purpose vehicle)
- Draft bilateral treaty framework with binding commitments, penalty clauses, and change-of-government survival provisions
- Establish IMO engagement strategy with pre-agreed timeline and fallback ICC arbitration
- Define dispute resolution pathways and enforcement mechanisms across sovereign jurisdictions
- Assess EU law constraints (TFEU provisions) on governance structure given Spain's EU membership

**Approval Authorities:** Spanish Cortes Generales, Moroccan Parliament, International Chamber of Commerce, IMO Legal Committee

### 3. Strategic Environmental Compliance Plan

**ID:** 136c81e8-007c-417f-91bb-57dd5ae64bd0

**Description:** High-level environmental strategy document governing regulatory, ecological, and permitting requirements for the transoceanic tunnel crossing international waters and sensitive marine ecosystems. Defines the elevated pillar configuration approach that preserves benthic habitats, the transboundary environmental impact assessment pathway through the IMO, seasonal construction restrictions during cetacean migration periods, the independent environmental oversight board structure with binding halt authority, and the ecosystem restoration program using artificial reef structures. Establishes the environmental compliance strategy as integrated engineering design rather than add-on remediation.

**Responsible Role Type:** Environmental Compliance & Marine Ecology Director

**Primary Template:** IMO Transboundary Environmental Impact Assessment Framework

**Secondary Template:** Barcelona Convention SPA/BD Protocol Compliance Template

**Steps:**

- Define elevated pillar configuration strategy that minimizes seabed contact area while preserving benthic habitats
- Establish IMO transboundary environmental impact assessment engagement pathway with pre-agreed timeline
- Design independent environmental oversight board structure with binding authority to halt construction
- Define seasonal construction restrictions during cetacean migration periods (spring March-May, autumn September-November)
- Plan ecosystem restoration program with artificial reef structures along tunnel corridor
- Establish €200-500 million marine mitigation fund structure

**Approval Authorities:** IMO Marine Environment Protection Committee, Spanish National Environmental Agency, Moroccan National Environmental Agency, Independent Environmental Oversight Board

### 4. Geotechnical Validation Framework

**ID:** 77a866a5-e9a4-4d93-8382-fdb4af3d3a21

**Description:** Foundational validation strategy document establishing the approach for validating the unprecedented hybrid floating-pillar architecture at 100m depth. Defines the geotechnical validation gate as a hard prerequisite before any construction mobilization, specifying deep-sea borehole sampling at minimum 5 locations across the 14 km corridor (200m below seabed), 3D seismic reflection profiling calibrated to the Azores-Gibraltar transform fault zone, probabilistic seismic hazard analysis with minimum 2% probability of exceedance in 50 years, 1:50 scale physical model testing under simulated Gibraltar Strait currents, and a fully instrumented 50-meter prototype segment deployment at 100m equivalent depth. Establishes the hard stop date of June 2027 before any construction permits are issued.

**Responsible Role Type:** Geotechnical & Seismic Engineering Director

**Primary Template:** Probabilistic Seismic Hazard Analysis Framework

**Secondary Template:** Deep-Sea Geotechnical Investigation Protocol

**Steps:**

- Define geotechnical validation gate with hard stop date before construction mobilization
- Specify deep-sea borehole sampling requirements (minimum 5 locations, 200m below seabed)
- Define 3D seismic reflection profiling scope calibrated to Azores-Gibraltar fault zone
- Establish probabilistic seismic hazard analysis methodology with minimum 2% PoE in 50 years
- Plan 1:50 scale physical model testing in deep-water basins under simulated currents (max 2.5 m/s)
- Define fully instrumented 50-meter prototype segment deployment and 6-month monitoring requirements

**Approval Authorities:** Independent Seismic Review Panel, Geotechnical & Seismic Engineering Director, Program Director

### 5. Phasing and Risk Strategy Document

**ID:** 0d6348a7-3a77-4682-bb34-f0a9e26bfa97

**Description:** Temporal architecture document defining the 20-year construction program's sequencing logic. Establishes functional-subsystem phasing (Phase 1: pillars and buoyancy ~6-7 years; Phase 2: rail infrastructure ~5-6 years; Phase 3: sealing, pressurization, and commissioning ~4-5 years) with 6-12 month inter-phase buffers for validation testing and course correction. Defines the balance between timeline compression and cost containment, the political sustainability considerations of phased returns, and the natural risk checkpoints that each phase provides. Addresses weather window dependencies consuming 20-30% of annual working time in the Strait of Gibraltar.

**Responsible Role Type:** Program Director & Cross-Border Governance Lead

**Primary Template:** Megaproject Phasing Strategy Framework

**Secondary Template:** Critical Path Method (CPM) Schedule Template with Monte Carlo Simulation

**Steps:**

- Define functional-subsystem phasing approach with approximate 4-5 year phases
- Establish go/no-go decision gates between each phase with validation testing requirements
- Define schedule contingency (2-3 years) and inter-phase buffer periods (6-12 months)
- Analyze weather window dependencies and their impact on annual working time (20-30%)
- Assess political sustainability implications of phased economic returns
- Establish tranche-based financing disbursement milestones aligned with phasing gates

**Approval Authorities:** Program Director, International Finance & Capital Director, Bilateral Diplomatic Task Force

### 6. International Consortium Financing Framework

**ID:** b1739746-7854-430e-b371-5e3270ef6bd7

**Description:** High-level capital sourcing and structuring document for the €40 billion project. Defines the financing architecture through multilateral government bonds jointly guaranteed by Spain and Morocco, public-private partnerships selling operational toll revenues, and multilateral development bank funds providing tranche-based disbursements tied to geological and marine milestones. Establishes the €4-6 billion contingency reserve with automated escalation triggers at 5%, 10%, and 15% budget utilization, the 12-month operational reserve fund, and the currency hedging program covering at least 70% of MAD-denominated expenditures. Addresses investor confidence management and alignment of return timelines with the 20-year construction horizon.

**Responsible Role Type:** International Finance & Capital Director

**Primary Template:** Multilateral Infrastructure Bond Structuring Framework

**Secondary Template:** Public-Private Partnership (PPP) Financial Model Template

**Steps:**

- Define financing architecture across sovereign bonds, development bank facilities, and private capital
- Establish tranche-based disbursement structure tied to geological and marine milestones
- Design €4-6 billion contingency reserve with automated escalation triggers
- Structure currency hedging program covering at least 70% of projected MAD-denominated expenditures
- Define 12-month operational reserve fund to buffer against funding cliffs
- Establish investor confidence management strategy including quarterly briefings and transparent reporting

**Approval Authorities:** European Investment Bank, African Development Bank, Spanish Ministry of Finance, Moroccan Ministry of Finance

### 7. Stakeholder Engagement Plan

**ID:** a09b3254-48dc-4cbf-9ad7-f4dce24d77fe

**Description:** Multi-tiered stakeholder engagement strategy document spanning two sovereign governments, international financial institutions, local communities in Tarifa and Tangier, environmental NGOs, maritime authorities, and the general public. Defines bilateral government coordination committees (quarterly), quarterly investor briefings with transparent financial reporting, community liaison offices in Tarifa and Tangier with bilingual communications teams, structured dialogue with environmental NGOs through advisory panels, and a public transparency portal with real-time project updates and environmental monitoring data. Includes community benefit agreements guaranteeing local hiring quotas and crisis communication protocols.

**Responsible Role Type:** Stakeholder Engagement & Public Affairs Director

**Primary Template:** Megaproject Stakeholder Engagement Framework

**Secondary Template:** Public Transparency Portal Design Specification

**Steps:**

- Map all stakeholder groups and define engagement tiers and frequency
- Design bilateral government coordination committee structure (quarterly meetings)
- Plan community liaison offices in Tarifa and Tangier with bilingual communications teams
- Define structured dialogue framework with environmental NGOs through advisory panels
- Design public transparency portal with real-time project updates and environmental monitoring data
- Establish crisis communication protocols and stakeholder advisory council

**Approval Authorities:** Program Director, Environmental Compliance & Marine Ecology Director, Bilateral Diplomatic Task Force

### 8. Risk Register

**ID:** 44c4b293-df48-4f6b-80c2-3c76065263ac

**Description:** Comprehensive initial risk register cataloging all identified risks across regulatory, technical, financial, environmental, social, operational, supply chain, security, geopolitical, and long-term sustainability categories. Documents 18 major risks including cross-border governance misalignment (2-5 year delay, €2-5 billion), unvalidated hybrid floating-pillar architecture (€500M-€2B per incident), financial sustainability over 20 years (€4-6 billion overrun potential), absence of seismic data near Azores-Gibraltar fault zone, missing energy supply infrastructure, inadequate maritime traffic integration, no decommissioning plan, rail gauge incompatibility, climate change impacts, and water intrusion/flooding risk at 100m depth. Includes impact, likelihood, severity, and mitigation actions for each risk.

**Responsible Role Type:** Program Director & Cross-Border Governance Lead

**Primary Template:** PMI Risk Register Template

**Secondary Template:** ISO 31000 Risk Management Framework

**Steps:**

- Catalog all 18 major risks across regulatory, technical, financial, environmental, social, operational, supply chain, security, geopolitical, and sustainability categories
- Assign impact, likelihood, and severity ratings for each risk
- Define mitigation actions and responsible owners for each risk
- Establish risk escalation thresholds and automated trigger mechanisms
- Identify risk interdependencies (governance delays compound financial exposure, technical failures trigger cost overruns)
- Define contingency reserve allocation aligned with risk severity

**Approval Authorities:** Program Director, International Finance & Capital Director, All Functional Directors

### 9. Communication Plan

**ID:** 939c6aff-0c7e-4200-a979-e77ad20b6c98

**Description:** Strategic communication document defining how project information flows to all stakeholder groups across the 20-year horizon. Establishes the public transparency portal strategy, quarterly investor briefing protocols, bilingual (Spanish/Arabic) community communications, environmental monitoring data disclosure frameworks, and crisis communication procedures. Defines the 'killer application' narrative positioning the tunnel as 'The Intercontinental Express' — the backbone of Euro-African connectivity enabling same-day business travel between continents. Addresses the gap in compelling narrative that could catalyze mainstream adoption and sustain political will across two decades.

**Responsible Role Type:** Stakeholder Engagement & Public Affairs Director

**Primary Template:** Megaproject Strategic Communication Framework

**Secondary Template:** Crisis Communication Protocol Template

**Steps:**

- Define the killer application narrative and brand identity ('The Intercontinental Express')
- Establish public transparency portal with real-time project updates and environmental monitoring data
- Design quarterly investor briefing protocols with transparent financial reporting
- Plan bilingual (Spanish/Arabic) community communications and community benefit agreements
- Define environmental monitoring data disclosure frameworks
- Establish crisis communication protocols and media engagement strategies

**Approval Authorities:** Program Director, Stakeholder Engagement & Public Affairs Director, Bilateral Diplomatic Task Force

### 10. High-Level Budget and Funding Framework

**ID:** 19edbbbc-ea99-4a4d-be4e-beb39be3a411

**Description:** High-level financial architecture document establishing the €40 billion budget envelope, its allocation across functional subsystems (pillar architecture, construction deployment, rail systems, environmental compliance, and operational readiness), the 10-15% contingency reserve (€4-6 billion), the 12-month operational reserve fund, and the currency hedging strategy covering 70% of MAD-denominated expenditures. Defines the cost escalation risk management approach including fixed-price contracts with penalty clauses, quarterly cost reviews, and automated escalation triggers at 5%, 10%, and 15% budget utilization. Addresses the €1-2 billion energy infrastructure budget, €3-8 billion maintenance trust fund, €2-4 billion decommissioning reserve fund, and €200-500 million marine mitigation fund.

**Responsible Role Type:** International Finance & Capital Director

**Primary Template:** Megaproject Budget Framework Template

**Secondary Template:** World Bank High-Value Infrastructure Budget Template

**Steps:**

- Define €40 billion budget allocation across functional subsystems
- Establish 10-15% contingency reserve (€4-6 billion) with automated escalation triggers
- Define 12-month operational reserve fund structure
- Design currency hedging program covering at least 70% of MAD-denominated expenditures
- Allocate dedicated budgets for energy infrastructure (€1-2B), maintenance trust fund (€3-8B), decommissioning reserve (€2-4B), and marine mitigation (€200-500M)
- Define cost escalation risk management including fixed-price contracts and quarterly reviews

**Approval Authorities:** International Finance & Capital Director, European Investment Bank, African Development Bank, Spanish Ministry of Finance, Moroccan Ministry of Finance

### 11. Initial High-Level Schedule and Timeline

**ID:** dd16e8e6-9425-4762-8d26-3ab15afa3a85

**Description:** High-level 20-year timeline document establishing the functional-subsystem phasing approach with approximate 4-5 year phases, weather window dependencies consuming 20-30% of annual working time, and 6-12 month inter-phase buffers. Defines the sequential logic of pre-project phases: governance establishment (Phase 0), geotechnical and environmental validation (Phase 1), infrastructure and workforce preparation (Phase 2), and prototype validation and permitting (Phase 3). Establishes the realistic mobilization date no earlier than 2030-2031 based on sequential phase-gate analysis, replacing the 'ASAP September 2026' start date. Defines key milestone gates including geotechnical validation gate (June 2027), prototype deployment (March 2028), and treaty ratification (by Q4 2028).

**Responsible Role Type:** Program Director & Cross-Border Governance Lead

**Primary Template:** Critical Path Method (CPM) High-Level Schedule Template

**Secondary Template:** Megaproject Phase-Gate Timeline Framework

**Steps:**

- Define sequential phase-gate methodology replacing parallel workstream assumptions
- Establish Phase 0 (Governance and Legal Foundation) timeline: Sept 2026 - Dec 2027
- Define Phase 1 (Geotechnical and Environmental Validation): Jan 2027 - Dec 2028
- Plan Phase 2 (Infrastructure and Workforce Preparation): Jan 2028 - Dec 2029
- Schedule Phase 3 (Prototype Validation and Permitting): Jan 2029 - Dec 2030
- Establish realistic mobilization date (no earlier than 2030-2031) and target operational commencement (~2046)

**Approval Authorities:** Program Director, All Functional Directors, Bilateral Diplomatic Task Force

### 12. Change Management Plan

**ID:** aa048334-0a8c-4412-8d27-0cb33501fb63

**Description:** High-level change management framework document addressing how changes to the project scope, design, governance, or timeline will be managed across two sovereign nations over a 20-year horizon. Defines the change request process, impact assessment methodology, approval authority thresholds, and escalation pathways for changes affecting the bilateral treaty, consortium governance, or €40 billion budget envelope. Addresses the risk that changes in government in either Spain or Morocco could fundamentally alter political commitment, funding guarantees, or governance structure, and establishes binding treaty commitments that survive political transitions.

**Responsible Role Type:** Program Director & Cross-Border Governance Lead

**Primary Template:** Megaproject Change Management Framework

**Secondary Template:** ISO 10006 Change Management Guidelines

**Steps:**

- Define change request process and impact assessment methodology for scope, design, and governance changes
- Establish approval authority thresholds for changes affecting budget, timeline, or treaty commitments
- Define escalation pathways for changes requiring bilateral government approval
- Establish binding treaty commitment structures that survive changes in government
- Design governance operations protocol defining technical vs. financial decision escalation
- Define automated shutdown protocols and emergency decision-making authority

**Approval Authorities:** Program Director, Bilateral Diplomatic Task Force, Neutral Third-Party Consortium

### 13. Monitoring and Evaluation Framework

**ID:** 88cbc6a7-e695-4601-ba49-745017c71377

**Description:** High-level M&E framework document establishing the key performance indicators, success metrics, and evaluation methodology for the 20-year project. Defines measurable targets including tunnel fully operational with cross-border rail service, structural integrity confirmed across the full 14 km span at 100m depth, all functional subsystems commissioned and validated, and cross-border rail service commenced. Establishes the monitoring architecture for structural surveillance (fiber-optic acoustic sensors, autonomous underwater vehicles, piezoelectric pressure sensors), environmental monitoring (real-time acoustic monitoring buoys at minimum 10 locations), and financial performance tracking (tranche-based disbursement milestones, cost escalation triggers).

**Responsible Role Type:** Program Director & Cross-Border Governance Lead

**Primary Template:** Megaproject M&E Framework Template

**Secondary Template:** World Bank Results Framework Template

**Steps:**

- Define measurable success criteria aligned with SMART goals
- Establish structural surveillance monitoring architecture and detection sensitivity targets
- Define environmental monitoring KPIs including marine mammal disturbance thresholds
- Design financial performance tracking including tranche-based disbursement milestones
- Establish automated alert systems for structural anomalies and environmental threshold breaches
- Define evaluation cadence and reporting structure for all stakeholder groups

**Approval Authorities:** Program Director, Structural Integrity & Lifecycle Maintenance Director, Environmental Compliance & Marine Ecology Director

### 14. Energy Infrastructure Strategy

**ID:** 04a0114e-b557-4b31-8c85-6bcbbc151b32

**Description:** High-level energy supply strategy document addressing the critical gap in the project's operational planning. Defines the comprehensive energy audit approach to quantify total operational demand (estimated 50-100 MW continuous), the hybrid energy strategy combining submarine HVDC cable connections to Spanish and Moroccan grids, offshore wind/tidal generation with battery storage, and diesel backup. Establishes the dedicated €1-2 billion energy infrastructure budget and the requirement to negotiate energy supply agreements with both national grid operators before construction begins. Addresses the fundamental risk that without reliable power, the tunnel cannot operate, rendering the entire €40 billion investment inoperable.

**Responsible Role Type:** Offshore Energy Infrastructure Engineer

**Primary Template:** Offshore Energy Infrastructure Planning Framework

**Secondary Template:** Submarine HVDC Cable Design Specification Template

**Steps:**

- Conduct comprehensive energy audit quantifying total operational demand (50-100 MW continuous)
- Define hybrid energy strategy combining submarine HVDC cables, offshore renewable generation, and backup power
- Establish dedicated €1-2 billion energy infrastructure budget
- Plan submarine HVDC cable specifications and grid interconnection requirements
- Define offshore wind/tidal generation capacity and battery storage requirements
- Establish negotiation timeline for energy supply agreements with both national grid operators

**Approval Authorities:** Spanish National Grid Operator, Moroccan National Grid Operator, Program Director

### 15. Maritime Traffic Integration Framework

**ID:** c54aaeb2-6150-4e0c-aa60-cadc8c33ec37

**Description:** High-level framework document addressing the critical gap in maritime traffic management for the Strait of Gibraltar, which sees over 100,000 vessel transits annually. Defines the comprehensive maritime traffic impact study approach including computational fluid dynamics modeling of tunnel-induced current changes, collision probability analysis, and the Temporary Traffic Management Plan with international authorities (IMO, Strait of Gibraltar Joint Coordination Center). Establishes the requirement for AIS monitoring and collision avoidance systems, permanent shipping lane adjustments, and a 24/7 maritime traffic control center for both construction and operational phases.

**Responsible Role Type:** Maritime Traffic & Navigation Safety Director

**Primary Template:** Maritime Traffic Impact Assessment Framework

**Secondary Template:** IMO Strait of Gibraltar Joint Coordination Center Protocols

**Steps:**

- Commission comprehensive maritime traffic impact study including CFD modeling and collision probability analysis
- Define Temporary Traffic Management Plan with IMO and Strait of Gibraltar Joint Coordination Center
- Plan AIS monitoring and collision avoidance system deployment
- Establish negotiation framework for permanent shipping lane adjustments
- Design 24/7 maritime traffic control center for construction and operational phases
- Define liability allocation framework for disruption to 100,000+ annual vessel transits

**Approval Authorities:** Strait of Gibraltar Joint Coordination Center, IMO, Spanish Maritime Authority, Moroccan Maritime Authority

### 16. Decommissioning Strategy

**ID:** 8ec9c64a-118f-4a8c-b48d-f1c4c61b7568

**Description:** High-level end-of-life strategy document addressing the unprecedented challenge of decommissioning a submerged tunnel at 100m depth across international waters between two sovereign nations. Defines the comprehensive decommissioning plan including environmental remediation protocols, material recovery strategies, and seabed restoration requirements. Establishes the €2-4 billion decommissioning reserve fund capitalized at project inception and the requirement to negotiate decommissioning obligations in the bilateral treaty and IMO framework. Addresses the massive unfunded liability created by the absence of any end-of-life planning, with unplanned decommissioning costs potentially reaching €5-15 billion.

**Responsible Role Type:** Decommissioning & End-of-Life Director

**Primary Template:** Submarine Infrastructure Decommissioning Framework

**Secondary Template:** IMO Decommissioning Guidelines for Artificial Installations

**Steps:**

- Define comprehensive decommissioning plan including environmental remediation protocols
- Establish material recovery strategies and seabed restoration requirements
- Structure €2-4 billion decommissioning reserve fund with contribution schedules and investment strategies
- Negotiate decommissioning obligations in bilateral treaty and IMO framework
- Conduct full lifecycle assessment (LCA) of construction and decommissioning environmental footprint
- Define end-of-life decision criteria and trigger mechanisms

**Approval Authorities:** IMO, Spanish Government, Moroccan Government, Independent Environmental Oversight Board

### 17. Technical Validation Strategy

**ID:** b01c4e11-c580-4eba-8a7a-a048894f764f

**Description:** High-level strategy document establishing the unified approach for validating the unprecedented hybrid floating-pillar architecture through prototype testing and research. Defines the 1:50 scale physical model testing roadmap in deep-water basins under simulated Gibraltar Strait current conditions, the fully instrumented 50-meter prototype segment deployment at 100m equivalent depth with minimum 6 months of continuous monitoring, and the full-scale pressurized rail prototype testing under simulated deep-sea conditions. Establishes the Research, Innovation & Prototype Validation Lead role to coordinate the research pipeline across all engineering disciplines and ensure the Builder's Foundation strategy's 'deliberate equilibrium between innovation and proven engineering' is maintained throughout the project lifecycle.

**Responsible Role Type:** Research, Innovation & Prototype Validation Lead

**Primary Template:** Prototype Validation Roadmap Framework

**Secondary Template:** Deep-Sea Structural Testing Protocol

**Steps:**

- Define unified prototype testing roadmap across all engineering disciplines
- Plan 1:50 scale physical model testing in deep-water basins under simulated currents (max 2.5 m/s)
- Define fully instrumented 50-meter prototype segment deployment and monitoring requirements
- Plan full-scale pressurized rail prototype testing under simulated 10-atmosphere conditions
- Establish knowledge management protocols for capturing and disseminating lessons learned
- Define go/no-go criteria for progression from validation to mass production

**Approval Authorities:** Research, Innovation & Prototype Validation Lead, Geotechnical & Seismic Engineering Director, Rail Systems & Transportation Engineering Lead

### 18. Workforce Resilience Strategy

**ID:** 8f471160-f44d-4fff-b49a-19cfcc89ea9e

**Description:** High-level workforce strategy document addressing the challenge of maintaining a stable, highly skilled workforce of 8,000-12,000 personnel across a 20-year isolated offshore construction environment. Defines the tiered rotational fly-in-fly-out model supplemented by permanent offshore residential platforms with family amenities, the partnership with maritime training institutions in Spain and Morocco targeting at least 500 trainees annually, the equity-sharing and long-term performance bonus structures tied to operational milestones, and the knowledge management system capturing structural engineering expertise independent of individual workers. Targets workforce turnover below 15% annually to avoid €500 million-€1.5 billion in repeated recruitment and training costs.

**Responsible Role Type:** Offshore Workforce & Safety Director

**Primary Template:** Megaproject Workforce Resilience Framework

**Secondary Template:** Offshore Workforce Retention Strategy Template

**Steps:**

- Define tiered rotational fly-in-fly-out model supplemented by permanent offshore residential platforms
- Establish partnerships with maritime training institutions in Cadiz province and Tanger-Tetouan-Al Hoceima region
- Design equity-sharing and long-term performance bonus structures tied to operational milestones
- Plan permanent offshore residential platforms with family amenities (schools, recreational facilities, healthcare)
- Establish knowledge management system capturing expertise independent of individual workers
- Define workforce turnover target below 15% annually and retention metrics

**Approval Authorities:** Offshore Workforce & Safety Director, Program Director, International Finance & Capital Director

### 19. Flooding Risk Management Strategy

**ID:** 12c4c3f0-7f85-4429-9171-3ae350730dc3

**Description:** High-level strategy document addressing the critical gap in flooding emergency protocols for hull breach scenarios at 100m depth with 10 atmospheres of external pressure. Defines the comprehensive flooding risk management approach including redundant hull integrity monitoring with automated breach detection at 500-point intervals, emergency flooding containment compartments at every 200-meter segment, rapid-deployment flood barriers at both tunnel entrance portals, and passenger evacuation protocols using specialized submersible rescue vehicles (50+ passengers per vehicle). Establishes dedicated emergency response vessels on 24/7 standby within 30 minutes of the tunnel corridor and the €100-300 million flooding prevention and response infrastructure budget.

**Responsible Role Type:** Structural Integrity & Lifecycle Maintenance Director

**Primary Template:** Submarine Flooding Emergency Response Framework

**Secondary Template:** Pressurized Enclosure Safety Standards Template

**Steps:**

- Define redundant hull integrity monitoring system with automated breach detection at 500-point intervals
- Plan emergency flooding containment compartments at every 200-meter segment interval
- Design rapid-deployment flood barriers at both tunnel entrance portals
- Define passenger evacuation protocols using specialized submersible rescue vehicles
- Establish dedicated emergency response vessels on 24/7 standby within 30 minutes
- Budget €100-300 million for flooding prevention and response infrastructure

**Approval Authorities:** Structural Integrity & Lifecycle Maintenance Director, Program Director, Offshore Workforce & Safety Director

### 20. Corrosion and Durability Management Strategy

**ID:** f85a2555-0c47-41f9-807f-b5002b61a59d

**Description:** High-level strategy document addressing the protection of the submerged concrete tunnel structure against the aggressive saline environment over a 20+ year operational horizon. Defines the multi-layer corrosion protection approach combining seamless polymer encapsulation, sacrificial zinc anodes within the concrete mix, and an active cathodic protection grid powered by offshore tidal energy generators as redundant systems. Establishes accessible inspection and maintenance ports at regular intervals, a dedicated corrosion monitoring program with predictive analytics, and the €3-8 billion maintenance trust fund for 20-year lifecycle costs. Addresses the risk that unmanaged corrosion could reduce structural lifespan below the 20-year horizon requiring premature rehabilitation.

**Responsible Role Type:** Structural Integrity & Lifecycle Maintenance Director

**Primary Template:** Submarine Corrosion Protection Framework

**Secondary Template:** ISO 12944 Corrosion Protection Standards Template

**Steps:**

- Define multi-layer corrosion protection combining polymer encapsulation, sacrificial anodes, and active cathodic protection
- Design accessible inspection and maintenance ports at regular intervals along the tunnel
- Establish dedicated corrosion monitoring program with predictive analytics
- Plan offshore tidal energy generators for cathodic protection power supply
- Define accelerated life-cycle testing under simulated 20-year saline exposure
- Structure €3-8 billion maintenance trust fund capitalized at project inception

**Approval Authorities:** Structural Integrity & Lifecycle Maintenance Director, Program Director, International Finance & Capital Director

### 21. Subsea Structural Surveillance Strategy

**ID:** 1c765104-7288-4dea-adeb-4d4cc18658ac

**Description:** High-level strategy document establishing the continuous real-time monitoring architecture across the submerged tunnel and pillar infrastructure. Defines the dense mesh of fiber-optic acoustic sensors along the entire tunnel length for structural deformation detection, autonomous underwater vehicles on fixed patrol routes for daily high-resolution sonar scans, and wireless piezoelectric pressure sensors embedded within the concrete matrix transmitting via acoustic modem to surface buoys. Establishes the data processing and analytics infrastructure for micro-fracture and sediment shift detection, automated shutdown protocols triggered by structural anomalies, and the integration with the Structural-Geotechnical Monitoring Framework.

**Responsible Role Type:** Structural Integrity & Lifecycle Maintenance Director

**Primary Template:** Subsea Structural Health Monitoring Framework

**Secondary Template:** Fiber-Optic Acoustic Sensor Network Design Specification

**Steps:**

- Define fiber-optic acoustic sensor mesh deployment along the entire 14 km tunnel length
- Plan autonomous underwater vehicle patrol routes and daily sonar scan schedules
- Design wireless piezoelectric pressure sensor network with acoustic modem transmission
- Establish data processing and analytics infrastructure for real-time structural health assessment
- Define automated shutdown protocols triggered by micro-fracture detection or depth deviation
- Plan integration with geotechnical monitoring data for unified Structural-Geotechnical Monitoring Framework

**Approval Authorities:** Structural Integrity & Lifecycle Maintenance Director, Geotechnical & Seismic Engineering Director, Program Director

### 22. Hydrodynamic Load Mitigation Strategy

**ID:** e9ae7a86-c137-4f95-981b-a86aa7da5e7a

**Description:** High-level strategy document addressing the engineering challenge of managing ocean currents, wave kinetic energy, and hydrodynamic pressures acting on the submerged tunnel structure at 100 meters depth. Defines the tunnel exterior profiling strategy (aerodynamic ridges to slice through deep-water currents), articulated flexible joints between tunnel segments to absorb wave-induced kinetic energy, and passive counter-oscillating outer shell systems. Establishes the interaction between hydrodynamic profile design and pillar architecture, the impact on buoyancy equilibrium, and the trade-offs with corrosion management through flexible joint seal interfaces.

**Responsible Role Type:** Marine Construction & Offshore Engineering Lead

**Primary Template:** Hydrodynamic Load Mitigation Engineering Framework

**Secondary Template:** Deep-Water Hydrodynamic Simulation Protocol

**Steps:**

- Define tunnel exterior profiling strategy for deep-water current deflection
- Plan articulated flexible joint design for wave energy absorption
- Design passive counter-oscillating outer shell systems
- Analyze interaction between hydrodynamic profile and pillar architecture load transfer
- Assess impact on buoyancy equilibrium and required recalibration
- Evaluate corrosion implications of flexible joint seal interfaces over 20-year lifespan

**Approval Authorities:** Marine Construction & Offshore Engineering Lead, Structural Integrity & Lifecycle Maintenance Director

### 23. Buoyancy Engineering Strategy

**ID:** bdb87da0-6da6-4f88-9724-12b5ad60a7f5

**Description:** High-level strategy document governing the vertical positioning stability and depth control of tunnel segments throughout the operational life. Defines the variable-ballast buoyant concrete sections that actively adjust displacement in response to real-time depth sensors, the rigid-buoyancy modules with fixed displacement calibrated for mean 100-meter depth, and the pneumatic buoyancy bladders for emergency surfacing capability. Establishes the interaction between buoyancy loads and pillar supports, the material composition implications for corrosion resistance, and the trade-offs between active ballast complexity and passive fixed-buoyancy simplicity.

**Responsible Role Type:** Marine Construction & Offshore Engineering Lead

**Primary Template:** Deep-Sea Buoyancy Engineering Framework

**Secondary Template:** Variable-Ballast Submarine Stability Protocol

**Steps:**

- Define variable-ballast buoyant concrete section design with real-time depth sensor integration
- Plan rigid-buoyancy modules with fixed displacement calibrated for 100m mean depth
- Design pneumatic buoyancy bladders for emergency surfacing capability
- Analyze buoyancy load transfer into pillar support systems
- Assess material composition implications for corrosion resistance and structural lifespan
- Evaluate active ballast system complexity vs. passive fixed-buoyancy trade-offs

**Approval Authorities:** Marine Construction & Offshore Engineering Lead, Structural Integrity & Lifecycle Maintenance Director

### 24. Offshore Logistics and Supply Chain Strategy

**ID:** 4d53176c-a8b8-4b50-916d-b26e45d3a7ef

**Description:** High-level strategy document managing the end-to-end flow of materials, components, and equipment across international waters for the tunnel construction program. Defines the distributed supply chain approach with at least two regional fabrication yards (southern Spain near Tarifa/Algeciras and northern Morocco near Tangier-Med) for redundancy, the 3-6 month strategic inventory of critical materials at offshore staging areas, and the pre-qualified alternative supplier network. Establishes blockchain-based supply chain tracking for real-time visibility and addresses the single-point-of-failure risk of the centralized mega-hub approach.

**Responsible Role Type:** Marine Construction & Offshore Engineering Lead

**Primary Template:** Offshore Supply Chain Resilience Framework

**Secondary Template:** Blockchain-Based Supply Chain Tracking Specification

**Steps:**

- Define distributed supply chain with at least two regional fabrication yards for redundancy
- Plan 3-6 month strategic inventory of critical materials at offshore staging areas
- Establish pre-qualified alternative supplier network for all critical material categories
- Design blockchain-based supply chain tracking system for real-time visibility
- Define maritime transport corridor agreements with Strait of Gibraltar Joint Coordination Center
- Plan purpose-built semi-submersible transport vessel fleet (minimum 3)

**Approval Authorities:** Marine Construction & Offshore Engineering Lead, Program Director, International Finance & Capital Director

### 25. Safety and Emergency Response Strategy

**ID:** 0e025657-3508-4ce2-801b-5c6c5cc93f34

**Description:** High-level safety framework document establishing the comprehensive safety management system for the 8,000-12,000 personnel across the 20-year construction period. Defines the multi-layered safety framework including real-time structural monitoring with automated shutdown protocols, dedicated emergency response vessels on 24/7 standby within 30 minutes of the tunnel corridor, pressurized corridor evacuation systems with redundant pathways and emergency depressurization protocols, and the comprehensive insurance program covering structural failure (€500 million-€2 billion per incident), environmental damage, and personnel incidents. Establishes the safety incident frequency target below 0.5 per 200,000 work hours and annual full-scale emergency simulation exercises.

**Responsible Role Type:** Offshore Workforce & Safety Director

**Primary Template:** Megaproject Safety Management Framework

**Secondary Template:** Pressurized Enclosure Emergency Response Protocol

**Steps:**

- Define multi-layered safety framework with automated shutdown protocols triggered by micro-fracture detection
- Establish dedicated emergency response vessels on 24/7 standby within 30 minutes
- Design pressurized corridor evacuation systems with redundant pathways and emergency depressurization
- Define comprehensive insurance program covering structural failure, environmental damage, and personnel incidents
- Establish safety incident frequency target below 0.5 per 200,000 work hours
- Plan annual full-scale emergency simulation exercises with joint Spain-Morocco coordination center

**Approval Authorities:** Offshore Workforce & Safety Director, Program Director, Structural Integrity & Lifecycle Maintenance Director

### 26. Geopolitical Risk Mitigation Strategy

**ID:** bafdeece-3f00-4a1a-b74f-c1156e5fd9ba

**Description:** High-level strategy document addressing the risks from changes in government in either Spain or Morocco, diplomatic tensions, and geopolitical dynamics that could escalate to project suspension or cancellation. Defines the binding international treaty approach that survives changes in government, the neutral dispute resolution mechanism with enforcement authority, the diversification of political support by demonstrating economic benefits to constituencies in both nations, and the continuous diplomatic engagement at multiple levels of government. Addresses the risk that a change in government or diplomatic crisis could result in project suspension lasting 1-3 years costing €2-6 billion.

**Responsible Role Type:** Program Director & Cross-Border Governance Lead

**Primary Template:** Megaproject Geopolitical Risk Mitigation Framework

**Secondary Template:** Binding International Treaty Design Template

**Steps:**

- Define binding international treaty structure that survives changes in government
- Establish neutral dispute resolution mechanism with enforcement authority
- Plan diversification of political support through demonstrated economic benefits to both nations
- Define continuous diplomatic engagement at multiple levels of government
- Establish early warning system for political risk indicators in both countries
- Define project suspension and remobilization protocols

**Approval Authorities:** Program Director, Bilateral Diplomatic Task Force, Both National Governments

## Documents to Find

### 1. Strait of Gibraltar Seismic and Geotechnical Data

**ID:** b0e4850d-3c68-47c4-8174-f30818941711

**Description:** Site-specific seismic hazard data, deep-sea borehole sampling results, 3D seismic reflection profiling data, and geotechnical characterization of clay, sand, and weathered bedrock strata at 100m depth below the Strait of Gibraltar seabed. This raw data is essential for the Geotechnical Validation Framework to validate the hybrid floating-pillar architecture and for all structural design decisions. The Azores-Gibraltar seismic transform fault zone proximity makes this data foundational to the entire project.

**Recency Requirement:** Most recent available year; geological data should be current within the last 5 years, with seismic hazard analysis updated to reflect latest IPCC-era climate projections

**Responsible Role Type:** Geotechnical & Seismic Engineering Director

**Access Difficulty:** Hard

**Steps:**

- Contact Spanish Instituto Geográfico Nacional (IGN) for seismic monitoring data in the Strait of Gibraltar region
- Request deep-sea borehole sampling data from Spanish and Moroccan geological survey agencies
- Access international seismic databases (ISC, USGS) for historical seismic activity in the Azores-Gibraltar transform zone
- Commission new 3D seismic reflection profiling surveys across the full 14 km tunnel corridor
- Obtain existing offshore energy sector geotechnical data from Mediterranean deep-sea operations

### 2. Existing Spain-Morocco Bilateral Investment Treaties

**ID:** bbaa2316-81d6-4636-9032-5a48243e44d1

**Description:** All existing Bilateral Investment Treaties (BITs) between Spain and Morocco, including investment protection provisions, minimum standard of treatment obligations, expropriation clauses, ISDS mechanisms, and sunset clauses. This raw treaty text is essential for the Cross-Border Governance Framework to assess applicable investment protections and determine whether the proposed consortium qualifies as an 'investment' triggering ISDS mechanisms.

**Recency Requirement:** All currently in-force treaties; any amendments or protocols within the last 10 years

**Responsible Role Type:** International Infrastructure Governance Lawyer

**Access Difficulty:** Medium

**Steps:**

- Search UNCTAD Investment Policy Hub for Spain-Morocco BIT texts
- Access Spanish Ministry of Economy and Finance treaty database
- Contact Moroccan Ministry of Economy and Finance for BIT documentation
- Review OECD Investment Policy Database for bilateral treaty texts
- Consult international law firm databases for Spain-Morocco investment treaty analysis

### 3. IMO Regulatory Framework for Subsea Installations

**ID:** 41f04887-969b-4001-8c54-dc98e5dda979

**Description:** International Maritime Organization regulatory documents governing artificial installations, submarine structures, and transboundary underwater construction in international waters. Includes UNCLOS Part V provisions on artificial islands and installations, SOLAS regulations for submerged structures, MARPOL environmental protection requirements, and the Barcelona Convention (SPA/BD Protocol, LBS Protocol) for Mediterranean marine environment protection. This raw regulatory text is essential for the Strategic Environmental Compliance Plan and the Cross-Border Governance Framework.

**Recency Requirement:** Current regulations as of 2025-2026; any amendments within the last 5 years

**Responsible Role Type:** International Infrastructure Governance Lawyer

**Access Difficulty:** Medium

**Steps:**

- Access IMO Legal Committee and Marine Environment Protection Committee documentation
- Retrieve UNCLOS Part V provisions on artificial installations from IMO website
- Obtain Barcelona Convention and its protocols from UNEP Mediterranean Action Plan
- Access SOLAS and MARPOL consolidated texts from IMO regulatory database
- Review IMO guidelines for transboundary underwater construction projects

### 4. Strait of Gibraltar Maritime Traffic Statistical Data

**ID:** cb441285-9b55-4adb-ad4f-43f9cec93658

**Description:** Annual vessel transit statistics, shipping lane configurations, collision history data, and maritime traffic density measurements for the Strait of Gibraltar. This raw statistical data is essential for the Maritime Traffic Integration Framework to conduct computational fluid dynamics modeling, collision probability analysis, and develop the Temporary Traffic Management Plan. The strait sees over 100,000 vessel transits annually including massive tankers and container ships.

**Recency Requirement:** Most recent 5-year period (2020-2025) to capture current traffic trends and vessel size distributions

**Responsible Role Type:** Maritime Traffic & Navigation Safety Director

**Access Difficulty:** Medium

**Steps:**

- Request data from Strait of Gibraltar Joint Coordination Center
- Access IMO statistical data on maritime traffic through the Strait of Gibraltar
- Contact Spanish Port Authority (Puertos del Estado) for traffic statistics near Tarifa
- Obtain Moroccan port authority data for Tangier-Med traffic volumes
- Access Lloyd's List or similar maritime intelligence databases for strait traffic analysis

### 5. IPCC Climate Projections for Mediterranean Region

**ID:** b82bdbd9-4a6f-4c48-8331-b0d984628a51

**Description:** IPCC climate change projection data for the Mediterranean and Atlantic regions including sea level rise projections (SSP2-4.5 and SSP5-8.5 scenarios), storm intensity projections, ocean current change models, and water temperature projections for the period through 2043 and beyond. This raw climate data is essential for integrating climate adaptation into structural design parameters and for the Environmental Compliance Strategy. Sea levels may rise 0.3-0.6m by 2043, and storm intensity may increase 10-20%.

**Recency Requirement:** IPCC Sixth Assessment Report (AR6) data; latest available projections as of 2025-2026

**Responsible Role Type:** Geotechnical & Seismic Engineering Director

**Access Difficulty:** Easy

**Steps:**

- Access IPCC AR6 Working Group I report data for Mediterranean sea level projections
- Retrieve SSP2-4.5 and SSP5-8.5 scenario data from IPCC Data Distribution Centre
- Obtain Mediterranean climate model projections from national meteorological agencies
- Access ocean current and storm intensity projection models from European climate services
- Commission specialized climate projection analysis for the Strait of Gibraltar region

### 6. Existing Cross-Border Infrastructure Treaty Precedents

**ID:** 34ce1066-156a-4c8e-8f72-14589e666f72

**Description:** Existing bilateral and multilateral treaties for cross-border infrastructure projects including the Channel Tunnel Treaty (UK-France), the Øresund Consortium Agreement (Denmark-Sweden), and other transboundary infrastructure governance frameworks. This raw treaty text provides templates and precedents for the Spain-Morocco bilateral treaty structure, governance mechanisms, and dispute resolution frameworks.

**Recency Requirement:** Original treaty texts with any amendments; Channel Tunnel Treaty (1986), Øresund Agreement (1995)

**Responsible Role Type:** International Infrastructure Governance Lawyer

**Access Difficulty:** Medium

**Steps:**

- Retrieve Channel Tunnel Treaty text from UK National Archives
- Access Øresund Consortium Agreement documentation from Øresundsbro Konsortiet
- Search UN Treaty Collection for cross-border infrastructure treaty precedents
- Contact Institution of Civil Engineers for Channel Tunnel governance documentation
- Review Nordic Council cross-border infrastructure agreement templates

### 7. Spain and Morocco Rail Gauge and Signaling Standards

**ID:** be926dec-0f97-48cd-a8f1-12c841078d4f

**Description:** Official documentation of Spain's Iberian gauge (1,668mm) and 25kV AC electrification standards, Morocco's standard gauge (1,435mm) and 3kV DC electrification standards, and existing ERTMS signaling system specifications. This raw standards documentation is essential for the Rail Systems Integration strategy to resolve the fundamental gauge incompatibility and design unified signaling and electrification systems.

**Recency Requirement:** Current national rail standards as of 2025-2026; any recent standardization updates

**Responsible Role Type:** Rail Systems & Transportation Engineering Lead

**Access Difficulty:** Easy

**Steps:**

- Access Spanish Ministry of Transport rail gauge and signaling standards documentation
- Retrieve Moroccan Ministry of Equipment and Transport rail standards
- Obtain ERTMS specification documents from European Railway Agency
- Contact Spanish ADIF and Moroccan ONCF for current rail infrastructure specifications
- Access international rail interoperability standards (UIC, CEN) for gauge transition requirements

### 8. Strait of Gibraltar Marine Ecosystem Baseline Data

**ID:** 23d0ed4e-53fb-4071-a26a-fa83cfc06c77

**Description:** Existing marine ecosystem data including cetacean migration pattern studies, benthic habitat mapping, water quality parameters, and sediment dynamics measurements for the Strait of Gibraltar corridor. This raw baseline data is essential for the Environmental Compliance Strategy and for commissioning comprehensive marine ecosystem baseline studies. The strait is home to critical cetacean migratory routes and fragile benthic habitats.

**Recency Requirement:** Most recent available studies; ideally within the last 5 years, with 24-month field data collection required before construction

**Responsible Role Type:** Environmental Compliance & Marine Ecology Director

**Access Difficulty:** Medium

**Steps:**

- Access IUCN Mediterranean marine ecosystem data and cetacean population studies
- Retrieve Convention on Migratory Species (CMS) data on cetacean migration through Strait of Gibraltar
- Obtain Spanish and Moroccan marine biodiversity survey data from national environmental agencies
- Access European Environment Agency marine ecosystem databases for the Mediterranean
- Contact research institutions (e.g., University of Barcelona, Mohammed V University) for existing marine ecology studies

### 9. EUR-MAD Currency Hedging and Foreign Exchange Framework

**ID:** 78fe4590-2daf-4826-952a-0dc0e79288a7

**Description:** Existing foreign exchange market data, currency hedging instrument specifications, Morocco's foreign exchange control regulations, and MAD convertibility/repatriation rights documentation. This raw financial data is essential for the International Consortium Financing Framework to design the currency hedging program covering at least 70% of MAD-denominated expenditures and to address Morocco's foreign exchange controls.

**Recency Requirement:** Current foreign exchange market data as of 2025-2026; Morocco's foreign exchange regulations current within last 2 years

**Responsible Role Type:** International Finance & Capital Director

**Access Difficulty:** Medium

**Steps:**

- Access Bank of Spain and Bank Al-Maghrib foreign exchange data and regulations
- Retrieve Morocco's foreign exchange control legislation and MAD convertibility rules
- Obtain EUR-MAD forward contract and swap pricing data from international banks
- Access IMF Article IV consultation reports on Morocco for foreign exchange policy analysis
- Consult international banking facilities for MAD hedging instrument availability and terms

### 10. Offshore Construction Cost Benchmarks and Reference Data

**ID:** 21cd1a0b-ab9e-4edc-b6f4-4e7c178f62df

**Description:** Cost data from comparable offshore and undersea construction projects including the Channel Tunnel (£9.5 billion, 73% cost overrun), Seikan Tunnel (¥700 billion), Marmaray Tunnel ($4.5 billion, 80% overrun), Gotthard Base Tunnel (CHF 12.2 billion), and Øresund Fixed Link (DKK 30 billion). This raw cost benchmark data is essential for the High-Level Budget and Funding Framework to validate the €40 billion budget envelope and the 10-15% contingency reserve assumption.

**Recency Requirement:** Most recent available cost data; original project costs with any subsequent adjustments

**Responsible Role Type:** International Finance & Capital Director

**Access Difficulty:** Easy

**Steps:**

- Retrieve Channel Tunnel cost data from Getlink investor relations and UK National Archives
- Access Seikan Tunnel cost data from JR Hokkaido and Japan Ministry of Land, Infrastructure, Transport and Tourism
- Obtain Marmaray Tunnel cost data from TCDD and World Bank project documents
- Access Gotthard Base Tunnel cost data from SBB CFF FFS and Swiss Federal Office of Transport
- Retrieve Øresund Fixed Link cost data from Øresundsbro Konsortiet and Nordic infrastructure databases

### 11. Existing Decommissioning Regulations and Precedents

**ID:** 35c764fb-8898-4a80-b3c5-cc4eeeac55c6

**Description:** International and domestic regulations governing the decommissioning of underwater structures, artificial installations, and offshore infrastructure. Includes IMO guidelines for decommissioning artificial installations, Barcelona Convention decommissioning protocols, and domestic regulations from Spain and Morocco for marine structure removal. This raw regulatory text is essential for the Decommissioning Strategy to define environmental remediation protocols, material recovery requirements, and seabed restoration obligations.

**Recency Requirement:** Current regulations as of 2025-2026; any recent amendments to decommissioning requirements

**Responsible Role Type:** Decommissioning & End-of-Life Director

**Access Difficulty:** Medium

**Steps:**

- Access IMO guidelines for decommissioning of artificial installations and structures
- Retrieve Barcelona Convention protocols on decommissioning and marine pollution prevention
- Obtain Spanish maritime decommissioning regulations from Spanish Maritime Safety Agency
- Access Moroccan marine infrastructure decommissioning regulations
- Review existing offshore oil and gas decommissioning precedents in the Mediterranean

### 12. Strait of Gibraltar Oceanographic and Current Data

**ID:** 69af898a-be56-4a7a-9e83-6d50088597ce

**Description:** Oceanographic data including current velocity profiles, wave height statistics, tidal patterns, water temperature data, and sediment transport dynamics for the Strait of Gibraltar at 100m depth. This raw oceanographic data is essential for the Hydrodynamic Load Mitigation Strategy, the buoyancy engineering design, and the climate adaptation integration. The strait's unique Atlantic-Mediterranean exchange creates complex current dynamics that directly affect structural loads.

**Recency Requirement:** Most recent 5-year period (2020-2025) to capture current oceanographic conditions and trends

**Responsible Role Type:** Marine Construction & Offshore Engineering Lead

**Access Difficulty:** Medium

**Steps:**

- Access oceanographic data from Spanish Instituto Español de Oceanografía (IEO)
- Retrieve Moroccan oceanographic monitoring data from Institut National de Recherche Océanographique
- Obtain current velocity and wave height data from Strait of Gibraltar Joint Coordination Center
- Access European Copernicus Marine Service oceanographic datasets for the Strait region
- Commission specialized oceanographic survey for 100m depth current and wave conditions

### 13. Existing Offshore Workforce Accommodation and Safety Standards

**ID:** 52d529e4-f4ec-4d77-b8c6-66e40154d894

**Description:** International standards and regulations for offshore workforce accommodation, safety management, and rotational work patterns in isolated marine environments. Includes IMCA (International Marine Contractors Association) standards, offshore survival and firefighting training requirements, saturation diving limits, and permanent offshore platform accommodation design specifications. This raw standards data is essential for the Workforce Resilience Strategy to design safe and effective offshore living and working conditions.

**Recency Requirement:** Current IMCA and international offshore safety standards as of 2025-2026

**Responsible Role Type:** Offshore Workforce & Safety Director

**Access Difficulty:** Easy

**Steps:**

- Access IMCA standards for offshore accommodation and workforce management
- Retrieve international offshore safety management system requirements (ISO 45001)
- Obtain saturation diving and offshore survival training standards from international diving organizations
- Access existing offshore platform accommodation design specifications from major offshore engineering firms
- Review workforce retention studies for long-duration offshore projects

### 14. Submarine HVDC Cable Technology Specifications

**ID:** 99f09b28-f388-437a-891f-8b4681aac199

**Description:** Technical specifications and market data for submarine HVDC (High Voltage Direct Current) cable systems including capacity ratings, installation methodologies, depth capabilities, and cost benchmarks. This raw technical data is essential for the Energy Infrastructure Strategy to design the submarine cable connections between the tunnel and Spanish and Moroccan national grids. The project requires an estimated 50-100 MW continuous power supply at 100m depth.

**Recency Requirement:** Current technology specifications as of 2025-2026; latest commercial HVDC cable product data

**Responsible Role Type:** Offshore Energy Infrastructure Engineer

**Access Difficulty:** Medium

**Steps:**

- Access submarine HVDC cable manufacturer specifications (e.g., Prysmian, Nexans, NKT)
- Retrieve existing submarine HVDC project data (e.g., North Sea Link, Viking Link) for reference
- Obtain deep-sea cable installation methodology documentation from offshore engineering firms
- Access European grid interconnection specifications for HVDC submarine connections
- Contact national grid operators for submarine cable interface requirements

### 15. Existing Pressurized Enclosure and Underground Rail Standards

**ID:** c84e6cc8-8edd-4554-b546-5ced9e828f1f

**Description:** International standards and specifications for pressurized enclosures, underground rail systems in pressurized environments, and sealed corridor design for passenger safety. Includes pressure vessel certification standards, pressurized tunnel design codes, and underground rail ventilation requirements. This raw standards data is essential for the Rail Systems Integration strategy to design the sealed pressurized rail corridor maintaining terrestrial-grade precision under 10 atmospheres of external hydrostatic pressure.

**Recency Requirement:** Current pressurized enclosure and underground rail standards as of 2025-2026

**Responsible Role Type:** Rail Systems & Transportation Engineering Lead

**Access Difficulty:** Medium

**Steps:**

- Access ASME pressure vessel certification standards for pressurized rail corridors
- Retrieve underground rail pressurized environment design codes from international standards bodies
- Obtain tunnel ventilation and pressurization system specifications from existing pressurized rail projects
- Access European railway interoperability standards (TSI) for pressurized environments
- Review existing pressurized underground infrastructure case studies for design parameters