**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic oversight and approval at a higher level.
Negative Consequences: Potential budget overruns, project delays, and financial instability.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: Materialization of a critical risk (e.g., geopolitical instability, major technical failure) requires strategic reassessment and resource allocation beyond the PMO's capacity.
Negative Consequences: Project failure, significant financial losses, and reputational damage.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: Inability of the PMO to reach a consensus on a key vendor selection necessitates a higher-level decision to ensure project progress.
Negative Consequences: Project delays, increased costs, and potential legal challenges.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote on Scope Change Request
Rationale: Significant alterations to the project scope require strategic evaluation and approval to ensure alignment with project objectives and budget.
Negative Consequences: Scope creep, budget overruns, and project delays.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Steering Committee
Rationale: Allegations of ethical violations require independent investigation and appropriate action to maintain project integrity and reputation.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Unresolved Technical Design Conflict**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Decision based on TAG Recommendation
Rationale: If the Technical Advisory Group cannot resolve a critical technical design conflict, the Steering Committee must provide strategic direction.
Negative Consequences: Compromised tunnel integrity, safety risks, and potential project failure.

**Significant Stakeholder Opposition**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Stakeholder Engagement Plan and Mitigation Strategies
Rationale: If the Stakeholder Engagement Group cannot mitigate significant opposition from key stakeholders, the Steering Committee must intervene to ensure project viability.
Negative Consequences: Project delays, legal challenges, and reputational damage.