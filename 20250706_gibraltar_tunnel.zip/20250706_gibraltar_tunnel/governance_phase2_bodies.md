### 1. Project Steering Committee

**Rationale for Inclusion:** This €40 billion, 20-year transoceanic tunnel spanning two sovereign nations demands a apex strategic oversight body capable of aligning Spanish and Moroccan national interests, approving billion-euro budget allocations, and providing unified strategic direction across an unprecedented engineering endeavor. The project's cross-border governance complexity, geopolitical risk exposure, and the need for parliamentary ratification of bilateral treaties require a body with sovereign-level authority that transcends purely operational management. Without it, strategic misalignment between nations could stall the project at the midpoint where both jurisdictions must simultaneously contribute resources.

**Responsibilities:**

- Provide high-level strategic direction and approve the project's overall vision, mission, and strategic framework
- Approve budgets exceeding €50 million and any modifications to the €40 billion total capital envelope
- Ratify major milestone approvals and phase-gate go/no-go decisions across all functional subsystems
- Oversee cross-border diplomatic alignment between Spain and Morocco, including bilateral treaty compliance
- Approve selection and oversight of the neutral third-party engineering consortium leadership
- Review and endorse the project's risk appetite statement and major risk mitigation strategies
- Ensure alignment with IMO transboundary environmental frameworks and bilateral parliamentary commitments
- Approve changes to project scope, timeline, or governance structure
- Oversee investor relations and ensure confidence in tranche-based financing disbursements

**Initial Setup Actions:**

- Establish the bilateral treaty foundation by ratifying the governance charter through both Spanish Cortes Generales and Moroccan Parliament
- Elect a joint Chair and Vice-Chair from senior representatives of Spain and Morocco respectively
- Define and formalize the financial approval thresholds distinguishing strategic from operational decisions
- Appoint independent external members to ensure impartial oversight and prevent sovereign dominance
- Establish the terms of reference including decision rights, escalation protocols, and meeting cadence
- Convene the first strategic session to align both nations on the Builder's Foundation strategic path
- Formalize the relationship and reporting lines between the Steering Committee and all subordinate governance bodies

**Membership:**

- Minister of Transport, Spain (or designated delegate)
- Minister of Equipment and Transport, Morocco (or designated delegate)
- Chair of the Neutral Third-Party Engineering Consortium
- Head of the Bilateral Diplomatic Task Force
- Chief Financial Officer of the International Consortium Financing Entity
- Independent External Member - Former Head of International Maritime Organization (IMO)
- Independent External Member - Senior Megaproject Governance Expert (non-aligned nation)
- Regional Governor of Andalusia (Spain) - representative of local stakeholder interests
- Regional Governor of Tanger-Tetouan-Al Hoceima (Morocco) - representative of local stakeholder interests
- Secretary General of the Strait of Gibraltar Joint Coordination Center (non-voting advisor)

**Decision Rights:** Approve all strategic decisions including: budgets exceeding €50 million; changes to project scope, timeline exceeding 6 months, or governance structure; appointment/removal of the neutral third-party consortium leadership; approval of phase-gate milestones; ratification of bilateral treaty amendments; authorization of contingency reserve drawdowns exceeding €250 million; and any decisions affecting cross-border sovereignty arrangements or international treaty obligations. Decisions require consensus or qualified majority (2/3 of voting members including at least one representative from each sovereign nation).

**Decision Mechanism:** Decisions are made by qualified majority vote requiring at least two-thirds of voting members, with the mandatory condition that at least one representative from each sovereign nation (Spain and Morocco) votes in favor. In the event of a deadlock where consensus cannot be reached, the matter is escalated to the Bilateral Diplomatic Task Force for mediation within 30 days. If mediation fails, the dispute is referred to binding international arbitration under ICC rules. The Chair holds a casting vote only on procedural matters, not substantive decisions, to prevent unilateral dominance.

**Meeting Cadence:** Quarterly formal meetings (minimum 4 per year), with additional extraordinary sessions convened within 14 days if triggered by any of the following: a risk event exceeding €500 million in potential impact; a governance dispute between Spain and Morocco; a critical phase-gate decision; or a request from the Project Management Office for strategic escalation. Pre-meeting briefing packages distributed 21 days in advance.

**Typical Agenda Items:**

- Review of quarterly financial performance against the €40 billion budget envelope and contingency reserve status
- Approval of phase-gate milestones for functional-subsystem transitions (pillars/buoyancy → rail → sealing/pressurization)
- Cross-border diplomatic alignment update and bilateral treaty compliance status
- Review of major risk register updates and mitigation strategy effectiveness
- Approval of major procurement contracts exceeding €50 million threshold
- Investor confidence briefing and tranche-based financing disbursement authorization
- Review of IMO transboundary environmental assessment progress
- Strategic risk oversight: geopolitical, financial sustainability, and governance alignment
- Review of independent external audit findings and ethics compliance reports

**Escalation Path:** Unresolved strategic disputes between Spain and Morocco that cannot be resolved by the Steering Committee are escalated to the Bilateral Diplomatic Task Force for mediation. If mediation fails within 30 days, the matter is referred to binding ICC arbitration. Financial disputes exceeding the €40 billion envelope or requiring additional sovereign capital commitments are escalated to the respective national parliaments. Technical disputes regarding the unprecedented hybrid floating-pillar architecture are escalated to the Technical Advisory Group for independent validation before returning to the Steering Committee for final decision.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** A dedicated operational management body is essential to coordinate the day-to-day execution of a 20-year, €40 billion construction program involving thousands of personnel, multiple functional subsystems, offshore platforms, and cross-border logistics. The project's functional-subsystem phasing approach requires continuous operational coordination between pillar/buoyancy, rail infrastructure, and sealing/pressurization workstreams. Without a centralized PMO, operational decisions would bottleneck at the strategic level, and the complex interdependencies between construction deployment, subsea logistics, workforce management, and environmental compliance would create coordination failures.

**Responsibilities:**

- Manage day-to-day execution of all construction activities across the three functional-subsystem phases
- Operationalize the functional-subsystem phasing strategy with 4-5 year phase cycles
- Coordinate offshore floating platform operations, fabrication yard activities, and subsea logistics
- Manage operational risks below the €50 million strategic threshold
- Oversee the 8,000-12,000 personnel workforce including rotational and permanent staff management
- Coordinate with the neutral third-party engineering consortium on technical implementation
- Manage weather window scheduling and seasonal construction restrictions
- Maintain the master project schedule with CPM methodology and Monte Carlo simulation updates
- Implement automated budget escalation triggers at 5%, 10%, and 15% utilization thresholds
- Coordinate subsea logistics including material delivery, transport corridors, and offshore staging
- Manage interface coordination with existing surface rail networks on both Spanish and Moroccan sides
- Oversee the deployment and operation of subsea structural surveillance systems

**Initial Setup Actions:**

- Establish the PMO organizational structure with dedicated leads for each functional subsystem (pillars/buoyancy, rail, sealing/pressurization)
- Recruit a Project Director and Deputy Project Director with megaproject offshore construction experience
- Develop the detailed CPM master schedule with phase-gate milestones and inter-phase buffers
- Set up the automated budget tracking and escalation trigger system across all cost centers
- Establish communication protocols and reporting lines to the Steering Committee, Technical Advisory Group, and Risk Management Committee
- Create the operational risk register with defined thresholds for escalation to strategic bodies
- Establish coordination protocols with the neutral third-party engineering consortium
- Set up the knowledge management system for institutional knowledge preservation across the 20-year horizon

**Membership:**

- Project Director (reports to the Steering Committee Chair)
- Deputy Project Director
- Phase 1 Lead (Pillars and Buoyancy Systems)
- Phase 2 Lead (Rail Infrastructure)
- Phase 3 Lead (Sealing, Pressurization, and Commissioning)
- Head of Subsea Logistics and Supply Chain
- Head of Offshore Workforce Management
- Head of Construction Deployment and Offshore Platforms
- Head of Environmental Compliance and Permitting
- Head of Finance and Budget Control
- Head of Quality Assurance and Inspection
- Head of Health, Safety, and Environment (HSE)
- Head of Technical Surveillance and Monitoring Systems
- Bilateral Coordination Manager (Spain-Morocco interface)
- Risk Manager (reporting line to Risk Management Committee)

**Decision Rights:** Make all operational decisions with financial authority up to €50 million per contract or expenditure, including procurement of materials, services, and equipment; manage workforce deployment and rotational schedules; approve weather-dependent construction scheduling adjustments; authorize operational risk mitigation actions below the €50 million threshold; manage day-to-day subsea logistics and supply chain operations; and implement phase-gate validation procedures. Decisions exceeding €50 million or affecting project scope/timeline by more than 6 months must be escalated to the Project Steering Committee.

**Decision Mechanism:** Operational decisions are made by the relevant Phase Lead or functional head within their delegated authority, with consultation from affected workstreams. Decisions requiring cross-functional input are resolved through the PMO weekly coordination meeting, chaired by the Project Director. In case of disagreement between functional leads, the Project Director makes the final call within 7 days. If the decision involves cross-border implications or exceeds operational authority, it is escalated to the Steering Committee within 48 hours.

**Meeting Cadence:** Weekly coordination meetings (all functional leads), monthly executive review meetings (PMO leadership and key stakeholders), and quarterly strategic reviews with the Steering Committee. Ad-hoc meetings convened within 48 hours for critical operational issues including weather emergencies, supply chain disruptions, or safety incidents.

**Typical Agenda Items:**

- Weekly construction progress update across all three functional subsystems
- Offshore platform operational status and weather window utilization
- Subsea logistics and material delivery status from fabrication yards
- Workforce headcount, turnover rates, and retention metrics
- Budget utilization tracking against automated escalation triggers
- Operational risk register updates and mitigation action status
- Environmental compliance monitoring including cetacean disturbance levels
- Phase-gate readiness assessment and validation testing results
- Interface coordination updates with surface rail networks
- Subsea structural surveillance system performance and anomaly reports
- Supply chain resilience assessment and alternative supplier status

**Escalation Path:** Operational issues exceeding €50 million financial authority or affecting project scope/timeline by more than 6 months are escalated to the Project Steering Committee. Technical disputes regarding the hybrid floating-pillar architecture or buoyancy engineering are escalated to the Technical Advisory Group for independent validation. Operational risks exceeding the defined risk appetite are escalated to the Risk Management Committee. Environmental compliance breaches or threshold exceedances are escalated to the Environmental Oversight Board, which has binding authority to halt construction.
### 3. Technical Advisory Group (TAG)

**Rationale for Inclusion:** The unprecedented nature of this project — a hybrid floating-pillar submerged tunnel at 100 meters below sea level with no existing precedent — demands independent technical validation that cannot be provided by the project's own engineering teams. The interaction between buoyant tunnel segments, vertical pillar members, and hydrodynamic lift at extreme depth creates complex force dynamics that cannot be fully validated through existing models. An independent Technical Advisory Group with external deep-sea engineering expertise is essential to validate the hybrid floating-pillar architecture, review buoyancy engineering designs, assess rail systems integration under pressurized conditions, and provide impartial technical assurance to both the Steering Committee and PMO.

**Responsibilities:**

- Provide independent technical validation of the hybrid floating-pillar architecture at 100-meter depth
- Review and approve scaled physical model testing results (1:50 scale) and finite element analysis
- Validate buoyancy engineering designs including variable-ballast systems and depth control mechanisms
- Assess rail systems integration within the sealed pressurized corridor under 10 atmospheres of external pressure
- Review hydrodynamic load mitigation strategies and their interaction with pillar architecture
- Validate geotechnical anchoring methodology and seismic loading case designs
- Provide independent assessment of corrosion and durability management systems
- Review subsea structural surveillance system design and detection sensitivity specifications
- Validate the fully instrumented prototype segment before mass production approval
- Provide technical opinions on design modifications or unforeseen engineering challenges
- Assess the technical adequacy of climate change adaptation measures (sea level rise, storm intensity)
- Review and certify the 20-year lifecycle cost analysis and maintenance strategy

**Initial Setup Actions:**

- Recruit independent external members with proven expertise in deep-sea marine engineering, buoyancy systems, and pressurized enclosure design
- Establish the Terms of Reference defining the TAG's independent authority to challenge project engineering decisions
- Define the technical review scope including mandatory review gates for prototype testing, model validation, and design certification
- Establish protocols for the TAG to commission independent supplementary testing or analysis at project expense
- Create the technical review schedule aligned with phase-gate milestones and prototype testing timelines
- Establish the relationship between the TAG and the neutral third-party engineering consortium to prevent conflicts of interest
- Set up secure data sharing protocols for accessing sensitive geotechnical, oceanographic, and structural data

**Membership:**

- Chair - Independent Deep-Sea Structural Engineering Expert (external, non-project-affiliated)
- Deep-Sea Marine Engineering Specialist (external, 20+ years offshore experience)
- Buoyancy and Hydrodynamics Expert (external, specialized in submerged structures)
- Pressurized Enclosure and Rail Systems Engineer (external, high-pressure systems expertise)
- Geotechnical and Seismic Engineering Specialist (external, Azores-Gibraltar fault zone experience)
- Corrosion and Materials Science Expert (external, marine environment specialization)
- Structural Health Monitoring and Surveillance Systems Expert (external)
- Climate Adaptation and Oceanographic Projection Specialist (external)
- Representative of the Neutral Third-Party Engineering Consortium (non-voting, technical advisor)
- Head of PMO Technical Division (non-voting, internal liaison)

**Decision Rights:** The TAG has binding authority to approve, conditionally approve, or reject technical designs and engineering decisions related to: the hybrid floating-pillar architecture; buoyancy engineering systems; rail systems integration within the pressurized corridor; geotechnical anchoring methodology; hydrodynamic load mitigation strategies; corrosion protection systems; and subsea structural surveillance system specifications. The TAG can mandate design modifications, require additional testing, or halt technical progress until concerns are resolved. The TAG does not approve financial or strategic decisions, which remain with the Steering Committee and PMO.

**Decision Mechanism:** Technical decisions are made by consensus where possible. In the event of a technical disagreement, the TAG Chair facilitates resolution through independent technical analysis. If consensus cannot be reached within 30 days, the TAG votes by simple majority. In case of a tie, the matter is escalated to the Project Steering Committee with the TAG's technical opinion attached. The TAG maintains the right to commission independent supplementary analysis at project expense when internal data is insufficient for validation.

**Meeting Cadence:** Monthly technical review meetings during active design and construction phases; bi-monthly meetings during operational phases. Additional extraordinary sessions convened within 7 days for critical technical decisions including prototype validation, design modifications, or unforeseen engineering challenges. Pre-meeting technical briefing packages distributed 14 days in advance.

**Typical Agenda Items:**

- Review of 1:50 scale physical model testing results under simulated Gibraltar Strait current conditions
- Validation of hybrid floating-pillar force dynamics at 100-meter depth including buoyancy-pillar interaction
- Assessment of variable-ballast buoyancy system reliability and fail-safe mechanisms
- Review of sealed pressurized rail corridor integrity under 10 atmospheres external hydrostatic pressure
- Validation of geotechnical anchoring methodology against site-specific seismic loading cases
- Review of hydrodynamic load mitigation effectiveness and tunnel profile optimization
- Assessment of multi-layer corrosion protection system performance under accelerated life-cycle testing
- Review of subsea structural surveillance system detection sensitivity and data accuracy
- Validation of fully instrumented prototype segment deployment results
- Assessment of climate change adaptation measures including sea level rise and storm intensity projections
- Review of 20-year lifecycle cost analysis and maintenance strategy technical adequacy

**Escalation Path:** Technical disagreements between the TAG and the neutral third-party engineering consortium that cannot be resolved are escalated to the Project Steering Committee with the TAG's technical opinion attached. If the Steering Committee disagrees with the TAG's technical assessment, the matter is referred to an independent international panel of deep-sea engineering experts for final adjudication. Technical findings indicating imminent structural risk are escalated immediately to the Steering Committee and PMO with authority to halt construction pending resolution.
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** The €40 billion budget envelope, cross-border nature involving two sovereign nations, and the identified corruption risks — including bribery in procurement contracts for buoyant concrete and marine-grade steel, nepotism in consortium leadership selection, conflicts of interest within the neutral engineering firm, kickbacks in offshore platform construction, and trading of diplomatic favors in permitting — create an exceptionally high-risk environment for ethical breaches. A dedicated Ethics & Compliance Committee is essential to proactively prevent, detect, and address corruption, ensure compliance with international anti-corruption standards, and maintain the integrity of governance decisions across both jurisdictions.

**Responsibilities:**

- Establish and enforce the project's code of ethics and anti-corruption policies across all governance bodies and personnel
- Oversee compliance with international anti-corruption regulations including OECD Convention and FCPA standards
- Monitor and audit procurement processes for buoyant concrete, marine-grade steel, mooring systems, and offshore platform construction contracts
- Investigate allegations of bribery, nepotism, conflicts of interest, and kickbacks in project decisions
- Ensure the neutral third-party engineering consortium maintains independence from construction contractors and material suppliers
- Oversee the integrity of the selection process for the neutral consortium leadership and key technical personnel
- Monitor cross-border permitting processes for evidence of trading diplomatic or regulatory favors
- Manage the whistleblower mechanism and anonymous reporting channels with anti-retaliation protections
- Conduct quarterly ethics audits of all project expenditures and governance decisions
- Ensure compliance with GDPR and data protection regulations for sensitive project information
- Oversee the integrity of tranche-based financing disbursements to prevent double-spending or misallocation
- Coordinate with international legal counsel specializing in transboundary infrastructure law

**Initial Setup Actions:**

- Draft and ratify the project's Code of Ethics and Anti-Corruption Policy with input from international legal counsel
- Establish the whistleblower mechanism with anonymous reporting channels and guaranteed anti-retaliation protections
- Define the mandatory independent audit threshold for all procurement contracts exceeding €50 million
- Recruit independent external members with expertise in international anti-corruption law and megaproject governance
- Establish protocols for investigating conflicts of interest within the neutral third-party engineering consortium
- Create the quarterly ethics audit schedule and define audit scope covering all financial and governance activities
- Establish information barriers and conflict-of-interest disclosure requirements for all committee members and project personnel
- Set up secure document handling protocols for sensitive geotechnical and financial information to prevent misuse

**Membership:**

- Chair - Independent International Anti-Corruption Expert (external, non-project-affiliated)
- International Anti-Corruption Law Specialist (external, OECD/FCPA expertise)
- Former Senior Government Ethics Official (external, independent)
- Representative of Spanish Ministry of Finance / Anti-Fraud Office (internal, non-voting advisor)
- Representative of Moroccan Ministry of Finance / Anti-Corruption Agency (internal, non-voting advisor)
- Head of PMO (internal, reporting on procurement and expenditure compliance)
- Head of International Consortium Financing (internal, reporting on fund disbursement integrity)
- Independent External Auditor - Big Four Firm Representative (external, rotating annually)
- Whistleblower Ombudsman (external, independent, handling anonymous reports)
- Data Protection Officer (internal, ensuring GDPR compliance)

**Decision Rights:** The Ethics & Compliance Committee has authority to: halt any procurement process suspected of corruption or conflicts of interest pending investigation; mandate independent audits of any contract or expenditure; recommend removal of personnel or consortium members found to have violated ethical standards; refer criminal matters to appropriate judicial authorities in Spain, Morocco, or international jurisdictions; and require the Steering Committee to reconsider any governance decision found to be compromised by ethical violations. The Committee can issue binding compliance directives that all project personnel and contractors must follow.

**Decision Mechanism:** Investigations and compliance determinations are made by the Committee Chair in consultation with relevant members. Formal findings of ethical violations require a two-thirds majority vote of the Committee. The Committee operates independently of the Steering Committee and PMO in its investigations, with direct reporting lines to both sovereign governments and international oversight bodies. In case of a tie or deadlock, the matter is referred to the independent external auditor for a binding determination.

**Meeting Cadence:** Monthly compliance review meetings; quarterly formal ethics audit sessions; ad-hoc sessions convened within 48 hours for whistleblower reports or suspected corruption incidents. Annual comprehensive ethics review report submitted to the Steering Committee and both sovereign governments.

**Typical Agenda Items:**

- Review of quarterly ethics audit findings across all procurement contracts and expenditure categories
- Investigation status update on whistleblower reports and alleged corruption incidents
- Conflict-of-interest disclosure review for neutral consortium leadership and key personnel
- Procurement compliance review for contracts exceeding €50 million threshold
- Assessment of cross-border permitting processes for evidence of diplomatic favor trading
- Review of tranche-based financing disbursement integrity and prevention of double-spending
- GDPR and data protection compliance status for sensitive project information
- Whistleblower mechanism effectiveness report and anonymous report statistics
- Anti-retaliation protection status for whistleblowers and reporting personnel
- Update on international anti-corruption regulation changes affecting project compliance
- Review of independent external auditor findings and recommended corrective actions

**Escalation Path:** Evidence of criminal corruption is escalated immediately to the relevant judicial authorities in Spain and Morocco, as well as to the OECD Anti-Bribery Convention monitoring body. Ethical violations involving the neutral third-party engineering consortium leadership are escalated to the Project Steering Committee with authority to remove and replace the consortium. Systematic corruption findings that threaten project viability are escalated to both sovereign governments with authority to suspend the project pending investigation. The Committee reports directly to both governments and the international community through the public transparency portal.
### 5. Environmental Oversight Board

**Rationale for Inclusion:** The project crosses international waters and sensitive marine ecosystems in the Strait of Gibraltar, including cetacean migratory routes and benthic habitats. The environmental compliance strategy is one of the five critical strategic levers, and permitting delays can add years to the timeline. The project's elevated pillar configuration, offshore platform construction, and segment placement activities generate noise, sediment plumes, and physical disruption that could trigger regulatory shutdowns, fines of €50-500 million, and mandatory remediation costing €200 million-€1 billion. An independent Environmental Oversight Board with binding authority to halt construction is essential to ensure that environmental thresholds are not exceeded and that the project maintains its social license to operate across both nations and the international community.

**Responsibilities:**

- Exercise binding authority to halt construction if marine mammal disturbance thresholds are exceeded
- Oversee compliance with the IMO transboundary environmental impact assessment framework
- Monitor real-time acoustic monitoring buoy data for cetacean disturbance detection across minimum 10 locations
- Verify adherence to seasonal construction restrictions during cetacean migration periods (spring March-May, autumn September-November)
- Oversee the €200-500 million marine mitigation fund and ecosystem restoration program
- Monitor sediment plume levels, water quality parameters, and benthic habitat preservation status
- Review and approve environmental monitoring data before public disclosure through the transparency portal
- Oversee the independent environmental baseline studies covering cetacean migration, benthic habitats, and water quality
- Verify compliance with artificial reef structure deployment and ecosystem restoration milestones
- Assess the effectiveness of elevated pillar configurations in preserving benthic habitats underneath the tunnel
- Coordinate with the International Maritime Organization on environmental compliance matters
- Publish independent environmental compliance reports accessible to both governments, investors, and the public

**Initial Setup Actions:**

- Establish the Board's binding authority to halt construction through the bilateral treaty and IMO framework
- Recruit independent marine biologists, oceanographers, and environmental scientists with no project affiliation
- Define environmental threshold parameters for cetacean disturbance, sediment plumes, and water quality
- Establish protocols for real-time data sharing from acoustic monitoring buoys and environmental sensors
- Create the environmental baseline study commissioning plan with 24-month field data collection timeline
- Define the marine mitigation fund disbursement criteria and oversight procedures
- Establish the public reporting framework and transparency portal integration for environmental data
- Create emergency response protocols for environmental incidents including cetacean stranding events

**Membership:**

- Chair - Independent Marine Ecosystem Expert (external, international reputation, non-project-affiliated)
- Cetacean Migration and Behavior Specialist (external, independent research institution)
- Deep-Sea Marine Ecologist (external, benthic habitat expertise)
- Oceanographer specializing in Strait of Gibraltar current dynamics and sediment transport (external)
- Environmental Lawyer specializing in international maritime environmental law (external)
- Representative of the International Maritime Organization (IMO) (non-voting advisor)
- Representative of the Spanish National Environmental Agency (internal, non-voting advisor)
- Representative of the Moroccan National Environmental Agency (internal, non-voting advisor)
- Independent Acoustic Monitoring Specialist (external, marine mammal detection technology)
- Representative of Environmental NGOs (non-voting, advisory role)

**Decision Rights:** The Environmental Oversight Board has binding authority to: halt all construction activities immediately if cetacean disturbance thresholds are exceeded; mandate seasonal construction restrictions beyond the standard migration periods if environmental conditions warrant; require modifications to construction methodology that cause excessive seabed disturbance; approve or reject environmental monitoring data before public release; and recommend penalties or remediation orders for environmental non-compliance. The Board's halt-authority is absolute and cannot be overridden by the Steering Committee or PMO without unanimous Board consent and IMO concurrence.

**Decision Mechanism:** Environmental threshold decisions are made by the Board Chair based on real-time monitoring data and established threshold parameters. For non-emergency compliance decisions, the Board votes by simple majority. In the event of a tie, the Chair casts the deciding vote. Emergency halt decisions (e.g., cetacean distress detected) can be made unilaterally by the Chair with immediate effect, followed by Board ratification within 72 hours. All decisions are documented and published through the transparency portal.

**Meeting Cadence:** Weekly environmental monitoring review meetings during construction phases; monthly formal Board sessions; quarterly public environmental compliance reports. Emergency sessions convened immediately upon detection of threshold exceedances or environmental incidents. Real-time monitoring data reviewed continuously through automated alert systems.

**Typical Agenda Items:**

- Review of real-time acoustic monitoring data from all 10+ buoy locations for cetacean disturbance detection
- Assessment of sediment plume levels and water quality parameters along the tunnel corridor
- Verification of seasonal construction restriction compliance during cetacean migration periods
- Review of benthic habitat preservation status underneath elevated pillar configurations
- Monitoring of artificial reef structure deployment progress and ecosystem establishment
- Review of marine mitigation fund disbursements and ecosystem restoration program effectiveness
- Assessment of construction methodology environmental impact including noise and vibration levels
- Review of environmental baseline study findings and updates
- Coordination with IMO on transboundary environmental compliance matters
- Publication of quarterly environmental compliance reports through the public transparency portal
- Review of any environmental incidents, near-misses, or threshold exceedances and corrective actions

**Escalation Path:** Environmental incidents exceeding the Board's authority to remediate (e.g., major cetacean mortality events, significant ecosystem damage) are escalated to the Project Steering Committee and the IMO for immediate review. Systematic environmental non-compliance patterns are escalated to the Ethics & Compliance Committee for investigation of potential regulatory violations. Environmental data suggesting fundamental design flaws (e.g., pillar configuration causing unexpected habitat destruction) are escalated to the Technical Advisory Group for design review. The Board maintains direct communication channels with both sovereign governments and the international community.
### 6. Risk Management Committee

**Rationale for Inclusion:** This project faces an extraordinary risk profile spanning 18 identified risks across technical, financial, environmental, geopolitical, operational, and supply chain domains — including the complete absence of site-specific seismic assessment near the Azores-Gibraltar fault zone, missing energy supply infrastructure, inadequate maritime traffic integration, and the unprecedented nature of the hybrid floating-pillar architecture at 100m depth. The interconnected nature of these risks (governance delays compound financial exposure, technical failures trigger cost overruns, financial constraints limit technical and governance solutions) demands a dedicated enterprise risk management body that transcends individual functional areas and provides holistic risk oversight to all governance bodies.

**Responsibilities:**

- Maintain and update the comprehensive enterprise risk register covering all 18 identified risks and emerging risks
- Conduct quantitative risk assessments including Monte Carlo simulations for cost and schedule impacts
- Monitor the interconnected risk landscape and identify cascading risk scenarios across governance, technical, financial, and environmental domains
- Oversee the €4-6 billion contingency reserve allocation and automated escalation trigger system
- Coordinate risk mitigation actions across all functional subsystems and governance bodies
- Assess the effectiveness of risk mitigation strategies including seismic mitigation, climate adaptation, and flooding protocols
- Monitor currency exchange rate risk between EUR and MAD and the effectiveness of hedging programs
- Track geopolitical risk including changes in government, diplomatic tensions, and treaty compliance
- Oversee the 12-month operational reserve fund and funding cliff prevention strategies
- Coordinate the comprehensive risk assessment for the unprecedented hybrid floating-pillar architecture
- Monitor supply chain resilience risks including single-point-of-failure at centralized mega-hub
- Assess long-term sustainability risks including technological obsolescence and maintenance cost escalation over 20 years

**Initial Setup Actions:**

- Establish the comprehensive enterprise risk register with all 18 identified risks, quantified impacts, and likelihood assessments
- Define the risk appetite statement approved by the Project Steering Committee
- Set up the automated risk escalation trigger system linked to the PMO budget tracking and contingency reserve
- Define risk interconnectivity mapping showing cascading scenarios across governance, technical, financial, and environmental domains
- Establish the Monte Carlo simulation schedule for cost and schedule risk modeling
- Create the risk mitigation tracking system with assigned owners, timelines, and effectiveness metrics
- Define the currency hedging program monitoring framework for EUR/MAD exposure
- Establish protocols for emerging risk identification and assessment

**Membership:**

- Chair - Independent Enterprise Risk Management Expert (external, megaproject risk specialization)
- Chief Risk Officer (internal, reporting to both PMO and Steering Committee)
- Financial Risk Specialist (internal/external, currency, funding continuity, and cost escalation expertise)
- Technical Risk Specialist (internal/external, hybrid floating-pillar and buoyancy engineering risk)
- Geopolitical Risk Specialist (external, cross-border governance and diplomatic risk)
- Environmental Risk Specialist (external, climate change and marine ecosystem risk)
- Supply Chain Risk Specialist (internal/external, logistics and single-point-of-failure risk)
- Insurance and Actuarial Specialist (external, catastrophic risk modeling)
- Head of PMO (internal, operational risk reporting)
- Head of Finance and Budget Control (internal, financial risk reporting)
- Representative of International Consortium Financing (internal, funding continuity risk)

**Decision Rights:** The Risk Management Committee has authority to: mandate risk mitigation actions across all functional subsystems; require additional contingency reserve allocation for specific risk categories; recommend project phase-gate hold decisions if risk levels exceed the approved risk appetite; mandate additional insurance coverage or hedging instruments; and require the PMO to modify construction schedules or methodologies based on risk assessment findings. The Committee can escalate risk findings to the Steering Committee with recommendations for strategic decisions including project scope modification or timeline adjustment.

**Decision Mechanism:** Risk assessments are conducted using quantitative models (Monte Carlo simulation, expected monetary value analysis) supplemented by expert judgment. Risk mitigation priorities are set by consensus, with the Committee Chair breaking ties. When risk interconnectivity creates cascading scenarios that exceed the Committee's mitigation capacity, the matter is escalated to the Steering Committee with a comprehensive risk assessment report and recommended strategic response. Emergency risk situations (e.g., imminent seismic event, major supply chain disruption) can trigger immediate escalation to the Steering Committee and PMO.

**Meeting Cadence:** Bi-monthly risk review meetings; quarterly comprehensive risk assessment reports to the Steering Committee; monthly risk register updates distributed to all governance bodies. Ad-hoc sessions convened within 24 hours for emergency risk situations. Annual comprehensive risk reassessment aligned with the project's phase-gate milestones.

**Typical Agenda Items:**

- Enterprise risk register update including new emerging risks and changes to existing risk assessments
- Monte Carlo simulation results for cost and schedule risk with updated probability distributions
- Assessment of seismic and geotechnic risk including Azores-Gibraltar fault zone monitoring data
- Review of contingency reserve utilization against automated escalation triggers (5%, 10%, 15%)
- Currency exchange rate risk assessment (EUR/MAD) and hedging program effectiveness
- Supply chain resilience assessment including single-point-of-failure analysis and alternative supplier status
- Geopolitical risk update including government changes, diplomatic tensions, and treaty compliance
- Technical risk assessment for hybrid floating-pillar architecture including prototype testing results
- Climate change adaptation progress including sea level rise and storm intensity projection updates
- Maritime traffic integration risk assessment including collision probability and current deflection analysis
- Long-term sustainability risk assessment including technological obsolescence and maintenance cost escalation
- Funding continuity risk assessment including tranche-based financing cliff prevention
- Flooding and water intrusion risk assessment including hull integrity monitoring system status

**Escalation Path:** Risk events exceeding the approved risk appetite or requiring strategic-level decisions (e.g., project scope modification, timeline adjustment, additional sovereign capital) are escalated to the Project Steering Committee. Technical risks requiring independent validation are escalated to the Technical Advisory Group. Financial risks requiring contingency reserve drawdowns exceeding €250 million are escalated to the Steering Committee for approval. Environmental risks exceeding established thresholds are escalated to the Environmental Oversight Board. Geopolitical risks requiring diplomatic intervention are escalated to the Bilateral Diplomatic Task Force. The Committee maintains a direct emergency escalation channel to the Steering Committee Chair for imminent catastrophic risks.