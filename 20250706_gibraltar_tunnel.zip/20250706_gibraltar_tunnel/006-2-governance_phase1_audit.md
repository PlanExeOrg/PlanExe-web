
## Audit - Corruption Risks

- Bribery of regulatory officials in Spain or Morocco to expedite permit approvals or overlook non-compliance issues.
- Kickbacks from construction companies or suppliers in exchange for being awarded contracts.
- Conflicts of interest involving project personnel with financial ties to companies bidding for contracts.
- Misuse of confidential project information for personal gain or to benefit favored contractors.
- Nepotism in hiring practices, favoring unqualified relatives or friends for key project positions.

## Audit - Misallocation Risks

- Inflated invoices from contractors or suppliers, with the excess funds diverted for personal use.
- Double billing for services or materials, with the same expenses claimed multiple times.
- Misuse of project funds for unauthorized expenses, such as personal travel or entertainment.
- Inefficient allocation of resources, leading to delays and cost overruns.
- Poor record-keeping and documentation, making it difficult to track project expenses and identify potential fraud.

## Audit - Procedures

- Conduct regular internal audits of project finances and contracts, at least quarterly, with a focus on high-value transactions and potential conflicts of interest. Responsibility: Internal Audit Department.
- Engage an independent external auditor to conduct an annual audit of the project's financial statements and compliance with relevant regulations. Responsibility: Audit Committee.
- Implement a whistleblower mechanism that allows employees and stakeholders to report suspected fraud or corruption anonymously. Responsibility: Ethics Officer.
- Establish clear contract review thresholds, requiring multiple levels of approval for contracts exceeding a certain value. Responsibility: Procurement Department.
- Conduct periodic compliance checks to ensure adherence to environmental regulations and ethical guidelines. Responsibility: Compliance Officer.

## Audit - Transparency Measures

- Publish a project progress dashboard online, updated monthly, showing key milestones, budget expenditures, and risk assessments.
- Publish minutes of key decision-making meetings of the binational authority overseeing the project.
- Establish a publicly accessible register of all contracts awarded, including the names of the contractors, the value of the contracts, and the selection criteria used.
- Implement a whistleblower protection policy that ensures the confidentiality and protection of individuals who report suspected wrongdoing.
- Make relevant project policies and reports, such as environmental impact assessments and risk management plans, available to the public online.