## Suggestion 1 - Fehmarn Belt Fixed Link

The Fehmarn Belt Fixed Link is an 18-kilometer immersed tunnel connecting Denmark and Germany beneath the Fehmarn Belt in the Baltic Sea. The project includes a four-lane motorway and a double-track railway. The project's objectives are to reduce travel time between Scandinavia and continental Europe, enhance trade, and promote regional integration. The project is expected to be completed around 2029, with a budget of approximately €7.4 billion.

### Success Metrics

Reduced travel time between Denmark and Germany by approximately 2 hours for rail and 1 hour for road.
Increased freight capacity between Scandinavia and Central Europe.
Adherence to the project budget of €7.4 billion (though subject to potential revisions).
Completion of construction by the target date of 2029.
Compliance with stringent environmental regulations in the Baltic Sea.

### Risks and Challenges Faced

Geotechnical challenges due to complex seabed conditions: Overcome by extensive geological surveys and ground improvement techniques.
Environmental concerns regarding the impact on marine life: Mitigated through comprehensive environmental impact assessments and the implementation of mitigation measures such as creating artificial reefs.
Delays due to permit approvals and legal challenges: Addressed through proactive engagement with regulatory bodies and stakeholders, and robust legal defense.
Cross-border coordination between Danish and German authorities: Managed through a binational project organization with clear roles and responsibilities.

### Where to Find More Information

Official project website: [https://www.femern.com/](https://www.femern.com/)
Ramboll's project page: [https://ramboll.com/projects/rfm/fehmarnbelt-fixed-link](https://ramboll.com/projects/rfm/fehmarnbelt-fixed-link)
Documentary: [https://www.youtube.com/watch?v=lx9-judJgJ4](https://www.youtube.com/watch?v=lx9-judJgJ4)

### Actionable Steps

Contact Femern A/S (the project owner) through their website for general inquiries.
Reach out to Ramboll and Arup (engineering consultants) for technical insights.
Connect with project managers via LinkedIn for specific operational details.

### Rationale for Suggestion

The Fehmarn Belt Fixed Link is highly relevant due to its similar nature as a large-scale immersed tunnel project in a marine environment. It shares similar challenges related to geotechnical conditions, environmental impact, cross-border coordination, and funding. While geographically distant, the project's advanced stage and comprehensive documentation provide valuable insights into risk management, construction techniques, and stakeholder engagement. The Fehmarn Belt project also uses immersed tunnel technology, similar to the proposed Spain-Morocco tunnel.
## Suggestion 2 - Hong Kong-Zhuhai-Macau Bridge (HZMB)

The Hong Kong-Zhuhai-Macau Bridge (HZMB) is a 55-kilometer bridge-tunnel system consisting of a series of bridges and one 6.7-kilometer immersed tunnel, that connects Hong Kong, Zhuhai, and Macau. Its objectives were to improve transportation links, stimulate economic growth, and enhance regional connectivity in the Pearl River Delta. The project was completed in 2018 with a budget of approximately $20 billion USD.

### Success Metrics

Reduced travel time between Hong Kong, Zhuhai, and Macau from 3 hours to approximately 30 minutes.
Increased traffic flow and economic activity in the Pearl River Delta region.
Successful integration of bridge and tunnel sections.
Adherence to the project budget of $20 billion USD (though subject to scrutiny regarding cost overruns).
Implementation of advanced traffic management and safety systems.

### Risks and Challenges Faced

Technical complexity of integrating bridge and tunnel sections: Addressed through advanced engineering design and construction techniques.
Environmental concerns related to marine ecology: Mitigated through extensive environmental impact assessments and the implementation of mitigation measures.
Coordination between three different administrative regions (Hong Kong, Zhuhai, Macau): Managed through a joint project authority with representatives from each region.
Reclamation of land for artificial islands: Overcome by advanced land reclamation techniques and environmental protection measures.

### Where to Find More Information

Official project website (in Chinese): [http://www.hzmb.hk/](http://www.hzmb.hk/)
Wikipedia: [https://en.wikipedia.org/wiki/Hong_Kong%E2%80%93Zhuhai%E2%80%93Macau_Bridge](https://en.wikipedia.org/wiki/Hong_Kong%E2%80%93Zhuhai%E2%80%93Macau_Bridge)
Documentary: [https://www.youtube.com/watch?v=lbU-R4-qD_E](https://www.youtube.com/watch?v=lbU-R4-qD_E)

### Actionable Steps

Contact the Hong Kong Highways Department for information on the project's management and construction.
Reach out to engineering firms involved in the project for technical insights.
Consult academic publications and research papers for detailed analysis of the project's challenges and outcomes.

### Rationale for Suggestion

The HZMB is relevant due to its scale, complexity, and the integration of both bridge and tunnel elements. It provides valuable lessons in managing large-scale infrastructure projects involving multiple jurisdictions, addressing environmental concerns, and overcoming technical challenges in marine construction. While geographically distant and culturally different, the HZMB's experience in managing a multi-billion dollar budget and coordinating diverse stakeholders is highly applicable. The HZMB also includes an immersed tunnel section, providing relevant experience in this specific technology.
## Suggestion 3 - Channel Tunnel (Chunnel)

The Channel Tunnel, also known as the 'Chunnel', is a 50.5 km (31.4 mi) undersea rail tunnel linking Folkestone, Kent, in the United Kingdom, with Coquelles, Pas-de-Calais, near Calais in northern France. It is the only fixed link between the island of Great Britain and the European mainland. At its lowest point, it is 75 m (250 ft) below the sea bed and 115 m (380 ft) below sea level. The project's objectives were to provide a fixed transport link between the UK and France, improve trade and travel, and foster closer economic and social ties. The project was completed in 1994.

### Success Metrics

Established a fixed transport link between the UK and France.
Reduced travel time between London and Paris.
Increased trade and tourism between the UK and continental Europe.
Successful operation of high-speed rail services (Eurostar).
Demonstrated the feasibility of long undersea tunnels.

### Risks and Challenges Faced

Geological challenges during tunneling: Overcome by advanced tunnel boring machines and ground stabilization techniques.
Political and economic uncertainties: Managed through a binational treaty and private financing.
Safety concerns related to fire and security: Addressed through comprehensive safety systems and emergency response plans.
Coordination between British and French authorities: Managed through a binational project organization.

### Where to Find More Information

Official project website: [https://www.eurotunnel.com/](https://www.eurotunnel.com/)
Wikipedia: [https://en.wikipedia.org/wiki/Channel_Tunnel](https://en.wikipedia.org/wiki/Channel_Tunnel)
Engineering case study: [https://www.ice.org.uk/what-is-civil-engineering/what-do-civil-engineers-do/channel-tunnel](https://www.ice.org.uk/what-is-civil-engineering/what-do-civil-engineers-do/channel-tunnel)

### Actionable Steps

Contact Eurotunnel for information on the tunnel's operation and maintenance.
Consult historical archives and engineering publications for details on the project's construction and challenges.
Reach out to engineering firms involved in the project for technical insights.

### Rationale for Suggestion

The Channel Tunnel is a classic example of a large-scale undersea tunnel project that faced significant technical, political, and financial challenges. Its success in establishing a fixed link between two countries, managing geological risks, and coordinating international efforts provides valuable lessons for the Spain-Morocco tunnel project. Although the Channel Tunnel was constructed using tunnel boring machines rather than immersed tunnel technology, the challenges of cross-border collaboration, risk management, and long-term operation are highly relevant.

## Summary

Based on the provided project details, which describe a large-scale, high-risk, transoceanic submerged tunnel project between Spain and Morocco, the following real-world projects are recommended as references. These projects offer insights into funding, construction, risk mitigation, and international collaboration, all crucial for the success of the proposed tunnel.