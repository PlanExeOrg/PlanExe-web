# Purpose

**Purpose:** business

**Purpose Detailed:** Large-scale infrastructure construction and transportation initiative involving the engineering and deployment of buoyant concrete tunnels anchored 100 meters below sea level to enable high-speed rail connectivity between two nations. This is a massive governmental/societal infrastructure project with significant economic, commercial, and public welfare implications.

**Topic:** 20-year, €40 billion transoceanic submerged tunnel infrastructure project connecting Spain and Morocco for high-speed rail traffic

# Domain

**Primary domain:** Marine Engineering

**Secondary domains:** Transportation Engineering, Structural Engineering, Geotechnical Engineering

**Rationale:** Marine Engineering is the primary discipline because the project's core success criterion — constructing a submerged tunnel at 100 meters below sea level across the Strait of Gibraltar — is fundamentally a marine environment construction challenge. Transportation Engineering, while relevant for the high-speed rail component, addresses a subordinate aspect of the system rather than the overarching marine construction problem that defines the project.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Marine Engineering | 5 | 5 | outcome | The submerged tunnel at 100m below sea level between Spain and Morocco is fundamentally a marine environment construction challenge. |
| Geotechnical Engineering | 5 | 5 | method | Pillar anchoring at 100m depth into the Strait of Gibraltar seabed requires deep understanding of subsurface geology, soil mechanics, and foundation design. |
| Offshore Engineering | 5 | 5 | method | Buoyant concrete tunnels anchored at controlled depth are offshore structures requiring specialized offshore design, installation, and mooring techniques. |
| Materials Engineering | 4 | 5 | method | Buoyant concrete and specialized marine-grade materials are core to the tunnel's construction and long-term submersion durability. |
| Transportation Engineering | 4 | 4 | outcome | The tunnel is specifically engineered for high-speed rail traffic, making rail systems design central to the project. |
| Structural Engineering | 4 | 4 | method | Buoyant concrete tunnel design and pillar-supported anchoring require specialized structural analysis and design expertise. |
| Coastal Engineering | 4 | 4 | method | Coastal hydrodynamics, wave forces, and sediment transport directly affect the pillar-supported structure and shoreline connection points. |
| Naval Architecture | 4 | 4 | method | The buoyant submerged tunnels require naval architectural principles for stability, buoyancy control, and mooring system design at 100m depth. |
| Environmental Engineering | 4 | 3 | constraint | A transoceanic tunnel crossing international waters demands extensive environmental impact assessments and marine ecosystem compliance. |

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** This plan is unequivocally physical. It involves the construction of a massive submerged tunnel system 100 meters below sea level across the Strait of Gibraltar, connecting Spain and Morocco. The plan requires: (1) physical construction of buoyant concrete tunnels and pillar-supported anchoring structures in a deep marine environment; (2) acquisition of enormous quantities of specialized materials (buoyant concrete, marine-grade steel, mooring systems); (3) physical labor from thousands of engineers, marine workers, and construction personnel on-site; (4) heavy equipment deployment and installation in open ocean conditions; (5) geotechnical drilling and foundation work into the seabed; (6) physical testing of the tunnel system under real-world marine conditions including hydrodynamic forces, pressure, and corrosion; (7) extensive transportation of materials and personnel across international waters; and (8) environmental assessments requiring on-site marine ecosystem research. No aspect of this plan can be executed digitally — every critical phase demands physical presence, physical resources, and real-world construction activity.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Must span or be situated within the Strait of Gibraltar
- Must connect Spain and Morocco across international waters
- Must support construction and anchoring at 100 meters below sea level
- Must accommodate buoyant concrete tunnel segment fabrication, transport, and submersion
- Must support pillar-supported structural foundations on the seabed
- Must enable high-speed rail traffic through the submerged corridor
- Must account for sensitive marine ecosystems in the Strait of Gibraltar
- Must allow cross-border coordination between two sovereign nations
- Must provide coastal staging areas for fabrication, logistics, and workforce deployment
- Must be geologically suitable for deep-sea pillar anchoring at 100m depth

## Location 1
Spain/Morocco (International Waters)

Strait of Gibraltar, between Tarifa (Spain) and Tangier (Morocco)

Strait of Gibraltar, approximately 14 km wide at narrowest point, depth ranging from 300m to 900m, with tunnel corridor at 100m below sea level

**Rationale**: The Strait of Gibraltar is the only viable crossing point between Spain and Morocco, representing the narrowest span of the Atlantic Ocean between Europe and Africa. At its narrowest (~14 km), it provides the shortest feasible tunnel route while deep enough waters accommodate the required 100m submersion depth. The strait's geology—featuring a seabed of clay, sand, and weathered bedrock—is suitable for pillar anchoring, and its position on the major Europe-Africa maritime corridor makes it the strategic centerpiece of this transoceanic infrastructure project.

## Location 2
Spain

Southern Coast, Andalusia region (Tarifa/Algeciras area)

Coastal zone near Tarifa and Algeciras, Province of Cádiz, Andalusia, Spain

**Rationale**: The southern Spanish coast near Tarifa and Algeciras provides the optimal staging area for tunnel segment fabrication, dry-dock construction facilities, and workforce deployment on the European side. This region offers existing port infrastructure, proximity to the Strait of Gibraltar's narrowest crossing point, well-developed road and rail networks connecting to Spain's high-speed rail system, and established industrial zones suitable for large-scale construction operations. The area's existing maritime infrastructure reduces the need for building ancillary facilities from scratch.

## Location 3
Morocco

Northern Coast, Tanger-Tetouan-Al Hoceima region (Tangier area)

Coastal zone near Tangier-Med port, Tanger-Tetouan-Al Hoceima region, Morocco

**Rationale**: The northern Moroccan coast near Tangier provides the counterpart staging and portal location for the tunnel's Moroccan terminus. Tangier-Med is one of Africa's largest and most modern ports, offering world-class logistics and fabrication capacity. The region has available industrial land for construction facilities, existing transportation infrastructure connecting to Morocco's rail network, and a strategic position at the western entrance of the Mediterranean—making it the ideal launch point for tunnel segments heading eastward across the Strait. Morocco's growing infrastructure investment capacity and favorable geographic position further support its role as a critical construction hub.

## Location Summary
The plan explicitly requires physical locations spanning the Strait of Gibraltar between Spain and Morocco for the construction of a pillar-supported transoceanic submerged tunnel at 100 meters below sea level. The three identified locations are: (1) the Strait of Gibraltar itself—the primary tunnel corridor connecting the two nations at its narrowest ~14 km span; (2) the southern Spanish coast near Tarifa/Algeciras—the European-side fabrication, staging, and portal hub leveraging existing port and rail infrastructure; and (3) the northern Moroccan coast near Tangier—the Moroccan-side counterpart staging and portal hub anchored by the modern Tangier-Med port facilities. Together, these three locations form the complete physical footprint required for this €40 billion, 20-year infrastructure initiative, covering the tunnel route itself and both coastal construction and operational endpoints.

# Currency Strategy

This plan involves money.

## Currencies

- **EUR:** Spain is a Eurozone member and the project is explicitly denominated in euros (€40 billion). EUR serves as the primary currency for consolidated budgeting, reporting, and the majority of procurement and financing activities.
- **MAD:** Morocco's official currency (Moroccan Dirham) is required for local transactions on the Moroccan side, including labor, local materials, permitting fees, and coastal staging operations near Tangier.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting and reporting across the entire 20-year project lifecycle, as the project is denominated in euros. MAD will be used for local Moroccan transactions. Exchange rate risk between EUR and MAD must be actively managed through hedging instruments (e.g., forward contracts or currency swaps) to protect the €40 billion budget envelope from cross-border currency fluctuations. International payments and financing should leverage cards or banking facilities with minimal foreign transaction fees.

# Identify Risks


## Risk 1 - Regulatory & Permitting
Cross-border governance misalignment between Spain and Morocco could cause severe permitting delays. The chosen neutral third-party consortium model requires diplomatic negotiation to establish legal frameworks, and disagreements over jurisdiction, regulatory standards, or dispute resolution mechanisms could stall project initiation. Additionally, the transboundary environmental impact assessment through the International Maritime Organization (IMO) could take five or more years to negotiate, during which political administrations may shift priorities.

**Impact:** A 2–5 year delay in permitting and governance establishment could push the project start beyond optimal weather windows and inflate total costs by an estimated €2–5 billion due to extended pre-construction overhead, inflation, and financing carry costs. Investor confidence may erode during prolonged uncertainty.

**Likelihood:** High

**Severity:** High

**Action:** Establish a dedicated bilateral diplomatic task force with pre-negotiated framework agreements before formal project launch. Engage the IMO early with a pre-agreed timeline and fallback arbitration mechanism. Retain international legal counsel specializing in transboundary infrastructure to accelerate treaty drafting.

## Risk 2 - Regulatory & Permitting
Environmental permitting across two sovereign jurisdictions with potentially conflicting marine protection standards could create duplicative review processes. Even with a unified IMO framework, national-level environmental agencies in Spain and Morocco may impose additional requirements, particularly regarding sensitive benthic habitats in the Strait of Gibraltar. Environmental organizations could file legal challenges at any stage.

**Impact:** Environmental litigation or additional national-level permitting requirements could add 1–3 years to the timeline and incur €500 million–€1.5 billion in additional compliance costs, including redesigned tunnel segments or modified pillar configurations to meet stricter habitat protection standards.

**Likelihood:** Medium

**Severity:** High

**Action:** Proactively engage environmental NGOs and local communities in the design phase. Incorporate elevated pillar configurations that preserve benthic habitats as a design feature rather than a retrofit. Commission independent environmental baseline studies early to establish defensible ecological benchmarks.

## Risk 3 - Technical
The hybrid floating-pillar architecture chosen under the Builder's Foundation strategy is unprecedented at this scale and depth. At 100 meters below sea level, the interaction between buoyant tunnel segments, vertical pillar members, and hydrodynamic lift creates complex force dynamics that cannot be fully validated through existing models or small-scale testing. The pillar-tunnel interface must simultaneously manage vertical buoyancy loads, lateral current forces, and dynamic storm loading—all while maintaining precise rail alignment.

**Impact:** Structural miscalculations could lead to tunnel segment misalignment, excessive pillar loading, or uncontrolled depth variation during extreme weather. A single structural failure could necessitate replacement of entire tunnel segments at an estimated cost of €500 million–€2 billion per incident, with 6–18 months of schedule delay for redesign and reconstruction.

**Likelihood:** Medium

**Severity:** High

**Action:** Invest in a comprehensive scaled physical model testing program in deep-water basins before full-scale deployment. Conduct finite element analysis validated against real-world oceanographic data from the Strait of Gibraltar. Build a full-scale prototype segment and instrument it extensively before committing to mass production.

## Risk 4 - Technical
Buoyancy engineering at 100-meter depth presents extreme challenges. The variable-ballast system chosen to maintain precise depth must function reliably for 20+ years in a corrosive saline environment with limited access. Mechanical failure of ballast systems could cause the tunnel to ascend beyond its design depth (risking collision with surface shipping) or descend and contact the seabed (risking structural damage). Active ballast systems add mechanical complexity and failure points that passive designs avoid.

**Impact:** Complete ballast system failure could require emergency intervention costing €200–800 million per tunnel section, with potential loss of the section entirely. Partial failure causing depth variance of several meters could compromise rail operations and safety, requiring service suspension and repairs costing €50–200 million per incident.

**Likelihood:** Medium

**Severity:** High

**Action:** Design redundant ballast systems with passive fail-safe mechanisms that default to a safe neutral buoyancy state. Implement real-time depth monitoring with automated ballast correction. Conduct accelerated life-cycle testing of ballast components under simulated 20-year saline exposure conditions.

## Risk 5 - Technical
Corrosion and durability over a 20-year submerged lifespan represents a fundamental challenge. The aggressive saline environment at 100 meters depth, combined with the complex geometry of hybrid floating-pillar joints and articulated flexible connections, creates numerous potential pathways for saline ingress. Polymer encapsulation can be breached during installation or degraded by UV exposure during pre-construction storage; sacrificial anodes require periodic replacement in inaccessible locations; active cathodic protection systems depend on reliable power generation at depth.

**Impact:** Unmanaged corrosion could reduce the structural lifespan below the 20-year design horizon, requiring premature rehabilitation costing €3–8 billion across the tunnel system. Cathodic protection system failure could accelerate degradation by 3–5x, potentially necessitating full tunnel replacement within 15 years.

**Likelihood:** High

**Severity:** High

**Action:** Implement a multi-layer corrosion protection strategy combining polymer encapsulation with sacrificial anodes and active cathodic protection as redundant systems. Design accessible inspection and maintenance ports at regular intervals. Establish a dedicated corrosion monitoring program with predictive analytics to schedule interventions before critical degradation occurs.

## Risk 6 - Technical
Rail systems integration within a pressurized, submerged environment introduces unprecedented engineering challenges. The sealed pressurized rail corridor must maintain terrestrial-grade track precision while subjected to external hydrostatic pressure of approximately 10 atmospheres at 100 meters depth. Thermal expansion from pressurization and temperature variations, combined with marine-induced vibration, creates complex stress distributions that could compromise track geometry over time. Transition points between surface rail and the submerged section represent critical failure points for passenger safety and operational continuity.

**Impact:** Track geometry deviations could require speed restrictions reducing the tunnel's commercial viability, potentially cutting projected revenue by 20–40%. Pressurization system failures could endanger passenger safety, requiring evacuation and potentially causing structural damage. Transition zone failures could isolate sections of the tunnel, with remediation costs of €100–500 million per incident.

**Likelihood:** Medium

**Severity:** High

**Action:** Develop and test a full-scale pressurized rail prototype under simulated deep-sea conditions before tunnel construction. Design modular track sections with active compensation systems for thermal and pressure-induced deformation. Implement redundant pressurization systems with emergency depressurization protocols.

## Risk 7 - Financial
The €40 billion budget envelope faces significant exposure to cost escalation over a 20-year construction horizon. Material costs for buoyant concrete, marine-grade steel, and specialized mooring systems are subject to commodity price volatility. Labor costs in the offshore construction sector are projected to rise significantly. Additionally, the neutral third-party consortium governance model may introduce administrative overhead and decision-making delays that extend the timeline and increase carrying costs.

**Impact:** A 10–15% cost overrun would represent €4–6 billion in additional funding requirements. If financing is structured through private equity with strict return timelines, cost overruns could trigger covenant breaches, investor withdrawal, or forced restructuring. Extended timelines compound financing costs—each additional year of construction could add €300–600 million in interest and overhead.

**Likelihood:** High

**Severity:** High

**Action:** Establish a €4–6 billion contingency reserve within the initial budget. Use fixed-price contracts with penalty clauses for major material suppliers. Implement rigorous cost tracking with quarterly reviews and automated escalation triggers. Structure financing with flexible disbursement tranches that can accommodate timeline adjustments without triggering default provisions.

## Risk 8 - Financial
Currency exchange rate risk between EUR (primary project currency) and MAD (Moroccan local currency) could erode the budget envelope over 20 years. Morocco's local costs—including labor, permits, local materials, and coastal staging operations near Tangier—are denominated in MAD. Significant MAD depreciation against EUR would increase the effective cost of Moroccan-side expenditures, while MAD appreciation would increase costs for Spanish-side entities paying MAD-denominated contracts.

**Impact:** Unhedged currency fluctuations of 10–20% over the project lifecycle could translate to €200 million–€800 million in additional costs, depending on the direction and magnitude of exchange rate movements. This is particularly acute during the construction phase when Moroccan-side expenditures peak.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Implement a comprehensive currency hedging program using forward contracts and currency swaps covering at least 70% of projected MAD-denominated expenditures. Establish a dedicated treasury function to monitor and manage FX exposure monthly. Consider negotiating some Moroccan-side contracts in EUR to transfer currency risk to counterparties.

## Risk 9 - Financial
The international consortium financing model, while enabling capital deployment, introduces risks related to investor confidence and funding continuity. Tranche-based disbursements tied to geological and marine milestones create funding cliffs—if a milestone is delayed or disputed, subsequent funding may be withheld, creating a cascading cash flow crisis. Political shifts in either Spain or Morocco could alter government guarantees or development bank commitments.

**Impact:** A funding gap of even 6–12 months could halt construction entirely, costing €500 million–€1 billion in idle workforce, equipment demobilization, and remobilization costs. Loss of government bond guarantees could increase the cost of capital by 200–400 basis points, adding €1–3 billion in total interest payments over the project lifecycle.

**Likelihood:** Medium

**Severity:** High

**Action:** Diversify funding sources across sovereign bonds, development bank facilities, and private capital to avoid single-point-of-failure dependencies. Establish a reserve fund covering at least 12 months of operational costs. Negotiate milestone definitions with sufficient specificity and dispute resolution mechanisms to prevent funding withholding over technical disagreements.

## Risk 10 - Environmental
Construction activities in the Strait of Gibraltar will disturb sensitive marine ecosystems, including migratory routes for cetaceans (whales and dolphins), benthic habitats on the seabed, and water quality during dredging and pillar installation. The elevated pillar configuration chosen to minimize seabed contact still requires significant offshore platform construction and segment placement activities that generate noise, sediment plumes, and physical disruption.

**Impact:** Environmental damage could trigger regulatory shutdowns, fines of €50–500 million, and mandatory remediation costing €200 million–€1 billion. Reputational damage could erode public support and political backing, potentially leading to project cancellation. Long-term ecosystem damage could affect fisheries and tourism industries in the region.

**Likelihood:** Medium

**Severity:** High

**Action:** Conduct comprehensive marine ecosystem baseline studies before construction begins. Implement seasonal construction restrictions during cetacean migration periods. Deploy real-time acoustic monitoring to detect and mitigate marine mammal disturbance. Establish an independent environmental oversight board with authority to halt construction if thresholds are exceeded.

## Risk 11 - Social
Offshore workforce resilience over a 20-year construction period presents profound human capital challenges. The isolated offshore environment at 100 meters depth, combined with the project's duration, creates extreme retention difficulties. Even with permanent residential platforms or generous equity incentives, specialized workers may leave due to burnout, family considerations, or better opportunities. High turnover forces repeated training cycles and erodes institutional knowledge precisely when it is most needed during critical installation phases.

**Impact:** Workforce turnover exceeding 20% annually could add €500 million–€1.5 billion in repeated recruitment and training costs over the project lifecycle. Loss of institutional knowledge during critical installation phases could increase error rates by 15–30%, leading to rework, delays, and safety incidents. Safety incident frequency could increase by 25–50% during periods of high turnover.

**Likelihood:** High

**Severity:** Medium

**Action:** Implement a tiered retention strategy combining competitive compensation, family accommodation options, career progression pathways, and equity participation. Establish a knowledge management system that captures and institutionalizes expertise independent of individual workers. Partner with maritime training institutions to create a continuous pipeline of qualified personnel.

## Risk 12 - Operational
Construction deployment using offshore floating platforms positioned directly above installation sites requires years of permitting and infrastructure setup before the first segment can be placed. These permanent offshore platforms are exposed to extreme weather conditions, including storms that are common in the Strait of Gibraltar. A single severe weather event during installation could damage platforms, displace tunnel segments, or injure personnel.

**Impact:** Platform damage from a severe storm could cost €200–800 million to repair and cause 3–6 months of construction delay. Displaced or damaged tunnel segments could cost €100–500 million to recover and replace. Personnel safety incidents could result in project shutdowns, legal liability, and reputational damage.

**Likelihood:** Medium

**Severity:** High

**Action:** Design offshore platforms to withstand 100-year storm events with redundant structural systems. Develop detailed weather monitoring and evacuation protocols. Pre-position emergency response equipment and vessels. Construct platforms during favorable weather windows with accelerated timelines to minimize exposure during vulnerable periods.

## Risk 13 - Supply Chain
The supply chain for this project depends on enormous quantities of specialized materials—buoyant concrete, marine-grade steel, mooring systems, and corrosion protection materials—delivered to remote offshore locations across international waters. A single mega-hub in southern Spain, while efficient, creates a catastrophic single point of failure. A port strike, facility fire, or logistics disruption at the hub could halt all construction simultaneously.

**Impact:** A supply chain disruption lasting 2–4 months could cost €1–3 billion in idle costs, contract penalties, and accelerated costs to recover the schedule. Material shortages could force design compromises that reduce structural integrity or operational capability. The concentration of materials at a single hub makes the project vulnerable to terrorism, piracy, or geopolitical disruption.

**Likelihood:** Medium

**Severity:** High

**Action:** Establish a distributed supply chain with at least two regional fabrication yards (one in Spain, one in Morocco) to provide redundancy. Maintain a 3–6 month strategic inventory of critical materials at offshore staging areas. Develop pre-qualified alternative suppliers for all critical material categories. Implement blockchain-based supply chain tracking for real-time visibility.

## Risk 14 - Supply Chain
The transportation of massive buoyant concrete tunnel segments from fabrication yards to offshore installation sites across international waters presents unique logistical challenges. Towing operations at 100-meter depth are subject to weather windows, ocean currents, and maritime traffic in one of the world's busiest shipping lanes. The Strait of Gibraltar's narrow width and heavy shipping traffic create congestion and collision risks during segment transport.

**Impact:** Transport delays could cascade through the entire construction schedule, with each week of delay costing €10–30 million in idle workforce and equipment costs. A collision or loss of a tunnel segment during transport could result in total loss of the segment (€50–200 million) and potential environmental disaster. Maritime traffic delays in the Strait could add weeks to transport schedules.

**Likelihood:** Medium

**Severity:** High

**Action:** Develop dedicated maritime transport corridors with temporary traffic management agreements with maritime authorities. Use purpose-built semi-submersible transport vessels with enhanced stability and positioning systems. Schedule transport during low-traffic periods and favorable weather windows. Maintain insurance coverage for total loss during transit.

## Risk 15 - Security
The tunnel infrastructure spanning international waters between two sovereign nations presents a high-value target for physical security threats, including sabotage, terrorism, or unauthorized access. The submerged structure at 100 meters depth is difficult to monitor and protect. Additionally, the subsea structural surveillance systems relying on fiber-optic sensors, acoustic modems, and underwater communication infrastructure are vulnerable to cyber attacks that could disable monitoring or feed false data.

**Impact:** A successful sabotage event could cause catastrophic structural failure with potential loss of life, environmental disaster, and total project loss valued at €40 billion. A cyber attack on surveillance systems could go undetected for weeks or months, allowing structural degradation to progress unchecked. Security breach remediation could cost €500 million–€2 billion and require complete system replacement.

**Likelihood:** Low

**Severity:** High

**Action:** Implement a multi-layered physical security system including underwater barriers, surveillance drones, and naval patrols. Deploy encrypted, air-gapped communication networks for critical structural monitoring systems. Conduct regular penetration testing and cybersecurity audits. Establish a joint Spain-Morocco security coordination center for the tunnel corridor.

## Risk 16 - Geopolitical
The project spans two sovereign nations with distinct political systems, legal frameworks, and strategic interests. Changes in government in either Spain or Morocco could fundamentally alter the political commitment to the project, funding guarantees, or governance structure. Diplomatic tensions between the two nations—whether related to migration, territorial disputes, or broader geopolitical dynamics—could escalate to the point of project suspension or cancellation.

**Impact:** A change in government or diplomatic crisis could result in project suspension lasting 1–3 years, costing €2–6 billion in carrying costs, contract termination penalties, and remobilization expenses. In the worst case, project cancellation could result in total loss of invested capital and significant reputational damage to both nations and all participating entities.

**Likelihood:** Medium

**Severity:** High

**Action:** Embed the project in binding international treaties that survive changes in government. Establish a neutral dispute resolution mechanism with enforcement authority. Diversify political support by demonstrating economic benefits to constituencies in both nations. Maintain continuous diplomatic engagement at multiple levels of government.

## Risk 17 - Operational
Integration with existing surface rail networks on both the Spanish and Moroccan sides presents significant interface challenges. The tunnel must connect to existing high-speed rail infrastructure at Tarifa/Algeciras and Tangier, requiring modifications to existing stations, signaling systems, and power supply. The transition between surface rail and the submerged pressurized corridor introduces complex engineering and operational challenges.

**Impact:** Interface failures could limit the tunnel's throughput capacity, reducing projected revenue by 15–30%. Signaling system incompatibilities could force operational speed restrictions. Station modifications could cost €200–800 million per terminal if not properly coordinated with existing infrastructure operators.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish joint interface teams with existing rail operators from the project's inception. Conduct comprehensive gauge, signaling, and power system compatibility studies. Design modular transition infrastructure that can be adapted to existing systems without requiring complete replacement.

## Risk 18 - Long-term Sustainability
The 20-year operational lifespan of the tunnel requires sustained maintenance funding, technological relevance, and structural integrity over an extremely long horizon. Maintenance costs for a submerged structure at 100 meters depth are orders of magnitude higher than terrestrial infrastructure. Technological obsolescence—particularly in rail systems, surveillance technology, and corrosion protection—could render the tunnel functionally outdated before its structural lifespan expires.

**Impact:** Maintenance costs over 20 years could reach €3–8 billion, potentially exceeding initial construction cost projections if not properly budgeted. Technological obsolescence could require major system upgrades costing €1–4 billion. Failure to budget for long-term maintenance could lead to progressive structural degradation and eventual safety-critical failures.

**Likelihood:** High

**Severity:** Medium

**Action:** Establish a dedicated maintenance trust fund capitalized at project inception, funded by a percentage of operational revenues. Design the tunnel with modular systems that can be upgraded without complete replacement. Commission a 20-year lifecycle cost analysis during the design phase to inform budget allocation.

## Risk summary
The most critical risks that could jeopardize this €40 billion, 20-year transoceanic submerged tunnel project are: (1) **Cross-border governance and regulatory delays**—the high likelihood of permitting delays, diplomatic misalignment, and environmental litigation could add 2–5 years and €2–5 billion in costs, potentially stalling the project before construction even begins. (2) **Technical uncertainty of the hybrid floating-pillar architecture**—the unprecedented nature of this design at 100-meter depth creates medium-probability but high-severity structural failure risks that could cost billions and cause catastrophic safety incidents. (3) **Financial sustainability over 20 years**—cost escalation, currency risk, and funding continuity threats could erode the €40 billion budget envelope, with each additional year of construction adding €300–600 million in carrying costs. These three risks are interconnected: governance delays compound financial exposure, technical failures trigger cost overruns, and financial constraints limit the ability to address technical and governance challenges. The Builder's Foundation strategy mitigates some risks through its balanced approach, but the unprecedented scale and complexity of this project demand continuous risk monitoring and adaptive management throughout the 20-year horizon.

# Make Assumptions


## Question 1 - How is the €40 billion budget allocated across the 20-year construction phases, and what contingency reserves are established to address cost escalation, currency fluctuation, and funding continuity risks?

**Assumptions:** Assumption: The budget is allocated with approximately 10-15% contingency reserve (€4-6 billion) distributed across functional-subsystem phases, with the remaining 85-90% divided proportionally among pillar architecture, construction deployment, rail systems, environmental compliance, and operational readiness based on the Builder's Foundation strategy. Currency hedging covers at least 70% of projected MAD-denominated expenditures, and a dedicated reserve fund covers 12 months of operational costs to buffer against funding cliffs from tranche-based disbursements.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluation of budget allocation adequacy, contingency reserve sufficiency, and multi-currency cost escalation risk management across the 20-year horizon.
Details: A 10-15% contingency (€4-6 billion) aligns with industry benchmarks for megaprojects of this complexity and directly addresses the identified Risk 7 (cost escalation) and Risk 8 (currency fluctuation). The tranche-based financing model tied to geological and marine milestones creates natural disbursement checkpoints but introduces funding cliff risks (Risk 9) that the 12-month reserve fund mitigates. However, if cost overruns exceed 15%, the contingency may be insufficient, potentially triggering covenant breaches with private equity investors. The EUR/MAD hedging strategy covering 70% of Moroccan expenditures is prudent but leaves 30% exposed to exchange rate volatility, which could add €200-800 million in costs over 20 years. Recommendation: Establish automated escalation triggers at 5%, 10%, and 15% budget utilization to activate contingency protocols before reserves are exhausted.

## Question 2 - What are the key milestones and phase durations for the functional-subsystem phasing approach (pillars and buoyancy → rail infrastructure → sealing and pressurization), and how are weather-dependent construction windows and validation periods accounted for within the 20-year timeline?

**Assumptions:** Assumption: The 20-year timeline is divided into approximately four to five year phases for each functional subsystem, with weather-dependent construction windows accounting for 20-30% of annual working time in the Strait of Gibraltar due to seasonal storm activity. Buffer periods of 6-12 months are allocated between phases for validation testing, course correction, and stakeholder review, with the first phase (pillar and buoyancy deployment) consuming approximately 6-7 years, rail infrastructure 5-6 years, and sealing/pressurization plus commissioning 4-5 years, leaving 2-3 years of schedule contingency.

**Assessments:** Title: Timeline & Milestones Assessment
Description: Evaluation of phase duration feasibility, weather window dependencies, and milestone validation checkpoint adequacy within the 20-year constraint envelope.
Details: The functional-subsystem phasing approach provides natural risk checkpoints that align with the Builder's Foundation strategy's 'deliberate equilibrium' philosophy. However, weather windows in the Strait of Gibraltar are constrained by Atlantic storm patterns, particularly in winter months, which can reduce effective construction time by 30-40% annually. If Phase 1 (pillars and buoyancy) exceeds its 6-7 year estimate due to installation failures or environmental permitting delays, the cascading effect on subsequent phases could compress the rail infrastructure and sealing phases beyond feasible limits. The 6-12 month inter-phase buffers are adequate for validation but may prove insufficient if structural testing reveals fundamental design issues (Risk 3). Recommendation: Develop a critical path method (CPM) schedule with Monte Carlo simulation to quantify schedule risk, and establish go/no-go decision gates at each phase transition with predefined criteria.

## Question 3 - What is the required workforce composition, specialized skill profile, and offshore accommodation strategy to sustain a stable, highly skilled workforce across the 20-year isolated offshore construction environment?

**Assumptions:** Assumption: The project requires approximately 8,000-12,000 personnel at peak construction, with a tiered rotational fly-in-fly-out model supplemented by permanent offshore residential platforms offering family accommodation and comprehensive amenities. A dedicated training pipeline through maritime institutions in both Spain and Morocco ensures continuous supply of qualified personnel, while equity-sharing and long-term performance bonuses incentivize retention. Workforce turnover is targeted below 15% annually through competitive compensation, career progression pathways, and knowledge management systems that institutionalize expertise independent of individual workers.

**Assessments:** Title: Resources & Personnel Assessment
Description: Evaluation of workforce sizing adequacy, retention strategy feasibility, and specialized skill continuity risks across the 20-year offshore construction period.
Details: The 8,000-12,000 peak workforce estimate is consistent with comparable megaprojects (e.g., Channel Tunnel, Crossrail) but must account for the unique challenges of 100-meter depth offshore work. The tiered rotational model with permanent platforms addresses Risk 11 (workforce resilience), but permanent housing creates massive fixed-cost burdens during reduced-activity periods, conflicting with International Consortium Financing constraints. The equity-sharing incentive (Decision 13) aligns worker interests with project success but reduces investor returns, creating tension with the private consortium governance model. Without effective retention, turnover exceeding 20% annually could add €500 million-€1.5 billion in recruitment and training costs and increase safety incident rates by 25-50%. Recommendation: Implement a dynamic workforce model that scales personnel based on phase-specific demands, with a core permanent workforce of 3,000-4,000 supplemented by rotational specialists during peak installation periods.

## Question 4 - How is the neutral third-party consortium governance structure established, and what legal frameworks govern cross-border permitting, dispute resolution, and regulatory compliance between Spain and Morocco throughout the 20-year project lifecycle?

**Assumptions:** Assumption: The neutral third-party consortium is established through a comprehensive bilateral treaty ratified by both the Spanish and Moroccan parliaments, with technical decision-making authority vested in the consortium led by a neutral engineering firm, while both governments retain financial oversight and veto rights on major budget decisions. Dispute resolution operates through binding international arbitration under ICC rules with enforcement mechanisms, and a dedicated bilateral diplomatic task force with pre-negotiated framework agreements accelerates permitting. The transboundary environmental impact assessment is negotiated through the IMO with a pre-agreed timeline and fallback arbitration mechanism to prevent the 2-5 year permitting delays identified in Risk 1.

**Assessments:** Title: Governance & Regulations Assessment
Description: Evaluation of governance structure viability, legal framework robustness, and dispute resolution effectiveness for a €40 billion project spanning two sovereign nations.
Details: The neutral third-party consortium model (Decision 3) elegantly resolves the cross-border governance challenge but faces significant establishment risks. The bilateral treaty requires ratification by both parliaments, which could be delayed by political shifts (Risk 16) or diplomatic tensions. The pre-negotiated framework agreements and dedicated task force mitigate some delay risk, but the IMO environmental assessment negotiation alone could exceed five years (Risk 1). The ICC arbitration mechanism provides a structured dispute resolution pathway, but enforcement across sovereign borders remains challenging if one party refuses to comply. Investor confidence (Risk 9) is directly tied to governance stability—any perceived governance weakness could trigger capital withdrawal. Recommendation: Establish the governance framework before project launch with binding commitments from both governments, including penalty clauses for non-compliance, and secure preliminary IMO engagement within the first 12 months to front-load the environmental assessment process.

## Question 5 - What comprehensive safety protocols, emergency response systems, and risk mitigation frameworks are established to address structural failure, personnel safety, pressurization emergencies, and catastrophic event scenarios at 100 meters below sea level?

**Assumptions:** Assumption: A multi-layered safety framework is established including real-time structural monitoring with automated shutdown protocols triggered by micro-fracture detection or depth deviation beyond tolerance limits, dedicated emergency response vessels on 24/7 standby within 30 minutes of the tunnel corridor, pressurized corridor evacuation systems with redundant pathways and emergency depressurization protocols, and a comprehensive insurance program covering structural failure (€500 million-€2 billion per incident), environmental damage, and personnel incidents. Safety incident frequency targets are set below 0.5 incidents per 200,000 work hours, consistent with international offshore construction standards.

**Assessments:** Title: Safety & Risk Management Assessment
Description: Evaluation of safety protocol adequacy, emergency response readiness, and catastrophic risk containment for a submerged structure at 100-meter depth.
Details: The safety framework must address the unique challenges of a pressurized submerged environment where evacuation is complicated by depth, pressure, and limited access points. The automated shutdown protocols (linked to Subsea Structural Surveillance, Decision 14) are critical but depend on sensor reliability—false positives could cause unnecessary shutdowns costing €10-30 million per incident, while false negatives could allow structural degradation to progress unchecked. Emergency response at 100 meters depth is extraordinarily challenging; current saturation diving limits are approximately 300-500 meters, but sustained human presence at 100 meters requires specialized decompression protocols. The pressurization emergency risk (Risk 6) is particularly acute—failure could endanger passenger safety and cause structural damage. The insurance program must cover total loss scenarios, but insurers may demand rigorous proof of structural validation before offering coverage. Recommendation: Conduct full-scale emergency simulation exercises annually, establish a joint Spain-Morocco emergency response coordination center, and require third-party safety certification before each phase transition.

## Question 6 - What environmental baseline studies, mitigation measures, and ongoing monitoring programs are required to address marine ecosystem disruption—including cetacean migration routes, benthic habitats, and water quality—during construction and the 20-year operational lifespan?

**Assumptions:** Assumption: Comprehensive marine ecosystem baseline studies are conducted 2-3 years before construction begins, covering cetacean migration patterns, benthic habitat mapping, water quality parameters, and sediment dynamics across the Strait of Gibraltar corridor. Seasonal construction restrictions are enforced during cetacean migration periods (typically spring and autumn), with real-time acoustic monitoring deployed to detect and mitigate marine mammal disturbance. The elevated pillar configuration chosen under the Builder's Foundation strategy preserves benthic habitats underneath the tunnel, and an independent environmental oversight board with authority to halt construction if thresholds are exceeded monitors compliance throughout the project lifecycle. An ecosystem restoration program creates artificial reef structures along the tunnel corridor to offset residual habitat disruption.

**Assessments:** Title: Environmental Impact Assessment
Description: Evaluation of environmental baseline study adequacy, mitigation measure effectiveness, and long-term ecosystem protection strategies for sensitive marine environments in the Strait of Gibraltar.
Details: The environmental strategy of elevated pillars integrating habitat preservation into the core design (Decision 4) is elegant but does not eliminate all environmental impact. Offshore platform construction, segment placement, and pillar installation still generate noise, sediment plumes, and physical disruption that affect cetacean migration (Risk 10). The seasonal construction restrictions during migration periods could reduce the already limited weather windows by an additional 15-20%, compressing the construction schedule. The independent environmental oversight board provides a critical check but could also become a bottleneck if its authority to halt construction is exercised frequently. The artificial reef restoration program is beneficial but takes years to establish functional ecosystems, meaning the offset is not immediate. Environmental litigation remains a significant risk (Risk 2) even with proactive measures, as environmental organizations may challenge the adequacy of mitigation. Recommendation: Commission baseline studies immediately upon project approval, establish pre-construction environmental covenants with both governments, and create a marine mitigation fund of €200-500 million to finance ongoing monitoring and restoration.

## Question 7 - What stakeholder engagement strategy addresses the diverse interests of both sovereign governments, international investors, local communities in Tarifa and Tangier, environmental organizations, maritime authorities, and the general public across the 20-year project horizon?

**Assumptions:** Assumption: A multi-tiered stakeholder engagement framework is established including bilateral government coordination committees meeting quarterly, quarterly investor briefings with transparent financial reporting, community liaison offices in both Tarifa and Tangier providing local employment information and addressing concerns, ongoing structured dialogue with environmental NGOs through advisory panels, and a public transparency portal providing real-time project updates, construction progress, and environmental monitoring data. Dedicated communications teams in both Spain and Morocco manage public perception, and community benefit agreements guarantee local hiring quotas and infrastructure improvements in exchange for community support.

**Assessments:** Title: Stakeholder Involvement Assessment
Description: Evaluation of stakeholder engagement strategy comprehensiveness, stakeholder alignment effectiveness, and communication transparency for a project with diverse and sometimes conflicting interests.
Details: The stakeholder landscape for this project is exceptionally complex, spanning two sovereign governments, international financial institutions, local communities, environmental organizations, maritime authorities, and the general public. The community liaison offices in Tarifa and Tangier are essential for maintaining local support, but community expectations may exceed what the project can deliver, particularly regarding employment quotas and infrastructure improvements. The public transparency portal is a strong trust-building mechanism but also creates reputational risk if negative developments are publicly disclosed before mitigation plans are ready. Environmental NGO advisory panels provide early warning of opposition but can also slow decision-making. Investor confidence (Risk 9) is directly tied to stakeholder sentiment—public opposition or political backlash could trigger funding withdrawal. The bilingual communications approach (Spanish/Arabic) is critical but requires sophisticated translation and cultural adaptation. Recommendation: Establish a stakeholder advisory council with representatives from each stakeholder group, conduct annual stakeholder satisfaction surveys, and develop crisis communication protocols for managing negative publicity.

## Question 8 - What operational systems and technology infrastructure are required to support high-speed rail traffic through the pressurized submerged tunnel, including ventilation, pressurization, structural surveillance, corrosion protection, and maintenance over the 20-year operational lifespan?

**Assumptions:** Assumption: The operational systems include a sealed pressurized rail corridor with climate-controlled track beds maintaining terrestrial-grade precision despite 10 atmospheres of external hydrostatic pressure, redundant ventilation and pressurization systems powered by offshore tidal energy generators, a dense mesh of fiber-optic acoustic sensors along the entire tunnel length for continuous structural surveillance, autonomous underwater vehicles on fixed patrol routes for periodic inspection, and a multi-layer corrosion protection strategy combining polymer encapsulation with sacrificial anodes and active cathodic protection. A dedicated maintenance trust fund capitalized at project inception covers 20-year lifecycle costs estimated at €3-8 billion, with modular system design enabling upgrades without complete replacement.

**Assessments:** Title: Operational Systems Assessment
Description: Evaluation of system architecture feasibility, technology reliability, and long-term maintenance sustainability for a pressurized submerged high-speed rail tunnel operating at 100-meter depth.
Details: The operational systems represent the most technologically demanding aspect of the project. The sealed pressurized rail corridor (Decision 7) must maintain track precision under extreme conditions—thermal expansion from pressurization, marine-induced vibration, and saltwater corrosion all threaten geometry. The pressurization system failure risk (Risk 6) is existential for passenger safety, requiring redundant systems with emergency depressurization protocols. The fiber-optic acoustic sensor mesh (Decision 14) provides continuous structural health data but requires complex waterproof splicing at extreme depths and resilient underwater communication infrastructure. The multi-layer corrosion protection strategy (Decision 11) is prudent but adds significant upfront costs and maintenance complexity—polymer encapsulation can be breached during installation, sacrificial anodes require inaccessible periodic replacement, and active cathodic protection depends on reliable power. The €3-8 billion maintenance cost estimate over 20 years is substantial and must be factored into the overall financial model. The modular design approach is wise but may introduce interface vulnerabilities. Recommendation: Invest in a full-scale pressurized rail prototype tested under simulated deep-sea conditions before tunnel construction, establish a dedicated operational technology research program, and require 20-year lifecycle cost analysis validation during the design phase.

# Distill Assumptions

- €40 billion, 20-year pillar-supported transoceanic submerged tunnel connecting Spain and Morocco at 100m depth for high-speed rail.
- 20-year timeline uses functional-subsystem phasing (pillars/buoyancy → rail → sealing), approximately 4-5 years per phase with weather windows consuming 20-30% of annual working time.
- €40 billion budget includes 10-15% contingency reserve (€4-6 billion), 12-month operational reserve fund, and currency hedging covering 70% of MAD-denominated expenditures.
- Peak construction requires 8,000-12,000 personnel using a tiered rotational fly-in-fly-out model supplemented by permanent offshore residential platforms.
- Neutral third-party consortium led by an engineering firm holds technical decision-making authority while Spain and Morocco retain financial oversight and veto rights.
- Elevated pillar configurations preserve benthic habitats; transboundary environmental assessment negotiated through the IMO with a pre-agreed timeline and fallback arbitration.
- Tranche-based financing disbursements are tied to geological and marine milestones from multilateral government bonds, public-private partnerships, and development bank funds.
- Bilateral treaty ratified by both Spanish and Moroccan parliaments establishes governance, with ICC arbitration for dispute resolution and a dedicated diplomatic task force for permitting.
- €3-8 billion maintenance trust fund capitalized at project inception covers 20-year lifecycle costs including corrosion protection, structural surveillance, and operational systems.
- Multi-layer corrosion protection combines polymer encapsulation, sacrificial anodes, and active cathodic protection powered by offshore tidal energy generators.
- Sealed pressurized rail corridor maintains terrestrial-grade track precision under 10 atmospheres of external hydrostatic pressure with redundant ventilation systems.
- Comprehensive marine ecosystem baseline studies covering cetacean migration, benthic habitats, and water quality are conducted 2-3 years before construction begins.
- Multi-tiered stakeholder engagement spans both governments, international investors, communities in Tarifa and Tangier, environmental NGOs, and the general public.
- Real-time structural surveillance via fiber-optic acoustic sensors and autonomous underwater vehicles enables automated shutdown protocols and continuous micro-fracture detection.
- Safety framework includes 24/7 emergency response vessels within 30 minutes, pressurized corridor evacuation systems, and insurance covering €500 million to €2 billion per incident.

# Review Assumptions

## Domain of the expert reviewer
Megaproject Infrastructure Planning & Risk Management

## Domain-specific considerations

- Transboundary infrastructure governance across sovereign nations
- Deep-sea structural engineering at unprecedented scale and depth
- Seismic and geotechnical risk in the Azores-Gibraltar seismic zone
- Marine ecosystem sensitivity and cetacean migration corridor impacts
- Long-term operational sustainability of pressurized submerged systems
- Currency and financing risk across EUR/MAD dual-currency operations
- Maritime traffic integration in one of the world's busiest shipping lanes
- 20-year lifecycle cost modeling and decommissioning obligations

## Issue 1 - Absence of Seismic and Detailed Geotechnical Risk Assessment
The project assumes pillar anchoring at 100m depth in the Strait of Gibraltar seabed described as 'clay, sand, and weathered bedrock,' but no detailed geotechnical survey data, seismic hazard analysis, or fault line mapping is referenced. The Strait of Gibraltar sits near the Azores-Gibraltar seismic transform fault, one of Europe's most active seismic zones. Without site-specific seismic design parameters (peak ground acceleration, soil liquefaction potential, fault rupture probability), the entire structural architecture—pillars, buoyancy systems, and tunnel segments—is built on unvalidated ground assumptions. This is a foundational gap that could invalidate all downstream engineering decisions.

**Recommendation:** Commission a comprehensive geotechnical and seismic risk assessment immediately, including deep-sea borehole sampling at multiple pillar locations, 3D seismic reflection profiling of the seabed, and probabilistic seismic hazard analysis (PSHA) calibrated to the Azores-Gibraltar fault zone. Require all pillar and tunnel designs to incorporate site-specific seismic loading cases with a minimum 2% probability of exceedance in 50 years. Establish a geotechnical validation gate before any construction mobilization.

**Sensitivity:** If seismic design is inadequate, a moderate earthquake (M5.5-6.5, 10% probability in 20 years) could cause pillar settlement or tunnel deformation requiring €3-8 billion in structural repairs and 12-24 months of reconstruction. A major event (M7.0+, 2% probability in 20 years) could cause catastrophic structural failure with total loss of tunnel segments valued at €10-20 billion. Seismic risk mitigation (deepened foundations, seismic joints) could add €500 million-€1.5 billion to initial construction costs but reduce expected annual loss by 60-80%.

## Issue 2 - Missing Energy Supply and Operational Power Infrastructure Plan
The project specifies massive energy demands—pressurized rail corridor climate control, ventilation, structural surveillance systems, active cathodic protection powered by tidal generators, buoyancy adjustment systems, and rail propulsion—but no energy supply strategy is articulated. The tunnel at 100m depth cannot connect to terrestrial power grids without submarine cables of extraordinary length and capacity. The assumption that offshore tidal energy generators can power cathodic protection is insufficient for the full operational load. No mention of energy storage, grid interconnection, backup power, or total operational energy budget. This omission could render the tunnel inoperable or force unsustainable energy costs.

**Recommendation:** Conduct a comprehensive energy audit quantifying total operational power demand (estimated 50-100 MW continuous for pressurization, ventilation, rail, surveillance, and corrosion systems). Develop a hybrid energy strategy combining submarine HVDC cable connections to both Spanish and Moroccan grids, offshore wind/tidal generation with battery storage, and diesel backup generators. Establish a dedicated energy infrastructure budget of €1-2 billion for submarine cable installation and power distribution systems. Negotiate energy supply agreements with both national grid operators before construction begins.

**Sensitivity:** Without reliable power, the tunnel cannot operate, resulting in zero revenue and €500 million-€1 billion in annual lost revenue potential. Energy cost overruns of 30-50% above projections could add €300-600 million to 20-year operational costs, reducing project ROI by 2-4 percentage points. A submarine HVDC cable failure could cause complete tunnel shutdown, costing €50-100 million per incident in lost revenue and emergency repair.

## Issue 3 - Inadequate Maritime Traffic Integration and Collision Risk Management
The Strait of Gibraltar is among the world's busiest shipping lanes, with over 100,000 vessel transits annually, including massive tankers and container ships. The project assumes tunnel segments can be towed through this congested waterway and that the submerged structure at 100m depth will not interfere with shipping. However, no detailed maritime traffic management plan, collision risk assessment, or navigational safety framework is provided. The tunnel structure itself could create current deflection effects that alter shipping lane conditions. The assumption that 'dedicated maritime transport corridors' can be established without disrupting one of the world's most critical maritime chokepoints is dangerously optimistic.

**Recommendation:** Commission a comprehensive maritime traffic impact study including computational fluid dynamics modeling of tunnel-induced current changes, collision probability analysis for the submerged structure, and development of a Temporary Traffic Management Plan (TTMP) with international maritime authorities (IMO, Strait of Gibraltar Joint Coordination Center). Install AIS (Automatic Identification System) monitoring and collision avoidance systems on the tunnel structure. Negotiate permanent shipping lane adjustments with the IMO and establish a 24/7 maritime traffic control center co-located with the tunnel surveillance system.

**Sensitivity:** A collision between a large vessel and the tunnel could cause €500 million-€2 billion in damage, potential environmental disaster (fuel spill from the vessel), and 6-12 months of repair shutdown costing €1-3 billion in lost revenue. Current deflection from the tunnel structure could increase wave heights in shipping lanes by 5-15%, potentially increasing collision risk by 10-30% and requiring costly navigational aids. Failure to secure shipping lane agreements could halt construction transport entirely, adding 6-12 months and €500 million-€1 billion in costs.

## Issue 4 - No Decommissioning and End-of-Life Plan
The project specifies a 20-year operational lifespan but provides zero detail on what happens at end-of-life. Decommissioning a submerged tunnel at 100m depth across international waters between two nations is an unprecedented engineering and legal challenge. Who bears the cost? How are materials disposed of without further marine environmental damage? What happens to the pillars in the seabed? The €3-8 billion maintenance trust fund addresses operational costs but not decommissioning. This omission creates a massive unfunded liability and potential environmental disaster at project end.

**Recommendation:** Develop a comprehensive decommissioning plan during the design phase, including environmental remediation protocols, material recovery strategies, and seabed restoration requirements. Establish a decommissioning reserve fund of €2-4 billion, capitalized at project inception and growing through operational revenues. Negotiate decommissioning obligations in the bilateral treaty and IMO framework. Conduct a full lifecycle assessment (LCA) to quantify the environmental footprint of both construction and decommissioning.

**Sensitivity:** Unplanned decommissioning costs could reach €5-15 billion depending on method (partial removal vs. in-situ abandonment). Failure to plan could result in the tunnel becoming an artificial reef with unknown ecological consequences, triggering environmental liability claims of €1-5 billion. Regulatory requirements for decommissioning could change over 20 years, potentially imposing standards not anticipated in the original design.

## Issue 5 - Rail Gauge and Systems Interoperability Gap
Spain uses the Iberian gauge (1,668mm) while Morocco uses standard gauge (1,435mm) for its rail network. The project assumes seamless high-speed rail connectivity between two nations without addressing the fundamental gauge incompatibility. Additionally, signaling systems, electrification standards (Spain: 25kV AC, Morocco: 3kV DC historically), and safety protocols differ. The project mentions 'dual-mode rail' as an option but does not commit to a solution. This is not a minor technical detail—it fundamentally determines whether the tunnel achieves its core purpose of connecting two nations by rail.

**Recommendation:** Mandate a unified gauge standard (likely standard gauge 1,435mm for high-speed compatibility) for the entire tunnel and both connecting networks. Conduct a comprehensive systems interoperability study covering gauge, signaling (ERTMS), electrification, and safety protocols. Budget €200-500 million for gauge transition infrastructure at both terminals. Require both national rail operators to commit to a unified standard before construction begins.

**Sensitivity:** Failure to resolve gauge incompatibility would require passengers to change trains at terminals, reducing the tunnel's value proposition and potentially cutting projected ridership by 30-50%, reducing revenue by €500 million-€1.5 billion annually over 20 years. Dual-gauge solutions add complexity and maintenance costs of €50-100 million per year. Signaling incompatibility could force speed restrictions reducing throughput by 20-40%.

## Issue 6 - Climate Change and Long-Term Oceanographic Projections Absent
The project is designed for a 20-year operational lifespan but makes no reference to climate change projections—sea level rise, ocean current changes, storm intensity increases, or water temperature changes—that will occur during this period. The Strait of Gibraltar is particularly vulnerable to Atlantic climate variability. Ocean current patterns may shift, storm frequency may increase, and sea levels may rise 0.3-0.6m by 2043 (IPCC projections). These changes could fundamentally alter the hydrodynamic forces acting on the tunnel, the buoyancy equilibrium, and the corrosion environment. The design assumes static oceanographic conditions over 20 years, which is scientifically indefensible.

**Recommendation:** Integrate IPCC climate projections (SSP2-4.5 and SSP5-8.5 scenarios) into the structural design, incorporating sea level rise of 0.3-0.6m, increased storm intensity of 10-20%, and potential ocean current changes into the hydrodynamic load models. Design the tunnel with adaptive buoyancy systems that can compensate for sea level changes. Budget €200-400 million for climate adaptation measures. Commission ongoing oceanographic monitoring to update design parameters every 5 years.

**Sensitivity:** Unaccounted sea level rise of 0.5m could alter the tunnel's depth profile, changing buoyancy equilibrium and pillar loading, potentially requiring structural modifications costing €1-3 billion. Increased storm intensity of 20% could increase hydrodynamic forces by 15-25%, exceeding design tolerances and risking structural damage costing €500 million-€2 billion per severe event. Without climate adaptation, the tunnel's design life could be reduced from 20 to 12-15 years, requiring premature rehabilitation costing €3-6 billion.

## Issue 7 - Water Intrusion and Catastrophic Flooding Protocols Missing
The project describes a pressurized sealed rail corridor within a submerged tunnel, but no emergency flooding protocol is articulated for the scenario where the tunnel hull is breached. At 100m depth with 10 atmospheres of external pressure, even a small breach could flood the tunnel at catastrophic rates. The project mentions 'emergency depressurization protocols' for the pressurized rail corridor but does not address the far more fundamental risk of seawater intrusion into the tunnel structure itself. With thousands of passengers in a submerged tunnel, a flooding event represents an existential safety risk.

**Recommendation:** Develop a comprehensive flooding risk management plan including: (1) redundant hull integrity monitoring with automated breach detection; (2) emergency flooding containment compartments within the tunnel design; (3) rapid-deployment flood barriers at tunnel entrances on both coasts; (4) passenger evacuation protocols for submerged conditions including specialized submersible rescue vehicles; (5) insurance coverage specifically for flooding events. Conduct full-scale flooding simulation exercises annually. Budget €100-300 million for flooding prevention and response infrastructure.

**Sensitivity:** A major flooding event could result in total loss of tunnel sections valued at €5-15 billion, potential loss of life creating unlimited liability, and permanent project cancellation. Even a minor breach requiring section isolation could cost €200-500 million in repairs and 3-6 months of partial shutdown, reducing annual revenue by 15-30%. The absence of flooding protocols could make the project uninsurable, preventing financing from being secured.

## Review conclusion
The three most critical issues threatening this €40 billion project are: (1) the complete absence of seismic and detailed geotechnical risk assessment, which could invalidate the entire structural design and expose the project to catastrophic earthquake damage costing €3-20 billion; (2) the missing energy supply infrastructure plan, without which the tunnel cannot operate, resulting in zero revenue and potential project failure; and (3) the inadequate maritime traffic integration strategy for one of the world's busiest shipping lanes, where a collision could cause €500 million-€2 billion in damage and halt construction. These three issues are interconnected—seismic events could damage energy infrastructure, and maritime incidents could disrupt energy supply logistics. The project's unprecedented scale, depth, and cross-border complexity demand that these foundational gaps be addressed before any construction begins. Additionally, the absence of decommissioning plans, rail gauge incompatibility, climate change projections, and flooding protocols represent significant secondary risks that compound the primary issues. The Builder's Foundation strategy provides a sound conceptual framework, but it is built on assumptions that lack the geotechnical, energy, and maritime specificity required for a project of this magnitude and risk profile.