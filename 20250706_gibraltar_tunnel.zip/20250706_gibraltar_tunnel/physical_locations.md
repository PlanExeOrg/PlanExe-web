This plan implies one or more physical locations.

## Requirements for physical locations

- Must span or be situated within the Strait of Gibraltar
- Must connect Spain and Morocco across international waters
- Must support construction and anchoring at 100 meters below sea level
- Must accommodate buoyant concrete tunnel segment fabrication, transport, and submersion
- Must support pillar-supported structural foundations on the seabed
- Must enable high-speed rail traffic through the submerged corridor
- Must account for sensitive marine ecosystems in the Strait of Gibraltar
- Must allow cross-border coordination between two sovereign nations
- Must provide coastal staging areas for fabrication, logistics, and workforce deployment
- Must be geologically suitable for deep-sea pillar anchoring at 100m depth

## Location 1
Spain/Morocco (International Waters)

Strait of Gibraltar, between Tarifa (Spain) and Tangier (Morocco)

Strait of Gibraltar, approximately 14 km wide at narrowest point, depth ranging from 300m to 900m, with tunnel corridor at 100m below sea level

**Rationale**: The Strait of Gibraltar is the only viable crossing point between Spain and Morocco, representing the narrowest span of the Atlantic Ocean between Europe and Africa. At its narrowest (~14 km), it provides the shortest feasible tunnel route while deep enough waters accommodate the required 100m submersion depth. The strait's geology—featuring a seabed of clay, sand, and weathered bedrock—is suitable for pillar anchoring, and its position on the major Europe-Africa maritime corridor makes it the strategic centerpiece of this transoceanic infrastructure project.

## Location 2
Spain

Southern Coast, Andalusia region (Tarifa/Algeciras area)

Coastal zone near Tarifa and Algeciras, Province of Cádiz, Andalusia, Spain

**Rationale**: The southern Spanish coast near Tarifa and Algeciras provides the optimal staging area for tunnel segment fabrication, dry-dock construction facilities, and workforce deployment on the European side. This region offers existing port infrastructure, proximity to the Strait of Gibraltar's narrowest crossing point, well-developed road and rail networks connecting to Spain's high-speed rail system, and established industrial zones suitable for large-scale construction operations. The area's existing maritime infrastructure reduces the need for building ancillary facilities from scratch.

## Location 3
Morocco

Northern Coast, Tanger-Tetouan-Al Hoceima region (Tangier area)

Coastal zone near Tangier-Med port, Tanger-Tetouan-Al Hoceima region, Morocco

**Rationale**: The northern Moroccan coast near Tangier provides the counterpart staging and portal location for the tunnel's Moroccan terminus. Tangier-Med is one of Africa's largest and most modern ports, offering world-class logistics and fabrication capacity. The region has available industrial land for construction facilities, existing transportation infrastructure connecting to Morocco's rail network, and a strategic position at the western entrance of the Mediterranean—making it the ideal launch point for tunnel segments heading eastward across the Strait. Morocco's growing infrastructure investment capacity and favorable geographic position further support its role as a critical construction hub.

## Location Summary
The plan explicitly requires physical locations spanning the Strait of Gibraltar between Spain and Morocco for the construction of a pillar-supported transoceanic submerged tunnel at 100 meters below sea level. The three identified locations are: (1) the Strait of Gibraltar itself—the primary tunnel corridor connecting the two nations at its narrowest ~14 km span; (2) the southern Spanish coast near Tarifa/Algeciras—the European-side fabrication, staging, and portal hub leveraging existing port and rail infrastructure; and (3) the northern Moroccan coast near Tangier—the Moroccan-side counterpart staging and portal hub anchored by the modern Tangier-Med port facilities. Together, these three locations form the complete physical footprint required for this €40 billion, 20-year infrastructure initiative, covering the tunnel route itself and both coastal construction and operational endpoints.