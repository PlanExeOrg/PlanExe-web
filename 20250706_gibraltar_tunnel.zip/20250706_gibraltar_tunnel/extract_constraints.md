## Positive Constraints

- Project duration: 20 years
- Budget: €40 billion
- Project type: pillar-supported transoceanic submerged tunnel infrastructure initiative
- Connects Spain and Morocco
- Structure type: submerged, buoyant concrete tunnels
- Purpose: high-speed rail traffic
- Anchored at a controlled depth of 100 meters below sea level
- Project start ASAP
