**Budget Request Exceeding PMO Financial Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee qualified majority vote requiring at least two-thirds of voting members, with the mandatory condition that at least one representative from each sovereign nation (Spain and Morocco) votes in favor
Rationale: The PMO's delegated financial authority is strictly capped at €50 million per contract or expenditure; any request exceeding this threshold directly impacts the €40 billion total capital envelope and requires strategic-level sovereign approval beyond operational management
Negative Consequences: Unauthorized spending, budget overrun, covenant breaches with private equity investors, and potential loss of tranche-based financing due to lack of strategic oversight

**Technical Deadlock on Unprecedented Hybrid Floating-Pillar Architecture Validation**
Escalation Level: Project Steering Committee
Approval Process: Technical Advisory Group (TAG) provides independent technical opinion; Steering Committee makes final decision based on TAG's binding technical assessment; if Steering Committee disagrees with TAG, referred to an independent international panel of deep-sea engineering experts for final adjudication
Rationale: The unprecedented nature of the hybrid floating-pillar architecture at 100-meter depth creates complex force dynamics that cannot be fully validated through existing models; requires independent technical validation and sovereign-level authority to mandate design modifications or halt construction
Negative Consequences: Structural miscalculations causing tunnel segment misalignment or uncontrolled depth variation, catastrophic safety incidents, €500 million-€2 billion per incident replacement costs, and 6-18 months of redesign delay per failure

**Critical Environmental Threshold Exceedance Requiring Sovereign Intervention**
Escalation Level: Project Steering Committee and International Maritime Organization (IMO)
Approval Process: Environmental Oversight Board exercises binding authority to halt construction; if incident exceeds Board's remediation authority (e.g., major cetacean mortality event), escalated to Steering Committee and IMO for immediate review; Board's halt-authority cannot be overridden without unanimous Board consent and IMO concurrence
Rationale: Major environmental incidents exceed the Board's operational authority to remediate and require sovereign diplomatic intervention and international regulatory compliance under the IMO transboundary environmental framework
Negative Consequences: Regulatory shutdown, fines of €50-500 million, mandatory remediation costing €200 million-€1 billion, severe reputational damage, loss of social license to operate, and potential project cancellation

**Evidence of Criminal Corruption or Systematic Ethical Violations**
Escalation Level: Relevant Judicial Authorities (Spain and Morocco) and Project Steering Committee
Approval Process: Ethics & Compliance Committee investigates and refers criminal matters to appropriate judicial authorities in Spain, Morocco, or international jurisdictions; Steering Committee receives recommendations to remove neutral consortium leadership or reconsider governance decisions compromised by ethical violations
Rationale: Criminal matters require judicial authority beyond the Committee's internal power; systematic corruption threatens project viability and requires sovereign-level intervention to maintain governance integrity and investor confidence
Negative Consequences: Legal penalties and criminal prosecution, project suspension lasting 1-3 years, loss of investor confidence, erosion of public support, and potential total loss of invested capital

**Unresolved Cross-Border Governance Deadlock Between Spain and Morocco**
Escalation Level: Bilateral Diplomatic Task Force and International Chamber of Commerce (ICC) Arbitration
Approval Process: Steering Committee deadlock (unable to reach consensus or qualified majority with both sovereign nations) is escalated to Bilateral Diplomatic Task Force for mediation within 30 days; if mediation fails, dispute is referred to binding international arbitration under ICC rules
Rationale: Sovereign diplomatic disputes between Spain and Morocco cannot be resolved by the Steering Committee alone; require diplomatic negotiation and binding international arbitration to prevent project stall at the midpoint where both jurisdictions must simultaneously contribute resources
Negative Consequences: Project stall of 1-3 years, €2-6 billion in carrying costs, erosion of investor confidence, potential treaty violation, and project cancellation due to diplomatic crisis

**Risk Event Exceeding Approved Risk Appetite or Requiring Major Contingency Drawdown**
Escalation Level: Project Steering Committee
Approval Process: Risk Management Committee monitors enterprise risk register and mandates mitigation actions; if risk exceeds approved risk appetite or requires contingency reserve drawdown exceeding €250 million, escalated to Steering Committee for approval of strategic decisions including project scope modification or timeline adjustment
Rationale: Risk Management Committee's authority is limited to risk mitigation within the approved risk appetite; major contingency drawdowns require strategic-level approval of the €40 billion budget envelope and sovereign capital commitments
Negative Consequences: Financial exposure exceeding €4-6 billion contingency reserve, inability to mitigate cascading interconnected risks, covenant breaches, investor withdrawal, and forced restructuring of the €40 billion financing