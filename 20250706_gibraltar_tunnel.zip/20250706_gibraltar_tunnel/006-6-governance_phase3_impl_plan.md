### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Structure Defined

### 2. Project Manager circulates Draft SteerCo ToR v0.1 for review by Senior representatives from the Spanish Ministry of Transport, Mobility and Urban Agenda and the Moroccan Ministry of Equipment, Transport, Logistics and Water.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager incorporates feedback and finalizes the Project Steering Committee ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Project Sponsor formally appoints the Project Steering Committee Chair (Senior representative from either the Spanish Ministry of Transport, Mobility and Urban Agenda or the Moroccan Ministry of Equipment, Transport, Logistics and Water).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Sponsor formally appoints Project Steering Committee members.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final SteerCo ToR v1.0
- SteerCo Chair Appointed

### 6. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- All SteerCo Members Appointed

### 7. Hold the initial Project Steering Committee kick-off meeting to review ToR, decision-making processes, and initial project plan.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- SteerCo Members Appointed
- SteerCo ToR Approved

### 8. Project Director establishes project management processes and tools for the Project Management Office (PMO).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Project Management Process Documentation
- List of Project Management Tools

**Dependencies:**

- Project Plan Approved

### 9. Project Director develops the initial project plan, budget, and schedule for the PMO.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Initial Project Plan
- Budget
- Schedule

**Dependencies:**

- Project Management Process Documentation

### 10. Project Director establishes a risk management framework for the PMO.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Risk Management Framework

**Dependencies:**

- Initial Project Plan

### 11. Project Director recruits and trains project team members for the PMO.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Project Team Members Recruited
- Training Materials

**Dependencies:**

- Risk Management Framework

### 12. Project Director schedules the initial PMO kick-off meeting.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- PMO Team Members Recruited

### 13. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- PMO Team Members Recruited
- Project Management Process Documentation

### 14. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Structure Defined

### 15. Project Manager circulates Draft TAG ToR v0.1 for review by the Chief Engineer's Office.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft TAG ToR v0.1

### 16. Project Manager incorporates feedback and finalizes the Technical Advisory Group ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Final TAG ToR v1.0

**Dependencies:**

- Feedback Summary

### 17. Project Sponsor formally appoints the Independent Expert in Submerged Tunnel Construction as the Technical Advisory Group Chair.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final TAG ToR v1.0

### 18. Technical Advisory Group Chair, in consultation with the Project Director, formally appoints Technical Advisory Group members.

**Responsible Body/Role:** Technical Advisory Group Chair

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final TAG ToR v1.0
- TAG Chair Appointed

### 19. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- All TAG Members Appointed

### 20. Hold the initial Technical Advisory Group kick-off meeting to review ToR, communication protocols, and key technical documents.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- TAG Members Appointed
- TAG ToR Approved

### 21. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Structure Defined

### 22. Project Manager circulates Draft ECC ToR v0.1 for review by Legal Counsel and Compliance Officer.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft ECC ToR v0.1

### 23. Project Manager incorporates feedback and finalizes the Ethics & Compliance Committee ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Final ECC ToR v1.0

**Dependencies:**

- Feedback Summary

### 24. Project Sponsor formally appoints the Independent Ethics Officer as the Ethics & Compliance Committee Chair.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final ECC ToR v1.0

### 25. Ethics & Compliance Committee Chair, in consultation with the Project Director, formally appoints Ethics & Compliance Committee members.

**Responsible Body/Role:** Ethics & Compliance Committee Chair

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final ECC ToR v1.0
- ECC Chair Appointed

### 26. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- All ECC Members Appointed

### 27. Hold the initial Ethics & Compliance Committee kick-off meeting to review ToR, reporting mechanisms, and conduct a risk assessment.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- ECC Members Appointed
- ECC ToR Approved

### 28. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft SEG ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Structure Defined

### 29. Project Manager circulates Draft SEG ToR v0.1 for review by the Stakeholder Engagement Manager.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SEG ToR v0.1

### 30. Project Manager incorporates feedback and finalizes the Stakeholder Engagement Group ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Final SEG ToR v1.0

**Dependencies:**

- Feedback Summary

### 31. Project Director formally appoints the Stakeholder Engagement Manager as the Stakeholder Engagement Group Chair.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SEG ToR v1.0

### 32. Stakeholder Engagement Group Chair, in consultation with the Project Director, formally appoints Stakeholder Engagement Group members.

**Responsible Body/Role:** Stakeholder Engagement Group Chair

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final SEG ToR v1.0
- SEG Chair Appointed

### 33. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- All SEG Members Appointed

### 34. Hold the initial Stakeholder Engagement Group kick-off meeting to review ToR, develop a stakeholder engagement plan, and identify key stakeholders.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- SEG Members Appointed
- SEG ToR Approved