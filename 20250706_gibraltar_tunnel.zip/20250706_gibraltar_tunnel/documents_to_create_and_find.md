# Documents to Create

## Create Document 1: Project Charter

**ID**: 74037638-6e60-448e-8954-468c39766b8b

**Description**: Formal authorization document establishing the €40 billion, 20-year transoceanic submerged tunnel project connecting Spain and Morocco at 100m depth across the Strait of Gibraltar. Defines the project purpose, measurable objectives, high-level scope, key stakeholders, Program Director authority, and initial success criteria. Establishes the Builder's Foundation strategic path as the chosen approach and provides the foundational mandate for all subsequent planning activities.

**Responsible Role Type**: Program Director & Cross-Border Governance Lead

**Primary Template**: PMI Project Charter Template

**Secondary Template**: World Bank Project Charter Framework

**Steps to Create**:

- Define project purpose and measurable objectives aligned with SMART criteria
- Identify and document key stakeholders across both sovereign nations
- Establish high-level scope including the 14 km tunnel span, 100m depth, and functional-subsystem phasing approach
- Define Program Director authority and decision-making boundaries
- Establish initial success criteria including cross-border rail service commencement by ~2046
- Secure formal sign-off from both Spanish and Moroccan government representatives

**Approval Authorities**: Spanish Ministry of Transport, Moroccan Ministry of Equipment and Transport, Bilateral Diplomatic Task Force

**Essential Information**:

- Define project purpose and measurable objectives aligned with SMART criteria: construct the world's first pillar-supported transoceanic submerged tunnel connecting Spain and Morocco at 100m depth across the Strait of Gibraltar, enabling high-speed rail connectivity over 20 years with a €40 billion budget envelope
- Establish high-level scope including the 14 km tunnel span, 100m depth, hybrid floating-pillar architecture, offshore floating platform construction, and functional-subsystem phasing (pillars/buoyancy → rail infrastructure → sealing/pressurization)
- Identify and document key stakeholders across both sovereign nations: Spanish Government (Ministry of Transport, Andalusia regional government), Moroccan Government (Ministry of Equipment and Transport, Tanger-Tetouan-Al Hoceima regional government), neutral third-party engineering consortium, international financing entity, construction workforce (8,000-12,000 personnel), and high-speed rail operators
- Define Program Director authority and decision-making boundaries, including veto rights, budget approval thresholds, and escalation pathways for cross-border disputes
- Establish initial success criteria including cross-border rail service commencement by ~2046, structural integrity confirmed across the full 14 km span at 100m depth, and all functional subsystems commissioned and validated
- Secure formal sign-off from both Spanish and Moroccan government representatives, the Bilateral Diplomatic Task Force, and international financing authorities
- Document the Builder's Foundation strategic path as the chosen approach, including hybrid floating-pillar architecture, neutral third-party consortium governance, and functional-subsystem phasing
- Identify critical dependencies: geotechnical/seismic risk assessment, bilateral treaty ratification, offshore fabrication infrastructure, workforce recruitment, prototype validation, environmental compliance framework, and international consortium financing
- Summarize high-level risks including cross-border governance misalignment, technical uncertainty of hybrid floating-pillar architecture, financial sustainability over 20 years, and absence of seismic/geotechnic data
- Establish approval authorities: Spanish Ministry of Transport, Moroccan Ministry of Equipment and Transport, and Bilateral Diplomatic Task Force

**Risks of Poor Quality**:

- Unclear scope definition leads to significant rework, scope creep, and budget overruns exceeding the €40 billion envelope
- Undefined Program Director authority causes decision paralysis during critical construction phases, particularly when cross-border disputes arise
- Missing or misaligned stakeholder identification undermines diplomatic coordination between Spain and Morocco, potentially stalling permitting and funding
- Unrealistic timeline or budget estimates in the charter erode investor confidence and may trigger covenant breaches or funding withdrawal
- Absence of clear success criteria makes it impossible to measure project progress or determine go/no-go decisions for subsequent phases
- Inadequate risk identification in the charter leaves the project unprepared for governance delays, technical failures, or financial disruptions
- Poorly defined governance structure fails to resolve cross-border disputes, leading to diplomatic crises that could cancel the project
- Missing dependencies and resource commitments result in unrealistic scheduling and resource shortages during critical construction windows

**Worst Case Scenario**: The project fails to secure formal authorization or international funding due to a poorly defined charter that lacks stakeholder alignment, clear authority structures, and realistic financial projections. Construction never commences, the €40 billion investment is never realized, and the strategic opportunity to connect Europe and Africa through subsea infrastructure is lost, with potential reputational damage to both sovereign nations and international partners.

**Best Case Scenario**: The charter provides a clear, authoritative mandate that enables swift decision-making, secures immediate buy-in from both governments and international investors, and establishes unambiguous success metrics and governance frameworks. It becomes the foundational document that accelerates permitting, unlocks tranche-based financing, and enables smooth transition from planning to execution, positioning Spain–Morocco as global leaders in cross-border infrastructure and establishing a model for future international megaprojects.

**Fallback Alternative Approaches**:

- Utilize the pre-approved PMI Project Charter Template and World Bank Project Charter Framework (as referenced in document.json) and adapt sections to the specific transoceanic tunnel context rather than creating from scratch
- Develop a simplified 'minimum viable charter' covering only the most critical elements (purpose, scope, stakeholders, authority, budget, timeline) with the understanding that detailed sections can be added during early execution phases
- Schedule a focused workshop with key stakeholders (Spanish and Moroccan government representatives, neutral consortium lead, financing entity) to collaboratively define charter requirements and draft content in a single intensive session
- Engage a technical writer or subject matter expert specializing in megaproject charters to synthesize the existing project-plan.md, strategic_decisions.md, and assumptions.md content into a cohesive charter document
- Create an interim authorization document that captures the essential mandate and authority structures, allowing project mobilization to begin while the full charter undergoes formal review and approval

## Create Document 2: Cross-Border Governance Framework

**ID**: bb320dc7-ba1e-4bcb-9292-a5fd09e0e814

**Description**: High-level governance architecture document establishing the political, administrative, and legal framework for managing the €40 billion project across two sovereign nations. Defines the neutral third-party consortium structure with technical decision-making authority, bilateral treaty ratification pathway through Spanish Cortes Generales and Moroccan Parliament, IMO engagement strategy for transboundary environmental assessment, ICC arbitration mechanisms for dispute resolution, and the diplomatic task force structure. Addresses sovereignty concerns, funding allocation mechanisms, and decision-making authority distribution between Spain and Morocco.

**Responsible Role Type**: Program Director & Cross-Border Governance Lead

**Primary Template**: Bilateral Infrastructure Treaty Framework Template

**Secondary Template**: IMO Transboundary Environmental Assessment Guidelines

**Steps to Create**:

- Analyze existing Bilateral Investment Treaties between Spain and Morocco for applicable investment protection provisions
- Define consortium legal personality and structure (treaty-based organization vs. contractual joint venture vs. special purpose vehicle)
- Draft bilateral treaty framework with binding commitments, penalty clauses, and change-of-government survival provisions
- Establish IMO engagement strategy with pre-agreed timeline and fallback ICC arbitration
- Define dispute resolution pathways and enforcement mechanisms across sovereign jurisdictions
- Assess EU law constraints (TFEU provisions) on governance structure given Spain's EU membership

**Approval Authorities**: Spanish Cortes Generales, Moroccan Parliament, International Chamber of Commerce, IMO Legal Committee

**Essential Information**:

- Define the neutral third-party consortium legal structure (treaty-based organization vs. contractual joint venture vs. special purpose vehicle) and its authority boundaries
- Specify the bilateral treaty ratification pathway through Spanish Cortes Generales and Moroccan Parliament, including change-of-government survival provisions and binding penalty clauses
- Establish the IMO engagement strategy with pre-agreed timeline for transboundary environmental assessment and fallback ICC arbitration mechanisms
- Detail the dispute resolution pathways and enforcement mechanisms across sovereign jurisdictions, including ICC arbitration rules and compliance enforcement
- Define funding allocation mechanisms and financial oversight structures, including how €40 billion capital is sourced, disbursed, and audited across both nations
- Address EU law constraints (TFEU provisions) on governance structure given Spain's EU membership and implications for cross-border infrastructure governance
- Specify decision-making authority distribution between Spain and Morocco, including veto rights on major budget decisions and technical vs. financial governance separation
- Establish the bilateral diplomatic task force structure with pre-negotiated framework agreements to accelerate permitting and resolve disputes
- Define sovereignty safeguards that protect both nations' interests while enabling efficient project execution
- Outline investor confidence mechanisms including transparent financial reporting, tranche-based disbursement triggers, and governance stability guarantees

**Risks of Poor Quality**:

- Governance misalignment between Spain and Morocco could cause severe permitting delays adding 2-5 years and €2-5 billion in costs, potentially stalling the project before construction begins
- Inadequate dispute resolution mechanisms could lead to diplomatic deadlock at the midpoint where both jurisdictions must simultaneously contribute resources, undermining investor confidence
- Missing change-of-government survival provisions could result in project suspension or cancellation if political priorities shift in either nation, costing €2-6 billion in carrying costs
- Unclear decision-making authority distribution could create jurisdictional conflicts that delay critical construction decisions and cascade into schedule risks
- Absence of binding penalty clauses could reduce compliance incentives, leading to funding withholding and cascading cash flow crises
- Failure to address EU law constraints could invalidate the governance structure legally, requiring complete redesign and re-ratification

**Worst Case Scenario**: Complete governance failure resulting in indefinite project suspension or cancellation, with total loss of invested capital (€40 billion), severe diplomatic crisis between Spain and Morocco, and potential legal battles across multiple international jurisdictions that could last decades and damage both nations' international infrastructure cooperation reputations.

**Best Case Scenario**: The governance framework enables seamless cross-border coordination, maintaining strong investor confidence and efficient permitting that keeps the project on schedule. The neutral third-party consortium structure elegantly resolves sovereignty concerns while ensuring technical excellence, making the Spain-Morocco tunnel a globally recognized model for international megaproject governance and potentially accelerating similar cross-border infrastructure initiatives worldwide.

**Fallback Alternative Approaches**:

- Utilize the Bilateral Infrastructure Treaty Framework Template as a starting point and adapt it with input from international legal counsel specializing in transboundary infrastructure
- Schedule a focused workshop with Spanish and Moroccan government representatives, neutral engineering consortium leaders, and international arbitration experts to collaboratively define governance requirements
- Engage a specialized international legal firm (minimum 12 attorneys across Madrid, Rabat, and The Hague) to draft the governance framework with pre-negotiated fallback provisions
- Develop a simplified 'minimum viable governance document' covering only critical elements (treaty ratification, dispute resolution, funding allocation) initially, with detailed operational protocols added in subsequent phases
- If the neutral third-party consortium model proves too complex, pivot to a bilateral treaty organization with equal voting power as a more straightforward alternative that still ensures sovereign representation
- Establish a phased governance approach where initial construction decisions use a simplified interim framework while the full treaty is being ratified, with clear sunset provisions

## Create Document 3: Strategic Environmental Compliance Plan

**ID**: 136c81e8-007c-417f-91bb-57dd5ae64bd0

**Description**: High-level environmental strategy document governing regulatory, ecological, and permitting requirements for the transoceanic tunnel crossing international waters and sensitive marine ecosystems. Defines the elevated pillar configuration approach that preserves benthic habitats, the transboundary environmental impact assessment pathway through the IMO, seasonal construction restrictions during cetacean migration periods, the independent environmental oversight board structure with binding halt authority, and the ecosystem restoration program using artificial reef structures. Establishes the environmental compliance strategy as integrated engineering design rather than add-on remediation.

**Responsible Role Type**: Environmental Compliance & Marine Ecology Director

**Primary Template**: IMO Transboundary Environmental Impact Assessment Framework

**Secondary Template**: Barcelona Convention SPA/BD Protocol Compliance Template

**Steps to Create**:

- Define elevated pillar configuration strategy that minimizes seabed contact area while preserving benthic habitats
- Establish IMO transboundary environmental impact assessment engagement pathway with pre-agreed timeline
- Design independent environmental oversight board structure with binding authority to halt construction
- Define seasonal construction restrictions during cetacean migration periods (spring March-May, autumn September-November)
- Plan ecosystem restoration program with artificial reef structures along tunnel corridor
- Establish €200-500 million marine mitigation fund structure

**Approval Authorities**: IMO Marine Environment Protection Committee, Spanish National Environmental Agency, Moroccan National Environmental Agency, Independent Environmental Oversight Board

**Essential Information**:

- Define the elevated pillar configuration strategy that minimizes seabed contact area while preserving benthic habitats underneath the tunnel, accepting higher structural costs as the primary environmental mitigation approach
- Establish the IMO transboundary environmental impact assessment engagement pathway with a pre-agreed timeline and fallback ICC arbitration, targeting preliminary framework agreement by mid-2027
- Design the independent environmental oversight board structure with binding authority to halt construction if marine mammal disturbance thresholds are exceeded
- Define seasonal construction restrictions during cetacean migration periods (spring March-May, autumn September-November), acknowledging these reduce already limited weather windows by an additional 15-20%
- Plan the ecosystem restoration program using artificial reef structures along the tunnel corridor, recognizing these take years to establish functional ecosystems
- Establish the €200-500 million marine mitigation fund structure, capitalized at project inception
- Commission comprehensive marine ecosystem baseline studies covering cetacean migration patterns, benthic habitat mapping, water quality parameters, and sediment dynamics across the Strait of Gibraltar corridor (24-month field data collection)
- Deploy real-time acoustic monitoring buoys at minimum 10 locations along the tunnel corridor for marine mammal disturbance detection and mitigation
- Address environmental permitting across two sovereign jurisdictions with conflicting marine protection standards that could create duplicative review processes
- Integrate environmental compliance as engineered design rather than add-on remediation, ensuring the elevated pillar configuration and habitat preservation are core architectural features

**Risks of Poor Quality**:

- Environmental permitting delays from duplicative national reviews and environmental organization litigation could add 1-3 years and incur €500 million-€1.5 billion in compliance costs, including redesigned tunnel segments or modified pillar configurations
- Inadequate mitigation approaches could trigger regulatory shutdowns, fines of €50-500 million, and mandatory remediation costing €200 million-€1 billion, with reputational damage eroding public support and political backing
- Failure to establish binding oversight authority could allow construction to proceed without adequate environmental safeguards, leading to irreversible marine ecosystem damage and potential project cancellation
- Poorly designed elevated pillar configuration that fails to preserve benthic habitats would undermine the core environmental strategy, exposing the project to NGO litigation and permitting delays
- Absence of pre-construction environmental covenants and baseline studies leaves the project vulnerable to retrospective environmental liability claims of €1-5 billion
- Inadequate marine mitigation fund capitalization could leave environmental damage unaddressed during construction, triggering regulatory enforcement and public backlash
- Failure to address cetacean migration impacts could result in project suspension by the independent oversight board, costing €500 million-€1 billion in idle workforce and equipment demobilization

**Worst Case Scenario**: Catastrophic environmental damage from unmitigated construction activities triggers permanent project cancellation by international regulatory authorities, resulting in total loss of the €40 billion investment, unlimited environmental liability claims of €1-5 billion for ecosystem restoration, and reputational destruction that prevents Spain and Morocco from pursuing any future international infrastructure projects, while leaving the Strait of Gibraltar marine ecosystem irreversibly damaged.

**Best Case Scenario**: The plan establishes the project as a global model for environmentally responsible transboundary infrastructure, enabling seamless permitting across both jurisdictions without litigation, eliminating environmental opposition through proactive design that creates net-positive marine ecosystem outcomes via artificial reefs exceeding pre-construction biodiversity levels, thereby securing both regulatory approval and sustained public support for the full 20-year program while setting new international standards for subsea environmental compliance.

**Fallback Alternative Approaches**:

- If the IMO transboundary environmental assessment proves too slow (exceeding 5 years), pivot to a dual-track approach: proceed with national environmental approvals from Spain and Morocco simultaneously while maintaining IMO engagement as a secondary pathway, accepting the risk of duplicative reviews to avoid timeline paralysis
- If the elevated pillar configuration proves technically infeasible or cost-prohibitive, adopt a hybrid approach combining tension-leg pillars (minimizing seabed disturbance) with targeted artificial reef creation at alternative locations near the tunnel corridor
- If the independent environmental oversight board structure faces diplomatic resistance from either sovereign nation, establish a joint Spain-Morocco environmental monitoring committee with third-party technical advisors as an interim measure, with binding authority delegated through the bilateral treaty
- If the marine mitigation fund cannot be fully capitalized at project inception, implement a phased funding mechanism tied to construction milestones with minimum €100 million initial capitalization, escalating contributions as construction phases progress
- If seasonal construction restrictions during cetacean migration prove too limiting for the 20-year timeline, develop advanced noise-dampening construction technologies and bubble curtain systems that allow limited work during migration periods under strict real-time acoustic monitoring protocols

## Create Document 4: Geotechnical Validation Framework

**ID**: 77a866a5-e9a4-4d93-8382-fdb4af3d3a21

**Description**: Foundational validation strategy document establishing the approach for validating the unprecedented hybrid floating-pillar architecture at 100m depth. Defines the geotechnical validation gate as a hard prerequisite before any construction mobilization, specifying deep-sea borehole sampling at minimum 5 locations across the 14 km corridor (200m below seabed), 3D seismic reflection profiling calibrated to the Azores-Gibraltar transform fault zone, probabilistic seismic hazard analysis with minimum 2% probability of exceedance in 50 years, 1:50 scale physical model testing under simulated Gibraltar Strait currents, and a fully instrumented 50-meter prototype segment deployment at 100m equivalent depth. Establishes the hard stop date of June 2027 before any construction permits are issued.

**Responsible Role Type**: Geotechnical & Seismic Engineering Director

**Primary Template**: Probabilistic Seismic Hazard Analysis Framework

**Secondary Template**: Deep-Sea Geotechnical Investigation Protocol

**Steps to Create**:

- Define geotechnical validation gate with hard stop date before construction mobilization
- Specify deep-sea borehole sampling requirements (minimum 5 locations, 200m below seabed)
- Define 3D seismic reflection profiling scope calibrated to Azores-Gibraltar fault zone
- Establish probabilistic seismic hazard analysis methodology with minimum 2% PoE in 50 years
- Plan 1:50 scale physical model testing in deep-water basins under simulated currents (max 2.5 m/s)
- Define fully instrumented 50-meter prototype segment deployment and 6-month monitoring requirements

**Approval Authorities**: Independent Seismic Review Panel, Geotechnical & Seismic Engineering Director, Program Director

**Essential Information**:

- Define the geotechnical validation gate with a hard stop date of June 2027 before any construction permits are issued or mobilization begins
- Specify deep-sea borehole sampling requirements across minimum 5 locations spanning the 14 km corridor, each reaching 200 meters below the seabed to capture subsurface stratigraphy
- Define 3D seismic reflection profiling scope calibrated specifically to the Azores-Gibraltar transform fault zone, including fault line mapping and liquefaction potential assessment
- Establish probabilistic seismic hazard analysis (PSHA) methodology requiring minimum 2% probability of exceedance in 50 years, producing site-specific seismic loading cases for all structural designs
- Plan 1:50 scale physical model testing in deep-water basins under simulated Gibraltar Strait currents (maximum 2.5 m/s) to validate hybrid floating-pillar architecture force dynamics
- Define fully instrumented 50-meter prototype segment deployment at 100-meter equivalent depth with 6-month continuous monitoring requirements for structural performance validation
- Establish validation criteria and acceptance thresholds for hybrid floating-pillar architecture at 100m depth, including load distribution, lateral stability, and seabed penetration metrics
- Document geotechnical assumptions currently used in design (clay, sand, weathered bedrock) and identify gaps requiring resolution through the validation program

**Risks of Poor Quality**:

- Construction proceeds on unvalidated geotechnical assumptions, risking structural failure of pillar foundations at 100m depth with potential loss of €10-20 billion in tunnel segments
- Seismic loading cases remain based on generic regional data rather than site-specific parameters, exposing the project to €3-8 billion in earthquake damage from a moderate event (M5.5-6.5)
- The hard stop date mechanism fails, allowing construction mobilization before geotechnical validation is complete, creating a point of no return where sunk costs pressure proceeding despite unknown risks
- Borehole sampling insufficient in number or depth, missing critical geological features such as fault lines or unstable sediment layers that could compromise pillar anchoring
- Physical model testing inadequately simulates real-world conditions, leading to false validation of the hybrid floating-pillar architecture and subsequent structural miscalculations at full scale
- Regulatory approval is granted based on incomplete geotechnical data, creating legal liability and potential project cancellation if validation later reveals inadequate foundation support

**Worst Case Scenario**: Construction mobilization begins before the June 2027 geotechnical validation gate is satisfied, and a major seismic event (M7.0+) occurs along the Azores-Gibraltar transform fault, causing catastrophic structural failure of the pillar foundations, total loss of tunnel segments valued at €10-20 billion, potential loss of life, environmental disaster from submerged structure rupture, and permanent project cancellation with unlimited liability for the sovereign nations involved.

**Best Case Scenario**: The Geotechnical Validation Framework definitively validates the unprecedented hybrid floating-pillar architecture at 100m depth, providing site-specific seismic loading cases that enable a resilient design capable of withstanding the 2% probability of exceedance seismic event. The hard stop date prevents premature construction, giving investors, governments, and insurers the confidence to commit the full €40 billion. The validation program produces a go/no-go decision point that de-risks the entire megaproject and establishes Spain-Morocco as leaders in evidence-based deep-sea infrastructure engineering.

**Fallback Alternative Approaches**:

- Commission a phased validation approach: begin with 2 borehole locations and preliminary seismic profiling to establish a minimum viable dataset, with provisions to expand to 5+ locations based on initial findings if budget or timeline constraints exist
- Engage a third-party geotechnical consultancy with existing regional data from the Strait of Gibraltar to develop a preliminary validation framework while deep-sea sampling is underway, allowing parallel workstreams
- Adopt conservative design assumptions based on historical seismic data and regional geological maps as an interim basis for early construction preparation, with a commitment to update designs upon validation completion while accepting a higher risk premium
- Utilize existing offshore oil and gas industry geotechnical data from comparable Mediterranean deep-sea conditions as a proxy dataset to inform initial validation parameters
- Establish a joint Spain-Morocco geotechnical data-sharing agreement with international research institutions to access existing seabed survey data, reducing the scope of new drilling required

## Create Document 5: Phasing and Risk Strategy Document

**ID**: 0d6348a7-3a77-4682-bb34-f0a9e26bfa97

**Description**: Temporal architecture document defining the 20-year construction program's sequencing logic. Establishes functional-subsystem phasing (Phase 1: pillars and buoyancy ~6-7 years; Phase 2: rail infrastructure ~5-6 years; Phase 3: sealing, pressurization, and commissioning ~4-5 years) with 6-12 month inter-phase buffers for validation testing and course correction. Defines the balance between timeline compression and cost containment, the political sustainability considerations of phased returns, and the natural risk checkpoints that each phase provides. Addresses weather window dependencies consuming 20-30% of annual working time in the Strait of Gibraltar.

**Responsible Role Type**: Program Director & Cross-Border Governance Lead

**Primary Template**: Megaproject Phasing Strategy Framework

**Secondary Template**: Critical Path Method (CPM) Schedule Template with Monte Carlo Simulation

**Steps to Create**:

- Define functional-subsystem phasing approach with approximate 4-5 year phases
- Establish go/no-go decision gates between each phase with validation testing requirements
- Define schedule contingency (2-3 years) and inter-phase buffer periods (6-12 months)
- Analyze weather window dependencies and their impact on annual working time (20-30%)
- Assess political sustainability implications of phased economic returns
- Establish tranche-based financing disbursement milestones aligned with phasing gates

**Approval Authorities**: Program Director, International Finance & Capital Director, Bilateral Diplomatic Task Force

**Essential Information**:

- Define the functional-subsystem phasing approach with approximate 4-5 year phases (Phase 1: pillars and buoyancy ~6-7 years; Phase 2: rail infrastructure ~5-6 years; Phase 3: sealing, pressurization, and commissioning ~4-5 years)
- Establish go/no-go decision gates between each phase with explicit validation testing requirements and criteria for course correction
- Define schedule contingency (2-3 years total) and inter-phase buffer periods (6-12 months) with triggers for buffer consumption
- Analyze weather window dependencies and quantify their impact on annual working time (20-30% reduction in Strait of Gibraltar)
- Assess political sustainability implications of phased economic returns and how delays in early phases erode public support
- Establish tranche-based financing disbursement milestones aligned with phasing gates to maintain investor confidence and unlock successive funding
- Detail the proof-of-concept validation approach for early segments before committing to full-scale deployment
- Define risk distribution across time, including how construction risk is allocated and mitigated at each phase transition
- Specify the balance between timeline compression and cost containment, including trade-offs for parallel vs. sequential construction
- Document the temporal architecture logic that governs all on-site building activities and cascades into logistics, workforce, and procurement planning

**Risks of Poor Quality**:

- Unclear or missing go/no-go decision gates allow structurally unvalidated phases to proceed, risking catastrophic failures at 100m depth
- Inadequate weather window analysis leads to unrealistic schedule estimates, causing cascading delays and €300-600 million in additional carrying costs per year of overrun
- Poorly defined tranche-based financing milestones disrupt investor confidence, triggering funding cliffs that halt construction for 6-12 months at a cost of €500 million-€1 billion
- Lack of political sustainability analysis results in eroded public support before completion, potentially causing government withdrawal or regulatory shutdown
- Insufficient schedule contingency leaves no buffer for the 20-30% weather-related working time loss, making the 20-year timeline mathematically unachievable
- Missing validation testing requirements at phase transitions allows systemic defects to propagate across subsystems, compounding remediation costs to €3-8 billion
- Unclear risk distribution logic concentrates exposure in single phases, creating single points of failure that can collapse the entire program

**Worst Case Scenario**: The entire 20-year, €40 billion project collapses due to cascading phase failures: without validated proof-of-concept before full-scale deployment, structural miscalculations in the hybrid floating-pillar architecture cause tunnel segment misalignment or uncontrolled depth variation at 100m, triggering a €500 million-€2 billion per-incident replacement cycle that exhausts the contingency reserve, destroys investor confidence, and forces project abandonment with total loss of invested capital.

**Best Case Scenario**: The document enables a validated, risk-mitigated construction sequence where each functional subsystem is proven through go/no-go gates before proceeding, ensuring the hybrid floating-pillar architecture is validated at scale before rail installation, maintaining continuous investor confidence through tranche-aligned milestones, preserving political support through visible phased progress, and delivering the transoceanic tunnel on schedule within the €40 billion envelope with natural checkpoints that distribute risk across the 20-year horizon.

**Fallback Alternative Approaches**:

- Develop a simplified 'minimum viable document' covering only the critical phase gates, contingency reserves, and financing milestones, deferring detailed weather analysis and political sustainability assessment to supplementary appendices
- Utilize a pre-approved megaproject phasing template (such as the CPM Schedule Template with Monte Carlo Simulation) and adapt it specifically to the functional-subsystem approach, reducing creation time while maintaining analytical rigor
- Engage a specialized technical scheduling consultant or project management firm with megaproject experience to co-author the document, leveraging their expertise in deep-sea construction sequencing
- Conduct a focused 2-day workshop with the Program Director, International Finance Director, and Bilateral Diplomatic Task Force to collaboratively define phasing requirements and decision gates, then document outcomes
- Start with a high-level phase overview (Phase 1/2/3 with approximate durations) and progressively detail each phase's validation requirements, allowing early stakeholder feedback to inform subsequent sections

## Create Document 6: International Consortium Financing Framework

**ID**: b1739746-7854-430e-b371-5e3270ef6bd7

**Description**: High-level capital sourcing and structuring document for the €40 billion project. Defines the financing architecture through multilateral government bonds jointly guaranteed by Spain and Morocco, public-private partnerships selling operational toll revenues, and multilateral development bank funds providing tranche-based disbursements tied to geological and marine milestones. Establishes the €4-6 billion contingency reserve with automated escalation triggers at 5%, 10%, and 15% budget utilization, the 12-month operational reserve fund, and the currency hedging program covering at least 70% of MAD-denominated expenditures. Addresses investor confidence management and alignment of return timelines with the 20-year construction horizon.

**Responsible Role Type**: International Finance & Capital Director

**Primary Template**: Multilateral Infrastructure Bond Structuring Framework

**Secondary Template**: Public-Private Partnership (PPP) Financial Model Template

**Steps to Create**:

- Define financing architecture across sovereign bonds, development bank facilities, and private capital
- Establish tranche-based disbursement structure tied to geological and marine milestones
- Design €4-6 billion contingency reserve with automated escalation triggers
- Structure currency hedging program covering at least 70% of projected MAD-denominated expenditures
- Define 12-month operational reserve fund to buffer against funding cliffs
- Establish investor confidence management strategy including quarterly briefings and transparent reporting

**Approval Authorities**: European Investment Bank, African Development Bank, Spanish Ministry of Finance, Moroccan Ministry of Finance

**Essential Information**:

- Define the multi-source financing architecture combining sovereign-backed infrastructure bonds jointly guaranteed by Spain and Morocco, public-private partnerships selling operational toll revenues, and multilateral development bank funds providing tranche-based disbursements
- Establish the tranche-based disbursement structure tied to specific geological and marine milestones, including natural validation checkpoints that unlock successive funding tranches and maintain investor confidence across the 20-year horizon
- Design the €4-6 billion contingency reserve with automated escalation triggers at 5%, 10%, and 15% budget utilization to prevent covenant breaches and investor withdrawal during cost overruns
- Structure the currency hedging program covering at least 70% of projected MAD-denominated expenditures using forward contracts and swaps, with a dedicated treasury function for monthly FX exposure monitoring
- Define the 12-month operational reserve fund to buffer against funding cliffs when milestones are delayed or disputed, preventing cascading cash flow crises that could halt construction
- Establish the investor confidence management strategy including quarterly transparent financial reporting, milestone-based disbursement alignment, and diversification across sovereign bonds, development bank facilities, and private capital to prevent single-source dependency
- Quantify the cost of capital implications across different financing instruments and establish the €1-2 billion contingency for potential 200-400 basis point increases if government bond guarantees are lost
- Define the governance and approval framework for financing decisions, including the roles of the European Investment Bank, African Development Bank, Spanish Ministry of Finance, and Moroccan Ministry of Finance as approval authorities

**Risks of Poor Quality**:

- Inadequate tranche-based milestone definitions could trigger funding withholding during disputes, creating 6-12 month funding gaps costing €500 million-€1 billion in idle workforce and equipment demobilization
- Missing or insufficient currency hedging could erode the budget by €200-800 million through EUR/MAD fluctuations, particularly acute during peak Moroccan-side construction expenditures
- Absence of automated escalation triggers in the contingency reserve could delay response to cost overruns, allowing them to cascade into covenant breaches that trigger investor withdrawal or forced restructuring
- Failure to diversify funding sources could create single-point-of-failure dependency; loss of one major investor or development bank commitment could collapse the entire financing structure
- Inadequate investor confidence management could increase the cost of capital by 200-400 basis points, adding €1-3 billion in total interest payments over the 20-year horizon
- Missing the 12-month operational reserve fund leaves the project vulnerable to any milestone delay, potentially halting construction and triggering contractual penalties

**Worst Case Scenario**: Complete financing collapse due to a combination of funding cliff triggers, currency devaluation eroding the budget, and investor confidence loss from governance delays, resulting in project cancellation after billions in sunk costs, total loss of invested capital, and severe reputational damage to both Spain and Morocco as international infrastructure partners.

**Best Case Scenario**: A robust, diversified financing structure is established that provides stable, long-term capital with flexible disbursement tranches aligned to geological and marine milestones, enabling the project to absorb cost overruns, currency fluctuations, and timeline delays without triggering covenant breaches or investor withdrawal, thereby maintaining continuous construction momentum and investor confidence across the full 20-year horizon.

**Fallback Alternative Approaches**:

- Utilize a pre-approved multilateral development bank template (e.g., EIB or AfDB standard infrastructure bond framework) and adapt it to the Spain-Morocco bilateral context, reducing structuring time and legal costs
- Schedule a focused workshop with the European Investment Bank, African Development Bank, and both national finance ministries to collaboratively define the tranche-based disbursement milestones and contingency triggers
- Engage a specialized financial structuring advisor or investment bank with megaproject financing expertise to develop the financing architecture, particularly for the PPP toll-revenue component
- Develop a simplified 'minimum viable document' covering only the critical financing elements (total capital requirement, primary funding sources, contingency reserve, and currency hedging) initially, with detailed operational provisions added in subsequent iterations
- Commission a parallel financial feasibility study using Monte Carlo simulation to model funding scenarios and stress-test the financing structure against the identified risks before finalizing the framework

## Create Document 7: Risk Register

**ID**: 44c4b293-df48-4f6b-80c2-3c76065263ac

**Description**: Comprehensive initial risk register cataloging all identified risks across regulatory, technical, financial, environmental, social, operational, supply chain, security, geopolitical, and long-term sustainability categories. Documents 18 major risks including cross-border governance misalignment (2-5 year delay, €2-5 billion), unvalidated hybrid floating-pillar architecture (€500M-€2B per incident), financial sustainability over 20 years (€4-6 billion overrun potential), absence of seismic data near Azores-Gibraltar fault zone, missing energy supply infrastructure, inadequate maritime traffic integration, no decommissioning plan, rail gauge incompatibility, climate change impacts, and water intrusion/flooding risk at 100m depth. Includes impact, likelihood, severity, and mitigation actions for each risk.

**Responsible Role Type**: Program Director & Cross-Border Governance Lead

**Primary Template**: PMI Risk Register Template

**Secondary Template**: ISO 31000 Risk Management Framework

**Steps to Create**:

- Catalog all 18 major risks across regulatory, technical, financial, environmental, social, operational, supply chain, security, geopolitical, and sustainability categories
- Assign impact, likelihood, and severity ratings for each risk
- Define mitigation actions and responsible owners for each risk
- Establish risk escalation thresholds and automated trigger mechanisms
- Identify risk interdependencies (governance delays compound financial exposure, technical failures trigger cost overruns)
- Define contingency reserve allocation aligned with risk severity

**Approval Authorities**: Program Director, International Finance & Capital Director, All Functional Directors

**Essential Information**:

- Catalog all 18 identified major risks across regulatory, technical, financial, environmental, social, operational, supply chain, security, geopolitical, and long-term sustainability categories
- Assign quantitative impact ratings (€500M-€20B potential losses), likelihood ratings (Low-Medium-High), and severity ratings for each risk
- Define specific mitigation actions, responsible owners, and implementation timelines for each risk
- Establish risk escalation thresholds and automated trigger mechanisms (e.g., 5%, 10%, 15% budget utilization triggers)
- Identify risk interdependencies and cascading effects (e.g., governance delays compound financial exposure, technical failures trigger cost overruns)
- Define contingency reserve allocation (€4-6 billion) aligned with risk severity and probability
- Document specific cost and timeline impacts for each risk (e.g., cross-border governance misalignment: 2-5 year delay, €2-5 billion cost increase)
- Include validation requirements for unprecedented technical risks (hybrid floating-pillar architecture at 100m depth)
- Specify regulatory compliance requirements and permitting risk factors across Spanish and Moroccan jurisdictions
- Detail environmental, seismic, energy, maritime traffic, and decommissioning risk factors with quantitative sensitivity analyses

**Risks of Poor Quality**:

- Incomplete risk identification could leave critical threats (seismic activity, flooding, energy supply) unmitigated, potentially causing catastrophic project failure
- Inadequate quantification of impacts and likelihoods could lead to misallocation of the €4-6 billion contingency reserve
- Failure to document risk interdependencies could result in cascading failures where one risk triggers multiple others simultaneously
- Lack of clear mitigation actions and responsible owners could delay response times during critical project phases
- Absence of escalation thresholds could cause delayed responses to emerging risks, allowing minor issues to become major crises
- Poorly defined risk categories could create gaps in coverage, leaving operational or supply chain risks unmonitored
- Inadequate financial risk assessment could expose the project to currency fluctuations, funding cliffs, and cost overruns exceeding €4-6 billion

**Worst Case Scenario**: Multiple critical risks materializing simultaneously—cross-border governance collapse, hybrid floating-pillar structural failure, and financial crisis—could result in total project abandonment, loss of the entire €40 billion investment, permanent damage to Spain-Morocco diplomatic relations, and catastrophic environmental consequences in the Strait of Gibraltar.

**Best Case Scenario**: A comprehensive risk register enables proactive, data-driven risk management that keeps the project on track within the €40 billion budget and 20-year timeline, successfully validating unprecedented deep-sea construction technologies and establishing Spain-Morocco as global leaders in subsea infrastructure while preserving marine ecosystems.

**Fallback Alternative Approaches**:

- Utilize the pre-existing PMI Risk Register Template and ISO 31000 framework documented in document.json, adapting it with project-specific data from assumptions.md and project-plan.md
- Engage a specialized megaproject risk management consultant with experience in transboundary infrastructure to facilitate the risk register creation process
- Develop a simplified 'minimum viable risk register' covering only the top 5 critical risks (governance, technical architecture, financial sustainability, seismic, and energy) initially, with plans to expand
- Conduct a focused 2-week workshop with all functional directors and the Program Director to collaboratively identify, quantify, and prioritize risks using the Delphi technique
- Leverage the existing risk summary in assumptions.md as a foundation and systematically expand each risk entry with detailed mitigation plans and quantitative impact data

## Create Document 8: High-Level Budget and Funding Framework

**ID**: 19edbbbc-ea99-4a4d-be4e-beb39be3a411

**Description**: High-level financial architecture document establishing the €40 billion budget envelope, its allocation across functional subsystems (pillar architecture, construction deployment, rail systems, environmental compliance, and operational readiness), the 10-15% contingency reserve (€4-6 billion), the 12-month operational reserve fund, and the currency hedging strategy covering 70% of MAD-denominated expenditures. Defines the cost escalation risk management approach including fixed-price contracts with penalty clauses, quarterly cost reviews, and automated escalation triggers at 5%, 10%, and 15% budget utilization. Addresses the €1-2 billion energy infrastructure budget, €3-8 billion maintenance trust fund, €2-4 billion decommissioning reserve fund, and €200-500 million marine mitigation fund.

**Responsible Role Type**: International Finance & Capital Director

**Primary Template**: Megaproject Budget Framework Template

**Secondary Template**: World Bank High-Value Infrastructure Budget Template

**Steps to Create**:

- Define €40 billion budget allocation across functional subsystems
- Establish 10-15% contingency reserve (€4-6 billion) with automated escalation triggers
- Define 12-month operational reserve fund structure
- Design currency hedging program covering at least 70% of MAD-denominated expenditures
- Allocate dedicated budgets for energy infrastructure (€1-2B), maintenance trust fund (€3-8B), decommissioning reserve (€2-4B), and marine mitigation (€200-500M)
- Define cost escalation risk management including fixed-price contracts and quarterly reviews

**Approval Authorities**: International Finance & Capital Director, European Investment Bank, African Development Bank, Spanish Ministry of Finance, Moroccan Ministry of Finance

**Essential Information**:

- Define €40 billion budget allocation across functional subsystems (pillar architecture, construction deployment, rail systems, environmental compliance, and operational readiness) with specific percentage or euro amounts per subsystem
- Establish 10-15% contingency reserve (€4-6 billion) with automated escalation triggers at 5%, 10%, and 15% budget utilization, including clear definitions of trigger actions and approval authorities
- Define 12-month operational reserve fund structure including capitalization mechanism, disbursement rules, and governance oversight
- Design currency hedging program covering at least 70% of projected MAD-denominated expenditures using forward contracts and swaps, with remaining 30% exposure quantified and risk-adjusted
- Allocate dedicated budgets for energy infrastructure (€1-2 billion), maintenance trust fund (€3-8 billion capitalized at inception), decommissioning reserve fund (€2-4 billion), and marine mitigation fund (€200-500 million)
- Define cost escalation risk management framework including fixed-price contracts with penalty clauses for major suppliers, quarterly cost review cadence, and automated escalation triggers
- Structure tranche-based financing disbursements tied to geological and marine milestones, defining specific milestone criteria, disbursement amounts, and funding cliff mitigation mechanisms
- Identify funding sources across multilateral government bonds (joint Spanish-Moroccan sovereign guarantees), public-private partnerships (toll revenue monetization), and development bank funds (EIB, AfDB)
- Establish EUR/MAD dual-currency management strategy including exchange rate risk quantification, hedging instrument specifications, and treasury function for monthly FX exposure monitoring
- Define investor confidence mechanisms including transparent financial reporting cadence, quarterly investor briefings, and milestone-based funding unlocks that maintain capital continuity across the 20-year horizon

**Risks of Poor Quality**:

- Budget overruns of €4-6 billion without adequate contingency reserves could trigger covenant breaches with private equity investors, leading to forced restructuring or funding withdrawal
- Funding cliffs from tranche-based disbursements without clear milestone definitions could halt construction for 6-12 months, costing €500 million-€1 billion in idle workforce and equipment demobilization/remobilization
- Unhedged EUR/MAD currency fluctuations of 10-20% could translate to €200-800 million in additional costs, particularly acute during peak Moroccan-side construction expenditures
- Absence of automated escalation triggers means cost overruns may go undetected until they exceed 15%, at which point remediation options are severely limited and investor confidence is already eroded
- Missing dedicated budgets for maintenance (€3-8B), decommissioning (€2-4B), and energy (€1-2B) creates massive unfunded liabilities that could render the project financially unsustainable over its 20-year lifespan
- Without fixed-price contracts and penalty clauses, material cost volatility for buoyant concrete, marine-grade steel, and specialized mooring systems could inflate costs beyond the €40 billion envelope
- Lack of transparent financial reporting and milestone-based funding unlocks could erode investor confidence, increasing the cost of capital by 200-400 basis points and adding €1-3 billion in total interest payments

**Worst Case Scenario**: Complete funding collapse triggered by the convergence of unhedged currency losses, a major cost overrun exceeding 15% without contingency reserves, and a funding cliff from withheld tranche disbursements—resulting in construction halt, investor withdrawal, covenant breaches across all financing instruments, and potential project cancellation with total loss of invested capital exceeding €20 billion, plus €2-6 billion in carrying costs, contract termination penalties, and remobilization expenses if the project is ever revived.

**Best Case Scenario**: Enables a confident go/no-go decision on Phase 2 funding by providing a clear, transparent financial architecture that protects the €40 billion envelope through automated escalation triggers, diversified funding sources, and comprehensive reserve funds; establishes investor confidence through milestone-based tranche disbursements and quarterly transparent reporting; and ensures long-term financial sustainability by capitalizing maintenance, decommissioning, and energy reserves at project inception, thereby reducing the cost of capital and attracting multilateral development bank participation.

**Fallback Alternative Approaches**:

- Utilize the World Bank High-Value Infrastructure Budget Template as a pre-approved framework and adapt it to the €40 billion transoceanic tunnel context, focusing on the specific subsystem allocations and dual-currency requirements
- Engage a specialized megaproject financial advisor or technical writer with experience in international infrastructure financing to assist in structuring the document, particularly for the tranche-based disbursement and currency hedging sections
- Develop a simplified 'minimum viable document' covering only the critical elements initially—€40 billion envelope, 10-15% contingency, and tranche-based milestones—with detailed sub-budgets (energy, maintenance, decommissioning) added in subsequent iterations
- Schedule a focused workshop with the International Finance & Capital Director, European Investment Bank, African Development Bank, and Spanish/Moroccan Ministry of Finance representatives to collaboratively define the budget allocation and risk triggers before drafting the full document

## Create Document 9: Energy Infrastructure Strategy

**ID**: 04a0114e-b557-4b31-8c85-6bcbbc151b32

**Description**: High-level energy supply strategy document addressing the critical gap in the project's operational planning. Defines the comprehensive energy audit approach to quantify total operational demand (estimated 50-100 MW continuous), the hybrid energy strategy combining submarine HVDC cable connections to Spanish and Moroccan grids, offshore wind/tidal generation with battery storage, and diesel backup. Establishes the dedicated €1-2 billion energy infrastructure budget and the requirement to negotiate energy supply agreements with both national grid operators before construction begins. Addresses the fundamental risk that without reliable power, the tunnel cannot operate, rendering the entire €40 billion investment inoperable.

**Responsible Role Type**: Offshore Energy Infrastructure Engineer

**Primary Template**: Offshore Energy Infrastructure Planning Framework

**Secondary Template**: Submarine HVDC Cable Design Specification Template

**Steps to Create**:

- Conduct comprehensive energy audit quantifying total operational demand (50-100 MW continuous)
- Define hybrid energy strategy combining submarine HVDC cables, offshore renewable generation, and backup power
- Establish dedicated €1-2 billion energy infrastructure budget
- Plan submarine HVDC cable specifications and grid interconnection requirements
- Define offshore wind/tidal generation capacity and battery storage requirements
- Establish negotiation timeline for energy supply agreements with both national grid operators

**Approval Authorities**: Spanish National Grid Operator, Moroccan National Grid Operator, Program Director

**Essential Information**:

- Quantify total continuous operational energy demand (50-100 MW) across all tunnel systems including pressurized rail climate control, ventilation, structural surveillance, cathodic protection, buoyancy adjustment, and rail propulsion at 100m depth
- Define hybrid energy architecture specifications: submarine HVDC cable routes and capacities connecting to Spanish and Moroccan grids, offshore wind/tidal generation capacity, battery storage duration for resilience, and diesel backup redundancy
- Establish dedicated €1-2 billion energy infrastructure budget with line-item allocations for submarine cables, offshore generation installations, battery storage systems, and backup generators
- Specify submarine HVDC cable technical requirements including voltage levels, cross-sectional area, insulation specifications for 100m depth marine environments, and grid interconnection points at Tarifa and Tangier
- Define offshore wind/tidal generation capacity targets and battery storage specifications (capacity in MWh, discharge duration) to ensure operational continuity during maintenance or grid disruptions
- Establish negotiation framework and timeline for energy supply agreements with Spanish National Grid Operator and Moroccan National Grid Operator, including pricing mechanisms, capacity reservations, and reliability guarantees
- Identify required inputs: detailed operational load profiles for all tunnel subsystems, existing grid capacity and stability data from both Spanish and Moroccan grid operators, oceanographic and meteorological data for the Strait of Gibraltar, submarine cable routing feasibility studies, and environmental impact assessments for offshore energy installations

**Risks of Poor Quality**:

- Without a validated energy strategy, the tunnel cannot operate, rendering the entire €40 billion investment inoperable and resulting in zero revenue ($500 million-$1 billion annual losses)
- Energy cost overruns of 30-50% could add €300-600 million to 20-year operational costs, reducing project ROI by 2-4 percentage points and potentially triggering investor withdrawal
- A submarine HVDC cable failure or inadequate grid interconnection could cause complete tunnel shutdown, costing €50-100 million per incident in lost revenue and emergency repairs
- Insufficient backup power or lack of energy storage could lead to catastrophic system failures during grid outages or extreme weather events, endangering passengers and compromising structural integrity
- Failure to secure energy supply agreements with national grid operators before construction begins could delay project initiation by 1-2 years, adding €300-600 million in carrying costs

**Worst Case Scenario**: Complete absence of reliable energy supply infrastructure renders the tunnel permanently inoperable, resulting in total loss of the €40 billion investment, potential legal liability for failing to deliver on the transcontinental connectivity promise, and permanent damage to Spain-Morocco bilateral relations and international investor confidence

**Best Case Scenario**: A robust, diversified energy infrastructure strategy enables uninterrupted tunnel operations, ensuring projected revenue streams are realized and the project achieves its transformative economic and commercial connectivity goals between Europe and Africa. Enables go/no-go decision on full-scale construction by validating energy feasibility and securing binding energy supply agreements with both national grid operators. Provides clear technical specifications for submarine cable routes and offshore generation installations, reducing ambiguity for construction teams and enabling accurate procurement planning.

**Fallback Alternative Approaches**:

- Utilize a phased energy infrastructure approach: initially deploy mobile offshore power units (MOPUs) and limited grid connections to support early construction phases, with full HVDC and renewable integration deferred to the operational phase after energy demand profiles are validated
- Engage specialized offshore energy consultants to develop a minimum viable energy plan covering only critical systems (ventilation, rail propulsion, surveillance) initially, expanding to full buoyancy adjustment and cathodic protection systems once revenue streams are established
- Leverage existing Spanish and Moroccan national grid expansion plans to piggyback on scheduled infrastructure upgrades rather than building dedicated submarine cables, reducing capital expenditure
- Establish a temporary energy solution using diesel generators during construction to validate energy demand profiles before committing to permanent submarine cable and offshore renewable infrastructure

## Create Document 10: Maritime Traffic Integration Framework

**ID**: c54aaeb2-6150-4e0c-aa60-cadc8c33ec37

**Description**: High-level framework document addressing the critical gap in maritime traffic management for the Strait of Gibraltar, which sees over 100,000 vessel transits annually. Defines the comprehensive maritime traffic impact study approach including computational fluid dynamics modeling of tunnel-induced current changes, collision probability analysis, and the Temporary Traffic Management Plan with international authorities (IMO, Strait of Gibraltar Joint Coordination Center). Establishes the requirement for AIS monitoring and collision avoidance systems, permanent shipping lane adjustments, and a 24/7 maritime traffic control center for both construction and operational phases.

**Responsible Role Type**: Maritime Traffic & Navigation Safety Director

**Primary Template**: Maritime Traffic Impact Assessment Framework

**Secondary Template**: IMO Strait of Gibraltar Joint Coordination Center Protocols

**Steps to Create**:

- Commission comprehensive maritime traffic impact study including CFD modeling and collision probability analysis
- Define Temporary Traffic Management Plan with IMO and Strait of Gibraltar Joint Coordination Center
- Plan AIS monitoring and collision avoidance system deployment
- Establish negotiation framework for permanent shipping lane adjustments
- Design 24/7 maritime traffic control center for construction and operational phases
- Define liability allocation framework for disruption to 100,000+ annual vessel transits

**Approval Authorities**: Strait of Gibraltar Joint Coordination Center, IMO, Spanish Maritime Authority, Moroccan Maritime Authority

**Essential Information**:

- Comprehensive maritime traffic impact study methodology including computational fluid dynamics (CFD) modeling of tunnel-induced current changes and wave height alterations across the Strait of Gibraltar shipping corridor
- Collision probability analysis framework quantifying risk exposure for 100,000+ annual vessel transits, including tanker and container ship traffic patterns, speed zones, and proximity thresholds to the submerged tunnel structure
- Temporary Traffic Management Plan (TTMP) specification defining construction-phase maritime lane closures, vessel scheduling protocols, and coordination procedures with the Strait of Gibraltar Joint Coordination Center and IMO
- AIS monitoring and collision avoidance system deployment architecture including real-time vessel tracking buoys, automated identification system integration, and alert protocols for vessels approaching exclusion zones
- Negotiation framework and diplomatic protocol for securing permanent shipping lane adjustments that accommodate both the tunnel's structural footprint and ongoing maritime commerce between Europe and Africa
- 24/7 maritime traffic control center design specifications including staffing requirements, communication systems linking Spanish and Moroccan maritime authorities, and integration with existing Strait of Gibraltar Joint Coordination Center operations
- Liability allocation framework defining financial responsibility and insurance requirements for disruptions to 100,000+ annual vessel transits, including collision damage, environmental spill liability, and business interruption claims
- Phased integration plan aligning maritime traffic management with construction deployment milestones (offshore platform construction, segment transport, installation) and the 20-year operational phase

**Risks of Poor Quality**:

- Failure to secure shipping lane agreements could halt construction transport, adding 6-12 months and €500 million-€1 billion in costs due to idle workforce and equipment demobilization
- Inadequate CFD modeling of tunnel-induced current changes could increase wave heights by 5-15%, elevating collision risk by 10-30% and endangering the submerged structure at 100m depth
- Absence of a robust Temporary Traffic Management Plan could cause congestion and delays in one of the world's busiest shipping lanes, triggering diplomatic incidents between Spain, Morocco, and international shipping nations
- Without proper AIS monitoring and collision avoidance systems, a collision with a tunnel segment during transport could cost €500 million-€2 billion, cause environmental disaster, and result in 6-12 months of repair shutdown
- Undefined liability allocation could leave the project exposed to unlimited financial claims from disrupted maritime commerce, potentially exceeding the €40 billion budget envelope
- Lack of coordination protocols between Spanish and Moroccan maritime authorities could create jurisdictional gaps in traffic management, compromising safety during both construction and operational phases

**Worst Case Scenario**: A major collision between a transport vessel and a partially submerged tunnel segment during construction could cause €500 million-€2 billion in immediate damage, trigger a catastrophic environmental disaster (fuel spill or structural breach releasing hazardous materials), result in loss of life, and necessitate 6-12 months of complete maritime shutdown for repairs—costing €1-3 billion in lost revenue and potentially leading to permanent project cancellation with unlimited legal liability across two sovereign nations.

**Best Case Scenario**: The framework enables safe, uninterrupted construction transport and 20-year operational logistics through the Strait of Gibraltar, establishing the tunnel as a global model for maritime infrastructure integration in congested waterways. It secures permanent shipping lane adjustments that accommodate both commerce and tunnel operations, provides clear protocols for 24/7 maritime traffic control ensuring zero collisions throughout the project lifecycle, and enables data-driven go/no-go decisions on construction phase timing based on real-time maritime traffic conditions and weather windows.

**Fallback Alternative Approaches**:

- Utilize existing IMO Strait of Gibraltar Joint Coordination Center protocols as a baseline template and adapt them specifically for tunnel-related maritime traffic requirements, reducing development time by leveraging established international frameworks
- Engage a specialized maritime traffic consulting firm with proven experience in congested straits and major infrastructure projects to develop the framework independently, then validate through joint review with the Strait of Gibraltar Joint Coordination Center
- Develop a simplified 'minimum viable document' covering only critical collision avoidance protocols and the Temporary Traffic Management Plan for the construction phase, deferring comprehensive CFD modeling and permanent lane adjustments to the pre-construction validation gate
- Schedule a focused multi-stakeholder workshop with the Strait of Gibraltar Joint Coordination Center, Spanish and Moroccan maritime authorities, international shipping representatives, and the project's neutral third-party consortium to collaboratively define requirements and draft the framework in real-time
- Leverage computational fluid dynamics modeling already commissioned for the geotechnical and seismic risk assessment to inform maritime current analysis, avoiding redundant modeling costs and accelerating framework development

## Create Document 11: Technical Validation Strategy

**ID**: b01c4e11-c580-4eba-8a7a-a048894f764f

**Description**: High-level strategy document establishing the unified approach for validating the unprecedented hybrid floating-pillar architecture through prototype testing and research. Defines the 1:50 scale physical model testing roadmap in deep-water basins under simulated Gibraltar Strait current conditions, the fully instrumented 50-meter prototype segment deployment at 100m equivalent depth with minimum 6 months of continuous monitoring, and the full-scale pressurized rail prototype testing under simulated deep-sea conditions. Establishes the Research, Innovation & Prototype Validation Lead role to coordinate the research pipeline across all engineering disciplines and ensure the Builder's Foundation strategy's 'deliberate equilibrium between innovation and proven engineering' is maintained throughout the project lifecycle.

**Responsible Role Type**: Research, Innovation & Prototype Validation Lead

**Primary Template**: Prototype Validation Roadmap Framework

**Secondary Template**: Deep-Sea Structural Testing Protocol

**Steps to Create**:

- Define unified prototype testing roadmap across all engineering disciplines
- Plan 1:50 scale physical model testing in deep-water basins under simulated currents (max 2.5 m/s)
- Define fully instrumented 50-meter prototype segment deployment and monitoring requirements
- Plan full-scale pressurized rail prototype testing under simulated 10-atmosphere conditions
- Establish knowledge management protocols for capturing and disseminating lessons learned
- Define go/no-go criteria for progression from validation to mass production

**Approval Authorities**: Research, Innovation & Prototype Validation Lead, Geotechnical & Seismic Engineering Director, Rail Systems & Transportation Engineering Lead

**Essential Information**:

- Define a unified prototype testing roadmap that spans all engineering disciplines (marine, structural, geotechnical, rail, corrosion, buoyancy) and establishes sequential validation gates before mass production begins
- Plan 1:50 scale physical model testing in deep-water basins under simulated Gibraltar Strait current conditions (maximum 2.5 m/s) to validate hydrodynamic load behavior, pillar-tunnel interaction forces, and buoyancy equilibrium at reduced scale
- Define the fully instrumented 50-meter prototype segment deployment at 100m equivalent depth with minimum 6 months of continuous monitoring, including fiber-optic acoustic sensors, piezoelectric pressure sensors, and autonomous underwater vehicle inspection protocols
- Plan full-scale pressurized rail prototype testing under simulated 10-atmosphere external hydrostatic pressure conditions to validate sealed corridor integrity, climate-controlled track bed precision, and emergency depressurization protocols
- Establish go/no-go criteria for each validation phase (scale model, prototype segment, full-scale rail) with explicit pass/fail thresholds for structural deformation, depth stability, pressurization integrity, and sensor data accuracy
- Define knowledge management protocols for capturing, documenting, and disseminating lessons learned across all engineering disciplines to prevent repeated mistakes and accelerate iterative design improvement
- Establish the Research, Innovation & Prototype Validation Lead role with authority to coordinate the research pipeline, enforce validation gates, and halt progression to mass production if criteria are not met
- Integrate geotechnical and seismic validation requirements into the prototype testing program, including site-specific loading cases calibrated to the Azores-Gibraltar fault zone
- Define environmental and marine ecosystem impact protocols for prototype deployment activities, including cetacean migration period restrictions and real-time acoustic monitoring during testing

**Risks of Poor Quality**:

- Deploying the unprecedented hybrid floating-pillar architecture at full scale without validated prototype data risks catastrophic structural failure at 100m depth, potentially causing €500 million-€2 billion per incident in segment replacement and 6-18 months of redesign delay
- Inadequate scale model testing may miss critical hydrodynamic force interactions between buoyant segments, vertical pillars, and Gibraltar Strait currents, leading to design miscalculations that compound across the full 14 km tunnel span
- Skipping the 6-month continuous monitoring period for the instrumented prototype segment risks undetected micro-fractures, sediment shifts, or depth instability that could escalate into catastrophic failures during full-scale deployment
- Without explicit go/no-go criteria, the project could proceed to mass production of untested tunnel segments, locking in design flaws that are impossible to correct after installation at 100m depth
- Failure to establish cross-disciplinary knowledge management protocols could result in repeated engineering mistakes across marine, structural, and rail teams, adding €500 million-€1.5 billion in rework costs over the 20-year program
- Inadequate pressurized rail prototype testing could lead to seal failures, track geometry deviations, or pressurization system malfunctions in the operational tunnel, endangering passenger safety and requiring €100-500 million per incident in remediation
- Poorly coordinated validation sequencing could create bottlenecks where downstream engineering disciplines (rail, corrosion, buoyancy) wait months for upstream structural validation, compressing the already tight 20-year timeline

**Worst Case Scenario**: The hybrid floating-pillar architecture is deployed at full scale across the 14 km tunnel span without adequate prototype validation, leading to structural failure at 100m depth under Gibraltar Strait hydrodynamic forces. This causes catastrophic tunnel collapse with potential loss of life, environmental disaster from ruptured pressurized rail corridors and concrete segments, total loss of the €40 billion investment, permanent project cancellation, and unlimited liability for the Spanish and Moroccan governments. The failure also damages international confidence in cross-border megaproject governance and eliminates Spain-Morocco's position as global leaders in subsea infrastructure.

**Best Case Scenario**: Comprehensive validation through 1:50 scale model testing, 50-meter instrumented prototype deployment with 6+ months of continuous monitoring, and full-scale pressurized rail prototype testing confirms the structural integrity, depth stability, and operational viability of the hybrid floating-pillar architecture. This enables confident go/no-go decisions for mass production, de-risks the unprecedented design for investors and insurers, reduces the cost of capital by demonstrating technical certainty, and provides validated engineering data that becomes the global benchmark for future subsea infrastructure. Key decisions directly enabled include: final approval of design parameters for mass production, release of tranche-based financing milestones, investor confidence in technical viability, and establishment of Spain-Morocco as pioneers in deep-sea engineering.

**Fallback Alternative Approaches**:

- If full-scale 50-meter prototype deployment at 100m equivalent depth is infeasible due to cost or logistics, deploy a smaller 20-30 meter instrumented segment at 50m depth first to gather baseline structural and buoyancy data, then extrapolate to full-scale conditions using validated scaling factors
- If deep-water basin testing facilities are unavailable or oversubscribed, partner with existing deep-sea research institutions (e.g., oceanographic institutes with large test tanks) or use computational fluid dynamics simulations validated against real-world oceanographic data as interim validation before physical testing
- If the full-scale pressurized rail prototype testing is too costly or time-consuming, test individual critical components (pressurization systems, sealed corridor joints, climate-controlled track beds) separately under simulated conditions before conducting integrated subsystem testing
- If prototype testing timelines threaten the overall project schedule, implement a phased validation approach where the most critical and unprecedented elements (hybrid pillar-buoyancy interaction, depth stability) are validated first, with less novel components validated through existing engineering standards and precedent
- Engage third-party validation firms specializing in deep-sea and offshore engineering (e.g., classification societies like DNV or Lloyd's Register) to supplement internal validation capabilities and provide independent certification of prototype results
- If physical model testing reveals fundamental design issues, pivot to an accelerated computational validation approach using digital twin technology and finite element analysis calibrated against the physical test data, reducing the need for extensive physical re-testing
- Establish a parallel validation track using accelerated life-cycle testing on material samples (polymer encapsulation, sacrificial anodes, buoyant concrete) under simulated 20-year saline exposure conditions to de-risk the durability and corrosion assumptions independently of the structural validation

## Create Document 12: Flooding Risk Management Strategy

**ID**: 12c4c3f0-7f85-4429-9171-3ae350730dc3

**Description**: High-level strategy document addressing the critical gap in flooding emergency protocols for hull breach scenarios at 100m depth with 10 atmospheres of external pressure. Defines the comprehensive flooding risk management approach including redundant hull integrity monitoring with automated breach detection at 500-point intervals, emergency flooding containment compartments at every 200-meter segment, rapid-deployment flood barriers at both tunnel entrance portals, and passenger evacuation protocols using specialized submersible rescue vehicles (50+ passengers per vehicle). Establishes dedicated emergency response vessels on 24/7 standby within 30 minutes of the tunnel corridor and the €100-300 million flooding prevention and response infrastructure budget.

**Responsible Role Type**: Structural Integrity & Lifecycle Maintenance Director

**Primary Template**: Submarine Flooding Emergency Response Framework

**Secondary Template**: Pressurized Enclosure Safety Standards Template

**Steps to Create**:

- Define redundant hull integrity monitoring system with automated breach detection at 500-point intervals
- Plan emergency flooding containment compartments at every 200-meter segment interval
- Design rapid-deployment flood barriers at both tunnel entrance portals
- Define passenger evacuation protocols using specialized submersible rescue vehicles
- Establish dedicated emergency response vessels on 24/7 standby within 30 minutes
- Budget €100-300 million for flooding prevention and response infrastructure

**Approval Authorities**: Structural Integrity & Lifecycle Maintenance Director, Program Director, Offshore Workforce & Safety Director

**Essential Information**:

- Define redundant hull integrity monitoring system with automated breach detection at 500-point intervals, specifying sensor types, placement density, and trigger thresholds for automated shutdown protocols
- Plan emergency flooding containment compartments at every 200-meter segment interval, including bulkhead specifications, sealing mechanisms, and pressure tolerance ratings for 10-atmosphere external conditions
- Design rapid-deployment flood barriers at both tunnel entrance portals (Tarifa and Tangier), including activation mechanisms, deployment time targets, and integration with surface rail network isolation
- Define passenger evacuation protocols using specialized submersible rescue vehicles (50+ passengers per vehicle), including deployment procedures, surface pickup coordination, and emergency medical support
- Establish dedicated emergency response vessels on 24/7 standby within 30 minutes of the tunnel corridor, specifying vessel types, equipment requirements, crew composition, and communication protocols
- Budget €100-300 million for flooding prevention and response infrastructure, broken down by component (monitoring systems, containment compartments, barriers, evacuation fleet, response vessels)
- Address the existential risk of seawater intrusion at 100m depth with 10 atmospheres of external pressure, including worst-case flooding rates and structural failure scenarios
- Specify automated shutdown protocols triggered by breach detection, including pressurized rail corridor depressurization procedures and passenger safety protocols
- Establish insurance coverage specifically for flooding events, including parametric insurance triggers and coverage limits aligned with project financing requirements
- Conduct full-scale flooding simulation exercises annually with joint Spain-Morocco emergency coordination center activation, defining exercise scenarios, evaluation metrics, and improvement protocols

**Risks of Poor Quality**:

- Absence of comprehensive flooding protocols could make the project uninsurable, preventing international consortium financing from being secured and stalling the entire €40 billion initiative
- Inadequate breach detection systems could allow seawater intrusion to go undetected for hours or days, leading to catastrophic structural failure with tunnel section losses valued at €5-15 billion
- Poorly designed containment compartments may fail under 10-atmosphere pressure, rendering flooding mitigation ineffective and exposing passengers to drowning risks in a pressurized submerged environment
- Undefined evacuation protocols could result in mass casualties during a flooding event, creating unlimited legal liability and permanent project cancellation
- Insufficient emergency response vessel coverage could delay rescue operations beyond survivable windows, transforming a manageable incident into a humanitarian disaster
- Inadequate flooding risk management could trigger environmental disasters (fuel spills, hazardous material release) compounding the structural failure with ecological damage and regulatory shutdowns

**Worst Case Scenario**: A major hull breach at 100m depth with 10 atmospheres of external pressure causes catastrophic flooding of multiple tunnel segments within minutes, resulting in total loss of tunnel infrastructure valued at €5-15 billion, potential loss of life among thousands of passengers and workers creating unlimited legal liability, permanent project cancellation, and possible diplomatic crisis between Spain and Morocco over cross-border infrastructure failure.

**Best Case Scenario**: The flooding risk management strategy enables safe construction and 20-year operation with robust prevention systems that detect and contain breaches before catastrophic flooding occurs, validated evacuation protocols that ensure zero fatalities in emergency scenarios, and project insurance that becomes readily available at favorable rates—establishing a new global standard for submerged infrastructure safety and enabling the €40 billion transoceanic tunnel to proceed with confidence from investors and regulators.

**Fallback Alternative Approaches**:

- Adapt existing submarine tunnel flooding protocols from comparable projects (e.g., Channel Tunnel, Seikan Tunnel) and modify them for 100-meter depth and 10-atmosphere conditions, reducing development time while leveraging proven engineering principles
- Develop a simplified 'minimum viable document' covering only the most critical elements initially (automated breach detection and passenger evacuation protocols) with detailed containment and response specifications added in subsequent phases
- Engage specialized submarine engineering firms (e.g., deep-sea oil and gas sector experts) to co-develop the flooding strategy using their existing deep-water containment expertise, reducing the need to develop all specifications from scratch
- Conduct physical flooding simulations at 1:10 scale in deep-water test basins to empirically validate flooding rates and containment effectiveness before finalizing the full documentation, using data-driven insights to inform the strategy


# Documents to Find

## Find Document 1: Strait of Gibraltar Seismic and Geotechnical Data

**ID**: b0e4850d-3c68-47c4-8174-f30818941711

**Description**: Site-specific seismic hazard data, deep-sea borehole sampling results, 3D seismic reflection profiling data, and geotechnical characterization of clay, sand, and weathered bedrock strata at 100m depth below the Strait of Gibraltar seabed. This raw data is essential for the Geotechnical Validation Framework to validate the hybrid floating-pillar architecture and for all structural design decisions. The Azores-Gibraltar seismic transform fault zone proximity makes this data foundational to the entire project.

**Recency Requirement**: Most recent available year; geological data should be current within the last 5 years, with seismic hazard analysis updated to reflect latest IPCC-era climate projections

**Responsible Role Type**: Geotechnical & Seismic Engineering Director

**Steps to Find**:

- Contact Spanish Instituto Geográfico Nacional (IGN) for seismic monitoring data in the Strait of Gibraltar region
- Request deep-sea borehole sampling data from Spanish and Moroccan geological survey agencies
- Access international seismic databases (ISC, USGS) for historical seismic activity in the Azores-Gibraltar transform zone
- Commission new 3D seismic reflection profiling surveys across the full 14 km tunnel corridor
- Obtain existing offshore energy sector geotechnical data from Mediterranean deep-sea operations

**Access Difficulty**: Hard

**Essential Information**:

- Site-specific peak ground acceleration (PGA) values at 100m depth across the full 14 km tunnel corridor
- Liquefaction potential and soil liquefaction classification for clay, sand, and weathered bedrock strata at 100m depth
- Fault rupture probability and seismic source characterization for the Azores-Gibraltar seismic transform fault zone
- 3D seismic reflection profiling data identifying subsurface discontinuities, fault traces, and geological heterogeneity
- Deep-sea borehole sampling results providing geotechnical parameters (shear wave velocity, density, shear strength) at 100m depth
- Probabilistic seismic hazard analysis (PSHA) calibrated to the Azores-Gibraltar fault zone with minimum 2% probability of exceedance in 50 years
- Site-specific seismic loading cases for hybrid floating-pillar architecture validation including vertical, lateral, and uplift forces
- Geotechnical characterization of seabed sediment transport patterns and their interaction with pillar foundations under seismic loading

**Risks of Poor Quality**:

- The entire structural architecture rests on unvalidated assumptions, potentially leading to catastrophic design failure during a seismic event
- Incorrect pillar depth and anchoring methodology selection could result in €3-8 billion in earthquake damage and 12-24 months of reconstruction
- Regulatory rejection of construction permits due to insufficient geotechnical validation, stalling project initiation by 1-2 years
- Inability to pass the geotechnical validation gate, preventing construction mobilization and triggering contract penalties
- Over-engineering of seismic protections due to lack of precise data, adding €500 million-€1.5 billion in unnecessary costs
- Under-design of seismic resistance leading to structural failure during a moderate earthquake (M5.5-6.5), causing €3-8 billion in repairs

**Worst Case Scenario**: A major earthquake (M7.0+, 2% probability) causes catastrophic structural failure of the hybrid floating-pillar architecture, resulting in total loss of tunnel segments valued at €10-20 billion, potential loss of life, permanent project cancellation, and unlimited liability from environmental disaster and loss of life.

**Best Case Scenario**: Comprehensive seismic and geotechnical data validates the hybrid floating-pillar architecture, enabling the geotechnical validation gate to be passed with confidence. This reduces expected annual seismic loss by 60-80%, optimizes pillar design to save €500 million-€1.5 billion in over-engineering, and provides precise site-specific loading cases that ensure structural integrity through a 20-year operational lifespan including seismic events.

**Fallback Alternative Approaches**:

- Commission new 3D seismic reflection profiling surveys across the full 14 km tunnel corridor using specialized deep-water seismic vessels
- Engage subject matter experts from international seismic research institutions to review and validate existing regional data as proxy
- Use conservative design assumptions with elevated safety factors (e.g., 1.5x design acceleration) to compensate for data uncertainty
- Purchase relevant industry standard documents and precedent studies from comparable deep-sea megaprojects in seismically active regions
- Initiate targeted deep-sea borehole sampling campaigns in collaboration with Spanish Instituto Geográfico Nacional (IGN) and Moroccan geological survey agencies
- Access international seismic databases (ISC, USGS) for historical seismic activity data and apply statistical extrapolation to the project site
- Obtain existing offshore energy sector geotechnical data from Mediterranean deep-sea operations as supplementary reference data

## Find Document 2: Existing Spain-Morocco Bilateral Investment Treaties

**ID**: bbaa2316-81d6-4636-9032-5a48243e44d1

**Description**: All existing Bilateral Investment Treaties (BITs) between Spain and Morocco, including investment protection provisions, minimum standard of treatment obligations, expropriation clauses, ISDS mechanisms, and sunset clauses. This raw treaty text is essential for the Cross-Border Governance Framework to assess applicable investment protections and determine whether the proposed consortium qualifies as an 'investment' triggering ISDS mechanisms.

**Recency Requirement**: All currently in-force treaties; any amendments or protocols within the last 10 years

**Responsible Role Type**: International Infrastructure Governance Lawyer

**Steps to Find**:

- Search UNCTAD Investment Policy Hub for Spain-Morocco BIT texts
- Access Spanish Ministry of Economy and Finance treaty database
- Contact Moroccan Ministry of Economy and Finance for BIT documentation
- Review OECD Investment Policy Database for bilateral treaty texts
- Consult international law firm databases for Spain-Morocco investment treaty analysis

**Access Difficulty**: Medium

**Essential Information**:

- Complete inventory of all in-force Spain-Morocco Bilateral Investment Treaties (BITs) with their effective dates and any amendments or protocols from the last 10 years
- Specific investment protection provisions in each treaty, including fair and equitable treatment standards, full protection and security obligations, and national treatment/MFN clauses
- Expropriation clauses detailing direct/indirect expropriation definitions, compensation mechanisms, and prompt/adequate/effective compensation standards
- Investor-State Dispute Settlement (ISDS) mechanisms including arbitration rules (ICSID, UNCITRAL, or ICC), jurisdiction thresholds, and procedural requirements
- Sunset clauses specifying the duration of treaty protections that survive termination or denunciation of the BIT
- Whether the proposed neutral third-party international consortium qualifies as an 'investment' under existing BIT definitions (covering movable/immovable property, shares, intellectual property, and contractual rights)
- Whether the consortium's tranche-based financing structure and public-private partnership elements trigger ISDS mechanisms that could expose the project to investor claims
- Applicable minimum standard of treatment obligations that constrain the governance framework's decision-making authority
- Any existing investment disputes or arbitration awards between Spain and Morocco that establish interpretive precedent for treaty obligations
- Legal analysis of whether the proposed bilateral treaty's penalty clauses and binding commitments are compatible with existing BIT obligations

**Risks of Poor Quality**:

- The bilateral treaty ratification could fail if existing BIT provisions conflict with the proposed governance structure, creating legal incompatibility that stalls the entire project before construction begins
- The consortium structure might inadvertently trigger ISDS claims from private investors claiming treaty violations, exposing the project to billions in arbitration liabilities
- Insufficient understanding of existing investment protections could deter international lenders and development banks whose financing commitments depend on treaty-based legal certainty
- Conflicting treaty obligations between Spain and Morocco could create legal vulnerabilities that undermine the neutral third-party consortium's authority
- Missing sunset clause analysis could result in the project losing investment protections mid-construction if either government terminates or amends existing BITs
- The cross-border governance framework could lack a solid legal foundation, making it susceptible to challenge under existing BIT dispute mechanisms

**Worst Case Scenario**: The entire €40 billion project faces legal invalidation or investor-state arbitration claims arising from conflicts between the proposed consortium governance structure and existing BITs, resulting in billions of euros in liabilities, potential asset freezes, and project cancellation before construction mobilization begins.

**Best Case Scenario**: The existing BITs provide a robust legal foundation that enables smooth parliamentary ratification of the bilateral treaty, protects the consortium's €40 billion investment under established international law standards, and provides clear ISDS pathways that reassure international lenders and private investors, accelerating financing commitments and reducing the cost of capital by 50-100 basis points.

**Fallback Alternative Approaches**:

- Engage specialized international infrastructure governance lawyers (minimum 12 attorneys across Madrid, Rabat, and The Hague) to conduct a comprehensive treaty analysis directly from primary legal sources when the consolidated document proves unavailable
- Request BIT texts directly from the Spanish Ministry of Economy and Finance and Moroccan Ministry of Economy and Finance through formal diplomatic channels
- Access the UNCTAD Investment Policy Hub and OECD Investment Policy Database to retrieve treaty texts and analytical reports as interim references
- Commission a formal legal opinion from a top-tier international law firm specializing in transboundary infrastructure to assess treaty applicability and ISDS exposure
- Use analogous bilateral investment treaties from comparable Spain-Morocco contexts (e.g., Spain's BITs with other Maghreb nations or Morocco's BITs with EU member states) as reference benchmarks for treaty analysis

## Find Document 3: IMO Regulatory Framework for Subsea Installations

**ID**: 41f04887-969b-4001-8c54-dc98e5dda979

**Description**: International Maritime Organization regulatory documents governing artificial installations, submarine structures, and transboundary underwater construction in international waters. Includes UNCLOS Part V provisions on artificial islands and installations, SOLAS regulations for submerged structures, MARPOL environmental protection requirements, and the Barcelona Convention (SPA/BD Protocol, LBS Protocol) for Mediterranean marine environment protection. This raw regulatory text is essential for the Strategic Environmental Compliance Plan and the Cross-Border Governance Framework.

**Recency Requirement**: Current regulations as of 2025-2026; any amendments within the last 5 years

**Responsible Role Type**: International Infrastructure Governance Lawyer

**Steps to Find**:

- Access IMO Legal Committee and Marine Environment Protection Committee documentation
- Retrieve UNCLOS Part V provisions on artificial installations from IMO website
- Obtain Barcelona Convention and its protocols from UNEP Mediterranean Action Plan
- Access SOLAS and MARPOL consolidated texts from IMO regulatory database
- Review IMO guidelines for transboundary underwater construction projects

**Access Difficulty**: Medium

**Essential Information**:

- Identify the exact UNCLOS Part V provisions governing artificial islands and installations that apply to a 100-meter depth submerged tunnel in international waters, including jurisdictional boundaries and consent requirements.
- Detail the specific SOLAS regulations for submerged structures regarding safety standards, structural marking, lighting, and navigation warnings applicable to a tunnel in one of the world's busiest shipping lanes (100,000+ annual vessel transits).
- Quantify the MARPOL environmental protection requirements for construction activities including sediment displacement limits, noise thresholds, and chemical discharge restrictions during pillar installation and segment placement.
- Map the Barcelona Convention (SPA/BD Protocol, LBS Protocol) requirements for Mediterranean marine environment protection to the project's elevated pillar configuration and benthic habitat preservation strategy.
- Specify the precise procedural steps, documentation requirements, and timeline for obtaining IMO transboundary environmental impact assessment approval, including pre-agreed timeline targets and fallback arbitration mechanisms.
- Identify jurisdictional conflicts between Spanish national maritime law, Moroccan coastal regulations, and international IMO frameworks that could create duplicative review processes or legal vulnerabilities.
- Produce a comprehensive regulatory compliance matrix mapping every construction activity to specific IMO, SOLAS, MARPOL, and Barcelona Convention articles with corresponding permitting requirements.

**Risks of Poor Quality**:

- Incorrect interpretation of UNCLOS provisions could lead to unauthorized construction in disputed international waters, triggering legal challenges from third-party nations or international bodies and causing immediate project shutdown.
- Failure to comply with MARPOL environmental discharge standards could result in regulatory fines of €50-500 million and mandatory remediation costing €200 million-€1 billion, eroding the €40 billion budget envelope.
- Inadequate understanding of Barcelona Convention protocols could cause duplicative national environmental reviews, adding 1-3 years of permitting delays and €500 million-€1.5 billion in compliance costs.
- Misinterpretation of SOLAS navigation safety requirements could lead to inadequate tunnel marking or lighting, increasing collision risk with the submerged structure and causing catastrophic environmental disaster with unlimited liability.
- Missing transboundary EIA procedural requirements could invalidate the entire environmental compliance strategy, forcing the project to restart the permitting process from scratch and adding 2-5 years of delay.

**Worst Case Scenario**: Complete project cancellation due to violation of international maritime law and environmental regulations, resulting in total loss of invested capital (€40 billion), unlimited legal liability for environmental damage in the Strait of Gibraltar, and permanent reputational damage to both Spain and Morocco as international infrastructure partners.

**Best Case Scenario**: Accelerated permitting process through precise IMO regulatory compliance, enabling the project to secure transboundary environmental approval within 2-3 years instead of 5+, saving €2-5 billion in carrying costs, establishing a binding legal precedent for future international subsea infrastructure projects, and positioning Spain-Morocco as global leaders in regulatory-compliant deep-sea construction.

**Fallback Alternative Approaches**:

- Engage specialized international maritime law firms with direct IMO regulatory expertise to conduct a targeted regulatory gap analysis and produce a preliminary compliance opinion within 6 months.
- Commission a preliminary legal opinion from the International Tribunal for the Law of the Sea (ITLOS) on applicable jurisdiction and regulatory requirements for the specific tunnel configuration.
- Initiate direct bilateral negotiations with Spain and Morocco to establish a supplementary domestic legal framework that preempts potential IMO jurisdictional conflicts while maintaining international compliance.
- Purchase and retain the full IMO regulatory database, Barcelona Convention archives, and SOLAS/MARPOL consolidated texts for ongoing compliance monitoring and real-time regulatory change tracking.
- Engage the UNEP Mediterranean Action Plan directly for expedited Barcelona Convention protocol interpretation and pre-consultation on the elevated pillar design's environmental compliance pathway.

## Find Document 4: Strait of Gibraltar Maritime Traffic Statistical Data

**ID**: cb441285-9b55-4adb-ad4f-43f9cec93658

**Description**: Annual vessel transit statistics, shipping lane configurations, collision history data, and maritime traffic density measurements for the Strait of Gibraltar. This raw statistical data is essential for the Maritime Traffic Integration Framework to conduct computational fluid dynamics modeling, collision probability analysis, and develop the Temporary Traffic Management Plan. The strait sees over 100,000 vessel transits annually including massive tankers and container ships.

**Recency Requirement**: Most recent 5-year period (2020-2025) to capture current traffic trends and vessel size distributions

**Responsible Role Type**: Maritime Traffic & Navigation Safety Director

**Steps to Find**:

- Request data from Strait of Gibraltar Joint Coordination Center
- Access IMO statistical data on maritime traffic through the Strait of Gibraltar
- Contact Spanish Port Authority (Puertos del Estado) for traffic statistics near Tarifa
- Obtain Moroccan port authority data for Tangier-Med traffic volumes
- Access Lloyd's List or similar maritime intelligence databases for strait traffic analysis

**Access Difficulty**: Medium

**Essential Information**:

- Annual vessel transit counts for the Strait of Gibraltar covering the most recent 5-year period (2020-2025), broken down by vessel type (tankers, container ships, bulk carriers, cruise ships, fishing vessels)
- Shipping lane configurations including width, depth, directional flow patterns, designated traffic separation schemes, and any seasonal lane adjustments
- Collision history data including frequency, severity, locations, and causal factors for incidents involving large vessels in and around the strait
- Maritime traffic density measurements by season, time of day, and geographic zone within the strait, including peak transit periods
- Vessel size distribution statistics (length, beam, draft, deadweight tonnage) to inform hydrodynamic interaction modeling with the tunnel structure
- Current maritime traffic management protocols, speed restrictions, and any existing temporary traffic management plans in effect
- Data on vessel acceleration/deceleration patterns, turning radii, and maneuvering characteristics in the narrow strait confines
- Statistics on maritime traffic growth trends and projected future volumes to inform the 20-year operational lifespan planning

**Risks of Poor Quality**:

- Inadequate or outdated traffic data leads to flawed computational fluid dynamics modeling, resulting in incorrect predictions of tunnel-induced current deflection and altered wave heights in shipping lanes
- Collision probability analysis based on incomplete data underestimates risk, leading to insufficient safety barriers, monitoring systems, and emergency response protocols
- Temporary Traffic Management Plan fails to account for actual traffic patterns, causing shipping disruptions, diplomatic tensions with maritime nations, and potential project shutdowns
- Hydrodynamic design of the tunnel interacts unpredictably with actual vessel traffic, increasing collision risk by 10-30% and potentially causing catastrophic structural damage
- Regulatory rejection of maritime safety plans by the IMO or Strait of Gibraltar Joint Coordination Center due to insufficient data backing, delaying construction permits
- Design of tunnel alignment or pillar placement conflicts with actual shipping lanes, requiring costly redesigns or forcing vessels into more dangerous transit patterns

**Worst Case Scenario**: A major collision between a large tanker or container ship and the submerged tunnel structure causes €500 million-€2 billion in damage, triggers an environmental disaster in the sensitive Strait of Gibraltar marine ecosystem, and results in a 6-12 month construction shutdown costing €1-3 billion in lost revenue and recovery expenses. Unaccounted current deflection effects from the tunnel alter shipping lane conditions unpredictably, increasing collision risk by 10-30% across all vessel categories. Failure to secure permanent shipping lane agreements due to inadequate traffic data halts all construction material transport, adding 6-12 months and €500 million-€1 billion in costs, potentially stalling the entire €40 billion project before critical construction milestones.

**Best Case Scenario**: Comprehensive and precise maritime traffic data enables highly accurate computational fluid dynamics modeling that precisely predicts tunnel-induced current changes, allowing the tunnel design to minimize hydrodynamic interference with shipping lanes. Collision probability analysis yields a robust Temporary Traffic Management Plan that gains rapid approval from the IMO and Strait of Gibraltar Joint Coordination Center. Permanent shipping lane adjustments are negotiated successfully, supporting uninterrupted construction transport and safe 20-year tunnel operations. The tunnel becomes a globally recognized model for safe subsea infrastructure deployment in one of the world's busiest maritime corridors, enhancing the project's reputation and demonstrating Spain-Morocco leadership in cross-border infrastructure innovation.

**Fallback Alternative Approaches**:

- Engage the Strait of Gibraltar Joint Coordination Center directly to access their proprietary vessel traffic database and historical incident records through a formal data-sharing agreement
- Purchase commercial maritime intelligence data from Lloyd's List, MarineTraffic, or VesselFinder covering the 2020-2025 period as a supplementary or primary data source
- Commission an independent maritime traffic survey using aggregated AIS (Automatic Identification System) data from multiple satellite and coastal radar sources to reconstruct traffic patterns
- Partner with academic institutions (e.g., University of Cadiz, Abdelmalek Essaâdi University) that have conducted previous hydrodynamic or traffic studies on the Gibraltar Strait
- Conduct original observational studies using temporary coastal monitoring stations and drone-based vessel tracking to collect primary traffic data for the specific tunnel corridor zone
- Negotiate data-sharing agreements with the Spanish Port Authority (Puertos del Estado) and Moroccan Tanger-Med port authority for localized traffic statistics near the tunnel portal zones
- Engage the International Maritime Organization to commission a dedicated traffic study for the Strait of Gibraltar corridor specifically addressing the tunnel's impact zone

## Find Document 5: IPCC Climate Projections for Mediterranean Region

**ID**: b82bdbd9-4a6f-4c48-8331-b0d984628a51

**Description**: IPCC climate change projection data for the Mediterranean and Atlantic regions including sea level rise projections (SSP2-4.5 and SSP5-8.5 scenarios), storm intensity projections, ocean current change models, and water temperature projections for the period through 2043 and beyond. This raw climate data is essential for integrating climate adaptation into structural design parameters and for the Environmental Compliance Strategy. Sea levels may rise 0.3-0.6m by 2043, and storm intensity may increase 10-20%.

**Recency Requirement**: IPCC Sixth Assessment Report (AR6) data; latest available projections as of 2025-2026

**Responsible Role Type**: Geotechnical & Seismic Engineering Director

**Steps to Find**:

- Access IPCC AR6 Working Group I report data for Mediterranean sea level projections
- Retrieve SSP2-4.5 and SSP5-8.5 scenario data from IPCC Data Distribution Centre
- Obtain Mediterranean climate model projections from national meteorological agencies
- Access ocean current and storm intensity projection models from European climate services
- Commission specialized climate projection analysis for the Strait of Gibraltar region

**Access Difficulty**: Easy

**Essential Information**:

- Sea level rise projections for the Strait of Gibraltar region under SSP2-4.5 and SSP5-8.5 scenarios through 2043 and beyond, with annual time-step resolution
- Projected percentage increases in storm intensity and frequency for the Mediterranean-Atlantic transition zone over the 20-year operational horizon
- Ocean current velocity and direction change models for the Strait of Gibraltar under each IPCC scenario, including seasonal variation data
- Water temperature projections at 100-meter depth for the Strait of Gibraltar corridor, including maximum sustained temperatures and thermal anomaly events
- Data formatted for direct integration into hydrodynamic load models, buoyancy equilibrium calculations, and corrosion rate projection algorithms
- Confidence intervals and uncertainty ranges for each projection parameter to inform structural safety factor calibration
- Projection data validated against regional downscaling models specific to the Iberian-Moroccan coastal zone

**Risks of Poor Quality**:

- Structural design based on static oceanographic assumptions could fail under actual climate conditions, risking €3-6 billion in premature rehabilitation
- Buoyancy equilibrium calculations using underestimated sea level rise could cause tunnel depth variation, compromising rail operations and pillar load distribution
- Hydrodynamic load models with incorrect storm intensity projections could undersize pillar foundations and tunnel profile, creating catastrophic failure risk during extreme weather
- Corrosion protection system lifespan estimates based on wrong water temperature projections could degrade 3-5x faster than designed, requiring €1-4 billion in unplanned upgrades
- The €200-400 million climate adaptation budget could be insufficient, triggering funding shortfalls and timeline delays
- Design life reduction from 20 to 12-15 years would necessitate premature decommissioning or full rehabilitation, creating an unfunded liability of €5-15 billion

**Worst Case Scenario**: Unaccounted climate change impacts—particularly higher-than-projected sea level rise and storm intensity—could reduce the tunnel's structural lifespan from 20 to 12-15 years, requiring premature rehabilitation costing €3-6 billion or causing catastrophic structural failure during an extreme weather event amplified by climate change, potentially resulting in total project loss valued at €40 billion and irreversible environmental damage in the Strait of Gibraltar.

**Best Case Scenario**: Precise IPCC climate projections enable climate-adaptive design that maintains structural integrity and operational capability for the full 20-year lifespan despite changing oceanographic conditions, avoiding €3-6 billion in premature rehabilitation costs, preserving projected revenue streams, and establishing the tunnel as a model for climate-resilient subsea infrastructure worldwide.

**Fallback Alternative Approaches**:

- Use historical oceanographic data from the past 30 years as a conservative baseline if IPCC projections are unavailable or insufficiently resolved for the Strait of Gibraltar
- Design with enlarged safety margins (e.g., +0.5m sea level rise buffer, +30% storm intensity factor) to create climate resilience without precise projection data
- Commission an independent, site-specific climate modeling study focused exclusively on the Strait of Gibraltar using regional downscaling techniques
- Implement adaptive design principles—modular buoyancy adjustment systems, adjustable pillar foundation depths, and replaceable corrosion protection layers—that allow post-construction climate compensation without full redesign
- Negotiate a climate adaptation clause in the bilateral treaty that mandates design parameter updates every 5 years based on the latest IPCC assessment reports

## Find Document 6: Spain and Morocco Rail Gauge and Signaling Standards

**ID**: be926dec-0f97-48cd-a8f1-12c841078d4f

**Description**: Official documentation of Spain's Iberian gauge (1,668mm) and 25kV AC electrification standards, Morocco's standard gauge (1,435mm) and 3kV DC electrification standards, and existing ERTMS signaling system specifications. This raw standards documentation is essential for the Rail Systems Integration strategy to resolve the fundamental gauge incompatibility and design unified signaling and electrification systems.

**Recency Requirement**: Current national rail standards as of 2025-2026; any recent standardization updates

**Responsible Role Type**: Rail Systems & Transportation Engineering Lead

**Steps to Find**:

- Access Spanish Ministry of Transport rail gauge and signaling standards documentation
- Retrieve Moroccan Ministry of Equipment and Transport rail standards
- Obtain ERTMS specification documents from European Railway Agency
- Contact Spanish ADIF and Moroccan ONCF for current rail infrastructure specifications
- Access international rail interoperability standards (UIC, CEN) for gauge transition requirements

**Access Difficulty**: Easy

**Essential Information**:

- Spain's Iberian gauge specification (1,668mm) and 25kV AC electrification system parameters including voltage tolerances, frequency, and catenary standards
- Morocco's standard gauge specification (1,435mm) and 3kV DC electrification system parameters including voltage ranges, power supply infrastructure, and overhead line specifications
- Existing ERTMS signaling system specifications including levels (ETCS Level 1, 2, or 3) deployed on each national network, balise placement standards, and train protection system protocols
- Current national rail standards as of 2025-2026 including any recent standardization updates, regulatory amendments, or infrastructure upgrades that affect interoperability
- International rail interoperability standards (UIC, CEN, ERA) governing gauge transition requirements, signaling system harmonization, and cross-border operational protocols
- Specific interface specifications between surface rail networks and the submerged pressurized rail corridor including gauge transition mechanisms, signaling handover zones, and pressurized environment track bed requirements
- Quantified data on gauge transition infrastructure requirements including dual-gauge track lengths, switching mechanisms, and associated costs (€200-500 million budget reference)
- Electrification system transition specifications including voltage conversion equipment, neutral sections, and power supply continuity requirements at the tunnel entrance/exit points

**Risks of Poor Quality**:

- Incorrect or outdated gauge specifications lead to incompatible rail interfaces, requiring passenger train changes that could cut ridership by 30-50% and reduce annual revenue by €500 million-€1.5 billion
- Inaccurate electrification standards (25kV AC vs 3kV DC) result in incompatible traction systems, forcing either fleet replacement costing billions or operational speed restrictions reducing throughput by 20-40%
- Outdated signaling system specifications cause ERTMS interoperability failures, preventing seamless cross-border operations and triggering costly retrofitting of legacy systems
- Missing recent standardization updates mean the tunnel design locks in obsolete protocols, requiring expensive post-construction modifications to meet current regulatory requirements
- Incomplete interface specifications between surface and submerged rail create safety-critical gaps in the pressurized corridor transition zones, potentially causing catastrophic operational failures

**Worst Case Scenario**: The tunnel becomes functionally isolated because trains cannot operate between Spain and Morocco due to incompatible rail gauges and signaling systems, rendering the €40 billion submerged tunnel unable to fulfill its primary purpose of cross-border high-speed rail connectivity, resulting in total project failure, complete loss of invested capital, and permanent reputational damage to both nations' infrastructure programs.

**Best Case Scenario**: Complete and precise resolution of gauge and signaling incompatibility enables seamless, high-speed rail service between Spain and Morocco with unified ERTMS signaling and compatible electrification systems, maximizing ridership and revenue across the Europe-Africa corridor, validating the entire €40 billion investment, and establishing a global benchmark for international rail interoperability in extreme environments.

**Fallback Alternative Approaches**:

- Engage subject matter experts directly from Spanish ADIF and Moroccan ONCF for targeted technical consultation on current rail specifications and recent updates
- Purchase and review official international rail interoperability standards documents (UIC, CEN, ERA) covering gauge transition requirements and ERTMS deployment specifications
- Initiate a dedicated technical review workshop with rail operators from both nations to validate interface requirements and confirm electrification transition protocols
- Commission a specialized interoperability feasibility study focusing specifically on gauge transition infrastructure and signaling system harmonization for the submerged tunnel context
- Access Spanish Ministry of Transport and Moroccan Ministry of Equipment and Transport official documentation portals for the most current national rail standards and any pending regulatory changes

## Find Document 7: Strait of Gibraltar Marine Ecosystem Baseline Data

**ID**: 23d0ed4e-53fb-4071-a26a-fa83cfc06c77

**Description**: Existing marine ecosystem data including cetacean migration pattern studies, benthic habitat mapping, water quality parameters, and sediment dynamics measurements for the Strait of Gibraltar corridor. This raw baseline data is essential for the Environmental Compliance Strategy and for commissioning comprehensive marine ecosystem baseline studies. The strait is home to critical cetacean migratory routes and fragile benthic habitats.

**Recency Requirement**: Most recent available studies; ideally within the last 5 years, with 24-month field data collection required before construction

**Responsible Role Type**: Environmental Compliance & Marine Ecology Director

**Steps to Find**:

- Access IUCN Mediterranean marine ecosystem data and cetacean population studies
- Retrieve Convention on Migratory Species (CMS) data on cetacean migration through Strait of Gibraltar
- Obtain Spanish and Moroccan marine biodiversity survey data from national environmental agencies
- Access European Environment Agency marine ecosystem databases for the Mediterranean
- Contact research institutions (e.g., University of Barcelona, Mohammed V University) for existing marine ecology studies

**Access Difficulty**: Medium

**Essential Information**:

- Identify current cetacean migration routes, seasonal timing (March-May and September-November), and population density across the 14 km Strait of Gibraltar tunnel corridor at 100m depth
- Quantify baseline water quality parameters: turbidity, salinity, dissolved oxygen, and pollutant concentrations at the tunnel alignment and offshore platform sites
- Map existing benthic habitat types, ecological sensitivity zones, and fragile ecosystem locations across all pillar installation points on the seabed
- Measure sediment dynamics: transport rates, grain size distribution, and stability indices at 100m depth to predict pillar-seabed interaction and long-term scour potential
- Establish marine mammal disturbance thresholds (noise levels, vessel traffic intensity) for construction activities based on existing CMS and IUCN protected species data
- Document existing marine biodiversity populations including endangered species distributions that would be affected by offshore platform construction and tunnel segment placement
- Define 24-month field data collection protocols for cetacean migration patterns, seasonal habitat use, and baseline acoustic environment measurements

**Risks of Poor Quality**:

- Outdated or incomplete cetacean migration data could cause construction during critical migration periods, triggering regulatory shutdowns, environmental fines of €50-500 million, and litigation delays of 1-3 years
- Insufficient benthic habitat mapping risks placing pillars on fragile ecosystems, requiring mandatory remediation costing €200 million-€1 billion and causing irreversible ecological damage
- Missing sediment dynamics data could lead to unexpected seabed erosion around pillar foundations, compromising structural stability and requiring expensive redesigns or additional anchoring
- Poor water quality baseline data may miss existing pollution thresholds, resulting in non-compliance with IMO environmental standards and potential project stoppage by regulatory authorities
- Lack of comprehensive marine biodiversity data could violate international conservation agreements (CMS, Barcelona Convention), exposing the project to injunctions from environmental NGOs and international courts

**Worst Case Scenario**: Inadequate baseline data leads to irreversible damage to protected cetacean migration routes and critical benthic habitats, triggering international legal action, permanent project cancellation by regulatory bodies, and total loss of the €40 billion investment with catastrophic reputational damage to both Spain and Morocco as cross-border infrastructure partners.

**Best Case Scenario**: Comprehensive, high-quality baseline data enables seamless environmental permitting within the target timeline, validates the elevated pillar design's ecological compatibility with benthic habitats, and establishes the project as a global benchmark for sustainable marine infrastructure—accelerating approval processes, securing the €200-500 million marine mitigation fund, and preserving critical marine ecosystems while enabling uninterrupted construction progress.

**Fallback Alternative Approaches**:

- Commission targeted rapid-assessment marine surveys focusing exclusively on critical cetacean migration corridors and high-sensitivity benthic zones if comprehensive baseline data is unavailable within the required timeframe
- Leverage existing IMO and European Environment Agency databases to access preliminary transboundary environmental data as an interim baseline while field data collection proceeds
- Partner with the University of Barcelona and Mohammed V University to launch immediate supplementary field studies to fill specific data gaps within a 6-month accelerated timeline
- Deploy satellite-based ocean monitoring and remote sensing technologies to generate temporary baseline data on marine mammal presence and seabed conditions while in-situ 24-month field collection is underway
- Implement a phased environmental study approach beginning with seasonal cetacean migration monitoring to generate immediate actionable data for construction scheduling decisions

## Find Document 8: EUR-MAD Currency Hedging and Foreign Exchange Framework

**ID**: 78fe4590-2daf-4826-952a-0dc0e79288a7

**Description**: Existing foreign exchange market data, currency hedging instrument specifications, Morocco's foreign exchange control regulations, and MAD convertibility/repatriation rights documentation. This raw financial data is essential for the International Consortium Financing Framework to design the currency hedging program covering at least 70% of MAD-denominated expenditures and to address Morocco's foreign exchange controls.

**Recency Requirement**: Current foreign exchange market data as of 2025-2026; Morocco's foreign exchange regulations current within last 2 years

**Responsible Role Type**: International Finance & Capital Director

**Steps to Find**:

- Access Bank of Spain and Bank Al-Maghrib foreign exchange data and regulations
- Retrieve Morocco's foreign exchange control legislation and MAD convertibility rules
- Obtain EUR-MAD forward contract and swap pricing data from international banks
- Access IMF Article IV consultation reports on Morocco for foreign exchange policy analysis
- Consult international banking facilities for MAD hedging instrument availability and terms

**Access Difficulty**: Medium

**Essential Information**:

- Current EUR-MAD exchange rate data and historical volatility patterns (2025-2026 baseline) to quantify the 10-20% fluctuation exposure that could cost €200-800 million over the 20-year horizon
- Specifications, pricing, and availability of forward contracts and currency swaps from international banking facilities capable of covering at least 70% of projected MAD-denominated expenditures across the full 20-year construction period
- Morocco's foreign exchange control legislation, including MAD convertibility rules, repatriation rights for foreign investors, and any capital flow restrictions that could impede the hedging program or fund transfers
- IMF Article IV consultation reports on Morocco providing authoritative analysis of foreign exchange policy, reserve adequacy, and regulatory stability
- Maximum available hedging tenors from counterparties to determine whether instruments can span the full 20-year project lifecycle or require rolling short-term contracts
- Counterparty risk parameters and creditworthiness assessments for international banks providing hedging instruments
- Documentation of any regulatory constraints on cross-border currency flows between Spain and Morocco, including withholding taxes, transaction limits, or reporting requirements
- Analysis of Morocco's foreign exchange reserve levels and their capacity to support large-scale hedging operations without market disruption

**Risks of Poor Quality**:

- Inadequate hedging coverage leaving 30%+ of MAD expenditures exposed to currency fluctuations, resulting in €200-800 million in additional costs that erode the €40 billion budget envelope
- Failure to identify Morocco's foreign exchange control restrictions could render the hedging strategy legally unenforceable or prevent actual conversion and repatriation of funds, stalling Moroccan-side construction activities
- Using inappropriate or mismatched hedging instruments (e.g., wrong tenor, wrong notional) could create additional financial exposure rather than mitigating risk
- Not accounting for potential changes in Morocco's FX regulations over the 20-year horizon could invalidate the hedging framework mid-project, requiring costly restructuring
- Insufficient hedging tenor coverage forcing the project to roll short-term contracts at unfavorable rates, adding cumulative costs and uncertainty to long-term budget forecasting

**Worst Case Scenario**: Complete failure of the hedging strategy due to Morocco imposing sudden capital controls or rendering MAD non-convertible, combined with a 20% MAD depreciation against EUR, resulting in €800 million+ in unrecoverable additional costs, triggering covenant breaches with private equity investors, causing a funding cliff that halts construction for 6-12 months and costs €500 million-€1 billion in idle workforce and remobilization expenses.

**Best Case Scenario**: A robust, fully documented hedging framework covering 70%+ of MAD exposure at optimal market rates, with clear legal understanding of Morocco's convertibility and repatriation rights, enabling predictable cross-border costs, protecting the €40 billion budget envelope from currency volatility, and maintaining investor confidence through transparent FX risk management across the entire 20-year construction horizon.

**Fallback Alternative Approaches**:

- Engage the IMF directly for technical assistance and policy advice on Morocco's foreign exchange framework to supplement or replace commercial banking data sources
- Implement a natural hedging strategy by negotiating Moroccan-side contracts in EUR where possible, or matching MAD revenues with MAD costs to reduce net exposure below the 70% threshold
- Establish a local Moroccan banking subsidiary or special purpose vehicle to manage FX risk domestically, bypassing cross-border conversion restrictions entirely
- Purchase standardized FX risk insurance products from multilateral agencies (e.g., MIGA, World Bank) that provide political risk coverage including currency inconvertibility
- Adopt a simplified rolling 3-year hedging cycle using the most liquid EUR-MAD forward contracts available, accepting some basis risk in exchange for guaranteed instrument availability and lower counterparty complexity

## Find Document 9: Strait of Gibraltar Oceanographic and Current Data

**ID**: 69af898a-be56-4a7a-9e83-6d50088597ce

**Description**: Oceanographic data including current velocity profiles, wave height statistics, tidal patterns, water temperature data, and sediment transport dynamics for the Strait of Gibraltar at 100m depth. This raw oceanographic data is essential for the Hydrodynamic Load Mitigation Strategy, the buoyancy engineering design, and the climate adaptation integration. The strait's unique Atlantic-Mediterranean exchange creates complex current dynamics that directly affect structural loads.

**Recency Requirement**: Most recent 5-year period (2020-2025) to capture current oceanographic conditions and trends

**Responsible Role Type**: Marine Construction & Offshore Engineering Lead

**Steps to Find**:

- Access oceanographic data from Spanish Instituto Español de Oceanografía (IEO)
- Retrieve Moroccan oceanographic monitoring data from Institut National de Recherche Océanographique
- Obtain current velocity and wave height data from Strait of Gibraltar Joint Coordination Center
- Access European Copernicus Marine Service oceanographic datasets for the Strait region
- Commission specialized oceanographic survey for 100m depth current and wave conditions

**Access Difficulty**: Medium

**Essential Information**:

- Identify the 5 primary strategic levers rated Critical or High: Pillar Architecture (67dbe525-04b7-4874-998e-f333c57dc322), Construction Deployment (5dba75a3-15fc-4437-84ff-6297bb16cd18), Cross-Border Governance (5c9b4b1e-0aab-4449-b206-bcac50c27696), Environmental Compliance Strategy (55d29a38-5b46-4ee4-8a8c-dac3a6d1ea00), and Phasing and Risk Strategy (5fe21aa9-baba-4a09-b014-83248564e8c1)
- Detail the 3 strategic choices, specific trade-offs, and strategic connections (synergies and conflicts) for each of the 14 levers
- Specify the core decision, justification, and criticality rating (Critical/High/Medium) for each lever to establish prioritization and resource allocation
- Document the fundamental tensions addressed: structural integrity vs seabed disturbance, speed vs cost containment, national sovereignty vs project efficiency, and regulatory approval vs construction velocity
- Provide the specific lever IDs for cross-referencing across project documents, risk registers, and the assumptions.md dependency matrix

**Risks of Poor Quality**:

- Misclassification of lever criticality (e.g., treating Medium levers as Strategic) leads to misallocated €40 billion budget and management attention across the 20-year horizon
- Incomplete trade-off analysis between Pillar Architecture and Environmental Compliance Strategy causes permitting delays and costly design rework of gravity-based pillars
- Missing conflict identification between Cross-Border Governance and Phasing Strategy creates diplomatic deadlock at the construction midpoint where both jurisdictions must contribute resources
- Absence of specific lever IDs breaks traceability between strategic decisions and the technical risks documented in assumptions.md (e.g., Risk 3 regarding hybrid floating-pillar uncertainty)
- Unvalidated strategic connections (e.g., not realizing Buoyancy Engineering constrains Subsea Structural Surveillance) create cascading technical failures and maintenance blind spots

**Worst Case Scenario**: The project adopts the wrong strategic path (e.g., Pioneer's Gambit with parallel construction and private BOT governance) due to incomplete decision analysis, resulting in structural failure of the unprecedented hybrid floating-pillar architecture at 100m depth, diplomatic breakdown between Spain and Morocco, and total loss of the €40 billion investment with potential catastrophic safety incidents and environmental disaster.

**Best Case Scenario**: The document serves as a comprehensive strategic blueprint enabling perfect alignment of all 14 levers under the Builder's Foundation path, resulting in successful construction of the world's first transoceanic submerged tunnel on time and within the €40 billion budget, establishing Spain-Morocco as global leaders in subsea infrastructure and creating a legacy engineering achievement of historic proportions.

**Fallback Alternative Approaches**:

- If full consensus on all 14 levers cannot be achieved, prioritize only the 5 primary levers (Pillar Architecture, Construction Deployment, Cross-Border Governance, Environmental Compliance, Phasing) as the minimum viable strategic framework, deferring Medium levers to operational planning phases
- Engage external megaproject strategic consultants (e.g., McKinsey Infrastructure, Arup Advisory) to independently validate the criticality ratings and strategic choice trade-offs against industry benchmarks
- Conduct facilitated workshops with Spanish and Moroccan government stakeholders to validate the Builder's Foundation strategic choices and resolve any conflicts between the 5 primary levers before finalizing the strategic decisions document
- If the Builder's Foundation path cannot be agreed upon, adopt the alternative scenarios from scenarios.md (Pioneer's Gambit or Consolidator's Anchor) as fallback strategic frameworks, adjusting the 14 lever decisions and trade-offs accordingly

## Find Document 10: Submarine HVDC Cable Technology Specifications

**ID**: 99f09b28-f388-437a-891f-8b4681aac199

**Description**: Technical specifications and market data for submarine HVDC (High Voltage Direct Current) cable systems including capacity ratings, installation methodologies, depth capabilities, and cost benchmarks. This raw technical data is essential for the Energy Infrastructure Strategy to design the submarine cable connections between the tunnel and Spanish and Moroccan national grids. The project requires an estimated 50-100 MW continuous power supply at 100m depth.

**Recency Requirement**: Current technology specifications as of 2025-2026; latest commercial HVDC cable product data

**Responsible Role Type**: Offshore Energy Infrastructure Engineer

**Steps to Find**:

- Access submarine HVDC cable manufacturer specifications (e.g., Prysmian, Nexans, NKT)
- Retrieve existing submarine HVDC project data (e.g., North Sea Link, Viking Link) for reference
- Obtain deep-sea cable installation methodology documentation from offshore engineering firms
- Access European grid interconnection specifications for HVDC submarine connections
- Contact national grid operators for submarine cable interface requirements

**Access Difficulty**: Medium

**Essential Information**:

- Specific HVDC cable voltage and current ratings capable of transmitting 50-100 MW continuous power across the Strait of Gibraltar at 100m depth
- Manufacturer specifications from Prysmian, Nexans, and NKT for submarine HVDC cables rated for 100-meter water depth with pressure and corrosion tolerances
- Installation methodology documentation for deep-sea (100m) HVDC cable laying, including vessel requirements, burial techniques, and depth-rated equipment
- Cost benchmarks per kilometer and per MW capacity for submarine HVDC cable systems of the required scale (estimated 14+ km span)
- Reference project data from comparable submarine HVDC installations (North Sea Link, Viking Link) for feasibility validation and risk calibration
- Interface specifications between submarine HVDC cables and Spanish/Moroccan national grid connection points, including converter station requirements
- Cable routing constraints, minimum bend radii, and landing station specifications for the Strait of Gibraltar crossing
- Maintenance accessibility requirements and expected lifespan specifications for submerged HVDC cables at 100m depth
- Environmental and marine impact considerations for cable route placement, including cetacean migration corridor conflicts and benthic habitat disturbance thresholds
- Power loss estimates and efficiency ratings for HVDC transmission over 14+ km at 100m depth to validate the 50-100 MW continuous demand model

**Risks of Poor Quality**:

- Incorrect voltage or current ratings could result in insufficient power delivery to the pressurized rail corridor, ventilation, and surveillance systems, rendering the tunnel inoperable
- Depth rating mismatches could cause cable insulation failure at 100m depth, leading to catastrophic power loss and potential safety hazards for submerged passengers
- Cost underestimation in cable specifications could breach the €40 billion budget envelope, especially given the €1-2 billion energy infrastructure budget allocation
- Installation methodology incompatibility with deep-sea conditions could cause project delays of 6-12 months and €500 million-€1 billion in idle costs
- Interface incompatibility with Spanish or Moroccan national grids could prevent tunnel operation entirely, resulting in zero revenue and €500 million-€1 billion in annual lost revenue
- Using outdated or unproven HVDC technology could lead to obsolescence or failure before the 20-year operational lifespan ends, requiring €1-4 billion in premature replacement

**Worst Case Scenario**: Complete failure of the submarine HVDC energy supply system could render the entire €40 billion tunnel project inoperable, resulting in total capital loss, potential loss of life for passengers trapped in the pressurized submerged corridor, and catastrophic environmental damage from uncontrolled systems at 100m depth.

**Best Case Scenario**: Precise HVDC cable specifications enable seamless integration of a reliable, future-proof energy infrastructure that supports the tunnel's full 20-year operational life with minimal maintenance, ensuring continuous high-speed rail service between Spain and Morocco and validating the project as a global model for subsea megaproject energy systems.

**Fallback Alternative Approaches**:

- Engage directly with HVDC cable manufacturers (Prysmian, Nexans, NKT) for custom engineering specifications tailored to the 100m depth and 50-100 MW requirements
- Commission a dedicated energy infrastructure feasibility study that includes computational modeling of power demand, cable routing optimization, and grid interface analysis
- Use reference projects (North Sea Link, Viking Link) as engineering proxies with validation from offshore energy consultants to derive approximate specifications
- Partner with Spanish and Moroccan national grid operators to obtain interface specifications and grid connection requirements directly from infrastructure planners
- Engage a specialized offshore energy consultancy to conduct a comprehensive energy audit and produce a detailed HVDC cable specification report as an interim deliverable