**Purpose:** business

**Purpose Detailed:** Infrastructure project connecting Spain and Morocco with a submerged tunnel system.

**Topic:** Transoceanic Submerged Tunnel Project