This plan involves money.

## Currencies

- **EUR:** The project budget is defined in EUR, and it spans multiple European countries.
- **MAD:** Local currency for transactions in Morocco.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting and reporting. Local currencies may be used for local transactions in Morocco. Hedging strategies should be considered to mitigate exchange rate fluctuations.