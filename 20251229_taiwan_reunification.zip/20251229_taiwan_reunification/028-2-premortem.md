A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The Taiwanese population will largely accept reunification after a well-executed PR campaign and economic incentives. | Conduct a large-scale, anonymous public opinion poll in Taiwan, focusing on attitudes towards reunification under various conditions. | The poll reveals that over 60% of the Taiwanese population opposes reunification under any conditions, even with significant economic benefits. |
| A2 | China can effectively deter military intervention from the US or other nations through a show of force and diplomatic assurances. | Conduct a series of wargaming simulations with realistic US and allied force deployments and response strategies. | The wargaming simulations consistently show that US intervention, even limited, would significantly disrupt or delay the reunification process, leading to unacceptable casualties and economic damage. |
| A3 | The transition to a unified economic system (currency, regulations, etc.) can be achieved smoothly and without significant disruption to the Taiwanese economy. | Develop a detailed economic model simulating the impact of currency conversion, regulatory changes, and trade integration on various sectors of the Taiwanese economy. | The economic model predicts a significant recession in Taiwan (GDP decline of >10%) due to capital flight, business closures, and disruption of international trade, even with substantial Chinese investment. |
| A4 | The existing Taiwanese infrastructure (power grids, communication networks, transportation systems) can be readily integrated with mainland China's systems without significant disruptions or compatibility issues. | Conduct a detailed technical assessment of key Taiwanese infrastructure systems, comparing them to their mainland Chinese counterparts and identifying potential integration challenges. | The assessment reveals significant incompatibilities and technical hurdles that would require extensive and costly upgrades, leading to prolonged service disruptions and potential system failures. |
| A5 | Key Taiwanese elites (business leaders, politicians, academics) will eventually cooperate with the reunification process, even if they initially express reservations. | Engage in discreet backchannel communications with influential Taiwanese figures to gauge their willingness to participate in a transitional government or advisory council. | The majority of key Taiwanese elites refuse to participate in any form of collaboration with the Chinese government, fearing for their personal safety, economic interests, or political future. |
| A6 | The international legal framework is sufficiently ambiguous or supportive enough to allow China to proceed with reunification without facing insurmountable legal challenges. | Commission a comprehensive legal analysis by a panel of international law experts, focusing on the legal justifications for reunification and potential challenges under international law. | The legal analysis concludes that the proposed reunification plan violates fundamental principles of international law, such as the right to self-determination, and is likely to face strong legal challenges in international courts. |
| A7 | The Chinese military can quickly and decisively neutralize any internal resistance from the Taiwanese military and security forces. | Conduct a detailed assessment of the Taiwanese military's capabilities, training, and morale, and compare them to the Chinese military's strengths and weaknesses in a potential conflict scenario. | The assessment reveals that the Taiwanese military possesses significant defensive capabilities, advanced weaponry, and a strong will to resist, making a swift and decisive victory for the Chinese military unlikely and potentially resulting in a protracted and costly conflict. |
| A8 | The international business community will prioritize economic opportunities in a unified Taiwan over concerns about human rights and political freedom. | Survey major international corporations with significant investments in Taiwan to gauge their willingness to continue operating in a unified Taiwan under Chinese rule, considering potential reputational risks and ethical concerns. | A significant number of international corporations indicate that they would withdraw or significantly reduce their investments in Taiwan due to concerns about human rights, political freedom, and the rule of law, leading to a substantial economic downturn. |
| A9 | The Taiwanese legal system can be effectively integrated into the Chinese legal system without creating significant disruptions or undermining the rule of law. | Conduct a comparative analysis of the Taiwanese and Chinese legal systems, identifying key differences in legal principles, procedures, and enforcement mechanisms, and assessing the potential impact of integrating the two systems. | The analysis reveals fundamental incompatibilities between the two legal systems, particularly regarding judicial independence, due process, and protection of individual rights, making a seamless integration impossible and potentially undermining the rule of law in Taiwan. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Economic Black Hole | Process/Financial | A3 | Financial Transition Planner | CRITICAL (20/25) |
| FM2 | The Straitjacket Strategy | Technical/Logistical | A2 | Head of Engineering | CRITICAL (15/25) |
| FM3 | The Hearts and Minds Meltdown | Market/Human | A1 | Permitting Lead | CRITICAL (25/25) |
| FM4 | The Legal Quagmire | Process/Financial | A6 | Financial Transition Planner | CRITICAL (20/25) |
| FM5 | The Infrastructure Implosion | Technical/Logistical | A4 | Head of Engineering | CRITICAL (25/25) |
| FM6 | The Elite Exodus | Market/Human | A5 | Permitting Lead | CRITICAL (20/25) |
| FM7 | The Rule of Law Rot | Process/Financial | A9 | Financial Transition Planner | CRITICAL (20/25) |
| FM8 | The Island Inferno | Technical/Logistical | A7 | Head of Engineering | CRITICAL (25/25) |
| FM9 | The Corporate Cold Shoulder | Market/Human | A8 | Permitting Lead | CRITICAL (20/25) |


### Failure Modes

#### FM1 - The Economic Black Hole

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A3
- **Owner**: Financial Transition Planner
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption of a smooth economic transition proves catastrophically false. The forced currency conversion from TWD to CNY triggers massive capital flight as Taiwanese businesses and individuals lose confidence in the new system. The imposition of Chinese regulations, often incompatible with existing Taiwanese business practices, leads to widespread bankruptcies and unemployment. International trade grinds to a halt as Taiwanese companies struggle to adapt to the new system and face increased tariffs and trade barriers. The promised Chinese investment fails to materialize quickly enough to offset the economic devastation. The initial stabilization fund proves woefully inadequate to address the scale of the crisis. The black market explodes as people try to circumvent the new regulations and preserve their wealth. Corruption becomes rampant as officials exploit the chaotic situation for personal gain. The Taiwanese economy spirals into a deep recession, leading to widespread poverty, social unrest, and a complete loss of faith in the reunification project. The Chinese government is forced to pour in massive amounts of aid, but it's too little, too late to salvage the situation. The project becomes a massive drain on the Chinese economy, fueling resentment on the mainland and further destabilizing the region.

##### Early Warning Signs
- Capital flight from Taiwan exceeds $5 billion USD within the first month of the announcement.
- The TWD/CNY exchange rate on the black market deviates by more than 5% from the official rate.
- Unemployment in Taiwan rises above 10% within the first quarter after reunification.

##### Tripwires
- TWD/CNY black market exchange rate >= 1:5.5 within 30 days of conversion.
- Taiwanese GDP decreases by >= 5% in the first quarter post-reunification.
- Unemployment rate in Taiwan >= 8% within 6 months of reunification.

##### Response Playbook
- Contain: Immediately inject additional capital into the Taiwanese economy to stabilize the currency and support key industries.
- Assess: Conduct an emergency audit of the financial transition plan to identify critical flaws and areas for improvement.
- Respond: Implement a revised economic strategy that prioritizes Taiwanese businesses, offers tax breaks, and eases regulatory burdens.


**STOP RULE:** Taiwanese GDP declines by more than 15% within the first year, triggering uncontrollable social unrest and economic collapse.

---

#### FM2 - The Straitjacket Strategy

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption that China can deter US intervention proves fatally flawed. Despite China's show of force, the US, backed by key allies, responds decisively to the reunification attempt. A naval blockade is imposed on Taiwan, crippling its economy and preventing the flow of essential goods. Cyberattacks cripple critical infrastructure, including power grids, communication networks, and financial systems. The Taiwanese military, bolstered by US intelligence and equipment, mounts a fierce resistance, inflicting heavy casualties on the invading forces. The conflict escalates rapidly, drawing in other regional powers and threatening a wider war. China's supply lines are stretched thin, and logistical bottlenecks hamper the deployment of troops and resources. The international community condemns China's actions, imposing crippling sanctions that further isolate the country. The reunification project grinds to a halt as the conflict drags on, resulting in massive casualties, economic devastation, and a complete loss of international credibility. The Chinese government faces mounting pressure from within and without to de-escalate the conflict and seek a peaceful resolution. The dream of reunification turns into a nightmare of war and destruction.

##### Early Warning Signs
- US naval presence in the Taiwan Strait increases significantly (more than 3 aircraft carrier groups).
- The US announces a formal defense pact with Taiwan.
- Major cyberattacks targeting Chinese infrastructure originate from US or allied sources.

##### Tripwires
- US military aid to Taiwan increases by >= 50% within 6 months.
- US and allied naval forces conduct joint exercises within 12 nautical miles of Taiwan.
- Confirmed reports of US military advisors deployed to Taiwan.

##### Response Playbook
- Contain: Immediately reinforce defenses around key strategic locations and prepare for a protracted conflict.
- Assess: Conduct a comprehensive assessment of the military situation, including troop strength, equipment levels, and logistical capabilities.
- Respond: Initiate backchannel diplomatic negotiations with the US and other key players to de-escalate the conflict and seek a peaceful resolution.


**STOP RULE:** Direct military engagement between Chinese and US forces results in significant casualties on both sides, triggering a high risk of nuclear escalation.

---

#### FM3 - The Hearts and Minds Meltdown

- **Archetype**: Market/Human
- **Root Cause**: Assumption A1
- **Owner**: Permitting Lead
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
The assumption that a PR campaign and economic incentives can sway the Taiwanese population proves disastrously wrong. The Taiwanese people, deeply attached to their democratic values and distinct cultural identity, reject reunification en masse. The PR campaign is seen as blatant propaganda and is widely ridiculed. The economic incentives are viewed as bribes and fail to win over hearts and minds. Instead, a wave of civil disobedience sweeps across the island. Protests erupt in major cities, paralyzing the government and disrupting daily life. Underground resistance movements emerge, engaging in acts of sabotage and violence. The Taiwanese diaspora launches a global campaign to condemn China's actions and rally international support. The Chinese government responds with increasing repression, further alienating the population and fueling the resistance. The information control strategy backfires, as people find ways to circumvent censorship and share information online. The international community condemns China's human rights abuses, imposing sanctions and isolating the country. The reunification project becomes a quagmire of social unrest, political instability, and international condemnation. The Chinese government is forced to reconsider its approach, but the damage is already done. The dream of a unified China is shattered by the unwavering resistance of the Taiwanese people.

##### Early Warning Signs
- Participation in pro-independence rallies in Taiwan exceeds 10% of the population.
- Online support for independence movements increases by more than 50% in a month.
- Significant increase in reports of civil disobedience and acts of sabotage in Taiwan.

##### Tripwires
- Public approval of reunification in Taiwan <= 20% based on independent polling.
- Daily protest participation >= 5% of the Taiwanese population.
- Confirmed acts of sabotage targeting critical infrastructure >= 10 per week.

##### Response Playbook
- Contain: Immediately de-escalate the situation by withdrawing troops from the streets and releasing political prisoners.
- Assess: Conduct a thorough review of the PR campaign and economic incentives to identify why they failed to resonate with the Taiwanese population.
- Respond: Initiate a genuine dialogue with Taiwanese representatives to address their concerns and negotiate a mutually acceptable solution.


**STOP RULE:** Uncontrollable social unrest leads to widespread violence and the collapse of civil order, making peaceful reunification impossible.

---

#### FM4 - The Legal Quagmire

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A6
- **Owner**: Financial Transition Planner
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption of a favorable or at least ambiguous international legal landscape proves disastrously wrong. The International Court of Justice (ICJ) issues a binding ruling condemning the reunification as a violation of Taiwan's right to self-determination. The ruling triggers a cascade of legal challenges in national courts around the world, targeting Chinese assets and individuals involved in the project. International organizations, such as the UN Human Rights Council, launch investigations into alleged human rights abuses in Taiwan. China faces mounting legal pressure and diplomatic isolation. The cost of defending the reunification in international courts skyrockets, draining the project's budget. Businesses and investors become increasingly wary of dealing with China, fearing legal repercussions. The legal quagmire paralyzes the reunification process, leading to indefinite delays and a complete loss of international credibility. The Chinese government is forced to defend its actions on multiple fronts, diverting resources and attention from other critical priorities. The project becomes a symbol of China's disregard for international law, further damaging its reputation on the world stage.

##### Early Warning Signs
- The ICJ agrees to hear a case challenging the legality of the reunification.
- A major international law firm withdraws from representing China in the reunification process.
- Several countries announce their intention to impose sanctions based on legal grounds.

##### Tripwires
- ICJ issues a preliminary injunction against the reunification.
- Number of countries imposing legal sanctions >= 5.
- Legal costs exceed $1 billion USD within the first year.

##### Response Playbook
- Contain: Immediately engage a team of top international lawyers to develop a robust legal defense strategy.
- Assess: Conduct a comprehensive review of the legal risks and potential liabilities associated with the reunification.
- Respond: Initiate diplomatic negotiations with key countries to seek a compromise and mitigate legal challenges.


**STOP RULE:** The ICJ issues a final, binding ruling condemning the reunification as illegal under international law, making further progress impossible.

---

#### FM5 - The Infrastructure Implosion

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A4
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
The assumption of seamless infrastructure integration proves to be a catastrophic miscalculation. The attempt to merge Taiwan's power grid with mainland China's results in a series of cascading failures, plunging major cities into darkness. Communication networks collapse due to incompatible protocols and cybersecurity vulnerabilities. Transportation systems grind to a halt as trains derail and airports shut down due to technical glitches. The integration process is plagued by delays, cost overruns, and technical snafus. Taiwanese engineers, familiar with their own systems, struggle to adapt to the Chinese models. Chinese engineers, unfamiliar with the Taiwanese infrastructure, make critical errors. The lack of coordination and communication between the two sides exacerbates the problems. The infrastructure implosion paralyzes the Taiwanese economy, disrupts daily life, and fuels widespread anger and resentment. The Chinese government is forced to divert massive resources to repair the damage, but it's too little, too late to restore public confidence. The reunification project becomes a symbol of incompetence and mismanagement.

##### Early Warning Signs
- Major power outages in Taiwan become increasingly frequent and widespread.
- Communication networks experience significant disruptions and slowdowns.
- Transportation systems experience a series of accidents and delays.

##### Tripwires
- Power outages affect >= 50% of Taiwan's population for more than 24 hours.
- Communication networks are disrupted for >= 72 hours.
- Transportation systems are paralyzed for >= 48 hours.

##### Response Playbook
- Contain: Immediately activate emergency backup systems and deploy technical teams to address the most critical infrastructure failures.
- Assess: Conduct a thorough assessment of the root causes of the infrastructure implosion and identify areas for improvement.
- Respond: Implement a revised integration plan that prioritizes stability and reliability over speed and efficiency.


**STOP RULE:** Critical infrastructure failures result in widespread loss of life or pose an imminent threat to public safety, making further integration impossible.

---

#### FM6 - The Elite Exodus

- **Archetype**: Market/Human
- **Root Cause**: Assumption A5
- **Owner**: Permitting Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption that key Taiwanese elites will eventually cooperate with the reunification process proves to be a fatal flaw. Instead, a mass exodus of business leaders, politicians, academics, and other influential figures flees Taiwan, taking their wealth, expertise, and connections with them. The brain drain cripples the Taiwanese economy, undermines the government, and fuels widespread social unrest. Businesses relocate to other countries, taking jobs and investment with them. Universities and research institutions lose their top talent, damaging Taiwan's intellectual capital. The political opposition gains strength as disillusioned elites join their ranks. The Chinese government attempts to co-opt or coerce the remaining elites, but their efforts are largely unsuccessful. The elite exodus creates a vacuum of leadership and expertise, making it impossible to govern Taiwan effectively. The reunification project becomes a hollow shell, lacking the support of the very people it needs to succeed.

##### Early Warning Signs
- A significant increase in applications for emigration from Taiwan.
- A sharp decline in foreign investment in Taiwan.
- A wave of resignations from key government positions.

##### Tripwires
- Number of Taiwanese millionaires emigrating >= 1000 per month.
- Foreign direct investment in Taiwan decreases by >= 20% in a quarter.
- Key government officials resigning >= 5 per month.

##### Response Playbook
- Contain: Immediately implement measures to prevent further emigration, such as travel restrictions and asset freezes.
- Assess: Conduct a thorough assessment of the reasons for the elite exodus and identify potential solutions.
- Respond: Offer incentives to encourage elites to stay, such as tax breaks, political representation, and guarantees of personal safety.


**STOP RULE:** The mass exodus of Taiwanese elites leads to the collapse of the Taiwanese economy and government, making further reunification impossible.

---

#### FM7 - The Rule of Law Rot

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Financial Transition Planner
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption of a smooth legal integration proves to be a critical error. The attempt to force the Taiwanese legal system into alignment with the Chinese system results in chaos and corruption. Judicial independence is eroded as judges are pressured to follow the dictates of the Chinese Communist Party. Due process is undermined as legal procedures are streamlined to expedite politically sensitive cases. The protection of individual rights is weakened as the government expands its surveillance powers and restricts freedom of expression. The Taiwanese business community loses confidence in the legal system, fearing arbitrary enforcement and unfair treatment. Foreign investors become wary of investing in Taiwan, fearing that their contracts will not be honored and their assets will be seized. Corruption becomes rampant as officials exploit the legal loopholes and lack of accountability. The rule of law collapses, leading to economic instability, social unrest, and a complete loss of faith in the reunification project.

##### Early Warning Signs
- Resignations of Taiwanese judges and lawyers spike dramatically.
- Reports of politically motivated prosecutions increase sharply.
- Foreign investment in Taiwan plummets.

##### Tripwires
- Number of Taiwanese judges resigning >= 20% within 6 months.
- Number of politically motivated prosecutions >= 100 per month.
- Foreign direct investment decreases by >= 30% within a year.

##### Response Playbook
- Contain: Immediately establish an independent commission to investigate allegations of corruption and judicial interference.
- Assess: Conduct a thorough review of the legal integration process and identify areas for improvement.
- Respond: Implement reforms to strengthen judicial independence, protect individual rights, and promote transparency and accountability.


**STOP RULE:** The Taiwanese legal system collapses completely, with widespread corruption, arbitrary enforcement, and a complete loss of public trust, making further governance impossible.

---

#### FM8 - The Island Inferno

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
The assumption of a swift military victory proves to be a catastrophic underestimation. The Taiwanese military, far from being easily neutralized, mounts a fierce and protracted resistance. The Chinese invasion is met with fierce opposition from well-trained and motivated Taiwanese soldiers, backed by advanced weaponry and a deep understanding of the island's terrain. Urban warfare erupts in major cities, turning streets into battlegrounds. Cyberattacks cripple Chinese military communications and logistics. The invasion stalls, and casualties mount on both sides. The international community condemns China's aggression, imposing crippling sanctions and providing military aid to Taiwan. The conflict escalates, drawing in other regional powers and threatening a wider war. The island becomes an inferno of destruction, with widespread civilian casualties and massive damage to infrastructure. The reunification project becomes a bloody and costly quagmire, with no end in sight.

##### Early Warning Signs
- Chinese military casualties exceed initial projections by 50%.
- The invasion stalls and fails to achieve key objectives within the planned timeframe.
- Reports of widespread civilian casualties and human rights abuses emerge.

##### Tripwires
- Chinese military casualties >= 10,000 within the first month.
- The invasion fails to secure Taipei within the first week.
- International sanctions are imposed by >= 5 major countries.

##### Response Playbook
- Contain: Immediately reinforce troop deployments and secure key strategic locations.
- Assess: Conduct a thorough assessment of the military situation and identify areas for improvement.
- Respond: Initiate backchannel diplomatic negotiations with Taiwan and other key players to de-escalate the conflict and seek a peaceful resolution.


**STOP RULE:** The military conflict escalates to the point of threatening regional or global war, or the level of destruction and civilian casualties becomes unacceptable.

---

#### FM9 - The Corporate Cold Shoulder

- **Archetype**: Market/Human
- **Root Cause**: Assumption A8
- **Owner**: Permitting Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption that the international business community will prioritize economic opportunities over ethical concerns proves to be a devastating miscalculation. Major international corporations, facing mounting pressure from consumers, investors, and governments, begin to withdraw their investments from Taiwan. The corporate cold shoulder sends a chilling message to the Chinese government and undermines the economic viability of the reunification project. The Taiwanese economy suffers a severe downturn as businesses relocate and jobs are lost. The international community applauds the corporations' ethical stance, further isolating China. The Chinese government attempts to pressure the corporations to reverse their decisions, but their efforts are largely unsuccessful. The corporate cold shoulder becomes a symbol of international disapproval and a major obstacle to the reunification project.

##### Early Warning Signs
- Major international corporations announce plans to withdraw investments from Taiwan.
- Consumer boycotts of Chinese products gain momentum.
- Share prices of companies with significant investments in Taiwan plummet.

##### Tripwires
- Number of major international corporations withdrawing >= 10 within a quarter.
- Consumer boycotts affect >= 20% of Chinese exports.
- Share prices of affected companies decrease by >= 15%.

##### Response Playbook
- Contain: Immediately launch a public relations campaign to reassure the international business community and address their concerns.
- Assess: Conduct a thorough assessment of the economic impact of the corporate withdrawals and identify potential solutions.
- Respond: Offer incentives to encourage corporations to stay, such as tax breaks, regulatory relief, and guarantees of political stability.


**STOP RULE:** The withdrawal of international corporations leads to a catastrophic economic collapse in Taiwan, making further reunification economically unviable.
