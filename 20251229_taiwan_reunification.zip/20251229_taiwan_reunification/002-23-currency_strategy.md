This plan involves money.

## Currencies

- **TWD:** Local currency of Taiwan, needed for local transactions during the integration process.
- **CNY:** Official currency of China, to be implemented as part of the reunification process.
- **USD:** Stable international currency for budgeting and reporting, especially given the significant economic and political changes involved.

**Primary currency:** USD

**Currency strategy:** Given the scale and nature of the project, USD is recommended for budgeting and reporting to mitigate risks from economic instability during the reunification process. While TWD will be used initially for local transactions, the plan involves transitioning to CNY. Hedging against exchange rate fluctuations between TWD and USD/CNY is advisable.