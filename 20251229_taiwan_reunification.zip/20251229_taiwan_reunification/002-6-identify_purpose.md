**Purpose:** business

**Purpose Detailed:** Societal and governmental initiative involving cultural, economic, and political integration of Taiwan with China.

**Topic:** Reunification of Taiwan with China