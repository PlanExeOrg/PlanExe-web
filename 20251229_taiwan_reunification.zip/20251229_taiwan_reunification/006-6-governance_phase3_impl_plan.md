### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved
- Project Sponsor Identified

### 2. Project Manager circulates Draft SteerCo ToR v0.1 for review by nominated members (Senior Representative from the Chinese Communist Party, Representative from the People's Liberation Army, Representative from the Ministry of Foreign Affairs, Representative from the Ministry of Finance, Senior Project Manager, Independent Geopolitical Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Circulation Email
- Review Feedback from Nominated Members

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 3. Project Manager consolidates feedback and revises the SteerCo ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.2
- Feedback Summary

**Dependencies:**

- Review Feedback from Nominated Members

### 4. Senior Representative from the Chinese Communist Party (Interim Chair) formally approves the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Senior Representative from the Chinese Communist Party

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- Draft SteerCo ToR v0.2

### 5. Senior Representative from the Chinese Communist Party (Interim Chair) formally appoints the Project Steering Committee members.

**Responsible Body/Role:** Senior Representative from the Chinese Communist Party

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Approved SteerCo ToR v1.0
- Nominated Members List Available

### 6. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Emails

### 7. Hold the initial Project Steering Committee kick-off meeting. Elect Vice-Chair.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Vice-Chair Elected

**Dependencies:**

- Meeting Invitation

### 8. Project Manager drafts initial Terms of Reference (ToR) for the Ethics and Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics and Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved

### 9. Legal Counsel circulates Draft Ethics and Compliance Committee ToR v0.1 for review by nominated members (Legal Counsel, Compliance Officer, Data Protection Officer, Independent Ethics Expert, Representative from the Ministry of Justice, Representative from the Anti-Corruption Bureau).

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Circulation Email
- Review Feedback from Nominated Members

**Dependencies:**

- Draft Ethics and Compliance Committee ToR v0.1
- Nominated Members List Available

### 10. Legal Counsel consolidates feedback and revises the Ethics and Compliance Committee ToR.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Ethics and Compliance Committee ToR v0.2
- Feedback Summary

**Dependencies:**

- Review Feedback from Nominated Members

### 11. Project Steering Committee formally approves the Ethics and Compliance Committee Terms of Reference.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved Ethics and Compliance Committee ToR v1.0

**Dependencies:**

- Draft Ethics and Compliance Committee ToR v0.2
- Project Steering Committee Initial Meeting Held

### 12. Project Steering Committee formally appoints the Ethics and Compliance Committee members.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Approved Ethics and Compliance Committee ToR v1.0
- Nominated Members List Available
- Project Steering Committee Initial Meeting Held

### 13. Legal Counsel schedules the initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Emails

### 14. Hold the initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 15. Project Manager establishes PMO structure and staffing.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- PMO Structure Document
- Staffing Plan

**Dependencies:**

- Project Plan Approved

### 16. Project Manager develops project management templates and tools.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Management Templates
- Project Management Tools

**Dependencies:**

- PMO Structure Document

### 17. Project Manager defines project reporting requirements.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Reporting Requirements Document

**Dependencies:**

- Project Management Templates

### 18. Project Manager establishes communication channels with project teams and stakeholders.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Communication Plan
- Communication Channels Established

**Dependencies:**

- Project Reporting Requirements Document

### 19. Project Manager schedules the initial PMO kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Communication Channels Established

### 20. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 21. Project Manager identifies and recruits technical experts for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- List of Technical Experts
- Recruitment Plan

**Dependencies:**

- Project Plan Approved

### 22. Project Manager defines scope of technical advisory services.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Scope of Technical Advisory Services Document

**Dependencies:**

- List of Technical Experts

### 23. Project Manager establishes communication channels with project teams for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Communication Plan
- Communication Channels Established

**Dependencies:**

- Scope of Technical Advisory Services Document

### 24. Project Manager develops technical assessment frameworks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Technical Assessment Frameworks

**Dependencies:**

- Communication Channels Established

### 25. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Technical Assessment Frameworks

### 26. Hold the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 27. Project Manager identifies key stakeholders for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- List of Key Stakeholders

**Dependencies:**

- Project Plan Approved

### 28. Project Manager develops a communication plan for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Communication Plan

**Dependencies:**

- List of Key Stakeholders

### 29. Project Manager establishes communication channels for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Communication Channels Established

**Dependencies:**

- Communication Plan

### 30. Project Manager recruits communication specialists and public relations experts for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Staffing Plan
- Recruitment Complete

**Dependencies:**

- Communication Channels Established

### 31. Project Steering Committee formally approves the Stakeholder Engagement Group members.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Staffing Plan
- Recruitment Complete
- Project Steering Committee Initial Meeting Held

### 32. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Emails

### 33. Hold the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation