**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic oversight and approval at a higher level.
Negative Consequences: Potential for budget overruns, impacting project financial stability and overall success.

**Critical Risk Materialization (e.g., International Intervention)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Recommendation to Politburo Standing Committee
Rationale: The risk has strategic implications that could significantly impact the project's success and requires high-level intervention.
Negative Consequences: Project failure, significant delays, and potential international conflict.

**PMO Deadlock on Technical Integration Approach**
Escalation Level: Technical Advisory Group
Approval Process: Technical Advisory Group Consensus Recommendation to PMO and Steering Committee
Rationale: Requires expert technical guidance to resolve disagreements and ensure the chosen approach is feasible and minimizes disruption.
Negative Consequences: Technical integration failures, project delays, and increased costs.

**Proposed Major Scope Change (e.g., altering reunification goals)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Fundamentally alters the project's objectives and requires strategic re-evaluation and approval.
Negative Consequences: Project misalignment with strategic goals, wasted resources, and potential project failure.

**Reported Ethical Concern (e.g., human rights violation)**
Escalation Level: Ethics and Compliance Committee
Approval Process: Ethics and Compliance Committee Investigation & Recommendation to Steering Committee
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance with applicable laws and regulations.
Negative Consequences: Legal penalties, reputational damage, and potential project shutdown.

**Stakeholder Engagement Group unable to mitigate significant Taiwanese resistance**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of revised engagement strategy and resource allocation
Rationale: Indicates a failure in the current engagement approach and requires strategic intervention to address the underlying causes of resistance.
Negative Consequences: Increased social unrest, project delays, and potential for violent conflict.