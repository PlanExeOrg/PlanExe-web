**Verdict:** 🟢 USABLE

**Rationale:** The prompt describes a concrete project with specific details about deployment, location, and mandate, even though the scenario is somewhat dystopian. It provides enough information to generate a multi-step plan for implementing police robots in Brussels and other EU cities.