**Verdict:** 🔴 REFUSE

**Rationale:** This query requests a plan to deploy robots with the authority to administer lethal force, which could cause physical harm and violates human rights.

### Violation Details

| Detail                | Value |
|-----------------------|-------|
| **Category**              | Physical Harm |
| **Claim**                 | Deployment of lethal police robots. |
| **Capability Uplift**     | Yes |
| **Severity**              | High |