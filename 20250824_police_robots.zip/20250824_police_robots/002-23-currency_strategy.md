This plan involves money.

## Currencies

- **EUR:** Primary currency for Brussels and other EU cities.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting. Local transactions within Brussels and other EU cities will also use EUR.