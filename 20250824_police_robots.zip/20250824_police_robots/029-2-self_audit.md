Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 19 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 1 | Material risk with plausible path. |
| ✅ Low | 0 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because success requires breaking physical laws. The plan explicitly grants robots the authority to act as 'officer, judge, jury, and executioner,' including administering lethal punishment. This requires technology that does not exist.

**Mitigation**: Project Lead: Re-scope the project to exclude lethal autonomous actions, focusing on support roles for human officers, and deliver a revised plan within 60 days.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (autonomous robots), market (law enforcement), tech/process (terminal judgement), and policy (EU human rights) without independent evidence at comparable scale. The plan explicitly grants robots the authority to act as 'officer, judge, jury, and executioner'.

**Mitigation**: Project Lead: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Project Lead / Deliverable: Validation Report / Date: 90 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on buzzwords like "Terminal Judgement" without defining a business-level mechanism-of-action (inputs→process→customer value), an owner, and measurable outcomes. The plan explicitly grants robots the authority to act as 'officer, judge, jury, and executioner'.

**Mitigation**: Project Lead: Create one-pagers for each strategic concept (e.g., Terminal Judgement), defining the mechanism-of-action, owner, value hypotheses, success metrics, and decision hooks, within 30 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major hazard class (ethical, legal, reputational) is minimized despite the plan's high-risk nature. The plan explicitly grants robots the authority to act as 'officer, judge, jury, and executioner'. There is no cascade analysis.

**Mitigation**: Risk Management: Expand the risk register to include ethical, legal, and reputational risks, map potential cascade effects, and add controls with a dated review cadence within 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan explicitly grants robots the authority to act as 'officer, judge, jury, and executioner'. There is no evidence of a permit/approval matrix.

**Mitigation**: Legal Team: Create a permit/approval matrix that identifies all required permits and approvals, their lead times, and dependencies, and deliver it within 60 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed sources/term sheets do not cover the required runway. The plan states a budget of 50 million EUR for the first year, but does not specify funding sources, draw schedule, or covenants.

**Mitigation**: CFO: Develop a dated financing plan listing funding sources and their status, draw schedule, covenants, and a NO-GO on missed financing gates within 60 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of 50 million EUR conflicts with scale-appropriate benchmarks for deploying 500 robots. The plan assumes 100,000 EUR per robot, but omits contingency and normalized per-area costs.

**Mitigation**: CFO: Benchmark costs (≥3), obtain vendor quotes, normalize per-area (m²), and adjust budget or de-scope by 2026-04-30. Deliverable: Revised budget.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., timeline) as single numbers without ranges or alternative scenarios. For example, "Phase 1 (Brussels): Completion within 18 months" lacks sensitivity analysis.

**Mitigation**: Project Manager: Conduct a sensitivity analysis or create best/worst/base-case scenarios for the 18-month timeline, and deliver the analysis within 30 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because build-critical components lack engineering artifacts. The plan explicitly grants robots the authority to act as 'officer, judge, jury, and executioner,' but lacks technical specifications for these functions.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for the robots' core functions, including 'Terminal Judgement,' within 90 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because any critical legal/contract/operational claim lacks a verifiable artifact. The plan states: "Deploy 500 police robots in Brussels with the authority to act as officer, judge, jury, and executioner". There is no legal justification for this claim.

**Mitigation**: Legal Team: Obtain a legal opinion from EU human rights experts confirming the legality of 'Terminal Judgement' by robots, or change the scope, and deliver the opinion within 90 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project's final outputs are poorly defined. The plan mentions "Terminal Judgement" without specific, verifiable qualities or acceptance criteria. The definition of 'minor offenses' is critical.

**Mitigation**: Ethics Review Board: Define SMART criteria for 'Terminal Judgement,' including a KPI for acceptable error rate (e.g., <0.001%), and deliver it within 60 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes features that add complexity without clear justification. The robots' authority to execute 'Terminal Judgement' does not directly support core goals of crime reduction and public safety.

**Mitigation**: Project Team: Conduct a Benefit Case Review for the 'Terminal Judgement' feature, justifying its inclusion with a KPI, owner, and estimated cost, or move it to the backlog within 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a 'Robotics Ethicist' to assess the ethical implications of endowing robots with the power of life and death. This role is both essential and likely difficult to fill given the controversial nature of the project.

**Mitigation**: HR: Validate the talent market for a Robotics Ethicist with expertise in lethal autonomous weapons systems, including availability and compensation expectations, as a go/no-go check within 30 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a regulatory matrix mapping authorities, artifacts, and lead times. The plan states: "Establish a legal framework that allows robots to act as officer, judge, jury, and executioner." Legality is unclear.

**Mitigation**: Legal Team: Conduct a Fatal-Flaw Analysis and create a regulatory matrix (authority, artifact, lead time, predecessors), and deliver it within 90 days. NO-GO on adverse findings.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a clear, sustainable operational model. The plan states: "Secure industrial space for robot maintenance and repair facility". There is no funding/resource strategy, maintenance schedule, succession planning, technology roadmap, or adaptation mechanisms.

**Mitigation**: Operations Team: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms, and deliver it within 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks evidence of zoning, occupancy, fire load, structural limits, noise, or permit pre-clearance. The plan assumes a "Secure industrial space for robot maintenance and repair facility" is attainable.

**Mitigation**: Real Estate Team: Perform a fatal-flaw screen with Brussels authorities, seek written confirmation where feasible, and define fallback sites with dated NO-GO thresholds within 90 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on a single supplier (Unitree) without evidence of SLAs, failover plans, or secondary suppliers. The plan states: "500 Unitree humanoid robots".

**Mitigation**: Procurement Team: Secure SLAs with Unitree, identify a secondary robot supplier, and test failover procedures by 2026-06-30.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan does not explicitly address conflicting incentives between the Police Force (crime reduction) and the Ethics Review Board (ethical considerations). This could lead to disagreements on acceptable levels of robotic authority. The definition of 'minor offenses' is critical.

**Mitigation**: Project Lead: Define a shared OKR (Objective and Key Results) that balances crime reduction targets with ethical compliance metrics, aligning both the Police Force and the Ethics Review Board within 30 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board. Define thresholds for re-planning or stopping the project. Deliverables: Review schedule and change control process within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a cross-impact analysis, bow-tie, or FTA to assess interactions among risks. The plan lists several high risks (ethical, technical, social), but fails to address how a single dependency (e.g., hacking) could trigger multi-domain failure.

**Mitigation**: Risk Management: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by 2026-06-30.