### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**


### 2. Project Manager drafts initial Terms of Reference (ToR) for the Ethics Review Board.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics Review Board ToR v0.1

**Dependencies:**


### 3. Project Manager drafts initial Stakeholder Engagement Plan for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Plan v0.1

**Dependencies:**


### 4. Circulate Draft SteerCo ToR for review by nominated members (CTO, CLO, CFO, Head of Public Safety, Independent Ethics Advisor).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 5. Circulate Draft Ethics Review Board ToR for review by nominated members (Independent Ethics Advisor, Legal Counsel, AI Ethics Specialist, Community Representative, Data Protection Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics Review Board ToR v0.1
- Nominated Members List Available

### 6. Finalize Project Steering Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 7. Finalize Ethics Review Board Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics Review Board ToR v1.0

**Dependencies:**

- Feedback Summary

### 8. Senior Management formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 9. Senior Management formally appoints the Chair of the Ethics Review Board.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics Review Board ToR v1.0

### 10. Project Manager formally confirms membership of the Project Steering Committee (CTO, CLO, CFO, Head of Public Safety, Independent Ethics Advisor).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Appointment Confirmation Email

### 11. Project Manager formally confirms membership of the Ethics Review Board (Independent Ethics Advisor, Legal Counsel, AI Ethics Specialist, Community Representative, Data Protection Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Appointment Confirmation Email

### 12. Project Manager schedules and facilitates the initial Project Steering Committee Kick-off Meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation Emails
- Final SteerCo ToR v1.0

### 13. Project Steering Committee approves initial project plan.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved Project Plan

**Dependencies:**

- Meeting Minutes with Action Items

### 14. Project Manager schedules and facilitates the initial Ethics Review Board Kick-off Meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Initial Ethical Guidelines

**Dependencies:**

- Membership Confirmation Emails
- Final Ethics Review Board ToR v1.0

### 15. Project Manager establishes project management processes and procedures for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Project Management Processes and Procedures Document

**Dependencies:**

- Approved Project Plan

### 16. Project Manager develops project communication plan for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Project Communication Plan

**Dependencies:**

- Approved Project Plan

### 17. Project Manager sets up project tracking and reporting systems for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Project Tracking and Reporting Systems

**Dependencies:**

- Approved Project Plan

### 18. Project Manager recruits project team members for the Project Management Office (PMO) (Lead Robotics Technician, Lead AI Specialist, Data Security Officer, Community Liaison Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Project Team Members Onboarded

**Dependencies:**

- Approved Project Plan

### 19. Project Manager schedules and holds the initial Project Management Office (PMO) Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Project Team Members Onboarded
- Project Management Processes and Procedures Document
- Project Communication Plan
- Project Tracking and Reporting Systems

### 20. Project Manager identifies key stakeholders for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- List of Key Stakeholders

**Dependencies:**

- Approved Project Plan

### 21. Community Liaison Officer (newly recruited PMO member) finalizes Stakeholder Engagement Plan based on feedback from the Project Manager.

**Responsible Body/Role:** Community Liaison Officer

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Plan v1.0

**Dependencies:**

- Draft Stakeholder Engagement Plan v0.1
- List of Key Stakeholders

### 22. Community Liaison Officer establishes communication channels for the Stakeholder Engagement Group.

**Responsible Body/Role:** Community Liaison Officer

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Communication Channels Established

**Dependencies:**

- Final Stakeholder Engagement Plan v1.0

### 23. Community Liaison Officer recruits community representatives for the Stakeholder Engagement Group.

**Responsible Body/Role:** Community Liaison Officer

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Community Representatives Recruited

**Dependencies:**

- Final Stakeholder Engagement Plan v1.0

### 24. Community Liaison Officer schedules and facilitates the initial Stakeholder Engagement Group Kick-off Meeting.

**Responsible Body/Role:** Community Liaison Officer

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Communication Channels Established
- Community Representatives Recruited
- Final Stakeholder Engagement Plan v1.0

### 25. The Project Steering Committee begins monthly meetings to review project progress against strategic objectives.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Month 2

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Project Steering Committee established

### 26. The Ethics Review Board begins bi-weekly meetings to review ethical guidelines and assess ethical implications of project decisions.

**Responsible Body/Role:** Ethics Review Board

**Suggested Timeframe:** Project Month 2

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Ethics Review Board established

### 27. The Project Management Office (PMO) begins weekly meetings to review project progress against plan and discuss operational risks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Project Management Office (PMO) established

### 28. The Stakeholder Engagement Group begins bi-weekly meetings to review the stakeholder engagement plan and discuss stakeholder feedback and concerns.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Month 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Stakeholder Engagement Group established