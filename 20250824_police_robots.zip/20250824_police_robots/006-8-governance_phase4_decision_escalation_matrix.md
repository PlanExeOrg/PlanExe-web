**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority and requires strategic oversight.
Negative Consequences: Potential for budget overruns, project delays, or scope reduction if not addressed.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: The PMO lacks the authority or resources to handle the materialized risk effectively, requiring strategic intervention.
Negative Consequences: Project failure, harm to citizens, legal liabilities, or reputational damage if not addressed.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: The PMO cannot reach a consensus on a critical vendor, requiring a higher-level decision to avoid delays.
Negative Consequences: Project delays, increased costs, or selection of a suboptimal vendor if not resolved.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote on Scope Change Request
Rationale: A significant change to the project's scope requires strategic alignment and approval.
Negative Consequences: Misalignment with strategic objectives, budget overruns, or project delays if not properly evaluated.

**Reported Ethical Concern**
Escalation Level: Ethics Review Board
Approval Process: Ethics Review Board Investigation & Recommendation
Rationale: Requires independent ethical review and guidance to ensure adherence to ethical principles.
Negative Consequences: Reputational damage, legal challenges, public outcry, or project abandonment if not addressed.

**Unresolved Ethical Conflict within Ethics Review Board**
Escalation Level: CEO
Approval Process: CEO Review and Final Decision
Rationale: Ensures that ethical conflicts are resolved at the highest level of the organization.
Negative Consequences: Erosion of public trust, legal challenges, or project abandonment if not resolved.

**Stakeholder Engagement Group cannot reach consensus on a communication strategy**
Escalation Level: Project Management Office (PMO)
Approval Process: PMO Review and Final Decision
Rationale: The Stakeholder Engagement Group cannot reach a consensus on a communication strategy, requiring a higher-level decision to avoid delays.
Negative Consequences: Public backlash, protests, challenges.