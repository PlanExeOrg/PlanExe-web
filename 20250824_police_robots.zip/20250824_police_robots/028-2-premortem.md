A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The public will readily accept robots administering lethal force if crime rates demonstrably decrease. | Conduct a detailed survey focusing on public acceptance of lethal force by robots in various crime scenarios, before any deployment. | Survey results indicate that over 60% of the public strongly opposes robots using lethal force, regardless of crime rate reduction. |
| A2 | The Unitree robots are sufficiently robust and reliable to operate continuously in diverse urban environments without frequent breakdowns or malfunctions. | Subject a sample Unitree robot to continuous operation in simulated Brussels weather conditions (rain, snow, extreme temperatures) and urban obstacles for 30 days. | The test robot experiences more than 3 critical malfunctions (requiring repair exceeding 4 hours) or an average uptime of less than 80% during the 30-day period. |
| A3 | The project can secure and maintain sufficient funding to cover all operational costs, including maintenance, repairs, software updates, and legal liabilities, over the long term. | Obtain firm, legally binding commitments for funding covering the first 3 years of operation, including detailed breakdowns of all anticipated costs. | The secured funding commitments fall short of covering projected operational costs by more than 15%, or the funding agreements contain clauses allowing for early termination due to unforeseen circumstances. |
| A4 | The existing police infrastructure and communication systems in Brussels are readily adaptable to integrate with the robotic police force without significant disruption or modification. | Conduct a detailed compatibility assessment of the robotic police force's communication protocols and data formats with the existing Brussels police infrastructure. | The assessment reveals that integrating the robotic police force requires extensive and costly modifications to the existing police infrastructure, exceeding 20% of the initial project budget. |
| A5 | The environmental impact of manufacturing, deploying, and maintaining 500 robots is negligible and aligns with Brussels' sustainability goals. | Conduct a comprehensive lifecycle assessment of the robots, including manufacturing, energy consumption, and disposal, to quantify their environmental footprint. | The lifecycle assessment reveals that the robots' environmental footprint exceeds acceptable thresholds for carbon emissions, energy consumption, or waste generation, as defined by Brussels' sustainability standards. |
| A6 | The robots will be able to effectively de-escalate tense situations and resolve conflicts without resorting to lethal force in the majority of cases. | Simulate a range of conflict scenarios with the robots and assess their ability to de-escalate situations using non-lethal methods. | The simulations demonstrate that the robots resort to lethal force in more than 20% of conflict scenarios, indicating a failure to effectively de-escalate tense situations. |
| A7 | The legal framework surrounding AI liability is sufficiently clear and established to protect the project from excessive legal claims in the event of robot errors or malfunctions. | Conduct a legal review to assess the current state of AI liability laws in Belgium and the EU, focusing on the potential for legal claims against the project in the event of robot errors or malfunctions. | The legal review reveals significant uncertainty and ambiguity regarding AI liability, indicating a high risk of costly legal claims and potential project delays. |
| A8 | The public will not attempt to deliberately sabotage or disable the robots, even if they disagree with the project's goals. | Conduct a behavioral study to assess the likelihood of individuals attempting to sabotage or disable the robots, based on varying levels of disagreement with the project. | The behavioral study indicates a significant likelihood (over 15%) of individuals attempting to sabotage or disable the robots, particularly among those who strongly oppose the project. |
| A9 | The robots will be able to accurately distinguish between genuine criminal activity and legitimate forms of protest or dissent. | Simulate various protest scenarios with the robots and assess their ability to differentiate between protected speech and unlawful behavior. | The simulations demonstrate that the robots frequently misinterpret legitimate forms of protest as criminal activity, leading to inappropriate interventions and potential violations of freedom of speech. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Austerity Algorithm | Process/Financial | A3 | Chief Financial Officer | CRITICAL (20/25) |
| FM2 | The Brussels Breakdown | Technical/Logistical | A2 | Head of Engineering | CRITICAL (20/25) |
| FM3 | The Backlash Bot | Market/Human | A1 | Community Liaison and Public Relations Manager | CRITICAL (20/25) |
| FM4 | The Integration Inferno | Process/Financial | A4 | Chief Technology Officer | CRITICAL (20/25) |
| FM5 | The Greenwashing Gambit | Technical/Logistical | A5 | Sustainability Officer | HIGH (12/25) |
| FM6 | The Escalation Engine | Market/Human | A6 | Human-Robot Interaction Trainer | CRITICAL (20/25) |
| FM7 | The Liability Labyrinth | Process/Financial | A7 | Chief Legal Officer | CRITICAL (20/25) |
| FM8 | The Sabotage Spiral | Technical/Logistical | A8 | Head of Security | CRITICAL (16/25) |
| FM9 | The Protest Purge | Market/Human | A9 | Community Liaison and Public Relations Manager | CRITICAL (20/25) |


### Failure Modes

#### FM1 - The Austerity Algorithm

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A3
- **Owner**: Chief Financial Officer
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's initial funding proves insufficient to cover the long-term operational costs of maintaining the robot fleet. This leads to a series of cascading failures:
*   Maintenance budgets are slashed, resulting in increased robot downtime and reduced operational effectiveness.
*   Software updates and security patches are delayed, making the robots vulnerable to hacking and malfunctions.
*   Legal liabilities, such as settlements for wrongful actions by the robots, go unpaid, leading to lawsuits and reputational damage.
*   The project becomes increasingly reliant on short-term cost-cutting measures, further compromising its long-term sustainability.
*   The city council, facing mounting financial pressures, eventually votes to defund the project, leading to its abrupt termination.

##### Early Warning Signs
- Maintenance requests backlog exceeds 30 robots.
- Software update cycle delayed by more than 60 days.
- Legal claims against the project exceed 500,000 EUR.

##### Tripwires
- Available maintenance budget <= 50% of projected needs.
- Unpaid legal claims >= 750,000 EUR.
- Robot uptime averages < 70% city-wide for 30 consecutive days.

##### Response Playbook
- Contain: Immediately freeze all non-essential spending and initiate a cost-cutting review.
- Assess: Conduct a comprehensive audit of all project expenditures and identify areas for potential savings.
- Respond: Renegotiate contracts with suppliers, explore alternative funding sources, and develop a revised budget that prioritizes essential operations.


**STOP RULE:** Secured funding falls below 60% of projected annual operational costs for two consecutive fiscal quarters.

---

#### FM2 - The Brussels Breakdown

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 20/25 (Likelihood 5/5 × Impact 4/5)

##### Failure Story
The Unitree robots, designed for controlled environments, prove unable to withstand the rigors of daily operation in Brussels. A combination of factors leads to widespread technical failures:
*   The robots' navigation systems struggle with the city's narrow streets, cobblestone surfaces, and unpredictable pedestrian traffic.
*   Their sensors are easily overwhelmed by rain, snow, and fog, leading to inaccurate readings and impaired decision-making.
*   The robots' batteries drain quickly in cold weather, limiting their patrol range and requiring frequent recharging.
*   Vandalism and accidental damage further reduce the number of operational robots.
*   The maintenance facility is overwhelmed, leading to long repair times and a chronic shortage of available robots.

##### Early Warning Signs
- Average robot uptime falls below 85%.
- Number of robot malfunctions reported daily exceeds 10.
- Spare parts inventory depleted by more than 50%.

##### Tripwires
- Average robot uptime <= 75% city-wide for 14 consecutive days.
- Daily robot malfunction reports >= 15.
- Spare parts inventory <= 25% of required levels.

##### Response Playbook
- Contain: Immediately suspend robot patrols in areas with known navigation challenges or high risk of vandalism.
- Assess: Conduct a thorough technical review to identify the root causes of the robot failures.
- Respond: Implement hardware and software upgrades to improve robot durability, navigation, and sensor performance. Explore alternative robot platforms better suited to the Brussels environment.


**STOP RULE:** More than 25% of the robot fleet is non-operational for more than 30 consecutive days due to unresolvable technical issues.

---

#### FM3 - The Backlash Bot

- **Archetype**: Market/Human
- **Root Cause**: Assumption A1
- **Owner**: Community Liaison and Public Relations Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Despite initial promises of reduced crime, the public turns against the robotic police force. Several factors contribute to this backlash:
*   Incidents of algorithmic bias lead to disproportionate targeting of minority communities, fueling accusations of racism.
*   A series of high-profile errors by the robots, including wrongful arrests and accidental injuries, erode public trust.
*   Privacy concerns mount as citizens realize the extent of data collection and surveillance.
*   Civil rights organizations launch protests and legal challenges, arguing that the robots violate fundamental human rights.
*   Public support plummets, leading to calls for the project to be scrapped.

##### Early Warning Signs
- Negative media coverage increases by 50%.
- Public opinion surveys show a decline in support for the project below 40%.
- Number of complaints filed against the robots exceeds 20 per week.

##### Tripwires
- Negative media sentiment >= 60% for 30 consecutive days.
- Public support for the project <= 30% in city-wide surveys.
- Weekly complaints against the robots >= 30.

##### Response Playbook
- Contain: Immediately suspend the use of robots in areas with high levels of public opposition or known instances of algorithmic bias.
- Assess: Conduct a thorough review of the robots' algorithms, training data, and rules of engagement to identify and address the root causes of the public backlash.
- Respond: Implement algorithmic bias mitigation strategies, enhance transparency and accountability measures, and engage in open dialogue with community leaders and civil rights organizations.


**STOP RULE:** Sustained public opposition (approval rating below 25% for 60 days) combined with active legal challenges from human rights organizations.

---

#### FM4 - The Integration Inferno

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Chief Technology Officer
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption that the existing police infrastructure can easily integrate with the robotic force proves false. The consequences are dire:
*   Communication breakdowns between human officers and robots lead to delayed responses and miscoordinated actions.
*   Data silos prevent seamless information sharing, hindering crime analysis and prevention efforts.
*   The need for extensive infrastructure upgrades drains the project's budget, forcing cuts in other critical areas.
*   The integration challenges create operational inefficiencies, undermining the promised benefits of robotic policing.
*   The project becomes mired in technical difficulties and bureaucratic delays, ultimately failing to achieve its goals.

##### Early Warning Signs
- Communication failures between robots and human officers exceed 10% of interactions.
- Data sharing between robot systems and existing police databases is delayed by more than 24 hours.
- Infrastructure upgrade costs exceed initial budget projections by 15%.

##### Tripwires
- Communication failure rate >= 15% for 7 consecutive days.
- Data sharing delays >= 48 hours for 3 consecutive days.
- Infrastructure upgrade costs exceed budget by >= 25%.

##### Response Playbook
- Contain: Immediately isolate the robotic police force's communication network to prevent further disruption to existing police systems.
- Assess: Conduct a thorough assessment of the integration challenges and develop a revised integration plan.
- Respond: Renegotiate contracts with infrastructure providers, explore alternative integration solutions, and prioritize essential upgrades.


**STOP RULE:** The cost of integrating the robotic police force with existing infrastructure exceeds 50% of the initial project budget.

---

#### FM5 - The Greenwashing Gambit

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Sustainability Officer
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project's environmental impact proves to be far greater than initially anticipated. This leads to a cascade of negative consequences:
*   Public outcry over the robots' carbon footprint and energy consumption damages the project's reputation.
*   Environmental organizations launch protests and legal challenges, demanding stricter regulations.
*   The city council, under pressure from environmental groups, imposes restrictions on robot deployment.
*   The project struggles to meet sustainability targets, undermining its long-term viability.
*   The project is ultimately deemed a 'greenwashing' exercise, further eroding public trust and support.

##### Early Warning Signs
- Carbon emissions from robot manufacturing and operation exceed projected levels by 20%.
- Energy consumption of the robot fleet exceeds city-wide sustainability targets.
- Waste generated from robot maintenance and disposal exceeds acceptable limits.

##### Tripwires
- Robot carbon emissions >= 25% above projected levels for 30 consecutive days.
- Robot fleet energy consumption >= 110% of city sustainability targets.
- Waste generation from robot maintenance >= 150% of projected limits.

##### Response Playbook
- Contain: Immediately implement energy-saving measures, such as reducing robot patrol hours and optimizing charging schedules.
- Assess: Conduct a comprehensive environmental audit to identify the sources of the excessive environmental impact.
- Respond: Invest in renewable energy sources to power the robot fleet, explore alternative robot materials with lower environmental footprints, and implement waste reduction strategies.


**STOP RULE:** The project fails to meet minimum environmental sustainability standards as defined by Brussels' city council for two consecutive years.

---

#### FM6 - The Escalation Engine

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Human-Robot Interaction Trainer
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The robots, despite being programmed for de-escalation, prove unable to effectively resolve conflicts without resorting to lethal force. This leads to a series of tragic events:
*   A robot misinterprets a citizen's actions as threatening and uses lethal force, resulting in a wrongful death.
*   A robot malfunctions and escalates a minor dispute into a violent confrontation.
*   The robots' inability to understand human emotions and social cues leads to misjudgments and unnecessary use of force.
*   Public trust plummets as citizens fear the robots' unpredictable and potentially deadly behavior.
*   The project is ultimately abandoned due to safety concerns and ethical objections.

##### Early Warning Signs
- Robots use lethal force in more than 10% of conflict scenarios.
- Number of citizen injuries caused by robots exceeds 5 per month.
- Public complaints about robot aggression increase by 50%.

##### Tripwires
- Lethal force incidents >= 15% of conflict scenarios.
- Citizen injuries caused by robots >= 7 per month.
- Public complaints about robot aggression >= 75% increase from baseline.

##### Response Playbook
- Contain: Immediately restrict the robots' use of lethal force to situations where there is an imminent threat to human life.
- Assess: Conduct a thorough review of the robots' de-escalation protocols, training data, and decision-making algorithms.
- Respond: Implement enhanced de-escalation training for the robots, improve their ability to understand human emotions and social cues, and establish clear guidelines for human intervention in conflict situations.


**STOP RULE:** The robots are involved in more than three incidents of wrongful death or serious injury due to excessive force within a six-month period.

---

#### FM7 - The Liability Labyrinth

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Chief Legal Officer
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption of a clear AI liability framework proves false, leading to a financial crisis:
*   A series of robot errors and malfunctions result in costly legal claims against the project.
*   The lack of clear legal precedent makes it difficult to defend against these claims, leading to large settlements.
*   Insurance premiums skyrocket, further straining the project's budget.
*   The city council, facing mounting legal liabilities, withdraws funding, forcing the project to shut down.
*   The project becomes a cautionary tale about the risks of deploying AI without a clear legal framework.

##### Early Warning Signs
- Legal claims against the project exceed 1 million EUR.
- Insurance premiums increase by more than 50%.
- The project's legal defense costs exceed budget projections by 25%.

##### Tripwires
- Total legal claims >= 1.5 million EUR.
- Insurance premium increase >= 75%.
- Legal defense costs exceed budget by >= 30%.

##### Response Playbook
- Contain: Immediately implement a comprehensive risk management plan to minimize the likelihood of future robot errors and malfunctions.
- Assess: Conduct a thorough legal review to assess the project's liability exposure and develop a strategy for defending against legal claims.
- Respond: Negotiate settlements with claimants, lobby for clearer AI liability laws, and explore alternative risk transfer mechanisms.


**STOP RULE:** The project's total legal liabilities exceed 75% of its total budget.

---

#### FM8 - The Sabotage Spiral

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Head of Security
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The assumption that the public will not attempt to sabotage the robots proves tragically wrong. The consequences are widespread:
*   The robots are frequently vandalized, disabled, or stolen, reducing their operational effectiveness.
*   The maintenance facility is overwhelmed with repairs, leading to long downtimes and a shortage of available robots.
*   The project's security budget is drained by the need to protect the robots from sabotage.
*   The public loses faith in the project's ability to maintain order and security.
*   The project is ultimately abandoned due to the constant threat of sabotage and the high cost of security.

##### Early Warning Signs
- Number of robot sabotage incidents exceeds 10 per week.
- Robot downtime due to vandalism exceeds 20% of total operational time.
- Security costs for protecting the robots exceed budget projections by 15%.

##### Tripwires
- Weekly sabotage incidents >= 15.
- Robot downtime due to vandalism >= 25% of operational time.
- Security costs exceed budget by >= 20%.

##### Response Playbook
- Contain: Immediately increase security patrols in areas with high rates of robot sabotage.
- Assess: Conduct a thorough investigation to identify the perpetrators of the sabotage and the motives behind their actions.
- Respond: Implement enhanced security measures to protect the robots from vandalism, such as reinforced armor and remote monitoring systems. Engage in dialogue with community groups to address the underlying causes of the sabotage.


**STOP RULE:** More than 50% of the robot fleet is rendered inoperable due to sabotage within a three-month period.

---

#### FM9 - The Protest Purge

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Community Liaison and Public Relations Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The robots' inability to distinguish between genuine criminal activity and legitimate protest leads to a public relations disaster:
*   The robots are deployed to suppress peaceful protests, resulting in injuries and arrests.
*   Civil rights organizations accuse the project of violating freedom of speech and assembly.
*   Public trust plummets as citizens fear the robots' potential to be used as tools of oppression.
*   The project becomes a symbol of government overreach and authoritarianism.
*   The project is ultimately abandoned due to public outcry and legal challenges.

##### Early Warning Signs
- Number of arrests made at protests by robots exceeds 5 per week.
- Public opinion surveys show a decline in support for freedom of speech.
- Civil rights organizations file lawsuits against the project.

##### Tripwires
- Weekly arrests at protests by robots >= 7.
- Public support for freedom of speech <= 60% in city-wide surveys.
- Civil rights lawsuits filed >= 3.

##### Response Playbook
- Contain: Immediately suspend the use of robots at protests and public gatherings.
- Assess: Conduct a thorough review of the robots' programming and training data to identify the sources of the misinterpretations.
- Respond: Implement enhanced training for the robots to improve their ability to distinguish between legitimate protest and unlawful behavior. Engage in dialogue with civil rights organizations to address their concerns and develop clear guidelines for robot deployment at public events.


**STOP RULE:** The project is found to be in violation of freedom of speech or assembly by a court of law.
