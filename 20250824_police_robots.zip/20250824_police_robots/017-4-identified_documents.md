
## Documents to Create

### 1. Project Charter

**ID:** e92b813b-d1bd-41ce-8d34-bec845cb5878

**Description:** A formal document that initiates the project, defines its objectives, scope, and stakeholders, and outlines the roles and responsibilities of the project team. It serves as a high-level overview and authorization for the project to proceed. Includes initial risk assessment and high-level budget.

**Responsible Role Type:** Project Manager

**Primary Template:** PMI Project Charter Template

**Steps:**

- Define project objectives and scope based on the goal statement.
- Identify key stakeholders and their roles.
- Outline project deliverables and success criteria.
- Develop a high-level budget and timeline.
- Obtain approval from relevant authorities.

**Approval Authorities:** Project Sponsor, Legal Counsel, Ethics Review Board

### 2. Risk Register

**ID:** fa948471-9ba2-460b-b22d-8b89ca458f29

**Description:** A comprehensive document that identifies potential risks associated with the project, assesses their likelihood and impact, and outlines mitigation strategies. It serves as a central repository for risk-related information and is regularly updated throughout the project lifecycle. Includes regulatory, technical, social, operational, financial, security, and ethical risks.

**Responsible Role Type:** Risk Assessment and Mitigation Coordinator

**Primary Template:** PMI Risk Register Template

**Steps:**

- Identify potential risks based on project scope and objectives.
- Assess the likelihood and impact of each risk.
- Develop mitigation strategies for high-priority risks.
- Assign responsibility for monitoring and managing risks.
- Regularly update the risk register throughout the project lifecycle.

**Approval Authorities:** Project Manager, Legal Counsel, Ethics Review Board

### 3. Communication Plan

**ID:** 105179b5-e202-4f55-8532-325bd46fd8e3

**Description:** A detailed plan that outlines how project information will be communicated to stakeholders, including the frequency, format, and channels of communication. It ensures that stakeholders are kept informed of project progress, risks, and issues. Includes internal team communication and external public relations strategies.

**Responsible Role Type:** Community Liaison and Public Relations Manager

**Primary Template:** PMI Communication Plan Template

**Steps:**

- Identify key stakeholders and their communication needs.
- Define communication objectives and strategies.
- Determine communication channels and frequency.
- Assign responsibility for communication activities.
- Establish a process for managing communication feedback.

**Approval Authorities:** Project Manager, Project Sponsor

### 4. Stakeholder Engagement Plan

**ID:** 6801167c-026c-48b6-ad0e-ceceea186730

**Description:** A plan that outlines how the project team will engage with stakeholders to ensure their support and address their concerns. It identifies key stakeholders, their interests, and the strategies for engaging them throughout the project lifecycle. Includes strategies for public forums, surveys, and community events.

**Responsible Role Type:** Community Liaison and Public Relations Manager

**Steps:**

- Identify key stakeholders and their interests.
- Assess stakeholder influence and impact.
- Develop engagement strategies for each stakeholder group.
- Establish a process for managing stakeholder feedback.
- Regularly update the stakeholder engagement plan.

**Approval Authorities:** Project Manager, Project Sponsor

### 5. Change Management Plan

**ID:** a807df40-43b2-477a-9567-3d974fa2943b

**Description:** A plan that outlines how changes to the project scope, objectives, or deliverables will be managed. It establishes a process for identifying, evaluating, and approving changes, and ensures that changes are implemented in a controlled and coordinated manner. Includes procedures for legal and ethical reviews of proposed changes.

**Responsible Role Type:** Project Manager

**Primary Template:** PMI Change Management Plan Template

**Steps:**

- Establish a change control board.
- Define the change request process.
- Develop criteria for evaluating change requests.
- Establish a process for approving and implementing changes.
- Communicate changes to stakeholders.

**Approval Authorities:** Change Control Board, Legal Counsel, Ethics Review Board

### 6. High-Level Budget/Funding Framework

**ID:** 382bbae2-fad0-4e79-a9fb-6a065b565757

**Description:** A high-level overview of the project budget, including estimated costs for robot procurement, deployment, maintenance, and operation. It outlines the funding sources and the allocation of funds across different project activities. Includes contingency planning for cost overruns.

**Responsible Role Type:** Financial Analyst

**Steps:**

- Estimate the costs for robot procurement, deployment, maintenance, and operation.
- Identify potential funding sources.
- Allocate funds across different project activities.
- Develop a contingency plan for cost overruns.
- Obtain approval from relevant authorities.

**Approval Authorities:** Project Sponsor, Ministry of Finance

### 7. Funding Agreement Structure/Template

**ID:** 9f5e6f1b-c94e-4ed5-b918-7176fdeac486

**Description:** A template for structuring agreements with funding providers, detailing terms, conditions, and obligations. This ensures clarity and legal soundness in financial arrangements.

**Responsible Role Type:** Legal Counsel

**Steps:**

- Define the legal structure of the funding agreement.
- Outline the terms and conditions of the agreement.
- Specify the obligations of each party.
- Include clauses for dispute resolution and termination.
- Obtain approval from relevant authorities.

**Approval Authorities:** Project Sponsor, Ministry of Finance

### 8. Initial High-Level Schedule/Timeline

**ID:** eb87fb46-f5b4-4c5c-af9c-15110a96f33b

**Description:** A high-level timeline that outlines the major project milestones and their estimated completion dates. It provides a roadmap for the project and helps to track progress. Includes procurement, testing, and deployment phases.

**Responsible Role Type:** Project Manager

**Primary Template:** Gantt Chart Template

**Steps:**

- Identify major project milestones.
- Estimate the duration of each milestone.
- Sequence the milestones in a logical order.
- Assign resources to each milestone.
- Obtain approval from relevant authorities.

**Approval Authorities:** Project Sponsor

### 9. M&E Framework

**ID:** ff01611a-cf60-4199-b6e9-2ca6e69f8708

**Description:** A framework for monitoring and evaluating the project's progress and impact. It defines the key performance indicators (KPIs), data collection methods, and reporting frequency. Includes ethical, operational, and financial performance metrics.

**Responsible Role Type:** Performance Measurement Expert

**Primary Template:** World Bank Logical Framework

**Steps:**

- Define the project's objectives and outcomes.
- Identify key performance indicators (KPIs) for each objective.
- Determine data collection methods and frequency.
- Establish a reporting schedule.
- Obtain approval from relevant authorities.

**Approval Authorities:** Project Sponsor, Ethics Review Board

### 10. Robotic Policing Ethical Framework

**ID:** 0e181a00-2ac1-41b9-bcf6-a3cec9ac2d27

**Description:** A framework outlining the ethical principles and guidelines that will govern the deployment and operation of the police robots. It addresses issues such as algorithmic bias, data privacy, and the use of force. This framework will guide the development of policies and procedures for the project.

**Responsible Role Type:** Ethics Review Board

**Steps:**

- Identify key ethical considerations related to robotic policing.
- Develop ethical principles and guidelines to address these considerations.
- Establish a process for reviewing and updating the ethical framework.
- Obtain approval from relevant authorities.

**Approval Authorities:** Project Sponsor, Legal Counsel

### 11. Algorithmic Bias Mitigation Strategy

**ID:** d4a1357d-8cd2-4eaa-ba89-609efbab955c

**Description:** A detailed strategy for identifying and mitigating algorithmic bias in the robots' decision-making processes. It outlines the data sources, algorithms, and monitoring mechanisms that will be used to ensure fairness and equity. Includes procedures for continuous monitoring and auditing.

**Responsible Role Type:** AI Bias and Fairness Auditor

**Steps:**

- Identify potential sources of algorithmic bias.
- Develop methods for detecting and measuring bias.
- Implement mitigation strategies to reduce bias.
- Establish a process for continuous monitoring and auditing.
- Obtain approval from relevant authorities.

**Approval Authorities:** Project Sponsor, Ethics Review Board

### 12. Public Engagement and Education Strategy

**ID:** d3fdddeb-1c0c-41ec-9f1c-0b8b8581749a

**Description:** A strategy for engaging with the public to address their concerns and build trust in the robotic police force. It outlines the communication channels, community forums, and educational materials that will be used to inform the public about the project. Includes strategies for addressing potential protests and civil unrest.

**Responsible Role Type:** Community Liaison and Public Relations Manager

**Steps:**

- Identify key stakeholders and their concerns.
- Develop communication messages and materials.
- Establish communication channels and frequency.
- Organize community forums and events.
- Obtain approval from relevant authorities.

**Approval Authorities:** Project Sponsor

### 13. Legal Compliance Assessment

**ID:** 6af69344-f31d-4093-9150-992e89f8b2b1

**Description:** A comprehensive assessment of the project's compliance with EU and Belgian laws, including human rights, data protection, and criminal justice. It identifies potential legal risks and outlines mitigation strategies. Includes a detailed legal justification for the use of 'Terminal Judgement'.

**Responsible Role Type:** Legal and Ethical Compliance Officer

**Steps:**

- Identify relevant EU and Belgian laws.
- Assess the project's compliance with these laws.
- Identify potential legal risks.
- Develop mitigation strategies to address these risks.
- Obtain approval from relevant authorities.

**Approval Authorities:** Project Sponsor, Ethics Review Board

### 14. Robot Deactivation Protocol

**ID:** 19b1af00-a15d-40ae-b194-7cdb89f06a86

**Description:** A detailed protocol outlining the procedures for safely deactivating robots in case of malfunction, security breach, or ethical violation. It specifies the circumstances under which a robot can be deactivated, who has the authority to do so, and the steps that must be followed. Includes multi-factor authentication and audit trails.

**Responsible Role Type:** Robotics Maintenance and Logistics Coordinator

**Steps:**

- Define the circumstances under which a robot can be deactivated.
- Specify who has the authority to initiate deactivation.
- Outline the steps that must be followed during deactivation.
- Implement multi-factor authentication and audit trails.
- Obtain approval from relevant authorities.

**Approval Authorities:** Project Sponsor, Legal Counsel, Ethics Review Board

### 15. Job Transition Program Framework

**ID:** af8b3cf6-dfa8-44f5-8b46-242ba3e5f0ff

**Description:** A framework for supporting human police officers displaced by the deployment of robots. It outlines the retraining programs, career counseling services, and job placement assistance that will be provided to displaced officers. Includes strategies for mitigating social unrest.

**Responsible Role Type:** Labor Economist

**Steps:**

- Assess the potential job displacement caused by the project.
- Identify retraining programs and career counseling services.
- Develop a job placement assistance program.
- Establish a budget for the job transition program.
- Obtain approval from relevant authorities.

**Approval Authorities:** Project Sponsor, Ministry of Labor

### 16. Mission Creep Prevention Plan

**ID:** fefb2422-3957-4a0b-9330-9de8e0524e76

**Description:** A plan to prevent the expansion of the robots' authority beyond the initially defined scope. It defines clear boundaries for the robots' authority and establishes a process for regularly reviewing and reassessing the scope of their powers. Any proposed expansion of the robots' authority should be subject to rigorous ethical and legal review, as well as public consultation.

**Responsible Role Type:** Legal and Ethical Compliance Officer

**Steps:**

- Define the initial scope of the robots' authority.
- Establish a process for reviewing and reassessing the scope of their powers.
- Require rigorous ethical and legal review for any proposed expansion of authority.
- Conduct public consultation on any proposed expansion of authority.
- Obtain approval from relevant authorities.

**Approval Authorities:** Project Sponsor, Legal Counsel, Ethics Review Board

### 17. Terminal Judgement Appeal Process

**ID:** 03b79d47-af50-4253-8037-c523cd575791

**Description:** A transparent and independent appeal process for all cases of 'Terminal Judgement'. This process should be easily accessible to the public and provide a fair opportunity for individuals to challenge the robot's decision. The appeal process should be clearly defined and communicated to the public.

**Responsible Role Type:** Legal and Ethical Compliance Officer

**Steps:**

- Establish an independent review board.
- Define the appeal process.
- Ensure the appeal process is easily accessible to the public.
- Provide a fair opportunity for individuals to challenge the robot's decision.
- Communicate the appeal process to the public.

**Approval Authorities:** Project Sponsor, Legal Counsel, Ethics Review Board

## Documents to Find

### 1. Existing EU Human Rights Laws and Regulations

**ID:** 21210678-ba03-4031-9beb-47666cfe294b

**Description:** Existing laws, regulations, and directives at the EU level pertaining to human rights, due process, and the use of force by law enforcement. Needed to assess the legality of the project and identify potential violations. Intended audience: Legal Counsel, Ethics Review Board.

**Recency Requirement:** Current

**Responsible Role Type:** Legal and Ethical Compliance Officer

**Access Difficulty:** Medium: Requires familiarity with EU legal databases and potentially legal expertise.

**Steps:**

- Search the European Union's official website for legal documents.
- Consult with legal experts specializing in EU human rights law.
- Review relevant case law from the European Court of Human Rights.

### 2. Existing Belgian Laws and Regulations

**ID:** 104d2c7f-7139-4dc9-8c13-e45b349fd639

**Description:** Existing laws, regulations, and directives at the Belgian level pertaining to criminal justice, data protection, and the use of force by law enforcement. Needed to assess the legality of the project and identify potential violations. Intended audience: Legal Counsel, Ethics Review Board.

**Recency Requirement:** Current

**Responsible Role Type:** Legal and Ethical Compliance Officer

**Access Difficulty:** Medium: Requires familiarity with Belgian legal databases and potentially legal expertise.

**Steps:**

- Search the Belgian government's official website for legal documents.
- Consult with legal experts specializing in Belgian law.
- Review relevant case law from Belgian courts.

### 3. Participating Nations Crime Statistics Data

**ID:** 9126a7c7-48d3-4f3b-bf9d-4df2d325c1e1

**Description:** Statistical data on crime rates, types of crimes, and demographic information of offenders and victims in Brussels and other EU cities. Needed to understand crime patterns and assess the potential impact of the project. Intended audience: Project Manager, AI Bias and Fairness Auditor.

**Recency Requirement:** Most recent available year

**Responsible Role Type:** Data Analyst

**Access Difficulty:** Medium: Requires contacting statistical offices and potentially accessing restricted databases.

**Steps:**

- Contact national statistical offices in Belgium and other EU countries.
- Search Eurostat database for crime statistics.
- Review reports from law enforcement agencies.

### 4. Existing National Data Protection Laws/Policies

**ID:** 1f8c22f0-040d-449e-9cde-705f5c868036

**Description:** Existing national laws and policies related to data protection, privacy, and surveillance in Belgium and other EU countries. Needed to ensure compliance with data protection regulations. Intended audience: Legal Counsel, Cybersecurity Specialist.

**Recency Requirement:** Current

**Responsible Role Type:** Legal and Ethical Compliance Officer

**Access Difficulty:** Medium: Requires familiarity with national data protection laws and potentially legal expertise.

**Steps:**

- Search the websites of national data protection authorities.
- Consult with legal experts specializing in data protection law.
- Review relevant case law from national courts.

### 5. Official National Demographic Data

**ID:** 953d1f3c-3fbe-401d-90cc-44969c92201f

**Description:** Demographic data on the population of Brussels and other EU cities, including age, gender, ethnicity, and socioeconomic status. Needed to assess potential biases in the robots' decision-making and ensure equitable outcomes. Intended audience: AI Bias and Fairness Auditor, Community Liaison and Public Relations Manager.

**Recency Requirement:** Most recent available year

**Responsible Role Type:** Data Analyst

**Access Difficulty:** Easy: Publicly available data from statistical offices and government agencies.

**Steps:**

- Contact national statistical offices in Belgium and other EU countries.
- Search Eurostat database for demographic data.
- Review reports from government agencies.

### 6. Existing National Law Enforcement Policies/Guidelines

**ID:** e933750e-6863-4334-9759-56de19688507

**Description:** Existing national policies and guidelines related to the use of force by law enforcement in Belgium and other EU countries. Needed to ensure that the robots' use of force is consistent with legal and ethical standards. Intended audience: Legal Counsel, Ethics Review Board.

**Recency Requirement:** Current

**Responsible Role Type:** Legal and Ethical Compliance Officer

**Access Difficulty:** Medium: Requires contacting law enforcement agencies and potentially accessing restricted documents.

**Steps:**

- Contact national law enforcement agencies.
- Search government websites for law enforcement policies.
- Consult with legal experts specializing in criminal justice.

### 7. Unitree Robot Technical Specifications

**ID:** c9d2fc09-6447-4eff-89ad-c3ce3ae2efe6

**Description:** Detailed technical specifications of the Unitree robot, including its capabilities, limitations, and safety features. Needed to assess the robot's suitability for the project and identify potential technical risks. Intended audience: Robotics Maintenance and Logistics Coordinator, Cybersecurity Specialist.

**Recency Requirement:** Most recent available version

**Responsible Role Type:** Robotics Maintenance and Logistics Coordinator

**Access Difficulty:** Medium: Requires contacting the vendor and potentially accessing restricted documents.

**Steps:**

- Contact Unitree directly.
- Review Unitree's website and product documentation.
- Search for independent reviews and testing reports.

### 8. Existing National AI Ethics Guidelines/Frameworks

**ID:** b2bf3033-31f2-4102-976d-c6f4774afe16

**Description:** Existing national AI ethics guidelines and frameworks in Belgium and other EU countries. Needed to ensure that the project aligns with ethical best practices. Intended audience: Ethics Review Board, Legal and Ethical Compliance Officer.

**Recency Requirement:** Current

**Responsible Role Type:** Legal and Ethical Compliance Officer

**Access Difficulty:** Medium: Requires searching government websites and potentially contacting experts.

**Steps:**

- Search government websites for AI ethics guidelines.
- Consult with AI ethics experts.
- Review reports from research institutions and think tanks.

### 9. Official National Mental Health Survey Data

**ID:** 96536ac5-5978-408f-8a67-011c149dd26a

**Description:** Survey data on public attitudes towards technology and law enforcement in Belgium. Needed to assess public acceptance of the project and identify potential concerns. Intended audience: Community Liaison and Public Relations Manager.

**Recency Requirement:** Within last 5 years

**Responsible Role Type:** Data Analyst

**Access Difficulty:** Medium: Requires contacting statistical offices and potentially accessing restricted databases.

**Steps:**

- Contact national statistical offices in Belgium.
- Search government websites for survey data.
- Review reports from research institutions and think tanks.

### 10. Existing National Job Transition Program Policies

**ID:** 4ec5dd04-2080-438d-a962-95c6f039cb49

**Description:** Policies and guidelines related to job transition programs and support for displaced workers in Belgium. Needed to develop a job transition program for police officers displaced by the robots. Intended audience: Labor Economist.

**Recency Requirement:** Current

**Responsible Role Type:** Labor Economist

**Access Difficulty:** Medium: Requires searching government websites and potentially contacting agencies.

**Steps:**

- Search government websites for job transition program policies.
- Contact relevant government agencies.
- Review reports from research institutions and think tanks.