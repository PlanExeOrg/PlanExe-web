**Purpose:** business

**Purpose Detailed:** Societal initiative to combat crime using robotic police force with autonomous judgement and execution capabilities.

**Topic:** Deployment of police robots in Brussels and other EU cities to combat crime.