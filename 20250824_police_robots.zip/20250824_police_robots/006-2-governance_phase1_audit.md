
## Audit - Corruption Risks

- Bribery of local officials to expedite permits and approvals for robot deployment and facility construction.
- Kickbacks from Unitree (or alternative robot supplier) in exchange for selecting their robots over competitors, even if they are not the best fit.
- Conflicts of interest involving project personnel who have financial ties to Unitree or other vendors.
- Misuse of confidential project information (e.g., deployment locations, security protocols) for personal gain or to benefit criminal elements.
- Trading favors with contractors involved in building the maintenance facility or data center, such as awarding contracts to friends or family members.

## Audit - Misallocation Risks

- Inflated invoices from Unitree or other vendors, leading to overpayment for robots or services.
- Double spending on resources, such as paying for the same training program twice or purchasing redundant equipment.
- Inefficient allocation of personnel, such as assigning too many technicians to robot maintenance or hiring unnecessary consultants.
- Unauthorized use of project funds for personal expenses or unrelated activities.
- Misreporting project progress or results to justify continued funding or to conceal delays or failures.

## Audit - Procedures

- Conduct periodic internal reviews of all financial transactions, including procurement, contracts, and expenses, to identify irregularities or discrepancies (quarterly, Internal Audit Department).
- Implement a robust contract review process with pre-defined thresholds for independent legal and financial review of all contracts exceeding a certain value (e.g., 50,000 EUR, Legal Department).
- Establish a whistleblower mechanism for reporting suspected fraud or corruption, with clear procedures for investigation and resolution (ongoing, Ethics Review Board).
- Perform regular compliance checks to ensure adherence to all applicable laws and regulations, including GDPR, EU human rights standards, and Belgian law (annually, Legal Department).
- Conduct post-project external audit to assess the overall effectiveness and efficiency of the project, including financial management, risk management, and compliance (post-Phase 1, External Audit Firm).

## Audit - Transparency Measures

- Publish a project progress dashboard that tracks key milestones, budget expenditures, and crime reduction statistics (monthly, Project Management Office).
- Publish minutes of key meetings of the Ethics Review Board, redacting sensitive information as necessary (monthly, Ethics Review Board Secretariat).
- Establish a publicly accessible website with information about the project, including its goals, objectives, budget, and progress (ongoing, Public Relations Department).
- Document and publish the selection criteria for all major decisions, such as vendor selection and deployment locations (as decisions are made, Project Management Office).
- Implement a clear and accessible process for citizens to file complaints or concerns about the robots' actions, with timely responses and investigations (ongoing, Community Relations Department).