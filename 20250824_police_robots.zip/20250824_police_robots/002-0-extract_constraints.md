## Positive Constraints

- Insert police robots in Brussels
- Combat escalating crime
- Use police robots similar to the "Unitree" humanoid robot
- Deploy 500 police robots
- Robots act as officer, judge, jury, and executioner
- Robots issue on-the-spot sentences
- Robots administer Terminal Judgement for minor offenses
- Terminal Judgement is recorded but cannot be appealed
- Phase 1: Brussels
- Phase 2: Gradual rollout to other EU cities
- Project start ASAP
