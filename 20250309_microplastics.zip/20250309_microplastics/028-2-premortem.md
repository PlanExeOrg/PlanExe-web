A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The project's reliance on a centralized data system will ensure data quality, security, and accessibility. | Simulate a data breach and assess the system's ability to prevent data loss and unauthorized access. | The simulation reveals vulnerabilities that could compromise data integrity or confidentiality. |
| A2 | Partner labs will consistently adhere to the detailed SOP manual, ensuring data comparability across all sites. | Conduct a blind proficiency test with all partner labs using identical samples and protocols. | The results show significant inter-lab variability exceeding pre-defined acceptable thresholds. |
| A3 | Policymakers will readily adopt the program's recommendations, leading to concrete action on microplastic pollution. | Present preliminary findings and policy recommendations to a panel of relevant policymakers and solicit their feedback. | The policymakers express significant reservations about the feasibility or political palatability of the recommendations. |
| A4 | The chosen deep-sea reference sites will remain relatively pristine throughout the project's duration, providing a stable baseline for comparison. | Analyze historical data and conduct preliminary sampling at the chosen reference sites to assess current contamination levels and identify potential sources of pollution. | Preliminary data reveals significant existing microplastic contamination or evidence of increasing pollution trends at the chosen reference sites. |
| A5 | The project's communication strategy will effectively reach and engage diverse stakeholder groups, fostering public awareness and support. | Conduct a pilot communication campaign targeting a representative sample of the intended audience and measure their awareness, understanding, and engagement with the project's message. | The pilot campaign fails to significantly increase awareness or engagement among the target audience. |
| A6 | The project's reliance on existing laboratory infrastructure will be sufficient to handle the volume and complexity of sample analysis. | Conduct a capacity assessment of each partner lab, evaluating their equipment, personnel, and throughput capabilities. | The capacity assessment reveals significant bottlenecks or limitations that could hinder sample processing and data analysis. |
| A7 | The cost estimates for deep-sea sampling will remain accurate throughout the project, allowing for the planned sampling intensity without budget overruns. | Obtain updated quotes from multiple research vessel operators and deep-sea equipment suppliers, factoring in potential fuel price fluctuations and logistical challenges. | The updated quotes significantly exceed the original cost estimates, indicating a potential budget shortfall for deep-sea sampling. |
| A8 | The project's data management plan will effectively address the challenges of integrating diverse datasets from multiple sources, ensuring data interoperability and usability. | Conduct a pilot data integration exercise using sample datasets from each partner lab, assessing the compatibility of data formats, metadata standards, and data quality control procedures. | The pilot exercise reveals significant data integration challenges, such as incompatible data formats, missing metadata, or inconsistent data quality, hindering data interoperability. |
| A9 | The project's policy recommendations will align with the priorities and agendas of key international bodies, increasing the likelihood of adoption and implementation. | Analyze the current policy agendas and priorities of the EU Commission, UN Environment Programme, and other relevant international bodies, assessing the alignment of the project's preliminary findings and policy recommendations. | The analysis reveals a significant misalignment between the project's recommendations and the current policy priorities of key international bodies, indicating a potential lack of policy relevance. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Data Fortress Fails | Process/Financial | A1 | IT Security Lead | CRITICAL (15/25) |
| FM2 | The Lab Labyrinth | Technical/Logistical | A2 | Laboratory Network Liaison | CRITICAL (16/25) |
| FM3 | The Policy Pariah | Market/Human | A3 | Policy Engagement Specialist | HIGH (12/25) |
| FM4 | The Shifting Baseline | Process/Financial | A4 | Sampling Campaign Coordinator | MEDIUM (8/25) |
| FM5 | The Echo Chamber | Technical/Logistical | A5 | Communications and Outreach Coordinator | HIGH (9/25) |
| FM6 | The Analytical Avalanche | Market/Human | A6 | Laboratory Network Liaison | CRITICAL (16/25) |
| FM7 | The Abyss of Costs | Process/Financial | A7 | Project Manager | CRITICAL (15/25) |
| FM8 | The Data Babel | Technical/Logistical | A8 | Data Quality Manager | CRITICAL (16/25) |
| FM9 | The Policy Vacuum | Market/Human | A9 | Policy Engagement Specialist | HIGH (12/25) |


### Failure Modes

#### FM1 - The Data Fortress Fails

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: IT Security Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's centralized data system, intended to ensure data quality and security, becomes a single point of failure. A sophisticated cyberattack exploits a vulnerability, compromising a significant portion of the collected data. Backups are found to be incomplete or corrupted, leading to irreversible data loss. The project incurs substantial costs for forensic investigation, system remediation, and legal counsel. The credibility of the entire program is severely damaged, and the flagship report is delayed indefinitely. Funding agencies lose confidence, and future funding opportunities are jeopardized. The project struggles to recover, facing legal challenges and reputational damage.

##### Early Warning Signs
- Failed vulnerability scans of the centralized data system
- Unusual network activity or suspicious login attempts
- Delays in implementing security patches or updates

##### Tripwires
- Critical vulnerability identified in the centralized data system with a severity score >= 8
- Data breach detected affecting >= 10% of the dataset
- Backup system failure lasting >= 7 days

##### Response Playbook
- Contain: Immediately isolate the affected systems and prevent further data exfiltration.
- Assess: Conduct a thorough forensic investigation to determine the extent of the breach and identify the root cause.
- Respond: Implement a comprehensive security remediation plan, including patching vulnerabilities, strengthening access controls, and improving data backup procedures.


**STOP RULE:** Irreversible loss of >= 50% of the core dataset due to a security breach.

---

#### FM2 - The Lab Labyrinth

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Laboratory Network Liaison
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
Despite the detailed SOP manual, partner labs deviate from standardized protocols due to equipment limitations, personnel turnover, or differing interpretations of the guidelines. This leads to significant inter-lab variability in microplastic concentration measurements, rendering the data incomparable across sites. The flagship report is delayed as the data analysis team struggles to reconcile the disparate datasets. Attempts to apply correction factors prove inadequate, and the scientific community questions the validity of the findings. The project fails to achieve its goal of establishing a standardized methodology for microplastic assessment, undermining its long-term impact.

##### Early Warning Signs
- Increasing discrepancies in inter-lab calibration exercises
- High turnover rate of trained personnel in partner labs
- Delayed submission of data from partner labs

##### Tripwires
- Average R-squared value in inter-lab calibration exercises falls below 0.8
- Coefficient of variation (CV) for microplastic concentration measurements exceeds 20% across labs
- >= 3 partner labs report significant deviations from the SOP manual

##### Response Playbook
- Contain: Immediately halt all data collection and analysis activities.
- Assess: Conduct a thorough audit of each partner lab's adherence to the SOP manual and identify the sources of variability.
- Respond: Provide targeted training and support to partner labs, revise the SOP manual to address ambiguities, and implement more stringent quality control measures.


**STOP RULE:** Inability to achieve acceptable data comparability across partner labs after three rounds of corrective action.

---

#### FM3 - The Policy Pariah

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Policy Engagement Specialist
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project's policy recommendations, while scientifically sound, are deemed politically infeasible or economically impractical by policymakers. Key stakeholders, such as the plastics industry and fishing communities, actively lobby against the recommendations, citing concerns about job losses and economic disruption. The recommendations are ignored by the EU Commission and national governments, and no concrete action is taken to address microplastic pollution. The project fails to achieve its goal of influencing policy decisions, and its findings are relegated to academic journals with limited real-world impact. Public interest wanes, and the project is viewed as an expensive exercise in ivory-tower research.

##### Early Warning Signs
- Lack of engagement from key policymakers at relevant forums
- Negative media coverage or public criticism of the policy recommendations
- Active lobbying efforts against the recommendations by industry groups

##### Tripwires
- No citations of the project's findings in any EU or UN policy documents after 12 months of publication
- Negative sentiment score >= 0.6 in media coverage of the policy recommendations
- Formal opposition to the recommendations expressed by >= 2 major industry associations

##### Response Playbook
- Contain: Immediately reassess the policy recommendations and identify areas for compromise.
- Assess: Conduct a thorough stakeholder analysis to understand the concerns of key policymakers and industry groups.
- Respond: Revise the policy recommendations to address stakeholder concerns, develop targeted communication materials, and engage in active dialogue with policymakers and industry representatives.


**STOP RULE:** Complete rejection of the project's policy recommendations by all major target audiences (EU Commission, UN Environment Programme, national governments).

---

#### FM4 - The Shifting Baseline

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Sampling Campaign Coordinator
- **Risk Level:** MEDIUM 8/25 (Likelihood 2/5 × Impact 4/5)

##### Failure Story
The project selects deep-sea reference sites based on initial assessments of relative pristine conditions. However, unforeseen events, such as increased deep-sea mining activity or shifts in ocean currents, lead to significant microplastic contamination at these sites during the project's timeline. The baseline shifts, making it difficult to accurately assess the extent of global microplastic pollution. The project's findings are questioned, and the credibility of the assessment is undermined. Additional funding is required to identify and sample new reference sites, straining the budget and delaying the flagship report. The project struggles to adapt to the changing environmental conditions, and its conclusions are deemed unreliable.

##### Early Warning Signs
- Increased industrial activity (e.g., deep-sea mining) near the reference sites
- Changes in ocean current patterns or weather events affecting the reference sites
- Reports of increased microplastic pollution in nearby areas

##### Tripwires
- Microplastic concentration at reference sites increases by >= 50% compared to baseline levels
- New deep-sea mining permits issued within 500 km of reference sites
- Major shift in ocean current patterns detected near reference sites

##### Response Playbook
- Contain: Immediately increase the frequency of sampling at the affected reference sites to monitor the extent of contamination.
- Assess: Conduct a thorough investigation to determine the source and cause of the increased contamination.
- Respond: Identify and sample alternative reference sites, adjust the data analysis methods to account for the shifting baseline, and communicate the changes to stakeholders.


**STOP RULE:** The chosen deep-sea reference sites are deemed unsuitable due to irreversible contamination, and no viable alternative sites can be identified within the project's budget and timeline.

---

#### FM5 - The Echo Chamber

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Communications and Outreach Coordinator
- **Risk Level:** HIGH 9/25 (Likelihood 3/5 × Impact 3/5)

##### Failure Story
The project's communication strategy, designed to reach diverse stakeholder groups, fails to resonate with the intended audience. The messaging is too technical, the channels are ineffective, or the content is not engaging. Public awareness of the project's findings remains low, and stakeholder engagement is minimal. Policymakers are not adequately informed, and the project's recommendations are ignored. The data dashboard is underutilized, and the project's website receives little traffic. The project struggles to translate its scientific findings into actionable insights for the broader community, limiting its real-world impact.

##### Early Warning Signs
- Low engagement rates on social media platforms
- Limited media coverage of the project's findings
- Low attendance at public events and webinars
- Lack of feedback from stakeholders

##### Tripwires
- Website traffic remains below 1000 unique visitors per month
- Social media engagement (likes, shares, comments) is < 50 per post
- No media coverage of the project's findings in major news outlets
- Stakeholder satisfaction score < 3 out of 5 in surveys

##### Response Playbook
- Contain: Immediately reassess the communication strategy and identify areas for improvement.
- Assess: Conduct a thorough audience analysis to understand their needs, preferences, and communication styles.
- Respond: Revise the messaging to be more accessible and engaging, diversify the communication channels, and actively solicit feedback from stakeholders.


**STOP RULE:** Inability to achieve significant stakeholder engagement or public awareness after two major communication strategy revisions.

---

#### FM6 - The Analytical Avalanche

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Laboratory Network Liaison
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project's reliance on existing laboratory infrastructure proves insufficient to handle the volume and complexity of sample analysis. Partner labs become overwhelmed, leading to significant delays in sample processing and data analysis. Equipment malfunctions, personnel shortages, and competing priorities further exacerbate the situation. The project struggles to meet its data delivery deadlines, and the flagship report is delayed. The quality of the data is compromised due to rushed analysis and inadequate quality control. The project's credibility is damaged, and its findings are questioned by the scientific community.

##### Early Warning Signs
- Increasing backlog of unprocessed samples in partner labs
- Frequent equipment malfunctions or downtime
- High workload and stress levels reported by lab personnel
- Delays in data submission from partner labs

##### Tripwires
- Sample processing time exceeds 6 months per sample
- Backlog of unprocessed samples reaches >= 20% of total collected samples
- Equipment downtime exceeds 10% of total operating time
- Significant increase in reported errors or inconsistencies in lab analysis

##### Response Playbook
- Contain: Immediately prioritize sample processing and allocate additional resources to the most critical tasks.
- Assess: Conduct a thorough assessment of each partner lab's capacity and identify the bottlenecks.
- Respond: Outsource sample analysis to external labs, invest in additional equipment or personnel, and streamline the analytical workflows.


**STOP RULE:** Inability to process samples within a reasonable timeframe (e.g., 9 months) due to persistent laboratory bottlenecks, rendering the project's timeline unachievable.

---

#### FM7 - The Abyss of Costs

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The initial cost estimates for deep-sea sampling prove to be drastically underestimated. Unexpected fuel price spikes, equipment failures requiring costly repairs, and unforeseen logistical challenges in remote ocean locations drive expenses far beyond the allocated budget. The project is forced to drastically reduce the planned deep-sea sampling intensity, limiting the scope of the assessment and undermining the representativeness of the data. The flagship report is delayed as the team scrambles to secure additional funding, and the project's credibility suffers. The reduced deep-sea data leads to criticism from the scientific community, questioning the validity of the overall assessment.

##### Early Warning Signs
- Fuel prices increase by >= 20% above initial estimates
- Equipment failure requiring costly repairs on a deep-sea research vessel
- Unforeseen logistical delays or complications during deep-sea sampling operations

##### Tripwires
- Deep-sea sampling costs exceed the allocated budget by >= 15%
- Planned deep-sea sampling sites reduced by >= 40%
- Research vessel downtime due to equipment failure exceeds 14 days

##### Response Playbook
- Contain: Immediately halt all non-essential deep-sea sampling activities and renegotiate contracts with vessel operators and equipment suppliers.
- Assess: Conduct a thorough review of the deep-sea sampling budget and identify areas for cost reduction.
- Respond: Secure additional funding from alternative sources, prioritize sampling at the most critical locations, and explore the use of less expensive sampling technologies.


**STOP RULE:** Inability to secure sufficient funding to conduct even a minimal level of deep-sea sampling, rendering the deep-sea component of the assessment unviable.

---

#### FM8 - The Data Babel

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Data Quality Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
Despite the data management plan, significant challenges arise in integrating diverse datasets from multiple partner labs. Incompatible data formats, inconsistent metadata standards, and varying data quality control procedures create a data integration nightmare. The data analysis team spends months wrangling the data, but significant errors and inconsistencies persist. The flagship report is delayed as the team struggles to produce a coherent and reliable assessment. The open-access database is launched with incomplete and unreliable data, undermining its usability and value. The project fails to achieve its goal of creating a comprehensive and accessible data resource, limiting its long-term impact.

##### Early Warning Signs
- Increasing reports of data integration errors or inconsistencies
- Delays in data submission from partner labs
- Inability to automate data integration processes
- High workload and stress levels reported by the data analysis team

##### Tripwires
- Data integration error rate exceeds 10%
- Data integration process takes >= 2x longer than initially planned
- Significant inconsistencies identified in data from different partner labs after integration
- User complaints about data quality and usability in the open-access database

##### Response Playbook
- Contain: Immediately halt all data integration activities and reassess the data management plan.
- Assess: Conduct a thorough audit of the data integration process and identify the sources of incompatibility.
- Respond: Develop standardized data formats and metadata standards, provide training to partner labs on data management procedures, and implement more robust data validation checks.


**STOP RULE:** Inability to integrate >= 50% of the collected data due to persistent data incompatibility issues, rendering the overall assessment incomplete and unreliable.

---

#### FM9 - The Policy Vacuum

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Policy Engagement Specialist
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project's policy recommendations, while scientifically sound, fail to align with the current priorities and agendas of key international bodies. The EU Commission is focused on other environmental issues, the UN Environment Programme is undergoing a restructuring, and national governments are preoccupied with economic concerns. The project's recommendations are ignored, and no concrete action is taken to address microplastic pollution. The project fails to achieve its goal of influencing policy decisions, and its findings are relegated to academic journals with limited real-world impact. Public interest wanes, and the project is viewed as an expensive exercise in ivory-tower research.

##### Early Warning Signs
- Lack of engagement from key policymakers at relevant forums
- Shifting policy priorities at the EU Commission and UN Environment Programme
- Increased focus on economic issues and reduced emphasis on environmental concerns by national governments

##### Tripwires
- No invitations to present the project's findings at major international policy conferences
- No citations of the project's findings in any EU or UN policy documents after 12 months of publication
- Negative feedback from policymakers regarding the relevance or feasibility of the recommendations

##### Response Playbook
- Contain: Immediately reassess the policy recommendations and identify areas for alignment with current policy priorities.
- Assess: Conduct a thorough analysis of the current policy landscape and identify emerging opportunities for influencing policy decisions.
- Respond: Revise the policy recommendations to address current policy priorities, develop targeted communication materials, and engage in active dialogue with policymakers and international organizations.


**STOP RULE:** Complete lack of interest or engagement from key international bodies, indicating a fundamental misalignment between the project's recommendations and the global policy agenda.
