### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and direction for the €24 million, 24-month pan-European research program, ensuring alignment with overall goals and objectives. Given the project's scale, complexity, and policy implications, a high-level steering committee is crucial for strategic decision-making and risk management.

**Responsibilities:**

- Approve the project management plan and any major revisions.
- Monitor project progress against key performance indicators (KPIs).
- Approve budget allocations and expenditures above €500,000.
- Review and approve major project deliverables, including the flagship report and policy briefs.
- Oversee risk management and mitigation strategies.
- Resolve strategic conflicts and escalate issues as needed.
- Ensure alignment with Horizon Europe grant requirements and ethical standards.

**Initial Setup Actions:**

- Finalize Terms of Reference and operating procedures.
- Appoint a chairperson.
- Establish a meeting schedule.
- Review and approve the initial project management plan.
- Define the escalation path for unresolved issues.

**Membership:**

- Senior representatives from GEOMAR Helmholtz Centre for Ocean Research (Lead Institution)
- Senior representatives from Kiel University (Lead Institution)
- Senior representatives from each consortium partner (Ifremer, National Oceanography Centre, ICM-CSIC)
- Independent expert in ocean policy (External)
- Representative from Horizon Europe funding agency (Observer)

**Decision Rights:** Strategic decisions related to project scope, budget, timeline, and key deliverables. Approval of expenditures exceeding €500,000. Approval of major changes to the project plan. Decisions regarding strategic partnerships and collaborations.

**Decision Mechanism:** Decisions are made by majority vote, with the chairperson having the tie-breaking vote. Any member can raise a concern that requires a formal vote. Dissenting opinions are recorded in the meeting minutes.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of project progress against KPIs.
- Financial performance review.
- Risk management updates.
- Discussion and approval of major deliverables.
- Strategic planning and decision-making.
- Review of compliance with ethical and regulatory requirements.

**Escalation Path:** Horizon Europe funding agency (for issues related to grant compliance or funding disputes). Senior Management of GEOMAR Helmholtz Centre for Ocean Research (for unresolved strategic conflicts within the consortium).
### 2. Core Project Team

**Rationale for Inclusion:** Manages the day-to-day execution of the project, ensuring tasks are completed on time and within budget. Given the project's multi-site nature and complex sampling requirements, a dedicated project team is essential for operational efficiency and coordination.

**Responsibilities:**

- Develop and maintain the project schedule.
- Manage project resources and budget.
- Coordinate sampling campaigns and laboratory analyses.
- Monitor project risks and implement mitigation strategies.
- Prepare progress reports for the Project Steering Committee.
- Manage communication and collaboration among consortium partners.
- Ensure compliance with data management and quality assurance protocols.

**Initial Setup Actions:**

- Define roles and responsibilities for each team member.
- Establish communication protocols and reporting procedures.
- Develop a detailed project schedule and budget.
- Set up project management tools and systems.
- Conduct a kickoff meeting with all team members.

**Membership:**

- Project Manager (GEOMAR)
- Work Package Leaders (from each consortium partner)
- Data Manager
- Communications Manager
- Sampling Coordinator

**Decision Rights:** Operational decisions related to task assignments, resource allocation within approved budgets, and day-to-day project execution. Approval of expenditures up to €50,000. Decisions regarding minor changes to the project schedule.

**Decision Mechanism:** Decisions are made by the Project Manager in consultation with the Work Package Leaders. Consensus is preferred, but the Project Manager has the final decision-making authority. Disagreements are documented and escalated to the Project Steering Committee if necessary.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of project progress against schedule.
- Discussion of project risks and issues.
- Coordination of sampling campaigns and laboratory analyses.
- Budget tracking and resource allocation.
- Communication and collaboration updates.
- Action item review.

**Escalation Path:** Project Steering Committee (for issues exceeding the team's authority or requiring strategic guidance). Senior Management of GEOMAR Helmholtz Centre for Ocean Research (for unresolved operational conflicts within the team).
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides expert advice and guidance on technical aspects of the project, ensuring the scientific rigor and validity of the research. Given the complexity of microplastic analysis and the need for standardized methodologies, a technical advisory group is crucial for maintaining data quality and comparability.

**Responsibilities:**

- Review and approve sampling protocols and analytical methods.
- Provide guidance on data analysis and interpretation.
- Assess the validity and reliability of research findings.
- Advise on the development of the proposed ISO standard methodology.
- Review and approve the flagship report and other scientific publications.
- Provide technical expertise on emerging issues and challenges.
- Ensure adherence to best practices in microplastic research.

**Initial Setup Actions:**

- Identify and recruit leading experts in microplastic research, oceanography, and analytical chemistry.
- Finalize Terms of Reference and operating procedures.
- Establish a meeting schedule.
- Review and approve the initial sampling protocols and analytical methods.
- Define the process for providing technical advice and guidance.

**Membership:**

- Leading experts in microplastic research (External)
- Experts in oceanography and marine ecology (External)
- Experts in analytical chemistry and spectroscopy (External)
- Representative from the Data Management Team
- Representative from the Sampling Coordination Team

**Decision Rights:** Provides recommendations on technical aspects of the project. Approves sampling protocols, analytical methods, and data analysis procedures. Reviews and approves scientific publications. Decisions are advisory, but the Project Steering Committee gives significant weight to the TAG's recommendations.

**Decision Mechanism:** Decisions are made by consensus among the members of the Technical Advisory Group. If consensus cannot be reached, the issue is escalated to the Project Steering Committee for a final decision.

**Meeting Cadence:** Semi-annually

**Typical Agenda Items:**

- Review of sampling protocols and analytical methods.
- Discussion of data analysis and interpretation.
- Assessment of research findings.
- Guidance on the development of the proposed ISO standard methodology.
- Review of scientific publications.
- Discussion of emerging issues and challenges.

**Escalation Path:** Project Steering Committee (for issues requiring strategic guidance or resource allocation). Senior Scientists at GEOMAR Helmholtz Centre for Ocean Research (for unresolved technical disputes within the group).
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures the project adheres to the highest ethical standards and complies with all relevant regulations, including GDPR and environmental regulations. Given the sensitive nature of environmental research and the need to protect personal data, an ethics and compliance committee is crucial for maintaining public trust and avoiding legal challenges.

**Responsibilities:**

- Review and approve all research protocols to ensure ethical compliance.
- Oversee data protection and privacy compliance (GDPR).
- Ensure compliance with environmental regulations and permitting requirements.
- Develop and implement a code of conduct for all project personnel.
- Investigate and resolve any ethical or compliance violations.
- Provide training on ethical and compliance issues.
- Conduct regular audits to assess compliance with relevant regulations.

**Initial Setup Actions:**

- Identify and recruit experts in ethics, data protection, and environmental law.
- Finalize Terms of Reference and operating procedures.
- Establish a meeting schedule.
- Develop a code of conduct for all project personnel.
- Establish procedures for reporting and investigating ethical or compliance violations.

**Membership:**

- Expert in research ethics (External)
- Expert in data protection and privacy law (External)
- Expert in environmental law and regulations (External)
- Data Manager
- Representative from the Legal Department of GEOMAR Helmholtz Centre for Ocean Research

**Decision Rights:** Approves research protocols, data protection policies, and environmental compliance plans. Investigates and resolves ethical or compliance violations. Decisions are binding and must be implemented by the project team.

**Decision Mechanism:** Decisions are made by majority vote, with the chairperson having the tie-breaking vote. Any member can raise a concern that requires a formal vote. Dissenting opinions are recorded in the meeting minutes.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of research protocols for ethical compliance.
- Discussion of data protection and privacy issues.
- Review of environmental compliance plans.
- Investigation of ethical or compliance violations.
- Training on ethical and compliance issues.
- Audit reports and compliance assessments.

**Escalation Path:** Senior Management of GEOMAR Helmholtz Centre for Ocean Research (for unresolved ethical or compliance violations). External legal counsel (for issues requiring legal expertise or independent investigation).