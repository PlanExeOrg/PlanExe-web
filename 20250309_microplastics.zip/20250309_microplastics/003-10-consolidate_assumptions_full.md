# Purpose

**Purpose:** business

**Purpose Detailed:** Societal initiative to assess microplastic contamination, develop policy recommendations, and standardize measurement methodologies.

**Topic:** Pan-European research and policy program on microplastic contamination in oceans

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** This plan *unequivocally* involves extensive physical activity. It requires: (1) physical sampling of water, sediment, and biota from multiple ocean locations (North Atlantic, Mediterranean, Baltic, South Pacific gyre); (2) laboratory analysis using specialized equipment (FTIR, Raman spectroscopy); (3) physical coordination of a large research team across multiple European institutes; (4) securing ship time on research vessels; (5) physical meetings and collaboration; and (6) dissemination of findings through policy briefs and presentations. The plan *cannot* be executed without these physical components.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Marine research facilities
- Access to ocean sampling sites (North Atlantic, Mediterranean, Baltic, South Pacific)
- Laboratories with FTIR and Raman spectroscopy equipment
- Office space for 45 FTE
- Proximity to GEOMAR Helmholtz Centre for Ocean Research and Kiel University

## Location 1
Germany

Kiel

GEOMAR Helmholtz Centre for Ocean Research / Kiel University

**Rationale**: The program is headquartered in Kiel, leveraging GEOMAR and Kiel University's marine sciences cluster.

## Location 2
France

Brest

Ifremer (French Research Institute for Exploitation of the Sea)

**Rationale**: Ifremer is a leading marine research institute with expertise in microplastic research and access to ocean sampling sites in the Atlantic and Mediterranean.

## Location 3
United Kingdom

Southampton

National Oceanography Centre

**Rationale**: The National Oceanography Centre in Southampton has extensive experience in oceanographic research, including deep-sea sampling and analysis, and is well-equipped for microplastic studies.

## Location 4
Spain

Barcelona

Institute of Marine Sciences (ICM-CSIC)

**Rationale**: The ICM-CSIC in Barcelona is a leading marine research institute with expertise in microplastic research and access to ocean sampling sites in the Mediterranean.

## Location Summary
The program is headquartered in Kiel, Germany, leveraging GEOMAR and Kiel University. Additional locations in Brest (France), Southampton (UK), and Barcelona (Spain) are suggested due to their established marine research facilities, access to relevant ocean sampling sites, and expertise in microplastic research.

# Currency Strategy

This plan involves money.

## Currencies

- **EUR:** The project budget is defined in EUR, and the project spans multiple European countries.
- **GBP:** The project involves research institutes in the United Kingdom.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting and reporting. Local currencies (e.g., GBP) may be used for local transactions within the UK.

# Identify Risks


## Risk 1 - Regulatory & Permitting
Delays in securing ethics and sampling permits, particularly for international waters and deep-sea sites, could delay the start of sampling campaigns. Different countries have different regulations, and obtaining permits for all sampling locations could be a lengthy process.

**Impact:** A delay of 2-6 months in the sampling schedule, potentially impacting the project timeline and budget. Could also lead to legal challenges and reputational damage.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Begin the permit application process as early as possible, engaging with regulatory bodies in each relevant country. Develop contingency plans for alternative sampling locations if permits are delayed or denied. Establish relationships with local experts to navigate the permitting process.

## Risk 2 - Technical
Inconsistencies in laboratory methodologies across partner institutions, despite harmonization efforts, could lead to data comparability issues. FTIR and Raman spectroscopy can be sensitive to variations in sample preparation and instrument calibration.

**Impact:** Reduced data quality and comparability, requiring significant rework and potentially compromising the validity of the flagship report. Could lead to a 10-20% increase in analytical costs due to re-analysis.

**Likelihood:** Medium

**Severity:** High

**Action:** Implement rigorous inter-lab calibration exercises with blind samples. Establish a centralized QA/QC laboratory or a detailed SOP manual. Invest in training programs to ensure consistent application of methodologies across all partner labs. Regular proficiency testing should be conducted.

## Risk 3 - Financial
Cost overruns due to unforeseen expenses (e.g., increased shipping costs, equipment repairs, higher-than-expected personnel costs) could strain the budget. The €24 million budget may be insufficient to cover all planned activities, especially deep-sea sampling.

**Impact:** Reduced sampling scope, delayed report publication, or compromised data quality. Could lead to a 5-10% budget overrun, requiring additional funding or project scope reduction.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a detailed budget with contingency funds. Regularly monitor expenses and identify potential cost-saving measures. Explore opportunities for additional funding from other sources. Negotiate favorable rates with suppliers and service providers.

## Risk 4 - Operational
Difficulty securing sufficient ship time on research vessels for deep-water sampling could delay or limit the scope of the sampling campaigns. Reliance on berth-sharing agreements may not provide sufficient access to research vessels.

**Impact:** Reduced sampling coverage, particularly in deep-sea environments, compromising the representativeness of the data. Could lead to a delay of 3-9 months in the sampling schedule.

**Likelihood:** Medium

**Severity:** High

**Action:** Establish strong relationships with research vessel operators. Negotiate long-term berth-sharing agreements. Explore alternative sampling platforms (e.g., autonomous underwater vehicles). Develop contingency plans for alternative sampling locations if ship time is unavailable.

## Risk 5 - Supply Chain
Disruptions in the supply of critical consumables (e.g., filters, solvents, calibration standards) could delay laboratory analyses. Global supply chain issues could impact the availability and cost of these materials.

**Impact:** Delayed sample processing and report publication. Could lead to a 1-3 month delay in the analytical schedule.

**Likelihood:** Low

**Severity:** Medium

**Action:** Establish relationships with multiple suppliers for critical consumables. Maintain a sufficient inventory of essential materials. Explore alternative suppliers and materials. Implement a robust inventory management system.

## Risk 6 - Social
Negative public perception or stakeholder opposition to the research program could undermine its credibility and impact. Concerns about the environmental impact of sampling activities or the potential for biased results could arise.

**Impact:** Reduced stakeholder engagement, difficulty securing permits, and compromised policy influence. Could lead to reputational damage and reduced public trust.

**Likelihood:** Low

**Severity:** Medium

**Action:** Implement a proactive communication strategy to engage with stakeholders and address concerns. Ensure transparency in all research activities. Engage with local communities and address their concerns. Emphasize the program's commitment to environmental protection and scientific integrity.

## Risk 7 - Environmental
Sampling activities could have unintended environmental impacts, such as disturbance of marine ecosystems or introduction of contaminants. The use of research vessels contributes to carbon emissions.

**Impact:** Damage to marine ecosystems, negative public perception, and compromised scientific integrity. Could lead to legal challenges and reputational damage.

**Likelihood:** Low

**Severity:** Medium

**Action:** Implement strict environmental protocols for all sampling activities. Minimize the use of harmful chemicals and materials. Offset carbon emissions from research vessels. Conduct environmental impact assessments before commencing sampling campaigns.

## Risk 8 - Security
Theft or damage to equipment or samples during sampling campaigns or in laboratories could disrupt the research program. Cyberattacks on the open-access geospatial database could compromise data integrity.

**Impact:** Delayed sample processing, loss of data, and compromised research findings. Could lead to financial losses and reputational damage.

**Likelihood:** Low

**Severity:** Medium

**Action:** Implement robust security measures to protect equipment and samples. Secure laboratories and research vessels. Implement cybersecurity protocols to protect the open-access geospatial database. Back up data regularly.

## Risk 9 - Integration with Existing Infrastructure
Challenges in integrating data from different sources and formats into the open-access geospatial database could delay its development and limit its usability. Existing studies use incompatible size thresholds, polymer classification schemes, and sampling depths.

**Impact:** Delayed database development, reduced data quality, and limited usability. Could lead to a 3-6 month delay in the database launch.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a comprehensive data management plan. Establish clear data standards and protocols. Invest in data integration tools and expertise. Conduct thorough testing and validation of the database.

## Risk 10 - Long-Term Sustainability
Lack of sustained funding or institutional support could jeopardize the long-term maintenance and accessibility of the open-access geospatial database. The proposed ISO-track standard methodology for ocean microplastic assessment may not be widely adopted.

**Impact:** Loss of data, reduced accessibility, and limited impact of the research program. Could lead to a failure to achieve the program's long-term goals.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a long-term sustainability plan for the open-access geospatial database. Seek commitments from funding agencies and institutions to support its maintenance. Promote the adoption of the proposed ISO-track standard methodology through outreach and advocacy.

## Risk 11 - Market or Competitive Risks
Other research groups may publish similar findings before this program, diminishing the impact and novelty of the flagship report. Competition for funding and recognition in the field of microplastic research is high.

**Impact:** Reduced impact and visibility of the flagship report. Could lead to a loss of funding opportunities and reputational damage.

**Likelihood:** Medium

**Severity:** Low

**Action:** Accelerate the research timeline where possible. Publish preliminary findings in peer-reviewed journals. Actively promote the program's findings through conferences and media outreach. Emphasize the unique aspects of the program, such as its standardized methodology and comprehensive data coverage.

## Risk summary
The most critical risks are technical inconsistencies in laboratory methodologies, difficulty securing sufficient ship time, and challenges in integrating data into the open-access database. Mitigation strategies should focus on rigorous inter-lab calibration, proactive engagement with research vessel operators, and a comprehensive data management plan. Trade-offs may be necessary between sampling scope and data quality, and between rapid data release and thorough validation. The Builder's Foundation scenario provides a strong framework for managing these risks by prioritizing data quality and objective information dissemination.

# Make Assumptions


## Question 1 - What specific funding allocation is planned for each of the three phases of the program, and what contingency plans are in place for potential funding shortfalls in any phase?

**Assumptions:** Assumption: 30% of the €24 million budget is allocated to Phase 1 (Months 1-6), 45% to Phase 2 (Months 7-16), and 25% to Phase 3 (Months 17-24). This distribution reflects the initial setup costs, the intensive sampling and analysis phase, and the final synthesis and dissemination phase. Contingency funds of 10% of the total budget are reserved for unforeseen expenses.

**Assessments:** Title: Funding & Budget Assessment
Description: Evaluation of the financial feasibility and sustainability of the program.
Details: A detailed breakdown of costs per phase is crucial for effective budget management. The 10% contingency fund is a good start, but a risk-adjusted contingency plan should be developed, considering potential cost overruns in deep-sea sampling or analytical costs. Explore alternative funding sources proactively to mitigate potential shortfalls. Quantify the impact of potential budget cuts on key deliverables.

## Question 2 - What are the key milestones for each phase of the program, and what are the dependencies between these milestones that could impact the overall timeline?

**Assumptions:** Assumption: Key milestones include securing ethics permits (Month 3), harmonizing lab methodologies (Month 6), completing seasonal sampling rounds (Months 9, 12, 15), building the geospatial database (Month 16), drafting the flagship report (Month 20), peer review completion (Month 22), and policy brief delivery (Month 24). A critical dependency is that data from sampling rounds must be processed and validated before the geospatial database can be populated.

**Assessments:** Title: Timeline & Milestones Assessment
Description: Analysis of the project schedule and critical path.
Details: The timeline is ambitious. Identify the critical path and potential bottlenecks. Delays in ethics permits or ship time could cascade through the entire project. Develop mitigation strategies for each critical dependency, such as parallel processing of samples or alternative sampling locations. Quantify the potential impact of delays on the final report publication date.

## Question 3 - What is the specific allocation of the 45 FTE across the consortium partners, and what are the roles and responsibilities of each team member?

**Assumptions:** Assumption: The 45 FTE are distributed as follows: 15 at GEOMAR/Kiel University (project management, data science, communications), 10 at Ifremer (sampling, marine chemistry), 10 at NOC (deep-sea sampling, ecotoxicology), and 10 at ICM-CSIC (Mediterranean sampling, policy analysis). Each team member has a clearly defined role and responsibilities documented in a responsibility assignment matrix (RACI).

**Assessments:** Title: Resources & Personnel Assessment
Description: Evaluation of the adequacy and allocation of human resources.
Details: Clearly defined roles and responsibilities are essential for effective collaboration. Assess the skill gaps within the consortium and develop training programs to address them. Consider the impact of personnel turnover on project continuity. Quantify the workload for each team member to ensure realistic expectations and prevent burnout.

## Question 4 - What specific governance structure will be implemented to manage the consortium, and what mechanisms are in place to ensure compliance with relevant regulations and ethical guidelines?

**Assumptions:** Assumption: A steering committee composed of representatives from each partner institution will oversee the project. A data management committee will ensure compliance with data privacy regulations (e.g., GDPR) and ethical guidelines for research involving marine organisms. Regular audits will be conducted to ensure adherence to these guidelines.

**Assessments:** Title: Governance & Regulations Assessment
Description: Review of the project's governance structure and compliance framework.
Details: A clear governance structure is crucial for decision-making and conflict resolution. Ensure that the steering committee has the authority to make timely decisions. Develop a comprehensive compliance checklist to ensure adherence to all relevant regulations and ethical guidelines. Quantify the potential costs of non-compliance, including fines and reputational damage.

## Question 5 - What specific safety protocols will be implemented during sampling campaigns, particularly for deep-sea operations, and what risk mitigation strategies are in place for potential accidents or emergencies?

**Assumptions:** Assumption: Comprehensive safety protocols will be developed and implemented for all sampling activities, including risk assessments, safety training, and emergency response plans. Deep-sea operations will adhere to strict safety standards for submersible operations and handling of potentially hazardous materials. Emergency response plans will include procedures for medical emergencies, equipment failures, and environmental spills.

**Assessments:** Title: Safety & Risk Management Assessment
Description: Evaluation of the project's safety protocols and risk mitigation strategies.
Details: Safety is paramount, especially in deep-sea environments. Conduct thorough risk assessments for all sampling activities. Ensure that all personnel are adequately trained in safety procedures. Develop a detailed emergency response plan and conduct regular drills. Quantify the potential costs of accidents, including medical expenses, equipment damage, and environmental remediation.

## Question 6 - What measures will be taken to minimize the environmental impact of sampling activities, and how will the program address concerns about potential disturbance of marine ecosystems?

**Assumptions:** Assumption: Sampling activities will be conducted in a manner that minimizes disturbance to marine ecosystems. Non-destructive sampling methods will be prioritized where possible. The use of harmful chemicals will be minimized. Carbon emissions from research vessels will be offset through carbon offsetting programs. An environmental impact assessment will be conducted before commencing sampling campaigns.

**Assessments:** Title: Environmental Impact Assessment
Description: Analysis of the project's potential environmental footprint and mitigation strategies.
Details: Minimizing environmental impact is crucial for maintaining public trust and scientific integrity. Implement best practices for sustainable sampling. Explore alternative sampling methods with lower environmental footprints. Quantify the carbon footprint of the project and develop a plan to reduce it. Engage with local communities to address their concerns about potential environmental impacts.

## Question 7 - What specific strategies will be used to engage with stakeholders, including policymakers, the scientific community, and the general public, to ensure the program's findings are effectively communicated and utilized?

**Assumptions:** Assumption: A multi-faceted communication strategy will be implemented to engage with stakeholders. This will include publishing peer-reviewed articles, presenting findings at conferences, developing policy briefs, creating a public-facing interactive data dashboard, and engaging with the media. Stakeholder engagement will be tailored to the specific needs and interests of each audience.

**Assessments:** Title: Stakeholder Involvement Assessment
Description: Evaluation of the project's stakeholder engagement strategy.
Details: Effective stakeholder engagement is crucial for maximizing the impact of the program. Identify key stakeholders and their specific needs and interests. Develop tailored communication materials for each audience. Track stakeholder engagement metrics to measure the effectiveness of communication efforts. Quantify the potential benefits of increased stakeholder engagement, such as increased policy influence and public awareness.

## Question 8 - What specific operational systems will be implemented to manage data collection, processing, and storage, and how will these systems ensure data quality, security, and accessibility?

**Assumptions:** Assumption: A centralized data management system will be implemented to manage data collection, processing, and storage. This system will include data validation protocols, data security measures, and data access controls. All data will be stored in a secure repository and backed up regularly. The open-access geospatial database will be built on a robust platform with appropriate security measures to prevent unauthorized access or data breaches.

**Assessments:** Title: Operational Systems Assessment
Description: Review of the project's data management and operational infrastructure.
Details: Robust operational systems are essential for ensuring data quality, security, and accessibility. Develop a comprehensive data management plan that outlines data collection, processing, storage, and access procedures. Implement data validation protocols to ensure data accuracy. Implement data security measures to protect against unauthorized access or data breaches. Quantify the potential costs of data loss or security breaches.

# Distill Assumptions

- Phase funding: 30% Phase 1, 45% Phase 2, 25% Phase 3; 10% contingency.
- Ethics (M3), labs (M6), sampling (M9,12,15), database (M16), report (M20), policy (M24).
- Sampling data must be validated before the geospatial database is populated.
- 45 FTE: GEOMAR/Kiel 15, Ifremer 10, NOC 10, ICM-CSIC 10; RACI documented.
- Steering committee oversees; data committee ensures GDPR compliance; regular audits occur.
- Safety protocols include risk assessments, training, and emergency plans for deep-sea.
- Sampling minimizes ecosystem disturbance; carbon emissions are offset; impact assessment occurs.
- Multi-faceted communication strategy tailored to policymakers, scientists, and the public.
- Centralized data system ensures data quality, security, accessibility, and regular backups.

# Review Assumptions

## Domain of the expert reviewer
Project Management and Risk Assessment for Scientific Initiatives

## Domain-specific considerations

- Scientific rigor and reproducibility
- Data management and quality control
- Stakeholder engagement and communication
- Regulatory compliance and ethical considerations
- Logistical complexity of multi-site sampling
- Long-term sustainability of data and infrastructure

## Issue 1 - Uncertainty in Ship Time Availability and Cost
The plan assumes sufficient ship time will be available for deep-sea sampling. However, securing ship time is a known bottleneck in oceanographic research, and costs can fluctuate significantly. The plan lacks a detailed strategy for mitigating potential delays or cost overruns related to ship time, which could severely impact the deep-sea sampling component and overall project timeline.

**Recommendation:** 1.  Develop a detailed ship time procurement plan, including identifying multiple potential research vessels and negotiating firm commitments with vessel operators. 2.  Explore alternative sampling platforms, such as autonomous underwater vehicles (AUVs), as a backup. 3.  Establish a clear decision-making process for prioritizing sampling locations if ship time is limited. 4.  Include a sensitivity analysis of ship time costs in the budget, considering potential fuel price increases and vessel availability constraints.

**Sensitivity:** A delay in securing necessary ship time (baseline: 0 months delay) could increase project costs by €200,000-€500,000 due to renegotiated contracts or alternative platform costs, or delay the ROI by 6-12 months. A 20% increase in ship time costs (baseline: €500,000) could reduce the project's ROI by 2-4%.

## Issue 2 - Insufficient Detail on Data Integration and Database Sustainability
The plan mentions an open-access geospatial database but lacks specifics on data integration processes, long-term maintenance, and governance. Integrating data from diverse sources with varying formats and quality levels is a significant challenge. The plan needs a robust data management plan, including clear data standards, validation protocols, and a sustainable funding model for database maintenance beyond the project's lifespan. Without this, the database's usability and long-term value are at risk.

**Recommendation:** 1.  Develop a comprehensive data management plan outlining data standards, validation procedures, and metadata requirements. 2.  Invest in data integration tools and expertise to ensure seamless data flow from partner labs to the database. 3.  Establish a data governance committee to oversee data quality and access policies. 4.  Develop a long-term sustainability plan for the database, including exploring options for institutional support, subscription models, or grant funding.

**Sensitivity:** Failure to properly integrate data (baseline: 0 months delay) could delay the database launch by 3-6 months, or reduce the ROI by 5-10% due to decreased usability. A lack of sustained funding for database maintenance (baseline: €50,000/year) could lead to data loss or reduced accessibility, diminishing the project's long-term impact.

## Issue 3 - Lack of Specificity Regarding Stakeholder Engagement and Policy Influence
While the plan mentions stakeholder engagement, it lacks concrete details on how to effectively influence policy decisions. The plan needs a targeted stakeholder engagement strategy that identifies key policymakers, understands their priorities, and develops tailored communication materials. Without a proactive and strategic approach, the program's policy recommendations may not be adopted, limiting its overall impact.

**Recommendation:** 1.  Conduct a stakeholder analysis to identify key policymakers and their influence on microplastic pollution policy. 2.  Develop tailored communication materials, including policy briefs and presentations, that address the specific needs and interests of each stakeholder group. 3.  Establish relationships with policymakers through regular meetings and consultations. 4.  Track policy engagement metrics, such as citations in policy documents and adoption of recommendations, to measure the program's impact.

**Sensitivity:** A failure to effectively engage policymakers (baseline: 0 policy recommendations adopted) could reduce the project's ROI by 10-20% due to limited policy impact. A 25% increase in stakeholder engagement efforts (baseline: €100,000) could increase the likelihood of policy adoption by 15-20%.

## Review conclusion
The plan is well-structured but needs more detailed strategies for securing ship time, ensuring data integration and database sustainability, and effectively engaging stakeholders to influence policy. Addressing these issues will significantly enhance the project's likelihood of success and maximize its impact on mitigating microplastic pollution.