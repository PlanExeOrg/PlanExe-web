Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 15 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 4 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project focuses on assessing microplastic contamination, which is within the realm of known physics and chemistry. No quotes needed.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (microplastic assessment) + market (international policy) + tech/process (standardization) + policy (actionable recommendations) without independent evidence at comparable scale. There is no credible precedent for this specific system.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Project Director / Deliverable: Validation Report / Date: 2026-Q2


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan uses terms like "definitive assessment", "actionable policy recommendations", and "standardized measurement" without defining their business-level mechanism-of-action. There are no one-pagers defining value hypotheses, success metrics, and decision hooks.

**Mitigation**: Project Director: Create one-pagers for "definitive assessment", "actionable policy recommendations", and "standardized measurement", including value hypotheses, success metrics, and decision hooks, by 2026-Q2.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies some risks (regulatory, technical, financial, operational) but lacks explicit analysis of second-order effects or cascade scenarios. The risk register does not map dependencies or analyze how one risk might trigger others.

**Mitigation**: Project Manager: Expand the risk register to include cascade effects (e.g., permit delay → sampling delay → report delay) and add controls with a review cadence by 2026-Q2.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions securing permits but lacks a comprehensive list of required permits, lead times, and responsible parties. Without this, delays are highly likely.

**Mitigation**: Project Manager: Create a permit/approval matrix with required permits, lead times, responsible parties, and NO-GO thresholds by 2026-Q2.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not include a financing plan listing sources/status, draw schedule, or covenants. Without this, it is impossible to assess the funding plan's integrity or runway length.

**Mitigation**: Project Manager: Develop a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO-GO on missed financing gates by 2026-Q2.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget conflicts with vendor quotes or scale-appropriate benchmarks. The plan lacks contingency, and no relevant comparables or quotes are provided to substantiate the figure.

**Mitigation**: Owner: Project Manager, Deliverable: Benchmarking report with ≥3 relevant comparables and quotes, Date: 2026-Q2.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., completion dates) as single numbers without providing a range or discussing alternative scenarios. For example, the goal is to complete the program within 24 months, but there is no discussion of potential delays or contingencies.

**Mitigation**: Project Manager: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the project's completion date, including potential delays, by 2026-Q2.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not include technical specs, interface definitions, test plans, or an integration map with owners/dates. The plan mentions SOPs, but these are insufficient for build-critical components.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components by 2026-Q2.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes several critical claims without providing verifiable evidence. For example, it states that the goal is "achievable through a consortium of European marine research institutes" but lacks evidence of formal agreements or commitments from these institutes.

**Mitigation**: Project Manager: Obtain letters of commitment or memoranda of understanding from each participating European marine research institute by 2026-Q2.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the deliverable "definitive assessment of microplastic contamination" is mentioned without specific, verifiable qualities. What constitutes 'definitive'? What are the acceptance criteria?

**Mitigation**: Project Director: Define SMART criteria for 'definitive assessment,' including a KPI for data coverage (e.g., sampling at >90% of key ocean biomes) by 2026-Q2.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Food Chain Bioaccumulation Modeling' feature adds complexity and cost without directly supporting the core goals of a definitive assessment or actionable policy. It trades off with geographic scope and data quality.

**Mitigation**: Project Team: Produce a one-page benefit case for 'Food Chain Bioaccumulation Modeling,' including KPI, owner, and estimated cost, or move the feature to the project backlog. Date: 2026-Q2.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a 'Database Architect' to design, develop, and maintain the open-access geospatial database. This role is critical for data accessibility and long-term sustainability, but the plan lacks evidence of talent availability.

**Mitigation**: HR Team: Validate the talent market for Database Architects with geospatial database expertise by surveying potential candidates and assessing availability within 30 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions securing permits but lacks a regulatory matrix (authority, artifact, lead time, predecessors). Legality is unclear, and required approvals are unmapped, a potential showstopper.

**Mitigation**: Legal Team: Develop a regulatory matrix identifying all required permits/licenses, authorities, artifacts, and lead times by 2026-Q2. Include NO-GO criteria for adverse findings.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions a sustainability plan for the database but lacks specifics on funding sources or commitments. Risk 10 identifies this, but the action is vague. "Lack of funding could jeopardize database maintenance."

**Mitigation**: Project Manager: Develop a detailed sustainability plan for the database, including funding sources, maintenance schedule, and data governance policies by 2026-Q3.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a comprehensive list of required permits, lead times, and responsible parties. Without this, delays are highly likely.

**Mitigation**: Project Manager: Create a permit/approval matrix with required permits, lead times, responsible parties, and NO-GO thresholds by 2026-Q2.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions establishing relationships with vessel operators and exploring alternative platforms, but lacks evidence of secured SLAs or tested failover plans. "Difficulty securing ship time could limit sampling."

**Mitigation**: Project Manager: Secure SLAs with vessel operators, add a secondary vessel supplier, and test failover by 2026-Q3. Document the failover test results.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the 'Communications Team' is incentivized to maximize reach and engagement, while the 'Data Quality Manager' is incentivized to ensure data accuracy, creating a conflict over releasing preliminary data. The plan does not address this.

**Mitigation**: Project Director: Define a shared OKR for the Communications Team and Data Quality Manager that balances data reach with accuracy, such as 'Increase data downloads by X% while maintaining a data accuracy rate of Y%' by 2026-Q2.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board. Include thresholds for re-planning or stopping by 2026-Q2.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because ≥3 High risks are strongly coupled. FM2 (Lab Labyrinth), FM6 (Analytical Avalanche), and FM8 (Data Babel) are tightly linked. Lab deviations (FM2) trigger data integration failures (FM8), compounded by lab overload (FM6).

**Mitigation**: Project Director: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by 2026-Q2.