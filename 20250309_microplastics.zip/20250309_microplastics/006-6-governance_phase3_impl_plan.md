### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Core Team ToR v0.1

**Dependencies:**

- Project Plan Approved

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project Plan Approved

### 4. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved

### 5. Circulate Draft SteerCo ToR for review by nominated members (GEOMAR, Kiel University, Ifremer, NOC, ICM-CSIC, Horizon Europe Observer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 6. Circulate Draft Core Team ToR for review by nominated members (Project Manager, Work Package Leaders, Data Manager, Communications Manager, Sampling Coordinator).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Core Team ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft Core Team ToR v0.1
- Nominated Members List Available

### 7. Circulate Draft TAG ToR for review by potential external members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft TAG ToR v0.1
- Potential Members Identified

### 8. Circulate Draft Ethics & Compliance Committee ToR for review by potential external members and GEOMAR Legal Department.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1
- Potential Members Identified

### 9. Project Sponsor formally approves the Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft SteerCo ToR v0.2

### 10. Project Sponsor formally approves the Terms of Reference for the Core Project Team.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved Core Team ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Core Team ToR v0.2

### 11. Project Sponsor formally approves the Terms of Reference for the Technical Advisory Group.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved TAG ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft TAG ToR v0.2

### 12. Project Sponsor formally approves the Terms of Reference for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Ethics & Compliance Committee ToR v0.2

### 13. Senior Management of GEOMAR formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SteerCo ToR v1.0

### 14. Project Manager confirms membership of the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation Emails

**Dependencies:**

- Approved Core Team ToR v1.0

### 15. Project Manager, in consultation with Senior Scientists at GEOMAR, formally appoints members to the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Approved TAG ToR v1.0

### 16. Project Manager, in consultation with GEOMAR Legal Department, formally appoints members to the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Approved Ethics & Compliance Committee ToR v1.0

### 17. Hold initial Project Steering Committee Kick-off Meeting.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Email
- Approved SteerCo ToR v1.0

### 18. Hold initial Core Project Team Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation Emails
- Approved Core Team ToR v1.0

### 19. Hold initial Technical Advisory Group Kick-off Meeting.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Emails
- Approved TAG ToR v1.0

### 20. Hold initial Ethics & Compliance Committee Kick-off Meeting.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Emails
- Approved Ethics & Compliance Committee ToR v1.0

### 21. The Project Steering Committee reviews and approves the initial project management plan.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved Project Management Plan

**Dependencies:**

- Meeting Minutes with Action Items
- Initial Project Management Plan Drafted

### 22. The Technical Advisory Group reviews and approves the initial sampling protocols and analytical methods.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Approved Sampling Protocols
- Approved Analytical Methods

**Dependencies:**

- Meeting Minutes with Action Items
- Initial Sampling Protocols and Analytical Methods Drafted

### 23. The Ethics & Compliance Committee reviews and approves the initial research protocols to ensure ethical compliance.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Approved Research Protocols

**Dependencies:**

- Meeting Minutes with Action Items
- Initial Research Protocols Drafted