## Suggestion 1 - JPI Oceans Microplastics Projects

The Joint Programming Initiative Healthy and Productive Seas and Oceans (JPI Oceans) has funded multiple projects focused on microplastics research across Europe. These projects aim to understand the sources, distribution, fate, and effects of microplastics in the marine environment. They involve collaborative research efforts across multiple European countries, addressing similar challenges in standardization, data management, and policy recommendations.

### Success Metrics

Number of peer-reviewed publications.
Development of standardized methodologies.
Influence on policy decisions at the EU level.
Creation of open-access datasets.

### Risks and Challenges Faced

Harmonizing methodologies across different laboratories.
Securing funding for long-term monitoring.
Coordinating research efforts across multiple countries.
Addressing the complexity of microplastic sources and pathways.

### Where to Find More Information

JPI Oceans website: [https://www.jpi-oceans.eu/](https://www.jpi-oceans.eu/)
CORDIS database for funded projects: [https://cordis.europa.eu/](https://cordis.europa.eu/)

### Actionable Steps

Contact JPI Oceans project coordinators through their website to inquire about specific project details and lessons learned.
Reach out to researchers involved in individual JPI Oceans microplastics projects via their institutional websites or LinkedIn.

### Rationale for Suggestion

This is a highly relevant suggestion because JPI Oceans is a major European initiative coordinating marine research, including numerous microplastics projects. These projects share similar goals, geographical scope, and challenges, making them an excellent source of information and best practices. The JPI Oceans projects also address the critical need for standardized measurement, a key deliverable of the user's project.
## Suggestion 2 - The Ocean Cleanup

The Ocean Cleanup is a non-profit organization developing and deploying technologies to remove plastic pollution from the oceans. While primarily focused on macroplastics, their work involves extensive data collection, mapping of plastic concentrations, and technological development for ocean cleanup. Their experience in large-scale ocean operations and data management is relevant to the user's project.

### Success Metrics

Tons of plastic removed from the ocean.
Area of ocean cleaned.
Development and deployment of cleanup technologies.
Public awareness and engagement.

### Risks and Challenges Faced

Technological challenges in developing effective cleanup systems.
Environmental impacts of cleanup operations.
Securing funding for large-scale deployments.
Navigating international regulations and permits.

### Where to Find More Information

The Ocean Cleanup website: [https://theoceancleanup.com/](https://theoceancleanup.com/)
Peer-reviewed publications on their research and technology.

### Actionable Steps

Contact The Ocean Cleanup through their website to inquire about their data collection methodologies and operational challenges.
Explore potential collaborations or data sharing opportunities.

### Rationale for Suggestion

While The Ocean Cleanup focuses on macroplastics, their experience in large-scale ocean operations, data collection, and technological development is highly relevant. Their challenges in securing permits, navigating international regulations, and managing environmental impacts are directly applicable to the user's project. Furthermore, their public engagement strategies can provide valuable insights for the user's communication plan.
## Suggestion 3 - EU Horizon 2020 project: WEATHER-MIC

WEATHER-MIC (Weathering of microplastics in the marine environment) was a Horizon 2020 project that investigated the weathering processes affecting microplastics in the marine environment and their impact on marine organisms. The project involved laboratory experiments, field sampling, and modeling to understand the fate and effects of microplastics. It is a good example of a focused research project funded by the EU that addresses specific aspects of microplastic pollution.

### Success Metrics

Number of peer-reviewed publications.
Development of models for microplastic weathering.
Quantification of the impact of weathered microplastics on marine organisms.
Contribution to policy recommendations.

### Risks and Challenges Faced

Simulating realistic weathering conditions in the laboratory.
Extrapolating laboratory results to the field.
Addressing the complexity of microplastic interactions with marine organisms.
Securing access to relevant field sites.

### Where to Find More Information

CORDIS database: [https://cordis.europa.eu/project/id/862482](https://cordis.europa.eu/project/id/862482)
Project website (if available).

### Actionable Steps

Contact the project coordinator (details available on CORDIS) to inquire about specific methodologies and findings.
Search for publications by project partners.

### Rationale for Suggestion

This project is relevant because it directly addresses the fate and effects of microplastics, a key aspect of the user's project. The challenges faced in simulating realistic weathering conditions and extrapolating laboratory results are directly applicable. The project's focus on specific aspects of microplastic pollution provides a valuable example of a focused research approach.
## Suggestion 4 - GESAMP Working Group 40 on Sources, Fate and Effects of Microplastics in the Marine Environment

GESAMP (Joint Group of Experts on the Scientific Aspects of Marine Environmental Protection) Working Group 40 produced a series of reports on the sources, fate, and effects of microplastics in the marine environment. These reports provide a comprehensive overview of the current state of knowledge and identify key research gaps. While not a research project *per se*, the GESAMP reports offer a valuable framework for the user's project.

### Success Metrics

Production of comprehensive reports on microplastics.
Influence on international policy and research agendas.
Identification of key research gaps.

### Risks and Challenges Faced

Synthesizing information from diverse sources.
Reaching consensus among experts with differing views.
Keeping up with the rapidly evolving field of microplastics research.
Communicating complex scientific information to policymakers.

### Where to Find More Information

GESAMP website: [http://www.gesamp.org/work/groups/40](http://www.gesamp.org/work/groups/40)
UN Environment Programme publications.

### Actionable Steps

Review the GESAMP reports to identify key research gaps and methodological recommendations.
Contact GESAMP experts to inquire about their perspectives on microplastic research priorities.

### Rationale for Suggestion

The GESAMP reports provide a comprehensive overview of the current state of knowledge on microplastics and identify key research gaps. This is valuable for the user's project in terms of informing the research design, identifying relevant methodologies, and ensuring that the project addresses the most pressing issues. The GESAMP reports also provide a framework for communicating complex scientific information to policymakers.

## Summary

Based on the provided project plan to launch a pan-European research program focused on microplastic contamination in the world's oceans, I recommend the following projects as references. These projects share similar objectives, methodologies, and challenges, offering valuable insights for successful execution.