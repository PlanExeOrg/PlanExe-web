This plan involves money.

## Currencies

- **EUR:** The project budget is defined in EUR, and the project spans multiple European countries.
- **GBP:** The project involves research institutes in the United Kingdom.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting and reporting. Local currencies (e.g., GBP) may be used for local transactions within the UK.