**Budget Request Exceeding Core Project Team Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds financial limit of Core Project Team's approval authority (€50,000).
Negative Consequences: Potential budget overrun, project scope reduction, or delayed deliverables.

**Critical Risk Materialization Requiring Additional Resources**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval
Rationale: Requires strategic decision-making and potential reallocation of resources beyond the Core Project Team's capacity.
Negative Consequences: Project failure, significant delays, or inability to meet project objectives.

**Technical Advisory Group Deadlock on Sampling Protocol**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Final Decision
Rationale: Requires higher-level arbitration to ensure scientific rigor and project progress.
Negative Consequences: Compromised data quality, invalid research findings, or delays in sampling campaigns.

**Proposed Major Scope Change (e.g., Adding New Sampling Locations)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval
Rationale: Impacts budget, timeline, and overall project objectives, requiring strategic alignment.
Negative Consequences: Budget overruns, project delays, or compromised data quality due to insufficient resources.

**Reported Ethical Concern or Compliance Violation**
Escalation Level: Senior Management of GEOMAR Helmholtz Centre for Ocean Research
Approval Process: Investigation by GEOMAR Legal Department and Senior Management Review
Rationale: Requires independent review and potential legal action to protect the project's integrity and reputation.
Negative Consequences: Legal penalties, reputational damage, or loss of funding.

**Unresolved Conflict Between Consortium Partners**
Escalation Level: Senior Management of GEOMAR Helmholtz Centre for Ocean Research
Approval Process: Mediation by Senior Management
Rationale: Requires intervention by the lead institution to maintain collaboration and project momentum.
Negative Consequences: Project delays, compromised data quality, or dissolution of the consortium.