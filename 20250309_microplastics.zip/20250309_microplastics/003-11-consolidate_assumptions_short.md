# Purpose
# Pan-European Microplastic Program

- Societal initiative: assess microplastic contamination, develop policy recommendations, standardize measurement.

## Research

- Focus: microplastic contamination in oceans.

## Policy

- Development of policy recommendations.

## Standardization

- Standardize measurement methodologies.


# Plan Type
This plan requires physical locations and cannot be executed digitally.

Explanation:

- Involves physical activity.
- Requires physical sampling (water, sediment, biota) from multiple ocean locations (North Atlantic, Mediterranean, Baltic, South Pacific gyre).
- Requires laboratory analysis using specialized equipment (FTIR, Raman spectroscopy).
- Requires physical coordination of a large research team across multiple European institutes.
- Requires securing ship time on research vessels.
- Requires physical meetings and collaboration.
- Requires dissemination of findings through policy briefs and presentations.

The plan cannot be executed without these physical components.

# Physical Locations
# Physical Locations

## Requirements

- Marine research facilities
- Access to ocean sampling sites (North Atlantic, Mediterranean, Baltic, South Pacific)
- Laboratories with FTIR and Raman spectroscopy equipment
- Office space for 45 FTE
- Proximity to GEOMAR Helmholtz Centre for Ocean Research and Kiel University

## Location 1
Germany

- Kiel
- GEOMAR Helmholtz Centre for Ocean Research / Kiel University
- Rationale: Program headquarters, leveraging GEOMAR and Kiel University.

## Location 2
France

- Brest
- Ifremer (French Research Institute for Exploitation of the Sea)
- Rationale: Expertise in microplastic research, access to Atlantic and Mediterranean sampling sites.

## Location 3
United Kingdom

- Southampton
- National Oceanography Centre
- Rationale: Experience in oceanographic research, deep-sea sampling and analysis.

## Location 4
Spain

- Barcelona
- Institute of Marine Sciences (ICM-CSIC)
- Rationale: Expertise in microplastic research, access to Mediterranean sampling sites.

## Location Summary
Headquartered in Kiel, Germany (GEOMAR/Kiel University). Additional locations: Brest (Ifremer), Southampton (National Oceanography Centre), and Barcelona (ICM-CSIC) for marine research facilities, ocean sampling sites, and microplastic research expertise.

# Currency Strategy
## Currencies

- EUR: Project budget, multiple European countries.
- GBP: Research institutes in the United Kingdom.

Primary currency: EUR

Currency strategy: EUR for budgeting/reporting. Local currencies (e.g., GBP) for local transactions.

# Identify Risks
# Risk 1 - Regulatory & Permitting

- Delays in securing permits could delay sampling.
- Impact: 2-6 month delay, budget impact, legal challenges.
- Likelihood: Medium
- Severity: Medium
- Action: Start permit applications early, develop contingency plans, engage local experts.

# Risk 2 - Technical

- Inconsistencies in lab methodologies could lead to data issues.
- Impact: Reduced data quality, increased analytical costs (10-20%).
- Likelihood: Medium
- Severity: High
- Action: Implement inter-lab calibration, establish QA/QC, invest in training, conduct proficiency testing.

# Risk 3 - Financial

- Cost overruns could strain the budget (€24 million).
- Impact: Reduced sampling, delayed report, 5-10% budget overrun.
- Likelihood: Medium
- Severity: Medium
- Action: Develop detailed budget with contingency, monitor expenses, explore funding, negotiate rates.

# Risk 4 - Operational

- Difficulty securing ship time could limit sampling.
- Impact: Reduced sampling coverage, 3-9 month delay.
- Likelihood: Medium
- Severity: High
- Action: Establish relationships with vessel operators, negotiate agreements, explore alternative platforms, develop contingency plans.

# Risk 5 - Supply Chain

- Disruptions in consumables could delay analyses.
- Impact: Delayed sample processing, 1-3 month delay.
- Likelihood: Low
- Severity: Medium
- Action: Establish relationships with multiple suppliers, maintain inventory, explore alternatives, implement inventory management.

# Risk 6 - Social

- Negative public perception could undermine the program.
- Impact: Reduced engagement, difficulty securing permits, reputational damage.
- Likelihood: Low
- Severity: Medium
- Action: Implement communication strategy, ensure transparency, engage with communities, emphasize environmental commitment.

# Risk 7 - Environmental

- Sampling could have environmental impacts.
- Impact: Damage to ecosystems, negative perception, legal challenges.
- Likelihood: Low
- Severity: Medium
- Action: Implement environmental protocols, minimize harmful chemicals, offset emissions, conduct impact assessments.

# Risk 8 - Security

- Theft or damage to equipment/samples could disrupt research. Cyberattacks could compromise data.
- Impact: Delayed processing, loss of data, financial losses.
- Likelihood: Low
- Severity: Medium
- Action: Implement security measures, secure labs/vessels, implement cybersecurity, back up data.

# Risk 9 - Integration with Existing Infrastructure

- Challenges integrating data into the database could delay development.
- Impact: Delayed database, reduced data quality, 3-6 month delay.
- Likelihood: Medium
- Severity: Medium
- Action: Develop data management plan, establish data standards, invest in integration tools, conduct testing.

# Risk 10 - Long-Term Sustainability

- Lack of funding could jeopardize database maintenance.
- Impact: Loss of data, reduced accessibility, limited impact.
- Likelihood: Medium
- Severity: Medium
- Action: Develop sustainability plan, seek commitments from funding agencies, promote ISO standard.

# Risk 11 - Market or Competitive Risks

- Other groups may publish similar findings first.
- Impact: Reduced impact, loss of funding, reputational damage.
- Likelihood: Medium
- Severity: Low
- Action: Accelerate timeline, publish preliminary findings, promote program, emphasize unique aspects.

# Risk summary

- Critical risks: technical inconsistencies, ship time, data integration.
- Mitigation: inter-lab calibration, vessel operator engagement, data management plan.
- Trade-offs: sampling scope vs. data quality, rapid release vs. validation.
- Builder's Foundation scenario: prioritize data quality and objective information.


# Make Assumptions
# Question 1 - Funding Allocation and Contingency Plans

- Assumption: 30% Phase 1, 45% Phase 2, 25% Phase 3. 10% contingency.

## Assessments: Funding & Budget Assessment

- Description: Financial feasibility evaluation.
- Details: Breakdown costs per phase. Risk-adjusted contingency plan needed. Explore alternative funding. Quantify budget cut impacts.

# Question 2 - Key Milestones and Dependencies

- Assumption: Ethics permits (M3), lab harmonization (M6), sampling (M9, 12, 15), database (M16), report draft (M20), peer review (M22), policy brief (M24). Data processing needed before database population.

## Assessments: Timeline & Milestones Assessment

- Description: Project schedule analysis.
- Details: Identify critical path/bottlenecks. Mitigation for dependencies (ethics, ship time). Quantify delay impacts.

# Question 3 - FTE Allocation and Responsibilities

- Assumption: 15 GEOMAR/Kiel, 10 Ifremer, 10 NOC, 10 ICM-CSIC. RACI matrix in place.

## Assessments: Resources & Personnel Assessment

- Description: Human resources evaluation.
- Details: Defined roles essential. Assess skill gaps, develop training. Consider personnel turnover. Quantify workload.

# Question 4 - Governance Structure and Compliance

- Assumption: Steering committee oversees project. Data committee ensures GDPR compliance. Regular audits.

## Assessments: Governance & Regulations Assessment

- Description: Governance and compliance review.
- Details: Clear structure needed. Steering committee authority. Compliance checklist. Quantify non-compliance costs.

# Question 5 - Safety Protocols and Risk Mitigation

- Assumption: Safety protocols, risk assessments, training, emergency plans. Deep-sea standards.

## Assessments: Safety & Risk Management Assessment

- Description: Safety protocols and risk mitigation evaluation.
- Details: Risk assessments for sampling. Personnel training. Emergency plan, drills. Quantify accident costs.

# Question 6 - Environmental Impact Minimization

- Assumption: Minimize disturbance. Prioritize non-destructive methods. Minimize chemicals. Offset emissions. Environmental impact assessment.

## Assessments: Environmental Impact Assessment

- Description: Environmental footprint analysis.
- Details: Sustainable sampling. Alternative methods. Quantify carbon footprint, reduce it. Engage communities.

# Question 7 - Stakeholder Engagement Strategies

- Assumption: Multi-faceted communication. Peer-reviewed articles, conferences, policy briefs, data dashboard, media. Tailored engagement.

## Assessments: Stakeholder Involvement Assessment

- Description: Stakeholder engagement strategy evaluation.
- Details: Identify stakeholders, needs. Tailored materials. Track engagement. Quantify benefits.

# Question 8 - Operational Systems for Data Management

- Assumption: Centralized system. Validation, security, access controls. Secure repository, backups.

## Assessments: Operational Systems Assessment

- Description: Data management and operational infrastructure review.
- Details: Data management plan. Validation protocols. Security measures. Quantify data loss costs.


# Distill Assumptions
# Project Plan

- Phase funding: 30% Phase 1, 45% Phase 2, 25% Phase 3; 10% contingency.
- Ethics (M3), labs (M6), sampling (M9,12,15), database (M16), report (M20), policy (M24).
- Sampling data validated before database population.
- 45 FTE: GEOMAR/Kiel 15, Ifremer 10, NOC 10, ICM-CSIC 10; RACI documented.
- Steering committee oversees; data committee ensures GDPR compliance; regular audits.
- Safety: risk assessments, training, emergency plans for deep-sea.
- Sampling minimizes disturbance; carbon emissions offset; impact assessment.
- Communication strategy for policymakers, scientists, public.
- Centralized data system: quality, security, accessibility, backups.


# Review Assumptions
# Domain of the expert reviewer
Project Management and Risk Assessment for Scientific Initiatives

## Domain-specific considerations

- Scientific rigor and reproducibility
- Data management and quality control
- Stakeholder engagement and communication
- Regulatory compliance and ethical considerations
- Logistical complexity of multi-site sampling
- Long-term sustainability of data and infrastructure

## Issue 1 - Uncertainty in Ship Time Availability and Cost
The plan assumes ship time availability for deep-sea sampling. Securing ship time is a bottleneck, and costs fluctuate. The plan lacks a strategy for mitigating delays or cost overruns, impacting the deep-sea sampling component and timeline.

Recommendation:

- Develop a ship time procurement plan, identifying vessels and negotiating commitments.
- Explore alternative sampling platforms, such as AUVs, as backup.
- Establish a decision-making process for prioritizing sampling locations if ship time is limited.
- Include a sensitivity analysis of ship time costs in the budget.

Sensitivity: A delay in securing ship time could increase project costs by €200,000-€500,000 or delay the ROI by 6-12 months. A 20% increase in ship time costs could reduce the project's ROI by 2-4%.

## Issue 2 - Insufficient Detail on Data Integration and Database Sustainability
The plan mentions an open-access geospatial database but lacks specifics on data integration, maintenance, and governance. Integrating data from diverse sources is a challenge. The plan needs a data management plan, including data standards, validation protocols, and a funding model for database maintenance. Without this, the database's usability is at risk.

Recommendation:

- Develop a data management plan outlining data standards, validation procedures, and metadata requirements.
- Invest in data integration tools and expertise.
- Establish a data governance committee to oversee data quality and access policies.
- Develop a sustainability plan for the database.

Sensitivity: Failure to properly integrate data could delay the database launch by 3-6 months or reduce the ROI by 5-10%. A lack of sustained funding for database maintenance could lead to data loss, diminishing the project's impact.

## Issue 3 - Lack of Specificity Regarding Stakeholder Engagement and Policy Influence
The plan mentions stakeholder engagement but lacks details on influencing policy decisions. The plan needs a stakeholder engagement strategy that identifies policymakers, understands their priorities, and develops communication materials. Without a strategic approach, the program's policy recommendations may not be adopted.

Recommendation:

- Conduct a stakeholder analysis to identify key policymakers.
- Develop communication materials that address the needs of each stakeholder group.
- Establish relationships with policymakers through meetings and consultations.
- Track policy engagement metrics to measure the program's impact.

Sensitivity: A failure to effectively engage policymakers could reduce the project's ROI by 10-20%. A 25% increase in stakeholder engagement efforts could increase the likelihood of policy adoption by 15-20%.

## Review conclusion
The plan needs more detailed strategies for securing ship time, ensuring data integration and database sustainability, and engaging stakeholders to influence policy. Addressing these issues will enhance the project's likelihood of success.