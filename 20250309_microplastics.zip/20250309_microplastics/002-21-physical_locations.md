This plan implies one or more physical locations.

## Requirements for physical locations

- Marine research facilities
- Access to ocean sampling sites (North Atlantic, Mediterranean, Baltic, South Pacific)
- Laboratories with FTIR and Raman spectroscopy equipment
- Office space for 45 FTE
- Proximity to GEOMAR Helmholtz Centre for Ocean Research and Kiel University

## Location 1
Germany

Kiel

GEOMAR Helmholtz Centre for Ocean Research / Kiel University

**Rationale**: The program is headquartered in Kiel, leveraging GEOMAR and Kiel University's marine sciences cluster.

## Location 2
France

Brest

Ifremer (French Research Institute for Exploitation of the Sea)

**Rationale**: Ifremer is a leading marine research institute with expertise in microplastic research and access to ocean sampling sites in the Atlantic and Mediterranean.

## Location 3
United Kingdom

Southampton

National Oceanography Centre

**Rationale**: The National Oceanography Centre in Southampton has extensive experience in oceanographic research, including deep-sea sampling and analysis, and is well-equipped for microplastic studies.

## Location 4
Spain

Barcelona

Institute of Marine Sciences (ICM-CSIC)

**Rationale**: The ICM-CSIC in Barcelona is a leading marine research institute with expertise in microplastic research and access to ocean sampling sites in the Mediterranean.

## Location Summary
The program is headquartered in Kiel, Germany, leveraging GEOMAR and Kiel University. Additional locations in Brest (France), Southampton (UK), and Barcelona (Spain) are suggested due to their established marine research facilities, access to relevant ocean sampling sites, and expertise in microplastic research.