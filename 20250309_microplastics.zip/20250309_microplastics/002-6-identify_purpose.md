**Purpose:** business

**Purpose Detailed:** Societal initiative to assess microplastic contamination, develop policy recommendations, and standardize measurement methodologies.

**Topic:** Pan-European research and policy program on microplastic contamination in oceans