
## Audit - Corruption Risks

- Bribery of permitting authorities to expedite or overlook environmental impact assessments for sampling locations.
- Kickbacks from suppliers of laboratory equipment or consumables in exchange for preferential selection.
- Conflicts of interest within the consortium, where researchers prioritize their own institutions' interests over the program's objectives.
- Misuse of confidential data regarding contamination hotspots for personal financial gain (e.g., real estate investments).
- Nepotism in hiring decisions, leading to unqualified personnel being appointed to key roles.
- Trading favors with ship time providers, potentially compromising the scientific integrity of sampling site selection.

## Audit - Misallocation Risks

- Inflated invoices from partner institutions for personnel costs or overhead expenses.
- Duplication of expenses across partner institutions (e.g., double-billing for travel or equipment).
- Inefficient allocation of ship time, resulting in underutilized research vessel capacity.
- Unauthorized use of program funds for unrelated research activities or personal expenses.
- Misreporting of progress or results to justify continued funding, even if milestones are not met.
- Poor record-keeping of sample provenance and analytical data, leading to data loss or compromised data integrity.

## Audit - Procedures

- Conduct quarterly internal audits of financial records and expense reports across all partner institutions.
- Implement a threshold for independent review of contracts exceeding €100,000 to ensure fair pricing and compliance.
- Perform periodic reviews of ship time logs and sampling records to verify adherence to protocols and efficient resource utilization.
- Conduct annual external audits of the program's financial statements and compliance with Horizon Europe grant requirements.
- Implement a data quality audit trail to track changes to the open-access geospatial database and ensure data integrity.
- Perform regular compliance checks to ensure adherence to GDPR and other relevant regulations.

## Audit - Transparency Measures

- Establish a public-facing project website with regularly updated progress reports, budget summaries, and key performance indicators.
- Publish minutes of steering committee meetings and scientific advisory board meetings on the project website.
- Implement a whistleblower mechanism for reporting suspected fraud, corruption, or ethical violations within the consortium.
- Document and publish the selection criteria for major vendors and subcontractors on the project website.
- Make the program's data management plan and quality assurance protocols publicly available.
- Publish a dashboard showing the status of ethics and sampling permits for each location.