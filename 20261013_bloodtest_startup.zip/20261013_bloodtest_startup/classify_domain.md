**Primary domain:** In Vitro Diagnostics

**Secondary domains:** Medical Device Manufacturing, Medical Device Regulation, Microfluidics Engineering

**Rationale:** In Vitro Diagnostics is the only outcome-role candidate and owns the core product: a multiplex blood-testing device. Microfluidics, assay development, manufacturing, regulation, and validation are subordinate methods or constraints serving that diagnostic outcome.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| In Vitro Diagnostics | 5 | 5 | outcome | Multiplex blood-testing device from a single drop is the core product. |
| Microfluidics Engineering | 5 | 5 | method | Running 500 tests from one blood drop requires microfluidic sample partitioning and multiplexed detection. |
| Multiplex Assay Development | 5 | 5 | method | Running 500 tests from one blood drop depends on multiplexed assay chemistry and detection. |
| Medical Device Manufacturing | 5 | 4 | method | Mass production in Newark, California requires scalable, quality-controlled device manufacturing. |
| Medical Device Regulation | 5 | 4 | constraint | FDA clearance, CLIA, and quality system compliance gate market entry. |
| Clinical Validation | 5 | 4 | constraint | Analytical and clinical accuracy of 500 multiplexed tests must be proven before commercialization. |
| Quality Management Systems | 4 | 4 | constraint | ISO 13485 and FDA-compliant design controls are required for mass production in Newark. |
| Venture Financing | 4 | 3 | stakeholder | A capital-intensive diagnostics startup needs investor funding for R&D and manufacturing scale-up. |
| Healthcare Reimbursement | 3 | 3 | market | Payer coverage and coding determine commercial adoption and revenue of a high-volume test panel. |