_Consistency: first pass found 3 high / 5 medium / 0 low contradictions. Repair: round 1: 64 edits → 2 high / 4 medium; round 2: 18 edits → 0 high / 6 medium. Published: round 2 (fewest high-severity issues). Shown below: the final check of the repaired documents (0 high / 6 medium / 0 low)._

## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Has the board adopted the Gate Authority Charter and closed a Seed sized to cover Months 0-6 commitments (non-payroll USD 2.0-3.6M plus payroll)? | Seed closed at >= USD 2M by Month 2 (premortem FM1 tripwire), with the Seed-vs-commitments gap resolved by one named path (larger Seed, A1 escrow released at the Month 6 gate, or reduced Phase 1 scope); Charter signed with the CFO veto above USD 100k and the yield <80% (or lower CI <75%) rule. | Signed Seed closing documents and board resolution with a Months 0-6 cash-flow table including payroll, by Month 2. | Delay: hire only the R&D director and quality/regulatory lead, defer Newark Phase 1 (USD 500-800k) and external studies until funding is closed; if Seed is < USD 2M at Month 2, run the FM1 containment (freeze commitments above USD 50k) and downsize to a feasibility-only program. |
| 2 | Does the Month 6 technical gate pass: plasma separation, cross-reactivity, COGS ceiling, FDA Pre-Submission held and QMS live? | >= 95% of >= 100 fingerstick subjects with >= 1.6 uL usable plasma and hemolysis index <50; <= 5% bias at 10x interferent; COGS ceiling USD 25 per cartridge locked; Pre-Submission held; electronic QMS live (proposed thresholds). | Plasma-yield and cross-reactivity study reports, locked bottom-up COGS model with supplier quotes, FDA meeting minutes and QMS audit, all at Month 6. | Hold Series A1 (USD 3-4M) and Newark Phase 1 expansion; narrow Cluster 1 to 8-10 analytes if plasma yield is <95%; if fewer than 8 analytes validate at >= 95% concordance by Month 12, stop single-drop positioning and move to Fallback V1 or a lab-service model. |
| 3 | Does written FDA Pre-Submission feedback support staged per-cluster 510(k), and if De Novo is indicated, is funding committed through Month 66? | 510(k) path with a suitable predicate and acceptance of staged per-cluster submissions; if De Novo (+12-18 months, +USD 2-4M, gap up to about USD 21M), committed funding covering clearance through Month 66 by Month 15 (FM5 stop rule). | Written FDA feedback by Month 6, regulatory consultant assessment, and a Series B/escrow term sheet sized against the extended burn by Month 15. | Re-baseline clearance to Months 48-66 and resize Series B; if funding is not committed by Month 15, cancel device clearance and pivot to CLIA lab-service or licensing. |
| 4 | Do payer and pharma evidence support unit economics at the 60% margin gate on a defined per-run basis? | Modeled gross margin >= 60% at 50k cartridges/month (requires net revenue >= about USD 100-113 per run at USD 40-45 variable cost); first paid pharma contract (USD 50-100k) by Month 9; >= 10 payer interviews completed. The retreat floor (USD 80 vs USD 100 per run vs 30% margin) must be fixed before the test. | Payer-readiness memo with low/mid/high net-revenue cases, CPT pathway analysis and bottom-up COGS, signed pharma contract, presented to the board by Month 9, before the A2 release at Month 12. | Split/downsize: withhold A2 (USD 2-3M) and Phase 2 Newark (USD 2-3M), narrow to a lower-cost menu or a services/CLIA route; stop device scale-up if validated net revenue is <USD 80 per run and 12 months of runway is not financed by Month 15. |
| 5 | Does the Month 12 analytical feasibility gate pass for the lead cluster? | Pilot yield >= 85% (>= 5 batches x 1,000 cartridges, lower 95% CI >= 80%); lot CV <10%; shelf-life projected >= 12 months (Arrhenius R2 >0.90); analytical concordance >= 95%; modeled COGS <= USD 25 (proposed thresholds). | Pilot-fill batch records, stability model and concordance data from the contract/Phase 1 site at Month 12. | Yield <80% (or lower CI <75%): pause Newark spend, one 4-week design review and retest; 80-85% runs 2-3 extra batches; unresolved by Month 15 activates Fallback V1 by board vote within 2 weeks. Shelf-life 9-12 months: retest at Month 15; <9 months: reformulate and delay about 3 months. |
| 6 | Is the lead-cluster design frozen with interim clinical evidence, and is the pharma run-rate sufficient to release Phase 2 Newark? | Design freeze signed by Month 18; interim concordance >= 95% (lower CI >= 93%, 150-200 samples); Newark pilot-fill yield >= 85%; ISO 13485 certified; FTO complete; pharma/contract run-rate >= USD 100k/month. | Signed design-freeze record, interim analysis, ISO certificate and the Month 18 revenue dashboard; the interim read should be available before the freeze deadline. | Do not place binding equipment orders or release USD 2-3M Phase 2 (plus USD 400-600k contingency) or A3; trigger lean pivot (-20-30% headcount, pause full Newark build) and replan with a freeze extension of weeks, not months. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: executive summary; review plan R1/R5/R11; self-audit 7
    canonical: economic_unit = 1 run = 1 cartridge (10-15 analytes); menu of 50 analytes = about 4-5 runs; net revenue USD 100-200 per run (base)
    observed:  USD 100-200 per panel vs USD 160-225 per 50-analyte menu (negative to 20% margin)
HIGH CF-002  document: executive summary; review plan R1/R3/R11; self-audit 6
    canonical: de_novo_fallback = +12-18 months and USD 2-4M; total equity need about USD 15-33M; gap after Month 24 up to about USD 21M; needs Series B sizing for +12-18 months runway (estimate)
    observed:  USD 3-5M contingency 'committed' / 'expansion', locked at Month 1, 2 or 6, for Months 18-30
HIGH CF-003  document: executive summary; review plan R4/R5; self-audit 7/8
    canonical: fallback_panel_v1 = 50-analyte pre-registered core menu; retreat range 50-100 analytes (proposed threshold)
    observed:  Fallback V1B of 25-35 / 20-30 analytes (2-3 cartridges) activated by the same yield trigger
HIGH CF-004  document: executive summary; self-audit 7 and 8; review plan R5/R6
    canonical: gross_margin_target = >= 60% at 50k cartridges/month; requires net revenue >= USD 100-113 per run (proposed threshold)
    observed:  retreat if mid-case < USD 100 per run, or < USD 80, or margin < 30%; 30-60% band 'continues'
MEDIUM CF-005  document: executive summary; review plan R1/R9/R11
    canonical: seed_period_commitments_vs_seed = Months 0-6 non-payroll commitments of USD 2.0-3.6M vs Seed USD 2-3M (estimate); decision needed on Seed sizing or A1 timing
    observed:  USD 0.6-1.6M gap; SBIR/deferred Phase 1 close it
MEDIUM CF-006  document: review plan R1/R11/R14; self-audit 11; pitch
    canonical: cartridge_cluster_size = 10-15 analytes per cartridge (Cluster 1 lead cartridge)
    observed:  Cluster 1 = 50 analytes; Clusters 1-5 x 50; one cluster per year Months 36-84
MEDIUM CF-007  document: review plan R4/R8/R10; premortem A3
    canonical: gate_month6_criteria = plasma separation >= 95% of >= 100 subjects with >= 1.6 uL plasma and hemolysis index <50 (proposed threshold)
    observed:  Cluster 1 of 10-15 analytes in an 8-16 analyte budget; 'recovery <95%'
MEDIUM CF-008  document: review plan R4 #3 and R6 #1; self-audit 18
    canonical: shelf_life_thresholds = Pass >= 12 months projected (R2 >0.90); 9-12 months retest at Month 15; <9 months reformulate and delay about 3 months (proposed threshold)
    observed:  label capped at 9 months when projection <9 months; analyte pass rate 95% vs 90% vs stop <8
MEDIUM CF-009  document: review plan R13 #3
    canonical: design_freeze_lead_cluster = Months 15-18 (hard deadline Month 18)
    observed:  removal vote Month 19; freeze extended by weeks; orders Months 20-21
MEDIUM CF-010  document: executive summary; self-audit 5/10/13; review plan R4/R12; pitch
    canonical: regulatory_milestones = FDA Pre-Sub held by Month 6 (request Months 2-3); mock FDA inspection Months 28-30; first submission Month 30 (proposed threshold)
    observed:  request by Month 1; registration Month 6; 'pre-approval inspection' Months 28-30; hire locked Month 15
MEDIUM CF-011  document: review plan R14, R15, R16; self-audit 15
    canonical: breakeven_volume = USD 3.75-7.5M/yr burn proxy (estimate)
    observed:  USD 35-50M+; runway extended 1-2 months per USD 50-100k contract
MEDIUM CF-012  document: self-audit 12
    canonical: preproject_regulatory_and_quality_budget = payer analytics USD 300-500k by Month 12 (estimate)
    observed:  5-payer rapid screen, USD 30-50k, payer strategy deferred to post-clearance
```

### 1. Revenue unit: per run (cartridge) vs per 50-analyte panel (🔴 High) — needs a project decision

- **Executive summary (Focus; Risk 1); Review plan R1, R5 #3, R11 #3:** 50-analyte menu variable cost USD 160-225 (4-5 x USD 40-45) vs base-case net revenue USD 100-200 per panel gives negative to 20% margin, 'not the 60% target'.
- **Canonical economic_unit / net_revenue_per_run_base / gross_margin_target; Self-audit 8; Pitch:** Net revenue is USD 100-200 per run (1 run = 1 cartridge); 60% margin needs USD 100-113 per run; capacity ceiling USD 12-24M/yr = 10k cartridges x USD 100-200.
- **Why it conflicts:** Recomputed per cartridge, USD 100-200 against USD 40-45 gives about 55-80% margin, so 60% is reachable; the 'negative to 20%' result holds only if a whole 4-5-cartridge menu is paid USD 100-200. The same range is used on both bases, so the 'unit economics broken' headline and the USD 80/USD 100 triggers have no single meaning. The USD 40-45 cost also differs from the USD 25 COGS ceiling, and no document states that cold chain (USD 15-20, outside COGS) bridges the two.
- **Suggested resolution:** Decide the billing unit: if payers pay per cartridge run, withdraw the 'unit economics broken' claim and express all triggers per run; if payers pay per 50-analyte panel, the 60% target needs about USD 400-560 per panel (recomputed from USD 160-225), which only the 'unlikely' USD 300-500 case approaches. State explicitly that USD 40-45 = USD 25 COGS + USD 15-20 cold chain.

### 2. De Novo contingency Series B: additional or baseline, size, lock date, 'committed' (🔴 High) — needs a project decision

- **Executive summary (Timeline and Budget; Risk 2; Purpose); Self-audit 6 (escrow at Series A close):** Seed + A tranches + Series B USD 3-5M = USD 12-18M 'committed'; De Novo contingency USD 3-5M is an 'open decision' / 'expansion'; lock at Month 2 board vote.
- **Executive summary (Action Orientation); Review plan R1 #3, R3 #3, R11 #2; canonical de_novo_fallback:** Contingency 'locked by Month 6 = Pre-Submission feedback'; USD 3-5M covers Months 18-30 for a 12-18 month extension; gap rises from up to about USD 17M to about USD 21M.
- **Why it conflicts:** The documents never say whether the USD 3-5M is the baseline Series B, an addition to it, or an escrow released on a De Novo finding. The lock date is Month 1, 2 or 6 depending on the section, and cannot precede the Month 6 FDA feedback. The size does not reconcile with the burn proxy (USD 3.75-7.5M/yr x 1-1.5 years = about USD 3.75-11.25M, recomputed), and the De Novo delay falls after Month 48, not Months 18-30. The baseline gap of up to USD 17M equals USD 30M burn minus Seed and A (USD 13M) with Series B and non-dilutive funding excluded, so it is unclear whether Series B (Months 18-24) is inside or outside it. Gate-linked, unsigned tranches are called 'committed'.
- **Suggested resolution:** Board to choose one structure: (a) escrow/option pre-sized at Series A close and released on a De Novo finding at Month 6, (b) additional Series B tranche sized to the burn proxy, or (c) replan trigger only. Restate tranches as 'planned, gate-linked' rather than 'committed', and state whether the USD 17M gap is before or after Series B and non-dilutive funds.

### 3. Fallback product floor: V1 (50 analytes) vs V1B (20-35 analytes) (🔴 High) — needs a project decision

- **Canonical fallback_panel_v1 / stop_and_fallback_rule; Executive summary (Action Orientation, Takeaway); Premortem FM2:** Fallback Panel V1 (50 analytes, retreat range 50-100) is the guaranteed product, activated by board vote within 2 weeks if yield <80% is unresolved by Month 15.
- **Executive summary (Risk 1, Feedback); Review plan R4 #1, R5 #3; Self-audit 7, 8; Premortem FM1:** Fallback V1B (25-35 analytes) / (2-3 cartridges) / (20-30 analytes) is activated by the same Month 15 yield trigger or by the margin and price triggers.
- **Why it conflicts:** V1B sits below the canonical 50-100 retreat range, is sized three ways (20-30, 25-35, 2-3 cartridges), and is not a canonical fact. One trigger (yield unresolved by Month 15) leads to V1 in some places and V1B in others, so the stop point is unknown. V1 itself (4-5 cartridges) is the menu whose economics are called broken, so retreating to V1 does not cure a margin failure.
- **Suggested resolution:** Decide whether the product floor may go below 50 analytes. Options: (a) keep V1 as the only product floor and treat margin failure as a pivot/stop to services; (b) pre-register one sized V1B with a defined staffing cut and a margin-specific activation rule, separate from the yield rule. Until decided, document one activation target per trigger.

### 4. Margin gate vs retreat triggers (USD 80, USD 100, 30%) (🔴 High) — needs a project decision

- **Self-audit 8; Review plan R2 #2, R6 #3; canonical gross_margin_target:** Gate is >= 60% at 50k cartridges/month (needs USD 100-113 per run); retreat floor 30%, and in the 30-60% band V1 continues with a cost-down review.
- **Executive summary (Risk 1, Feedback); Self-audit 7; Review plan R5 #3, R3 #2; Premortem FM1 stop rule (<USD 80):** If mid-case net revenue is < USD 100 per run, activate Fallback V1B / retreat; payer price < USD 80 per run forces pivot; Series A Tranche 2 scope is adjusted.
- **Why it conflicts:** At USD 40-45 per cartridge, USD 100 gives about 55-60% margin and USD 80 about 44-50%, both inside the band where Self-audit 8 says continue; the 30% floor corresponds to roughly USD 57-64 per run (recomputed). The three triggers therefore give different actions for the same Month 9 data. The 50k/month volume has no date (scale-up target is 10k by Month 36), so a Month 9 test can only be modeled, and Self-audit 15 now assumes 50k by Month 60.
- **Suggested resolution:** Fix one trigger in margin terms on a stated per-run basis (gate >= 60% at 50k modeled at Month 9; one retreat floor), derive the USD per run equivalents from it, and define the action for the band between floor and gate. The retreat floor is not canonical and requires a board decision.

### 5. Seed gap arithmetic, payroll and mitigation timing (🟡 Medium)

- **Executive summary (Purpose); Review plan R1 #2, R9 #2, R11 #1; Self-audit 6:** Non-payroll commitments USD 2.0-3.6M vs Seed USD 2-3M leave a 'USD 0.6-1.6M' gap.
- **Canonical seed_period_commitments_vs_seed; Review plan R3 #3, R9 #2:** Seed USD 2-3M can exceed commitments of USD 2.0M; commitments exclude payroll; options include deferring Phase 1 (USD 0.5-0.8M) or SBIR grants (applications Months 4-5).
- **Why it conflicts:** Recomputed, the shortfall ranges from no gap (USD 2.0M vs USD 3M) to USD 1.6M; USD 0.6-1.6M uses only the USD 3.6M upper commitment case. Payroll is excluded, so the true Months 0-6 shortfall is larger and unquantified. SBIR awards cannot arrive within Months 0-6, and deferring Phase 1 (Months 3-6) cannot cover a USD 0.6-1.6M gap. Option A (defer A1 to Month 9) also moves the canonical Month 6 A1 gate.
- **Suggested resolution:** State the gap as a range with payroll included once a Months 0-6 cash table exists; treat SBIR as a Months 10+ source; keep A1 at the Month 6 gate or record the change as a decision.

### 6. Meaning of 'cluster', the 3-cluster claim rule and 500-analyte pace (🟡 Medium)

- **Canonical cartridge_cluster_size / public_claim_rule / menu_500_timing; Project plan:** A cluster is a 10-15 analyte cartridge; no '500 tests' marketing until at least 3 clusters are independently validated; 500 analytes at Months 90-129 via 10 blocks of 50 (about 6-9 months per block).
- **Review plan R1, R11 #3, R14 #3; Self-audit 11; Executive summary (Takeaway):** Cluster 1 = 50 analytes (4-5 cartridges); 'narrow Cluster 1 from 50 to 20-30'; Clusters 1-5 each 50 analytes, one per year in Months 36-84; '3-5 clusters'.
- **Why it conflicts:** '3 clusters' means 30-45 analytes or about 150, depending on the definition. Five 50-analyte clusters give 250, not 500, and one per year from Month 36 gives about 250 by Month 84, which does not match 10 blocks at Months 90-129. The pitch also calls the 50-analyte core 'pharma-funded' although non-dilutive funding is USD 1-2M against USD 15-30M burn.
- **Suggested resolution:** Use 'cluster' = 10-15 analyte cartridge and 'block' = 50 analytes (4-5 clusters); apply the claim rule to clusters; replace 'Clusters 2-5' with blocks 2-10 and the 6-9 month pace; remove 'pharma-funded' or qualify it.

### 7. Plasma-volume gate vs Cluster 1 size (🟡 Medium) — needs a project decision

- **Canonical gate_month6_criteria / cartridge_cluster_size; Premortem A3; Pitch:** Month 6 gate: >= 95% of >= 100 subjects with >= 1.6 uL usable plasma; Cluster 1 = 10-15 analytes.
- **Canonical single_drop_analyte_budget; Review plan R4 #1, R10 #3 (and the older assumptions' worked example):** Drop-volume budget is about 8-16 analytes; 1.6 uL at 200 nL per analyte supports 8 analytes; Cluster 1 'may exceed available sample volume'.
- **Why it conflicts:** The 1.6 uL threshold comes from an example (2 uL drop x 80% recovery, 200 nL/analyte = 8 analytes). A Cluster 1 of 10-15 analytes needs <= about 107-160 nL per analyte at 1.6 uL (recomputed), a per-analyte volume no document establishes. Passing the gate would not show that the cluster fits. Review R4/R8/R10 also mix 'plasma recovery <95%' (volume fraction) with '>= 95% of subjects' (success rate) and write '<= 1.6 uL per analyte' for a total-volume figure.
- **Suggested resolution:** Set the per-analyte volume requirement from measured assay chemistry and derive the minimum plasma volume for the chosen cluster size, or accept a Cluster 1 at the lower end of 8-16. Correct the unit wording to subject-level success rate.

### 8. Month 12 analyte pass-rate threshold and shelf-life consequence (🟡 Medium) — needs a project decision

- **Review plan R6 #1:** >= 95% of pre-specified analytes must meet concordance >= 95%, CV <10%, shelf-life >= 12 months.
- **Self-audit 11, 18; Premortem FM3 stop rule; Review plan R4 #3; canonical shelf_life_thresholds:** >= 90% of planned Cluster 1 analytes (target 13-15 of 15); stop only if fewer than 8 analytes validate; if shelf-life projects <9 months, cap label at 9 months and delay launch.
- **Why it conflicts:** Three pass levels apply to the same gate (95%, 90%, stop below 8 of 10-15); 13 of 15 is 86.7%, below 90%, and between about 14 and 8 analytes no action is stated. The shelf-life contingency (cap label at 9 months) conflicts with the canonical rule (pass >= 12; 9-12 retest at Month 15; <9 reformulate, delay about 3 months).
- **Suggested resolution:** Define one analyte pass fraction and one action for the band between pass and stop; use the canonical shelf-life rule.

### 9. Design-freeze hard deadline vs later removal vote (🟡 Medium)

- **Canonical design_freeze_lead_cluster / gate_month18_criteria; Executive summary; Premortem FM2:** Design freeze: hard deadline Month 18, with interim concordance also assessed at Month 18; binding orders only at the Month 18 release.
- **Review plan R13 #3:** Analyte-removal vote by Month 19; a failed interim read extends the freeze 2-4 weeks and pushes equipment orders to Months 20-21.
- **Why it conflicts:** A hard deadline of Month 18 cannot coexist with a Month 19 vote, a freeze extension and an escalation at Months 20-21. Interim concordance reported at Month 18 leaves no time to act on it before the freeze.
- **Suggested resolution:** Keep Month 18 as the deadline; take the interim read at Months 15-16 (enrollment runs from Month 12) so removal decisions precede the freeze; remove the Month 19 vote or label it a formal deadline slip with a re-baselined release date.

### 10. Same milestones with different months and out-of-order dependencies (🟡 Medium)

- **Canonical regulatory_milestones; Project plan; Review plan R12/R13/R16; Premortem A4/FM7; Self-audit 16:** FDA Pre-Sub request Months 2-3, held by Month 6; protocol locked by Month 9-10; mock inspection Months 28-30; CFO hired by Month 2; lock Quality lead acceptance as a Month 1 hire; permits with a 4-6 month review.
- **Executive summary (Action); Self-audit 5, 13, 10; Review plan R4 #2, R4 #3, R12 #1, R4/R5 (Month 4); Pitch (Call to Action):** Pre-Sub request by Month 1; Charter signed at Month 1 closing naming the CFO; ClinicalTrials.gov registered at Month 6; 'pre-approval inspection' at Months 28-30; Quality lead acceptance locked by Month 15; permits submitted Month 2 yet in hand by Month 5; cross-reactivity matrix done by Month 4; pharma study 'beginning Month 6', 2-3 months.
- **Why it conflicts:** The same milestone carries different months. The Charter names a CFO who is hired a month later. A registration at Month 6 precedes the Month 6 FDA feedback and the Month 9-10 protocol lock. Months 28-30 is a mock inspection, not the pre-approval inspection. A Month 15 lock for a Month 1 hire is out of order. A 4-6 month permit review from Month 2 ends at Months 6-8, after the Month 5 tripwire and the Month 6 Phase 1 operational date. A 3-4 month matrix study started at Month 3, after the Month 2 cluster definition, cannot finish by Month 4. The pitch study start and 2-3 month length differ from the canonical first contract (paid by Month 9; samples over Months 10-15).
- **Suggested resolution:** Use the canonical months: request Months 2-3; registration at Months 9-10; mock inspection label; Quality lead by Month 3 (premortem A5); matrix study completing Months 5-6; permit tripwire consistent with a 4-6 month review; Charter naming the CEO/board until the CFO starts; pharma wording per canonical.

### 11. Arithmetic in funding and impact figures (🟡 Medium)

- **Review plan R14 #3, R15 #2, R16 #1; Self-audit 15:** Clusters 2-5 at USD 1-2M each raise capital need from USD 15-30M to 'USD 35-50M+'; about USD 4-10M for Clusters 2-5; each USD 50-100k pharma contract extends runway 1-2 months; gate automation saves 12-16 weeks over 3 gates.
- **Recomputed from the same documents and canonical breakeven_volume / cumulative_burn_through_clearance:** 4 clusters x USD 1-2M = USD 4-8M, so USD 19-38M; burn proxy USD 3.75-7.5M/yr is about USD 0.31-0.63M/month; 3 gates x 2-4 weeks = 6-12 weeks.
- **Why it conflicts:** USD 15-30M + USD 4-8M is USD 19-38M, not USD 35-50M+. At the burn proxy a USD 50-100k contract covers about 0.1-0.3 months, not 1-2. The savings figure exceeds its own per-gate assumption.
- **Suggested resolution:** Correct to USD 19-38M and USD 4-8M (or state five clusters), restate contract runway extension at about 0.1-0.3 months, and fix the weeks saved.

### 12. Payer validation scope: gating vs deferrable (🟡 Medium)

- **Executive summary (Purpose, Risk 1); Review plan R3 #2; canonical preproject_regulatory_and_quality_budget:** Payer net-revenue validation (>= 10 payers) completes by Month 9 and gates Series A Tranche 2 (Month 12) and Phase 2 Newark; payer analytics USD 300-500k by Month 12.
- **Self-audit 12:** 'None of these gates depend on pre-validated payer coverage models'; payer strategy is critical 'only post-clearance'; run a 5-payer rapid screen and reallocate USD 30-50k.
- **Why it conflicts:** Self-audit 12 removes payer evidence from the gates, while the unit-economics gate at Month 9 and the A2 release depend on it. The 5-payer screen and USD 30-50k also differ from >= 10 payers and USD 300-500k.
- **Suggested resolution:** Keep >= 10 payer interviews and the Month 9 memo as a gate input; defer only multi-block value-based modeling, and align the budget to the canonical USD 300-500k.

## Summary

The plan is largely aligned with the canonical facts on gates, tranches, Newark phasing and fallback rules, and most earlier fixes (A-tranche total, CLIA 'prepared' wording, 80-85% yield band) now hold. The remaining inconsistencies are concentrated in the economics: the revenue unit (per run vs per panel), the margin and price retreat triggers, the V1/V1B floor and the De Novo contingency structure. These change the go/no-go logic and need board decisions rather than wording fixes. The rest are repairable inconsistencies: cluster terminology and pace, seed-gap arithmetic, milestone months and a few arithmetic errors.