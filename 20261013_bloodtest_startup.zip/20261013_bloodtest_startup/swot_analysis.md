
## Strengths 👍💪🦾
- Pragmatic Foundation path: modular 10-15 analyte cartridges validated, cleared and sold one cluster at a time, so one cluster failing does not sink the whole program.
- Pre-registered Fallback Panel V1 (50 analytes) and gate criteria (Months 6, 12, 18 = 2027-04-13, 2027-10-13, 2028-04-13) give a planned retreat instead of sunk-cost escalation.
- Credibility-first rules: no '500 tests' marketing until 3 clusters are independently validated, advisory board with raw-data audit, published failures.
- Newark limited to reagent formulation and filling (highest-risk step); molding and instrument assembly contracted, so fixed cost tracks demonstrated yield.
- Quality system and design controls start at Month 1 (2026-11-13), with early senior IVD hires (R&D director, quality/regulatory lead).
- Funding is tranche-based and gate-linked, with a pharma/grant beachhead, a CLIA lab-service fallback by Month 12 (2027-10-13), and a Bay Area talent and supplier cluster near Newark.

## Weaknesses 👎😱🪫⚠️
- Drop budget supports only about 8-16 analytes per drop (estimate), so the 500-test headline cannot be met per run; the 500-analyte menu is not committed within Months 0-72 (2026-10-13 to 2032-10-13) and is estimated at Months 90-129 (2034-04-13 to 2037-07-13).
- Unit economics are weak: a 50-analyte menu costs USD 160-225 variable (4-5 cartridges) against USD 100-200 net revenue per panel (estimate), far below the 60% margin target.
- No product revenue before clearance (Months 36-48 = 2029-10-13 to 2030-10-13); about USD 17M still to raise after Month 24 (2028-10-13) (estimate); Seed USD 2-3M is below Months 0-6 (2026-10-13 to 2027-04-13) commitments of USD 2.0-3.6M (estimate).
- Multi-cartridge workflow (several consumables per collection) adds user burden and weakens the single-drop appeal.
- Shared dependencies (plasma separation, collection device, cold chain) concentrate risk across clusters despite modularity.
- Gate thresholds are proposed before real data exist; budget cap, CLIA fallback cost and clinical sample size remain open.
- Heavy dependence on contract molders and dual-sourced reagents, with tooling financing unresolved.

## Opportunities 🌈🌐
- Pharma and clinical-trial biomarker monitoring can fund evidence generation with less reimbursement dependence (first paid contract targeted by Month 9 = 2027-07-13).
- Non-dilutive SBIR/STTR and grants (USD 1-2M over Months 0-24 = 2026-10-13 to 2028-10-13, estimate) reduce dilution and add validation credibility.
- FDA Pre-Submission by Month 6 (2027-04-13) can confirm a staged per-cluster path, as Abbott i-STAT's cumulative menu suggests.
- The CLIA lab-service route, viable after the 2025 LDT rule rescission, could generate early revenue and real-world data.
- A transparent, published-failure approach can differentiate against the Theranos legacy and build clinician, payer and investor trust.
- Partnerships or licensing with an established diagnostics firm could add regulatory experience, distribution and validation capacity.
- Cepheid-style Bay Area cartridge manufacturers and alumni offer process know-how and talent for Newark filling.

## Threats ☠️🛑🚨☢︎💩☣︎
- Analytical infeasibility: cross-reactivity, plasma separation and reagent stability may cap Cluster 1 below plan.
- Regulatory uncertainty: De Novo could add 12-18 months and USD 2-4M, moving clearance to Months 48-66 (2030-10-13 to 2032-04-13) and raising the gap after Month 24 (2028-10-13) to about USD 21M (estimate).
- Reputational contamination from failed single-drop precedents, including one in Newark, that may bias investors, regulators and clinicians.
- Payers may not cover a multiplex bundle; reimbursement could fall to USD 50-100 per run (low case).
- Pharma contracts may slip, causing a funding gap at Months 18-24 (2028-04-13 to 2028-10-13) or a down round.
- Competitors or incumbents may launch broader panels before Months 36-48 (2029-10-13 to 2030-10-13).
- The LDT enforcement-discretion regime could change, and FDA inspection findings could delay clearance.
- Scarce Bay Area talent and supplier or reagent discontinuations may stall production.

## Recommendations 💡✅
- By Month 1 (2026-11-13), board and founders approve gate criteria, Fallback Panel V1 and the 'no 500-test claim' rule in writing (owner: CEO/board).
- By Month 2 (2026-12-13), finish the drop-budget and plasma-separation model, then run the Month 4-6 (2027-02-13 to 2027-04-13) study (>=100 subjects) to size Cluster 1 realistically (owner: R&D director).
- Request FDA Pre-Submission in Months 2-3 (2026-12-13 to 2027-01-13) and hold it by Month 6 (2027-04-13), asking 510(k) versus De Novo and the CLIA parallel route; model both timelines in the funding plan (owner: quality/regulatory lead plus consultant).
- By Month 3 (2027-01-13), build a unit-economics model with a per-run price test; lock the USD 25 COGS ceiling by Month 6 (2027-04-13) and test payer scenarios by Month 9 (2027-07-13) (owner: CFO, commercial lead).
- Resolve the Seed shortfall by Month 2 (2026-12-13), via a larger Seed or an earlier A1; start SBIR/STTR applications by Month 5 and 5-10 pharma conversations by Month 3 (2027-01-13) (owner: CEO/CFO).
- Phase Newark: Phase 1 reagent lab (USD 500-800k) Months 3-6 (2027-01-13 to 2027-04-13); no binding long-lead orders before the Month 18 (2028-04-13) release (owner: operations lead).
- Stand up the advisory board by Month 1 (2026-11-13) and publish the first quarterly performance report, including failures, by Month 6 (2027-04-13) (owner: chief scientist, communications).

## Strategic Objectives 🎯🔭⛳🏅
- By Month 6 (2027-04-13): meet Month 6 (2027-04-13) gate criteria (plasma separation >=95% of >=100 subjects, cross-reactivity <=5% bias, COGS ceiling locked, Pre-Sub held, QMS live).
- By Month 12 (2027-10-13): pass the analytical feasibility gate for Cluster 1 (yield >=85%, lot CV <10%, shelf-life >=12 months projected, concordance >=95%, COGS <= USD 25).
- By Month 18 (2028-04-13): freeze the lead-cluster design, achieve ISO 13485 certification and show Newark pilot yield >=85%.
- By Month 18 (2028-04-13): reach a pharma/grant run-rate >= USD 100k/month and cumulative commitments of USD 1-2M by Month 12 (2027-10-13).
- By Month 30 (2029-04-13): submit the first 510(k)/De Novo; target clearance by Month 48 (2030-10-13) with first commercial sales.

## Assumptions 🤔🧠🔍
- The 500 tests are a cumulative modular menu, not one run, and the Pragmatic Foundation path is adopted.
- The LDT enforcement-discretion regime remains in place through the CLIA fallback period.
- Cumulative burn through clearance is USD 15-30M (estimate), funded by gate-linked equity plus grants and pharma.
- About 8-16 analytes per drop (estimate) and USD 100-200 net revenue per run (base case, estimate).
- Bay Area talent and contract molders are obtainable at market rates.
- Gate thresholds are proposed and may be refined after Pre-Submission feedback.

## Missing Information 🧩🤷‍♂️🤷‍♀️
- Formal budget cap and latest acceptable date for clearance or first revenue.
- Initial clinical use case and intended-use claim for Cluster 1, and which analytes it contains.
- Actual customer demand: which pharma sponsors, clinicians or payers would pay, and at what price.
- CLIA lab-service cost and revenue estimates.
- Clinical study sample size and FDA feedback on 510(k) versus De Novo.
- Freedom-to-operate results and financing of tooling and contract-manufacturer capex.
- Competitor launch timelines and detection and readout technology selection.
- Early evidence on which customers return and which tests they choose first, to reveal what drives adoption.

## Questions 🙋❓💬📌
- If the drop budget supports only about 8-16 analytes per run, what customer need is met by a 10-15 analyte cartridge that justifies USD 100-200 per run?
- Which gate failure would the board genuinely act on, and who has the authority to activate Fallback V1 without sunk-cost resistance?
- Would pharma sponsors pay for this platform before Month 18 (2028-04-13) if Cluster 1 data were only analytical, and what proof do they need?
- If De Novo is required, can the company afford the extra 12-18 months and about USD 21M gap, or should the CLIA route lead?
- How will the company differentiate itself credibly from Theranos-era claims to investors, payers and clinicians, and what evidence would change your mind about Newark investment?