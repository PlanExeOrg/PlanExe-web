**6 open decisions: 4 high and 2 medium severity.** The unit-economics and fallback decisions (billing unit, retreat floor, V1 vs V1B) and the De Novo funding structure are the most consequential, as they change go/no-go logic and the Month 6-15 (2027-04-13 to 2028-01-13) gates. Before they are made, the plan can proceed with Seed closing, key hires, Cluster 1 definition and Month 6 (2027-04-13) gate studies. Plasma-volume and Month 12 (2027-10-13) pass-fraction choices must be fixed before study protocols are locked.

| # | Decision | Severity | Owner | Decide by | Blocks |
|---|---|---|---|---|---|
| 1 | Revenue billing unit | 🔴 High | Investor Board with CEO and CFO | Month 3 (2027-01-13), so the payer interview design (by Month 9 = 2027-07-13) uses the right unit. | Month 9 (2027-07-13) payer memo and unit-economics gate; A2 release at Month 12 (2027-10-13). |
| 2 | Margin gate and retreat floor | 🔴 High | Investor Board | Month 6 (2027-04-13), before payer work concludes at Month 9 (2027-07-13). | Month 9 (2027-07-13) unit-economics test and A2 release at Month 12 (2027-10-13). |
| 3 | Fallback product floor | 🔴 High | Investor Board (CEO, Steering Committee) | Month 9 (2027-07-13), before the A2 and Month 12 (2027-10-13) gate. | Month 12 (2027-10-13) gate fail path and Month 15 (2028-01-13) fallback vote. |
| 4 | De Novo contingency structure | 🔴 High | Investor Board / Lead Investor | Month 6 (2027-04-13), when FDA Pre-Sub feedback arrives. | Month 6 (2027-04-13) gate and Month 15 (2028-01-13) funding commitment (FM5). |
| 5 | Cluster 1 size vs plasma volume | 🟡 Medium | Project Steering Committee with Technical Advisory Group | Month 2 (2026-12-13), when Cluster 1 is defined. | Month 6 (2027-04-13) gate study protocol. |
| 6 | Month 12 (2027-10-13) analyte pass fraction | 🟡 Medium | Project Steering Committee with Technical Advisory Group | Month 9 (2027-07-13), before Month 12 (2027-10-13) pilot batches are read. | Month 12 (2027-10-13) analytical feasibility gate and A2. |

## 1. Revenue billing unit (🔴 High)

**Decision:** Is net revenue measured per cartridge run or per 50-analyte panel for all margin and retreat triggers?

**Why it is open:** Canonical economic_unit is 1 run = 1 cartridge at USD 100-200 (base). Executive summary and review plan compare USD 100-200 per panel with USD 160-225 menu cost, giving negative to 20% margin.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Per cartridge run: withdraw the 'unit economics broken' claim and express all triggers per run. | 60% gate reachable at USD 100-113 per run; Month 9 (2027-07-13) memo tests payer price per run; A2 release at Month 12 (2027-10-13) stays on the current logic. | Executive summary, review plan R1/R5/R11, self-audit 7; state USD 40-45 = USD 25 COGS + USD 15-20 cold chain. |
| B. Per 50-analyte panel: payers pay one price for the menu. | 60% needs about USD 400-560 per panel (recomputed); only the unlikely USD 300-500 case approaches it; likely downsize or services route. | economic_unit, net_revenue_per_run_base, gross_margin_target, multi_cartridge_menu_economics. |

- **If nobody decides:** Both bases stay in use; Month 9 (2027-07-13) margin test has no single meaning and A2 release is contested.
- **Owner:** Investor Board with CEO and CFO
- **Decide by:** Month 3 (2027-01-13), so the payer interview design (by Month 9 = 2027-07-13) uses the right unit.
- **Blocks:** Month 9 (2027-07-13) payer memo and unit-economics gate; A2 release at Month 12 (2027-10-13).

## 2. Margin gate and retreat floor (🔴 High)

**Decision:** What single retreat floor and band action apply between the retreat floor and the 60% margin gate, stated per run?

**Why it is open:** Self-audit 8 gives 60% gate and 30% floor with continue in between; other documents trigger retreat at USD 100 or USD 80 per run, which equal about 55-60% and 44-50% margin (recomputed).

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Margin-based floor of 30% (about USD 57-64 per run, recomputed); continue with cost-down review in the band. | USD 80 and USD 100 triggers removed; A2 proceeds more readily; more downside exposure. | gross_margin_target; executive summary, self-audit 7/8, review plan R5/R6. |
| B. Price-based floor of USD 80 per run; below it pivot, 80-100 requires cost-down plan. | Stricter; withholds A2 (USD 2-3M) and Phase 2 sooner. | Add retreat floor fact; align Premortem FM1. |
| C. Retreat at the 60% gate (USD 100 per run). | Fails gate on any mid case below USD 100-113; likely downsizing. | gross_margin_target; remove 30% band. |

- **If nobody decides:** Month 9 (2027-07-13) data gives conflicting actions; the conservative branch (withhold A2) applies.
- **Owner:** Investor Board
- **Decide by:** Month 6 (2027-04-13), before payer work concludes at Month 9 (2027-07-13).
- **Blocks:** Month 9 (2027-07-13) unit-economics test and A2 release at Month 12 (2027-10-13).

## 3. Fallback product floor (🔴 High)

**Decision:** May the product floor go below 50 analytes (V1B), and what activates it?

**Why it is open:** Canonical Fallback V1 is 50 analytes (retreat range 50-100). Executive summary, R4/R5 and self-audit use V1B at 20-35 analytes or 2-3 cartridges on the same yield trigger and on margin triggers.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. V1 only; margin failure leads to services/CLIA pivot or stop. | Clear stop point; no sub-50 product; matches the escalation matrix. | Remove V1B from executive summary, R4/R5, self-audit 7/8. |
| B. Pre-register one sized V1B (analyte count, staffing cut) with a margin-specific activation rule. | Adds a lower floor, needs board approval for scope below 50; menu narrower than funder commitment. | fallback_panel_v1 retreat range; stop_and_fallback_rule; escalation matrix. |

- **If nobody decides:** Month 15 (2028-01-13) yield trigger goes to V1 per canonical rule; V1B undefined.
- **Owner:** Investor Board (CEO, Steering Committee)
- **Decide by:** Month 9 (2027-07-13), before the A2 and Month 12 (2027-10-13) gate.
- **Blocks:** Month 12 (2027-10-13) gate fail path and Month 15 (2028-01-13) fallback vote.

## 4. De Novo contingency structure (🔴 High)

**Decision:** How is the De Novo contingency funded: escrow at Series A close, additional Series B tranche, or replan trigger only?

**Why it is open:** Documents call USD 3-5M 'committed' or 'expansion', lock at Month 1, 2 or 6 (2026-11-13, 2026-12-13, 2027-04-13); de_novo_fallback adds 12-18 months and USD 2-4M, gap up to about USD 21M. Not stated whether the USD 17M gap is before or after Series B.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Escrow/option pre-sized at Series A close, released on a De Novo finding after Month 6 (2027-04-13) feedback. | Dilutes earlier; secures funding to Month 15 (2028-01-13) stop rule. | equity_tranche_schedule; de_novo_fallback; funding_gap. |
| B. Additional Series B tranche sized to extended burn. | Series B larger than USD 3-5M; risk in Months 18-24 (2028-04-13 to 2028-10-13). | equity_tranche_schedule; funding_gap_after_month_24. |
| C. Replan trigger only, no pre-sized money. | Lowest early dilution; if De Novo found, cancel or pivot at Month 15 (2028-01-13). | Restate tranches 'planned, gate-linked'. |

- **If nobody decides:** Funding for De Novo is unsized; the Month 15 (2028-01-13) stop rule would cancel device clearance.
- **Owner:** Investor Board / Lead Investor
- **Decide by:** Month 6 (2027-04-13), when FDA Pre-Sub feedback arrives.
- **Blocks:** Month 6 (2027-04-13) gate and Month 15 (2028-01-13) funding commitment (FM5).

## 5. Cluster 1 size vs plasma volume (🟡 Medium)

**Decision:** Which per-analyte volume and Cluster 1 size should the Month 6 (2027-04-13) plasma gate be derived from?

**Why it is open:** Gate uses >=1.6 uL plasma (8 analytes at 200 nL) while Cluster 1 is 10-15 analytes; 10-15 analytes at 1.6 uL need about 107-160 nL each (recomputed). Wording mixes volume fraction and subject success rate.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Set volume threshold from measured assay chemistry for 10-15 analytes. | Gate may need a different volume; study design changes before Month 6 (2027-04-13). | gate_month6_criteria; R4/R8/R10. |
| B. Limit Cluster 1 to the low end (about 8 analytes) at 1.6 uL. | More cartridges per 50-analyte menu; COGS and cold chain rise. | cartridge_cluster_size; fallback_panel_v1 cartridge count. |

- **If nobody decides:** Gate passes at 1.6 uL without proving the cluster fits.
- **Owner:** Project Steering Committee with Technical Advisory Group
- **Decide by:** Month 2 (2026-12-13), when Cluster 1 is defined.
- **Blocks:** Month 6 (2027-04-13) gate study protocol.

## 6. Month 12 (2027-10-13) analyte pass fraction (🟡 Medium)

**Decision:** What analyte pass fraction applies at Month 12 (2027-10-13), and what action covers the band between pass and stop?

**Why it is open:** Review R6 uses >=95% of analytes, self-audit/premortem use >=90% and stop below 8; no action stated for about 8-14 analytes. Shelf-life contingency (cap label at 9 months) conflicts with canonical rule.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. 95% of analytes pass; below it, narrow cluster and retest at Month 15 (2028-01-13). | Strict; more narrowing and delay risk. | gate_month12_criteria; R6 #1. |
| B. 90% of analytes pass; band down to 8 analytes narrows the cluster; below 8 stop. | Keeps cluster viable; 13 of 15 (86.7%) falls in band. | gate_month12_criteria; self-audit 11/18; premortem FM3. |

- **If nobody decides:** Steering Committee judges case by case; shelf-life follows the canonical rule.
- **Owner:** Project Steering Committee with Technical Advisory Group
- **Decide by:** Month 9 (2027-07-13), before Month 12 (2027-10-13) pilot batches are read.
- **Blocks:** Month 12 (2027-10-13) analytical feasibility gate and A2.

## Choices made on your behalf

Set when the scenario was selected, not by you. Confirm or change them.

| Lever | Chosen | Strongest alternative | Why it matters | Revisit by |
|---|---|---|---|---|
| Assay Panel Architecture | Modular cartridge family; 500 is a cumulative menu. | Centralized mass-spectrometry lab with device sample prep. | Sets product, claim rules and the single-drop volume budget. | Month 6 (2027-04-13) gate |
| Regulatory Route and Sequencing | Staged per-cluster 510(k) or De Novo clearances. | CLIA lab service (LDT) first, FDA later. | Drives timeline to clearance at Months 36-48 (2029-10-13 to 2030-10-13) and funding need. | Month 6 (2027-04-13) FDA Pre-Sub feedback |
| Newark Manufacturing Build-Out Timing | Newark as reagent formulation and filling site, phased. | Contract manufacturer first, Newark after design freeze. | Fixes USD 2.9-4.4M capex timing and exposure. | Month 12 (2027-10-13) gate |
| Funding Path and Commercial Beachhead | Pharma and grant beachhead funds evidence. | Narrow physician-ordered panel under existing reimbursement code. | Non-dilutive funding is only USD 1-2M against USD 15-30M burn. | Month 18 (2028-04-13) lean-pivot check |
| Cartridge Fluidic Architecture and Integration Depth | Several specialized cartridges per collection. | Single monolithic cartridge, or reusable reader with disposable strips. | Determines cartridge count, COGS and per-run economics. | Month 6 (2027-04-13) gate |
