This plan implies one or more physical locations.

## Requirements for physical locations

- Manufacturing site in Newark, California (fixed by plan) with cleanroom or controlled-environment space for reagent formulation and cartridge filling
- Zoning and permits allowing light industrial or life-science manufacturing, including biological reagent handling
- BSL-2 capable wet-lab space for R&D with blood-sample handling
- Proximity to Bay Area talent in microfluidics, assay chemistry, quality and regulatory affairs
- Access to highways, Bay Area airports and cold-chain logistics for reagents and cartridges
- Proximity to contract molding and instrument-assembly suppliers and to clinical partners for validation studies
- Scalable lease terms so fixed cost follows demonstrated yield (Month 0 = 2026-10-13 onward, phased)
- Utilities and ISO 13485-compatible facility controls (HVAC, power, water, cold storage)

## Location 1
USA, California

Newark, Alameda County, San Francisco Bay Area

Light-industrial and R&D zones in Newark, CA (e.g., near Cherry Street, Central Avenue, Mowry Avenue corridors); exact site to be selected

**Rationale**: The plan fixes mass production in Newark. Existing industrial buildings can host a reagent formulation and cartridge-filling cleanroom, the phased Newark role in the chosen strategy. Access to I-880 and Dumbarton Bridge supports logistics and supplier proximity.

## Location 2
USA, California

Fremont, Alameda County (adjacent to Newark)

Warm Springs / Fremont life-science and industrial districts, near Newark city limits

**Rationale**: Adjacent to Newark with an established cluster of medtech and diagnostics firms, contract manufacturers and molders. Suited to early R&D labs, pilot builds and supplier hubs, with a shared talent pool and short commutes to Newark.

## Location 3
USA, California

Hayward or Union City, Alameda County

Industrial and lab space in Hayward or Union City, within roughly 15-25 km of Newark (estimate)

**Rationale**: Often lower-cost lab and warehouse space than core Bay Area biotech hubs. Suitable for a pre-Newark development lab, reagent storage or a contract-manufacturing interface, while keeping the team near the Newark site.

## Location 4
USA, California

South San Francisco or Berkeley/Emeryville, Bay Area

Shared lab incubators and clinical-research partner sites (university and hospital networks)

**Rationale**: Provides access to academic collaborators, clinical sites for method-comparison and venous reference studies, pharma sponsors for the beachhead, and investor and regulatory-consultant networks, without committing fixed capital early.

## Location Summary
Newark, California is explicitly named for mass production, so it is the anchor site, with an initial role in reagent formulation and cartridge filling. Nearby Fremont and Hayward/Union City offer lower-risk, scalable lab and supplier space. South San Francisco and the East Bay cluster provide clinical, academic, pharma and investor access for validation and funding.