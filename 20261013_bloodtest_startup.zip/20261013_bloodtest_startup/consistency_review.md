## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Is Months 0-6 (2026-10-13 to 2027-04-13) funding secured so that Seed plus pre-committed Series A1 covers non-payroll commitments AND payroll, with the Gate Authority Charter signed? | Seed USD 2-3M closed (tripwire: Seed closed <USD 2M by Month 2 = 2026-12-13) with a written A1 escrow or enlarged Seed that covers non-payroll commitments of USD 2.0-3.6M (estimate) plus payroll for the Month 1 (2026-11-13) hires; Charter signed with CFO named. | Signed Seed term sheet / escrow terms and board-approved Charter by Month 2 (2026-12-13); sized Months 0-6 (2026-10-13 to 2027-04-13) cash model. | Delay or downsize: defer Newark Phase 1 (USD 500-800k) and non-essential studies, pursue SBIR/STTR and pharma feasibility income, and do not start Month 3 (2027-01-13) site and equipment commitments until funding is closed. |
| 2 | Does the Month 6 (2027-04-13) gate pass: plasma separation, cross-reactivity, locked COGS ceiling, FDA Pre-Sub held and QMS live? | >=95% of >=100 fingerstick subjects give >=1.6 uL usable plasma with hemolysis index <50; cross-reactivity <=5% bias at 10x interferent; COGS ceiling USD 25 per cartridge locked; FDA Pre-Sub held; electronic QMS live. | External study report and cross-reactivity matrix, COGS bottom-up with supplier quotes, FDA meeting record, QMS validation (Month 6 = 2027-04-13). | Withhold Series A1 (USD 3-4M) and Newark Phase 1 spend; narrow Cluster 1 to validated analytes; if fewer than 8 analytes validate at >=95% concordance by Month 12 (2027-10-13), stop single-drop positioning and move to Fallback V1 or a lab-service model. |
| 3 | Does written FDA feedback support staged per-cluster 510(k), and if De Novo is indicated, is Series B runway for +12-18 months committed by Month 15 (2028-01-13)? | Written FDA feedback on 510(k) vs De Novo (Month 6-7 = 2027-04-13 to 2027-05-13); if De Novo, committed funding must cover clearance through Month 66 (2032-04-13) by Month 15 (2028-01-13) (premortem stop rule); De Novo adds 12-18 months and USD 2-4M. | Pre-Sub written feedback and predicate search (Month 6-7 = 2027-04-13 to 2027-05-13); Series B/bridge term sheet or escrow (by Month 15 = 2028-01-13). | Split: stop device clearance and pivot to the CLIA lab-service or licensing/pharma-services model (only if confirmed legally available), or resize the plan to the funded runway. |
| 4 | Do payer and pharma interviews validate net revenue and margin at the chosen pricing unit, with a first paid pharma contract signed? | >=10 payers interviewed; median net revenue >=USD 100 per run (below USD 80 = stop rule trigger); modeled gross margin consistent with the >=60% at 50k/month target (requires >=USD 100-113 per run); first paid pharma contract (USD 50-100k) signed by Month 9 (2027-07-13). | Payer-readiness memo with low/mid/high cases, CPT pathway analysis and bottom-up COGS; signed pharma contract (Month 9 = 2027-07-13). | Downsize: trigger the narrow-menu fallback (scope to be decided), hold Series A2 (USD 2-3M, Month 12 = 2027-10-13) and Phase 2 Newark; if <USD 80 per run and no 12-month financing by Month 15 (2028-01-13), stop device scale-up and pivot to services or wind down. |
| 5 | Does the Month 12 (2027-10-13) analytical feasibility gate pass at pilot scale? | Pilot yield >=85% (>=5 batches x 1,000; lower 95% CI >=80%); lot CV <10%; shelf-life projected >=12 months (Arrhenius R2 >0.90); analytical concordance >=95%; modeled COGS <= USD 25. | Pilot batch records, stability and Arrhenius model, concordance data, COGS model (Month 12 = 2027-10-13). | Yield <80% (or lower CI <75%) pauses Newark spend with a 4-week design review and retest; unresolved by Month 15 (2028-01-13) triggers Fallback V1 by board vote within 2 weeks; shelf-life of 9-12 months is retested at Month 15 (2028-01-13), <9 months means reformulate (about 3 months delay). Series A2 not released. |
| 6 | Does the Month 18 (2028-04-13) gate pass, and is pharma/contract run-rate at least USD 100k/month so that Phase 2 Newark and A3 can be released? | Lead-cluster design freeze (hard deadline Month 18 = 2028-04-13); interim concordance >=95% (lower CI >=93%, 150-200 samples); Newark pilot fills yield >=85%; ISO 13485 certified; FTO complete; pharma/contract run-rate >=USD 100k/month. | Design freeze sign-off, interim analysis, registrar certificate, FTO opinion, monthly revenue ledger (Month 18 = 2028-04-13). | Lean pivot (-20-30% headcount, pause full Newark build), withhold Phase 2 filling line (USD 2-3M plus 20% contingency) and Series A3, and retreat to Fallback V1 scope (50-100 analytes). |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: executive_summary / review_plan / premortem A2
    canonical: economic_unit = 1 run = 1 cartridge (10-15 analytes); menu of 50 analytes = about 4-5 runs
    observed:  USD 100-200 'per run' revenue compared directly with USD 160-225 cost of a 4-5-cartridge menu
HIGH CF-002  document: review_plan (Reviews 5, 6, 14), executive_summary Feedback, premortem A2
    canonical: gross_margin_target = >=60% at 50k cartridges/month; requires net revenue >= USD 100-113 per run
    observed:  >=40% at 10k/month; <30% at 10k/month; <30% at 50k/month; >=50% at 50k/month
HIGH CF-003  document: executive_summary Action Orientation; review_plan; self_audit 3
    canonical: stop_and_fallback_rule = Yield <80% (mean, or lower CI <75%) pauses Newark spend, 4-week design review, retest; unresolved by Month 15 (2028-01-13) activates Fallback V1 (board vote within 2 weeks)
    observed:  Automatic activation within 5 business days if Month 12 or 18 (2027-10-13, 2028-04-13) gates fail; yield <85% or >=3 analytes failing triggers Fallback V1
HIGH CF-004  document: pitch
    canonical: de_novo_fallback = De Novo adds 12-18 months and USD 2-4M; clearance would move to Months 48-66 (2030-10-13 to 2032-04-13)
    observed:  510(k) pathway adds 12-18 months; De Novo adds 24+ months
HIGH CF-005  document: executive_summary (also review_plan and self_audit)
    canonical: de_novo_fallback = needs Series B sizing for +12-18 months runway (estimate)
    observed:  Series B contingency USD 3-5M, locked at Month 2 (2026-12-13) and also at Month 6 (2027-04-13); Series B counted as 'committed'
MEDIUM CF-006  document: executive_summary; review_plan
    canonical: de_novo_fallback = gap after Month 24 (2028-10-13) up to about USD 21M (baseline about USD 17M)
    observed:  gap rises USD 5-10M; total need USD 21M; gap USD 13-29M
MEDIUM CF-007  document: review_plan / executive_summary / self_audit / pitch
    canonical: fallback_panel_v1 = 50-analyte pre-registered core menu (about 4-5 cartridges of 10-15); retreat range 50-100 analytes
    observed:  Fallback V1B of 20-30 or 25-35 analytes; Cluster 1 = 50 analytes
MEDIUM CF-008  document: review_plan / self_audit / executive_summary / pitch
    canonical: pharma_contract_timing = 2-3 feasibility partnerships by Month 6 (2027-04-13) (unfunded); first paid contract by Month 9 (2027-07-13); no >USD 100k/month before Month 18 (2028-04-13)
    observed:  SOW with USD commitment by Month 6 (2027-04-13); USD 50-200k/month from Month 10 (2027-08-13); lean-pivot assessed at Month 12 (2027-10-13); USD 1-2M SBIR by Month 4 (2027-02-13)
MEDIUM CF-009  document: executive_summary
    canonical: seed_period_commitments_vs_seed = non-payroll commitments of USD 2.0-3.6M vs Seed USD 2-3M (estimate); decision needed on Seed sizing or A1 timing
    observed:  USD 0.6-1.6M gap excluding payroll; USD 12-18M 'committed'
MEDIUM CF-010  document: review_plan Review 10; premortem A7; pitch
    canonical: clia_lab_fallback = CLIA lab-service route prepared and staffed by Month 12 (2027-10-13); cost not quantified (open); revenue unestimated
    observed:  USD 50-200k/month CLIA revenue window; USD 3-5M added burn; launch by Month 12 (2027-10-13)
MEDIUM CF-011  document: self_audit (items 5, 16, 17); premortem FM7
    canonical: long_lead_equipment_rule = binding orders only at Month 18 (2028-04-13) release (after design freeze); 6-12 month lead time
    observed:  order by Month 4 (2027-02-13); Phase 2 Months 12-15 (2027-10-13 to 2028-01-13); lead-time NO-GO at 10-12 weeks; USD 600k NO-GO; permits Month 7 (2027-05-13)
MEDIUM CF-012  document: pitch
    canonical: public_claim_rule = No '500 tests' marketing until at least 3 clusters are independently validated and published; '500 per drop' never used for the cumulative menu
    observed:  "One Drop. 500 Answers."; 250-400 validated analytes by Months 48-72 (2030-10-13 to 2032-10-13)
```

### 1. Revenue unit: per run (cartridge) vs per 50-analyte panel (🔴 High) — needs a project decision

- **canonical_facts: economic_unit, net_revenue_per_run_base, gross_margin_target:** 1 run = 1 cartridge; a 50-analyte menu = about 4-5 runs; net revenue USD 100-200 per run; >=60% margin needs >=USD 100-113 per run (variable cost USD 40-45 per cartridge).
- **executive_summary (Focus, Risks); premortem A2; review_plan Reviews 1, 5, 11; self_audit 7; pitch (Stakeholder Benefits):** "50-analyte bundle variable cost USD 160-225 vs. net revenue USD 100-200 yields negative to 20% margin"; premortem A2 compares "net revenue per run (USD 100-200)" with the 50-analyte menu cost; pitch quotes "50-500 analyte menu at USD 100-200/run".
- **Why it conflicts:** If USD 100-200 is per run against USD 40-45 per cartridge, margin is roughly 55-80% and the 60% target is reachable; the 'negative to 20%' result holds only if a whole 4-5-cartridge menu is sold for USD 100-200. The documents use 'per run' and 'per panel' interchangeably, so the headline unit-economics failure (and the triggers built on it) is not well defined.
- **Suggested resolution:** Decide the pricing and reimbursement unit before the Month 9 (2027-07-13) validation: per cartridge run, per 50-analyte panel, or a bundled price. Options differ materially: per-run pricing makes the economics viable at USD 100+; per-panel pricing at USD 100-200 is not viable at USD 160-225 cost. Then restate every margin figure, trigger and payer-interview script in that unit.

### 2. Gross-margin target and retreat threshold differ across documents (🔴 High)

- **canonical_facts: gross_margin_target, scale_up_volume; pitch Metrics:** Gross margin target >=60% at 50k cartridges/month (50k/month has no committed date; 10k/month by Month 36 = 2029-10-13).
- **review_plan Reviews 5, 6, 14; executive_summary Feedback; premortem A2:** Margin >=40% at 10k/month (Review 6, Review 5), 40% at 10k scaling to >=50% at 50k (Review 14); retreat if <30% at 50k/month (exec Feedback) vs <30% at 10k/month (Review 6, premortem A2).
- **Why it conflicts:** Three different target/trigger combinations (40% at 10k, 50% at 50k, 60% at 50k) and two volumes for the same <30% trigger mean the Month 9 (2027-07-13) gate and the Fallback V1B activation cannot be evaluated unambiguously. A margin test at 50k/month also has no date, so a Month 9 (2027-07-13) test can only be modeled.
- **Suggested resolution:** Keep >=60% at 50k/month as the target (proposed threshold). State one retreat floor with one named volume and say it is a modeled value at Month 9 (2027-07-13); use the 10k/month (Month 36 = 2029-10-13) volume only for actual measurement.

### 3. Fallback V1 activation rule: timing, trigger and authority (🔴 High)

- **canonical_facts: stop_and_fallback_rule; premortem FM2; project_plan Mitigation:** Yield <80% (mean, or lower CI <75%) pauses Newark spend, 4-week design review, retest; unresolved by Month 15 (2028-01-13) activates Fallback V1 with a board vote within 2 weeks.
- **executive_summary Action Orientation; review_plan Reviews 2, 3, 6, 9; self_audit 3:** "Automatic Fallback V1 activation within 5 business days if Month 12 or 18 (2027-10-13, 2028-04-13) gates fail"; Review 6: "yield <85% or failure of >=3 analytes triggers Fallback V1"; self-audit 3: activation within 5 business days of any gate failure.
- **Why it conflicts:** Executive summary also says 'automatic activation by Month 15 (2028-01-13)', while elsewhere activation follows a Month 18 (2028-04-13) gate miss, which is after the Month 15 (2028-01-13) deadline. A yield of 80-85% is a fail under one rule and a retest under another; 5 business days vs 2 weeks; automatic vs board vote. Self-audit 2 and 3 disagree with each other.
- **Suggested resolution:** Use the canonical rule everywhere: <80% (or lower CI <75%) triggers pause and 4-week review, unresolved by Month 15 (2028-01-13) triggers Fallback V1 by board vote within 2 weeks. Remove the 5-business-day and 'yield <85%' / 'Month 18 (2028-04-13)' activation wording, or add them explicitly as a separate Month 18 (2028-04-13) rule.

### 4. De Novo vs 510(k) delay in the pitch (🔴 High)

- **canonical_facts: de_novo_fallback; project_plan Key Risks; executive_summary:** De Novo adds 12-18 months and USD 2-4M; clearance moves to Months 48-66 (2030-10-13 to 2032-04-13); 510(k) is the base case with clearance Months 36-48 (2029-10-13 to 2030-10-13).
- **pitch (Risks and Mitigation Strategies):** "Regulatory delay: 510(k) pathway adds 12-18 months; De Novo adds 24+ months."
- **Why it conflicts:** The pitch attaches the De Novo delay to the 510(k) pathway (the base case that defines the Months 36-48 = 2029-10-13 to 2030-10-13 timeline) and doubles the De Novo delay. Investors would read a different timeline and funding need than the plan's own.
- **Suggested resolution:** Correct to 'De Novo adds 12-18 months and USD 2-4M (estimate); 510(k) is the base case with clearance in Months 36-48 (2029-10-13 to 2030-10-13)'.

### 5. De Novo contingency Series B: additional or baseline, sized how, locked when (🔴 High) — needs a project decision

- **canonical_facts: equity_tranche_schedule, de_novo_fallback:** Series B USD 3-5M sits in the baseline tranche schedule (Months 18-24 = 2028-04-13 to 2028-10-13); De Novo needs Series B sizing for +12-18 months runway (not yet sized).
- **executive_summary (Timeline, Risks, Action Orientation); review_plan Reviews 3, 9, 11; self_audit 2, 6, 14:** "Series B USD 3-5M = USD 12-18M committed (open decision on De Novo contingency USD 3-5M expansion)"; contingency locked at "Month 2 (2026-12-13) board vote" and also "locked by Month 6 (2027-04-13) Pre-Submission feedback"; self-audit: escrow "at Series A close"; review: "Series B expanded USD 3-5M for Months 18-30 (2028-04-13 to 2029-04-13)".
- **Why it conflicts:** It is unclear whether USD 3-5M is the baseline Series B, an addition to it, or the same money counted twice. The lock date is Month 2 (2026-12-13) (before De Novo can be known) in one place and Month 6 (2027-04-13) in another. USD 3-5M is below the 12-18 month extension implied by the USD 3.75-7.5M/yr burn proxy plus USD 2-4M extra cost. 'Committed' presents an unsecured, gate-linked tranche as fact.
- **Suggested resolution:** A project decision is needed. Options: (a) pre-commit an escrowed expansion at Series A close; (b) conditional commitment triggered by written Month 6-7 (2027-04-13 to 2027-05-13) FDA feedback; (c) no pre-commitment, and the Month 15 (2028-01-13) stop rule applies. Whichever is chosen, state whether it adds to the baseline Series B, size it against +12-18 months of burn, and replace 'committed' with 'proposed'.

### 6. De Novo funding-gap figures (🟡 Medium)

- **canonical_facts: funding_gap_after_month_24, de_novo_fallback:** Gap after Month 24 (2028-10-13) is up to about USD 17M; under De Novo it rises to up to about USD 21M; total equity need about USD 15-33M.
- **executive_summary Risk 2; review_plan Reviews 1, 2, 11:** "funding gap rises USD 5-10M after Month 24 (2028-10-13)" (exec); "funding need rises to USD 21M total (versus USD 15-30M baseline), creating a USD 5-10M gap" (Review 1); "Series B/C funding gap of USD 13-29M" (Review 2).
- **Why it conflicts:** 17 to 21 is an increase of about USD 4M, not USD 5-10M. A 'total need of USD 21M' lies inside the USD 15-30M baseline, so it cannot be a rise. USD 13-29M subtracts only USD 1-2M non-dilutive funding from burn and ignores equity tranches, contradicting the USD 17M gap.
- **Suggested resolution:** Use the canonical figures: gap up to about USD 17M (baseline) and up to about USD 21M under De Novo; total equity need about USD 15-33M. Delete the USD 5-10M and USD 13-29M figures.

### 7. Fallback floor: Cluster 1 size and narrow-menu 'V1B' (🟡 Medium) — needs a project decision

- **canonical_facts: cartridge_cluster_size, fallback_panel_v1; project_plan:** Cluster = 10-15 analytes per cartridge; Fallback V1 = 50-analyte pre-registered core (4-5 cartridges); retreat range 50-100 analytes.
- **review_plan Reviews 1, 4, 5, 11; executive_summary Risks and Feedback; self_audit 7, 8; premortem FM1, FM3; pitch Overview and Long-term Vision:** "Cluster 1: 50 analytes as 4-5 cartridges"; "narrow Cluster 1 from 50 to 20-30 analytes"; Fallback V1B "25-35 analytes" (exec, Review 4) vs "20-30" (Reviews 1, 5, self-audit 7, FM1); exec: "3-5 clusters" to reach the menu; pitch: 10-15-analyte clusters yet "second and third clusters" = 100-150 tests.
- **Why it conflicts:** 'Cluster' means a 10-15-analyte cartridge in some places and a 50-analyte block in others. The new V1B (20-35 analytes) sits below the canonical retreat range of 50-100 and below the 'guaranteed' V1 product, and its size is stated three ways. The '3 clusters' public-claim rule and the 'per-cluster 510(k)' unit therefore have no single meaning.
- **Suggested resolution:** A decision is needed on (a) the regulatory and claim unit (10-15-analyte cartridge or 50-analyte block) and (b) whether a floor below 50 analytes exists at all. If V1B is kept, define it once (size, COGS, staffing cuts), record it as a departure from the 50-100 retreat range, and fix all documents to one range.

### 8. Pharma/grant timing, run-rate and lean-pivot month (🟡 Medium)

- **canonical_facts: pharma_contract_timing, first_pharma_contract_value, lean_pivot_trigger, nondilutive_and_contract_funding:** 2-3 feasibility partnerships by Month 6 (2027-04-13) (unfunded); first paid contract by Month 9 (2027-07-13) (USD 50-100k, Months 10-15 = 2027-08-13 to 2028-01-13); no >USD 100k/month before Month 18 (2028-04-13); lean-pivot trigger at Month 18 (2028-04-13); USD 1-2M non-dilutive/contract funding cumulative over Months 0-24 (2026-10-13 to 2028-10-13).
- **self_audit 10; review_plan Reviews 2, 5, 9, 10; executive_summary Key Deliverables; pitch Call to Action:** ">=2 feasibility agreements with SOW and USD 50-100k commitment by Month 6 (2027-04-13)"; pharma/grant revenue "USD 50-200k/month Months 10-24 (2027-08-13 to 2028-10-13)"; lean-pivot "assessed" at Month 12 (2027-10-13) on run-rate <USD 100k/month; "USD 1-2M SBIR/STTR grants by Month 4 (2027-02-13)"; pitch: 2-3 month feasibility study beginning Month 6 (2027-04-13).
- **Why it conflicts:** Paid commitments by Month 6 (2027-04-13) contradict 'unfunded' partnerships at Month 6 (2027-04-13). A USD 50-200k/month run-rate over Months 10-24 (2027-08-13 to 2028-10-13) contradicts a single USD 50-100k contract and the USD 1-2M two-year total. A Month 12 (2027-10-13) test against USD 100k/month would fire by design, since no such run-rate is expected before Month 18 (2028-04-13). USD 1-2M of SBIR by Month 4 (2027-02-13) would consume the whole 24-month non-dilutive target.
- **Suggested resolution:** Align to the canonical sequence: unfunded partnerships Month 6 (2027-04-13), first paid contract Month 9 (2027-07-13) (commitments targeted by Month 12 = 2027-10-13), lean-pivot test only at Month 18 (2028-04-13), USD 1-2M cumulative non-dilutive over Months 0-24 (2026-10-13 to 2028-10-13) with SBIR applications by Month 4-5 (2027-02-13 to 2027-03-13).

### 9. Seed shortfall understated and Seed/tranches described as 'committed' (🟡 Medium) — needs a project decision

- **canonical_facts: seed_period_commitments_vs_seed, equity_tranche_schedule:** Months 0-6 (2026-10-13 to 2027-04-13) non-payroll commitments of USD 2.0-3.6M vs Seed USD 2-3M; decision needed on Seed sizing or A1 timing; equity tranches are proposed thresholds.
- **executive_summary (Purpose, Timeline); review_plan Reviews 1, 11:** Exec: Seed sizing resolves a "USD 0.6-1.6M funding gap" and Seed + A + Series B = "USD 12-18M committed"; Review 1 itself says the gap leaves "payroll and operational runway unresolved".
- **Why it conflicts:** The USD 0.6-1.6M gap compares Seed with non-payroll items only, while the plan hires leadership at Month 1 and 25-35 staff by Month 12 (2027-10-13), so the true Months 0-6 (2026-10-13 to 2027-04-13) gap is larger and unquantified. 'Committed' presents proposed, gate-linked, unsigned tranches as fact.
- **Suggested resolution:** A decision is needed: Seed enlarged to USD 4-5M, Seed USD 3M plus A1 escrow, or deferred Newark Phase 1 with SBIR targets. Quantify the payroll element and relabel the funding total as 'proposed' until term sheets exist.

### 10. Pre-clearance revenue: CLIA lab service vs 'no product revenue before clearance' (🟡 Medium)

- **canonical_facts: revenue_timeline, clia_lab_fallback:** No product revenue before clearance; pre-clearance income only pharma/grant; CLIA route prepared and staffed by Month 12 (2027-10-13) with cost not quantified and revenue unestimated.
- **review_plan Review 10; premortem A7 / FM8; pitch (Project Overview):** CLIA route forfeits "an estimated USD 50-200k/month early revenue window (Months 12-24 = 2027-10-13 to 2028-10-13)" and "USD 3-5M" burn; premortem A7: lab service "can launch by Month 12 (2027-10-13)"; pitch: "each cluster independently cleared by FDA before launch".
- **Why it conflicts:** A revenue and cost estimate is given for a route the canonical facts say is unquantified, and it contradicts the 'pharma/grant only' rule. 'Prepared by Month 12 (2027-10-13)' (canonical) differs from 'launch by Month 12 (2027-10-13)' (premortem). The pitch's 'cleared before launch' ignores the lab-service route that the plan treats as a fallback.
- **Suggested resolution:** Remove the USD 50-200k/month and USD 3-5M figures until a CLIA cost and revenue model exists (due by Month 6 = 2027-04-13 per FM8). Say 'prepared and staffed by Month 12 (2027-10-13)' and qualify the pitch sentence to device sales.

### 11. Newark equipment and Phase 2 timing in self-audit and premortem (🟡 Medium)

- **canonical_facts: long_lead_equipment_rule, newark_phase1_capex, newark_phase2_capex:** Quotes by Month 3 (2027-01-13); cancellable deposits only after Month 12 (2027-10-13) gate; binding orders only at Month 18 (2028-04-13) release; lead time 6-12 months; Phase 2 USD 2-3M released at Month 18 (2028-04-13); Phase 1 USD 500-800k.
- **self_audit 5, 16, 17; premortem A9 vs FM7:** Phase 2 filling line "Months 12-15 (2027-10-13 to 2028-01-13)"; "escalate ordering to Month 4 (2027-02-13)" / "order long-lead items by Month 4 (2027-02-13)"; NO-GO if lead time "exceeds 10 weeks" / "12 weeks"; NO-GO at "USD 600k (15% above Phase 1 budget)"; premortem FM7: permit approval due "Month 7 (2027-05-13)" although Phase 1 is operational by Month 6 (2027-04-13).
- **Why it conflicts:** Orders at Month 4 (2027-02-13) and Phase 2 at Months 12-15 (2027-10-13 to 2028-01-13) follow the superseded assumption and contradict the Month 18 (2028-04-13) release. A 10-12 week NO-GO threshold against a 6-12 month lead time would trip immediately. USD 600k lies inside the USD 500-800k Phase 1 range, so the NO-GO would fire within budget; FM7's 120% of budget (about USD 600-960k) is a different threshold. A Month 7 (2027-05-13) permit cannot precede a Month 6 (2027-04-13) operational date.
- **Suggested resolution:** Restate to the canonical rule (binding orders only at Month 18 = 2028-04-13; Phase 2 at Month 18 = 2028-04-13). Use one overrun trigger (>120% of USD 500-800k) and a lead-time threshold in months (>12). Move the permit tripwire to no later than Month 5 (2027-03-13), or move the Phase 1 operational date.

### 12. Pitch headline and menu pace vs claim rule (🟡 Medium)

- **canonical_facts: public_claim_rule, menu_500_timing; project_plan; assumptions Risk 2:** No '500 tests' marketing until >=3 clusters are independently validated and published; '500 per drop' never used; 500 analytes not committed within Months 0-72 (2026-10-13 to 2032-10-13) (estimated Months 90-129 = 2034-04-13 to 2037-07-13 if 10 blocks of 50 clear sequentially).
- **pitch (title; Long-term Vision) vs pitch Ethical Considerations:** Title "One Drop. 500 Answers. From Newark."; Long-term vision: 100-150 tests with second and third clusters cleared by Month 48 and 250-400 validated analytes by Months 48-72 (2030-10-13 to 2032-10-13).
- **Why it conflicts:** The pitch breaks the claim rule in its own title, while its Ethical Considerations section repeats the rule. Three cleared clusters by Month 48 and 250-400 analytes by Month 72 (2032-10-13) outrun the canonical pace (first clearance Months 36-48 = 2029-10-13 to 2030-10-13, 500 only at Months 90-129 = 2034-04-13 to 2037-07-13).
- **Suggested resolution:** Retitle without '500' or 'one drop... 500'. Align the expansion pace to the canonical sequential-block estimate, and describe 100-150 analytes as upside, not plan.

## Summary

The plan's architecture is largely coherent: gates at Months 6, 12 and 18 (2027-04-13, 2027-10-13, 2028-04-13), the 50-analyte Fallback V1 and the staged Newark capex agree in the project plan, premortem and canonical facts. Inconsistencies cluster in the review, self-audit and pitch, which repeat superseded or invented thresholds: margin and fallback-trigger rules, De Novo funding figures, pharma timing, equipment and Phase 2 timing, and a 'per run' vs 'per panel' revenue unit. Two of these are genuine missing decisions that gate capital: the pricing unit that underlies the 'unit economics broken' claim, and the De Novo Series B contingency (size, additional vs baseline, lock date). Most other items are repairable by restating canonical values.