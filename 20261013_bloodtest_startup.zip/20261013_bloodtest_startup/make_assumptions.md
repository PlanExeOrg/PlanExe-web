
## Question 1 - What total capital and staged tranche structure (venture, pharma contracts, grants) is available to fund development through first clearance and the Newark build-out?

**Assumptions:** Assumption: Cumulative burn through clearance is about USD 15-30 million (estimate, per IVD startup benchmarks), funded by a seed/Series A of USD 8-12 million (proposed), pharma contracts and USD 1-2 million in grants over Months 0-24 (2026-10-13 to 2028-10-13). Tranches are tied to technical gates, not calendar.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluates runway adequacy against a capital-intensive, pre-revenue path.
Details: Main risk is a funding gap at Months 18-24 (2028-04-13 to 2028-10-13) if pharma revenue lags; dilution of USD 5-15 million (estimate) in a down round. Mitigate with a 60-month cash model, gate-linked tranches, a 20% equipment contingency, and a lean-pivot trigger if pharma revenue stays below USD 100 k/month by Month 18 (2028-04-13). Opportunity: non-dilutive SBIR/STTR funds cut dilution.

## Question 2 - What are the target dates for analytical feasibility, design freeze, Newark fit-out, clinical studies and first clearance, and who owns the gate decisions?

**Assumptions:** Assumption: Pre-Submission meeting Months 3-6 (2027-01-13 to 2027-04-13); analytical feasibility gate Month 12 (2027-10-13); lead-cluster design freeze Months 15-18 (2028-01-13 to 2028-04-13); Newark filling-line fit-out Months 12-15 (2027-10-13 to 2028-01-13) after the gate; ISO 13485 by Month 18 (2028-04-13); first 510(k)/De Novo submission Months 30-36 (2029-04-13 to 2029-10-13); clearance Months 36-48 (2029-10-13 to 2030-10-13) (all proposed). Board owns gate votes.

**Assessments:** Title: Schedule Feasibility Assessment
Description: Tests whether milestones are realistic and sequenced against risk.
Details: Critical path runs through assay feasibility, design freeze and equipment lead times of 6-12 months (estimate). Slips of 6-12 months are plausible if yield falls below 80%. Mitigate by ordering long-lead equipment early, running parallel CLIA-lab revenue prep by Month 12 (2027-10-13), and holding gates at Months 6, 12 and 18 (2027-04-13, 2027-10-13, 2028-04-13). Gate-based capital release limits sunk cost.

## Question 3 - Which core roles must be hired first, how many staff are needed by Month 12 (2027-10-13) and Month 24 (2028-10-13), and what is the split between in-house and contract capacity?

**Assumptions:** Assumption: Month 1 (2026-11-13) hires are an R&D director and a quality/regulatory lead with 10+ years in IVD. Headcount is about 25-35 by Month 12 and 50-70 by Month 24 (2028-10-13) (estimate). Molding, instrument assembly and clinical operations are contracted; Newark staffs reagent formulation and filling. Bay Area compensation is at market.

**Assessments:** Title: Talent and Resource Assessment
Description: Reviews availability and cost of scarce skills in the Bay Area.
Details: Microfluidics, assay chemistry and quality talent are competed for; turnover above 20% could cost USD 200-400 k/year (estimate). Key-person loss at design freeze could cost 2-3 months. Mitigate with equity vesting tied to gates, early quality hires, academic partnerships and a USD 300-500 k/year recruiting budget (estimate). Opportunity: Fremont/Hayward talent pool near Newark.

## Question 4 - Which regulatory pathway governs the first product (CLIA service, staged 510(k)/De Novo), and what quality system, permits and IP clearances are required?

**Assumptions:** Assumption: Staged per-cluster 510(k)/De Novo submissions are the main route, starting with an initial cluster of well-characterized assays. A CLIA lab-service fallback is prepared by Month 12 (2027-10-13). ISO 13485 and 21 CFR 820 controls, IEC 62304 software and a freedom-to-operate review are in place before design freeze. Newark zoning permits biological reagent handling.

**Assessments:** Title: Regulatory Compliance Assessment
Description: Assesses pathway clarity, evidence burden and governance readiness.
Details: No precedent clears a broad multiplex menu in one device; De Novo could add 12-18 months and USD 2-4 million (estimate). LDT route is viable after the 2025 rescission but may change. Mitigate with early Pre-Submission, pre-registered studies, mock FDA inspection at Months 28-30 (2029-02-13 to 2029-04-13) and a USD 1-2 million regulatory budget for Months 0-6 (2026-10-13 to 2027-04-13) (estimate). Avoid 500-test claims until clusters are validated.

## Question 5 - What are the main technical and operational failure modes (crosstalk, plasma separation, yield, reagent stability), and what thresholds trigger retreat or pause?

**Assumptions:** Assumption: Proposed thresholds: cartridge yield >80% at pilot scale (target 90%), lot-to-lot CV <10%, shelf life >=12 months, plasma separation success >95%, concordance >=95% with reference. Missing a threshold pauses Newark spend and triggers a scope-retreat review to a 50-100 analyte core.

**Assessments:** Title: Technical Risk Assessment
Description: Evaluates the likelihood and impact of core feasibility failures.
Details: Analytical feasibility, over-claiming and cross-reactivity are rated high likelihood. A late pivot could strand USD 2-10 million (estimate). Mitigate by validating clusters of 5-10 analytes independently, dual-sourcing critical reagents, DFM review with a molder before fit-out, and cold-chain plans by Month 12 (2027-10-13). Pre-set gates guard against sunk-cost escalation and quiet mission drift.

## Question 6 - What environmental, health and waste obligations arise from blood handling, reagent formulation, plastics and cold-chain shipping at the Newark site?

**Assumptions:** Assumption: Facility operates at BSL-2 with biohazard and sharps waste contracts, Bay Area air-quality and wastewater permits, chemical inventories under California rules, and a small footprint (2,000-3,000 sq ft initially, proposed). Single-use plastic cartridges and cold-chain packaging are the main footprint; no major emissions sources.

**Assessments:** Title: Environmental Impact Assessment
Description: Reviews permitting, waste and sustainability exposure.
Details: Impact is moderate and manageable: biohazard waste, solvents and antibody reagents, disposable plastics and refrigerated shipping. Risks are permit delays and added cold-chain cost of USD 10-20 per cartridge (estimate). Mitigate with early permit scoping, licensed medical-waste vendor, recyclable or reduced-material cartridge design, and consolidated shipping. Opportunity: lower-mass cartridges also cut cost of goods.

## Question 7 - Which stakeholders (investors, pharma sponsors, FDA, clinical sites, payers, suppliers, city of Newark) must be engaged, and when?

**Assumptions:** Assumption: Engagement order: pharma sponsors and grant agencies from Month 0 (2026-10-13); FDA Pre-Submission Months 3-6 (2027-01-13 to 2027-04-13); academic clinical partner Months 3-6 (2027-01-13 to 2027-04-13); payer discussions by Month 6 (2027-04-13); contract molders and reagent suppliers qualified by Month 6 (2027-04-13); external scientific advisory board with data audit access from Month 1 (2026-11-13).

**Assessments:** Title: Stakeholder Engagement Assessment
Description: Maps influence and alignment of parties critical to funding, evidence and adoption.
Details: Credibility is the key asset given past failed single-drop claims. Transparent, published validation and an advisory board reduce reputational risk (valuation writedown 20-50%, estimate). Partner exclusivity and pharma delays are risks. Mitigate via a communications plan avoiding unsupported claims, signed pharma contracts of USD 1-2 million before Month 6 (2027-04-13) (proposed), and quarterly investor updates tied to gates.

## Question 8 - What operational systems (quality management, LIMS, lot release, supply chain, software, cold chain) must be running at Newark and by when?

**Assumptions:** Assumption: Electronic QMS and document control live by Month 6 (2027-04-13); LIMS and lot-release SOPs by Month 12 (2027-10-13); ERP and supplier scorecards by Month 12 (2027-10-13); IEC 62304 software lifecycle from Month 3 (2027-01-13); cold-chain logistics partner contracted by Month 12 (2027-10-13); operator model starts with trained-staff lab placements.

**Assessments:** Title: Operational Systems Assessment
Description: Assesses readiness of the systems supporting compliant manufacturing and delivery.
Details: Gaps in design controls, complaint handling or lot traceability can trigger FDA 483 findings, adding 3-6 months and USD 500 k-1 million (estimate). Mitigate by building the QMS before pilot lots, an internal ISO 13485 audit by Month 6 (2027-04-13), and USD 300-500 k for quality build-out (estimate). Dual suppliers and 90-day capacity commitments reduce halt risk. Opportunity: early systems ease partner due diligence.