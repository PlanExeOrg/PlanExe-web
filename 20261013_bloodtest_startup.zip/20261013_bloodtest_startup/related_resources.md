## Suggestion 1 - Theranos Edison / Newark lab (cautionary precedent)

Bay Area startup claiming hundreds of tests from a fingerstick drop; operated a lab and device-development site in Newark, California. Collapsed around 2016-2018 after CMS/CLIA sanctions and fraud convictions of its founders. Documented in court records, CMS letters and journalism.

### Success Metrics

Not a success: tests ran on third-party analyzers; claims not validated
Outcome: CLIA sanctions, lab closure, criminal convictions, company dissolved (documented)
Useful as negative benchmark for evidence transparency and peer review

### Risks and Challenges Faced

Over-claiming before validation: avoid by public claim rule and pre-registered studies
Sample volume physics: model drop budget (about 8-16 analytes per drop, estimate) early
Closed data and no independent audit: mitigate with advisory board holding raw-data access
Regulatory shortcuts via LDT route: plan CLIA and FDA evidence in parallel

### Where to Find More Information

Court records and CMS CLIA inspection reports (public, search CMS and PACER)
Journalism and the book 'Bad Blood' by John Carreyrou (WSJ coverage)
FDA and CMS public statements on Theranos

### Actionable Steps

Review CMS CLIA inspection documents for Newark lab findings to build a QMS checklist
Interview former Bay Area IVD staff via LinkedIn about lessons for quality culture
Consult a regulatory attorney about public-claim review process

### Rationale for Suggestion

Same city, same headline claim. Directly informs credibility-first communication, evidence gates and the 'no 500 tests' claim rule. Included as a cautionary reference because validated geographic peers are few.
## Suggestion 2 - Abbott i-STAT cartridge platform (Abbott Point of Care)

Handheld analyzer with single-use cartridges running blood chemistry, blood gases, cardiac markers and coagulation panels from a few drops of whole blood. Developed from the 1980s, cleared by FDA via many staged per-cartridge 510(k)s and CLIA-waived categories. Manufactured in Ottawa/Canada and US sites.

### Success Metrics

Dozens of cartridge types cleared over decades (approximate, not verified)
Widely deployed in hospitals, EMS and clinics worldwide
Demonstrates cumulative menu via successive clearances

### Risks and Challenges Faced

Cartridge reagent stability: addressed with cold-chain and room-temperature shelf-life options per cartridge
Per-cartridge regulatory burden: managed through modular 510(k) sequence
Sample volume limits: each cartridge serves a small analyte cluster, not hundreds

### Where to Find More Information

Abbott Point of Care website (globalpointofcare.abbott)
FDA 510(k) database entries for i-STAT cartridges (accessdata.fda.gov)

### Actionable Steps

Pull i-STAT 510(k) summaries from FDA database to model per-cluster evidence packages
Contact Abbott Point of Care business development via corporate site for partnership or licensing discussion
Consult former i-STAT regulatory staff via LinkedIn as advisors

### Rationale for Suggestion

Closest validated analogue to modular cartridge family with staged 510(k) clearance. Distant geographically, but shows the cumulative-menu model works at small cluster sizes.
## Suggestion 3 - Cepheid GeneXpert cartridge manufacturing (Sunnyvale / Bay Area origin)

Cepheid, founded in the Bay Area, built self-contained fluidic cartridges with on-board reagent storage and a modular instrument, scaling mass cartridge production and reagent filling in-house. Acquired by Danaher in 2016. Menu grew through successive FDA clearances.

### Success Metrics

Large installed base and high cartridge volumes (figures not verified)
Multi-assay menu cleared incrementally
Acquisition by Danaher for about USD 4B reported (approximate)

### Risks and Challenges Faced

Cartridge yield at scale: solved with automated filling and in-process QC
Reagent lyophilization stability: engineered dry reagent beads
Capital intensity: financed via IPO and staged growth

### Where to Find More Information

Cepheid corporate website (cepheid.com)
Danaher acquisition press release and SEC filings
FDA 510(k) database

### Actionable Steps

Approach Cepheid alumni in Sunnyvale/Bay Area via LinkedIn for manufacturing process advisors
Request facility benchmarking discussions via Cepheid corporate contact
Review SEC filings for capex and cartridge cost structure

### Rationale for Suggestion

Bay Area cartridge manufacturing precedent with in-house reagent filling, matching the Newark filling-site strategy and talent pool.
## Suggestion 4 - Olink / Quanterix multiplex pharma-funded biomarker model (secondary suggestion)

Secondary suggestion. Olink (Sweden, acquired by Thermo Fisher) and Quanterix (Massachusetts) built multiplex proteomics and ultrasensitive immunoassay platforms funded largely by research and pharma customers before any clinical diagnostic claims.

### Success Metrics

Revenue from research and pharma customers (figures not verified)
Large published datasets in peer-reviewed literature

### Risks and Challenges Faced

Research-use-only versus clinical claims: kept separate
Cross-reactivity in multiplex: addressed by proximity-extension design and validation publications

### Where to Find More Information

olink.com
quanterix.com
Thermo Fisher acquisition announcement

### Actionable Steps

Contact Quanterix or Olink business development to learn about pharma contracting
Review published validation papers for cross-reactivity criteria

### Rationale for Suggestion

Validates the pharma/research beachhead funding path; geographically distant and uses larger sample volumes than a single drop.

## Summary

Reference projects for a modular fingerstick multiplex diagnostics startup with Newark, California manufacturing. Theranos (Newark, CA) is the cautionary precedent for over-claiming single-drop testing. Positive references: Cepheid-style cartridge manufacturing in the Bay Area, Abbott i-STAT (cartridge-based fingerstick/whole-blood testing, staged clearances), and Olink/Quanterix multiplex platforms for pharma-funded evidence. Geographically close examples are limited for validated multiplex single-drop devices; distant examples are justified on technology and business model. Figures below are approximate or unverified; contact details are named as organizations or roles, not individuals.