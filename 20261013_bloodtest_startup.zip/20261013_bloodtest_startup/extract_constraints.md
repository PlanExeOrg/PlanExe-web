## Positive Constraints

- Build a startup that can run 500 complex health tests from a single drop of blood
- Mass production of blood-testing devices located in Newark, California
- Project start ASAP (Month 0 = 2026-10-13)
