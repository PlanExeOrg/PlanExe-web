**Purpose:** business

**Purpose Detailed:** Commercial venture: founding a medical diagnostics startup, developing a multiplex blood-testing device and setting up mass manufacturing in Newark, California, with the aim of generating revenue and profit from the product.

**Topic:** Startup developing a blood-testing device that runs 500 complex health tests from a single drop of blood, with mass production in Newark, California