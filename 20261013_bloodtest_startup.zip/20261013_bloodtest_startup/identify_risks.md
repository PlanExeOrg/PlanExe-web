
## Risk 1 - Technical—Analytical Feasibility
The core claim of 500 complex tests from a single drop of blood is not shown to be physically feasible at clinical-grade accuracy. The strategy document explicitly states that 'no option makes all 500 analytes simultaneously physically feasible at clinical-grade accuracy.' Cross-reactivity between assay chemistries, reagent stability in a micro-volume sample, and cartridge manufacturing yield are the primary failure modes. A monolithic cartridge with hundreds of chambers and reagents risks a single failure in any chamber cascading to the entire result.

**Impact:** If the 500-test claim is not technically achievable, the company may be forced to retreat to a much narrower panel (e.g., 50–100 analytes) after months or years of development and significant capital spend. This redefines the business case, reducing addressable market and per-cartridge revenue, and may trigger loss of investor confidence, delayed or failed funding rounds, and months to years of redesign. Financial impact: USD 2–10 million in sunk R&D if pivot occurs at Month 18–24 (2028-04-13 to 2028-10-13); valuation writedown of 50–80% if retreat is announced.

**Likelihood:** High

**Severity:** High

**Action:** Define analyte clusters (e.g., 5–10 analytes per cartridge) and validate each cluster independently via pre-registered, blinded method-comparison studies against reference methods by Month 6–9 (2027-04-13 to 2027-07-13). Lock each cluster to the menu only after it meets pre-set accuracy and precision thresholds (e.g., ≥95% concordance with reference). Use feasibility gates (Month 6, 12, 18 = 2027-04-13, 2027-10-13, 2028-04-13) to decide whether to add clusters or retreat to a sellable 50–100 analyte core. Avoid public 500-test claims until at least three clusters are independently validated.

## Risk 2 - Regulatory—Over-Claiming and Credibility Loss
The headline '500 tests per drop' is marketing language, not a regulatory claim. If the company market this as a feature before evidence supports it, FDA may challenge the claim, and clinicians and payers may reject the product as over-claimed once early real-world results show a narrower panel or lower analyte count. This risk is amplified because earlier single-drop diagnostics companies (including some in the Newark, California area—not verified) have made and failed to deliver on similar claims, creating skepticism in the market.

**Impact:** FDA warning letter or enforcement action for unsubstantiated claims, requiring a costly corrective submission and halting commercial activity for 2–6 months. Clinician and payer distrust, leading to slow adoption even if the product is cleared. Market repositioning and rebranding campaign, costing USD 500 k–2 million. Valuation impact: 30–50% writedown if credibility is lost. Time-to-market delay: add 4–8 months.

**Likelihood:** High

**Severity:** High

**Action:** Adopt a staged disclosure strategy: (1) Internally, commit to an Evidence Generation and Transparency plan with pre-registered study designs and a public failure log. (2) Pre-register analyte-by-analyte accuracy targets and publish results cluster-by-cluster as they complete validation. (3) Market the cumulative menu ('up to 500 tests' or 'a family of multiplex panels totaling 500 analytes') only after at least 3 clusters are independently published. (4) Appoint an external scientific advisory board with audit rights to raw data and failure logs; publish analyte-level performance quarterly, including failures. (5) Avoid internal communication or investor pitches claiming 500 simultaneous tests on one drop.

## Risk 3 - Financial—Newark Capital Commitment Misaligned with Design Maturity
The plan names Newark, California as the mass-manufacturing site and commits to establishing a cleanroom and cartridge-filling facility. The strategic decision on Newark build-out timing is complex: starting early locks fixed capital around an unfrozen design (risking cost overruns and stranded capital if design changes), while starting late risks discovering at production scale that yield or reagent stability cannot be achieved (forcing redesign or market repositioning). The risk is that capital is committed before the cartridge design, reagent performance, and process parameters are locked.

**Impact:** If Newark is built out at Month 3–6 (2027-01-13 to 2027-04-13) (early) before the cartridge is frozen, unforeseen design changes (e.g., adding or removing assay chemistries to address crosstalk) could render equipment obsolete or require expensive re-tooling. Estimated sunk cost: USD 1–3 million. If Newark is built out at Month 18–24 (2028-04-13 to 2028-10-13) (late), the company may discover at pilot scale that cartridge yield is <80% or that reagent stability fails at 12-month shelf life, forcing a redesign and adding 6–12 months to the timeline. Financial impact: USD 500 k–2 million in rework, plus delay in revenue start.

**Likelihood:** Medium

**Severity:** High

**Action:** Stage Newark investment in two tranches: (1) Months 3–6 (2027-01-13 to 2027-04-13): lease a small space (e.g., 2,000–3,000 sq ft) and set up a limited reagent formulation and lot-release lab (not full cartridge filling). Focus on pilot batches and stability testing. Capital: USD 500–800 k. (2) Months 12–15 (2027-10-13 to 2028-01-13): complete analytical feasibility gates and design freeze on the lead cartridge cluster. Only then fit out the full pilot cartridge-filling line. Capital: USD 2–4 million. Link each tranche to pre-agreed technical gates (yield >80%, shelf-life >12 months, lot-to-lot CV <10%), not to schedule. If gates are missed, pause Newark investment and redeploy capital to R&D or market pivot.

## Risk 4 - Regulatory—FDA Regulatory Pathway Uncertainty
The FDA's regulatory landscape for in vitro diagnostics changed rapidly: the LDT rule was vacated and rescinded in September 2025 (verified), restoring enforcement discretion. A CLIA lab-service route is currently viable but could change if Congress or FDA acts again. Separately, the 510(k) or De Novo pathway for a multiplex device that claims 500 analytes is untested; FDA has not yet cleared such a broad menu in a single cartridge. Pre-Submission meetings can help align on evidence, but FDA feedback is not binding and can shift.

**Impact:** If the CLIA route is blocked by a new FDA rule or enforcement action, the company may be forced into a more rigorous device-approval pathway, requiring 2–4 additional years and USD 3–7 million in clinical studies. If the 510(k) pathway for 500 analytes is rejected by FDA in a Pre-Submission meeting and a De Novo is required instead, add 12–18 months and USD 2–4 million in evidence generation. Alternatively, FDA may require a staged, per-analyte or per-cluster clearance strategy, which extends time-to-market but reduces risk of a single rejection.

**Likelihood:** Medium

**Severity:** High

**Action:** Conduct early FDA Pre-Submission meetings (Month 3–6 = 2027-01-13 to 2027-04-13) to clarify the regulatory path for a multiplex 500-analyte device. Present a modular cartridge strategy (e.g., initial 50-analyte cluster for 510(k), with a plan to expand through successive submissions) as the likely path. Request feedback on evidence requirements and study design early. Maintain a fallback CLIA-lab service route in parallel, approved and staffed by Month 12 (2027-10-13), so revenue can start via that path while device clearance proceeds. Allocate USD 1–2 million for Pre-Submission meetings, freedom-to-operate review, and regulatory consulting in Months 0–6 (2026-10-13 to 2027-04-13).

## Risk 5 - Technical—Reagent Supply and Lot Consistency
Each analyte in the multiplex panel depends on an antibody, aptamer, enzyme, or other capture reagent whose performance varies between supplier lots and suppliers. A single supplier discontinuation, quality failure, or price increase can block cartridge production. If the company outsources reagent sourcing (the lowest-capital option), it has limited control over lot-to-lot variability and may face unexpected re-validation costs if a supplier changes manufacturing processes.

**Impact:** A supplier discontinuation of a critical antibody could force a 2–8 week production halt and USD 200–500 k in re-qualification and re-validation of a new supplier. If lot-to-lot variability exceeds tolerance (e.g., CV >15% instead of <10%), the company may have to reject 20–40% of production lots, raising cost of goods by 30–50%. Shelf-life failure due to reagent degradation could require shortening the claimed shelf life from 12 to 6 months, cutting inventory turns and raising logistics costs by 10–15%.

**Likelihood:** Medium

**Severity:** Medium

**Action:** By Month 6 (2027-04-13), conduct a critical-reagent supply-chain assessment and identify dual suppliers for the top 10 analytes. Qualify at least two suppliers per critical reagent (antibodies, probes, enzymes). Lock suppliers in binding quality agreements specifying lot-release criteria (potency assay, endotoxin, sterility), stability testing protocols (accelerated and real-time shelf-life), and price-lock periods (e.g., 3 years). Establish an in-house reagent-lot release program in the Newark facility, with training and SOPs by Month 12 (2027-10-13). If a supplier discontinues a reagent, activate the dual supplier within 4–6 weeks and conduct a mini re-validation (4–8 weeks) before releasing cartridge lots.

## Risk 6 - Operational—Cartridge Manufacturing Yield and Scalability
Transitioning from hand-assembled research prototypes to pilot-scale cartridge production is a notorious challenge in microfluidics and diagnostics. Yield (the fraction of cartridges passing all quality checks) often falls sharply when the design moves from a single-skilled technician to semi-automated or automated lines. Common failure modes are injection-molding defects (warping, sink marks), fluidic bonding failures (delamination, channel misalignment), and reagent-filling variability (bubble entrapment, incomplete fill).

**Impact:** If initial Newark pilot-scale yield is <70% instead of the target >90%, the cost of goods per passing cartridge rises by 25–40%, threatening unit economics and forcing a redesign cycle. This could add 6–12 months to the timeline and USD 1–3 million in re-work. High scrap rates also delay the accumulation of real-world data from clinical studies, pushing back evidence generation by 3–6 months.

**Likelihood:** High

**Severity:** Medium

**Action:** Before Newark fit-out (Month 6 = 2027-04-13), conduct a manufacturing feasibility and design-for-manufacturability (DFM) review with an experienced contract molding and assembly partner. Identify yield-limiting steps (molding, bonding, filling) and specify tolerance and rejection criteria for each. Build a detailed yield model (target ≥90% end-to-end by Month 12 = 2027-10-13). Establish a pilot production run at the contract manufacturer or a shared facility (e.g., in Fremont or Hayward) at Month 9–12 (2027-07-13 to 2027-10-13) to validate yield before Newark fit-out. If yield falls below 80% at pilot scale, pause Newark build-out and conduct a design review; only proceed after yield is restored to ≥85% at scale.

## Risk 7 - Financial—Funding Runway and Capital Intensity
The project requires multi-year development (analytical feasibility by Month 12 = 2027-10-13, design freeze by Month 18–24 = 2028-04-13 to 2028-10-13, clinical studies by Month 24–36 = 2028-10-13 to 2029-10-13, regulatory clearance by Month 36–48 = 2029-10-13 to 2030-10-13) before significant revenue. Estimated cumulative cash burn is USD 15–30 million (not verified; based on typical IVD startup benchmarks). The strategy recommends pharma and grant funding as beachhead revenue, but pharma contracts typically require proof-of-concept (Month 9–12 = 2027-07-13 to 2027-10-13) and are subject to partner risk and delays. If pharma partners exit or reduce contracts, the company may face a funding gap and an unplanned fundraising round at an unfavorable valuation.

**Impact:** A shortfall in pharma or grant revenue at Month 18–24 (2028-04-13 to 2028-10-13) could require an emergency Series A or B round, but the valuation may be depressed if progress milestones are not met (e.g., if only 1 analyte cluster is validated instead of 3). This could result in USD 5–15 million in dilution. Alternatively, if funding is unavailable, the company may have to lay off 20–30% of staff and halt Newark build-out, adding 6–12 months of delay while seeking rescue funding or strategic partnerships.

**Likelihood:** Medium

**Severity:** High

**Action:** Build a detailed 60-month cash-flow model (Months 0–60 = 2026-10-13 to 2031-10-13) with two funding scenarios: (1) pharma-and-grant funded, and (2) venture-only funded. Assume pharma revenue ramps from USD 0 at Month 0 (2026-10-13) to USD 500 k–2 million by Month 24 (2028-10-13) and plateaus. Assume grant funding (NIH SBIR/STTR, NSF, or foundation grants) totals USD 1–2 million over Months 0–24 (2026-10-13 to 2028-10-13). Use this to size Series A and B rounds. Pre-plan a lean-operations pivot (e.g., transition to a contract-research-organization model or narrow beachhead) if pharma revenue falls below USD 100 k/month by Month 18 (2028-04-13). Lock in at least USD 1–2 million in pharma contracts or grants before Month 6 (2027-04-13) Pre-Submission work.

## Risk 8 - Operational—Talent Acquisition and Retention
The startup requires a blend of scarce skills: microfluidics engineering, assay chemistry, quality systems, regulatory affairs, and manufacturing process engineering. All are heavily competed for in the San Francisco Bay Area, driving high salary and equity expectations. Early hires will be critical to setting technical culture and passing FDA inspections, but premium compensation burns runway. High turnover in early-stage biotech can stall progress and lose institutional knowledge.

**Impact:** If a key microfluidics engineer or quality-systems lead leaves during a critical phase (e.g., at Month 12 = 2027-10-13 design freeze), the team may lose 2–3 months of progress and institutional knowledge, delaying design freeze by a quarter. If senior talent is hard to recruit at budget, the company may hire less-experienced staff and discover quality-system gaps during FDA inspections, triggering delays and rework. High turnover (>20% annual) can double the cost of recruitment and training, absorbing USD 200–400 k/year.

**Likelihood:** Medium

**Severity:** Medium

**Action:** By Month 1 (2026-11-13), recruit a senior R&D director and a quality/regulatory leader (both with 10+ years in IVD) as co-founders or early hires. Offer competitive Bay Area salaries (USD 150–200 k) and significant equity (1–3%). Develop a retention plan with clear technical milestones and equity vesting tied to feasibility gates (e.g., unlock 25% of equity at design freeze). Use remote-work flexibility and partnership with academic labs to lower costs for research staff. Plan for 10–15% annual turnover and budget USD 300–500 k/year for recruitment and onboarding.

## Risk 9 - Technical—Cross-Reactivity and Multiplexing Burden
Running hundreds of assay chemistries in parallel in a single drop of blood raises the risk of cross-reactivity: antibodies or probes binding to unintended targets, reagents interfering with each other, and false-positive or false-negative results. The larger the menu, the higher the cross-reactivity burden. A single undetected cross-reactivity (e.g., a cardiac marker antibody binding to a muscle-injury protein) could invalidate results for dozens of patients.

**Impact:** If cross-reactivity is discovered late (e.g., at Month 18 = 2028-04-13 during clinical method-comparison studies), the company may have to remove affected analytes from the menu, shrinking the panel by 10–30% and delaying launch by 4–8 months. If a cross-reactivity is missed and discovered post-launch by a payer or clinician, it triggers a recall, regulatory investigation, and USD 1–5 million in liability and remediation.

**Likelihood:** High

**Severity:** Medium

**Action:** By Month 4–6 (2027-02-13 to 2027-04-13), conduct a systematic cross-reactivity screening for each analyte pair using a high-complexity sample matrix (e.g., pooled human plasma with elevated levels of potential interferents). Use published literature and supplier data to identify high-risk pairs (e.g., cross-reactive antibodies, enzyme inhibitors). Remove or redesign high-risk analyte pairs from the initial panel, accepting a narrower but more reliable menu. Pre-register cross-reactivity success criteria (e.g., <5% bias from any single interferent at 10x physiologic levels) and publish results alongside accuracy data.

## Risk 10 - Regulatory—Clinical Study Design and Sample Size
Demonstrating clinical utility and analytical accuracy for 500 analytes through formal clinical studies is a massive undertaking. FDA typically requires method-comparison studies (comparing the new assay to a predicate or reference method) for each analyte, plus a clinical outcomes study for claims like 'diagnostic' or 'screening.' With 500 analytes, this could require 500+ independent studies or a very large multi-analyte study enrolling thousands of subjects. The statistical power and sample size required can be prohibitive.

**Impact:** If the company underestimates study scope and designs a 200-patient study when 2,000 patients are needed, the results may lack statistical power and FDA may request a larger study, adding 12–18 months and USD 2–5 million. Alternatively, the company may retreat to a narrower panel of 50–100 analytes that can be validated in a reasonable study, shrinking the addressable market.

**Likelihood:** Medium

**Severity:** Medium

**Action:** By Month 3–6 (2027-01-13 to 2027-04-13), engage an academic clinical-research partner (e.g., a university medical center or large hospital system) to design a multi-analyte clinical study. Use a tiered approach: (1) conduct method-comparison studies for the initial 50-analyte cluster using 200–300 healthy and disease-state subjects; (2) pool results across sites to gain statistical power; (3) publish cluster-level results and use them as evidence for the next 50-analyte cluster. Specify analyte-level success criteria (≥95% concordance with reference, CV <10%) in a pre-registered study protocol. Budget USD 2–4 million for clinical studies over Months 12–36 (2027-10-13 to 2029-10-13).

## Risk 11 - Reputational—Historical Precedent of Failed Single-Drop Diagnostics
Earlier diagnostics companies have made headlines with single-drop or multiplex claims and failed to deliver, creating skepticism in the market and with regulators and investors. A company operating in Newark, California (not verified) previously made similar claims. If the media or market perceives this startup as following the same pattern, it will face uphill battles with payers, clinicians, and investors, regardless of actual progress.

**Impact:** Negative media coverage or investor skepticism can slow fundraising and payer adoption. If the company is perceived as the 'next failed single-drop startup,' Series B or C funding may be harder to raise, or valuations may be depressed by 20–40%. Clinician and payer adoption may be slower despite a cleared product, adding 12–24 months to revenue ramp.

**Likelihood:** Medium

**Severity:** Medium

**Action:** From Month 0 (2026-10-13), adopt a credibility-first communications strategy: (1) avoid superlative claims about 500 tests until evidence exists; (2) commit publicly to independent, published validation (pre-registered studies with external partners); (3) acknowledge and learn from historical precedents transparently; (4) publish negative results (analytes that fail thresholds) alongside successes; (5) engage investor and clinician advisory boards early and include them in milestone planning. Build trust through evidence, not marketing.

## Risk 12 - Technical—Shelf-Life and Reagent Stability
Hundreds of reagents packed into a single cartridge, exposed to temperature fluctuations and time, may degrade unevenly, causing some analytes to drift out of specification while others remain stable. The claimed shelf life (typically 12–24 months for IVD cartridges) requires real-time and accelerated stability testing. If shelf life is shorter than claimed, the product loses competitiveness and raises logistics costs.

**Impact:** If real-time stability data at Month 12 (2027-10-13) shows shelf life is only 6 months instead of the claimed 12 months, the company must either (1) shorten the claimed shelf life and accept lower inventory efficiency and higher logistics cost, or (2) re-formulate the reagents, adding 3–6 months of work. This could delay market launch by a quarter and increase cost of goods by 10–15% due to accelerated turnover.

**Likelihood:** Medium

**Severity:** Medium

**Action:** By Month 3 (2027-01-13), establish an accelerated and real-time stability testing program for the lead analyte cluster. Test cartridges at 2–8°C (intended storage) and at elevated temperature/humidity (e.g., 40°C/75% RH) to mimic worst-case storage. Measure analyte recovery and bias monthly for 12 months in real-time and extrapolate to 24-month shelf life using statistical models (e.g., Arrhenius). Set a feasibility gate at Month 12 (2027-10-13): if shelf life is <9 months, conduct a re-formulation review and delay launch by 3 months; if shelf life is ≥12 months, proceed to clinical studies. Specify shelf-life success criteria (≤10% drift from baseline by end of claimed shelf life) in the development plan.

## Risk 13 - Operational—Contract Manufacturer Dependency
The strategy recommends outsourcing injection-molded parts and instrument assembly to established suppliers while Newark handles reagent formulation and cartridge filling. This distributes capital risk but creates dependency on contract manufacturers. A supplier capacity shortage, quality failure, or exit could halt cartridge production.

**Impact:** If a contract molder discontinues a custom mold or goes out of business, the company may face a 4–8 week production halt while qualifying a new supplier and re-validating parts. If a molder's quality drifts and cartridge defect rates spike from <5% to >20%, the company must halt production, investigate, and potentially re-qualify the entire supplier base, adding 2–4 months and USD 200–500 k. Supplier consolidation (loss of a backup supplier) could leave the company with no alternative if the primary supplier fails.

**Likelihood:** Medium

**Severity:** Medium

**Action:** By Month 6 (2027-04-13), qualify at least two contract molders and/or assembly partners with validated mold tooling and process controls. Lock in capacity and lead-time agreements (e.g., 90-day forward commitments with 2-week lead times). Specify quality requirements (defect rate <5%, first-pass yield >90%) in binding quality agreements. Establish supplier scorecard reviews monthly, tracking defect rates, delivery, and cost. If a supplier's defect rate exceeds 10%, trigger a quality investigation and activate a backup supplier within 2 weeks.

## Risk 14 - Financial—Payer Coverage and Reimbursement Uncertainty
The business case assumes reimbursement for the multiplex panel, but payers (Medicare, private insurers) typically cover individual tests with established CPT codes and may not cover a 500-analyte bundle. If payers deny or severely restrict coverage, per-run revenue could fall from the projected USD 500–1,000 to USD 100–200, making the unit economics unviable.

**Impact:** If payer coverage is restricted to 50 analytes instead of 500, per-run revenue falls by 80%, and the business must either (1) reduce the scope to match covered analytes (shrinking the differentiator), or (2) rely on self-pay or employer-funded screening (smaller market). This could cut addressable market by 60–80% and require a business pivot by Month 24–30 (2028-10-13 to 2029-04-13), adding significant time-to-profitability.

**Likelihood:** Medium

**Severity:** High

**Action:** By Month 6 (2027-04-13), conduct a payer-coverage landscape analysis. Identify existing CPT codes and coverage policies for the top 20 analytes in the initial cluster. Engage 2–3 major payers (Medicare, Aetna, Anthem) in pre-launch coverage discussions, presenting clinical utility evidence and economic models. Develop a tiered pricing and bundling strategy: (1) code for high-value, well-reimbursed analytes (e.g., lipid panel, metabolic panel) at a premium; (2) offer lower-reimbursed analytes as value-add to support adoption. Budget USD 300–500 k for payer analytics and coverage support by Month 12 (2027-10-13).

## Risk 15 - Technical—Assay Sensitivity and Detection Limit
Some analytes in a 500-test panel will have very low normal concentrations (e.g., troponin in healthy individuals, rare biomarkers). Achieving the required sensitivity (detection limit) in a micro-volume sample, while avoiding interference and cross-reactivity, is challenging. If sensitivity falls short, clinically important analytes may be unusable.

**Impact:** If the detection limit for cardiac troponin is 1 ng/L instead of the required 0.01 ng/L, the assay cannot reliably detect myocardial infarction in some patients. This forces either a redesign of the detection chemistry (adding 3–6 months) or removal of the analyte from the menu. If 10–20% of analytes fail to meet sensitivity targets, the effective panel size shrinks to 400–450 analytes, weakening the 500-test claim.

**Likelihood:** Medium

**Severity:** Medium

**Action:** By Month 4 (2027-02-13), establish analytical performance targets for each analyte, specifying required detection limit, linear range, and accuracy. Prioritize the top 50 analytes by clinical value and conduct a sensitivity/feasibility study using reference materials and clinical samples. If any analyte falls short of the target, trigger a design review and consider removing it from the initial menu. Accept a core panel of 50–100 well-characterized analytes at launch, and expand only after sensitivity challenges are resolved. Publish sensitivity and detection-limit data alongside accuracy, so clinicians know which analytes are suitable for their use case.

## Risk 16 - Operational—Regulatory Inspection Readiness
FDA conducts pre-approval inspections of manufacturing facilities before clearing a device. If Newark (or contract manufacturers) lack adequate quality systems, documentation, environmental controls, or personnel training, FDA may issue a 483 citation or even refuse to clear the device pending remediation. This can add 3–6 months and USD 500 k–1 million in corrective work.

**Impact:** An FDA 483 at Newark requiring corrective action on manufacturing, design controls, or complaint handling could delay market launch by 3–6 months and require rework or retesting of pilot lots. If the facility lacks ISO 13485 certification or passes no pre-approval inspection, FDA may refuse to clear the device until all deficiencies are closed, effectively pausing commercialization.

**Likelihood:** Medium

**Severity:** Medium

**Action:** By Month 6 (2027-04-13), conduct an internal quality-system audit against ISO 13485 and FDA guidance (e.g., design controls, management of change, complaint handling, risk management). Hire or contract a quality-systems expert to lead documentation, training, and facility readiness. Aim for ISO 13485 certification by Month 18 (2028-04-13), well before the expected FDA pre-approval inspection (Month 30–36 = 2029-04-13 to 2029-10-13). Schedule a mock FDA inspection (conducted by an external regulatory consultant) at Month 28–30 (2029-02-13 to 2029-04-13) to identify and close gaps before the real inspection. Budget USD 300–500 k for quality-system build-out and certification.

## Risk 17 - Strategic—Scope Creep and Feature Expansion
During development, new analytes may seem feasible, or investors and partners may request added features (e.g., on-board temperature control, wireless connectivity) that consume design and capital resources without advancing the core mission. Scope creep delays design freeze, increases Newark capital requirements, and prolongs pre-revenue runway.

**Impact:** If scope creep adds 6 months to design freeze (Month 18 = 2028-04-13 becomes Month 24 = 2028-10-13), pre-revenue runway extends by USD 2–4 million, and the company may face a funding gap. Each added analyte or feature also increases the risk that the design will not meet cost-of-goods targets, necessitating a redesign before Newark scale-up.

**Likelihood:** Medium

**Severity:** Low

**Action:** By Month 1 (2026-11-13), establish a formal change-control process and a 'locked' core analyte list (e.g., the initial 50-analyte cluster). Any requests to add analytes or features must be evaluated against a gate criterion: does it delay design freeze or increase cost of goods beyond the ceiling? If yes, defer it to Phase 2 (post-launch expansion). Require investor, technical leadership, and product-leadership sign-off on scope changes. Hold quarterly scope-review meetings to track proposed changes and approve or reject them explicitly.

## Risk 18 - Regulatory—Software and Data Handling
A multiplex diagnostics device likely includes software for data processing, result interpretation, and reporting. FDA expects software to be developed under a defined development process (IEC 62304 or equivalent) with version control, testing, and cybersecurity. If the company underestimates software complexity or security risk, FDA may request additional evidence or security testing, delaying clearance.

**Impact:** If software security vulnerabilities are discovered post-launch or during FDA review, the company may face a mandatory software update, recall, or enforcement action. A delay in software clearance (e.g., FDA requesting additional penetration testing or validation) could add 2–4 months to regulatory review. Cybersecurity incident post-launch could trigger lawsuits and reputation damage.

**Likelihood:** Medium

**Severity:** Medium

**Action:** By Month 3 (2027-01-13), establish a software development plan aligned with IEC 62304, including requirements traceability, design controls, testing, and version management. Conduct a cybersecurity threat model and risk assessment, identifying potential vulnerabilities (e.g., unauthorized access to patient data, tampering with results). Budget USD 200–400 k for software development and security audits. Engage an external cybersecurity consultant for a penetration test by Month 18 (2028-04-13). Include software documentation and security evidence in the FDA submission package.

## Risk 19 - Market—Competitive Response and Product Obsolescence
The diagnostics market is competitive, with large incumbents (Roche, Siemens, Abbott) and well-funded startups (e.g., in liquid biopsy and molecular diagnostics) pursuing similar goals of broader, faster, cheaper testing. By the time this startup reaches market (Month 36–48 = 2029-10-13 to 2030-10-13), competitors may have already launched a similar or superior product, or the market may shift (e.g., toward molecular testing or AI-driven interpretation) rendering the single-drop immunoassay approach less valuable.

**Impact:** If a competitor launches a broader multiplex panel or a faster turnaround (e.g., 1-hour result instead of 10 minutes) before this company, market adoption and payer coverage will slow. The startup's addressable market could shrink by 20–40%, and per-unit pricing may be pressured downward by competition, reducing revenue by 30–50%.

**Likelihood:** Low

**Severity:** Medium

**Action:** By Month 6 (2027-04-13), conduct a competitive landscape analysis covering immunoassay multiplex panels, microfluidic devices, and rapid diagnostics in development and on the market. Identify the 5–10 closest competitors and track their patent filings, regulatory submissions, press releases, and funding. Define a defensible niche (e.g., rare-disease biomarkers, at-home screening, or a specific use case like post-COVID syndrome monitoring) where the startup can differentiate and reach market faster than incumbents. Consider partnerships or licensing deals with larger firms to accelerate time-to-market.

## Risk 20 - Technical—Plasma Separation and Sample Preparation
Most clinical analytes are measured in blood plasma or serum, not whole blood. Separating plasma from cells in a single drop of capillary blood without centrifugation is challenging and prone to failure (hemolysis, incomplete separation, variable efficiency). If plasma separation is unreliable, analyte results will be variable or inaccurate.

**Impact:** If plasma separation fails in >10% of fingerstick samples (e.g., due to hemolysis or incomplete wicking), the invalid-sample rate becomes unacceptable for clinical use, and the single-drop fingerstick promise fails. The company may be forced to switch to a larger sample volume or a different collection method (e.g., venous draw), losing the differentiation. This could add 6 months to validation and delay launch.

**Likelihood:** Medium

**Severity:** Medium

**Action:** By Month 4–6 (2027-02-13 to 2027-04-13), conduct a systematic evaluation of plasma-separation methods (e.g., passive wicking filters, acoustic separation, or on-card centrifugation). Test with fingerstick samples from 100+ subjects under real-world conditions (variable puncture depth, blood flow, user technique). Measure plasma-separation efficiency (volume and purity) and hemolysis rate. Set a success criterion: >95% of samples yield adequate plasma with hemolysis index <50. If passive separation cannot meet this, evaluate active (centrifugal or acoustic) methods, accepting added device complexity. Budget USD 200–300 k and 4–6 months for this feasibility work.

## Risk 21 - Operational—Supply Chain Logistics and Temperature Control
Cartridges containing reagents must be stored and shipped in a temperature-controlled manner (typically 2–8°C or frozen). Managing a cold chain from Newark through distribution to clinics or patient homes adds cost, complexity, and risk of temperature excursions. A single temperature-control failure could spoil a lot of cartridges.

**Impact:** If a shipment of cartridges is exposed to elevated temperature during transport or storage (e.g., truck failure, warehouse malfunction), the entire lot may be unusable, resulting in product loss of USD 50–200 k per incident and a production halt. Establishing and maintaining a cold chain also adds USD 10–20 per cartridge in logistics costs, raising the cost of goods by 5–10%.

**Likelihood:** Low

**Severity:** Medium

**Action:** By Month 12 (2027-10-13), establish a cold-chain logistics plan in partnership with a temperature-controlled distributor (e.g., Cardinal Health, McKesson, or a specialty cold-chain provider). Specify temperature monitoring (e.g., data loggers in every shipment), handling procedures, and contingency plans for temperature excursions. Conduct a cold-chain risk assessment and implement redundancy (e.g., backup freezers, alternative shipping routes). Budget USD 15–25 per cartridge for cold-chain logistics by Month 24 (2028-10-13). Negotiate agreements with distributors that include liability coverage for temperature failures.

## Risk 22 - Financial—Equipment Capital and Build-Out Cost Overrun
Outfitting a Newark reagent-formulation and cartridge-filling facility with equipment (filling machines, quality-control instruments, freezers, cleanroom HVAC) is expensive and subject to long lead times (6–12 months) and cost overruns. Equipment procurement may slip or costs may rise faster than budgeted, consuming contingency reserves.

**Impact:** If equipment lead times extend by 4 months and costs overrun by 20–30%, the Newark build-out could cost USD 4–6 million instead of USD 3–4 million, eating into the Series A funding and delaying the ramp to production-scale fills. This adds pressure to the budget and may force an unplanned fundraising round at an unfavorable valuation.

**Likelihood:** Medium

**Severity:** Medium

**Action:** By Month 3 (2027-01-13), identify and quote long-lead equipment (automated cartridge-filling machine, reagent dispensing systems, stability chambers, quality-control instruments). Order long-lead items (>6 month lead time) by Month 4–5 (2027-02-13 to 2027-03-13). Lock equipment pricing with suppliers using binding quotes or contracts. Build a contingency reserve of 20% in equipment budgets (add USD 400–600 k to the Newark capital plan). Establish a project management office to track equipment procurement, site preparation, and installation. Use a phased approach: critical path items first (e.g., filling machine), lower-priority items last.

## Risk 23 - Regulatory—Clinical Use Case Definition and Clinical Validity Evidence
FDA distinguishes between analytical validity (the assay measures what it claims) and clinical validity (the measurement is meaningful for diagnosis or prognosis). A test may be analytically accurate but clinically irrelevant. For example, measuring 500 biomarkers without evidence that any combination predicts a specific outcome may not satisfy FDA's clinical-validity expectations.

**Impact:** If FDA determines that clinical validity has not been demonstrated for the claimed use (e.g., 'disease screening,' 'patient stratification'), the company may be required to conduct additional clinical outcome studies, adding 12–24 months and USD 2–5 million. Alternatively, FDA may restrict the labeling to 'research use only,' limiting the market and revenue.

**Likelihood:** Medium

**Severity:** High

**Action:** By Month 6 (2027-04-13), work with clinical advisors and FDA through a Pre-Submission meeting to define the intended use (e.g., 'screening for cardiovascular risk,' 'monitoring treatment response in cancer'). Identify the primary clinical outcome that the assay should predict or inform (e.g., 'detection of myocardial infarction,' 'identification of responders to therapy'). Design the clinical study to measure that outcome (e.g., compare results to a reference diagnosis, measure agreement on treatment decisions). Ensure the study population, sample size, and statistical analysis are adequate to demonstrate clinical validity. Budget USD 1–3 million for clinical studies demonstrating clinical validity over Months 12–36 (2027-10-13 to 2029-10-13).

## Risk summary
A medical diagnostics startup proposing to run 500 complex health tests from a single drop of blood, with mass production in Newark, California, faces extreme technical, regulatory, financial and operational risks. The core claim—500 tests per drop at clinical-grade accuracy—is explicitly stated in the strategy document as physically infeasible under all proposed architectures. Major risks include: (1) analytical feasibility—crosstalk, reagent stability, and cartridge yield may not support the breadth claimed, forcing a retreat to a narrower panel and redefining the business; (2) regulatory and reputational exposure—over-claiming 500 tests without validated evidence risks FDA enforcement, clinician distrust, and payer rejection; (3) capital intensity and staged commitment—Newark manufacturing build-out timing is coupled to design maturity and funding tranches; premature investment locks cost into an unfrozen design, while delay risks discovering scale-up failures too late. Secondary risks include supply-chain fragility (reagent lot variability, contract-manufacturer dependencies), talent competition in the Bay Area, and long pre-revenue runway (multi-year clinical validation and regulatory clearance). The strategy document recommends a modular cartridge approach with staged 510(k) clearances and pharma beachhead funding, which distributes risk and contains the single-device-single-drop claim within a cumulative menu. However, this path trades faster revenue (off-device measurement in a CLIA lab) for the named Newark manufacturing and on-device measurement premise. The three most critical risks are: over-claiming and credibility loss (likelihood: high, severity: high); Newark capital commitment misaligned with design maturity (likelihood: medium, severity: high); and analytical feasibility across a 500-test scope (likelihood: high, severity: high). Mitigation depends on explicit feasibility gates, independent evidence generation, modular product architecture, and strict capital release tied to technical proof points rather than schedule or investor narrative.