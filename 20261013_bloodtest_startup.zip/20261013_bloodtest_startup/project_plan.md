**Goal Statement:** Build a diagnostics startup that delivers a cumulative modular menu of up to 500 complex health tests from a single drop of blood per cartridge cluster, with cartridge reagent formulation and filling at Newark, California, starting Month 0 (2026-10-13).

## SMART Criteria

- **Specific:** Establish a diagnostics company that develops, validates and manufactures modular cartridges (10-15 analytes each) run from a fingerstick drop, offered as a cumulative menu toward 500 tests, with Newark, California as the manufacturing site.
- **Measurable:** Success is the number of independently validated analyte clusters cleared and shipped from Newark: Fallback Panel V1 of 50 analytes first (proposed threshold), then successive 50-analyte blocks, each meeting concordance >=95% and lot CV <10% (proposed thresholds).
- **Achievable:** Feasible only as a staged, gate-controlled program: 500 simultaneous tests per drop is not physically feasible, so the menu is cumulative. Cumulative burn through clearance is USD 15-30M (estimate), with no user-stated budget cap.
- **Relevant:** A validated multi-analyte fingerstick platform made in Newark would be a category-defining diagnostics product; staged evidence and clearance protect credibility given past failed single-drop claims.
- **Time-bound:** Program planning horizon is Months 0-72 (2026-10-13 to 2032-10-13). First clearance Months 36-48 (2029-10-13 to 2030-10-13) and first commercial sales by Month 48 (2030-10-13). The full 500-analyte menu is not committed within the horizon.

## Dependencies

- Secure gate-linked equity tranches plus pharma and grant funding to cover the multi-year pre-revenue runway
- Complete analytical feasibility gates (plasma separation, cross-reactivity, yield, shelf-life) before releasing Newark filling-line capital
- Align regulatory pathway through FDA Pre-Submission and build ISO 13485 quality system and design controls from Month 1 (2026-11-13)
- Qualify contract molders, instrument assemblers and dual-sourced critical reagent suppliers
- Secure Newark BSL-2 cleanroom space with zoning permitting biological reagent handling

## Resources Required

- Newark BSL-2 reagent formulation and cartridge-filling facility (2,000-3,000 sq ft initially) (proposed)
- Microfluidics, assay chemistry, quality and regulatory talent (25-35 staff by Month 12 = 2027-10-13) (estimate)
- Antibodies, probes and other critical reagents with dual suppliers
- Contract injection molding and instrument assembly partners
- Clinical study partner and sample access for method-comparison studies

## Related Goals

- Pre-register a 50-analyte Fallback Panel V1 as the guaranteed product
- Obtain staged per-cluster 510(k)/De Novo clearances
- Establish pharma biomarker beachhead and non-dilutive grant revenue
- Prepare a CLIA lab-service fallback by Month 12 (2027-10-13)
- Reach ISO 13485 certification by Month 18 (2028-04-13)

## Tags

- diagnostics
- microfluidics
- blood-testing
- Newark
- medtech

## Risk Assessment and Mitigation Strategies


### Key Risks

- Analytical infeasibility: cross-reactivity, plasma separation and drop-volume budget (about 8-16 analytes per drop) (estimate) limit panel size
- Regulatory uncertainty: 510(k) vs De Novo, which could add 12-18 months and USD 2-4M (estimate)
- Funding gap: up to about USD 17M to raise after Month 24 (2028-10-13) (estimate) and pharma revenue lagging
- Unit economics: multi-cartridge menu cost vs USD 100-200 per run net revenue (estimate)
- Reputational damage from over-claiming given failed single-drop precedents

### Diverse Risks

- Cartridge yield, reagent lot variability and shelf-life shortfalls at scale
- Contract manufacturer dependency and tooling re-work (USD 50-150k, 3-4 months) (estimate)
- Talent scarcity and key-person loss in the Bay Area
- Payer coverage unavailable for a multiplex bundle
- Equipment lead times of 6-12 months and cost overruns

### Mitigation Plans

- Gate-linked capital at Months 6, 12 and 18 (2027-04-13, 2027-10-13, 2028-04-13) with pre-agreed thresholds; Fallback V1 (50 analytes) activates if unresolved by Month 15 (2028-01-13)
- Hold FDA Pre-Submission by Month 6 (2027-04-13) and model both 510(k) and De Novo timelines in the funding plan
- Phase Newark investment: USD 500-800k reagent lab first, filling line (USD 2-3M plus 20% contingency) only after design freeze and yield proof
- Lock USD 25 per cartridge COGS ceiling by Month 6 (2027-04-13) and test payer scenarios by Month 9 (2027-07-13); lean pivot if pharma run-rate is below USD 100k/month at Month 18 (2028-04-13)
- Credibility-first communication: pre-registered studies, advisory board with data audit, no '500 tests' claims until 3 clusters are independently validated

## Stakeholder Analysis


### Primary Stakeholders

- Founding team and board (gate decision owners)
- R&D director and assay/microfluidics engineers
- Quality/regulatory lead
- Newark manufacturing and reagent operations team
- Seed and Series A investors

### Secondary Stakeholders

- FDA (CDRH) and CLIA/regulatory bodies
- Pharma sponsors and grant agencies
- Contract molders, instrument assemblers and reagent suppliers
- Academic clinical partner and scientific advisory board
- Payers and clinicians

### Engagement Strategies

- Investors and board: quarterly gate-linked reports with pass/fail/ambiguous results and board votes on tranche release
- Primary team: monthly performance reviews, analyte review meetings and prompt answers to information requests
- FDA: Pre-Submission by Month 6 (2027-04-13), then milestone-based follow-ups
- Pharma, grants and payers: feasibility partnerships from Month 0 (2026-10-13), paid contract by Month 9 (2027-07-13), payer discussions by Month 6 (2027-04-13)
- Suppliers and partners: quality agreements, dual sourcing and monthly scorecards
- Public and clinicians: published validation data including failures

## Regulatory and Compliance Requirements


### Permits and Licenses

- Newark zoning/use permit for biological reagent handling
- Bay Area air-quality and wastewater permits
- Medical/biohazard waste and chemical inventory permits (California)
- CLIA certification for lab-service fallback
- FDA 510(k)/De Novo clearance for cartridges and instrument

### Compliance Standards

- ISO 13485 and 21 CFR 820 quality system
- ISO 14971 risk management
- IEC 62304 software lifecycle and cybersecurity
- BSL-2 biosafety and occupational safety rules
- Pre-registered clinical study protocols (ClinicalTrials.gov)

### Regulatory Bodies

- FDA CDRH
- CMS (CLIA program)
- City of Newark and Alameda County authorities
- Bay Area Air Quality Management District
- ISO 13485 accredited registrar

### Compliance Actions

- Request FDA Pre-Submission in Months 2-3 (2026-12-13 to 2027-01-13); hold by Month 6 (2027-04-13)
- Launch electronic QMS and design controls by Month 6 (2027-04-13); assess ISO 13485 at Month 15 (2028-01-13), certify by Month 18 (2028-04-13)
- Scope Newark permits early and contract a licensed medical-waste vendor
- Run mock FDA inspection at Months 28-30 (2029-02-13 to 2029-04-13)
- Prepare CLIA lab-service route by Month 12 (2027-10-13) and file first 510(k)/De Novo by Month 30 (2029-04-13)