# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Microfluidic Cartridge Design Engineer

**Knowledge**: Microfluidics, plasma separation, fluidic architecture, injection molding, cartridge integration, multi-analyte sample partitioning, point-of-care device design

**Why**: The Cartridge Fluidic Architecture and Integration Depth decision (Decision 5) and the drop-volume analyte budget (8-16 analytes per drop, estimate) are the core physical constraints driving all panel architecture choices. An expert in microfluidic design is essential to validate whether the modular cartridge family can achieve the proposed 10-15 analyte clusters, plasma separation >95%, and the USD 25 COGS ceiling within the manufacturing tolerance windows that Newark will inherit.

**What**: Conduct a Design-for-Manufacturability review with the R&D director by Month 6 (2027-04-13) to map the fluidic partitioning, plasma separation and reagent-storage chambers that fit within the drop budget, and to identify the yield-limiting tolerance stack-ups and bonding/molding steps that determine cartridge cost and first-pass yield.

**Skills**: Cartridge design iteration, plasma separation method selection, tolerance stack-up analysis, Design-for-Manufacturability (DFM), microfluidic simulation (CFD), injection-mold design, bonding and assembly process design, failure-mode analysis

**Search**: microfluidic cartridge design engineer, point-of-care device fluidics, plasma separation microfluidics, cartridge DFM consulting

## 1.1 Primary Actions

- By Month 2 (2026-12-13): Lock a realistic per-run net-revenue assumption (USD 100, USD 150, or USD 200) and derive the corresponding COGS ceiling (USD 40, USD 60, or USD 80) required for 50–60% gross margin. Pre-register a Fallback V1B product (25–35 analytes, 2–3 cartridges) that achieves ≥50% margin at your most conservative price; define the trigger (e.g., pharma run-rate <USD 150k/month at Month 18 = 2028-04-13) for automatic activation without board debate. Model unit economics for the 50-analyte fallback with actual contract-manufacturing quotes and cold-chain costs; if margin is <30%, accept that a narrower panel (25–35 analytes) is the true business model and size Seed and Series A accordingly.
- By Month 3 (2027-01-13): Engage an FDA regulatory consultant (USD 150–250k), prepare a Pre-Submission Type B package with 3–5 specific regulatory questions (510(k) vs. De Novo, clinical-study sample size, staged-modification pathway), and hold the meeting by Month 6 (2027-04-13). Model two funding and timeline scenarios in parallel: Scenario A (510(k), clearance Month 48 = 2030-10-13, Series A/B totals USD 10–12M) and Scenario B (De Novo, clearance Month 60 = 2031-10-13, Series A/B/C totals USD 15–22M). Size Series B at Month 18 (2028-04-13) to cover the indicated pathway without forced down-round; if De Novo is likely, increase Series B by USD 2–4M preemptively. Schedule a follow-up Pre-Submission by Month 9 (2027-07-13) to confirm pathway before finalizing clinical-study design.
- By Month 2 (2026-12-13): Document a Capital Commitment Authority Charter naming CFO as veto authority over equipment orders >USD 100k and deposits >USD 50k; define 'cancellable deposit' as <10% forfeiture if cancelled by Month 18 (2028-04-13), with all terms pre-approved in writing. Establish a fallback V1 activation protocol: if Month 12 (2027-10-13) analytical yield is <80% (lower 95% CI) or design freeze is delayed past Month 18 (2028-04-13), CEO and CFO activate pre-registered Fallback V1 within 5 business days by board motion, without vendor negotiation or operations escalation. Link all Series A tranches to gate closure and documented gate results; ambiguous gates (e.g., yield 84% when threshold is 85%) trigger board decision to re-test (1–2 weeks) or pivot, not automatic release.
- By Month 1 (2026-11-13): Establish an external scientific advisory board (5–7 members from diagnostics and academia) with quarterly public meetings and audit access to raw analyte performance data, failure logs, and removal justifications. Commit to a 'Science-First' transparency charter: all assay-level performance data (accuracy, precision, cross-reactivity, failures) published monthly in a public dashboard, with no suppression of weak analytes. Pre-register the clinical-study protocol on ClinicalTrials.gov before enrollment, specifying analyte-level success criteria and sample size; publish the first Quarterly Analyte Performance Report by Month 6 (2027-04-13) showing validated assays and any failures with technical root causes. This preempts reputational damage from past failed single-drop claims and gives FDA and payers confidence in transparency.
- By Month 6 (2027-04-13): Complete the Month 6 (2027-04-13) gate criteria in full and document all results (pass/fail/ambiguous) in writing with lower 95% confidence intervals for each metric: plasma separation ≥95% (lower CI ≥92%) of ≥100 subjects, cross-reactivity ≤5% bias, FDA Pre-Submission held and pathway documented, COGS ceiling locked, QMS live. If any gate is 'ambiguous' (e.g., plasma separation at 94%), hold a board vote within 2 weeks: approve 1–2 weeks re-testing (USD 10–20k) or activate Fallback V1 and pivot. Release Series A Tranche 2 (USD 2–3M) only upon documented gate pass, not on schedule.

## 1.2 Secondary Actions

- By Month 1 (2026-11-13): Hire or contract a senior quality/regulatory director (10+ years IVD device experience) as a co-founder or early full-time employee; assign them authority over all design decisions, change management, and ISO 13485 compliance from Month 1 (2026-11-13) onwards. This person is accountable for design controls and DHF (Design History File) maturity at each gate, preventing regulatory rework at Month 28–30 (2029-02-13 to 2029-04-13) mock inspection.
- By Month 4 (2027-02-13): Perform a critical-supplier risk assessment for Cluster 1: identify all suppliers (contract molders, reagent suppliers, instrument assemblers), assess financial stability and sole-source exposure, and qualify ≥2 molders and ≥2 reagent suppliers for each of the top 10 analytes by Month 6 (2027-04-13). Execute binding quality agreements specifying defect rate <5%, first-pass yield >90%, and 3-year price caps. Establish a 4–6 week buffer inventory of critical reagents (cost USD 20–30k) by Month 12 (2027-10-13).
- By Month 5 (2027-03-13): Launch SBIR/STTR grant applications (USD 1–2M cumulative over Months 0–24 = 2026-10-13 to 2028-10-13) and initiate conversations with 5–10 pharma sponsors to identify research-use-only partnerships for Cluster 1 biomarker validation. Target first pharma contract signature by Month 9 (2027-07-13) and cumulative non-dilutive commitments of USD 1–2M by Month 12 (2027-10-13); treat pharma revenue as upside, not core runway.
- By Month 6 (2027-04-13): Conduct a Design-for-Manufacturability (DFM) review with ≥2 contract molders and a filling-equipment vendor; identify yield-limiting steps, tolerance windows, and supplier capability gaps. Execute a pilot fill of 1,000–5,000 cartridges at a contract manufacturer or Phase 1 Newark lab using production-equivalent processes; measure first-pass yield (target ≥85%, acceptance ≥80%). Document all DFM findings and mold-flow simulations.
- By Month 12 (2027-10-13): Complete analytical feasibility gate documentation and board vote on gate pass/fail; if passed, release Series A Tranche 3 (USD 2–3M) for Phase 2 Newark fit-out (filling line, USD 2–3M capex + 20% equipment contingency). If gate is failed or ambiguous, execute Fallback V1 activation (board vote within 2 weeks) and pause Newark expansion; conduct a 4-week design review and re-pilot by Month 15 (2028-01-13).
- By Month 15 (2028-01-13): Assess ISO 13485 readiness through an internal audit; identify major gaps and close them within 4 weeks. Conduct environmental and shelf-life testing at accelerated conditions (e.g., Arrhenius 40°C/75% RH); project 12-month shelf-life with R² >0.90 or accept a 9-month claim and plan re-stability testing at Month 15 (2028-01-13).
- By Month 18 (2028-04-13): Achieve design freeze for Cluster 1, ISO 13485 certification (from accredited registrar), interim clinical concordance ≥95% (lower CI ≥93%, 150–200 samples), Newark pilot yield ≥85% over ≥5 production batches, and Freedom-to-Operate (FTO) opinion cleared by IP counsel. Board votes on Phase 2 release (filling-line capex) contingent on all criteria met.
- By Month 24 (2028-10-13): Complete clinical-study enrollment (300–500 subjects, Months 12–18 = 2027-10-13 to 2028-04-13) and conduct statistical analysis; prepare for submission package (510(k) or De Novo per FDA feedback). Secure Series B (USD 3–5M, or larger if De Novo is pathway) to cover regulatory submission and clearance (Months 30–48 = 2029-04-13 to 2030-10-13).
- By Month 30 (2029-04-13): Submit the first 510(k) or De Novo dossier to FDA; target clearance by Month 48 (2030-10-13). Conduct mock FDA inspection (Months 28–30 = 2029-02-13 to 2029-04-13) and remediate findings. Publish clinical-study results and first Quarterly Analyte Performance Report (Month 6 = 2027-04-13) if not yet completed.
- By Month 36 (2029-10-13): Prepare for commercial launch: establish sales infrastructure, payer coverage applications, reimbursement strategy, and supply-chain logistics. Begin production ramp at Newark or contract manufacturer; target 10k cartridges/month by Month 36–42 (2029-10-13 to 2030-04-13).

## 1.3 Follow Up Consultation

In the next consultation (Month 1 = 2026-11-13), review: (1) per-run revenue assumption and COGS-ceiling derivation; (2) FDA Pre-Submission questions and Scenario A/B funding models; (3) Capital Commitment Authority Charter and fallback activation protocol; (4) Advisory board charter and transparency commitments; (5) Cluster 1 analyte list (10–15) with clinical rationale; (6) Fallback V1B definition (25–35 analytes, 2–3 cartridges) and activation trigger; (7) Pharma outreach plan and grant applications; (8) Quality director hire and Design Control charter. Confirm whether the founding team accepts the constraint that 500 simultaneous tests per drop are not feasible, and that the product is a cumulative modular menu with no '500 tests' marketing until ≥3 clusters are published. Clarify who on the board or leadership has authority to activate Fallback V1 and Fallback V1B without escalation and sunk-cost resistance. Discuss whether Series B should be sized and pre-committed at Month 0 (2026-10-13) or deferred pending Pre-Submission feedback at Month 6 (2027-04-13).

## 1.4.A Issue - Unit economics are mathematically broken; the 50-analyte Fallback V1 cannot achieve 60% gross margin at any realistic price.

The plan assumes 50 analytes delivered as 4–5 cartridges (USD 160–225 variable cost) sold at USD 100–200 per run, yielding 20% or negative margin at best. The 60% margin target requires either USD 400–500+ per run (unattainable payer reimbursement) or COGS <USD 40–50 per cartridge (no evidence this is feasible at clinical-grade yield). The breakeven volume of 2,000–11,000 runs/month assumes USD 3.75–7.5M annual burn, yet the plan budgets USD 2–3M Series A tranches for 6-month intervals. This mismatch will become undeniable at Month 12 (2027-10-13) gate. No pivot to a narrower (higher-margin) panel is pre-registered, leaving sunk-cost escalation risk.

### 1.4.B Tags

- unit_economics_infeasibility
- margin_gap
- breakeven_volume_unachievable
- pricing_contradiction
- cost_ceiling_too_loose

### 1.4.C Mitigation

By Month 2 (2026-12-13), lock a per-run price assumption (USD 100, USD 150, or USD 200) and model the corresponding COGS ceiling: USD 40 (for 60% margin at USD 100), USD 60 (at USD 150), or USD 80 (at USD 200). For each, list which analytes or assay classes must be cut to hit the COGS target. Pre-register a Fallback V1B panel (25–35 analytes, 2–3 cartridges) that achieves ≥50% margin at your most pessimistic price (e.g., USD 100 net). Model pharma contract revenue and payer reimbursement scenarios in parallel; if neither reaches USD 150k/month by Month 18 (2028-04-13), activate Fallback V1B without board debate. This forces explicit choice between margin and analyte count before the design is frozen.

### 1.4.D Consequence

Without mitigation, the company will reach Month 12–18 (2027-10-13 to 2028-04-13) with a 50-analyte cartridge family that cannot generate positive unit economics, forcing either a 15–25% price increase (payer rejection) or a redesign that delays clearance 6–12 months. Newark fixed-cost build-out approved at Month 18 (2028-04-13) becomes stranded capital. Series B investors will demand margin proof before funding, compressing runway. Reputational risk: market will perceive another over-engineered, uneconomical single-drop device.

### 1.4.E Root Cause

The 500-analyte ambition and the USD 100–200 per-run price assumption were never reconciled against COGS and margin targets. The plan assumes payer coverage and volume without evidence; it also conflates 'modular' (separate cartridges) with economical (price per test drops). The cost ceiling of USD 25 per cartridge was set as a target rather than derived from reimbursement and margin requirements.

## 1.5.A Issue - Regulatory pathway uncertainty (510(k) vs. De Novo) is acknowledged but not operationalized; the funding plan has no contingency for De Novo's 12–18 month delay and USD 2–4M cost.

The plan requires FDA Pre-Submission by Month 6 (2027-04-13) to confirm pathway, yet the Series A tranches and monthly burn are sized for a 510(k) timeline (clearance Months 36–48 = 2029-10-13 to 2030-10-13). If FDA indicates De Novo is likely (high complexity, new intended use, no predicate), clearance moves to Months 48–66 (2030-10-13 to 2032-04-13), adding ~18 months. The funding gap after Month 24 (2028-10-13) is estimated at USD 17M; a De Novo pathway would push it to USD 21M (estimate), and the plan has no Series B sizing or gate to address this contingency. Monthly burn and tranche sizes remain unchanged in both 510(k) and De Novo scenarios.

### 1.5.B Tags

- regulatory_pathway_unresolved
- contingency_funding_absent
- timeline_volatility
- series_b_sizing_missing
- de_novo_cost_not_budgeted

### 1.5.C Mitigation

By Month 3 (2027-01-13), engage a regulatory consultant (USD 150–250k) and prepare a Pre-Submission Type B package with 3–5 specific questions: 'Is a 10–15 analyte immunoassay suitable for 510(k) or does FDA expect De Novo?', 'What clinical evidence (sample size, study design) is required?', 'Can a staged per-cluster modification pathway be used?'. Hold the Pre-Submission by Month 6 (2027-04-13) and document FDA's initial indication in writing. Model two funding scenarios: Scenario A (510(k), clearance Month 48 = 2030-10-13) and Scenario B (De Novo, clearance Month 60 = 2031-10-13). Size Series B at Month 18 (2028-04-13) to cover either timeline; if De Novo is indicated, increase Series B by USD 2–4M and add 6 months to Month 24 (2028-10-13) runway. By Month 9 (2027-07-13), conduct a follow-up meeting to confirm pathway before committing to clinical-study design.

### 1.5.D Consequence

Without contingency, the company reaches Month 24 (2028-10-13) confident in a 510(k) path, only to learn at Month 30 (2029-04-13) that De Novo was indicated by FDA at Month 6 (2027-04-13) but not acted upon. Runway is insufficient for an additional 12–18 months of evidence generation. Series B is forced to be larger and more dilutive, or capital raises at lower valuation. Clinical-study protocol may require major rework if it was not aligned with De Novo expectations from the start. Clearance slips to Month 60+ (2031-10-13+), pushing first product revenue to Year 5, and the company becomes acquisition-dependent.

### 1.5.E Root Cause

The plan treats FDA feedback as a 'confirmation' of a pre-planned path (510(k)) rather than as a contingency that reshapes funding and timeline. The Pre-Submission is scheduled correctly (Month 6 = 2027-04-13), but the downstream funding and clinical-trial planning are not branched on the outcome. Series B sizing is not mentioned; the plan jumps from Series A (Months 6–18 = 2027-04-13 to 2028-04-13) to an undefined Series B (Months 18–24 = 2028-04-13 to 2028-10-13).

## 1.6.A Issue - The Newark facility phasing strategy is sound, but the binding orders and long-lead-equipment decision rule is unenforceable; no owner, authority, or veto mechanism is assigned for Month 18 (2028-04-13) or later.

The plan correctly defers binding equipment orders to Month 18 (2028-04-13) after design freeze and yield proof, but it does not specify who has authority to override this rule if pressure mounts. A typical scenario: Month 15 (2028-01-13), operations proposes placing a deposit on a filling-line to 'secure the delivery slot' (9–12 month lead time). No owner, CFO veto, or board gate is named to prevent this. Similarly, 'cancellable deposits' allowed after Month 12 (2027-10-13) gate are undefined: what is the cost, who approves, and does 'cancellable' mean USD 50k penalty or 50%? By Month 12 (2027-10-13), if analytical yield passes but is marginal (85% mean, 80% lower CI), the fallback rule triggers, but Newark staff and vendors may resist the design-review pause, escalating instead to the board for 'exception.' No escalation protocol or 'circuit breaker' is documented.

### 1.6.B Tags

- decision_authority_undefined
- long_lead_rule_unenforceable
- deposit_commitment_ambiguous
- fallback_activation_resistance_unmanaged
- vendor_escalation_uncontrolled

### 1.6.C Mitigation

By Month 2 (2026-12-13), document a Capital Commitment Authority Charter: (1) CFO holds veto authority over any equipment order >USD 100k or with lead time >6 months; (2) CEO and CFO together approve all deposits >USD 50k and monitor cancellation clauses in writing; (3) 'Cancellable deposit' is defined as forfeiture of <10% if order is cancelled by Month 18 (2028-04-13), and deposits must be pre-approved in writing with cancellation terms attached; (4) Fallback V1 activation (if Month 12 = 2027-10-13 yield <80% or design freeze delayed past Month 18 = 2028-04-13) is a board decision, executable in ≤5 business days by CEO and CFO without vendor negotiation; (5) Operations leads report monthly to CFO on equipment quotes, commitments, and long-lead status. Escalation: if Operations proposes exception to the Month 18 (2028-04-13) binding-order rule, CFO and CEO present it to the board with full cost and timeline impact. This prevents a de facto acceleration of commitments disguised as 'vendor management.'

### 1.6.D Consequence

Without clear authority, the company will drift toward premature capital commitments in Months 9–15 (2027-07-13 to 2028-01-13), rationalizing them as 'prudent' or 'vendor-required.' By Month 18 (2028-04-13), if yield is 83% (marginal) or shelf-life shows degradation at 9 months, the design needs 8–12 weeks of reformulation. However, a USD 2.5M filling line on order cannot be stopped without USD 250k–500k penalty, forcing the company to accept suboptimal cartridge design or absorb the penalty and delay Newark opening by 6 months. The fallback to Fallback V1 becomes politically untenable because operations and Newark staff are already in place, resisting scope reduction. Series B investors, unaware of the commitment, discover 'stranded Newark capex' and demand accountability, eroding board credibility.

### 1.6.E Root Cause

The plan correctly identifies the long-lead-equipment risk but does not assign operational authority or create enforceable decision rules with named accountable owners. The phrase 'binding orders only at Month 18 (2028-04-13)' is aspirational, not procedural. No CFO or board gate is explicitly responsible for preventing pre-Month 18 (2028-04-13) commitments, and no fallback activation protocol names a decision-maker who can override operational resistance.

---

# 2 Expert: FDA Regulatory Strategy Consultant (510(k) vs De Novo Pathway)

**Knowledge**: FDA medical-device clearance and approval, 510(k) and De Novo pathways for multiplex assays, CLIA and LDT regulatory landscape, clinical study design alignment with regulatory submissions, pre-submission meetings

**Why**: The Regulatory Route and Sequencing decision (Decision 2) and the regulatory uncertainty risk (estimated 12-18 month delay and USD 2-4M cost if De Novo is required instead of 510(k)) are the longest-pole pathway affecting funding and timing. An FDA regulatory expert is essential to conduct the Pre-Submission meeting by Month 6 (2027-04-13), confirm the likely clearance pathway for a 100+ analyte multiplex, and align the clinical-study design and evidence package with FDA expectations before committing Series A capital.

**What**: Lead the FDA Pre-Submission Type B meeting (request Months 2-3 = 2026-12-13 to 2027-01-13, hold by Month 6 = 2027-04-13) to confirm whether Cluster 1 (10-15 analytes) is suitable for 510(k) or will require De Novo review, and to document FDA feedback on analytical evidence, clinical-study design, and the feasibility of a staged per-cluster submission strategy.

**Skills**: FDA submission strategy, pre-submission meeting preparation and execution, 510(k) and De Novo comparator selection and evidence packages, clinical-study statistical design, device classification and predicate device selection, communications with CDRH

**Search**: FDA regulatory consultant 510k De Novo medical device, diagnostics regulatory pathway, multiplex assay FDA clearance strategy

## 2.1 Primary Actions

- By Month 2 (2026-12-13): Conduct a formal FDA predicate-device search and regulatory-pathway risk assessment with a senior regulatory consultant; develop two cost/timeline scenarios (510(k) vs De Novo) and present to the board; commit De Novo contingency capital (USD 2-4M additional Series B) if likelihood exceeds 30%, or lock 510(k)-first strategy and commit to Pre-Submission by Month 5 (2027-03-13) confirmation.
- By Month 3 (2027-01-13): Lock the Cluster 1 analyte set (10-15 names with clinical rationale) and complete a rapid cross-reactivity screening study in spiked plasma (hemoglobin, bilirubin, rheumatoid factor, lipemia at 5-10x pathologic concentration); remove any analyte that fails; document the final Cluster 1 specification and cross-reactivity matrix in writing.
- By Month 6 (2027-04-13): Complete the FDA Pre-Submission meeting with two prepared clinical-study protocols (510(k) analytical concordance focus vs De Novo clinical-utility focus); lock the study design based on FDA feedback; begin immediate enrollment; establish a monthly FDA liaison call to confirm milestones and resolve ambiguities, not to rediscover misalignments.
- By Month 2 (2026-12-13): Establish a detailed cash-flow model and board-approved capital-release schedule with quantitative gate criteria (yield ≥85%, lot CV <10%, concordance ≥95%, COGS ≤USD 25), explicit Fallback V1 (50-analyte core) activation trigger, and board sign-off authority for each tranche; model both 510(k) and De Novo funding scenarios independently.
- By Month 1 (2026-11-13): Hire or contract a full-time Quality/Regulatory Director (10+ years IVD/FDA experience) as a co-founder; establish ISO 13485 design controls, design history file, and change-control procedures from Month 1 (2026-11-13) (not post-design-freeze); conduct an internal ISO 13485 audit at Month 6 (2027-04-13) and target certification by Month 18 (2028-04-13) with an accredited registrar.

## 2.2 Secondary Actions

- By Month 4 (2027-02-13): Conduct a drop-volume and plasma-separation feasibility study with ≥100 subjects to confirm the 8-16 analyte budget is realistic for Cluster 1; measure actual plasma recovery, hemolysis control and analyte stability over 4-week storage; adjust Cluster 1 scope if recovery is <95% or hemolysis index control is unreliable.
- By Month 3 (2027-01-13): Establish a dual-sourcing and supply-chain continuity plan for the top 10 highest-risk analytes and critical molding/filling suppliers; qualify ≥2 molders and ≥2 critical reagent suppliers per analyte; execute quality agreements with 3-year price locks and 90-day capacity commitments; budget USD 50-100k and 6-8 weeks for supplier qualification.
- By Month 1 (2026-11-13): Appoint an external scientific advisory board (5-7 members from leading diagnostics and academic labs) with quarterly public meetings and audit access to raw performance data and analyte-removal logs; commit to publishing a quarterly analyte-performance report (pass and fail) by Month 6 (2027-04-13) to pre-empt credibility attacks.
- By Month 6 (2027-04-13): Define and publish a Fallback V1 product specification (50 analytes, 10-15 per cartridge, minimum viable menu for disease triage or screening); communicate that activation is a technical decision, not a failure; brief investors on fallback before Series A close.
- By Month 9 (2027-07-13): Conduct a financial modeling session with payers and 2-3 pharma customers to confirm net revenue per run (base case USD 100-200); test whether USD 25 COGS ceiling is achievable; identify pricing/reimbursement barriers that might limit adoption even if clearance succeeds; adjust Series A scope if payer scenario is USD <80 per run (low case).
- By Month 12 (2027-10-13): Prepare and staff a CLIA lab-service fallback route with protocol, SOPs and anticipated start-up cost; if Newark Phase 2 is paused by a failed gate, the lab-service route can launch within 8-12 weeks and generate early revenue/data while device development is redirected.
- By Month 15 (2028-01-13): Conduct a design-for-manufacturability (DFM) review with ≥2 contract molders and the Newark Phase 1 team; confirm yield-limiting steps, tolerance windows and fill-time at pilot scale; execute pilot fills (1,000-5,000 cartridges) to measure first-pass yield and shelf-life stress data; use data to gate the Phase 2 Newark investment at Month 18 (2028-04-13).

## 2.3 Follow Up Consultation

"In the next consultation, focus on: (1) FDA regulatory pathway confirmation and predicate-device findings; present the De Novo contingency capital plan if likelihood >30%. (2) Cluster 1 analyte finalization and cross-reactivity results; resolve any failed analyte pairs and lock the clinical-study protocol. (3) Clinical-study enrollment status and FDA liaison updates from the monthly calls; confirm no protocol misalignment has emerged. (4) Month 12 (2027-10-13) analytical feasibility gate results (yield, shelf-life, concordance, COGS); decision on Fallback V1 activation or Phase 2 release. (5) Dual-sourcing and supply-chain continuity progress; confirm molding and reagent supplier agreements are signed and current. (6) Financial/payer feedback from Month 9 (2027-07-13) testing; confirm net revenue assumption holds or adjust Series A scope. (7) Early pharma/grant revenue and contract pipeline status; confirm USD 100k/month run-rate is on track by Month 18 (2028-04-13) or trigger lean-pivot contingency."


## 2.4.A Issue - Regulatory pathway is unconfirmed and De Novo risk is under-capitalized; 12-18 month delay and USD 2-4M cost are not factored into Series A sizing.

The plan requests FDA Pre-Submission by Month 6 (2027-04-13), but treats 510(k) and De Novo as equally likely without evidence. For a 100+ analyte multiplex immunoassay claiming clinical accuracy and a novel cartridge design, De Novo is more likely than 510(k). No predicate device exists for this exact configuration. The plan models clearance at Months 36-48 (2029-10-13 to 2030-10-13) but does not adjust equity tranches or runway if De Novo extends to Months 48-66 (2030-10-13 to 2032-04-13). Series A (USD 9-12M total) is already tight for a 510(k) path; a De Novo scenario requires USD 2-4M additional and covers only Months 0-36 (2026-10-13 to 2029-10-13), not Months 0-54 (2026-10-13 to 2031-04-13)+. This mismatch will force an unplanned Series B extension or a down round at Month 18-24 (2028-04-13 to 2028-10-13).

### 2.4.B Tags

- regulatory-uncertainty
- de-novo-risk
- funding-gap
- series-a-sizing

### 2.4.C Mitigation

By Month 2 (2026-12-13): conduct a formal predicate-device search with FDA Guidance documents (510(k) Program Guidance, De Novo pathway, CDRH classification database). Engage a senior FDA regulatory consultant (USD 150-250k) to model two funding scenarios: (A) 510(k) path, clearance Month 36-42 (2029-10-13 to 2030-04-13), Series A USD 10-12M sufficient; (B) De Novo, clearance Months 48-60 (2030-10-13 to 2031-10-13), Series A must cover Months 0-36 (2026-10-13 to 2029-10-13) only, Series B (USD 3-5M) sized for additional 12-18 month runway at Month 18 (2028-04-13). Present both scenarios to investors by Month 4 (2027-02-13); lock the preferred pathway at Month 6 (2027-04-13) Pre-Submission or confirm De Novo contingency capital is committed separately.

### 2.4.D Consequence

Without De Novo capital pre-positioned, the company will face a funding cliff at Months 30-36 (2029-04-13 to 2029-10-13) if FDA signals De Novo pathway. Either a down round occurs (dilution 30-50%, team morale loss) or the company must pause development for 2-4 months awaiting Series B close (delays clearance by one Q). Historical precedent: Guardant's cfDNA assay required unexpected De Novo reclassification and took 18 months to clear, forcing emergency Series B at a lower valuation.

### 2.4.E Root Cause

The plan treats Pre-Submission feedback as confirmatory rather than exploratory. No historical predicate device search has been done. The team likely expects a narrow immunoassay 510(k) (like i-STAT or Cobas) but a broad multiplex claim, coupled with novel cartridge fluidics, triggers De Novo review pathway rules. Cost and timeline for De Novo (USD 2-4M, 12-18 months) are acknowledged in the pre-project assessment but not integrated into the Series A cap or milestone calendar.

## 2.5.A Issue - Analyte-cluster cross-reactivity and sample-volume feasibility are not validated before Month 6 (2027-04-13) gate; risk of late design failure is high.

The plan identifies 10-15 analytes for Cluster 1 but does not specify which analytes or whether they have been screened for cross-reactivity compatibility. The estimated 8-16 analyte budget per drop is not tied to Cluster 1 definition. Cross-reactivity studies are planned for 'Month 6 (2027-04-13) gate', but the gate criterion is stated passively ('<=5% bias at 10x interferent') without specifying which interferents, which analytes are at high risk (e.g., kidney biomarkers in hemolyzed samples, cardiac troponins vs hematologic proteins), or what happens if 3-4 analytes fail and must be removed post-Month 6 (2027-04-13). If Cluster 1 is redefined after Month 6 (2027-04-13), clinical-study sample size, design and protocol become invalid; re-enrollment delays the Month 12 (2027-10-13) gate by 3-6 months and costs USD 300-500k.

### 2.5.B Tags

- analyte-selection
- cross-reactivity-risk
- sample-volume-constraint
- clinical-study-delay

### 2.5.C Mitigation

By Month 2 (2026-12-13): define Cluster 1 analytes explicitly (10-15 names, clinical rationale for each, reference method for each). By Month 2 (2026-12-13): execute a rapid cross-reactivity screening (0.5-1 month, USD 20-40k) in spiked plasma: measure each analyte alone, then in pairs with the highest-risk interferents (hemoglobin, bilirubin, rheumatoid factor, lipemia) at 5-10x pathologic concentration. Document pass/fail for each pair. By Month 3 (2027-01-13): if any analyte-pair fails, reformulate the assay or remove the analyte. Lock Cluster 1 analyte set and cross-reactivity matrix by Month 3 (2027-01-13) before clinical-protocol writing. This bounds the Month 6 (2027-04-13) gate to confirmation of full-plex cross-reactivity, not discovery of fundamental incompatibilities.

### 2.5.D Consequence

If cross-reactivity discovery is deferred to Month 6-9 (2027-04-13 to 2027-07-13) and incompatibilities are found, Cluster 1 must be redesigned: reformulation costs USD 30-50k, retest USD 20-40k, and clinical-protocol revision adds 2-3 months. Enrollment delay pushes Month 12 (2027-10-13) gate to Month 15-18 (2028-01-13 to 2028-04-13), compressed with design-freeze milestones, forcing either a late design freeze (risk of incomplete validation) or a 6-month slip. Historical: Illumina's Helio assay discovered hemoglobin interference in Month 18 (2028-04-13) after enrollment began, requiring assay reformulation and 10-month protocol amendment cycle.

### 2.5.E Root Cause

The team has not locked the Cluster 1 analyte list or completed a preliminary cross-reactivity matrix. Decision 1 (Assay Panel Architecture) states that 'no option makes all 500 analytes simultaneously feasible', but the plan does not surface which 10-15 analytes were selected, why those analytes are compatible, or which 400+ analytes are deprioritized. The sample-volume estimate (8-16 per drop) is an order-of-magnitude proxy, not a measured constraint. Clinical-study design cannot begin until the analyte set is locked and cross-reactivity is bounded.

## 2.6.A Issue - Clinical study design is not aligned with regulatory expectations; sample size, primary endpoints and De Novo vs 510(k) evidence strategy are undefined.

The plan allocates USD 2-4M for a clinical study (Months 12-36 = 2027-10-13 to 2029-10-13) with 300-500 subjects but does not specify: (1) primary endpoints (concordance vs reference method? clinical utility in a disease cohort? patient-relevant outcomes like treatment changes?), (2) sample-size justification (non-inferiority margin, power, comparator method), (3) reference-method selection (lab reference? other IVD? clinical outcome?), (4) De Novo-specific requirements (if required, study must show clinical utility; if 510(k), analytical equivalence may suffice). FDA expects these elements in Pre-Submission feedback (Month 6 = 2027-04-13), but the study design is not drafted before Month 6 (2027-04-13). If FDA feedback diverges from the plan (e.g., 'clinical utility required' for De Novo or 'larger sample size needed'), the study must be redesigned, delayed and re-sized, costing USD 500k-1M and 3-6 months.

### 2.6.B Tags

- clinical-study-design
- sample-size-undefined
- endpoints-undefined
- de-novo-evidence-gap

### 2.6.C Mitigation

By Month 1 (2026-11-13): engage a clinical-trial design firm or academic partner with FDA submission experience (budget USD 50-100k). By Month 2 (2026-12-13): draft two clinical-study protocols in parallel: Protocol A (assuming 510(k), analytical concordance focus, 200-300 subjects, reference method comparison) and Protocol B (assuming De Novo, clinical-utility focus, 400-500 subjects, patient outcome or triage validation). By Month 5 (2027-03-13): register both protocols on ClinicalTrials.gov with pre-specified endpoints and statistical analysis plans. By Month 6 (2027-04-13) Pre-Submission, present both protocols to FDA; lock the protocol that aligns with FDA feedback and activate that study immediately. This prevents Month 18-24 (2028-04-13 to 2028-10-13) rework if study design is misaligned.

### 2.6.D Consequence

If study design is not locked until Month 12 (2027-10-13) or later, and FDA Pre-Submission feedback requires protocol changes, enrollment delay of 3-6 months is typical (data-safety monitoring board review, IRB amendment cycle, site activation delay). This compresses Month 12 (2027-10-13) and Month 18 (2028-04-13 and 2028-04-13) gates, forcing either truncated data at the gates (unacceptable for release decisions) or a 6-month slip of the entire timeline. Regulatory clearance shifts from Month 36-48 (2029-10-13 to 2030-10-13) to Months 42-54 (2030-04-13 to 2031-04-13), extending Series B runway need by USD 2-3M and increasing total cumulative burn to USD 18-35M.

### 2.6.E Root Cause

The plan treats the clinical study as a post-Month 12 (2027-10-13) activity after Cluster 1 analytical feasibility is proven, but regulatory strategy (510(k) vs De Novo) and study design must be co-developed with FDA input by Month 6 (2027-04-13). The plan's pre-project assessment states 'clinical-study statistical design' should align with regulatory submissions, but no statistical design or FDA alignment mechanism exists in the project plan. The team has not defined which clinical use case (screening, diagnosis, monitoring, triage) Cluster 1 addresses, which drives the study design and evidence burden.

---

# 3 Expert: Clinical Diagnostics Validation and Evidence Generation Lead

**Knowledge**: In vitro diagnostics (IVD) method-comparison studies, analytical and clinical validation, assay accuracy and precision, cross-reactivity and interference testing, pre-clinical and clinical study design, payer evidence requirements, publication strategy

**Why**: The Evidence Generation and Transparency decision (Decision 7) and the clinical-study plan (300-500 subjects, analytical concordance >=95%, cost USD 2-4M over Months 12-36 = 2027-10-13 to 2029-10-13) require expert oversight of study protocol design, statistical power, analyte-by-analyte validation and publication to build credibility with clinicians, payers and regulators. This expert bridges the gate criteria (Month 6 = 2027-04-13 plasma separation, Month 12 = 2027-10-13 yield and concordance, Month 18 = 2028-04-13 clinical interim) to the FDA submission package and payer coverage evidence.

**What**: Design and execute the pre-registered, blinded method-comparison study protocol by Month 6 (2027-04-13), specifying sample size, reference methods, primary endpoints (concordance >=95%, CV <10%), analyte-level acceptance criteria, and publication timeline; initiate enrollment by Month 12 (2027-10-13) and publish Quarterly Analyte Performance Reports including failures by Month 6 (2027-04-13) onwards.

**Skills**: Method-comparison study design, statistical analysis and power calculations, assay analytical validation, cross-reactivity and interference testing, pre-clinical to clinical transition, clinical-utility studies, publication and medical writing, payer evidence synthesis

**Search**: diagnostics validation scientist method comparison studies, IVD assay clinical validation, multiplex immunoassay validation, payer evidence generation

## 3.1 Primary Actions

- By Month 1 (2026-11-13 at 10:00): Hire a senior FDA regulatory consultant (10+ years CDRH, USD 150-250k contract). Prepare and submit FDA Pre-Submission Type B meeting request immediately; target hold date Month 4-5 (2027-02-13 to 2027-03-13), not Month 6 (2027-04-13). Document three critical regulatory questions: 510(k) vs. De Novo, clinical evidence requirements, acceptability of a tiered per-cluster strategy.
- By Month 2 (2026-12-13 at 09:00): Define Cluster 1 as exactly 10-15 analytes with documented clinical rationale and low known cross-reactivity risk. Commission an independent cross-reactivity feasibility study (external lab, USD 150-250k, 8 weeks): measure plasma separation ≥95%, full matrix at 10× interferent, cartridge metering tolerance. Do not sign binding supplier or molding contracts until results are in.
- By Month 2 (2026-12-13 at 11:00): Develop a 60-month detailed cash-flow model with gate-linked tranches: Seed USD 2-3M, Series A Tranche 1 USD 3-4M (upon Pre-Submission + pharma contracts), Tranche 2 USD 2-3M (Month 12 = 2027-10-13 analytical gate), Tranche 3 USD 2-3M (Month 18 = 2028-04-13 design freeze). Document gate criteria (yield ≥85%, concordance ≥95%, lot CV <10%, COGS ≤USD 25) in writing with board sign-off authority. Lock a Fallback V1 (50-analyte core) activation trigger: if any gate at Months 12 or 18 (2027-10-13, 2028-04-13) fails, activate within 5 business days (no board negotiation).
- By Month 3 (2027-01-13 at 10:00): Hire or contract a reimbursement/payer strategist. Conduct 10-15 payer interviews and 5 health system pilot engagements to validate net-revenue floor (proposed minimum USD 150 per run) and identify which coding/contracting model is credible (bundled panel, value-based, self-pay, or single-analyte CPT codes). Document findings and model three unit-economics scenarios. If any scenario projects <USD 100 per run, activate the lean-pivot trigger immediately (reduce cartridge scope or panel complexity).
- By Month 3 (2027-01-13 at 14:00): Define the phased Newark strategy in writing: Phase 1 (Months 3-12 = 2027-01-13 to 2027-10-13) rents 2,000 sq ft for reagent formulation and lot-release lab (USD 500-800k capex); Phase 2 (Months 12-15 = 2027-10-13 to 2028-01-13, only if analytical gate passes) expands to 3,000-4,000 sq ft for pilot fill-line (USD 2-3M capex). Do not issue binding long-lead orders or mold tooling deposits before Month 18 (2028-04-13) design freeze. Conduct Design-for-Manufacturability review with ≥2 contract molders and filling-equipment vendor by Month 6 (2027-04-13).
- By Month 6 (2027-04-13 at 10:00): Gate decision on analytical feasibility: cross-reactivity matrix complete, drop-volume/plasma-separation data in hand, COGS ceiling locked (USD 25 per cartridge). If any threshold is failed, reformulate (2-week cycle) or remove analyte from Cluster 1 and document for FDA. Do not release Series A Tranche 2 capital or commit Newark Phase 2 until gate is passed. Hold FDA Pre-Submission meeting and document feedback on regulatory pathway (510(k) vs. De Novo) and clinical-study design.
- By Month 1 (2026-11-13 at 11:00): Establish ISO 13485 quality system and design controls from Day 1: hire quality/regulatory director (10+ years IVD), maintain a Design History File with all design decisions, implement formal change-control process. Prepare a Design Control and Quality Management Charter in writing. Do not treat quality as post-design; it is a core design constraint from Month 0 (2026-10-13). Establish an external scientific advisory board (5-7 members) with quarterly public meetings and raw-data audit access.
- By Month 2 (2026-12-13 at 15:00): Publicly commit to a 'Science-First' transparency charter: all analyte performance data (accuracy, precision, cross-reactivity, failures) published monthly in a public dashboard. Register the clinical-study protocol on ClinicalTrials.gov before enrollment; pre-register analyte-level success criteria. By Month 6 (2027-04-13), publish the first Quarterly Analyte Performance Report, including failures with root-cause analysis. This differentiates against Theranos-era skepticism and satisfies FDA expectations.
- By Month 4 (2027-02-13 at 10:00): Conduct critical-supplier risk assessment for Cluster 1: map all suppliers (≥2 molders, ≥1 reagent supplier per analyte, ≥2 for top 5 high-risk analytes). By Month 6 (2027-04-13), qualify and contract ≥2 molders and ≥2 reagent suppliers for top 10 analytes; execute binding quality agreements specifying defect rate <5%, yield >90%, 90-day capacity commitments, 3-year price locks. By Month 9 (2027-07-13), execute a pilot fill of 1,000-5,000 cartridges using production-equivalent processes; measure first-pass yield (target ≥85%, acceptance ≥80%).

## 3.2 Secondary Actions

- By Month 3 (2027-01-13): Model the CLIA lab-service fallback route in detail: cost per sample, revenue per panel, staffing (pathologist, technicians), CLIA certification timeline (~6 months), regulatory path (if applicable). Define the trigger for activation (e.g., if device-pathway funding stalls, or if De Novo is confirmed and Series B funding is not secured). Staff a small CLIA leadership team by Month 6 (2027-04-13) so the fallback can launch at Month 12 (2027-10-13) if needed.
- By Month 3 (2027-01-13): Define the primary clinical use case for Cluster 1 (e.g., drug-development biomarker monitoring, cardiovascular risk screening, diabetes management) with documented medical rationale and payer pathway. Secure a pharma sponsor partner or health system for the first paid contract by Month 9 (2027-07-13) (target USD 50-100k feasibility study, 1,000 samples). Use real-world data to inform Clusters 2-5 scope.
- By Month 5 (2027-03-13): Begin SBIR/STTR and grant applications (NIH Phase I/II, NSF, state innovation programs). Target USD 500k-1M cumulative by Month 12 (2027-10-13) to reduce equity dilution and strengthen regulatory credibility.
- By Month 6 (2027-04-13): Conduct a mock FDA inspection (simulated by an external consultant or retired inspector) to identify quality-system gaps and design-control documentation shortfalls before the real pre-approval inspection (estimated Months 28-30 = 2029-02-13 to 2029-04-13). Establish a priority list of remediation actions with owners and due dates.
- By Month 9 (2027-07-13): Finalize the clinical-study protocol for method-comparison validation (sample size 300-500, power analysis, primary endpoints: concordance ≥95% lower CI ≥93%, lot CV <10%). Register on ClinicalTrials.gov. Begin enrollment by Month 12 (2027-10-13). Budget USD 2-4M over Months 12-36 (2027-10-13 to 2029-10-13) for study execution and publication.
- By Month 12 (2027-10-13): Conduct a formal funding and timeline reconciliation meeting with the board: review burn to date, month-by-month cash balance forecast, timing of pharma/grant revenue, and assess whether Series A Tranche 2 release is sustainable or whether a Series A extension or earlier Series B is needed. Model the De Novo scenario's impact on funding and adjust tranches accordingly.
- By Month 15 (2028-01-13): Assess shelf-life data using Arrhenius modeling (target R² >0.90); if projected shelf-life is ≥12 months, proceed to Month 18 (2028-04-13) design freeze. If 9-12 months, conduct retest; if <9 months, trigger reformulation and delay 3 months.
- By Month 18 (2028-04-13): Lock lead-cluster design, achieve ISO 13485 certification, demonstrate pilot-scale yields ≥85%, and issue binding long-lead orders for molding tooling and filling equipment. Establish a monthly supplier performance scorecard with escalation if defect rate exceeds 10% for two consecutive months.
- By Month 24 (2028-10-13): Publish the clinical method-comparison data (confidential to the company, FDA, and study site until pre-publication agreement is met with FDA at Month 27-30 = 2029-01-13 to 2029-04-13). Prepare for first FDA submission by Month 30 (2029-04-13). Conduct quarterly analyte-performance and transparency reports throughout (public dashboard and advisory board review).
- By Month 30 (2029-04-13): Submit the first 510(k) (if pathway confirmed) or prepare comprehensive De Novo dossier. Include Cluster 1 clinical data, ISO 13485 certification summary, design controls, shelf-life data, and manufacturing information (supplier agreements, process controls, quality system). Target clearance decision by Months 36-42 (2029-10-13 to 2030-04-13) for 510(k) or Months 48-54 (2030-10-13 to 2031-04-13) for De Novo.

## 3.3 Follow Up Consultation

In the next consultation (Month 1-3, 2026-11-13 to 2027-01-13), confirm: (1) FDA Pre-Submission meeting is scheduled for Month 4-5 (2027-02-13 to 2027-03-13) and regulatory consultant is engaged; (2) Cluster 1 analytes are finalized and cross-reactivity study is underway; (3) Seed funding is secured and Series A tranches are modeled for both 510(k) and De Novo scenarios; (4) Payer interviews are underway and reimbursement strategy is being tested; (5) ISO 13485 quality director is hired and design controls are documented; (6) CLIA fallback is outlined with cost and revenue estimates. By Month 6 (2027-04-13), review gate results (analytical feasibility, regulatory feedback, payer validation), board approval of tranche release, and Series A Tranche 1 commitment. Discuss any gate failures or ambiguous results and confirm fallback activation authority and timing.

## 3.4.A Issue - Unresolved unit economics and reimbursement strategy create silent death risk

The plan models USD 100-200 net revenue per run against USD 40-45 COGS per cartridge. A 50-analyte menu requires 4-5 cartridges, yielding USD 160-225 variable cost versus the per-panel revenue cap. This produces negative to 20% gross margin—far below the 60% target required for a sustainable business. No payer model, coding strategy, or price test is documented. The business case assumes volume and price that payer behavior and reimbursement processes have not validated. Without a credible payer-coverage pathway and price validation by Month 6-9 (2027-04-13 to 2027-07-13), the company risks building manufacturing capacity for a product no payer will fund at breakeven volumes.

### 3.4.B Tags

- unit_economics_unproven
- payer_strategy_missing
- price_validation_deferred
- margin_math_broken
- capacity_demand_mismatch

### 3.4.C Mitigation

By Month 3 (2027-01-13), hire a reimbursement/payer strategist and build a detailed unit-economics model with three scenarios: (1) coded analyte bundles with existing CPT codes, (2) value-based contract with a risk-bearing health system, (3) direct-to-consumer wellness (self-pay or employer). By Month 6 (2027-04-13), conduct 10-15 payer interviews and 5 health system pilots to validate which model is credible. Lock a per-run net-revenue floor (e.g., USD 150 minimum) and a COGS ceiling (USD 25 current) by Month 6 (2027-04-13). If payer feedback suggests <USD 100 per run is the floor, activate the lean-pivot trigger immediately and reduce cartridge complexity or panel scope to meet margin targets. Reimbursement is not optional—it determines whether Newark investment makes sense.

### 3.4.D Consequence

Without payer validation, the company builds manufacturing capacity optimized for a phantom market. At Month 30-36 (2029-04-13 to 2029-10-13), when clearance approaches, payer feedback reveals that covered reimbursement is USD 50-75 per run or requires single-analyte coding that fragments the multiplex advantage. The business case collapses, forcing a down round, asset sale, or shutdown. Investors lose 70-90% of their capital. The Newark investment becomes a stranded cost. Estimated impact: USD 10-20M value destruction and 24+ month delay to pivot.

### 3.4.E Root Cause

The plan separates reimbursement strategy from product architecture and manufacturing decisions. It assumes a SMART revenue model (USD 100-200 per run at scale) without evidence. The team has not engaged payers or conducted price validation; reimbursement is treated as a downstream sales problem rather than a core design constraint. This is a classic medtech mistake: building a device first and hoping payers will fund it, rather than designing backward from what payers will pay.

## 3.5.A Issue - Analytical feasibility is assumed, not proven; cross-reactivity and drop-volume budget remain unvalidated before major capital commits

The plan acknowledges that 500 simultaneous analytes per drop are not physically feasible and proposes a modular 10-15 analyte cartridge as the solution. However, the cross-reactivity matrix study for Cluster 1 (the lead cartridge) is not scheduled until Month 3-6 (2027-01-13 to 2027-04-13), and design maturity decisions (Newark phasing, reagent suppliers, molding tooling) are made in parallel without waiting for cross-reactivity results. If cross-reactivity or plasma-separation performance falls short of the proposed ≤5% bias threshold at Month 6 (2027-04-13), the design must be reformed, but suppliers may be locked in and tooling deposits committed. The drop-volume budget (8-16 analytes estimated) is stated as an estimate; no experimental proof is presented for Cluster 1's 10-15 analytes fitting reliably into a fingerstick drop. This leaves a material technical risk unresolved at the gate where capital is released.

### 3.5.B Tags

- analytical_feasibility_unproven
- cross_reactivity_risk
- drop_volume_estimate_unvalidated
- design_before_proof
- gate_criteria_not_meeting_gatekeeper_role

### 3.5.C Mitigation

By Month 2 (2026-12-13), commission an independent analytical feasibility study (budget USD 150-250k, 6-8 week execution, external lab or academic partner) to measure: (1) plasma separation yield and purity for Cluster 1 (target ≥95% of subjects with ≥1.6 µL usable plasma), (2) full cross-reactivity matrix in spiked plasma with hemoglobin, bilirubin, lipemia, rheumatoid factor at 10× physiologic concentration (proposed ≤5% bias acceptance), (3) actual cartridge-level analyte metering accuracy and drop-volume partitioning tolerance across 50 production-scale cartridges. By Month 6 (2027-04-13), gate the analytical feasibility decision: if cross-reactivity or drop-volume data fail to meet thresholds, do not release Phase 1 Newark capital (USD 500-800k) or sign binding supplier contracts. Instead, re-formulate failing assays (2-4 week cycle) and retest (1 retest maximum per analyte). If a second failure occurs or reformulation is infeasible, remove the analyte from Cluster 1 and document the removal for the FDA submission. Do not proceed to molding tooling or supplier commitment until cross-reactivity is locked.

### 3.5.D Consequence

If cross-reactivity or drop-volume issues are discovered after Newark Phase 1 capital is committed or molding tooling is ordered (Months 9-12 = 2027-07-13 to 2027-10-13), the company faces a choice: (1) redesign the cartridge, re-qualify suppliers, and re-tool molds (USD 100-300k, 3-6 months), (2) remove problematic analytes from Cluster 1 and revalidate (6-12 months, impacts clinical credibility), or (3) accelerate to Fallback V1 (50-analyte core), which may lack commercial appeal. Any of these paths delays first commercial sales by 6-12 months and burns USD 500k-2M in wasted capital. Investor confidence in the team's technical judgment erodes. Estimated impact: 12+ month delay, USD 1-3M additional burn, possible Series B funding loss or down round.

### 3.5.E Root Cause

The plan treats analytical feasibility as a design-team certainty and defers proof to Month 6 (2027-04-13) at the same time that capital and supplier commitments are released. This inverts the correct sequence: proof must come before commitment. The 8-16 analyte-per-drop estimate is published without experimental support; the team is designing a cartridge around a number, not a measured constraint. Cross-reactivity is a known hard problem in multiplex immunoassay, yet the plan proposes a light-touch feasibility gate (Month 6 = 2027-04-13, no detailed protocol cited) rather than an early, independent, rigorous study.

## 3.6.A Issue - Regulatory pathway remains uncertain; FDA Pre-Submission is scheduled too late (Month 6 = 2027-04-13 vs. Month 1 = 2026-11-13) and does not model the De Novo fallback or CLIA parallel route adequately

The plan acknowledges that 510(k) clearance is uncertain and De Novo is plausible for a 100+ analyte multiplex device. De Novo adds 12-18 months and USD 2-4M (estimate), moving clearance from Months 36-48 (2029-10-13 to 2030-10-13) to Months 48-66 (2029-10-13 to 2030-10-13 vs. 2030-10-13 to 2032-04-13). The FDA Pre-Submission is not scheduled until Months 2-3 (2026-12-13 to 2027-01-13) with a hold by Month 6 (2027-04-13), but critical funding, hiring, and design decisions (Seed size, Series A timing, Newark phasing, cartridge architecture) must be made or locked by Month 3 (2027-01-13) without FDA feedback. The CLIA lab-service fallback is mentioned but not sized: cost, revenue, timeline, and how it would be staffed or operated are open. The funding model assumes a 510(k) timeline and does not show a credible plan for raising an additional 12-18 months of runway if De Novo is confirmed. This leaves a USD 5-10M funding gap unresolved after Month 24 (2028-10-13) in the De Novo case.

### 3.6.B Tags

- regulatory_uncertainty_unresolved
- pre_submission_too_late
- de_novo_fallback_unfunded
- clia_route_unplanned
- funding_gap_de_novo_scenario
- decision_tree_incomplete

### 3.6.C Mitigation

By Month 1 (2026-11-13), engage a senior FDA regulatory consultant (10+ years CDRH experience, USD 150-250k budget) to prepare a Pre-Submission Type B meeting package immediately (not Months 2-3 = 2026-12-13 to 2027-01-13). Schedule the meeting for Month 4 (2027-02-13) at the latest, holding it by Month 5 (2027-03-13). Ask three critical questions: (1) Is a multiplex immunoassay claiming 100+ simultaneous analytes suitable for 510(k) or does FDA expect De Novo? (2) What is the minimum clinical evidence (sample size, comparator, endpoints) required? (3) Is a tiered strategy acceptable (Cluster 1 first as 510(k), then successive modifications)? By Month 2 (2026-12-13), model two funding and timeline scenarios: 510(k) (clearance Months 36-48 = 2029-10-13 to 2030-10-13) and De Novo (clearance Months 48-66 = 2030-10-13 to 2032-04-13). If De Novo is likely, size Series B to cover an additional 12-18 months (estimated USD 5-10M) and include De Novo costs (USD 1-2M) in the plan. By Month 3 (2027-01-13), define the CLIA lab-service route as a documented contingency: cost per sample, revenue per panel, staffing, regulatory path (CLIA certification timeline ~6 months), and trigger for activation (e.g., if device-pathway funding stalls). Do not release Series A tranches until FDA Pre-Submission feedback is documented and incorporated into the regulatory and funding plan.

### 3.6.D Consequence

If De Novo is confirmed at Month 6 (2027-04-13) without prior planning, the company faces a 12-18 month clearance delay and a USD 5-10M funding gap. Series A investors expected clearance at Months 36-48 (2029-10-13 to 2030-10-13); a De Novo timeline of Months 48-66 (2030-10-13 to 2032-04-13) is a 24-month slip. The company must raise an unplanned Series B at a discounted valuation to cover the delay (estimated impact: 30-50% valuation dilution, USD 5-10M capital at risk). The team's credibility with investors suffers; founders may face pressure to pivot to the CLIA route (revenue sooner, but off-device measurement that abandons the product vision). Alternatively, the company runs out of cash and fails to reach clearance. Estimated impact: 24-month delay, 30-50% investor dilution, possible failure to reach product launch.

### 3.6.E Root Cause

The plan separates regulatory certainty from funding and design decisions. Pre-Submission is treated as a formality, not a dependency gate. The De Novo scenario is acknowledged but not planned (no funding model, no timeline contingency). The CLIA route is mentioned as a fallback but has no cost, revenue, or operational plan. This reflects a common pattern in medtech startups: regulatory uncertainty is documented in risk assessments but not integrated into decision logic or funding models. The correct sequence is: (1) confirm regulatory pathway first (Month 1-3 = 2026-11-13 to 2027-01-13), (2) size funding for the confirmed pathway, (3) design and execute development aligned with the pathway.

---

# 4 Expert: Manufacturing Engineering and Scale-Up Operations Lead (Newark Facility Build)

**Knowledge**: Medical-device manufacturing, GMP and ISO 13485 quality systems, cartridge assembly and filling processes, reagent formulation and stability, facility design and operations, yield improvement and statistical process control, supplier quality and dual sourcing, equipment procurement and installation

**Why**: The Newark Manufacturing Build-Out Timing decision (Decision 3) phases the facility commitment to track demonstrated yield and design maturity, with Phase 1 (USD 500-800k reagent formulation and pilot-fill lab, Months 3-6 = 2027-01-13 to 2027-04-13) and Phase 2 (USD 2-3M filling line, released Month 18 = 2028-04-13 after design freeze). A manufacturing operations expert is essential to execute the phased investment, manage the pilot yield gate (>=85% at Month 12 = 2027-10-13), oversee design-for-manufacturability with contract molders, and establish ISO 13485 and quality controls from Month 1 (2026-11-13) to prevent FDA inspection delays.

**What**: Lead the Phase 1 Newark facility ramp (reagent formulation lab, pilot-fill capability, lot-release QC) by Month 6 (2027-04-13), conduct a pilot fill of 1,000-5,000 cartridges at Month 9 (2027-07-13) to measure first-pass yield (target >=85%), establish supplier quality agreements and dual-sourcing by Month 6 (2027-04-13), and prepare the Phase 2 long-lead equipment orders (quotes by Month 3 = 2027-01-13, binding orders only at Month 18 = 2028-04-13 after design freeze).

**Skills**: GMP and ISO 13485 facility design and compliance, cartridge filling and assembly process engineering, reagent formulation and stability protocol, yield improvement and DOE, supplier quality management and dual sourcing, equipment selection and procurement, statistical process control, regulatory inspection readiness

**Search**: manufacturing operations medical device cartridge filling, GMP facility design diagnostics, ISO 13485 quality systems, reagent stability manufacturing

## 4.1 Primary Actions

- By Month 1 (2026-11-13), formally approve and document: (1) 'Credibility First' charter prohibiting any '500 simultaneous tests per drop' or '500 per run' language in external communications; (2) Fallback Panel V1 (50-analyte core) scope and activation trigger; (3) board decision authority for tranche release tied to gate criteria. Assign a Chief Compliance Officer or quality lead to audit all public materials monthly against the charter.
- By Month 2 (2026-12-13), resolve Seed funding shortfall by increasing Seed to USD 4–5M and securing Series A1 pre-commitment (USD 3–4M, held in escrow pending Month 6 = 2027-04-13 gate), or defer Phase 1 Newark and reduce Month 0–6 (2026-10-13 to 2027-04-13) commitments to USD 1–1.5M and target USD 500k in non-dilutive grants by Month 4 (2027-02-13). Document the board's decision and CFO's authority to execute tranches within 2 weeks of gate closure.
- By Month 2 (2026-12-13), hire or onboard full-time quality/regulatory lead (10+ years IVD, FDA experience) as co-founder or Month 1 (2026-11-13) employee; assign them authority over all design changes and QMS governance. By Month 1 (2026-11-13), simultaneously hire or contract R&D director and initiate FDA Pre-Submission preparation.
- By Month 3 (2027-01-13), hire a Commercial/Payer Lead and complete a unit-economics model: define 3 net-revenue scenarios (USD 50–100, USD 100–150, USD 150–200 per 50-analyte panel), contact 5–10 payers/health systems for coverage appetite, and estimate breakeven volume. Lock a base-case net-revenue assumption by Month 6 (2027-04-13) and tie Newark Phase 2 capital release to achieving minimum volume commitment from payors or pharma.
- By Month 6 (2027-04-13), hold FDA Pre-Submission meeting with written feedback on 510(k) vs. De Novo pathway and clinical-study design alignment; establish quantitative gate criteria for Months 6, 12, and 18 (2027-04-13, 2027-10-13, 2028-04-13) in writing and present board vote outcomes within 5 business days of gate closure.
- By Month 3 (2027-01-13), define Cluster 1 scope (10–15 analytes with lowest cross-reactivity risk) and design a complete cross-reactivity study protocol (spiked plasma with hemolysis, bilirubin, lipemia, rheumatoid factor at 10× physiologic levels); complete cross-reactivity matrix by Month 6 (2027-04-13) or remove failing analytes permanently from Cluster 1.
- By Month 2 (2026-12-13), establish ISO 13485 design controls and QMS live, including Design History File, change-control log, and risk management. Conduct internal audit at Month 6 (2027-04-13) and file ISO 13485 registration by Month 12 (2027-10-13).

## 4.2 Secondary Actions

- By Month 4 (2027-02-13), perform critical-supplier risk assessment and qualify dual-source molders and reagent suppliers for top 10 analytes; execute binding quality agreements with price-lock and defect-rate thresholds (<5% defect, >90% yield).
- By Month 9 (2027-07-13), execute pilot-scale fill (1,000–5,000 cartridges) at contract manufacturer or Phase 1 Newark lab using production-equivalent processes; measure first-pass yield (target ≥85%, acceptance ≥80%). If yield <80%, pause Phase 2 Newark and conduct 4-week design review, re-pilot by Month 12 (2027-10-13).
- By Month 1 (2026-11-13), establish external scientific advisory board (5–7 members, academia + diagnostics industry) with quarterly public meetings and audit access to raw data; publish first quarterly analyte-performance report (including failures) by Month 6 (2027-04-13).
- By Month 5 (2027-03-13), initiate SBIR/STTR and non-dilutive grant applications; target USD 1–2M cumulative by Month 12 (2027-10-13) to reduce dilution and strengthen validation credibility.
- By Month 6 (2027-04-13), lock per-cartridge COGS ceiling (USD 25 modeled at 10k/month) and test payer coverage scenarios; establish supply-chain continuity plan (4–6 week buffer inventory of critical reagents, USD 20–30k cost).
- By Month 12 (2027-10-13), prepare CLIA lab-service route staffing and process design (sample collection, stabilization, transport, off-device measurement if needed); document cost and revenue model for this fallback.
- By Month 15 (2028-01-13), conduct mock FDA inspection at the Newark Phase 1 facility to identify and close design-control and quality-documentation gaps; address all Observations within 60 days before Month 18 (2028-04-13) gate.

## 4.3 Follow Up Consultation

At next consultation, review: (1) Funding committed and board decision authority documented; (2) FDA Pre-Submission feedback and regulatory pathway confirmed (510(k) vs. De Novo); (3) unit-economics model and payer-coverage feedback; (4) Cluster 1 analyte scope and cross-reactivity study protocol; (5) ISO 13485 QMS and design controls live; (6) supply-chain risk assessment and dual sourcing. Discuss contingency: if Series A is delayed beyond Month 6 (2027-04-13), activate CLIA lab fallback and defer Newark Phase 2. If De Novo is likely, model extended timeline and Series B sizing impact.

## 4.4.A Issue - Critical Disconnect: 500-Test Headline vs. Physical Reality Not Adequately Surfaced in Plan

The strategic documents acknowledge that 500 simultaneous tests per drop is 'not physically feasible at clinical-grade accuracy' and estimate only 8–16 analytes per drop are achievable. Yet the project plan still leads with '500 complex health tests from a single drop' as the goal statement, and the 'no 500-test claim' rule is buried in decisions rather than front-and-center in communications and investor pitch. This invites over-claiming risk and reputational damage given precedent failures (including one in Newark). The cumulative-menu framing is correct but must be the non-negotiable product story from Month 0 (2026-10-13), not a post-hoc retreat.

### 4.4.B Tags

- over-claiming-risk
- headline-credibility
- investor-narrative-misalignment
- regulatory-scrutiny-exposure

### 4.4.C Mitigation

By Month 1 (2026-11-13), revise all external communications (pitch deck, SEC filings, investor updates, FDA pre-sub package) to lead with 'cumulative modular menu of validated analyte clusters, targeting 500 tests across multiple cartridges over time' and quantify 'approximately 10–15 analytes per cartridge, about 8–16 per fingerstick drop.' Board must formally approve a 'Credibility First' charter stating no '500 per drop' or '500 simultaneous' language ever appears in marketing or investor materials. Appoint a compliance monitor (quality/regulatory lead) to audit all public communications monthly. This shifts the narrative from an unproven moonshot to a disciplined, phased validation program—far more credible to FDA, payers and repeat investors.

### 4.4.D Consequence

Without explicit reframing, the company risks losing institutional investor confidence at Series A if 'physical infeasibility' is discovered through due diligence or FDA Pre-Submission. Payers and clinicians may discount results if the product is perceived as another failed single-drop claim. Regulatory review could be delayed if FDA sees overclaiming in pre-sub materials. Estimated reputational and valuation impact: 20–30% discount or investor rejection, and 2–4 month regulatory delay.

### 4.4.E Root Cause

The strategic documents were written to explore many paths, so the 'Pragmatic Foundation' path's constraints (modular, cumulative, phased) were documented as design choices rather than immutable product truths. The project plan then inherited the original '500 tests' headline without translating it into the realistic phased language. No single owner was assigned credibility and messaging authority.

## 4.5.A Issue - Seed Funding Shortfall vs. Month 0–6 (2026-10-13 to 2027-04-13) Commitments Not Resolved; Series A Gate Timing and Size Underdefined

The plan estimates Month 0–6 (2026-10-13 to 2027-04-13) non-payroll commitments at USD 2.0–3.6M (facility lease, early regulatory consulting, equipment quotes, preclinical studies) against a Seed round of USD 2–3M. This leaves no payroll buffer for core hires (R&D director, QA/regulatory lead, assay scientists) and assumes Seed closes immediately at Month 0 (2026-10-13), which is unrealistic for a medical-device startup. Additionally, Series A Tranche 1 (USD 3–4M) is tied to Pre-Submission completion at Month 6 (2027-04-13), but the plan does not specify how months 0–6 (2026-10-13 to 2027-04-13) payroll and infrastructure are funded if Seed closes late (Month 2–3 = 2026-12-13 to 2027-01-13) or the market demands a larger Seed. The gate-release tranches (A1, A2, A3) are proposed but not tied to board-approved go/no-go decision authority.

### 4.5.B Tags

- funding-runway-gap
- seed-series-a-timing-mismatch
- gate-decision-authority-undefined
- payroll-and-commitment-overlap

### 4.5.C Mitigation

By Month 2 (2026-12-13), resolve one of three paths: (A) increase Seed to USD 4–5M to cover Months 0–9 (2026-10-13 to 2027-07-13) payroll and commitments independently of Series A timing, and use Seed to hire Month 1 (2026-11-13) core team without dilution risk; (B) structure a Seed of USD 2–3M plus a pre-committed Series A1 of USD 3–4M signed at Seed closing, with A1 capital held in escrow and released at Month 6 (2027-04-13) gate, reducing execution risk; or (C) defer Phase 1 Newark capital (USD 500–800k) to Month 6 (2027-04-13), reduce Month 0–6 (2026-10-13 to 2027-04-13) commitments to USD 1–1.5M, and pad Seed with non-dilutive SBIR/STTR grants (USD 500k target by Month 4 = 2027-02-13). Document the chosen path and the board's authority to release each tranche within 2 weeks of gate closure. Without this, the company will either run out of runway before Month 6 (2027-04-13) or defer Seed/A1 closing and miss Month 6 (2027-04-13) gate milestones, cascading delays downstream.

### 4.5.D Consequence

If Seed is undersized and closes late, the company cannot hire the quality/regulatory lead and R&D director by Month 1 (2026-11-13), delaying FDA Pre-Submission preparation and ISO 13485 QMS launch by 2–3 months. Each month of delay in design controls and regulatory alignment costs USD 100–200k in burn and pushes all downstream gates. If Series A gate release is not pre-authorized, the board may hesitate to release tranches on schedule, forcing a down round or emergency financing. Estimated impact: 3–6 month regulatory delay, USD 200–500k unexpected dilution, and Series A closing delayed to Month 9 (2027-07-13) or later.

### 4.5.E Root Cause

Funding sections of the plan use 'proposed thresholds' and 'estimates' without stating decision ownership or commitment authority. No single CFO or board designate owns the tranche-release decision and the power to execute immediately when a gate is met. Seed sizing was anchored to a rough estimate (USD 2–3M) without modeling Month 0–6 (2026-10-13 to 2027-04-13) actual burn, which includes both payroll and capex commitments.

## 4.6.A Issue - Unit Economics and Revenue Model Severely Underdeveloped; Payer Coverage and Pricing Strategy Missing, Driving Uncertainty in Scale-Up Justification

The plan assumes USD 100–200 per run net revenue (base case), with a COGS ceiling of USD 25 per cartridge, implying gross margin of 50–75% at scale. However, multi-cartridge bundles (4–5 runs for a 50-analyte menu) cost USD 160–225 in variable cost versus USD 100–200 per-panel net revenue, yielding negative to 20% margin if priced as a bundle. The plan does not specify whether customers pay per-run or per-panel, whether payers will code and cover a multiplex bundle, or what the actual addressable market size is at any price point. Breakeven volume is estimated at 2–11k cartridges/month, but the plan targets 10k/month by Month 36 (2029-10-13) without demonstrating demand or pricing credibility. The CLIA lab-service fallback is mentioned but has no cost or revenue model. Without payer engagement and a pricing road map by Month 6–9 (2027-04-13 to 2027-07-13), the company cannot validate whether 10k/month capacity is oversized, right-sized or undersized, making Newark phased investment decisions speculative.

### 4.6.B Tags

- unit-economics-misalignment
- payer-coverage-undefined
- pricing-strategy-missing
- capacity-planning-demand-driven-forecast-absent

### 4.6.C Mitigation

By Month 3 (2027-01-13), establish a Commercial/Payer Lead role (hire or advise) and commission a pricing and payer-coverage model: (1) Model 3 pricing scenarios—per-run (USD 50–100 each), per-50-analyte panel bundled (USD 200–400 total), or value-based per-patient annually; (2) contact 5–10 major health systems, reference labs, and payers (Anthem, Aetna, UnitedHealth) by Month 4 (2027-02-13) to assess coverage appetite and precedent for multiplex bundles; (3) by Month 6 (2027-04-13), lock a target net-revenue assumption (USD 100–150 per panel is a realistic base case for a bundled 50-analyte offering) and publish a breakeven volume curve; (4) by Month 9 (2027-07-13), execute a pricing-strategy board memo tying net revenue per panel, COGS per cartridge, and allowable volume to a phase-out of Newark scaling—e.g., if net revenue drops below USD 80 per panel, cap Newark at 2–3k cartridges/month and pivot to contract manufacturing. Without this, the Phase 2 filling-line investment (USD 2–3M) is justified by optimistic volume assumptions, not customer and payer reality.

### 4.6.D Consequence

If payer coverage is delayed or denied (plausible for an unproven multiplex bundle), net revenue could fall to USD 50–80 per panel, pushing gross margin negative even at high volumes. The company would then be forced to cut Newark capacity investments by Month 12–15 (2027-10-13 to 2028-01-13), stranding Phase 1 capex (USD 500–800k) as sunk cost and delaying profitability by 2–3 years. Alternatively, if demand is lower than anticipated, 10k cartridges/month capacity becomes a liability—excess overhead and inventory carrying cost. Estimated impact: USD 3–5M in stranded Newark capex if pricing is wrong, or 18–24 month additional runway needed if demand is undersized.

### 4.6.E Root Cause

The plan separates product development from commercial strategy; payer and pricing work are listed as secondary actions or are assigned to Month 6–9 (2027-04-13 to 2027-07-13), after major design and funding decisions are already locked. No revenue model exists that ties COGS, price, and volume together into a feasibility gate. The CLIA fallback is mentioned but not modeled, leaving no 'Plan B' revenue if device clearance is delayed or payer coverage fails.

---

# 5 Expert: IVD Quality Systems and ISO 13485 Compliance Lead

**Knowledge**: ISO 13485 design controls, 21 CFR 820, quality management systems, design history files, change control, risk management (ISO 14971), pre-approval inspection readiness, medical device software (IEC 62304)

**Why**: The Pragmatic Foundation path requires ISO 13485 certification by Month 18 (2028-04-13) and design controls established from Month 1 (2026-11-13), yet the project assessment flags that deferring these systems to design freeze risks 2-4 month FDA inspection delays and USD 300-500k remediation. A senior quality systems expert is essential to build the design history file, change-control process, and risk documentation from inception so the company passes pre-approval inspection on schedule and avoids 483 observations that would delay clearance.

**What**: Establish ISO 13485 framework and design controls charter by Month 2 (2026-12-13); conduct internal audit against FDA requirements by Month 6 (2027-04-13); close major gaps within 4 weeks; lead mock FDA inspection at Months 28-30 (2029-02-13 to 2029-04-13) and prepare certification audit for Month 18 (2028-04-13) completion.

**Skills**: Design control and design history file management, change-control procedures, risk management and FMEA, software validation (IEC 62304), supplier quality agreements, regulatory inspection readiness, gap assessment and remediation planning, quality-metrics dashboards

**Search**: ISO 13485 medical device quality systems consultant, FDA design controls compliance, medical device pre-approval inspection readiness

## 5.1 Primary Actions

- By Month 2 (2026-12-13), establish a written Gate Authority Charter with explicit board sign-off authority over capital tranches, fallback activation triggers, and timeline for gate decisions (pass/fail/ambiguous); pre-register Fallback V1 product definition, regulatory scope, and staffing-cut contingencies to prevent sunk-cost escalation.
- By Month 1 (2026-11-13), hire a quality/regulatory director (10+ years IVD) as co-founder; by Month 2 (2026-12-13), establish a Design Control Charter with Design History File documentation, change-control process, and monthly design reviews; conduct internal ISO 13485 audit by Month 6 (2027-04-13) and achieve certification by Month 18 (2028-04-13) to prevent pre-approval-inspection 483 observations.
- By Month 1 (2026-11-13), finalize Cluster 1 analytes (10–15 with lowest cross-reactivity risk); by Month 2 (2026-12-13), design a comprehensive cross-reactivity matrix study (≥100 subjects, spiked interferents, ≤5% bias acceptance); execute Months 3–6 (2027-01-13 to 2027-04-13) and prepare Analyte Removal Log for FDA to ensure Month 6 (2027-04-13) gate criteria are data-driven, not assumptions.
- By Month 1 (2026-11-13), engage a senior FDA regulatory consultant (USD 150–250k for 6–12 months); by Month 2 (2026-12-13), prepare Pre-Submission Type B package with 3–5 core regulatory questions; schedule and hold meeting by Month 6 (2027-04-13) to confirm 510(k) vs. De Novo pathway and align clinical-study design with FDA expectations to de-risk the longest-pole regulatory milestone.
- By Month 3 (2027-01-13), define phased Newark investment in writing: Phase 1 (Months 3–12 = 2027-01-13 to 2027-10-13) USD 500–800k for 2,000–3,000 sq ft reagent formulation and pilot-scale lot-release lab (no full filling line); Phase 2 (released at Month 18 = 2028-04-13 gate, if feasibility passes) USD 2–3M for filling line; bind no long-lead equipment orders before Month 18 (2028-04-13) design freeze to limit fixed cost exposure around an unfrozen design.

## 5.2 Secondary Actions

- By Month 2 (2026-12-13), develop a 60-month detailed cash-flow model with quarterly burn rates and gate-linked tranches (Seed USD 2–3M Months 0–6 = 2026-10-13 to 2027-04-13, A1 Tranche 1 USD 3–4M at Month 6 = 2027-04-13 gate, A2 USD 2–3M at Month 12 = 2027-10-13, A3 USD 2–3M at Month 18 = 2028-04-13); resolve the Seed shortfall (Months 0–6 = 2026-10-13 to 2027-04-13 non-payroll commitments USD 2.0–3.6M vs. Seed USD 2–3M) by Month 2 (2026-12-13) via larger Seed or earlier A1 timing.
- By Month 1 (2026-11-13), stand up an external scientific advisory board (5–7 members from academia and diagnostics) with quarterly public meetings and audit access to raw data and analyte-removal logs; establish a 'Science-First' public charter committing to monthly transparency dashboard and published-failure disclosure; register clinical-study protocol on ClinicalTrials.gov before enrollment and pre-register analyte-level success criteria.
- By Month 4 (2027-02-13), conduct critical-supplier risk assessment for Cluster 1: map all suppliers (molders, reagent vendors, high-risk analyte providers); by Month 6 (2027-04-13), qualify and contract ≥2 molders and ≥2 reagent suppliers per analyte with binding quality agreements (defect rate <5%, first-pass yield >90%, 90-day capacity commitments, 3-year price locks); establish 4–6 week buffer inventory by Month 9 (2027-07-13) and monthly supplier-performance scorecard.
- By Month 3 (2027-01-13), conduct a Design-for-Manufacturability review with ≥2 contract molders and filling-equipment vendors; by Month 9 (2027-07-13), execute pilot fill of 1,000–5,000 cartridges using production-equivalent processes and measure first-pass yield (target ≥85%, acceptance ≥80%); gate decision at Month 12 (2027-10-13): if yield ≥85% and shelf-life projects ≥12 months, release Phase 2 capital; if yield <80%, conduct 4-week design review and re-pilot.
- By Month 3 (2027-01-13), lock COGS ceiling at USD 25 per cartridge and test payer scenarios (self-pay, coding, value-based) by Month 9 (2027-07-13); model unit economics at projected volumes (10k/month by Month 36, 50k/month for margin testing); if gross margin at 50k/month projects below 50%, flag this to the board and evaluate lean pivot or menu narrowing.
- By Month 6 (2027-04-13), initiate clinical-study planning: define 300–500 subject sample size (decision needed), comparator reference methods, primary endpoints, and enroll-rate assumptions; prepare for enrollment Months 12–18 (2027-10-13 to 2028-04-13) with ≥1 clinical partner site; budget USD 2–4M over Months 12–36 (2027-10-13 to 2029-10-13) for study conduct and analysis.
- By Month 5 (2027-03-13), launch SBIR/STTR grant applications targeting Months 12–15 (2027-10-13 to 2028-01-13) approval (USD 150–400k per grant, 2–3 grants); by Month 3 (2027-01-13), initiate 5–10 pharma sponsor conversations on biomarker feasibility partnerships (unfunded by Month 6 = 2027-04-13, paid by Month 9 = 2027-07-13).

## 5.3 Follow Up Consultation

At the next meeting (target Month 1 end = 2026-11-13), present the Gate Authority Charter, Design Control Charter, and Cluster 1 analyte list with clinical justification for board approval before Series A closes. Review FDA Pre-Submission timeline and confirm whether 510(k) or De Novo is more likely; adjust funding and clearance projections accordingly. Discuss Seed/A1 timing to resolve the identified funding gap. Confirm Phase 1 Newark site and equipment selections. Review scientific-advisory-board charter and transparency commitments. Establish monthly design-control and gate-decision review cadence with the board. Lastly, discuss whether CLIA lab-service fallback should be resource-allocated in parallel to device development, given regulatory and capital uncertainties.

## 5.4.A Issue - Critical: No Quantitative Go/No-Go Gates or Capital Release Authority Defined Before Project Start

The plan states gate criteria at Months 6, 12, 18 (2027-04-13, 2027-10-13, 2028-04-13) but lacks board-voted authority to enforce them or activate Fallback V1 if gates fail. Without pre-committed board sign-off (documented before Month 1 = 2026-11-13 close), sunk-cost escalation will override gate failures: teams will argue 'one more month' to fix yield or concordance, and the company will spend USD 2–10M on unviable analytes. This is the pattern that has killed prior diagnostics ventures. The plan cannot proceed without explicit board resolution assigning capital-release authority and timeline for gate decisions.

### 5.4.B Tags

- governance-vacuum
- sunk-cost-risk
- capital-discipline-missing
- fallback-not-triggered

### 5.4.C Mitigation

By Month 2 (2026-12-13 at 11:00), document a formal Gate Authority Charter: (1) Board authorizes CEO to release each tranche within 2 weeks of gate closure; gate results are pass/fail/ambiguous (ambiguous allows 1–2 week retest). (2) Fallback V1 (50-analyte product) activates automatically if any Month 12 or 18 (2027-10-13, 2028-04-13) gate is failed, with board vote required within 5 business days only to confirm, not to debate. (3) Pre-register fallback product definition, regulatory scope, and staffing cuts (–20–30% headcount, pause Newark Phase 2) in writing before Month 3 (2027-01-13). This enforces capital discipline and prevents drift into extended development.

### 5.4.D Consequence

Without gate authority, failed analytes or yield shortfalls will trigger 'one more round' of funding instead of product pivot. Expected outcome: USD 2–5M wasted on infeasible assays; 12–18 month schedule slip; investor loss of confidence or down round; possible company failure or acquisition at distressed valuation (20–50% markdown).

### 5.4.E Root Cause

The plan acknowledges gates and fallback but does not assign decision rights or pre-commit the trigger conditions. Governance and capital discipline are deferred to 'board conversations' rather than locked in writing before fundraising. This is a fatal omission in a USD 15–30M venture with extreme technical risk.

## 5.5.A Issue - Critical: Design Controls and ISO 13485 Quality System Deferred to Design Freeze (Month 18 = 2028-04-13); FDA Pre-Approval Inspection Will Reveal Immature Documentation

The plan states 'ISO 13485 certification by Month 18 (2028-04-13)' but starts design controls at Month 1 (2026-11-13) as a placeholder. In reality, most teams defer formalization until freeze, which leaves a 12–18 month gap where design changes are not formally documented, risk assessments are incomplete, and traceability is lost. FDA pre-approval inspection (Months 28–30 = 2029-02-13 to 2029-04-13) will encounter a Design History File (DHF) with missing design input/output records, undocumented change justifications, and incomplete verification protocols. This triggers 483 observations and 2–4 month remediation, delaying clearance by Months 36–42 (2029-10-13 to 2030-04-13) to Months 42–48 (2030-04-13 to 2030-10-13). Cost: USD 300–500k rework; investor confidence loss.

### 5.5.B Tags

- quality-system-immaturity
- design-controls-placeholder
- dhf-gaps
- pre-approval-inspection-risk

### 5.5.C Mitigation

Hire a quality/regulatory director at Month 1 (2026-11-13) as a co-founder or full-time employee (10+ years IVD experience). By Month 2 (2026-12-13 at 13:00), establish a written Design Control Charter: (1) All design decisions from Month 0 (2026-10-13) onwards are documented with design inputs (product requirements), design outputs (specifications), formal design reviews (monthly), and design verification (prototypes meet specs). (2) Maintain a Design History File (electronic) with all records; every design change after Month 5 (2027-03-13) requires written justification, risk assessment, and quality sign-off. (3) Conduct an internal ISO 13485 audit by Month 6 (2027-04-13); close major gaps in 4 weeks. By Month 18 (2028-04-13), achieve ISO 13485 certification from an accredited registrar. This embeds quality discipline from the start and ensures a defensible DHF at pre-approval inspection.

### 5.5.D Consequence

Deferred design controls leave a 483-observation gap at pre-approval inspection, forcing 2–4 month remediation and USD 300–500k rework. Clearance delays from Months 36–42 (2029-10-13 to 2030-04-13) to Months 42–48 (2030-04-13 to 2030-10-13). Investors and payers lose confidence in quality maturity. First commercial sales slip from Month 48 (2030-10-13) to Month 54–60 (2031-04-13 to 2031-10-13), extending pre-revenue runway and increasing total burn by USD 3–5M.

### 5.5.E Root Cause

Empty

## 5.6.A Issue - Critical: Analytical Feasibility (Cross-Reactivity, Plasma Separation, Drop-Budget) Is Unproven; Month 6 (2027-04-13) Gate Lacks a Real Feasibility Study

The plan proposes Month 6 (2027-04-13) gate criteria (plasma separation ≥95%, cross-reactivity ≤5% bias at 10× interferent) but provides no study protocol or timeline for executing them. Cross-reactivity testing alone requires ≥100 subject samples, pairwise analyte measurements, and interferent spiking—3–4 months of wet-lab work. If the study is not initiated by Month 1 (2026-11-13), results will not be available until Month 8–9 (2027-06-13 to 2027-07-13), which slips the Month 6 (2027-04-13) gate decision into Month 9 (2027-07-13). This delays Series A1 release, disrupts downstream clinical-study planning, and forces either a late pivot or overdraft. Furthermore, no one has specified which 10–15 analytes comprise Cluster 1; if analytes are selected after Month 2 (2026-12-13), the cross-reactivity study cannot start on schedule.

### 5.6.B Tags

- analytical-feasibility-unproven
- cross-reactivity-timeline-undefined
- plasma-separation-protocol-missing
- month6 (2027-04-13)-gate-misaligned

### 5.6.C Mitigation

By Month 1 (2026-11-13 at 14:00), finalize Cluster 1 analyte selection: 10–15 candidates with established reference methods and lowest known cross-reactivity risk; document clinical rationale for each. By Month 2 (2026-12-13 at 09:00), design a comprehensive cross-reactivity study protocol: ≥100 normal and disease-state subject samples, measure each analyte alone and in full plex using human plasma spiked with hemolysis, lipemia, bilirubin, and rheumatoid factor at 10× physiologic concentration; acceptance criterion ≤5% bias from any interferent. Execute the study Months 3–6 (2027-01-13 to 2027-04-13); if any analyte pair fails, reformulate or remove within 2 weeks. Prepare an Analyte Removal Log for the FDA submission. This front-loads analytical risk and ensures Month 6 (2027-04-13) gate decision is based on real data, not assumptions.

### 5.6.D Consequence

Without a defined feasibility study, Month 6 (2027-04-13) gate criteria cannot be evaluated; the team will defer results to Month 9–10 (2027-07-13 to 2027-08-13), slip Series A1 release by 3 months, and miss downstream clinical-study enrollment dates. If cross-reactivity or plasma-separation issues emerge post-Month 9 (2027-07-13), costly redesign (USD 100–300k, 2–3 months) will be necessary. Alternatively, weak analytes will be carried into clinical validation, increasing later failure risk and wasting USD 1–2M on clinical studies that prove analytes unusable.

### 5.6.E Root Cause

Empty

---

# 6 Expert: Venture Capital and Series Funding Strategy Advisor

**Knowledge**: Medical device and diagnostics venture funding, Series A/B/C raise mechanics, investor value perception, tranche-linked governance, down-round and bridge financing, runway burn modeling, non-dilutive funding (SBIR/STTR), pharma partnership deals

**Why**: The Funding Path and Commercial Beachhead decision (Decision 4) specifies gate-linked tranches (Seed USD 2-3M, A1-A3 USD 2-3M each, Series B USD 3-5M) totaling about USD 12-17M through Month 24 (2028-10-13), with a USD 17-21M gap remaining to clearance. However, Seed commitments (USD 2.0-3.6M non-payroll, Months 0-6 = 2026-10-13 to 2027-04-13) may exceed the Seed raise (USD 2-3M), creating an immediate sizing mismatch. A venture capital advisor is essential to design the actual tranche structure, negotiate with investors on gate release authority, stress-test pharma and grant assumptions, and prepare contingency financing (down-round, bridge, debt) if gates slip.

**What**: Model two scenarios by Month 2 (2026-12-13): Scenario A (gates met on time) with standard A1-A3 releases, and Scenario B (gate slip of 3-6 months) with bridge financing or larger early tranches; present investor-readiness materials for Seed close by Month 1 (2026-11-13) and develop Series A governance docs (gate criteria, board voting, tranche release conditions) by Month 2 (2026-12-13).

**Skills**: Series A/B/C raise planning and materials, investor relations and pitch strategy, term sheet negotiation, gate-linked funding structures, down-round and bridge financing, SBIR/STTR grant strategy, pharma deal structuring and validation partnerships, financial modeling and sensitivity analysis

**Search**: venture capital advisor medical device diagnostics, Series A funding strategy, gate-linked financing, SBIR grants life sciences

## 6.1 Primary Actions

- By Month 1 (2026-11-13), lock a detailed 60-month monthly cash-flow model showing payroll ramp (by role and salary scale), Newark Phase 1 and Phase 2 capex and opex, regulatory and clinical-study spend, equipment purchases, and overhead allocation. Reconcile stated burn (USD 8–12M Months 0–18 = 2026-10-13 to 2028-04-13, estimate) against the tranche schedule (Seed USD 2–3M + A tranches USD 9–10M = USD 11–13M). If burn exceeds capital, either increase Seed to USD 4M and A1 to Month 5 (2027-03-13), or identify USD 2–3M in cost-reduction targets (defer Phase 1 Newark, reduce staff ramp, narrow clinical-study scope). Present the reconciled model to Series A investors as a non-negotiable pre-closing deliverable.
- By Month 6 (2027-04-13), validate unit economics with a bottom-up COGS model at 1k, 10k and 50k cartridges/month for Cluster 1, and a payer/customer willingness-to-pay survey (≥10 labs, clinicians, payers) for a 50-analyte panel. If validated net revenue is <USD 150 per panel, reduce Cluster 1 scope to 8–10 analytes (lower COGS) or revise the gross-margin target downward to ≥40% (more realistic for medtech). Lock the COGS ceiling (USD 25 per cartridge at 10k/month) as a design-gate criterion: any cartridge or reagent option failing to meet the ceiling by Month 12 (2027-10-13) is redesigned or removed from Cluster 1 before clinical enrollment.
- By Month 6 (2027-04-13), hold FDA Pre-Submission with a two-scenario package (510(k) primary, De Novo contingency) and confirm the regulatory pathway in writing. Document FDA feedback and model both timelines in the funding plan: if De Novo is likely, activate a Series B contingency funding plan (USD 3–5M) by Month 15 (2028-01-13) to avoid a capital crisis at Month 18 (2028-04-13). Lock the clinical-study protocol (sample size, comparator methods, endpoints) by Month 9 (2027-07-13) and register on ClinicalTrials.gov before enrollment to ensure alignment with FDA expectations and avoid 12–18 month study redesign delays.
- By Month 2 (2026-12-13), establish written gate criteria and board sign-off authority for each tranche release (Seed, A1, A2, A3). Define quantitative thresholds: yield ≥85% (95% CI ≥80%), concordance ≥95%, lot CV <10%, COGS ≤USD 25 per cartridge. Pre-register Fallback V1 (50-analyte core) with automatic activation if any gate fails at Month 12 or 18 (2027-10-13, 2028-04-13); board must vote to activate within 5 business days, pausing Clusters 2–5 development. This enforces capital discipline and prevents sunk-cost escalation of USD 2–10M into unfeasible analyte architectures.
- By Month 1 (2026-11-13), establish ISO 13485 design controls, quality management system and design history file (DHF) as live, operational systems—not post-hoc documentation. Assign a quality/regulatory director (10+ years IVD experience) authority over all design decisions and change management. By Month 6 (2027-04-13), conduct an internal ISO 13485 audit and close major gaps within 4 weeks. This prevents FDA 483 observations during pre-approval inspection (2–4 month delay, USD 300–500k remediation cost) and ensures the company is inspection-ready by Month 36 (2029-10-13).

## 6.2 Secondary Actions

- By Month 3 (2027-01-13), define Cluster 1 scope explicitly: 10–15 specific analytes with clinical rationale for each, selected for low known cross-reactivity risk and established reference methods. Conduct a comprehensive cross-reactivity matrix study (each analyte alone, in pairs, in full plex) by Month 6 (2027-04-13) using spiked human plasma with hemoglobin, bilirubin, lipemia and rheumatoid factor at 10× physiologic concentration; acceptance criterion ≤5% bias. Remove or reformulate any analyte pair failing the criterion before Month 9 (2027-07-13) enrollment. Prepare an Analyte Removal Log for the FDA 510(k) submission documenting all evaluated but excluded analytes with technical reasons.
- By Month 4 (2027-02-13), perform a critical-supplier risk assessment: map all suppliers (≥2 contract molders, ≥1 reagent supplier per analyte, ≥2 for top 5 highest-risk analytes). By Month 6 (2027-04-13), qualify ≥2 molders and ≥2 reagent suppliers for Cluster 1; execute binding quality agreements (defect rate <5%, first-pass yield >90%, 90-day forward commitments, 3-year price locks). Establish a 4–6 week buffer inventory of critical reagents and molded parts (USD 20–30k cost). Review supplier performance monthly; if any supplier exceeds 10% defect rate for 2 consecutive months, trigger corrective-action request and activate backup within 2 weeks.
- By Month 1 (2026-11-13), establish a Science-First charter and external scientific advisory board (5–7 members from academia and diagnostics firms) with quarterly public meetings and audit access to raw data. By Month 6 (2027-04-13), publish the first Quarterly Analyte Performance Report, including all validated assays and any that failed, with technical details and next steps. Register the clinical-study protocol on ClinicalTrials.gov before enrollment; pre-register analyte-level success criteria in the registry. This protects against credibility loss from prior failed single-drop diagnostics precedents and pre-empts market skepticism, reducing downstream valuation impact (estimated 20–30% savings vs. reactive disclosure).
- By Month 3 (2027-01-13), define the phased Newark strategy in writing: Phase 1 (Months 3–12 = 2027-01-13 to 2027-10-13) rents 2,000 sq ft for reagent formulation and lot-release lab (not full cartridge filling); budget USD 500–800k capex + USD 5–10k/month opex. Phase 2 (Months 12–15 = 2027-10-13 to 2028-01-13, only if analytical feasibility gate passes) expands to 3,000–4,000 sq ft for pilot-scale filling line; budget additional USD 2–3M capex. Conduct design-for-manufacturability review with ≥2 contract molders and a filling-equipment vendor by Month 6 (2027-04-13). Execute a 1,000–5,000 cartridge pilot fill by Month 9 (2027-07-13); measure first-pass yield (target ≥85%, acceptance ≥80%). Gate decision at Month 12 (2027-10-13): if yield ≥85% and shelf-life data project ≥12 months, release Phase 2 capital (USD 2–3M); if yield <80%, pause and conduct 4-week design review before re-pilot.
- By Month 5 (2027-03-13), initiate SBIR/STTR Phase I applications (USD 150–200k) and 5–10 pharma sponsor conversations for biomarker-monitoring feasibility partnerships. Target first signed feasibility agreement by Month 9 (2027-07-13) and first paid contract (USD 50–100k for 1,000 samples) by Month 12 (2027-10-13). Track pharma/grant run-rate monthly; if below USD 100k/month at Month 18 (2028-04-13), activate lean-pivot protocol (reduce headcount 20–30%, pause full Newark build-out, shift to cost-recovery mode).
- By Month 9 (2027-07-13), develop a unit-economics scenario test for payer coverage under three price-point assumptions (USD 100–150, USD 150–250, USD 250+); model breakeven volume and margin at each. By Month 12 (2027-10-13), initiate payer discussions (≥3 major insurers, ≥3 integrated health systems) to validate coverage appetite for a 50-analyte multiplex panel and expected reimbursement rates. If consensus price is <USD 150 per panel, narrow Cluster 1 scope or defer full 50-analyte menu to Fallback V2 (2-year expansion plan) and focus Series A/B on a narrower, higher-margin core product.
- By Month 1 (2026-11-13), hire or contract a regulatory consultant (FDA Pre-Submission experience, 10+ years device submissions) as a part-time advisor or co-founder role (budget USD 150–250k for Months 0–12 = 2026-10-13 to 2027-10-13). By Month 2 (2026-12-13), develop the Pre-Submission meeting package. By Month 3 (2027-01-13), schedule the Pre-Submission meeting; hold by Month 6 (2027-04-13). Circulate FDA feedback to the board and development team by Month 7 (2027-05-13) and use it to finalize the regulatory pathway and clinical-study design by Month 9 (2027-07-13).

## 6.3 Follow Up Consultation

"At the next consultation (suggested Month 6 = 2027-04-13), review: (1) Reconciled cash-flow model for Months 6–24 (2027-04-13 to 2028-10-13) and tranche-funding decisions (Seed adjustment, A1/A2 timing, Series B contingency); (2) FDA Pre-Submission feedback and confirmed regulatory pathway (510(k) vs. De Novo) with updated timeline; (3) Unit-economics validation (COGS model, payer survey results, gross-margin gate decisions); (4) Cluster 1 scope lock (analyte list, cross-reactivity study completion, clinical use case); (5) Pilot-fill results (yield, shelf-life projection, design-for-manufacturability findings); (6) Pharma/grant contracts (signed, revenue run-rate, runway extension). Bring updated financial model, FDA response letters, payer feedback summary, and Cluster 1 analyte performance data. If any gate (e.g., yield <80%, FDA signals De Novo, payer price <USD 150) is ambiguous or failed, be prepared to discuss Fallback V1 activation or strategic pivot options."

## 6.4.A Issue - Funding tranche schedule is undersized and misaligned with stated burn, leaving a critical gap at Month 18 (2028-04-13) and risking forced down-round or pivot.

The equity tranches (Seed USD 2–3M, A1 USD 3–4M, A2 USD 2–3M, A3 USD 2–3M) total USD 9–13M through Month 18 (2028-04-13), yet stated Months 0–6 (2026-10-13 to 2027-04-13) non-payroll capex alone is USD 2.0–3.6M, and Phase 1 Newark is USD 500–800k. Payroll for 25–35 staff at Month 12 (2027-10-13) adds USD 3–5M annual burn. Total Months 0–18 (2026-10-13 to 2028-04-13) burn is estimated at USD 8–12M without Series B funding. The gap between available capital and burn forces either A-tranche extension (dilution risk) or Series B entry at Month 18 (2028-04-13) (unrealistic for a company still in pilot-yield validation with no revenue), creating a down-round scenario.

### 6.4.B Tags

- funding-gap
- capital-efficiency
- tranche-timing
- burn-modeling

### 6.4.C Mitigation

By Month 1 (2026-11-13), develop a detailed 60-month cash-flow model showing monthly payroll (salary scales by role, hiring ramp), Newark Phase 1 and Phase 2 opex, regulatory and clinical-study spend, and equipment purchases month by month. Model three scenarios: base (Months 0–18 = 2026-10-13 to 2028-04-13 burn = USD 10M), high (USD 12M), and low (USD 8M). Lock tranche sizes to ensure each tranche covers ≥6 months of runway at the base-case burn rate, with 2-month slippage buffer. If combined tranches cover only Months 0–16 (2026-10-13 to 2028-02-13), expand Seed to USD 3–4M or accelerate A1 to Month 5 (2027-03-13). Treat pharma/grant income as upside cash-flow, not tranche reduction. Present reconciled cash-flow model to investors before Series A closes.

### 6.4.D Consequence

If tranche sizing is not corrected, the company faces a funding crisis at Month 15–18 (2028-01-13 to 2028-04-13), when Series A capital is exhausted but clinical data is still preliminary, yield gates are ambiguous, and Series B is unavailable. The board may then be forced to choose between a down-round (significant dilution, demoralization), a bridge round at punitive terms, or accelerated CLIA launch (reputational risk if data is immature). Historical precedent shows such mid-stage funding gaps cost 15–25% valuation haircut or delayed milestones that competitors exploit.

### 6.4.E Root Cause

The plan does not reconcile the quarterly burn model (payroll, Newark opex, regulatory, clinical study) against the tranche schedule month by month. Pharma and grant income (USD 1–2M over Months 0–24 = 2026-10-13 to 2028-10-13, estimate) was treated as upside acceleration rather than risk mitigation of the core equity need. Seed sizing (USD 2–3M) was set without a detailed cash-flow model showing how much each Seed tranche covers; months 0–6 (2026-10-13 to 2027-04-13) non-payroll commitments alone (USD 2.0–3.6M) conflict with the Seed range.

## 6.5.A Issue - Unit economics are mathematically unviable at projected volumes and price; multi-cartridge COGS (USD 160–225 for a 50-analyte panel) exceeds net revenue (USD 100–200), leaving negative to 20% gross margin instead of the 60% target.

The plan states that a 50-analyte menu requires 4–5 cartridges at USD 40–45 COGS each (total USD 160–225 variable cost, before cold chain USD 15–20 and distribution). Net revenue per panel is estimated at USD 100–200 (base case). This yields a gross margin of 0–20% at best, far below the ≥60% target stated. At 10k cartridges/month (USD 12–24M annual capacity-limited revenue), the company cannot cover the USD 3.75–7.5M annual burn proxy implied by headcount and facility costs. The model assumes a single-run net revenue of USD 100–200, but provides no evidence that customers will pay USD 100–200 for a 50-analyte panel, nor does it show how multi-cartridge workflow affects customer adoption or willingness-to-pay.

### 6.5.B Tags

- unit-economics
- pricing
- cogs
- gross-margin
- scalability

### 6.5.C Mitigation

By Month 3 (2027-01-13), conduct a detailed bottom-up COGS model for Cluster 1 (10–15 analytes) at volumes of 1k, 10k and 50k cartridges/month, showing material, labor, overhead and allocated facility cost per unit. Model a cost-down roadmap (e.g., molding yield improvement, reagent consolidation) to show the path from USD 40–45 to USD 25 by Month 36 (2029-10-13). By Month 6 (2027-04-13), survey 10–15 labs, clinicians and payers to validate willingness-to-pay for a 50-analyte panel at USD 100–200, USD 200–300 and USD 300+; document price sensitivity. If validated price is <USD 150, adjust the COGS ceiling or narrow the menu to improve margin. Lock a gross-margin target (≥40% at 10k/month is more realistic than 60%) and design-gate exit criteria so that any cartridge architecture failing to meet the target is redesigned or removed from Cluster 1 before Month 12 (2027-10-13).

### 6.5.D Consequence

If unit economics are not addressed, the company will ship a product that loses money on every sale at any plausible volume. Series B and C investors will refuse to fund unit-negative businesses, or will demand such steep dilution that founders lose control. If the company tries to raise prices to improve margin, payers and customers will resist, forcing a volume target (<5k cartridges/month) that cannot cover burn and does not justify Newark manufacturing investment. The result is a 50–80% likelihood of acqui-hire or insolvency within 24–36 months of clearance, destroying USD 15–20M in invested capital.

### 6.5.E Root Cause

The plan conflates two different product models: (1) a 10–15 analyte cartridge sold as a single run, and (2) a 50-analyte cumulative menu sold as a bundle. The economics of (2) have not been modeled separately. The COGS ceiling of USD 25 per cartridge was set as a design target, but no cost-down roadmap exists to show how USD 40–45 variable cost at pilot scale becomes USD 25 at volume. The price per run (USD 100–200) was never validated with customers, payers or even internal sales/market assumptions. The plan assumes customers will accept 4–5 collection steps per panel, but does not model how this user friction degrades adoption or justifies the premium.

## 6.6.A Issue - Regulatory pathway (510(k) vs. De Novo) is unconfirmed; De Novo scenario is acknowledged but not resourced, creating a 12–18 month surprise delay and USD 2–4M cost overrun if triggered after Month 6 (2027-04-13) feedback.

The plan defers FDA Pre-Submission to Months 2–3 (2026-12-13 to 2027-01-13) with a target hold date of Month 6 (2027-04-13). However, no contingency plan exists if FDA indicates that a 100+ simultaneous analyte multiplex immunoassay requires De Novo review (which is plausible, as FDA has not cleared such a device). De Novo adds 12–18 months and USD 2–4M for expanded clinical evidence, pushing clearance to Months 48–66 (2030-10-13 to 2032-04-13). The Series A tranches and clinical-study budget assume 510(k) timeline (Months 36–48 = 2029-10-13 to 2030-10-13 for clearance). If De Novo is confirmed at Month 6 (2027-04-13), the plan cannot absorb the additional runway without an unplanned Series B expansion or a forced pivot to CLIA-only launch, either of which is disruptive and damaging to investor confidence.

### 6.6.B Tags

- regulatory-pathway
- fda-uncertainty
- de-novo
- timeline-risk
- contingency-planning

### 6.6.C Mitigation

By Month 2 (2026-12-13), engage a senior FDA regulatory consultant (10+ years device submissions experience) to draft two Pre-Submission meeting packages: one optimized for 510(k) submission (primary scenario) and one for De Novo (contingency). In each, propose 3–5 regulatory questions specific to multiplex immunoassay, including predicate-device selection, analytical validity evidence, and clinical-utility thresholds. By Month 6 (2027-04-13), upon FDA feedback, model both timelines in the funding plan: (A) 510(k) pathway (clearance Months 36–48 = 2029-10-13 to 2030-10-13), (B) De Novo pathway (clearance Months 48–66 = 2030-10-13 to 2032-04-13). For scenario B, budget Series B expansion of USD 3–5M for Months 18–30 (2028-04-13 to 2029-04-13) to cover additional clinical-study cost (USD 2–4M) and extended burn. Lock the clinical-study protocol (sample size, comparator, primary endpoints) by Month 9 (2027-07-13) and register it on ClinicalTrials.gov before enrollment begins. If De Novo is likely, activate a contingent Series B fundraising plan by Month 15 (2028-01-13) to ensure capital is available by Month 18 (2028-04-13) without delay.

### 6.6.D Consequence

If the regulatory pathway is not confirmed and resourced by Month 6 (2027-04-13), discovery of a De Novo requirement at Month 9–12 (2027-07-13 to 2027-10-13) forces a cascade of corrective actions: study redesign (3–6 months), delayed enrollment, Series B fundraising under duress (punitive terms, 2–3 month distraction), and 12–18 month clearance delay that competitors exploit. The cumulative impact is a 40–60% reduction in Series A/B valuations and 18–24 month delay in revenue realization, destroying founder equity and demoralizing the team.

### 6.6.E Root Cause

The plan acknowledges De Novo as a threat ('De Novo adds 12–18 months') but treats it as a secondary consideration. The Pre-Submission meeting is correctly scheduled early (Month 6 = 2027-04-13), but no decision tree exists for what to do if FDA signals De Novo is likely. The clinical-study design (sample size, endpoints, comparator methods) has not been pre-agreed with FDA or drafted in a format that aligns with either 510(k) or De Novo submission requirements. This creates a scenario where FDA feedback at Month 6 (2027-04-13) may require a study redesign that delays enrollment, adding 4–6 months and USD 500k–1M in cost.

---

# 7 Expert: Payer Coverage and Health Economics Strategist

**Knowledge**: CMS coverage policies and CPT coding, payer reimbursement mechanisms, health-economic analysis, laboratory developed test (LDT) coverage, value-based payment models, multiplex bundle pricing, formulary and coverage negotiation

**Why**: The Payer Coverage and Pricing Architecture decision (Decision 10) is unresolved: the 50-analyte menu has variable cost USD 160-225 (4-5 cartridges) against base-case net revenue USD 100-200, implying negative to 20% gross margins far below the 60% target. Payers have not yet been consulted on whether they will reimburse a multiplex bundle or only individual coded analytes, and a low-case scenario (USD 50-100 per run) would further compress margins. A payer strategy expert is essential to conduct early market soundings (Months 6-9 = 2027-04-13 to 2027-07-13), model reimbursement scenarios (bundled vs. unbundled coding), and identify a narrow high-value initial indication that can support the test economics, informing both the pricing strategy and the Cluster 1 analyte selection.

**What**: By Month 6 (2027-04-13), conduct interviews with 5-10 major payers (Medicare, Aetna, UnitedHealth, regional plans) on multiplex bundle coverage appetite and identify 2-3 high-value disease areas (e.g., cardiovascular risk, diabetes management) where analyte claims align with coverage precedent; model three pricing scenarios (USD 100, 150, 200 per run) and their margin and volume implications; deliver payer-readiness materials (health-economic analysis template, coverage pathway) by Month 9 (2027-07-13).

**Skills**: CMS coverage policy and CPT coding, payer reimbursement negotiation, health-economic modeling and outcomes research, evidence synthesis for coverage decisions, laboratory test bundling and unbundling, formulary strategy, comparative-effectiveness analysis, risk-sharing and value-based contract terms

**Search**: payer coverage strategy diagnostics lab tests, CPT coding health economics, CMS reimbursement multiplex assays

## 7.1 Primary Actions

- By Month 3 (2027-01-13), define a clinically-justified intended-use claim for Cluster 1 (e.g., 'Biomarker monitoring in patients with [specific indication]' or 'Screening for metabolic and cardiovascular risk') and specify the clinical indication, patient population, sample size and primary-endpoint hypothesis for the clinical study. Lock this before Cluster 1 analyte selection is finalized and submit it to FDA in the Pre-Submission package (Month 6 = 2027-04-13).
- By Month 4 (2027-02-13), engage a health-economics firm with CMS and payer experience to conduct a payer reimbursement and willingness-to-pay study: (a) model three scenarios (unbundled CPT, single bundled CPT, value-based contracts) with realistic payer discount rates; (b) interview 5–10 payers and 3–5 health systems on coverage likelihood and price ceiling for the stated intended-use claim; (c) deliver a memo to the board documenting realistic net revenue per run (low/mid/high case) and the coverage rate required to break even at projected volumes. Use this to reset the revenue assumption and validate the USD 25 COGS ceiling and USD 100–200 per-run revenue estimate, or adjust them.
- By Month 6 (2027-04-13), in the FDA Pre-Submission meeting, ask explicitly: (a) 'Given the intended-use claim and the Cluster 1 analyte list, does FDA expect clinical evidence of comparative-effectiveness vs. standard-of-care, or is analytical equivalence to reference methods sufficient?'; (b) 'Is the clinical study design (sample size, comparators, primary endpoints) aligned with FDA's expectations for 510(k) vs. De Novo?'; (c) 'Does FDA consider a multiplex immunoassay panel of 50 simultaneous analytes a new type of device (De Novo) or a modification of existing high-plex platforms (510(k))?'; Document all FDA feedback in writing and circulate to the board. Adjust the clinical-study plan and funding timeline accordingly.
- By Month 9 (2027-07-13), complete the CPT coding strategy: (a) file a CPT application for the primary billing pathway (single bundled code or modular codes per cartridge) with the AMA RUC committee or a CPT advisor; (b) model the payer coverage landscape (Medicare, Anthem, UnitedHealth, etc.) and the reimbursement rate for each pathway; (c) present the coding strategy and projected net revenue to the board; (d) if net revenue is <USD 80 per run, trigger a design-retreat decision: narrow Cluster 1 from 50 to 20–30 analytes that maximize per-analyte clinical value and payer coverage probability. Adjust Newark scale-up assumptions and Series A Tranche 2 (Month 12 = 2027-10-13) capital release accordingly.
- By Month 12 (2027-10-13), before clinical enrollment reaches 150+ subjects, conduct a interim payer health-economic review: (a) share preliminary clinical concordance, sensitivity/specificity and cost-of-goods data with 3 payers; (b) ask whether the device is on track for coverage at the projected net revenue and volume; (c) if payers signal 'coverage unlikely' or 'price must be <USD 60 per run', halt enrollment, redesign Cluster 1 (remove low-clinical-value analytes, reformulate high-cost assays), and restart enrollment with revised protocol. This prevents spending USD 1–2M on a clinical study for a product payers will not cover.

## 7.2 Secondary Actions

- By Month 5 (2027-03-13), build a detailed 'Payer Coverage and Pricing Roadmap' document specifying: (a) the target payers (top 5 by lives covered in US: UnitedHealth, Anthem, Humana, Cigna, Aetna; regional players if relevant to beachhead geography); (b) the evidence types each payer historically requires for coverage (e.g., Anthem: published health-economic analysis; Humana: real-world outcomes; CMS: HEOR + patient stratification evidence); (c) the coverage-negotiation timeline (months between submission and coverage determination, typically 90–180 days); (d) the reimbursement levers available (network-restricted coverage, coinsurance tiers, prior authorization). Share with board and use to plan the regulatory and clinical evidence generation.
- By Month 6 (2027-04-13), request feedback from CMS (via a MEDCAC pre-nomination or advisory opinion) on whether a multiplex immunoassay panel would be suitable for coverage under the existing clinical laboratory fee schedule or whether CMS would require a special valuation (e.g., composite code, bundled reimbursement, per-analyte carve-outs). Incorporate CMS feedback into the revenue model.
- By Month 9 (2027-07-13), commission a quick 'Comparative Effectiveness Analysis' (CER) comparing Cluster 1 to existing standard-of-care for the intended-use claim: measure time-to-diagnosis, downstream testing frequency, clinical decision-change rate, patient outcomes (if available in preliminary data). Payers increasingly require CER evidence for high-cost or multiplex tests. A CER showing 10–20% reduction in downstream testing cost or 5–10% improvement in patient outcomes makes a case for coverage premium.
- By Month 12 (2027-10-13), develop a 'Payer Reference Package' (15–20 pages) including: (a) clinical-study summary with efficacy, safety and cost-of-goods; (b) health-economic model (net cost per diagnosis or per QALY); (c) CER summary; (d) proposed CPT code(s) and reimbursement rationale; (e) risk-sharing or performance-based contract offer (e.g., 'guaranteed replacement if false-positive rate exceeds X%'). Use this to initiate formal coverage negotiations with payers at Month 18–24 (2028-04-13 to 2028-10-13).
- By Month 18 (2028-04-13), establish a 'Payer Advisory Board' (3–5 representatives from national and regional payers) to provide quarterly feedback on coverage likelihood, pricing trends, and competitive threats. This keeps the company aligned with payer expectations and reduces the risk of missing coverage criteria late in development.
- Conduct a competitive landscape analysis by Month 6 (2027-04-13): identify existing multiplex immunoassay panels (e.g., Myriad, Mayo Clinic) and their CPT codes, payer coverage status, reimbursement rates, and market penetration. Use this to benchmark realistic pricing and coverage rates.
- By Month 24 (2028-10-13), before FDA submission, have at least one 'commitment letter' from a major payer or health system documenting the minimum coverage and reimbursement rate (e.g., 'Anthem commits to cover at USD 125 per run for [indication] pending FDA clearance'). This reduces the revenue-ceiling risk and gives investors confidence in the economic model.
- Develop a 'Diagnostic Stewardship Plan' by Month 12 (2027-10-13): outline how the company will work with clinicians to prevent overutilization and false-positive-driven cascade testing. Payers are increasingly skeptical of multiplex tests and will demand evidence that ordering patterns are evidence-based. A stewardship plan (e.g., clinical decision-support integration, provider education, test-ordering algorithms) strengthens the coverage case.

## 7.3 Follow Up Consultation

By Month 12 (2027-10-13), we should reconvene to review the results of the payer reimbursement study, FDA Pre-Submission feedback, CPT coding pathway, and interim clinical concordance data. At that point, we will know whether the USD 100–200 per-run assumption is realistic, whether the 50-analyte cluster size is aligned with payer clinical-necessity and CPT-coding expectations, and whether the health-economic value proposition is credible to payers. If any of these is misaligned, we will need to execute a design retreat (reduce analyte count, narrow the intended-use claim, or pivot to a different clinical indication or payer route, such as value-based contracts or self-pay wellness). This interim review will inform the Series A Tranche 2 (Month 12 = 2027-10-13) capital release and the clinical-study protocol final approval.

## 7.4.A Issue - Payer reimbursement pathway is not credibly defined; 'USD 100–200 per run' is an unconstrained assumption unsupported by coding, coverage precedent, or negotiation evidence.

The plan assumes USD 100–200 net revenue per run (base case) and USD 300–500 (upside, treated as unlikely) without documented CMS coding options, health-economic justification, or payer willingness-to-pay studies. A 50-analyte panel as a single bundled CPT code does not exist; current CPT architecture codes individual tests. Unbundling yields USD 15–50 per analyte × 50 = USD 750–2,500 list, but payers typically carve out 30–50% discounts and bundle-price negotiations. The gap between the USD 100–200 assumption and realistic payer economics (USD 40–100 net per panel) is not reconciled, yet the entire unit economics and Newark investment decision depends on it.

### 7.4.B Tags

- payer-reimbursement-risk
- cpt-coding-gap
- bundle-economics-unvalidated
- breakeven-assumption-unsupported

### 7.4.C Mitigation

By Month 3 (2027-01-13), engage a health-economics consulting firm with CMS and payer experience to model three reimbursement scenarios: (1) unbundled per-analyte CPT codes with 40% payer discount; (2) a new high-plex bundle CPT code petition with CMS valuation (RUC process, budget impact analysis); (3) value-based contracts with risk-bearing payers (e.g., Mayo Clinic Health System). For each, estimate net revenue per run and required payer coverage rate (% of addressable market willing to adopt). By Month 6 (2027-04-13), initiate structured interviews with 5–10 payers (e.g., UnitedHealth, Anthem, Aetna) and 3–5 health systems to document willingness to pay and coverage criteria. Lock a realistic net-revenue assumption (low, mid, high case) by Month 9 (2027-07-13) before Series A Tranche 2 is released at Month 12 (2027-10-13). Remodel unit economics and breakeven volume; adjust Newark capital release if net revenue is <USD 80 per run.

### 7.4.D Consequence

If net revenue is USD 40–100 per run instead of USD 100–200, the 50-analyte panel (4–5 cartridges @ USD 40–45 COGS) yields negative to 20% gross margin, not the 60% target. Breakeven moves from 2–11k runs/month to 5–30k runs/month, beyond any plausible demand proof. Series B and C capital requirements rise from USD 15–30M to USD 25–45M. Investors and board will lose confidence by Month 18 (2028-04-13) when payer negotiations reveal the true reimbursement ceiling. The company may be forced to pivot to self-pay wellness (smaller market) or abandon Newark manufacturing economics altogether.

### 7.4.E Root Cause

The plan treats reimbursement as a marketing and sales problem, not a health-economics and regulatory problem. No payer engagement, comparative-effectiveness analysis, or CMS coding petition has been performed. The revenue assumption was likely derived from a venture-style 'market size ÷ addressable volume' formula, not from payer rate-setting mechanisms. The quarterly gate at Month 9 (2027-07-13) is labeled 'payer scenarios' but has no deliverable or success criterion.

## 7.5.A Issue - Clinical utility and health-economic value are not defined; the plan lacks evidence that a 50-analyte multiplex delivers lower cost-per-clinically-actionable-result than existing individual tests or narrow panels.

The plan commits to clinical-study enrollment at Month 12 (2027-10-13) but does not specify the intended-use claim, clinical indication, or hypothesis being tested. Is the device for screening asymptomatic populations (large addressable market, low pretest probability, high cost per true positive), biomarker monitoring in pharma trials (narrow pharma beachhead, evidence only in sponsor hands), or disease diagnosis in symptomatic patients (smaller market, clearer clinical value)? Without a defined clinical use case, it is impossible to size the sample, compare to existing standard-of-care, or estimate payer health-economic requirements. Payers increasingly demand comparative effectiveness and cost-effectiveness evidence (e.g., cost per quality-adjusted life-year, diagnostic accuracy vs. reference standard). A 50-analyte panel may deliver false positives and cascade testing costs that exceed the value of detection.

### 7.5.B Tags

- clinical-utility-undefined
- health-economics-analysis-missing
- intended-use-claim-unspecified
- cost-effectiveness-unmodeled

### 7.5.C Mitigation

By Month 3 (2027-01-13), convene a clinical advisory panel (5–7 board-certified physicians spanning primary care, cardiology, hematology, oncology, and preventive medicine) to define 2–3 credible clinical use cases for a 50-analyte panel. For each use case, document: (a) the clinical indication (diagnosis, screening, monitoring, prognosis); (b) the reference standard or standard-of-care workflow being compared; (c) the projected clinical sensitivity/specificity and positive/negative predictive values; (d) the estimated frequency of use in the intended population (volume demand). By Month 6 (2027-04-13), engage a health-economics firm to build a decision-analytic model (e.g., decision tree or Markov model) for the top use case, comparing the multiplex device to existing standard-of-care in terms of cost per diagnosis, cost per quality-adjusted life-year, and impact on treatment decisions. By Month 9 (2027-07-13), present the health-economic model to 3–5 payers and ask: 'Would you cover this device if the clinical evidence supports equivalence to reference standard and the cost-effectiveness is in the range USD 50k–150k per QALY?' Use payer feedback to refine the intended-use claim and analyte selection for Cluster 1. Lock the clinical study protocol by Month 10 (2027-08-13) and align it with the FDA Pre-Submission feedback (Month 6 = 2027-04-13) and payer coverage expectations.

### 7.5.D Consequence

At Month 18 (2028-04-13), when design is frozen and clinical enrollment is underway, the company discovers that the intended-use claim does not support payer coverage or that the health-economic value is negative (more false positives, more downstream tests, higher total cost of care than existing alternatives). FDA Pre-Submission feedback or a payer health-economics review may demand a new clinical study design (6–12 month delay, USD 500k–2M additional cost). The company is forced to choose between narrowing the analyte menu to a single clinically-defensible use case (defeating the multiplex value proposition) or delaying clearance and revenue by 12+ months while new evidence is generated.

### 7.5.E Root Cause

The plan is built around a technical vision (500 tests from one drop) and a manufacturing constraint (Newark, California) rather than a clinical or payer need. The strategic path selected pharma biomarker beachhead funding, which delays the definition of a clinically-actionable use case until after design decisions (cluster size, analyte selection) are locked. The project plan assumes that 'a validated multi-analyte fingerstick platform' is self-evidently valuable without testing that assumption against real payer and clinician demand.

## 7.6.A Issue - The modular multiplex bundle-pricing strategy is not aligned with actual payer payment models; the plan conflates 'modular cartridges for manufacturing' with 'modular billing' but bundling 50 analytes into a single payment yields worse economics than billing per-analyte.

The plan asserts that a 'modular cartridge family' (4–5 cartridges of 10–15 analytes each) will be 'sold one at a time' and accumulate toward 500 tests, but pricing strategy is undefined. If the company bills each cartridge separately (e.g., 5 × USD 20–40 = USD 100–200 per panel), payers will either (a) cover only the clinically essential cartridge(s) and disallow the rest as medically unnecessary, or (b) require a lowest-price guarantee across cartridges, eroding the bundled price. If the company bundles all 50 analytes into one CPT code, the per-analyte reimbursement becomes USD 100–200 ÷ 50 = USD 2–4 per analyte, far below the USD 15–50 per-analyte unbundled rate. The CMS Multiplex Bundling Policy and historical precedents (e.g., GeneSight, Guardant health genomic panels) show that payers will aggressively de-bundle or exclude tests deemed redundant or low-clinical-value, cutting revenue by 30–60% if the panel is not narrowly justified. The plan does not address whether each cartridge will have its own CPT code or whether the 50-analyte panel will be coded as a single test.

### 7.6.B Tags

- bundle-derisking-missing
- cpt-coding-strategy-undefined
- payer-deselection-risk-unmodeled
- clinical-necessity-unproven

### 7.6.C Mitigation

By Month 4 (2027-02-13), engage the American Medical Association's RUC (Relative Value Scale Update Committee) consultant or a CPT coding advisor to model the coding and valuation pathways: (a) single bundled CPT code for 50 analytes (e.g., 'Multiplex Immunoassay Panel, 50 analytes'), estimated RUC value and Medicare reimbursement; (b) separate codes per cartridge (e.g., 5 × CPT codes, one per cartridge), estimated aggregate reimbursement and payer likely to de-select; (c) core high-value analytes unbundled (e.g., 15–20 analytes as separate codes) + a supplemental panel for the remainder. For each scenario, model the payer reimbursement (Medicare rate × payer adjustment + private pay mix), deductible/copay, and net revenue after mandatory rebates. By Month 6 (2027-04-13), present the three coding scenarios to the board and 3–5 payers; ask which pathway payers would accept for coverage. Lock a CPT coding strategy and corresponding analyte-selection strategy by Month 9 (2027-07-13). If a single bundled code is required and the RUC valuation is <USD 100 total, retreat Cluster 1 from 50 to 20–30 most-clinically-essential analytes to maximize per-analyte value and payer acceptance. Adjust Newark capital release and manufacturing scale assumptions accordingly.

### 7.6.D Consequence

When the company attempts to negotiate payer coverage at Month 18–24 (2028-04-13 to 2028-10-13), payers will demand a single, clinically-justified CPT code for the entire 50-analyte panel or will require separate codes and coverage decisions for each cartridge. If separate codes, the company loses the 'convenience premium' and must justify each test individually, exposing low-clinical-value analytes to exclusion. If a single code, payers may revalue the entire panel downward (e.g., USD 50–100 total, USD 1–2 per analyte), yielding negative or single-digit margin. The company will be forced to either (a) apply for a new bundled CPT code (RUC process, 12–18 month delay), (b) pivot to multiple separate codes and accept payer de-selection of low-value analytes, or (c) abandon payer coverage and shift to self-pay or employers. All three paths reduce the addressable market or delay revenue significantly.

### 7.6.E Root Cause

The strategic path was chosen based on manufacturing and capital-risk logic (modular cartridges isolate failure and cost), but the corresponding pricing and coverage strategy was not developed in parallel. The plan assumes that manufacturing modularity translates automatically to pricing modularity and that payers will pay a 'multiplex premium' for convenience. In reality, payers reimburse clinical value, not manufacturing convenience. The cost-ceiling decision (USD 25 per cartridge, locked by Month 6 = 2027-04-13) was made without testing it against realistic payer reimbursement.

---

# 8 Expert: Assay Chemistry and Reagent Development Lead

**Knowledge**: Immunoassay chemistry (sandwich, competitive, agglutination), multiplex assay design and cross-reactivity mechanisms, antibody and synthetic binder selection, reagent formulation and stability, shelf-life acceleration protocols (Arrhenius), lot-to-lot reproducibility, matrix effects and hemolysis

**Why**: The Assay Panel Architecture decision (Decision 1) chooses modular cartridges validated cluster-by-cluster, with Cluster 1 locked by Month 2 (2026-12-13) and cross-reactivity matrix study completed by Month 6 (2027-04-13). However, the project carries extreme risk on analytical feasibility: cross-reactivity between 10-15 analytes in a sub-microliter sample budget, hemolysis and plasma-separation variation, and reagent stability over 12+ months are unproven. An assay chemistry expert is essential to lead Cluster 1 analyte selection, design the cross-reactivity study protocol, oversee reagent sourcing and stability testing, and identify which analytes are incompatible early, preventing expensive downstream redesign.

**What**: By Month 2 (2026-12-13), define Cluster 1 as 10-15 analytes selected for low known cross-reactivity risk and established reference methods; by Month 3 (2027-01-13), design the cross-reactivity matrix protocol (spiked plasma with hemoglobin, bilirubin, lipemia, rheumatoid factor at 10x physiologic; acceptance ≤5% bias); by Month 6 (2027-04-13), complete the study and produce an Analyte Removal Log with technical reason for any analyte excluded.

**Skills**: Multiplex immunoassay design and optimization, cross-reactivity testing and interference resolution, antibody and synthetic binder sourcing and qualification, reagent formulation (pH, osmolality, stability enhancers), accelerated shelf-life testing (Arrhenius modeling), lot-to-lot CV reduction, assay analytical validation and method comparison, hemolysis and plasma-separation effects

**Search**: assay chemistry multiplex immunoassay cross-reactivity, reagent formulation stability, antibody sourcing diagnostics

## 8.1 Primary Actions

- By Month 2 (2026-12-13): Hire an assay chemistry lead (PhD or ≥10 years IVD immunoassay experience) as a co-founder or first R&D hire, with ownership of Cluster 1 analyte selection, cross-reactivity testing, and shelf-life validation. This person must have direct authority over assay design changes and gate criteria.
- By Month 2 (2026-12-13): Commission and finalize the cross-reactivity study protocol: define Cluster 1 analytes (10–15), specify interferent panels (hemoglobin 200 mg/dL, bilirubin 5 mg/dL, triglycerides 500 mg/dL, rheumatoid factor 100 IU/mL at 10× physiologic), set acceptance criterion ≤5% bias from each interferent, and lock the timeline for completion by Month 6 (2027-04-13). Identify an ISO/IEC 17025-accredited lab to execute the study if internal capacity is insufficient.
- By Month 3 (2027-01-13): Specify the multiplex reagent formulation in writing (buffer pH, osmolality, stabilizer concentrations, surfactant type, antimicrobial preservative, storage conditions). By Month 3 (2027-01-13), initiate formal accelerated shelf-life testing under Arrhenius conditions (2–8 °C real-time, 37 °C accelerated; quarterly sampling for 12 months minimum). Budget USD 50–100 k for full Arrhenius study and commit to monthly data review with the assay chemistry lead.
- By Month 3 (2027-01-13): For each of the top 5 analytes in Cluster 1 (lowest volume, shortest history, highest complexity), identify and qualify ≥2 suppliers; execute quality agreements specifying incoming-lot defect rate <5%, first-pass yield >90%, and ≤2–3% annual price escalation. Establish incoming-lot acceptance criteria (assay CV ≤7%, recovery 98–102%) and assign the quality lead to oversee monthly lot-release reviews.
- By Month 6 (2027-04-13): Complete the cross-reactivity matrix study. Any analyte pair failing the ≤5% bias criterion must be reformulated within 2 weeks or permanently removed from Cluster 1, with written documentation in the Analyte Removal Log for the FDA submission. If ≥2 analytes are removed, reset Cluster 1 to the revised list and update the clinical study protocol.
- By Month 9 (2027-07-13): Execute a pilot cartridge fill (1,000–5,000 units) using production-equivalent reagent lots, processes, and storage conditions. Measure first-pass yield (target ≥85%, acceptance ≥80% lower CI), and test 3 consecutive reagent lots for lot-to-lot consistency (CV across lots <10%). Document all failures and root causes; any yield <80% or lot CV ≥10% triggers a design review and Month 12 (2027-10-13) gate contingency.

## 8.2 Secondary Actions

- By Month 4 (2027-02-13): Develop a risk-based analyte clustering strategy: group Cluster 1 analytes by chemical class (proteins, small metabolites, hormones) and cross-reactivity risk tier (low, medium, high based on literature and supplier data); prioritize highest-confidence pairs for clinical enrollment to maximize gate-passing probability.
- By Month 5 (2027-03-13): Establish a monthly Assay Chemistry Review meeting (assay lead, quality lead, R&D director, FDA consultant) to review cross-reactivity data, shelf-life trends, and reagent-lot performance; flag issues for Month 6 (2027-04-13) and Month 12 (2027-10-13) gate reviews at least 4 weeks in advance.
- By Month 6 (2027-04-13): Document all analyte performance data—successful and failed—in a structured Analyte Performance Database (assay precision, accuracy, cross-reactivity matrix, shelf-life projection, manufacturing yield per analyte). Use this database to inform Cluster 2 analyte selection and to support the advisory board's public transparency reports.
- By Month 9 (2027-07-13): Conduct a Design-for-Manufacturability review with ≥2 contract molders and the Newark operations team, focusing on reagent-storage chamber design, hermetic sealing, humidity control, and first-pass yield limits; identify any cartridge-design modifications needed to meet the ≥85% yield target.
- By Month 12 (2027-10-13): Prepare a detailed Technical Summary of Cluster 1 assay chemistry for FDA submission: cross-reactivity testing results, shelf-life Arrhenius projection with R² and 90% CI, reagent sourcing and lot-release criteria, manufacturing process and yield data, and lot-to-lot consistency evidence. Use this document to support the 510(k)/De Novo submission.
- By Month 15 (2028-01-13): Finalize the interim clinical-study concordance analysis (150–200 samples); align analytical performance with clinical endpoints and identify any analytes with lower-than-expected clinical utility for potential removal before design freeze (Month 18 = 2028-04-13).
- By Month 18 (2028-04-13): Lock the Cluster 1 reagent formulation and sourcing as part of the design freeze; execute a Change Control freeze on all assay components and process parameters; establish a baseline for design-control documentation required by ISO 13485 and FDA pre-approval inspection.
- Establish a Scientific Advisory Board (SAB) with external assay chemistry and diagnostics expertise (≥1 assay chemist, ≥1 clinical chemist, ≥1 diagnostics company leader); grant SAB members monthly access to raw cross-reactivity and shelf-life data; require SAB sign-off on analyte removal decisions and gate outcomes before board approval.

## 8.3 Follow Up Consultation

"At the next consultation, bring: (1) Proposed Cluster 1 analyte list (10–15) with literature cross-reactivity risk assessment for each pair; (2) draft cross-reactivity study protocol (interferent levels, acceptance criteria, timeline, responsible lab); (3) preliminary multiplex reagent formulation (buffer composition, pH, osmolality, stabilizer package, storage conditions); (4) list of identified suppliers for top 5 analytes with financial-stability and quality-system assessment; (5) preliminary Arrhenius shelf-life study plan (storage conditions, sampling schedule, R² target); (6) pilot-fill timeline and capability (in-house vs. contract, 1k–5k cartridge target, yield measurement plan); (7) FDA Pre-Submission meeting questions on cross-reactivity evidence expectations and De Novo risk; (8) draft Analyte Removal Log template for regulatory submission. Bring data, not plans: cross-reactivity literature matrix, supplier certificates of analysis for pilot analytes, preliminary shelf-life data if Months 1–2 (2026-11-13 to 2026-12-13) studies have begun. Expect 2–4 hour technical deep-dive focused on assay-chemistry risk and Month 6 (2027-04-13) gate readiness."

## 8.4.A Issue - Cross-reactivity matrix incomplete and under-resourced; risks analytical failure and expensive late-stage redesign.

The project lacks a comprehensive, quantitative cross-reactivity protocol for Cluster 1 analytes. The strategic documents acknowledge cross-reactivity as a core risk but do not define acceptance criteria, interferent panels (hemoglobin, bilirubin, lipemia, rheumatoid factor at 10× physiologic concentration), measurement conditions, or a decision tree for reformulation versus removal. Without this foundation by Month 6 (2027-04-13), the project risks discovering incompatibilities post-Month 9 (2027-07-13) when clinical enrollment is underway, forcing costly redesign (3–6 months, USD 200–500 k). The pre-project assessment mentions cross-reactivity as a critical gate criterion but provides no study design.

### 8.4.B Tags

- assay-chemistry
- cross-reactivity
- analytical-validation
- gate-readiness

### 8.4.C Mitigation

By Month 2 (2026-12-13): Define Cluster 1 as 10–15 analytes with lowest documented cross-reactivity risk (consult literature, competitor data, antibody supplier interference reports). By Month 3 (2027-01-13): Commission a full cross-reactivity matrix study from an ISO/IEC 17025-accredited assay lab or internal pilot: measure each analyte alone and in pairs, plus full plex, spiked with hemoglobin (200 mg/dL), bilirubin (5 mg/dL), triglycerides (500 mg/dL), rheumatoid factor (100 IU/mL) at up to 10× physiologic concentration. Set acceptance: ≤5% bias from any interferent, ≥95% concordance with singleplex. By Month 6 (2027-04-13): Complete matrix; remove or reformulate any failing pair within 2 weeks. Hire an assay chemistry lead (PhD or senior IVD experience, ≥10 years) as Month 1 (2026-11-13) co-founder or Month 2 (2026-12-13) hire to own this gate.

### 8.4.D Consequence

If cross-reactivity is not quantified by Month 6 (2027-04-13), clinical study enrollment (Month 12 = 2027-10-13) proceeds with unvalidated analyte pairs. Discovery of incompatibility post-enrollment forces either removal of that analyte (weakening Cluster 1), or redesign and re-validation (3–6 months, USD 200–500 k), or silent suppression of the problematic result (reputational risk). A failed clinical study costs USD 500 k–2 M and delays clearance by 6–12 months, triggering Series B requirement by Month 24 (2028-10-13) instead of Month 30 (2029-04-13).

### 8.4.E Root Cause

No explicit cross-reactivity study protocol has been pre-specified, and assay chemistry expertise is not prioritized in early hiring (no chemist or assay lead mentioned in Month 1 = 2026-11-13 staffing). The project assumes multiplex immunoassay design but does not isolate the single highest-risk step: whether 10–15 analytes can coexist in one microdroplet without mutual interference. This is the analogue of Theranos's misdiagnosis of cross-reactivity in their Edison device.

## 8.5.A Issue - Reagent supply and lot-to-lot consistency unaddressed; threatens shelf-life claims and scale-up yield.

The project designates Newark as a reagent formulation and filling site but does not specify: which reagent inputs (antibodies, probes, enzymes, stabilizers) are sourced, from how many suppliers, with what qualification criteria, or how lot-to-lot variability is controlled. The strategic documents identify reagent supply as a medium-priority decision lever but leave it downstream of cartridge architecture and Newark timing. In assay chemistry practice, lot-to-lot CV in critical biologics (especially antibodies) drives overall precision and directly threatens the Month 12 (2027-10-13) gate criterion of lot CV <10%. Without dual sourcing, qualification, and retest protocols in place by Month 3 (2027-01-13), a supplier discontinuation or quality failure at scale (Months 9–12 = 2027-07-13 to 2027-10-13) halts cartridge filling for 4–8 weeks and costs USD 100–500 k in scrap and lost revenue.

### 8.5.B Tags

- reagent-supply
- lot-consistency
- shelf-life
- manufacturing-risk

### 8.5.C Mitigation

By Month 1 (2026-11-13): Hire or contract a senior assay chemist (PhD in assay chemistry, immunoassay experience, ≥10 years) and assign ownership of reagent qualification and shelf-life testing. By Month 3 (2027-01-13): For each of the top 5 highest-risk analytes in Cluster 1 (those with smallest antibody volumes, shortest history, or most complex capture chemistry), identify ≥2 qualified suppliers; execute quality agreements specifying incoming-lot defect rate <5%, first-pass yield >90%, 3-year price lock or ≤2–3% annual escalation. By Month 4 (2027-02-13): Begin accelerated shelf-life testing (Arrhenius: 37 °C and 2–8 °C, quarterly sampling) with Cluster 1 reagents; project 12-month stability via linear or non-linear regression (R² >0.90). By Month 6 (2027-04-13): Establish incoming-lot acceptance criteria in writing: assay precision (CV) on lot release ≤7%, accuracy (recovery) 98–102%, cross-lot consistency (CV <10%). By Month 9 (2027-07-13): Execute a pilot fill (1,000–5,000 cartridges) using production-equivalent reagent lots and processes; measure first-pass yield (target ≥85%); test 3 consecutive lots for lot-to-lot performance consistency (CV across lots <10%).

### 8.5.D Consequence

Without reagent qualification, the Month 12 (2027-10-13) gate criterion (lot CV <10%) cannot be met or verified; gate failure forces a fallback to narrower analyte set or triggers technical redesign and delay. A supplier discontinuation during scale-up (Months 9–18 = 2027-07-13 to 2028-04-13) halts filling for 4–8 weeks (USD 100–500 k loss) and pushes Newark to idle capacity or external fill-service, adding USD 1–3 per cartridge to COGS and eroding the USD 25 ceiling. Shelf-life projection failure (R² <0.90 or <9 month stability) post-Month 12 (2027-10-13) forces reformulation and 3-month delay; total impact: 6–9 month delay to clearance, Series B requirement by Month 24 (2028-10-13).

### 8.5.E Root Cause

The project treats reagent sourcing as a vendor-management task rather than a core assay-chemistry gate criterion. No assay chemistry lead or quality chemist is assigned to reagent qualification, and no budget or timeline is allocated for incoming-lot acceptance testing, dual-source qualification, or long-term stability tracking under accelerated conditions (Arrhenius protocol). This mirrors the hidden failure mode in Theranos's Edison: reagent quality was not actively managed, and the company relied on supplier claims without independent re-validation.

## 8.6.A Issue - Shelf-life and Arrhenius protocol absent; 12-month projection target may be unattainable for multiplex formulation.

The Month 12 (2027-10-13) gate criterion requires shelf-life ≥12 months projected via Arrhenius modeling (R² >0.90), but the project does not specify: storage conditions (2–8 °C, 25 °C/60% RH, or ambient), reagent composition (stabilizers, surfactants, osmolytes), test matrix (aqueous buffer, whole cartridge), or acceptance criteria for individual assay components. Multiplex formulations are inherently more complex than single-assay reagent mixes and face simultaneous degradation of multiple capture antibodies, enzymes, and substrate analogs, which may not follow clean Arrhenius kinetics if degradation pathways compete or if one component is much more labile. Without a formal shelf-life study protocol by Month 3 (2027-01-13), the project risks projecting 12-month stability on insufficient data (e.g., 3 time points), leading to false confidence, field failures post-clearance, or forced product recall.

### 8.6.B Tags

- shelf-life
- stability-testing
- arrhenius
- formulation-chemistry

### 8.6.C Mitigation

By Month 3 (2027-01-13): Specify the formulation composition and storage conditions in writing; design a formal shelf-life protocol: store cartridges at 2–8 °C (primary), 25 °C/60% RH (secondary), and 37 °C (accelerated); sample at 0, 1, 3, 6, 9, 12 months (real-time) and 1, 2, 4, 8, 12, 16 weeks (accelerated); measure analyte stability (% recovery versus Day 0) and assay precision (CV) per analyte per time point. Set acceptance: ≥90% recovery and CV ≤20% of baseline at any shelf-life claim duration. By Month 6 (2027-04-13): Produce the first Arrhenius projection (minimum 12 weeks accelerated + 6 months real-time data; if insufficient, extend to Month 9 = 2027-07-13); document R² and 90% CI for shelf-life estimate. If projection indicates <9 months, initiate reformulation (add stabilizers, reduce humidity exposure, switch to nitrogen-flushed cartridge) and restart stability testing (3-month delay). By Month 12 (2027-10-13): Gate decision on shelf-life—if data support ≥12 months, proceed; if 9–12 months, label product accordingly and plan 24-month real-time data collection post-clearance for potential label expansion; if <9 months, flag as a formulation redesign issue for the Month 15 (2028-01-13) review.

### 8.6.D Consequence

If shelf-life is not studied systematically, the Month 12 (2027-10-13) gate criterion cannot be objectively met. FDA Pre-Approval Inspection (Months 28–36 = 2029-02-13 to 2029-10-13) will challenge the 12-month stability claim if accelerated data are weak (R² <0.90, extrapolation >2 months beyond test duration) or absent, resulting in FDA 483 observations and conditional clearance with a shorter initial shelf-life claim (3–6 months), driving higher per-cartridge cost (more frequent manufacturing, higher cold-chain burden) and user inconvenience. Post-clearance shelf-life failures (product failing potency or precision testing at claimed shelf life) force product recall (USD 500 k–2 M for 50 k cartridges), regulatory action, and potential 510(k) supplement with new stability data (3–6 month delay to resume sales).

### 8.6.E Root Cause

The project assumes shelf-life can be projected by Month 12 (2027-10-13) but does not allocate time or resources for accelerated-stability testing. Multiplex reagent formulations require 6–9 months of real-time data at 2–8 °C plus 3–4 months of accelerated data at elevated temperature to establish Arrhenius kinetics confidently. If the project initiates cartridge filling at Month 6 or 7 (2027-04-13 or 2027-05-13), the earliest shelf-life projection would be Month 12–15 (2027-10-13 to 2028-01-13) at best, and if real-time stability is required post-clearance, shelf-life claim may be limited to 6–9 months initially, requiring 12-month data collection post-clearance. This is not a surprise in assay development, but it is commonly underestimated.