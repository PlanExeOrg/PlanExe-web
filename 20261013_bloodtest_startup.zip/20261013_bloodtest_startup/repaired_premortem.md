A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Pilot-scale cartridge yield will reach >=85% (proposed threshold) with lot CV <10% and shelf-life >=12 months using contract molders and Newark filling, without custom fluidic or bonding engineering. | Commission DFM reviews from 2 molders and a filling vendor; build 500 production-equivalent cartridges from 3 reagent lots and measure per-step yield, lot CV and 4-week accelerated stability. | First-pass yield below 80% across 3 lots, or lot CV >=10%, or projected shelf-life below 9 months after one reformulation cycle. |
| A2 | Payers and pharma sponsors will pay enough net revenue per run (USD 100-200 (estimate)) to cover multi-cartridge variable cost of a 50-analyte menu (USD 160-225 (estimate)) and fund runway. | Run 10 structured payer and 5 pharma interviews with a priced 10-15 analyte offer; model net revenue per run and per 50-analyte panel against a bottom-up COGS built from supplier quotes. | Median validated net revenue below USD 100 per run, no pharma sponsor willing to sign a paid feasibility contract of USD 50-100k, or modeled gross margin below 30% at 50k cartridges/month (modeled value at Month 9 (2027-07-13); proposed threshold). |
| A3 | A fingerstick drop yields enough usable plasma and cross-reactivity-free chemistry to run a 10-15 analyte cluster at <=5% bias and >=95% concordance, and the public can be convinced this is not another single-drop overclaim. | Run a >=100-subject fingerstick plasma-yield study plus spiked-plasma cross-reactivity matrix for a draft 10-15 analyte cluster; test messaging on 10 investors and clinicians. | Fewer than 95% of subjects give >=1.6 uL usable plasma with hemolysis index <50, or >=3 analyte pairs exceed 5% bias after one reformulation, or most reviewers equate the plan with prior failed claims. |
| A4 | FDA will accept staged per-cluster 510(k) submissions for a multi-cartridge menu with a clearance in Months 36-48 (2029-10-13 to 2030-10-13); a De Novo requirement (adding 12-18 months and USD 2-4M) is not the base case. | Engage a senior FDA regulatory consultant and run a predicate-device search; request the Pre-Submission Type B meeting in Months 2-3 (2026-12-13 to 2027-01-13) with written questions on 510(k) versus De Novo and on staged per-cluster clearance. | Written FDA feedback or consultant assessment indicates no suitable predicate and a De Novo pathway, or rejects per-cluster staged submissions for the cumulative menu. |
| A5 | The scarce IVD talent (microfluidics, assay chemistry, quality/regulatory) can be hired and retained at planned Bay Area compensation to reach 25-35 staff by Month 12 (2027-10-13) (estimate) without key-person loss before design freeze. | Open searches for the R&D director, quality/regulatory lead and assay chemistry lead; survey 10 candidates on compensation, equity and gate-linked vesting; check time-to-fill against Month 1 (2026-11-13) targets. | Fewer than 2 of 3 critical leaders accepted by Month 3 (2027-01-13), or accepted offers require compensation or equity materially above the recruiting budget of USD 300-500k/year (estimate). |
| A6 | Contract molders, instrument assemblers and reagent suppliers will accept binding quality agreements, price locks and 90-day capacity commitments for a low-volume start-up, and tooling and contract-manufacturer capex can be financed without equity beyond the planned tranches. | Send RFQs and draft quality agreements to 3 molders, 2 assemblers and suppliers of the top 5 analyte reagents; request tooling financing terms and minimum-volume requirements in writing. | Fewer than 2 qualified molders sign terms by Month 6 (2027-04-13), or suppliers require minimum volumes or prepayment that exceed the Newark and tooling budget (re-tooling risk USD 50-150k (estimate)). |
| A7 | Existing CLIA and FDA enforcement-discretion policy for lab-developed tests stays unchanged through the CLIA lab-service fallback period, so a lab-service route can be prepared and staffed by Month 12 (2027-10-13) without device clearance. | Commission a regulatory attorney opinion on the LDT enforcement position and CLIA certification timeline; ask the FDA Pre-Submission questions on a parallel CLIA route; draft a staffing and cost outline for the lab service. | Counsel or FDA written feedback indicates the lab-service route would require device clearance, or CLIA certification and staffing cannot be completed by Month 12 (2027-10-13). |
| A8 | Clinicians and health systems will accept a multi-cartridge workflow (about 4-5 runs for a 50-analyte menu) with a fingerstick collection, and the pharma beachhead will not be displaced by an incumbent or well-funded competitor before clearance. | Run workflow usability sessions with 15 clinicians and lab staff using mock multi-cartridge kits; interview 5 pharma sponsors on alternatives; map 10 competitors' filings and launches. | More than half of participants reject a multi-cartridge workflow, or a competitor with a 100+ analyte fingerstick panel is cleared or launching before Month 36 (2029-10-13). |
| A9 | Newark site, permits, utilities and long-lead equipment can be secured on schedule for BSL-2 reagent handling, so Phase 1 (USD 500-800k, proposed threshold) is operational by Month 6 (2027-04-13) and the filling line by Months 24-30 (2028-10-13 to 2029-04-13). | Pre-screen 3 Newark and Fremont sites with a permitting consultant; obtain written zoning and air-quality permit timelines; collect binding quotes and lead times for filling line, stability chambers and HVAC. | No site with zoning for biological reagent handling is leasable by Month 3 (2027-01-13), permits exceed 6 months, or equipment lead times exceed 12 months. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Runway That Ran Dry Before Revenue | Process/Financial | A2 | Head of Investor Relations and Strategic Finance | CRITICAL (20/25) |
| FM2 | The Cartridge That Would Not Repeat | Technical/Logistical | A1 | Manufacturing Engineering and Newark Operations Lead | CRITICAL (16/25) |
| FM3 | Another Drop, Another Doubt | Market/Human | A3 | Chief Product Officer / Commercial and Beachhead Strategy Lead | CRITICAL (15/25) |
| FM4 | The Bench Emptied at Design Freeze | Market/Human | A5 | Chief Executive Officer (with Head of People Operations) | HIGH (12/25) |
| FM5 | The Predicate That Never Existed | Process/Financial | A4 | Chief Quality Officer / Regulatory Affairs Lead | CRITICAL (15/25) |
| FM6 | The Supplier Who Said No | Technical/Logistical | A6 | Supply Chain, Sourcing, and Partner Management Lead | HIGH (12/25) |
| FM7 | The Cleanroom That Never Opened | Technical/Logistical | A9 | Manufacturing Engineering and Newark Operations Lead | HIGH (12/25) |
| FM8 | The Shortcut That Closed | Process/Financial | A7 | Head of Investor Relations and Strategic Finance | HIGH (12/25) |
| FM9 | Five Cartridges Too Many | Market/Human | A8 | Chief Product Officer / Commercial and Beachhead Strategy Lead | HIGH (12/25) |


### Failure Modes

#### FM1 - The Runway That Ran Dry Before Revenue

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: Head of Investor Relations and Strategic Finance
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Seed (USD 2-3M) is below Months 0-6 (2026-10-13 to 2027-04-13) commitments (USD 2.0-3.6M) (estimate).
- Pharma contracts slip beyond Month 9 (2027-07-13); payer price lands at USD 50-100 per run.
- 50-analyte menu costs USD 160-225 variable, so margin is negative.
- Newark Phase 1 capex is stranded; Series B/C gap of up to USD 17M (estimate) opens at Months 18-24 (2028-04-13 to 2028-10-13).
- Down round or shutdown follows.

##### Early Warning Signs
- No signed paid pharma contract by Month 9 (2027-07-13)
- Payer interviews cluster below USD 100 per run
- Cash runway under 6 months at Month 15 (2028-01-13)
- Modeled margin at 50k cartridges/month below 30% (modeled at Month 9 (2027-07-13); proposed threshold)

##### Tripwires
- Pharma/contract run-rate <USD 100k/month at Month 18 (2028-04-13)
- Validated net revenue per run <USD 100
- Cash runway <=6 months at any month-end
- Seed closed <USD 2M by Month 2 (2026-12-13)

##### Response Playbook
- Contain: Freeze all Newark and equipment commitments above USD 50k and halt Phase 2 orders within 5 business days.
- Assess: Rebuild the 60-month cash model with low-case price (USD 50-100) and measured COGS; quantify the gap by tranche.
- Respond: Activate lean pivot (-20-30% headcount), narrow to a 20-30 analyte panel or CLIA/pharma services model, and open a sized bridge or Series B.


**STOP RULE:** If validated net revenue is <USD 80 per run at Month 9 (2027-07-13) and no financing covering 12 months of runway is signed by Month 15 (2028-01-13), stop device scale-up and pivot to services or wind down.

---

#### FM2 - The Cartridge That Would Not Repeat

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A1
- **Owner**: Manufacturing Engineering and Newark Operations Lead
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Hand-built prototypes pass; production-equivalent lots do not.
- Molding, bonding and reagent-fill variability drive yield below 80%.
- Reagent lot CV exceeds 10% and shelf-life projects below 9 months.
- Tooling re-work (USD 50-150k, 3-4 months) repeats.
- Design freeze at Month 18 (2028-04-13) slips and Newark Phase 2 (USD 2-3M) is blocked.

##### Early Warning Signs
- Yield by step is not tracked at granular level
- Arrhenius R2 below 0.90 at Month 9 (2027-07-13)
- Second reagent supplier fails compatibility test
- Mold trial needs more than one iteration

##### Tripwires
- Pilot first-pass yield <80% (or lower CI <75%)
- Lot-to-lot CV >=10% across 3 lots
- Projected shelf-life <9 months
- Design freeze not signed by Month 18 (2028-04-13)

##### Response Playbook
- Contain: Pause Newark spend and long-lead orders; quarantine failing lots and freeze design changes.
- Assess: Run a 4-week design review with molder and assay lead; root-cause yield loss by process step and retest 500-1,000 units.
- Respond: Reformulate or redesign; if unresolved by Month 15 (2028-01-13), activate Fallback V1 by board vote within 2 weeks.


**STOP RULE:** If pilot yield is <80% (mean, or lower CI <75%) after the single 4-week design review and retest and remains unresolved by Month 15 (2028-01-13), cancel full cartridge build-out and activate Fallback V1 by board vote within 2 weeks. A yield of 80-85% is ambiguous: run 2-3 extra batches and re-evaluate.

---

#### FM3 - Another Drop, Another Doubt

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Chief Product Officer / Commercial and Beachhead Strategy Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Plasma yield or cross-reactivity forces Cluster 1 below 8 analytes.
- Investors and clinicians read the 500-test headline as a repeat of a prior Newark failure.
- Multi-cartridge workflow adds user burden; adoption stalls.
- Valuation discount of 20-50% (estimate) and lost pharma interest follow.
- Key scientific hires leave.

##### Early Warning Signs
- Plasma yield study misses target
- Advisory board members decline or demand claim changes
- Investor feedback cites Theranos comparisons
- Pilot users abandon multi-cartridge workflow

##### Tripwires
- <95% of >=100 subjects give >=1.6 uL plasma
- Cross-reactivity bias >5% for >=3 analyte pairs
- <2 of 5 target pharma sponsors engage by Month 6 (2027-04-13)
- Any external material uses '500 per drop' wording

##### Response Playbook
- Contain: Pull all external materials, enforce the no-500-claim rule and brief investors on current data within 5 business days.
- Assess: Publish the failure log to the advisory board, quantify analyte loss and survey 10 stakeholders on trust and adoption.
- Respond: Narrow Cluster 1 to validated analytes, reposition as a pharma biomarker tool and relaunch with independent published data.


**STOP RULE:** If Cluster 1 validates fewer than 8 analytes at >=95% concordance by Month 12 (2027-10-13), stop the single-drop positioning and pivot to Fallback V1 or a lab-service model.

---

#### FM4 - The Bench Emptied at Design Freeze

- **Archetype**: Market/Human
- **Root Cause**: Assumption A5
- **Owner**: Chief Executive Officer (with Head of People Operations)
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Bay Area competition for microfluidics, assay and quality talent delays Month 1 (2026-11-13) hires.
- Key-person loss near design freeze costs 2-3 months (estimate).
- Design controls lag, so DHF gaps surface at inspection.
- Remaining staff burn out; turnover above 20% (estimate) costs USD 200-400k/year.
- Gate evidence quality drops and credibility with investors and FDA erodes.

##### Early Warning Signs
- R&D director or quality lead not signed by Month 2 (2026-12-13)
- Two or more senior resignations in a quarter
- Offer acceptance rate below 50%
- Open critical roles unfilled for over 90 days

##### Tripwires
- Critical roles unfilled >=90 days after posting
- Annualized turnover >=20%
- Headcount <20 at Month 12 (2027-10-13)
- Any gate-owner (CTO, quality, assay lead) departure within 6 months of a gate

##### Response Playbook
- Contain: Freeze new scope and assign named deputies for every gate-critical role within 5 business days; secure retention grants for key staff.
- Assess: Map every open or at-risk role to the Month 6, 12 and 18 (2027-04-13, 2027-10-13, 2028-04-13) gates and quantify the schedule slip in weeks per role.
- Respond: Engage specialist contractors and academic partners, re-sequence hiring to quality and assay leads first, and re-baseline gates with the board.


**STOP RULE:** If the quality/regulatory lead and assay chemistry lead are both unfilled by Month 4 (2027-02-13), halt Newark Phase 1 spend and re-plan the program before further capital release.

---

#### FM5 - The Predicate That Never Existed

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Chief Quality Officer / Regulatory Affairs Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Pre-Submission feedback signals De Novo for a multiplex cartridge menu.
- Clearance moves from Months 36-48 (2029-10-13 to 2030-10-13) to Months 48-66 (2030-10-13 to 2032-04-13).
- Cost rises USD 2-4M (estimate); gap after Month 24 (2028-10-13) reaches about USD 21M (estimate).
- Clinical protocol (300-500 subjects) needs redesign.
- Series B is raised under pressure at a discount.

##### Early Warning Signs
- Predicate search finds no comparable cleared multiplex cartridge
- FDA asks for clinical-utility endpoints, not only concordance
- Pre-Submission slips past Month 6 (2027-04-13)
- Investors ask for De Novo case in diligence

##### Tripwires
- Pre-Submission not held by Month 6 (2027-04-13)
- FDA written feedback indicates De Novo
- Protocol redesign adds >=3 months
- Funding gap estimate >=USD 21M (estimate)

##### Response Playbook
- Contain: Pause protocol registration and clinical site contracts above USD 50k until FDA feedback is documented, within 5 business days.
- Assess: Re-model both timelines and funding needs with the regulatory consultant and quantify the added runway and cost.
- Respond: Resize Series B for +12-18 months, start the CLIA lab-service route in parallel and redesign the study to De Novo evidence.


**STOP RULE:** If De Novo is confirmed and committed funding does not cover clearance through Month 66 (2032-04-13) by Month 15 (2028-01-13), cancel device clearance and pivot to the CLIA lab-service or licensing model.

---

#### FM6 - The Supplier Who Said No

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A6
- **Owner**: Supply Chain, Sourcing, and Partner Management Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Molders decline or deprioritize a low-volume customer.
- Reagent suppliers refuse price locks or discontinue a binder.
- Single-source failure halts filling for 4-8 weeks (estimate).
- Mold tooling needs re-work (USD 50-150k, 3-4 months).
- Pilot fills at Month 9 (2027-07-13) slip, compressing the Month 12 (2027-10-13) gate.

##### Early Warning Signs
- Fewer than 2 qualified molders after audits
- Suppliers decline quality agreements
- Lead times exceed 90 days
- Supplier defect rate above 5%

##### Tripwires
- <2 molders signed by Month 6 (2027-04-13)
- Supplier defect rate >10% for 2 consecutive months
- Any critical reagent single-sourced at Month 9 (2027-07-13)
- Quoted lead time >12 weeks

##### Response Playbook
- Contain: Place buffer orders for 4-6 weeks of critical reagents and parts and quarantine suspect lots within 5 business days.
- Assess: Re-run the supplier risk map and quantify schedule and cost impact on pilot fill and gates.
- Respond: Activate backup suppliers within 2 weeks, move pilot fill to a contract manufacturer and renegotiate volume commitments or tooling financing.


**STOP RULE:** If no two qualified molders and no dual source for the top 5 analyte reagents exist by Month 9 (2027-07-13), stop Newark Phase 2 planning and reduce to Fallback V1 scope.

---

#### FM7 - The Cleanroom That Never Opened

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A9
- **Owner**: Manufacturing Engineering and Newark Operations Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- No leasable Newark space zoned for biological reagent handling.
- Permit review (air quality, wastewater, biohazard) runs past Month 6 (2027-04-13).
- HVAC and stability chamber lead times of 6-12 months (estimate) delay commissioning.
- Pilot fills and Arrhenius studies lack a controlled site, compressing the Month 12 (2027-10-13) gate.
- Cost overruns exceed the 20% equipment contingency.

##### Early Warning Signs
- No signed lease letter of intent by Month 2 (2026-12-13)
- Permit consultant timeline exceeds 6 months
- Equipment quotes show lead time above 9 months
- Build-out bids exceed budget by more than 20%

##### Tripwires
- No executed lease by Month 3 (2027-01-13)
- Permit approval not obtained by Month 5 (2027-03-13)
- Equipment lead time >12 months for any critical item
- Build-out cost forecast >120% of USD 500-800k Phase 1 budget (proposed threshold)

##### Response Playbook
- Contain: Stop all fit-out purchase orders above USD 50k and hold deposits until the lease and permits are confirmed.
- Assess: Re-baseline critical path with the permitting consultant and quantify the gate slip in weeks for pilot fill and shelf-life work.
- Respond: Move pilot fills and stability studies to a Fremont or Hayward contract site and re-sequence Newark to start after Month 12 (2027-10-13).


**STOP RULE:** If no compliant Newark site is leased and permitted by Month 9 (2027-07-13), cancel Phase 1 and run pilot work only at a contract site until Month 18 (2028-04-13).

---

#### FM8 - The Shortcut That Closed

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Head of Investor Relations and Strategic Finance
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Enforcement policy shifts or FDA signals the lab-service route needs clearance.
- CLIA certification and staffing slip beyond Month 12 (2027-10-13).
- The prepared lab-service route is not ready; the fallback cannot bridge a De Novo delay.
- Cost of the lab service stays unquantified, so the funding plan has no reliable Plan B.
- Series B is forced earlier at a discount.

##### Early Warning Signs
- Counsel opinion flags enforcement uncertainty
- CLIA certification plan not drafted by Month 6 (2027-04-13)
- No lab director candidate identified
- FDA feedback discourages parallel route

##### Tripwires
- CLIA fallback cost model not complete by Month 6 (2027-04-13)
- Laboratory director not hired by Month 9 (2027-07-13)
- FDA or counsel written view that clearance is required
- Lab-service route not prepared and staffed by Month 12 (2027-10-13)

##### Response Playbook
- Contain: Stop spending on lab-service build-out above USD 100k until counsel confirms the legal position in writing.
- Assess: Model funding runway without lab-service revenue (excluded from the base case until cost and revenue are quantified at the Month 6 = 2027-04-13 cost model) and quantify the Series B pull-forward in months.
- Respond: Re-plan to a licensing or pharma-services bridge and raise a sized bridge round before runway falls below 9 months.


**STOP RULE:** If the lab-service route is confirmed unavailable and runway is below 12 months at Month 12 (2027-10-13), freeze device scale-up and pivot to pharma services or licensing.

---

#### FM9 - Five Cartridges Too Many

- **Archetype**: Market/Human
- **Root Cause**: Assumption A8
- **Owner**: Chief Product Officer / Commercial and Beachhead Strategy Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Users find 4-5 runs per 50-analyte menu burdensome; adoption stalls.
- A competitor clears a broader fingerstick panel first and compresses pricing.
- Pharma sponsors prefer existing multiplex platforms for biomarker work.
- Net revenue per run falls toward USD 50-100 (estimate).
- Newark volume of 10k cartridges/month by Month 36 (2029-10-13) is not demanded.

##### Early Warning Signs
- Usability sessions show repeated handling errors
- Pilot sites ask for a single-cartridge option
- Competitor files a multiplex 510(k)
- Pharma sponsors cite incumbent platforms as preferred

##### Tripwires
- More than 50% of usability participants reject workflow
- Fewer than 2 pharma sponsors engaged by Month 6 (2027-04-13)
- Competitor 510(k) for 100+ analytes filed before Month 30 (2029-04-13)
- Pilot-site invalid-run rate >10% (proposed threshold)

##### Response Playbook
- Contain: Pause Cluster 2-3 design spending and Newark Phase 2 planning until adoption data is reviewed.
- Assess: Survey 20 users and 5 sponsors on workflow and competing platforms; quantify demand at USD 100-200 per run.
- Respond: Reposition to a narrow high-value cluster or pharma biomarker service and redesign collection to cut handling steps.


**STOP RULE:** If fewer than 2 paid pharma or health-system customers commit by Month 15 (2028-01-13), stop menu expansion and pivot to a single-cluster or services business.
