### 1. Project Sponsor and Founding Team identify and formally confirm the Project Steering Committee membership (CEO/Founder, Lead Investor or Board Delegate, CFO, Chief R&D Officer, Chief Quality Officer). Confirm availability, roles, decision rights and conflict-of-interest status.

**Responsible Body/Role:** Project Sponsor (or CEO/Founder acting as initiating authority) in coordination with Lead Investor

**Suggested Timeframe:** Within 1 week of project start (Month 0 = 2026-10-13, by 2026-10-20)

**Key Outputs/Deliverables:**

- Steering Committee membership roster with names, titles, affiliations
- Signed commitment letters from all 5 members confirming availability
- Conflict-of-interest disclosure forms (signed by each member)

**Dependencies:**

- Project Sponsor and Lead Investor identified
- CEO/Founder, CFO, R&D and Quality leadership roles defined and staffing authorized

### 2. Project Steering Committee hold inaugural founding meeting (2-3 hours) to finalize charter, define Fallback Panel V1 (50-analyte core with 4-5 cartridges), lock gate criteria (yield ≥85%, concordance ≥95%, shelf-life ≥12 months, plasma separation ≥95%, COGS ≤USD 25/cartridge), approve capital tranches and timeline, assign gate-meeting chair (typically CEO), establish monthly dashboard and reporting cadence.

**Responsible Body/Role:** Project Steering Committee (newly formed)

**Suggested Timeframe:** Month 0.5 (2026-10-28) (within 2 weeks of project start, by 2026-10-28)

**Key Outputs/Deliverables:**

- Steering Committee Charter (roles, decision rights, approval authorities, escalation paths)
- Fallback Panel V1 Definition Document (50 analytes, cartridge clustering, clinical use case)
- Gate Criteria and Thresholds Document (quantitative pass/fail/ambiguous criteria for Months 6, 12, 18, 24 = 2027-04-13, 2027-10-13, 2028-04-13, 2028-10-13)
- Capital Tranches Schedule (Seed USD 2-3M Months 0-6 = 2026-10-13 to 2027-04-13, A1 USD 3-4M Month 6 = 2027-04-13 gate, A2 USD 2-3M Month 12 = 2027-10-13 gate, etc.)
- Monthly Dashboard Template (analyte performance, yield, cash burn, regulatory milestones)

**Dependencies:**

- Steering Committee membership confirmed
- Project vision and strategic path (modular clusters, pharma beachhead, Newark phasing) understood by all members

### 3. CEO/Founder (or designated Formation Lead) formally draft and circulate the Steering Committee Charter and decision authorities document to all members for written comment. Incorporate feedback and finalize within 1 week.

**Responsible Body/Role:** CEO/Founder or Project Manager (as Formation Lead, before Steering Committee is fully operational for formal decisions)

**Suggested Timeframe:** Month 0.5 (2026-10-28) (within 2 weeks of project start, concurrent with membership confirmation)

**Key Outputs/Deliverables:**

- Draft Steering Committee Charter v0.1 (circulated for review)
- Feedback Summary (member comments consolidated)
- Final Steering Committee Charter v1.0 (signed off by CEO and Lead Investor)

**Dependencies:**

- Steering Committee membership roster confirmed
- Project governance structure and decision authorities outlined

### 4. Steering Committee formally adopt and publish the Fallback Panel V1 Definition (50 analytes, cartridge design, clinical scope), gate criteria, and capital-tranche schedule. Board votes on these foundational decisions; document voting record and any dissents.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Month 0.5 (2026-10-28) to Month 1 (2026-11-13) (within 3 weeks of project start)

**Key Outputs/Deliverables:**

- Signed Fallback Panel V1 Definition and Board Approval Minutes
- Gate Criteria and Thresholds Approval Minutes (voting record)
- Capital Tranches Approval Minutes (equity rounds and release conditions signed off)

**Dependencies:**

- Steering Committee Charter finalized
- Fallback Panel V1 and gate criteria drafted and ready for board review

### 5. CEO/Founder recruit and hire Chief R&D Officer and Chief Quality Officer / Regulatory Lead as first employees or co-founders (critical early hires). Finalize offer letters, compensation, equity, and onboarding plan.

**Responsible Body/Role:** CEO/Founder and HR/People Lead (or retained recruiter)

**Suggested Timeframe:** Month 1 (2026-11-13)

**Key Outputs/Deliverables:**

- Signed offer letters for R&D Director and Quality/Regulatory Lead
- First-hire onboarding plan and start dates
- Equity grant documents (vesting tied to technical milestones and gates)

**Dependencies:**

- CEO/Founder and lead investor available to lead recruitment
- Compensation and equity framework approved by board

### 6. Chief R&D Officer and Chief Quality Officer/Regulatory Lead, upon hire, jointly establish the Operations and Execution Committee charter, membership, and meeting cadence. Define design-change log process, analyte-review protocol, supplier scorecard, and regulatory-readiness assessment schedule.

**Responsible Body/Role:** Chief R&D Officer (as chair) and Chief Quality Officer / Regulatory Lead, with CEO approval

**Suggested Timeframe:** Month 1 (2026-11-13), immediately upon hire or within 1 week

**Key Outputs/Deliverables:**

- Operations and Execution Committee Charter and Membership List
- Design-Change Log Template and Approval Thresholds (USD 50k, 2-week impact ceiling)
- Analyte Review Meeting Schedule and Performance Report Template
- Supplier Scorecard Template (defect rate, delivery, cost tracking)
- Monthly Executive Sync Agenda and Meeting Cadence (weekly 1-hour, monthly full 2-hour)

**Dependencies:**

- Chief R&D Officer and Quality/Regulatory Lead hired and in role
- Project Steering Committee Fallback Panel V1 and gate criteria finalized

### 7. CEO/Founder and Chief Quality Officer develop and communicate Compliance, Ethics and Risk Management Committee charter. Hire or contract Chief Compliance Officer or General Counsel. Establish conflict-of-interest policy, data-integrity policy, and marketing/claims guidelines (no '500 tests per drop' claims until 3 clusters validated).

**Responsible Body/Role:** CEO/Founder (initiating), Chief Quality Officer (QMS liaison), and Chief Compliance Officer/General Counsel (upon hire)

**Suggested Timeframe:** Month 1 (2026-11-13) to Month 2 (2026-12-13 to 2026-12-13)

**Key Outputs/Deliverables:**

- Compliance, Ethics and Risk Management Committee Charter
- Conflict-of-Interest Policy (signed by CEO, board, early employees)
- Data-Integrity and Research-Misconduct Policy
- Marketing and Claims Compliance Policy (prohibiting '500 tests per drop' claims until 3 clusters validated)
- Risk Register Template and Scoring Methodology (likelihood × severity scale 1-25; escalate >9)

**Dependencies:**

- CEO/Founder and Chief Quality Officer in role
- Project governance structure and Fallback Panel V1 finalized

### 8. Project Sponsor and CEO/Founder identify and recruit 5-7 external Technical Advisory Group members (microfluidics, immunoassay chemistry, manufacturing, regulatory affairs experts with 15+ years experience, no financial interest in suppliers). Finalize advisory agreements and charter.

**Responsible Body/Role:** CEO/Founder (recruitment lead) with input from Chief R&D Officer and Lead Investor

**Suggested Timeframe:** Month 0.5 (2026-10-28) to Month 1 (2026-11-13 to 2026-11-13)

**Key Outputs/Deliverables:**

- Technical Advisory Group Roster (names, affiliations, expertise areas)
- Signed advisory agreements (scope, meeting cadence, confidentiality, no financial conflicts)
- Technical Advisory Group Charter (decision rights, validation authority, escalation path)

**Dependencies:**

- CEO/Founder and Lead Investor available to recruit external experts
- Project vision and technical risks (plasma separation, cross-reactivity, yield) clearly articulated

### 9. Project Steering Committee formally establish the Compliance, Ethics and Risk Management Committee. Approve charter, confirm Chief Compliance Officer/General Counsel hire, and authorize policies drafted in Month 2 (2026-12-13). Board votes on risk-management framework and data-integrity standards.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Month 2 (2026-12-13)

**Key Outputs/Deliverables:**

- Compliance, Ethics and Risk Management Committee Charter Approval Minutes
- Risk Management Framework and Enterprise Risk Register v1.0
- Compliance Policies Approval and All-Staff Communication (data integrity, conflict-of-interest, marketing claims)

**Dependencies:**

- Steering Committee in place with established meeting cadence
- Chief Compliance Officer/General Counsel hired or contracted
- Policies drafted and ready for board review

### 10. Chief R&D Officer, Chief Quality Officer, and Finance Lead jointly develop the 60-month cash-flow model with gate-linked tranches and lean-pivot trigger (pharma revenue <USD 100k/month at Month 18 = 2028-04-13 triggers 20-30% headcount reduction). Model pessimistic pharma scenario and non-dilutive funding (SBIR/STTR grants, partnerships). Finalize funding strategy and Series A sizing.

**Responsible Body/Role:** Chief R&D Officer, Chief Quality Officer, and CFO/Finance Lead

**Suggested Timeframe:** Month 2 (2026-12-13)

**Key Outputs/Deliverables:**

- 60-Month Cash-Flow Model (Months 0-60 = 2026-10-13 to 2031-10-13) with quarterly burn and gate-linked releases
- Pharma Revenue Scenarios (pessimistic, base, optimistic with probability-weighted funding need)
- Non-Dilutive Funding Strategy (SBIR/STTR grant applications, expected awards by Month 10-12 = 2027-08-13 to 2027-10-13)
- Series A Sizing and Tranche Approval Memo (recommended USD 10-15M Series A, phased release tied to gates)

**Dependencies:**

- Project Steering Committee capital tranches and lean-pivot trigger approved
- Chief R&D Officer and CFO in role; Finance lead identified

### 11. CEO/Founder and Chief Compliance Officer initiate freedom-to-operate (FTO) analysis with external patent counsel. Develop IP strategy document (what to patent, what to publish, what to trade-secret). Identify high-priority patent filings and provisional application timeline.

**Responsible Body/Role:** CEO/Founder and Chief Compliance Officer / General Counsel

**Suggested Timeframe:** Month 2 (2026-12-13)

**Key Outputs/Deliverables:**

- Freedom-to-Operate Preliminary Report (major patent risks identified, if any, in microfluidics, immunoassay, plasma separation)
- IP Strategy Document (filing plan, publication strategy, trade-secret inventory)
- Patent Counsel Engagement Letter and Budget (USD 50-100k for FTO and provisional filings, Months 0-6 = 2026-10-13 to 2027-04-13)

**Dependencies:**

- CEO/Founder, lead investor, and patent counsel available
- Cartridge architecture and fluidic design concepts articulated

### 12. Chief Quality Officer and Chief Compliance Officer jointly establish electronic quality management system (QMS), design-control system, and document-management infrastructure. Implement design-history file (DHF) template, change-control log, risk-management file (ISO 14971), and design-review meeting schedule.

**Responsible Body/Role:** Chief Quality Officer (owner) and Chief Compliance Officer (oversight)

**Suggested Timeframe:** Month 2 (2026-12-13) to Month 3 (2027-01-13 to 2027-01-13)

**Key Outputs/Deliverables:**

- Electronic QMS Platform Live (document management, workflow, audit trail)
- Design-History File (DHF) Template and Initial Population (from Month 0 = 2026-10-13 decisions)
- Change-Control Log Template and Approval Process (minor <USD 50k, USD 50k+ escalates to Steering Committee)
- Risk-Management File Template (ISO 14971 risk register, design-failure analysis, risk controls)
- Design-Review Meeting Schedule (monthly design reviews with R&D, quality, regulatory leads)

**Dependencies:**

- Chief Quality Officer hired and operational
- QMS software platform (e.g., MasterControl, Veeva, or equivalent) selected and contract signed

### 13. Chief R&D Officer initiate detailed design-for-manufacturability (DFM) review with 2-3 qualified contract injection-molding partners. Present cartridge architecture concepts and evaluate moldability, tolerances, process windows, lead times, and cost. Obtain mold quotes and identify design improvements to reduce yield risk.

**Responsible Body/Role:** Chief R&D Officer (lead) with Microfluidics/CAD Engineer and Procurement Lead

**Suggested Timeframe:** Month 3 (2027-01-13)

**Key Outputs/Deliverables:**

- DFM Review Summary from 2-3 Molders (moldability assessment, tolerance recommendations, yield concerns)
- Mold Tooling Quotes (design, build, and first-article-run pricing; lead times 4-6 months)
- Design-Improvement Recommendations (modifications to cartridge to improve moldability)

**Dependencies:**

- Chief R&D Officer and microfluidics engineers in role
- Cartridge architecture and fluidic design concepts mature enough for molding assessment
- 2-3 contract molders identified and contacted

### 14. Chief R&D Officer and Chief Quality Officer jointly finalize Fallback Panel V1 analyte list (50 analytes, 4-5 cartridges of 10-15 analytes each). Lock analyte selection criteria (clinical value, reference-method availability, cross-reactivity risk, sensitivity feasibility). Create Analyte Performance Report template with monthly tracking of concordance, CV, shelf-life, yield per analyte.

**Responsible Body/Role:** Chief R&D Officer (technical lead) and Chief Quality Officer (quality and regulatory alignment)

**Suggested Timeframe:** Month 2 (2026-12-13)

**Key Outputs/Deliverables:**

- Fallback Panel V1 Analyte List (50 analytes, grouped into 4-5 cartridges with clinical clustering)
- Analyte Selection Criteria and Justification Document
- Analyte Performance Report Template v1.0 (columns: analyte name, concordance mean/95% CI, CV, shelf-life projection, yield, status: In Progress/Pass/Fail/Retired)

**Dependencies:**

- Chief R&D Officer and Chief Quality Officer in role
- Steering Committee Fallback Panel V1 definition approved (general 50-analyte target)

### 15. CEO/Founder and Chief R&D Officer identify and initiate relationships with academic clinical research partner for pre-submission clinical-study co-design and future patient-sample enrollment (Months 12-24 = 2027-10-13 to 2028-10-13). Issue RFP or letter of intent to 3-5 academic medical centers. Negotiate partnership terms (data ownership, publication rights, cost-sharing).

**Responsible Body/Role:** CEO/Founder (business lead) and Chief R&D Officer (scientific lead)

**Suggested Timeframe:** Month 3 (2027-01-13)

**Key Outputs/Deliverables:**

- Academic Partner RFP or Letter of Intent (3-5 centers contacted)
- Partnership Discussions Summary (candidate sites, preliminary terms)
- Signed Partnership Agreement or Letter of Intent with primary academic site (expected by Month 6 = 2027-04-13)

**Dependencies:**

- CEO/Founder and Chief R&D Officer in role
- Clinical-study scope and timeline (Months 12-24 = 2027-10-13 to 2028-10-13) defined

### 16. Chief R&D Officer establish analytical-feasibility and cross-reactivity testing protocol for Cluster 1 (10-15 analytes). Design systematic screening: each analyte measured alone, in pairs, and in full multiplex, spiked into human plasma with elevated interferents (hemoglobin, bilirubin, lipemia, rheumatoid factor). Set success criteria: ≤5% bias at 10× physiologic interferent concentration. Conduct testing over Months 4-6 (2027-02-13 to 2027-04-13).

**Responsible Body/Role:** Chief R&D Officer (owner) and Assay Chemistry Lead

**Suggested Timeframe:** Month 3 (2027-01-13) to Month 4 (2027-02-13 to 2027-02-13), with testing execution Months 4-6 (2027-02-13 to 2027-04-13)

**Key Outputs/Deliverables:**

- Cross-Reactivity Testing Protocol and Success Criteria
- Cross-Reactivity Study Plan (sample selection, interferent levels, measurement methods)
- Preliminary Cross-Reactivity Data (by Month 5 = 2027-03-13) and Preliminary Report by Month 6 (2027-04-13)

**Dependencies:**

- Chief R&D Officer and Assay Chemistry Lead in role
- Fallback Panel V1 Cluster 1 analyte list finalized (Month 2 = 2026-12-13)

### 17. Chief R&D Officer establish plasma-separation feasibility study protocol for fingerstick collection. Design study: collect samples from 100+ fingerstick subjects, measure plasma yield, hemolysis rate, and sample adequacy. Set success gate: ≥95% of samples yield ≥1.6 microliters usable plasma. Conduct study over Months 4-6 (2027-02-13 to 2027-04-13).

**Responsible Body/Role:** Chief R&D Officer (owner) and Sample-Preparation / Microfluidics Engineer

**Suggested Timeframe:** Month 3 (2027-01-13) to Month 4 (2027-02-13 to 2027-02-13), with testing execution Months 4-6 (2027-02-13 to 2027-04-13)

**Key Outputs/Deliverables:**

- Plasma-Separation Feasibility Study Protocol
- Subject Recruitment and Informed-Consent Plan (100+ fingerstick subjects)
- Preliminary Plasma-Yield Data (by Month 5 = 2027-03-13) and Interim Report by Month 6 (2027-04-13)

**Dependencies:**

- Chief R&D Officer and sample-preparation engineers in role
- Academic clinical partner identified for subject recruitment
- Institutional review board (IRB) approval pathway understood

### 18. Chief Compliance Officer and Chief Quality Officer prepare materials for FDA Pre-Submission Type B meeting. Draft questions: (1) Is 510(k) or De Novo required for a 50-analyte or 100-analyte multiplex immunoassay panel? (2) Can staged per-cluster 510(k)s be filed? (3) What analytical and clinical evidence is expected? (4) Can a CLIA lab-service route run in parallel? Submit Pre-Submission request to FDA CDRH by Month 3 (2027-01-13). Target meeting by Month 6 (2027-04-13).

**Responsible Body/Role:** Chief Compliance Officer / Regulatory Lead (lead) and Chief Quality Officer (quality-system context)

**Suggested Timeframe:** Month 2 (2026-12-13) to Month 3 (2027-01-13 to 2027-01-13) for request submission; meeting held Month 6 (2027-04-13)

**Key Outputs/Deliverables:**

- FDA Pre-Submission Type B Meeting Request (submitted to FDA CDRH by Month 3 = 2027-01-13)
- Pre-Sub Meeting Preparation Package (slides, intended use statement, proposed regulatory pathway, clinical-study design outline)
- FDA Pre-Submission Meeting Minutes and Agency Feedback (by Month 6 = 2027-04-13)

**Dependencies:**

- Chief Compliance Officer and Chief Quality Officer in role
- Regulatory consultant or counsel engaged to support Pre-Sub preparation (USD 50-100k budget, Months 0-6 = 2026-10-13 to 2027-04-13)

### 19. Chief R&D Officer initiate stability-testing program for Cluster 1. Prepare cartridge lots at Month 3 (2027-01-13). Launch real-time stability (2-8°C storage, monthly testing for 24 months) and accelerated stability (25°C/60% RH and 40°C/75% RH per ICH, testing at days 0, 7, 14, 30, 60, 90, 180). Set gate at Month 12 (2027-10-13): if shelf-life projected ≥12 months with Arrhenius R² >0.90, proceed; if <9 months, reformulate and delay launch 3 months.

**Responsible Body/Role:** Chief R&D Officer (owner) and Assay Chemistry / Formulation Lead

**Suggested Timeframe:** Month 3 (2027-01-13) for protocol setup and initial lot preparation

**Key Outputs/Deliverables:**

- Stability-Testing Protocol (real-time and accelerated per ICH Q1A/Q1B)
- Initial Lot Preparation and Storage (at Month 3 = 2027-01-13)
- Month 6 (2027-04-13) Interim Stability Report (90 days accelerated data, initial real-time readings)
- Month 12 (2027-10-13) Shelf-Life Projection and Gate Determination (Arrhenius model, pass/fail decision)

**Dependencies:**

- Chief R&D Officer and formulation chemist in role
- Cluster 1 cartridge design and reagent formulations finalized (by Month 3 = 2027-01-13)

### 20. CEO/Founder and Chief R&D Officer identify pharma and grant-funding prospects. Target 5-10 potential pharma sponsors (biomarker monitoring, Phase 2b/Phase 3 clinical trials). Issue 'feasibility partnership' letters; no committed funding expected yet. Simultaneously, identify SBIR/STTR grant opportunities (NIH, NSF, DOE) and prepare Phase 1 applications (deadline Month 4-5 = 2027-02-13 to 2027-03-13).

**Responsible Body/Role:** CEO/Founder (business lead) and Chief R&D Officer (scientific credibility)

**Suggested Timeframe:** Month 3 (2027-01-13)

**Key Outputs/Deliverables:**

- Pharma Prospect List (5-10 sponsors, preliminary outreach)
- Feasibility Partnership Letter (describing platform, data-generation opportunity, no funding request yet)
- SBIR/STTR Grant Application Package (Phase 1 grants, USD 100-500k, due Month 4-5 = 2027-02-13 to 2027-03-13)

**Dependencies:**

- CEO/Founder and Chief R&D Officer in role
- Platform concept and preliminary data (cross-reactivity, plasma separation) available by Month 3 (2027-01-13)

### 21. Chief Quality Officer conduct internal ISO 13485 compliance assessment (Month 3-4 = 2027-01-13 to 2027-02-13). Audit design controls, documentation, management of change, complaint handling, supplier management, and personnel training. Identify gaps and develop corrective-action plan for certification by Month 18 (2028-04-13).

**Responsible Body/Role:** Chief Quality Officer (lead) with external ISO 13485 consultant if needed

**Suggested Timeframe:** Month 3 (2027-01-13) to Month 4 (2027-02-13 to 2027-02-13)

**Key Outputs/Deliverables:**

- Internal ISO 13485 Gap Assessment Report (design controls, QMS documentation, CAPA, supplier management, training records)
- Corrective-Action Plan to achieve ISO 13485 certification by Month 18 (2028-04-13)
- ISO 13485 Consultant Engagement (if external support needed; budget USD 50-100k)

**Dependencies:**

- Chief Quality Officer in role
- QMS platform and design-control system established (Month 2-3 = 2026-12-13 to 2027-01-13)

### 22. Chief R&D Officer and Operations Committee conduct preliminary supplier-identification and qualification planning. Identify 2-3 candidate contract-injection-molders, 1-2 reagent suppliers per critical analyte, and potential instrument-assembly partner. Request quality certifications, lead-time quotes, and quality-agreement templates. Target dual sourcing for highest-risk reagents.

**Responsible Body/Role:** Chief R&D Officer (technical evaluation) and Procurement Lead / Operations Committee

**Suggested Timeframe:** Month 4 (2027-02-13)

**Key Outputs/Deliverables:**

- Supplier Candidate List (molders, reagent suppliers, assembly partners; names, capabilities, references)
- Supplier Qualification Checklist (quality certifications, financial stability, lead-time commitments)
- Quality-Agreement Template and Critical Reagent Dual-Source Plan

**Dependencies:**

- Chief R&D Officer, Procurement Lead, and Supplier/Quality team in role
- Cartridge design and analyte list mature enough to specify supplier requirements

### 23. Chief R&D Officer and CFO develop bottom-up cost-of-goods (COGS) model for Cluster 1. Estimate: cartridge body USD 2-4, fluidic bonding USD 1-2, reagents USD 4-8, QC consumables USD 2-4, packaging USD 2-3. Lock COGS ceiling of USD 25 per cartridge. Model per-run reimbursement (USD 100-200 base case) and gross-margin target (≥60% at 50k cartridges/month).

**Responsible Body/Role:** Chief R&D Officer (engineering cost driver estimation) and CFO / Finance Lead (financial modeling)

**Suggested Timeframe:** Month 3 (2027-01-13)

**Key Outputs/Deliverables:**

- Bottom-Up COGS Model (component-level cost breakdown for Cluster 1)
- COGS Ceiling Lock Document (USD 25 per cartridge, approved by Steering Committee)
- Unit-Economics Projection (revenue scenarios USD 50-500 per panel, margin sensitivity analysis)

**Dependencies:**

- Chief R&D Officer, CFO, and Finance Lead in role
- Cluster 1 cartridge design and analyte list finalized

### 24. Operations Committee formally establish monthly Analyte Review Meeting schedule (Months 3-12 = 2027-01-13 to 2027-10-13). Monthly meetings assess each Cluster 1 analyte against thresholds (concordance ≥95%, CV <10%, shelf-life ≥12 months projected). Decide: redesign (re-test within 4-8 weeks), retire (remove from panel), or defer (move to Cluster 2). Document decisions in Analyte Performance Report visible to board.

**Responsible Body/Role:** Operations Committee (Chief R&D Officer, Quality Lead, Assay Chemistry Lead, and others)

**Suggested Timeframe:** Month 3 (2027-01-13), with first meeting Month 4 (2027-02-13) and monthly thereafter

**Key Outputs/Deliverables:**

- Analyte Review Meeting Schedule (monthly Months 4-12 = 2027-02-13 to 2027-10-13)
- Analyte Review Meeting Minutes (analyte status, pass/fail/redesign decisions, timeline for re-tests)
- Analyte Performance Report (updated monthly, cumulative view of all analyte status)

**Dependencies:**

- Operations Committee established with monthly cadence
- Analyte Performance Report template created and populated with baseline data

### 25. Chief Compliance Officer and project team develop comprehensive communications and transparency strategy. Commit publicly to: (1) pre-registered, independent clinical studies with published protocols (ClinicalTrials.gov registration by Month 6 = 2027-04-13); (2) monthly public data dashboard (assay performance, analytes passing/failing, cross-reactivity results); (3) external scientific advisory board with quarterly public meetings and data audit access; (4) quarterly investor and stakeholder updates (gate results, miss/make analysis); (5) no '500 tests per drop' marketing claim until 3 clusters independently validated. Issue public statement of commitment (Month 2-3 = 2026-12-13 to 2027-01-13).

**Responsible Body/Role:** Chief Compliance Officer (policy lead) and CEO/Founder (public announcement)

**Suggested Timeframe:** Month 2 (2026-12-13) to Month 3 (2027-01-13 to 2027-01-13) for policy; public announcement Month 3 (2027-01-13)

**Key Outputs/Deliverables:**

- Science-First Communications Charter (public commitment document, signed by CEO and board)
- Pre-Registration Plan for Clinical Study (ClinicalTrials.gov registration by Month 6 = 2027-04-13)
- Monthly Data-Dashboard Template and Reporting Plan
- Advisory Board Structure and Meeting Schedule (quarterly public meetings)
- Marketing and Claims Policy (written policy prohibiting '500 tests per drop' claims before validation)

**Dependencies:**

- CEO/Founder, Chief Compliance Officer, and Chief R&D Officer in role
- Project Steering Committee and board aware of and committed to transparency strategy

### 26. Technical Advisory Group hold inaugural meeting (2-3 hours, virtual). Review project overview, risk map, and technical governance. Establish quarterly meeting cadence and identify highest-priority technical assessments (plasma separation, cross-reactivity, yield). Schedule ad-hoc focused reviews at Months 3, 5-6 (2027-01-13, 2027-03-13 to 2027-04-13) for DFM, cross-reactivity screening.

**Responsible Body/Role:** Technical Advisory Group (newly formed external advisors) facilitated by Chief R&D Officer

**Suggested Timeframe:** Month 1 (2026-11-13) to Month 2 (2026-12-13 to 2026-12-13)

**Key Outputs/Deliverables:**

- Technical Advisory Group Inaugural Meeting Minutes (risk prioritization, assessment schedule)
- Quarterly Meeting Schedule and Agenda Template
- Ad-Hoc Assessment Plan (DFM review Month 3 = 2027-01-13, cross-reactivity Month 5-6 = 2027-03-13 to 2027-04-13)

**Dependencies:**

- Technical Advisory Group members confirmed and advisory agreements signed
- Chief R&D Officer available to facilitate and brief advisors

### 27. Compliance, Ethics and Risk Management Committee hold inaugural meeting (2 hours). Review enterprise risk register (initial 20+ risks identified: analytical feasibility, regulatory pathway, funding gap, unit economics, reputational damage, supply-chain, talent, payer coverage, shelf-life, equipment lead times, clinical study design, scope creep, software/cybersecurity, competition, plasma separation, cold chain, facility cost, IP/partnerships). Establish quarterly review cadence and assign risk owners. Set escalation triggers (risk score >9 escalates to Steering Committee within 5 business days).

**Responsible Body/Role:** Compliance, Ethics and Risk Management Committee (Chief Compliance Officer, Chief Quality Officer, CFO, and external ethics advisor)

**Suggested Timeframe:** Month 2 (2026-12-13)

**Key Outputs/Deliverables:**

- Enterprise Risk Register v1.0 (20+ risks, likelihood/severity scoring, owners, mitigation plans)
- Risk-Scoring Methodology and Escalation Thresholds (score >9 = immediate Steering Committee escalation)
- Quarterly Risk-Review Meeting Schedule
- Data-Integrity, Research-Misconduct, and Conflict-of-Interest Policies (communicated to all staff)

**Dependencies:**

- Chief Compliance Officer, Chief Quality Officer, and external advisor in place
- Project Steering Committee and risk landscape understood by committee

### 28. Operations Committee establish supplier-scorecard process and begin monthly supplier monitoring. For each contract molder, reagent supplier, and assembly partner, track: defect rate, on-time delivery %, cost performance vs. contract, and quality-agreement compliance. Set escalation: if defect rate exceeds 10% or delivery delay exceeds 2 weeks, escalate within 1 week; activate backup supplier within 2 weeks if primary fails.

**Responsible Body/Role:** Operations Committee (Chief R&D Officer, Procurement Lead, Quality Lead, and Supplier/Quality Manager)

**Suggested Timeframe:** Month 4 (2027-02-13), with supplier scorecard live by Month 6 (2027-04-13)

**Key Outputs/Deliverables:**

- Supplier Scorecard Template (columns: supplier name, defect rate %, on-time delivery %, cost variance, quality-agreement status, escalation flag)
- Monthly Supplier Review Meeting (1 hour, track and escalate quality failures)
- Supplier Escalation and Backup-Activation Plan (defect >10% = 2-week backup activation)

**Dependencies:**

- Primary suppliers identified and quality agreements signed (by Month 4 = 2027-02-13)
- Supplier scorecard system integrated into operations

### 29. Operations Committee issue request for quotation (RFQ) to 2-3 qualified contract-injection-molders, specifying cartridge design, first-article requirements, and mold lead time. Request quotes for mold design/build, first-article-run (5,000-10,000 units), and per-cartridge pricing at 1k, 10k, 50k volumes. Target quotes received by Month 4 (2027-02-13); mold-order decision deferred until design freeze (Month 18 = 2028-04-13).

**Responsible Body/Role:** Chief R&D Officer (technical specifications) and Procurement Lead (RFQ issuance and quote management)

**Suggested Timeframe:** Month 3 (2027-01-13) to Month 4 (2027-02-13 to 2027-02-13)

**Key Outputs/Deliverables:**

- RFQ for Contract-Injection Molding (cartridge design, first-article requirements, lead-time and cost expectations)
- Molder Quotes Summary (2-3 quotes received by Month 4 = 2027-02-13; mold cost, lead time, per-unit pricing)
- Design-for-Manufacturability Feedback Consolidated (design improvement recommendations from molders)

**Dependencies:**

- Cartridge design mature enough for molding RFQ (frozen by Month 3-4 = 2027-01-13 to 2027-02-13)
- 2-3 qualified contract molders identified and RFQ issued

### 30. Chief Compliance Officer coordinate clinical-study protocol development with academic clinical partner. Define study design: 300-500 subjects (healthy and disease states), paired fingerstick and reference samples, method-comparison for each analyte, pre-registered protocol on ClinicalTrials.gov. Set success criteria: ≥95% concordance, CV <10% per analyte. Target protocol approval by Month 9 (2027-07-13) and IRB approval by Month 12 (2027-10-13).

**Responsible Body/Role:** Chief Compliance Officer / Regulatory Lead (lead) with Chief R&D Officer and academic partner

**Suggested Timeframe:** Month 3 (2027-01-13) to Month 9 (2027-07-13 to 2027-07-13) for protocol development; IRB approval target Month 12 (2027-10-13)

**Key Outputs/Deliverables:**

- Clinical-Study Protocol Draft v1.0 (study design, sample size, inclusion/exclusion, analytical acceptance criteria)
- Sample-Size Power Calculation (based on smallest-effect-size analyte, 80% power, 5% significance)
- Pre-Registration on ClinicalTrials.gov (by Month 9 = 2027-07-13)
- IRB Submission Package (by Month 10 = 2027-08-13); IRB approval expected Month 12 (2027-10-13)

**Dependencies:**

- Chief Compliance Officer, Chief R&D Officer, and academic clinical partner in role
- Cluster 1 analyte list and study timeline finalized

### 31. Project Steering Committee hold Month 6 (2027-04-13) comprehensive gate-review meeting (4-6 hours). Assess Month 6 (2027-04-13) gate criteria: plasma separation ≥95% of ≥100 subjects with ≥1.6 µL plasma, hemolysis <50; cross-reactivity ≤5% bias; COGS ceiling USD 25 locked; FDA Pre-Sub held (minutes reviewed); QMS live and design controls documented; Fallback Panel V1 defined. Vote on gate passage (pass/fail/ambiguous with confidence intervals). If pass, release Series A Tranche 1 (USD 3-4M). If fail or ambiguous, escalate to retest or redesign within 4 weeks.

**Responsible Body/Role:** Project Steering Committee (CEO, Lead Investor, CFO, Chief R&D Officer, Chief Quality Officer)

**Suggested Timeframe:** Month 6 (2027-04-13)

**Key Outputs/Deliverables:**

- Gate-Review Meeting Minutes (analyte performance data, plasma-separation results, COGS model, FDA Pre-Sub feedback, QMS status)
- Month 6 (2027-04-13) Gate Determination Document (pass/fail/ambiguous with numeric data, confidence intervals, decision logic)
- Series A Tranche 1 Capital Release Approval (if gate passes) or Retest/Redesign Plan (if fail/ambiguous)
- Updated Cash-Flow Forecast and Pharma-Revenue Status

**Dependencies:**

- Steering Committee monthly tracking meetings held (Months 1-5 = 2026-11-13 to 2027-03-13)
- Cross-reactivity, plasma-separation, COGS, and FDA Pre-Sub data compiled and validated

### 32. CEO/Founder and Chief R&D Officer initiate formal pharma-partnership negotiations. Target 2-3 pharma sponsors for paid feasibility studies (1,000-5,000 patient samples, Months 10-15 = 2027-08-13 to 2028-01-13). Issue term sheets; target signed contracts by Month 9 (2027-07-13) specifying: sample volume, pricing (USD 50-100 per sample), data ownership, publication rights, timeline.

**Responsible Body/Role:** CEO/Founder (business lead) and Chief R&D Officer (scientific credibility)

**Suggested Timeframe:** Month 6 (2027-04-13) to Month 9 (2027-07-13 to 2027-07-13)

**Key Outputs/Deliverables:**

- Pharma Partnership Term Sheet (sample volume, pricing, data ownership, publication rights)
- Signed Pharma Contract 1 (or 2) for paid feasibility study (USD 50-100k per contract); expected by Month 9 (2027-07-13)

**Dependencies:**

- Month 6 (2027-04-13) gate passes and Series A Tranche 1 funding secured
- Preliminary Cluster 1 data available (cross-reactivity, concordance) to support pharma pitch

### 33. CEO/Founder and CFO initiate Series A Tranche 2 (USD 2-3M) and Series B (USD 3-5M) fundraising roadmaps, modeling contingencies. If Month 6 (2027-04-13) gate passes, Series A Tranche 2 (USD 2-3M) is released at Month 12 (2027-10-13) analytical-feasibility gate. Series B (USD 3-5M) is targeted for Month 18-24 (2028-04-13 to 2028-10-13) upon design freeze and clinical-study enrollment. Prepare pitch deck with gate-linked milestones and risk mitigations.

**Responsible Body/Role:** CEO/Founder (investor relations) and CFO (financial modeling)

**Suggested Timeframe:** Month 6 (2027-04-13)

**Key Outputs/Deliverables:**

- Series A and Series B Fundraising Roadmap (gate-linked capital release, target dates)
- Series B Pitch Deck (executive summary, technical risks, gate criteria, capital ask, exit scenarios)
- Investor Communication Plan (quarterly gate-result updates, board participation)

**Dependencies:**

- Month 6 (2027-04-13) gate passes and Series A Tranche 1 funded
- Cash-flow model and lean-pivot trigger communicated to investors

### 34. Technical Advisory Group conduct formal cross-reactivity assessment (Month 5-6 = 2027-03-13 to 2027-04-13). Review cross-reactivity screening results (each analyte pair, spiked-plasma data, % bias). Recommend redesign or removal for high-risk pairs (>5% bias at 10× interferent). Document risk-mitigation decisions in Technical Advisory report to Steering Committee.

**Responsible Body/Role:** Technical Advisory Group (external microfluidics and immunoassay experts) facilitated by Chief R&D Officer

**Suggested Timeframe:** Month 5 (2027-03-13) to Month 6 (2027-04-13 to 2027-04-13)

**Key Outputs/Deliverables:**

- Cross-Reactivity Assessment Report (analyte-pair results, pass/fail against ≤5% bias criterion, redesign or removal recommendations)
- High-Risk Analyte Pair Summary (analytes recommended for redesign or retirement, rationale)

**Dependencies:**

- Cross-reactivity screening data compiled (by Month 5 = 2027-03-13)
- Technical Advisory Group in place and ready to review

### 35. Operations Committee formally finalize clinical-study protocol and submit to IRB for approval. Coordinate with academic partner on site activation, subject recruitment plan, and informed-consent process. Obtain IRB approval by Month 12 (2027-10-13). Designate clinical-trial coordinator and establish data-management systems (eCRF, LIMS integration for result reporting).

**Responsible Body/Role:** Operations Committee (Chief Compliance Officer / Regulatory Lead, Chief R&D Officer, Clinical-Trial Coordinator, and academic partner)

**Suggested Timeframe:** Month 9 (2027-07-13) to Month 12 (2027-10-13 to 2027-10-13)

**Key Outputs/Deliverables:**

- Final Clinical-Study Protocol v2.0 (IRB-approved)
- IRB Approval Letter (by Month 12 = 2027-10-13)
- Clinical-Site Activation Plan (subject recruitment target, enrollment timeline, data-collection procedures)
- Data-Management Systems Documentation (eCRF setup, LIMS integration, data-integrity controls)

**Dependencies:**

- Protocol drafted and pre-registered (Month 9 = 2027-07-13)
- Academic partner and clinical sites identified
- IRB submission complete (by Month 10 = 2027-08-13)

### 36. Operations Committee conduct pilot-scale cartridge manufacturing with contract-injection-molder partner. Conduct first-article run (FAR) of 5,000-10,000 cartridges with Cluster 1 design. Measure yield, defect rate, reagent-fill variability. Target completion by Month 12 (2027-10-13). Yield should be ≥85% mean (lower 95% CI ≥80%); lot CV <10%. Results inform design-freeze decision and Month 18 (2028-04-13) Newark phase-2 capital release.

**Responsible Body/Role:** Chief R&D Officer (quality oversight) with contract-molder partner and Manufacturing/Operations Lead

**Suggested Timeframe:** Month 9 (2027-07-13) to Month 12 (2027-10-13 to 2027-10-13) for first-article run

**Key Outputs/Deliverables:**

- First-Article Run Plan (cartridge design, mold trials, defect-mode analysis, yield targets)
- First-Article Run Results (yield %, defect-rate summary, reagent-fill consistency, lot CV)
- Design-for-Manufacturability Lessons Learned (mold modifications if needed for next iteration)

**Dependencies:**

- Cartridge design locked (by Month 6 = 2027-04-13)
- Contract molder engaged and production mold ready (by Month 10-12 = 2027-08-13 to 2027-10-13)

### 37. Operations Committee establish standardized lot-release and reagent-handling SOPs for future Newark operations. Define reagent-lot acceptance criteria (potency assay, endotoxin, sterility, stability), release documentation, and quarantine procedures. Document requirements for in-house reagent formulation and lot release at Newark site.

**Responsible Body/Role:** Chief Quality Officer (lead) with Chief R&D Officer and Operations Committee

**Suggested Timeframe:** Month 9 (2027-07-13) to Month 12 (2027-10-13 to 2027-10-13)

**Key Outputs/Deliverables:**

- Reagent Lot-Release SOP and Acceptance Criteria
- Lot-Traceability Documentation Template (batch numbers, supplier, potency, stability, release sign-off)
- Reagent Quality-Control Methods and Qualification Plan

**Dependencies:**

- Chief Quality Officer and Chief R&D Officer in role
- QMS and design controls established (Months 2-3 = 2026-12-13 to 2027-01-13)

### 38. Chief Compliance Officer and Compliance, Ethics and Risk Management Committee conduct data-integrity audit of cross-reactivity and plasma-separation studies (Months 4-6 = 2027-02-13 to 2027-04-13). Verify: protocol adherence, measurement accuracy, data recording and traceability, absence of selective reporting or corrections without documentation. Issue audit report by Month 7 (2027-05-13).

**Responsible Body/Role:** Chief Compliance Officer (lead) and Compliance, Ethics and Risk Management Committee

**Suggested Timeframe:** Month 7 (2027-05-13) for audit completion

**Key Outputs/Deliverables:**

- Data-Integrity Audit Report (cross-reactivity and plasma-separation studies, findings, corrective actions if any)

**Dependencies:**

- Cross-reactivity and plasma-separation studies completed (by Month 6 = 2027-04-13)
- Chief Compliance Officer and audit procedures in place

### 39. Chief Quality Officer coordinate formal regulatory-roadmap approval with Steering Committee. Document FDA Pre-Submission feedback (510(k) vs. De Novo likelihood), planned regulatory pathway (staged per-cluster 510(k) submissions preferred), quality-system readiness timeline (ISO 13485 by Month 18 = 2028-04-13), and CLIA lab-service fallback (staff and operational plan by Month 12 = 2027-10-13). Obtain Steering Committee approval of regulatory plan.

**Responsible Body/Role:** Chief Quality Officer / Regulatory Lead (lead) with Steering Committee

**Suggested Timeframe:** Month 6 (2027-04-13) to Month 9 (2027-07-13 to 2027-07-13)

**Key Outputs/Deliverables:**

- Regulatory Roadmap Document (FDA pathway, quality-system milestones, submission timeline)
- CLIA Lab-Service Fallback Plan (operations, staffing, revenue timeline, no later than Month 12 = 2027-10-13)
- Steering Committee Approval Minutes (regulatory pathway and plan signed off)

**Dependencies:**

- FDA Pre-Submission feedback received (by Month 6 = 2027-04-13)
- Chief Quality Officer and Steering Committee in place

### 40. Operations Committee finalize Cluster 1 analyte list and design freeze decision with input from Technical Advisory Group. Document all analyte-performance data compiled through Month 6-12 (2027-04-13 to 2027-10-13). Remove any analytes failing thresholds (concordance <95%, CV >10%, shelf-life <9 months projected, cross-reactivity >5%). Publish Fallback Panel V1 final roster (≤50 analytes, likely 4-5 cartridges of ~10-15 analytes each, or smaller if more fail). Obtain Steering Committee and Technical Advisory Group sign-off on final panel and design freeze.

**Responsible Body/Role:** Operations Committee (Chief R&D Officer, Quality Lead, Chief Quality Officer) with Technical Advisory Group review

**Suggested Timeframe:** Month 12 (2027-10-13) to Month 15 (2028-01-13 to 2028-01-13), with design freeze target Month 15-18 (2028-01-13 to 2028-04-13)

**Key Outputs/Deliverables:**

- Analyte Final Performance Report (all analytes, pass/fail data, retired/redesigned analyte rationale)
- Fallback Panel V1 Final Roster (confirmed ≤50 analytes, cartridge clustering, clinical use claim)
- Design Freeze Sign-Off (Steering Committee, Technical Advisory Group, and R&D leadership approval of final cartridge design, fluidics, and analyte list)

**Dependencies:**

- Months 6-12 (2027-04-13 to 2027-10-13) analyte-performance data (concordance, cross-reactivity, shelf-life, yield) compiled
- Operations and Technical Advisory Group reviews completed

### 41. Project Steering Committee hold Month 12 (2027-10-13) comprehensive analytical-feasibility gate-review meeting (4-6 hours). Assess gate criteria: (1) pilot-scale yield ≥85% (mean, lower 95% CI ≥80%); (2) lot-to-lot CV <10%; (3) shelf-life ≥12 months projected (Arrhenius R² >0.90); (4) concordance ≥95% (lower CI ≥93%) from preliminary clinical data (100-150 samples); (5) COGS modeled ≤USD 25/cartridge (validated against FAR data); (6) Fallback Panel V1 finalized with ≤50 analytes; (7) FDA Pre-Sub completed and regulatory pathway confirmed; (8) clinical-study protocol approved and enrollment about to start. Vote on gate passage. If pass, approve design freeze and release Series A Tranche 2 (USD 2-3M) and authorize Newark Phase 1 capital release (USD 500-800k). If fail, pause design freeze and Newark spending; conduct 4-week design review and retest by Month 15 (2028-01-13).

**Responsible Body/Role:** Project Steering Committee (CEO, Lead Investor, CFO, Chief R&D Officer, Chief Quality Officer)

**Suggested Timeframe:** Month 12 (2027-10-13)

**Key Outputs/Deliverables:**

- Month 12 (2027-10-13) Gate-Review Meeting Minutes (yield, CV, shelf-life, concordance data; COGS validation; Fallback Panel V1 final roster; FDA feedback; clinical-study readiness)
- Analytical-Feasibility Gate Determination (pass/fail/ambiguous with numeric data and confidence intervals)
- Series A Tranche 2 Capital Release Approval (if gate passes)
- Newark Phase 1 Capital Release Approval (if gate passes) with lease/fit-out timeline
- Design-Freeze Sign-Off (if gate passes)

**Dependencies:**

- Steering Committee monthly tracking through Month 11 (2027-09-13 to 2027-09-13)
- Pilot-scale yield, stability, concordance, and COGS data validated and compiled

### 42. CEO/Founder and Chief Compliance Officer initiate Newark facility site selection and lease negotiations. Identify and visit 3-5 available spaces in Newark, California (light-industrial or life-science zoning, 2,000-3,000 sq ft, suitable for BSL-2 with biohazard-waste handling, close to I-880 and Dumbarton Bridge for logistics). Confirm zoning permits biological reagent handling and cartridge filling. Target lease execution by Month 14-15 (2028-01-13), contingent on Month 12 (2027-10-13) gate passage.

**Responsible Body/Role:** CEO/Founder (business lead) and Facilities/Operations Lead with real-estate counsel

**Suggested Timeframe:** Month 12 (2027-10-13) to Month 14 (2027-12-13 to 2027-12-13) for site selection; lease target Month 14-15 (2028-01-13)

**Key Outputs/Deliverables:**

- Newark Facility Site-Selection Summary (3-5 candidate properties evaluated, zoning confirmation)
- Lease Term Sheet (space, rent, landlord TI allowance, term, environmental/waste-handling requirements)
- Signed Lease Agreement (target Month 14-15 = 2028-01-13, contingent on Month 12 = 2027-10-13 gate)

**Dependencies:**

- Month 12 (2027-10-13) gate passes (design freeze and yield validation)
- Newark Phase 1 capital approved (USD 500-800k)
- Facilities and real-estate resources available

### 43. Operations Committee initiate clinical-study subject enrollment (target launch Month 12 = 2027-10-13). Coordinate with academic partner on recruitment, informed-consent process, sample collection (paired fingerstick and reference samples), and result reporting. Track enrollment progress monthly. Target 300-500 subjects enrolled by Month 18 (2028-04-13).

**Responsible Body/Role:** Operations Committee (Chief Compliance Officer / Regulatory Lead, Clinical-Trial Coordinator, and academic partner)

**Suggested Timeframe:** Month 12 (2027-10-13) enrollment start; target completion Month 18 (2028-04-13)

**Key Outputs/Deliverables:**

- Clinical-Study Enrollment Report (monthly updates: subjects enrolled, data quality, protocol deviations if any, adverse events)
- Subject-Enrollment Tracking Dashboard (cumulative enrollment, target vs. actual, timeline status)

**Dependencies:**

- Clinical-study protocol IRB-approved (by Month 12 = 2027-10-13)
- Clinical sites activated and staff trained
- Academic partner and LIMS systems operational

### 44. Operations Committee begin Newark Phase 1 facility fit-out (reagent formulation and pilot-scale filling lab). Contractors design and install: reagent-handling hood, refrigerated storage, liquid-handling equipment, QC instruments (potency assay, endotoxin, sterility equipment), and lot-release documentation systems. Target operational by Month 15-18 (2028-01-13 to 2028-04-13). Conduct pilot fills of Cluster 1 cartridges (1,000-5,000 units) to validate reagent formulation, fill parameters, and lot-to-lot consistency.

**Responsible Body/Role:** Operations Committee (Manufacturing Lead / Facilities Manager) with contractors and Chief Quality Officer oversight

**Suggested Timeframe:** Month 12 (2027-10-13) to Month 18 (2028-04-13 to 2028-04-13) for fit-out and pilot fills

**Key Outputs/Deliverables:**

- Newark Phase 1 Facility Design and Equipment List (fit-out scope, equipment procurement, installation timeline)
- Pilot-Fill Plan and Yield Validation (batch parameters, QC testing, lot-release criteria)
- Pilot-Fill Results (yield %, lot-to-lot CV, reagent stability at Newark conditions)

**Dependencies:**

- Month 12 (2027-10-13) gate passes and Newark Phase 1 capital approved
- Newark facility lease executed (by Month 14-15 = 2028-01-13)
- Design frozen and cartridge geometry locked (Month 15-18 = 2028-01-13 to 2028-04-13)

### 45. Chief Quality Officer conduct full ISO 13485 certification assessment and begin formal certification audit (target Month 15 = 2028-01-13). Complete corrective-action plan from earlier assessment. Ensure design controls, DHF, change-control log, management-of-change, supplier agreements, training records, and complaint/CAPA procedures are mature and documented. Obtain ISO 13485 certification by Month 18 (2028-04-13).

**Responsible Body/Role:** Chief Quality Officer (lead) with external ISO 13485 auditor/registrar

**Suggested Timeframe:** Month 15 assessment (2028-01-13); certification by Month 18 (2028-04-13)

**Key Outputs/Deliverables:**

- ISO 13485 Certification Audit Report (formal audit, findings, corrective actions)
- ISO 13485 Certificate (issued by accredited registrar, valid Months 18-21 = 2028-04-13 to 2028-07-13 and beyond)

**Dependencies:**

- Design controls and QMS fully documented (Months 2-6 = 2026-12-13 to 2027-04-13)
- Supplier agreements and management-of-change procedures implemented
- Training and competency records complete

### 46. Chief Compliance Officer complete freedom-to-operate (FTO) review and file provisional patent applications for core cartridge architecture and fluidic design. Finalize IP strategy: confirm no blocking patents from incumbents, or negotiate licenses if required. Document all findings in final FTO report and clearance opinion. File US and international provisional patents by Month 15 (2028-01-13).

**Responsible Body/Role:** Chief Compliance Officer / General Counsel (lead) with external patent counsel

**Suggested Timeframe:** Month 12 (2027-10-13) to Month 15 (2028-01-13 to 2028-01-13) for FTO finalization and provisional filings

**Key Outputs/Deliverables:**

- Final Freedom-to-Operate Report (clearance opinion, blocking patents identified or not, licenses required or not)
- Provisional Patent Applications (US and key international jurisdictions, core cartridge and fluidic designs)
- IP Strategy Summary (filing plan going forward, trade-secret protection for reagent formulations)

**Dependencies:**

- Cartridge design and fluidic innovations finalized (by Month 12 = 2027-10-13)
- Patent counsel engaged and FTO review completed (by Month 15 = 2028-01-13)

### 47. Operations Committee assess Month 12-18 (2027-10-13 to 2028-04-13) pharma revenue and lean-pivot eligibility. If pharma contracts delivered <USD 100k cumulative revenue by Month 18 (2028-04-13), or are at risk of falling below USD 100k/month run-rate, activate lean-pivot contingency: reduce headcount by 20-30% (preserve R&D, quality, and clinical/manufacturing readiness; defer Clusters 2-5 expansion planning), pause Newark full filling-line fit-out (continue only reagent lab), shift focus to CLIA lab-service revenue path (if applicable). Present lean-pivot plan and funding-gap mitigation to Steering Committee for approval.

**Responsible Body/Role:** CFO / Finance Lead (trigger assessment) and Operations Committee (execution planning)

**Suggested Timeframe:** Month 18 (2028-04-13) for pivot decision; execution Month 18-24 (2028-04-13 to 2028-10-13)

**Key Outputs/Deliverables:**

- Month 18 (2028-04-13) Pharma-Revenue Assessment (cumulative revenue vs. USD 100k target, run-rate trajectory)
- Lean-Pivot Contingency Plan (headcount reduction, spending cuts, refocus on CLIA/narrow beachhead)
- Steering Committee Lean-Pivot Approval (if triggered)

**Dependencies:**

- Pharma contracts signed and revenue tracking through Month 18 (2028-04-13)
- CFO and Operations Committee monitoring revenue monthly

### 48. Project Steering Committee hold Month 18 (2028-04-13) comprehensive design-freeze and manufacturing-readiness gate-review meeting (4-6 hours). Assess gate criteria: (1) lead-cluster (Cluster 1) design freeze complete (all design documents final, frozen, change-control locked); (2) interim clinical concordance ≥95% (lower 95% CI ≥93%) from 150-200 enrolled subjects; (3) Newark pilot fills yield ≥85% (mean, lower CI ≥80%); (4) ISO 13485 certification achieved; (5) FTO review complete (no blocking patents or licenses secured); (6) clinical-study enrollment on track (≥50% enrolled); (7) Fallback Panel V1 finalized; (8) Series A Tranches 1-2 spent, Series B fundraising commenced. Vote on gate passage. If pass, approve design freeze, release Series A Tranche 3 (USD 2-3M) or Series B (USD 3-5M), and authorize Newark Phase 2 capital release (USD 2-4M for full filling line). If fail, pause Newark Phase 2 and escalate design or clinical issues to Technical Advisory Group and Steering Committee.

**Responsible Body/Role:** Project Steering Committee (CEO, Lead Investor, CFO, Chief R&D Officer, Chief Quality Officer)

**Suggested Timeframe:** Month 18 (2028-04-13)

**Key Outputs/Deliverables:**

- Month 18 (2028-04-13) Gate-Review Meeting Minutes (design freeze status, clinical concordance data, yield results, ISO 13485 certification, FTO completion, clinical-enrollment status)
- Design-Freeze Gate Determination (pass/fail/ambiguous with numeric data and confidence intervals)
- Series A Tranche 3 or Series B Capital Release Approval (if gate passes)
- Newark Phase 2 Capital Release Approval (if gate passes): USD 2-4M for full filling line, 20% contingency USD 400-600k

**Dependencies:**

- Steering Committee monthly tracking Months 12-17 (2027-10-13 to 2028-03-13)
- Design-freeze documentation, clinical enrollment data, Newark pilot-fill results, and ISO 13485 certification compiled

### 49. Operations Committee begin Newark Phase 2 facility fit-out (full cartridge-filling line, scaled equipment). Procure long-lead filling equipment (automated cartridge filler, reagent-dispensing systems, stability chambers, QC instruments), manage installation and commissioning. Target operational by Month 24-30 (2028-10-13 to 2029-04-13). Conduct pilot runs and scale-up feasibility studies to validate full-scale manufacturing parameters (fill rate, accuracy, lot yield, consistency).

**Responsible Body/Role:** Operations Committee (Manufacturing Lead, Facilities Manager) with equipment vendors and Chief Quality Officer oversight

**Suggested Timeframe:** Month 18 (2028-04-13) to Month 30 (2029-04-13 to 2029-04-13) for Phase 2 fit-out and commissioning

**Key Outputs/Deliverables:**

- Newark Phase 2 Equipment Procurement List (long-lead filling machine, dispensing systems, QC instruments, lead times, pricing)
- Equipment Installation and Commissioning Plan (timeline, vendor support, validation testing)
- Scale-Up Feasibility Study Results (full-scale pilot fills, yield validation, process capability study)

**Dependencies:**

- Month 18 (2028-04-13) gate passes and Newark Phase 2 capital approved
- Newark Phase 1 operational (Month 15-18 = 2028-01-13 to 2028-04-13)
- Design frozen and cartridge geometry locked

### 50. Operations Committee initiate development of electronic laboratory information-management system (LIMS) and integrated data-management platform for clinical studies, cartridge lot tracking, stability-testing results, and regulatory submissions. Ensure eCRF (electronic case report form) and result-reporting workflows are operational for clinical study by Month 18 (2028-04-13) and production lot-release by Month 24 (2028-10-13).

**Responsible Body/Role:** Operations Committee (IT/Data Systems Lead, Clinical-Trial Coordinator, Chief Quality Officer) with LIMS vendor

**Suggested Timeframe:** Month 12 (2027-10-13) to Month 24 (2028-10-13 to 2028-10-13) for LIMS development and integration

**Key Outputs/Deliverables:**

- LIMS Platform Selection and Vendor Engagement (software choice, data-integration scope)
- eCRF Design and Validation (for clinical study, workflow design, data validation rules)
- Lot-Release Module Configuration (cartridge lot tracking, stability results, release sign-off)
- LIMS Operational Validation (user-acceptance testing, data integrity audit, staff training)

**Dependencies:**

- Clinical study protocol finalized (Month 9 = 2027-07-13)
- IT and data-systems resources in place

### 51. Chief Compliance Officer publish monthly Analyte Performance Dashboard and initiate quarterly Transparency Report for board and investors. Dashboard includes: per-analyte concordance, CV, shelf-life projection, cross-reactivity results, yield, status (In Progress/Pass/Fail/Retired), and cumulative menu count toward 500 analytes. Transparency Report summarizes project progress vs. gates, milestones achieved/missed, technical risks, funding status, and regulatory pathway. Avoid '500 tests' claims; use 'expanding menu' or 'cumulative portfolio' language.

**Responsible Body/Role:** Chief Compliance Officer (lead) with Chief R&D Officer and Operations Committee

**Suggested Timeframe:** Starting Month 6 (2027-04-13); monthly dashboard live by Month 6 (2027-04-13), quarterly reports starting Month 6 (2027-04-13)

**Key Outputs/Deliverables:**

- Monthly Analyte Performance Dashboard (shared with board, investors, advisory board)
- Quarterly Transparency Report (project milestones, gate results, risk updates, regulatory status, financial runway)
- No '500 Tests' Marketing Rule Enforcement (audit all communications for compliance)

**Dependencies:**

- Analyte Performance Report template created and populated
- Chief Compliance Officer and communications team in place

### 52. Technical Advisory Group conduct formal shelf-life and stability assessment at Month 12 (2027-10-13). Review real-time (9 months) and accelerated-stability data; validate Arrhenius modeling assumptions; confirm projected 12-month shelf-life (or adjust if projection is 9-12 months, requiring retest at Month 15 = 2028-01-13). Issue Technical Advisory report to Steering Committee on shelf-life confidence.

**Responsible Body/Role:** Technical Advisory Group (external stability/formulation expert) with Chief R&D Officer and Assay Chemistry Lead

**Suggested Timeframe:** Month 12 (2027-10-13)

**Key Outputs/Deliverables:**

- Shelf-Life and Stability Assessment Report (Arrhenius modeling, confidence intervals, pass/fail per analyte)

**Dependencies:**

- Real-time and accelerated-stability data from Months 3-12 (2027-01-13 to 2027-10-13)
- Technical Advisory Group in place

### 53. Operations Committee and Chief R&D Officer coordinate preparation of 510(k) or De Novo submission package (target submission Month 30 = 2029-04-13). Compile: (1) clinical-study data and analytical performance (concordance, CV, sensitivity, specificity); (2) design documentation (cartridge design, manufacturing process, quality controls); (3) risk analysis (ISO 14971); (4) software documentation (IEC 62304); (5) shelf-life and stability data; (6) biocompatibility assessment if needed. Engage regulatory consultant to review submission package and prepare for FDA interaction.

**Responsible Body/Role:** Operations Committee (Chief Quality Officer / Regulatory Lead, Chief R&D Officer) with regulatory consultant

**Suggested Timeframe:** Month 18 (2028-04-13) to Month 30 (2029-04-13 to 2029-04-13) for submission package preparation; filing target Month 30 (2029-04-13)

**Key Outputs/Deliverables:**

- 510(k) or De Novo Submission Package (complete as per FDA guidance, ready for submission)
- Submission Strategy Memo (510(k) pathway with predicate or De Novo pathway and justification)
- FDA Submission (filed Month 30 = 2029-04-13; expected decision Months 36-42 = 2029-10-13 to 2030-04-13 for 510(k); Months 42-48 = 2030-04-13 to 2030-10-13 for De Novo)

**Dependencies:**

- Clinical-study data analysis and statistical review complete (by Month 24 = 2028-10-13)
- Design controls, risk analysis, and software documentation finalized
- Regulatory consultant engaged

### 54. Compliance, Ethics and Risk Management Committee conduct mock FDA pre-approval inspection (conducted by external regulatory consultant or firm) at Months 28-30 (2029-02-13 to 2029-04-13), 2-4 months before expected FDA pre-approval inspection. Assess: design history file completeness, change-control log, risk-management file, management-of-change documentation, supplier agreements, training records, complaint handling, and regulatory documentation. Generate inspection report with 483-observation-level findings and corrective actions. Close gaps before real FDA inspection.

**Responsible Body/Role:** Compliance, Ethics and Risk Management Committee (Chief Compliance Officer, Chief Quality Officer) with external regulatory consultant

**Suggested Timeframe:** Months 28-30 (2029-02-13 to 2029-04-13)

**Key Outputs/Deliverables:**

- Mock FDA Inspection Report (findings, 483-observation-level gaps, corrective-action plan)
- Corrective-Action Plan and Close-Out (gaps remediated before real inspection, documentation of corrections)

**Dependencies:**

- Design controls and QMS mature and documented (Months 2-18 = 2026-12-13 to 2028-04-13)
- ISO 13485 certification achieved (by Month 18 = 2028-04-13)

### 55. Project Steering Committee hold quarterly gate-tracking meetings (Months 1-35 = 2026-11-13 to 2029-09-13, in addition to formal gate reviews at Months 6, 12, 18 = 2027-04-13, 2027-10-13, 2028-04-13). Review: monthly Analyte Performance Report, cash burn vs. budget, regulatory milestone status (FDA Pre-Sub feedback, ISO 13485 progress, submission package status), pharma/grant revenue, supplier scorecard, clinical-enrollment progress, and risk-register updates. Document decisions and capital-release approvals. Escalate any miss-make-vs-forecast variances or unplanned risk events within 1 week.

**Responsible Body/Role:** Project Steering Committee (CEO, Lead Investor, CFO, Chief R&D Officer, Chief Quality Officer)

**Suggested Timeframe:** Monthly, Months 1-35 (2026-11-13 to 2029-09-13), in addition to formal gate reviews (Months 6, 12, 18, 24 = 2027-04-13, 2027-10-13, 2028-04-13, 2028-10-13)

**Key Outputs/Deliverables:**

- Monthly Steering Committee Meeting Minutes (analytics, cash, regulatory, clinical, supplier, risk status)
- Quarterly Analyte Performance Dashboard Update (shared with investors and board)

**Dependencies:**

- Steering Committee established and operational (Month 0.5 = 2026-10-28)
- Operations Committee and Technical Advisory Group providing monthly data and reports

### 56. Operations Committee finalize Cluster 2-5 planning and roadmap (Months 12-24 = 2027-10-13 to 2028-10-13) for post-launch expansion. Define each cluster's clinical use case (e.g., oncology, rare disease, metabolic), analyte selection (50 analytes per cluster), development timeline (6-9 months per cluster after Cluster 1 clearance), and regulatory strategy (separate 510(k) or De Novo per cluster, or combined submission). Present expansion roadmap to Steering Committee for funding and resource planning.

**Responsible Body/Role:** Operations Committee (Chief R&D Officer, Chief Product Officer or Product Lead) with Steering Committee oversight

**Suggested Timeframe:** Months 12-24 (2027-10-13 to 2028-10-13) for cluster planning and roadmap definition

**Key Outputs/Deliverables:**

- Cluster 2-5 Expansion Roadmap (clinical use cases, analyte lists, development timelines, regulatory strategy, estimated cost and revenue per cluster)

**Dependencies:**

- Cluster 1 design frozen (Month 18 = 2028-04-13)
- Clinical-study and analytical-feasibility experience from Cluster 1 informs planning

### 57. CEO/Founder and CFO finalize Series B fundraising (target Month 18-24 = 2028-04-13 to 2028-10-13). Close Series B round (USD 3-5M proposed) by Month 24 (2028-10-13) to fund Months 24-48 (2028-10-13 to 2030-10-13) runway through FDA clearance and commercial launch. Use gate results, clinical data, and Newark readiness as fundraising proof points. If lean-pivot is triggered (Month 18 = 2028-04-13 pharma revenue <USD 100k/month), adjust Series B size and messaging to reflect narrower beachhead or CLIA-first strategy.

**Responsible Body/Role:** CEO/Founder (investor relations) and CFO (financial planning)

**Suggested Timeframe:** Month 18 (2028-04-13) to Month 24 (2028-10-13 to 2028-10-13) for Series B close

**Key Outputs/Deliverables:**

- Series B Pitch Deck (updated with Cluster 1 clinical data, manufacturing validation, regulatory progress)
- Series B Financing Agreement (investor terms, governance rights, board seat, liquidation preferences)
- Series B Capital in Bank (USD 3-5M received by Month 24 = 2028-10-13)

**Dependencies:**

- Month 12 (2027-10-13) and Month 18 (2028-04-13) gates pass and data demonstrates technical progress
- Clinical-enrollment and regulatory-pathway progress documented

### 58. Operations Committee hold Month 24 (2028-10-13) quarterly gate-tracking meeting to assess progress toward FDA submission (target Month 30 = 2029-04-13). Review: clinical-study analysis completion (target Month 24 = 2028-10-13), submission-package preparation status, regulatory-consultant engagement, and any FDA Q-Submission or Pre-Sub follow-up needed. Confirm submission target remains Month 30 (2029-04-13) or escalate any delays.

**Responsible Body/Role:** Operations Committee (Chief Quality Officer / Regulatory Lead, Chief R&D Officer)

**Suggested Timeframe:** Month 24 (2028-10-13)

**Key Outputs/Deliverables:**

- Clinical-Study Analysis Report (all analytes, concordance, CV, sensitivity/specificity per analyte, statistical summary)
- Submission-Package Status Report (draft/near-final status, expected completion date Month 28-30 = 2029-02-13 to 2029-04-13)

**Dependencies:**

- Clinical-study enrollment complete (by Month 24 = 2028-10-13)
- Data analysis in progress (Months 18-24 = 2028-04-13 to 2028-10-13)

### 59. Chief R&D Officer and Operations Committee finalize full-scale manufacturing readiness (target Month 30 = 2029-04-13). Validate: cartridge yield ≥85% at 10k+ cartridges/month scale; reagent lot-to-lot CV <10%; shelf-life stable through planned distribution; fill-line throughput ≥90% of design capacity; equipment reliability and maintainability demonstrated over 4-12 week pilot campaign. Prepare for commercial manufacturing ramp-up post-clearance.

**Responsible Body/Role:** Operations Committee (Manufacturing Lead, Chief Quality Officer) with contract-molder partners

**Suggested Timeframe:** Months 24-30 (2028-10-13 to 2029-04-13) for manufacturing scale-up validation

**Key Outputs/Deliverables:**

- Manufacturing Scale-Up Validation Report (yield, CV, shelf-life, throughput, reliability data)
- Commercial Manufacturing Plan (post-clearance ramp-up from 10k to 50k cartridges/month, timeline, staffing, quality controls)

**Dependencies:**

- Newark Phase 2 filling line operational (by Month 24-30 = 2028-10-13 to 2029-04-13)
- Cluster 1 design frozen and validated at scale (Month 18 = 2028-04-13)

### 60. Chief Compliance Officer finalize payer-coverage and reimbursement strategy. Conduct payer-coverage landscape analysis identifying CPT codes, coverage policies, and economics for Cluster 1 analytes. Initiate pre-launch payer discussions with 2-3 major payers (Medicare, Aetna, Anthem) presenting clinical-utility evidence and economic models. Develop tiered pricing and bundling strategy. Target payer-coverage pathways identified by Month 36 (2029-10-13), ready for implementation post-clearance.

**Responsible Body/Role:** Chief Compliance Officer / Regulatory Lead (lead) with Chief R&D Officer and Finance Lead

**Suggested Timeframe:** Months 24-36 (2028-10-13 to 2029-10-13) for payer engagement and coverage planning

**Key Outputs/Deliverables:**

- Payer-Coverage Landscape Analysis (CPT codes, coverage policies, reimbursement rates for Cluster 1 analytes)
- Payer Pre-Launch Engagement Summary (discussions with 2-3 major payers, preliminary coverage feedback)
- Pricing and Bundling Strategy (tiered approach, expected per-run revenue, margin implications)

**Dependencies:**

- Clinical-study data available to support coverage discussions (by Month 24 = 2028-10-13)
- Regulatory pathway confirmed (510(k) vs. De Novo)

### 61. FDA review and issue decision on 510(k) or De Novo submission (target decision Months 36-48 = 2029-10-13 to 2030-10-13, depending on submission type and FDA responsiveness). 510(k) typically reviews in 6-12 months; De Novo in 12-18 months. Engage with FDA on any deficiencies, requests for additional data, or labeling negotiations. Plan for 1-2 rounds of FDA Q-Submissions or supplemental submissions if needed.

**Responsible Body/Role:** Chief Quality Officer / Regulatory Lead (lead) with regulatory consultant and Chief R&D Officer

**Suggested Timeframe:** FDA review Months 30-48 (2029-04-13 to 2030-10-13); decision expected Months 36-48 (2029-10-13 to 2030-10-13)

**Key Outputs/Deliverables:**

- FDA Submission Acknowledgment and Review Clock Start (received Month 30 = 2029-04-13)
- FDA Deficiency Letter or Q-Submission Requests (if any, expected Month 36-42 = 2029-10-13 to 2030-04-13)
- Responses to FDA Deficiencies (prepared and submitted within 30-60 days of FDA request)
- FDA Clearance/Approval Letter (received Months 36-48 = 2029-10-13 to 2030-10-13)

**Dependencies:**

- 510(k) or De Novo submission filed Month 30 (2029-04-13)
- Quality system and design controls mature (ISO 13485 certified by Month 18 = 2028-04-13)

### 62. Operations Committee prepare post-clearance commercial launch plan. Define: manufacturing scale-up (ramp from 10k to 50k cartridges/month over Months 48-72 = 2030-10-13 to 2032-10-13), sales-channel activation (direct to reference labs, point-of-care clinics, or pharmacy partnerships), clinical-site and payer onboarding, training for operators and support staff, cold-chain logistics setup, and customer-support infrastructure. Target commercial launch by Month 48 (2030-10-13).

**Responsible Body/Role:** Operations Committee (Chief R&D Officer, Manufacturing Lead, Chief Quality Officer) with Commercial/Sales Lead

**Suggested Timeframe:** Months 36-48 (2029-10-13 to 2030-10-13) for launch-plan finalization

**Key Outputs/Deliverables:**

- Post-Clearance Commercial Launch Plan (manufacturing scale-up, sales channels, training, support, timeline)
- First Commercial Cartridge Shipment Plan (date, volume, customer sites, fulfillment logistics)

**Dependencies:**

- FDA clearance received (expected Months 36-48 = 2029-10-13 to 2030-10-13)
- Manufacturing scale-up validation complete (by Month 30 = 2029-04-13)

### 63. Project Steering Committee oversee Cluster 1 commercial launch and Cluster 2 development initiation (Months 48-72 = 2030-10-13 to 2032-10-13). Monitor: first-year revenue, operational yield and quality metrics, payer-coverage uptake, clinical adoption, and regulatory/pharmacovigilance performance. Manage Cluster 2 development timeline and gate-linked capital releases. Track expansion toward the 500-analyte cumulative menu (estimated 10 clusters of 50 analytes each, which would require Months 48-120 = 2030-10-13 to 2036-10-13 if clusters clear sequentially at 6-9 months post-launch). Communicate progress and re-planning to investors.

**Responsible Body/Role:** Project Steering Committee (CEO, Lead Investor, CFO, Chief R&D Officer, Chief Quality Officer) with Commercial/Operations team

**Suggested Timeframe:** Months 48-72 (2030-10-13 to 2032-10-13) and beyond for ongoing governance

**Key Outputs/Deliverables:**

- Monthly Commercial Operations Reports (revenue, units shipped, yield, quality metrics, customer feedback, adoption trends)
- Cluster 2 Development Progress Reports (analyte selection, clinical study planning, regulatory strategy, funding status)
- Expansion Roadmap Updates (revised timelines for Clusters 3-10, adjusted for market demand and technical learnings)

**Dependencies:**

- Cluster 1 FDA clearance and commercial launch complete (Month 48 = 2030-10-13)
- Series B and Series C/D funding in place for Cluster 2+ development