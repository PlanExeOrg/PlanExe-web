This plan involves money.

## Currencies

- **USD:** Primary currency for all major expenditures. US-based company with headquarters and manufacturing in Newark, California. Venture capital financing, regulatory submissions to FDA, supplier payments in US dollars, and clinical trial costs in US dollars will dominate the budget.
- **EUR:** Secondary currency for potential European clinical validation studies and regulatory submissions to CE mark or EMA if a European expansion path is considered. Relevant only if pharma partners or clinical trial sites are in Europe, which is not stated in the base plan.

**Primary currency:** USD

**Currency strategy:** All budgeting and reporting in USD. The company is US-registered, headquartered in the San Francisco Bay Area, manufacturing in Newark, California, and funded via US venture capital. Regulatory costs (FDA, CLIA, ISO 13485 certification) are in USD. Supplier payments for molded parts, instruments, reagents and contract manufacturing are primarily domestic (US) or priced in USD. If European clinical validation or regulatory pathways are pursued later, those costs will be converted at prevailing rates; no forward hedging is required at project start. Monitor USD/EUR exchange only if significant European partnerships materialize.