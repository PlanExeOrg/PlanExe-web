# Governance Audit


## Audit - Corruption Risks

- Supplier kickbacks or side agreements: Undisclosed rebates, payments, or exclusivity concessions from reagent suppliers, contract molders, or instrument assemblers in exchange for preferential purchasing or favorable contract terms, not reflected in cost models or procurement records.
- Conflict of interest in vendor selection: Board members, investors, or technical leads having financial interest in contract manufacturers, molders, reagent suppliers, or clinical research partners, leading to inflated pricing or unfavorable terms without competitive bidding.
- Regulatory capture and false documentation: Misrepresentation of analytical or clinical data in FDA submissions or CLIA applications to accelerate approvals, including selective reporting of failed analytes or shelf-life shortfalls not disclosed in regulatory packages.
- Grant and pharma-contract fraud: Misappropriation of grant or pharma-contract funds for unrelated corporate overhead, personal benefit, or side projects not aligned with the stated study protocol or research objectives.
- Nepotism in hiring and key-person roles: Appointment of unqualified relatives or personal associates to critical positions (microfluidics engineer, quality lead, regulatory affairs) at inflated compensation, compromising technical capability and design credibility.
- Internal trading on undisclosed material information: Founders, early employees, or board members trading equity or selling shares based on knowledge of failed gates, regulatory setbacks, or funding gaps not yet disclosed to later-stage investors.

## Audit - Misallocation Risks

- Design-freeze scope creep and feature-addition spending: Adding analytes, cartridge variants, or instrument features to satisfy investor or partner requests after design freeze, consuming USD 200k–1M+ in rework without advancing core product and delaying Newark manufacturing.
- Newark facility cost overruns and idle-capacity overhead: Over-sizing the initial Newark cleanroom, equipment purchases, or staffing (rent, utilities, headcount) relative to pilot-scale demand, leading to USD 300–500k+/year in under-utilized fixed costs and stranded capital.
- Premature high-volume equipment ordering: Committing to large molding equipment, automated filling lines, or quality-control instrument purchases before design freeze and yield validation, risking USD 500k–2M+ in obsolete or over-sized equipment if design changes or yield remains below target.
- Consultant and professional-services budget sprawl: Excessive spending on regulatory, quality-systems, patent, and business-development consultants without clear deliverables or gate-linked completion, consuming USD 100–300k+/year of scarce runway.
- Duplicate or redundant clinical studies: Conducting overlapping method-comparison or stability studies at multiple sites without data-sharing, resulting in USD 200–400k in wasted sample-collection and testing costs.
- Reagent and cartridge pilot-batch waste: Manufacturing pilot-scale cartridges or reagent lots for internal testing, feasibility studies, and early pharma partnerships without strict lot-release criteria or reuse protocols, generating USD 50–150k in consumable waste per cluster.

## Audit - Procedures

- Quarterly gate-linked capital release and financial reviews: Conduct formal gate-review meetings at Months 6, 12, 18, 24 (2027-04-13, 2027-10-13, 2028-04-13, 2028-10-13) with board review of technical pass/fail criteria, cash burn versus budget, non-payroll commitments (supplier orders, equipment), and equity-tranche release. Document gate decision and variance explanations in board minutes.
- Monthly supplier and contract-manufacturer scorecard reviews: Track each critical vendor's quality metrics (defect rate, first-pass yield), on-time delivery, price performance, and compliance with quality agreements. Flag defect-rate increases >10% or delivery delays >2 weeks within 5 business days; escalate to quality leadership and vendor management.
- Quarterly vendor-spending and procurement audits: Reconcile all supplier purchase orders, invoices, and payments against contracts and budgets. Verify competitive bidding for purchases >USD 50k; flag sole-source suppliers lacking dual-sourcing plans. Inspect change-order approvals and verify no unauthorized commitments were made.
- Semi-annual analyte-performance and design-history-file reviews: Audit the design-history file (DHF) and design-input/output documentation for completeness, traceability, and sign-offs. Cross-check monthly Analyte Performance Reports against the pre-registered success criteria; verify that analytes meeting or failing thresholds are correctly documented and removal decisions are recorded.
- Annual ISO 13485 and quality-system internal audits: Conduct an independent internal audit against ISO 13485, 21 CFR 820, and FDA guidance before the formal certification audit and regulatory inspections. Document findings, corrective-action plans, and closure evidence. Schedule mock FDA inspection at Months 28–30 (2029-02-13 to 2029-04-13).
- Post-gate design-change and scope-creep reviews: At each gate (Months 6, 12, 18 = 2027-04-13, 2027-10-13, 2028-04-13), audit the change-control log to verify that all design modifications since the prior gate were properly evaluated, approved, and traced to a documented business or technical reason. Flag changes exceeding a pre-set threshold (>USD 50k impact, >2 week timeline, architecture-level) as requiring board or executive review.

## Audit - Transparency Measures

- Gate-linked quarterly progress dashboards and board reports: Publish a monthly progress dashboard visible to board and senior leadership showing: (1) analytical-feasibility status (yield, concordance, shelf-life, cross-reactivity), (2) cash burn versus budget and runway-months remaining, (3) regulatory milestones (FDA Pre-Sub status, submission timeline), (4) manufacturing readiness (supplier on-boarding, mold status, pilot-fill results). Include pass/fail/ambiguous status for each gate criterion with confidence intervals and expected re-test timeline.
- Pre-registered clinical study protocol and ClinicalTrials.gov registry: Publish the analyte-by-analyte accuracy targets, sample-size calculations, and success criteria (≥95% concordance, <10% CV) on ClinicalTrials.gov before enrollment begins (by Month 12 = 2027-10-13). Post protocol amendments, enrollment progress, and enrollment-delay explanations quarterly. Commit to publishing results (positive and negative) regardless of outcome by Month 30 (2029-04-13).
- Monthly Analyte Performance Report with failure transparency: Issue a monthly report documenting each analyte's accuracy, precision, shelf-life, and cross-reactivity results against pre-set thresholds. List analytes that fail any threshold, the root-cause analysis, and the redesign or retirement decision. Circulate to board, R&D leadership, and external scientific advisory board; archive and publish after regulatory submission.
- External scientific advisory board with data audit access: Establish a 5–7 member advisory board (academic, clinical, industry experts) with quarterly public meetings. Grant board members access to raw analytical data, clinical data, and failure logs. Publish meeting summaries and board member names/affiliations on the company website. Include board-recommended changes or dissents in regulatory submissions.
- Published regulatory-pathway transparency and FDA meeting summaries: Disclose the chosen regulatory route (510(k) vs. De Novo, staged submissions) and FDA Pre-Submission meeting topics, questions asked, and FDA responses in an annual regulatory roadmap document. Update publicly after each FDA milestone (submission, substantive review feedback, clearance). Explain any deviations (e.g., if pathway changes from 510(k) to De Novo) within 30 days.
- Supplier quality-agreement summaries and dual-sourcing status: Publish aggregate supply-chain risk status (number of suppliers per critical reagent, dual-sourcing coverage, lead-time and pricing stability). Update quarterly; flag any sole-source dependencies and mitigation plans. Disclose any significant supplier changes, quality failures, or contract disputes to investors and board within 10 business days.

# Internal Governance Bodies

### 1. Project Steering Committee (Strategic Oversight Board)

**Rationale for Inclusion:** This capital-intensive, multi-year diagnostics venture operates under extreme technical and regulatory uncertainty with a fixed manufacturing commitment (Newark) that cannot be quickly exited. The Steering Committee provides strategic direction, allocates capital tranches tied to quantified technical gates, makes go/no-go decisions on product scope (Fallback V1 retreat), and oversees systemic risks (funding gaps, regulatory pathway changes, competitive threats). Without this body, sunk-cost escalation, late pivot-to-fallback decisions, and funding shortfalls would accumulate uncontrolled. The committee is essential to reconcile the venture ambition (500-test menu) with the physical/financial constraints.

**Responsibilities:**

- Approve and monitor gate-linked capital tranches (Seed, Series A Tranches 1-3, Series B); release capital only upon pre-agreed technical gate passage (yield, concordance, design freeze) documented at gate meetings
- Decide scope retreat: vote on Fallback Panel V1 (50-analyte core) activation if technical gates fail by Month 15 (2028-01-13) or if funding gap exceeds reserves
- Oversee regulatory pathway (510(k) vs De Novo decision); escalate to investor board if pathway changes add >6 months or USD 2M; approve Pre-Submission meeting strategy and FDA communication plan
- Review and approve Newark phased build-out plan and capital release triggers; pause Newark spending if design freeze is missed or yield falls below 80% mean (lower CI <75%)
- Manage funding strategy (pharma contracts, non-dilutive grants, Series A/B sizing); approve lean-pivot trigger if pharma revenue is <USD 100k/month at Month 18 (2028-04-13)
- Set quantitative thresholds for operational decisions (COGS ceiling USD 25 per cartridge by Month 6 = 2027-04-13; shelf-life >=12 months; plasma separation >95% at Month 6 = 2027-04-13; concordance >=95%; yield >=85% at Month 12 = 2027-10-13) and approve changes to thresholds

**Initial Setup Actions:**

- Hold founding meeting Month 0.5 (2026-10-28): finalize Fallback Panel V1 definition, confirm gate criteria and capital schedule, assign gate-meeting chair (CEO or board lead), establish monthly dashboard reporting

**Membership:**

- CEO/Founder (chair)
- Lead investor or board delegate (independent voice on capital decisions and scope retreat)
- CFO or finance lead (capital, cash-flow, funding pipeline responsibility)
- Chief R&D Officer (technical gate assessment and regulatory pathway alignment)
- Chief Quality Officer (ISO 13485 readiness, regulatory risk, design controls maturity)

**Decision Rights:** Sole authority to approve or withhold capital tranches tied to gates (USD 2-5M decisions). Authority to retreat to Fallback V1 or pause Newark spending. Authority to change regulatory pathway or request board escalation if pathway changes. Authority to approve pharma/grant strategy and lean-pivot trigger. Cannot modify pre-agreed gate thresholds without investor board approval.

**Decision Mechanism:** Majority vote (3 of 5 members). Tie-breaker: CEO casts second vote. Gate passage determined by quantitative criteria (pass/fail/ambiguous per confidence intervals); ambiguous results (e.g., yield 80-85% when gate is >=85%) require data review and board discussion to decide retest vs. fail. All gate decisions documented in minutes with numeric data, decision logic, and tie-breaker used if applicable.

**Meeting Cadence:** Monthly gate-tracking meetings (1-2 hours); full gate-review meetings at Months 6, 12, 18, 24 (2027-04-13, 2027-10-13, 2028-04-13, 2028-10-13) lasting 4-6 hours including board discussion of analyte performance, capital draw, regulatory milestones, and forward plan. Emergency meetings called within 1 week if gates are missed or funding gap emerges.

**Typical Agenda Items:**

- Monthly: Analyte Performance Report (concordance, yield, shelf-life data vs. thresholds); cash burn vs. budget; regulatory milestone status (FDA Pre-Sub prep, ISO 13485 progress); supplier scorecard (defect rate, lead time); Fallback Panel V1 status
- Gate meetings (Months 6, 12, 18, 24 = 2027-04-13, 2027-10-13, 2028-04-13, 2028-10-13): Formal gate decision (pass/fail/ambiguous) with confidence intervals and re-test plan; capital tranche approval/withholding; Newark phased build-out decision (fit-out timing, budget approval); regulatory pathway confirmation or change; pharma/grant revenue status and lean-pivot eligibility; portfolio company scaling/retreat options

**Escalation Path:** If gate is ambiguous (e.g., yield 80-85%), Steering Committee requests 2-3 week retest or directives from Technical Advisory Group. If gate fails and Steering Committee cannot agree on retreat vs. redesign, escalate to investor board with two competing motions (Fallback V1 retreat vs. design-review extension); investor board votes within 2 weeks. If regulatory pathway changes (510(k) → De Novo), Steering Committee approves response plan; if plan exceeds USD 2M or 6 months, escalate to investor board within 5 business days.
### 2. Operations and Execution Committee (Operational Management)

**Rationale for Inclusion:** Day-to-day execution of the development program requires close coordination of assay chemistry, microfluidics, manufacturing, quality, and regulatory work. The Operations Committee manages the 25-70 person team across these functions, makes decisions on design changes, analyte removal, supplier changes, clinical-study protocol adjustments, and resource allocation. Without this body, technical decisions would lack discipline, change control would be weak, and operational risk (supplier failures, analyte incompatibilities, yield loss) would not be managed proactively. The committee translates Steering Committee gates and capital decisions into executable plans and reports progress upward.

**Responsibilities:**

- Execute development plan against Steering Committee gates; prepare gate-review materials (analyte performance, yield data, clinical enrollment, regulatory milestones, cost tracking) for Steering Committee by 5 business days before each gate meeting
- Manage design changes and changes to Fallback Panel V1 analyte list: maintain design-change log, evaluate impact on schedule/cost/regulatory, approve changes <USD 50k/2-week impact without Steering Committee approval; escalate larger changes for review within 5 business days
- Manage analyte removal: conduct monthly Analyte Review Meetings (Months 3-12 = 2027-01-13 to 2027-10-13, then quarterly) to assess each analyte against pre-set thresholds (concordance >=95%, CV <10%, shelf-life >=12 months); decide redesign/retire/defer for each failing analyte; document in Analyte Performance Report visible to board
- Oversee supplier relationships and quality: track contract-manufacturer and reagent-supplier scorecard (defect rate, delivery, cost); escalate defect-rate increases >10% within 2 weeks; approve dual-sourcing transitions; manage supplier quality agreements and corrective actions
- Manage clinical-study execution: coordinate academic partner on protocol, enrollment, data QA, and timelines; escalate enrollment delays >3 months to Steering Committee; prepare clinical-study reports for regulatory submission by Month 24 (2028-10-13)
- Coordinate Newark facility phased build-out: schedule long-lead equipment orders by Month 4-5 (2027-02-13 to 2027-03-13) if design is sufficiently mature; manage fit-out contractors; conduct pilot fills and yield validation; report results to Steering Committee for Phase 2 capital release decision at Month 18 (2028-04-13)
- Manage regulatory readiness: prepare ISO 13485 documentation and internal audits; coordinate FDA Pre-Submission meeting preparation (Months 2-6 = 2026-12-13 to 2027-04-13); prepare 510(k)/De Novo submission package (Months 24-30 = 2028-10-13 to 2029-04-13)

**Initial Setup Actions:**

- Month 1 (2026-11-13): Hire R&D director and quality/regulatory lead (first hires); establish Operations Committee charter and meeting cadence
- Month 2 (2026-12-13): Lock Fallback Panel V1 definition (50 analytes, 4-5 cartridges); finalize Analyte Performance Report template and monthly review calendar
- Month 3 (2027-01-13): Establish design-change log, change-control process, and approval thresholds (USD 50k/2-week minor; >USD 50k or >2-week escalates to Steering Committee); conduct first Analyte Review Meeting
- Month 4 (2027-02-13): Initiate supplier identification for molding, instrument assembly, reagent sourcing; begin FDA Pre-Sub preparation; launch clinical-study site and protocol co-development with academic partner

**Membership:**

- Chief R&D Officer (chair)
- Microfluidics engineering lead or principal engineer
- Assay chemistry and biology lead
- Chief Quality Officer (ISO 13485, design controls, regulatory readiness)
- Manufacturing/operations lead (or contractor representative for early phases)
- Clinical-trial coordinator or academic-partner liaison
- Finance/program manager (budget, cost tracking, procurement authority)

**Decision Rights:** Authority to approve design changes <USD 50k and <2 week timeline impact without Steering Committee escalation. Authority to manage supplier relationships, approve dual-sourcing transitions, and escalate quality failures. Authority to make operational trade-offs (e.g., reduce analyte count to meet COGS ceiling, adjust clinical-study site selection) if aligned with Fallback Panel V1 scope and Steering Committee direction. Cannot retreat from Fallback Panel V1 or approve capital >USD 500k; those decisions are escalated to Steering Committee.

**Decision Mechanism:** Consensus preferred; if disagreement, R&D director makes the call (subject to Steering Committee review if impact is >USD 50k). Monthly Analyte Review Meetings use quantitative criteria to decide redesign vs. retire vs. defer: if concordance <95% or CV >10%, failure is documented and escalated same week; decision to redesign or retire is made within 2 weeks (chair + quality lead approval). Clinical-study protocol changes requested by academic partner are reviewed within 1 week; changes <USD 50k and <2 month timeline impact are approved operationally; larger changes escalate to Steering Committee.

**Meeting Cadence:** Weekly executive sync (1 hour, R&D director + quality lead + finance lead); monthly full Operations Committee (2 hours, all members); monthly Analyte Review Meetings (1 hour, R&D + quality + design lead); monthly supplier scorecard reviews (1 hour with procurement lead); bi-weekly clinical-study status (with academic partner).

**Typical Agenda Items:**

- Weekly sync: blockers, risk watch list (supplier delays, analyte performance surprises, budget variance >5%), regulatory-readiness gaps, clinical-enrollment status
- Monthly Operations Committee: detailed Analyte Performance Report (all analytes, design review of failing ones), yield and manufacturing learnings (pilot fills, contract-manufacturer quality), supplier performance (defect rate, lead time, cost), design-change log review, clinical-study progress, regulatory milestone tracking, cash-burn tracking vs. gate-linked budget
- Monthly Analyte Review: concordance, CV, shelf-life data per analyte; documentation of failures; redesign scope and timeline for failing analytes; retirement decision and FDA transparency plan for removed analytes
- Monthly supplier scorecard: defect rate, on-time delivery %, quality-agreement compliance, cost performance vs. contract; escalation flags (defect >10%, delay >2 weeks, new quality issues)

**Escalation Path:** Design changes >USD 50k or >2 weeks impact escalate to Steering Committee within 5 business days. Analyte failure needing major redesign (>USD 100k, >4 weeks) escalates to Steering Committee; Fallback Panel V1 removal decision escalates to Steering Committee if >10% of core panel is affected. Supplier defect rate >10% or delivery failure escalates within 2 weeks; if dual-source activation costs >USD 50k, escalate to Steering Committee. Clinical-study enrollment delay >3 months escalates to Steering Committee. If Newark pilot fill yield is <80% at Month 12 (2027-10-13), escalation to Steering Committee with redesign proposal and retest plan.
### 3. Technical Advisory Group (Specialized Technical Assurance)

**Rationale for Inclusion:** The venture's core technical risks are plasma separation feasibility, cross-reactivity multiplexing challenges, reagent stability at scale, and cartridge yield. These are highly specialized domains requiring deep expertise in microfluidics, clinical immunoassay chemistry, manufacturing, and regulatory standards. The Operations Committee, while experienced, may miss technical nuances or over-commit to infeasible analyte targets. The Technical Advisory Group provides independent technical review, validates gate-passage decisions, flags design risks early, and ensures that analytical feasibility assessments are credible (protecting investor confidence and regulatory credibility). Without this body, over-optimistic performance projections at gates could lock in capital and manufacturing commitments to a flawed design.

**Responsibilities:**

- Validate analytical-feasibility assessment at each gate: review raw data, measurement protocols, and success-criteria calculations; sign off on concordance, yield, and shelf-life gate results before Steering Committee votes (by 3 business days before gate meeting)
- Assess cross-reactivity risk across Cluster 1 analyte pairs: review systematic cross-reactivity screening protocol (Month 4-6 = 2027-02-13 to 2027-04-13); identify high-risk pairs; recommend analyte redesign or removal if cross-reactivity >5% bias at 10× interferent; document risk mitigation
- Review plasma-separation and sample-preparation feasibility: assess plasma-yield and hemolysis data from Month 4-6 (2027-02-13 to 2027-04-13) study (100+ fingerstick subjects); validate that >=95% of samples yield >=1.6 microliters plasma with hemolysis index <50; flag any feasibility gaps and re-design scope
- Evaluate manufacturing and yield risk: conduct design-for-manufacturability (DFM) review with contract molding partner by Month 3 (2027-01-13); identify yield-limiting steps (injection molding defects, bonding, reagent filling); recommend design changes to improve moldability and yield; validate pilot-fill results (Month 12 = 2027-10-13) against yield model
- Assess reagent stability and shelf-life modeling: review real-time and accelerated-stability testing protocols (Month 3 = 2027-01-13); validate Arrhenius modeling assumptions; review Month 12 (2027-10-13) shelf-life projections; flag analytes with suspected early drift; recommend re-formulation scope
- Provide regulatory strategy and evidence-package guidance: review clinical-study protocol design, sample-size calculations, and analytical acceptance criteria (concordance >=95%, CV <10%); ensure that study design aligns with likely FDA expectations for 510(k) or De Novo; flag evidence gaps early

**Initial Setup Actions:**

- Month 0.5 (2026-10-28): Identify and recruit 5-7 external technical advisors (microfluidics, immunoassay, manufacturing, regulatory) with 15+ years experience and no financial interest in suppliers or funding decisions; finalize advisory-board charter
- Month 1 (2026-11-13): Hold inaugural meeting; review project risk map and identify highest-priority technical assessments (plasma separation, cross-reactivity, yield modeling)
- Month 2 (2026-12-13): Conduct first design-for-manufacturability session with contract-molding partners; document DFM findings and design-improvement recommendations

**Membership:**

- External microfluidics or lab-on-a-chip expert (15+ years in device development, no funding or supplier interest)
- External clinical immunoassay chemistry expert (15+ years in multiplex assay development, academic or industry)
- External manufacturing and process-engineering expert (15+ years in cartridge/device molding and assembly scale-up)
- External regulatory affairs expert (FDA submissions for in vitro diagnostics, 510(k) or De Novo experience)
- Internal Chief R&D Officer (ex officio, for context but not voting on R&D decisions to avoid conflicts)
- Optional: external scientific advisory board member with clinical-data interpretation expertise (if multi-analyte clinical-study design is novel)

**Decision Rights:** Authority to request data, protocols, and raw results from Operations Committee and to conduct independent verification of analytical or manufacturing results. Authority to recommend analyte removal, design changes, or re-testing without Operations approval (escalates to Steering Committee if Operations disagrees). Cannot directly command Operations Committee actions or approve funding; all recommendations are advisory. Cannot veto Steering Committee gate decisions, but can submit a minority written opinion if Technical Advisory Group disagrees with gate passage.

**Decision Mechanism:** Consensus opinion preferred; if split, the group issues separate findings and lets Steering Committee decide. Gate-validation decisions (e.g., concordance >=95% passes) are made by reviewing raw data and measurement protocols; success is confirmed only if measurement method is sound and acceptance criteria are met. Analyte-removal recommendations are made if an analyte fails objective thresholds; subjective calls (e.g., whether 94% concordance is 'close enough' to 95%) are escalated to Steering Committee with Technical Advisory Group's pro/con analysis.

**Meeting Cadence:** Quarterly full meetings (2-3 hours, virtual or in-person at Newark site) to review progress, risk, and upcoming gates. Ad-hoc targeted meetings (1-2 hours) at critical junctures: DFM review (Month 3 = 2027-01-13), cross-reactivity assessment (Month 5-6 = 2027-03-13 to 2027-04-13), plasma-separation data review (Month 6 = 2027-04-13), shelf-life projection (Month 12 = 2027-10-13), yield validation (Month 12-15 = 2027-10-13 to 2028-01-13), regulatory-evidence adequacy (Month 18 = 2028-04-13).

**Typical Agenda Items:**

- Quarterly meetings: project status and risk summary; upcoming technical gates and what data will determine passage; preliminary analyte and design performance; preliminary manufacturing learnings; regulatory pathway alignment and evidence-gap assessment
- DFM review (Month 3 = 2027-01-13): cartridge design, mold complexity, bonding method, yield assumptions; recommendations for design simplification or alternative manufacturing approaches
- Cross-reactivity assessment (Month 5-6 = 2027-03-13 to 2027-04-13): cross-reactivity screening results; high-risk analyte pairs; recommended removals or chemistry redesigns
- Plasma-separation review (Month 6 = 2027-04-13): plasma-yield data from 100+ fingerstick subjects; hemolysis distribution; adequacy of sample budget for intended analyte count
- Shelf-life and stability review (Month 12 = 2027-10-13): real-time and accelerated-stability data; Arrhenius modeling results; confidence in 12-month shelf-life projection; risk of early drift in any analyte
- Yield validation (Month 12-15 = 2027-10-13 to 2028-01-13): pilot-fill results; defect-mode analysis; first-pass yield; correlation to yield model and design-for-manufacturability recommendations
- Regulatory evidence (Month 18 = 2028-04-13): clinical-study protocol and enrollment progress; analytical acceptance criteria; sample-size power; evidence adequacy for planned submission pathway

**Escalation Path:** If Technical Advisory Group identifies a major feasibility risk (e.g., cross-reactivity cannot be resolved within design constraints, plasma separation achieves only 80% yield vs. 95% gate), a minority report is submitted to Steering Committee within 1 week. Steering Committee must address the concern in monthly meeting minutes. If gate passage is recommended by Operations but Technical Advisory Group disagrees (e.g., yield is 84% when gate is >=85%), Steering Committee holds an extended discussion with Technical Advisory Group present; Steering Committee decides, but dissent is documented. Technical Advisory Group can request an independent re-test at any time if data quality or measurement protocol is in question; Steering Committee approves or denies the request within 1 week.
### 4. Compliance, Ethics and Risk Management Committee (Specialized Governance Assurance)

**Rationale for Inclusion:** This venture operates in a heavily regulated domain (FDA, CLIA, ISO 13485, clinical trials) with significant reputational exposure due to historical precedent of failed single-drop diagnostic claims. The Compliance, Ethics and Risk Management Committee ensures that the company adheres to regulatory obligations, manages over-claiming risk, protects data integrity in clinical studies, and maintains ethical standards in transparency and stakeholder communication. The committee also integrates risk management across all governance bodies, ensuring that technical risks (gates), financial risks (capital, funding gaps), supply-chain risks (supplier dependencies), and reputational risks (credibility loss from failed analytes or over-claims) are identified, monitored, and mitigated proactively. Without this body, regulatory violations, clinical-trial non-compliance, selective data reporting, and credibility erosion could occur without systematic mitigation.

**Responsibilities:**

- Ensure regulatory compliance (FDA, CLIA, ISO 13485, IEC 62304, clinical-trial regulations): maintain a regulatory roadmap and compliance checklist; flag upcoming submissions, certifications, and inspection readiness; coordinate with Operations Committee on quality-system maturity, design-control documentation, and software development lifecycle compliance; schedule and support mock FDA inspection at Months 28-30 (2029-02-13 to 2029-04-13)
- Oversee compliance with pre-registered clinical-study protocol: review protocol registration on ClinicalTrials.gov; monitor study execution against approved protocol; flag any protocol deviations or amendments; coordinate with academic partner on data integrity, adverse-event reporting, and informed-consent compliance; ensure results (positive and negative) are published within committed timeline (Month 30 = 2029-04-13)
- Manage over-claiming and marketing compliance: enforce no-500-tests-per-drop rule (no public claim until 3 clusters independently validated); audit all investor pitches, press releases, and marketing materials for accuracy; cross-check product claims against validated data in Analyte Performance Report; ensure that failed or retired analytes are disclosed in regulatory submissions and, per company policy, in external communications after clearance
- Protect data integrity and research misconduct prevention: establish a data-management and research-misconduct policy; conduct data audits of clinical studies, analytical results, and regulatory submissions; maintain a research-misconduct hotline and handle reports confidentially; flag any evidence of selective data reporting, falsification, or regulatory misrepresentation within 48 hours to CEO and board
- Manage intellectual property and freedom-to-operate (FTO) compliance: oversee FTO review by patent counsel (Month 2-6 = 2026-12-13 to 2027-04-13); ensure no patents or regulatory violations from third-party IP; manage patent filings and publication strategy; ensure trade-secret protections on reagent formulations and processes
- Comprehensive risk management and escalation: maintain an enterprise risk register identifying all risks (technical, financial, regulatory, supply-chain, reputational) with likelihood, severity, owner, and mitigation plan; update quarterly; escalate risks scoring >9 (likelihood×severity) to Steering Committee within 5 business days; track mitigation progress; coordinate risk response across Operations and Technical Advisory Group
- Conflict-of-interest and ethics oversight: establish and enforce a conflict-of-interest policy for board, employees, advisors, and contractors; disclose all related-party transactions (e.g., board member has equity in a supplier) and manage recusals; maintain an ethics hotline for reporting concerns; review and approve all material supplier agreements and partnership deals for transparency and fairness

**Initial Setup Actions:**

- Month 1 (2026-11-13): Hire or contract a Chief Compliance Officer or General Counsel; establish committee charter and compliance roadmap
- Month 2 (2026-12-13): Develop conflict-of-interest policy, data-integrity policy, and marketing/claims policy; communicate to all staff
- Month 3 (2027-01-13): Initiate FTO review and regulatory roadmap (FDA Pre-Sub, ISO 13485, CLIA); establish risk register template and initial risk assessment; register clinical-study protocol on ClinicalTrials.gov (in preparation for Month 12 = 2027-10-13 study initiation)
- Month 4 (2027-02-13): Establish data-management and research-misconduct policies; brief academic clinical partner on data-integrity expectations; set up ethical advisory board (if not covered by Technical Advisory Group)

**Membership:**

- Chief Compliance Officer or General Counsel (chair)
- Quality/Regulatory lead (ISO 13485, FDA, design controls, inspection readiness)
- Chief Financial Officer or Finance lead (financial risk, funding compliance, budget controls)
- Chief R&D Officer or Operations lead (technical and operational risk, design-control compliance) (ex officio for risk discussions, not voting on operational decisions)
- External ethics or compliance expert (independent perspective on conflict-of-interest, data integrity, and corporate governance)
- Optional: external scientific integrity advisor (if clinical-study data management is novel or high-risk)

**Decision Rights:** Authority to develop and enforce compliance, ethics, and risk policies without Steering Committee approval (policies are informational unless they conflict with business decisions). Authority to audit and request corrections to regulatory submissions, marketing materials, and clinical-study documentation. Authority to escalate compliance violations, research misconduct, or unresolved conflicts of interest directly to CEO and investor board. Cannot unilaterally block a business decision (e.g., cannot stop a 510(k) submission), but can require documented risk disclosure to Steering Committee before decision is finalized.

**Decision Mechanism:** Consensus on policy development and risk assessment. Compliance violations are escalated by simple reporting (no vote needed). Risk escalation uses a quantitative risk-scoring matrix (likelihood 1-5 × severity 1-5 = 1-25 score); scores >9 are escalated immediately; scores 5-9 are tracked and reviewed quarterly. Data-integrity or research-misconduct allegations are investigated by the Chief Compliance Officer with external investigator involvement if needed; findings are reported to CEO and audit committee within 30 days.

**Meeting Cadence:** Quarterly compliance and risk reviews (2 hours); monthly check-ins with Quality/Regulatory on inspection readiness and design-control progress (1 hour); monthly data-integrity audits of clinical studies and analytical results (1 hour with academic partner); ad-hoc escalations (within 48 hours of identification).

**Typical Agenda Items:**

- Quarterly: regulatory roadmap status (FDA Pre-Sub prep, ISO 13485 timeline, CLIA application if applicable); inspection-readiness assessment; compliance violations or near-misses in past quarter; risk register review (technical, financial, regulatory, supply-chain, reputational risks); data-integrity audit findings; marketing/claims compliance check; conflict-of-interest disclosures and recusals
- Monthly data-integrity: clinical-study enrollment and data-entry status; adverse-event reporting (if any); protocol deviations or amendments; data-audit findings; academic-partner communication and compliance
- Monthly inspection-readiness: design-history-file completeness; change-control log review; training records and competency assessments; management-of-change documentation; complaint handling and adverse-event trending (if applicable)
- Quarterly risk register: update likelihood and severity for all identified risks; identify new risks; track mitigation-plan progress; escalate scores >9; discuss risk interdependencies (e.g., plasma-separation failure cascades to all clusters)

**Escalation Path:** Compliance violations (regulatory breach, research misconduct allegation, conflict-of-interest violation) escalate to CEO and board audit committee within 48 hours. Risk scores >9 (e.g., combined technical + financial risk of design failure + funding gap) escalate to Steering Committee within 5 business days with mitigation options. Data-integrity concerns (suspected selective reporting, falsification) trigger independent investigation and escalation to CEO and board within 30 days. Marketing or claims non-compliance (use of '500 tests' claim before validation) is escalated to CEO and chief marketing officer within 24 hours.

# Governance Implementation Plan

### 1. Project Sponsor and Founding Team identify and formally confirm the Project Steering Committee membership (CEO/Founder, Lead Investor or Board Delegate, CFO, Chief R&D Officer, Chief Quality Officer). Confirm availability, roles, decision rights and conflict-of-interest status.

**Responsible Body/Role:** Project Sponsor (or CEO/Founder acting as initiating authority) in coordination with Lead Investor

**Suggested Timeframe:** Within 1 week of project start (Month 0 = 2026-10-13, by 2026-10-20)

**Key Outputs/Deliverables:**

- Steering Committee membership roster with names, titles, affiliations
- Signed commitment letters from all 5 members confirming availability
- Conflict-of-interest disclosure forms (signed by each member)

**Dependencies:**

- Project Sponsor and Lead Investor identified
- CEO/Founder, CFO, R&D and Quality leadership roles defined and staffing authorized

### 2. Project Steering Committee hold inaugural founding meeting (2-3 hours) to finalize charter, define Fallback Panel V1 (50-analyte core with 4-5 cartridges), lock gate criteria (yield ≥85%, concordance ≥95%, shelf-life ≥12 months, plasma separation ≥95%, COGS ≤USD 25/cartridge), approve capital tranches and timeline, assign gate-meeting chair (typically CEO), establish monthly dashboard and reporting cadence.

**Responsible Body/Role:** Project Steering Committee (newly formed)

**Suggested Timeframe:** Month 0.5 (2026-10-28) (within 2 weeks of project start, by 2026-10-28)

**Key Outputs/Deliverables:**

- Steering Committee Charter (roles, decision rights, approval authorities, escalation paths)
- Fallback Panel V1 Definition Document (50 analytes, cartridge clustering, clinical use case)
- Gate Criteria and Thresholds Document (quantitative pass/fail/ambiguous criteria for Months 6, 12, 18, 24 = 2027-04-13, 2027-10-13, 2028-04-13, 2028-10-13)
- Capital Tranches Schedule (Seed USD 2-3M Months 0-6 = 2026-10-13 to 2027-04-13, A1 USD 3-4M Month 6 = 2027-04-13 gate, A2 USD 2-3M Month 12 = 2027-10-13 gate, etc.)
- Monthly Dashboard Template (analyte performance, yield, cash burn, regulatory milestones)

**Dependencies:**

- Steering Committee membership confirmed
- Project vision and strategic path (modular clusters, pharma beachhead, Newark phasing) understood by all members

### 3. CEO/Founder (or designated Formation Lead) formally draft and circulate the Steering Committee Charter and decision authorities document to all members for written comment. Incorporate feedback and finalize within 1 week.

**Responsible Body/Role:** CEO/Founder or Project Manager (as Formation Lead, before Steering Committee is fully operational for formal decisions)

**Suggested Timeframe:** Month 0.5 (2026-10-28) (within 2 weeks of project start, concurrent with membership confirmation)

**Key Outputs/Deliverables:**

- Draft Steering Committee Charter v0.1 (circulated for review)
- Feedback Summary (member comments consolidated)
- Final Steering Committee Charter v1.0 (signed off by CEO and Lead Investor)

**Dependencies:**

- Steering Committee membership roster confirmed
- Project governance structure and decision authorities outlined

### 4. Steering Committee formally adopt and publish the Fallback Panel V1 Definition (50 analytes, cartridge design, clinical scope), gate criteria, and capital-tranche schedule. Board votes on these foundational decisions; document voting record and any dissents.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Month 0.5 (2026-10-28) to Month 1 (2026-11-13) (within 3 weeks of project start)

**Key Outputs/Deliverables:**

- Signed Fallback Panel V1 Definition and Board Approval Minutes
- Gate Criteria and Thresholds Approval Minutes (voting record)
- Capital Tranches Approval Minutes (equity rounds and release conditions signed off)

**Dependencies:**

- Steering Committee Charter finalized
- Fallback Panel V1 and gate criteria drafted and ready for board review

### 5. CEO/Founder recruit and hire Chief R&D Officer and Chief Quality Officer / Regulatory Lead as first employees or co-founders (critical early hires). Finalize offer letters, compensation, equity, and onboarding plan.

**Responsible Body/Role:** CEO/Founder and HR/People Lead (or retained recruiter)

**Suggested Timeframe:** Month 1 (2026-11-13)

**Key Outputs/Deliverables:**

- Signed offer letters for R&D Director and Quality/Regulatory Lead
- First-hire onboarding plan and start dates
- Equity grant documents (vesting tied to technical milestones and gates)

**Dependencies:**

- CEO/Founder and lead investor available to lead recruitment
- Compensation and equity framework approved by board

### 6. Chief R&D Officer and Chief Quality Officer/Regulatory Lead, upon hire, jointly establish the Operations and Execution Committee charter, membership, and meeting cadence. Define design-change log process, analyte-review protocol, supplier scorecard, and regulatory-readiness assessment schedule.

**Responsible Body/Role:** Chief R&D Officer (as chair) and Chief Quality Officer / Regulatory Lead, with CEO approval

**Suggested Timeframe:** Month 1 (2026-11-13), immediately upon hire or within 1 week

**Key Outputs/Deliverables:**

- Operations and Execution Committee Charter and Membership List
- Design-Change Log Template and Approval Thresholds (USD 50k, 2-week impact ceiling)
- Analyte Review Meeting Schedule and Performance Report Template
- Supplier Scorecard Template (defect rate, delivery, cost tracking)
- Monthly Executive Sync Agenda and Meeting Cadence (weekly 1-hour, monthly full 2-hour)

**Dependencies:**

- Chief R&D Officer and Quality/Regulatory Lead hired and in role
- Project Steering Committee Fallback Panel V1 and gate criteria finalized

### 7. CEO/Founder and Chief Quality Officer develop and communicate Compliance, Ethics and Risk Management Committee charter. Hire or contract Chief Compliance Officer or General Counsel. Establish conflict-of-interest policy, data-integrity policy, and marketing/claims guidelines (no '500 tests per drop' claims until 3 clusters validated).

**Responsible Body/Role:** CEO/Founder (initiating), Chief Quality Officer (QMS liaison), and Chief Compliance Officer/General Counsel (upon hire)

**Suggested Timeframe:** Month 1 (2026-11-13) to Month 2 (2026-12-13 to 2026-12-13)

**Key Outputs/Deliverables:**

- Compliance, Ethics and Risk Management Committee Charter
- Conflict-of-Interest Policy (signed by CEO, board, early employees)
- Data-Integrity and Research-Misconduct Policy
- Marketing and Claims Compliance Policy (prohibiting '500 tests per drop' claims until 3 clusters validated)
- Risk Register Template and Scoring Methodology (likelihood × severity scale 1-25; escalate >9)

**Dependencies:**

- CEO/Founder and Chief Quality Officer in role
- Project governance structure and Fallback Panel V1 finalized

### 8. Project Sponsor and CEO/Founder identify and recruit 5-7 external Technical Advisory Group members (microfluidics, immunoassay chemistry, manufacturing, regulatory affairs experts with 15+ years experience, no financial interest in suppliers). Finalize advisory agreements and charter.

**Responsible Body/Role:** CEO/Founder (recruitment lead) with input from Chief R&D Officer and Lead Investor

**Suggested Timeframe:** Month 0.5 (2026-10-28) to Month 1 (2026-11-13 to 2026-11-13)

**Key Outputs/Deliverables:**

- Technical Advisory Group Roster (names, affiliations, expertise areas)
- Signed advisory agreements (scope, meeting cadence, confidentiality, no financial conflicts)
- Technical Advisory Group Charter (decision rights, validation authority, escalation path)

**Dependencies:**

- CEO/Founder and Lead Investor available to recruit external experts
- Project vision and technical risks (plasma separation, cross-reactivity, yield) clearly articulated

### 9. Project Steering Committee formally establish the Compliance, Ethics and Risk Management Committee. Approve charter, confirm Chief Compliance Officer/General Counsel hire, and authorize policies drafted in Month 2 (2026-12-13). Board votes on risk-management framework and data-integrity standards.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Month 2 (2026-12-13)

**Key Outputs/Deliverables:**

- Compliance, Ethics and Risk Management Committee Charter Approval Minutes
- Risk Management Framework and Enterprise Risk Register v1.0
- Compliance Policies Approval and All-Staff Communication (data integrity, conflict-of-interest, marketing claims)

**Dependencies:**

- Steering Committee in place with established meeting cadence
- Chief Compliance Officer/General Counsel hired or contracted
- Policies drafted and ready for board review

### 10. Chief R&D Officer, Chief Quality Officer, and Finance Lead jointly develop the 60-month cash-flow model with gate-linked tranches and lean-pivot trigger (pharma revenue <USD 100k/month at Month 18 = 2028-04-13 triggers 20-30% headcount reduction). Model pessimistic pharma scenario and non-dilutive funding (SBIR/STTR grants, partnerships). Finalize funding strategy and Series A sizing.

**Responsible Body/Role:** Chief R&D Officer, Chief Quality Officer, and CFO/Finance Lead

**Suggested Timeframe:** Month 2 (2026-12-13)

**Key Outputs/Deliverables:**

- 60-Month Cash-Flow Model (Months 0-60 = 2026-10-13 to 2031-10-13) with quarterly burn and gate-linked releases
- Pharma Revenue Scenarios (pessimistic, base, optimistic with probability-weighted funding need)
- Non-Dilutive Funding Strategy (SBIR/STTR grant applications, expected awards by Month 10-12 = 2027-08-13 to 2027-10-13)
- Series A Sizing and Tranche Approval Memo (recommended USD 10-15M Series A, phased release tied to gates)

**Dependencies:**

- Project Steering Committee capital tranches and lean-pivot trigger approved
- Chief R&D Officer and CFO in role; Finance lead identified

### 11. CEO/Founder and Chief Compliance Officer initiate freedom-to-operate (FTO) analysis with external patent counsel. Develop IP strategy document (what to patent, what to publish, what to trade-secret). Identify high-priority patent filings and provisional application timeline.

**Responsible Body/Role:** CEO/Founder and Chief Compliance Officer / General Counsel

**Suggested Timeframe:** Month 2 (2026-12-13)

**Key Outputs/Deliverables:**

- Freedom-to-Operate Preliminary Report (major patent risks identified, if any, in microfluidics, immunoassay, plasma separation)
- IP Strategy Document (filing plan, publication strategy, trade-secret inventory)
- Patent Counsel Engagement Letter and Budget (USD 50-100k for FTO and provisional filings, Months 0-6 = 2026-10-13 to 2027-04-13)

**Dependencies:**

- CEO/Founder, lead investor, and patent counsel available
- Cartridge architecture and fluidic design concepts articulated

### 12. Chief Quality Officer and Chief Compliance Officer jointly establish electronic quality management system (QMS), design-control system, and document-management infrastructure. Implement design-history file (DHF) template, change-control log, risk-management file (ISO 14971), and design-review meeting schedule.

**Responsible Body/Role:** Chief Quality Officer (owner) and Chief Compliance Officer (oversight)

**Suggested Timeframe:** Month 2 (2026-12-13) to Month 3 (2027-01-13 to 2027-01-13)

**Key Outputs/Deliverables:**

- Electronic QMS Platform Live (document management, workflow, audit trail)
- Design-History File (DHF) Template and Initial Population (from Month 0 = 2026-10-13 decisions)
- Change-Control Log Template and Approval Process (minor <USD 50k, USD 50k+ escalates to Steering Committee)
- Risk-Management File Template (ISO 14971 risk register, design-failure analysis, risk controls)
- Design-Review Meeting Schedule (monthly design reviews with R&D, quality, regulatory leads)

**Dependencies:**

- Chief Quality Officer hired and operational
- QMS software platform (e.g., MasterControl, Veeva, or equivalent) selected and contract signed

### 13. Chief R&D Officer initiate detailed design-for-manufacturability (DFM) review with 2-3 qualified contract injection-molding partners. Present cartridge architecture concepts and evaluate moldability, tolerances, process windows, lead times, and cost. Obtain mold quotes and identify design improvements to reduce yield risk.

**Responsible Body/Role:** Chief R&D Officer (lead) with Microfluidics/CAD Engineer and Procurement Lead

**Suggested Timeframe:** Month 3 (2027-01-13)

**Key Outputs/Deliverables:**

- DFM Review Summary from 2-3 Molders (moldability assessment, tolerance recommendations, yield concerns)
- Mold Tooling Quotes (design, build, and first-article-run pricing; lead times 4-6 months)
- Design-Improvement Recommendations (modifications to cartridge to improve moldability)

**Dependencies:**

- Chief R&D Officer and microfluidics engineers in role
- Cartridge architecture and fluidic design concepts mature enough for molding assessment
- 2-3 contract molders identified and contacted

### 14. Chief R&D Officer and Chief Quality Officer jointly finalize Fallback Panel V1 analyte list (50 analytes, 4-5 cartridges of 10-15 analytes each). Lock analyte selection criteria (clinical value, reference-method availability, cross-reactivity risk, sensitivity feasibility). Create Analyte Performance Report template with monthly tracking of concordance, CV, shelf-life, yield per analyte.

**Responsible Body/Role:** Chief R&D Officer (technical lead) and Chief Quality Officer (quality and regulatory alignment)

**Suggested Timeframe:** Month 2 (2026-12-13)

**Key Outputs/Deliverables:**

- Fallback Panel V1 Analyte List (50 analytes, grouped into 4-5 cartridges with clinical clustering)
- Analyte Selection Criteria and Justification Document
- Analyte Performance Report Template v1.0 (columns: analyte name, concordance mean/95% CI, CV, shelf-life projection, yield, status: In Progress/Pass/Fail/Retired)

**Dependencies:**

- Chief R&D Officer and Chief Quality Officer in role
- Steering Committee Fallback Panel V1 definition approved (general 50-analyte target)

### 15. CEO/Founder and Chief R&D Officer identify and initiate relationships with academic clinical research partner for pre-submission clinical-study co-design and future patient-sample enrollment (Months 12-24 = 2027-10-13 to 2028-10-13). Issue RFP or letter of intent to 3-5 academic medical centers. Negotiate partnership terms (data ownership, publication rights, cost-sharing).

**Responsible Body/Role:** CEO/Founder (business lead) and Chief R&D Officer (scientific lead)

**Suggested Timeframe:** Month 3 (2027-01-13)

**Key Outputs/Deliverables:**

- Academic Partner RFP or Letter of Intent (3-5 centers contacted)
- Partnership Discussions Summary (candidate sites, preliminary terms)
- Signed Partnership Agreement or Letter of Intent with primary academic site (expected by Month 6 = 2027-04-13)

**Dependencies:**

- CEO/Founder and Chief R&D Officer in role
- Clinical-study scope and timeline (Months 12-24 = 2027-10-13 to 2028-10-13) defined

### 16. Chief R&D Officer establish analytical-feasibility and cross-reactivity testing protocol for Cluster 1 (10-15 analytes). Design systematic screening: each analyte measured alone, in pairs, and in full multiplex, spiked into human plasma with elevated interferents (hemoglobin, bilirubin, lipemia, rheumatoid factor). Set success criteria: ≤5% bias at 10× physiologic interferent concentration. Conduct testing over Months 4-6 (2027-02-13 to 2027-04-13).

**Responsible Body/Role:** Chief R&D Officer (owner) and Assay Chemistry Lead

**Suggested Timeframe:** Month 3 (2027-01-13) to Month 4 (2027-02-13 to 2027-02-13), with testing execution Months 4-6 (2027-02-13 to 2027-04-13)

**Key Outputs/Deliverables:**

- Cross-Reactivity Testing Protocol and Success Criteria
- Cross-Reactivity Study Plan (sample selection, interferent levels, measurement methods)
- Preliminary Cross-Reactivity Data (by Month 5 = 2027-03-13) and Preliminary Report by Month 6 (2027-04-13)

**Dependencies:**

- Chief R&D Officer and Assay Chemistry Lead in role
- Fallback Panel V1 Cluster 1 analyte list finalized (Month 2 = 2026-12-13)

### 17. Chief R&D Officer establish plasma-separation feasibility study protocol for fingerstick collection. Design study: collect samples from 100+ fingerstick subjects, measure plasma yield, hemolysis rate, and sample adequacy. Set success gate: ≥95% of samples yield ≥1.6 microliters usable plasma. Conduct study over Months 4-6 (2027-02-13 to 2027-04-13).

**Responsible Body/Role:** Chief R&D Officer (owner) and Sample-Preparation / Microfluidics Engineer

**Suggested Timeframe:** Month 3 (2027-01-13) to Month 4 (2027-02-13 to 2027-02-13), with testing execution Months 4-6 (2027-02-13 to 2027-04-13)

**Key Outputs/Deliverables:**

- Plasma-Separation Feasibility Study Protocol
- Subject Recruitment and Informed-Consent Plan (100+ fingerstick subjects)
- Preliminary Plasma-Yield Data (by Month 5 = 2027-03-13) and Interim Report by Month 6 (2027-04-13)

**Dependencies:**

- Chief R&D Officer and sample-preparation engineers in role
- Academic clinical partner identified for subject recruitment
- Institutional review board (IRB) approval pathway understood

### 18. Chief Compliance Officer and Chief Quality Officer prepare materials for FDA Pre-Submission Type B meeting. Draft questions: (1) Is 510(k) or De Novo required for a 50-analyte or 100-analyte multiplex immunoassay panel? (2) Can staged per-cluster 510(k)s be filed? (3) What analytical and clinical evidence is expected? (4) Can a CLIA lab-service route run in parallel? Submit Pre-Submission request to FDA CDRH by Month 3 (2027-01-13). Target meeting by Month 6 (2027-04-13).

**Responsible Body/Role:** Chief Compliance Officer / Regulatory Lead (lead) and Chief Quality Officer (quality-system context)

**Suggested Timeframe:** Month 2 (2026-12-13) to Month 3 (2027-01-13 to 2027-01-13) for request submission; meeting held Month 6 (2027-04-13)

**Key Outputs/Deliverables:**

- FDA Pre-Submission Type B Meeting Request (submitted to FDA CDRH by Month 3 = 2027-01-13)
- Pre-Sub Meeting Preparation Package (slides, intended use statement, proposed regulatory pathway, clinical-study design outline)
- FDA Pre-Submission Meeting Minutes and Agency Feedback (by Month 6 = 2027-04-13)

**Dependencies:**

- Chief Compliance Officer and Chief Quality Officer in role
- Regulatory consultant or counsel engaged to support Pre-Sub preparation (USD 50-100k budget, Months 0-6 = 2026-10-13 to 2027-04-13)

### 19. Chief R&D Officer initiate stability-testing program for Cluster 1. Prepare cartridge lots at Month 3 (2027-01-13). Launch real-time stability (2-8°C storage, monthly testing for 24 months) and accelerated stability (25°C/60% RH and 40°C/75% RH per ICH, testing at days 0, 7, 14, 30, 60, 90, 180). Set gate at Month 12 (2027-10-13): if shelf-life projected ≥12 months with Arrhenius R² >0.90, proceed; if <9 months, reformulate and delay launch 3 months.

**Responsible Body/Role:** Chief R&D Officer (owner) and Assay Chemistry / Formulation Lead

**Suggested Timeframe:** Month 3 (2027-01-13) for protocol setup and initial lot preparation

**Key Outputs/Deliverables:**

- Stability-Testing Protocol (real-time and accelerated per ICH Q1A/Q1B)
- Initial Lot Preparation and Storage (at Month 3 = 2027-01-13)
- Month 6 (2027-04-13) Interim Stability Report (90 days accelerated data, initial real-time readings)
- Month 12 (2027-10-13) Shelf-Life Projection and Gate Determination (Arrhenius model, pass/fail decision)

**Dependencies:**

- Chief R&D Officer and formulation chemist in role
- Cluster 1 cartridge design and reagent formulations finalized (by Month 3 = 2027-01-13)

### 20. CEO/Founder and Chief R&D Officer identify pharma and grant-funding prospects. Target 5-10 potential pharma sponsors (biomarker monitoring, Phase 2b/Phase 3 clinical trials). Issue 'feasibility partnership' letters; no committed funding expected yet. Simultaneously, identify SBIR/STTR grant opportunities (NIH, NSF, DOE) and prepare Phase 1 applications (deadline Month 4-5 = 2027-02-13 to 2027-03-13).

**Responsible Body/Role:** CEO/Founder (business lead) and Chief R&D Officer (scientific credibility)

**Suggested Timeframe:** Month 3 (2027-01-13)

**Key Outputs/Deliverables:**

- Pharma Prospect List (5-10 sponsors, preliminary outreach)
- Feasibility Partnership Letter (describing platform, data-generation opportunity, no funding request yet)
- SBIR/STTR Grant Application Package (Phase 1 grants, USD 100-500k, due Month 4-5 = 2027-02-13 to 2027-03-13)

**Dependencies:**

- CEO/Founder and Chief R&D Officer in role
- Platform concept and preliminary data (cross-reactivity, plasma separation) available by Month 3 (2027-01-13)

### 21. Chief Quality Officer conduct internal ISO 13485 compliance assessment (Month 3-4 = 2027-01-13 to 2027-02-13). Audit design controls, documentation, management of change, complaint handling, supplier management, and personnel training. Identify gaps and develop corrective-action plan for certification by Month 18 (2028-04-13).

**Responsible Body/Role:** Chief Quality Officer (lead) with external ISO 13485 consultant if needed

**Suggested Timeframe:** Month 3 (2027-01-13) to Month 4 (2027-02-13 to 2027-02-13)

**Key Outputs/Deliverables:**

- Internal ISO 13485 Gap Assessment Report (design controls, QMS documentation, CAPA, supplier management, training records)
- Corrective-Action Plan to achieve ISO 13485 certification by Month 18 (2028-04-13)
- ISO 13485 Consultant Engagement (if external support needed; budget USD 50-100k)

**Dependencies:**

- Chief Quality Officer in role
- QMS platform and design-control system established (Month 2-3 = 2026-12-13 to 2027-01-13)

### 22. Chief R&D Officer and Operations Committee conduct preliminary supplier-identification and qualification planning. Identify 2-3 candidate contract-injection-molders, 1-2 reagent suppliers per critical analyte, and potential instrument-assembly partner. Request quality certifications, lead-time quotes, and quality-agreement templates. Target dual sourcing for highest-risk reagents.

**Responsible Body/Role:** Chief R&D Officer (technical evaluation) and Procurement Lead / Operations Committee

**Suggested Timeframe:** Month 4 (2027-02-13)

**Key Outputs/Deliverables:**

- Supplier Candidate List (molders, reagent suppliers, assembly partners; names, capabilities, references)
- Supplier Qualification Checklist (quality certifications, financial stability, lead-time commitments)
- Quality-Agreement Template and Critical Reagent Dual-Source Plan

**Dependencies:**

- Chief R&D Officer, Procurement Lead, and Supplier/Quality team in role
- Cartridge design and analyte list mature enough to specify supplier requirements

### 23. Chief R&D Officer and CFO develop bottom-up cost-of-goods (COGS) model for Cluster 1. Estimate: cartridge body USD 2-4, fluidic bonding USD 1-2, reagents USD 4-8, QC consumables USD 2-4, packaging USD 2-3. Lock COGS ceiling of USD 25 per cartridge. Model per-run reimbursement (USD 100-200 base case) and gross-margin target (≥60% at 50k cartridges/month).

**Responsible Body/Role:** Chief R&D Officer (engineering cost driver estimation) and CFO / Finance Lead (financial modeling)

**Suggested Timeframe:** Month 3 (2027-01-13)

**Key Outputs/Deliverables:**

- Bottom-Up COGS Model (component-level cost breakdown for Cluster 1)
- COGS Ceiling Lock Document (USD 25 per cartridge, approved by Steering Committee)
- Unit-Economics Projection (revenue scenarios USD 50-500 per panel, margin sensitivity analysis)

**Dependencies:**

- Chief R&D Officer, CFO, and Finance Lead in role
- Cluster 1 cartridge design and analyte list finalized

### 24. Operations Committee formally establish monthly Analyte Review Meeting schedule (Months 3-12 = 2027-01-13 to 2027-10-13). Monthly meetings assess each Cluster 1 analyte against thresholds (concordance ≥95%, CV <10%, shelf-life ≥12 months projected). Decide: redesign (re-test within 4-8 weeks), retire (remove from panel), or defer (move to Cluster 2). Document decisions in Analyte Performance Report visible to board.

**Responsible Body/Role:** Operations Committee (Chief R&D Officer, Quality Lead, Assay Chemistry Lead, and others)

**Suggested Timeframe:** Month 3 (2027-01-13), with first meeting Month 4 (2027-02-13) and monthly thereafter

**Key Outputs/Deliverables:**

- Analyte Review Meeting Schedule (monthly Months 4-12 = 2027-02-13 to 2027-10-13)
- Analyte Review Meeting Minutes (analyte status, pass/fail/redesign decisions, timeline for re-tests)
- Analyte Performance Report (updated monthly, cumulative view of all analyte status)

**Dependencies:**

- Operations Committee established with monthly cadence
- Analyte Performance Report template created and populated with baseline data

### 25. Chief Compliance Officer and project team develop comprehensive communications and transparency strategy. Commit publicly to: (1) pre-registered, independent clinical studies with published protocols (ClinicalTrials.gov registration by Month 6 = 2027-04-13); (2) monthly public data dashboard (assay performance, analytes passing/failing, cross-reactivity results); (3) external scientific advisory board with quarterly public meetings and data audit access; (4) quarterly investor and stakeholder updates (gate results, miss/make analysis); (5) no '500 tests per drop' marketing claim until 3 clusters independently validated. Issue public statement of commitment (Month 2-3 = 2026-12-13 to 2027-01-13).

**Responsible Body/Role:** Chief Compliance Officer (policy lead) and CEO/Founder (public announcement)

**Suggested Timeframe:** Month 2 (2026-12-13) to Month 3 (2027-01-13 to 2027-01-13) for policy; public announcement Month 3 (2027-01-13)

**Key Outputs/Deliverables:**

- Science-First Communications Charter (public commitment document, signed by CEO and board)
- Pre-Registration Plan for Clinical Study (ClinicalTrials.gov registration by Month 6 = 2027-04-13)
- Monthly Data-Dashboard Template and Reporting Plan
- Advisory Board Structure and Meeting Schedule (quarterly public meetings)
- Marketing and Claims Policy (written policy prohibiting '500 tests per drop' claims before validation)

**Dependencies:**

- CEO/Founder, Chief Compliance Officer, and Chief R&D Officer in role
- Project Steering Committee and board aware of and committed to transparency strategy

### 26. Technical Advisory Group hold inaugural meeting (2-3 hours, virtual). Review project overview, risk map, and technical governance. Establish quarterly meeting cadence and identify highest-priority technical assessments (plasma separation, cross-reactivity, yield). Schedule ad-hoc focused reviews at Months 3, 5-6 (2027-01-13, 2027-03-13 to 2027-04-13) for DFM, cross-reactivity screening.

**Responsible Body/Role:** Technical Advisory Group (newly formed external advisors) facilitated by Chief R&D Officer

**Suggested Timeframe:** Month 1 (2026-11-13) to Month 2 (2026-12-13 to 2026-12-13)

**Key Outputs/Deliverables:**

- Technical Advisory Group Inaugural Meeting Minutes (risk prioritization, assessment schedule)
- Quarterly Meeting Schedule and Agenda Template
- Ad-Hoc Assessment Plan (DFM review Month 3 = 2027-01-13, cross-reactivity Month 5-6 = 2027-03-13 to 2027-04-13)

**Dependencies:**

- Technical Advisory Group members confirmed and advisory agreements signed
- Chief R&D Officer available to facilitate and brief advisors

### 27. Compliance, Ethics and Risk Management Committee hold inaugural meeting (2 hours). Review enterprise risk register (initial 20+ risks identified: analytical feasibility, regulatory pathway, funding gap, unit economics, reputational damage, supply-chain, talent, payer coverage, shelf-life, equipment lead times, clinical study design, scope creep, software/cybersecurity, competition, plasma separation, cold chain, facility cost, IP/partnerships). Establish quarterly review cadence and assign risk owners. Set escalation triggers (risk score >9 escalates to Steering Committee within 5 business days).

**Responsible Body/Role:** Compliance, Ethics and Risk Management Committee (Chief Compliance Officer, Chief Quality Officer, CFO, and external ethics advisor)

**Suggested Timeframe:** Month 2 (2026-12-13)

**Key Outputs/Deliverables:**

- Enterprise Risk Register v1.0 (20+ risks, likelihood/severity scoring, owners, mitigation plans)
- Risk-Scoring Methodology and Escalation Thresholds (score >9 = immediate Steering Committee escalation)
- Quarterly Risk-Review Meeting Schedule
- Data-Integrity, Research-Misconduct, and Conflict-of-Interest Policies (communicated to all staff)

**Dependencies:**

- Chief Compliance Officer, Chief Quality Officer, and external advisor in place
- Project Steering Committee and risk landscape understood by committee

### 28. Operations Committee establish supplier-scorecard process and begin monthly supplier monitoring. For each contract molder, reagent supplier, and assembly partner, track: defect rate, on-time delivery %, cost performance vs. contract, and quality-agreement compliance. Set escalation: if defect rate exceeds 10% or delivery delay exceeds 2 weeks, escalate within 1 week; activate backup supplier within 2 weeks if primary fails.

**Responsible Body/Role:** Operations Committee (Chief R&D Officer, Procurement Lead, Quality Lead, and Supplier/Quality Manager)

**Suggested Timeframe:** Month 4 (2027-02-13), with supplier scorecard live by Month 6 (2027-04-13)

**Key Outputs/Deliverables:**

- Supplier Scorecard Template (columns: supplier name, defect rate %, on-time delivery %, cost variance, quality-agreement status, escalation flag)
- Monthly Supplier Review Meeting (1 hour, track and escalate quality failures)
- Supplier Escalation and Backup-Activation Plan (defect >10% = 2-week backup activation)

**Dependencies:**

- Primary suppliers identified and quality agreements signed (by Month 4 = 2027-02-13)
- Supplier scorecard system integrated into operations

### 29. Operations Committee issue request for quotation (RFQ) to 2-3 qualified contract-injection-molders, specifying cartridge design, first-article requirements, and mold lead time. Request quotes for mold design/build, first-article-run (5,000-10,000 units), and per-cartridge pricing at 1k, 10k, 50k volumes. Target quotes received by Month 4 (2027-02-13); mold-order decision deferred until design freeze (Month 18 = 2028-04-13).

**Responsible Body/Role:** Chief R&D Officer (technical specifications) and Procurement Lead (RFQ issuance and quote management)

**Suggested Timeframe:** Month 3 (2027-01-13) to Month 4 (2027-02-13 to 2027-02-13)

**Key Outputs/Deliverables:**

- RFQ for Contract-Injection Molding (cartridge design, first-article requirements, lead-time and cost expectations)
- Molder Quotes Summary (2-3 quotes received by Month 4 = 2027-02-13; mold cost, lead time, per-unit pricing)
- Design-for-Manufacturability Feedback Consolidated (design improvement recommendations from molders)

**Dependencies:**

- Cartridge design mature enough for molding RFQ (frozen by Month 3-4 = 2027-01-13 to 2027-02-13)
- 2-3 qualified contract molders identified and RFQ issued

### 30. Chief Compliance Officer coordinate clinical-study protocol development with academic clinical partner. Define study design: 300-500 subjects (healthy and disease states), paired fingerstick and reference samples, method-comparison for each analyte, pre-registered protocol on ClinicalTrials.gov. Set success criteria: ≥95% concordance, CV <10% per analyte. Target protocol approval by Month 9 (2027-07-13) and IRB approval by Month 12 (2027-10-13).

**Responsible Body/Role:** Chief Compliance Officer / Regulatory Lead (lead) with Chief R&D Officer and academic partner

**Suggested Timeframe:** Month 3 (2027-01-13) to Month 9 (2027-07-13 to 2027-07-13) for protocol development; IRB approval target Month 12 (2027-10-13)

**Key Outputs/Deliverables:**

- Clinical-Study Protocol Draft v1.0 (study design, sample size, inclusion/exclusion, analytical acceptance criteria)
- Sample-Size Power Calculation (based on smallest-effect-size analyte, 80% power, 5% significance)
- Pre-Registration on ClinicalTrials.gov (by Month 9 = 2027-07-13)
- IRB Submission Package (by Month 10 = 2027-08-13); IRB approval expected Month 12 (2027-10-13)

**Dependencies:**

- Chief Compliance Officer, Chief R&D Officer, and academic clinical partner in role
- Cluster 1 analyte list and study timeline finalized

### 31. Project Steering Committee hold Month 6 (2027-04-13) comprehensive gate-review meeting (4-6 hours). Assess Month 6 (2027-04-13) gate criteria: plasma separation ≥95% of ≥100 subjects with ≥1.6 µL plasma, hemolysis <50; cross-reactivity ≤5% bias; COGS ceiling USD 25 locked; FDA Pre-Sub held (minutes reviewed); QMS live and design controls documented; Fallback Panel V1 defined. Vote on gate passage (pass/fail/ambiguous with confidence intervals). If pass, release Series A Tranche 1 (USD 3-4M). If fail or ambiguous, escalate to retest or redesign within 4 weeks.

**Responsible Body/Role:** Project Steering Committee (CEO, Lead Investor, CFO, Chief R&D Officer, Chief Quality Officer)

**Suggested Timeframe:** Month 6 (2027-04-13)

**Key Outputs/Deliverables:**

- Gate-Review Meeting Minutes (analyte performance data, plasma-separation results, COGS model, FDA Pre-Sub feedback, QMS status)
- Month 6 (2027-04-13) Gate Determination Document (pass/fail/ambiguous with numeric data, confidence intervals, decision logic)
- Series A Tranche 1 Capital Release Approval (if gate passes) or Retest/Redesign Plan (if fail/ambiguous)
- Updated Cash-Flow Forecast and Pharma-Revenue Status

**Dependencies:**

- Steering Committee monthly tracking meetings held (Months 1-5 = 2026-11-13 to 2027-03-13)
- Cross-reactivity, plasma-separation, COGS, and FDA Pre-Sub data compiled and validated

### 32. CEO/Founder and Chief R&D Officer initiate formal pharma-partnership negotiations. Target 2-3 pharma sponsors for paid feasibility studies (1,000-5,000 patient samples, Months 10-15 = 2027-08-13 to 2028-01-13). Issue term sheets; target signed contracts by Month 9 (2027-07-13) specifying: sample volume, pricing (USD 50-100 per sample), data ownership, publication rights, timeline.

**Responsible Body/Role:** CEO/Founder (business lead) and Chief R&D Officer (scientific credibility)

**Suggested Timeframe:** Month 6 (2027-04-13) to Month 9 (2027-07-13 to 2027-07-13)

**Key Outputs/Deliverables:**

- Pharma Partnership Term Sheet (sample volume, pricing, data ownership, publication rights)
- Signed Pharma Contract 1 (or 2) for paid feasibility study (USD 50-100k per contract); expected by Month 9 (2027-07-13)

**Dependencies:**

- Month 6 (2027-04-13) gate passes and Series A Tranche 1 funding secured
- Preliminary Cluster 1 data available (cross-reactivity, concordance) to support pharma pitch

### 33. CEO/Founder and CFO initiate Series A Tranche 2 (USD 2-3M) and Series B (USD 3-5M) fundraising roadmaps, modeling contingencies. If Month 6 (2027-04-13) gate passes, Series A Tranche 2 (USD 2-3M) is released at Month 12 (2027-10-13) analytical-feasibility gate. Series B (USD 3-5M) is targeted for Month 18-24 (2028-04-13 to 2028-10-13) upon design freeze and clinical-study enrollment. Prepare pitch deck with gate-linked milestones and risk mitigations.

**Responsible Body/Role:** CEO/Founder (investor relations) and CFO (financial modeling)

**Suggested Timeframe:** Month 6 (2027-04-13)

**Key Outputs/Deliverables:**

- Series A and Series B Fundraising Roadmap (gate-linked capital release, target dates)
- Series B Pitch Deck (executive summary, technical risks, gate criteria, capital ask, exit scenarios)
- Investor Communication Plan (quarterly gate-result updates, board participation)

**Dependencies:**

- Month 6 (2027-04-13) gate passes and Series A Tranche 1 funded
- Cash-flow model and lean-pivot trigger communicated to investors

### 34. Technical Advisory Group conduct formal cross-reactivity assessment (Month 5-6 = 2027-03-13 to 2027-04-13). Review cross-reactivity screening results (each analyte pair, spiked-plasma data, % bias). Recommend redesign or removal for high-risk pairs (>5% bias at 10× interferent). Document risk-mitigation decisions in Technical Advisory report to Steering Committee.

**Responsible Body/Role:** Technical Advisory Group (external microfluidics and immunoassay experts) facilitated by Chief R&D Officer

**Suggested Timeframe:** Month 5 (2027-03-13) to Month 6 (2027-04-13 to 2027-04-13)

**Key Outputs/Deliverables:**

- Cross-Reactivity Assessment Report (analyte-pair results, pass/fail against ≤5% bias criterion, redesign or removal recommendations)
- High-Risk Analyte Pair Summary (analytes recommended for redesign or retirement, rationale)

**Dependencies:**

- Cross-reactivity screening data compiled (by Month 5 = 2027-03-13)
- Technical Advisory Group in place and ready to review

### 35. Operations Committee formally finalize clinical-study protocol and submit to IRB for approval. Coordinate with academic partner on site activation, subject recruitment plan, and informed-consent process. Obtain IRB approval by Month 12 (2027-10-13). Designate clinical-trial coordinator and establish data-management systems (eCRF, LIMS integration for result reporting).

**Responsible Body/Role:** Operations Committee (Chief Compliance Officer / Regulatory Lead, Chief R&D Officer, Clinical-Trial Coordinator, and academic partner)

**Suggested Timeframe:** Month 9 (2027-07-13) to Month 12 (2027-10-13 to 2027-10-13)

**Key Outputs/Deliverables:**

- Final Clinical-Study Protocol v2.0 (IRB-approved)
- IRB Approval Letter (by Month 12 = 2027-10-13)
- Clinical-Site Activation Plan (subject recruitment target, enrollment timeline, data-collection procedures)
- Data-Management Systems Documentation (eCRF setup, LIMS integration, data-integrity controls)

**Dependencies:**

- Protocol drafted and pre-registered (Month 9 = 2027-07-13)
- Academic partner and clinical sites identified
- IRB submission complete (by Month 10 = 2027-08-13)

### 36. Operations Committee conduct pilot-scale cartridge manufacturing with contract-injection-molder partner. Conduct first-article run (FAR) of 5,000-10,000 cartridges with Cluster 1 design. Measure yield, defect rate, reagent-fill variability. Target completion by Month 12 (2027-10-13). Yield should be ≥85% mean (lower 95% CI ≥80%); lot CV <10%. Results inform design-freeze decision and Month 18 (2028-04-13) Newark phase-2 capital release.

**Responsible Body/Role:** Chief R&D Officer (quality oversight) with contract-molder partner and Manufacturing/Operations Lead

**Suggested Timeframe:** Month 9 (2027-07-13) to Month 12 (2027-10-13 to 2027-10-13) for first-article run

**Key Outputs/Deliverables:**

- First-Article Run Plan (cartridge design, mold trials, defect-mode analysis, yield targets)
- First-Article Run Results (yield %, defect-rate summary, reagent-fill consistency, lot CV)
- Design-for-Manufacturability Lessons Learned (mold modifications if needed for next iteration)

**Dependencies:**

- Cartridge design locked (by Month 6 = 2027-04-13)
- Contract molder engaged and production mold ready (by Month 10-12 = 2027-08-13 to 2027-10-13)

### 37. Operations Committee establish standardized lot-release and reagent-handling SOPs for future Newark operations. Define reagent-lot acceptance criteria (potency assay, endotoxin, sterility, stability), release documentation, and quarantine procedures. Document requirements for in-house reagent formulation and lot release at Newark site.

**Responsible Body/Role:** Chief Quality Officer (lead) with Chief R&D Officer and Operations Committee

**Suggested Timeframe:** Month 9 (2027-07-13) to Month 12 (2027-10-13 to 2027-10-13)

**Key Outputs/Deliverables:**

- Reagent Lot-Release SOP and Acceptance Criteria
- Lot-Traceability Documentation Template (batch numbers, supplier, potency, stability, release sign-off)
- Reagent Quality-Control Methods and Qualification Plan

**Dependencies:**

- Chief Quality Officer and Chief R&D Officer in role
- QMS and design controls established (Months 2-3 = 2026-12-13 to 2027-01-13)

### 38. Chief Compliance Officer and Compliance, Ethics and Risk Management Committee conduct data-integrity audit of cross-reactivity and plasma-separation studies (Months 4-6 = 2027-02-13 to 2027-04-13). Verify: protocol adherence, measurement accuracy, data recording and traceability, absence of selective reporting or corrections without documentation. Issue audit report by Month 7 (2027-05-13).

**Responsible Body/Role:** Chief Compliance Officer (lead) and Compliance, Ethics and Risk Management Committee

**Suggested Timeframe:** Month 7 (2027-05-13) for audit completion

**Key Outputs/Deliverables:**

- Data-Integrity Audit Report (cross-reactivity and plasma-separation studies, findings, corrective actions if any)

**Dependencies:**

- Cross-reactivity and plasma-separation studies completed (by Month 6 = 2027-04-13)
- Chief Compliance Officer and audit procedures in place

### 39. Chief Quality Officer coordinate formal regulatory-roadmap approval with Steering Committee. Document FDA Pre-Submission feedback (510(k) vs. De Novo likelihood), planned regulatory pathway (staged per-cluster 510(k) submissions preferred), quality-system readiness timeline (ISO 13485 by Month 18 = 2028-04-13), and CLIA lab-service fallback (staff and operational plan by Month 12 = 2027-10-13). Obtain Steering Committee approval of regulatory plan.

**Responsible Body/Role:** Chief Quality Officer / Regulatory Lead (lead) with Steering Committee

**Suggested Timeframe:** Month 6 (2027-04-13) to Month 9 (2027-07-13 to 2027-07-13)

**Key Outputs/Deliverables:**

- Regulatory Roadmap Document (FDA pathway, quality-system milestones, submission timeline)
- CLIA Lab-Service Fallback Plan (operations, staffing, revenue timeline, no later than Month 12 = 2027-10-13)
- Steering Committee Approval Minutes (regulatory pathway and plan signed off)

**Dependencies:**

- FDA Pre-Submission feedback received (by Month 6 = 2027-04-13)
- Chief Quality Officer and Steering Committee in place

### 40. Operations Committee finalize Cluster 1 analyte list and design freeze decision with input from Technical Advisory Group. Document all analyte-performance data compiled through Month 6-12 (2027-04-13 to 2027-10-13). Remove any analytes failing thresholds (concordance <95%, CV >10%, shelf-life <9 months projected, cross-reactivity >5%). Publish Fallback Panel V1 final roster (≤50 analytes, likely 4-5 cartridges of ~10-15 analytes each, or smaller if more fail). Obtain Steering Committee and Technical Advisory Group sign-off on final panel and design freeze.

**Responsible Body/Role:** Operations Committee (Chief R&D Officer, Quality Lead, Chief Quality Officer) with Technical Advisory Group review

**Suggested Timeframe:** Month 12 (2027-10-13) to Month 15 (2028-01-13 to 2028-01-13), with design freeze target Month 15-18 (2028-01-13 to 2028-04-13)

**Key Outputs/Deliverables:**

- Analyte Final Performance Report (all analytes, pass/fail data, retired/redesigned analyte rationale)
- Fallback Panel V1 Final Roster (confirmed ≤50 analytes, cartridge clustering, clinical use claim)
- Design Freeze Sign-Off (Steering Committee, Technical Advisory Group, and R&D leadership approval of final cartridge design, fluidics, and analyte list)

**Dependencies:**

- Months 6-12 (2027-04-13 to 2027-10-13) analyte-performance data (concordance, cross-reactivity, shelf-life, yield) compiled
- Operations and Technical Advisory Group reviews completed

### 41. Project Steering Committee hold Month 12 (2027-10-13) comprehensive analytical-feasibility gate-review meeting (4-6 hours). Assess gate criteria: (1) pilot-scale yield ≥85% (mean, lower 95% CI ≥80%); (2) lot-to-lot CV <10%; (3) shelf-life ≥12 months projected (Arrhenius R² >0.90); (4) concordance ≥95% (lower CI ≥93%) from preliminary clinical data (100-150 samples); (5) COGS modeled ≤USD 25/cartridge (validated against FAR data); (6) Fallback Panel V1 finalized with ≤50 analytes; (7) FDA Pre-Sub completed and regulatory pathway confirmed; (8) clinical-study protocol approved and enrollment about to start. Vote on gate passage. If pass, approve design freeze and release Series A Tranche 2 (USD 2-3M) and authorize Newark Phase 1 capital release (USD 500-800k). If fail, pause design freeze and Newark spending; conduct 4-week design review and retest by Month 15 (2028-01-13).

**Responsible Body/Role:** Project Steering Committee (CEO, Lead Investor, CFO, Chief R&D Officer, Chief Quality Officer)

**Suggested Timeframe:** Month 12 (2027-10-13)

**Key Outputs/Deliverables:**

- Month 12 (2027-10-13) Gate-Review Meeting Minutes (yield, CV, shelf-life, concordance data; COGS validation; Fallback Panel V1 final roster; FDA feedback; clinical-study readiness)
- Analytical-Feasibility Gate Determination (pass/fail/ambiguous with numeric data and confidence intervals)
- Series A Tranche 2 Capital Release Approval (if gate passes)
- Newark Phase 1 Capital Release Approval (if gate passes) with lease/fit-out timeline
- Design-Freeze Sign-Off (if gate passes)

**Dependencies:**

- Steering Committee monthly tracking through Month 11 (2027-09-13 to 2027-09-13)
- Pilot-scale yield, stability, concordance, and COGS data validated and compiled

### 42. CEO/Founder and Chief Compliance Officer initiate Newark facility site selection and lease negotiations. Identify and visit 3-5 available spaces in Newark, California (light-industrial or life-science zoning, 2,000-3,000 sq ft, suitable for BSL-2 with biohazard-waste handling, close to I-880 and Dumbarton Bridge for logistics). Confirm zoning permits biological reagent handling and cartridge filling. Target lease execution by Month 14-15 (2028-01-13), contingent on Month 12 (2027-10-13) gate passage.

**Responsible Body/Role:** CEO/Founder (business lead) and Facilities/Operations Lead with real-estate counsel

**Suggested Timeframe:** Month 12 (2027-10-13) to Month 14 (2027-12-13 to 2027-12-13) for site selection; lease target Month 14-15 (2028-01-13)

**Key Outputs/Deliverables:**

- Newark Facility Site-Selection Summary (3-5 candidate properties evaluated, zoning confirmation)
- Lease Term Sheet (space, rent, landlord TI allowance, term, environmental/waste-handling requirements)
- Signed Lease Agreement (target Month 14-15 = 2028-01-13, contingent on Month 12 = 2027-10-13 gate)

**Dependencies:**

- Month 12 (2027-10-13) gate passes (design freeze and yield validation)
- Newark Phase 1 capital approved (USD 500-800k)
- Facilities and real-estate resources available

### 43. Operations Committee initiate clinical-study subject enrollment (target launch Month 12 = 2027-10-13). Coordinate with academic partner on recruitment, informed-consent process, sample collection (paired fingerstick and reference samples), and result reporting. Track enrollment progress monthly. Target 300-500 subjects enrolled by Month 18 (2028-04-13).

**Responsible Body/Role:** Operations Committee (Chief Compliance Officer / Regulatory Lead, Clinical-Trial Coordinator, and academic partner)

**Suggested Timeframe:** Month 12 (2027-10-13) enrollment start; target completion Month 18 (2028-04-13)

**Key Outputs/Deliverables:**

- Clinical-Study Enrollment Report (monthly updates: subjects enrolled, data quality, protocol deviations if any, adverse events)
- Subject-Enrollment Tracking Dashboard (cumulative enrollment, target vs. actual, timeline status)

**Dependencies:**

- Clinical-study protocol IRB-approved (by Month 12 = 2027-10-13)
- Clinical sites activated and staff trained
- Academic partner and LIMS systems operational

### 44. Operations Committee begin Newark Phase 1 facility fit-out (reagent formulation and pilot-scale filling lab). Contractors design and install: reagent-handling hood, refrigerated storage, liquid-handling equipment, QC instruments (potency assay, endotoxin, sterility equipment), and lot-release documentation systems. Target operational by Month 15-18 (2028-01-13 to 2028-04-13). Conduct pilot fills of Cluster 1 cartridges (1,000-5,000 units) to validate reagent formulation, fill parameters, and lot-to-lot consistency.

**Responsible Body/Role:** Operations Committee (Manufacturing Lead / Facilities Manager) with contractors and Chief Quality Officer oversight

**Suggested Timeframe:** Month 12 (2027-10-13) to Month 18 (2028-04-13 to 2028-04-13) for fit-out and pilot fills

**Key Outputs/Deliverables:**

- Newark Phase 1 Facility Design and Equipment List (fit-out scope, equipment procurement, installation timeline)
- Pilot-Fill Plan and Yield Validation (batch parameters, QC testing, lot-release criteria)
- Pilot-Fill Results (yield %, lot-to-lot CV, reagent stability at Newark conditions)

**Dependencies:**

- Month 12 (2027-10-13) gate passes and Newark Phase 1 capital approved
- Newark facility lease executed (by Month 14-15 = 2028-01-13)
- Design frozen and cartridge geometry locked (Month 15-18 = 2028-01-13 to 2028-04-13)

### 45. Chief Quality Officer conduct full ISO 13485 certification assessment and begin formal certification audit (target Month 15 = 2028-01-13). Complete corrective-action plan from earlier assessment. Ensure design controls, DHF, change-control log, management-of-change, supplier agreements, training records, and complaint/CAPA procedures are mature and documented. Obtain ISO 13485 certification by Month 18 (2028-04-13).

**Responsible Body/Role:** Chief Quality Officer (lead) with external ISO 13485 auditor/registrar

**Suggested Timeframe:** Month 15 assessment (2028-01-13); certification by Month 18 (2028-04-13)

**Key Outputs/Deliverables:**

- ISO 13485 Certification Audit Report (formal audit, findings, corrective actions)
- ISO 13485 Certificate (issued by accredited registrar, valid Months 18-21 = 2028-04-13 to 2028-07-13 and beyond)

**Dependencies:**

- Design controls and QMS fully documented (Months 2-6 = 2026-12-13 to 2027-04-13)
- Supplier agreements and management-of-change procedures implemented
- Training and competency records complete

### 46. Chief Compliance Officer complete freedom-to-operate (FTO) review and file provisional patent applications for core cartridge architecture and fluidic design. Finalize IP strategy: confirm no blocking patents from incumbents, or negotiate licenses if required. Document all findings in final FTO report and clearance opinion. File US and international provisional patents by Month 15 (2028-01-13).

**Responsible Body/Role:** Chief Compliance Officer / General Counsel (lead) with external patent counsel

**Suggested Timeframe:** Month 12 (2027-10-13) to Month 15 (2028-01-13 to 2028-01-13) for FTO finalization and provisional filings

**Key Outputs/Deliverables:**

- Final Freedom-to-Operate Report (clearance opinion, blocking patents identified or not, licenses required or not)
- Provisional Patent Applications (US and key international jurisdictions, core cartridge and fluidic designs)
- IP Strategy Summary (filing plan going forward, trade-secret protection for reagent formulations)

**Dependencies:**

- Cartridge design and fluidic innovations finalized (by Month 12 = 2027-10-13)
- Patent counsel engaged and FTO review completed (by Month 15 = 2028-01-13)

### 47. Operations Committee assess Month 12-18 (2027-10-13 to 2028-04-13) pharma revenue and lean-pivot eligibility. If pharma contracts delivered <USD 100k cumulative revenue by Month 18 (2028-04-13), or are at risk of falling below USD 100k/month run-rate, activate lean-pivot contingency: reduce headcount by 20-30% (preserve R&D, quality, and clinical/manufacturing readiness; defer Clusters 2-5 expansion planning), pause Newark full filling-line fit-out (continue only reagent lab), shift focus to CLIA lab-service revenue path (if applicable). Present lean-pivot plan and funding-gap mitigation to Steering Committee for approval.

**Responsible Body/Role:** CFO / Finance Lead (trigger assessment) and Operations Committee (execution planning)

**Suggested Timeframe:** Month 18 (2028-04-13) for pivot decision; execution Month 18-24 (2028-04-13 to 2028-10-13)

**Key Outputs/Deliverables:**

- Month 18 (2028-04-13) Pharma-Revenue Assessment (cumulative revenue vs. USD 100k target, run-rate trajectory)
- Lean-Pivot Contingency Plan (headcount reduction, spending cuts, refocus on CLIA/narrow beachhead)
- Steering Committee Lean-Pivot Approval (if triggered)

**Dependencies:**

- Pharma contracts signed and revenue tracking through Month 18 (2028-04-13)
- CFO and Operations Committee monitoring revenue monthly

### 48. Project Steering Committee hold Month 18 (2028-04-13) comprehensive design-freeze and manufacturing-readiness gate-review meeting (4-6 hours). Assess gate criteria: (1) lead-cluster (Cluster 1) design freeze complete (all design documents final, frozen, change-control locked); (2) interim clinical concordance ≥95% (lower 95% CI ≥93%) from 150-200 enrolled subjects; (3) Newark pilot fills yield ≥85% (mean, lower CI ≥80%); (4) ISO 13485 certification achieved; (5) FTO review complete (no blocking patents or licenses secured); (6) clinical-study enrollment on track (≥50% enrolled); (7) Fallback Panel V1 finalized; (8) Series A Tranches 1-2 spent, Series B fundraising commenced. Vote on gate passage. If pass, approve design freeze, release Series A Tranche 3 (USD 2-3M) or Series B (USD 3-5M), and authorize Newark Phase 2 capital release (USD 2-4M for full filling line). If fail, pause Newark Phase 2 and escalate design or clinical issues to Technical Advisory Group and Steering Committee.

**Responsible Body/Role:** Project Steering Committee (CEO, Lead Investor, CFO, Chief R&D Officer, Chief Quality Officer)

**Suggested Timeframe:** Month 18 (2028-04-13)

**Key Outputs/Deliverables:**

- Month 18 (2028-04-13) Gate-Review Meeting Minutes (design freeze status, clinical concordance data, yield results, ISO 13485 certification, FTO completion, clinical-enrollment status)
- Design-Freeze Gate Determination (pass/fail/ambiguous with numeric data and confidence intervals)
- Series A Tranche 3 or Series B Capital Release Approval (if gate passes)
- Newark Phase 2 Capital Release Approval (if gate passes): USD 2-4M for full filling line, 20% contingency USD 400-600k

**Dependencies:**

- Steering Committee monthly tracking Months 12-17 (2027-10-13 to 2028-03-13)
- Design-freeze documentation, clinical enrollment data, Newark pilot-fill results, and ISO 13485 certification compiled

### 49. Operations Committee begin Newark Phase 2 facility fit-out (full cartridge-filling line, scaled equipment). Procure long-lead filling equipment (automated cartridge filler, reagent-dispensing systems, stability chambers, QC instruments), manage installation and commissioning. Target operational by Month 24-30 (2028-10-13 to 2029-04-13). Conduct pilot runs and scale-up feasibility studies to validate full-scale manufacturing parameters (fill rate, accuracy, lot yield, consistency).

**Responsible Body/Role:** Operations Committee (Manufacturing Lead, Facilities Manager) with equipment vendors and Chief Quality Officer oversight

**Suggested Timeframe:** Month 18 (2028-04-13) to Month 30 (2029-04-13 to 2029-04-13) for Phase 2 fit-out and commissioning

**Key Outputs/Deliverables:**

- Newark Phase 2 Equipment Procurement List (long-lead filling machine, dispensing systems, QC instruments, lead times, pricing)
- Equipment Installation and Commissioning Plan (timeline, vendor support, validation testing)
- Scale-Up Feasibility Study Results (full-scale pilot fills, yield validation, process capability study)

**Dependencies:**

- Month 18 (2028-04-13) gate passes and Newark Phase 2 capital approved
- Newark Phase 1 operational (Month 15-18 = 2028-01-13 to 2028-04-13)
- Design frozen and cartridge geometry locked

### 50. Operations Committee initiate development of electronic laboratory information-management system (LIMS) and integrated data-management platform for clinical studies, cartridge lot tracking, stability-testing results, and regulatory submissions. Ensure eCRF (electronic case report form) and result-reporting workflows are operational for clinical study by Month 18 (2028-04-13) and production lot-release by Month 24 (2028-10-13).

**Responsible Body/Role:** Operations Committee (IT/Data Systems Lead, Clinical-Trial Coordinator, Chief Quality Officer) with LIMS vendor

**Suggested Timeframe:** Month 12 (2027-10-13) to Month 24 (2028-10-13 to 2028-10-13) for LIMS development and integration

**Key Outputs/Deliverables:**

- LIMS Platform Selection and Vendor Engagement (software choice, data-integration scope)
- eCRF Design and Validation (for clinical study, workflow design, data validation rules)
- Lot-Release Module Configuration (cartridge lot tracking, stability results, release sign-off)
- LIMS Operational Validation (user-acceptance testing, data integrity audit, staff training)

**Dependencies:**

- Clinical study protocol finalized (Month 9 = 2027-07-13)
- IT and data-systems resources in place

### 51. Chief Compliance Officer publish monthly Analyte Performance Dashboard and initiate quarterly Transparency Report for board and investors. Dashboard includes: per-analyte concordance, CV, shelf-life projection, cross-reactivity results, yield, status (In Progress/Pass/Fail/Retired), and cumulative menu count toward 500 analytes. Transparency Report summarizes project progress vs. gates, milestones achieved/missed, technical risks, funding status, and regulatory pathway. Avoid '500 tests' claims; use 'expanding menu' or 'cumulative portfolio' language.

**Responsible Body/Role:** Chief Compliance Officer (lead) with Chief R&D Officer and Operations Committee

**Suggested Timeframe:** Starting Month 6 (2027-04-13); monthly dashboard live by Month 6 (2027-04-13), quarterly reports starting Month 6 (2027-04-13)

**Key Outputs/Deliverables:**

- Monthly Analyte Performance Dashboard (shared with board, investors, advisory board)
- Quarterly Transparency Report (project milestones, gate results, risk updates, regulatory status, financial runway)
- No '500 Tests' Marketing Rule Enforcement (audit all communications for compliance)

**Dependencies:**

- Analyte Performance Report template created and populated
- Chief Compliance Officer and communications team in place

### 52. Technical Advisory Group conduct formal shelf-life and stability assessment at Month 12 (2027-10-13). Review real-time (9 months) and accelerated-stability data; validate Arrhenius modeling assumptions; confirm projected 12-month shelf-life (or adjust if projection is 9-12 months, requiring retest at Month 15 = 2028-01-13). Issue Technical Advisory report to Steering Committee on shelf-life confidence.

**Responsible Body/Role:** Technical Advisory Group (external stability/formulation expert) with Chief R&D Officer and Assay Chemistry Lead

**Suggested Timeframe:** Month 12 (2027-10-13)

**Key Outputs/Deliverables:**

- Shelf-Life and Stability Assessment Report (Arrhenius modeling, confidence intervals, pass/fail per analyte)

**Dependencies:**

- Real-time and accelerated-stability data from Months 3-12 (2027-01-13 to 2027-10-13)
- Technical Advisory Group in place

### 53. Operations Committee and Chief R&D Officer coordinate preparation of 510(k) or De Novo submission package (target submission Month 30 = 2029-04-13). Compile: (1) clinical-study data and analytical performance (concordance, CV, sensitivity, specificity); (2) design documentation (cartridge design, manufacturing process, quality controls); (3) risk analysis (ISO 14971); (4) software documentation (IEC 62304); (5) shelf-life and stability data; (6) biocompatibility assessment if needed. Engage regulatory consultant to review submission package and prepare for FDA interaction.

**Responsible Body/Role:** Operations Committee (Chief Quality Officer / Regulatory Lead, Chief R&D Officer) with regulatory consultant

**Suggested Timeframe:** Month 18 (2028-04-13) to Month 30 (2029-04-13 to 2029-04-13) for submission package preparation; filing target Month 30 (2029-04-13)

**Key Outputs/Deliverables:**

- 510(k) or De Novo Submission Package (complete as per FDA guidance, ready for submission)
- Submission Strategy Memo (510(k) pathway with predicate or De Novo pathway and justification)
- FDA Submission (filed Month 30 = 2029-04-13; expected decision Months 36-42 = 2029-10-13 to 2030-04-13 for 510(k); Months 42-48 = 2030-04-13 to 2030-10-13 for De Novo)

**Dependencies:**

- Clinical-study data analysis and statistical review complete (by Month 24 = 2028-10-13)
- Design controls, risk analysis, and software documentation finalized
- Regulatory consultant engaged

### 54. Compliance, Ethics and Risk Management Committee conduct mock FDA pre-approval inspection (conducted by external regulatory consultant or firm) at Months 28-30 (2029-02-13 to 2029-04-13), 2-4 months before expected FDA pre-approval inspection. Assess: design history file completeness, change-control log, risk-management file, management-of-change documentation, supplier agreements, training records, complaint handling, and regulatory documentation. Generate inspection report with 483-observation-level findings and corrective actions. Close gaps before real FDA inspection.

**Responsible Body/Role:** Compliance, Ethics and Risk Management Committee (Chief Compliance Officer, Chief Quality Officer) with external regulatory consultant

**Suggested Timeframe:** Months 28-30 (2029-02-13 to 2029-04-13)

**Key Outputs/Deliverables:**

- Mock FDA Inspection Report (findings, 483-observation-level gaps, corrective-action plan)
- Corrective-Action Plan and Close-Out (gaps remediated before real inspection, documentation of corrections)

**Dependencies:**

- Design controls and QMS mature and documented (Months 2-18 = 2026-12-13 to 2028-04-13)
- ISO 13485 certification achieved (by Month 18 = 2028-04-13)

### 55. Project Steering Committee hold quarterly gate-tracking meetings (Months 1-35 = 2026-11-13 to 2029-09-13, in addition to formal gate reviews at Months 6, 12, 18 = 2027-04-13, 2027-10-13, 2028-04-13). Review: monthly Analyte Performance Report, cash burn vs. budget, regulatory milestone status (FDA Pre-Sub feedback, ISO 13485 progress, submission package status), pharma/grant revenue, supplier scorecard, clinical-enrollment progress, and risk-register updates. Document decisions and capital-release approvals. Escalate any miss-make-vs-forecast variances or unplanned risk events within 1 week.

**Responsible Body/Role:** Project Steering Committee (CEO, Lead Investor, CFO, Chief R&D Officer, Chief Quality Officer)

**Suggested Timeframe:** Monthly, Months 1-35 (2026-11-13 to 2029-09-13), in addition to formal gate reviews (Months 6, 12, 18, 24 = 2027-04-13, 2027-10-13, 2028-04-13, 2028-10-13)

**Key Outputs/Deliverables:**

- Monthly Steering Committee Meeting Minutes (analytics, cash, regulatory, clinical, supplier, risk status)
- Quarterly Analyte Performance Dashboard Update (shared with investors and board)

**Dependencies:**

- Steering Committee established and operational (Month 0.5 = 2026-10-28)
- Operations Committee and Technical Advisory Group providing monthly data and reports

### 56. Operations Committee finalize Cluster 2-5 planning and roadmap (Months 12-24 = 2027-10-13 to 2028-10-13) for post-launch expansion. Define each cluster's clinical use case (e.g., oncology, rare disease, metabolic), analyte selection (50 analytes per cluster), development timeline (6-9 months per cluster after Cluster 1 clearance), and regulatory strategy (separate 510(k) or De Novo per cluster, or combined submission). Present expansion roadmap to Steering Committee for funding and resource planning.

**Responsible Body/Role:** Operations Committee (Chief R&D Officer, Chief Product Officer or Product Lead) with Steering Committee oversight

**Suggested Timeframe:** Months 12-24 (2027-10-13 to 2028-10-13) for cluster planning and roadmap definition

**Key Outputs/Deliverables:**

- Cluster 2-5 Expansion Roadmap (clinical use cases, analyte lists, development timelines, regulatory strategy, estimated cost and revenue per cluster)

**Dependencies:**

- Cluster 1 design frozen (Month 18 = 2028-04-13)
- Clinical-study and analytical-feasibility experience from Cluster 1 informs planning

### 57. CEO/Founder and CFO finalize Series B fundraising (target Month 18-24 = 2028-04-13 to 2028-10-13). Close Series B round (USD 3-5M proposed) by Month 24 (2028-10-13) to fund Months 24-48 (2028-10-13 to 2030-10-13) runway through FDA clearance and commercial launch. Use gate results, clinical data, and Newark readiness as fundraising proof points. If lean-pivot is triggered (Month 18 = 2028-04-13 pharma revenue <USD 100k/month), adjust Series B size and messaging to reflect narrower beachhead or CLIA-first strategy.

**Responsible Body/Role:** CEO/Founder (investor relations) and CFO (financial planning)

**Suggested Timeframe:** Month 18 (2028-04-13) to Month 24 (2028-10-13 to 2028-10-13) for Series B close

**Key Outputs/Deliverables:**

- Series B Pitch Deck (updated with Cluster 1 clinical data, manufacturing validation, regulatory progress)
- Series B Financing Agreement (investor terms, governance rights, board seat, liquidation preferences)
- Series B Capital in Bank (USD 3-5M received by Month 24 = 2028-10-13)

**Dependencies:**

- Month 12 (2027-10-13) and Month 18 (2028-04-13) gates pass and data demonstrates technical progress
- Clinical-enrollment and regulatory-pathway progress documented

### 58. Operations Committee hold Month 24 (2028-10-13) quarterly gate-tracking meeting to assess progress toward FDA submission (target Month 30 = 2029-04-13). Review: clinical-study analysis completion (target Month 24 = 2028-10-13), submission-package preparation status, regulatory-consultant engagement, and any FDA Q-Submission or Pre-Sub follow-up needed. Confirm submission target remains Month 30 (2029-04-13) or escalate any delays.

**Responsible Body/Role:** Operations Committee (Chief Quality Officer / Regulatory Lead, Chief R&D Officer)

**Suggested Timeframe:** Month 24 (2028-10-13)

**Key Outputs/Deliverables:**

- Clinical-Study Analysis Report (all analytes, concordance, CV, sensitivity/specificity per analyte, statistical summary)
- Submission-Package Status Report (draft/near-final status, expected completion date Month 28-30 = 2029-02-13 to 2029-04-13)

**Dependencies:**

- Clinical-study enrollment complete (by Month 24 = 2028-10-13)
- Data analysis in progress (Months 18-24 = 2028-04-13 to 2028-10-13)

### 59. Chief R&D Officer and Operations Committee finalize full-scale manufacturing readiness (target Month 30 = 2029-04-13). Validate: cartridge yield ≥85% at 10k+ cartridges/month scale; reagent lot-to-lot CV <10%; shelf-life stable through planned distribution; fill-line throughput ≥90% of design capacity; equipment reliability and maintainability demonstrated over 4-12 week pilot campaign. Prepare for commercial manufacturing ramp-up post-clearance.

**Responsible Body/Role:** Operations Committee (Manufacturing Lead, Chief Quality Officer) with contract-molder partners

**Suggested Timeframe:** Months 24-30 (2028-10-13 to 2029-04-13) for manufacturing scale-up validation

**Key Outputs/Deliverables:**

- Manufacturing Scale-Up Validation Report (yield, CV, shelf-life, throughput, reliability data)
- Commercial Manufacturing Plan (post-clearance ramp-up from 10k to 50k cartridges/month, timeline, staffing, quality controls)

**Dependencies:**

- Newark Phase 2 filling line operational (by Month 24-30 = 2028-10-13 to 2029-04-13)
- Cluster 1 design frozen and validated at scale (Month 18 = 2028-04-13)

### 60. Chief Compliance Officer finalize payer-coverage and reimbursement strategy. Conduct payer-coverage landscape analysis identifying CPT codes, coverage policies, and economics for Cluster 1 analytes. Initiate pre-launch payer discussions with 2-3 major payers (Medicare, Aetna, Anthem) presenting clinical-utility evidence and economic models. Develop tiered pricing and bundling strategy. Target payer-coverage pathways identified by Month 36 (2029-10-13), ready for implementation post-clearance.

**Responsible Body/Role:** Chief Compliance Officer / Regulatory Lead (lead) with Chief R&D Officer and Finance Lead

**Suggested Timeframe:** Months 24-36 (2028-10-13 to 2029-10-13) for payer engagement and coverage planning

**Key Outputs/Deliverables:**

- Payer-Coverage Landscape Analysis (CPT codes, coverage policies, reimbursement rates for Cluster 1 analytes)
- Payer Pre-Launch Engagement Summary (discussions with 2-3 major payers, preliminary coverage feedback)
- Pricing and Bundling Strategy (tiered approach, expected per-run revenue, margin implications)

**Dependencies:**

- Clinical-study data available to support coverage discussions (by Month 24 = 2028-10-13)
- Regulatory pathway confirmed (510(k) vs. De Novo)

### 61. FDA review and issue decision on 510(k) or De Novo submission (target decision Months 36-48 = 2029-10-13 to 2030-10-13, depending on submission type and FDA responsiveness). 510(k) typically reviews in 6-12 months; De Novo in 12-18 months. Engage with FDA on any deficiencies, requests for additional data, or labeling negotiations. Plan for 1-2 rounds of FDA Q-Submissions or supplemental submissions if needed.

**Responsible Body/Role:** Chief Quality Officer / Regulatory Lead (lead) with regulatory consultant and Chief R&D Officer

**Suggested Timeframe:** FDA review Months 30-48 (2029-04-13 to 2030-10-13); decision expected Months 36-48 (2029-10-13 to 2030-10-13)

**Key Outputs/Deliverables:**

- FDA Submission Acknowledgment and Review Clock Start (received Month 30 = 2029-04-13)
- FDA Deficiency Letter or Q-Submission Requests (if any, expected Month 36-42 = 2029-10-13 to 2030-04-13)
- Responses to FDA Deficiencies (prepared and submitted within 30-60 days of FDA request)
- FDA Clearance/Approval Letter (received Months 36-48 = 2029-10-13 to 2030-10-13)

**Dependencies:**

- 510(k) or De Novo submission filed Month 30 (2029-04-13)
- Quality system and design controls mature (ISO 13485 certified by Month 18 = 2028-04-13)

### 62. Operations Committee prepare post-clearance commercial launch plan. Define: manufacturing scale-up (ramp from 10k to 50k cartridges/month over Months 48-72 = 2030-10-13 to 2032-10-13), sales-channel activation (direct to reference labs, point-of-care clinics, or pharmacy partnerships), clinical-site and payer onboarding, training for operators and support staff, cold-chain logistics setup, and customer-support infrastructure. Target commercial launch by Month 48 (2030-10-13).

**Responsible Body/Role:** Operations Committee (Chief R&D Officer, Manufacturing Lead, Chief Quality Officer) with Commercial/Sales Lead

**Suggested Timeframe:** Months 36-48 (2029-10-13 to 2030-10-13) for launch-plan finalization

**Key Outputs/Deliverables:**

- Post-Clearance Commercial Launch Plan (manufacturing scale-up, sales channels, training, support, timeline)
- First Commercial Cartridge Shipment Plan (date, volume, customer sites, fulfillment logistics)

**Dependencies:**

- FDA clearance received (expected Months 36-48 = 2029-10-13 to 2030-10-13)
- Manufacturing scale-up validation complete (by Month 30 = 2029-04-13)

### 63. Project Steering Committee oversee Cluster 1 commercial launch and Cluster 2 development initiation (Months 48-72 = 2030-10-13 to 2032-10-13). Monitor: first-year revenue, operational yield and quality metrics, payer-coverage uptake, clinical adoption, and regulatory/pharmacovigilance performance. Manage Cluster 2 development timeline and gate-linked capital releases. Track expansion toward the 500-analyte cumulative menu (estimated 10 clusters of 50 analytes each, which would require Months 48-120 = 2030-10-13 to 2036-10-13 if clusters clear sequentially at 6-9 months post-launch). Communicate progress and re-planning to investors.

**Responsible Body/Role:** Project Steering Committee (CEO, Lead Investor, CFO, Chief R&D Officer, Chief Quality Officer) with Commercial/Operations team

**Suggested Timeframe:** Months 48-72 (2030-10-13 to 2032-10-13) and beyond for ongoing governance

**Key Outputs/Deliverables:**

- Monthly Commercial Operations Reports (revenue, units shipped, yield, quality metrics, customer feedback, adoption trends)
- Cluster 2 Development Progress Reports (analyte selection, clinical study planning, regulatory strategy, funding status)
- Expansion Roadmap Updates (revised timelines for Clusters 3-10, adjusted for market demand and technical learnings)

**Dependencies:**

- Cluster 1 FDA clearance and commercial launch complete (Month 48 = 2030-10-13)
- Series B and Series C/D funding in place for Cluster 2+ development

# Decision Escalation Matrix

**Budget or Capital Expenditure Exceeding Project Steering Committee Authorization Limit**
Escalation Level: Investor Board or Lead Investor
Approval Process: Lead Investor reviews the capital request, convenes board vote if required by equity agreements, and approves or denies capital tranche release. Decision documented in board minutes with financial justification and impact on timeline/scope.
Rationale: Gate-linked capital tranches (Seed, Series A Tranches 1-3, Series B, Series C) require board-level approval to release funds beyond Operations Committee authority (USD 500k ceiling). Unbudgeted capital requests (e.g., emergency supplier surcharge, equipment overrun >20%, unexpected regulatory consulting) that exceed monthly gate-allocated burn require investor approval to preserve cash discipline and avoid uncontrolled spend.
Negative Consequences: Uncontrolled capital spend beyond gate budgets consumes runway prematurely, forces unplanned fundraising rounds at adverse valuation, delays development by 2-4 months due to funding gaps, or triggers forced lean pivot earlier than planned, stranding previous investments and demoralizing the team.

**Technical Gate Failure or Ambiguous Gate Results Requiring Fallback Panel V1 Retreat Decision**
Escalation Level: Project Steering Committee with Technical Advisory Group Assessment
Approval Process: Operations Committee prepares gate data (yield, concordance, CV, shelf-life). Technical Advisory Group validates results within 3 business days. Steering Committee holds emergency gate-review meeting (within 1 week of gate miss) and votes on: (1) retest/redesign plan with 4-week extension, or (2) activate Fallback Panel V1 (50 analytes, immediate). Board approval required if retreat impacts Series A/B commitments or extends timeline >6 months.
Rationale: Analytical-feasibility gates (plasma separation ≥95% at Month 6 = 2027-04-13; yield ≥85% at Month 12 = 2027-10-13; shelf-life ≥12 months projected; concordance ≥95%) are the primary technical checkpoints. A miss (yield 80-85%, shelf-life 8-11 months, concordance 93-95%) triggers ambiguity requiring Technical Advisory Group validation and Steering Committee judgment on pursue-vs-retreat. Fallback V1 retreat is a strategic decision affecting product scope, revenue potential, and funder expectations.
Negative Consequences: Delayed or absent gate decision creates sunk-cost escalation: unrealistic hope prolongs spending on unviable design, consumes USD 3-10M in unrecovered capital, extends pre-revenue runway to Months 54-72 (2031-04-13 to 2032-10-13), and may result in product with insufficient market validation or manufacturability, causing late-stage failure at Months 36-48 (2029-10-13 to 2030-10-13) pre-approval inspection.

**Scope Retreat Decision: Fallback Panel V1 Analyte Removal or Menu Narrowing Below 50 Analytes**
Escalation Level: Project Steering Committee with Chief Compliance Officer and CEO to Investor Board
Approval Process: Chief Compliance Officer / Regulatory Lead documents FDA feedback (Pre-Submission response, Q-Submission answer, or deficiency letter). Operations Committee and Technical Advisory Group assess impact on design, clinical study, and timeline. Steering Committee votes on response (e.g., additional clinical sites, expanded sample size, new biocompatibility testing, shelf-life retest). If impact exceeds USD 2M or 6 months, escalate to investor board with two options: (1) absorb cost and timeline, or (2) narrow Fallback V1 scope to accelerate path.
Rationale: FDA pathway (510(k) vs. De Novo) determines evidence burden and timeline. Pre-Submission feedback is advisory; FDA may later require different evidence in actual submission. De Novo requirement (instead of 510(k)) adds 12-18 months and USD 2-4M. Major protocol amendment (e.g., FDA requests outcomes study vs. method-comparison) extends clinical timeline by 6-12 months. These changes cascade to funding need, investor expectations, and competitive positioning, requiring top-level decision.
Negative Consequences: Unaddressed regulatory-pathway uncertainty results in developing wrong evidence package, forcing redesign or re-study at Months 30-36 (2029-04-13 to 2029-10-13), adding 6-18 months and USD 2-4M to clearance timeline. If discovery occurs post-Phase 1 submission (Month 30 = 2029-04-13), FDA deficiency response adds 3-6 months. Investor funding gap widens by USD 5-15M; Series B/C timing slips; competitive entry risk increases.

**Design Change, Analyte Removal, or Product-Scope Modification Affecting Fallback Panel V1 Definition or Cluster Roadmap**
Escalation Level: Project Steering Committee (if ≥10% of Fallback V1 affected or >USD 500k cost); Investor Board (if >25% of menu affected or strategic retreat)
Approval Process: Operations Committee documents the design change, analyte failure, or scope request. Technical Advisory Group assesses feasibility impact. If change is <USD 50k and <2 weeks timeline, Operations Committee approves and reports to Steering Committee monthly. If change ≥USD 50k or ≥2 weeks impact, Steering Committee votes within 1 week. If ≥10% of Fallback V1 or ambiguous clinical impact, Steering Committee escalates to investor board with risk assessment and revised product definition.
Rationale: Fallback Panel V1 is the guaranteed product and funder commitment. Removing analytes or narrowing menu scope changes product differentiation, revenue potential, and investor return. Design changes after Month 6 (2027-04-13) lock in cost and manufacturing decisions; changes to fluidic geometry, reagent volumes, or cartridge footprint after mold ordering (expected Month 6-9 = 2027-04-13 to 2027-07-13) trigger re-tooling cost (USD 50-150k, 3-4 months). Scope creep (adding analytes) delays design freeze and manufacturing readiness.
Negative Consequences: Uncontrolled design changes delay design freeze from Month 18 (2028-04-13) to Month 24-30 (2028-10-13 to 2029-04-13), pushing clinical study and FDA submission 6-12 months. Re-tooling molds and equipment adds USD 50-200k and 4-8 weeks. Product scope uncertainty erodes investor confidence in Series B/C fundraising. Analyte removals (e.g., due to cross-reactivity or sensitivity failure) not escalated to Steering Committee can silently degrade product and credibility (e.g., delivering 35-analyte menu instead of 50, surprising customers post-launch).

**Funding Gap, Unexpected Burn, or Pharma Revenue Shortfall Threatening Runway Beyond 6 Months**
Escalation Level: Project Steering Committee to Investor Board and CEO
Approval Process: CFO / Finance Lead reports monthly cash burn vs. budget and forecasts runway. If variance exceeds 10% of monthly burn or cumulative gap >6 months of operations, Steering Committee is notified within 1 week. If gap cannot be closed by spending cuts or pharma acceleration, CEO and Steering Committee convene emergency board meeting (within 2 weeks) to approve contingency: (1) lean-pivot activation (20-30% headcount reduction, pause Newark Phase 2, focus on CLIA fallback or narrow beachhead), (2) bridge financing (debt or down-round equity), or (3) partnership/acquisition discussions.
Rationale: Pharma revenue is contingent on sponsor commitments and is inherently uncertain. Non-dilutive funding (grants) is variable and timing-dependent. Equipment lead times and cost overruns are common. Funding gaps at Months 12-18 (2027-10-13 to 2028-04-13) or Months 24-30 (2028-10-13 to 2029-04-13) are high-probability risks given the lean-pivot trigger (pharma <USD 100k/month at Month 18 = 2028-04-13). Early warning and board-level escalation preserves optionality (lean pivot, partnership) vs. forced crisis-mode decisions.
Negative Consequences: Funding shortfall discovered at Month 18 (2028-04-13) with only 2-3 months runway forces emergency bridge financing at 40-60% valuation discount, diluting Series A and founder shares by 10-20%. Missed payroll or unplanned headcount cuts destabilize team and cause key-person departures (2-3 month productivity loss). Delayed Newark Phase 2 equipment orders miss 6-month lead times, pushing manufacturing readiness to Months 30-36 (2029-04-13 to 2029-10-13) and FDA submission to Months 36-42 (2029-10-13 to 2030-04-13), compressing pre-clearance window and increasing competitive risk.

**Critical Supplier Failure, Quality Defect, or Single-Source Dependency Crisis (Defect Rate >10% or Delivery Failure >2 Weeks)**
Escalation Level: Operations Committee to Project Steering Committee (if duration >4 weeks or recovery cost >USD 100k)
Approval Process: Procurement Lead and Quality Scorecard Owner flag supplier defect rate >10% or delivery delay >2 weeks within 1 week of discovery. Operations Committee votes to activate backup supplier (within 2-week window if pre-qualified). If backup activation costs >USD 100k, requires USD 500k+ authority check-in with Steering Committee within 5 business days. If supplier failure affects clinical-study or FDA-submission timeline by >2 weeks, escalate to Steering Committee for risk mitigation approval (expedited re-qualification, alternative material sourcing, design pivot).
Rationale: Contract molders, reagent suppliers, and logistics partners are external dependencies. Yield loss due to molder defects, reagent lot failures due to supplier quality drift, and logistics delays all directly impact cartridge availability, clinical-study enrollment, and regulatory-submission timeline. Single-source suppliers (identified during supply-chain risk assessment at Month 4 = 2027-02-13) without dual-source qualification expose the program to 4-8 week production halts if primary supplier fails.
Negative Consequences: Unaddressed supplier defect discovered at Month 12-15 (2027-10-13 to 2028-01-13) during pilot fills delays cartridge availability for clinical study by 4-8 weeks, compressing enrollment window from 6 to 2-3 months and reducing statistical power. Reagent supplier discontinuation or price shock at Months 18-24 (2028-04-13 to 2028-10-13) forces re-qualification of alternative supplier (4-8 weeks) and potential re-validation of assay (USD 100-300k, 4-8 weeks), pushing clinical-study close-out to Month 30 (2029-04-13) and FDA submission to Months 36-42 (2029-10-13 to 2030-04-13). Logistics failure (cold-chain outage) during clinical distribution spoils cartridge lots (USD 50-150k loss, 2-4 week replacement delay).

**Reputational or Compliance Risk: Over-Claiming, Data Integrity Violation, Conflict-of-Interest Disclosure, or Regulatory Non-Compliance Discovery**
Escalation Level: Chief Compliance Officer and Compliance, Ethics and Risk Management Committee to Investor Board and Legal Counsel
Approval Process: Chief Compliance Officer investigates allegation within 48 hours. If substantiated (e.g., '500 tests per drop' claim made prematurely, analyte data selectively excluded from Analyte Performance Report, conflict of interest undisclosed), compliance committee convenes within 1 week. Response options: (1) public corrective statement and remediation plan, (2) internal investigation and disciplinary action, (3) notification to FDA or relevant regulator, (4) legal review and liability assessment. Board is notified immediately if issue impacts regulatory submissions, investor communications, or company valuation >5%.
Rationale: Diagnostics industry credibility is built on transparent, accurate data and regulatory compliance. Historical context of failed single-drop claims creates reputational vulnerability. Over-claiming (e.g., 500 tests before validation), selective data reporting (publishing only passing analytes, hiding failures), or regulatory breaches (false statements in FDA submissions) are high-severity risks with potential FDA enforcement (warning letter, import detention, criminal referral) and investor confidence loss. Undisclosed conflicts of interest (e.g., board member has equity in supplier) create legal liability.
Negative Consequences: Discovered over-claim at Month 12-18 (2027-10-13 to 2028-04-13) results in corrective media statement, Series A/B fundraising delay or valuation haircut 20-50%, FDA warning letter or submission rejection adding 6-12 months and USD 2-4M to remediation. Data-integrity violation (e.g., analyte failure data omitted from FDA submission) discovered at pre-approval inspection triggers 483 observations, delays clearance 3-6 months, and exposes company to FDA enforcement action or OIG investigation. Undisclosed conflict of interest triggers board-level restructuring and potential fiduciary-duty litigation against founders/early investors.

# Monitoring Progress

### 1. Analytical Feasibility and Assay Performance Tracking (Gate Criteria Monitoring)
**Monitoring Tools/Platforms:**

  - Analyte Performance Report (monthly spreadsheet/dashboard: concordance, CV, shelf-life projection, yield, status per analyte)
  - Analyte Review Meeting Minutes (monthly assessment of pass/fail/redesign/retire decisions)
  - Cross-Reactivity Screening Data (Month 4-6 = 2027-02-13 to 2027-04-13 experimental results)
  - Pilot Yield and Lot-Consistency Records (first-article run Month 12 = 2027-10-13 data)
  - Stability Testing Database (real-time and accelerated-stability results, Arrhenius projections)

**Frequency:** Monthly Analyte Review Meetings (Months 3-12 = 2027-01-13 to 2027-10-13, then quarterly). Formal gate assessments at Months 6, 12, 18 (2027-04-13, 2027-10-13, 2028-04-13). Technical Advisory Group validation of gate results within 3 business days before Steering Committee vote.

**Responsible Role:** Operations Committee (Chief R&D Officer, Assay Chemistry Lead, Chief Quality Officer) owns monthly tracking. Technical Advisory Group (external microfluidics, immunoassay, manufacturing experts) validates analytical feasibility and manufacturing-yield assessments. Steering Committee votes on gate passage.

**Adaptation Process:** Monthly Analyte Review identifies analyte failures (concordance <95%, CV >10%, shelf-life <9 months projected). Decision logic: if threshold miss, Operations Committee decides within 2 weeks whether to (a) redesign and retest within 4-8 weeks, (b) retire analyte from panel and update Fallback Panel V1 roster, or (c) defer to Cluster 2. Retired analytes are documented in Analyte Performance Report with root-cause analysis, visible to board and FDA. If ≥10% of Cluster 1 analytes require retirement or major redesign, escalate to Steering Committee for scope impact and gate-delay assessment. Formal gate failures (e.g., pilot yield <80% at Month 12 = 2027-10-13) trigger 4-week design-review cycle; if unresolved by Month 15 (2028-01-13), Steering Committee votes to activate Fallback Panel V1 (50-analyte core) or pursue extended redesign with capital reallocation.

**Adaptation Trigger:** Month 6 (2027-04-13) gate: plasma separation ≥95% yield from ≥100 fingerstick subjects with ≥1.6 µL usable plasma, hemolysis index <50; cross-reactivity ≤5% bias at 10× interferent; COGS ceiling USD 25/cartridge locked (proposed threshold). Month 12 (2027-10-13) analytical feasibility gate: pilot-scale yield ≥85% (mean, lower 95% CI ≥80%), lot-to-lot CV <10%, shelf-life ≥12 months projected (Arrhenius R² >0.90), analytical concordance ≥95% from preliminary clinical data (100-150 samples); modeled COGS ≤USD 25 (proposed threshold). Month 18 (2028-04-13) design-freeze gate: lead-cluster design locked, interim clinical concordance ≥95% (lower CI ≥93%, 150-200 enrolled subjects), Newark pilot fills yield ≥85%, ISO 13485 certified (proposed threshold). Any analyte failing monthly thresholds for 2+ months → retire/redesign decision. Yield or concordance miss at gate → retest plan (2-3 week escalation) or Fallback V1 retreat (Steering Committee vote).

### 2. Capital Tranche Release and Budget Variance Monitoring
**Monitoring Tools/Platforms:**

  - 60-Month Cash-Flow Model (Months 0-60 = 2026-10-13 to 2031-10-13 with quarterly burn rates and gate-linked tranche schedule)
  - Monthly Cash Burn Report (actual spend vs. budgeted by project phase: R&D, Newark, clinical, regulatory, G&A)
  - Pharma Contract and Grant Revenue Tracking (signed contracts, revenue received, pipeline status)
  - Capital Tranche Release Log (Seed, Series A Tranches 1-3, Series B; dates, amounts, gate thresholds, board approvals)

**Frequency:** Monthly cash-burn tracking and variance reporting (actuals vs. forecast ±10% variance flag). Gate-linked capital releases voted at Months 6, 12, 18, 24 (2027-04-13, 2027-10-13, 2028-04-13, 2028-10-13). Emergency Steering Committee meeting within 1 week if cumulative variance >10% monthly burn or runway gap >6 months.

**Responsible Role:** CFO / Finance Lead owns monthly cash-flow reporting and variance analysis. Steering Committee approves each capital-tranche release before funds are drawn (pass/fail/defer vote tied to gate criteria). If funding gap emerges >6 months, CEO escalates to investor board for lean-pivot approval or bridge-financing decision within 2 weeks.

**Adaptation Process:** Monthly cash-burn report compared to gate-linked budget (Seed USD 2-3M Months 0-6 = 2026-10-13 to 2027-04-13; Series A Tranche 1 USD 3-4M at Month 6 = 2027-04-13 gate; etc.). If actuals exceed monthly budget by >15%, Finance Lead investigates variance and proposes corrective action (spending cuts, project re-scoping, accelerated revenue) to Steering Committee within 5 business days. If cumulative variance indicates cash runway <6 months, CFO convenes emergency Steering Committee within 1 week. Options voted: (a) accelerate fundraising (bridge round, Series B pull-forward), (b) activate lean-pivot contingency (20-30% headcount reduction, pause Newark Phase 2, refocus on CLIA or narrow beachhead), or (c) seek strategic partnership/acquisition. Pharma-revenue shortfall (cumulative <USD 500k by Month 18 = 2028-04-13, or run-rate <USD 100k/month by Month 18 = 2028-04-13) automatically triggers lean-pivot review within 2 weeks per pre-agreed threshold.

**Adaptation Trigger:** Cumulative burn exceeds gate-linked budget by >15% (or USD 500k cumulative variance) for any month. Pharma/grant revenue below USD 1-2M cumulative target by Month 12 (2027-10-13), or <USD 100k/month run-rate at Month 18 (2028-04-13) → lean-pivot eligible (proposed threshold). Runway forecast <6 months at any month → emergency funding decision required (Steering Committee escalation, investor board vote within 2 weeks). Series A or B tranche gate fails (e.g., Month 12 = 2027-10-13 analytical feasibility not met) → capital release is withheld; Operations Committee has 4 weeks to retest/redesign, or Fallback V1 is activated and capital is reallocated to narrower scope.

### 3. Regulatory Pathway Alignment and FDA Pre-Submission Feedback Monitoring
**Monitoring Tools/Platforms:**

  - FDA Pre-Submission Meeting Minutes and Agency Feedback Summary (Month 6 = 2027-04-13 expected)
  - Regulatory Roadmap Document (510(k) vs. De Novo assessment, evidence requirements, submission timeline)
  - ISO 13485 and Design-Control Compliance Checklist (design controls, DHF completeness, management of change, supplier agreements, training records)
  - Quality-System Audit Reports (internal ISO 13485 assessment Month 15 = 2028-01-13, certification audit Month 18 = 2028-04-13)
  - IEC 62304 Software Development Lifecycle Documentation (requirements, design, testing, version control)

**Frequency:** Pre-Submission meeting held Month 6 (2027-04-13); FDA feedback documented and disseminated within 2 weeks. ISO 13485 compliance assessed at Month 15 (2028-01-13); formal certification audit Month 18 (2028-04-13); ongoing compliance audits quarterly thereafter. Mock FDA pre-approval inspection Months 28-30 (2029-02-13 to 2029-04-13). Regulatory roadmap reviewed and confirmed by Steering Committee at Months 12, 18 (2027-10-13, 2028-04-13).

**Responsible Role:** Chief Quality Officer / Regulatory Lead owns regulatory-pathway strategy and quality-system readiness. Chief Compliance Officer oversees Pre-Submission preparation and FDA communication. External regulatory consultant (retained Months 0-6 = 2026-10-13 to 2027-04-13, budget USD 50-100k) supports Pre-Sub meeting and submission package preparation. Technical Advisory Group reviews regulatory evidence adequacy (study design, sample-size calculations, analytical acceptance criteria) at Month 18 (2028-04-13).

**Adaptation Process:** FDA Pre-Submission feedback (Month 6 = 2027-04-13) is reviewed by Steering Committee within 1 week; if pathway changes from 510(k) expected to De Novo likely (adding 12-18 months and USD 2-4M), Steering Committee votes on: (a) proceed with De Novo evidence package and extend funding model, or (b) narrow product scope to de-risk De Novo or pursue Fallback V1 + CLIA lab-service route. If FDA indicates additional clinical or analytical evidence needed, Operations Committee assesses impact on clinical-study protocol, timeline, and cost; if impact >USD 2M or >6 months, escalate to Steering Committee and investor board for funding/scope decision. ISO 13485 compliance gaps identified at Month 15 (2028-01-13) assessment are incorporated into corrective-action plan due by Month 18 (2028-04-13); if major gaps remain unclosed (design-control deficiency, supplier-agreement gaps, complaint-handling procedures), design freeze is delayed and Steering Committee is notified of inspection-readiness risk. Mock FDA inspection (Months 28-30 = 2029-02-13 to 2029-04-13) findings are tracked; 483-level observations must be closed within 2-4 weeks before real pre-approval inspection. Any FDA Q-Submission or deficiency letter post-submission (expected Months 36-42 = 2029-10-13 to 2030-04-13) is escalated to Steering Committee within 3 business days with recommended response and timeline.

**Adaptation Trigger:** FDA Pre-Submission feedback indicates De Novo pathway is likely (vs. 510(k) assumed) → Steering Committee decision within 1 week: continue De Novo (budget/timeline impact = +12-18 months, +USD 2-4M) or pivot to narrower scope/fallback. Major regulatory evidence gap identified (e.g., FDA requires outcomes study or expanded sample size) → impact assessment and Steering Committee decision on cost/timeline trade-off within 2 weeks. ISO 13485 assessment reveals major non-conformance (design-control deficiency) → corrective-action plan required, design freeze delayed if not resolved by Month 18 (2028-04-13). Mock FDA inspection identifies ≥5 potential 483-level observations → remediation plan developed and closed within 4 weeks, or pre-approval inspection delayed by 2-4 months. Any FDA Q-Submission deficiency or major comments post-submission (Month 36-42 = 2029-10-13 to 2030-04-13) → response prepared within 30-60 days per FDA timeline; if deficiency indicates fundamental design or evidence issue, escalate to Steering Committee with re-design/re-test scope and cost.

### 4. Pharma Beachhead Revenue and Commercial-Validation Tracking
**Monitoring Tools/Platforms:**

  - Pharma Partnership Pipeline Tracker (5-10 prospects, status: interest, negotiation, signed contract, data-generation in progress, results received)
  - Signed Pharma Contracts Register (2-3 contracts expected by Month 9 = 2027-07-13; terms: sample volume, pricing, timeline, data ownership)
  - Monthly Pharma Revenue Report (cumulative and run-rate USD, invoiced and received, collection status)
  - Non-Dilutive Funding Pipeline (SBIR/STTR grant applications, expected award dates, amounts received)
  - Lean-Pivot Trigger Checklist (cumulative revenue <USD 500k by Month 12 = 2027-10-13 or run-rate <USD 100k/month by Month 18 = 2028-04-13)

**Frequency:** Monthly pharma-partnership status calls with key sponsors (Months 3-18 = 2027-01-13 to 2028-04-13). Revenue reporting monthly (actual invoices and collections). Quarterly pharma/grant pipeline review with Steering Committee (Months 6, 12, 18, 24 = 2027-04-13, 2027-10-13, 2028-04-13, 2028-10-13). Lean-pivot trigger assessed at Month 18 (2028-04-13); decision made within 2 weeks if triggered.

**Responsible Role:** CEO / Founder (business development lead) owns pharma relationship and sponsorship strategy. Finance Lead tracks revenue received and burn-rate impact. Steering Committee reviews pharma pipeline quarterly and votes on lean-pivot activation if trigger is met.

**Adaptation Process:** Monthly pharma calls track: (1) feasibility-phase partnership status (Months 3-6 = 2027-01-13 to 2027-04-13, no funding expected), (2) contract-negotiation status (Months 6-9 = 2027-04-13 to 2027-07-13, first contract signatures targeted), (3) data-generation in progress (Months 9-18 = 2027-07-13 to 2028-04-13, samples processed, results reporting). If pharma partner delays signing or reduces sample volume >30%, CEO escalates to Steering Committee and re-evaluates revenue forecast. If cumulative pharma revenue is <USD 100k by Month 12 (2027-10-13), or projected run-rate at Month 18 (2028-04-13) is <USD 100k/month, Steering Committee convenes within 1 week and votes on lean-pivot contingency: (a) reduce headcount 20-30% (preserve R&D, quality, clinical readiness; defer Clusters 2-5), (b) pause Newark Phase 2 equipment orders (continue only Phase 1 reagent lab), (c) accelerate CLIA lab-service fallback preparation (Month 12 = 2027-10-13 target), (d) pursue alternative funding (bridge, Series B pull-forward, partnership). Non-dilutive funding (SBIR/STTR) applications submitted by Month 4-5 (2027-02-13 to 2027-03-13); Phase 1 awards (USD 100-500k) expected Month 10-12 (2027-08-13 to 2027-10-13). If SBIR/STTR awards are delayed or rejected, fundraising target (Series A sizing) is re-evaluated.

**Adaptation Trigger:** Cumulative pharma contract revenue <USD 500k by Month 12 (2027-10-13) (proposed threshold) → reassess revenue strategy; if <USD 1M cumulative by Month 18 (2028-04-13), lean-pivot contingency is activated. Pharma partner contract negotiations slip >4 months past target (e.g., expected signature Month 9 = 2027-07-13 delays to Month 13 = 2027-11-13) → CEO and Steering Committee re-plan cash burn and fundraising timeline within 2 weeks. First pharma contract not signed by Month 9 (2027-07-13) → Series A Tranche 1 funding (Month 6 = 2027-04-13) contingency reassessed; if pharma deal remains unsigned by Month 12 (2027-10-13), lean-pivot triggered automatically. Run-rate below USD 100k/month at Month 18 (2028-04-13) assessment → lean-pivot contingency activated within 2 weeks (proposed threshold). Non-dilutive funding awards fall short of USD 1-2M target by >30% (e.g., only USD 500k of USD 1.5M applied) → Series A/B sizing increased to compensate, or spending reduced accordingly.

### 5. Newark Manufacturing Build-Out and Capital-Committed Assurance Monitoring
**Monitoring Tools/Platforms:**

  - Newark Facility Lease Agreement and Site-Selection Documentation (by Month 14 = 2027-12-13, contingent on Month 12 = 2027-10-13 gate)
  - Phase 1 Equipment Procurement List and Quotes (reagent hood, refrigerated storage, QC instruments; ordered Months 4-6 = 2027-02-13 to 2027-04-13, lead times 4-6 months)
  - Phase 1 Fit-Out Timeline and Budget (Months 12-15 = 2027-10-13 to 2028-01-13, capital USD 500-800k; operational by Month 15-18 = 2028-01-13 to 2028-04-13)
  - Pilot-Fill Results and Yield Validation Records (Month 12-18 = 2027-10-13 to 2028-04-13 batches, yield ≥85% target)
  - Phase 2 Equipment Procurement Plan and Long-Lead Orders (Months 18-24 = 2028-04-13 to 2028-10-13, capital USD 2-4M + 20% contingency USD 400-600k, operational by Months 24-30 = 2028-10-13 to 2029-04-13)

**Frequency:** Monthly Newark facility and equipment status (fit-out progress, equipment deliveries, installation schedule, pilot fills). Gate-linked capital release votes at Months 12, 18 (2027-10-13, 2028-04-13): Phase 1 capital USD 500-800k approved at Month 12 (2027-10-13) gate (after analytical feasibility pass); Phase 2 capital USD 2-4M approved at Month 18 (2028-04-13) gate (after design freeze and pilot yield ≥85%).

**Responsible Role:** Operations Committee (Manufacturing Lead, Chief Quality Officer) owns Newark facility planning and equipment procurement. CFO / Finance Lead manages capital budgets and equipment ordering authority. Steering Committee votes on capital release for each phase before commitment is made.

**Adaptation Process:** Month 12 (2027-10-13) gate: if analytical feasibility passes (yield, concordance, shelf-life thresholds met), Steering Committee approves Phase 1 capital release (USD 500-800k) and authorizes Newark site selection and lease negotiation. If gate fails, Phase 1 is paused (no facility lease, no equipment orders). Phase 1 fit-out (Months 12-15 = 2027-10-13 to 2028-01-13) is tracked monthly: equipment delivery dates, installation progress, pilot-fill scheduling. If pilot-fill yield from Phase 1 is <85% (lower 95% CI <80%), design-review cycle is triggered; Phase 2 commitment is deferred until redesign is resolved and retest yield is ≥85%. If Phase 1 equipment costs exceed quoted price by >20% or lead times slip >4 weeks, Finance Lead escalates to Steering Committee within 1 week for contingency-fund approval (20% contingency reserve is pre-allocated for such overruns). Month 18 (2028-04-13) gate: if design freeze and yield validation are confirmed, Phase 2 capital release (USD 2-4M) is approved. Long-lead equipment (automated cartridge filler, 6-12 month lead time) is ordered immediately upon approval; binding orders with non-cancellable deposits are placed. Phase 2 fit-out (Months 18-30 = 2028-04-13 to 2029-04-13) is tracked monthly; equipment commissioning and scale-up validation are completed by Month 30 (2029-04-13) to support manufacturing readiness for FDA pre-approval inspection (expected Months 36-42 = 2029-10-13 to 2030-04-13).

**Adaptation Trigger:** Month 12 (2027-10-13) analytical feasibility gate fails (yield <80%, concordance <95%, shelf-life <9 months) → Phase 1 commitment is paused; no facility lease signed, no equipment orders placed. Steering Committee decides within 2 weeks: (a) retest and redesign (extend by 4-8 weeks), (b) activate Fallback V1 and cancel Newark Phase 1 (pivot to contract-manufacturer and CLIA lab-service fallback). Phase 1 pilot-fill yield <85% at Month 12-15 (2027-10-13 to 2028-01-13) → design-review cycle triggered; Phase 2 approval delayed until yield is restored to ≥85% via redesign (additional 4-8 weeks, +USD 100-300k). Phase 1 or Phase 2 equipment costs exceed budget by >20% (each phase) → 20% contingency is applied; if contingency is exhausted, Steering Committee votes on additional capital request or spending cuts elsewhere. Long-lead equipment delivery slip >6 weeks (e.g., filling machine delivery delays from Month 24 = 2028-10-13 to Month 30 = 2029-04-13) → alternative equipment sourcing or contract-manufacturer contingency activated within 2 weeks; manufacturing scale-up readiness by Month 30 (2029-04-13) may be at risk, escalating FDA pre-approval inspection readiness.

### 6. Clinical Study Enrollment and Data Integrity Monitoring
**Monitoring Tools/Platforms:**

  - Clinical-Study Protocol and IRB Approval Documentation (by Month 12 = 2027-10-13)
  - Subject-Enrollment Tracking Dashboard (monthly: target vs. actual, sites activated, protocol-deviation rate, adverse events)
  - LIMS Integration and eCRF System (data entry, quality checks, result reporting to device and reference lab)
  - Clinical-Study Data-Integrity Audit Reports (quarterly data audits of measurement accuracy, traceability, adverse-event reporting)
  - Interim Clinical-Data Analysis Report (Months 18, 24 = 2028-04-13, 2028-10-13: concordance, CV, sensitivity/specificity per analyte)

**Frequency:** Monthly clinical-study enrollment tracking (vs. target 300-500 subjects over Months 12-18 = 2027-10-13 to 2028-04-13). Data-integrity audits quarterly (Months 15, 18, 21, 24 = 2028-01-13, 2028-04-13, 2028-07-13, 2028-10-13). Interim concordance analysis at Months 18, 24 (2028-04-13, 2028-10-13) from 100-150 and 200+ subjects respectively. Final analysis and publication target Month 30 (2029-04-13).

**Responsible Role:** Chief Compliance Officer / Regulatory Lead (study governance, protocol adherence, data integrity). Clinical-Trial Coordinator (day-to-day enrollment, site coordination, informed consent, adverse-event reporting). Academic clinical partner (site activation, subject recruitment, sample collection, reference-lab testing). Compliance, Ethics and Risk Management Committee (data-integrity audits, research-misconduct investigation if needed).

**Adaptation Process:** Monthly enrollment tracking compared to target (300-500 subjects over 6 months = 50-83 subjects/month target). If enrollment falls >20% behind target (e.g., <40 subjects/month when 50 target), Clinical-Trial Coordinator and academic partner assess reasons within 2 weeks and propose corrective action (additional sites, extended enrollment period, adjusted inclusion criteria if scientifically justified). Interim data analysis at Month 18 (2028-04-13) with 150-200 subjects provides first concordance snapshot (target ≥95% lower CI ≥93%); if concordance is 93-95% (ambiguous), additional sites or subjects are enrolled to increase power; if <93%, analytes failing concordance are escalated to Operations Committee for potential redesign or removal from final panel. Data-integrity audits (quarterly) verify protocol adherence, measurement accuracy, and absence of selective data reporting. If audit finds significant non-compliance (e.g., >5% of data entry errors, protocol deviations not documented, adverse events under-reported), study is paused; corrective actions are implemented and re-audit is conducted within 2 weeks. Any suspected research misconduct (falsified data, selective reporting) is escalated to Chief Compliance Officer within 48 hours and investigated; findings are reported to IRB and FDA within 30 days. Enrollment close-out occurs at Month 18-24 (2028-04-13 to 2028-10-13); final analysis is completed by Month 24 (2028-10-13) and results are submitted to pre-registration database (if not already published); publication is targeted for Month 30 (2029-04-13) before FDA submission (Month 30-36 = 2029-04-13 to 2029-10-13).

**Adaptation Trigger:** Subject enrollment <50 subjects/month average over rolling 3-month window (proposed threshold) → protocol amendment or site-activation acceleration within 2 weeks. Interim concordance analysis (Month 18 = 2028-04-13, ≥150 subjects) shows <95% concordance (lower CI <93%) for any analyte → analyte is flagged for redesign or removal; Steering Committee is notified if >10% of Cluster 1 analytes are affected. Data-integrity audit identifies ≥5% error rate or protocol-deviation rate >3% → study is paused; corrective-action plan required and re-audit within 2-4 weeks. Suspected research misconduct or data falsification allegation → immediate escalation to Chief Compliance Officer, independent investigation, IRB and FDA notification within 30 days. Clinical-study publication delayed beyond Month 30 (2029-04-13) target by >2 months → FDA submission (target Month 30-36 = 2029-04-13 to 2029-10-13) is at risk; expedited publication or interim results submission to FDA considered.

### 7. Over-Claiming Prevention and Transparency/Credibility Risk Monitoring
**Monitoring Tools/Platforms:**

  - Marketing and Claims Compliance Audit Trail (monthly review of all investor pitches, press releases, marketing materials, social media, website copy for '500 tests' claim or other unsupported assertions)
  - Monthly Analyte Performance Dashboard (published externally, updated monthly showing per-analyte pass/fail status, retired analytes with rationale)
  - External Scientific Advisory Board Meeting Minutes (quarterly public meetings, audit access to raw data, advisory recommendations on transparency)
  - Quarterly Transparency Report (to investors, regulators, clinicians: milestone status, gate results, risk updates, failed analytes, regulatory pathway, funding status)
  - Communications Policy and Compliance Checklist (prohibits '500 tests per drop' claims until ≥3 clusters independently validated; requires disclosure of retired analytes in regulatory submissions; specifies language for claims)

**Frequency:** Monthly marketing-materials audit (100% review of all external communications). Monthly Analyte Performance Dashboard published (internal and external to board, advisors, key stakeholders). Quarterly Transparency Report (Months 6, 12, 18, 24, 30 = 2027-04-13 onwards). Quarterly external advisory board public meetings (Months 6, 12, 18, 24 = 2027-04-13, 2027-10-13, 2028-04-13, 2028-10-13).

**Responsible Role:** Chief Compliance Officer (policy, audit, enforcement). CEO / Founder (communications strategy, investor messaging). Chief R&D Officer (technical accuracy of claims). External Scientific Advisory Board (independent validation of data and transparency adequacy, public credibility endorsement).

**Adaptation Process:** Monthly marketing-materials audit: all draft materials (investor decks, press releases, website content, social media) are reviewed by Chief Compliance Officer before publication. Any use of '500 tests', 'single drop', or other product claims is flagged; language must be verified against validated data in Analyte Performance Dashboard. If claim is not supported (e.g., Cluster 1 has only 35 analytes validated so far, not 50), material is rejected or claim is revised to 'expanding menu' or 'cumulative panel'. Pre-approved language templates are published (e.g., 'We are developing a modular panel that, when fully validated across all clusters, may eventually offer testing for up to 500 analytes'; 'Our lead panel (Cluster 1) is currently validating up to 50 analytes; we have retired X analytes due to cross-reactivity or sensitivity limitations'). Quarterly Transparency Report documents: (1) milestones achieved (analytical feasibility gate pass Month 12 = 2027-10-13, design freeze Month 18 = 2028-04-13), (2) gate results with numeric data and confidence intervals, (3) analytes retired (count and root causes: cross-reactivity, sensitivity, stability, regulatory feedback), (4) regulatory pathway and evidence status, (5) funding raised and runway to next gate. Report is published to investors quarterly and made available to scientific advisors. Any failed analyte or missed gate is reported transparently (not hidden); this builds credibility and shows rigor. External Scientific Advisory Board (5-7 members, 15+ years experience, no financial conflicts) holds quarterly public meetings (1-2 hours, virtual or in-person) where results are presented and advisory feedback is solicited. Board members have audit access to raw data (concordance, CV, shelf-life, yield data) and can verify that Analyte Performance Dashboard is accurate and complete. Board publishes quarterly statements of opinion on data integrity and transparency adequacy (e.g., 'The data presented in the dashboard is consistent with raw records reviewed; we have identified no evidence of selective reporting or data manipulation'). If Chief Compliance Officer discovers an over-claim (e.g., '500 tests per drop' used prematurely), a corrective statement is issued within 24-48 hours; the error is documented in Transparency Report; and corrective action is reported to board and investors within 1 week.

**Adaptation Trigger:** Any investor pitch, press release, or marketing material using '500 tests per drop' claim before ≥3 clusters are independently published and cleared (proposed threshold) → material is rejected; author is coached on policy; repeat violations result in escalation to CEO and board (proposed threshold). Monthly audit identifies unsupported claim (e.g., Cluster 1 concordance stated as '99%' when validated data shows '94%' lower CI) → corrective amendment is published within 2 weeks (proposed threshold); source of error is investigated (measurement error, data-reporting error, communication misunderstanding) and process is improved. External Scientific Advisory Board identifies data integrity concern or transparency gap (e.g., retired analytes not disclosed in Transparency Report) → Chief Compliance Officer conducts investigation within 2 weeks; findings and corrective actions are reported to board and advisors within 30 days. Media or analyst inquiry about failed analytes or over-claiming history → CEO and Chief Compliance Officer coordinate transparent response with advisory board input, emphasizing rigorous gate methodology and transparent reporting of failures; response is published and shared with investors within 1 week.

# Governance Extra

## Governance Validation Checks

1. Completeness Confirmation: All four core governance components (internal bodies, implementation plan, decision escalation matrix, monitoring/progress) are present and detailed. However, no explicit 'Stage 1 Audit Details' file was provided in the input; the governance-phase1-audit.json describes corruption and misallocation risks but does not appear integrated into a formal audit schedule or compliance-control baseline for Months 0–6 (2026-10-13 to 2027-04-13). The audit procedures listed (quarterly gate reviews, monthly supplier scorecards, semi-annual DHF reviews, mock FDA inspection) are reactive; a foundational Month 0–1 (2026-10-13 to 2026-11-13) control-establishment schedule is absent.
2. Internal Consistency Check: The four governance stages are logically aligned in sequence: Audit baseline → Internal Bodies established → Implementation milestones → Escalation rules → Monitoring cadence. The Steering Committee owns capital gates; Operations Committee executes; Technical Advisory Group validates; Compliance manages risk. However, one gap: the Implementation Plan step-descriptions do not explicitly state who 'formally confirms' Fallback Panel V1 analyte removals post-facto to the board monthly (vs. only reporting after Analyte Review decisions are made). This risks silent scope drift if operations removes analytes without escalating numeric impact to Steering Committee.
3. Clarity of Roles—Advisor and Independent Perspectives: The Technical Advisory Group (external microfluidics, immunoassay, manufacturing, regulatory experts) has audit rights and can submit minority reports, but lacks formal veto authority over gate passage. The External Scientific Advisory Board (mentioned in communications policy) has audit access to raw data and quarterly public meetings, but its authority to recommend analyte removal or design changes is advisory only. Neither body has explicit authority to pause gates unilaterally. Consider: Should the Technical Advisory Group have a 'hold' veto (requiring Steering Committee override vote within 5 business days) if it identifies major feasibility risk? Should the Scientific Advisory Board have authority to request independent re-testing at any time?
4. Process Depth—Conflict of Interest and Ethics Escalation: The Compliance, Ethics and Risk Management Committee charter defines conflict-of-interest policy and research-misconduct hotline, but does not specify: (1) How undisclosed conflicts (e.g., board member owns equity in a reagent supplier) are resolved if discovered at Month 6, 12, 18 (2027-04-13, 2027-10-13, 2028-04-13)? (2) Who investigates and decides whether the member must recuse or divest? (3) How is the decision communicated to investors and regulators? (4) What is the timeline for resolution (within 2 weeks, 30 days)? Add explicit escalation: undisclosed material conflict → Chief Compliance Officer investigation (within 48 hours) → Steering Committee review (within 1 week) → investor board notification (within 3 business days) if impact on governance or decisions is material.
5. Process Depth—Change Control and Design Authority Below Steering Committee: The Operations Committee approves design changes <USD 50k and <2 weeks impact without escalation. However, the implementation plan does not specify: (1) Who has signature authority on the design-change log? (2) If a microfluidics engineer proposes a cartridge geometry change (within USD 50k, <2 weeks impact), does the Chief R&D Officer sign off unilaterally, or does it require joint sign-off with Quality? (3) What happens if Operations Committee members disagree (e.g., R&D wants a design change, Quality flags risk)? Current rule is 'R&D director makes the call (subject to Steering Committee review if >USD 50k),' but that defers escalation. Add: (a) joint sign-off (R&D + Quality) required for all design changes; (b) if disagreement, escalate to Steering Committee within 3 business days; (c) no design change is implemented until sign-offs are complete.
6. Thresholds and Delegation Clarity—'Ambiguous' Gate Results and Re-Test Authority: The monitoring plan defines 'ambiguous' results (e.g., yield 80–85% when gate is ≥85%, concordance 93–95% when gate is ≥95%) as requiring re-test and board discussion. However, the implementation plan does not specify: (1) Who decides whether a re-test is approved (Operations, Steering Committee, or board)? (2) What is the maximum duration of a re-test cycle (proposed: 2–3 weeks; if longer, escalate to Steering Committee)? (3) If re-test results remain ambiguous (e.g., yield 84–86% in second test, 95% CI 80–90%), does a third test occur or does Fallback V1 activate? Add explicit re-test rules: (a) First ambiguity → up to 2-week re-test approved by Steering Committee; (b) Second ambiguity after re-test → escalate to Steering Committee within 1 week for pass/fail/retreat vote; (c) no more than 2 re-test cycles per gate; after that, board decides by majority vote (Steering Committee or investor board if >USD 2M impact).

## Tough Questions

1. By Month 6 (2027-04-13), what is the actual measured plasma-separation efficiency from 100+ fingerstick subjects, and does the lower 95% confidence interval exceed 95% yield of ≥1.6 microliters per subject? If plasma separation is 80–90% efficiency (vs. the ≥95% gate), how many analytes are physically feasible per drop after accounting for hemolysis and clotting losses—and does this change the cumulative-menu strategy from 10 cartridges of 50 to, say, 5 cartridges of 40?
2. Show the raw cross-reactivity screening data (each analyte pair, spiked into human plasma with elevated hemoglobin, bilirubin, lipemia, rheumatoid factor) measured at Month 6 (2027-04-13). For any analyte-pair combination showing >5% bias at 10× physiologic interferent, what is the root cause (antibody cross-binding, probe quenching, matrix interference), and is the planned remediation (antibody swap, assay chemistry redesign, or analyte removal) credible given the Months 12–18 (2027-10-13 to 2028-04-13) timeline before design freeze?
3. By Month 12 (2027-10-13), provide the first-article run (FAR) yield data from contract-molder partner: (1) mean yield from ≥5 batches of 1,000 cartridges each; (2) lower 95% CI for yield (gate is ≥80%); (3) any defect modes (injection-molding defects, bonding failures, reagent-fill variability) that recurred across batches; (4) if yield is <85%, what specific cartridge geometry, material, or process-window adjustment will restore it, and what is the re-tooling cost and lead-time impact?
4. What is the current probability-weighted forecast for pharma contract revenue at Month 18 (2028-04-13)? Show the pipeline: (1) how many pharma sponsors are in active negotiation (target: 2–3 signed contracts by Month 9 = 2027-07-13); (2) what is the cumulative revenue from signed contracts by Month 12 (2027-10-13) and Month 18 (2028-04-13) (cumulative floor: USD 500k by Month 12 = 2027-10-13, USD 1M+ by Month 18 = 2028-04-13, or lean-pivot triggered); (3) if pharma revenue is tracking below USD 100k/month run-rate at Month 18 (2028-04-13), what is the plan (lean pivot, Series B timing adjustment, CLIA fallback activation)?
5. At Month 6 (2027-04-13) FDA Pre-Submission meeting, what specific feedback will FDA provide on: (1) Is a 510(k) or De Novo pathway required for a multiplex panel of 50 analytes? (2) What analytical and clinical evidence will FDA expect (method-comparison study sample size, statistical power for 50 simultaneous analytes, outcomes data)? (3) Can staged per-cluster 510(k)s be filed, or must all analytes be submitted together? If FDA indicates De Novo is likely, how does this change the Series A/B funding roadmap (+12–18 months, +USD 2–4M)?
6. Show the detailed unit-economics model locked by Month 6 (2027-04-13): (1) cost of goods per cartridge (bottom-up: molded body USD 2–4, fluidic bonding USD 1–2, reagents USD 4–8, QC consumables USD 2–4, packaging USD 2–3; total ≤USD 25 ceiling); (2) expected net revenue per run at each volume (1k, 10k, 50k cartridges/month) under the base-case payer scenario (USD 100–200 per panel); (3) gross margin at each volume; (4) if payers cover only USD 50–100 per panel (low scenario), what cost-reduction or volume-increase targets are needed to maintain ≥60% margin?
7. By Month 12 (2027-10-13) analytical-feasibility gate, provide evidence that Fallback Panel V1 (50 analytes, 4–5 cartridges) is technically validated: (1) each analyte meets ≥95% concordance with reference method (show lower 95% CI for each); (2) lot-to-lot CV <10% (show data from ≥3 pilot lots); (3) shelf-life projected ≥12 months (show Arrhenius modeling with R² >0.90); (4) no analytes removed due to cross-reactivity, sensitivity, or stability failures. If >5 analytes (10% of 50) have been retired by Month 12 (2027-10-13), what is the revised Fallback Panel V1 definition, and does it still command sufficient payer interest and clinical utility to justify the USD 15–30M cumulative burn?

## Summary

The governance framework establishes a disciplined four-layer structure (Steering Committee for strategy, Operations for execution, Technical Advisory Group for validation, Compliance for risk/ethics) with explicit gate-linked capital releases, quantified go/no-go criteria, and a pre-registered Fallback Product (50 analytes) retreat trigger. Monthly Analyte Review Meetings and transparency dashboards enforce credibility through public failure reporting. The framework's core strength is its defense against sunk-cost escalation: gates are quantitative (yield ≥85%, concordance ≥95%, shelf-life ≥12 months), capital tranches are tied to gate passage, and Fallback V1 retreat is pre-authorized (rather than reactive) by Month 15 (2028-01-13) if gates fail. Key gaps requiring clarification: (1) conflict-of-interest resolution timelines and escalation; (2) design-change joint sign-off authority and deadlock resolution; (3) re-test cycle limits and ambiguous-gate decision rules; (4) technical advisory board veto authority over gate passage. The regulatory pathway (510(k) vs. De Novo) is FDA Pre-Submission dependent (Month 6 = 2027-04-13) and not yet confirmed, creating material funding and timeline uncertainty. Pharma beachhead revenue is contingent and may be insufficient to avoid lean pivot by Month 18 (2028-04-13). Overall, the framework is operationally sound for a capital-constrained, high-risk medtech venture, but its success depends entirely on gate execution discipline and early resolution of regulatory pathway and pharma-revenue contingencies.