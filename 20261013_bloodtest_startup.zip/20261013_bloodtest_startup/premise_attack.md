### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] The plan restates Theranos's discredited promise, a huge test menu from one finger-prick drop with devices mass-produced in Newark, California, as a new startup, and it names no analytical mechanism that gets around the sample-volume and assay-chemistry limits that sank that company.**

**Bottom Line:** REJECT: A new company promising hundreds of tests from one drop of blood, with a Newark factory before any proven chemistry, rebuilds a known fraud template and should not be started.


#### Reasons for Rejection

- A single drop is roughly tens of microliters (estimate), so 500 tests leave on the order of 0.1 µL per assay (recomputed estimate), below what most validated immunoassay, chemistry, hematology and molecular methods can measure with clinical precision.
- The 500 tests span incompatible sample types (whole blood, serum, plasma, different anticoagulants), different detection chemistries and wildly different concentration ranges, so one cartridge cannot serve them all without sacrificing accuracy on most.
- Naming Newark, California as the mass-production site for devices that have not yet been shown to work is premature capital commitment: it builds the factory before proving the assay, and it repeats the location where the Theranos lab was cited and shut down.
- The plan has no clinical validation, regulatory pathway (FDA clearance or CLIA waiver) or comparison against central-lab reference methods, and "project start ASAP" signals speed is being prized over analytical proof in a field where a wrong potassium or troponin result harms patients.
- Any startup that makes this claim carries a built-in credibility deficit: clinicians, payers and investors will demand independent peer-reviewed validation for every one of the 500 tests, so the breadth advertised as the selling point multiplies the burden of proof 500 times.

#### Second-Order Effects

- 0–6 months: Fundraising and hiring are built on a headline number (500 tests, one drop) that cannot be backed by data, so early engineers and advisors are pushed to demonstrate a demo rather than validate accuracy, and the first discrepancy against reference labs becomes a reputational problem.
- 1–3 years: Factory lease, tooling and cartridge production in Newark consume the bulk of capital while the assay menu stays narrow, so the company either quietly shrinks to a handful of conventional tests or sends unvalidated results to patients and invites regulatory and legal action.
- 5–10 years: A further high-profile failure in this category hardens payer, regulator and investor skepticism toward legitimate low-volume and point-of-care diagnostics, raising the evidence bar and capital cost for honest competitors.

#### Evidence

- Case/Incident — Theranos CLIA sanctions (2016): CMS inspected the Newark, California lab, found deficiencies, revoked its CLIA certificate in July 2016 and banned Holmes from owning or operating a lab for at least two years.
- Case/Incident — United States v. Elizabeth Holmes (2022): a federal jury convicted the Theranos founder in January 2022 on three counts of wire fraud and one count of conspiracy over claims of finger-stick blood testing, and she was later sentenced to just over 11 years in prison.
- Law/Standard — Clinical Laboratory Improvement Amendments (1988): U.S. law requiring laboratories that test human specimens for clinical use to meet quality and proficiency standards, which is the framework the Newark lab failed.



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[STRATEGIC] — The Newark Encore: the plan re-stages the Theranos promise (hundreds of complex tests from one drop of blood, devices mass-produced in Newark, California) as a founding premise before any single test has been shown to work, so the headline number is the product and the science is an afterthought.**

**Bottom Line:** REJECT: The Newark Encore sells a claim the world has already watched collapse in the same town, with the same hook of hundreds of tests from one drop, and the premise gives no reason to expect a different ending. A plan that makes the impossible number the foundation deserves to be closed at the gate.


#### Reasons for Rejection

- Patients would decide on medication, surgery or cancer fears from a result they cannot inspect, produced from a sample too small to repeat or cross-check, so their consent rests on a promise instead of an understanding.
- A bundle of 500 complex tests sits across device, laboratory and state regulators, and the plan's own order of work (mass production first) invites claiming trade secrecy to avoid outside scrutiny, then moving the testing wherever the least scrutiny lives.
- Factory-scale output multiplies every unvalidated assay into thousands of wrong answers, and a missed diagnosis or a needless treatment cannot be recalled the way a defective device can.
- The number 500 is a marketing headline, not a clinical need: it forces unrelated chemistries into one tiny sample, chasing breadth where doctors need a few trustworthy results.

#### Second-Order Effects

- **Months 0–12 (2026-10-13 to 2027-10-13) — The Cracks Appear:** Investor pitch decks and a Newark production line outrun the lab data, and the first honest internal comparison against conventional venous testing becomes the document nobody wants to circulate.
- **Months 12–36 (2027-10-13 to 2029-10-13) — Copycats Arrive:** Rivals see that a bold 'hundreds of tests, one drop' claim raises money faster than a narrow, validated assay, and the field drifts toward headline metrics.
- **Months 36–72 (2029-10-13 to 2032-10-13) — Norms Degrade:** Clinicians and regulators begin treating every fingerstick-diagnostics pitch as presumptively false, which taxes honest developers of small-volume testing with delays and doubt.
- **Months 72–120 (2032-10-13 to 2036-10-13) — The Reckoning:** Whoever received a wrong result carries the harm for years while the company, its patents and its manufacturing site are wound down in bankruptcy and litigation.

#### Evidence

- Law/Standard — Clinical Laboratory Improvement Amendments of 1988 (CLIA): U.S. law requiring clinical laboratories to meet quality and accuracy standards for human test results, which is the standard Theranos' Newark laboratory was cited under.
- Case/Report — In January 2016 the Centers for Medicare & Medicaid Services found Theranos' Newark, California laboratory out of compliance in five areas and posing 'immediate jeopardy' to patient health and safety; the CLIA certificate was later revoked and Elizabeth Holmes was barred from operating a lab for two years.
- Case/Report — Theranos voided two years of results from its Edison devices and issued corrected reports to doctors and patients, showing that results already acted on cannot be unwound.
- Case/Report — Elizabeth Holmes was convicted of three counts of wire fraud and one count of conspiracy to commit wire fraud over claims that the technology could run hundreds of tests from a few drops of blood, and received a prison sentence of more than 11 years (reported; exact term not verified).



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] Promising 500 complex assays from one drop of blood, then mass-producing devices in Newark, stakes everything on volume arithmetic that has already destroyed a well-funded predecessor.**

**Bottom Line:** REJECT: A company that promises 500 tests from one drop of blood and builds factories in Newark before proving a single assay repeats a claim that physics and precedent have already refuted.


#### Reasons for Rejection

- Physics: one drop is roughly 50 microliters (estimate), so 500 tests (user constraint) leave about 0.1 microliter per assay (recomputed estimate), far below the sample volumes that immunoassays, chemistry panels and nucleic-acid tests normally need to be reproducible.
- Sequencing: committing to mass production in Newark, California before any one of the 500 assays is proven bakes unvalidated hardware into tooling, leases and supply contracts, so a failed premise cannot be unwound cheaply.
- Governance: every one of 500 "complex" tests is a separate clinical claim needing its own analytical validation under CLIA and FDA review, so "ASAP" start collides with a regulatory workload that scales per assay, not per device.
- Patient harm: even at an assumed 99% specificity per test (illustrative assumption), the chance of at least one false positive across 500 independent tests is about 99.3% (recomputed), so each patient would be handed a list of phantom diseases to chase.
- Precedent: Newark, California is where Theranos ran its lab, so a one-drop, hundreds-of-tests pitch tied to that same city invites the immediate scepticism of regulators, press and investors before a single data point exists.

#### Second-Order Effects

- 0–6 months (Months 0-6 = 2026-10-13 to 2027-04-13): Capital is raised on the headline figure of 500 tests, a Newark site is leased and staffed, and engineers discover that the volume per assay cannot support more than a small fraction of the promised menu.
- 1–3 years (Months 12-36 = 2027-10-13 to 2029-10-13): Pilot data reveal precision failures across assay families, the menu is quietly cut to a handful of tests, and pressure grows to run samples on conventional analyzers while the single-drop device is still presented as the source.
- 5–10 years (Months 60-120 = 2031-10-13 to 2036-10-13): Investors, clinicians and regulators treat every single-drop multi-panel claim as presumptively false, raising the cost of capital and the evidence burden for honest, narrower diagnostic ventures.

#### Evidence

- Case/Incident — Theranos CMS sanctions (2016): CMS revoked the CLIA certificate of Theranos's Newark, California lab and barred Elizabeth Holmes from owning or operating a lab for at least two years after Edison devices often failed the company's own accuracy requirements.
- Case/Incident — Wall Street Journal investigation by John Carreyrou (2015): former employees said only about 15 of the 240-plus tests Theranos offered ran on its proprietary device, with the rest run on commercial analyzers.
- Case/Incident — United States v. Holmes jury verdict (2022): a San Jose jury found Elizabeth Holmes guilty of three counts of wire fraud and one count of conspiracy to commit wire fraud against investors over claims about the technology.



### Premise Attack 4 — Cascade
_Tracks second/third-order effects and copycat propagation._

**The premise (500 complex tests from one drop of blood, with mass manufacturing in Newark, California) is not an engineering challenge awaiting funding but a re-enactment of Theranos's claim, down to the town of its sanctioned lab. A single drop (roughly 50 µL, estimate) divided 500 ways leaves about 0.1 µL per assay (estimate), below the volume at which incompatible assay chemistries can produce clinically reliable results, and manufacturing at scale cannot repair a signal that does not exist.**

**Bottom Line:** Abandon the premise: 500 complex tests from one drop of blood is a claim that physics and assay chemistry do not support, and building a Newark factory around it only scales the failure. The flaw lies in the headline promise itself, not in funding, execution or manufacturing, and the only defensible alternative is a different business with a different promise.


#### Reasons for Rejection

- The Sub-Microliter Mirage: dividing about 50 µL (estimate) of capillary blood into 500 assays leaves roughly 0.1 µL per test (estimate), below the dead volume, dilution and pipetting-precision limits of immunoassay, chemistry, molecular and cell-counting methods. The plan treats a sample-volume constraint as a miniaturization problem; it is a signal-to-noise limit that scaling does not remove.
- The One-Cartridge Chemistry Fallacy: 'complex' tests span incompatible modalities (immunoassays, enzymatic chemistry, nucleic-acid amplification, flow cytometry) with different reagents, temperatures, incubation times and interference profiles. A single device performing all of them forces every assay into compromise, so none performs to clinical standard. No general-purpose platform of this kind has been validated.
- Factory-Before-Proof Inversion: committing to mass production in Newark before any assay is analytically validated against reference methods builds tooling, lease commitments and headcount around an unproven measurement. Each hardware revision then scraps inventory, and the factory becomes the main source of cash burn rather than a source of product.
- The Regulatory Gauntlet Blind Spot: 500 distinct analytes imply hundreds of separate analytical and clinical validation burdens under FDA clearance and CLIA oversight (exact count not verified). Each requires its own comparator study, so a single-drop breadth claim becomes an unfundable multi-year, multi-hundred-study program for any startup.
- The Founder-Narrative Trap: a startup whose pitch is a breadth number (500) with no per-assay performance data is selling a story to investors, not a measurement to clinicians. Pressure to preserve the headline pushes teams toward running samples on conventional analyzers, quietly diluting results, or concealing failures, which converts a technical failure into fraud exposure.

#### Second-Order Effects

- Within Months 0-6 (2026-10-13 to 2027-04-13): hiring and a Newark lease get ahead of data; engineers discover that interference between assays and sub-microliter metering errors dominate results, but the 500-test headline is already in the investor deck and cannot be walked back without devaluing the company.
- Within Months 6-18 (2027-04-13 to 2028-04-13): the program narrows quietly to a handful of assays that work, while external messaging keeps the 500 figure. Internal truth and external claims diverge, and dissenting scientists leave or are sidelined, which is the precondition for whistleblower complaints.
- Within Months 18-36 (2028-04-13 to 2029-10-13): pilot customers or partners (clinics, pharmacies, employers) request validation data; results that fail comparison with reference labs trigger voided tests, patient-notification obligations and liability exposure for any clinical decisions already made on bad numbers.
- Within Months 36-60 (2029-10-13 to 2031-10-13): regulatory inspection of the Newark facility under CLIA/FDA, investor litigation and potential securities or wire-fraud inquiries; the company cannot raise further capital, and tooling and facility obligations become stranded liabilities.
- Within Months 60-120 (2031-10-13 to 2036-10-13): founders face personal criminal and civil exposure, patients with misdirected care become plaintiffs, and the failure further hardens investor and regulator skepticism toward legitimate low-volume blood-testing startups.

#### Evidence

- Theranos claimed finger-stick blood testing across a broad menu using its 'Edison' device; a former lab director testified he voided two years of patient tests run on Edison devices after concluding the machines had not worked from the beginning (reported by Almanac/Palo Alto Online and NBC Bay Area, 2021: https://www.almanacnews.com/news/2021/11/10/former-theranos-lab-director-voided-tests-run-on-companys-malperforming-edison-devices-in-2014-2015/).
- Theranos's Newark, California lab drew the most stringent CMS sanctions available in July 2016, including revocation of its CLIA certificate and a two-year ban on Elizabeth Holmes owning or operating a CLIA lab (https://en.wikipedia.org/wiki/Theranos).
- Theranos reached a peak valuation above $9 billion by 2015 and was dissolved in September 2018 (https://en.wikipedia.org/wiki/Theranos).
- Elizabeth Holmes was convicted on four fraud counts and sentenced by Judge Edward Davila to 11 years and 3 months in prison, beginning April 27, 2023 (https://www.bostonglobe.com/2023/05/18/business/theranos-founder-elizabeth-holmes-is-going-prison-heres-what-know).
- The plan reproduces three Theranos features: a multi-hundred-test, one-drop claim, a proprietary all-in-one device, and Newark, California as the production site. No credible scientific precedent shows a validated single-drop panel of this breadth (not verified for every technology in development).



### Premise Attack 5 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[STRATEGIC] — The Droplet Ceiling: The plan promises hundreds of complex assays from one drop of blood and builds a factory in Newark, California before any physical law, regulator or clinical reality has agreed that this is possible, so it repeats the Theranos premise (a 'hundreds of tests from a finger-stick' claim, a Newark lab, a mass-produced device) and bets patients' health on that gap.**

**Bottom Line:** REJECT: A 500-test single-drop device mass-produced in Newark restates a premise that has already collapsed once, and it still asks patients to trust claims that physics, regulation and precedent have not supported. The gate is closed.


#### Reasons for Rejection

- Rights and dignity: Patients cannot assess a 500-analyte result themselves, so every wrong potassium, troponin or HIV value is a medical decision made on their behalf by a device they cannot question, and the downside falls on the least informed party.
- Accountability and oversight: Complexity multiplies assay types, each with its own interferences, calibrations and failure modes. No regulator, auditor, clinician or board can independently validate 500 distinct methods on a shared micro-sample, so the founders become the only party who knows whether it works.
- Systemic risk and scale: Mass production before validation means defects are manufactured in bulk. One flaw in the cartridge chemistry, the sample-handling step or the calibration model reaches every device, every result and every downstream treatment decision at once.
- Value-proposition rot: The promise of 'complex tests from one drop' is a marketing claim bound by sample volume and detection limits. Closing the gap between what is promised and what is physically measurable creates a continuous incentive to dilute, to bend validation, to quietly use conventional analyzers behind the interface, and to conceal all of it from investors, partners and patients.

#### Second-Order Effects

- T+0–6 months — The Cracks Appear: The pitch is built on a headline number, and the first internal validation runs show that some assays need more sample than one drop provides. The company narrows what it measures in private while keeping the 500-test claim in public, and the first employees who object are managed out.
- T+1–3 years — Copycats Arrive: Investors, wary of missing out, fund competing 'comprehensive micro-sample diagnostics' firms that copy the headline claim. A race to out-promise each other pushes the whole segment toward unvalidated claims, and clinicians start receiving results from several devices that disagree.
- T+5–10 years — Norms Degrade: Patients and physicians learn that fingerstick panels are unreliable, and the discredit spreads to legitimate point-of-care and microsampling work that was sound. Skepticism hardens into policy, and genuine diagnostic progress is slowed by the backlash.
- T+10+ years — The Reckoning: Lawsuits, regulatory bans and criminal exposure for executives become the settled consequence of the model. A generation of clinicians treats single-drop diagnostics as a byword for fraud, and the harmed patients are never fully identified, because bad results were never fully traced.

#### Evidence

- Case/Report — Theranos: The company claimed its Edison device could run as many as 200 clinical tests from a finger-stick of blood. Its Newark, California lab was inspected by CMS and stripped of its CLIA certificate, and it voided or revised tens of thousands of test results from 2014–2015. This plan uses the same premise, the same city and a larger number.
- Case/Report — United States v. Holmes: A federal jury convicted Elizabeth Holmes on three counts of wire fraud and one count of conspiracy to commit wire fraud over claims about the blood-testing technology. The conviction shows that the 'one drop, many tests' pitch carried criminal liability for those who made it.
- Case/Report — Walgreens and Theranos: Walgreens ended its contract for 40 Theranos wellness centers in Arizona stores after the lab's results were questioned and voided, and then sued for breach. Commercial partners flee as soon as the analytical claims are doubted.
- Principle/Analogue — Analytical Chemistry: Assay sensitivity depends on sample volume and analyte concentration. A single drop is on the order of tens of microlitres (estimate), and after dilution and splitting across hundreds of assays, low-abundance analytes fall below reliable detection. Adding assays does not remove this limit.