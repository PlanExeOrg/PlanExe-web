# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** Very high. The plan seeks to found a diagnostics company whose single device runs 500 complex tests from one drop of blood, with mass manufacturing in Newark, California. It spans assay chemistry, microfluidics, an ISO 13485 quality system, FDA/CLIA regulatory work, clinical studies and a scaled production site. The headline claim is category-defining and commercial, with revenue and profit as the stated aim.

**Risk and Novelty:** Extreme technical and reputational risk. The 500-tests-per-drop claim is not shown to be physically feasible at clinical-grade accuracy within a drop-volume budget (the lever review itself states that no option makes all 500 analytes simultaneously feasible). It has precedent in earlier single-drop diagnostics claims that failed, including a company that operated in Newark, California (not verified here). Key risks are cross-reactivity, reagent stability, cartridge yield and over-claiming. The regulatory environment is favourable to lab services: the FDA LDT rule was vacated by a court and formally rescinded in September 2025, which restores enforcement discretion for CLIA-lab tests (verified), but selling an instrument still needs FDA clearance.

**Complexity and Constraints:** High operational complexity with several coupled decisions: assay architecture, regulatory route, Newark build-out timing, funding path and cartridge integration depth. Constraints are physical (wet lab, cleanroom, human-subject studies), a multi-year pre-revenue runway, capital intensity of a factory, and the need to freeze the design before the manufacturing investment. No budget or timeline is stated, so capital efficiency and staged commitment matter. The Newark manufacturing location is a fixed requirement.

**Domain and Tone:** Commercial medical diagnostics and life-science hardware. The tone is business and venture-style, aspirational and product-focused, within a heavily regulated, evidence-driven domain (FDA, CLIA, ISO 13485).

**Holistic Profile:** A high-ambition, high-risk, capital-intensive commercial medtech venture built on an unvalidated headline claim and a fixed Newark manufacturing commitment. Success depends less on the boldness of the vision than on staging evidence, regulatory progress and factory investment so that a technical failure in one cluster or step cannot take down the whole company, while still delivering a real manufactured product from Newark.

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Pragmatic Foundation
**Strategic Logic:** Build a modular cartridge family whose clusters can be validated, cleared and sold one at a time, with the 500-test figure presented as a cumulative menu. Pharma and research customers plus grants fund the evidence base, while Newark takes on only the highest-risk step (reagent formulation and cartridge filling) and established suppliers handle molding and instrument assembly. This balances progress against a single point of failure and keeps fixed cost proportional to demonstrated yield.

**Fit Score:** 8/10

**Why This Path Was Chosen:** Keeps the 500-test ambition as a cumulative menu, isolates yield risk with modular cartridges, funds evidence through pharma and grants, and puts Newark to work on the highest-risk step (reagent formulation and filling) while fixed cost tracks demonstrated yield. Residual risks are several consumables per collection, a slower 510(k) path and a pharma beachhead that may not justify Newark capacity.

**Key Strategic Decisions:**

- **Assay Panel Architecture:** Develop a family of modular cartridges, each running a validated cluster of related analytes from the same capillary sample, and market the 500-test figure as a cumulative menu rather than one run.
- **Regulatory Route and Sequencing:** File staged per-analyte or per-cluster 510(k) or De Novo submissions beginning with the best-characterized assays, and build the menu through successive clearances.
- **Newark Manufacturing Build-Out Timing:** Stand up Newark first as a reagent formulation and cartridge-filling site, the highest-risk step, while outsourcing injection-molded parts and instrument assembly to established suppliers.
- **Funding Path and Commercial Beachhead:** Sell the platform first as a research-use or clinical-trial biomarker tool for pharmaceutical sponsors, using contract revenue and non-dilutive grants to fund the move into clinical diagnostics.
- **Cartridge Fluidic Architecture and Integration Depth:** Split the workflow into a small family of specialized cartridges, each serving one assay class from the same drop, accepting several consumables per collection.

**The Decisive Factors:**

- **Matches ambition with realism:** it keeps the 500-test goal as a cumulative menu and the device-plus-Newark manufacturing premise, while validating analyte clusters one at a time.
- **Contains risk:** modular cartridges avoid a single point of failure. Newark takes on only reagent formulation and filling, so fixed cost follows demonstrated yield.
- **Fits the complexity:** staged 510(k)/De Novo clearances and pharma/grant revenue pay for evidence without early over-claiming.
- **Pioneer's Gambit:** monolithic cartridge, early factory fit-out and venture pressure to claim 500 tests could all fail together before the design is proven.
- **Consolidator's Lab-First Path:** safest financially, but it moves measurement off-device and defers Newark, which departs from the plan's product and manufacturing intent and may cap the market.

---
## Alternative Paths
### The Pioneer's Gambit
**Strategic Logic:** Commit to the full single-device, single-loading-step vision and fund it with broad venture capital. Reduce regulatory uncertainty by agreeing a comprehensive evidence package with FDA early (Breakthrough eligibility for a broad screening claim is not verified), and build Newark capacity alongside the design team to compress learning cycles. This accepts that a monolithic cartridge, early fixed cost and an unfrozen design can fail together if yield or analytical performance falls short.

**Fit Score:** 3/10

**Assessment of this Path:** Matches the stated ambition of one device, one loading step and early Newark build-out, but stacks every failure mode together: a monolithic cartridge, fixed cost around an unfrozen design, and venture pressure to claim 500 tests before the evidence exists. It is also internally inconsistent, pairing a narrow single-chemistry immunoassay menu with a broad screening story.

**Key Strategic Decisions:**

- **Assay Panel Architecture:** Commit to a single multiplexed immunoassay array platform and expand the analyte count incrementally, accepting a narrower menu to keep the cartridge design and manufacturing process unified.
- **Regulatory Route and Sequencing:** Seek Breakthrough Device designation and early Pre-Submission meetings to agree on a single comprehensive evidence package with FDA before committing to full-scale manufacturing.
- **Newark Manufacturing Build-Out Timing:** Lease and fit out a pilot cleanroom and assembly line in Newark at the start, and develop the cartridge process there alongside the design team.
- **Funding Path and Commercial Beachhead:** Raise venture capital against a broad consumer and clinical-screening vision and build the full stack, from assays to manufacturing, under one company before generating meaningful revenue.
- **Cartridge Fluidic Architecture and Integration Depth:** Build one monolithic injection-molded cartridge that integrates plasma separation, reagent storage, mixing, and detection chambers so the operator performs a single loading step.

### The Consolidator's Lab-First Path
**Strategic Logic:** Minimize capital at risk by using proven high-plex measurement in a centralized CLIA lab, while the device collects and stabilizes the drop and ships it to that lab. The company launches a narrow physician-ordered panel under an existing reimbursement code, on the LDT route, which has reverted to enforcement discretion since FDA rescinded its 2024 LDT rule in September 2025 ([source](https://clpmag.com/lab-management/compliance/fda-withdraws-final-rule-regulating-lab-developed-tests-medical-devices/)). Newark is opened only after the design is frozen and verification builds show stable yields. This defers the instrument-sales and 500-on-one-device claims in exchange for earlier revenue and lower fixed cost.

**Fit Score:** 5/10

**Assessment of this Path:** Lowest capital at risk and fastest revenue via the CLIA/LDT route, which is currently viable (verified). However, off-device mass-spectrometry measurement and deferring Newark until after design freeze abandon the plan's core premise of a device that runs the tests and is mass-produced in Newark, and a narrow reimbursed panel may be too small a business.

**Key Strategic Decisions:**

- **Assay Panel Architecture:** Pair a drop-volume sample preparation step with a centralized mass-spectrometry proteomics lab, so the device collects and stabilizes the sample while the high-plex measurement happens off-device.
- **Regulatory Route and Sequencing:** Launch first as a CLIA-certified laboratory service running the device in-house under the LDT pathway, and pursue FDA submissions later for the instrument and cartridge as a commercial product.
- **Newark Manufacturing Build-Out Timing:** Use a contract manufacturer for early clinical-lot cartridges and open the Newark line only after the design is frozen and verification builds have shown stable yields.
- **Funding Path and Commercial Beachhead:** Pursue a narrow, physician-ordered panel with an existing reimbursement code in one disease area, and expand the menu only as payer coverage and clinical evidence accumulate.
- **Cartridge Fluidic Architecture and Integration Depth:** Move fluidic complexity into a precision reusable reader head that pairs with low-cost disposable capture strips, keeping the consumable deliberately simple and the instrument carrying the engineering burden.
