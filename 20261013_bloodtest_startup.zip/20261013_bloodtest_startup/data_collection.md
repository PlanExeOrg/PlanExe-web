## 1. Analytical Feasibility and Cross-Reactivity Validation for Cluster 1 (10–15 Analytes)

Analytical feasibility is the highest-risk technical gate and the single point of failure for the cumulative-menu strategy. Cross-reactivity, plasma separation, reagent stability, and pilot-scale yield are tightly coupled: failure in any one cascades to all clusters and invalidates the 500-analyte modular hypothesis. This data collection gates all downstream investment (Newark, clinical studies, regulatory pathway). Without completion by Month 6 (2027-04-13), Series A Tranche 1 release is deferred, regulatory alignment is missed, and the company risks sunk-cost escalation into infeasible analyte architectures.

### Data to Collect

- Cross-reactivity matrix: each analyte alone, in pairs, and in full multiplex, spiked with hemoglobin, bilirubin, lipemia, rheumatoid factor at 10× physiologic concentration; bias acceptance ≤5%
- Plasma separation yield and purity from fingerstick samples (≥100 subjects); target ≥95% yield of ≥1.6 µL usable plasma; hemolysis control (index <50)
- Reagent lot-to-lot consistency (CV <10% across 3+ consecutive production lots) and stability (Arrhenius projection ≥12 months at 2–8°C, R² >0.90)
- Cartridge manufacturing yield at pilot scale (≥5 batches × 1,000 units; target ≥85%, acceptance ≥80% lower CI) and analyte metering accuracy within cartridge
- Cluster 1 analyte list (10–15) finalized with clinical rationale and cross-reactivity risk assessment; documented Analyte Removal Log for any analytes failing thresholds

### Simulation Steps

- Use literature cross-reactivity data (PubMed, antibody supplier datasheets) to pre-screen Cluster 1 analyte pairs for known incompatibilities (Month 1–2 = 2026-11-13 to 2026-12-13); flag high-risk pairs for priority testing
- Run a rapid cross-reactivity feasibility study in spiked human plasma using an ISO/IEC 17025 accredited lab or internal pilot (if available); measure each analyte pair and full plex at interference levels; document recovery and CV per analyte per interferent (Months 3–6 = 2027-01-13 to 2027-04-13)
- Model plasma separation using published microfluidic designs (CFD simulation tools: COMSOL, ANSYS Fluent) and prototype filters (passive wicking, acoustic separation); test with ≥20 fingerstick samples under realistic collection conditions (Month 4–5 = 2027-02-13 to 2027-03-13)
- Conduct an Arrhenius shelf-life study: store Cluster 1 reagents at 2–8°C (real-time), 25°C/60% RH, and 37°C (accelerated); sample at 0, 1, 3, 6, 9, 12 months (real-time) and 1–16 weeks (accelerated); measure analyte recovery (%) and assay CV per time point; fit exponential decay model (R² >0.90) to project shelf-life (Months 3–12 = 2027-01-13 to 2027-10-13)
- Conduct a pilot cartridge fill (1,000–5,000 units) at a contract manufacturer or phase 1 Newark lab using production-equivalent processes; measure first-pass yield, analyte recovery per cartridge, and metering accuracy across units; test 3 consecutive reagent lots for consistency (Month 9 = 2027-07-13)

### Expert Validation Steps

- Have an external assay chemistry expert (Ph.D. in analytical or assay chemistry, ≥10 years IVD immunoassay experience) review the cross-reactivity protocol and results; sign-off required on analyte removal decisions and acceptance criteria; validate that ≤5% bias threshold is defensible to FDA
- Request FDA Pre-Submission feedback (held by Month 6 = 2027-04-13) on: (a) acceptability of the cross-reactivity testing matrix and bias thresholds, (b) expectations for multiplex analytical validation, (c) whether per-analyte or panel-level concordance is required. Document FDA's specific feedback in writing
- Have an external plasma-separation engineer or point-of-care device expert review the plasma-separation protocol and pilot results; confirm that ≥95% yield is achievable at fingerstick collection rates and hemolysis is controlled to specification
- Engage a stability-testing expert (Ph.D. in pharmaceutical sciences or assay formulation chemistry, ≥8 years shelf-life experience) to review the Arrhenius protocol, model fit (R² calculation), degradation pathways, and shelf-life projection; validate R² >0.90 and advise on confidence interval for the 12-month claim
- Contract a contract-manufacturing partner or pilot-fill service provider (established medical-device or IVD cartridge experience) to execute the pilot fill; provide monthly yield and quality reports; flag any design-for-manufacturability (DFM) issues or tolerance stack-up problems

### Responsible Parties

- Assay Chemistry Lead (hire or contract by Month 1 = 2026-11-13; owns Cluster 1 analyte selection, cross-reactivity protocol, shelf-life testing)
- R&D Director (overall feasibility study coordination and design-control documentation)
- Quality/Regulatory Lead (FDA Pre-Submission preparation, ISO 13485 design-input documentation, gate-criteria evidence)
- External assay chemistry expert (review protocol, validate analyte removal decisions, sign-off on FDA submissions)
- External stability/formulation expert (Arrhenius modeling, shelf-life projection, FDA guidance alignment)
- Contract manufacturing or pilot-fill service provider (execute pilot fill, yield reporting, DFM feedback)

### Assumptions

- **High:** Cross-reactivity of ≤5% bias at 10× interferent concentration is achievable for all 10–15 analytes in Cluster 1 without major reformulation or analyte removal; literature and supplier data suggest low-risk pairs.
- **High:** Plasma separation yield of ≥95% is achievable from fingerstick capillary collection without active centrifugation or acoustic separation; passive wicking or simple filtration suffices.
- **High:** Shelf-life of ≥12 months at 2–8°C can be achieved with standard reagent formulation (buffer, stabilizers, surfactants); no novel preservation chemistry or cartridge engineering is required.
- **Medium:** Cartridge manufacturing pilot yield of ≥85% is attainable at contract molders using standard injection-molding and cartridge-bonding processes; no custom fluidic engineering or proprietary bonding method is necessary.
- **High:** Cluster 1 definition (10–15 analytes) is stable from Month 2 (2026-12-13) through Month 18 (2028-04-13); cross-reactivity findings do not force removal of >3 analytes or require scope narrowing to <10 analytes.

### SMART Validation Objective

By Month 6 (2027-04-13), complete a quantitative cross-reactivity matrix for Cluster 1 (10–15 analytes) measured in spiked plasma with hemoglobin, bilirubin, lipemia, and rheumatoid factor at 10× physiologic concentration, documenting ≤5% bias for all analyte pairs (acceptance criterion); conduct ≥100-subject plasma-separation pilot (≥95% yield of ≥1.6 µL usable plasma) and initiate 12-month Arrhenius shelf-life study (target projection ≥12 months, R² >0.90). Complete pilot cartridge fill (1,000–5,000 units, Month 9 = 2027-07-13) with ≥85% first-pass yield and lot CV <10%. Document all results (pass/ambiguous/fail) and any analyte removals in an Analyte Removal Log for FDA submission. Gate decision at Month 12 (2027-10-13): proceed to clinical enrollment if all thresholds met; if any failed, reform and retest within 2 weeks or remove analyte permanently.

### Notes

- Cross-reactivity is the highest-probability failure mode; prioritize this study in Month 1–2 (2026-11-13 to 2026-12-13) analyte selection to de-risk Month 6 (2027-04-13) gate.
- Plasma separation and shelf-life studies run in parallel (Months 3–6 = 2027-01-13 to 2027-04-13) and (Months 3–12 = 2027-01-13 to 2027-10-13); allow time for iterative reformulation if early Arrhenius data show <12-month projection.
- Pilot fill results (Month 9 = 2027-07-13) inform the Month 12 (2027-10-13) gate and design-freeze decision; if yield <80%, pause manufacturing scale-up and conduct a 4-week design review before Month 15 (2028-01-13) re-pilot.
- Analyte Removal Log is a regulatory artifact; document technical reason for every analyte evaluated but not included in Cluster 1 to show rigorous downselection to FDA.
- FDA Pre-Submission feedback (Month 6 = 2027-04-13) may adjust acceptance criteria or require additional interferent testing; plan for 2-week retest cycle if FDA requests data on specific interferents not in the initial matrix.


## 2. Regulatory Pathway Confirmation and Clinical Study Design Alignment (510(k) vs. De Novo)

Regulatory pathway uncertainty (510(k) vs. De Novo) is the longest-pole item affecting funding and timeline. A De Novo pathway adds 12–18 months and USD 2–4M, moving clearance from Months 36–48 (2029-10-13 to 2030-10-13) to Months 48–66 (2030-10-13 to 2032-04-13). Clinical-study design must be co-developed with FDA feedback by Month 6 (2027-04-13) to avoid 12–18 month rework post-Month 12 (2027-10-13). Without early pathway confirmation and funding contingency, the company faces a capital and timeline cliff at Month 18–24 (2028-04-13 to 2028-10-13) if De Novo is confirmed late.

### Data to Collect

- FDA Pre-Submission Type B meeting response documenting: (a) regulatory pathway recommendation (510(k) or De Novo), (b) predicate device(s) if 510(k) suitable, (c) analytical evidence expectations (method comparison sample size, accuracy/precision thresholds, reference methods), (d) clinical-utility requirements (health-economic analysis, patient-relevant outcomes, comparative effectiveness)
- Clinical study protocol specification: intended-use claim, patient population, sample size justification with power analysis, primary and secondary endpoints, comparator reference methods, statistical analysis plan, inclusion/exclusion criteria, and enrollment timeline
- Timeline scenario models for both 510(k) (clearance Months 36–48 = 2029-10-13 to 2030-10-13) and De Novo (Months 48–66 = 2030-10-13 to 2032-04-13) with corresponding funding needs (Series A/B/C sizing, extended runway) and milestones
- Evidence package requirements from FDA (analytical validation scope, clinical study endpoints, quality-system maturity, software controls per IEC 62304, risk management per ISO 14971) and mapping to development milestones
- Fallback contingency plan if FDA indicates De Novo is likely: Series B expansion, clinical-study redesign, timeline extension, and resource reallocation

### Simulation Steps

- Conduct a predicate-device search (FDA PMDA database, FDA 510(k) summaries, published clearances) to identify comparator devices for a multiplex immunoassay panel; use FDA's classification guidance (IVD multiplex assay classification, clinical chemistry panel classification) to assess clearance pathway likelihood (Month 1–2 = 2026-11-13 to 2026-12-13)
- Prepare a Pre-Submission Type B meeting package: (a) device description and intended use, (b) 3–5 specific regulatory questions (510(k) feasibility, analytical evidence scope, clinical-study expectations), (c) proposed clinical-study protocol outline, (d) comparison to predicate device or discussion of novel device features. Use FDA's Pre-Submission guidance (FDA Form 1571) to structure the package (Month 2–3 = 2026-12-13 to 2027-01-13)
- Draft two clinical-study protocols in parallel: Protocol A (510(k) focus, analytical method comparison, 200–300 subjects, reference lab comparison, 8–12 week study) and Protocol B (De Novo focus, clinical-utility outcomes, 400–500 subjects, health-economic endpoints, 6-month follow-up). Use published clinical-trial design guidance (CONSORT) and FDA's diagnostics study guidance (FDA Guidance for IVD Method Comparison Studies)
- Model two funding and timeline scenarios using a 60-month cash-flow tool: Scenario A (510(k) pathway, clearance Month 36–48 = 2029-10-13 to 2030-10-13, total equity USD 15–20M) and Scenario B (De Novo, clearance Month 48–66 = 2030-10-13 to 2032-04-13, Series B expansion USD 3–5M, total USD 18–28M). Include regulatory consulting, clinical-study, and extended-runway costs
- Create a regulatory-evidence mapping document: for each FDA requirement (analytical accuracy, clinical validity, software validation, risk management), specify the development activity, timeline, and responsible owner; identify dependencies and critical-path items

### Expert Validation Steps

- Engage a senior FDA regulatory consultant (≥10 years CDRH device submissions experience) to review the Pre-Submission package and provide guidance on likelihood of 510(k) vs. De Novo pathway; request a preliminary assessment by Month 4 (2027-02-13) before the formal Pre-Submission is held (Month 6 = 2027-04-13)
- Hold the FDA Pre-Submission Type B meeting (request Months 2–3 = 2026-12-13 to 2027-01-13, hold by Month 6 = 2027-04-13); document all FDA feedback in writing (meeting minutes, follow-up correspondence); circulate to the board and development team by Month 7 (2027-05-13)
- Have a clinical-trial design expert (Ph.D. in biostatistics or epidemiology, ≥8 years diagnostic trial design experience) review both clinical-study protocols; provide feedback on sample-size calculations, statistical power, primary-endpoint selection, and alignment with FDA guidance; adjust protocols based on feedback by Month 9 (2027-07-13)
- Engage a health-economics expert to model the clinical-utility outcomes for the De Novo scenario (cost per diagnosis, cost per QALY, diagnostic accuracy vs. standard-of-care); present to the board and payers for feedback on whether the proposed clinical-study design supports coverage decisions
- Request an independent review of the regulatory pathway assessment by a second regulatory consultant or a senior advisor with FDA or CDRH connections; confirm that the recommended pathway (510(k) or De Novo) is aligned with the device's novelty and complexity

### Responsible Parties

- Quality/Regulatory Lead (owns FDA Pre-Submission preparation and execution; coordinates all regulatory correspondence)
- External FDA Regulatory Consultant (prepares Pre-Submission package, interprets FDA feedback, models 510(k) vs. De Novo timelines and requirements)
- Clinical Research Lead (drafts clinical-study protocols for both scenarios, coordinates with clinical advisors and FDA feedback interpretation)
- CFO/Finance Lead (models funding scenarios A and B; identifies Series B sizing and timing for De Novo contingency)
- Biostatistics Expert (reviews clinical-study design, validates sample-size calculations and statistical power)
- Board and Leadership Team (votes on regulatory pathway and funding contingency; approves clinical-study protocol by Month 9 = 2027-07-13)

### Assumptions

- **High:** A multiplex immunoassay panel claiming 50+ simultaneous analytes will be classified as a medical device requiring either 510(k) or De Novo review; CLIA LDT route is a fallback but not the primary regulatory path for device clearance and sales.
- **Medium:** A 510(k) pathway is more likely than De Novo for a multiplex cartridge platform if a reasonable predicate device exists (e.g., existing high-plex immunoassay systems); predicate-device search will identify comparators by Month 3 (2027-01-13).
- **Medium:** FDA Pre-Submission feedback is actionable and aligns with the team's proposed clinical-study design and evidence package; no major regulatory barriers emerge post-Month 6 (2027-04-13) that require redesign.
- **Medium:** Clinical-study protocol finalization and IRB approval can be completed by Month 10 (2027-08-13), allowing enrollment to begin by Month 12 (2027-10-13) without delays.
- **High:** De Novo pathway, if required, adds 12–18 months and USD 2–4M in additional clinical-evidence costs; Series B contingency funding will be available at Month 18 (2028-04-13) if De Novo is indicated.

### SMART Validation Objective

By Month 6 (2027-04-13), hold an FDA Pre-Submission Type B meeting with documented feedback confirming regulatory pathway (510(k) or De Novo) and clinical-study design expectations (sample size, endpoints, comparator methods, evidence scope). Develop and register two clinical-study protocols on ClinicalTrials.gov (510(k) and De Novo versions) with pre-specified endpoints and statistical analysis plans by Month 10 (2027-08-13). Model funding scenarios A (510(k), clearance Month 36–48 = 2029-10-13 to 2030-10-13) and B (De Novo, clearance Month 48–66 = 2030-10-13 to 2032-04-13) with corresponding Series A/B/C sizing by Month 6 (2027-04-13). If De Novo is indicated, activate Series B contingency (USD 3–5M for additional runway and clinical-study expansion) by Month 15 (2028-01-13). Gate decision at Month 6 (2027-04-13): proceed to clinical enrollment with locked protocol if FDA feedback is aligned; if misaligned, conduct protocol redesign (target completion Month 9 = 2027-07-13) and delay enrollment by 1–2 months.

### Notes

- Pre-Submission meeting must be scheduled early (request Months 2–3 = 2026-12-13 to 2027-01-13) to allow FDA 30-day response window and buffer for follow-up questions before Month 6 (2027-04-13) gate decision.
- FDA feedback on regulatory pathway is not binding but is highly predictive; a De Novo recommendation at Month 6 (2027-04-13) should trigger immediate Series B contingency planning.
- Clinical-study protocol registration on ClinicalTrials.gov before enrollment is a transparency and credibility requirement; pre-registration locks endpoints and statistical-analysis plan, preventing post-hoc analysis tweaking.
- Two parallel clinical-study protocols (510(k) and De Novo) run Months 0–9 (2026-10-13 to 2027-07-13); choose between them at Month 9 (2027-07-13) based on FDA feedback, and finalize the selected protocol by Month 10 (2027-08-13) for enrollment by Month 12 (2027-10-13).
- If FDA Pre-Submission reveals missing regulatory requirements (e.g., software validation per IEC 62304, cybersecurity risk assessment), plan for 2–4 week additional development work before Month 10 (2027-08-13) protocol finalization.


## 3. Unit Economics and Payer Coverage Validation (Net Revenue, COGS, Gross Margin Targets)

Unit economics are mathematically broken at current assumptions: a 50-analyte menu requiring 4–5 cartridges (USD 160–225 COGS) against USD 100–200 net revenue per panel yields negative to 20% gross margin, far below the 60% target. Without validation of net revenue and COGS ceiling by Month 6 (2027-04-13), the company risks building manufacturing capacity for a product payers will not fund or customers will not afford at any volume. This data informs both the Cluster 1 analyte selection (narrow to highest-value assays if revenue is low) and the Newark investment decision (capacity sizing depends on viable per-unit economics).

### Data to Collect

- Bottom-up cost-of-goods (COGS) model for Cluster 1 cartridge at volumes 1k, 10k, and 50k cartridges/month: material cost (injection-molded plastic, reagents, buffers, membranes), labor (filling, assembly, QC), facility overhead (depreciation, utilities, maintenance), and distribution cost (cold chain, packaging)
- Payer willingness-to-pay study: interviews with ≥10 payers (Medicare, Aetna, Anthem, UnitedHealth, regional plans) and ≥5 health systems documenting expected reimbursement rates, coverage likelihood, evidence requirements, and coding strategy (bundled CPT code, per-analyte codes, value-based contract)
- CPT code pathway analysis: comparison of three coding models (unbundled per-analyte, single bundled code, value-based contract) with estimated Medicare/payer reimbursement, net revenue after discounts, and volume assumptions required for breakeven
- Gross-margin sensitivity analysis: model three net-revenue scenarios (USD 50–100, USD 100–150, USD 150–200 per cartridge) against COGS model to calculate breakeven volume, time-to-profitability, and capital requirement impact
- Health-economic and comparative-effectiveness evidence: preliminary cost-per-diagnosis and cost-per-QALY models for the intended-use clinical case; identify whether health-economic value supports payer coverage at target price

### Simulation Steps

- Build a detailed bottom-up COGS model using actual quotes from suppliers (plastic molders, reagent vendors, filling-line equipment providers) for Cluster 1 cartridge; model material cost per unit, labor hours per cartridge (manual + semi-automated processes at different volume scales), and allocated facility overhead. Use cost-modeling software (e.g., Excel, Anaplan) or contract a manufacturing cost consultant to validate (Months 2–4 = 2026-12-13 to 2027-02-13)
- Conduct a payer coverage landscape survey: identify existing multiplex assay CPT codes (e.g., GeneSight, Myriad panels) and their CMS/payer reimbursement rates; use research databases (Optum, Evernorth, payer websites) and direct outreach to 10+ payer medical directors to ask: 'Would you cover a 50-analyte multiplex panel at USD 100, USD 150, or USD 200 per test if clinical evidence supports equivalent accuracy to reference standards?' Document responses by payer and indication (Months 3–6 = 2027-01-13 to 2027-04-13)
- Model three CPT coding pathways: (1) unbundled per-analyte codes (50 analytes × USD 20–50 each = USD 1,000–2,500 list price, 30–50% payer discount = USD 500–1,250 net per panel); (2) single bundled CPT code (RUC valuation process, estimated USD 75–150 per panel); (3) value-based contract (risk-bearing payer, per-patient annual payment or outcomes-based pricing). Calculate net revenue and margin for each pathway at 10k and 50k cartridges/month (Months 4–6 = 2027-02-13 to 2027-04-13)
- Use a sensitivity-analysis tool (e.g., Excel Data Table, Monte Carlo simulation) to model the impact of three net-revenue scenarios on breakeven volume and time-to-profitability: low (USD 50–100 per cartridge), mid (USD 100–150), high (USD 150–200). Assume COGS ranges USD 15–30 at different volumes and plot cumulative burn curves for each scenario (Months 2–6 = 2026-12-13 to 2027-04-13)
- Develop a preliminary health-economic model (decision tree or Markov model) comparing the multiplex cartridge to standard-of-care (individual tests or existing panels) for the lead clinical use case; estimate cost per diagnosis, diagnostic accuracy (sensitivity/specificity), and projected cost per QALY; present to 3–5 payers and ask whether the value proposition supports coverage at target price (Months 6–9 = 2027-04-13 to 2027-07-13)

### Expert Validation Steps

- Engage a manufacturing cost consultant (10+ years medical-device or diagnostics manufacturing experience) to review the bottom-up COGS model, validate assumptions (labor rates, material yields, facility allocation), and provide a third-party cost estimate at 10k and 50k cartridges/month. Confirm that USD 25 COGS ceiling at 10k/month is achievable or provide a revised estimate (Months 4–6 = 2027-02-13 to 2027-04-13)
- Have a senior payer contracting advisor or health-economics consultant (10+ years payer coverage negotiation experience) conduct the payer interviews; synthesize responses into a market-readiness report documenting realistic net-revenue floor and coverage likelihood by payer. Present findings to the board by Month 9 (2027-07-13)
- Engage a CPT coding expert (certified CPT coder with device experience) or the AMA RUC (Relative Value Scale Update Committee) consultant to model the three coding pathways and estimated Medicare reimbursement under each scenario; identify the pathway with the highest net revenue and lowest regulatory burden (Months 4–9 = 2027-02-13 to 2027-07-13)
- Request feedback from 2–3 major payers on the proposed clinical-study design's ability to support coverage: 'Does the planned method-comparison study meet your evidence requirements for coverage? What health-economic analysis would strengthen the coverage case?' Document feedback and adjust clinical-study design accordingly by Month 10 (2027-08-13)
- Have a health-economics expert (Ph.D. in health services research or economics, ≥8 years diagnostic-study experience) build and validate the preliminary health-economic model; peer-review the assumptions and results with at least one external payer health-economics team

### Responsible Parties

- Chief Product Officer or Commercial Lead (owns payer outreach, coverage-landscape analysis, and coding-strategy development; coordinates with CPT expert)
- CFO/Finance Lead (builds COGS model, models funding scenarios A/B/C sensitivity to net revenue; calculates breakeven volume and time-to-profitability)
- External Manufacturing Cost Consultant (validates bottom-up COGS model, provides third-party cost estimate at different volume scales)
- External Payer/Health Economics Consultant (conducts payer interviews, synthesizes coverage feedback, builds health-economic model, presents to board)
- External CPT Coding Expert (analyzes three coding pathways, estimates Medicare reimbursement, advises on coverage strategy)
- Quality/Regulatory Lead (ensures clinical-study design aligns with payer evidence requirements)

### Assumptions

- **High:** Bottom-up COGS model at 10k cartridges/month can achieve USD 25 per cartridge ceiling through material procurement, labor standardization, and facility overhead allocation; no novel manufacturing process or vertical integration is required.
- **High:** Payers will cover a 50-analyte multiplex bundle under a bundled CPT code or value-based contract at net reimbursement of USD 100–200 per panel if clinical evidence supports equivalent accuracy to reference methods; unbundled per-analyte coverage is achievable for ≥50% of analytes at USD 20–50 each.
- **Medium:** Health-economic value (cost per diagnosis, cost per QALY) supports payer coverage at the target price point; no comparative-effectiveness studies reveal that the multiplex cartridge increases overall cost of care through false positives and cascade testing.
- **High:** Gross-margin target of ≥60% at 50k cartridges/month is achievable if the company reaches USD 150–200 net revenue per cartridge and maintains COGS ≤USD 50 at that volume; breakeven volume is 2k–11k cartridges/month, feasible within the 12–24 month timeframe post-clearance.
- **Medium:** Payer coverage decisions are predictable based on clinical-study evidence and health-economic value; no systemic barriers (lack of CPT coding, prior-authorization restrictions, network limitations) will prevent or severely delay access to payers.

### SMART Validation Objective

By Month 9 (2027-07-13), validate net revenue and COGS assumptions by completing: (1) a bottom-up COGS model at 1k, 10k, and 50k cartridges/month with supplier quotes and third-party cost estimate (target USD 25 per cartridge at 10k/month); (2) payer willingness-to-pay interviews documenting net revenue floor (low/mid/high scenario) for a 50-analyte panel; (3) CPT coding pathway analysis (unbundled vs. bundled vs. value-based) with estimated Medicare/payer reimbursement under each; (4) gross-margin sensitivity analysis showing breakeven volume and time-to-profitability for each revenue scenario; (5) preliminary health-economic model (cost per diagnosis, cost per QALY) with payer feedback on coverage likelihood at target price. Gate decision at Month 9 (2027-07-13): if net revenue validates ≥USD 100–150 per cartridge at ≥50% payer coverage, proceed to Series A Tranche 2 release with full Newark Phase 2 plan; if net revenue is USD 50–100, trigger design-retreat review (narrow Cluster 1 from 50 to 20–30 analytes, remodel COGS and margin) and adjust Newark scale-up assumptions; if net revenue is <USD 50, escalate to board for contingency planning (pivot to CLIA lab service, pause device development, or seek strategic partnership).

### Notes

- COGS modeling must include actual supplier quotes for materials, not published benchmarks; contract with 2–3 injection-molding vendors and reagent suppliers by Month 4 (2027-02-13) to lock pricing.
- Payer interviews should be conducted by an expert (not internal team) to avoid bias and to build relationships for future coverage negotiations; document payer requirements in writing for use in clinical-study design refinement.
- CPT coding is complex and slow (RUC process 12–18 months); initiate discussions with the AMA RUC consultant by Month 4 (2027-02-13) to allow time for code application before FDA submission (Month 30 = 2029-04-13).
- Gross-margin target (≥60% at 50k/month) may be unrealistic for a medtech multiplex device in early post-launch volumes (typical range 40–50% at volume); propose realistic target of ≥40–50% at 10k/month and ≥50–60% at 50k/month based on industry benchmarks.
- Health-economic value is a payer gate for coverage; if preliminary model shows cost per QALY >USD 150k (payer threshold varies but USD 50k–150k is common), initiate clinical-study redesign to improve health-economic outcomes (e.g., faster diagnosis, fewer downstream tests) by Month 9 (2027-07-13).


## 4. Newark Phase 1 Facility Setup, Design-for-Manufacturability Review, and Pilot-Scale Manufacturing Feasibility

Newark Phase 1 is a critical early-stage gate requiring capital commitment (USD 500–800k) and operational execution 3–6 months after project start. DFM review and pilot-fill results at Month 9 (2027-07-13) inform the Month 12 (2027-10-13) analytical-feasibility gate yield criterion and the Month 18 (2028-04-13) design-freeze and Phase 2 capital-release decision. Without early DFM assessment and pilot validation, the company risks scaling to Phase 2 (USD 2–3M filling line) with a design that cannot achieve ≥85% yield, forcing expensive re-tooling (USD 50–150k, 3–4 months) or fallback to Fallback V1.

### Data to Collect

- Site identification and lease terms for Newark Phase 1 facility (2,000–3,000 sq ft, BSL-2 capable, 2–8°C controlled storage, cleanroom-adjacent or cleanroom-lite environment); budget USD 500–800k capex for reagent formulation lab, pilot-scale fill capacity, and lot-release QC equipment
- Design-for-Manufacturability (DFM) assessment from ≥2 contract molders and filling-equipment vendors: cartridge tolerance stack-up analysis, molding process capability (defect rate <5%, first-pass yield >90%), fluidic bonding method (ultrasonic, thermal, adhesive) and yield impact, reagent-filling process parameters (pressure, volume accuracy, filling speed, clog risk)
- Pilot-scale manufacturing run results (1,000–5,000 cartridges, Month 9 = 2027-07-13): first-pass yield per assembly step (molding, bonding, filling, testing), analyte metering accuracy, cartridge-to-cartridge consistency, and quality defects observed (categorized by root cause: molding, fluidic bonding, reagent-fill accuracy, QC failure)
- Long-lead equipment quotes and procurement timeline for Phase 2 filling-line (6–12 month lead times typical): automated filling machine, reagent-dispensing system, cartridge-indexing and testing equipment, environmental chambers (2–8°C storage, 37°C accelerated aging)
- Contract manufacturer or supplier quality agreements: defect rates, first-pass yield commitments, price-lock terms, capacity commitments (90-day forward forecasts), and contingency for supplier discontinuation or quality failure

### Simulation Steps

- Conduct a facility-site search in Newark, California (e.g., areas near Cherry Street, Central Avenue, Hayward/Union City industrial corridors) and identify 2–3 available properties (2,000–4,000 sq ft, BSL-2 or BSL-2 adaptable, zoned for light manufacturing and biological reagent handling); request quotes for lease (estimated USD 2,500–4,000/month = USD 30k–48k/year) and landlord's facility-upgrade allowance for cleanroom build-out (Month 1–2 = 2026-11-13 to 2026-12-13)
- Request design-for-manufacturability (DFM) review from ≥2 contract injection molders (e.g., established medtech suppliers in California, Asia, or Mexico) and ≥1 filling-system vendor: provide cartridge CAD, specify production volume ramp (100 units/month prototype, 1k–10k pilot, scale to 50k), and ask for feedback on tolerance requirements, tool cost, lead time, and estimated defect rate and first-pass yield. Use FEA (finite-element analysis) and mold-flow simulation to stress-test the design (Months 2–4 = 2026-12-13 to 2027-02-13)
- Execute a pilot-cartridge fill at Month 9 (2027-07-13) using a contract manufacturer or phase-1 Newark lab (if operational): produce 1,000–5,000 units using production-equivalent processes (same tooling, filling pressure/speed, reagent lot, and environmental conditions planned for scale-up). Measure first-pass yield per process step (molding defects, bonding failures, fill-accuracy rejects, QC failures); categorize defects and estimate rework/scrap (yield target ≥85%, acceptance ≥80% lower 95% CI)
- Create a long-lead equipment procurement plan: list equipment required for Phase 2 filling line (automated cartridge indexing, volumetric filling pumps, on-board QC testing, environmental chambers); request quotes from equipment vendors specifying 6–12 month lead times; flag items requiring binding orders by Month 18 (2028-04-13) to ensure delivery by Months 24–30 (2028-10-13 to 2029-04-13) for facility commissioning
- Negotiate quality agreements with contract molders and reagent suppliers: specify defect-rate acceptance (<5%), first-pass yield (>90%), and lot-consistency requirements (CV <10% across lots); request capacity commitments (90-day forward forecasts, 2-week lead-time guarantees); identify contingency suppliers and lead-time if primary supplier fails

### Expert Validation Steps

- Engage a manufacturing process engineer (10+ years medical-device cartridge assembly or diagnostics device manufacturing experience) to conduct the DFM review and evaluate mold-flow simulation results; provide feedback on tolerance stack-up risks, yield bottlenecks, and design modifications to improve manufacturability. Review pilot-fill results and root-cause analyze any yield-loss failures (Months 2–9 = 2026-12-13 to 2027-07-13)
- Have a contract manufacturer with established medical-device or IVD cartridge production experience execute the pilot fill (Month 9 = 2027-07-13); provide detailed yield and quality reports by process step; flag any DFM issues or unexpected defect modes that require design iteration
- Request facility-design review from a GMP compliance consultant (10+ years medical-device cleanroom and BSL-2 facility experience) to validate that the Phase 1 space meets ISO 13485 and CLIA environmental requirements (temperature/humidity control, air handling, segregation, materials); confirm that the facility can support reagent formulation and lot-release testing without FDA 483 observations
- Engage a procurement or supply-chain expert to manage equipment sourcing: validate vendor quotes, negotiate delivery terms and cancellation clauses (allow <10% forfeiture if order cancelled by Month 18 = 2028-04-13), and establish long-lead-item tracking dashboard. Confirm that binding orders are issued only at Month 18 (2028-04-13) after design freeze (Month 15–18 = 2028-01-13 to 2028-04-13)
- Have quality-system expert (ISO 13485 auditor) review contract-manufacturer quality agreements and supplier audit plans; ensure that quality agreements specify acceptance criteria, re-work procedures, and change-control processes aligned with FDA and ISO 13485 expectations

### Responsible Parties

- Manufacturing Engineering and Operations Lead (owns Newark facility site selection, DFM coordination, pilot-fill execution, equipment procurement; responsible for phase 1 go/no-go decision at Month 12 = 2027-10-13)
- Process Engineer or Manufacturing Consultant (conducts DFM review, analyzes pilot-fill results, identifies yield bottlenecks and design modifications)
- Contract Manufacturer Partner (executes pilot fill, provides yield and quality reporting, flags process issues)
- GMP Compliance Consultant (validates Newark facility design against ISO 13485 and CLIA requirements)
- Procurement/Supply-Chain Manager (manages equipment sourcing, long-lead-item tracking, vendor negotiations)
- Quality/Regulatory Lead (oversees supplier quality agreements, audit planning, and ISO 13485 readiness)

### Assumptions

- **Low:** Newark, California industrial space (2,000–3,000 sq ft) with BSL-2 or adaptable zoning is available at USD 2,500–4,000/month lease rate; landlord upgrade allowance or fit-out assistance is obtainable to reduce initial Phase 1 capex below USD 800k.
- **High:** Contract molders can achieve <5% defect rate and >90% first-pass yield on the proposed cartridge design using standard injection-molding and bonding processes; no proprietary fluidic engineering or custom bonding method is required.
- **Medium:** Pilot-scale manufacturing (1,000–5,000 cartridges) can be executed at Month 9 (2027-07-13) with a contract manufacturer or shared facility; no long-lead tooling or facility build-out delays push pilot to Month 12 (2027-10-13).
- **High:** Pilot yield of ≥85% is achievable without re-tooling or design iteration; if yield is 80–85% (marginal), a 2-week design review and retest by Month 12 (2027-10-13) resolves the issue without major delay.
- **Medium:** Long-lead equipment (filling line, indexing, QC systems) with 6–12 month lead times can be managed with binding orders at Month 18 (2028-04-13) to ensure delivery by Months 24–30 (2028-10-13 to 2029-04-13); no unexpected delays or supplier issues disrupt the timeline.

### SMART Validation Objective

By Month 6 (2027-04-13), complete DFM review with ≥2 contract molders and filling-equipment vendors; identify tolerance stack-up risks, yield bottlenecks, and design modifications required to achieve ≥85% pilot-scale yield. By Month 9 (2027-07-13), execute a 1,000–5,000 unit pilot fill at a contract manufacturer using production-equivalent processes; measure first-pass yield per process step and document all defects (molding, bonding, fill accuracy, QC) with root-cause analysis. Gate decision at Month 12 (2027-10-13): if pilot yield ≥85% (95% CI ≥80%), shelf-life projects ≥12 months, and no design changes needed, release Series A Tranche 2 for Phase 2 Newark fit-out (USD 2–3M) and proceed to fill-line equipment orders by Month 18 (2028-04-13). If yield 80–85% (marginal), conduct a 2-week design review (identify specific yield-loss steps and modifications), re-pilot 500–1,000 units by Month 15 (2028-01-13); if re-pilot achieves ≥85%, proceed to Phase 2; if not, activate Fallback V1 and pause full-scale manufacturing investment. If yield <80% or shelf-life <12 months, pause Phase 2 investment, conduct a 4-week comprehensive design review, and plan a revised pilot for Month 15–18 (2028-01-13 to 2028-04-13).

### Notes

- DFM review is concurrent with cross-reactivity and shelf-life studies (Months 2–9 = 2026-12-13 to 2027-07-13); no design changes should be made to the cartridge post-Month 6 (2027-04-13) without formal review and molder consultation.
- Pilot fill must use production-equivalent processes (same mold, filling system, reagent lot, environmental conditions) to represent scale-up behavior; hand-assembled prototypes or lab-scale processes will overestimate yield and mislead the Month 12 (2027-10-13) gate decision.
- Yield tracking must be granular: document first-pass yield per process step (molding %, bonding %, filling %, QC acceptance) so bottlenecks are clear and design iteration targets root causes.
- Long-lead equipment procurement timeline is critical; quotes must be requested by Month 3 (2027-01-13) and binding orders issued by Month 18 (2028-04-13) to ensure delivery by Months 24–30 (2028-10-13 to 2029-04-13) for Phase 2 commissioning and clinical cartridge production (Months 30–36 = 2029-04-13 to 2029-10-13).
- Phase 1 facility (reagent lab, pilot fill) should be operationalized by Month 12 (2027-10-13) to support pilot-scale production and lot-release QC; this is smaller and lower-risk than Phase 2, allowing early validation of the Newark site and team readiness.


## 5. Clinical Method-Comparison Study Design, Enrollment, and Interim Concordance Validation

Clinical-study results are the evidentiary backbone of FDA submissions and payer coverage decisions. Enrollment must begin by Month 12 (2027-10-13) to deliver interim concordance by Month 18 (2028-04-13) and final results by Month 24 (2028-10-13), in time for FDA submission (Month 30 = 2029-04-13). Any analyte failing the ≥95% concordance threshold must be identified by Month 18 (2028-04-13) so it can be removed before design freeze (Month 18 = 2028-04-13) without forcing a study re-design. Clinical utility is the ultimate measure of value; health-economic modeling and payer feedback during the study ensure that the data collected support coverage decisions.

### Data to Collect

- Clinical study protocol specification: intended-use claim, target patient population (healthy and disease states), sample-size justification with statistical power calculation, primary endpoints (concordance ≥95% lower CI ≥93%, analyte-specific accuracy), reference-method comparators (established lab methods, commercial IVD comparators, or clinical-gold-standard), inclusion/exclusion criteria, enrollment timeline, and statistical analysis plan
- Study site activation and enrollment timeline: ≥2 clinical partner sites (academic medical center or reference lab) with IRB approval and informed-consent documentation; enrollment rate forecast (subjects/month) and cumulative enrollment status (observed vs. projected) at Months 12, 15, 18 (2027-10-13, 2028-01-13, 2028-04-13); projected completion by Month 24 (2028-10-13)
- Interim concordance analysis results (Month 18 = 2028-04-13, ≥150–200 enrolled subjects): per-analyte and panel-level agreement with reference method, bias and precision (CV) estimates with 95% confidence intervals, subgroup analysis (healthy vs. disease, different sample collection methods), adverse events or study terminations
- Analyte-level clinical utility assessment: for each Cluster 1 analyte, measure clinical sensitivity/specificity, positive/negative predictive values, and clinical decision-change frequency (% of results that would change clinical management vs. standard-of-care); identify low-utility analytes for potential removal pre-design-freeze
- Clinical site performance metrics: enrollment rate per site per month, data quality (missing data rate, protocol violations), sample-integrity issues (hemolysis, clotting, contamination), and reference-lab turnaround time and result agreement

### Simulation Steps

- Develop a detailed clinical-study protocol using FDA guidance documents (Guidance for Clinical Laboratory Improvement Act (CLIA) Laboratory-Developed Tests, Guidance for IVD Method Comparison Studies) and published diagnostic-accuracy study standards (CONSORT-AI, STARD). Specify: intended-use claim (e.g., 'screening for metabolic and cardiovascular risk in asymptomatic adults'), patient population (age, gender, disease-state distribution), sample size calculation (assuming 95% concordance with reference, 90% power, 5% significance level; estimated 200–500 subjects depending on rare analytes), primary and secondary endpoints, reference methods for each analyte (lab method specifications), and statistical analysis plan (agreement measures: Pearson correlation, Bland-Altman plot, concordance rate) (Months 2–6 = 2026-12-13 to 2027-04-13)
- Register the clinical study protocol on ClinicalTrials.gov before enrollment begins; pre-specify all endpoints and statistical-analysis plan to prevent post-hoc analysis adjustments; include the protocol in the FDA Pre-Submission package (Month 6 = 2027-04-13) for feedback
- Identify and activate ≥2 clinical study sites (academic medical centers or large reference laboratories) with established IRB review, clinical-specimen collection capability, and research-blood-banking services; execute site agreements specifying enrollment targets (e.g., 100–150 subjects per site over 6–9 months), data-sharing and publication rights, and quality/compliance expectations; complete IRB reviews and informed-consent approval by Month 10 (2027-08-13)
- Conduct an interim concordance analysis at Month 18 (2028-04-13) after ≥150 subjects are enrolled and ≥100 are fully analyzed (analyte data from both device and reference method available). Calculate per-analyte Pearson correlation, Bland-Altman bias and limits-of-agreement, and concordance rate (% meeting >95% agreement criterion). For each analyte, stratify by disease state and sample-collection method to identify subgroup biases or failures. Document any analyte failing the ≥95% concordance threshold and flag for potential removal or redesign (Months 18–24 = 2028-04-13 to 2028-10-13)
- Use preliminary clinical data (Months 18–24 = 2028-04-13 to 2028-10-13) to build a preliminary health-economic model: estimate cost per diagnosis, cost per clinically actionable result, and impact on downstream testing (fewer follow-up tests, faster diagnosis, treatment decision changes). Share with payers for feedback on clinical-utility value (Months 18–24 = 2028-04-13 to 2028-10-13)

### Expert Validation Steps

- Have a clinical-trial design expert (Ph.D. in biostatistics or epidemiology, ≥8 years diagnostic-accuracy study experience) review the protocol for statistical power, sample-size calculation, and primary-endpoint selection. Request external review to ensure the design meets FDA expectations for method-comparison studies (e.g., sample size ≥200 per group if comparing to multiple reference methods, appropriate control of multiplicity if testing multiple analytes)
- Engage an IRB-coordinating center or clinical-research organization (CRO) to manage study site activation, protocol amendments, and IRB communications; ensure that all 21 CFR 11 (electronic records/signatures), HIPAA privacy, and informed-consent requirements are met
- Request FDA feedback on the clinical-study protocol during the Pre-Submission meeting (Month 6 = 2027-04-13): 'Does the proposed method-comparison study meet your expectations for analytical validation? Are the sample size, reference methods, and concordance thresholds acceptable?' Incorporate FDA feedback into final protocol by Month 9 (2027-07-13) before enrollment begins
- Have an independent statistician (not employed by the company) review the interim concordance analysis (Month 18 = 2028-04-13) to validate the calculation of agreement measures, bias estimates, and 95% confidence intervals. Confirm that any analyte flagged as failing thresholds is correctly identified and documented
- Engage a clinical-advisory panel (5–7 physicians from relevant specialties) to review interim concordance results and provide feedback on clinical utility: 'For each analyte, how would the device result influence clinical decision-making compared to standard-of-care?' Use feedback to identify low-utility analytes for removal pre-design-freeze

### Responsible Parties

- Clinical Research Lead (owns protocol development, site activation, enrollment coordination, interim analysis)
- External Clinical-Trial Design Expert and Biostatistician (reviews protocol design, validates interim-analysis calculations, ensures FDA alignment)
- Clinical Research Organization (CRO) or IRB Coordinator (manages site activation, IRB approvals, 21 CFR 11 compliance, data management)
- Clinical Study Sites (≥2 academic or reference-lab partners; enroll subjects, collect specimens, coordinate reference-lab testing, report data)
- Clinical Advisory Panel (5–7 physicians; review interim results, assess clinical utility, flag low-utility analytes)
- Health-Economics Expert (builds preliminary health-economic model, engages payers for coverage feedback)

### Assumptions

- **Medium:** Clinical-study protocol design and IRB approval can be completed by Month 10 (2027-08-13), allowing enrollment initiation by Month 12 (2027-10-13) without delays.
- **Medium:** ≥2 clinical study sites with adequate specimen-collection volume (100+ subjects per site over 6–9 months) are available and can be activated; no site activation delays push enrollment start beyond Month 12 (2027-10-13).
- **High:** Cluster 1 analytes will achieve ≥95% concordance (lower CI ≥93%) with established reference methods in ≥150–200 enrolled subjects; no analyte will fail concordance and require removal post-Month 18 (2028-04-13).
- **Medium:** Interim concordance analysis (Month 18 = 2028-04-13) is adequate for go/no-go decision on design freeze (Month 18 = 2028-04-13); final concordance results (Month 24 = 2028-10-13) align with interim findings and do not reveal new analyte failures.
- **Medium:** FDA Pre-Submission feedback on clinical-study design (Month 6 = 2027-04-13) is actionable and aligns with the proposed protocol; no major FDA concerns about study design or endpoints emerge post-Month 6 (2027-04-13).

### SMART Validation Objective

By Month 10 (2027-08-13), finalize clinical-study protocol (sample size ≥300–500 subjects, per-analyte concordance primary endpoints, ≥2 study sites activated with IRB approval). Register protocol on ClinicalTrials.gov with pre-specified endpoints. By Month 12 (2027-10-13), initiate enrollment (target 50–100 subjects/month). By Month 18 (2028-04-13), complete interim concordance analysis (≥150–200 subjects enrolled): measure per-analyte concordance ≥95% (lower CI ≥93%), bias <10%, and CV <10% vs. reference method (acceptance criteria). Gate decision at Month 18 (2028-04-13): if all analytes meet concordance thresholds, proceed to design freeze and continued enrollment for final analysis (Month 24 = 2028-10-13). If ≤2 analytes fail (marginal, 93–95% concordance), flag for potential removal and assess clinical utility; if ≥3 analytes fail (concordance <93%), conduct a root-cause review and consider analyte removal or assay redesign (3–4 week delay, revisit Month 21 = 2028-07-13). By Month 24 (2028-10-13), complete final analysis and publish interim results (at least in company submission, with peer-reviewed publication target Month 30 = 2029-04-13). Build preliminary health-economic model and present to 3 payers; document payer feedback on coverage likelihood and pricing support.

### Notes

- Protocol registration on ClinicalTrials.gov before enrollment is a transparency and credibility requirement; it locks endpoints and prevents post-hoc analysis tweaking.
- FDA Pre-Submission feedback (Month 6 = 2027-04-13) should align with protocol design; any misalignment triggers a 2-week protocol amendment before IRB submission (Month 7 = 2027-05-13), to avoid 4-week IRB review delays post-Month 10 (2027-08-13).
- Interim concordance at Month 18 (2028-04-13) must be completed and reviewed by a non-company statistician to avoid bias in analyte-removal decisions; any removal recommendation goes to the clinical advisory board and company leadership for vote before design freeze (Month 18 = 2028-04-13).
- Analyte clinical utility (sensitivity/specificity, diagnostic accuracy, impact on treatment decisions) is assessed during the study; payers will request this data for coverage; ensure clinical sites are prompted to collect data on clinical decision-change events and patient outcomes where available.
- Health-economic model during the study (Months 18–24 = 2028-04-13 to 2028-10-13) should include preliminary cost-per-diagnosis, cost-per-QALY, and diagnostic-accuracy estimates; share with payers to gather early feedback on coverage likelihood and pricing ceiling, informing the final clinical-study design and health-economic evidence package for FDA submission.


## 6. Supplier Qualification, Dual Sourcing, and Supply-Chain Continuity for Critical Reagents and Contract Manufacturing

Supplier quality and continuity are foundational to manufacturing scale-up and regulatory compliance. A single-supplier discontinuation, quality failure, or price increase can halt production for 4–8 weeks and cost USD 100–500k in scrap, expedited buys, and lost revenue. Dual-source qualification by Month 6 (2027-04-13) ensures that backup suppliers are pre-qualified and tested before Months 9–12 (2027-07-13 to 2027-10-13) pilot production; a buffer inventory (USD 20–30k) provides 2–3 weeks of supply continuity if a primary supplier fails. Monthly supplier-performance tracking and an escalation protocol (activate backup supplier within 2 weeks if defect rate exceeds 10%) prevent quality surprises from cascading into production delays.

### Data to Collect

- Critical-supplier mapping for Cluster 1 (10–15 analytes): identify all suppliers of antibodies, enzymes, probes, or synthetic binders per analyte; assess financial stability, quality-system maturity (ISO 13485, ISO 9001), and sole-source exposure; document supplier certifications (CoA, stability data, purity/potency testing)
- Dual-source qualification results for top 10 analytes: ≥2 qualified suppliers per analyte with executed quality agreements specifying defect-rate acceptance (<5%), lot-consistency requirements (CV <10%), price-lock terms (3-year stable pricing or ≤2–3% annual escalation), and capacity commitments (90-day forward forecasts, 2-week lead-time guarantee)
- Contract-manufacturer quality agreements: defect-rate acceptance (<5% per-unit defect, >90% first-pass yield), re-work procedure, lot-release criteria, change-control process, audit schedule, and contingency supplier activation timeline if primary manufacturer fails (target 2-week activation)
- Reagent supply-chain inventory plan: 4–6 week buffer inventory of critical reagents (estimated USD 20–30k inventory cost); storage conditions (2–8°C temperature control, humidity logging), first-in-first-out (FIFO) rotation, and expiration-date tracking; monthly inventory review and reorder forecasting
- Supplier performance scorecard: monthly tracking of defect rate (target <5%), delivery (on-time %), price (inflation tracking), and quality-issue resolution time; escalation protocol if a supplier exceeds 10% defect rate for 2 consecutive months (trigger backup supplier activation)

### Simulation Steps

- Conduct a critical-reagent supply-chain assessment: map all suppliers for Cluster 1 analytes (antibodies, enzymes, buffers, stabilizers, membranes, molding resin, filling-system consumables). For each supplier, document: financial stability (SEC EDGAR filings, Dun & Bradstreet rating), quality certifications (ISO 13485, ISO 9001, cGMP), production capacity (annual volume in units or mg), and sole-source risk (whether substitute is available). Identify suppliers with single-source or high-concentration risk (e.g., only one supplier of a specific monoclonal antibody); flag for dual-source plan (Months 1–3 = 2026-11-13 to 2027-01-13)
- Identify and contact ≥2 alternative suppliers for each of the top 10 highest-risk analytes (those with smallest order volumes, shortest supplier history, or most specialized capture chemistry); request quotes, samples for compatibility testing, and willingness to accept a quality agreement with defect-rate and CV requirements. By Month 4 (2027-02-13), execute binding quality agreements with ≥2 suppliers per critical analyte (Months 3–6 = 2027-01-13 to 2027-04-13)
- Develop a supplier quality agreement template (covering price, defect rate <5%, first-pass yield >90%, lot-consistency CV <10%, 3-year price lock or ≤2–3% annual escalation, 90-day forward forecasting, 2-week lead-time commitment, re-work procedures, change-notification process, audit rights). Execute with all critical suppliers by Month 6 (2027-04-13); distribute to quality team for quarterly review
- Build a reagent inventory-management spreadsheet: track current stock levels (by lot, supplier, expiration date, temperature/humidity storage), reorder points (based on usage rate and supplier lead time), and monthly consumption forecast (based on manufacturing plan). Set a target inventory of 4–6 weeks of critical reagents (estimated USD 20–30k); update monthly and conduct rotation per FIFO protocol (Month 1 = 2026-11-13 onward)
- Create a supplier-performance scorecard: track monthly defect rate (%), on-time delivery (%), price inflation (%), and quality-issue resolution time. Establish escalation protocol: if any supplier exceeds 10% defect rate for 2 consecutive months, issue a corrective-action request (CAR) and activate backup supplier within 2 weeks (Months 6 = 2027-04-13 onward)

### Expert Validation Steps

- Have a quality/supply-chain expert (10+ years medical-device supplier management experience) conduct the critical-reagent assessment and validate the dual-source qualification plan. Review proposed suppliers' quality certifications and financial stability; provide risk rating (low/medium/high sole-source risk) for each analyte
- Engage a contract-manufacturer auditor (ISO 13485 experience, FDA inspection familiarity) to audit the proposed contract molders and filling-service providers (≥2 facilities) by Month 6 (2027-04-13); document quality-system maturity, process controls, defect data, and capacity. Request audit reports and quality agreements before tooling commitments
- Request supplier references from established diagnostics or medical-device companies that use the same reagent suppliers; validate supplier quality, delivery, and responsiveness with reference customers
- Have an inventory-management consultant review the 4–6 week buffer-inventory plan; validate that inventory levels are adequate for pilot and clinical-scale manufacturing without excessive carrying cost or storage risk (USD 20–30k is reasonable for a startup, equivalent to 2–3 weeks at 10k cartridges/month)
- Require all critical suppliers to provide written stability data (Certificates of Analysis, shelf-life, storage conditions) and commit to routine stability monitoring and lot-release testing per written protocol; include these requirements in quality agreements

### Responsible Parties

- Supply-Chain and Partner Management Lead (owns critical-supplier assessment, dual-source qualification, quality agreements)
- Quality/Regulatory Lead (oversees supplier audit planning, quality-agreement sign-off, incoming-lot acceptance criteria, monthly performance review)
- Assay Chemistry Lead (specifies reagent quality requirements, evaluates alternative suppliers for compatibility, validates substitute suppliers)
- Manufacturing Engineering Lead (qualifies contract molders, negotiates quality agreements, establishes supplier performance scorecard)
- External Supply-Chain and Quality Consultants (audit suppliers, validate risk assessments, provide third-party certification of supplier readiness)

### Assumptions

- **Medium:** Dual-source suppliers for critical reagents (≥2 per analyte) can be identified and qualified by Month 6 (2027-04-13) without major delays or compatibility issues; substitute suppliers deliver equivalent or superior quality at comparable price.
- **Medium:** Contract molders and reagent suppliers accept quality agreements with defect-rate <5% and lot-consistency CV <10% requirements; these thresholds are achievable with standard manufacturing processes and do not require proprietary or expensive controls.
- **Low:** A 4–6 week buffer inventory of critical reagents (estimated USD 20–30k) is economically feasible and does not exceed startup capital constraints; storage conditions (2–8°C controlled environment) are available at Phase 1 Newark lab or external storage facility.
- **Medium:** Suppliers are responsive to quality escalations and can activate backup/alternative manufacturing within 2–4 weeks if primary supplier fails; no single reagent or component lacks a substitute source.
- **Low:** Supplier performance monitoring (monthly scorecard, defect-rate tracking, price inflation) is operationally feasible and does not require significant data-collection overhead; defect-rate data are accurate and comparable across suppliers.

### SMART Validation Objective

By Month 6 (2027-04-13), complete critical-reagent supply-chain assessment for Cluster 1; identify sole-source suppliers and high-risk analytes. Identify and qualify ≥2 alternative suppliers for top 10 highest-risk analytes; execute binding quality agreements by Month 6 (2027-04-13) specifying defect-rate <5%, first-pass yield >90%, lot CV <10%, 3-year price lock (≤2–3% annual escalation), 90-day forward forecasts, and 2-week lead-time commitments. Audit ≥2 contract molders/filling-service providers by Month 6 (2027-04-13); document quality-system maturity and process controls. Establish a 4–6 week buffer inventory of critical reagents (estimated USD 20–30k) by Month 9 (2027-07-13) and maintain monthly inventory turnover per FIFO. By Month 6 (2027-04-13) onward, track supplier performance monthly: defect rate (<5%), on-time delivery (>95%), price inflation (≤2–3%/year), and quality-issue resolution time. If any supplier exceeds 10% defect rate for 2 consecutive months, issue corrective-action request and activate backup supplier within 2 weeks. Gate decision at Month 12 (2027-10-13): if all critical suppliers are dual-sourced and performing (defect rate <5%, on-time delivery >95%), proceed to pilot fill and scale-up; if any supplier is unstable (defect rate 5–10% or delivery <90%), escalate and confirm backup capability; if defect rate >10%, activate backup supplier and delay pilot by 2–4 weeks while validating new supplier.

### Notes

- Dual-source qualification is an early activity (Months 1–6 = 2026-11-13 to 2027-04-13) that directly supports pilot-fill success (Month 9 = 2027-07-13); do not defer to post-design-freeze.
- Quality agreements must be written and binding; verbal commitments from suppliers are not enforceable and do not provide contractual protection if quality or delivery fails.
- Reagent buffer inventory is a working-capital requirement (USD 20–30k) and should be included in the Phase 1 and Phase 2 capital budgets; do not underestimate this carrying cost.
- Supplier audit by an external quality consultant (Month 6 = 2027-04-13) is a regulatory expectation; FDA expects evidence that suppliers are audited and quality-system maturity is verified before manufacturing scale-up.
- Supplier performance scorecard is a regulatory artifact; ISO 13485 and FDA expect documented evidence of ongoing supplier monitoring and corrective actions; maintain this scorecard through clearance and post-launch.

## Summary

This project seeks to develop a diagnostics platform delivering a cumulative modular menu of up to 500 health tests from fingerstick blood, with mass manufacturing in Newark, California. The six critical data-collection areas address the highest-risk assumptions: (1) analytical feasibility (cross-reactivity, plasma separation, shelf-life, pilot yield)—the single point of failure; (2) regulatory pathway confirmation (510(k) vs. De Novo)—the longest-pole item affecting funding and timeline; (3) unit economics and payer coverage (net revenue, COGS, gross margin)—mathematically broken at current assumptions; (4) Newark Phase 1 facility and design-for-manufacturability—gates capital commitment and design maturity; (5) clinical method-comparison study—the evidentiary backbone for FDA and payer decisions; (6) supplier qualification and dual sourcing—mitigates supply-chain risk. Each area has quantitative validation objectives, expert review, and gate-linked capital release (Months 6, 12, 18 = 2027-04-13, 2027-10-13, 2028-04-13). Fallback Panel V1 (50-analyte core) is pre-registered and activates automatically if any gate fails by Month 15 (2028-01-13), preventing sunk-cost escalation. No budget cap is stated; planning horizon is Months 0–72 (2026-10-13 to 2032-10-13); first commercial sales targeted Month 48 (2030-10-13); the full 500-analyte menu is not committed within the horizon. De Novo regulatory pathway (if indicated by Month 6 = 2027-04-13 Pre-Submission) adds 12–18 months and USD 2–4M, and Series B must be contingency-sized. Immediate actions: (1) by Month 1 (2026-11-13), lock Fallback V1 definition, gate criteria, and board capital-release authority; (2) by Month 2 (2026-12-13), finalize Cluster 1 analytes and cross-reactivity protocol; (3) by Month 3 (2027-01-13), request FDA Pre-Submission and engage regulatory consultant; (4) by Month 6 (2027-04-13), validate net revenue with payer interviews and lock COGS ceiling; (5) by Month 9 (2027-07-13), execute pilot cartridge fill and qualify dual-source suppliers.