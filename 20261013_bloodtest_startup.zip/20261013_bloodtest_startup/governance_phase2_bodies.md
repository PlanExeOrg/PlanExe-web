### 1. Project Steering Committee (Strategic Oversight Board)

**Rationale for Inclusion:** This capital-intensive, multi-year diagnostics venture operates under extreme technical and regulatory uncertainty with a fixed manufacturing commitment (Newark) that cannot be quickly exited. The Steering Committee provides strategic direction, allocates capital tranches tied to quantified technical gates, makes go/no-go decisions on product scope (Fallback V1 retreat), and oversees systemic risks (funding gaps, regulatory pathway changes, competitive threats). Without this body, sunk-cost escalation, late pivot-to-fallback decisions, and funding shortfalls would accumulate uncontrolled. The committee is essential to reconcile the venture ambition (500-test menu) with the physical/financial constraints.

**Responsibilities:**

- Approve and monitor gate-linked capital tranches (Seed, Series A Tranches 1-3, Series B); release capital only upon pre-agreed technical gate passage (yield, concordance, design freeze) documented at gate meetings
- Decide scope retreat: vote on Fallback Panel V1 (50-analyte core) activation if technical gates fail by Month 15 (2028-01-13) or if funding gap exceeds reserves
- Oversee regulatory pathway (510(k) vs De Novo decision); escalate to investor board if pathway changes add >6 months or USD 2M; approve Pre-Submission meeting strategy and FDA communication plan
- Review and approve Newark phased build-out plan and capital release triggers; pause Newark spending if design freeze is missed or yield falls below 80% mean (lower CI <75%)
- Manage funding strategy (pharma contracts, non-dilutive grants, Series A/B sizing); approve lean-pivot trigger if pharma revenue is <USD 100k/month at Month 18 (2028-04-13)
- Set quantitative thresholds for operational decisions (COGS ceiling USD 25 per cartridge by Month 6 = 2027-04-13; shelf-life >=12 months; plasma separation >95% at Month 6 = 2027-04-13; concordance >=95%; yield >=85% at Month 12 = 2027-10-13) and approve changes to thresholds

**Initial Setup Actions:**

- Hold founding meeting Month 0.5 (2026-10-28): finalize Fallback Panel V1 definition, confirm gate criteria and capital schedule, assign gate-meeting chair (CEO or board lead), establish monthly dashboard reporting

**Membership:**

- CEO/Founder (chair)
- Lead investor or board delegate (independent voice on capital decisions and scope retreat)
- CFO or finance lead (capital, cash-flow, funding pipeline responsibility)
- Chief R&D Officer (technical gate assessment and regulatory pathway alignment)
- Chief Quality Officer (ISO 13485 readiness, regulatory risk, design controls maturity)

**Decision Rights:** Sole authority to approve or withhold capital tranches tied to gates (USD 2-5M decisions). Authority to retreat to Fallback V1 or pause Newark spending. Authority to change regulatory pathway or request board escalation if pathway changes. Authority to approve pharma/grant strategy and lean-pivot trigger. Cannot modify pre-agreed gate thresholds without investor board approval.

**Decision Mechanism:** Majority vote (3 of 5 members). Tie-breaker: CEO casts second vote. Gate passage determined by quantitative criteria (pass/fail/ambiguous per confidence intervals); ambiguous results (e.g., yield 80-85% when gate is >=85%) require data review and board discussion to decide retest vs. fail. All gate decisions documented in minutes with numeric data, decision logic, and tie-breaker used if applicable.

**Meeting Cadence:** Monthly gate-tracking meetings (1-2 hours); full gate-review meetings at Months 6, 12, 18, 24 (2027-04-13, 2027-10-13, 2028-04-13, 2028-10-13) lasting 4-6 hours including board discussion of analyte performance, capital draw, regulatory milestones, and forward plan. Emergency meetings called within 1 week if gates are missed or funding gap emerges.

**Typical Agenda Items:**

- Monthly: Analyte Performance Report (concordance, yield, shelf-life data vs. thresholds); cash burn vs. budget; regulatory milestone status (FDA Pre-Sub prep, ISO 13485 progress); supplier scorecard (defect rate, lead time); Fallback Panel V1 status
- Gate meetings (Months 6, 12, 18, 24 = 2027-04-13, 2027-10-13, 2028-04-13, 2028-10-13): Formal gate decision (pass/fail/ambiguous) with confidence intervals and re-test plan; capital tranche approval/withholding; Newark phased build-out decision (fit-out timing, budget approval); regulatory pathway confirmation or change; pharma/grant revenue status and lean-pivot eligibility; portfolio company scaling/retreat options

**Escalation Path:** If gate is ambiguous (e.g., yield 80-85%), Steering Committee requests 2-3 week retest or directives from Technical Advisory Group. If gate fails and Steering Committee cannot agree on retreat vs. redesign, escalate to investor board with two competing motions (Fallback V1 retreat vs. design-review extension); investor board votes within 2 weeks. If regulatory pathway changes (510(k) → De Novo), Steering Committee approves response plan; if plan exceeds USD 2M or 6 months, escalate to investor board within 5 business days.
### 2. Operations and Execution Committee (Operational Management)

**Rationale for Inclusion:** Day-to-day execution of the development program requires close coordination of assay chemistry, microfluidics, manufacturing, quality, and regulatory work. The Operations Committee manages the 25-70 person team across these functions, makes decisions on design changes, analyte removal, supplier changes, clinical-study protocol adjustments, and resource allocation. Without this body, technical decisions would lack discipline, change control would be weak, and operational risk (supplier failures, analyte incompatibilities, yield loss) would not be managed proactively. The committee translates Steering Committee gates and capital decisions into executable plans and reports progress upward.

**Responsibilities:**

- Execute development plan against Steering Committee gates; prepare gate-review materials (analyte performance, yield data, clinical enrollment, regulatory milestones, cost tracking) for Steering Committee by 5 business days before each gate meeting
- Manage design changes and changes to Fallback Panel V1 analyte list: maintain design-change log, evaluate impact on schedule/cost/regulatory, approve changes <USD 50k/2-week impact without Steering Committee approval; escalate larger changes for review within 5 business days
- Manage analyte removal: conduct monthly Analyte Review Meetings (Months 3-12 = 2027-01-13 to 2027-10-13, then quarterly) to assess each analyte against pre-set thresholds (concordance >=95%, CV <10%, shelf-life >=12 months); decide redesign/retire/defer for each failing analyte; document in Analyte Performance Report visible to board
- Oversee supplier relationships and quality: track contract-manufacturer and reagent-supplier scorecard (defect rate, delivery, cost); escalate defect-rate increases >10% within 2 weeks; approve dual-sourcing transitions; manage supplier quality agreements and corrective actions
- Manage clinical-study execution: coordinate academic partner on protocol, enrollment, data QA, and timelines; escalate enrollment delays >3 months to Steering Committee; prepare clinical-study reports for regulatory submission by Month 24 (2028-10-13)
- Coordinate Newark facility phased build-out: schedule long-lead equipment orders by Month 4-5 (2027-02-13 to 2027-03-13) if design is sufficiently mature; manage fit-out contractors; conduct pilot fills and yield validation; report results to Steering Committee for Phase 2 capital release decision at Month 18 (2028-04-13)
- Manage regulatory readiness: prepare ISO 13485 documentation and internal audits; coordinate FDA Pre-Submission meeting preparation (Months 2-6 = 2026-12-13 to 2027-04-13); prepare 510(k)/De Novo submission package (Months 24-30 = 2028-10-13 to 2029-04-13)

**Initial Setup Actions:**

- Month 1 (2026-11-13): Hire R&D director and quality/regulatory lead (first hires); establish Operations Committee charter and meeting cadence
- Month 2 (2026-12-13): Lock Fallback Panel V1 definition (50 analytes, 4-5 cartridges); finalize Analyte Performance Report template and monthly review calendar
- Month 3 (2027-01-13): Establish design-change log, change-control process, and approval thresholds (USD 50k/2-week minor; >USD 50k or >2-week escalates to Steering Committee); conduct first Analyte Review Meeting
- Month 4 (2027-02-13): Initiate supplier identification for molding, instrument assembly, reagent sourcing; begin FDA Pre-Sub preparation; launch clinical-study site and protocol co-development with academic partner

**Membership:**

- Chief R&D Officer (chair)
- Microfluidics engineering lead or principal engineer
- Assay chemistry and biology lead
- Chief Quality Officer (ISO 13485, design controls, regulatory readiness)
- Manufacturing/operations lead (or contractor representative for early phases)
- Clinical-trial coordinator or academic-partner liaison
- Finance/program manager (budget, cost tracking, procurement authority)

**Decision Rights:** Authority to approve design changes <USD 50k and <2 week timeline impact without Steering Committee escalation. Authority to manage supplier relationships, approve dual-sourcing transitions, and escalate quality failures. Authority to make operational trade-offs (e.g., reduce analyte count to meet COGS ceiling, adjust clinical-study site selection) if aligned with Fallback Panel V1 scope and Steering Committee direction. Cannot retreat from Fallback Panel V1 or approve capital >USD 500k; those decisions are escalated to Steering Committee.

**Decision Mechanism:** Consensus preferred; if disagreement, R&D director makes the call (subject to Steering Committee review if impact is >USD 50k). Monthly Analyte Review Meetings use quantitative criteria to decide redesign vs. retire vs. defer: if concordance <95% or CV >10%, failure is documented and escalated same week; decision to redesign or retire is made within 2 weeks (chair + quality lead approval). Clinical-study protocol changes requested by academic partner are reviewed within 1 week; changes <USD 50k and <2 month timeline impact are approved operationally; larger changes escalate to Steering Committee.

**Meeting Cadence:** Weekly executive sync (1 hour, R&D director + quality lead + finance lead); monthly full Operations Committee (2 hours, all members); monthly Analyte Review Meetings (1 hour, R&D + quality + design lead); monthly supplier scorecard reviews (1 hour with procurement lead); bi-weekly clinical-study status (with academic partner).

**Typical Agenda Items:**

- Weekly sync: blockers, risk watch list (supplier delays, analyte performance surprises, budget variance >5%), regulatory-readiness gaps, clinical-enrollment status
- Monthly Operations Committee: detailed Analyte Performance Report (all analytes, design review of failing ones), yield and manufacturing learnings (pilot fills, contract-manufacturer quality), supplier performance (defect rate, lead time, cost), design-change log review, clinical-study progress, regulatory milestone tracking, cash-burn tracking vs. gate-linked budget
- Monthly Analyte Review: concordance, CV, shelf-life data per analyte; documentation of failures; redesign scope and timeline for failing analytes; retirement decision and FDA transparency plan for removed analytes
- Monthly supplier scorecard: defect rate, on-time delivery %, quality-agreement compliance, cost performance vs. contract; escalation flags (defect >10%, delay >2 weeks, new quality issues)

**Escalation Path:** Design changes >USD 50k or >2 weeks impact escalate to Steering Committee within 5 business days. Analyte failure needing major redesign (>USD 100k, >4 weeks) escalates to Steering Committee; Fallback Panel V1 removal decision escalates to Steering Committee if >10% of core panel is affected. Supplier defect rate >10% or delivery failure escalates within 2 weeks; if dual-source activation costs >USD 50k, escalate to Steering Committee. Clinical-study enrollment delay >3 months escalates to Steering Committee. If Newark pilot fill yield is <80% at Month 12 (2027-10-13), escalation to Steering Committee with redesign proposal and retest plan.
### 3. Technical Advisory Group (Specialized Technical Assurance)

**Rationale for Inclusion:** The venture's core technical risks are plasma separation feasibility, cross-reactivity multiplexing challenges, reagent stability at scale, and cartridge yield. These are highly specialized domains requiring deep expertise in microfluidics, clinical immunoassay chemistry, manufacturing, and regulatory standards. The Operations Committee, while experienced, may miss technical nuances or over-commit to infeasible analyte targets. The Technical Advisory Group provides independent technical review, validates gate-passage decisions, flags design risks early, and ensures that analytical feasibility assessments are credible (protecting investor confidence and regulatory credibility). Without this body, over-optimistic performance projections at gates could lock in capital and manufacturing commitments to a flawed design.

**Responsibilities:**

- Validate analytical-feasibility assessment at each gate: review raw data, measurement protocols, and success-criteria calculations; sign off on concordance, yield, and shelf-life gate results before Steering Committee votes (by 3 business days before gate meeting)
- Assess cross-reactivity risk across Cluster 1 analyte pairs: review systematic cross-reactivity screening protocol (Month 4-6 = 2027-02-13 to 2027-04-13); identify high-risk pairs; recommend analyte redesign or removal if cross-reactivity >5% bias at 10× interferent; document risk mitigation
- Review plasma-separation and sample-preparation feasibility: assess plasma-yield and hemolysis data from Month 4-6 (2027-02-13 to 2027-04-13) study (100+ fingerstick subjects); validate that >=95% of samples yield >=1.6 microliters plasma with hemolysis index <50; flag any feasibility gaps and re-design scope
- Evaluate manufacturing and yield risk: conduct design-for-manufacturability (DFM) review with contract molding partner by Month 3 (2027-01-13); identify yield-limiting steps (injection molding defects, bonding, reagent filling); recommend design changes to improve moldability and yield; validate pilot-fill results (Month 12 = 2027-10-13) against yield model
- Assess reagent stability and shelf-life modeling: review real-time and accelerated-stability testing protocols (Month 3 = 2027-01-13); validate Arrhenius modeling assumptions; review Month 12 (2027-10-13) shelf-life projections; flag analytes with suspected early drift; recommend re-formulation scope
- Provide regulatory strategy and evidence-package guidance: review clinical-study protocol design, sample-size calculations, and analytical acceptance criteria (concordance >=95%, CV <10%); ensure that study design aligns with likely FDA expectations for 510(k) or De Novo; flag evidence gaps early

**Initial Setup Actions:**

- Month 0.5 (2026-10-28): Identify and recruit 5-7 external technical advisors (microfluidics, immunoassay, manufacturing, regulatory) with 15+ years experience and no financial interest in suppliers or funding decisions; finalize advisory-board charter
- Month 1 (2026-11-13): Hold inaugural meeting; review project risk map and identify highest-priority technical assessments (plasma separation, cross-reactivity, yield modeling)
- Month 2 (2026-12-13): Conduct first design-for-manufacturability session with contract-molding partners; document DFM findings and design-improvement recommendations

**Membership:**

- External microfluidics or lab-on-a-chip expert (15+ years in device development, no funding or supplier interest)
- External clinical immunoassay chemistry expert (15+ years in multiplex assay development, academic or industry)
- External manufacturing and process-engineering expert (15+ years in cartridge/device molding and assembly scale-up)
- External regulatory affairs expert (FDA submissions for in vitro diagnostics, 510(k) or De Novo experience)
- Internal Chief R&D Officer (ex officio, for context but not voting on R&D decisions to avoid conflicts)
- Optional: external scientific advisory board member with clinical-data interpretation expertise (if multi-analyte clinical-study design is novel)

**Decision Rights:** Authority to request data, protocols, and raw results from Operations Committee and to conduct independent verification of analytical or manufacturing results. Authority to recommend analyte removal, design changes, or re-testing without Operations approval (escalates to Steering Committee if Operations disagrees). Cannot directly command Operations Committee actions or approve funding; all recommendations are advisory. Cannot veto Steering Committee gate decisions, but can submit a minority written opinion if Technical Advisory Group disagrees with gate passage.

**Decision Mechanism:** Consensus opinion preferred; if split, the group issues separate findings and lets Steering Committee decide. Gate-validation decisions (e.g., concordance >=95% passes) are made by reviewing raw data and measurement protocols; success is confirmed only if measurement method is sound and acceptance criteria are met. Analyte-removal recommendations are made if an analyte fails objective thresholds; subjective calls (e.g., whether 94% concordance is 'close enough' to 95%) are escalated to Steering Committee with Technical Advisory Group's pro/con analysis.

**Meeting Cadence:** Quarterly full meetings (2-3 hours, virtual or in-person at Newark site) to review progress, risk, and upcoming gates. Ad-hoc targeted meetings (1-2 hours) at critical junctures: DFM review (Month 3 = 2027-01-13), cross-reactivity assessment (Month 5-6 = 2027-03-13 to 2027-04-13), plasma-separation data review (Month 6 = 2027-04-13), shelf-life projection (Month 12 = 2027-10-13), yield validation (Month 12-15 = 2027-10-13 to 2028-01-13), regulatory-evidence adequacy (Month 18 = 2028-04-13).

**Typical Agenda Items:**

- Quarterly meetings: project status and risk summary; upcoming technical gates and what data will determine passage; preliminary analyte and design performance; preliminary manufacturing learnings; regulatory pathway alignment and evidence-gap assessment
- DFM review (Month 3 = 2027-01-13): cartridge design, mold complexity, bonding method, yield assumptions; recommendations for design simplification or alternative manufacturing approaches
- Cross-reactivity assessment (Month 5-6 = 2027-03-13 to 2027-04-13): cross-reactivity screening results; high-risk analyte pairs; recommended removals or chemistry redesigns
- Plasma-separation review (Month 6 = 2027-04-13): plasma-yield data from 100+ fingerstick subjects; hemolysis distribution; adequacy of sample budget for intended analyte count
- Shelf-life and stability review (Month 12 = 2027-10-13): real-time and accelerated-stability data; Arrhenius modeling results; confidence in 12-month shelf-life projection; risk of early drift in any analyte
- Yield validation (Month 12-15 = 2027-10-13 to 2028-01-13): pilot-fill results; defect-mode analysis; first-pass yield; correlation to yield model and design-for-manufacturability recommendations
- Regulatory evidence (Month 18 = 2028-04-13): clinical-study protocol and enrollment progress; analytical acceptance criteria; sample-size power; evidence adequacy for planned submission pathway

**Escalation Path:** If Technical Advisory Group identifies a major feasibility risk (e.g., cross-reactivity cannot be resolved within design constraints, plasma separation achieves only 80% yield vs. 95% gate), a minority report is submitted to Steering Committee within 1 week. Steering Committee must address the concern in monthly meeting minutes. If gate passage is recommended by Operations but Technical Advisory Group disagrees (e.g., yield is 84% when gate is >=85%), Steering Committee holds an extended discussion with Technical Advisory Group present; Steering Committee decides, but dissent is documented. Technical Advisory Group can request an independent re-test at any time if data quality or measurement protocol is in question; Steering Committee approves or denies the request within 1 week.
### 4. Compliance, Ethics and Risk Management Committee (Specialized Governance Assurance)

**Rationale for Inclusion:** This venture operates in a heavily regulated domain (FDA, CLIA, ISO 13485, clinical trials) with significant reputational exposure due to historical precedent of failed single-drop diagnostic claims. The Compliance, Ethics and Risk Management Committee ensures that the company adheres to regulatory obligations, manages over-claiming risk, protects data integrity in clinical studies, and maintains ethical standards in transparency and stakeholder communication. The committee also integrates risk management across all governance bodies, ensuring that technical risks (gates), financial risks (capital, funding gaps), supply-chain risks (supplier dependencies), and reputational risks (credibility loss from failed analytes or over-claims) are identified, monitored, and mitigated proactively. Without this body, regulatory violations, clinical-trial non-compliance, selective data reporting, and credibility erosion could occur without systematic mitigation.

**Responsibilities:**

- Ensure regulatory compliance (FDA, CLIA, ISO 13485, IEC 62304, clinical-trial regulations): maintain a regulatory roadmap and compliance checklist; flag upcoming submissions, certifications, and inspection readiness; coordinate with Operations Committee on quality-system maturity, design-control documentation, and software development lifecycle compliance; schedule and support mock FDA inspection at Months 28-30 (2029-02-13 to 2029-04-13)
- Oversee compliance with pre-registered clinical-study protocol: review protocol registration on ClinicalTrials.gov; monitor study execution against approved protocol; flag any protocol deviations or amendments; coordinate with academic partner on data integrity, adverse-event reporting, and informed-consent compliance; ensure results (positive and negative) are published within committed timeline (Month 30 = 2029-04-13)
- Manage over-claiming and marketing compliance: enforce no-500-tests-per-drop rule (no public claim until 3 clusters independently validated); audit all investor pitches, press releases, and marketing materials for accuracy; cross-check product claims against validated data in Analyte Performance Report; ensure that failed or retired analytes are disclosed in regulatory submissions and, per company policy, in external communications after clearance
- Protect data integrity and research misconduct prevention: establish a data-management and research-misconduct policy; conduct data audits of clinical studies, analytical results, and regulatory submissions; maintain a research-misconduct hotline and handle reports confidentially; flag any evidence of selective data reporting, falsification, or regulatory misrepresentation within 48 hours to CEO and board
- Manage intellectual property and freedom-to-operate (FTO) compliance: oversee FTO review by patent counsel (Month 2-6 = 2026-12-13 to 2027-04-13); ensure no patents or regulatory violations from third-party IP; manage patent filings and publication strategy; ensure trade-secret protections on reagent formulations and processes
- Comprehensive risk management and escalation: maintain an enterprise risk register identifying all risks (technical, financial, regulatory, supply-chain, reputational) with likelihood, severity, owner, and mitigation plan; update quarterly; escalate risks scoring >9 (likelihood×severity) to Steering Committee within 5 business days; track mitigation progress; coordinate risk response across Operations and Technical Advisory Group
- Conflict-of-interest and ethics oversight: establish and enforce a conflict-of-interest policy for board, employees, advisors, and contractors; disclose all related-party transactions (e.g., board member has equity in a supplier) and manage recusals; maintain an ethics hotline for reporting concerns; review and approve all material supplier agreements and partnership deals for transparency and fairness

**Initial Setup Actions:**

- Month 1 (2026-11-13): Hire or contract a Chief Compliance Officer or General Counsel; establish committee charter and compliance roadmap
- Month 2 (2026-12-13): Develop conflict-of-interest policy, data-integrity policy, and marketing/claims policy; communicate to all staff
- Month 3 (2027-01-13): Initiate FTO review and regulatory roadmap (FDA Pre-Sub, ISO 13485, CLIA); establish risk register template and initial risk assessment; register clinical-study protocol on ClinicalTrials.gov (in preparation for Month 12 = 2027-10-13 study initiation)
- Month 4 (2027-02-13): Establish data-management and research-misconduct policies; brief academic clinical partner on data-integrity expectations; set up ethical advisory board (if not covered by Technical Advisory Group)

**Membership:**

- Chief Compliance Officer or General Counsel (chair)
- Quality/Regulatory lead (ISO 13485, FDA, design controls, inspection readiness)
- Chief Financial Officer or Finance lead (financial risk, funding compliance, budget controls)
- Chief R&D Officer or Operations lead (technical and operational risk, design-control compliance) (ex officio for risk discussions, not voting on operational decisions)
- External ethics or compliance expert (independent perspective on conflict-of-interest, data integrity, and corporate governance)
- Optional: external scientific integrity advisor (if clinical-study data management is novel or high-risk)

**Decision Rights:** Authority to develop and enforce compliance, ethics, and risk policies without Steering Committee approval (policies are informational unless they conflict with business decisions). Authority to audit and request corrections to regulatory submissions, marketing materials, and clinical-study documentation. Authority to escalate compliance violations, research misconduct, or unresolved conflicts of interest directly to CEO and investor board. Cannot unilaterally block a business decision (e.g., cannot stop a 510(k) submission), but can require documented risk disclosure to Steering Committee before decision is finalized.

**Decision Mechanism:** Consensus on policy development and risk assessment. Compliance violations are escalated by simple reporting (no vote needed). Risk escalation uses a quantitative risk-scoring matrix (likelihood 1-5 × severity 1-5 = 1-25 score); scores >9 are escalated immediately; scores 5-9 are tracked and reviewed quarterly. Data-integrity or research-misconduct allegations are investigated by the Chief Compliance Officer with external investigator involvement if needed; findings are reported to CEO and audit committee within 30 days.

**Meeting Cadence:** Quarterly compliance and risk reviews (2 hours); monthly check-ins with Quality/Regulatory on inspection readiness and design-control progress (1 hour); monthly data-integrity audits of clinical studies and analytical results (1 hour with academic partner); ad-hoc escalations (within 48 hours of identification).

**Typical Agenda Items:**

- Quarterly: regulatory roadmap status (FDA Pre-Sub prep, ISO 13485 timeline, CLIA application if applicable); inspection-readiness assessment; compliance violations or near-misses in past quarter; risk register review (technical, financial, regulatory, supply-chain, reputational risks); data-integrity audit findings; marketing/claims compliance check; conflict-of-interest disclosures and recusals
- Monthly data-integrity: clinical-study enrollment and data-entry status; adverse-event reporting (if any); protocol deviations or amendments; data-audit findings; academic-partner communication and compliance
- Monthly inspection-readiness: design-history-file completeness; change-control log review; training records and competency assessments; management-of-change documentation; complaint handling and adverse-event trending (if applicable)
- Quarterly risk register: update likelihood and severity for all identified risks; identify new risks; track mitigation-plan progress; escalate scores >9; discuss risk interdependencies (e.g., plasma-separation failure cascades to all clusters)

**Escalation Path:** Compliance violations (regulatory breach, research misconduct allegation, conflict-of-interest violation) escalate to CEO and board audit committee within 48 hours. Risk scores >9 (e.g., combined technical + financial risk of design failure + funding gap) escalate to Steering Committee within 5 business days with mitigation options. Data-integrity concerns (suspected selective reporting, falsification) trigger independent investigation and escalation to CEO and board within 30 days. Marketing or claims non-compliance (use of '500 tests' claim before validation) is escalated to CEO and chief marketing officer within 24 hours.