## Primary Decisions
The vital few decisions that have the most impact.


The Critical and High levers jointly address the core tensions: menu breadth versus analytical reliability (Assay Panel, Cartridge, Sample Volume), speed to revenue versus evidence burden (Regulatory Route, Deployment), and capital commitment versus design maturity (Funding Path, Newark Timing, Cost Ceiling, Feasibility Gates). Dimensions that seem under-represented are detection and readout instrument technology, software and data handling, and selection of the initial clinical use case.

### Decision 1: Assay Panel Architecture
**Lever ID:** `6d4658e4-193b-4f9a-81eb-a35a87cc09fa`

**The Core Decision:** Fixes the technical meaning of the '500 tests' claim: one detection chemistry read repeatedly, a cumulative modular menu, or off-device high-plex measurement. Scope covers analyte selection, chemistry mix, and the calibration and cross-reactivity burden. Success metrics: analytes passing pre-set accuracy and precision thresholds (proposed), per-analyte clinical relevance, and cartridge complexity that manufacturing can hold in tolerance.

**Why It Matters:** Defines what '500 tests' physically means: one detection chemistry read many times, or several chemistries (immunoassay, nucleic acid, metabolite) sharing one sample. A single-chemistry array simplifies the cartridge and manufacturing but narrows clinical coverage. A multi-chemistry design widens coverage but multiplies cross-reactivity, reagent-stability and calibration problems inside a sub-microliter-per-test sample budget.

**Strategic Choices:**

1. Commit to a single multiplexed immunoassay array platform and expand the analyte count incrementally, accepting a narrower menu to keep the cartridge design and manufacturing process unified.
2. Develop a family of modular cartridges, each running a validated cluster of related analytes from the same capillary sample, and market the 500-test figure as a cumulative menu rather than one run.
3. Pair a drop-volume sample preparation step with a centralized mass-spectrometry proteomics lab, so the device collects and stabilizes the sample while the high-plex measurement happens off-device.

**Trade-Off / Risk:** The headline of 500 tests per drop is the assumption everything else rests on; each architecture trades menu breadth against analytical reliability, and no option makes all 500 analytes simultaneously physically feasible at clinical-grade accuracy.

**Strategic Connections:**

**Synergy:** Amplifies Cartridge Fluidic Architecture and Integration Depth, since a unified chemistry lets fluidics be designed once and scaled. Also enables Evidence Generation and Transparency by permitting analyte-by-analyte validation and staged menu release.

**Conflict:** Constrains Sample Volume and Collection Method: each added chemistry splits a fixed drop budget further. Also trades off against Design-to-Cost Ceiling and Unit Economics Gate, because multi-chemistry breadth raises reagent and cartridge cost per run.

**Justification:** *Critical*, Defines what '500 tests' physically means and is the hub linking fluidics, sample budget, cost ceiling, validation and scope-retreat decisions. It controls the core trade-off between menu breadth and analytical reliability that every other lever inherits.

### Decision 2: Regulatory Route and Sequencing
**Lever ID:** `bb50b0da-9d49-4d08-b485-cecd6e161cbe`

**The Core Decision:** Chooses the legal pathway to market and the order of evidence, which sets when revenue begins and what quality system is required. Options span a CLIA lab service, staged 510(k) or De Novo submissions, and Breakthrough designation. Success metrics: months to first revenue, FDA feedback alignment through Pre-Submission, and cumulative regulatory spend against the funding runway.

**Why It Matters:** Determines when revenue can start and how much evidence is needed up front. FDA's 2024 rule on lab-developed tests was vacated and then rescinded in 2025, so a CLIA-lab service can launch under enforcement discretion, but a device sold to other labs or clinics still needs clearance or approval. Choosing the route also shapes the quality system, clinical study design and investor timeline.

**Strategic Choices:**

1. Launch first as a CLIA-certified laboratory service running the device in-house under the LDT pathway, and pursue FDA submissions later for the instrument and cartridge as a commercial product.
2. File staged per-analyte or per-cluster 510(k) or De Novo submissions beginning with the best-characterized assays, and build the menu through successive clearances.
3. Seek Breakthrough Device designation and early Pre-Submission meetings to agree on a single comprehensive evidence package with FDA before committing to full-scale manufacturing.

**Trade-Off / Risk:** A lab-service route gets revenue sooner, but it keeps the product outside FDA review and concentrates reputational risk in the lab's own results, while device clearance is slower and costlier but is the only route to selling the instrument.

**Strategic Connections:**

**Synergy:** Amplifies Funding Path and Commercial Beachhead, since an early CLIA service produces revenue and real-world data that de-risk financing. Also pairs with Payer Coverage and Pricing Architecture, which depends on clearance status.

**Conflict:** Constrains Newark Manufacturing Build-Out Timing: device clearance demands design freeze and ISO 13485 production controls, while a lab-service route defers them. Also tensions with Intellectual Property and Partner Leverage if partners require cleared products.

**Justification:** *Critical*, Controls time to first revenue, required quality system and evidence package. Its synergy and conflict texts tie it to funding, payer pricing, Newark timing and partners, making it a central hub governing the speed versus evidence-burden trade-off.

### Decision 3: Newark Manufacturing Build-Out Timing
**Lever ID:** `676fc457-b458-4b90-8c3f-b326fccfae3a`

**The Core Decision:** Governs when capital and headcount are committed to the Newark site relative to design maturity. It determines whether process learning on production-like equipment happens early or after design freeze, and which steps (reagent filling, molding, assembly) are in-house. Success metrics: first-pass cartridge yield, lot-to-lot reagent stability, capital at risk before design freeze, and time from freeze to verification builds.

**Why It Matters:** Decides how much capital is committed to the Newark, California site before the cartridge design is locked. Early build-out gives control over process development and quality but fixes cost into a design that may still change. Late build-out preserves flexibility but delays learning about yield, reagent stability and scale-up issues that appear only on production-like equipment.

**Strategic Choices:**

1. Lease and fit out a pilot cleanroom and assembly line in Newark at the start, and develop the cartridge process there alongside the design team.
2. Use a contract manufacturer for early clinical-lot cartridges and open the Newark line only after the design is frozen and verification builds have shown stable yields.
3. Stand up Newark first as a reagent formulation and cartridge-filling site, the highest-risk step, while outsourcing injection-molded parts and instrument assembly to established suppliers.

**Trade-Off / Risk:** Starting the Newark build early speeds learning but locks fixed cost around an unfrozen design, while delaying it risks discovering at scale that the cartridge cannot be built consistently; neither removes the yield risk.

**Strategic Connections:**

**Synergy:** Amplifies Reagent Supply and Lot Consistency Control, since an in-house formulation and filling site gives direct command of the highest-risk step. Also supports Talent Sourcing Geography and Hiring Sequence by anchoring process engineers locally.

**Conflict:** Trades off against Design-to-Cost Ceiling and Unit Economics Gate and Funding Path and Commercial Beachhead: early fit-out burns capital before unit economics are proven. It also conflicts with Feasibility Gates and Scope-Retreat Triggers if sunk cost resists retreat.

**Justification:** *Critical*, Governs the largest capital commitment against design maturity at the named Newark site. It conflicts with cost, funding, gating and payer volume assumptions and supports reagent control and talent, so it controls the flexibility versus learning-speed tension.

### Decision 4: Funding Path and Commercial Beachhead
**Lever ID:** `1abc7974-577a-424c-b8f5-6bf27d7508d9`

**The Core Decision:** Selects who funds the multi-year development runway and which first customer validates the platform. It sets the cash-burn profile, milestone cadence, investor expectations, and how soon the company produces real-world evidence. Key success metrics are months of runway per financing round, first revenue date, share of cost covered by non-dilutive or contract funds, and whether the beachhead volume justifies committing Newark capital.

**Why It Matters:** Determines which customers and capital sources pay for the long development period before a broad menu is validated. Venture-led financing allows a full-stack build but demands a large-market story early. Starting with a narrow paying customer, such as drug-development biomarker monitoring, funds development with less reimbursement dependence but narrows the initial market.

**Strategic Choices:**

1. Raise venture capital against a broad consumer and clinical-screening vision and build the full stack, from assays to manufacturing, under one company before generating meaningful revenue.
2. Sell the platform first as a research-use or clinical-trial biomarker tool for pharmaceutical sponsors, using contract revenue and non-dilutive grants to fund the move into clinical diagnostics.
3. Pursue a narrow, physician-ordered panel with an existing reimbursement code in one disease area, and expand the menu only as payer coverage and clinical evidence accumulate.

**Trade-Off / Risk:** Broad venture funding fits the vision but increases pressure to claim early; narrow beachheads produce revenue and evidence sooner but may be too small to justify the Newark manufacturing investment.

**Strategic Connections:**

**Synergy:** Amplifies Feasibility Gates and Scope-Retreat Triggers by tying financing tranches to technical milestones, and enables Newark Manufacturing Build-Out Timing by showing when committed revenue or capital can justify phased factory investment.

**Conflict:** Constrains Assay Panel Architecture and Payer Coverage and Pricing Architecture: a narrow beachhead pushes toward a small panel and one reimbursement route, while a broad venture story pressures early 500-test claims the evidence cannot yet support.

**Justification:** *Critical*, Determines who pays for the multi-year runway and which first customer validates the platform. It constrains panel scope and payer route, enables phased Newark investment and ties to gates, so it governs the ambition versus capital-survival trade-off.

### Decision 5: Cartridge Fluidic Architecture and Integration Depth
**Lever ID:** `2223a7b8-aad9-42ca-8929-dc9a9fb542cd`

**The Core Decision:** Determines where plasma separation, metering, reagent storage, mixing and readout reside between disposable and reader, and thereby fixes consumable cost, per-lot yield, shelf-life exposure and operator steps. Success metrics: cartridge-level yield at pilot-line scale, assay-to-assay crosstalk, reagent stability over claimed shelf life, and number of user handling steps per drop of blood.

**Why It Matters:** This sets how much sample handling (plasma separation, metering, reagent storage, mixing, readout) lives inside the disposable versus the instrument. Deeper integration simplifies the user's workflow but concentrates fluidic, bonding, and reagent-stability risk into a single consumable that must be manufactured at scale in Newark. Shallower integration shifts cost and complexity into the reader and the operator's steps.

**Strategic Choices:**

1. Build one monolithic injection-molded cartridge that integrates plasma separation, reagent storage, mixing, and detection chambers so the operator performs a single loading step.
2. Split the workflow into a small family of specialized cartridges, each serving one assay class from the same drop, accepting several consumables per collection.
3. Move fluidic complexity into a precision reusable reader head that pairs with low-cost disposable capture strips, keeping the consumable deliberately simple and the instrument carrying the engineering burden.

**Trade-Off / Risk:** Integration depth looks like a pure engineering choice, but it fixes consumable cost, yield loss, and shelf-life exposure at once; a monolithic cartridge fails entirely when any one of hundreds of chambers fails.

**Strategic Connections:**

**Synergy:** Amplifies Design-to-Cost Ceiling and Unit Economics Gate, since integration depth sets the cost-of-goods that the ceiling tests. Also enables Sample Volume and Collection Method by defining how a single drop is partitioned across assay chambers.

**Conflict:** Trades off against Reagent Supply and Lot Consistency Control, because deeper integration concentrates reagent-stability risk in one consumable, and against Newark Manufacturing Build-Out Timing, since monolithic designs demand mature molding and bonding lines early.

**Justification:** *Critical*, Central technical hub fixing consumable cost, yield and shelf-life exposure at once. It connects to cost ceiling, sample partitioning, reagent stability, Newark process maturity and IP, controlling the integration versus manufacturability trade-off.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Sample Volume and Collection Method
**Lever ID:** `090cd9e0-215f-4136-882f-633805f61c37`

**The Core Decision:** Sets the physical sample budget and who can collect it, defining whether the single-drop promise holds at launch or is earned later. Scope includes collection hardware, volume metering, hemolysis and clotting control, and venous-equivalence demonstration. Success metrics: fraction of fingerstick samples meeting acceptance criteria, per-analyte bias versus venous reference, and collection failure rate among untrained users.

**Why It Matters:** Sets the physical limit on how many measurements are possible and who can collect the sample. Strict fingerstick-only capillary collection delivers the product promise but is vulnerable to hemolysis, tissue-fluid dilution and variable volume, which degrade results for many analytes. Allowing a larger sample improves data quality but weakens the single-drop differentiation.

**Strategic Choices:**

1. Hold strictly to a single fingerstick capillary drop as the product definition and invest in collection hardware that controls volume, hemolysis and clotting at the point of collection.
2. Use a volumetric microsampling device that wicks a fixed, metered volume from a fingerstick and can be collected at home, then run the assays at a central facility.
3. Run a tiered approach where the validation program uses paired venous draws as the reference and the fingerstick claim is expanded analyte by analyte only as equivalence is demonstrated.

**Trade-Off / Risk:** Sample volume is a hard physical budget, not an engineering preference; the options differ mainly in whether the single-drop claim is preserved at launch or earned later, and the cost is time-to-market versus credibility.

**Strategic Connections:**

**Synergy:** Enables Deployment Setting and Operator Model, since controlled, metered collection is what makes home or point-of-care use credible. Strengthens Evidence Generation and Transparency through paired venous reference data that supports equivalence claims.

**Conflict:** Constrains Assay Panel Architecture, because the available microliters cap analyte count and chemistry diversity. Trades off against Regulatory Route and Sequencing: a strict drop claim needs heavier collection-device evidence and may delay clearance.

**Justification:** *High*, Sets the hard physical sample budget that caps analyte count and determines whether the single-drop claim holds at launch. Connects to panel architecture, deployment and regulatory burden, but is largely a constraint that the architecture choices work within.

### Decision 7: Evidence Generation and Transparency
**Lever ID:** `f5db6263-cccd-410f-b85c-5bee4bc1df66`

**The Core Decision:** Defines how accuracy is proven and who controls the data: pre-registered blinded comparisons, gated analyte release, or advisory-board audit with public failure reporting. It sets the credibility basis for clinicians, payers and regulators. Success metrics: share of analytes meeting pre-set thresholds, independent replication, publication timeline, and acceptance of the dataset by FDA and payers.

**Why It Matters:** Establishes how accuracy is demonstrated and who is allowed to see the data. Independent, pre-specified comparisons against established reference methods are slower and may expose weak analytes, but they are the basis for clinician, payer and regulator trust. Controlling data internally is faster, yet leaves the company exposed to credibility loss if results cannot be reproduced externally.

**Strategic Choices:**

1. Run pre-registered, blinded method-comparison studies against established reference laboratory methods with an independent academic or clinical partner who holds the analysis rights and publishes the results.
2. Validate analytes in sequence, releasing each to the menu only after it passes pre-set accuracy and precision thresholds, and withhold the rest from any commercial claim.
3. Appoint an external scientific and clinical advisory board with audit access to raw data and failure logs, and report analyte-level performance publicly, including those that fail.

**Trade-Off / Risk:** Open validation reduces the risk of overclaiming, but it makes every weak analyte visible early and can slow the funding story; the trade-off is credibility against narrative control, and the 500-analyte scope multiplies the work.

**Strategic Connections:**

**Synergy:** Amplifies Payer Coverage and Pricing Architecture, because independently published performance data is what coverage decisions rely on. Also strengthens Regulatory Route and Sequencing by producing study designs that map onto submission packages.

**Conflict:** Trades off against Funding Path and Commercial Beachhead: public visibility of failing analytes can weaken the investor narrative. It also slows Assay Panel Architecture expansion, since each added analyte needs its own validation work.

**Justification:** *Medium*, Builds credibility with clinicians, payers and regulators and feeds gate decisions, but largely executes the choices made in panel architecture and regulatory route. Its main tension, transparency versus investor narrative, is secondary to funding and scope choices.

### Decision 8: Deployment Setting and Operator Model
**Lever ID:** `1ba1eacd-53f5-408b-b2dc-e0222eaa7285`

**The Core Decision:** Defines the operator, site, and sales channel for the device, which fixes the regulatory category (high-complexity CLIA versus waived-use), human-factors burden, and per-run revenue. It also sets how much error tolerance must be engineered into the cartridge. Success is measured by invalid-run rate, operator training time, site activation speed, and revenue per placed instrument.

**Why It Matters:** Deciding who runs the device (trained lab technologists, clinic staff, pharmacists, or patients at home) drives cartridge robustness, onboarding design, quality-control features, and which regulatory category applies. A central-lab deployment tolerates a more complex instrument, while point-of-care placement demands fault tolerance and on-board controls. The setting also determines the sales channel and the revenue per run the business can realistically capture.

**Strategic Choices:**

1. Deploy first as a high-complexity instrument in reference and hospital laboratories run by trained staff, prioritizing assay performance and throughput over ease of use.
2. Design for clinic and pharmacy point-of-care placement with a simplified, closed cartridge workflow, accepting tighter performance tolerances and heavier human-factors and waived-use evidence.
3. Operate a company-run centralized testing service that receives sealed collection kits by mail, keeping the instrument in-house until the hardware has matured and then licensing it outward.

**Trade-Off / Risk:** A lab-first deployment lowers technical risk but may forfeit the 'single drop' differentiation that justifies the venture, while point-of-care placement multiplies human-factors and QC obligations the team may not be staffed for.

**Strategic Connections:**

**Synergy:** Enables Sample Volume and Collection Method by matching finger-stick or mailed-kit collection to the operator, and reinforces Cartridge Fluidic Architecture and Integration Depth by fixing how much on-board control and automation the cartridge needs.

**Conflict:** Trades off against Design-to-Cost Ceiling and Unit Economics Gate and Regulatory Route and Sequencing: point-of-care simplicity adds cartridge cost and waiver evidence, whereas lab-first placement lowers risk but may dilute the single-drop differentiation.

**Justification:** *High*, Fixes operator, sales channel and regulatory category, driving cartridge robustness and per-run revenue. It trades off against cost ceiling and regulatory route and decides whether the single-drop differentiation is retained or diluted.

### Decision 9: Reagent Supply and Lot Consistency Control
**Lever ID:** `c0b2a31c-ce25-4bb3-8f4e-269e7427afd7`

**The Core Decision:** Governs sourcing, qualification, and release of the antibodies, probes, enzymes, or synthetic binders behind each assay, which determines whether performance validated on prototypes holds across production lots. It covers supplier agreements, incoming-lot acceptance criteria, dual sourcing, and re-validation triggers. Success is measured by lot-to-lot CV, supplier-change events forcing re-validation, reagent share of cost of goods, and lot-release cycle time.

**Why It Matters:** Hundreds of assays depend on antibodies, probes, and enzymes whose quality varies between lots and suppliers. Control over reagent sourcing and lot release determines whether results stay consistent as production moves from prototype to Newark volumes. Vertical integration protects quality and margins but ties up capital and specialized staff, while outsourcing exposes the product to supplier changes that can force re-validation.

**Strategic Choices:**

1. Contract established reagent suppliers under quality agreements with dual sourcing for critical biologics, keeping capital light while accepting exposure to supplier discontinuations and lot variability.
2. Produce critical antibodies and probes in-house in a dedicated Newark reagent suite, absorbing the capital and staffing cost to control lot release and secure long-term intellectual property.
3. Replace biologic capture reagents with synthetic binders such as aptamers or engineered scaffolds that can be manufactured chemically, trading a less mature validation record for more reproducible supply.

**Trade-Off / Risk:** Reagent control is the quiet determinant of whether 500 assays stay stable at scale, yet in-house production adds a second manufacturing operation, and synthetic binders carry performance uncertainty that may not be visible until late validation.

**Strategic Connections:**

**Synergy:** Amplifies Design-to-Cost Ceiling and Unit Economics Gate by exposing reagent cost drivers early, and strengthens Intellectual Property and Partner Leverage when proprietary in-house binders become protectable assets or partners supply qualified reagent capacity.

**Conflict:** Competes with Newark Manufacturing Build-Out Timing and Funding Path and Commercial Beachhead for scarce capital and specialized staff: an in-house reagent suite adds a second manufacturing operation, while outsourcing keeps cash but leaves supply exposed.

**Justification:** *Medium*, Determines whether validated performance survives production scale and is a key stability risk, but its decision space (sourcing and lot release) is downstream of cartridge and Newark choices. Important for optimization, with fewer system-wide connections.

### Decision 10: Payer Coverage and Pricing Architecture
**Lever ID:** `41ddbb83-7da3-4a5d-a2e5-838eec5033d3`

**The Core Decision:** Determines how results are billed and who pays: self-pay or employer wellness, coded high-value analytes with a broad add-on, or value-based contracts. It sets the realizable price per run, the evidence payers will demand, and the revenue-per-cartridge assumptions underlying the business case. Key metrics are net revenue per test, coverage decisions obtained, days-sales-outstanding, and adoption at the achieved price.

**Why It Matters:** How the multiplex result is billed, whether as one bundled panel or as separately coded tests, determines payer scrutiny, price ceilings, and which customers can afford to adopt. Existing coding and coverage processes were built for individual tests, so a 500-analyte output may not map cleanly to any established payment pathway. Early choices on pricing and evidence for coverage shape the unit economics that Newark production capacity has to support.

**Strategic Choices:**

1. Price as a self-pay or employer-sponsored wellness and screening product that avoids insurer coverage, accepting a smaller addressable market in exchange for faster revenue.
2. Pursue payer coverage for a small number of high-value analytes with established billing codes, and use the broader panel as a non-billed add-on that gathers real-world evidence.
3. Negotiate value-based contracts with integrated health systems or risk-bearing payers who pay per patient managed, tying revenue to measured reductions in follow-up testing or visits.

**Trade-Off / Risk:** Each pricing route demands different evidence and sales capability, and none is validated for a 500-analyte output; the risk is building capacity sized for volumes that the chosen payment pathway never releases.

**Strategic Connections:**

**Synergy:** Strengthens Evidence Generation and Transparency, since payer-grade clinical utility data doubles as coverage evidence, and informs Design-to-Cost Ceiling and Unit Economics Gate by setting the price against which cartridge cost is tested.

**Conflict:** Conflicts with Newark Manufacturing Build-Out Timing and Assay Panel Architecture: capacity sized for a 500-analyte vision may outrun volumes any payment route releases, while coded-analyte coverage favors a narrower panel than the vision implies.

**Justification:** *Medium*, Sets realizable price per run and the revenue assumptions behind capacity sizing. Valuable, but it largely follows regulatory status and beachhead choice, and its levers are partly covered by the cost ceiling and funding path.

### Decision 11: Intellectual Property and Partner Leverage
**Lever ID:** `6b34b43a-fe63-41b4-a03b-8e4ae87d5c5b`

**The Core Decision:** Sets how the company secures freedom to operate and defensible differentiation in a crowded microfluidics, assay, and detection patent landscape, and whether it builds alone, licenses in, or co-develops. It governs royalty burden, exclusivity concessions, and acquirer appeal. Success is measured by a clean freedom-to-operate opinion, issued claims on core architecture, royalty rate stack, and partner-contributed validation capacity.

**Why It Matters:** The startup's freedom to operate in microfluidics, assay chemistry, and detection depends on a dense existing patent landscape, and its defensibility depends on what it chooses to protect, publish, or license. Partnerships with established diagnostics firms or contract manufacturers can supply reach and capacity but may claim rights, channels, or exclusivity. The balance affects valuation, acquirer interest, and how much of the build-out the company must fund itself.

**Strategic Choices:**

1. File a broad patent portfolio around the cartridge architecture and sample-partitioning method, and fund prosecution and freedom-to-operate analysis early to maximize standalone valuation.
2. License in enabling platform technology from universities or incumbents and focus proprietary effort on integration and manufacturing know-how, accepting royalty stacking and dependency on licensors.
3. Co-develop with an established diagnostics company under a structured partnership that trades some exclusivity for validation capacity, regulatory experience, and an existing distribution channel.

**Trade-Off / Risk:** Strong IP raises valuation but costs money and attention before a product exists, while partnering shortens the path at the price of control; the decision should follow an actual freedom-to-operate review, not precede it.

**Strategic Connections:**

**Synergy:** Amplifies Cartridge Fluidic Architecture and Integration Depth by protecting or licensing the core partitioning design, and complements Regulatory Route and Sequencing when a partner contributes regulatory experience and an existing channel.

**Conflict:** Trades off against Funding Path and Commercial Beachhead and Deployment Setting and Operator Model: partner exclusivity can restrict channel or customer choices, while a broad patent filing program consumes pre-revenue cash and management attention.

**Justification:** *Medium*, Affects freedom to operate, valuation and partner dependence, with links to fluidics, regulatory experience and funding. Important for defensibility but secondary to the technical and capital decisions that determine whether a product exists.

### Decision 12: Design-to-Cost Ceiling and Unit Economics Gate
**Lever ID:** `54dd682e-8c3b-4abd-9188-376021ab3e44`

**The Core Decision:** Sets a per-cartridge cost-of-goods limit and the decision rule for enforcing it, so that design options are judged against volume economics rather than technical elegance. Success metrics: modeled versus measured unit cost at pilot volume, gross margin at target price, and the number of architecture options rejected or redesigned because of the ceiling before freeze.

**Why It Matters:** Fixing a per-test-card cost ceiling early forces architecture choices (materials, reagent volumes, number of spotted analytes) to be judged against volume economics rather than purely technical elegance. Skipping the ceiling accelerates a first demonstration but risks a platform that works only at unsustainable cost. The ceiling also interacts with payer pricing and with Newark capital equipment choices.

**Strategic Choices:**

1. Fix a cost-of-goods ceiling per cartridge before architecture freeze and reject design options that cannot reach it at projected production volume.
2. Let performance lead through development and defer cost reduction to a post-clearance redesign cycle funded by early revenue and partner payments.
3. Work backward from the lowest credible reimbursement per patient panel, derive the allowable manufacturing cost, and shrink the panel scope whenever the derived cost cannot be met.

**Trade-Off / Risk:** A hard cost ceiling disciplines design, but set too early it can lock out the sensitivity needed for the harder analytes; set too late, the platform ships economically unviable and cannot be redesigned without repeating validation.

**Strategic Connections:**

**Synergy:** Strengthens Payer Coverage and Pricing Architecture by anchoring allowable cost to reimbursable price, and reinforces Feasibility Gates and Scope-Retreat Triggers by supplying a quantitative economic gate for releasing capital.

**Conflict:** Constrains Assay Panel Architecture, since a hard ceiling may force fewer or less sensitive analytes, and Cartridge Fluidic Architecture and Integration Depth, where cost-driven simplification can undercut the sensitivity that harder analytes need.

**Justification:** *High*, Imposes volume economics on architecture and links price, panel scope, cartridge design and capital release. It governs the performance versus affordability trade-off and acts as a quantitative gate, though it operates through the Critical levers.

### Decision 13: Talent Sourcing Geography and Hiring Sequence
**Lever ID:** `54cb6f85-c626-4b9d-a83c-24c456d9caae`

**The Core Decision:** Governs which scarce skills (microfluidics, assay chemistry, quality, regulatory, manufacturing) are hired first and where they sit relative to the Newark site. The sequence shapes technical culture, quality-system maturity and inspection readiness. Success metrics: time-to-fill for critical roles, runway burn per milestone, attrition, and readiness of design-control and quality documentation at each gate.

**Why It Matters:** The mix of microfluidics, assay chemistry, quality, and regulatory skills needed is scarce and competed for in the Bay Area, so who is hired first shapes the technical culture and the ability to pass inspections later. Early senior hires cost more but shorten learning curves; early academic-style hires explore faster but leave quality-system gaps. Location choices also affect cost and integration with the Newark site.

**Strategic Choices:**

1. Recruit a senior core of experienced IVD veterans from established Bay Area diagnostics firms first, accepting premium compensation to import manufacturing and quality discipline early.
2. Anchor R&D with academic collaborators and early-career scientists, and add manufacturing, quality, and regulatory leaders only as the design approaches freeze.
3. Distribute core engineering to a lower-cost hub outside the Bay Area through a remote-first R&D group, while keeping only manufacturing, quality, and clinical operations in Newark.

**Trade-Off / Risk:** Hiring veterans first buys process maturity but burns runway at premium salaries; a distributed model cuts cost yet strains the tight bench-to-pilot-line feedback loop that cartridge development depends on.

**Strategic Connections:**

**Synergy:** Enables Regulatory Route and Sequencing by bringing early regulatory and quality expertise, and accelerates Newark Manufacturing Build-Out Timing by supplying process engineers who can transfer designs from bench to pilot line.

**Conflict:** Competes for runway with Funding Path and Commercial Beachhead, since premium senior hiring accelerates maturity but burns capital, and conflicts with Intellectual Property and Partner Leverage where partner-supplied expertise might substitute for in-house hires.

**Justification:** *Low*, Largely an execution enabler: it supports regulatory readiness and Newark process transfer but is shaped by funding and manufacturing decisions rather than driving them. Its trade-offs are mainly runway burn and are tactical.

### Decision 14: Feasibility Gates and Scope-Retreat Triggers
**Lever ID:** `6bb5b966-7952-4e76-975f-90e9b98df502`

**The Core Decision:** Defines the evidence thresholds, capital-release triggers and retreat paths that govern whether the program proceeds toward 500 tests or narrows scope. It provides the governance backbone linking technical results to funding tranches. Success metrics: gate criteria agreed before data exist, decision latency after each gate, and avoidance of both sunk-cost escalation and premature termination on noisy data.

**Why It Matters:** Explicit gates define when evidence is strong enough to release the next tranche of capital and when to shrink ambition from 500 tests to a narrower product. Hard gates protect investors and the team from sunk-cost escalation but may end a promising platform on a noisy early dataset. Soft gates preserve optionality while risking prolonged spending on an unattainable target.

**Strategic Choices:**

1. Define quantitative go/no-go gates (proposed) at analytical feasibility, pilot-line reproducibility, and clinical concordance, and pre-commit capital release to each gate.
2. Pre-register a reduced-panel fallback product that activates automatically when multiplex crosstalk or sensitivity gates fail, so the company retreats to a sellable product rather than stopping.
3. Time-box each development phase with a fixed budget and calendar envelope, requiring a formal replan and board vote whenever either is exceeded, rather than relying on outcome-based gates.

**Trade-Off / Risk:** Pre-committed gates curb sunk-cost escalation, but thresholds set before real data exist are guesses; a fallback product keeps the company alive yet may quietly redefine the mission into a conventional panel business.

**Strategic Connections:**

**Synergy:** Amplifies Funding Path and Commercial Beachhead by giving investors tranche-linked proof points, and works with Evidence Generation and Transparency, whose analytical and clinical datasets supply the objective inputs for each gate decision.

**Conflict:** Tensions with Assay Panel Architecture, because a pre-registered reduced-panel fallback can quietly erode the 500-test mission, and with Newark Manufacturing Build-Out Timing, where hard gates delay committing capital to long-lead facility work.

**Justification:** *High*, Provides the governance backbone linking technical results to capital tranches and controlling the 500-test ambition versus sellable-product retreat. It connects funding, evidence, cost and Newark timing, protecting against sunk-cost escalation.
