### 1. Project Director drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start ASAP

### 2. Circulate Draft SteerCo ToR for review by Senior Government Official, Legal Counsel, Ethics and Compliance Officer, Financial Officer, Independent External Advisor, and Representative from the Department of Public Safety.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Director finalizes the Terms of Reference for the Project Steering Committee based on feedback.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior Government Official formally appointed as Chair of the Project Steering Committee.

**Responsible Body/Role:** Head of the Government Agency sponsoring the project

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Director formally invites nominated members to the Project Steering Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Invitation Emails
- Confirmed Membership List

**Dependencies:**

- Appointment Confirmation Email

### 6. Schedule the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Membership List

### 7. Hold the initial Project Steering Committee kick-off meeting to review the project charter, initial budget, and define escalation paths.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Project Charter
- Approved Initial Budget
- Defined Escalation Paths

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 8. Project Manager defines roles and responsibilities of Core Project Team members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Roles and Responsibilities Matrix

**Dependencies:**

- Project Start ASAP

### 9. Project Manager establishes communication protocols for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Communication Plan

**Dependencies:**

- Roles and Responsibilities Matrix

### 10. Project Manager develops the initial Project Management Plan.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Project Management Plan v0.1

**Dependencies:**

- Communication Plan

### 11. Project Manager sets up project tracking and reporting systems.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Tracking System
- Reporting Templates

**Dependencies:**

- Draft Project Management Plan v0.1

### 12. Project Manager defines operational decision thresholds for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Decision Threshold Document

**Dependencies:**

- Project Tracking System

### 13. Schedule the initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Decision Threshold Document

### 14. Hold the initial Core Project Team kick-off meeting to review the project plan, communication protocols, and decision thresholds.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Final Project Management Plan v1.0

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 15. Project Director drafts initial Terms of Reference for the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics and Compliance Committee ToR v0.1

**Dependencies:**

- Project Start ASAP

### 16. Circulate Draft Ethics and Compliance Committee ToR for review by Legal Counsel.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics and Compliance Committee ToR v0.1

### 17. Project Director finalizes the Terms of Reference for the Ethics and Compliance Committee based on feedback.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Ethics and Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 18. Head of the Government Agency sponsoring the project formally appoints Independent Ethics Expert as Chair of the Ethics and Compliance Committee.

**Responsible Body/Role:** Head of the Government Agency sponsoring the project

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics and Compliance Committee ToR v1.0

### 19. Project Director formally invites nominated members to the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Invitation Emails
- Confirmed Membership List

**Dependencies:**

- Appointment Confirmation Email

### 20. Schedule the initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Membership List

### 21. Hold the initial Ethics and Compliance Committee kick-off meeting to develop an ethical framework for the project and define procedures for investigating and resolving ethical complaints.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Ethical Framework v1.0
- Ethical Complaint Procedures v1.0

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 22. Project Director drafts initial Terms of Reference for the Technical Advisory Group.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Start ASAP

### 23. Circulate Draft Technical Advisory Group ToR for review by the Lead Game Designer and Head of Security.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1

### 24. Project Director finalizes the Terms of Reference for the Technical Advisory Group based on feedback.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 25. Project Director appoints Experienced Game Designer as Chair of the Technical Advisory Group.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Technical Advisory Group ToR v1.0

### 26. Project Director formally invites nominated members to the Technical Advisory Group.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Invitation Emails
- Confirmed Membership List

**Dependencies:**

- Appointment Confirmation Email

### 27. Schedule the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Confirmed Membership List

### 28. Hold the initial Technical Advisory Group kick-off meeting to identify key technical areas requiring expertise and recruit/onboard technical experts.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- List of Key Technical Areas
- Recruitment Plan

**Dependencies:**

- Meeting Invitation
- Meeting Agenda