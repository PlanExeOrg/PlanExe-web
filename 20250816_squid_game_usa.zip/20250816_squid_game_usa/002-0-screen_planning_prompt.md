**Verdict:** 🟢 USABLE

**Rationale:** The prompt describes a concrete project (a Squid Game competition) with specific details like budget, location (implicitly the US), and timeline (ASAP, weekly events). Despite the dark theme, it's a plannable event with logistics, participants, and spectators.