This plan involves money.

## Currencies

- **USD:** The project is based in the USA and the budget is specified in US dollars.

**Primary currency:** USD

**Currency strategy:** The project is based in the USA, so USD will be used for all transactions. No additional international risk management is needed.