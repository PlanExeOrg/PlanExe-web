## Positive Constraints

- Life-or-death competition 'Squid Game'
- Involuntary trajectory for citizens unable to pay their debts
- Squid events will be held in public on every Friday
- Spectators where VIP guests can purchase tickets
- Find suitable participants with minor or major debts
- National entertainment
- Boosting humans mental health
- Budget: $500 Million

## Negative Constraints

- Do not use VR
- Do not use AR
- Do not use DAO
- Do not use app
