**Purpose:** business

**Purpose Detailed:** Societal entertainment initiative, public spectacle, and debt management strategy.

**Topic:** Government-sponsored 'Squid Game' for entertainment and mental health boost.