Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 20 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 0 | Material risk with plausible path. |
| ✅ Low | 0 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because success requires breaking physical laws. The plan describes a real-life Squid Game with lethal competitions. This violates laws against murder, assault, and endangerment. "The Core Decision: This lever determines the level of danger and potential for death within the games."

**Mitigation**: Legal Team: Conduct a legal feasibility study by constitutional law experts to identify conflicting laws and develop alternative game formats complying with existing laws within 60 days.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of entertainment, debt relief, and government sponsorship without comparable real-world evidence. The plan states, "We introduce the **'Pioneer's Gambit'** – a bold, government-sponsored initiative to stage a real-life 'Squid Game'".

**Mitigation**: Project Management: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Project Lead / Deliverable: Validation Report / Date: 90 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because any strategic concept driving the plan is undefined. The plan mentions "Pioneer's Gambit" as a strategic path but lacks a one-pager defining its mechanism-of-action, owner, and measurable outcomes. The plan states, "The Pioneer's Gambit is the most suitable scenario because it directly addresses the plan's core characteristics".

**Mitigation**: Project Lead: Create a one-pager for "Pioneer's Gambit" defining its inputs, processes, customer value, owner, measurable outcomes, value hypotheses, success metrics, and decision hooks by next week.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major hazard class (legal) is absent. The plan acknowledges legal challenges but minimizes their severity, assuming waivers can be obtained. The plan states, "Secure necessary legal waivers or amendments to laws against murder, assault, and gambling."

**Mitigation**: Legal Team: Conduct a comprehensive legal risk assessment, mapping potential legal challenges and their cascade effects on the project timeline and budget within 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions the need for legal waivers but does not include a matrix detailing required permits, lead times, or dependencies. The plan states, "Secure necessary legal waivers or amendments to laws against murder, assault, and gambling."

**Mitigation**: Legal Team: Create a permit/approval matrix detailing all required permits, typical lead times in each jurisdiction, and dependencies within 60 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed sources/term sheets are absent. The plan mentions a $500M budget but lacks details on funding sources, draw schedules, or covenants. The plan states, "within a $500 million budget".

**Mitigation**: CFO: Develop a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO-GO on missed financing gates within 30 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget lacks substantiation. The plan mentions a $500 million budget, but there are no vendor quotes or scale-appropriate benchmarks normalized by area. The plan states, "within a $500 million budget".

**Mitigation**: CFO: Obtain ≥3 vendor quotes for game construction, security, and medical support, normalize costs per area, and adjust the budget or de-scope by 60 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections as single numbers without ranges or alternative scenarios. For example, the budget is stated as "within a $500 million budget" without sensitivity analysis.

**Mitigation**: CFO: Conduct a sensitivity analysis on the budget, creating best-case, worst-case, and base-case scenarios, and identify key drivers within 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because core components lack engineering artifacts. The plan lacks technical specifications, interface definitions, test plans, and an integration map. The plan states, "The 'Critical' and 'High' impact levers address the fundamental project tensions..."

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components within 90 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes critical legal claims without verifiable artifacts. The plan states, "Secure necessary legal waivers or amendments to laws against murder, assault, and gambling." There is no evidence of legal consultation or a strategy to obtain these waivers.

**Mitigation**: Legal Team: Conduct a legal feasibility study by constitutional law experts to assess the legal viability of the project and identify conflicting laws within 60 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "debt relief" without SMART criteria. The plan states, "to alleviate participants' financial burdens". There are no specific, verifiable qualities defining successful debt relief.

**Mitigation**: Financial Team: Define SMART criteria for debt relief, including a KPI for debt reduction (e.g., average debt reduction of $50,000 per participant) within 30 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes features that add cost/complexity without directly supporting core goals. The plan includes "Offer educational resources and financial literacy programs alongside the games". Core goals are entertainment and debt relief.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of financial literacy programs, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog by EOW.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a 'Game Design & Safety Engineer' to balance entertainment with participant safety. This role demands rare expertise in both creative game design and rigorous safety engineering, making it difficult to fill. The plan states, "Designs the games, ensuring they are both entertaining and safe for participants".

**Mitigation**: HR Team: Conduct a talent market analysis for a 'Game Design & Safety Engineer' with experience in both game design and safety engineering within 30 days to validate talent availability.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because legality is unclear and required approvals are unmapped. The plan states, "Secure necessary legal waivers or amendments to laws against murder, assault, and gambling." There is no regulatory matrix or fatal-flaw analysis.

**Mitigation**: Legal Team: Conduct a fatal-flaw analysis and create a regulatory matrix (authority, artifact, lead time, predecessors) for all required permits and waivers within 90 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a sustainable operational model. The plan mentions revenue from VIP tickets but doesn't address long-term funding for debt relief or post-game support. The plan states, "Generate revenue through VIP ticket sales".

**Mitigation**: CFO: Develop a 5-year operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms within 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires large venues with seating, medical facilities, and security. The plan states, "Requires large venues with seating, medical facilities, and security." It is unclear if zoning/land-use allows this activity.

**Mitigation**: Real Estate Team: Perform a fatal-flaw screen with zoning/land-use authorities for proposed sites, seeking written confirmation where feasible within 60 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks evidence of contracts or SLAs with vendors for critical services like medical support and security. The plan states, "Medical equipment and supplies" and "Security personnel and equipment" are required resources, but there is no mention of vendor contracts.

**Mitigation**: Procurement Team: Secure SLAs with backup provisions for medical support, security, and key vendors, including tested failover plans, within 90 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Finance Department is incentivized to minimize costs and adhere to a strict budget, while the Event Organizers are incentivized to maximize spectacle and entertainment value, potentially leading to conflicts over resource allocation. The plan states, "within a $500 million budget".

**Mitigation**: Project Lead: Create a shared OKR focused on maximizing both entertainment value (measured by viewership) and cost-effectiveness (measured by cost per viewer) to align Finance and Event Organizers within 30 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a change-control process. The plan states, "The 'Critical' and 'High' impact levers address the fundamental project tensions..." but lacks a process to monitor and adjust these levers.

**Mitigation**: Project Lead: Add a monthly review with a KPI dashboard and a lightweight change board with thresholds (when to re-plan/stop) within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has ≥3 Critical risks that are strongly coupled. Legal challenges (Risk 1), ethical concerns (Risk 2), and security breaches (Risk 3) are all tightly linked. Failure to obtain legal waivers directly exacerbates ethical concerns and increases security risks. The plan states, "Overwhelming risks across domains."

**Mitigation**: Project Lead: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds within 60 days.