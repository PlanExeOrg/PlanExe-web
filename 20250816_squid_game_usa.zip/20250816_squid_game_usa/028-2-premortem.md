A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Legal waivers for activities resulting in participant death can be obtained with reasonable effort. | Engage a constitutional law expert to assess the likelihood of obtaining waivers for activities that could result in death. | The legal expert concludes that obtaining such waivers is highly unlikely or impossible due to constitutional constraints. |
| A2 | Participants can fully understand and consent to the risks involved, and will not suffer long-term psychological harm. | Conduct a pilot study with a representative sample of potential participants, assessing their understanding of the risks and their psychological responses to simulated game scenarios. | The pilot study reveals that participants do not fully grasp the risks or exhibit signs of significant psychological distress. |
| A3 | Security measures can effectively prevent breaches and ensure the safety of participants and spectators, given the controversial nature of the event. | Conduct a comprehensive security risk assessment by an independent security firm, simulating various threat scenarios (e.g., sabotage, terrorism, crowd control issues). | The security risk assessment identifies significant vulnerabilities that cannot be effectively mitigated within the project's budget and resources. |
| A4 | Sufficient numbers of individuals will be willing to participate in a potentially lethal game, even with the promise of debt relief. | Conduct a survey and focus groups targeting the demographic most likely to participate, gauging their willingness to risk their lives for debt relief. | The survey and focus groups reveal a lack of interest in participating, with potential participants citing safety concerns and ethical objections. |
| A5 | The public will accept the 'Squid Game' concept as a form of entertainment, despite its controversial nature and potential for violence. | Conduct a public opinion poll to assess public attitudes towards the 'Squid Game' concept, focusing on ethical concerns, entertainment value, and potential social impact. | The public opinion poll reveals widespread disapproval of the 'Squid Game' concept, with respondents citing ethical objections and concerns about the normalization of violence. |
| A6 | The project can secure adequate insurance coverage to mitigate potential liabilities related to participant injuries or deaths. | Consult with insurance providers to assess the availability and cost of insurance coverage for the project, disclosing the inherent risks and potential liabilities. | Insurance providers decline to offer coverage or provide quotes that are prohibitively expensive, citing the high risk and potential liabilities associated with the project. |
| A7 | The necessary technology (e.g., surveillance, game control systems, medical monitoring) can be reliably implemented and maintained within the project's budget and timeline. | Conduct a detailed technical feasibility study, including vendor assessments, prototyping, and testing of key technological components. | The technical feasibility study reveals significant challenges in implementing and maintaining the required technology, exceeding budget and timeline constraints. |
| A8 | Participants will behave predictably and rationally during the games, allowing for effective risk management and control. | Conduct behavioral simulations and psychological profiling to assess potential participant behavior under stress and in competitive scenarios. | Behavioral simulations and psychological profiling reveal a high likelihood of unpredictable and irrational behavior, making risk management and control extremely difficult. |
| A9 | The project can effectively manage and mitigate potential environmental impacts (e.g., waste disposal, noise pollution, traffic congestion) to avoid negative consequences. | Conduct a comprehensive environmental impact assessment, identifying potential environmental risks and developing mitigation plans. | The environmental impact assessment reveals significant environmental risks that cannot be effectively mitigated within the project's budget and resources, potentially leading to legal challenges and public opposition. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Regulatory Black Hole | Process/Financial | A1 | Legal Counsel | CRITICAL (25/25) |
| FM2 | The Trauma Tsunami | Technical/Logistical | A2 | Participant Advocate | CRITICAL (20/25) |
| FM3 | The Security Meltdown | Market/Human | A3 | Security Director | CRITICAL (15/25) |
| FM4 | The Empty Arena Gamble | Process/Financial | A4 | Recruitment Lead | CRITICAL (25/25) |
| FM5 | The Public Outcry Implosion | Technical/Logistical | A5 | Public Relations Manager | CRITICAL (20/25) |
| FM6 | The Uninsurable Catastrophe | Market/Human | A6 | Financial Controller | CRITICAL (15/25) |
| FM7 | The Technological House of Cards | Process/Financial | A7 | Head of Engineering | CRITICAL (25/25) |
| FM8 | The Unpredictable Human Factor | Technical/Logistical | A8 | Game Master | CRITICAL (20/25) |
| FM9 | The Environmental Backlash | Market/Human | A9 | Environmental Compliance Officer | CRITICAL (15/25) |


### Failure Modes

#### FM1 - The Regulatory Black Hole

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Legal Counsel
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
The project's financial model hinges on the assumption that legal waivers can be secured. However, if constitutional law experts determine that obtaining waivers for activities resulting in participant death is impossible, the entire legal foundation crumbles. This triggers a cascade of financial consequences:

*   The project becomes illegal, halting all operations.
*   VIP ticket sales, the primary revenue stream, cease immediately.
*   Sponsors withdraw their funding due to legal and reputational risks.
*   The $500 million budget is rendered useless, as the core concept is unviable.
*   Legal liabilities and lawsuits from stakeholders (e.g., investors, participants' families) further deplete resources.

##### Early Warning Signs
- Constitutional law experts express strong reservations about the project's legality.
- Lobbying efforts to secure waivers face significant resistance from policymakers.
- Public opinion polls show declining support for the project due to legal concerns.

##### Tripwires
- Constitutional law experts rate the likelihood of obtaining necessary waivers as <= 10%.
- Lobbying efforts fail to secure support from key legislative committees after 60 days.
- Public opinion polls show >= 60% disapproval of the project's legality.

##### Response Playbook
- Contain: Immediately suspend all activities related to the original game concept.
- Assess: Conduct an emergency legal review to explore alternative game formats that comply with existing laws.
- Respond: Pivot to a less lethal game format or abandon the project entirely if no legally viable alternative can be found.


**STOP RULE:** Constitutional law experts definitively conclude that obtaining waivers for activities resulting in participant death is legally impossible.

---

#### FM2 - The Trauma Tsunami

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Participant Advocate
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project assumes participants can fully consent and won't suffer long-term harm. However, the reality of life-or-death games shatters this assumption. Participants, driven by desperation, may not fully grasp the psychological risks. The simulated game scenarios fail to capture the true horror. The result is a wave of psychological trauma:

*   Participants develop severe PTSD, anxiety, and depression.
*   The limited counseling resources are overwhelmed, leading to inadequate support.
*   Participants struggle to reintegrate into society, facing unemployment and social isolation.
*   Suicide rates among participants spike, triggering public outrage.
*   The project's reputation is irreparably damaged, leading to its shutdown.

##### Early Warning Signs
- Psychological screening reveals high rates of pre-existing mental health conditions among applicants.
- Participants exhibit signs of distress during simulated game scenarios.
- Counseling resources are stretched thin, with long wait times for appointments.

##### Tripwires
- Psychological screening reveals >= 40% of applicants have pre-existing mental health conditions.
- >= 20% of participants withdraw from the project due to psychological distress within the first 30 days.
- Counseling wait times exceed 14 days.

##### Response Playbook
- Contain: Immediately suspend recruitment and game activities.
- Assess: Conduct a comprehensive review of the psychological screening and support protocols.
- Respond: Increase counseling resources, revise the game format to reduce psychological stress, and offer alternative debt relief options for those who withdraw.


**STOP RULE:** Suicide rate among participants exceeds 5% within one year of game completion.

---

#### FM3 - The Security Meltdown

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Security Director
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project assumes security measures can effectively prevent breaches. However, the controversial nature of the event attracts extremists and saboteurs. The security risk assessment underestimates the sophistication of potential threats. The result is a catastrophic security failure:

*   A terrorist group attacks the venue, causing mass casualties.
*   A disgruntled employee sabotages the game, leading to participant deaths.
*   Hackers breach the security system, exposing participant data and disrupting the event.
*   Public trust is shattered, leading to widespread condemnation.
*   The project is shut down, facing legal action and financial ruin.

##### Early Warning Signs
- Online forums show increased chatter about disrupting the event.
- Security personnel report suspicious activity near the venue.
- The security system experiences repeated hacking attempts.

##### Tripwires
- Online threat monitoring identifies >= 5 credible threats against the event.
- Security personnel report >= 3 suspicious incidents per week near the venue.
- The security system experiences >= 5 hacking attempts per day.

##### Response Playbook
- Contain: Immediately evacuate the venue and suspend all game activities.
- Assess: Conduct a thorough security review to identify vulnerabilities and strengthen security protocols.
- Respond: Increase security personnel, implement advanced surveillance technology, and coordinate with law enforcement agencies.


**STOP RULE:** A successful security breach results in injuries or fatalities.

---

#### FM4 - The Empty Arena Gamble

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Recruitment Lead
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
The project's financial viability depends on attracting participants. If few are willing to risk their lives, the entire model collapses:

*   Recruitment efforts fail, leaving the games empty.
*   VIP ticket sales plummet due to lack of spectacle.
*   Sponsors withdraw, fearing association with a failed venture.
*   The $500 million budget is wasted on empty venues and unused infrastructure.
*   The project is deemed a public embarrassment and shut down.

##### Early Warning Signs
- Recruitment numbers fall far short of projections.
- Potential participants express reluctance due to safety concerns.
- Advertising campaigns fail to generate significant interest.

##### Tripwires
- Recruitment numbers are <= 25% of the target after 60 days.
- Survey data shows >= 70% of potential participants are unwilling to risk their lives.
- Website traffic and application submissions are <= 50% of projections.

##### Response Playbook
- Contain: Immediately reassess the recruitment strategy and incentives.
- Assess: Conduct market research to understand the reasons for low participation.
- Respond: Increase the prize money, reduce the lethality of the games, or offer alternative incentives.


**STOP RULE:** Recruitment numbers remain below 50% of the target one month before the scheduled start of the games.

---

#### FM5 - The Public Outcry Implosion

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Public Relations Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project assumes public acceptance, but the reality is widespread outrage:

*   Ethical objections dominate public discourse.
*   Protests erupt outside venues, disrupting events.
*   Social media campaigns condemn the project as exploitative.
*   Advertisers boycott the games, fearing reputational damage.
*   The government withdraws support, bowing to public pressure.

##### Early Warning Signs
- Public opinion polls show declining support for the project.
- Social media sentiment turns overwhelmingly negative.
- Advertisers express concerns about associating with the games.

##### Tripwires
- Public opinion polls show >= 60% disapproval of the project.
- Social media sentiment is >= 70% negative.
- Major advertisers withdraw their sponsorships.

##### Response Playbook
- Contain: Immediately launch a crisis communication campaign to address ethical concerns.
- Assess: Conduct focus groups to understand the reasons for public outrage.
- Respond: Revise the game format to reduce violence, increase transparency, and emphasize the debt relief aspect.


**STOP RULE:** The government withdraws its support due to public pressure.

---

#### FM6 - The Uninsurable Catastrophe

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Financial Controller
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project assumes adequate insurance coverage can be secured. However, the inherent risks make it uninsurable:

*   Insurance providers refuse to offer coverage, deeming the project too risky.
*   The project is exposed to massive liabilities in case of participant injuries or deaths.
*   Potential investors are scared off by the lack of insurance.
*   The project becomes financially unsustainable and collapses.
*   Legal challenges from injured participants or their families bankrupt the organization.

##### Early Warning Signs
- Insurance providers express reluctance to offer coverage.
- Insurance quotes are prohibitively expensive.
- Potential investors demand proof of adequate insurance.

##### Tripwires
- Insurance providers decline to offer coverage after 60 days of negotiations.
- Insurance quotes exceed 20% of the total project budget.
- Potential investors withdraw their funding due to lack of insurance.

##### Response Playbook
- Contain: Immediately explore alternative risk mitigation strategies.
- Assess: Conduct a comprehensive legal review to assess potential liabilities.
- Respond: Revise the game format to reduce risks, seek government indemnification, or abandon the project.


**STOP RULE:** The project is unable to secure adequate insurance coverage to mitigate potential liabilities.

---

#### FM7 - The Technological House of Cards

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
The project's reliance on complex technology creates a fragile system. If the technology fails, the consequences are dire:

*   Surveillance systems malfunction, compromising security.
*   Game control systems glitch, leading to unfair outcomes and participant injuries.
*   Medical monitoring fails, delaying critical care and increasing fatalities.
*   The project faces lawsuits, reputational damage, and financial losses.
*   The entire operation grinds to a halt, deemed unsafe and unreliable.

##### Early Warning Signs
- Technology vendors express concerns about meeting project requirements.
- Prototyping reveals glitches and instability in key systems.
- Testing uncovers vulnerabilities in the security infrastructure.

##### Tripwires
- Key technology vendors fail to meet performance benchmarks after 60 days.
- Prototyping reveals >= 3 critical system failures per week.
- Security testing uncovers >= 5 high-severity vulnerabilities.

##### Response Playbook
- Contain: Immediately suspend all game activities and isolate affected systems.
- Assess: Conduct a thorough technical review to identify the root cause of the failures.
- Respond: Implement backup systems, revise technology specifications, or seek alternative solutions.


**STOP RULE:** Critical technology systems remain unreliable after three attempts to fix them.

---

#### FM8 - The Unpredictable Human Factor

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Game Master
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project assumes participants will behave rationally, but desperation and competition breed chaos:

*   Participants collude, cheat, or sabotage the games.
*   Violence erupts between participants, overwhelming security.
*   Participants refuse to follow instructions, disrupting the event.
*   The game becomes unmanageable, leading to injuries and fatalities.
*   The project is deemed too dangerous and shut down.

##### Early Warning Signs
- Behavioral simulations reveal a high likelihood of cheating and collusion.
- Security personnel report increasing tension and aggression among participants.
- Participants express dissatisfaction with game rules and procedures.

##### Tripwires
- Behavioral simulations predict >= 50% of participants will attempt to cheat or collude.
- Security personnel report >= 3 violent incidents per week among participants.
- Participant surveys show >= 40% dissatisfaction with game rules.

##### Response Playbook
- Contain: Immediately suspend the game and isolate disruptive participants.
- Assess: Review game rules and security protocols to identify weaknesses.
- Respond: Implement stricter penalties for rule violations, increase security presence, and revise game design to reduce opportunities for cheating and violence.


**STOP RULE:** Uncontrollable violence erupts between participants, resulting in serious injuries or fatalities.

---

#### FM9 - The Environmental Backlash

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Environmental Compliance Officer
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project overlooks the environmental impact, triggering public outrage and legal challenges:

*   Waste disposal contaminates local water sources.
*   Noise pollution disrupts nearby communities.
*   Traffic congestion overwhelms local infrastructure.
*   Environmental groups launch protests and lawsuits.
*   The project faces permit revocations, fines, and reputational damage.

##### Early Warning Signs
- Environmental impact assessments reveal significant risks.
- Local residents complain about noise and traffic.
- Environmental groups organize protests against the project.

##### Tripwires
- Environmental impact assessments predict >= 3 significant environmental risks.
- Local resident complaints about noise and traffic exceed 100 per week.
- Environmental groups file lawsuits against the project.

##### Response Playbook
- Contain: Immediately suspend activities that contribute to environmental damage.
- Assess: Conduct a thorough environmental audit to identify the extent of the impact.
- Respond: Implement mitigation measures, compensate affected communities, and engage with environmental groups to address their concerns.


**STOP RULE:** The project faces legal action resulting in permit revocations or significant fines related to environmental damage.
