Persuasive elevator pitch.

# Bilateral AI Frontier-Technology Verification Consortium

## Project Overview

Uncontrolled frontier AI computing represents a strategic threat neither the US nor China can ignore. The Consortium bridges the gap between suspicion and verification: a **90-day test of a revolutionary bilateral mechanism** to detect undeclared changes to computing equipment at declared datacenters. Built on **double-key governance**, mirrored inspection teams, and cryptographic ledgers that neither side controls alone, it proves that **transparent verification of critical technology is possible** without surrendering intellectual property or national security. A Go decision at Month 10 (2027-08-08) enables phased expansion to additional sites and sets the precedent for reciprocal high-stakes verification between great powers.

## Target Audience

US and Chinese national security leadership, appropriations authorities, datacenter operators in both countries, and equipment vendors. Secondary audiences include bilateral treaty implementers, arms-control verification experts, and domestic legislatures that must authorize funding and access authority. The pitch assumes skepticism about reciprocity and sensitivity to intellectual property exposure, with emphasis on the mechanism's safeguards and the strict gating that keeps the test clean.

## Risks and Mitigation Strategies

- **Entry delays** (vetting, domestic authority) can slip the clock by 3 months and cost USD 150–300M; weekly co-chair reviews, strict gate milestones and a Month 9 (2027-07-08) backstop force decision
- **Ledger divergence or sync failure** triggers automatic escalation and suspension protocols; a joint forensic panel (3–5 per side, 48-hour findings) resolves contested identities
- **Vendor refusal** leaves equipment unverifiable; a pre-bound pool of 3–5 examiner labs per country and clean-room facilities per region (agreements by Month 4 = 2027-02-08) provide fallbacks on a day-10 ladder
- **Intellectual property exposure** causes consent withdrawal; narrow marked zones, audited operator redaction and three-tier infraction enforcement limit risk

A contingency fund of USD 500M (double-key release, fast lane up to USD 50M) absorbs identified fallbacks.

## Metrics for Success

**Detection performance:**

- Blind-challenge detection of at least 90% unreported arrivals, 85% substitutions, 80% record falsifications (provisional, validated in pre-clock calibration)
- False positives <5%
- Parity between US and China results within 20%

**Operational and integrity targets:**

- Unresolved discrepancies <10% of events
- Unverifiable equipment <5% per site
- Zero unresolved ledger divergence >7 days
- Zero material asymmetric-access or IP/counterintelligence incidents

**Schedule and governance:**

- Entry certification achieved by Month 6 (2027-04-08)
- Phase One completes on schedule
- Final decision issued by Month 10 (2027-08-08) with documented, double-key justification that both governments accept as principled rather than tuned

## Stakeholder Benefits

- **US and China:** Credible bilateral verification mechanism with no known precedent, insulating critical-technology policy from mutual suspicion
- **Operators:** Participation protects them against unilateral sanctions and provides legitimate channel for compliance
- **Vendors:** Pre-binding agreements and fallback examiner pools remove surprise and uncertainty
- **Legislatures and treasuries:** Auditable, principled decision process with double-key governance ensures no single side manipulates the outcome
- **Inspectors:** Carefully vetted, rotating teams with conduct oversight and separation of duties reduce espionage and coercion risk

The mechanism succeeds only if both sides benefit equally; asymmetry triggers automatic suspension.

## Ethical Considerations

The Consortium respects **sovereignty and reciprocity**: each government vets its own inspectors, administers its own spending, and holds a veto on every decision. No unilateral truth-seeking. Bounded zones and operator-run, audited redaction protect intellectual property and workload confidentiality; evidence is filtered before it leaves the site. Inspector conduct is governed by joint rules and monitored by both sides; no single-country surveillance. Equipment identity is confirmed only when independent evidence layers agree; no source is decisive. The 90-day gate ensures setup is complete and honest before evidence-gathering begins. The design assumes absent trust and builds reciprocity through mechanism, not hope.

## Collaboration Opportunities

This is a **co-creation effort**: 

- Independent testing unit staffing (red teams, neutral-country officials)
- Accredited examiner networks and clean-room facilities
- Third countries and private research organizations can contribute expertise
- Bilateral treaty precedent opens doors for extensions to additional sites, allied governments, and other critical-technology domains (semiconductors, supply chains, pharmaceuticals)
- Arms-control and verification communities can co-author standards for bilateral technology verification that transcend this first test
- Equipment vendors can shape fallback examiner-pool training and validation protocols
- Legislators and auditors from both countries gain high-visibility oversight roles

Success catalyzes a shared toolbox for reciprocal technology verification between governments.

## Long-Term Vision

A single 90-day test is a proof-of-concept; success enables a **phased expansion to additional sites and equipment classes**, deepening bilateral transparency on frontier computing without requiring unified global AI governance. Over 24–36 months, the mechanism can mature into a standing body managing multiple sites, vendor relationships and continuous evolution of the covered-equipment schedule. Beyond US–China, reciprocal verification models inform alliance partnerships and multilateral frameworks for critical technologies. This is not comprehensive AI governance; it is focused, bounded, bilateral, and auditable verification of the equipment changes most likely to signal an asymmetric leap. It buys time for policy to catch up with technology and demonstrates that great-power verification of frontier technology is possible. Long-term impact: a new generation of **verification practice between actors with conflicting interests** but aligned recognition that uncontrolled change is worse for both.

## Call to Action

- **Authorize bilateral instrument signature** by Month 2 (2026-12-08), commit appropriations (USD 2.5B per country) by Month 3 (2027-01-08), and nominate sites for joint pairing within 4 weeks
- **Designate co-chairs** and establish a weekly entry-condition review cadence starting Month 0 (2026-10-08)
- **Parallel domestic action:** Each government initiates domestic access-authority legislation, inspector vetting, and operator engagement
- **Gate compliance:** The 90-day clock starts only when all 7 entry conditions are certified; this gating protects both sides against setup failure
- **Backstop decision:** Failure to reach certification by Month 9 (2027-07-08) triggers a double-key decision to extend or stop
