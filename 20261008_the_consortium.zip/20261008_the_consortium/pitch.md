Persuasive elevator pitch.

# US–China Bilateral Frontier-Computing Verification Consortium: Phase One Operational Test

## Project Overview

Imagine two great powers verifying the other's frontier-computing hardware without exposing secrets or breaking trust. The Consortium is the first bilateral US–China mechanism to prove this is possible: a 90-day operational test verifying **declared equipment changes** at matched datacenters, using tamper-evident ledgers, reciprocal inspections and provisional validated thresholds. With USD 5 billion in committed appropriations, full mirrored teams and independent exercises, it answers whether **credible detection is achievable between adversaries**. Success brings strategic stability; failure informs what not to do next. This is not arms control as usual—it is **verification engineering at the edge of feasibility**.

The project scope is strictly bounded: declared-equipment change verification at participating declared sites only. The program is a sovereign public-sector national-security initiative with no commercial elements.

## Target Audience

The primary audience comprises US and Chinese national co-chairs, bilateral oversight bodies, and legislative appropriations committees evaluating strategic investment. Secondary audiences include participating inspectorates, operators and vendors assessing participation costs and benefits; third-country neutral facility hosts and independent auditors; and arms-control experts and academic verification researchers seeking precedent and lessons. 

The pitch must convince sovereigns that the mission is worth USD 5 billion, operationally feasible and honest about limits.

## Risks and Mitigation Strategies

**Entry gates slip, compressing the test and widening statistical uncertainty.** Mitigation: binding roadmap with 2-week escalation and 4-week re-scope backstop. Any gate slipping over 2 weeks triggers an emergency co-chair summit within 5 days; if the entry gate is not certified by Month 9 (2027-07-08), a formal Stop/re-scope decision is invoked.

**Asymmetric access undermines parity.** Mitigation: pre-clock reciprocal-access audit and hard stop on shielding. If access is found to be asymmetric or material unverifiable equipment exceeds thresholds (over 10% at a site or overall), the project halts.

**Thin exercise data makes the verdict ambiguous.** Mitigation: pre-register thresholds, lock before the clock, and default to Modify when intervals straddle a decision boundary.

**Ledger divergence blocks evidence.** Mitigation: rehearsed key recovery and hourly digest exchange with alerts. Local recording occurs at event time (at most 5 minutes); counterpart signed-digest exchange occurs at least every 1 hour; alerts trigger when an exchange is overdue by 30 minutes; mismatch is escalated within 4 hours with a reconciliation target of 72 hours.

**Funding is withheld by either country.** Mitigation: synchronized tranches with 14-day escalation and 30-day stop trigger. Tranche delay over 14 days escalates to co-chair review; delay over 30 days or unequal deposits unresolved activates the stop trigger.

**Inspectors are exposed to counterintelligence threats.** Mitigation: compartmentalization, filtered evidence, and CI Oversight Board oversight. Inspectors are compartmentalized by role and site with debriefs and monitored cooling-off before reassignment; no personal phones on site. A CI Oversight Board of 3 officers per side investigates breaches within 48 hours, recommends within 72 hours, and decides within 7 days.

**Staffing attrition in 24/7 shifts.** Mitigation: staggered rotations and leave buffers built into the staffing model.

## Metrics for Success

**Detection capability** is measured as:

- At least 70% of planned-event class (unreported arrival, substitution)
- At least 50% of unplanned class (vendor refusal, reluctant operator)
- Class thresholds for the remaining three event types to be determined at pre-registration

**Data quality and parity** are measured as:

- False positives at most 10%
- Unverifiable equipment at most 5%
- Reciprocal-access parity at least 85%
- No discrepancy older than 21 days at conclusion
- Fewer than 5 open material discrepancies

**Ledger integrity** is measured as:

- Zero unauthorized signings
- Hourly digest exchange with mismatch escalation within 4 hours
- Reconciliation within 72 hours

**Exercise Authority performance** is measured as:

- 54 total exercises in 90 days (6 per month per country-pair across 3 pairs)
- Scenario coverage across all seven event types
- Independent scoring by mixed-nationality teams

**Inspectorate deployment** is measured as:

- 80% certification by Month 5 (2027-03-08)
- Full deployment by Month 5.5 (2027-03-23)
- Zero production disruption
- Zero confirmed IP or cyber breaches

**Audit completeness** is measured as:

- 100% envelope mapping sampled
- At most 2% exceptions

**Adjudication workload** is measured as:

- Planned capacity of 15 cases per month
- Escalation if exceeded

**Go verdict threshold:** At least 4 of 5 scored criteria met (detection, false positives, unverifiable equipment, reciprocal-access parity, discrepancy age), fewer than 5 open material discrepancies, no hard stop trigger, and intervals not straddling a threshold.

## Stakeholder Benefits

**Co-chairs** gain a credible test of bilateral verification feasibility, a framework for detecting undeclared equipment changes, and documented operational lessons that shape future policy.

**Inspectorates** gain full-time employment, training in frontier-computing inspection, and a pathway to permanent roles.

**Operators** secure home-government compensation, controlled access limits, and demonstrated fairness through reciprocal inspection.

**Vendors** participating in fallback exercises gain credibility as trustworthy; those declining gain documented exclusion.

**Auditors and neutral hosts** gain paid engagements and reputation as guarantors of integrity.

**Legislative bodies** gain transparency on spending, envelope mapping and stopping conditions, plus proof that verification of sensitive domains is achievable.

## Ethical Considerations

This project is built on **double-key governance**: neither country unilaterally controls the outcome. Compartmentalized inspectors protect sensitive technology without hiding evidence—filtered packages are certified by independent auditors, and raw evidence is available in a joint reading room after formal challenge. 

Entry gates and hard stop triggers are pre-registered to block political gaming of ambiguous results. The verdict defaults to Modify when statistical intervals are ambiguous, not to Go based on hope. Provisional thresholds are validated against historical data before deployment.

Operator and vendor compensation is transparent and administered by home governments. Language of record is dual-authoritative with a controlled glossary to prevent translation weaponization. All spending is mapped to envelopes and independently audited.

**Failure is accepted and informative**: a Stop verdict or key suspension does not require confession, only transparent deadlock procedures.

## Collaboration Opportunities

- **Independent Exercise Authority:** Mixed-nationality core team of 8 staff plus red teams from both countries design and score all 54 blind challenges.
- **Neutral facility host:** Joint neutral secure facility (Geneva or Singapore; site choice to be decided by Month 1 = 2026-11-08), at least 1,000 sq m, operational by Month 3 (2027-01-08).
- **Independent filter auditor:** Third-country auditor certifies that evidence packages omit nothing event-relevant before counterpart disclosure.
- **Envelope and compliance auditors:** Conduct envelope reconciliation and compliance testing (100% sampling of high-risk categories).
- **Accredited independent examiners:** From both countries, execute vendor-refusal fallback ladders.
- **Technical specialists:** From both sides, form rotating evidence-weighting committees, validated against blind outcomes.
- **Arms-control institutes and academic verification researchers:** Observe declassified process and outcomes to build precedent.
- **Bilateral legal implementation team:** Ensures instrument consistency and enforceability.

## Long-term Vision

Phase One is a 90-day proof-of-concept of declared-equipment change verification at matched sites. If the Go verdict is reached, Phase Two (not yet funded) could extend to additional sites, longer duration or broader equipment scope. If Modify, the verdict specifies rework: stronger evidence rules, more exercises, tighter synchronization bounds, or revised thresholds. If Stop, the outcome documents what broke: access asymmetry, shielding, ledger failure or statistical insufficiency—knowledge that shapes whether verification of frontier computing is feasible at scale.

Beyond this bilateral frame, success establishes a **replicable model** for three-country, regional or treaty-based verification of sensitive technology. Lessons on double-key governance, compartmentalization, tamper-evident ledgers and reciprocal challenge exercises are relevant to future arms-control regimes. 

The project does not aim to solve verification permanently; it aims to prove that the problem is tractable, establish the operational and political costs, and **inform the next iteration**.

## Call to Action

Both governments must commit to the bilateral instrument and domestic appropriations by Month 2 (2026-12-08), triggering the first tranche (USD 625 million per country) and entry-gate clock.

Co-chairs must sign off on matched-pair selections by Month 3 (2027-01-08) and certify the entry gate by Month 5.5 (2027-03-23). If either milestone slips more than 2 weeks, a 5-day emergency co-chair summit is convened. If the entry gate is not certified by Month 9 (2027-07-08), the scope-reduction backstop is invoked.

Operators must submit Statements of Cooperation and access schedules by Month 3 (2027-01-08).

Independent auditors and neutral-facility hosts should signal availability by Month 1 (2026-11-08).

The 90-day clock starts only when all gates are certified (target Month 5.5 = 2027-03-23); the verdict is delivered by Month 9.5 (2027-07-23).