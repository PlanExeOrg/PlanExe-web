# Purpose

**Purpose:** business

**Purpose Detailed:** Large-scale, sovereign public-sector national-security and governmental initiative, not a for-profit venture. It covers strategic planning and program/project management for a bilateral verification institution: a replicated tamper-evident ledger, an Intake Protocol and Exit Protocol, mirrored full-time inspectorates, double-key co-governed decision-making, live challenge exercises, KPI-based evaluation, and a final Go/Modify/Stop decision. Scope is limited to monitored changes at participating declared sites. The program is funded by appropriations (USD 2.5 billion from each country) and involves cross-border governance, infrastructure, and fiscal accountability. Under the classification rules, governmental, societal-scale and infrastructure initiatives count as "business" even though the plan has no commercial or profit motive.

**Topic:** The Consortium: a jointly governed US–China verification mechanism for declared frontier-relevant computing equipment changes (arrivals, installations, removals, transfers, maintenance changes, decommissioning) at a small matched set of declared datacenters, with a 90-day Phase One operational test and a USD 5 billion budget split 50/50

# Domain

**Primary domain:** Arms Control Verification

**Secondary domains:** Hardware Supply Chain Security, Treaty Law, Counterintelligence and Information Security

**Rationale:** Arms Control Verification is the outcome discipline with the highest importance × specificity (25). Its mission is bilateral verification of declared equipment changes under mutual distrust. Bilateral Program Management is also an outcome but scores lower (20) and is a delivery vehicle. Treaty Law, Counterintelligence and Information Security, and the method candidates are subordinate.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Arms Control Verification | 5 | 5 | outcome | Core mission is bilateral inspection and verification of declared equipment changes under mutual distrust. |
| Counterintelligence and Information Security | 5 | 4 | constraint | Protecting sensitive IP, security architecture and inspector conduct under mutual distrust is a blocking requirement. |
| Distributed Ledger Engineering | 4 | 5 | method | Replicated tamper-evident ledger with independent national copies and bounded synchronization is a core mechanism. |
| Bilateral Program Management | 5 | 4 | outcome | Owns delivery of the 90-day test, workstreams, staffing, and Go/Modify/Stop decision. |
| Hardware Supply Chain Security | 4 | 4 | method | Intake, identity verification, custody, vendor binding and attestation of computing equipment. |
| Treaty Law | 4 | 4 | constraint | Bilateral instrument, double-key governance, domestic access authority and reciprocity require legal structuring. |
| Red Team Testing | 4 | 4 | method | Blind live challenge exercises determine detection credibility and drive the Go/Modify/Stop decision. |
| Public Financial Management | 4 | 4 | constraint | Governs the 50/50 USD 5 billion appropriations, envelopes, contingency, and fiscal accountability. |
| Datacenter Operations | 4 | 4 | method | Staging, installation, maintenance, and decommissioning of equipment at declared sites without disrupting production. |

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** The plan is physical. It sets up a bilateral inspection and verification mechanism for computing equipment at declared datacenters in the United States and China, and almost every part of it needs a real-world presence. Inspectors work in shifts at the sites, which means travel, secure facilities, and mirrored national teams on the ground. The Intake Protocol checks equipment identity in controlled staging areas before installation, using physical inspection, equipment identifiers, and witnessed movement. The Exit Protocol covers witnessed destruction, verified permanent disablement, and transfers between sites, all of which are physical acts that must be observed in person. Live challenge exercises run in staging, spare-inventory, maintenance, and expansion areas of operating datacenters. They involve unreported arrivals, substituted equipment, delayed access, and vendor refusal, and these are physical events. Site preparation and operator compensation (USD 1 billion), secure facilities, and secure clean-room procedures also need construction, hardware, and physical security. The replicated, tamper-evident ledger, the attestation systems, and the double-key governance are digital components. They still depend on physical hardware, secure communications facilities, and in-person meetings of the co-chairs, and their purpose is to record and support physical events. The plan cannot be completed entirely online, and it benefits heavily from physical presence, so it is classified as physical.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- United States and China territory (one datacenter in each country or a small matched set in each)
- Declared frontier-relevant computing equipment at the datacenter
- Staging and controlled intake areas for equipment identity verification
- Spare-inventory, maintenance, and expansion bays for third-party access and live exercises
- Secure facilities for shift-based inspector teams (24/7 coverage)
- Secure communications infrastructure for replicated, tamper-evident ledger synchronization
- Facilities for operator-run evidence redaction and inspector audit
- Emergency response and rapid-call access for urgent maintenance windows
- Accessibility for bilateral meetings and adjudication activities
- Proximity to third-party maintenance, logistics and destruction facilities (for exit disposition witnessing)
- Observable parity in event frequency, staging layout, and vendor dependence (for matched-site selection)
- Sufficient complexity and third-party-access traffic to test detection credibly (at least one deliberately hard site per country)
- Operator willingness to participate and bind vendors to reporting, confidentiality and escort requirements

## Location 1
United States

Silicon Valley / San Francisco Bay Area, California

Major hyperscaler datacenter campus (e.g., within Google, Meta, or AWS regional cluster) with existing security infrastructure, staging facilities, and vendor ecosystem

**Rationale**: Datacenters in this region host frontier computing equipment, have mature staging and maintenance areas, established third-party vendor and logistics networks, secure facilities for personnel, and operator experience with bilateral agreements. Bay Area geography allows secure facility co-location for ledger, communications and bilateral operations. High equipment-change frequency and complex vendor dependencies provide realistic testing ground for detection and vendor-refusal protocols.

## Location 2
United States

Northern Virginia (Loudoun County area)

Tier-1 hyperscaler or US government contractor datacenter with existing government security clearances and facility hardening

**Rationale**: Northern Virginia hosts multiple large-scale datacenters with existing government contracts, integrated cybersecurity infrastructure, and established secure communications capabilities. Proximity to Washington DC enables bilateral government coordination. Existing personnel vetting and security protocols reduce entry-condition timeline. Government contractor experience with bilateral oversight and classified operations reduces compliance friction.

## Location 3
China

Beijing or Shanghai metropolitan region

Tier-1 state-owned or state-backed datacenter operator facility (e.g., within China Telecom, China Unicom, or Alibaba infrastructure) with government relationships and existing security hardening

**Rationale**: State-owned or aligned operators in Beijing and Shanghai have frontier computing equipment, established maintenance and staging areas, and direct government authority needed to compel participation and bind vendors. Government-backed operators facilitate Chinese government's direct political backing and domestic access authority. Shanghai's East-West geography mirrors US site accessibility for bilateral operations.

## Location 4
China

Shenzhen or Chengdu

Alternative Tier-1 state-backed datacenter with complex equipment mix and high third-party-access traffic

**Rationale**: Shenzhen and Chengdu datacenters offer geographic diversity from Beijing/Shanghai, differ in equipment profiles and vendor dependencies, and provide harder test cases for detection (Decision 6: deliberately hard site per country). Chengdu's distance from coast tests logistics and exit-disposition witnessing capabilities. Alternative selection reduces either government's ability to steer site pairing.

## Location Summary
The Consortium is a bilateral US–China verification mechanism with operations at "a small, matched set of declared datacenters" in both countries. The plan explicitly requires physical presence: shift-based inspector deployment at participating sites, controlled staging areas for equipment intake, maintenance and expansion bays, third-party escort and access areas, and secure facilities for bilateral meetings and ledger operations. Phase One cannot proceed without site selection and matching as a mandatory entry condition. No specific datacenter locations are named in the plan; site selection is deferred to a structured decision process governed by Matched Site Selection Logic (Decision 6).

# Currency Strategy

This plan involves money.

## Currencies

- **USD:** Primary currency specified in the user constraint: USD 5 billion total budget (USD 2.5 billion per country). All budget envelopes (secure ledger, site preparation, personnel, facilities, testing, legal implementation, contingency) are denominated in USD. Essential for consolidated bilaterally reviewed fiscal accounting and US government appropriations.
- **CNY:** China's domestic appropriations and compensation to operators, vendors, and personnel will be administered by the Chinese government in Chinese yuan. Necessary for domestic government budget execution, domestic personnel compensation, and payment to Chinese-based vendors and maintenance providers at Chinese participating sites.

**Primary currency:** USD

**Currency strategy:** The program uses a split-currency model consistent with sovereign national budgeting. USD is the primary currency for consolidated bilateral budget reporting, all appropriations governance references (user constraint: USD 5 billion, split USD 2.5 billion each), and cross-border financial transparency required for dual-track double-key fiscal accountability. Each government administers its own USD 2.5 billion contribution domestically: the US executes its contribution in USD; China converts its share to CNY for domestic operator compensation, vendor payments, and personnel salaries at Chinese sites. All inter-governmental budget transfers and consolidated financial reporting use USD to maintain a single transparent ledger of the 50/50 split. Quarterly budget reconciliation and final audit reports use USD, with CNY conversion rates documented for transparency. No hedging is required within the 90-day Phase One test window; the focus is administrative clarity and fiscal accountability to both governments' oversight bodies.

# Identify Risks


## Risk 1 - Regulatory & Permitting
Mandatory entry conditions (signed bilateral instrument, appropriations, domestic access authority, site approval, inspector vetting, vendor participation, equipment schedule) sit outside the 90-day clock. Delays in any condition block Phase One start indefinitely. Most vulnerable are inspector vetting (counterintelligence clearances on both sides), domestic legislation enacting legal authority to compel operator and vendor cooperation, and approval of the confidential covered-equipment schedule. Neither government controls the other's administrative pace.

**Impact:** Phase One clock not starting by Month 6–9 (2027-04-08 to 2027-07-08), or starting with partial entry conditions that degrade verification validity. If domestic authority legislation stalls in either parliament, the test cannot start. If inspector vetting extends beyond Month 3–4 (2027-01-08 to 2027-02-08), competing security priorities may deprioritize clearances. Estimated delay: 4–8 months per unresolved condition; total risk: 50% probability of Month 6+ delay in starting the formal 90-day test.

**Likelihood:** High

**Severity:** High

**Action:** Establish a bilateral entry-conditions steering committee with both co-chairs meeting weekly starting Month 0 (2026-10-08). Decompose each condition (signed instrument, appropriations, domestic authority, sites, inspectors, vendors, schedule) into weekly milestones with explicit owners. Identify critical-path blockers (e.g., parliament session dates, security-clearance agency backlogs) and escalate to political leadership Month 1 (2026-11-08). Create a written fallback for any single-country delay: allow that country to begin testing on its own side with foreign observers while the other country completes entry conditions, or use a pre-clock dry-run gate on non-covered equipment to surface authority gaps and buy negotiating time.

## Risk 2 - Operational
Ledger divergence: the two national replicated ledgers may record events differently, disagree on timing, or develop conflicting identity claims for the same equipment. Causes include network latency, local time-sync failures, competing equipment-identity evidence, inspector disputes over witnessed events, and deliberate operator falsification. If divergence persists beyond a bounded reconciliation window, the plan defines automatic impaired-confidence or suspension triggers, but the 90-day test window is tight for forensic recovery.

**Impact:** Unresolved ledger divergence lasting >7 days (estimate) escalates to automatic site suspension or Stop decision. If a critical equipment-identity dispute (equipment X is two different things in each national ledger) cannot be resolved within 3–5 days, a site may fail Phase One even if the mechanism is working. Estimated impact: 20–30% probability of at least one ledger divergence event per site; 30–50% of divergences take >5 days to reconcile if both governments contest the evidence. One unresolved divergence per 90-day test per site is plausible.

**Likelihood:** High

**Severity:** High

**Action:** Implement shift-boundary cross-signing by mirrored national inspectors at handover to catch divergences within hours, not days. Establish a pre-authorized forensic team (3–5 technical staff plus counterpart) with authority to issue binding evidential findings on identity disputes within 48 hours, feeding into the escalation clock. Maintain a neutral third-party escrow ledger record under strict double-key control, used only to arbitrate which national copy diverged, with access logs audited. Pre-agree on a divergence-resolution hierarchy: cryptographic attestation > physical inspection + chain of custody > maintenance records > third-party logs. Run a Month 1–2 (2026-11-08 to 2026-12-08) ledger-sync stress test using non-covered equipment to validate latency bounds and forensic response before the formal clock starts.

## Risk 3 - Technical
Attestation trust root provenance: cryptographic identity attestation is one evidence layer among several, but if joint key ceremonies are compromised, delayed or rejected by either government, or if vendor-specific key material is unavailable, the entire attestation layer collapses. A joint ceremony facility becomes a single point of failure and a high-value espionage target. Delayed or refused vendor cooperation (e.g., a manufacturer withholds device-identity credentials) forces fallback to independent examiners or clean-room testing, which may lack vendor-specific expertise.

**Impact:** Loss of cryptographic attestation evidence layer for 5–15% of deployed equipment (estimate); reduction in equipment-identity confidence score from 90%+ to 60–70%. If joint ceremony cannot be scheduled before Month 2 (2026-12-08), ceremony delays feed back into the reciprocity gate and defer the clock. If a major manufacturer (e.g., NVIDIA, AMD alternative) withholds attestation hooks, all chips from that vendor become dependent on physical inspection + third-party logs + clean-room testing, lengthening verification time by 2–4 weeks per batch and increasing dispute risk.

**Likelihood:** Medium

**Severity:** High

**Action:** Pre-qualify a shared neutral location and ceremony procedures (e.g., in a third country or under UN auspices) by Month 0.5 (2026-10-23), with both governments signing off on physical security, logging and audit controls. If either government objects to a joint facility, immediately trigger a two-independent-national-roots contingency in which each government maintains its own attestation root and cross-validates the other's certificates, accepting doubled infrastructure cost. Identify the top 5–10 manufacturers of covered equipment and pre-negotiate attestation-cooperation agreements with each, documenting the fallback route (vendor-supervised testing, accredited examiners, clean-room access) if they refuse full cooperation. Establish a pre-qualified independent-examiner pool (3–5 labs per country) with access agreements signed before Month 1 (2026-11-08), so vendor refusal can be bypassed without renegotiating individual refusals.

## Risk 4 - Financial
Budget appropriations and spending pace misalignment: each country controls its USD 2.5 billion share domestically, but domestic operators and vendors are paid from the national budget share, creating a split-currency and governance complexity. If China's domestic budget execution is slower, operator compensation or vendor participation agreements may not materialize on time, delaying site readiness. Contingency budget (USD 500 million) is allocated but mechanisms for activating surge capacity across both countries are not specified.

**Impact:** Site preparation delays of 2–4 weeks if operator compensation budgets are not cleared by Month 2 (2026-12-08). A 10–15% budget variance in either country's domestic spending (estimated) could reduce personnel deployment, equipment staging preparation, or third-party vendor access agreements. If contingency funds cannot be mobilized by both countries on short notice (e.g., a ledger facility failure or exercise escalation needs emergency repairs), critical Path items could stall for 1–2 weeks. Estimated impact: 25% probability of a 2–4 week site-readiness delay due to budget execution; 15% probability of contingency-activation friction.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish a bilateral budget-execution working group meeting bi-weekly from Month 0 (2026-10-08), with spending plans from each country broken into monthly milestones. Create a contractual obligation (via bilateral instrument) that each government funds its approved budget within 45 days of fiscal-year start (Month 0 = 2026-10-08 for US, aligned timing for China), with automatic penalties or rephasing if delays occur. Pre-authorize a joint contingency-access committee with authority to release up to USD 50 million (USD 25 million per side) on a joint signature within 5 business days for emergency repairs, ledger restoration, or exercise escalation. Separate operator compensation (paid to national entities by each government) from program overhead, and have both governments audit their own spending monthly.

## Risk 5 - Technical
Vendor refusal cascade: if one or more critical manufacturers (e.g., semiconductor suppliers, cooling-system vendors, data-center infrastructure providers) refuse to cooperate with evidence-gathering, equipment-identity verification, or maintenance reporting, the fallback routes (vendor-supervised testing, independent examiners, clean-room procedures, validated attestation) may be unable to produce sufficient evidence. Material unverifiable equipment could accumulate and fail a site during Phase One.

**Impact:** One or two major vendor refusals (estimated 15–25% probability per site over 90 days) could classify 5–15% of deployed equipment as unverifiable (estimate). If a site accumulates >10% unverifiable equipment, the plan permits a site to fail Phase One. Estimated cascade risk: 20–30% probability that at least one site faces a material vendor-refusal outcome during the test, potentially failing Phase One for that site even if the mechanism otherwise works.

**Likelihood:** Medium

**Severity:** High

**Action:** Pre-qualify and bind critical vendors via legal agreements signed before Month 1 (2026-11-08), requiring participation in equipment-identity verification, maintenance reporting, and evidence-preservation under penalty of non-renewal of service contracts at the participating site. Establish a vendor-escalation protocol: (1) direct request for cooperation; (2) operator mediation; (3) independent examiner or clean-room testing; (4) validated attestation fallback; (5) unverifiable classification. Pre-stage independent examiners and clean-room facilities for at least the top 3 vendors per equipment class before the clock starts. If a vendor refuses at all stages, that equipment must be classified as unverifiable within 10 days and reported to the bilateral adjudication unit. Document every refusal and its reason in the ledger under both national copies.

## Risk 6 - Operational
Inspector conduct and espionage risk: full-time mirrored inspector teams at each site create a counterintelligence exposure. Inspectors from one country may attempt to gather intelligence on the other country's equipment, operational security, or supply-chain dependencies beyond the declared scope. Conversely, inspectors may be coerced by their own government or service into unauthorized collection. Vetting and conduct oversight reduce but do not eliminate the risk.

**Impact:** A confirmed or credibly alleged espionage incident could cause one government to withdraw consent or expel counterpart inspectors, collapsing reciprocal access and failing the test. Estimated probability: 5–10% of at least one minor conduct incident (suspicious activity, undisclosed note-taking, access to off-limits areas) within 90 days; 1–3% probability of a major incident that triggers consent withdrawal. Reputational impact on the bilateral relationship extends beyond Phase One.

**Likelihood:** Medium

**Severity:** High

**Action:** Establish a joint bilateral inspector-conduct committee with equal national co-chairs, empowered to investigate allegations, discipline or replace inspectors, and veto any inspector from the counterpart. Implement continuous access-log audit and counterintelligence monitoring of inspector activities, with logs shared between governments in redacted form (focused on access patterns, not details). Pair every inspector with a host-country observer for access to sensitive areas (e.g., staging zones, ledger facilities), providing transparency and reducing temptation. Rotate inspectors across paired sites on a quarterly basis to prevent entrenchment and operator familiarity. Establish a clear conduct code signed by every inspector at induction, with zero-tolerance rules for unauthorized area access, recording, or collection. Run surprise spot audits of inspector notes and device access logs monthly.

## Risk 7 - Operational
Inspection zone boundary creep and IP exposure: the plan requires narrow, marked inspection zones limited to staging, spare inventory, and maintenance areas. Evidence must be filtered (operator-run redaction audited by inspectors) before leaving the site. If inspectors pressure to expand zones, or if operators refuse to redact, the boundary can blur, exposing workloads, model weights, source code or network topology that one or both governments wish to protect.

**Impact:** Exposure of sensitive IP or counterintelligence data could trigger consent withdrawal or legal disputes over the bilateral instrument. A single significant exposure incident (estimated 10% probability within 90 days) could cause one government to halt Phase One. Zone-boundary disputes during maintenance or third-party-access events could delay inspections by 1–3 days and escalate to co-chair mediation.

**Likelihood:** Medium

**Severity:** High

**Action:** Define the boundary as a physically marked perimeter with access-control gates logged on both national ledgers. Conduct a pre-clock boundary audit with both governments' security teams and operators present, photographing and documenting exact limits. Require operator-run evidence redaction for all departing data, with inspectors auditing the redaction step (spot-check sample review, not pre-approval). Establish an escalation protocol: minor boundary infractions trigger a written warning and re-training; repeated or serious infractions (e.g., unauthorized photography beyond the zone) trigger a co-chair review and potential inspector removal. Use sealed capture instruments in the zones (e.g., camera traps recording only equipment identifiers and movement, not topology or workloads) so inspectors review filtered metadata rather than entering live areas unnecessarily.

## Risk 8 - Operational
Matched site selection deadlock: identifying a small set of comparable US and Chinese datacenters that are representative, willing to participate, and acceptable to both governments is a non-trivial task sitting outside the 90-day clock. If one country nominates sites the other views as unrepresentative or too easy, mutual vetoes can delay site agreement by weeks. Conversely, if selection is too structured or rushed, chosen sites may be unrepresentative of real operations.

**Impact:** Delay in site approval extending the entry-condition gate by 4–8 weeks (estimate). Disagreement over site difficulty, parity, and vendor mix could lower the credibility of Phase One results; a Go decision from unrepresentative sites may not transfer to broader future operations. Estimated risk: 30% probability of site-selection friction extending gate by >4 weeks.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Pre-agree on site-selection criteria by Month 0 (2026-10-08): equipment-change frequency (within 20% parity), vendor mix diversity, staging and maintenance area capacity, and operator willingness to participate. Establish a structured nomination process: each country nominates 3–5 candidates; a joint technical committee evaluates them against agreed criteria without veto power; a sealed random draw from the jointly vetted shortlist selects the final sites, preventing either side from steering toward easy targets. Include at least one deliberately hard site on each side (higher vendor dependencies, more complex maintenance) explicitly to test the mechanism under stress conditions. Complete site selection by Month 1.5 (2026-11-23), with bilateral site-selection ratification signed by both co-chairs.

## Risk 9 - Operational
Mirrored shift roster staffing and vetting delays: the plan requires full-time mirrored national inspectors covering 24/7 shifts, plus technical, legal, counterintelligence, and adjudication personnel. Counterintelligence vetting of ~100–200 personnel per side is a slow process. Security clearances, background checks, and conduct-rule sign-offs can delay hiring by 8–12 weeks (estimate). If rosters are incomplete at clock start, coverage gaps increase blind spots and escalation bottlenecks.

**Impact:** Incomplete rosters at clock start: estimated 15–25% of planned positions unfilled. Coverage gaps during nights, weekends or leave periods could miss equipment changes or delay event response by 4–8 hours. Estimated impact: 10–15% of events in the first Month 1–2 (2026-11-08 to 2026-12-08) may lack real-time coverage, increasing false negatives. Vetting delays of 8–12 weeks (estimate) could defer clock start if entry conditions include 'all inspectors approved.'

**Likelihood:** High

**Severity:** Medium

**Action:** Initiate counterintelligence vetting of candidate inspectors by Month -2 (8 weeks before planned clock start), using pre-agreed vetting standards and expedited timelines. Identify and vet a 20–30% surge pool above planned roster strength to cover leave, illness and turnover. Conduct rapid-induction training on ledger protocols, evidence-handling and zone rules by Month 0.5 (2026-10-23), so inspectors can deploy to sites by Month 1.5 (2026-11-23) at the latest. Allow Phase One clock to start with 80% roster strength if critical positions are filled; defer low-priority roles (e.g., administrative, some audit) to Month 1 (2026-11-08). Pre-identify and pre-vet a rapid-replacement pool for any inspector removed during the test.

## Risk 10 - Operational
Challenge exercise coordination and production disruption: live exercises (unreported arrivals, substituted equipment, record falsification, vendor refusal, reluctant operators) are meant to occur in staging, spare-inventory, maintenance and expansion areas without interrupting live computation. However, exercises require coordinated operator, inspector, vendor and red-team participation, scheduled around maintenance windows and equipment cycles. Tight coordination can delay exercises, or an exercise can inadvertently intrude on active-computation areas, causing outages.

**Impact:** Exercises delayed or cancelled due to production-schedule conflicts: estimated 20–30% of planned exercises (5–10 per site over 90 days) may be postponed. If an exercise disrupts live computation, the operator may object and refuse future cooperation, or demand compensation. Estimated impact: 1–2 unplanned production incidents per site over 90 days; USD 100,000–500,000 per incident in operational-recovery costs (not in budget). Missed or compromised exercises reduce blind-challenge evidence quality and could weaken the Go decision.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish a quarterly exercise schedule at Month 0.5 (2026-10-23), coordinating with each operator's maintenance windows, equipment-procurement cycles and production calendars. Reserve dedicated staging and spare-inventory areas that are segregated from live computation and available exclusively for exercises. Run a pre-test exercise in Month 1 (2026-11-08) at each site to validate coordination procedures and identify conflicts before the formal clock. Establish an exercise-dispute resolution protocol: if an exercise causes unexpected outages, the bilateral adjudication unit investigates whether it was conducted according to plan, and compensation is paid from contingency budget if fault is shared. Cap exercises to no more than 2 per month per site to balance testing frequency against disruption risk.

## Risk 11 - Operational
Maintenance and third-party-access scheduling abuse: the plan requires advance notice of maintenance, repair and vendor visits, with inspectors present at start and end of windows. However, operators have an incentive to classify urgent maintenance as emergencies to bypass scheduling rules, or to defer non-urgent work until after the test to avoid scrutiny. Emergency-access abuse controls are defined but may be weak in practice.

**Impact:** Repeated emergency-access claims could create 5–10 unscheduled, unsupervised maintenance windows per site during the 90-day test (estimate), some hiding real equipment changes. If emergency-access audit trails are weak, distinguishing true emergencies from scheduled-work misclassifications becomes difficult, adding 2–3 hours per incident to investigation and escalation. Estimated impact: 20–30% of claimed emergencies require escalation; 5–10% are ruled abusive and trigger discrepancy escalation clocks.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Define emergency maintenance as repairs needed to restore failed systems within 4 hours, requiring operator notification to an on-site inspector and continuous recording (video, access logs) during the unscheduled window. Establish a post-event audit requiring operators to file a detailed report within 24 hours on what failed, why, and what was repaired, with inspectors reviewing maintenance logs against the reported damage. Set a per-site cap: if any site claims >3 emergencies per month, an independent technical auditor reviews the claims; if >50% are ruled non-emergency, the operator faces escalation and potential sanctions. Require operators to pre-stage spare parts and maintenance personnel outside emergency windows to reduce claims for true emergencies. Run monthly reconciliation audits of scheduled vs. emergency maintenance to detect abuse patterns.

## Risk 12 - Operational
Exit disposition verification gaps: the plan defines five exit dispositions (witnessed destruction, verified disablement, transfer to another site, documented release beyond monitored system, unresolved). Inspectors may not have access to third-party destruction or recycling facilities, making full end-to-end witnessing impractical. If dispositions are recorded as 'documented release' or 'unresolved,' the ledger loses visibility of where equipment goes, creating a gap where re-entry or diversion could occur undetected.

**Impact:** If 20–30% of departures are recorded as 'release beyond monitored system' (estimate), and equipment secretly re-enters use unseen, detection depends entirely on later identity verification of arrivals. Blind-challenge exercises involving equipment re-entry or substitution may fail if disposition data is weak. Estimated impact: 5–10% false-negative rate on re-entry detection if exit witnessing is weak; one undetected re-entry per site over 90 days is plausible.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish a tiered exit-witnessing standard: Tier 1 (destruction/disablement) requires inspector presence at the destruction facility or independent certification from an accredited recycler; Tier 2 (transfer to another site) requires witnessed handoff and ledger entry at receiving site; Tier 3 (documented release) accepts operator sign-off with supporting vendor receipts; Tier 4 (unresolved) is used only when no evidence is available, flagged for auditor review. Require operators to bind recyclers and disposal vendors to reporting agreements and evidence preservation, as for maintenance vendors. Pre-qualify a pool of accredited recyclers in each geography (estimate 2–3 per country) with bilateral audit rights. For a random sample of Tier 3 releases (20–30% per month), conduct post-release verification calls to the receiving party to confirm receipt. Run blind-challenge exercises where equipment is reportedly destroyed but secretly re-enters the site, testing detection sensitivity to weak exit records.

## Risk 13 - Operational
Discrepancy escalation clock and deadlock: the plan defines fixed time limits for resolving discrepancies (record mismatches, disputed identity, delayed access, vendor refusal outcomes). Automatic suspension fires when clocks expire. However, in a 90-day test, fact-finding can take longer than allocated deadlines, and both countries may contest what counts as resolution, leading to escalation grid-lock.

**Impact:** Automatic site suspension triggered by expired discrepancy clocks (estimated 3–5 unresolved items per site over 90 days), even if the mechanism is functioning. Estimated probability: 15–25% of discrepancies exceed their fixed deadline, cascading to impaired-confidence status or suspension. One site suspension per test phase is plausible. False suspensions from administrative lag damage the credibility of Phase One results.

**Likelihood:** Medium

**Severity:** High

**Action:** Define three clock tiers: Tier 1 (24 hours) for minor record discrepancies (serial-number typos, timestamp mismatches); Tier 2 (72 hours) for medium-severity items (delayed maintenance access, incomplete evidence); Tier 3 (14 days) for major issues (disputed identity, vendor refusal, concerning events). Allow the bilateral adjudication unit to extend any clock once by up to 50% (e.g., 24h → 36h, 72h → 108h) with written reasons, but not twice. Create an independent technical referee panel (3–5 senior specialists per country) that can issue non-binding evidential opinions within 48 hours, giving co-chairs a shared factual basis for closing discrepancies before clocks expire. Establish a protocol: if a clock expires and no resolution is agreed, the matter escalates to co-chairs for double-key decision; unilateral escalation to automatic suspension is not permitted without written co-chair sign-off.

## Risk 14 - Operational
Evidence layer weighting disputes: the plan specifies that no single evidence source is decisive; identity requires corroboration across multiple layers (attestation, physical inspection, records, witnesses, infrastructure changes). However, the fixed corroboration rule (e.g., 'identity confirmed when 3 of 5 independent layers agree') may be too rigid or too loose. If an equipment-identity dispute arises, both governments may dispute the weight assigned to different layers, or claim that some layers were tainted by the other side.

**Impact:** Contested identity findings (estimated 5–10 per site over 90 days) delay closure by 3–5 days while adjudication units debate evidence weights. One major identity dispute per site that requires co-chair resolution is plausible. Disputed findings weaken the credibility of blind-challenge results if both governments contest the standards used to score them.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Pre-define the corroboration rule and document the rationale before the clock starts, signed by both co-chairs. Example: 'Equipment identity is confirmed if (a) cryptographic attestation AND (b) physical inspection + serial-number match agree, OR (c) if attestation is unavailable, physical inspection + two independent records (maintenance log, customs receipt, vendor certificate) agree.' Every identity finding must cite the specific layers used and their provenance. If a disputed identity finding arises, the bilateral adjudication unit applies the pre-agreed rule; co-chairs may not override the rule without a documented protocol change recorded in the ledger. Run a pre-test identity-verification exercise at Month 1.5 (2026-11-23) using non-covered equipment, comparing how the two national teams apply the corroboration rule and resolving any divergence before formal clocks start.

## Risk 15 - Operational
Provisional threshold mis-calibration: the plan requires that decision thresholds for Go/Modify/Stop be fixed and justified before the first challenge exercise. Most figures start as provisional (e.g., 'false-negative rate target: 5–10%, TBD'). If provisional thresholds turn out to be mis-set based on early blind exercises, they cannot be changed without a documented protocol change; this can force a Modify outcome that reflects the yardstick rather than real mechanism performance.

**Impact:** Early blind exercises reveal that the provisional false-negative threshold (e.g., 5–10%) is unrealistic; real performance is 12–15%, or alternatively, the mechanism performs at 2–3%, making the original threshold overly stringent. A Go decision based on a mis-set high threshold may not reflect real capability; a Modify decision may be forced simply to recalibrate the metrics, not to fix mechanism defects. Estimated impact: 30–50% probability that at least one threshold will need adjustment based on early exercise data; 15–25% probability that this forces a Modify outcome rather than Go.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Conduct a pre-test calibration exercise on non-covered equipment in Month 1–2 (2026-11-08 to 2026-12-08), outside the formal 90-day clock. Use this exercise to validate provisional thresholds and adjust them based on observed performance before the blind challenges that feed the final decision. Document every provisional figure and its source (expert opinion, historical analogy, theoretical model). Before locking thresholds, conduct a sensitivity analysis: if the false-negative rate is actually 2x higher than the provisional target, does the mechanism still meet the Go criteria, or does it shift to Modify? If a threshold needs adjustment after the calibration exercise, do so via a documented protocol change signed by both co-chairs before the formal clock starts. Classify the post-calibration thresholds as 'validated' rather than provisional in the ledger.

## Risk 16 - Operational
Blind-challenge realism and gaming risk: challenge exercises are meant to be blind to inspectors, but both governments can attempt to game the exercises. A government might design challenges biased toward detecting its counterpart's evasion methods while concealing its own; conversely, red teams might design exercises so hard that the mechanism cannot pass, discrediting the other side.

**Impact:** Exercise results appear credible but are biased by national gaming. Blind-challenge detection rates may be artificially high (if easier challenges are run against the counterpart) or artificially low (if deliberately impossible tests are designed). Go/Modify/Stop decision based on biased evidence lacks legitimacy. Estimated impact: 20–30% probability that at least one side perceives exercise bias; 10–15% probability that this triggers a formal dispute over exercise fairness, delaying the final decision by 1–2 weeks.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Vest all exercise design, scheduling and scoring in an independent testing unit staffed by neutral technical experts from neither country, or from a third country. Require scenario peer review: before each exercise is run, both red teams review the scenario against a fairness rubric and certify that it is realistic, non-biased and comparable to exercises run against their own inspectors. Document every objection and its resolution. Randomize exercise sequence and timing using a sealed double-key schedule so neither government knows in advance when its inspectors will be tested. Score results using a pre-agreed rubric (e.g., 'detection = equipment correctly identified as unauthorized within 24 hours'), with both national audit teams independently scoring each result; if scores diverge, a neutral third party breaks the tie.

## Risk 17 - Operational
Asymmetric access and reciprocity breakdown: the bilateral mechanism is founded on reciprocal access: each government must grant the other's inspectors equivalent access, zone coverage, evidence, and escalation rights. However, one country may claim national-security grounds to restrict counterpart access (e.g., deny access to certain zones due to proximity to classified infrastructure), or may restrict evidence-sharing, creating asymmetric conditions.

**Impact:** If one country grants narrower access than the other, reciprocal-access parity breaks down, and the counterpart may object to the Go decision or withdraw consent. One asymmetry incident per test is plausible (estimated 10–20% probability). Estimated impact: 1–3 week delay to resolve access disputes; 5–10% probability of consent withdrawal if asymmetry cannot be resolved.

**Likelihood:** Medium

**Severity:** High

**Action:** Define reciprocal access as a core entry condition: before the clock starts, both governments certify that each country's inspectors have been granted equivalent zone access, evidence-sharing rights, and escalation authority. During the test, measure reciprocal-access parity monthly: compare the number of inspectors deployed per country, hours of zone access per inspector, events each side has documented as witnessed, and escalation items raised by each side. If parity metrics diverge by >20% (estimate), trigger a bilateral review within 5 days to identify the gap and restore parity. Establish an automatic parity-restoration mechanism: if one side restricts access citing national security, the other side has the right to equivalent restriction on its side, maintaining symmetry. Record every access restriction in the ledger with justification, so any asymmetry is visible to auditors and the final decision panel.

## Risk 18 - Operational
Operator withdrawal or non-compliance: participating operators must commit to binding vendors, allowing inspectors on-site, maintaining the ledger, enabling exercises, and accepting evidence redaction. If an operator withdraws consent or refuses a specific protocol step during Phase One, the test may be disrupted.

**Impact:** Operator refusal of one protocol element (e.g., 'we will not allow inspectors in the maintenance bay') requires escalation and potentially site suspension. Operator withdrawal of consent (estimated 5–10% probability per site over 90 days due to operational friction or political pressure) terminates testing at that site. Estimated impact: 1 site operational disruption or early withdrawal per test phase is plausible; mitigation requires alternate site availability or protocol modifications.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Lock operator participation via legally binding bilateral agreements signed before the clock starts, specifying binding of vendors, inspector access, maintenance procedures and exercise participation as non-negotiable terms. Include penalty clauses (e.g., reduced future contracting, loss of equipment certification) for mid-test withdrawal or non-compliance. Establish a rapid operator-dispute resolution channel: if an operator objects to a protocol step, convene a joint bilateral operator-engagement team within 48 hours to understand the concern and propose workarounds (e.g., alternative scheduling, additional escorts, expanded redaction). Pre-identify a standby alternate operator at a nearby site who has agreed to rapid deployment if primary operator withdraws. Monitor operator sentiment monthly via confidential interviews with operations leadership; escalate concerns to government co-chairs before friction reaches withdrawal risk.

## Risk 19 - Regulatory & Permitting
Bilateral instrument ratification delays: the plan depends on both governments signing a bilateral instrument before entry conditions are certified. Domestic parliamentary or administrative approval of the instrument may be delayed by legal reviews, amendments, or political objections.

**Impact:** Instrument ratification delayed by 4–8 weeks (estimate) extends entry-condition timeline and defers clock start. Disputes over instrument language (e.g., dispute-resolution procedures, suspension triggers, inspector rights) may require renegotiation. Estimated impact: 20–30% probability of ratification extending beyond Month 2 (2026-12-08).

**Likelihood:** Medium

**Severity:** Medium

**Action:** Complete draft bilateral instrument by Month 0 (2026-10-08) and begin simultaneous domestic approval processes in both countries immediately. Identify all domestic approval authorities (legislature, executive, security agencies) and map their decision timelines. Pre-socialize controversial terms (automatic suspension, inspector immunity, evidence-sharing scope) with key stakeholders in Month 0 (2026-10-08) to avoid late surprises. Establish a negotiation protocol: if either government objects to specific language, trigger a structured resolution process within 2 weeks, with escalation to co-chairs if agreement cannot be reached. Consider provisional entry on non-controversial terms (site selection, operator binding) while final ratification is completing, if the bilateral instrument permits it.

## Risk 20 - Operational
Ledger synchronization latency and technology failure: the replicated ledger requires bounded synchronization between national copies (target: <1 hour, TBD). Network outages, system crashes, or cybersecurity incidents could delay synchronization, creating temporary divergence that escalates to impaired-confidence status.

**Impact:** Network outages or system failures causing >4-hour ledger divergence (estimated 5–10% probability per site over 90 days) trigger automatic escalation. Estimated impact: 2–4 ledger-sync escalation events per site over 90 days; each requiring 1–2 hours of bilateral technical troubleshooting and forensic review. A major ledger-system failure could require recovery from backup, delaying reconciliation by 8–24 hours and triggering automatic suspension if recovery takes >7 days.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Design the ledger system for high availability: duplicate facilities in each country connected by redundant, physically separate secure communications links. Test failover procedures monthly to ensure recovery time meets <4-hour sync-divergence tolerance. Implement continuous integrity checking: each national ledger runs cryptographic verification that the counterpart's copy has not diverged beyond bounds; divergences are logged and escalated automatically within 2 hours. Maintain secure offline backups that can restore the ledger to any point in time within 6 hours. Establish a bilateral ledger-technology working group that meets monthly to review system performance, plan upgrades, and address technical issues before they become crises. Conduct a full ledger-system resilience test in Month 0.5 (2026-10-23), simulating network outages, system crashes and recovery scenarios.

## Risk 21 - Operational
Equipment identity falsification or substitution undetected in exercises: challenge exercises are designed to test whether inspectors can detect unreported arrivals, substituted equipment, or record falsification. However, if the operator or a sophisticated adversary can defeat the evidence layers, undetected substitutions become possible, and exercises may provide false confidence.

**Impact:** A sophisticated substitution (e.g., identical equipment with modified internals, or a substitute with altered identifiers) goes undetected in blind exercises, providing false evidence of mechanism effectiveness. Estimated impact: 5–10% probability of one undetected substitution per site in blind exercises (estimate); if discovered during audits, it undermines the credibility of the Go decision. One major undetected-substitution discovery per test phase is plausible, potentially forcing a Modify or Stop outcome.

**Likelihood:** Medium

**Severity:** High

**Action:** Design challenge exercises to include deliberately sophisticated scenarios: internal modification with identical externals, altered serial numbers or attestation credentials, substitution during maintenance or third-party-access windows. Require independent technical experts to validate that exercises are capable of detecting such sophisticated attacks, and adjust evidence layers or detection procedures if not. Use red-team adversarial testing to probe for gaps in the detection logic. Implement cryptographic hardware-security modules or tamper-evidence seals on critical equipment to make substitution more detectable. Conduct a pre-test sophistication assessment at Month 1.5 (2026-11-23): run exercises where both governments are aware of the test scenario and the adversary strategy, then compare detection effectiveness to blind exercises; large gaps suggest the mechanism is vulnerable to sophisticated evasion.

## Risk 22 - Technical
Attestation and cryptography vulnerabilities: the cryptographic layers (attestation, ledger integrity, key ceremony) may be vulnerable to attack, delay or compromise. Cryptographic root compromise could undermine the entire identity-verification foundation.

**Impact:** Discovery of a cryptographic weakness in attestation methods (estimated 5% probability) requires rapid key rotation and re-attestation of affected equipment, delaying Phase One by 1–2 weeks. A key ceremony failure or compromise could invalidate all attestation evidence and require fallback to physical inspection and records, increasing verification latency by 3–5 days per equipment batch.

**Likelihood:** Low

**Severity:** High

**Action:** Subject the cryptographic design to independent third-party assessment by a reputable cryptographic audit firm before Month 1 (2026-11-08). Include a pre-defined rapid-response protocol for key compromise: immediate key rotation, re-signing of all attestation records, and forensic investigation of which equipment was signed with compromised keys. Maintain offline cryptographic root backups and rehearse key-recovery procedures quarterly. Use cryptographic agility in the design so that hash algorithms, key sizes or signing methods can be upgraded without wholesale system redesign if vulnerabilities emerge.

## Risk 23 - Operational
Information asymmetry and claim disputes: if one government claims the other has violated a protocol (e.g., unauthorized zone access, espionage, falsified records), and the other denies it, resolution depends on evidence credibility and both governments trusting the adjudication process. Without independent verification, disputes can become intractable.

**Impact:** One serious allegation of protocol violation (estimated 5–10% probability per test) triggers bilateral dispute escalation. If both governments dispute the facts, adjudication by neutral referees becomes necessary but may not be trusted by one side. Estimated impact: 1–2 weeks to resolve a serious dispute; 10–15% probability that one side rejects the adjudication finding and escalates to political level.

**Likelihood:** Medium

**Severity:** High

**Action:** Pre-agree on evidence standards for adjudication: ledger entries, timestamped witness statements, video recordings, cryptographic signatures. Establish an independent adjudication panel (3–5 senior technical or legal figures from neutral countries or international organizations) that reviews disputed claims using the pre-agreed standards and issues binding findings. Allow limited appeal rights (e.g., one appeal per government per Phase One), but make clear that repeated disputes trigger automatic escalation to co-chairs for political resolution. Document the adjudication process and outcomes in the ledger so both governments have a shared record.

## Risk 24 - Strategic
Geopolitical escalation or political will withdrawal: the underlying bilateral relationship between the US and China could deteriorate during Phase One, causing one or both governments to withdraw support or reinterpret the bilateral instrument in hostile ways. Political will for the project could wane due to competing priorities or electoral cycles.

**Impact:** Political pressure from either government could lead to inspector removal, consent withdrawal, or reinterpretation of the bilateral instrument that collapses the mechanism. Estimated impact: 15–25% probability of a significant political incident (trade tensions, military provocations) during the 90-day test that strains the bilateral relationship and raises risk of Phase One interruption.

**Likelihood:** Medium

**Severity:** High

**Action:** Insulate the Phase One test from routine political friction by securing high-level political commitment (presidential or prime-ministerial level) at project launch. Establish a bilateral political steering committee of senior government officials who meet quarterly to reinforce commitment and resolve any political-level disputes before they impact operations. Include escape clauses in the bilateral instrument that allow Phase One to pause (but not terminate) if international crises warrant, so short-term political friction does not destroy the entire mechanism. Brief elected officials and media on the project's strategic importance and the mutual benefits of verification, building sustained political support. If political support wanes, identify alternative implementation models (e.g., extend Phase One, reduce site count) that preserve core testing while reducing operational burden.

## Risk summary
The Consortium is a novel, high-stakes US–China bilateral verification mechanism for frontier computing equipment at matched datacenters. The 90-day Phase One test follows mandatory entry conditions and relies on fixed decision thresholds, double-key governance, and bounded inspection zones. The most critical risks are: (1) Entry-condition delays that defer the 90-day clock indefinitely, especially inspector vetting and domestic authority enactment across two sovereigns; (2) Ledger divergence and forensic disputes over contested equipment identity under asymmetric operational security postures; (3) Vendor refusal cascades that classify material equipment as unverifiable and fail a site before Phase One concludes. Secondary but significant risks include IP/counterintelligence exposure leading to consent withdrawal, fixed threshold miscalibration driving a Modify verdict, and asymmetric access or evidence claiming that collapses reciprocity. The plan's strength—procedural rigor and double-key authority—is also its vulnerability: any impasse over entry conditions, ledger reconciliation, or threshold interpretation can trigger automatic suspension. Success depends on both governments sustaining political commitment through procedural friction, maintaining reciprocal access even under adversarial inspection, and accepting independent evidence layers as sufficient when vendor cooperation fails.

# Make Assumptions


## Question 1 - How will the USD 5 billion budget be disbursed if entry conditions extend beyond Month 6 (2027-04-08), and which budget envelopes face the highest risk of underspend or reallocation if Phase One starts late?

**Assumptions:** Assumption: The bilateral instrument will specify a disbursement schedule tied to milestone completion rather than calendar dates, with both governments authorized to defer spending if entry conditions are not met. Contingency budget (USD 500 million) is held in reserve and released only upon joint co-chair approval, reducing immediate commitment but allowing rapid surge deployment. Operator compensation and site preparation costs (USD 1.75 billion combined) are most at risk of delay if site selection or operator vetting extends beyond Month 3 (2027-01-08). Personnel and training budgets (USD 750 million) can be phased: core roster deployed at Month 1 (2026-11-08), surge pool hired at Month 2 (2026-12-08). Based on bilateral government appropriations typically holding funds in escrow until conditions are certified, this assumption reflects standard sovereign fiscal practice.

**Assessments:** Title: Financial Sustainability and Appropriations Timing
Description: Assessment of how USD 5 billion (50/50 split) is committed, disbursed and tracked under dual-country budget cycles and entry-condition gating.
Details: Risk is high if entry conditions extend beyond Month 6 (2027-04-08), as domestic budget authorities may redirect unspent funds to other priorities or face year-end reversion. Mitigation: lock appropriations in both countries for 18 months (Months 0–18 = 2026-10-08 to 2028-04-08), contingent on Phase One start by Month 6 (2027-04-08); if delayed, trigger automatic reallocation to surge/contingency categories without requiring new legislative approval. Personnel costs (estimated USD 750 million) are most flexible; site preparation (USD 1 billion) is rigid if tied to real-estate contracts. Operator compensation (charged to each government's budget share) requires pre-signed operator agreements by Month 0.5 (2026-10-23) to trigger fund release. Success metric: zero budget variance >5% between planned and actual spending in Months 0–3 (2026-10-08 to 2027-01-08); zero funds returned to treasury before Phase One starts.

## Question 2 - What is the critical path sequence for the mandatory entry conditions, and which single delay would defer the Phase One clock start the longest?

**Assumptions:** Assumption: The critical path runs: (1) bilateral instrument signature (Month 0.5, 2026-10-23); (2) domestic appropriations clearance in both countries (Month 1.5, 2026-11-23); (3) domestic access-authority legislation enacted (Month 2–3, 2026-12-08 to 2027-01-08); (4) site selection and mutual vetting completed (Month 1.5, 2026-11-23); (5) inspector vetting and security clearances approved (Month 3–4, 2027-01-08 to 2027-02-08); (6) operator and vendor binding agreements signed (Month 1, 2026-11-08); (7) provisional covered-equipment schedule adopted (Month 2.5, 2026-12-23). Inspector vetting is the longest-pole activity, taking 12–16 weeks for counterintelligence clearances across two sovereigns. Legislative authority enactment is politically unpredictable. Both are external and difficult to accelerate. Based on typical bilateral security-clearance timelines (8–12 weeks) and domestic legislation cycles (4–8 weeks), this sequence reflects realistic precedent.

**Assessments:** Title: Critical-Path and Entry-Condition Gating Timeline
Description: Assessment of mandatory entry conditions, their dependencies, and which single failure point extends the 90-day clock start the longest.
Details: Inspector vetting is the critical bottleneck, requiring counterintelligence clearance of ~100–150 personnel per country and cross-vetting of counterparts. Estimated duration: 14–16 weeks if expedited (Months 0–3 = 2026-10-08 to 2027-01-08.5), or 20+ weeks if security agencies deprioritize. Domestic access-authority legislation is the second critical risk: if either parliament delays approval, the operator and vendor binding cannot proceed. Mitigation: (1) initiate vetting in Month −4 (8 weeks before Month 0 = 2026-10-08) using pre-positioned candidate lists; (2) parallel-path domestic legislation drafting before bilateral instrument signature; (3) allow Phase One to start with 80% of roster if critical positions are filled by Month 3 (2027-01-08); (4) secure high-level political commitment that authorizes expedited domestic processes. Success metric: all entry conditions certified by Month 4 (2027-02-08); any single condition delay >8 weeks triggers escalation to co-chairs for alternate-start procedures or protocol modification.

## Question 3 - How will mirrored national inspection teams be staffed, and what is the total full-time personnel commitment required to maintain 24/7 shift coverage across two to four matched sites?

**Assumptions:** Assumption: Two participating sites require ~30–40 full-time equivalent (FTE) inspectors per country per site (total 60–80 FTE inspectors per site, mirrored). Four sites multiply this to 240–320 FTE inspectors across both countries combined. Add ~40–50 FTE technical, legal, counterintelligence, audit and adjudication staff per country (total 80–100). Estimated total: 320–420 FTE personnel per country, or 640–840 combined. This aligns with 24/7 shift coverage model: three shifts (8 hours each) + leave coverage (~20% buffer) + separation-of-duties specialization (staging, maintenance, ledger, escalation) + surge reserve (~10–15%). The USD 750 million personnel budget (user constraint) supports ~1,200–1,500 FTE at average USD 500,000–625,000 per-year cost (salary, benefits, security clearance overhead, training). Based on typical bilateral government inspection programs (IAEA, OPCW) deploying 200–400 inspectors for equivalent scope, this assumption is conservative and realistic.

**Assessments:** Title: Resources and Personnel Deployment Architecture
Description: Assessment of full-time staffing model, headcount, shift coverage, and personnel budget sufficiency across two-to-four bilateral sites.
Details: Two sites with 24/7 shift coverage require 60–80 FTE inspectors per site (mirrored). Personnel envelope (USD 750 million) supports estimated 1,200–1,500 FTE at blended rates. Risk: if average cost exceeds USD 625,000 (salary + overhead), headcount shortfall emerges; if sites scale to four, mirrored staffing doubles without corresponding budget increase. Mitigation: (1) model staffing from actual site selection and confirmed shift model by Month 1.5 (2026-11-23); (2) use core roster (day shifts) supplemented by rapid-call duty teams for nights/weekends, reducing baseline but accepting >4-hour response time for off-hours alerts; (3) rotate inspectors across paired sites to pool surge capacity and reduce per-site fixed cost. Personnel vetting workload is front-loaded (Months 0–3 = 2026-10-08 to 2027-01-08) and can be partially outsourced to domestic security agencies. Success metric: roster 80% filled by Month 1 (2026-11-08), 100% by Month 3 (2027-01-08); zero unfilled critical positions (lead inspectors, adjudicators); surge-pool mobilization time <24 hours.

## Question 4 - What governance mechanism prevents one government from unilaterally suspending the mechanism or reinterpreting the bilateral instrument, and how is deadlock resolved when the two co-chairs cannot agree?

**Assumptions:** Assumption: Double-key authorization for budgets, protocol changes, site findings and sanctions requires both co-chairs' signatures, with no casting vote and no majority override. Deadlock is defined as disagreement persisting >7 days (estimate) on a decision-critical item (suspension, major protocol change, contested finding). Automatic procedures trigger: (1) escalation to a neutral independent referee panel (3–5 senior officials from agreed third parties or international organizations) who issue a non-binding opinion within 5 days; (2) if agreement remains impossible, the decision is deferred without prejudicing either side's rights; (3) automatic deferral of site findings pending resolution; (4) automatic suspension trigger if deadlock persists >14 days (estimate) on a contested identity or equipment status. The bilateral instrument specifies these procedures in advance, removing discretion from co-chairs. Based on standard bilateral agreements (US–Russia arms-control protocols, China–US military communication channels), this deadlock model is precedented.

**Assessments:** Title: Governance, Reciprocity and Double-Key Authority
Description: Assessment of co-chair governance model, deadlock resolution, automatic suspension triggers, and prevention of unilateral action.
Details: Double-key authority with no casting vote creates mutual veto, which can cause paralysis if either government acts in bad faith. Deadlock risk is medium (15–25% probability of one deadlock incident per 90-day test). Escalation to independent referee panel introduces third-party credibility but delays decisions by 5 days, which is acceptable for most items but problematic for safety or urgent escalations. Automatic suspension trigger prevents indefinite stalling but can produce false stops if deadlock results from legitimate fact-finding disputes rather than obstruction. Mitigation: (1) pre-agree on referee-panel membership and their authority limits before Phase One starts; (2) exclude time-sensitive safety/security items from referee escalation, instead triggering immediate co-chair call; (3) document every deadlock and its resolution in the ledger for auditors and the final Go/Modify/Stop decision. Success metric: average deadlock resolution time <10 days; zero unilateral suspensions without co-chair sign-off; zero disputes over referee findings.

## Question 5 - How will inspectors and evidence systems be protected from cybersecurity attacks, counterintelligence compromise, or physical tampering that could invalidate ledger records or expose classified operating procedures?

**Assumptions:** Assumption: The plan requires two independent national ledger copies with bounded synchronization (<1 hour), redundant secure communications links, offline cryptographic backups, and continuous integrity verification. Inspectors operate under conduct rules, rotation protocols, and continuous access-log audit. A bilateral counterintelligence unit reviews inspector activities monthly and audits note-taking and device access. Physical inspection zones are marked and access-controlled, with badge-swipe logs and video recording. Evidence handling includes chain-of-custody documentation and tamper-evident seals on critical records. Cybersecurity hardening includes air-gapped offline backup systems, cryptographic signing of all ledger entries, and multi-factor authentication for ledger access. Based on standards used in international nuclear safeguards (IAEA) and chemical weapons verification (OPCW), this multi-layered approach is industry-standard for bilateral verification systems.

**Assessments:** Title: Safety, Risk Management and Cybersecurity Resilience
Description: Assessment of cybersecurity architecture, inspector vetting/conduct oversight, and tamper-evidence controls protecting ledger integrity and operational security.
Details: Cybersecurity risk is medium-high (20–30% probability of at least one security incident). Ledger divergence from cyber attack is estimated 5–10% probability per site over 90 days. Mitigation reduces risk but does not eliminate it. Inspector compromise risk (espionage or coercion) is estimated at 5–10% probability of one incident per side over the test. Counterintelligence vetting, rotation and conduct audits reduce but do not eliminate insider-threat risk. Mitigation: (1) design ledger for cyber resilience—redundancy, offline backups, air-gapped recovery systems; (2) implement continuous integrity checking so divergence is detected within 2 hours; (3) conduct monthly cybersecurity audits of ledger systems and inspector access logs; (4) rehearse incident-response procedures quarterly. Success metrics: zero undetected ledger tampering; zero successful cyberattacks on core systems (ledger, communications); ledger-sync divergence detected and resolved within 4 hours; zero substantiated inspector compromise incidents.

## Question 6 - What environmental or facility impacts are created by staged destruction, disablement, or recycling of frontier computing equipment at participating sites, and what third-party environmental compliance requirements apply?

**Assumptions:** Assumption: Exit-disposition verification includes witnessed destruction, disablement, or transfer of frontier computing equipment (semiconductors, cooling systems, power infrastructure). Destruction and recycling of semiconductor equipment may require environmental compliance (hazardous-waste handling, e-waste regulations) under US EPA, Chinese Ministry of Ecology regulations, and local jurisdictions. Estimated 10–20% of deployed equipment will be retired or replaced during the 90-day Phase One test (based on typical datacenter equipment refresh rates). Disablement procedures may involve data destruction (environmental concern if incineration is used), chemical destruction (environmental permits required), or physical shredding (noise, dust control). The plan requires inspectors to witness disposition but does not specify environmental-compliance authority or permit coordination. Assumption: participating sites have existing environmental-compliance protocols; inspectors verify disposition without substituting for operator environmental responsibility. Based on US and Chinese e-waste and hazardous-materials regulations, third-party compliance oversight is mandatory.

**Assessments:** Title: Environmental Impact and Regulatory Compliance
Description: Assessment of environmental footprint of equipment destruction/recycling, third-party compliance authority, and risk of permit or regulatory delays in witnessing exit disposition.
Details: Environmental impact is low-to-medium. Destruction and recycling of semiconductor equipment generate hazardous waste (heavy metals, solvents) and e-waste requiring permitted facilities. Incineration or chemical destruction may trigger air-quality or water-discharge permits. Risk: if witness-verification procedures interfere with environmental-compliance inspection or delay processing, equipment disposition may be blocked. Estimated probability of a permit-related delay: 10–15% per site over 90 days; average delay: 1–2 weeks if inspector presence requires facility schedule adjustment. Mitigation: (1) pre-coordinate with environmental regulators in each jurisdiction; (2) allow third-party recyclers/destruction vendors to maintain their environmental-compliance procedures without interruption; (3) inspectors witness disposition at defined checkpoints (arrival, processing start, completion) rather than continuous oversight, minimizing interference; (4) pre-qualify a pool of recyclers/destruction vendors in each jurisdiction with existing environmental permits before Phase One starts. Success metric: zero environmentally non-compliant dispositions; zero regulatory delays attributable to inspection procedures; 100% of departures assigned to a final disposition within 10 days of site removal.

## Question 7 - How will each participating operator and vendor be engaged, bound to cooperation commitments, and held accountable if they refuse access, delay evidence collection, or falsify maintenance records?

**Assumptions:** Assumption: Operators at participating sites sign binding bilateral agreements committing to inspector access, equipment-identity verification, third-party escort, maintenance notification, evidence preservation, and ledger compliance. Vendors (manufacturers, maintenance providers, logistics firms) are contractually bound by operators to cooperate with evidence-gathering, attestation validation, and equipment tracking. Refusal or non-compliance by an operator triggers escalation to bilateral co-chairs and potential site suspension or Phase One failure. Vendor refusal triggers a fallback protocol: vendor-supervised testing → accredited independent examiners → clean-room validation → validated attestation → unverifiable classification. Penalties for operator non-compliance include reduced future contracting, loss of equipment certification, or financial sanctions (USD 1–10 million per breach, estimated). Based on precedent in international inspection regimes (IAEA has authority to suspend operator licenses; OPCW can impose facility closures), this assumption reflects standard enforcement mechanisms.

**Assessments:** Title: Stakeholder Involvement and Operator/Vendor Engagement
Description: Assessment of operator and vendor binding agreements, escalation procedures for refusal/non-compliance, and penalties or incentives aligning stakeholder interests with verification goals.
Details: Operator cooperation is critical and at medium risk of failure. Estimated probability of at least one operator refusing a specific protocol element during Phase One: 15–25% per site. Vendor refusal is higher risk (20–30% per site per 90 days), especially for proprietary-equipment suppliers unwilling to expose internals or attestation keys. Mitigation: (1) lock operator participation in binding bilateral agreements by Month 0.5 (2026-10-23), with clear consequences for withdrawal or non-compliance; (2) pre-negotiate vendor-cooperation agreements with top 5–10 manufacturers and logistics firms before Phase One starts; (3) establish penalty tiering: minor delays or errors → written warning; repeated or material non-compliance → escalation to co-chairs and site review; willful obstruction → facility suspension and potential Phase One failure. Incentives: operators benefit from assured equipment tracking and supply-chain transparency; vendors benefit from access to a large bilateral market if they cooperate. Success metric: zero unresolved operator or vendor refusals; >95% compliance with binding agreements; <5% of events requiring vendor-refusal escalation protocol.

## Question 8 - What criteria define success for the final Go/Modify/Stop decision, and how will provisional KPI thresholds be validated before the decision is locked?

**Assumptions:** Assumption: Go decision requires: (1) blind-challenge detection rates by event type meeting or exceeding targets (proposed targets: 90%+ for unreported arrivals, 85%+ for substitutions, 80%+ for record falsification; TBD); (2) false-positive rate <5% (proposed); (3) reciprocal-access parity metrics within 20% (proposed); (4) unresolved discrepancies <10% of total events (proposed); (5) unverifiable equipment <5% of deployed (proposed); (6) zero material ledger divergence unresolved beyond 7 days (proposed); (7) zero material asymmetric access incidents. Modify decision required if: correctable weakness remains (e.g., detection rates 70–85%, or training/procedure improvements can raise performance). Stop decision required if: access is asymmetric without resolution, material equipment remains unverifiable, vendor refusals prevent verification of critical infrastructure, ledger divergence cannot be reconciled, or either government withholds funding. Thresholds are provisional and marked TBD pending pre-test calibration. Calibration exercise runs outside formal clock in Months 1–2 (2026-11-08 to 2026-12-08) on non-covered equipment; results validate or adjust thresholds before formal clock starts. Based on international inspection precedent (IAEA safeguards KPIs, OPCW challenge-inspection success metrics), this approach is standard.

**Assessments:** Title: Operational Systems and Go-Modify-Stop Decision Criteria
Description: Assessment of KPI thresholds defining Phase One success, threshold validation procedures, and mechanisms preventing goalpost-shifting between calibration and final decision.
Details: KPI threshold calibration is critical and at medium-to-high risk of misalignment. Proposed thresholds (detection 80–90%, false positives <5%, unverifiable <5%) are estimates pending calibration. Early blind exercises may reveal that thresholds are mis-set (too loose or too tight); a rigid threshold can then force a Modify outcome reflecting the yardstick rather than mechanism defects. Mitigation: (1) conduct calibration exercise on non-covered equipment in Months 1–2 (2026-11-08 to 2026-12-08), outside formal clock, measuring actual detection and false-positive rates; (2) document every threshold and its rationale (expert judgment, historical analogy, theoretical model); (3) if calibration results differ >20% from provisional thresholds, adjust via a documented protocol change signed by both co-chairs before formal clock starts; (4) classify post-calibration thresholds as 'validated' in the ledger. Success metric: all thresholds locked and signed by Month 3 (2027-01-08); zero threshold changes during formal 90-day test without documented co-chair amendment; final Go/Modify/Stop decision made by Month 4.5 (2027-02-23).

# Distill Assumptions

- Phase One 90-day clock starts only after all mandatory entry conditions are certified: bilateral instrument, appropriations, domestic access authority, site selection, inspector approval, operator/vendor participation, and covered-equipment schedule.
- USD 5 billion budget split exactly 50/50; disbursement tied to milestone completion with contingency reserve (USD 500M) held for surge.
- Inspector vetting is critical-path bottleneck requiring 14–16 weeks for counterintelligence clearance across both sovereigns.
- Two participating sites require 60–80 FTE inspectors per site mirrored; total 320–420 FTE per country supported by USD 750M personnel budget.
- Mirrored national inspection teams provide 24/7 shift coverage with separation of duties, leave buffer, and surge reserve.
- Double-key authorization required for budgets, protocol changes, findings, sanctions; no casting vote, no majority override.
- Deadlock unresolved beyond 7 days escalates to neutral independent referee panel for non-binding opinion within 5 days.
- Automatic suspension triggers if ledger divergence exceeds 7 days unresolved; divergence detected within 2 hours.
- Narrow marked inspection zones limited to staging, spare inventory, maintenance bays; operator-run redaction auditable by inspectors.
- Fixed corroboration rule: equipment identity confirmed when minimum independent evidence layers agree; all provenance recorded.
- No single evidence source decisive: attestation, physical inspection, customs, identifiers, maintenance, infrastructure, witnessed movement layered.
- Independent testing unit runs blind challenges on sealed double-key schedule; only small group aware of timing.
- Challenge exercises limited to staging, spare, maintenance, expansion areas; no interruption of active computation.
- Vendor refusal follows escalation: supervised testing → independent examiners → clean-room → validated attestation → unverifiable.
- Equipment classified unverifiable if material evidence cannot be produced; unverifiable equipment >threshold fails site.
- Exit disposition assigns every departure: witnessed destruction, verified disablement, transfer to site, documented release, or unresolved.
- All KPI thresholds fixed and double-key signed before first exercise; changes only via documented protocol amendment.
- Provisional thresholds include: detection 80–90% by event type, false positives <5%, unverifiable <5%, reciprocal-access parity within 20%.
- Calibration exercise on non-covered equipment in Months 1–2 (2026-11-08 to 2026-12-08) validates thresholds outside formal clock before blind challenges.
- Go decision requires: detection targets met, false positives <5%, parity within 20%, unresolved <10%, no asymmetric access.
- Modify decision required if correctable weaknesses remain; Stop if access asymmetric, material unverifiable, vendor refusals block verification.
- Operator and vendor binding agreements signed by Month 0.5 (2026-10-23); non-compliance triggers escalation to co-chairs and potential site suspension.
- Inspector conduct audit continuous; monthly reviews, rotation across sites, counterintelligence vetting, zero solo-critical functions.
- Ledger replicated with independent national copies, bounded <1-hour synchronization, offline cryptographic backups, tamper-evident recording.
- Intake Protocol verifies equipment identity in controlled staging before installation using layered independent evidence and cryptographic attestation.
- Exit Protocol assigns witnessed, verified, transferred, released or unresolved disposition; inspectors do not claim knowledge beyond boundary.
- Maintenance and third-party access scheduled with advance notice, inspector coverage, sealed work areas, and emergency-use escalation controls.
- Unresolved discrepancies escalate by severity tier with fixed deadlines; auto-suspension if clock expires per protocol.
- Equipment schedule confidential, versioned, manufacturer-neutral; frozen for Phase One test or amended via double-key protocol change.
- Governance uses equal co-chairs, double-key decisions, no casting vote, defined deadlock and automatic-suspension procedures.
- Bilateral instrument specifies reciprocity gate, deadlock resolution, penalty tiering, and prohibited actions (no unilateral suspension without co-chair).
- Success limited to monitored changes at participating declared sites; no capacity estimates, workload inspection, hidden-facility verification, or comprehensive AI governance.
- No blockchain-based systems; replicated tamper-evident ledger uses cryptographic signing and dual national copies with bounded sync.
- Contingency and surge capacity (USD 500M) released on joint co-chair approval for rapid deployment if entry conditions delay.
- Budget variance >5% in Months 0–3 (2026-10-08 to 2027-01-08) triggers escalation; zero funds returned to treasury before Phase One starts.
- Environmental compliance for equipment destruction/recycling managed by operators under existing regulations; inspectors witness disposition without replacing compliance authority.
- Counterintelligence unit conducts monthly inspector activity review; conduct rules, device access audit, rotation protocol, zero substantiated compromise incidents required.

# Review Assumptions

## Domain of the expert reviewer
Bilateral Government Verification Program Management & Strategic Infrastructure Risk Analysis

## Domain-specific considerations

- Dual-sovereignty decision-making with no casting vote and mutual-veto deadlock risk
- Critical-path dependency on domestic legislative authority and counterintelligence vetting across two countries
- Ledger divergence, cryptographic trust roots, and cybersecurity resilience under adversarial inspection
- Vendor refusal cascades and fallback evidence routes when cooperation is denied
- Reciprocity gate timing and mandatory entry conditions sitting outside the 90-day test clock
- IP/counterintelligence exposure risk in narrow bounded zones and redacted evidence handoff

## Issue 1 - Critical Missing Assumption: Domestic Authority Enactment Timeline and Legislative Risk
The plan treats 'domestic access authority' as a mandatory entry condition but does not specify what legal authority is required, which legislatures or agencies must approve it, or their typical enactment timelines. US Congressional authorization and Chinese government delegation of verification authority are assumed but not detailed. No fallback is defined if either domestic process stalls. This is a missing assumption because neither government can start Phase One without legal authority to compel operator and vendor cooperation, yet the path to that authority is outside the plan's control and historically subject to multi-month delays.

**Recommendation:** By Month 0 (2026-10-08), decompose domestic authority into specific legislative or executive acts required in each country (e.g., US: bilateral instrument ratification, authorization for site access, inspector immunity; China: State Council directive authorizing operator participation, enforcement against vendors). Identify the approval authorities (Congress, executive agencies, provincial governments) and map realistic timelines based on similar past authorizations. Establish a bilateral steering committee meeting weekly from Month 0 (2026-10-08) to track progress. If either country's domestic process lags >4 weeks behind plan, trigger political escalation to co-chairs. Consider a provisional partial-start mechanism: allow Phase One to begin on non-covered equipment at Month 2.5 (2026-12-23) while formal authority enactment is still pending, using a pre-clock dry run to surface authority gaps before the formal 90-day clock (Decision 1, Strategic Choice 3).

**Sensitivity:** A 4-week delay in either country's domestic authority enactment (baseline: Month 2, 2026-12-08) extends the reciprocity gate and defers Phase One clock start by 4–8 weeks, shifting start to Month 4–6 (2027-02-08 to 2027-04-08). This compresses the operational window and increases risk that entry conditions slip further (inspector vetting completing by Month 3.5 = 2027-01-23 instead of Month 3 = 2027-01-08, reducing pre-test calibration time from 6 weeks to 2 weeks). If authority enactment is delayed 8+ weeks in either country, Phase One clock start moves to Month 6+ (2027-04-08), eliminating the pre-test calibration window and forcing a lockdown of thresholds on provisional data, increasing probability of Modify decision by 15–25%.

## Issue 2 - Critical Missing Assumption: Ledger Divergence Forensic Resolution Authority and Escalation Timeline
The plan specifies that unresolved ledger divergence >7 days triggers automatic impaired-confidence or suspension, but does not define: (1) who has authority to declare divergence 'resolved' when evidence is contested by both governments; (2) what evidentiary standard closes a dispute (majority of layers agree, or unanimous?); (3) whether an independent referee panel can issue binding findings on identity disputes, or only non-binding opinions; (4) how fast forensics can be conducted (target: <48 hours assumed, not stated). Without a defined forensic authority, divergence disputes will escalate to co-chairs, consuming time within the 7-day clock. This is critical because ledger divergence is explicitly listed as a Stop condition, and the 90-day window is short for forensic recovery.

**Recommendation:** Before Phase One starts (by Month 2, 2026-12-08), establish a pre-authorized joint forensic panel (3–5 senior technical staff per country) with authority to issue binding or co-chair-delegated findings on equipment-identity disputes within 48 hours. Define a divergence-resolution hierarchy by evidence layer: cryptographic attestation (if both copies agree) > physical inspection + chain-of-custody > maintenance records > third-party logs. Require the forensic panel to issue findings within 48 hours; if both governments dispute the finding, escalate to co-chairs for decision within 24 hours. Implement shift-boundary cross-signing by mirrored inspectors (Decision 7, Strategic Choice 3) to catch most divergences within hours, not days. If divergence persists >7 days unresolved despite escalation, automatic site suspension fires, but this decision is auditable and justified in the ledger.

**Sensitivity:** If forensic resolution takes 5–7 days (instead of target 2–3 days), unresolved divergence clocks expire and trigger automatic suspension (50–100% of divergence events per site estimated at 20–30 total divergences per site over 90 days = 10–30 automatic suspensions per site). One automatic suspension per site per Phase One is plausible. Estimated impact: 1–2 week operational disruption per site per suspension, reducing effective test window from 90 days to 75–80 days, increasing probability of incomplete exercise coverage and lowering confidence in final decision. If forensic authority is not pre-agreed and divergence resolution defaults to co-chair negotiation (no binding panel), average resolution time extends to 7–10 days, triggering automatic suspensions for 50–70% of divergences and making the mechanism appear to fail when it is actually working correctly.

## Issue 3 - Critical Missing Assumption: Vendor Refusal Escalation Path Clearance Timeline and Trade-Secret Exposure Boundary
The plan specifies vendor-refusal fallbacks (vendor-supervised testing, independent examiners, clean-room procedures, validated attestation) but does not specify: (1) which vendors must be pre-bound before Phase One starts; (2) how much lead time is needed to pre-qualify independent examiners and clean-room facilities for each equipment class; (3) what trade-secret exposure is acceptable for independent examiners to accept a vetting job; (4) whether vendors can refuse after sites are already selected, or if binding must occur before month 1.5 (2026-11-23); (5) how long each fallback route takes (estimate: vendor-supervised 1–2 weeks, independent exam 2–3 weeks, clean-room 3–4 weeks). This is critical because vendor refusal is estimated at 20–30% probability per site over 90 days, and if fallback routes are not pre-cleared, material equipment will be classified unverifiable faster than thresholds allow, failing the site.

**Recommendation:** By Month 0.5 (2026-10-23), identify the top 8–12 manufacturers and logistics vendors whose equipment or services are essential to each participating site. Conduct bilateral negotiations with each to secure pre-signed vendor-cooperation agreements committing to attestation sharing, equipment-identity disclosure, and evidence preservation, with penalty clauses (loss of market access, contract termination) for refusal. Simultaneously, pre-qualify a pool of 3–5 independent examiners per country and equipment class, with pre-signed access agreements allowing them to conduct in-situ testing if vendors refuse. Establish binding cost-sharing: if vendor refuses and independent examiner must substitute, the operator bears 50% of additional examination cost (capped at USD 50,000 per equipment class). Define the fallback escalation clock: first vendor request (Day 0), escalation to operator (Day 1), independent examiner notification (Day 2), examination scheduled (Day 3–5), results reported (Day 10). If no evidence is produced by Day 10, equipment is marked unverifiable. Document every vendor refusal in the ledger with justification.

**Sensitivity:** If key vendors (estimated 3–5 per country) refuse to participate and are not pre-bound, the fallback routes activate for 10–20% of deployed equipment (estimate 500–1,000 items per site). If independent examiners or clean-room facilities are not pre-qualified, fallback procedures take 4–6 weeks instead of 2–3 weeks, compressing the 90-day test window and increasing probability of material equipment remaining unverifiable at final decision (10–20% unverifiable instead of target <5%). This would fail the site under Go-Modify-Stop thresholds. Cost impact: if independent examiners are engaged late, average cost per examination is USD 50,000–100,000 instead of budgeted USD 20,000–30,000 (30–40 examinations per site = USD 1.2–4M additional cost per site, consuming contingency budget). Estimated probability of vendor refusal forcing Modify or Stop outcome: 20–30% per site.

## Issue 4 - Under-Explored Assumption: Pre-Test Calibration Exercise Scope and Data Reuse Constraints
The plan assumes a calibration exercise on non-covered equipment in Months 1–2 (2026-11-08 to 2026-12-08) will validate provisional thresholds before the formal clock starts. However, several details are missing: (1) what equipment is 'non-covered' available at the site for testing? (2) can data from the calibration exercise be reused in the formal Go/Modify/Stop decision, or must it be discarded? (3) who designs and scores the calibration exercise (same independent testing unit as formal exercises, or separate)? (4) how many scenarios must run to be statistically valid (estimate: 50–100 events per site, taking 3–4 weeks)? This is important because if calibration data cannot be reused, the formal test must produce all detection evidence within the 90-day window, reducing the evidence base by 20–30%.

**Recommendation:** By Month 0.5 (2026-10-23), confirm in the bilateral instrument whether calibration-exercise data can be reused in the final Go/Modify/Stop decision (recommended: yes, with caveats—calibration data is valid if equipment and procedures match formal test). Define non-covered equipment as surplus, refurbished, or decommissioned equipment available at each site but not in active computational use. Reserve 100–150 units per site for calibration use. Require the independent testing unit to design calibration scenarios using the same blind-exercise methodology as formal challenges (unreported arrivals, substitutions, record falsification, vendor refusal, reluctant operators). Run calibration from Month 1 (2026-11-08) to Month 2.5 (2026-12-23), allowing 6 weeks for scenario design, execution, scoring and threshold adjustment. If calibration data is reusable, formally integrate it into the evidence base; if not, acknowledge the limitation in the final decision rationale. Success metric: calibration exercise completes by Month 2.5 (2026-12-23) with detection rates, false-positive rates and unverifiable-equipment counts documented, thresholds locked by Month 3 (2027-01-08).

**Sensitivity:** If calibration exercise cannot be completed by Month 2.5 (2026-12-23) due to schedule conflicts or equipment unavailability (15–20% probability), thresholds remain provisional and unvalidated, increasing probability of Modify outcome by 10–15%. If calibration data cannot be reused and must be discarded, the formal 90-day test produces all detection evidence, reducing total evidence-event count from estimated 600–800 (if calibration included) to 400–500, lowering statistical confidence in detection-rate estimates by 20–25% and increasing probability of threshold mis-calibration (30–40% instead of 20–25%).

## Issue 5 - Questionable Assumption: Reciprocity Gate Stringency and Partial-Start Fallback Absence
The plan specifies a strict reciprocity gate (Decision 1, Strategic Choice 1: all entry conditions certified before clock starts, no exceptions). However, if one country completes its entry conditions (sites selected, inspectors approved, authority enacted) but the other country is delayed 8–12 weeks, the first country has a veto over timing unless a partial-start fallback is explicit. The plan does not specify what happens if the gate cannot be met by Month 3–4 (2027-01-08 to 2027-02-08). This is questionable because: (1) strict gating assumes both countries complete entry work at identical pace, which historical bilateral programs (IAEA, OPCW) show is unrealistic; (2) whichever side is slower gains a veto, creating negotiating leverage; (3) no fallback is defined if the gate cannot be met before political will erodes or budgets expire.

**Recommendation:** Supplement the strict gate (Strategic Choice 1) with an explicit fallback: if all entry conditions cannot be certified by Month 4 (2027-02-08), trigger an automatic conditional-start protocol (Decision 1, Strategic Choice 2) in which each country begins Phase One independently once its own conditions are met, with the formal Go/Modify/Stop decision deferred until both sites have run the full 90-day test. This preserves the clean test baseline while removing either country's unilateral veto over timing. Document the conditional-start option in the bilateral instrument before Month 1 (2026-11-08), so both governments accept it in advance rather than negotiating it as a crisis measure. Alternatively, pre-authorize a 'non-binding pre-clock dry run' (Decision 1, Strategic Choice 3) on non-covered equipment starting Month 2 (2026-12-08) at whichever sites are ready, with formal clock deferral acceptable up to Month 5 (2027-03-08) without triggering crisis escalation.

**Sensitivity:** If the strict gate is enforced and one country delays past Month 4 (2027-02-08), Phase One does not start until Month 5–6 (2027-03-08 to 2027-04-08), compressing the formal 90-day window. If Phase One starts late, pre-test calibration (Months 1–2 = 2026-11-08 to 2026-12-08 originally planned = 2026-11-08 to 2026-12-08) is compressed to 1–2 weeks or eliminated, forcing decision thresholds to be locked on unvalidated provisional data. Estimated probability: 30–40% probability of >4 week delay in one country's entry-condition completion. Cost of delay: USD 50–100M in personnel and facility holding costs for each delayed month (estimated). Reputational cost: late start or failure to start Phase One by Month 5 (2027-03-08) signals weak bilateral commitment and may trigger political reassessment of the entire program.

## Issue 6 - Under-Explored Assumption: Inspection Zone Boundary Enforcement and Infractions Protocol Weakness
The plan specifies narrow marked zones with operator-run redaction and inspector audit (Decision 3, Strategic Choice 1). However, enforcement procedures for zone boundary violations are minimal. The plan states 'narrowly marked zones' and 'auditable redaction' but does not define: (1) what happens if an inspector is found photographing or accessing beyond the marked boundary; (2) what counts as a 'material' IP-exposure incident requiring consent withdrawal vs. a 'minor' infraction; (3) whether minor infractions accumulate to trigger removal, or if first serious incident is grounds for immediate expulsion; (4) how quickly alleged violations are adjudicated (currently no procedure defined). Without clear enforcement, operators and governments may dispute alleged violations, and weak penalties may not deter determined adversarial inspection.

**Recommendation:** Establish a three-tier infraction protocol: Tier 1 (minor, first offense) = written warning and mandatory re-training within 48 hours (e.g., inspector photographed zone boundary by accident); Tier 2 (moderate, repeated or deliberate) = formal notice to counterpart, co-chair review, and proposed removal; Tier 3 (material espionage risk, serious unauthorized access) = immediate removal without co-chair review. Define material IP exposure as: undisclosed photography of workload location, network topology, source code, weight values, or infrastructure details beyond the bounded zone. For Tier 2 and 3 infractions, a joint bilateral conduct-review panel (established per Inspector Vetting and Conduct Oversight, Decision 14) issues a finding within 48 hours; the offending government may appeal to co-chairs within 24 hours, but the decision stands pending co-chair override. Document every zone violation, alleged or substantiated, in the ledger with photographs or access-log evidence. Run monthly zone-boundary audits during inspector shift changes, spot-checking access logs and reviewing any flagged boundary crossings within 24 hours.

**Sensitivity:** If zone-boundary enforcement is weak, estimated 10–20% of inspectors will test or attempt boundary violations (e.g., wandering near classified areas, recording without authorization). If violations are not escalated or penalized quickly, the risk of unauthorized collection increases by 30–50%, raising probability of material IP exposure (from baseline 10% to 15–25%) and consent withdrawal (from baseline 5% to 10–15%). Estimated cost of zone-violation discovery: 1–2 week delay in Phase One operations while adjudication occurs; reputational damage to bilateral trust.

## Review conclusion
The Consortium plan is well-structured for bilateral verification of frontier computing equipment, with strong procedural rigor and double-key governance. However, three critical missing assumptions create highest risk: (1) Domestic legislative authority timelines and lack of fallback if one country's enactment stalls >4 weeks (defers Phase One clock start by 4–8 months, compresses calibration window, forces Modify outcomes); (2) Ledger divergence forensic authority and 7-day suspension cliff (without pre-authorized forensic panel, disputes escalate to co-chairs, consuming the clock and triggering automatic suspensions that appear to fail a working mechanism); (3) Vendor refusal escalation-path pre-clearance and trade-secret exposure (if vendors are not pre-bound and independent examiners not pre-qualified by Month 0.5 = 2026-10-23, material equipment becomes unverifiable by Month 3–4 = 2027-01-08 to 2027-02-08, failing sites under thresholds). Secondary but significant gaps: (1) pre-test calibration scope and data-reuse constraints (if calibration is incomplete or data cannot be reused, formal evidence base shrinks by 20–30%); (2) reciprocity gate lacks conditional-start fallback if entry-condition timing diverges >4 weeks (strict gate creates unilateral veto risk); (3) zone-boundary enforcement protocol is minimal, risking IP exposure and consent withdrawal if violations are not escalated promptly. Immediate actions: (1) by Month 0 (2026-10-08), decompose domestic authority requirements and map legislative timelines per country; establish weekly bilateral steering committee to track entry-condition milestones; (2) by Month 0.5 (2026-10-23), pre-authorize forensic panel and pre-bind top 8–12 vendors to cooperation agreements; (3) by Month 0.5 (2026-10-23), pre-qualify independent examiners and clean-room facilities for each equipment class; (4) by Month 1 (2026-11-08), establish explicit partial-start fallback if strict gate cannot be met by Month 4 (2027-02-08). These actions reduce probability of Phase One start delay from 50% to 20%, vendor-refusal failures from 30% to 10%, and ledger-divergence suspension cascades from 50% to 15%, materially improving likelihood of a credible Go decision or defensible Modify outcome.