This plan implies one or more physical locations.

## Requirements for physical locations

- Declared frontier-relevant computing datacenters with existing operational infrastructure
- Staging, spare-inventory, maintenance and expansion areas suitable for live challenge exercises without interrupting active computation
- Reciprocally accessible sites: matched pairs demonstrating functional parity of inspector access
- Capacity to support full-time mirrored national inspectorates (estimated 150–200+ personnel per country across multiple sites in shifts)
- Secure facilities meeting physical and electronic security standards for classified ledger hosting, evidence review, key custody and counterintelligence
- Facilities for continuous monitoring and witness capability during intake, installation, maintenance and exit procedures
- Space and infrastructure for secure clean-room procedures, vendor-supervised testing and accredited independent examinations
- Proximity or accessibility to customs, logistics and shipment tracking infrastructure for intake verification
- Capacity to host secured reading rooms and joint secure governance spaces accessible to both national teams
- Isolated secure areas for post-rotation inspector debriefs and cooling-off periods to enforce information barriers
- Network infrastructure capable of supporting tamper-evident ledger synchronization with bounded latency and signed-digest exchange
- Physical separation enabling independent national ledger copies and secure key custody

## Location 1
United States

Tier-1 hyperscale datacenter regions (Northern Virginia, Oregon, Texas, or equivalent critical computing hubs)

Declared hyperscale operator facilities with multiple isolated staging and maintenance areas, existing access-control infrastructure, and capacity for sustained 24/7 inspectorate presence

**Rationale**: US sites must host frontier-relevant computing equipment and demonstrate existing operational security standards, physical logistics infrastructure for equipment intake/exit, and capacity for continuous mirrored staffing. Northern Virginia and Oregon align with established US computing infrastructure and federal-security precedent. Hyperscale operators have documented equipment-change procedures and maintenance areas suitable for blind-challenge exercises without disrupting active workloads.

## Location 2
China

Major regional computing hubs (e.g., Beijing, Shanghai, Shenzhen, or state-approved tier-1 datacenter zones)

Declared state-operated or state-approved frontier computing facilities with government-controlled access, documented equipment schedules, and existing maintenance and spare-equipment areas

**Rationale**: Chinese sites must be selected through bilateral Matched Site Selection Doctrine and represent frontier-relevant computing capacity. Selection at major regional hubs (Beijing, Shanghai) reflects where state-directed frontier research and computing infrastructure concentrate. The sites must be government-accessible under the domestic-authority provision and include documented procedures for equipment arrival, installation, maintenance and removal. Pairing with US hyperscale sites requires functional equivalence in staging and spare-inventory areas.

## Location 3
Neutral or joint secure facility location (proposed: Geneva, Singapore, or equivalent diplomatically neutral jurisdiction)

Secure bilateral governance and evidence-review facility outside both countries' direct territorial control, with established secure-communications and classified-document handling standards

Joint secure facility housing: dual national ledger-hosting infrastructure, bilateral co-chair workspace, secure reading rooms for counterpart evidence review, key-custody ceremonies, inspector debriefing and cooling-off spaces, and independent auditor workspace

**Rationale**: The Consortium's equal co-chair governance, double-key authorization, no-casting-vote structure and Inspector Information Firewall Doctrine require a neutral space where neither government has unilateral physical control. A Geneva-based facility (aligning with precedent in IAEA, OPCW and START verification) or Singapore (neutral in US–China context, strong secure-infrastructure capability) supports joint operations without territorial sovereignty complications. This facility hosts the replicated ledgers, hosts bilateral dispute adjudication, secures root-of-trust key material and provides secure evidence review rooms that apply Counterpart Evidence Disclosure Tiers without either side controlling the filtering environment.

## Location Summary
The Consortium is a bilateral US–China verification mechanism with inherently localized, physical operations. Phase One requires declared datacenters in both countries as the primary operational sites where inspectors deploy full-time, where intake and exit protocols are executed, where staged equipment is physically inspected, and where live challenge exercises are conducted in staging, spare-inventory, maintenance and expansion areas. The plan explicitly constrains these to "a small, matched set of declared datacenters" selected through a bilateral gate before the 90-day clock begins. Additionally, secure facilities are needed to host the replicated national ledgers, conduct evidence review in secure reading rooms, hold key-custody ceremonies, staff full-time mirrored inspectorates, run training and translation units, and maintain counterintelligence capability. The bilateral mechanism itself requires joint secure spaces for co-chair governance, double-key authorization protocols and dispute adjudication.