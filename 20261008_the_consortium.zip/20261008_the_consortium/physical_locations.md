This plan implies one or more physical locations.

## Requirements for physical locations

- United States and China territory (one datacenter in each country or a small matched set in each)
- Declared frontier-relevant computing equipment at the datacenter
- Staging and controlled intake areas for equipment identity verification
- Spare-inventory, maintenance, and expansion bays for third-party access and live exercises
- Secure facilities for shift-based inspector teams (24/7 coverage)
- Secure communications infrastructure for replicated, tamper-evident ledger synchronization
- Facilities for operator-run evidence redaction and inspector audit
- Emergency response and rapid-call access for urgent maintenance windows
- Accessibility for bilateral meetings and adjudication activities
- Proximity to third-party maintenance, logistics and destruction facilities (for exit disposition witnessing)
- Observable parity in event frequency, staging layout, and vendor dependence (for matched-site selection)
- Sufficient complexity and third-party-access traffic to test detection credibly (at least one deliberately hard site per country)
- Operator willingness to participate and bind vendors to reporting, confidentiality and escort requirements

## Location 1
United States

Silicon Valley / San Francisco Bay Area, California

Major hyperscaler datacenter campus (e.g., within Google, Meta, or AWS regional cluster) with existing security infrastructure, staging facilities, and vendor ecosystem

**Rationale**: Datacenters in this region host frontier computing equipment, have mature staging and maintenance areas, established third-party vendor and logistics networks, secure facilities for personnel, and operator experience with bilateral agreements. Bay Area geography allows secure facility co-location for ledger, communications and bilateral operations. High equipment-change frequency and complex vendor dependencies provide realistic testing ground for detection and vendor-refusal protocols.

## Location 2
United States

Northern Virginia (Loudoun County area)

Tier-1 hyperscaler or US government contractor datacenter with existing government security clearances and facility hardening

**Rationale**: Northern Virginia hosts multiple large-scale datacenters with existing government contracts, integrated cybersecurity infrastructure, and established secure communications capabilities. Proximity to Washington DC enables bilateral government coordination. Existing personnel vetting and security protocols reduce entry-condition timeline. Government contractor experience with bilateral oversight and classified operations reduces compliance friction.

## Location 3
China

Beijing or Shanghai metropolitan region

Tier-1 state-owned or state-backed datacenter operator facility (e.g., within China Telecom, China Unicom, or Alibaba infrastructure) with government relationships and existing security hardening

**Rationale**: State-owned or aligned operators in Beijing and Shanghai have frontier computing equipment, established maintenance and staging areas, and direct government authority needed to compel participation and bind vendors. Government-backed operators facilitate Chinese government's direct political backing and domestic access authority. Shanghai's East-West geography mirrors US site accessibility for bilateral operations.

## Location 4
China

Shenzhen or Chengdu

Alternative Tier-1 state-backed datacenter with complex equipment mix and high third-party-access traffic

**Rationale**: Shenzhen and Chengdu datacenters offer geographic diversity from Beijing/Shanghai, differ in equipment profiles and vendor dependencies, and provide harder test cases for detection (Decision 6: deliberately hard site per country). Chengdu's distance from coast tests logistics and exit-disposition witnessing capabilities. Alternative selection reduces either government's ability to steer site pairing.

## Location Summary
The Consortium is a bilateral US–China verification mechanism with operations at "a small, matched set of declared datacenters" in both countries. The plan explicitly requires physical presence: shift-based inspector deployment at participating sites, controlled staging areas for equipment intake, maintenance and expansion bays, third-party escort and access areas, and secure facilities for bilateral meetings and ledger operations. Phase One cannot proceed without site selection and matching as a mandatory entry condition. No specific datacenter locations are named in the plan; site selection is deferred to a structured decision process governed by Matched Site Selection Logic (Decision 6).