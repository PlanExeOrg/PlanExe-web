This plan implies one or more physical locations.

## Requirements for physical locations

- Matched set of declared datacenters in the United States and China with comparable staging, spare-inventory, maintenance and expansion areas
- Controlled staging areas for pre-installation identity verification, with bounded inspection zones
- Secure facilities for evidence handling, clean rooms, ledger nodes and counterintelligence-protected workspaces
- Proximity to logistics hubs (airports, ports, customs) for shipment records and witnessed movement
- Operator and vendor willingness plus domestic legal authority to compel access
- Neutral-feeling or jointly acceptable venue for co-chair double-key governance sessions
- Capacity to house full-time mirrored resident inspection, technical, legal, translation and adjudication units
- No disruption to active computational work; separation from production halls

## Location 1
United States

Northern Virginia datacenter corridor (Loudoun and Prince William Counties)

Declared commercial or operator datacenter campus with a dedicated staging and spare-inventory zone near Washington Dulles International Airport

**Rationale**: Dense datacenter cluster with airport and customs access, many operators and vendors, and proximity to federal authority for domestic access enactment. Supports a US-side matched site with staging, maintenance and expansion areas.

## Location 2
China

Beijing–Hebei (Zhangjiakou/Langfang) or Shanghai region datacenter cluster

Declared datacenter campus with bonded staging and spare-inventory area near a major airport or port with customs facilities

**Rationale**: Large datacenter clusters with strong logistics and customs access and state authority to compel operator participation. Offers a functional match to the US site on staging, maintenance and expansion areas.

## Location 3
Third-country or jointly agreed venue

Geneva, Switzerland or Singapore

Secure meeting and adjudication facility for co-chair double-key sessions, technical referees and ledger reconciliation reviews

**Rationale**: A jointly acceptable venue for governance, deadlock handling and Go/Modify/Stop deliberation, without placing either government on home ground. Site inspection work stays at the matched US and Chinese datacenters.

## Location Summary
The plan inherently requires physical presence at a small matched set of declared datacenters in the United States and China, where equipment arrivals, changes and departures are verified. Suggested locations are a US Northern Virginia campus, a matched Chinese datacenter cluster (Beijing–Hebei or Shanghai region), and a jointly acceptable venue for co-chair governance and adjudication. Final site selection remains an entry condition decided by both governments before the 90-day clock starts.