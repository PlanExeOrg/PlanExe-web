## Focus and Context
First-of-kind bilateral US–China equipment-change verification pilot: 90-day operational test at 4 matched declared sites with mirrored inspectorates, tamper-evident ledger, and double-key governance. Success unblocks credible pathway to continuous bilateral AI-equipment monitoring; failure clarifies what remains impossible under mutual distrust.

## Purpose and Goals
Prove bilateral equipment-change verification is operationally feasible with credible detection (≥90% blind-exercise performance), reciprocal access (parity variance ≤10%), and tamper-evident ledger integrity. Deliver Go/Modify/Stop verdict at Month 12.25 (2027-10-20) grounded in evidence, not politics. Enable informed strategic dialogue on AI governance.

## Key Deliverables and Outcomes
Signed bilateral instrument with binding deadlock escalation, enumerated auto-suspension triggers, CHALLENGE-tag partition, and principal-level decision authority (Month 7, 2027-05-12). Certified entry conditions at single gate (Month 9, 2027-07-12). Operational Phase One with ≥70 blind-exercise injections across 7 event types (Months 9–12 = 2027-07-12 to 2027-10-12). Sealed bilateral detection-rate scores and parity-variance report. Go/Modify/Stop verdict with documented thresholds and evidence sufficiency.

## Timeline and Budget
Total budget USD 5 billion (50/50 split); 90-day Phase One (Months 9–12, 2027-07-12 to 2027-10-12) contingent on entry-gate certification by Month 9 (2027-07-12) with principal go/no-go checkpoint Month 7.5 (2027-05-27). Tranches released in matched USD 625M installments at Months 7, 10, 13, 16 (2027-05-12, 2027-08-12, 2027-11-12, 2028-02-12); tranches 3–4 only after non-Stop verdict.

## Risks and Mitigations
Critical: Entry-gate stall (sunk cost USD 100–200M estimate if any condition slips past Month 9 = 2027-07-12). Mitigation: bilateral steering committee with weekly tracking, binding deadlines, principal 48-hour escalation. Critical: Vendor refusal (10–40% unverifiable equipment estimate). Mitigation: vendor binding by Month 7 (2027-05-12), clean-room centers by Month 6.5 (2027-04-27), filter-adequacy pre-test by Month 8.5 (2027-06-27) with <85% halt threshold.

## Audience Tailoring
Executive summary tailored for bilateral national co-chairs, principals, finance authorities and participating operators. Tone is formal, adversarial-realist, governance-heavy; acknowledges deep mutual distrust and absence of legal symmetry. Emphasizes hard evidence, objective decision rules, and fiscal accountability over political comfort.

## Action Orientation
Immediately establish bilateral steering committee (Month 0.5, 2026-10-27). Lock instrument signature deadline Month 7 (2027-05-12). Complete vendor binding and attestation validation by Month 7 (2027-05-12). Conduct filter-adequacy blind pre-test by Month 8.5 (2027-06-27). Operationalize challenge-exercise CHALLENGE-tag partition and misclassification-escalation procedures by Month 8.75 (2027-07-05). Certify entry conditions at single gate by Month 9 (2027-07-12).

## Overall Takeaway
Bilateral equipment-change verification is technically and operationally feasible within 90 days if entry conditions are certified by Month 9 (2027-07-12), vendor binding and filter adequacy are validated by Month 8.5 (2027-06-27), and deadlock procedures are locked in the bilateral instrument by Month 7 (2027-05-12). Go verdict will enable Phase Two commitment; Modify or Stop will inform whether verification requires alternative constraints or is unachievable under mutual distrust.

## Feedback
Strengthen by: (1) Publishing detailed principal-escalation-authority charter by Month 6 (2027-04-12) defining decision timers and contingency paths. (2) Documenting unverifiable-equipment threshold calibration methodology against actual vendor participation rates by Month 7 (2027-05-12). (3) Embedding CHALLENGE-tag partition rules and false-positive containment procedures directly in bilateral instrument language, not as procedural guidance. (4) Establishing automated KPI dashboard by Month 9 (2027-07-12) to maintain transparency and operator confidence.