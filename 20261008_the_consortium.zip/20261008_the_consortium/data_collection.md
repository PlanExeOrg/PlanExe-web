## 1. Domestic Authority Enactment Timeline and Legislative Critical Path

Domestic authority enactment is the critical-path bottleneck for entry-condition gate certification (Month 6 = 2027-04-08). A single government's legislative delay of 4+ weeks can defer the 90-day Phase One clock indefinitely, accumulating USD 150–300M holding cost and consuming contingency. Without explicit decomposition and a pre-agreed conditional-start fallback, whichever government is slower gains a unilateral timing veto, violating reciprocity principles. This data determines whether Phase One is viable by Month 6 (2027-04-08) or must be deferred, compressed, or restructured.

### Data to Collect

- Specific legislative or executive acts required per country (e.g., US Congressional ratification, China State Council directive)
- Approval bodies, committee schedules, and realistic enactment windows per country
- Interdependencies and single-item critical path (which country's authority is slowest)
- Named domestic-authority leads and escalation contacts per government
- Fallback options if one country's authority slips >4 weeks (conditional-start mechanism, deferral authority)

### Simulation Steps

- Use a bilateral entry-conditions timeline spreadsheet (Excel or Smartsheet) to map each required act through its approval process; identify critical path and float
- Model three scenarios: on-time completion (baseline), 4-week slip in Country A, 4-week slip in Country B; calculate cost impact (USD 50–100M/month holding cost per canonical facts)
- Cross-check realistic timelines against comparable bilateral programs (New START ratification, OPCW instrument, IAEA safeguards agreements); access Congressional Record, parliamentary archives, State Department records
- Simulate the conditional-start fallback: model Phase One clock start at each site independently, with joint certification required for final decision; verify bilateral instrument language supports this model

### Expert Validation Steps

- Consult US State Department Bureau of Arms Control, Deterrence and Stability on Congressional ratification procedures and typical timelines for bilateral verification instruments
- Consult US Treasury and OMB on appropriations cycle timelines and statutory authorities for verification participation
- Consult Chinese Ministry of Foreign Affairs and relevant State Council office on domestic delegation procedures and typical approval timelines
- Obtain signed commitment from both governments' domestic-authority leads confirming the decomposed milestones and escalation contacts by Month 0.5 (2026-10-23)

### Responsible Parties

- US State Department co-chair (primary US authority lead)
- Chinese government co-chair (primary China authority lead)
- Bilateral legal implementation unit (document mapping)
- Both countries' legislative/executive liaison offices

### Assumptions

- **High:** Both governments can identify and expedite required domestic legislation (Congressional bill, China State Council directive) without undue delay; expedited timelines are achievable within 14–18 weeks (Month 0.5 = 2026-10-23 to Month 3 = 2027-01-08 to 2027-01-08).
- **High:** Neither government will use domestic-authority procedures as a deliberate delaying tactic to renegotiate bilateral terms or withdraw from the program; both maintain political commitment through entry-condition work.
- **Medium:** A conditional-start fallback (Phase One beginning site-by-site rather than all simultaneously) is acceptable to both governments; the fallback is pre-agreed before Month 1 (2026-11-08) and codified in the bilateral instrument.
- **Medium:** Holding costs of USD 50–100M/month (per canonical facts) are accurate and acceptable to both treasuries as a contingency charge if gate delays occur; no additional appropriation is sought.

### SMART Validation Objective

By Month 0.5 (2026-10-23 17:00), both governments provide a written decomposition of required domestic acts, named leads, and committee schedules, with zero unresolved items. By Month 2 (2026-12-08), all required legislation is drafted and submitted for approval; if any item is >4 weeks behind baseline, a conditional-start fallback is invoked in writing. By Month 3.5 (2027-01-23), domestic authority is enacted in at least one country and tracked at 80%+ completion in both; a written escalation plan exists for any item that will miss Month 4 (2027-02-08) deadline.

### Notes

- Domestic authority enactment is outside the project's direct control and is the primary vector for external delay; weekly steering-committee reviews are essential.
- Conditional-start fallback must be negotiated and codified before Months 0–1 (2026-10-08 to 2026-11-08) deadline; attempting fallback negotiation after Month 1 (2026-11-08) creates crisis dynamics.
- Holding-cost modeling assumes USD 50–100M/month and 3-month worst-case slip; if actual costs are higher or slip is longer, contingency exposure increases and site replacement or examiner overruns become unfundable.
- Parliamentary recess, committee delays, and interagency review in either country are foreseeable; a domestic-authority lead should be senior enough to escalate to cabinet level if blocked.


## 2. Vendor Pre-Binding and Independent-Examiner Pre-Qualification

Vendor refusal is a high-probability scenario (20–30% per risk analysis); without pre-bound vendors and pre-qualified examiner fallbacks, material equipment will be classified unverifiable by the day-10 ladder, exceeding the 5% Go threshold and failing sites. Pre-qualification by Month 1 (2026-11-08) ensures fallback availability when refusals occur; delays to Month 4 (2027-02-08) or later leave Phase One exposed to cascading unverifiable-equipment accumulation and contingency overruns (USD 3.6–11.2M estimated). This data is critical to site-level Go/Modify/Stop viability and contingency management.

### Data to Collect

- Identity, tier ranking, and dependency profile for the top 8–12 critical vendors per participating site (manufacturers, attestation-key custodians, maintenance providers, logistics firms)
- Vendor willingness to sign pre-Phase-One cooperation agreements (attestation disclosure, maintenance-record preservation, penalty clauses USD 500k–2M per material refusal)
- Signed vendor cooperation agreements with counterpart acknowledgment (target 80% of Tier 1 vendors by Month 1 = 2026-11-08)
- Identification and pre-qualification of independent examiner labs (3–5 per country, 6–10 total) and clean-room facilities (2 per geography, 4–8 total) with confirmed availability, cost per exam (target USD 20–50k), and parallel-exam capacity (minimum 5 per week per facility)
- Written day-10 vendor-refusal escalation ladder locked in bilateral instrument before Phase One clock starts

### Simulation Steps

- Use a vendor-dependency mapping tool (supplier matrix, equipment bills of materials) to identify the top 8–12 vendors per site; rank by attestation criticality, supply-chain custody, and maintenance exclusivity
- Model three vendor-refusal scenarios per site: (a) 0% refusal, (b) 20% refusal (2–3 Tier 1 vendors per site), (c) 40% refusal; calculate the unverifiable-equipment count and impact on the 5% Go threshold per canonical facts
- Identify candidate independent examiner labs and clean-room facilities in the US and China; obtain preliminary cost estimates and capacity data via RFQ (request for quote) from at least 2 labs per country
- Simulate the day-10 vendor-refusal ladder: for each scenario, calculate whether fallback examiners can be engaged, scheduled, and report within day 10; identify schedule bottlenecks or cost overruns

### Expert Validation Steps

- Engage US-based semiconductor equipment manufacturers (Intel, Nvidia, AMD, FPGA vendors) and Chinese equipment suppliers (Huawei, ZTE, Alibaba cloud equipment divisions) via government trade and technology liaison channels to assess willingness to participate in pre-Phase-One cooperation agreements
- Consult equipment-testing and authentication laboratories accredited by NIST (US) and China Certification and Accreditation Administration (CNCA) to identify potential independent examiners and clean-room facilities capable of equipment-identity verification without vendor cooperation
- Obtain bilateral legal review of vendor cooperation-agreement language (penalty clauses, trade-secret protection, confidentiality) from both countries' legal teams; ensure enforceability under domestic law
- Conduct a pre-Phase-One vendor engagement briefing with both countries' procurement and technology teams to secure political backing for binding agreements and penalty enforcement

### Responsible Parties

- Bilateral vendor-management unit (lead negotiator, identification of Tier 1 vendors)
- US and Chinese procurement teams (contract language, domestic vendor engagement)
- Independent-laboratory industry associations (INMM, ASQ, Chinese equipment-testing associations) for referrals
- Both countries' legal teams (enforcement of penalty clauses, trade-secret compartmentalization)

### Assumptions

- **High:** At least 80% of Tier 1 vendors per site will agree to sign pre-Phase-One cooperation agreements; no major vendor withholds participation outright before Month 1 (2026-11-08).
- **High:** Independent examiner labs and clean-room facilities exist in sufficient numbers (3–5 per country) and can be contracted with <4 week lead time by Month 1 (2026-11-08) to be operational by Phase One start (Month 6 = 2027-04-08).
- **Medium:** Vendor penalty clauses (USD 500k–2M per material refusal) are economically meaningful and enforced; neither government will signal that penalties are unenforceable or waivable, undermining deterrence.
- **Medium:** Independent examiners are capable of equipment-identity verification (cryptographic attestation, physical inspection, measurement) without vendor cooperation; cost and schedule targets (USD 20–50k per exam, 5 parallel exams/week) are realistic.

### SMART Validation Objective

By Month 0.5 (2026-10-23 17:00), both governments provide written identification of top 8–12 vendors per site and initial vendor-engagement strategy. By Month 1 (2026-11-08 17:00), at least 80% of Tier 1 vendors have signed pre-Phase-One cooperation agreements; 3–5 independent examiner labs and 2 clean-room facilities per geography are contracted with confirmed cost and capacity. Day-10 vendor-refusal ladder is locked in the bilateral instrument. By Month 4 (2027-02-08), all pre-qualified examiners have completed a full mock equipment-identity examination to validate methodology and timeline.

### Notes

- Vendor negotiations must start immediately (Month 0 = 2026-10-08) to allow 8–12 weeks for agreement signing; delays to Month 2 (2026-12-08) compress the engagement timeline.
- Contingency reserve of USD 2–4M per site (USD 8–16M total) should be earmarked at Month 3 (2027-01-08) for late-engaged examiner costs if pre-qualification is incomplete.
- Examiner cost uncertainty (USD 20–50k per exam) creates contingency exposure; locking cost targets by Month 1 (2026-11-08) is essential to avoid budget variance.
- Vendor refusal at a hard site (high third-party traffic, complex maintenance) could trigger cascading unverifiable-equipment counts >10%, failing the site outright; hard sites must have vendor pre-binding as Entry Condition precedent.


## 3. Ledger Divergence Forensic Authority and Shift-Boundary Cross-Signing Operationalization

Unresolved ledger divergence >7 days is an explicit Stop condition (canonical facts). Without a pre-authorized forensic panel, pre-agreed evidence hierarchy, and operationalized shift-boundary cross-signing, divergences will escalate unchecked and automatic suspension will fire, appearing to fail a functioning mechanism when the root cause is procedural gridlock. This data determines whether the ledger system can reliably detect and resolve contested identity disputes within required timelines, preventing spurious Stop triggers.

### Data to Collect

- Joint forensic-identity panel composition and vetting status (3–5 specialists per country, 6–10 total, counterintelligence approval from both governments)
- Pre-agreed evidence-weighting corroboration hierarchy codified in bilateral instrument (e.g., attestation > physical inspection + chain of custody > maintenance records > third-party logs)
- Shift-boundary cross-signing procedures operationalized at 08:00, 16:00, 24:00 UTC daily; ledger entries signed by mirrored inspectors certifying no undisclosed divergences
- Automatic divergence-detection system configuration (latency <2 hours) and escalation routing (alert to forensic panel within 15 minutes)
- Forensic panel decision-making procedures: findings within 48 hours, deadlock escalation to co-chairs within 24 hours, enforcement mechanism

### Simulation Steps

- Build a mock bilateral ledger system on non-covered equipment at one pilot site (Month 1 = 2026-11-08); configure two independent national ledger copies with simulated 1-hour sync latency and deliberate divergences injected (e.g., timestamp skew of 5–30 minutes, equipment-identifier mismatch)
- Run a mock shift-handover cross-signing ceremony with two inspectors (one per country) signing a ledger entry; measure time to detect and escalate divergence; verify <2-hour detection and <48-hour forensic investigation are achievable
- Simulate the forensic-panel decision-making process: present a contested equipment-identity dispute to the panel (3–5 per country); measure consensus time and decision quality using the pre-agreed corroboration hierarchy
- Model three divergence scenarios: (a) technical sync fault (recoverable within 4 hours), (b) contested identity (requiring 48-hour forensic investigation), (c) unresolvable deadlock (requiring co-chair escalation); calculate timeline and escalation path for each

### Expert Validation Steps

- Engage cryptographic systems engineers and distributed-ledger architects to validate that the proposed <2-hour divergence-detection window and <48-hour forensic-finding timeline are technically feasible given network latency, clock-sync tolerances, and investigation procedures
- Consult bilateral legal experts to ensure that the forensic panel's authority to issue 'binding' findings on contested identity is enforceable under both countries' national law and the bilateral instrument
- Obtain both governments' agreement on the pre-agreed evidence-weighting corroboration hierarchy by Month 1 (2026-11-08) and ensure it is codified in writing in the bilateral instrument with no ambiguity
- Conduct a full-system stress test of the ledger and forensic-panel procedures on non-covered equipment by Month 4 (2027-02-08), simulating network outages, system crashes, and key unavailability; verify recovery and forensic response within SLA

### Responsible Parties

- Joint forensic-identity panel (3–5 per country, appointed and vetted by Month 0.5 = 2026-10-23)
- Bilateral ledger-operations and cryptographic-custody teams (system design, divergence detection, escalation routing)
- Bilateral legal implementation unit (forensic-panel charter, bilateral instrument language)
- Independent testing unit (mock divergence scenarios and stress-test execution)

### Assumptions

- **High:** A joint forensic-identity panel of 3–5 specialists per country can be recruited, vetted, and pre-authorized by Month 0.5 (2026-10-23) without security or political objections from either government.
- **High:** A pre-agreed evidence-weighting corroboration hierarchy can be locked in the bilateral instrument by Month 1 (2026-11-08); neither government contests the hierarchy or attempts to revise it mid-Phase-One.
- **Medium:** Ledger systems are capable of detecting divergence within 2 hours and mirrored inspectors can perform shift-handover cross-signing within 10–30 minutes; no technical barriers prevent operationalization by Phase One clock start (Month 6 = 2027-04-08).
- **Medium:** Forensic-panel findings are binding on both governments; neither government can unilaterally reject a finding or appeal to national courts to override it. The bilateral mechanism's authority supersedes domestic legal challenge.

### SMART Validation Objective

By Month 0.5 (2026-10-23 17:00), forensic-panel members are identified and vetting initiated. By Month 1 (2026-11-08 17:00), panel is appointed and pre-authorized; forensic-panel charter and evidence-weighting hierarchy are signed by both co-chairs and codified in bilateral instrument. By Month 4 (2027-02-08), ledger stress test confirms <2-hour divergence detection, mock divergence scenarios are resolved within 48 hours, and shift-handover cross-signing is operationalized at pilot site with zero missed handovers or delayed escalations.

### Notes

- Forensic-panel pre-authorization is not explicitly listed as an entry condition (Entry Condition 1–7) in canonical facts; it should be elevated to Entry Condition 8 or integrated into the gate-certification process to prevent procedural gaps.
- Shift-boundary cross-signing must be practiced before Phase One; inspectors need hands-on training to execute the ceremony reliably and avoid signing delays that defeat early-divergence detection.
- Automatic suspension at 7 days is a powerful deterrent against concealment, but without operationalized forensic authority, it becomes a cascade that can freeze a functioning mechanism; extensive testing and rehearsal before Phase One is essential.
- Deadlock escalation from forensic panel (no consensus within 48 hours) to co-chairs (decision within 24 hours) depends on co-chairs being available and responsive; assignment of escalation duty officers is necessary.


## 4. Counterintelligence Vetting and Inspector Conduct Oversight

Inspector vetting (14–16 weeks, up to 20+ weeks if deprioritized) is the critical-path entry-condition bottleneck. Delayed vetting defers Phase One clock start, accumulating USD 50–100M/month holding cost. Incomplete vetting (roster <80% by clock start) reduces coverage, increases likelihood of missed events, and signals low-credibility preparation. Conduct-oversight infrastructure (access-log audit, zone-violation investigation, three-tier escalation) is essential to prevent espionage or capture and to maintain bilateral confidence that inspectors are acting impartially. This data determines whether sufficient inspectors are cleared, deployed, and supervised to execute Phase One with full shift coverage and credible event detection.

### Data to Collect

- Counterintelligence vetting progress: number of candidate inspectors submitted per country (target 120–150 per country) and projected completion date (target 14–16 weeks from Month 0.5 = 2026-10-23, i.e., by Month 4.5 = 2027-02-23)
- Critical-post vacancies and surge-bench fill rate (target 100% critical posts + 20–30% surge bench by Month 5 = 2027-03-08)
- Inspector conduct-oversight infrastructure: bilateral Conduct Committee composition and authority, access-log audit procedures, zone-violation investigation protocols, three-tier infraction escalation
- Inspector rotation schedule (quarterly cross-site rotation, no permanent site assignment >3 months) and leave coverage planning (2 weeks per quarter per inspector)
- Zone-conduct acknowledgment and vetting-completion status: percentage of inspectors signed and cleared by 5 days before Phase One clock (Month 5.5 = 2027-03-23)

### Simulation Steps

- Map counterintelligence vetting timelines per country using historical data from analogous bilateral programs (New START vetting, OPCW inspector approval, IAEA safeguards); identify bottlenecks and acceleration opportunities
- Model three staffing scenarios: (a) on-time vetting completion (baseline), (b) 4-week vetting slip, (c) 8-week slip; calculate roster fill rate at Phase One clock start and impact on coverage gaps (night shifts, leave coverage)
- Simulate quarterly inspector rotation across 4 sites; confirm that rotation does not create knowledge gaps or separation-of-duties violations; identify surge-pool requirements to cover rotation transitions and leave
- Design and test a 24/7 access-log audit procedure on non-covered equipment: conduct monthly access-log review for 100 mock inspectors, comparing badge swipes against stated activities; measure detection time for boundary violations and investigate thoroughness

### Expert Validation Steps

- Consult US counterintelligence and security-clearance agencies (DCSA, IC security offices) on vetting timelines and expediting opportunities for 120–150 inspector-level clearances by Month 4.5 (2027-02-23); obtain written commitment to timeline or alert of schedule risks by Month 1 (2026-11-08)
- Consult Chinese Ministry of State Security and equivalent vetting bodies on parallel vetting procedures and timeline for 120–150 inspectors; secure written confirmation of vetting-completion target
- Engage bilateral legal teams to define the Conduct Committee's authority (power to veto, remove, or replace inspectors), enforce the three-tier infraction protocol, and adjudicate misconduct allegations within 72 hours
- Consult OPCW and IAEA inspector-management programs for best practices on rotation scheduling, conflict-of-interest management, and access-log audit to inform the Consortium's procedures

### Responsible Parties

- US counterintelligence services (DCSA, FBI CI, CIA) and Chinese security agencies (MSS, equivalent)
- Bilateral Inspector Conduct Committee with equal national co-chairs
- Site-level counterintelligence and security personnel (access-log audit, zone monitoring)
- Both countries' human-resources and logistics teams (rotation scheduling, leave management)

### Assumptions

- **High:** Both countries' counterintelligence agencies prioritize Phase One inspector vetting and complete clearances within the 14–16 week baseline (Month 0.5 = 2026-10-23 to Month 4.5 = 2027-02-23); competing security priorities do not cause delays >4 weeks.
- **Medium:** A roster of 80% of planned inspectors (target ~280 of 434 FTE) is sufficient for Phase One operations with reduced night-shift coverage and acceptable leave gaps; no force-protection or event-detection capability is materially degraded.
- **Medium:** Neither government will use the conduct-oversight process (veto authority, Tier 2 or Tier 3 removal) to remove counterpart inspectors for political reasons; all removal decisions are substantiated by factual misconduct or security concerns.
- **Low:** Inspector rotation across sites every 3 months is administratively feasible and does not create information-barrier violations, document-management issues, or security clearance complications.

### SMART Validation Objective

By Month 0.5 (2026-10-23 17:00), both counterintelligence agencies issue written commitment to vetting-completion target and expedited-review procedures. By Month 2 (2026-12-08), at least 60% of candidate inspectors (>70 per country) are submitted for clearance. By Month 4.5 (2027-02-23), at least 80% of planned roster (217 per country) is vetted and approved; any critical-post vacancy is filled from a pre-approved surge bench within 5 working days. By Month 5.5 (2027-03-23), 100% of deployed inspectors have signed zone-conduct acknowledgments and three-tier infraction protocol acknowledgments; bilateral Conduct Committee is operationalized with monthly meeting cadence.

### Notes

- Inspector vetting is subject to external delays outside the project's control; weekly steering-committee tracking and escalation protocols are essential to detect slips early.
- A surge-bench of 20–30% pre-vetted replacements must be in place by Month 4 (2027-02-08) to accommodate vetting delays, turnover, and rotation absences; surge-bench vetting should begin in parallel with main-roster vetting, not sequentially.
- Access-log audit monthly is resource-intensive; if audit staff are insufficient, audits will lag and zone violations will go undetected, raising espionage risk; dedicated audit personnel per country are needed.
- Quarterly rotation is procedurally complex (handoffs, document transfer, temporary knowledge gaps); pilot the rotation process at one site in Months 5–6 (2027-03-08 to 2027-04-08) before full implementation during Phase One to identify and resolve procedural friction.


## 5. Pre-Test Calibration Exercise Design and Go/Modify/Stop Threshold Validation

Provisional thresholds (90% detection target, <5% false positives, <5% unverifiable equipment) are estimates used to lock the Go/Modify/Stop decision criteria before Phase One begins. Calibration exercises validate these estimates against real equipment and inspector performance; if calibration reveals that provisional targets are unrealistic (e.g., actual detection is 70%, not 90%), thresholds must be recalibrated before formal blind challenges to avoid a Modify outcome that reflects mis-set targets rather than mechanism performance. This data determines whether the final Go/Modify/Stop verdict is credible and defensible as an assessment of the mechanism's real capability, not a reflection of yardstick errors.

### Data to Collect

- Calibration-exercise scenario suite design (at least 50–100 events per site covering all 7 event types: unreported arrivals, substitutions, record falsification, delayed access, disputed identity, vendor refusal, reluctant operators)
- Calibration-exercise execution results: blind-challenge detection rates by event type (proposed targets: 90% unreported arrivals, 85% substitutions, 80% record falsification); false-positive rate (<5% proposed); unverifiable-equipment count (<5% proposed); confidence intervals around all estimates
- Provisional Go/Modify/Stop threshold adjustment based on calibration evidence: if calibration results diverge >20% from provisional targets, recalibrate thresholds or document justification for keeping provisional values
- Decision rule codification: documented rubric specifying which KPI failures are non-negotiable Stop conditions, which are Modify conditions (correctable weaknesses), and which can be waivers or conditional Go outcomes
- Double-key co-chair signature locking all thresholds and decision rules by Month 5.5 (2027-03-23) with no further amendment except via recorded protocol-change procedures

### Simulation Steps

- Commission the independent testing unit to design the full calibration-exercise scenario suite by Month 1 (2026-11-08); include realistic event scenarios that both governments' red teams deem fair and difficult enough to test detection credibly
- Reserve 100–150 non-covered equipment units per site (surplus, refurbished, or decommissioned, not in active computational use) for calibration use; confirm operator and site-readiness for Months 4–5 (2027-02-08 to 2027-03-08) execution
- Execute calibration exercises Months 4–5 (2027-02-08 to 2027-03-08) using blind-challenge methodology (sealed double-key schedule, minimal advance notice to inspectors and operators); score detection results using the fixed pre-agreed corroboration rule
- Analyze calibration results: calculate detection rates, false-positive rate, unverifiable-equipment count, and 95% confidence intervals per event type; document any scenarios where detection failed and analyze root causes

### Expert Validation Steps

- Engage independent testing unit leadership and both red teams to validate that calibration scenarios are realistic, representative of expected Phase One events, and fair to both countries' inspectors
- Consult statistical experts to ensure that the calibration sample size (50–100 events per site = 200–400 total across 4 sites) is sufficient to estimate detection rates with acceptable confidence intervals (e.g., ±5% for 90% detection target)
- Obtain bilateral agreement (signed by both co-chairs) on whether calibration-exercise data will be reused in the final Go/Modify/Stop evidence base or discarded as out-of-scope; if reused, formally integrate results into evidence base with 'validated' status
- Commission an independent audit (third-party auditor from a neutral country) to verify that calibration-exercise methodology matches the planned Phase One exercise methodology and that detected anomalies are not artifacts of test procedure rather than mechanism weakness

### Responsible Parties

- Independent testing unit (scenario design, blind-exercise execution, scoring)
- Both red teams (scenario fairness review, realism assessment)
- Bilateral threshold-validation working group (threshold adjustment, decision-rule codification)
- Both co-chairs (threshold lock-in and double-key signature)

### Assumptions

- **Medium:** 100–150 non-covered equipment units per site are available and reserved for calibration use (Months 4–5 = 2027-02-08 to 2027-03-08) without disrupting Phase One operations or requiring additional facility standby.
- **High:** Calibration-exercise scenarios are sufficiently representative of Phase One events that calibration results predict formal Phase One detection performance within ±10–15% accuracy; calibration is not just a rehearsal but a meaningful validation test.
- **Medium:** Provisional threshold targets (90% detection, <5% false positives, <5% unverifiable) are recalibrated without triggering dispute over whether recalibration constitutes 'moving the goalposts'; both governments accept that calibration validates targets or justifies adjustment.
- **High:** Calibration-exercise data can be reused in the formal Go/Modify/Stop decision (i.e., the 50–100 calibration events per site count as part of the Phase One evidence base) without muddying the distinction between calibration and formal testing; both governments agree on this in writing by Month 2 (2026-12-08).

### SMART Validation Objective

By Month 1 (2026-11-08 17:00), calibration-exercise scenario suite is designed and locked; both co-chairs and red teams have reviewed scenarios and approved them as realistic and fair. By Month 5 (2027-03-08), calibration exercises are completed at all 4 sites; detection results, false-positive rate, and unverifiable-equipment counts are documented with 95% confidence intervals. By Month 5.5 (2027-03-23 17:00), all Go/Modify/Stop thresholds are double-key signed by both co-chairs; if calibration results diverged >20% from provisional targets, recalibration is documented and new thresholds are signed; all other adjustments are recorded as protocol changes with date and rationale.

### Notes

- Calibration is the only opportunity to validate provisional thresholds before formal blind challenges; skipping or rushing calibration leaves the final verdict resting on unvalidated estimates.
- Calibration data reuse (or exclusion) must be decided by Month 2 (2026-12-08); attempting to decide after calibration execution creates the appearance of outcome-biasing.
- If calibration reveals that false-positive rate is 10% instead of 5%, a Modify outcome may become inevitable; both governments must be prepared to accept that result without contesting the threshold or mechanism validity.
- Calibration-exercise difficulty and scenario realism depend on independent testing unit quality and both red teams' engagement; if scenarios are too easy or too hard, calibration results will be misleading and final thresholds will be mis-set.


## 6. Contingency Budget Exposure and Fiscal Governance

The contingency reserve (USD 500M per canonical facts) is the only buffer for gate delays, site replacement, vendor-refusal examiner overruns, and exercise disruptions. Worst-case contingency exposure is estimated at USD 515M (per canonical facts: about USD 15M shortfall), leaving zero surge margin if multiple contingencies activate simultaneously. Contingency-governance procedures (fast-lane authority, double-key limits, fiscal escalation) determine whether contingency can be accessed fast enough to prevent operational failure when crises occur. This data determines whether the USD 500M reserve is adequate or if supplemental appropriation is required; whether contingency-governance procedures enable timely access or create decision bottlenecks; and whether fiscal tracking can detect underfunding in time to activate the withheld-funding Stop condition.

### Data to Collect

- Cost estimates for gate-delay holding cost (USD 50–100M per month x number of months deferred); worst-case gate slip from Month 6 (2027-04-08) to Month 9 (2027-07-08) = 3 months = USD 150–300M per canonical facts
- Cost estimates for site replacement (4–8 weeks delay, USD 50–200M per canonical facts); triggered if a site is withdrawn or fails entry conditions
- Cost estimates for late-engaged independent examiners (30–40 exams per site at USD 50–100k per exam = USD 1.5–4.0M per site vs. USD 0.6–1.2M budget; overrun USD 3.6–11.2M total per canonical facts)
- Cost estimates for exercise-incident recovery and contingency miscellaneous (USD 4M estimate); attestation-root alternative costs if joint ceremony fails (absorbed in USD 1.25B ledger envelope, not separate)
- Contingency reserve allocation strategy: ring-fencing (USD 200M for gate, USD 150M for site replacement, USD 100M for examiners, USD 50M for surge/incidents) vs. unified reserve; fast-lane release authority (USD 50M per side on joint signature within 5 business days per canonical facts)

### Simulation Steps

- Build a contingency-exposure model in Excel or Monte Carlo software; model 10+ scenarios combining gate delays, vendor refusals, site replacement, examiner overruns, and exercise disruptions; calculate worst-case, median, and best-case contingency burn and remaining reserve
- For each delay scenario, calculate holding-cost accumulation: USD 50–100M/month x (number of months slipped); map holding-cost to contingency drawdown and impact on other budget envelopes
- Model vendor-refusal cascades: if X% of Tier 1 vendors refuse, how many examiners are needed, at what cost, and is that cost within pre-allocated sub-envelope; if cost exceeds sub-envelope, calculate gap and contingency impact
- Design three contingency-governance options: (a) unified reserve with double-key approval for any release >USD 50M; (b) ring-fenced sub-envelopes with fast-lane release authority up to USD 10M per sub-envelope; (c) tiered release authority: single-signature release up to USD 25M, double-key for USD 25–100M, co-chair political decision >USD 100M; compare governance burden and decision speed for each

### Expert Validation Steps

- Consult US Treasury, OMB, and Chinese equivalent fiscal authorities on the USD 5B appropriation and per-country USD 2.5B budgets; confirm that the 18-month appropriation window (Months 0–18 = 2026-10-08 to 2028-04-08) is enforceable and that unspent funds will not revert at fiscal-year end
- Obtain bilateral agreement (signed by budget working group and treasuries) on contingency-governance procedures: fast-lane release authority limits, double-key decision timelines (target 5 business days), escalation to co-chairs if consensus cannot be reached within the decision window
- Engage fiscal auditors from both countries to design the monthly contingency burn-rate reporting and variance-tracking dashboard; establish variance thresholds (e.g., variance >5% triggers escalation investigation within 5 working days)
- Consult financial-management experts on funding-timeliness governance: design a procedure where late tranches are flagged within 5 working days, co-chairs notified within 10 days, and a 75-day total cure period applies before withheld-funding Stop is triggered (per canonical facts: 45-day disbursement window + 30-day cure = 75 days)

### Responsible Parties

- Bilateral budget working group (cost estimation, sensitivity analysis, scenario modeling)
- US Treasury, OMB, and Chinese finance/budget authorities (appropriation governance, tranche disbursement timing)
- Independent fiscal auditors (monthly burn-rate reporting, variance analysis, withheld-funding detection)
- Both co-chairs (final approval of contingency-governance procedures and release authority)

### Assumptions

- **Medium:** Holding-cost estimates (USD 50–100M per month for gate delay) are accurate and reflect the full cost of personnel, facility, and equipment standby; no hidden costs emerge during actual delay periods.
- **Medium:** Site-replacement cost estimates (USD 50–200M for 4–8 weeks) include all additional vetting, training, ledger setup, and facility standby for the alternate site; no one-time infrastructure costs exceed estimates.
- **Medium:** Examiner cost estimates (USD 50–100k per exam, USD 3.6–11.2M total overrun) reflect realistic market rates for independent equipment-identity examination without vendor cooperation; bulk-discount or pre-contracting opportunities reduce actual cost.
- **Medium:** Fast-lane contingency release (up to USD 50M per side on joint signature within 5 business days per canonical facts) is administratively feasible; both treasuries can authorize and transfer funds within the 5-day window without legislative or regulatory delay.

### SMART Validation Objective

By Month 0.5 (2026-10-23 17:00), a bilateral budget working group provides a written cost-basis analysis for all identified contingency drivers (gate delay, site replacement, examiner overrun, exercise incidents), with low, mid, and high estimates. By Month 1 (2026-11-08), contingency-governance procedures are drafted and circulated to treasuries for comment; fast-lane release authority limits and double-key decision timelines are documented. By Month 3 (2027-01-08), both governments approve the contingency-governance procedure and sign the budget accord; if the contingency-exposure gap (estimated USD 15M) cannot be closed via governance efficiency, a written decision is made to either seek supplemental appropriation or accept reduced contingency margin. By Month 6 (2027-04-08) and ongoing, monthly contingency burn-rate reports are provided to both treasuries; variance >5% triggers escalation investigation within 5 working days.

### Notes

- Contingency worst-case of USD 515M exceeds reserve by USD 15M; if gates slip 3 months (300M worst case) and a site requires replacement (200M worst case), contingency is depleted before examiner overruns (11M) can be absorbed; ring-fencing sub-envelopes can prevent exhaustion of one category but may prevent flexibility in others.
- Holding-cost estimates assume continuous personnel and facility costs during delay; if Phase One is deferred pending entry-condition resolution, some personnel and facilities may be placed on temporary standby or reduced deployment, lowering holding cost; modeling should include a 'standby mode' cost estimate.
- Fast-lane contingency release (USD 50M per side, 5 business days) is faster than some bilateral decision processes; ensuring treasuries can sign within 5 days may require pre-delegation to a named fiscal authority or automatic standing authorization.
- Withheld-funding Stop trigger (75 days total: 45-day disbursement window + 30-day cure) is a powerful sanction but may not distinguish between legitimate payment-system delays and deliberate funding withholding; the procedure must include a good-faith cure-notice mechanism and a dispute-resolution path before Stop is invoked.


## 7. Independent Testing Unit Exercise Credibility and Blind-Challenge Fairness Validation

The Go/Modify/Stop decision rests entirely on blind-challenge detection results (proposed targets: 90% unreported arrivals, 85% substitutions, 80% record falsification). Either government could contest exercise fairness, claiming that scenarios were biased, too difficult, or unrepresentative. Without a credible, independent testing unit and a transparent fairness-comparison protocol locked before exercises begin, the final verdict will be vulnerable to post-hoc dispute over exercise validity. This data determines whether blind-challenge results are credible, symmetric, and defensible as evidence of the mechanism's real capability.

### Data to Collect

- Independent testing unit charter and governance: staffing model (neutral-country nationals, no direct national-government loyalty), reporting authority (both co-chairs jointly), conflict-of-interest policy, sealed-schedule management
- Sealed double-key exercise schedule mechanism: how event scenarios are drawn (random, stratified, or adversarial design), how schedule is stored and revealed (encrypted, dual-key unsealing), who has access to schedule before exercises and when
- Exercise scenario templates for all 7 event types (unreported arrival, substitution, record falsification, delayed access, disputed identity, vendor refusal, reluctant operator): realism, complexity, difficulty parity between US and China scenarios
- Fairness-comparison protocol: how US scenarios are compared against China scenarios for difficulty, artifact visibility, operator-knowledge assumptions; how both red teams certify fairness before each exercise runs
- Detection-performance scoring methodology: definition of 'detection' (change recorded in ledger within 48 hours? or immediate observation?), scoring consistency across event types, false-negative and false-positive audit trail

### Simulation Steps

- Design a mock sealed double-key exercise-schedule system: define the schedule as a time-stamped list of event scenarios and timings; encrypt it with one key held by each country (neither can unseal alone); practice unsealing the schedule daily, verifying that schedule entropy and access controls prevent gaming
- Commission independent testing unit to design representative exercise scenarios for each of the 7 event types; have both red teams review scenarios for realism and difficulty; document any fairness concerns and mitigation strategies
- Simulate fairness comparison: present 5 unreported-arrival scenarios designed by the US red team and 5 designed by the China red team to independent auditors; score each scenario on difficulty, artifact visibility, and operator-knowledge assumptions; calculate parity metrics
- Model three detection-scoring definitions: (a) change recorded in ledger within 24 hours, (b) within 48 hours, (c) immediate observation during physical inspection; calculate how scoring-definition choice affects false-negative rate and Go threshold achievement for each event type

### Expert Validation Steps

- Engage an independent international organization (e.g., Switzerland's Federal Department of Defence, UNIDIR, or a neutral third-country government) to assess the independent testing unit's governance and conflict-of-interest policies; confirm that unit is structurally independent from both national governments
- Consult both countries' red teams and bilateral technical leads to validate that the sealed double-key schedule mechanism prevents both inspection-side and operator-side advance knowledge; conduct a mock schedule-unsealing ceremony to confirm the procedure works in practice
- Engage a neutral third-party auditor to review fairness-comparison protocols and certify that the fairness-audit process is transparent, documented, and produces reproducible parity assessments between US and China scenarios
- Obtain bilateral agreement (signed by independent testing unit director and both co-chairs) on the detection-scoring definition and consistency audit procedures before the first formal blind exercise is run

### Responsible Parties

- Independent testing unit (neutral-country staffing, sealed-schedule management, scenario design, scoring)
- Both red teams (scenario design, fairness review, bias detection)
- Bilateral fairness-audit team (scenario comparison, parity analysis, bias certification)
- Both co-chairs (approval of fairness protocols and scoring methodology)

### Assumptions

- **High:** An independent testing unit staffed by neutral-country nationals (not directly controlled by US or China) is acceptable to both governments; neither government perceives the unit as a loss of sovereign control over exercise design.
- **High:** Sealed double-key schedule mechanism prevents both operator and inspector advance knowledge of exercise timing and content; neither side can engineer events or responses to optimize appearance of detection.
- **Medium:** Fairness-comparison protocols produce reproducible, objective measures of scenario difficulty and parity; subjective assessments (e.g., 'this scenario is harder') can be converted to quantitative metrics that both governments accept.
- **Medium:** Neither red team will deliberately design unfair scenarios (too difficult for counterpart inspectors, too easy for own inspectors) during Phase One; both teams prioritize scenario realism and testing credibility over tactical advantage.

### SMART Validation Objective

By Month 1 (2026-11-08 17:00), independent testing unit charter is signed by both co-chairs; unit director and staff are appointed and cleared by both governments. By Month 2 (2026-12-08), sealed double-key schedule mechanism is designed and tested on mock data; unsealing procedures are documented and both co-chairs verify the mechanism prevents advance knowledge. By Month 4 (2027-02-08), fairness-comparison protocols are operationalized; at least 2 mock scenarios per event type are presented to the fairness-audit team, and parity metrics are calculated and approved by both red teams before protocol is locked. By Month 5 (2027-03-08), the independent testing unit conducts a full mock blind exercise at one site (with live inspectors, sealed schedule, real equipment) to validate end-to-end procedures and measure detection performance; mock results are reviewed and scored by both technical teams and approved as representative before formal Phase One challenges begin.

### Notes

- Independent testing unit must be geographically separate from both governments and participating sites to prevent pressure or access by national security or intelligence agencies; location (e.g., Switzerland, UN facility) should be confirmed by Month 1 (2026-11-08).
- Sealed double-key schedule unsealing should occur only minutes before each exercise begins, not hours or days in advance; operational details of time, location, and event type should be revealed only to site leadership, not to inspectors or operators until exercise is underway.
- Fairness-comparison protocol must be applied to every exercise scenario, not just a sample; if one scenario is found to be unfair after the fact, the results from that exercise must be marked as questionable or excluded from the final verdict.
- Both red teams must certify fairness before each exercise runs, not after; post-hoc fairness claims ('this scenario was unfair') should not be permitted to invalidate detection results, but pre-exercise concerns should be resolved before the scenario is executed.

## Summary

The Consortium bilateral verification program faces seven critical data-collection priorities spanning domestic authority enactment, vendor pre-qualification, ledger-forensics operationalization, inspector vetting and conduct oversight, pre-test calibration, contingency fiscal governance, and independent exercise credibility. Together, these areas determine whether Phase One can start on time (Month 6 = 2027-04-08), whether the 90-day test window is credible and complete, whether the final Go/Modify/Stop decision is defensible, and whether the USD 500M contingency reserve is adequate. Immediate actions (Months 0–1 = 2026-10-08 to 2026-11-08) focus on decomposing domestic authority enactment, securing vendor pre-binding agreements, recruiting and authorizing the forensic panel, and locking the bilateral instrument's conditional-start fallback, evidence-weighting hierarchy, and contingency-governance procedures. Critical dependencies are inspector vetting (14–16 weeks, Month 0.5 = 2026-10-23 to Month 4.5 = 2027-02-23 to 2027-02-23) and calibration-exercise execution (Months 4–5 = 2027-02-08 to 2027-03-08), both of which feed the threshold-lock decision by Month 5.5 (2027-03-23). Worst-case contingency exposure (USD 515M vs. USD 500M reserve, shortfall ~USD 15M) must be reconciled by Month 3 (2027-01-08) via supplemental appropriation, ring-fenced envelope allocation, or scope trade-off. Success is measured by entry-condition certification by Month 6 (2027-04-08) with zero unresolved items >4 weeks old, detection rates from calibration exercises confirming threshold realism, and independent testing unit standing by with sealed Phase One exercise schedule locked and fairness-audited. The highest-risk areas are domestic authority timing veto (no fallback if one government lags), vendor refusal cascades (no pre-bound examiners = unverifiable equipment >5% threshold), and ledger divergence procedural deadlock (no pre-authorized forensic panel = automatic suspension on technical faults). Each data-collection area requires bilateral expert validation before Month 1 (2026-11-08) to permit course correction; late discovery of gaps (e.g., vendors unwilling to pre-bind by Month 2 = 2026-12-08) compresses the remediation window and forces either Phase One deferral (Month 9 = 2027-07-08 backstop) or acceptance of reduced credibility.