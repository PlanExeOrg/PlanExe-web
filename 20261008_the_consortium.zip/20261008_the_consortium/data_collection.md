## 1. Entry-Gate Certification Timeline and Principal Escalation Authority

Entry-gate certification is the critical path; slippage beyond Month 9 (2027-07-12) compresses Phase One from 90 days to 30-60 days or forces cancellation. No binding timers or escalation procedures exist; principal go/no-go at Month 7.5 (2027-05-27) is noted but lacks teeth. Validation must confirm that a signed instrument with explicit deadlines, contingency paths and principal-level authority will be in place before any site selection or operator contracts are finalized. This de-risks the highest-probability failure pathway: indefinite entry-gate stall.

### Data to Collect

- Bilateral instrument draft completion date and signature timeline (target Month 7, 2027-05-12)
- Status of domestic legal authority enactment in both countries; any litigation risk and delay estimate
- Weekly entry-condition tracker showing progress on all 7 conditions (instrument, appropriations, access authority, site selection, inspector approval, operator/vendor participation, schedule)
- Principal go/no-go decision documentation at Month 7.5 (2027-05-27) with binding escalation rule and contingency paths (defer, proceed with reduced scope, stop)
- Budget tracking for gate-readiness sub-account (USD 50M from contingency); drawdown authorization and sunk-cost attribution

### Simulation Steps

- Model a bilateral steering committee tracking schedule using Gantt chart software (MS Project, Asana, or similar) with weekly condition status, blockers and escalation timers; share template bilaterally by Month 0.5 (2026-10-27)
- Conduct a legal-barrier assessment using interviews with US State Dept Bureau of Arms Control and Chinese foreign ministry liaisons; document any legislative amendment or litigation risk with estimated delays (2-4 months typical)
- Build a decision-tree model in spreadsheet software showing outcomes if any condition misses Month 8, 8.5 or 9 (2027-06-12, 2027-06-27, 2027-07-12) deadline; quantify sunk-cost burn per day of delay past Month 9 (2027-07-12)
- Establish bilateral budget-tracking dashboard (Google Sheets or Excel with bilateral edit access) showing gate-readiness sub-account balance, cumulative entry-gate spending by category, and drawdown authorization trail

### Expert Validation Steps

- Bilateral co-chairs and designated principal representatives validate principal-level go/no-go decision procedure and escalation timers (confirm 48-hour response rule and binding authority)
- State Department Office of Legal Counsel and Chinese counterpart legal authority certify domestic access-authority scope and identify any legislative gaps requiring amendment
- Independent budget auditor (appointed Month 2, 2026-12-12) audit-trails gate-readiness spending and certifies that entry-gate costs do not exceed the USD 50M sub-account or draw from operational envelopes
- New START and IAEA verification experts review bilateral instrument draft language on deadlock escalation and suspension triggers; recommend edits aligned with precedent (meetings scheduled Months 5-6, 2027-03-12 to 2027-04-12)

### Responsible Parties

- US and Chinese bilateral co-chairs (primary); national legal representatives; State Dept/Foreign Ministry liaison offices
- Independent budget auditor (Month 2 = 2026-12-12 appointment); bilateral steering committee secretariat

### Assumptions

- **High:** Bilateral instrument can be negotiated and signed by Month 7 (2027-05-12) if negotiation begins immediately (Month 0.5 = 2026-10-27) with weekly drafting cycles and principal-level escalation authority for blocking issues.
- **High:** Domestic legal authority to compel operator and private-vendor participation can be enacted by Month 7.5 (2027-05-27) without litigation delays >4 weeks in either country.
- **High:** Principal-level go/no-go decision at Month 7.5 (2027-05-27) with binding escalation rule (48-hour response, binary decision: proceed/defer/stop) is enforceable without re-negotiation or political delay.
- **Medium:** USD 50M gate-readiness sub-account held in escrow and accessible only upon simultaneous certification of all 7 conditions will prevent sunk-cost accumulation if entry gate slips.
- **Medium:** Any single entry condition slipping >2 weeks triggers automatic bilateral principal escalation within 48 hours without requiring co-chair consensus (escalation is automatic).

### SMART Validation Objective

By Month 7.5 (2027-05-27), certify that bilateral instrument is signed with binding escalation language, domestic access authority is enacted or has a defined legislative pathway with no delay risk >4 weeks, principal go/no-go decision procedure is documented with 48-hour response timers and binary outcomes, and all seven entry conditions are on track to certify by Month 9 (2027-07-12) or escalated to principals with contingency paths (defer 2-4 weeks, proceed with reduced scope, stop).

### Notes

- Entry-gate stall is the single highest-probability failure mode (estimated 6-12 months typical for bilateral instrument negotiation). Current plan provides no binding timers or escalation procedures.
- Sunk-cost exposure during entry-gate work is estimated USD 100-200M if gate slips past Month 9 (2027-07-12). This cost is unbudgeted and must be absorbed within spending envelopes, creating severe budget pressure.
- Contingency contingency upon entry-gate certification: only the USD 50M gate-readiness sub-account is ring-fenced; if gate-readiness spending exceeds USD 50M, it draws from the free USD 450M contingency, which is then unavailable for Phase One operational surges.
- Legal litigation over compelling private vendors or state-enterprise exemptions could delay vendor binding by 2-4 months (estimate), pushing Phase One into Month 11-12 (2027-09-12 to 2027-10-12) and compressing operational window below statistical significance.
- Principal escalation rule is stated in procedural documents but must be embedded in the bilateral instrument with binding language before signature; otherwise either government can claim no escalation authority exists.


## 2. Vendor Binding and Equipment Identity Attestation Validation

Attestation concentration creates a 10-40% unverifiable-equipment risk (estimate). Vendor binding, clean-room readiness and three-tier evidence validation are scheduled to complete by Month 8 (2027-06-12), leaving only 1 month for recovery if vendors refuse or keys fail validation. Pre-Phase-One validation de-risks this pathway: completed vendor census, documented key validation and operational clean rooms by Month 2.5 (2026-12-27) give 6 months for remediation before Phase One. Unverifiable-equipment forecasts by site enable threshold negotiation and contingency funding allocation.

### Data to Collect

- Complete vendor-participation census by site: each operator declares >=95% of supplier list with equipment counts; identifies any vendor >2% of declared units
- Attestation-key validation results: for each critical vendor (>5% of equipment), documented cryptographic key fingerprints and independent validation by accredited examiners from both countries
- Three-tier evidence ladder corroboration data: customs-record linkage times, maintenance-log completeness, physical-inspection field-test results on staged test units
- Clean-room examination center operational readiness: facility security certification, bilateral examination protocols, examiner training completion, test-run results on >=10 test units per non-binding vendor
- Vendor-refusal fallback outcomes: equipment classified by binding status (A: signed+validated, B: signed+pending, C: refusing/no-contact); unverifiable-equipment count projection by site

### Simulation Steps

- Deploy vendor-census spreadsheet (GitHub or bilateral shared folder) to each operator by Month 0.5 (2026-10-27) requesting supplier list, equipment counts, and contact information for binding negotiation; track completion by Month 1 (2026-11-12) deadline
- Run attestation-key validation simulation: obtain sample vendor key fingerprints and test bilateral examiner workflow (key fingerprint submission, digital signature verification, binding certificate issuance) using air-gapped tools (OpenSSL, GnuPG) in a staged lab environment
- Simulate corroboration evidence collection: use historical customs records, maintenance logs and physical inspection photos from prior datacenter audits (e.g., IAEA or OPCW reports, publicly available redacted samples) to test timeliness and completeness of each layer; model >=2-layer agreement rule
- Mock clean-room examination: deploy a test workstation in a controlled facility (SCIF or accredited security lab) and conduct a practice examination of 3-5 hardware units with fabricated identity discrepancies (wrong serial, firmware rollback, tamper-mark damage); measure examination cycle time and evidence quality against proposed bilateral protocols

### Expert Validation Steps

- Vendor representatives (critical vendors >5% equipment) meet bilaterally with attestation-validation experts by Month 2 (2026-12-12) to confirm key-custody procedures, binding participation terms, and key-escrow options (shared half-keys or third-party certification)
- Independent accredited examiners (appointed by both countries by Month 1.5 = 2026-11-27) conduct dry-run attestation validation on sample units; document procedure, time, and any key-validation failures or anomalies
- IAEA safeguards technical experts and OPCW challenge-inspection practitioners review clean-room examination protocols and corroboration-evidence adequacy by Month 2 (2026-12-12); recommend alignment with precedent (managed access, seals, unique identifiers)
- Bilateral vendors and operators certification meeting (Month 2.5 = 2026-12-27): bilateral co-chairs convene participating vendors to confirm participation terms, binding status and fallback pathways; document any vendor refusal or key-validation risk for principal escalation

### Responsible Parties

- Each country's bilateral vendor-binding lead; participating operators and vendors; accredited examiner panels from both countries
- Independent bilateral budget auditor (clean-room cost tracking); Counterintelligence Unit (vendor personnel vetting)

### Assumptions

- **High:** All critical vendors (>5% of declared equipment) will participate in binding negotiation and provide cryptographic key fingerprints for independent validation by Month 7 (2027-05-12).
- **High:** Accredited examiners from both countries can independently validate vendor attestation keys within 4-hour SLA, with <5% false-reject rate (keys wrongly rejected as invalid).
- **Medium:** Clean-room examination centers (one per country) can be operationalized by Month 2.5 (2026-12-27) with bilateral protocols, trained examiners, and equipment within USD 30-50M (estimate) and USD 500M testing envelope.
- **High:** Equipment from vendors refusing or unable to validate attestation will be <5% of total declared equipment per site, so unverifiable count remains <3% even after attestation failures.
- **Medium:** Three-layer corroboration (attestation + customs + physical; customs + maintenance + physical; supervised exam) provides >85% substitution-detection capability when attestation layer fails.

### SMART Validation Objective

By Month 2.5 (2026-12-27), complete vendor-participation census showing >=95% of declared equipment identified by supplier, classify all vendors by binding status (A/B/C), validate cryptographic keys for all critical vendors (>5% equipment) through bilateral accredited examiners, operationalize >=2 clean-room examination centers with tested protocols, and project unverifiable-equipment count by site (target: <3% per site, >3% escalates to principal review). By Month 7 (2027-05-12), all vendor binding is complete and attestation keys are validated; any vendor refusing or failing validation is classified Tier C (unverifiable equipment).

### Notes

- Vendor refusal is a Stop criterion if equipment from refusing vendors exceeds 3% per site (material unverifiable). No recovery path exists mid-Phase-One if vendors refuse binding during testing.
- Attestation-key validation latency is critical: proposed 4-hour SLA for key fingerprint verification must be validated by Month 2 (2026-12-12) dry-run to ensure intake speed is not crippled by key-validation backlog.
- Clean-room cost estimate USD 30-50M (estimate) for >=2 centers is within USD 500M testing envelope, but any cost overrun competes with blind-exercise design and pre-test funding.
- Vendor binding negotiation typically consumes 2-4 months per vendor tier; critical path is the slowest vendor, not the average. Recommend parallel binding for all vendors >2% equipment, with legal escalation authority if any vendor refuses.
- Tier C (refusing/unbound) equipment is automatically unverifiable; no operator choice. This is a binding lever: operators can pressure vendors to participate by threatening to declare their equipment unverifiable and lose market access.


## 3. Filter Adequacy and Identity-Confidence Threshold Validation

Operator-run redaction gateways have incentive to filter aggressively, stripping fields needed for substitution detection. The proposed 95% identity-confidence threshold (provisional) cannot be validated without empirical testing. Pre-test at Month 8.5 (2027-06-27) is only 2 weeks before Phase One start; if detection falls below 85%, no time remains for filter redesign before scored exercises begin. Early validation (Month 8.5 = 2027-06-27 simulation, Month 8.5 = 2027-06-27 pre-test) ensures that filter adequacy is proven before any Phase One operational equipment processing occurs.

### Data to Collect

- Filter-adequacy blind pre-test results: >=10 injected substitutions (wrong serial, firmware rollback, physical tampering, attestation forgery) per event type; detection rate measured with redacted evidence only (no raw telemetry)
- Detection-rate distribution by filter scenario: identify which field redactions (cluster membership, power state, timestamp precision) cause largest detection-rate degradation
- Identity-confidence scoring by layer: measure agreement rate between attestation, customs records, physical inspection and maintenance logs when applied to test units with known substitutions
- Evidence-schema corroboration matrix: which >=2-layer combinations achieve >95% confidence (proposed threshold); which combinations fall below 90%
- Operator-controlled gateway log-audit results: filter decisions documented with reason codes, redaction impact on detectability, any filter rule violations or drift from bilateral agreement

### Simulation Steps

- Establish a filter-adequacy test lab by Month 1 (2026-11-12) using staged equipment or virtual simulation (equipment substitution database with test scenarios); inject >=10 known substitutions with various signatures (serial mismatch, firmware version change, attestation digest alteration, physical seal tampering)
- Apply proposed operator-controlled redaction-gateway rules (cluster membership redacted, power state redacted, etc.) to raw records for each test unit; compare redacted vs. unredacted detection rates using intake inspection checklist
- Run three-layer corroboration matching algorithm on test data: for each test substitution, check whether attestation layer alone detects discrepancy (yes/no), customs+maintenance layer (yes/no), physical inspection layer (yes/no); measure >=2-layer agreement rate
- Simulate filter-rule audit process: log every redaction decision in a tamper-evident mock ledger with reason code, examiner name, timestamp; run a bilateral audit tool comparing both countries' filter logs for drift or unauthorized rule changes

### Expert Validation Steps

- Independent testers (Challenge Exercise Design Panel, appointed Month 1.5 = 2026-11-27) conduct blind pre-test at Month 8.5 (2027-06-27) with >=10 injected substitutions in staging or spare-inventory zones; inspectors work blind (no knowledge of test status) and detection is scored
- Bilateral sensitive-asset experts review minimum evidence schema (serial, firmware, attestation, timestamp, physical identifiers) and jointly approve list of non-redactable fields by Month 1.5 (2026-11-27); any proposed redaction of a non-redactable field is escalated to principals
- Accredited examiner from each country validates filter-adequacy test methodology and results by Month 8.5 (2027-06-27); if detection rate <85%, halt all operator contracts and renegotiate filters before Phase One start
- IAEA and OPCW managed-access experts review filter-adequacy methodology and recommend any adjustments aligned with precedent for protecting sensitive information while preserving evidence quality (consultation Month 2 = 2026-12-12)

### Responsible Parties

- Challenge Exercise Design Panel (independent testers); bilateral sensitive-asset specialists; operator-liaison representatives
- Accredited examiners from both countries; independent budget auditor (funding for pre-test injections and test-equipment procurement)

### Assumptions

- **High:** Operator-controlled redaction gateway can preserve >=9 of 10 substitution-detection signals (90% threshold, 85% minimum halt threshold) under bilateral agreement on non-redactable fields.
- **High:** Three-layer corroboration (attestation, customs+maintenance, physical) with >=2-layer agreement rule achieves >95% identity confidence on equipment with known substitutions.
- **Medium:** Filter-adequacy testing by Month 8.5 (2027-06-27) allows sufficient time for filter renegotiation before Phase One operational clock start at Month 9 (2027-07-12).
- **Medium:** Operator compliance with jointly agreed filter rules (no unauthorized redactions) can be verified through log audit and bilateral oversight without real-time technical controls.
- **Low:** Test-unit substitutions can be reliably injected without detection by field inspectors (blind testing) and without operator knowledge or suspicion during pre-test at Month 8.5 (2027-06-27).

### SMART Validation Objective

By Month 8.5 (2027-06-27), conduct blind pre-test with >=10 injected substitutions per event type; measure detection rate with redacted evidence (target >=90%, halt if <85%). By the same date, validate that minimum evidence schema non-redactable fields are bilaterally agreed and any unauthorized redaction triggers automatic equipment escalation to unverifiable status. By Month 9 (2027-07-12), confirm that three-layer corroboration achieves >95% identity confidence on >=90% of test units and that operator-gateway filter-decision logs show zero drift from bilateral agreement. If any target is unmet, halt Phase One operational start and renegotiate filters within 2-week window.

### Notes

- Filter adequacy is not validated until Month 8.5 (2027-06-27) pre-test—only 2 weeks before Phase One start. Any discovery of <85% detection at that point leaves no time for filter redesign before operational Phase One begins.
- Identity-confidence threshold of >95% (provisional) is a pre-test assumption with no empirical grounding. If three-layer corroboration achieves only 90% on test units, either the threshold must be renegotiated or equipment failing to meet 95% is automatically unverifiable.
- Redaction of critical fields (serial, firmware, attestation digest) can cause detection rate to drop from 95% (unredacted) to <70% (heavily redacted), violating the 85% pre-test minimum. Bilateral agreement on non-redactable fields must be locked by Month 1.5 (2026-11-27) to give operators time to design compliant gateways.
- Blind-test injection requires staging or spare-inventory zones where test substitutions can be placed without alerting inspectors; operational integrity depends on compartmentation and CI oversight.
- False-positive risk during filter-adequacy testing: if a redacted data set triggers false-positive anomaly alerts during pre-test, the test result is contaminated. Separate filter-adequacy test from operational exercises until production-readiness is validated.


## 4. Deadlock and False-Positive Containment Procedures

Deadlock and false-positive cascade risk are medium-high. The pre-project assessment estimates 2-3 false positives per Phase One if partition is weak; a single misclassification can trigger automatic suspension, consuming 3-7 operational days. Enumerated automatic-suspension triggers with objective thresholds convert deadlock from political judgment into procedural execution. CHALLENGE-tag partition with cryptographic commitment and 2-hour escalation contain false-positive impact. Validation requires: (1) instrument language locked before signature, (2) technical controls implemented in ledger system, (3) misclassification drill executed to prove 2-hour SLA is achievable across time zones.

### Data to Collect

- Bilateral instrument language on deadlock escalation: 5/8/13-day timers, referee panel fact-statement procedure, principal-review decision rule, status-quo heightened-inspection default, documented unresolved-discrepancy aging rule
- Challenge-event partition technical specification: CHALLENGE-tag cryptographic commitment (dual-signed before injection), misclassification detection workflow, 2-hour principal escalation and auto-reinstatement procedure
- Enumerated automatic-suspension triggers with objective thresholds: unverifiable >3% for 5 days, divergence >5%, access denial >15%, discrepancy age >10 days, operator consent withdrawn; documented in bilateral instrument
- False-positive containment and audit trail: false-positive incident count per site per phase, 1-point confidence reduction per misclassification, halt condition (>3 false positives per site during Phase One = impaired-confidence review)
- Misclassification drill results from Month 8.75 (2027-07-05) rehearsal: time-to-escalation measured, auto-reinstatement procedure validated, inspector training completion rates

### Simulation Steps

- Draft bilateral instrument text on deadlock and suspension mechanics using template language from New START, IAEA Additional Protocol and OPCW CWC challenge-inspection clauses; simulate co-chair and principal review workflows in a decision-tree model with realistic time allocations (5 days co-chair, 3 days referees, 5 days principals)
- Design CHALLENGE-tag cryptographic protocol: generate dual-signed JSON or XML envelope for each injected scenario with UUID, scenario description (encrypted), bilateral signatures, injection timestamp; verify that system ingestion rules validate dual signature before exempting event from suspension triggers
- Model false-positive cascade: simulate 3 sequentially misclassified CHALLENGE events triggering 3 suspension cascades within a 7-day window; measure cumulative operational impact (days offline, KPI data loss, confidence degradation)
- Build misclassification escalation simulation: test 2-hour principal-notification SLA across time zones (UTC+8 Beijing, UTC-5 Eastern, UTC+1 Geneva); verify that auto-reinstatement can be executed without waiting for principal decision confirmation

### Expert Validation Steps

- New START Bilateral Consultative Commission (BCC) and IAEA safeguards escalation experts review drafted instrument language on deadlock timers and suspension triggers by Month 5 (2027-03-12); recommend edits aligned with precedent and identify any new loopholes
- Bilateral co-chairs and designated adjudication referees conduct a full misclassification drill at Month 8.75 (2027-07-05): simulate a CHALLENGE event incorrectly flagged as operational, measure time-to-escalation, verify auto-reinstatement procedure executes within 2 hours, document decision audit trail
- Independent auditor certifies that CHALLENGE-tag partition is embedded in the bilateral instrument with binding language (not procedural guidance); confirms that system technical controls prevent CHALLENGE-tagged events from triggering suspension without principal-level override
- Cryptographic security expert validates CHALLENGE-tag dual-signature mechanism: verifies that keys cannot be forged or substituted, that timestamp cannot be altered retroactively, and that audit trail of all tag signatures is immutable in the ledger

### Responsible Parties

- Bilateral co-chairs; bilateral legal team (instrument drafting); adjudication referees (decision-making); Incident Command Center duty officers (operational execution)
- Cryptographic security expert (CHALLENGE-tag technical validation); independent auditor (procedure audit trail)

### Assumptions

- **High:** Bilateral instrument can be drafted with explicit deadlock language (5/8/13-day timers, referee procedure, principal decision rule) and signed by Month 7 (2027-05-12) without renegotiation or legal challenge.
- **Medium:** 2-hour principal escalation SLA for misclassified CHALLENGE events can be reliably achieved across UTC±5 time-zone separation without requiring principals to be on-call 24/7.
- **Medium:** Auto-reinstatement of suspended sites can be executed without double-key principal authorization (automatic, pending principal adjudication) under the partition rule.
- **High:** CHALLENGE-tag dual-signature cryptographic protocol is unforgivable and immutable, preventing either country from claiming a tag was unauthorized or corrupted post-hoc.
- **Medium:** Enumerated auto-suspension triggers (unverifiable >3%, divergence >5%, age >15 days) cannot be weaponized by manufactured incidents without exceeding the false-positive tolerance (>3 false positives = impaired-confidence review).

### SMART Validation Objective

By Month 7 (2027-05-12), bilateral instrument is signed with explicit deadlock-escalation language (5/8/13-day timers, referee procedure, principal decision rule, auto-suspension triggers, CHALLENGE-tag partition) that both governments certify as binding and unambiguous. By Month 8.75 (2027-07-05), conduct full misclassification drill: inject a known false CHALLENGE event, measure time-to-escalation (<2 hours), validate auto-reinstatement procedure, verify no suspension persists pending principal adjudication, document decision audit trail. By Month 9 (2027-07-12), Incident Command Center is operational with 24/7 duty-officer coverage, misclassification escalation SLA is validated, and all adjudication referees and principals are trained on procedures. By Month 11 (2027-09-12), cumulative false-positive count per site is tracked in KPI dashboard; if any site exceeds >3 false positives, impaired-confidence review is triggered automatically.

### Notes

- Deadlock escalation timers (5/8/13 days) assume continuous business-day operations. Holiday closures, personnel leave or geopolitical crises could compress or expand timers; consider force-majeure language in instrument.
- False-positive tolerance threshold of >3 false positives per site per Phase One (proposed threshold) may be too lenient if each false positive consumes 3-7 operational days; recommend tighter tolerance (>2 triggers impaired-confidence review) during pre-test validation.
- CHALLENGE-tag partition depends on 100% compliant tagging discipline from the Challenge Exercise Design Panel. Any missed tag or out-of-sequence tag could cascade into suspension; recommend automated tag-validation rules in the ledger system that reject untagged scenarios before they enter the operational log.
- Principal escalation SLA of 2 hours assumes secure comms and decision-maker availability across time zones. Beijing, Washington DC and Geneva span ~18 hours of global time; escalation during night-shift hours may exceed 2-hour SLA; recommend 24/7 duty-principal designation.
- Misclassification drill must be fully executed at Month 8.75 (2027-07-05) before scored exercises begin; any procedure failure discovered during actual Phase One testing cannot be corrected in time and will destroy operational credibility.


## 5. Ledger Synchronization and Divergence Detection Latency

Ledger synchronization and divergence detection are foundational to evidence credibility. The proposed 1-hour sync KPI and 4-hour divergence-detection window are aggressive; validation is critical before Phase One operational start. A single undetected divergence or unreconciled mismatch between national ledger copies could undermine the entire Go/Modify/Stop verdict. Pre-Phase-One validation (ledger-node deployment, cryptographic-key ceremony, divergence-scenario testing) by Month 2.5 (2026-12-27) gives 6 months to harden infrastructure and remediate any latency or security gaps before Phase One testing begins.

### Data to Collect

- Ledger-node facility security certification: SCIF-equivalent hardening, biometric access control, intrusion detection, Faraday cage for cryptographic key storage, UPS and backup power (72+ hours), geographically diverse locations >=300 km apart
- Cryptographic key-exchange ceremony documentation: bilateral key-derivation procedure, key custody split between countries, key-escrow mechanism, audit trail of key generation and distribution
- Checkpoint synchronization latency measurements: actual time from local event recording to signed checkpoint exchange between national ledger nodes; target <=1 hour (proposed)
- Divergence-detection workflow results: automated divergence detection within 4 hours (proposed); reconciliation procedure execution time; reconciliation closure rate (>95% within 24 hours target)
- Neutral-party digest-escrow implementation: custodian identification and security vetting, escrow-access procedures, hourly digest update rate, forensic-recovery capability validation

### Simulation Steps

- Establish mock bilateral ledger nodes at geographically diverse secure facilities using open-source ledger software (e.g., Apache Cassandra, permissioned blockchain simulator or custom hash-chain implementation) by Month 1 (2026-11-12); simulate event recording, checkpoint generation and signed-hash exchange over IPsec tunnel with mutual TLS
- Measure local event-recording latency: capture timestamps from physical device (network switch, GPS-disciplined clock) of evidence-generation event, ledger ingestion, signed checkpoint generation; quantify latency components (device-to-gateway, gateway-to-ledger, ledger-to-checkpoint)
- Simulate bilateral checkpoint exchange: generate hourly signed hash-chain checkpoints containing event count, timestamp nonce, and bilateral signatures; transmit over dedicated IPsec tunnel and measure delivery latency (target: <=1 hour), delivery failure rate (target: <1% per month), and retransmission overhead
- Model divergence scenarios: inject intentional record-keeping delays or packet loss between ledgers; measure divergence-detection latency (target <=4 hours); simulate reconciliation workflow and measure closure time (target <=24 hours); test both automated and manual reconciliation paths

### Expert Validation Steps

- Cryptographic ledger architect (appointed Month 1 = 2026-11-12) conducts bilateral key-derivation ceremony by Month 1.5 (2026-11-27): generates shared cryptographic secrets for checkpoint signing, distributes half-keys to each country's secure facility, documents all procedures in an escrow-sealed envelope; validates ceremony with independent cryptographic auditor present
- National facility-security inspectors (US and China counterparts) conduct physical security audit of hardened ledger-node facilities by Month 2 (2026-12-12); certify SCIF-equivalent hardening (biometric access, intrusion detection, no single-point-of-failure power/cooling), document any deficiencies and remediation timeline
- Network security expert validates IPsec tunnel configuration and TLS mutual authentication between ledger nodes by Month 2 (2026-12-12); stress-tests tunnel under high-volume traffic simulation (10x normal expected event load) to measure latency, packet loss and failover behavior
- Neutral-party custodian (independent security audit firm, appointed Month 1.5 = 2026-11-27) validates escrow procedures and tests forensic-recovery capability: simulate a full ledger-node failure and demonstrate that escrow digests can be used to reconstruct the lost ledger copy (recovery time target: <=24 hours)

### Responsible Parties

- Bilateral Ledger and Cryptographic Systems Architect team (one lead per country); national secure-facility security officers; network and cryptographic security experts
- Independent neutral-party digest custodian; independent cryptographic auditor; facility security inspectors from both countries

### Assumptions

- **High:** Hardened ledger-node facilities in geographically diverse locations (>=300 km apart) can be operationalized by Month 2 (2026-12-12) with SCIF-equivalent security, biometric access and intrusion detection without cost overrun >USD 50M (estimate).
- **High:** Cryptographic key-derivation ceremony can generate bilateral shared secrets by Month 1.5 (2026-11-27) using standard cryptographic protocols (e.g., Diffie-Hellman); shared secrets enable checkpoint signing without requiring either country to hold the other's private key.
- **Medium:** Hourly signed hash-chain checkpoints can be exchanged over dedicated IPsec/TLS tunnel with <=1-hour latency (proposed) and <1% monthly delivery failure rate without real-time network monitoring or manual intervention.
- **Medium:** Divergence-detection algorithm can identify >5% disputed events within 4 hours (proposed) with <5% false-positive rate (misclassifying consistent records as diverged).
- **Medium:** Neutral-party digest-escrow custodian can reliably maintain hourly copies of both countries' ledger-copy digests and enable forensic reconstruction of either ledger within 24 hours (proposed) after a node failure or suspected tampering.

### SMART Validation Objective

By Month 1.5 (2026-11-27), conduct bilateral cryptographic key-derivation ceremony under independent audit; distribute and escrow shared secrets. By Month 2 (2026-12-12), certify hardened ledger-node facilities (SCIF-equivalent security, >=300 km separation); validate network transport (IPsec/TLS mutual authentication, <1 hour latency); measure local event-recording latency to ensure <=1 hour end-to-end checkpoint generation. By Month 2.5 (2026-12-27), operationalize neutral-party digest-escrow custodian and validate forensic-recovery capability (simulate node failure, recover ledger within 24 hours). By Month 8 (2027-06-12), run 1-week ledger stress-test under 10x normal event load; measure divergence-detection latency (target <=4 hours), reconciliation closure time (target <=24 hours) and transaction-processing overhead. Document any latency or reliability risks exceeding thresholds in risk register and escalate to principals for contingency funding.

### Notes

- Ledger synchronization is not testable until events are actually being recorded; simulation during Months 0-2 (2026-10-12 to 2026-12-12) uses mock events but cannot replicate actual operational load, geopolitical latency (e.g., border firewall delays) or security incidents (e.g., DDoS, key compromise). Stress-test during Phase One ramp-up (Month 9 = 2027-07-12, Days 1-5 = opening inventory baseline) will be the first real validation.
- Divergence-detection false-positive rate (misidentifying consistent records as diverged) is not quantified. If false-positive rate >10%, impaired-confidence reviews will cascade even when no real tampering occurred, eroding regime credibility.
- Neutral-party digest custodian is a new third party outside bilateral control; custody of hourly ledger digests is a high-value espionage target. Custodian location (Geneva? Singapore?) and security protocols must be jointly agreed and independently audited.
- Cryptographic key-escrow requires sharing half-keys between countries; if either half-key is compromised, both countries' checkpoint signatures can be forged. Key custody procedures and security clearances for key-custodian personnel must be stringently vetted.
- IPsec tunnel between ledger nodes traverses at least one commercial internet backbone; a determined nation-state adversary could intercept, replay or inject packets to induce divergence. Consider air-gapped courier sync as fallback; cost trade-off between latency (online IPsec <1 hour) vs. security (offline courier 24-48 hours).


## 6. Counterintelligence Vetting and Compartmentation Discipline

Continuous resident mirrored inspectors at counterpart sites are high-value intelligence targets. Espionage compromise of a single inspector can exfiltrate equipment identifiers, facility layouts, vendor information or classified inspection procedures—destroying operator confidence and causing site withdrawal. The Counterintelligence and Personnel Security Unit role is critical but demanding: vetting 350-500 staff, maintaining compartmentation discipline, running insider-threat red cell. Pre-Phase-One validation (Month 1-2 = 2026-11-12 to 2026-12-12) ensures CI protocols are operationalized, vetting is complete and compartmentation rules are enforceable before Phase One clock starts.

### Data to Collect

- Personnel security clearance completeness for all 350-500 cleared inspectors, technical, translation and support staff: background investigation results, financial vetting, polygraph examination records, reciprocal intelligence-service clearance validation
- Compartmentation audit logs: documented access scope per inspector (site assignment, event-type knowledge, ledger access limits); cross-compartment knowledge violations; tenure-limit compliance (no inspector >6 months at same site)
- Insider-threat red-team operation results: attempted compromises (social engineering, financial offers, relationship-capture scenarios); success rate (estimated target: <5% attempted compromises succeed); documented findings and escalation records
- CI-liaison officer coverage and incident-logging: host-country CI liaisons embedded at each site; daily liaison-alert log showing boundary violations, unauthorized access attempts, suspicious inspector behavior
- Operator-consent status tracking: operator feedback on inspector compliance with zone boundaries, evidence-handling rules, compartmentation rules; consent status (full/degraded/withdrawn); any incidents of inspector boundary violations or perceived intelligence-collection activity

### Simulation Steps

- Develop a comprehensive personnel-security vetting checklist (Month 0.5 = 2026-10-27) covering background investigation, financial records, foreign-contact review, polygraph protocol and reciprocal-clearance validation; pilot the checklist on a sample of 10-20 candidate inspectors before full deployment
- Model compartmentation rules: assign each inspector a site, event-type compartment (intake only, monitoring only, exit only) and limit their ledger-access privileges to only the events and sites they are assigned to; simulate access violations (cross-site communication, out-of-compartment knowledge) and measure detection latency (target: <2 hours)
- Design insider-threat red-team operation: develop 5-10 social-engineering and financial-offer scenarios targeting candidate compromises (relationship-capture, family pressure, financial hardship); validate that red-team attempts can be reliably detected and do not compromise actual inspector credibility or security clearances
- Build compartmentation-audit dashboard: track tenure expiry dates, compartment-boundary violations, cross-site knowledge incidents; automate alerts for inspectors approaching 6-month tenure limits (alert at Month 5 = 2027-03-12, remove at Month 6 = 2027-04-12); track rotation and break schedules to ensure no inspector exceeds limits

### Expert Validation Steps

- Bilateral Counterintelligence Unit leads (appointed Month 0.5 = 2026-10-27, min 4 senior CI specialists per country) design and implement personnel-security vetting protocol by Month 1 (2026-11-12); validate protocol against NSA personnel-security standards and IAEA safeguards personnel-vetting precedent
- US and Chinese national security and counterintelligence agencies review and validate reciprocal-clearance procedures (reciprocal acceptability of each country's security-clearance investigative standards) by Month 1.5 (2026-11-27); identify any gaps requiring bilateral supplementary investigation
- Bilateral insider-threat red-team operations (2 specialists per country) conduct practice red-team attempts on sample pool of 5-10 candidate inspectors by Month 2 (2026-12-12); document success rate, detection latency, and inspector reaction; refine red-team tactics based on results
- Host-country CI-liaison officers (embedded at each site by Month 1 = 2026-11-12) conduct quarterly compartmentation audits starting Month 3 (2027-01-12); review access logs, interview inspectors on out-of-compartment knowledge, identify any relationship-capture attempts or suspicious foreign-contact patterns

### Responsible Parties

- Bilateral Counterintelligence Unit leads (4+ per country); national security and counterintelligence agencies (reciprocal-clearance validation); host-country CI-liaison officers embedded at each site
- Insider-threat red-team operations (2 per country); bilateral compartmentation-audit function

### Assumptions

- **Medium:** All 350-500 candidate inspectors can be comprehensively vetted (background, financial, polygraph, reciprocal clearance) by Month 2 (2026-12-12) without bottleneck delays and with <5% rejection rate.
- **High:** Compartmentation rules (no cross-site knowledge, no event-type spillover, ledger-access limits) can be enforced technically in the ledger system and procedurally via CI audit without crippling inspectors' ability to recognize patterns or anomalies.
- **Medium:** Insider-threat red-team attempts can be conducted on candidate inspectors without compromising their clearances or creating false positives that lead to unjust rejection of qualified staff.
- **Medium:** 6-month site-tenure limit with 2-month breaks prevents relationship capture and country-deep espionage even though shared sites (both countries' inspectors working same zone) mean counterpart relationships form over months.
- **High:** Host-country CI-liaison officers can audit inspector boundary compliance and foreign contacts without themselves becoming infiltration agents for the host government.

### SMART Validation Objective

By Month 1.5 (2026-11-27), bilateral CI Unit is operationalized with charter, staffing and reciprocal-clearance vetting protocol documented. By Month 2 (2026-12-12), all 350-500 candidate inspectors have completed background investigation, financial vetting and polygraph; reciprocal security-clearance acceptability is validated; final clearance list is published to both co-chairs. By Month 2.5 (2026-12-27), compartmentation rules are embedded in ledger system (access-control lists per inspector), tenure-limit tracking is automated (alerts at 5 months, removal at 6 months), and insider-threat red-team operations have completed practice runs on sample pool with <5% acceptance rate for red-team successful compromise. By Month 3 (2027-01-12), host-country CI-liaison officers are embedded at each site and conducting daily compliance audits (boundary violations, cross-compartment knowledge, suspicious contacts). By Month 8 (2027-06-12), first quarterly compartmentation audit is completed and any violations are documented and remediated.

### Notes

- Personnel security vetting for 350-500 cleared staff in 2-3 months is extremely compressed; typical US clearance cycles are 6-12 months. Recommend: (1) begin vetting immediately at Month 0 (2026-10-12) in parallel to instrument negotiation; (2) use expedited clearance procedures (National Security Presidential Memorandum or equivalent Chinese directive); (3) if vetting cannot complete by Month 2 (2026-12-12), escalate staffing shortfall to principals for decision on Phase One delay or reduced inspector corps.
- Reciprocal-clearance acceptability is politically sensitive; US may not trust Chinese clearance investigations and vice versa. Recommend: (1) bilateral supplementary investigation of high-sensitivity candidates; (2) reciprocal CI liaison observation during polygraph and background interviews; (3) pre-publication agreement on clearance standards so no surprises at Month 2 (2026-12-12).
- Compartmentation discipline can cripple substitution detection if inspectors are siloed by site/event and cannot recognize cross-site patterns or maintenance anomalies. Recommend: (1) allow limited cross-compartment briefings on specific technical findings (without revealing inspector identities or operational contexts); (2) rotate specialists (not resident inspectors) across sites to carry institutional knowledge; (3) test compartmentation stress-points during dry-run at Month 8 (2027-06-12).
- Insider-threat red-team attempts on candidate inspectors can backfire if (1) inspector suspects compromise attempt and refuses clearance, (2) red-team attempt creates a false positive and inspector is unjustly rejected, or (3) red-team operative is detected and causes diplomatic incident. Recommend: (1) red-team operations cleared with national security advisors; (2) red-team failure scenarios are pre-approved and do not trigger clearance rejection; (3) red-team operators are highly trained and document all attempts.
- Host-country CI-liaison officers have access to inspector notes, evidence-handling logs and compartmentation violations; they can easily become a spy channel for the host government. Recommend: (1) CI liaisons are vetted reciprocally and cleared by the counterpart government; (2) liaison reports are dual-reviewed (host and counterpart CI); (3) liaison access to inspector evidence is logged and audited by neutral party.


## 7. Reciprocal-Access Parity and Divergence Threshold Validation

Reciprocal access is a Go criterion; asymmetric access >15% variance (proposed threshold) triggers impaired-confidence review and potentially a Stop condition. However, non-identical sites (different equipment counts, facility sizes, customs latency) invite disputes over what 'equivalent' access means. Pre-Phase-One validation (site-equivalence baseline, access-parity trial runs during Months 6-8 = 2027-04-12 to 2027-06-12) establishes objective parity metrics and thresholds before Phase One scoring begins. Trial runs during site-preparation phase (Months 6-8 = 2027-04-12 to 2027-06-12) test the accounting system and refine denial-reason codes without operational pressure.

### Data to Collect

- Matched-site equivalence baseline data by site: declared equipment count and categories, staging-area square meters, spare-inventory capacity, maintenance-bay square meters, customs-access latency (time from vehicle arrival to inspection initiation), operator staffing levels for facility access coordination
- Access-parity accounting methodology and trip-point definitions: unit of comparison (matched events vs. outcome-based detection), tolerance bands (±10% variance proposed), denial-reason codes (access granted, access denied, delayed >48 hours, other), threshold for impaired-confidence review (proposed >15% for 2 weeks)
- Reciprocal-access denial logs from Months 6-8 (2027-04-12 to 2027-06-12) pre-Phase-One period: every inspector-access request (entry, staging-area inspection, equipment sampling, evidence handling), site-operator response (approved, denied, delayed), denial reason code, host-liaison witness log
- Parity-variance trend data by week: cumulative access-approval rate for each country's inspectors at matched sites; variance between sites calculated as (approval rate Site A) - (approval rate Site B) / average; trend analysis to identify asymmetric denial patterns
- Operator-feedback on access fairness by site: operator perception of reciprocal treatment (fair/degraded), documented incidents of preferential access or obstruction, any operator requests for parity adjustment

### Simulation Steps

- Establish site-equivalence data collection templates (Month 0.5 = 2026-10-27) requesting equipment counts, facility dimensions, customs-access data and operator feedback from each participating operator; compile baseline equivalence data by Month 1 (2026-11-12)
- Design bilateral access-parity accounting system (spreadsheet or lightweight database) by Month 1 (2026-11-12) with fields: site ID, request date, inspector country, access category (entry, staging, sampling, evidence handling), approval status, denial reason code, delay duration; auto-calculate weekly approval rate by country per site
- Run parity-variance scenario model (Month 1.5 = 2026-11-27): simulate 100 sequential access requests at each matched-site pair with random approval rates (vary 70-95% approval for each site) and measure whether ±10% tolerance band captures actual asymmetries without false alarms
- Design denial-reason code taxonomy (Month 1 = 2026-11-12): legitimate reasons (equipment maintenance, operator workload, customs delay, facility access limitations), procedural denials (missing paperwork, wrong inspector credentials, unscheduled visit), anomalous denials (unexcused refusals); classify simulated denials by reason code and measure false-positive rate

### Expert Validation Steps

- Bilateral Reciprocal Access Parity Accounting Working Group (2 specialists per country) review site-equivalence baseline data by Month 2 (2026-12-12) and validate that matched sites are sufficiently equivalent (within ±20% on equipment count, facility size, customs access) to justify symmetric parity expectations
- IAEA safeguards and OPCW challenge-inspection practitioners review parity-accounting methodology by Month 2 (2026-12-12) and recommend alignment with precedent (e.g., IAEA managed-access protocols, OPCW sample-access denial procedures)
- Bilateral co-chairs conduct parity-threshold calibration meeting by Month 8 (2027-06-12) using data from Months 6-8 (2027-04-12 to 2027-06-12) pre-Phase-One access requests; jointly agree on final threshold for impaired-confidence review (target: >15% variance for 2 consecutive weeks) and document in bilateral instrument amendment if needed
- Independent auditor validates parity-variance calculation methodology and spot-checks monthly parity reports during Phase One (sampling >=5 denial-reason codes per report) to ensure consistent classification and prevent goalpost-moving on parity definition

### Responsible Parties

- Bilateral Reciprocal Access Parity Accounting Working Group (2 specialists per country); bilateral co-chairs (threshold calibration); participating operators (access data collection and operator-feedback)
- Independent auditor (parity-report spot-checking during Phase One)

### Assumptions

- **Medium:** Matched US and China sites are sufficiently equivalent (within ±20% on equipment count, facility capacity, customs access) so that symmetric parity expectations (±10% variance tolerance) are defensible to both governments.
- **Medium:** Denial-reason codes can be objectively classified (legitimate vs. anomalous) without operator bias; >90% inter-rater agreement on reason-code classification without further clarification.
- **Low:** Parity variance measured by weekly approval-rate delta can be calculated without revealing individual inspector identities or specific access circumstances (compartmentation respected).
- **Medium:** Asymmetric access (>15% variance) will be detected within 2 weeks of onset, allowing timely impaired-confidence review before material Phase One time is lost.
- **Low:** Trial parity accounting during Months 6-8 (2027-04-12 to 2027-06-12) (site-preparation phase) will validate methodology and threshold calibration before Phase One operational scoring begins.

### SMART Validation Objective

By Month 1 (2026-11-12), collect and publish baseline equivalence data for matched sites (equipment count, facility dimensions, customs access, operator staffing). By Month 2 (2026-12-12), validate site-equivalence defensibility (within ±20% on key metrics); lock site-pairing rationale in bilateral instrument. By Month 1.5 (2026-11-27), operationalize bilateral access-parity accounting system with denial-reason code taxonomy and weekly approval-rate calculation. By Month 8 (2027-06-12), calibrate final parity threshold (proposed >15% for 2 weeks) based on pre-Phase-One trial data from Months 6-8 (2027-04-12 to 2027-06-12); publish calibrated threshold in bilateral instrument amendment or KPI dashboard. By Month 12.25 (2027-10-20), parity variance at verdict is <=10% at all sites, or documented asymmetries are acknowledged as site-specific technical factors (not government obstruction) in the verdict report.

### Notes

- Site equivalence is challenging because US and Chinese datacenters have different ownership structures (commercial vs. state-run), equipment sourcing (US vendors vs. Chinese domestic vendors) and security practices. Matched-site pairing rationale must be jointly agreed and defensible to both governments' analysts.
- Denial-reason code taxonomy risks becoming politicized: what one side calls 'unexcused refusal' the other side calls 'facility maintenance priority.' Recommend: (1) pre-define reason codes jointly and lock in bilateral instrument; (2) require reason-code justification within 24 hours of denial; (3) escalate any denial with no reason code or disputed reason code to bilateral liaison for clarification within 48 hours.
- Parity variance calculated as % delta can mask real asymmetries if approval rates are low at both sites (e.g., both sites 60% approval = 0% variance but 40% denial rate is still high). Recommend absolute-threshold metric alongside variance metric: escalate if approval rate drops below 80% at any site regardless of parity delta.
- Trial parity runs during Months 6-8 (2027-04-12 to 2027-06-12) may not be representative of Phase One access patterns because sites are still under preparation and operator staffing/access procedures may change. Recommend: run trial at >=2 weeks during normal operations before Phase One start to establish baseline variability.
- Operator feedback on access fairness is subjective and politically sensitive; operators may complain about reciprocal fairness to justify their own access delays or obstruction. Recommend: operator-feedback reports are anonymous (coded by site, not named operators) and reviewed by bilateral operations directors, not co-chairs.

## Summary

The Consortium is a USD 5 billion, 90-day bilateral US-China verification pilot (Months 9-12, 2027-07-12 to 2027-10-12) designed to test whether changes to declared equipment at matched datacenters can be credibly verified through layered evidence, mirrored inspectorates, and double-key governance. The project depends on seven entry conditions (signed instrument, appropriations, access authority, site selection, inspectors, operator/vendor participation, equipment schedule) certified at a single gate by Month 9 (2027-07-12), followed by 90-day operational testing with blind detection exercises and a final Go/Modify/Stop verdict at Month 12.25 (2027-10-20). The plan faces three critical failure pathways: (1) entry-gate stall consuming sunk costs without operational test; (2) vendor-refusal or attestation-key compromise rendering 10-40% of equipment unverifiable, exceeding the 3% material threshold; (3) deadlock, false-positive cascade or manufactured-incident gaming weaponizing suspension procedures. This data collection plan identifies five to seven most critical validation areas that must be de-risked before Phase One operationally begins, with focus on the highest-sensitivity assumptions: entry-gate certification timeline and escalation authority, vendor-binding completion and attestation-key custody, filter-adequacy and identity-confidence thresholds, deadlock and false-positive containment procedures, and ledger divergence detection and reconciliation latency. The plan prioritizes immediate actions (Months 0-2, 2026-10-12 to 2026-12-12) to lock binding instrument language, complete vendor binding, validate filter adequacy, establish Counterintelligence Unit vetting, and operationalize secure ledger infrastructure before Phase One clock start.