**Goal Statement:** Run a 90-day Phase One operational test (Months 6-9 = 2027-04-08 to 2027-07-08) of The Consortium, a US–China mechanism verifying declared frontier-computing equipment changes at 3 matched pairs of declared datacenters, within a USD 5.0 billion cap (USD 2.5 billion each), and reach a Go/Modify/Stop decision by Month 9.5 (2027-07-23).

## SMART Criteria

- **Specific:** Verify arrivals, installations, removals, transfers, maintenance changes and decommissioning of declared equipment at matched participating sites, then issue a Go, Modify or Stop decision. Excludes total-capacity estimates, workload or model-weight checks, hidden-facility detection and foreign-hosted infrastructure.
- **Measurable:** Five scored criteria: detection (at least 70% planned class, at least 50% unplanned class; proposed thresholds), false positives at most 10%, unverifiable equipment at most 5%, parity at least 85% (definition TBD), no discrepancy older than 21 days. Go needs 4 of 5 plus no hard Stop trigger. All thresholds provisional, validated on pilot data.
- **Achievable:** Both leaders back the mission and can compel participation. Funding is fixed at USD 2.5 billion per country, about 180 full-time staff per country (estimate) and 54 exercises are planned. Limits: no trust, thin statistics (pooled about ±12% at 95%, per type about ±32%; estimate) and strict entry gates.
- **Relevant:** Tests whether declared-equipment change verification is credible between distrustful powers, protecting national security and political control. Public value is mission justification and fiscal accountability; commercial elements are Not applicable.
- **Time-bound:** Entry gates Months 0-5 (2026-10-08 to 2027-03-08).5 (start Month 0 = 2026-10-08), 90-day clock Months 6-9 (2027-04-08 to 2027-07-08), verdict scored within 5 days, final decision by Month 9.5 (2027-07-23). Any gate slipping over 2 weeks triggers a summit; no certification by Month 9 (2027-07-08) forces a Stop/re-scope decision.

## Dependencies

- Bilateral instrument signed by both governments
- Both contributions appropriated and domestic access authority enacted
- Participating sites selected as matched pairs with parity confirmed
- Inspectors approved and operator and vendor participation secured
- Provisional covered-equipment schedule adopted

## Resources Required

- Replicated tamper-evident ledger, attestation, evidence and secure communications systems
- Mirrored full-time national inspection and specialist units
- Joint neutral secure facility for ledger hosting, key custody and reading rooms
- Independent Exercise Authority, red teams and accredited examiner teams
- Independent auditors and bilateral legal implementation team

## Related Goals

- Bilateral authority and reciprocity gate
- Site eligibility and matched selection
- Live challenge exercises
- Discrepancy adjudication and suspension
- Possible Modify-directed rework or later phase (funding OPEN)

## Tags

- Arms control verification
- US-China
- Frontier computing
- Tamper-evident ledger
- Public-sector

## Risk Assessment and Mitigation Strategies


### Key Risks

- Entry gates slip, compressing the test and widening statistical uncertainty
- Asymmetric access or operator shielding undermines parity
- Thin exercise data makes the verdict ambiguous or contested
- Ledger divergence or key-custody failure blocks evidence
- Tranche delay or withheld funding by either country

### Diverse Risks

- Counterintelligence breach or IP exposure by inspectors
- Vendor refusal leaves equipment unverifiable (full fallback ladder cannot finish before entry)
- Evidence rule miscalibration overloads adjudication (about 15 cases per month planned)
- Exercises disrupt production
- Staffing shortfall or attrition in 24/7 mirrored shifts

### Mitigation Plans

- Entry task force with binding roadmap; parallel tracks; summit within 5 days of a gate slipping over 2 weeks; compression reserve USD 50-100M (estimate); re-scope rather than extend
- Pre-clock parity audit; exclude asymmetric pairs; fall back to 2 pairs; hard Stop on shielding
- Pre-register thresholds, lock before the clock, report intervals openly; default to Modify when intervals straddle thresholds
- Validate evidence rule on 100-200 historical events per site; rehearse key recovery; hourly digest exchange with alerts
- Synchronized tranches with 14-day escalation and 30-day Stop trigger; contingency draw triggers at 30%, 50% and 75%
- Compartmentalized inspectors, filtered evidence, 3-officer CI board; run exercises only in staging, spare, maintenance or expansion areas

## Stakeholder Analysis


### Primary Stakeholders

- US national co-chair and office
- Chinese national co-chair and office
- Mirrored inspection and technical units
- Independent Exercise Authority
- Ledger, cybersecurity and counterintelligence units

### Secondary Stakeholders

- Participating datacenter operators
- Critical equipment vendors and maintenance providers
- Independent auditors and third-country filter auditor
- Legislative oversight bodies of both countries
- Customs and logistics agencies

### Engagement Strategies

- Co-chairs: weekly dashboard, double-key decisions, emergency summit on gate slips
- Inspection and specialist units: regular briefings, rapid answers to information requests, rotation and debrief schedules
- Operators and vendors: written commitments, access baselines, home-government compensation, fallback options
- Auditors and filter auditor: monthly unclassified findings and milestone reports
- Legislatures and agencies: periodic declassified summaries and notice of significant scope or timeline changes

## Regulatory and Compliance Requirements


### Permits and Licenses

- Bilateral instrument and domestic access authority in each country
- Appropriation acts for each USD 2.5 billion contribution
- Inspector security clearances and site access approvals
- Export-control and data-handling authorizations for evidence and equipment inspection
- Host-country permits for the neutral facility (Geneva or Singapore; OPEN)

### Compliance Standards

- Double-key authorization with no casting vote
- Public financial management and envelope mapping (100% sampled)
- Classified-information and cybersecurity standards
- Operator confidentiality and evidence-preservation requirements
- Scope limits: monitored changes at participating declared sites only

### Regulatory Bodies

- Both governments' appropriations and audit authorities
- National security and counterintelligence agencies
- Export control and customs authorities
- Neutral host-country authorities
- Independent third-country auditors

### Compliance Actions

- Sign instrument and enact access authority before the clock
- Lock deadlock, impaired-confidence and suspension thresholds in the instrument
- Schedule monthly envelope reconciliation and independent audits
- Apply for neutral facility permits and clearances for all personnel
- Certify entry gate by Month 5.5 (2027-03-23) and publish verdict within 5 days