**Goal Statement:** Run a 90-day Phase One operational test (Months 9-12 = 2027-07-12 to 2027-10-12) of The Consortium, a US-China mechanism verifying declared-equipment changes at 4 matched sites, and deliver a Go/Modify/Stop verdict at Month 12.25 (2027-10-20), within the USD 5 billion 50/50 budget.

## SMART Criteria

- **Specific:** Verify arrivals, installations, removals, transfers, maintenance changes and decommissioning of declared equipment at 4 participating sites (2 matched US-China pairs), then issue a Go, Modify or Stop verdict. Scope excludes total capacity, workloads, model weights and hidden facilities.
- **Measurable:** Blind detection of at least 90% for each of 7 event types with at least 10 injections each (proposed threshold); identity confidence above 95% (provisional); unverifiable equipment at or below 3% per site; parity variance within 10%; ledger synchronization within 1 hour; zero production disruption.
- **Achievable:** Both leaders provide political backing and compulsion authority. USD 5 billion funds mirrored teams of about 350-500 staff (estimate). Entry conditions, not test work, are the main constraint and gate Phase One.
- **Relevant:** Gives both governments a hard-to-contest evidential basis on whether bilateral change verification is credible, serving national-security mission justification and fiscal accountability. Business framing is not applicable.
- **Time-bound:** Phase One clock targets Month 9 (2027-07-12) (estimate; range Months 6-12 = 2027-04-12 to 2027-10-12), runs Months 9-12 (2027-07-12 to 2027-10-12), with the verdict at Month 12.25 (2027-10-20). Entry certification outer limit is Month 12 (2027-10-12).

## Dependencies

- Signed bilateral instrument
- Appropriated contributions from both countries
- Enacted domestic access authority
- Selected participating sites
- Approved inspectors
- Secured operator and vendor participation
- Adopted provisional covered-equipment schedule

## Resources Required

- Replicated tamper-evident ledger, attestation and secure communications systems
- Cleared full-time mirrored inspection, technical, legal, CI, translation, audit, logistics and adjudication staff
- Secure facilities and at least 2 clean-room examination centers
- Controlled staging and bounded inspection zones at 4 sites
- Independent testing and red-team capability

## Related Goals

- Phase Two scope and funding decision (open, undefined)
- Confidential versioned covered-equipment schedule
- Reciprocal access parity accounting
- Hash-committed challenge exercise program

## Tags

- Arms Control Verification
- US-China
- Equipment Identity
- Tamper-evident Ledger
- Double-key Governance

## Risk Assessment and Mitigation Strategies


### Key Risks

- Entry conditions not all certified by Month 9 (2027-07-12); sunk cost USD 100-200M (estimate)
- Vendor refusal or attestation-key compromise leaves equipment unverifiable (10-40% estimate)
- Deadlock or manufactured incidents stall findings or force suspension
- Counterintelligence breach or IP leakage causes operator withdrawal
- Ledger divergence or filters stripping identity fields undermine evidence

### Diverse Risks

- Staffing shortfalls during surge and leave
- Parity disputes between non-identical sites
- Contingency exhaustion or funding asymmetry
- Legal challenges to compelling vendors (delay 2-4 months, estimate)
- Exit disposition witness backlog

### Mitigation Plans

- Weekly condition tracking, Month 7.5 (2027-05-27) principal go/no-go and USD 50M gate-readiness sub-account
- Vendor binding by Month 8 (2027-06-12); refusal ladder with clean-room centers and unverifiable fallback
- Fixed 5/8/13-day escalation, enumerated auto-suspension triggers and CHALLENGE-tag partition
- Compartmentation, 6-month tenure limits, CI unit and insider-threat red cell
- Hourly signed checkpoints, neutral digest custodian, filter-adequacy pre-test at Month 8.5 (2027-06-27) and staffing dry-run at Month 8 (2027-06-12)

## Stakeholder Analysis


### Primary Stakeholders

- US and Chinese national co-chairs
- Mirrored inspectorate and technical units
- Ledger and cybersecurity units
- Counterintelligence units
- Adjudication and technical referee panels

### Secondary Stakeholders

- Participating datacenter operators
- Equipment manufacturers, maintenance and logistics vendors
- National legislatures and finance authorities
- Independent auditor and neutral digest custodian
- Independent testers and calibration panel

### Engagement Strategies

- Weekly reports and prompt responses to co-chairs and mirrored units
- Operator liaisons, consent-status tracking and signed confidentiality terms
- Vendor binding with registry and clean-room options for refusers
- Milestone and compliance reports to appropriating bodies and auditor
- Advance exercise schedule notices without scenario details to operators

## Regulatory and Compliance Requirements


### Permits and Licenses

- Domestic access authority in each country
- Facility security clearances for ledger nodes and clean rooms
- Personnel security clearances for inspectors
- Licensed destruction and recycling facility authorizations
- Export-control and data-transfer authorizations for evidence handling

### Compliance Standards

- Bilateral instrument obligations
- Host-country datacenter and e-waste disposal law
- Counterintelligence and classified-information handling rules
- Appropriations and fiscal accountability rules
- Customs and shipment record requirements

### Regulatory Bodies

- US and Chinese legislative and finance authorities
- Host-country customs authorities
- National security and counterintelligence agencies
- Independent bilateral budget auditor
- Facility Security Review Panel

### Compliance Actions

- Complete legal review and domestic access enactment by Month 7.5 (2027-05-27)
- Certify entry conditions at a single gate at Month 9 (2027-07-12)
- Fix CNY conversion rule before appropriation release
- Run independent budget audits of each tranche release
- Log facility incidents in the ledger within 1 hour