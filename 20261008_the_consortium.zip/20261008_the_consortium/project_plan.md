**Goal Statement:** Establish The Consortium, a jointly governed US–China mechanism, and run a 90-day Phase One test (Month 6 = 2027-04-08 to Month 9 = 2027-07-08) verifying arrivals, installations, removals, transfers, maintenance changes and decommissioning of declared frontier-relevant computing equipment at 4 matched declared sites, ending in a Go/Modify/Stop decision at Month 10 (2027-08-08). Success covers only monitored changes at participating declared sites.

## SMART Criteria

- **Specific:** Verify declared-equipment changes at 4 participating declared datacenters (2 US, 2 China) using layered evidence and a replicated tamper-evident ledger, then issue a double-key Go, Modify or Stop decision. Excluded: total capacity estimates, workload or model-weight inspection, hidden-facility claims, foreign-hosted infrastructure, comprehensive AI governance.
- **Measurable:** Blind-challenge detection of at least 90% unreported arrivals, 85% substitutions, 80% record falsification (provisional, TBD); false positives <5%; parity within 20%; unverifiable equipment <5% per site; unresolved discrepancies <10% of events; zero unresolved ledger divergence >7 days (all proposed thresholds, validated in calibration).
- **Achievable:** Both leaders provide political backing and authority to compel participation. USD 5.0 billion (user constraint) is split 50/50 and fully allocated to envelopes. Scope is deliberately narrow. Trust, legal symmetry and willingness to expose technology are not assumed, so the design relies on bounded zones, mirrored teams and double-key governance.
- **Relevant:** Both governments view uncontrolled frontier AI as a threat to national security and political control. A credible verification mechanism provides mission justification and public value through auditable, reciprocal change verification. Revenue, investors, customers, ROI and market demand: Not applicable.
- **Time-bound:** Start ASAP at Month 0 (2026-10-08). Entry conditions certified by Month 6 (2027-04-08), outside the 90 days; Phase One runs Months 6-9 (2027-04-08 to 2027-07-08); final decision at Month 10 (2027-08-08). If certification is not reached by Month 9 (2027-07-08), co-chairs decide by double-key to extend or stop.

## Dependencies

- Bilateral instrument signed (Month 2 = 2026-12-08) and site selection ratified by both co-chairs (Month 2 = 2026-12-08)
- Appropriations secured and provisional covered-equipment schedule adopted (Month 3 = 2027-01-08), with domestic access authority enacted (Month 3.5 = 2027-01-23)
- Operator and vendor binding agreements in place (Month 4 = 2027-02-08), plus pre-qualified independent examiners and clean-room fallbacks
- All inspectors counterintelligence-approved (Month 5 = 2027-03-08) and ledger operational and stress-tested (Month 4 = 2027-02-08)
- Calibration on non-covered equipment (Months 4-5 = 2027-02-08 to 2027-03-08) and thresholds double-key locked (Month 5.5 = 2027-03-23), then certification of all 7 entry conditions (Month 6 = 2027-04-08)

## Resources Required

- Replicated tamper-evident ledger, attestation, evidence and secure communications systems (USD 1.25B envelope)
- Site preparation, controlled staging areas, marked inspection zones and operator compensation (USD 1.0B envelope)
- About 434 FTE full-time mirrored inspection, technical, legal, cybersecurity, counterintelligence, translation, audit, logistics and adjudication staff (estimate)
- Secure facilities, cybersecurity and counterintelligence capability (USD 0.75B envelope)
- Independent testing unit, red teams, accredited examiners and clean-room facilities (USD 0.5B envelope)

## Related Goals

- Extend verification to additional sites if Go is reached
- Refine the confidential, versioned covered-equipment schedule as hardware evolves
- Build reusable evidence standards for bilateral technology verification
- Strengthen reciprocal confidence between the two governments

## Tags

- bilateral verification
- frontier computing
- US-China
- national security
- ledger

## Risk Assessment and Mitigation Strategies


### Key Risks

- Entry-condition delays (inspector vetting, domestic authority) defer the clock; holding cost USD 50-100M per month (estimate)
- Ledger divergence or sync failure triggers impaired confidence or automatic suspension
- Vendor refusal leaves equipment unverifiable, failing a site
- IP or counterintelligence exposure causes consent withdrawal
- Contingency worst case about USD 515M if fallbacks coincide, exceeding the USD 500M reserve by about USD 15M (estimate)

### Diverse Risks

- Asymmetric access or a government shielding an operator collapses reciprocity
- Provisional thresholds mis-set, forcing a Modify outcome
- Exercises disrupting active computation or being perceived as biased
- Funding late beyond 45 days plus 30-day cure counts as withheld (Stop)
- Geopolitical deterioration reduces political will

### Mitigation Plans

- Weekly co-chair entry-conditions review from Month 0 (2026-10-08); strict gate with Month 9 (2027-07-08) backstop requiring double-key extend-or-stop decision; 18-month appropriation window
- Joint forensic panel (3-5 per country) issuing findings in 48 hours; shift-handover cross-signing; monthly failover tests
- Pre-bind top 8-12 vendors per site; 3-5 examiner labs per country and 2 clean-room facilities per geography by Month 4 (2027-02-08); day-10 ladder
- Narrow marked zones, audited operator redaction, three-tier infraction protocol, inspector rotation and continuous access-log audit
- Calibrate on non-covered equipment, lock thresholds by Month 5.5 (2027-03-23), cap exercises at 2 sessions per site per month in staging, spare, maintenance or expansion areas; contingency released by double-key, fast lane up to USD 50M

## Stakeholder Analysis


### Primary Stakeholders

- Equal US and Chinese national co-chairs
- Mirrored national inspection and technical units
- Legal, adjudication and audit units
- Cybersecurity, counterintelligence and ledger operations teams
- Independent testing unit and red teams

### Secondary Stakeholders

- Participating datacenter operators
- Equipment manufacturers, maintenance providers and logistics companies
- Treasury and appropriations authorities in both countries
- Accredited independent examiners, recyclers and destruction facilities
- Domestic legislatures and regulators

### Engagement Strategies

- Co-chairs: weekly entry-gate reviews, double-key decisions, deadlock escalation to a neutral referee panel after 7 days
- Primary units: shift-level reporting, monthly progress reports, prompt answers to information requests
- Operators and vendors: binding agreements, compensation via own government, rapid dispute channel
- Treasuries: milestone-based tranche reporting and monthly fiscal accountability reports
- Regulators and legislatures: notification at key milestones and of significant scope or timeline changes

## Regulatory and Compliance Requirements


### Permits and Licenses

- Bilateral instrument ratification and domestic access authority in each country
- Inspector security approvals and site access authorizations
- Export-control and technology-transfer authorizations for evidence handling
- Hazardous e-waste handling permits for destruction and recycling partners

### Compliance Standards

- Domestic public finance and appropriations law
- Information security and classified-information handling rules
- Environmental and e-waste regulations in each jurisdiction
- Data protection rules for operator and customer data

### Regulatory Bodies

- US and Chinese treasury and appropriations authorities
- Domestic security and counterintelligence agencies
- Export-control authorities
- Environmental regulators (e.g., US EPA, China Ministry of Ecology and Environment)
- Independent auditors

### Compliance Actions

- Decompose domestic authority into specific acts per country and track them weekly from Month 0 (2026-10-08)
- Enact access authority by Month 3.5 (2027-01-23) and certify before the clock starts
- Schedule independent audits of funding timeliness and spending against envelopes
- Coordinate with environmental regulators on witnessed destruction and disposition
- Run boundary and conduct audits against the three-tier infraction protocol