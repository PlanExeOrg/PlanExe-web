Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 11 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 8 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is a sovereign bilateral national-security verification program centered on physical inspections, cryptographic ledger systems, personnel-staffed monitoring, and reciprocal challenge exercises. All load-bearing mechanisms—equipment tracking, evidence preservation, staffing, and information barriers—operate within known physics; no mechanism claims faster-than-light signaling, violation of conservation laws, or non-physical causation of real-world outcomes.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination (bilateral double-key governance + trilayered equipment identity + real-time ledger + 24/7 mirrored inspectors + blind detection exercises with sealed scoring) without independent evidence at comparable bilateral scale. Resident mirrored inspectors 24/7 at counterpart sites, operator-controlled redaction gateways, and hourly cryptographic ledger checkpoints are individually documented but untested together. New START and IAEA precedents cover bilateral inspection and unique identifiers separately; CTBTO and OPCW conducted mock exercises separately. No precedent demonstrates this **system combination** works. Filter-adequacy pre-test (Month 8.5 = 2027-06-27) and ledger stress-test (Month 8 = 2027-06-12) are pilots but use staged equipment and synthetic events, not operational data. Failure is existential: if ledger divergence, identity confidence collapse, or deadlock paralysis occur, the Go/Modify/Stop verdict loses credibility and either government can claim rigging, terminating the program."

**Mitigation**: Establish bilateral Empirical Validation Panel by Month 2 (2026-12-12). Define two binding NO-GO gates before Phase One starts Month 9 (2027-07-12): (1) Technical/Operational Validity Gate: all pilots (filter adequacy >=85%, ledger latency <=1 hour, staffing >=80%, unverifiable <=3%, legal litigation risk <=4 months) must pass by Month 8.5 (2027-06-27); halt Phase One if any pilot falls short. (2) Legal/Compliance Clearance Gate: domestic access authority and vendor-compulsion mechanisms must be enacted without litigation risk >4 weeks by Month 7.5 (2027-05-27). Document all pilot results (filter-adequacy detection rate, ledger divergence false-positive rate, staffing shortfall, vendor unverifiable count, legal challenge status) in ledger by Month 8.75 (2027-07-05). Publish a Joint Empirical Readiness Certification signed by both co-chairs at Month 9 (2027-07-12) attesting that validation tracks are complete and Phase One evidence base is credible, or formally defer/stop.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because 15 named strategic decision levers are defined with mechanism-of-action descriptions and assigned owners, but three critical gaps undermine clarity: (1) Provisional thresholds (95% identity confidence, 3% unverifiable, 90% detection, 1-hour ledger sync) lack documented validation methods or contingency rules if empirical data diverges >10%; (2) Covered-Equipment Schedule and Opening Inventory Baseline are described but lack named single owners with explicit decision authority; (3) The causal chain from blind-exercise detection → threshold freeze → verdict is stated procedurally but not explicitly defined with contingency paths if detection falls in the 85–90% ambiguous band at the Month 8.5 (2027-06-27) pre-test. Strategic intent is clear but operational mechanism-of-action is incomplete.

**Mitigation**: Bilateral Strategic Clarity Working Group (one senior lead per country, funded from USD 250M legal/audit envelope): By Month 6 (2027-04-12), produce one-pager summaries for each of the 15 strategic decisions documenting: mechanism-of-action (inputs→process→customer value), single named owner with decision authority, success metric and validation method, and contingency rule if empirical data diverges >10% from provisional thresholds. Lock all mechanism-of-action and contingency rules in the bilateral instrument signed by Month 7 (2027-05-12); any threshold change post-signing requires principal double-key re-authorization within 5 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because three critical second-order cascades are inadequately mitigated: (1) entry-gate sunk-cost burn (USD 100–200M estimate) consumes free contingency before Phase One, eliminating surge buffer; (2) vendor-refusal concentration creates 10–40% unverifiable risk with untested fallback centers and insufficient timeline for recovery; (3) false-positive cascade (misclassified CHALLENGE events) lacks automated tag detection and compressed escalation path. Cascades are documented in the risk register but lack binding principal escalation timers, contingency allocation, or technical enforcement (e.g., ledger system rules for CHALLENGE partition). Consequence: sites fail automatically under enumerated suspension triggers despite sound underlying capability; Go verdict is impossible if material unverifiable equipment or manufactured incidents consume the operational window.

**Mitigation**: Risk Registry Owner: By Month 2 (2026-12-12), expand the Risk Register to explicitly map nine second-order cascades (entry-gate → contingency exhaustion, vendor refusal → unverifiable cascade, false-positive → operational halt, parity dispute → suspension, ledger divergence → forensic recovery, operator withdrawal → site failure, staffing shortfall → curtailment, legal litigation → timeline compression, political drift → verdict rejection) with quantified contingency allocation (USD 75–100M reserve for entry-gate recovery, USD 50–80M for vendor mitigation, USD 30–50M for false-positive investigation), binding decision gates (principal checkpoint Month 7.5 = 2027-05-27 with automatic tranche hold if slippage exceeds 2 weeks), and technical enforcement rules (automated CHALLENGE-tag detection in ledger system; Incident Command Center 2-hour escalation SLA; misclassification drill by Month 8.75 = 2027-07-05).


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a binding instrument-signed escalation authority (principal go/no-go decision rule locked before Month 7, 2027-05-12 signature), no authoritative lead-time matrix per entry condition per jurisdiction, and no buffer between entry certification (Month 9, 2027-07-12) and Phase One start. Entry-gate stall is documented as the highest-probability failure (6-12 month typical bilateral negotiation), yet gate-slippage triggers no automatic contingency-release rule or phase delay. Attestation-key validation and filter-adequacy testing occur at Month 8.5 (2027-06-27), only 2 weeks before Phase One, leaving insufficient time for design remediation if thresholds are missed. Vendor recovery path (clean-room centers) is untested by Month 9 (2027-07-12) start. Staffing vetting completion (Month 2, 2026-12-12) assumes 2-3 month CI cycles on 350-500 candidates without documented rejection-rate contingency.

**Mitigation**: Bilateral Chief Schedule Officer: Embed binding escalation language in the bilateral instrument signed by Month 7 (2027-05-12) specifying automatic principal go/no-go decision within 48 hours if any entry condition slips >14 days past its deadline (instrument Month 7 = 2027-05-12, access authority Month 7.5 = 2027-05-27, vendor binding Month 8 = 2027-06-12, single gate Month 9 = 2027-07-12, all 2027). Document authoritative lead-time matrix per condition per jurisdiction by Month 1 (2026-11-12) using precedent (New START, IAEA, OPCW) and bilateral legal team input. Allocate 2-week buffer after filter-adequacy pre-test (Month 8.5, 2027-06-27) before Phase One operational start; halt entry certification if detection falls below 85% and defer Phase One to Month 11 (2027-09-12) if filter redesign requires >7 days of bilateral review. Lock all seven conditions certified simultaneously at Month 9 (2027-07-12) 17:00 UTC or invoke principal stop/defer decision within 24 hours without extending the gate beyond Month 12 (2027-10-12).


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because committed funding sources lack evidence of signature or legislative approval—appropriations are a mandatory entry condition but no LOI, budget-committee schedule, or government commitment document is presented. Tranches 3–4 are contingent on a non-Stop verdict without defined Phase Two scope, and CNY conversion rule for compensation is undocumented. Tranche 1 (USD 1.25B for Months 9–12 = 2027-07-12 to 2027-10-12) and parity governance (±10% tolerance, impaired-confidence review at >20% divergence) are procedurally sound. Contingency cliff risk (entry-gate sunk costs USD 100–200M estimate absorbed in envelopes, not contingency) erodes surge buffer before Phase One begins. Material gap: no evidence either government has committed appropriations to the legislative calendar or binding schedule.

**Mitigation**: Bilateral Finance Authority Lead: By Month 1 (2026-11-12), produce a signed bilateral Funding Commitment Charter documenting each government's appropriations schedule, legislative approval timeline, and binding authorization for USD 2.5B tranche release; publish commitment status (pending/scheduled/approved) in monthly KPI dashboard. Lock CNY conversion rule and compensation ceilings by Month 6 (2027-04-12) in bilateral instrument. Define Phase Two funding criteria (Go triggers USD 2.5B authorization for 8–12 sites; Modify triggers USD 500M–1.0B corrective trials; Stop closes program) by Month 11 (2027-09-12) before verdict, removing post-verdict funding ambiguity.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan allocates USD 5 billion across seven envelopes (ledger 1.25B, site prep 1B, personnel 750M, facilities 750M, testing 500M, legal/audit 250M, contingency 500M) with identified exposures (entry-gate sunk cost USD 100–200M estimate, vendor fallback USD 30–50M estimate, CI/audit USD 20–30M estimate) consuming up to 60% of the USD 450M free contingency, yet provides no vendor quotes, ≥3 comparable programs' actual costs, or cost-per-unit/per-m² benchmarks to validate the figure. Filter-adequacy and ledger stress-tests (Months 8–8.5 = 2027-06-12 to 2027-06-27) are scheduled but are simulations, not market validation. Contingency adequacy against identified exposures is unproven.

**Mitigation**: Bilateral Budget Validation Working Group: By Month 6 (2027-04-12), obtain ≥3 comparable bilateral program cost actuals (New START, IAEA safeguards expansion, OPCW verification upgrade) for staffing, facility security, cryptographic systems and testing; solicit competitive quotes from ≥2 vendors each for clean-room centers, secure ledger nodes, and equipment-examination services; normalize all costs by site-pair, per inspector-day, and per injected scenario; validate contingency allocation (USD 450M free) is adequate by recomputing exposures against actual quotes; adjust budget or de-scope by Month 7.5 (2027-05-27) principal checkpoint.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan presents multiple key projections (detection ≥90%, identity confidence >95%, unverifiable ≤3%, ledger sync ≤1 hour, entry gate Month 9 = 2027-07-12) as single-point thresholds without ranges, confidence intervals, or documented best/worst-case scenarios. Detection rate and staffing have stated buffers (≥85% halt threshold, 80% manning minimum) but lack sensitivity analysis. Contingency procedures (escalation timers, suspension triggers) exist but are not modeled as alternative outcome paths. Entry-gate slip is documented as 2-4 months typical but no binding recovery scenario is quantified.

**Mitigation**: Bilateral Projections and Sensitivities Working Group (one analyst per country, funded from USD 250M legal/audit envelope): By Month 7 (2027-05-12), produce three scenario models (conservative, base, optimistic) for each critical projection (detection rate, identity confidence, staffing headcount, entry-gate slip, ledger latency, parity variance); publish sensitivity tables and alternative-outcome decision trees in bilateral instrument Annex; lock base-case thresholds and define automatic Modify/Stop triggers if projections diverge >10% from base case during Phase One calibration exercises.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because build-critical components (ledger, attestation, filtering, exercises, escalation, compartmentation) have isolated technical specifications and acceptance tests planned (filter-adequacy pre-test Month 8.5 = 2027-06-27, ledger stress-test Month 8 = 2027-06-12, misclassification drill Month 8.75 = 2027-07-05), but lack formal interface contracts between layers, integrated end-to-end acceptance test sequence, and named integration lead. No unified integration plan exists showing how all seven components interact during Phase One operations or how component failures cascade. Bilateral instrument locks procedures and individual KPIs (1-hour ledger sync, 4-hour divergence detection, 2-hour escalation, 85% filter detection), but system-level acceptance gates are incomplete and integration-test coverage is partial.

**Mitigation**: Bilateral Chief Systems Engineer (one per country, appointed by Month 1 = 2026-11-12): Design formal interface contracts and integration test plan by Month 7 (2027-05-12) covering ledger-evidence-gateway interaction, identity-anchor-filter enforcement, exercise-deadlock-escalation workflow, and compartmentation-detection coupling. Schedule end-to-end integration test for Month 8.5 (2027-06-27) under 10x event load with injected failures; halt Phase One if integration test fails to validate all escalation timers within 15% slack.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because multiple critical legal, operational and financial claims lack verifiable artifacts before the 90-day clock starts. Specific examples: (1) "Signed bilateral instrument" is listed as mandatory entry condition #1, yet no draft, negotiation timeline or principal-signature commitment document is cited—only reference to "Month 7 (2027-05-12) binding signature deadline" without evidence that this date is agreed or achievable. (2) "Domestic legal authority to compel operators and vendors" is asserted as a gate condition but no country's legislative bill, OLC opinion, or enacted statute is presented; pre-assessment notes "2–4 month litigation risk (estimate)" without naming any actual litigation or legal barrier. (3) "Appropriations of USD 2.5 billion per country" is stated but no appropriations bill, budget committee hearing schedule, or legislative commitment is documented. (4) "Bilateral accredited examiner" pools are assumed operational by Month 9 (2027-07-12) with no identification of who the examiners are, which bilateral accreditation body exists, or any roster. (5) "Bilateral Counterintelligence Unit" staffing assumption of "≥4 senior CI specialists per country" lacks named personnel, clearance status, or team charter. Without these verifiable artifacts, the plan cannot prove that entry conditions can actually be certified by Month 9 (2027-07-12), making the entire Phase One timeline a contingency on unvalidated assumptions."

**Mitigation**: Legal Implementation and Bilateral Instrument Lead: Produce a bilateral Evidence Artifact Inventory by Month 2 (2026-12-12) listing every critical claim (signed instrument, domestic legal authority per jurisdiction, appropriations commitment, accredited examiner rosters, CI unit staffing, operator confidentiality agreements, vendor binding certifications) with the verifiable artifact required, current status (draft/in-progress/complete), responsible party, completion deadline, and escalation rule if deadline is missed. Publish the inventory in the tamper-evident ledger and link each claim to its supporting document (instrument draft, legislative bill text, budget authority letter, clearance certificates, signed contracts). Escalate any artifact >14 days behind deadline to principals within 48 hours for prioritization or scope adjustment.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because three major Go-decision deliverables (blind-detection rate ≥90% per event type; identity confidence >95% per unit; reciprocal-access parity ≤10% variance) are mentioned in the plan as verdict criteria without defining: measurement unit, sampling procedure, confidence interval, or dispute-resolution rule. Detection thresholds reference a "proposed threshold" to be validated at Month 8.5 (2027-06-27), leaving uncertainty whether provisional figures are binding. Identity-confidence calculation ("≥2 independent layers must agree") lacks a numeric score formula. Parity-variance metric lacks definition of what constitutes the denominator (approval rate per site? per event type? per week?). Without SMART criteria, neither government can prove objectively whether the Go threshold is met, and the verdict becomes contestable as political judgment rather than evidence-based.

**Mitigation**: Bilateral Verdict Acceptance Criteria Working Group: By Month 8 (2027-06-12), publish a Verdict Specification document defining SMART acceptance criteria for each of the three Go deliverables: (1) Detection Rate KPI: unit = percentage of injected scenarios correctly detected per event type; measurement = blind inspectors' yes/no responses scored against known-truth scenarios; sampling = all ≥10 injections per event type (70 total); acceptance = ≥90% mean across all 7 types with no type <85% (proposed threshold); confidence interval = 95% binomial (TBD); dispute rule = if country scores diverge >5 points, convene technical referees for fact statement within 3 days. (2) Identity Confidence KPI: unit = percentage of units passing the ≥2-layer agreement rule; measurement = for each intake unit, cryptographic attestation + customs record + physical inspection scored (pass/fail per layer); acceptance = ≥95% units with ≥2 layers agreeing (proposed threshold); sampling = all equipment at intake; dispute rule = any unit with 1-layer agreement escalates to referees for dual-signed adjudication. (3) Parity Variance KPI: unit = percentage-point absolute difference in access-approval rate; measurement = (approval rate Site A) − (approval rate Site B) normalized by equipment count; sampling = weekly cumulative rolling average; acceptance = ≤10% variance for final 4 weeks of Phase One (proposed threshold); confidence interval and dispute rule same as Detection Rate. Lock all SMART criteria in bilateral instrument Annex by Month 9 (2027-07-12); any threshold change after Month 10.5 (2027-08-27) requires principal double-key reauthorization within 5 days and is recorded in ledger as an audit finding.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Neutral-Party Digest Escrow Custodian (USD 20–30M estimate) and Bilateral Insider-Threat Red Cell do not demonstrably support the two core Phase One goals: (1) detect declared-equipment changes via layered evidence, and (2) measure reciprocal access parity. The custodian provides forensic recovery if ledger nodes are compromised—a defensive control, not a detection mechanism. The red cell attempts to compromise inspectors—a security test, not equipment verification. Both add cost and operational complexity (escrow facility access protocols, red-team scenario design, staff vetting overhead) without directly contributing to the Go/Modify/Stop verdict, which depends on blind-detection rates and parity metrics, not ledger-node resilience or insider-threat testing. Recommend: (1) Produce a one-page benefit case for each feature justifying its inclusion, identifying which Go-decision KPI or binding requirement it addresses, quantifying its cost, and assigning an owner. (2) If no binding requirement or demonstrable detection benefit is documented, move both features to Phase Two backlog.

**Mitigation**: Project Controls Owner: Conduct a Feature Benefit-Case Review within 30 days. For each flagged feature (Neutral-Party Digest Escrow Custodian, Bilateral Insider-Threat Red Cell), produce a one-page benefit case including: (1) which Phase One KPI or Go-decision criterion it directly supports (e.g., "supports ledger-synchronization KPI ≤1 hour" or "enables detection of ≥90%"), (2) estimated cost and budget source, (3) owner and implementation date, (4) contingency if feature is deferred. If no direct KPI link is documented, move feature to Phase Two backlog and reallocate USD 30–50M (estimate) to core detection or parity-measurement capabilities.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Bilateral Cryptographic Ledger Systems Architect is a unicorn role: this single specialist must design, deploy, and operate a replicated tamper-evident ledger synchronized across national boundaries with hourly signed checkpoints, cryptographic key-derivation ceremonies, divergence detection within 4 hours, and forensic recovery within 24 hours—all under mutual distrust without a neutral third party as arbiter. The role combines distributed-ledger consistency theory, applied cryptography, bilateral ceremony protocol, and operational resilience at a scale and complexity with very few real-world precedents (New START and IAEA safeguards operate single-source ledgers, not mirrored bilateral copies). Ledger failure is existential: divergence >5% triggers automatic site suspension; undetected divergence erodes verdict credibility; key-custody compromise invalidates evidence integrity. The plan explicitly names this role but provides no candidate roster, vetting criteria, or recruitment timeline. Finding 2-4 qualified architects (one per country minimum, plus backup) in the 6-month entry-gate window (Months 0–6 = 2026-10-12 to 2027-04-12) is unlikely without parallel recruitment starting immediately.

**Mitigation**: Bilateral Chief Architect Search Team: Convene by Month 0.5 (2026-10-27) with one senior technical recruiter per country and one subject-matter expert from national cryptographic or intelligence agencies. Identify ≥3 candidate Ledger Architects per country (estimated 6–12 globally with active bilateral cryptography experience) by Month 2 (2026-12-12); conduct technical validation interviews covering hash-chain design, Byzantine fault tolerance, key-custody protocols, and bilateral ceremony expertise by Month 3 (2027-01-12); extend offers and begin vetting by Month 4 (2027-02-12); confirm deployment by Month 6 (2027-04-12), 3 months before Phase One start.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because legal feasibility is functionally unmapped: the plan names controlling regimes (bilateral instrument, domestic access authority, vendor-compulsion statutes) and identifies litigation exposure (2–4 month delay estimate per jurisdiction on vendor-compulsion scope), but provides no draft instrument language, no legislative bill text, no Office of Legal Counsel opinion validating federal authority to compel private vendors, no clarification of Chinese state-enterprise exemptions, no vendor binding legal memoranda, and no binding bilateral legal negotiation schedule. Entry-gate legal work is the critical path; slippage cascades to all seven entry conditions. Pre-assessment flagged litigation and reauthorization risk >4 weeks per jurisdiction, yet plan provides no mitigation timetable, no fallback scope-reduction pathway, and no principal escalation rule if legal barriers persist past Month 6 (2027-04-12). Without mapped legal artifacts, bilateral instrument signature, and domestic legal authority both certified by Month 7 (2027-05-12), Phase One cannot start, and the entire USD 5B program is in jeopardy.

**Mitigation**: Legal Implementation and Bilateral Instrument Lead: Establish bilateral legal working group by Month 0.5 (2026-10-27) with senior legal counsel from both countries' foreign offices and justice departments. Produce by Month 1 (2026-11-12): (1) Annotated draft bilateral instrument with binding escalation language, deadlock procedures, auto-suspension triggers, and double-key authorization rules locked in place of placeholders; (2) Memorandum identifying all domestic legal authorities required (US: executive authority, Congressional approval mechanism if treaty vs. executive agreement distinction applies; China: State Council directive or equivalent; both: vendor-compulsion authority), with realistic lead times per jurisdiction and documented precedent. By Month 4 (2027-02-12), escalate any legal barrier projecting >4 weeks delay to principals for decision on expedited legislative track, supplementary appropriation, or scope reduction by Month 6 (2027-04-12). Signature deadline: Month 7 (2027-05-12). NO-GO trigger: if bilateral instrument is unsigned or domestic access authority is unenacted by Month 7.5 (2027-05-27), invoke principal stop/defer decision within 48 hours per binding escalation rule.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies operational sustainability as a design criterion (continuous operations beyond Phase One require sustained funding, personnel, technology refresh, and maintenance capability) but defers all Phase Two and post-verdict sustainability planning to an undefined future decision point. The plan explicitly states 'Phase Two scope and funding authorization remain undefined' in the budget section and treats Phase Two as an open contingency with no agreed pathway. This creates three material sustainability gaps: (1) Personnel: 350–500 cleared full-time staff (estimated) are recruited and vetted for a 90-day test; no retention strategy, post-test redeployment plan, or successor-regime transition procedure is documented, risking loss of institutional knowledge and trained capacity if Phase Two is delayed >6 months. (2) Technology: the bilateral ledger, cryptographic key-custody systems, and attestation-validation infrastructure must be maintained post-verdict; no technology-refresh roadmap or vendor-continuity plan exists, creating obsolescence risk if component manufacturers withdraw support or cryptographic standards shift. (3) Funding: tranches 3–4 (USD 1.25B combined) release only after a non-Stop verdict and new bilateral authorization; if either government delays Phase Two appropriation, the built infrastructure (ledger nodes, secure facilities, clean rooms, USD 30–50M estimate) becomes dormant and depreciates, generating sunk-cost pressure to accelerate Phase Two or abandon capability. Operational sustainability is feasible for Phase One (90-day funded window with full staffing and contingency) but depends entirely on a Phase Two decision that is not pre-negotiated.

**Mitigation**: Phase Two Decision Authority Lead: Establish a Bilateral Phase Two Framework by Month 11 (2027-09-12), before Phase One verdict is finalized, documenting objective Go/Modify/Stop acceptance criteria and corresponding Phase Two scope and funding pathways. Specifically: (1) If Go (bilateral detection ≥90%, parity variance ≤10% at 4 sites), authorization for Phase Two Expansion to 8–12 declared sites (estimated USD 2.5B additional) with continuous operation start Month 13 (2027-11-12); (2) If Modify (detection 80–89% or correctable cause identified), authorization for Phase Two Corrective Trials (estimated USD 500M–1.0B) with 12-month remediation cycle ending Month 24 (2028-10-12); (3) If Stop (asymmetric access, material unverifiable equipment, or unresolved divergence), program closure with asset handoff to national governments or research institutions. Document retention pathways for cleared personnel (re-deploy to allied intelligence partnerships, academic research, or standby roster), technology-refresh roadmap (cryptographic standards updates every 3 years, ledger-node operating-system patches monthly, component manufacturer continuity tracking), and facility stewardship (secure ledger nodes transitioned to national custody, clean-room centers repurposed or maintained by participating operators). Publish the Phase Two Framework in the KPI dashboard at Month 11 (2027-09-12) so bilateral principals can authorize funding tranches 3–4 within 30 days of the Phase One verdict and prevent >3-month capability drift.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan designates four declared sites (2 US in Northern Virginia, 2 China in Beijing-Hebei or Shanghai region) as inspection venues but provides no evidence that zoning/land-use permits, occupancy/egress certificates, fire-load capacity validation, structural-limit engineering reviews, or noise-compliance assessments have been conducted or approved by host authorities. The plan states "site selection is an entry condition decided by both governments before the 90-day clock starts" (Month 9, 2027-07-12), yet reserves binding facility hardening and security certification to Month 2 (2026-12-12)—a 7-month window during which actual sites remain open questions. Site equivalence baseline data collection (Month 1, 2026-11-12) and site-pairing rationale (Month 2, 2026-12-12) are scheduled, but no fatal-flaw screen with local building/zoning authorities is documented. Viable alternatives (smaller declared-equipment sets, subset-of-pairs start, phased-site expansion) are mentioned but not operationalized. Risk: if any selected site fails zoning or fire-load validation post-selection, site swap or scope reduction cascades into entry-gate delay or Phase One compression.

**Mitigation**: Bilateral Chief Facilities Officer (appointed Month 0.5 = 2026-10-27): Conduct a fatal-flaw zoning and occupancy screen with local building authorities at all candidate sites by Month 1.5 (2026-11-27). Screen scope: zoning designation and permitted uses (ensure foreign governmental/diplomatic/verification uses are permitted or require variance); occupancy load classification for inspection and evidence-handling spaces; fire-code egress and life-safety requirements for 24/7 continuous operations; structural adequacy for secure ledger-node equipment (seismic resilience, load capacity); noise limits on facility operations and contingency generators. Document all findings in a Site Constraint Matrix by Month 2 (2026-12-12) and escalate any non-waivable barrier (e.g., zoning prohibition on foreign government operations, fire-code egress insufficient for 24/7 use) to principals within 48 hours with named fallback sites. Define four NO-GO thresholds tied to constraint outcomes by Month 2.5 (2026-12-27) and lock in bilateral instrument: (1) zoning variance unachievable by Month 7 (2027-05-12); (2) fire-load shortfall >10% of required capacity; (3) structural inadequacy for hardened-facility equipment; (4) noise limits violated under continuous-operations scenario. If any NO-GO threshold is crossed, invoke site-swap or scope-reduction decision within 5 days, documented in ledger.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan designates 4 matched sites (2 US, 2 China) for Phase One but lacks pre-Phase-One validation of: (1) site-equivalence defensibility and functional matching (staging, spare-inventory, maintenance, expansion areas); (2) operator and vendor binding commitment per site with participation certificates; (3) customs-access latency and shipment-record availability per location; (4) bilateral accredited-examiner rosters and clean-room operational readiness (2 centers) by Month 9 (2027-07-12); (5) attestation-key validation status for critical vendors (>5% of equipment) at each site. Without pre-validated site data and tested logistics chains, Phase One operations cannot establish reciprocal-access parity accounting or equipment identity chains from factory through intake, creating material single points of failure if logistics or customs access are asymmetric.

**Mitigation**: Bilateral Site and Logistics Validation Lead: By Month 6 (2027-04-12), complete site-equivalence baseline data collection; by Month 7 (2027-05-12), validate site-pairing defensibility and lock site selections; by Month 8 (2027-06-12), operationalize examiner rosters, certify clean-room readiness, conduct vendor-shipment dry-runs measuring customs-access SLA and attestation-key validation latency; publish site-readiness certification in KPI dashboard by Month 9 (2027-07-12).


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because Finance Authority (incentivized by fiscal discipline and parity accounting) and Bilateral Co-Chairs (incentivized by operational readiness and evidence credibility) have unstated conflicting incentives. Finance wants to defer spending and preserve contingency (gate-readiness USD 50M accessible only at certification, tranches 3-4 held until non-Stop verdict). Co-Chairs want to front-load entry-gate spending (estimated USD 100-200M for vetting, rehearsals, facility hardening) to de-risk Phase One operationally. No shared measurable objective (OKR) aligns both parties' spending decisions or resolves who decides if a readiness gap justifies further expense or forces scope reduction. Without alignment, budget disputes will escalate to principals repeatedly, delaying execution.

**Mitigation**: Bilateral Finance and Operational Leadership Joint OKR Panel: By Month 1 (2026-11-12), co-chairs and budget authority agree on a shared OKR: "Achieve Phase One operational readiness (staffing >=80%, rehearsals passed, entry conditions certified) within USD 5B cap and 50/50 parity ±10% by Month 9 (2027-07-12)." Define four quarterly spend milestones (Months 1, 3, 6, 9 = 2026-11-12, 2027-01-12, 2027-04-12, 2027-07-12) with agreed spending profiles per envelope; any monthly divergence >15% triggers joint review (not unilateral freeze) within 48 hours; contingency draws >USD 10M require joint approval; shared bonus/penalty if both OKRs are met (retention/promotion) or missed (salary reduction/formal review).


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan establishes KPIs (detection rate, parity variance, ledger latency, unverifiable count, false-positive incidents, funding timeliness), review cadence (weekly entry conditions, monthly KPIs, escalation timers 5/8/13 days), and enumerated auto-suspension thresholds, but lacks a single named feedback-loop owner, a formal change-control process for post-start threshold adjustments, and documented decision authority for escalation routing. Escalation procedures exist on paper but operational rehearsal and audit trails for all changes are unspecified. Monthly KPI dashboard and steering-committee tracking provide visibility, but who owns the escalation trigger, change-control log, and decision audit is ambiguous.

**Mitigation**: Bilateral Feedback Loop Operator and Change Control Board: Establish by Month 7 (2027-05-12). Designate Incident Command Center as feedback-loop owner with documented decision authority for escalation routing, change-control log, and monthly audit. Publish Feedback Loop Charter locking escalation procedures, threshold-change approval rules, and audit procedures by Month 9 (2027-07-12) start.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan documents nine individual high-priority risks (entry-gate stall, vendor-refusal cascade, false-positive cascade, ledger divergence, staffing shortfall, legal litigation, parity disputes, operator withdrawal, false verdict) but lacks a bow-tie, fault-tree, or cross-impact analysis showing how two or more risks cascade simultaneously into multi-domain failures. Concrete example: vendor refusal at Month 8 (2027-06-12) triggers unverifiable-threshold suspension by Month 9.25 (2027-07-20), which collides with a misclassified CHALLENGE event during opening-inventory baseline (Days 1–5, Months 9–9.25 = 2027-07-12 to 2027-07-27), creating a second suspension and aging discrepancies to the 15-day Stop criterion—all within 2 weeks of Phase One start, before scaled exercises can commence. This cascade is possible but not explicitly mapped in the plan, leaving no pre-Phase-One NO-GO gate to prevent simultaneous failures.

**Mitigation**: Bilateral Risk and Interdependency Lead: Develop a comprehensive Interdependency Map and Cross-Impact Heatmap by Month 2 (2026-12-12). Deliverables: (1) Bow-tie or fault-tree diagram showing the nine named high-priority risks as nodes, with causal arrows indicating which failures cascade into which others (e.g., vendor refusal → unverifiable threshold breach → auto-suspension); (2) Combined KPI heatmap identifying which risk-combination thresholds trigger automatic principal escalation or Phase One NO-GO gate before Month 9 (2027-07-12) clock start (e.g., vendor refusal + staffing shortfall + legal litigation delay = automatic defer decision); (3) Shared contingency reserve allocation (USD 75–100M estimate) held in escrow for cascade remediation, released only if 2+ high-priority risks exceed thresholds simultaneously. Embed the interdependency map and NO-GO thresholds in the bilateral instrument by Month 7 (2027-05-12); activate automatic principal escalation at Day 5 of any identified cascade (e.g., detect vendor refusal + CHALLENGE misclassification on Day 5, trigger principal decision by Day 7).