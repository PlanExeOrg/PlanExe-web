**Verdict:** 🟢 USABLE

**Rationale:** The prompt describes a concrete, highly detailed public-sector verification program. It gives a budget with allocations, a 90-day phase, governance rules, staffing logic, workstreams, KPIs and decision criteria. The formatting and style instructions are legitimate planning constraints, not injection attempts.