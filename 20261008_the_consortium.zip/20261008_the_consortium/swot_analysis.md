
## Strengths 👍💪🦾
- Layered evidence with no decisive source: Attestation, customs records, physical inspection and witnessed movement must agree across at least two layers. This resists single-point forgery and gives a verdict that is hard for either government to contest.
- Narrow, well-bounded mission: Only declared-equipment changes at about 4 matched sites are verified, with explicit exclusions (no total-capacity estimate, no workload or weight inspection). The limited claim keeps the technical problem tractable and the conclusions defensible.
- Governance built for distrust: Double-key authorization, no casting vote, enumerated suspension triggers and a CHALLENGE-tag partition make obstruction and manufactured incidents visible and bounded. Deadlock timers (5/8/13 days) convert disagreement into a recorded process.
- Empirical decision basis: Hash-committed blind exercises (at least 10 injections across 7 event types) with thresholds frozen before scoring turn the Go/Modify/Stop verdict into measured evidence rather than political judgment.

## Weaknesses 👎😱🪫⚠️
- Attestation concentration: Identity is anchored on vendor-issued attestation, so key compromise, forgery or vendor refusal can make a large share of units unverifiable (10-40%, estimate). Corroborating layers may not compensate when the counterpart disputes their origin.
- Filtering can blind detection: Operator-run redaction gateways have an incentive to strip fields, and the counterpart audits rules but not inputs. Filter adequacy is untested until the pre-test at Month 8.5 (2027-06-27), so substitution may pass undetected.
- Many thresholds are unvalidated: Figures such as 95% identity confidence, 3% unverifiable and 90% detection are proposed thresholds with no empirical grounding. Pre-registration may encode guesses that force an unwarranted Modify or hide real weakness.
- Compartmentation versus context: Strict compartmentation and tenure limits protect hosts but fragment the site knowledge inspectors need to recognize substitution. Staffing of roughly 350-500 cleared people (estimate) is also hard to surge or backfill.

## Opportunities 🌈🌐
- Reusable verification methods: Equipment-identity chains, tamper-evident ledgers and hash-committed exercise catalogs could inform later technical verification research. Documenting them openly where classification permits adds to the evidence base on verifying digital-hardware change.
- Learning from precedent: IAEA seals and managed access, OPCW mock challenge inspections and New START unique identifiers offer mature, tested practices. Expert exchange with these communities can shorten design iteration and improve credibility.
- Empirical parity measurement: Reason-coded access logging and outcome-based parity give a rare quantitative picture of reciprocity under distrust. The data can refine matched-site equivalence and inform whether bilateral change verification is credible.
- Vendor-neutral schedule design: A role-based, versioned covered-equipment schedule can demonstrate how verification stays valid across hardware generations. This creates a template for technology-agnostic definitions.

## Threats ☠️🛑🚨☢︎💩☣︎
- Entry-gate stall: Seven mandatory conditions must be certified together, and instruments, appropriations and access authority typically take 6-12 months (estimate). Slippage past Month 12 (2027-10-12) erodes political momentum and could end the program before testing begins.
- Espionage and IP leakage: Resident inspectors, translators and evidence systems form a collection channel for the counterpart. A single breach can cause operator withdrawal, site failure and an impaired-confidence review.
- Political fragility and obstruction: No enforcement path exists beyond suspension, as New START's breakdown shows. A government can stall findings, shield an operator or withhold funding, and manufactured triggers can cascade into suspension.
- Legal and supply-chain disruption: Litigation over compelling private vendors or state-enterprise ambiguity may delay binding by 2-4 months (estimate). Geopolitical or export-control shocks could also alter vendor participation mid-test.

## Recommendations 💡✅
- Start instrument negotiation, legal review and supplier declarations immediately, with weekly entry-condition tracking and the principal go/no-go at Month 7.5 (2027-05-27). Owner: co-chairs' legal working group.
- Complete vendor binding by Month 8 (2027-06-12) and stand up at least 2 clean-room centers by Month 9 (2027-07-12), with a documented refusal ladder. Owner: bilateral technical unit.
- Run the filter-adequacy pre-test at Month 8.5 (2027-06-27) with at least 10 substitutions and halt scored exercises below 85% detection. Owner: exercise design panel.
- Hold a staffing dry-run at Month 8 (2027-06-12) and validate leave, surge and tenure assumptions before clock start. Owner: mirrored personnel units.
- Lock deadlock timers, suspension triggers and the CHALLENGE-tag rule in the instrument before signature, and rehearse a misclassification escalation within 2 hours. Owner: adjudication unit.

## Strategic Objectives 🎯🔭⛳🏅
- By Month 9 (2027-07-12), certify all 7 entry conditions at a single gate with a matched instrument, schedule and site set.
- Achieve at least 90% blind detection for each of 7 event types with at least 10 injections each by Month 11.5 (2027-09-27) (proposed threshold).
- Hold identity confidence above 95% and unverifiable equipment at or below 3% per site through the 90-day window (provisional).
- Keep reciprocal-access variance within 10% and ledger synchronization within 1 hour, with zero production disruption, through Month 12 (2027-10-12).
- Deliver a Go/Modify/Stop verdict at Month 12.25 (2027-10-20) with every threshold documented, validated or marked provisional.

## Assumptions 🤔🧠🔍
- Both leaders give sustained political backing and domestic compulsion authority throughout Phase One.
- Attestation-capable equipment and accredited examiner laboratories exist in both countries.
- Four sites (2 matched US-China pairs) provide comparable staging, spare-inventory, maintenance and expansion areas.
- Dedicated authenticated transport and hardened ledger nodes can be built before Month 9 (2027-07-12).
- Cleared, bilingual full-time inspectors can be recruited and vetted in time (estimate).

## Missing Information 🧩🤷‍♂️🤷‍♀️
- Actual vendor mix and attestation-key custody for declared equipment at each site.
- Validated detection rates under realistic filtering; all thresholds remain provisional.
- Final China site location and the governance venue (Geneva or Singapore).
- Local event-recording latency and false-positive limit (TBD).
- Scope, criteria and funding for any Phase Two after the verdict.
- Status of domestic legal authority to compel private vendors in each country.

## Questions 🙋❓💬📌
- Which evidence layer should carry the most weight if attestation and physical inspection conflict, and what would justify that ordering?
- How can the minimum evidence schema be made detailed enough to expose substitution without revealing topology or workload information?
- What exercise design could test a determined state adversary rather than only anticipated scenarios in a sealed catalog?
- How should reciprocal-access parity be normalized across non-identical sites so that disputes reflect real asymmetry rather than site differences?
- What wording and procedures will keep closed exit records from implying knowledge beyond the monitored boundary?