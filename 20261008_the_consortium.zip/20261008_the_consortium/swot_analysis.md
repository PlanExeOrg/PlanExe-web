
## Strengths 👍💪🦾
- Narrow, bounded mission (declared-equipment change verification only) keeps scope achievable and avoids contested claims about hidden facilities or total capacity.
- Leader-level backing in both countries and domestic authority to compel participation address the main precedent failure: access curtailment.
- Fixed USD 5.0B cap, exactly 50/50, with seven envelopes, 100% envelope-mapping audits and four synchronized tranches makes withholding visible and symmetric.
- Layered evidence (no single source decisive), confidential rotating rule and vendor fallback ladder resist gaming and single-point failure.
- Governance is explicit: double-key, no casting vote, timed deadlock, partial suspension (day 14) and impaired-confidence (days 21/28) rules that keep unrelated verification running.
- Independent 8-person mixed-nationality Exercise Authority, cross-designed red-team challenges and pre-registered thresholds support credible, reciprocal detection evidence.
- Staffing is sized from sites, shifts and leave (about 180 per country, estimate), with deputies for every critical role.
- Strong precedents to borrow from: IAEA, OPCW, START commissions, CTBTO signed data.

## Weaknesses 👎😱🪫⚠️
- Thin statistics: about 54 exercises give pooled about ±12% at 95%, and per event type about ±32% (estimate). Go/Modify/Stop on 70% and 50% thresholds will often be ambiguous.
- Thresholds, parity definition, functional-equivalence criteria and the evidence rule are unvalidated (proposed); the rule is calibrated only on historical records, not adversarial cases.
- Entry gates are sequential and heavy (instrument, appropriations, sites, inspectors, vendors, schedule) and run Months 0-5 (2026-10-08 to 2027-03-08).5. Any slip compresses the test.
- Vendor ladder cannot finish before the clock: five rungs at 8-12 weeks each, so unresolved equipment becomes unverifiable or is excluded. This lets vendors shape what is covered.
- Adjudication capacity of about 15 cases per month is small against a possible 50+ cases if the rule is miscalibrated.
- Filtering and certification add 2-3 days per package, and filters are a point where evidence can be hidden.
- Key ceremonies and the neutral facility are chokepoints (site OPEN, due Month 3 = 2027-01-08). Dual-share keys can block the ledger for 8-24 hours.
- Funding after Phase One (Modify rework or Phase Two) is OPEN, and the 'Go' tranche is tied to the verdict, which could bias scoring.

## Opportunities 🌈🌐
- Create a first-of-kind, reusable template for hardware-change verification between adversaries, with the technology-neutral schedule and coded bilingual schema adaptable to other regimes.
- Publish unclassified KPIs and verdict logic, building legislative and public confidence in fiscal accountability and objective results.
- Use the Month 5 (2027-03-08) pilot (all seven event types, non-production site) to recalibrate thresholds and the evidence rule before the clock starts.
- Engage IAEA, OPCW and former START/OSIA inspectors for managed-access, seal and dispute-procedure lessons, and use third-country auditors and the filter auditor for neutral legitimacy.
- Pre-agreed vendor participation terms, home-government compensation and fallback options can turn vendors into supporters and extend verifiability.
- Add cross-pair exercise replicates or extend the window after a Modify verdict to narrow the intervals, if funding is agreed.

## Threats ☠️🛑🚨☢︎💩☣︎
- Political withdrawal or deterioration of US-China relations, as seen with the lapsed JCPOA monitoring and New START.
- Tranche delay or unequal deposits: over 14 days triggers escalation, over 30 days is a Stop trigger.
- Asymmetric operator compliance: commercial US operators may resist on confidentiality grounds, while state-run Chinese sites may slow access through bureaucracy. Either can break parity or amount to shielding.
- Counterintelligence breaches or IP leaks by inspectors, and public disclosure that forces withdrawal.
- Contested exercise integrity or filter disputes that turn the dataset into a forensic argument.
- Entry slips of 8-12 weeks costing USD 100-500M (estimate) and exhausting contingency, risking a breach of the USD 5B cap.
- Gaming of the evidence rule by operators or vendors, and rapid hardware change outpacing the frozen schedule.
- Staffing shortfalls or attrition in 24/7 mirrored shifts, and exercises disrupting production.

## Recommendations 💡✅
- Entry task force (both co-chairs' offices): publish the roadmap at Month 0 (2026-10-08), run site, vendor and vetting tracks in parallel, hold a summit within 5 days of any gate slipping over 2 weeks, and keep the USD 50-100M compression reserve (estimate). Decide the neutral facility site by Month 1 (2026-11-08).
- Evidence rule owners (accountable specialists): place the draft rule in escrow at Month 4.5 (2027-02-23). Validate it on 100-200 historical events per site by Month 5.5 (2027-03-23), then add adversarial synthetic cases. Adjust and re-validate on a second cohort if deviation exceeds 5 points.
- Exercise Authority and verdict panel: pre-register thresholds and scoring as bands by Month 5.5 (2027-03-23), with a mechanical rule that defaults to Modify when intervals straddle a threshold. State the ±12% pooled and ±32% per-type limits in every report. Lock before the Month 6 (2027-04-08) clock.
- Vendor Liaison Offices: document vendor refusals by Month 3 (2027-01-08) and start the first fallback rung immediately. Pre-stage one examiner team per country (5-8 specialists). Exclude or mark unverifiable anything unresolved at entry, and publish the registry by Month 4 (2027-02-08).
- Co-chairs and finance officers: lock deadlock, suspension and age thresholds into the instrument by Month 1 (2026-11-08). Appoint the independent timekeeper. Do not tie the final tranche to a Go/Modify outcome, only to verdict publication. Settle the post-Phase One funding route by Month 8 (2027-06-08).
- Counterintelligence Board and filter auditor: certify the filters by Month 5 (2027-03-08), enforce the firewall and no-phone rules, and run monthly spot checks. Add adjudication surge capacity above 15 cases per month.

## Strategic Objectives 🎯🔭⛳🏅
- Certify the entry gate by Month 5.5 (2027-03-23) with all seven conditions met, including parity confirmed for at least 2 and a target of 3 matched pairs.
- Complete pilot and historical validation by Month 5.5 (2027-03-23), with pilot false positives of 7-13% and false negatives under 5% (proposed thresholds), and lock thresholds before the Month 6 (2027-04-08) clock.
- Run at least 6 exercises per event type (54 total at 3 pairs) in the 90-day window (Months 6-9 = 2027-04-08 to 2027-07-08) with zero production disruption, and report intervals with every rate.
- Keep every discrepancy under 21 days at conclusion, ledger digests exchanged at least hourly, and ledger divergence reconciled within 72 hours (target), with zero unresolved divergences.
- Publish the scored unclassified verdict within 5 days of Month 9 (2027-07-08) and take the final Go/Modify/Stop decision by Month 9.5 (2027-07-23), with audit exceptions at or below 2% of sampled value.

## Assumptions 🤔🧠🔍
- Both leaders sustain political backing and compel operators and vendors, with no trust assumed.
- Phase One starts only after all entry conditions are met; the 90-day clock begins at Month 6 (2027-04-08).
- Commercial elements are Not applicable; value is judged by outcomes and fiscal accountability.
- Canonical facts supersede earlier documents: 3 matched pairs, about 180 staff per country (estimate), 54 exercises.
- Thresholds and the parity definition remain provisional until validated on pilot data.
- Both countries fund exactly USD 2.5B, drawn in four synchronized tranches.

## Missing Information 🧩🤷‍♂️🤷‍♀️
- Definition and measurement method of reciprocal-access parity.
- Validated historical datasets and ground truth for the evidence-rule calibration.
- Exact treatment of the other three event types (class TBD) in detection thresholds.
- Neutral facility site (Geneva or Singapore) and host-country permits.
- Vendor positions: which Tier-1 vendors will participate, refuse or demand fallback.
- Funding route for Modify rework or Phase Two.
- Translation turnaround targets and the adjudication surge budget.
- Legal basis for operator compensation and domestic access authority in each country.

## Questions 🙋❓💬📌
- If detection lands at 60-80% with wide intervals, what pre-agreed outcome does each government accept, and is Modify a real decision or a default exit?
- What evidence would show that one side's operators are shielding, and who certifies it without a casting vote?
- How will the draft evidence rule be tested against adversarial behaviour, not only benign historical records?
- Which gate is most likely to slip, and would each government accept a smaller test (2 pairs, shorter window) rather than a delay?
- Who funds and decides what follows a Modify verdict, and does that affect how the final tranche and scoring are perceived?