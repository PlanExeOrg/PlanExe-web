# Governance Audit


## Audit - Corruption Risks

- Inspectors stationed at counterpart sites susceptible to bribery, blackmail or relationship-capture by host-country intelligence services to conceal equipment substitutions, misreport findings or delay audit reports.
- Vendor representatives offering cryptographic attestation keys, firmware versions or equipment identifiers as conditional quid pro quo for favorable identity rulings at intake or exemption from layered corroboration checks.
- Mirrored national team members sharing confidential equipment schedules, filtered evidence or inspection procedures with domestic operators or vendors in exchange for compensation, advance warning of exercises or career advancement.
- Host-country government officials steering inspectors away from certain declared sites, maintenance areas or equipment categories by invoking undefined 'national security' or administrative delay to shield non-compliant operators from verification.
- Ledger custodians or checkpoint signatories accepting side payments to introduce deliberate divergences, delay divergence detection or suppress reconciliation records so one country's findings can be rewritten post hoc without audit trail.
- Neutral-party technical referees or arbitrators manipulating advisory fact statements or threshold-calibration recommendations based on political signaling or private government preference rather than documented evidence.

## Audit - Misallocation Risks

- Operator and vendor compensation flowing through host-country government channels without transparent itemization, allowing domestic entities to over-bill declared equipment costs (e.g., claiming 10× market rates for staging-area preparation) while unverifiable spending diverges from USD 2.5 billion share.
- Contingency envelope (USD 500 million) drawn by co-chairs without documented approval thresholds or trip points, enabling front-loading of discretionary administrative costs (travel, temp staffing, facility rental) that exhaust reserves before Phase One operational start.
- Challenge-exercise budgets absorbed into testing or personnel envelopes without ring-fenced accounting, allowing redirected funds or inflated hours to obscure actual exercise costs and leave insufficient reserves for red-team surge capacity.
- Secure-facility and ledger-node capital costs claimed against multiple envelopes simultaneously (e.g., as both secure facilities and ledger systems) without consolidated depreciation or maintenance-cost accounting, double-counting expenditure against the USD 5 billion cap.
- Staffing time-cards for mirrored inspectors recorded without granular task coding by site or event type, preventing audit recovery of hours misallocated to administrative work, training or leave-coverage versus billable verification activity.
- Vendor-binding legal fees, clean-room examination setup and bilateral-instrument negotiation costs not explicitly mapped to the USD 250 million legal/audit envelope, leaving unclear who absorbs costs and creating budget illusion that preparation is on-track.

## Audit - Procedures

- Monthly bilateral budget-burn audits by an independent auditor (funded from USD 250 million legal/audit envelope) confirming each country's cumulative-disbursement tracking against the USD 2.5 billion share and ±10% tolerance, with tranche-release holds if variance exceeds 15% or parity audit cannot be completed.
- Quarterly unannounced facility-security inspections by a bilateral Facility Security Review Panel at ledger nodes, clean-room centers and secure workspaces, with incident logging in the tamper-evident ledger within 1 hour and escalation to co-chairs if any security findings cannot be remediated within 5 days.
- Monthly evidence-schema audits at each site confirming that operator-controlled redaction gateways preserve all non-redactable fields (serial number, firmware version, attestation digest, timestamp, physical identifiers) and logging every filter decision with reason codes in the ledger for retroactive validation.
- Post-Phase-One independent financial audit by the bilateral auditor reviewing all USD 5 billion expenditure against envelope allocation, vendor-compensation rates, contingency drawdowns and tranche reconciliation to certify compliance with parity rules and cost attribution before Phase Two budget authorization.
- Continuous monitoring of inspector accessibility, request-denial logs and reciprocal-access parity metrics (target ±10% variance) with automated escalation when monthly divergence exceeds 15% for 2 consecutive weeks, triggering impaired-confidence review and principal-level audit of access-control policies.
- Quarterly cryptographic-ledger integrity audits confirming checkpoint signature validity, divergence-detection latency performance against ±4-hour KPI, reconciliation closure time against <=24-hour standard, and absence of any unsigned or ante-dated entries; results published in KPI dashboard.

## Audit - Transparency Measures

- Published monthly KPI dashboard (classified for bilateral distribution only) reporting blind-detection rates by event type, false-negative and false-positive counts, equipment-identity confidence scores, unverifiable-equipment ratio per site, ledger-synchronization latency, parity variance between matched sites, unresolved-discrepancy age distribution, and funding timeliness by tranche and envelope.
- Sealed, jointly committed challenge-exercise scenario catalog (hash-committed before Phase One starts at Month 9 = 2027-07-12) published after scoring so neither government can redefine success post hoc; all challenge-exercise events tagged CHALLENGE in the ledger before injection to partition them from operational triggers.
- Published escalation and deadlock records in the ledger documenting every co-chair impasse, referee-panel fact statement, principal-level review and decision outcome with timestamps, allowing either government to audit whether procedural timers (5/8/13-day escalation) were respected and deadlock was not weaponized for delay.
- Quarterly operator-consent-status reports shared with both co-chairs listing each participating operator's consent state (full/degraded/withdrawn), recent incidents affecting trust (e.g., IP leakage allegations, boundary violations), remediation actions and confidence rating; withdrawal triggers automatic suspension and principal-level diplomatic response.
- Pre-published bilateral instrument and operating procedures detailing entry conditions, governance structure, deadlock escalation, automatic-suspension triggers (with objective thresholds), evidence standards and verdict rules, enabling both national legislatures and the public press to hold the regime accountable to its own announced framework.
- Documented covered-equipment-schedule version history in the ledger recording every versioned schedule update with bilateral-specialist signatures, timestamp, functional role definitions and rationale for boundary-case migrations, preventing unilateral or secret redefinition of what equipment is in scope.

# Internal Governance Bodies

### 1. Bilateral Steering Committee (Co-Chair Level)

**Rationale for Inclusion:** Provides strategic direction and high-level oversight for The Consortium's 90-day Phase One operational test. Equal national co-chairs enforce double-key governance without casting votes, approve budgets above USD 10M thresholds, authorize protocol changes, and manage escalations from operational teams. Required for bilateral equity and sovereign accountability.

**Responsibilities:**

- Set strategic priorities and governance posture for Phase One
- Approve major budget draws (>USD 10M) and contingency allocations, with matched parity accountability
- Authorize protocol changes, site findings and suspension decisions via double-key
- Oversee entry-condition certification and gate readiness
- Receive and act on escalations from technical referees and operational deadlocks within fixed timers
- Authorize personnel assignments, inspector rotations and staffing surge

**Initial Setup Actions:**

- Confirm bilateral instrument signature and co-chair appointment by Month 7 (2027-05-12)
- Establish monthly decision cadence and escalation timer protocols before Month 9 (2027-07-12)
- Document no-casting-vote and double-key procedures in operational bylaws
- Pre-position deputy co-chairs and continuity succession before transition
- Certify all entry conditions at simultaneous gate decision point by Month 9 (2027-07-12)

**Membership:**

- National co-chair from United States (deputy secretary or equivalent)
- National co-chair from China (vice-minister or equivalent)
- Each co-chair's designated alternate and successor (for continuity)

**Decision Rights:** Strategic and policy decisions, budget allocations above USD 10M thresholds, protocol changes, suspension authorizations, personnel assignments, and escalation disputes from operational teams. Decisions require bilateral consensus; no majority vote or casting vote permitted. Disagreement triggers escalation to principals within fixed timers (5/8/13-day sequence).

**Decision Mechanism:** Bilateral consensus required on all decisions. Deadlock is defined as failure to reach consensus within 5 days. No casting vote or majority procedure. If co-chairs cannot agree, automatic escalation to designated principals (e.g., secretary of state level) within 2 days. Principals must decide within 5 calendar days or status quo defaults to heightened inspection (not suspension) while further escalation continues. All decisions and deadlocks recorded in the tamper-evident ledger with timestamps.

**Meeting Cadence:** Monthly formal decision sessions (1st of each month, Months 9–12 = 2027-07-12 to 2027-10-12); weekly informal reviews during Phase One operations; emergency convocation within 24 hours if escalation from operational level is triggered. All deadlocks escalate by Day 5 automatically.

**Typical Agenda Items:**

- Budget-burn reports and contingency-draw requests with parity accounting
- Monthly KPI dashboard review (detection rates, parity variance, ledger sync, unresolved discrepancies)
- Escalated site findings, deadlocked identity disputes or vendor-refusal outcomes
- Personnel and staffing-surge authorization requests
- Facility security incidents and counterintelligence briefings
- Challenge-exercise schedule and threshold-calibration panel recommendations

**Escalation Path:** Deadlocked co-chair disagreements automatically escalate to Bilateral Technical Referees panel (composed of 2 pre-cleared experts per country) within 24 hours. If referees issue dual-signed advisory fact statement and co-chairs still cannot agree, escalation triggers automatic Principal-Level Review (secretary-level or equivalent) within 2 days, with mandatory decision required within 5 calendar days.
### 2. Project Management Office and Operational Execution Team

**Rationale for Inclusion:** Manages day-to-day operational execution, tactical risk management, evidence handling, personnel scheduling and coordination of mirrored national teams across 4 declared sites. Directly accountable to co-chairs for meeting KPI targets, managing surges and maintaining the 90-day schedule. Required because the operational scope is large (350-500 staff), geographically distributed and time-constrained.

**Responsibilities:**

- Coordinate day-to-day operations at all 4 declared sites with zero disruption to active compute
- Schedule and deploy mirrored inspection teams across sites, managing shifts, leave coverage and surge capacity
- Manage intake, identity verification, maintenance monitoring and exit-disposition activities at each site
- Record all events in the tamper-evident ledger with immediate local posting and checkpoint synchronization
- Monitor and escalate KPI performance (detection rates, identity confidence, parity variance, ledger latency)
- Manage evidence handling, redaction-gateway audits and filter-adequacy compliance
- Coordinate challenge-exercise logistics in staging and spare-inventory areas without operator disruption

**Initial Setup Actions:**

- Establish operational command structure and site-level teams by Month 8 (2027-06-12)
- Deploy and clear all inspector, technical and support personnel by Month 8.75 (2027-07-05)
- Conduct staffing dry-run and attestation-validation rehearsal by Month 8 (2027-06-12)
- Run filter-adequacy blind pre-test with >=10 substitutions by Month 8.5 (2027-06-27)
- Prepare opening-inventory baseline collection protocols for Days 1-5 of Phase One
- Finalize challenge-exercise staging protocols and site-specific logistics

**Membership:**

- Program Director (project lead, accountable for schedule and KPI delivery)
- US National Operations Director (US mirrored team lead)
- China National Operations Director (China mirrored team lead)
- Site Operations Managers (one per declared site, minimum 4)
- Evidence and Ledger Manager (local recording, synchronization, checkpoint validation)
- Inspector Deployment and Leave Coordinator (shift scheduling, surge management)

**Decision Rights:** Operational decisions within defined thresholds: personnel deployments and rotations up to 20% surge; evidence-handling redactions within approved schema; challenge-exercise logistics; incident response and containment. Decisions exceeding thresholds (e.g., site access suspension, unverifiable-equipment escalation, contingency spend >USD 10M) escalate to co-chairs. Day-to-day tactical decisions made at site level without escalation unless a KPI threshold is breached or an enumerated auto-suspension trigger is approached.

**Decision Mechanism:** National operations directors make operational decisions within their country's mirrored teams by consensus of site managers and functional leads. Cross-site or bilateral operational decisions require agreement between national operations directors; disagreement escalates to co-chairs within 24 hours. All event recording, ledger entries and KPI-threshold violations logged automatically and escalated using reason codes and severity classification.

**Meeting Cadence:** Daily operational sync (15 minutes, all site managers) during Phase One; weekly bilateral operations review with national directors and co-chairs (1 hour); emergency tactical huddles within 2 hours if a KPI threshold is breached or auto-suspension trigger is approached.

**Typical Agenda Items:**

- Daily equipment arrivals, movements, maintenance and departures by site
- Shift staffing status, leave coverage and unplanned absences
- Identity-verification escalations and unverifiable-equipment counts
- Ledger synchronization status and divergence-reconciliation updates
- Parity-denial logs and access-request outcomes
- Challenge-exercise progress and injected-scenario status
- Facility security incidents and counterintelligence alerts
- Contingency-spend requests and budget-burn tracking

**Escalation Path:** Site-level issues escalate to national operations director within 4 hours. Bilateral operational disputes escalate to co-chairs within 24 hours. Any KPI threshold breach (identity confidence <95%, unverifiable >3%, parity >15%, ledger sync >4 hours, unresolved discrepancy >10 days) automatically triggers an escalation report to co-chairs with recommended corrective action within 2 hours of detection. Auto-suspension triggers escalate to co-chairs immediately for double-key authorization of suspension or heightened inspection.
### 3. Bilateral Technical Referees Panel

**Rationale for Inclusion:** Provides independent technical fact-finding and advisory decision-making for deadlocked co-chair disagreements on site findings, equipment identity disputes, vendor-refusal outcomes and evidence sufficiency. Composed of 2 pre-cleared technical experts per country with no political incentive to obstruct. Required because the plan explicitly forbids casting votes and requires escalation of deadlocks to a non-political fact-based process.

**Responsibilities:**

- Issue dual-signed advisory fact statements on contested site findings within 3 days of referral
- Adjudicate disputed equipment-identity rulings by reviewing layered evidence and independence-of-layers analysis
- Evaluate vendor-refusal escalations and recommend appropriate disposition (supervised testing, clean-room examination, unverifiable status)
- Assess equipment-identity confidence and corroboration adequacy for borderline units
- Review filter-adequacy audit findings and recommend protocol adjustments if schema fields are at risk
- Provide technical input to Threshold Calibration Panel on detection-rate assumptions and blind-exercise data

**Initial Setup Actions:**

- Recruit, vet and clear 4 technical experts (2 per country) with certification authority by Month 7 (2027-05-12)
- Establish technical-referee protocols and evidence-review procedures by Month 8 (2027-06-12)
- Train referees on identity-verification layering, evidence schema and corroboration rules
- Establish secure facilities for sealed evidence review and dual-signed advisory production
- Define escalation rules: when a co-chair disagreement on a technical matter becomes a referee referral

**Membership:**

- Senior Technical Expert from United States (cleared, independent of inspectorate)
- Senior Technical Expert from China (cleared, independent of inspectorate)
- Each country's alternate referee (for continuity if primary is unavailable)

**Decision Rights:** Authority to issue dual-signed advisory fact statements on specific technical disputes referred by co-chairs. Statements are advisory; co-chairs remain accountable for final decision. Referees have no authority to bind co-chairs, but their facts become part of the escalation record and inform principal-level review if co-chairs remain deadlocked.

**Decision Mechanism:** Both referees review evidence independently and sealed, then convene to draft a joint fact statement that both must sign. Disagreement between referees becomes part of the record; they may issue a statement saying 'Referees assessed evidence independently; assessment differs on [specific point]' and recommend principal-level review. No casting vote or majority ruling; if consensus cannot be reached on a fact statement, the extent of disagreement is documented and escalated with the unsigned draft to principals.

**Meeting Cadence:** On-demand; convenes within 24 hours of co-chair referral. Must produce dual-signed advisory statement within 3 days. No regular cadence; purely triggered by escalated disputes.

**Typical Agenda Items:**

- Review of sealed evidence (identity documentation, customs records, attestation validation, physical inspection notes, maintenance logs)
- Assessment of whether layered evidence meets independence-of-layers requirement and identity-confidence threshold (>95% provisional)
- Evaluation of vendor-refusal outcomes and recommendation among: vendor-supervised testing, filtered evidence, clean-room examination, or unverifiable status
- Filter-adequacy assessment if redaction decisions are in dispute
- Corroboration-mismatch analysis (e.g., attestation timestamp misaligned with customs entry)

**Escalation Path:** If referees cannot produce a dual-signed fact statement (disagreement on core findings), the unsigned draft, areas of disagreement and both referees' independent assessments escalate automatically to Principal-Level Review within 2 days. If co-chairs receive a dual-signed fact statement but remain deadlocked on the policy decision, the matter escalates to principals with the referees' statement attached.
### 4. Evidence and Ledger Integrity Committee

**Rationale for Inclusion:** Ensures the tamper-evident replicated ledger remains trustworthy, synchronization stays within KPI bounds, divergences are detected and reconciled within 24 hours, and all evidence handling meets schema and chain-of-custody standards. Central to the entire verification program because evidence credibility is the sole basis for the Go/Modify/Stop verdict. Required because ledger integrity is a foundational technical requirement and a Stop criterion.

**Responsibilities:**

- Operate and monitor each country's independent ledger copy and synchronization checkpoints
- Detect divergences between national copies and initiate reconciliation within 4 hours of detection
- Validate cryptographic checkpoint signatures and hash-chain integrity hourly
- Log all facility incidents (power loss, physical access, personnel changes) in the ledger within 1 hour
- Audit operator-controlled redaction gateways and confirm all non-redactable evidence schema fields are preserved
- Monitor equipment-identity confidence scores and escalate units approaching the unverifiable threshold (>5% at a site)
- Maintain equipment-classification schedule versioning and track all double-key schedule updates

**Initial Setup Actions:**

- Establish ledger-node security hardening and geographically diverse deployment by Month 8 (2027-06-12)
- Deploy hash-chain checkpoint validation infrastructure with hourly cryptographic validation by Month 8.5 (2027-06-27)
- Establish neutral-party digest custodian arrangement for ledger escrow and offline backup by Month 8 (2027-06-12)
- Train operators on redaction-gateway logging and run filter-adequacy pre-test by Month 8.5 (2027-06-27)
- Establish reconciliation procedures and timers (4-hour detection, 24-hour closure) and log every step in the ledger
- Pre-stage offline backup media and recovery procedures for forensic ledger reconstruction

**Membership:**

- Ledger System Architect (design, cryptography, checkpoint validation)
- US Ledger Node Operator (national copy management, synchronization, security)
- China Ledger Node Operator (national copy management, synchronization, security)
- Evidence Schema and Classification Specialist (each country, 1 per country minimum)
- Divergence Reconciliation Lead (bilateral, accountable for 24-hour closure SLA)

**Decision Rights:** Authority to record all events in the ledger with immediate local posting; to validate checkpoint signatures and detect divergences; to classify divergences as resolved or unresolved based on evidence; to escalate unresolved divergences or sync-latency KPI breaches. Authority to partition challenge-exercise events from operational events using CHALLENGE tagging. No authority to alter event records post hoc or override reconciliation; all changes tracked and escalated.

**Decision Mechanism:** Ledger operators record events as they occur with immediate local timestamp. National copies exchange signed hourly checkpoints. On divergence detection, both operators independently review the diverged events and logs; if cause is clear and correction is made (e.g., late-arriving event), reconciliation is logged and closed. If cause is unclear or disputed, unresolved status is recorded and escalated to co-chairs; 24-hour closure deadline applies. If divergence cannot be resolved at ledger-operator level, escalation goes to co-chairs with no discretion to override the reconciliation process.

**Meeting Cadence:** Daily ledger health check (15 minutes, all operators and schema specialists) during Phase One; weekly bilateral reconciliation review (1 hour) if any divergences occurred; emergency convocation within 2 hours if divergence-detection latency exceeds 4-hour KPI or sync latency exceeds 1 hour.

**Typical Agenda Items:**

- Hourly checkpoint validation results and signature verification status
- Any divergence events detected: event count, age, content and root cause
- Reconciliation progress and closure status for any open divergences
- Facility security incidents affecting ledger integrity (power loss, access, personnel changes)
- Redaction-gateway audit results and evidence-schema compliance checks
- Equipment-identity confidence trend (units trending toward >5% unverifiable at any site)
- Schedule-version update requests and bilateral signature status
- Offline backup and forensic-recovery readiness status

**Escalation Path:** Divergence detected -> immediate escalation report to co-chairs with summary and cause analysis within 2 hours. Reconciliation not closed within 8 hours -> escalation to co-chairs flagging age and recommending co-chair review. Unresolved divergence age >10 days -> automatic impaired-confidence review trigger; >15 days -> Stop-criterion candidate. Sync latency exceeding 4-hour KPI or checkpoint validation failure -> immediate escalation to co-chairs and Facility Security Review Panel.
### 5. Counterintelligence and Compartmentation Oversight Unit

**Rationale for Inclusion:** Protects inspector and evidence-handler personnel from espionage, blackmail and relationship-capture by counterpart intelligence services. Enforces compartmentation rules, manages personnel vetting and tenure limits, runs insider-threat red-cell operations and conducts security incident investigations. Required because resident mirrored teams at counterpart sites face extraordinary CI risk and operator willingness depends on credible compartmentation assurances.

**Responsibilities:**

- Vet, polygraph and continuously monitor all inspectors, technical staff and translators for CI risk
- Enforce compartmentation rules: inspectors segregated by site and event type, with no individual holding cross-site knowledge
- Manage inspector tenure limits (6-month site tenure with 2-month breaks) and rotation scheduling
- Conduct quarterly unannounced facility-security inspections of ledger nodes, clean rooms and secure workspaces
- Operate bilateral insider-threat red cell attempting to compromise inspectors and evidence handlers
- Investigate and log all suspected CI incidents in the tamper-evident ledger within 1 hour
- Audit boundary-violation allegations and operator-complaint investigations
- Review and approve all cross-border evidence movement and communications

**Initial Setup Actions:**

- Recruit and clear CI specialists (minimum 4 per country: 2 counterintelligence officers, 1 polygraph examiner, 1 forensic investigator) by Month 7 (2027-05-12)
- Establish CI vetting protocols and polygraph schedule for all 350-500 personnel by Month 8 (2027-06-12)
- Establish compartmentation rules, access-control matrices and event-type segregation by Month 8 (2027-06-12)
- Deploy insider-threat red cell (2 officers per country) and establish red-team exercise protocols by Month 8.5 (2027-06-27)
- Establish secure facilities and compartmented workspaces at each site by Month 9 (2027-07-12)
- Conduct pre-Phase-One CI baseline briefing for all inspectors and clearance-status confirmation

**Membership:**

- CI Director from United States (senior counterintelligence official, cleared)
- CI Director from China (senior counterintelligence official, cleared)
- Senior CI Officer per country (2 FTE minimum per country)
- Polygraph and Personnel Vetting Lead (per country, 1 per country minimum)
- Insider-Threat Red Cell Coordinator (per country, bilingual, 2 per country recommended)
- Forensic Investigator and Incident Response Lead (joint or per-country)

**Decision Rights:** Authority to deny personnel access to Phase One operations if vetting reveals CI risk; to enforce tenure limits and rotations; to initiate investigations of suspected CI incidents; to recommend compartmentation changes if operational needs conflict with security. No authority to override co-chair decisions on site suspension or personnel assignments, but findings feed directly into co-chair briefings and suspension criteria.

**Decision Mechanism:** CI decisions are made independently by each country's CI director on vetting and tenure; bilateral agreement is required for compartmentation rule changes, clearance denials that affect operations, and red-cell exercise protocols. CI incidents are investigated by both sides jointly when cross-border elements are present. Disagreement on CI risk assessments is escalated to co-chairs; vetting denial stands until resolved by principals if either side objects.

**Meeting Cadence:** Weekly CI briefing (1 hour, both CI directors) during Phase One; monthly compartmentation-compliance review; quarterly unannounced facility inspections (concurrent, both sides); insider-threat red-cell exercises at Month 9.75, 10.75, 11.75 (2027-08-04, 2027-09-04, 2027-10-05) (roughly monthly during Phase One).

**Typical Agenda Items:**

- Polygraph results and new vetting completions for incoming personnel
- Tenure-limit compliance and upcoming rotations by site and function
- Suspected or confirmed CI incidents and investigation status
- Compartmentation compliance audits and access-control log review
- Insider-threat red-cell exercise results and attempted-compromise summaries
- Facility security incidents affecting compartmented areas
- Operator-complaint investigations and boundary-violation allegations
- Recommended compartmentation adjustments based on operational experience

**Escalation Path:** Suspected CI incident -> immediate investigation initiation and co-chair notification within 2 hours. Confirmed CI breach -> automatic co-chair briefing and Facility Security Review Panel convocation within 4 hours. Disputed vetting denial (one country clears, other rejects) -> escalation to co-chairs within 24 hours for resolution. Compartmentation-rule conflict (operational need vs. security requirement) -> escalation to co-chairs for policy adjustment. Red-cell successful compromise of an inspector -> incident investigation and personnel removal within 24 hours, with co-chair notification.
### 6. Threshold Calibration and Verdict Panel

**Rationale for Inclusion:** Establishes and defends the Go, Modify and Stop thresholds so verdicts rest on evidence rather than political preference. Pre-registers unsupported figures with documented validation methods, calibrates thresholds using early blind-exercise data, freezes thresholds before scored exercises, and produces sealed independent scores to prevent post-hoc goalpost-moving. Required because the plan explicitly demands thresholds separated from political decision-making and evidence-based verdict criteria.

**Responsibilities:**

- Pre-register all Go, Modify and Stop thresholds before Month 9 (2027-07-12) with documented validation source for each figure
- Mark provisional or TBD figures explicitly and specify validation method
- Calibrate thresholds using early blind-exercise results (Months 9.5-10.5 = 2027-07-27 to 2027-08-27) and recommend adjustments if empirical data diverges >10% from assumptions
- Freeze all thresholds by Month 10.5 (2027-08-27) before scored exercises begin
- Score blind-exercise results independently and sealed by each national team
- Compare sealed scores at Month 11.75 (2027-10-05) to measure scoring divergence
- Produce a Verdict Evidence Report documenting how evidence maps to Go/Modify/Stop criteria

**Initial Setup Actions:**

- Recruit bilateral technical calibration experts (2 per country minimum, cleared) by Month 7 (2027-05-12)
- Publish pre-registered threshold table with provisional-figure labeling and validation-method source by Month 8.5 (2027-06-27)
- Establish scoring criteria and evidence-sufficiency rules for each KPI before Phase One starts
- Establish secure facilities for sealed score storage and comparison protocols by Month 8 (2027-06-12)
- Conduct threshold-calibration dry-run using historical or simulated exercise data by Month 8.5 (2027-06-27)

**Membership:**

- Calibration Panel Lead (bilateral, senior technical authority accountable for pre-registration and freeze decisions)
- US Threshold Specialist (technical expert, cleared, independent of inspectorate)
- China Threshold Specialist (technical expert, cleared, independent of inspectorate)
- Evidence Sufficiency Analyst (per country, 1 per country minimum, responsible for scoring protocol)

**Decision Rights:** Authority to set and publish pre-registered thresholds; to recommend threshold adjustments based on early-exercise calibration; to freeze thresholds by Month 10.5 (2027-08-27); to score exercise results against frozen thresholds. No authority to change thresholds after freeze except by bilateral co-chair amendment. Sealed scoring is independent; panel does not gate the Go/Modify/Stop verdict, but provides the evidence basis for co-chair decision.

**Decision Mechanism:** Thresholds are pre-registered by bilateral agreement (both specialists sign off) and published by Month 8.5 (2027-06-27). Calibration recommendations require both specialists' agreement; disagreement on a calibration recommendation is documented and escalated to co-chairs. Threshold freeze at Month 10.5 (2027-08-27) requires both specialists' sign-off; disagreement is escalated to co-chairs for final decision. Sealed scoring is done independently by each country; scoring divergence is measured but both scores are treated as valid assessments and reported alongside the verdict.

**Meeting Cadence:** Monthly during preparation (Months 7-8 = 2027-05-12 to 2027-06-12); weekly during calibration exercises (Months 9.5-10.5 = 2027-07-27 to 2027-08-27); sealed-score comparison meeting at Month 11.75 (2027-10-05); no regular cadence after freeze, only convened if co-chairs request threshold amendment.

**Typical Agenda Items:**

- Pre-registration table review: threshold values, provisional-figure labels, validation-method documentation
- Early blind-exercise results and divergence analysis (actual vs. provisional assumption)
- Recommended threshold adjustments (if empirical data diverges >10% from assumptions)
- Freeze-readiness assessment and final specialist sign-off
- Sealed-score comparison and measurement of scoring divergence between national assessments
- Evidence-mapping review: how KPI results translate to Go/Modify/Stop verdict criteria

**Escalation Path:** Disagreement on threshold values before pre-registration -> escalation to co-chairs by Month 8 (2027-06-12) with recommendations from both specialists. Disagreement on calibration recommendations -> documented in the calibration report with both positions published. Disagreement on freeze decision -> escalation to co-chairs for final authorization. Scoring divergence >10 percentage points between national teams -> both scores reported alongside verdict, with divergence magnitude itself become a transparency metric.
### 7. Vendor and Operator Binding and Compliance Unit

**Rationale for Inclusion:** Ensures vendors and operators accept and comply with verification duties (reporting, confidentiality, escort, evidence preservation) before Phase One starts. Manages vendor-refusal escalations, operates clean-room examination centers for refusing vendors, and enforces consequences for non-compliance. Required because vendor refusal and operator shielding are listed Stop criteria and must be contractually bound before entry gate.

**Responsibilities:**

- Draft and execute verification-duty contracts with all equipment manufacturers, maintenance providers and logistics firms
- Establish pre-qualified vendor registry and enforce supply-chain consequences for refusal
- Operate accredited clean-room examination centers for vendors unwilling to participate directly
- Manage attestation-key validation by accredited examiners (both countries) for each critical vendor
- Track vendor-attestation confidence and flag vendors whose signatures cannot be independently validated by Month 10 (2027-08-12)
- Escalate vendor-refusal outcomes and recommend supervisory-testing, filtered-evidence or unverifiable status
- Audit operator adherence to access-control and compartmentation boundaries
- Monitor operator-consent status and escalate any withdrawal or degradation as immediate impaired-confidence trigger

**Initial Setup Actions:**

- Identify critical vendors and suppliers (manufacturers, maintenance, logistics) by Month 7 (2027-05-12)
- Draft vendor-binding agreements with confidentiality, reporting and evidence-preservation terms by Month 7.5 (2027-05-27)
- Obtain operator and vendor signatures on binding agreements by Month 8 (2027-06-12)
- Establish pre-qualified vendor registry and communicate supply-chain consequences by Month 8 (2027-06-12)
- Construct clean-room examination centers (at least 1 per country) by Month 8.5 (2027-06-27)
- Establish accredited-examiner vetting and attestation-validation protocols by Month 8.5 (2027-06-27)
- Confirm all critical vendors' attestation keys are validated by Month 10 (2027-08-12) or flag for unverifiable status

**Membership:**

- Vendor and Operator Liaison Director (bilateral, accountable for binding and compliance)
- US Vendor Binding and Compliance Lead (national, manages US operator and vendor relationships)
- China Vendor Binding and Compliance Lead (national, manages China operator and vendor relationships)
- Accredited Examiner and Clean-Room Lead (per country, 1 per country, manages supervised testing)
- Attestation-Key Validation Specialist (technical, cryptography, 1 per country minimum)

**Decision Rights:** Authority to require vendors and operators to sign binding agreements as a condition of participation; to deny supply-chain access to refusers; to escalate vendor-refusal outcomes and recommend disposition (clean-room, filtered evidence, unverifiable); to flag attestation-validation failures. No authority to override co-chair decisions on suspension or equipment disposition, but vendor-refusal and attestation-validation findings feed directly into escalation.

**Decision Mechanism:** Binding agreements are drafted jointly and signed by each country with counterpart vendors and operators. Vendor-refusal escalations are jointly assessed; if refusal handling diverges (one country recommends clean-room, other recommends unverifiable), escalation goes to co-chairs within 5 days of refusal with both country's recommendations. Attestation-validation results are assessed independently by each country's examiner; if validation fails for a critical vendor, automatic escalation to co-chairs and principal-level resolution within 5 days.

**Meeting Cadence:** Weekly vendor-compliance review (1 hour) during preparation (Months 7-8 = 2027-05-12 to 2027-06-12) and through Phase One; monthly operator-consent-status report shared with co-chairs; immediate escalation meetings within 24 hours if a vendor refuses or an operator withdraws consent.

**Typical Agenda Items:**

- Vendor-binding-agreement execution status and signature tracking
- Pre-qualified registry roster and supply-chain consequence enforcement
- Vendor-refusal incidents and escalation status (clean-room testing, filtered evidence, unverifiable classification)
- Attestation-key validation results by vendor tier and confidence status
- Clean-room examination capacity and schedule; refusing-vendor testing queue
- Operator-consent status by site; any degradation or withdrawal incidents
- Operator-complaint investigations and boundary-violation allegations
- Attestation-validation confidence trending and Month 10 (2027-08-12) certification readiness

**Escalation Path:** Vendor refusal -> escalation to co-chairs within 24 hours with both countries' recommendations for disposition. Vendor-refusal handling disagreement -> co-chairs decision required within 5 days; absent agreement, equipment from refuser becomes unverifiable if material (>3% of site). Attestation-validation failure for critical vendor -> immediate escalation to co-chairs and principals within 2 hours; principal-level resolution required within 5 days. Operator-consent withdrawal -> automatic site suspension and diplomatic escalation to principals within 4 hours.
### 8. Independent Testing, Challenge Exercise and Red Team Unit

**Rationale for Inclusion:** Designs and executes blind challenge exercises (unreported arrivals, substitutions, inaccurate records, delayed access, vendor refusal, reluctant operators) in staging, spare-inventory, maintenance and expansion areas without disrupting active compute. Validates detection capability and filter adequacy through empirical testing. Produces evidence for the Go/Modify/Stop verdict and ensures neither government can redefine success post hoc. Required because blind detection is a stated Go criterion and challenge exercises are the only empirical basis for credible verdicts.

**Responsibilities:**

- Design blind challenge scenarios for 7 event types with >=10 injections each (70 total) before Phase One starts
- Hash-commit sealed scenario catalog before Month 9 (2027-07-12) so neither government can redefine scenarios
- Conduct filter-adequacy pre-test (Month 8.5, 2027-06-27) with >=10 substitutions to validate redaction rules before scored exercises
- Run unscored calibration exercises (Months 9.5-10.5, 2027-07-27 to 2027-08-27) to establish baseline detection and false-positive/negative rates
- Execute scored blind exercises (Months 10.5-11.5, 2027-08-27 to 2027-09-27) with detection tracking by event type
- Score exercise results against frozen thresholds (>=90% detection per event type for Go)
- Operate reciprocal red-team challenges where each country's team tests the counterpart's inspectorate at matched sites

**Initial Setup Actions:**

- Recruit independent testing director and red-team leads (2 per country minimum, cleared, no ties to inspectorate) by Month 7 (2027-05-12)
- Design 70 blind scenarios (>=10 per event type) by Month 8 (2027-06-12)
- Hash-commit sealed scenario catalog by Month 8.5 (2027-06-27)
- Prepare filter-adequacy pre-test injections and detection-measurement protocols by Month 8.5 (2027-06-27)
- Establish scenario-tagging (CHALLENGE tag) and reconciliation protocols with ledger unit by Month 8 (2027-06-12)
- Brief inspectors on exercise partitioning: CHALLENGE tags exclude exercises from triggering suspension or KPI violations

**Membership:**

- Independent Testing Director (bilateral, accountable for blind scenario integrity and scoring independence)
- US Red Team Lead (challenges China's inspectorate at US site, 1-2 FTE minimum)
- China Red Team Lead (challenges US's inspectorate at China site, 1-2 FTE minimum)
- Detection-Measurement Analyst (per country, tracks blind-scenario injection, detection and false-positive rates)
- Filter-Adequacy Tester (per country, conducts pre-test and validates redaction-rule preservation of schema fields)

**Decision Rights:** Authority to design sealed scenarios, hash-commit the scenario catalog and set injection schedules; to tag exercises CHALLENGE and partition them from operational triggers; to score results against frozen thresholds. No authority to change scenarios after hash-commit or to override Threshold Calibration Panel freeze decisions; testing feeds evidence to the verdict but does not bind the verdict.

**Decision Mechanism:** Scenario design is done jointly by both countries' red-team leads; disagreement on scenarios is resolved by co-chairs before hash-commit. Scenario hash-commitment is done by bilateral agreement and published before Phase One starts. Scored results are recorded independently by each national testing team and compared by Threshold Calibration Panel; disagreements on how to classify a result are documented and escalated to the panel.

**Meeting Cadence:** Weekly scenario-design review (Month 8 = 2027-06-12); monthly during Phase One preparation and execution (Months 9-11 = 2027-07-12 to 2027-09-12); sealed-score comparison with Threshold Calibration Panel at Month 11.75 (2027-10-05).

**Typical Agenda Items:**

- Blind-scenario design and validation for 7 event types
- Hash-commitment and sealed-catalog publication
- Filter-adequacy pre-test results: preservation of evidence-schema fields, detection rate, false-positive rate
- Calibration-exercise results and baseline detection/false-positive rates by event type
- Scored-exercise progress: injections per event type, detections and misses, false-positive incidents
- Reciprocal red-team challenges: each country's outcomes at matched sites
- CHALLENGE-tag partition compliance: exercises not triggering suspension or KPI violations
- Detection trending toward >=90% Go threshold

**Escalation Path:** Filter-adequacy pre-test detects missing schema fields -> exercise halt; filters renegotiated and re-tested by Month 9 (2027-07-12) or Phase One delayed. Blind exercise detected by inspectors as unverifiable equipment or triggered an auto-suspension -> immediate escalation to co-chairs with CHALLENGE-tag verification; automatic reinstatement if confirmed as exercise. Scoring divergence >10 percentage points on a given event type -> documented in Threshold Calibration Panel report with both countries' assessments. Detection rate below 85% in calibration exercises -> investigation of filter or presence issues; corrective action or Phase One delay if root cause cannot be remedied.

# Governance Implementation Plan

### 1. Initiate parallel bilateral-instrument negotiation and establish a bilateral steering group to track negotiation progress weekly, with both governments committing to a fixed instrument-signature deadline of Month 7 (2027-05-12). Begin negotiation by Month 5 (2027-03-12) to allow 16-month runway.

**Responsible Body/Role:** US Department of State and China Ministry of Foreign Affairs (diplomatic leads); designated negotiation teams from both countries.

**Suggested Timeframe:** Month 5 (2027-03-12) to Month 7 (2027-05-12 to 2027-05-12); ongoing weekly progress reviews.

**Key Outputs/Deliverables:**

- Signed bilateral instrument (executive agreement or treaty), fixing co-chair roles, double-key procedures, escalation rules, deadlock definitions, and entry-condition certification logic
- Weekly negotiation status report with blockers and escalation triggers
- Documented instrument-signature target of Month 7 (2027-05-12) with accountability for delays

**Dependencies:**

- Project initiation decision
- US and Chinese government political backing confirmed
- Negotiation team recruitment and briefing

### 2. Establish a bilateral Legal and Regulatory Working Group to identify domestic legal barriers to compulsory operator/vendor participation, export controls, facility clearances and data-transfer rules. Conduct comprehensive legal review for both countries and recommend legislative or regulatory amendments needed before entry gate.

**Responsible Body/Role:** US Department of Justice (Office of Legal Counsel), US Department of Commerce (Bureau of Industry and Security), and China's State Council, Ministry of Commerce and counterpart legal authorities; legal working group co-leads from each country.

**Suggested Timeframe:** Month 5 (2027-03-12) to Month 7.5 (2027-05-27 to 2027-05-27); final legal opinions published by Month 7.5 (2027-05-27).

**Key Outputs/Deliverables:**

- Comprehensive legal barrier assessment (US and China)
- OLC opinion affirming US authority to compel operator/vendor participation
- Chinese legal directive affirming domestic compulsion authority
- Export-control and data-transfer clearance documentation
- Recommended legislative or regulatory amendments (if any) with fast-track timetable

**Dependencies:**

- Bilateral instrument scope and entry conditions defined
- Domestic authority requirements documented
- Negotiation team input on substantive legal terms

### 3. Identify participating datacenters and operators in both countries and conduct preliminary site surveys to document staging areas, spare-inventory zones, maintenance and expansion areas, operator types, logistics access, customs proximity and security posture. Develop a matched-site pairing rationale (by verification function, operator type, or capacity tier) for bilateral agreement.

**Responsible Body/Role:** US project lead (designated by NSC or State Department) and China project lead (designated by relevant ministry); supported by site-survey technical teams.

**Suggested Timeframe:** Month 5 (2027-03-12) to Month 8 (2027-06-12 to 2027-06-12); site selection finalized by Month 8 (2027-06-12).

**Key Outputs/Deliverables:**

- Inventory of candidate sites (≥6 per country, narrowed to 2 per country)
- Physical site-survey reports documenting staging, spare-inventory, maintenance, expansion areas and operator characteristics
- Matched-site pairing rationale document approved by bilateral agreement
- Site selection certification by both countries confirming 4 declared sites ready for Phase One

**Dependencies:**

- Preliminary political backing confirmed
- Budget allocation decision (USD 5B 50/50)
- Covered-equipment schedule draft available to define which equipment zones are in scope

### 4. Draft a provisional, vendor-neutral, hardware-generation-agnostic Covered-Equipment Schedule defining frontier-relevant equipment by functional role (e.g., tensor-accelerated parallel computation exceeding X exaflops per second) rather than manufacturer or product. Establish a double-key schedule-update process for quarterly revisions by bilateral specialist teams.

**Responsible Body/Role:** Bilateral technical specialists (≥2 per country) with security clearances; accountable to the designated project leads from each country.

**Suggested Timeframe:** Month 5 (2027-03-12) to Month 8 (2027-06-12 to 2027-06-12); provisional schedule published for bilateral approval by Month 8 (2027-06-12).

**Key Outputs/Deliverables:**

- Provisional Covered-Equipment Schedule defining covered equipment by functional role with numerical thresholds and abstraction layers
- Schedule version-control procedure and quarterly-update process documented
- Boundary-case resolution rule ('when in doubt, classify as covered') and specialist-review protocols
- Bilateral sign-off on provisional schedule by both countries' technical leads

**Dependencies:**

- Site identification and equipment inventory available from site surveys
- Ledger and attestation system requirements documented
- Legal authority to classify equipment confirmed

### 5. Identify all critical equipment vendors (manufacturers, maintenance providers, logistics firms) for both countries' participating sites. Draft vendor-binding agreements committing vendors to reporting, confidentiality, escort and evidence-preservation duties. Establish a pre-qualified vendor registry with supply-chain consequences for refusal.

**Responsible Body/Role:** Bilateral Vendor and Operator Binding Lead (designated); supported by national vendor-liaison teams (US and China).

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 8 (2027-06-12 to 2027-06-12); vendor-binding agreements signed by Month 8 (2027-06-12).

**Key Outputs/Deliverables:**

- Vendor-identification list (manufacturers, maintenance, logistics) by participating site
- Drafted vendor-binding agreements with confidentiality, reporting and evidence-preservation terms
- Pre-qualified vendor registry roster and supply-chain consequence policy
- Executed vendor-binding agreements signed by each critical vendor and both governments

**Dependencies:**

- Participating sites and operators identified
- Covered-equipment schedule published
- Legal authority to bind vendors confirmed

### 6. Plan and construct accredited clean-room examination centers (≥1 per country) where refusing vendors can submit equipment for supervised testing without exposing source code or proprietary details. Establish accredited-examiner vetting, cryptographic-attestation validation protocols and chain-of-custody procedures.

**Responsible Body/Role:** Bilateral Clean-Room and Accredited-Examiner Lead (designated technical authority); national facility-design and construction leads.

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 9 (2027-07-12 to 2027-07-12); operational by Month 9 (2027-07-12) for Phase One.

**Key Outputs/Deliverables:**

- Clean-room facility design and security specifications (≥2 centers, one per country)
- Attestation-validation laboratory protocols and equipment list
- Accredited-examiner vetting and clearance procedures (bilateral)
- Facility security certification and operational readiness attestation by Month 9 (2027-07-12)

**Dependencies:**

- Vendor-refusal escalation procedures documented
- Budget allocation to secure-facilities envelope (USD 750M)
- Site locations finalized
- Security and facility-access requirements defined

### 7. Recruit, vet, clear and pre-position the Bilateral Steering Committee co-chairs (US deputy secretary level, China vice-minister level) and their deputies. Hold co-chair appointment confirmation meeting with both governments and document succession protocols for continuity.

**Responsible Body/Role:** US government (State Department, NSC) and China's relevant ministry; co-chair nominees subject to bilateral confirmation.

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 7 (2027-05-12 to 2027-05-12); co-chairs confirmed by Month 7 (2027-05-12).

**Key Outputs/Deliverables:**

- Named co-chairs (one per country) with security clearances and confirmed tenure
- Documented succession and continuity plan
- Co-chair confirmation letter from each government
- Deputy co-chair appointments and continuity roster

**Dependencies:**

- Bilateral instrument framework defining co-chair roles published
- Government political backing and personnel authorization confirmed

### 8. Establish a principal-level go/no-go decision checkpoint at Month 7.5 (2027-05-27) to assess entry-condition readiness. Review status of bilateral instrument, appropriations, domestic access authority, site selection, vendor binding and inspector clearance pipeline. Decide whether to proceed to full entry-gate certification by Month 9 (2027-07-12) or defer.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs (newly confirmed); supported by designated project leads and legal working group.

**Suggested Timeframe:** Month 7.5 (2027-05-27); decision documented same day.

**Key Outputs/Deliverables:**

- Principal-level go/no-go checkpoint decision report documenting status of all 7 entry conditions
- Documented decision: proceed to full gate by Month 9 (2027-07-12), defer, or restart with revised scope
- Escalation of any condition lagging timeline with corrective action and revised target date

**Dependencies:**

- Bilateral instrument signature target of Month 7 (2027-05-12) achieved or near-certain
- Status updates on all 6 remaining entry conditions available
- Co-chairs in place and first decision authority confirmed

### 9. Conduct comprehensive legal enactment of domestic access authority in each country, including any required legislative authorization, executive orders or ministerial directives to compel operator and vendor participation. Publish final legal findings confirming domestic compulsion authority is in effect.

**Responsible Body/Role:** US Department of Justice (OLC), Office of Management and Budget; China State Council and relevant ministries; each government's legal/legislative authorities.

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 8 (2027-06-12 to 2027-06-12); final legal authority published by Month 8 (2027-06-12).

**Key Outputs/Deliverables:**

- Published US domestic access authority (legal opinion, executive order or statute)
- Published China domestic access authority (State Council directive or ministerial order)
- Certification by each government that compulsion authority is enacted and in effect
- Legal opinion summary for bilateral record

**Dependencies:**

- Legal barrier assessment completed
- Bilateral instrument framework defining authority scope published
- Operator and vendor participation requirements documented

### 10. Initiate recruitment, vetting and security-clearance processing for all inspectors, technical specialists, legal staff, counterintelligence officers, translators, logistics personnel and support functions (estimated 350-500 cleared full-time staff). Conduct background investigation and polygraph scheduling for all personnel.

**Responsible Body/Role:** US National Security Agency and equivalent China security authorities (personnel vetting agencies); designated recruiting leads from each country's inspectorate-to-be.

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 8 (2027-06-12 to 2027-06-12); clearance processing complete by Month 8.75 (2027-07-05).

**Key Outputs/Deliverables:**

- Recruitment target list (350-500 personnel by function and country) with no single-person critical positions
- Personnel clearance processing status report (polygraph, background investigation, CI vetting)
- Final clearance roster by Month 8.75 (2027-07-05) confirming all Phase One staff cleared
- Clearance denial documentation and appeal resolution for any rejected candidates

**Dependencies:**

- Staffing model and functional unit structure defined
- CI and personnel-vetting protocols established
- Site locations and operational structure finalized

### 11. Recruit and appoint senior technical and CI specialists to establish the Evidence and Ledger Integrity Committee, Counterintelligence and Compartmentation Oversight Unit, and Bilateral Technical Referees Panel. Confirm appointment of committee members and document their operational authorities before Phase One.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs (newly confirmed); supported by designated project leads and recruiting teams.

**Suggested Timeframe:** Month 7 (2027-05-12) to Month 8.5 (2027-06-27 to 2027-06-27); all committee members confirmed by Month 8.5 (2027-06-27).

**Key Outputs/Deliverables:**

- Named members of Evidence and Ledger Integrity Committee (ledger architects, node operators, divergence-reconciliation lead per country)
- Named members of Counterintelligence and Compartmentation Oversight Unit (CI directors, vetting leads, insider-threat red-cell coordinators per country)
- Named members of Bilateral Technical Referees Panel (2 technical experts per country, independent of inspectorate)
- Appointment letters documenting authorities and tenure for each role

**Dependencies:**

- Clearance pipeline complete
- Budget authorization for specialist staffing
- Committee charter and responsibility documents finalized

### 12. Establish the legal and procedural framework for the Bilateral Steering Committee: publish operational bylaws documenting double-key governance, no-casting-vote rule, 5/8/13-day escalation-timer sequence, deadlock definition, enumerated auto-suspension triggers, and decision recording in the tamper-evident ledger.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs; supported by Legal and Regulatory Working Group.

**Suggested Timeframe:** Month 7 (2027-05-12) to Month 8 (2027-06-12 to 2027-06-12); bylaws published and co-chair approved by Month 8 (2027-06-12).

**Key Outputs/Deliverables:**

- Bilateral Steering Committee Operational Bylaws documenting governance procedures, decision thresholds (budgets >USD 10M, protocol changes, personnel assignments), escalation rules and timers, and ledger-recording requirements
- Co-chair decision-authority charter
- Deadlock-definition document with 5-day trigger and escalation sequence
- Enumerated auto-suspension trigger list with objective thresholds (unverifiable >3%, divergence >5%, denial >15%, age >15 days)

**Dependencies:**

- Bilateral instrument signature and co-chair confirmation
- Entry conditions and decision framework defined
- Ledger and KPI architecture specified

### 13. Finalize the ledger and attestation-system architecture, including cryptographic hash-chain design, signed checkpoint format (hourly cadence proposed), transport security (dedicated IPsec tunnel), divergence-detection algorithms and reconciliation procedures. Award contracts for ledger system development and deployment.

**Responsible Body/Role:** US and China national leads for ledger systems; bilateral ledger architect and cybersecurity specialists.

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 8.5 (2027-06-27 to 2027-06-27); system design complete and procurement awarded by Month 8.5 (2027-06-27).

**Key Outputs/Deliverables:**

- Ledger Architecture and Security Specification document
- Cryptographic checkpoint format and hourly validation procedures
- Divergence-detection and reconciliation algorithms
- Transport-security specifications (dedicated IPsec, mutual TLS, no shared internet)
- Ledger system development and deployment contract awards

**Dependencies:**

- Budget allocation to ledger envelope (USD 1.25B)
- Attestation validation and evidence-schema requirements defined
- Facility security and facility access specifications available
- KPI targets (1-hour sync, 4-hour divergence detection, 24-hour reconciliation) published

### 14. Arrange neutral-party digest-custodian services (third-country entity or trusted international organization) to hold encrypted hash-chain digests of both national ledger copies and serve as offline backup and forensic-recovery escrow. Execute escrow agreement by both governments.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs and Legal Working Group; designated neutral custodian organization.

**Suggested Timeframe:** Month 7 (2027-05-12) to Month 8 (2027-06-12 to 2027-06-12); escrow agreement signed by Month 8 (2027-06-12).

**Key Outputs/Deliverables:**

- Neutral-party custodian identification and selection (bilateral agreement)
- Escrow agreement specifying digest format, release triggers, audit rights and offline-backup protocols
- Custodian security vetting and facility inspection completed
- Escrow operational readiness confirmed by Month 8.75 (2027-07-05)

**Dependencies:**

- Ledger architecture and checkpoint format defined
- Budget for custodian services (USD 20-30M estimate, within ledger envelope)
- Bilateral agreement on neutral-party selection criteria

### 15. Hire and deploy the independent testing director, red-team leads (≥1 per country), detection-measurement analysts and filter-adequacy testers. Design sealed 70 blind challenge scenarios (≥10 per event type) covering unreported arrivals, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal and reluctant operators.

**Responsible Body/Role:** Independent testing director (bilingual, cleared, no ties to inspectorate); national red-team leads and testing teams from each country.

**Suggested Timeframe:** Month 7 (2027-05-12) to Month 8 (2027-06-12 to 2027-06-12); scenario design and hash-commitment complete by Month 8.5 (2027-06-27).

**Key Outputs/Deliverables:**

- Independent testing director and red-team leads confirmed with clearances
- 70 sealed blind-challenge scenarios (10 per event type minimum) with injection protocols
- Hash-committed scenario catalog published before Phase One (Month 9, 2027-07-12)
- CHALLENGE-tagging partition protocol and detection-measurement procedures

**Dependencies:**

- Budget allocation to testing envelope (USD 500M)
- Event types and detection thresholds (≥90% proposed) defined
- Cleared independent-tester recruitment and vetting complete

### 16. Draft minimum evidence-schema specification (serial number, firmware version, attestation digest, maintenance-event timestamp, physical identifiers) and establish evidence-filtering rules. Jointly design operator-controlled redaction-gateway rules ensuring non-redactable schema fields are preserved. Publish redaction rules and gateway-logging requirements.

**Responsible Body/Role:** Bilateral Evidence and Ledger Integrity Committee chair; supported by sensitive-asset specialists from each country and operator liaisons.

**Suggested Timeframe:** Month 7 (2027-05-12) to Month 8 (2027-06-12 to 2027-06-12); rules published by Month 8 (2027-06-12).

**Key Outputs/Deliverables:**

- Non-redactable evidence-schema specification (serial number, firmware version, attestation digest, timestamp, physical marks)
- Operator-controlled redaction-gateway rules and field-preservation requirements
- Gateway-logging protocol (every redaction decision logged in ledger with reason code and timestamp)
- Bilateral agreement that stripping any schema field escalates equipment to unverifiable status

**Dependencies:**

- Covered-equipment schedule and identity-verification architecture defined
- Operator compartmentation and IP-protection boundaries agreed
- Ledger system and evidence-recording infrastructure designed

### 17. Conduct a staffing dry-run exercise simulating 7 consecutive days of Phase One intake and monitoring operations at a test site (or by simulation). Validate that 24/7 shift coverage with minimum 2-person teams per function, 15% leave allowance and 10% surge reserve meet readiness requirements. Document staffing KPIs and identify any gaps.

**Responsible Body/Role:** Project Management Office and Operational Execution Team (formation in progress); simulation directors from each country.

**Suggested Timeframe:** Month 8 (2027-06-12); dry-run conducted and results published by Month 8 (2027-06-12).

**Key Outputs/Deliverables:**

- Staffing dry-run scenario and simulation protocol
- Readiness report documenting 7-day coverage by shift, function and site
- Identified staffing gaps or surge-capacity shortfalls
- Corrective actions (cross-site floaters, additional recruiting, shift-rotation adjustments) and timeline

**Dependencies:**

- Staffing model and functional units defined
- Personnel clearance processing substantially complete
- Operational procedures and intake protocols drafted

### 18. Conduct filter-adequacy blind pre-test by injecting ≥10 test substitutions in a controlled staging area and measuring detection rate and false-positive rate under the proposed redaction-gateway rules. Verify that ≥9 of 10 substitutions are detected without exposing redacted fields.

**Responsible Body/Role:** Independent testing director and filter-adequacy testers (both countries); supported by operations and evidence-integrity teams.

**Suggested Timeframe:** Month 8.5 (2027-06-27); pre-test completed and results published by Month 8.5 (2027-06-27).

**Key Outputs/Deliverables:**

- Filter-adequacy blind pre-test protocol and test-substitution design
- Detection rate and false-positive-rate results (target ≥9 of 10, i.e., ≥90%)
- Redaction-rule audit confirming no non-negotiable schema fields were stripped
- Halt-or-proceed recommendation: if <85% detected, exercises halted for filter renegotiation and re-test; if ≥85%, proceed to Phase One

**Dependencies:**

- Sealed challenge-scenario design and injection protocols finalized
- Redaction-gateway rules and schema published
- Staging area and inspector teams ready for pre-test injection
- Co-chairs prepared to halt Phase One if filter adequacy fails

### 19. Establish the Threshold Calibration and Verdict Panel with bilateral technical specialists. Pre-register all Go, Modify and Stop thresholds with documented validation source (proposed: detection ≥90% per event type for Go, identity confidence >95%, unverifiable ≤3%, parity variance ±10%). Mark unsupported figures as provisional and specify validation method.

**Responsible Body/Role:** Bilateral Threshold Calibration and Verdict Panel lead (bilateral); national threshold specialists (1 per country minimum).

**Suggested Timeframe:** Month 7.5 (2027-05-27) to Month 8.5 (2027-06-27 to 2027-06-27); pre-registered thresholds published by Month 8.5 (2027-06-27).

**Key Outputs/Deliverables:**

- Pre-registered threshold table: Go (detection ≥90%, identity >95%, unverifiable ≤3%, parity ±10%), Modify, Stop criteria
- Validation-method documentation for each figure (blind exercises, historical data, expert assessment)
- Provisional-figure labeling and TBD fields with planned validation by Month 1.5 (2026-11-27) exercises (estimate)
- Sealed independent-score templates for later bilateral comparison

**Dependencies:**

- KPI and success-criteria definitions finalized
- Challenge-exercise design and 70-scenario plan published
- Co-chairs authorized to freeze thresholds by Month 10.5 (2027-08-27)

### 20. Complete appropriations legislation and budgetary authorization in both countries. Allocate USD 2.5 billion per country across seven envelopes (ledger 1.25B, site 1B, personnel 750M, security 750M, testing 500M, legal 250M, contingency 500M). Establish matched-tranche release rules: four equal quarterly tranches of USD 625M per country with parity tolerance ±10% and contingency-draw thresholds (>USD 10M = co-chair sign-off, 75% drawn = principal escalation).

**Responsible Body/Role:** US Congress (appropriations committee) and China's National People's Congress or equivalent; national finance ministers and OMB/State Department (US) or Ministry of Finance (China).

**Suggested Timeframe:** Month 4 (2027-02-12) to Month 8 (2027-06-12 to 2027-06-12); appropriations enacted by Month 8 (2027-06-12).

**Key Outputs/Deliverables:**

- Enacted appropriations legislation (US and China) providing USD 2.5B authorization per country
- Budget-envelope allocation and spending caps by category
- Tranche schedule (Months 7, 10, 13, 16 = 2027-05-12, 2027-08-12, 2027-11-12, 2028-02-12)
- Parity-tolerance rule documentation (±10% cumulative, 15% monthly triggers review, 20% divergence triggers hold)
- Contingency sub-account reservation (USD 50M gate-readiness, USD 450M free contingency)

**Dependencies:**

- Total budget (USD 5B) and envelope allocation finalized
- Bilateral Steering Committee and co-chair governance framework published
- Spending-accountability and tranche-release procedures defined

### 21. Hire independent bilateral budget auditor (funded from USD 250M legal/audit envelope) to verify all tranche releases and provide monthly spending reports by envelope category. Establish auditor protocols for parity-divergence detection and tranche-hold triggers.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs; national finance leads; independent auditor selection committee.

**Suggested Timeframe:** Month 7 (2027-05-12) to Month 8 (2027-06-12 to 2027-06-12); independent auditor appointed and operational by Month 8.75 (2027-07-05).

**Key Outputs/Deliverables:**

- Independent bilateral budget auditor identified and hired
- Auditor charter documenting monthly reporting requirements, tranche-verification procedures and parity-divergence thresholds
- Monthly budget-burn dashboard template by envelope and country
- Tranche-release authorization procedures (auditor confirmation + co-chair double-key approval)

**Dependencies:**

- Appropriations enacted and budget authority confirmed
- Tranche schedule and parity rules published
- Co-chair governance framework established

### 22. Conduct comprehensive entry-condition certification at a single gate decision point by Month 9 (2027-07-12). Verify all seven mandatory conditions: (1) bilateral instrument signed, (2) appropriations enacted, (3) domestic access authority enacted, (4) participating sites selected and certified equivalent, (5) inspectors approved and cleared, (6) operators and vendors committed to participation, (7) provisional covered-equipment schedule adopted. Issue joint certification or defer Phase One if any condition is unmet.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs (formally convened for entry-gate decision); supported by project leads, legal working group and condition-tracking teams.

**Suggested Timeframe:** Month 9 (2027-07-12); single certification decision made by Month 9 (2027-07-12), Day 1.

**Key Outputs/Deliverables:**

- Entry-Condition Certification Report documenting status of all 7 conditions (Met / Not Met / Near-Ready with path)
- Joint certification decision: 'Entry Gate Certified - Phase One Clock Starts Month 9 (2027-07-12)' OR 'Gate Deferred - Remediation Timeline: [specific condition and target date]'
- If certified: Phase One baseline-collection schedule published (Days 1-5 reserved for opening-inventory seal)
- If deferred: revised gate re-evaluation date and contingency-sunk-cost tracking

**Dependencies:**

- All entry-condition status reports delivered by Month 9 (2027-07-12), Day 0
- Bilateral instrument signed
- Appropriations enacted
- Legal authority confirmed
- Sites selected and surveys complete
- Vendor binding agreements signed
- Personnel clearances complete
- Provisional schedule published

### 23. Establish the Project Management Office and Operational Execution Team structure, appointing a Program Director (accountable to co-chairs), US and China National Operations Directors, Site Operations Managers (one per declared site, ≥4 total), Evidence and Ledger Manager, and Inspector Deployment and Leave Coordinator. Confirm operational authorities and decision thresholds in writing.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs (newly confirmed and in formal session); supported by designated project leads.

**Suggested Timeframe:** Month 8 (2027-06-12) to Month 9 (2027-07-12 to 2027-07-12); full team confirmed and operational by Month 9 (2027-07-12) if entry gate is certified.

**Key Outputs/Deliverables:**

- Named Program Director (bilateral accountability, accountable to co-chairs for KPI delivery and schedule)
- Named US National Operations Director and China National Operations Director with bilateral-coordination authority
- Named Site Operations Managers for all 4 declared sites with escalation authorities
- Evidence and Ledger Manager and Inspector Deployment Coordinator confirmed
- Operational-authority charter documenting decision rights (personnel deployments <20% surge, evidence handling within schema, challenge logistics, incident response)

**Dependencies:**

- Entry gate certified
- Personnel clearance roster complete
- Operational procedures and site-level protocols drafted
- Co-chair governance framework and escalation rules published

### 24. Conduct bilateral co-chair formal inaugural meeting, confirming operational readiness, reviewing KPI targets and monthly decision cadence (1st of each month), publishing first-month operational briefing agenda, and authorizing Phase One clock start at Month 9 (2027-07-12).

**Responsible Body/Role:** Bilateral Steering Committee co-chairs (formally convened); all committee members and project leads present.

**Suggested Timeframe:** Month 9 (2027-07-12); inaugural meeting held on Day 1 of Phase One.

**Key Outputs/Deliverables:**

- Co-chair Inaugural Meeting Minutes documenting readiness confirmation, KPI targets published, monthly meeting schedule locked (1st of month), escalation procedures confirmed
- First-month briefing agenda (opening-inventory baseline, KPI monitoring, facility status, contingency budget, early challenge exercises)
- Co-chair joint authorization letter confirming Phase One operations are live and Budget Tranche 1 (USD 625M per country) is released

**Dependencies:**

- Entry gate certified and Phase One clock started
- All governance bodies and executive teams appointed and confirmed
- Operational procedures and monthly decision cadence documented

### 25. Establish the bilateral Counterintelligence and Compartmentation Oversight Unit, confirming CI Directors and specialist staff from both countries. Publish compartmentation rules (inspectors segregated by site and event type, no cross-site knowledge), tenure limits (6-month site tenure with 2-month breaks), and insider-threat red-cell protocols. Issue clearance-status confirmation for all Phase One personnel.

**Responsible Body/Role:** Bilateral Steering Committee; national CI directors (recruited and cleared Month 7 = 2027-05-12); supported by vetting and polygraph specialists.

**Suggested Timeframe:** Month 8 (2027-06-12) to Month 9 (2027-07-12 to 2027-07-12); CI protocols published and compartmentation rules enforced by Month 9 (2027-07-12), Day 1.

**Key Outputs/Deliverables:**

- Named CI Directors (one per country) with decision authorities documented
- Compartmentation Rules and Access-Control Matrix (inspectors segregated by site and event type, no individual cross-site knowledge)
- 6-month tenure limits and mandatory 2-month breaks between site assignments
- Insider-threat red-cell charter and monthly exercise schedule (three planned exercises at Months 9.75, 10.75, 11.75 = 2027-08-04, 2027-09-04, 2027-10-05)
- Personnel clearance-status roster (all Phase One staff confirmed cleared) with any denials and appeals resolved

**Dependencies:**

- Personnel vetting and polygraph processing complete
- Compartmentation and IP-protection boundaries defined
- Insider-threat red-team protocols and staffing approved

### 26. Formally establish the Bilateral Technical Referees Panel (2 technical experts per country, independent of inspectorate). Confirm members, publish technical-referee charter, establish sealed evidence-review facility, train referees on identity-verification layering and corroboration rules, and document escalation triggers (co-chair deadlock escalates to referees within 24 hours; referees must produce dual-signed fact statement within 3 days or escalate to principals).

**Responsible Body/Role:** Bilateral Steering Committee co-chairs; recruited technical-referee panel members (cleared, independent).

**Suggested Timeframe:** Month 8 (2027-06-12) to Month 9 (2027-07-12 to 2027-07-12); panel operational by Month 9 (2027-07-12), Day 1.

**Key Outputs/Deliverables:**

- Named Bilateral Technical Referees Panel members (2 from US, 2 from China) with independence certification and sealed facility access
- Technical-Referee Charter documenting authorities (dual-signed advisory statements), decision timers (3-day closure for fact statements), and escalation rules
- Training on identity-verification layering, corroboration analysis, evidence-schema validation and threshold-sufficiency assessment
- Sealed evidence-review facility operational and CI-protected

**Dependencies:**

- Technical-expert recruitment and clearance complete
- Identity-verification architecture and corroboration rules published
- Evidence-schema and threshold-sufficiency criteria defined

### 27. Formally establish the Evidence and Ledger Integrity Committee, confirming Ledger System Architect, US and China Ledger Node Operators, Evidence-Schema and Classification Specialists (≥1 per country), and Divergence Reconciliation Lead. Publish ledger operational procedures (hourly checkpoint validation, divergence detection within 4 hours, reconciliation closure within 24 hours, facility incidents logged within 1 hour) and KPI monitoring protocols.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs; recruited committee members (systems architects, node operators, cryptographers, cleared).

**Suggested Timeframe:** Month 8 (2027-06-12) to Month 9 (2027-07-12 to 2027-07-12); committee operational and ledger systems live by Month 9 (2027-07-12), Day 1.

**Key Outputs/Deliverables:**

- Named Evidence and Ledger Integrity Committee members with appointed roles and authorities
- Ledger Operational Procedures: hourly hash-chain checkpoint validation, signed checkpoint format, divergence-detection algorithms, reconciliation procedures
- KPI monitoring protocols (synchronization ≤1 hour, divergence detection ≤4 hours, reconciliation ≤24 hours, facility incidents ≤1 hour logging)
- Equipment-identity-confidence scoring methodology and escalation to unverifiable status when confidence falls below 95% (proposed threshold)
- Schedule-versioning and double-key update procedures for covered-equipment classification

**Dependencies:**

- Ledger system design and architecture finalized
- Cryptographic checkpoint format and transport security implemented
- Neutral-party custodian escrow agreement signed
- Ledger nodes deployed and synchronized for testing

### 28. Formally establish the Vendor and Operator Binding and Compliance Unit, confirming Vendor and Operator Liaison Director, national Binding and Compliance Leads, Accredited Examiner and Clean-Room Lead (per country) and Attestation-Key Validation Specialist. Confirm all vendor-binding agreements are signed and enforce compliance with verification duties. Certify clean-room examination centers operational.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs; recruited vendor-binding unit members (cleared, contracts specialists, technical examiners).

**Suggested Timeframe:** Month 8 (2027-06-12) to Month 9 (2027-07-12 to 2027-07-12); unit operational and all vendor binding confirmed by Month 9 (2027-07-12), Day 1.

**Key Outputs/Deliverables:**

- Named Vendor and Operator Liaison Director (bilateral accountability) with national leads
- Confirmed pre-qualified vendor registry roster (all critical vendors on registry with signed binding agreements)
- Supply-chain consequence policy enforcement (refusers denied supply-chain access or escalated to clean-room testing)
- Accredited clean-room examination centers (≥1 per country) certified operational and ready to accept refusing vendors' equipment
- Attestation-key validation result summary: all critical vendors' cryptographic keys validated by independent examiners or flagged for Month 10 (2027-08-12) unverifiable status

**Dependencies:**

- Vendor-binding agreements drafted and signed
- Clean-room facilities constructed and security-hardened
- Accredited-examiner vetting and protocols published

### 29. Formally establish the Threshold Calibration and Verdict Panel (bilateral lead, 1 specialist per country). Confirm members and freeze the pre-registered threshold table by bilateral signature. Establish sealed independent-score storage and comparison protocols. Train panel on evidence-sufficiency analysis and thresholds-to-verdict mapping.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs; recruited Threshold Calibration Panel members (technical specialists, cleared, independent).

**Suggested Timeframe:** Month 8 (2027-06-12) to Month 9 (2027-07-12 to 2027-07-12); panel operational and thresholds frozen (by Month 10.5 = 2027-08-27) with interim confirmation by Month 9 (2027-07-12).

**Key Outputs/Deliverables:**

- Named Threshold Calibration and Verdict Panel members with independence attestation
- Frozen threshold table (by Month 10.5, 2027-08-27) signed by bilateral members: Go criteria (detection ≥90%, identity >95%, unverifiable ≤3%, parity ±10%), Modify, Stop
- Sealed independent-score process: each national team scores evidence independently and sealed; scores compared at Month 11.75 (2027-10-05) with divergence magnitude reported
- Training documentation for evidence-sufficiency analysis and verdict-mapping rules

**Dependencies:**

- Pre-registered threshold table published and validated
- Challenge-exercise design finalized
- Early blind-exercise data available for calibration (if scheduled before freeze)

### 30. Formally establish the Independent Testing, Challenge Exercise and Red Team Unit, confirming Independent Testing Director (bilateral), US and China Red Team Leads, Detection-Measurement Analysts and Filter-Adequacy Testers. Publish sealed challenge-exercise catalog (hash-committed, 70 scenarios ≥10 per event type), exercise-injection timeline (calibration Months 9.5-10.5 = 2027-07-27 to 2027-08-27, scored Months 10.5-11.5 = 2027-08-27 to 2027-09-27), and CHALLENGE-tagging partition protocol confirming exercises cannot trigger suspension or KPI violations.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs; recruited testing unit members (cleared, scenario designers, red-team operational leads).

**Suggested Timeframe:** Month 8 (2027-06-12) to Month 9 (2027-07-12 to 2027-07-12); unit operational and sealed scenario catalog published by Month 9 (2027-07-12), Day 0 (before Phase One clock starts).

**Key Outputs/Deliverables:**

- Named Independent Testing Director (bilateral) and Red Team Leads (US and China) with operational authorities
- Hash-committed sealed challenge-scenario catalog (70 scenarios: ≥10 each for 7 event types), published and locked before Phase One
- Exercise-injection schedule: calibration exercises Months 9.5-10.5 (2027-07-27 to 2027-08-27), unscored; scored exercises Months 10.5-11.5 (2027-08-27 to 2027-09-27)
- CHALLENGE-tagging partition protocol: every injected scenario tagged CHALLENGE in the ledger before injection; tagged events excluded from triggering suspension, impaired-confidence review or KPI violations
- Misclassification escalation rule: if a CHALLENGE-tagged exercise is mistakenly flagged as operational and triggers suspension, automatic escalation to principals within 2 hours with reinstatement pending adjudication

**Dependencies:**

- Challenge-scenario design and hash-commitment complete
- Ledger CHALLENGE-tagging infrastructure and partition rules implemented
- Co-chairs authorized to exclude exercises from suspension triggers

### 31. Conduct opening-inventory baseline collection and sealing during Days 1-5 of Phase One (Month 9 = 2027-07-12). Deploy joint mirrored teams to each of the four declared sites to count and verify covered-equipment categories within declared zones (staging, spare-inventory, maintenance, expansion areas). Seal and sign the baseline ledger entry with bilateral co-chair confirmation. No challenge exercises or equipment movements during baseline Days 1-5.

**Responsible Body/Role:** Project Management Office and Operational Execution Team (Program Director, Site Operations Managers); mirrored inspection teams (US and China) at each site.

**Suggested Timeframe:** Month 9 (2027-07-12), Days 1-5 (2027-07-12 to 2027-07-17); baseline sealing completed and ledger entry signed by Month 9 (2027-07-12), Day 5.

**Key Outputs/Deliverables:**

- Opening-Inventory Baseline Count Report for each of 4 sites: equipment categories, serial numbers or identifiers, location within declared zones, cryptographic attestation digest, baseline sealed date/time
- Bilateral co-chair signature on baseline ledger entry
- Baseline-change reconciliation log (any discrepancies between observers resolved before seal)
- Confirmation that Days 1-5 baseline work did not trigger any challenge exercises or include equipment movements

**Dependencies:**

- Phase One clock started and entry gate certified
- Mirrored teams deployed and operational
- Covered-equipment schedule published
- Intake protocols and baseline-counting procedures finalized

### 32. Execute Monthly Decision and Oversight Cadence: co-chairs convene on the 1st of each month (Months 9, 10, 11, 12 = 2027-07-12, 2027-08-12, 2027-09-12, 2027-10-12) to review KPI dashboard, approve budget draws >USD 10M, authorize personnel assignments and surge staffing, evaluate escalated site findings, receive CI briefings and manage contingency allocation. All decisions and deadlocks recorded in the tamper-evident ledger.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs (formally convened); Project Management Office, Evidence and Ledger Integrity Committee, Counterintelligence Oversight Unit, Vendor and Operator Binding Unit provide briefing materials.

**Suggested Timeframe:** Monthly formal sessions: Months 9, 10, 11, 12 (2027-07-12, 2027-08-12, 2027-09-12, 2027-10-12); plus weekly informal reviews during Phase One.

**Key Outputs/Deliverables:**

- Monthly Co-Chair Decision Minutes documenting: KPI results (detection rates, identity confidence, parity variance, ledger sync, unresolved discrepancies), budget-burn status and tranche-release authorizations, approved personnel assignments and surge staffing, escalated site findings and deadlock resolutions, CI and facility security briefings, contingency allocation decisions
- Any budget draws approved with bilateral signature and ledger entry
- Escalation decisions and escalation timers started (5/8/13-day sequence for deadlocked disputes)
- Monthly KPI dashboard published with all metrics, thresholds and status

**Dependencies:**

- Bilateral Steering Committee governance framework and decision rules established
- KPI targets and monthly reporting protocols finalized
- Co-chair informal-review schedule (weekly) and emergency-escalation triggers defined

### 33. Execute Calibration Exercise Phase (Months 9.5-10.5 = 2027-07-27 to 2027-08-27): Independent Testing Unit injects unscored blind scenarios in staging, spare-inventory, maintenance and expansion areas to establish baseline detection rates and false-positive/negative rates under realistic filtering and inspector presence. No scoring against Go/Modify/Stop thresholds during calibration; results inform Threshold Calibration Panel's recommendation for threshold adjustments if empirical data diverges >10% from provisional assumptions.

**Responsible Body/Role:** Independent Testing Director and Red Team Leads; Detection-Measurement Analysts; mirrored inspectors at each site.

**Suggested Timeframe:** Months 9.5-10.5 (2027-07-27 to 2027-08-27); calibration-exercise summary published by Month 10.5 (2027-08-27).

**Key Outputs/Deliverables:**

- Calibration-Exercise Injection Log: scenario type, injection timing, site, whether detected by inspectors, false-positive incidents, detection latency
- Baseline detection rate and false-positive/negative rate by event type (7 types)
- Filter-adequacy assessment: evidence-schema field preservation under operator redaction, any schema fields stripped (escalation trigger)
- Threshold-calibration recommendation: if empirical detection rate diverges >10% from provisional assumption (e.g., 85% detected vs. 90% assumed), Threshold Calibration Panel recommends threshold adjustment

**Dependencies:**

- Sealed challenge-scenario catalog published and tagged CHALLENGE
- Mirrored inspectors trained on blind-exercise partition (exercises don't trigger suspension)
- Filter-adequacy pre-test complete and filters validated
- Detection-measurement protocols established

### 34. Freeze all Go, Modify and Stop thresholds by Month 10.5 (2027-08-27) following bilateral Threshold Calibration Panel review of early calibration-exercise data. Both national specialists must sign off on final thresholds; disagreement escalates to co-chairs for decision. Thresholds cannot be changed after freeze except by bilateral co-chair amendment, which is recorded in the ledger.

**Responsible Body/Role:** Bilateral Threshold Calibration and Verdict Panel members; Bilateral Steering Committee co-chairs if disagreement.

**Suggested Timeframe:** Month 10.5 (2027-08-27); threshold-freeze meeting convened and decision published by Month 10.5 (2027-08-27), Day 15.

**Key Outputs/Deliverables:**

- Frozen Threshold Table: final Go criteria (detection ≥X%, identity confidence >X%, unverifiable ≤X%, parity variance ±X%), Modify and Stop criteria, signed by bilateral panel members
- Threshold-adjustment documentation: calibration-exercise findings, any divergence from provisional assumptions, recommended adjustments, reason for each adjustment
- If disagreement: disputed threshold(s) escalated to co-chairs with both panel members' recommendations; co-chair decision published and recorded in ledger
- Confirmation: thresholds are now frozen and cannot be changed except by bilateral amendment (recorded in ledger)

**Dependencies:**

- Calibration-exercise data available and summarized
- Threshold Calibration Panel review completed
- Co-chairs prepared to resolve any disagreement on freeze decision

### 35. Execute Scored Exercise Phase (Months 10.5-11.5 = 2027-08-27 to 2027-09-27): Independent Testing Unit injects sealed blind scenarios from the hash-committed catalog in staging, spare-inventory, maintenance and expansion areas. Each national team's Detection-Measurement Analyst independently and sealed scores whether each scenario was detected. Results are recorded in the ledger with CHALLENGE tags and tracked by event type, false-positive/negative rate.

**Responsible Body/Role:** Independent Testing Director and Red Team Leads; Detection-Measurement Analysts (per country, independent scoring); mirrored inspectors at each site.

**Suggested Timeframe:** Months 10.5-11.5 (2027-08-27 to 2027-09-27); scored-exercise summary and sealed-score data delivered to Threshold Calibration Panel by Month 11.75 (2027-10-05).

**Key Outputs/Deliverables:**

- Scored Exercise Injection Log: scenario type, injection date, site, detection outcome (detected/missed by inspectors), false-positive incidents, detection latency
- Sealed independent-score sheets from US and China teams: detection results by event type, summarized detection rate per event type and overall (proposed target ≥90%)
- Event-type-specific false-positive/negative rate
- Filter-adequacy assessment during scored exercises: evidence-schema field preservation, any schema stripping (escalation)
- Summary statistics ready for sealed-score comparison at Month 11.75 (2027-10-05)

**Dependencies:**

- Thresholds frozen by Month 10.5 (2027-08-27)
- Sealed challenge-scenario catalog locked and tagged CHALLENGE
- Mirrored inspectors trained on partition and scoring rules
- Ledger CHALLENGE-tagging infrastructure operational

### 36. Conduct sealed independent-score comparison at Month 11.75 (2027-10-05): Threshold Calibration Panel compares US and China's sealed detection scores by event type and overall. Measure scoring divergence; divergence >10 percentage points is documented but both scores are treated as valid assessments. Prepare joint evidence-mapping analysis showing how detection results and other KPI metrics (identity confidence, parity variance, unverifiable count, ledger sync) map to Go, Modify, Stop verdict criteria.

**Responsible Body/Role:** Bilateral Threshold Calibration and Verdict Panel members; Detection-Measurement Analysts from each country (sealed scores unsealed only at comparison meeting).

**Suggested Timeframe:** Month 11.75 (2027-10-05); sealed-score comparison meeting and verdict-evidence analysis completed by Month 11.75 (2027-10-05), Day 15.

**Key Outputs/Deliverables:**

- Sealed-Score Comparison Report: US team detection rate by event type vs. China team detection rate, overall divergence magnitude, assessment of causes (filter differences, inspector training, site differences)
- Joint Evidence-Mapping Analysis: how all KPI metrics (detection ≥90%, identity >95%, unverifiable ≤3%, parity ±10%, ledger sync ≤1 hour, no unresolved discrepancies >15 days) align with Go (all green), Modify (some correctable) and Stop (any red) verdicts
- Sealed-Score Comparison Minutes documenting any disagreement and both national assessments
- Preliminary verdict recommendation for co-chairs: 'Evidence Supports Go / Modify / Stop Criteria'

**Dependencies:**

- Scored exercises complete and sealed scores delivered
- Thresholds frozen and final KPI values established
- All Phase One operational data (KPIs, escalations, incidents) collected and verified

### 37. Hold the final co-chair Bilateral Steering Committee session at Month 12 (2027-10-12) to receive the Threshold Calibration Panel's evidence-mapping analysis and sealed-score comparison. Review all operational KPI results, any outstanding escalations or unresolved discrepancies, and facility security briefing. Co-chairs jointly decide Go, Modify or Stop verdict based on evidence presented.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs (formally convened); Threshold Calibration Panel, Project Management Office, Evidence and Ledger Integrity Committee, Counterintelligence Oversight Unit provide briefing materials.

**Suggested Timeframe:** Month 12 (2027-10-12); co-chair verdict decision convened and published by Month 12.25 (2027-10-20).

**Key Outputs/Deliverables:**

- Final Co-Chair Verdict Minutes documenting: Threshold Calibration Panel evidence-mapping analysis, sealed-score comparison (divergence magnitude reported), all Phase One KPI results (detection, identity confidence, parity variance, ledger sync, unresolved discrepancies), outstanding escalations (if any) and their status, CI and facility-security briefing summary
- Bilateral co-chair Go / Modify / Stop Verdict Decision, jointly signed by both co-chairs
- Verdict Justification Document: evidence supporting the decision, with reference to frozen thresholds and sealed-score data
- Verdict Publication and Post-Phase-One Recommendation (if applicable): Go → proceed to Phase Two or continuation negotiations; Modify → identify corrective actions and re-test timeline; Stop → documented reasons for termination

**Dependencies:**

- Sealed-score comparison complete by Month 11.75 (2027-10-05)
- All Phase One operations and data collection complete
- Outstanding escalations resolved or documented as unresolved
- Co-chairs authorized to issue binding verdict

### 38. Publish final Phase One Operational Report and KPI Dashboard summarizing 90-day test results: detection rates by event type, identity-confidence metrics, parity variance, ledger synchronization performance, unverifiable-equipment counts, unresolved-discrepancy age, vendor-refusal outcomes, IP/cybersecurity incidents, budget burn and contingency spend, and audit exceptions. Mark all unsupported or provisional figures as such. Conclude Go, Modify or Stop and state that success covers only monitored changes at participating declared sites.

**Responsible Body/Role:** Project Management Office and Operational Execution Team (Program Director); supported by all governance committees (Evidence and Ledger, Counterintelligence, Threshold Calibration, Independent Testing, Vendor and Operator Binding).

**Suggested Timeframe:** Month 12.25 (2027-10-20); final report published within 10 days of co-chair verdict decision.

**Key Outputs/Deliverables:**

- Phase One Operational Report: KPI dashboard with all metrics (detection rates, identity confidence, parity variance, ledger sync, discrepancy age, vendor refusals, unverifiable equipment, cybersecurity incidents, funding timeliness)
- Sealed-score comparison summary and voting divergence (if any)
- Vendor-refusal outcomes and clean-room testing results
- Exit-disposition evidence ladder results (witnessed destruction, permanent disablement, transfers, releases beyond boundary, unresolved)
- Contingency-spend accounting and parity-divergence summary
- CI briefing summary and facilities security incident log
- Conclusion: Go (reciprocal access and credible detection demonstrated) / Modify (correctable weaknesses identified) / Stop (asymmetric access, unverifiable equipment, shielded operator, diverged ledger, withheld funding) with explicit statement that success covers only monitored changes at participating declared sites

**Dependencies:**

- Co-chair verdict decision published
- All Phase One data collection and KPI calculation complete
- Audit exception log from independent auditor delivered
- All governance committees' final briefing materials consolidated

# Decision Escalation Matrix

**Budget Request Exceeding Co-Chair Authority**
Escalation Level: Bilateral Steering Committee Co-Chairs
Approval Process: Co-chairs convene within 24 hours. Joint review of request and documented justification. Bilateral consensus required; no casting vote. If deadlocked, escalation to principals within 5 days with mandatory decision.
Rationale: Budget draws above USD 10 million require double-key authorization and verified parity accounting. Single-country or unilateral spending threatens the 50/50 governance model and can trigger impaired-confidence review if cumulative divergence exceeds ±10% of pro-rata share.
Negative Consequences: Unresolved budget disputes age, consuming contingency without authorization. Spending parity divergence exceeds 15% monthly threshold, triggering impaired-confidence review. Contingency exhaustion by Month 2 (2026-12-12) forces scope cuts or Phase One curtailment. Reputational damage: program appears unequal or one side appears to be looting the budget.

**Critical Vendor Refusal or Attestation-Key Compromise**
Escalation Level: Vendor and Operator Binding and Compliance Unit, then Bilateral Steering Committee Co-Chairs if unresolved
Approval Process: Vendor-binding unit assesses refusal outcome and proposes disposition: vendor-supervised testing, filtered evidence, accredited clean-room examination, or unverifiable status. If refusal handling diverges between countries, escalation to co-chairs within 5 days. Co-chairs authorize disposition or escalate to principals if equipment represents >3% of site and material status is disputed.
Rationale: Vendor refusal or attestation-key compromise renders equipment identity unverifiable. Concentration in 3–4 critical vendors means 10–40% of declared equipment could become unverifiable. Vendor binding must be complete before entry gate. Unresolved vendor status becomes a Stop criterion if material equipment count exceeds 3% per site.
Negative Consequences: Unverifiable equipment accumulates above 3% threshold per site, triggering automatic site failure. One or more declared sites fail Phase One outright, blocking Go decision. Vendor escalations consume 2–4 weeks per dispute; sunk cost USD 50–100 million if litigation required. Estimated 10–40% of declared equipment unverifiable depending on vendor mix, rendering Phase One verdict inconclusive or reversed.

**Deadlocked Co-Chair Disagreement on Site Finding or Equipment Identity**
Escalation Level: Bilateral Technical Referees Panel (within 24 hours); if unresolved, Principal-Level Review (within 2 days)
Approval Process: Co-chair deadlock (no consensus within 5 days) automatically triggers referees within 24 hours. Referees issue dual-signed advisory fact statement within 3 days or escalate to principals. If principals cannot agree within 5 calendar days, status quo defaults to heightened inspection (not suspension) while further escalation continues. All escalation steps recorded in ledger with timestamps.
Rationale: No casting vote and double-key requirement create structural deadlock risk. Unresolved findings on equipment identity or site suspension can age indefinitely, weaponizing delay as obstruction. Enumerated objective triggers (unverifiable >3%, divergence >5%, denial >15%, age >15 days) and fixed escalation timers prevent infinite stalling and force decision.
Negative Consequences: Contested findings age to 15+ days without resolution, triggering Stop criterion even if technical facts are minor. A single manufactured-incident false positive cascades into suspension, losing 3–7 days of operational work and consuming 2–8 weeks per escalated dispute. Unresolved discrepancy age becomes a KPI tracked daily; aging findings erode credibility of Go verdict and feed political allegations of obstruction or bad faith.

**Ledger Divergence Between National Copies or Synchronization Latency Exceeding 4-Hour KPI**
Escalation Level: Evidence and Ledger Integrity Committee, then Bilateral Steering Committee Co-Chairs if divergence unresolved >8 hours
Approval Process: Divergence detected within 4 hours (proposed KPI). Both ledger operators independently review diverged events and reconcile within 24-hour closure deadline. If cause is clear (late-arriving event, corrected entry), reconciliation is logged and closed. If cause is unclear or disputed, escalation to co-chairs with both operators' independent assessments. Unresolved divergence >10 days triggers impaired-confidence review and potential automatic suspension.
Rationale: Ledger integrity is the sole evidentiary foundation for the Go verdict. Divergence between national cryptographic copies creates ground-truth ambiguity. Synchronization latency >4 hours (proposed threshold) extends the window during which one side could alter records. Unresolved divergence is listed as a Stop criterion; rapid detection and bounded reconciliation are essential.
Negative Consequences: Divergence detection latency exceeds 4-hour KPI; contested findings age without ground truth for 12+ hours. Per-incident delay 1–3 days; if >5 discrepancies per site per week, formal review triggered and impaired-confidence automatic. If divergence age exceeds 15 days, automatic site suspension without co-chair discretion and Stop criterion triggered. Reputational damage: program's evidence system discredited, Go verdict reversed or replaced with Stop.

**Equipment Identity Confidence Falls Below 95% Threshold or Attestation Validation Fails**
Escalation Level: Bilateral Technical Referees Panel (for identity disputes); Vendor and Operator Binding Unit (for attestation validation); Bilateral Steering Committee Co-Chairs if material
Approval Process: Equipment approaching unverifiable threshold (confidence <95% proposed) flagged by Evidence and Ledger Integrity Committee. If identity corroboration is disputed (e.g., attestation timestamp misaligned with customs entry), referees review layered evidence and issue fact statement within 3 days. If attestation cannot be validated by Month 10 (2027-08-12) (proposed deadline), vendor's equipment automatically escalated to unverifiable status. If unverifiable count reaches >3% of site, automatic escalation to co-chairs for site-failure determination.
Rationale: Identity confidence >95% (proposed threshold) is a Go criterion. Cryptographic attestation is the primary anchor but requires independent validation; no single evidence layer is decisive. Two-layer mismatch triggers referee review. Layering resilience against vendor-key compromise or forged attestation is essential. Unverifiable >3% per site becomes material and fails the site outright.
Negative Consequences: Identity confidence drops to 80–85%, equipment escalated to unverifiable status for 5–10% of units per site. Equipment identity disputes escalate to referees, consuming 3–5 days per incident. Unverifiable count accumulates to >3% threshold, triggering automatic site failure and Stop decision. Estimated 2–4 week delay per escalation; reputational cost if substitution is later discovered post Phase One.

**Reciprocal-Access Parity Variance Exceeds 15% or Unexplained Denials >5 per Month**
Escalation Level: Project Management Office and Operational Execution Team (reason-code review within 24 hours); Bilateral Steering Committee Co-Chairs if variance >15% sustained
Approval Process: Each access denial logged in ledger with reason code and timestamp. Denials >tolerance (proposed ±10% variance) require explanation within 24 hours. Unexplained denials >5 per month or variance >15% for 2 consecutive weeks trigger escalation to co-chairs. Co-chairs review reason codes and authorize corrective action or escalate to principals for parity-threshold amendment.
Rationale: Reciprocal access parity is a Go criterion and feeds Stop decision if asymmetric. Matched sites differ in operator responsiveness, logistics speed and operational disruptions, making parity disputes likely. Reason codes and trip points keep denials auditable. >15% sustained variance suggests systemic access obstruction by one side, indicating bad faith or shielded operators.
Negative Consequences: Parity disputes age without resolution, consuming 1–2 weeks per major escalation. Denials exceed threshold, triggering impaired-confidence review and potential operational halt (3–5 days per incident). Estimated 10–20% of Phase One time consumed in parity adjudication. If parity variance >15% at verdict, asymmetric access becomes Stop criterion and Go decision blocked.

# Monitoring Progress

### 1. Key Performance Indicator (KPI) Tracking Against Project Targets
**Monitoring Tools/Platforms:**

  - Monthly KPI Dashboard (reconciled by Evidence and Ledger Integrity Committee)
  - Sealed Independent-Score Tracking (Threshold Calibration Panel)
  - Equipment-Identity Confidence Spreadsheet (Evidence and Ledger Integrity Committee)
  - Ledger Synchronization and Divergence Log (Ledger Node Operators)

**Frequency:** Daily operational KPI tracking; weekly informal co-chair review; monthly formal co-chair decision session (1st of each month)

**Responsible Role:** Evidence and Ledger Integrity Committee (daily collection); Project Management Office (aggregation); Bilateral Steering Committee Co-Chairs (monthly formal review and threshold-sufficiency assessment)

**Adaptation Process:** Monthly co-chair decision sessions review KPI results (detection rates, identity confidence, parity variance, ledger sync latency, unverifiable-equipment count, unresolved-discrepancy age) against frozen thresholds. KPI shortfalls >5 percentage points from threshold trigger investigation and corrective-action assignment. If a KPI breaches threshold (e.g., identity confidence drops below 95%, unverifiable exceeds 3%, parity variance exceeds 15%), automatic escalation to co-chairs within 2 hours with recommended mitigation (staffing surge, filter renegotiation, site access rebalancing). Adaptation decisions recorded in ledger with bilateral sign-off.

**Adaptation Trigger:** Monthly: Any KPI result diverges >5 percentage points from target; Daily: identity confidence <95%, unverifiable >3%, parity variance >15%, ledger sync >4 hours, unresolved discrepancy >10 days. Immediate escalation if auto-suspension threshold is approached (5 consecutive days of unverifiable >3%, divergence >5%, denial >15% for 2 consecutive weeks).

### 2. Critical Success Factor Monitoring: Equipment Identity Confidence and Attestation Validation
**Monitoring Tools/Platforms:**

  - Attestation-Key Validation Confidence Log (Vendor and Operator Binding Unit)
  - Identity Corroboration Analysis Spreadsheet (Bilateral Technical Referees Panel)
  - Equipment Classification and Unverifiable Status Tracker (Evidence and Ledger Integrity Committee)

**Frequency:** Real-time tagging at intake; daily escalation of units approaching unverifiable status (identity confidence trending below 95%); weekly summary to co-chairs; mandatory checkpoint at Month 10 (2027-08-12) for all vendor attestations

**Responsible Role:** Vendor and Operator Binding and Compliance Unit (attestation validation); Bilateral Technical Referees Panel (identity dispute resolution); Evidence and Ledger Integrity Committee (confidence scoring and escalation)

**Adaptation Process:** Equipment identity confidence is scored at intake and maintenance events on a scale of 0-100%. Units below 95% are flagged and corroboration layers reviewed (attestation, customs records, physical marks). If two independent layers cannot validate identity (e.g., attestation timestamp misaligned with customs entry by >2 hours), escalation to Bilateral Technical Referees panel within 24 hours. Referees issue dual-signed fact statement within 3 days confirming identity or classifying unit as unverifiable. If unverifiable count per site reaches 3%, automatic escalation to co-chairs for site-failure determination. Attestation keys unvalidated by Month 10 (2027-08-12) automatically escalate all equipment from that vendor to unverifiable status.

**Adaptation Trigger:** Identity confidence <95% on any unit; attestation validation failure or timeout at Month 10 (2027-08-12); two-layer corroboration mismatch; unverifiable count reaching 3% of declared units per site (material threshold, automatic site failure).

### 3. Critical Success Factor Monitoring: Blind Detection Capability and Challenge Exercise Results
**Monitoring Tools/Platforms:**

  - Sealed Challenge-Scenario Catalog (hash-committed before Phase One)
  - Blind-Exercise Injection and Detection Log (Independent Testing Unit)
  - Detection-Rate Summary by Event Type (Detection-Measurement Analysts per country)
  - Sealed Independent-Score Sheets (Threshold Calibration Panel)

**Frequency:** Calibration exercises (Months 9.5-10.5 = 2027-07-27 to 2027-08-27): daily injection and response tracking; unscored preliminary summary weekly. Scored exercises (Months 10.5-11.5 = 2027-08-27 to 2027-09-27): daily injection and detection tracking; sealed scores submitted end of each week. Sealed-score comparison at Month 11.75 (2027-10-05); final verdict-mapping analysis before Month 12.25 (2027-10-20) decision

**Responsible Role:** Independent Testing Director and Red-Team Leads (injection and scenario management); Detection-Measurement Analysts per country (blind-scenario detection tracking and sealed scoring); Threshold Calibration and Verdict Panel (score comparison and verdict-evidence mapping)

**Adaptation Process:** Calibration exercises (unscored) measure baseline detection rates by event type (7 types: unreported arrival, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal, reluctant operator). If calibration detection rate diverges >10 percentage points from provisional assumption (e.g., 80% actual vs. 90% assumed), Threshold Calibration Panel recommends threshold adjustment. Thresholds frozen by Month 10.5 (2027-08-27) before scored exercises begin. Scored exercises (Month 10.5-11.5 = 2027-08-27 to 2027-09-27) test against frozen thresholds (>=90% detection per event type for Go). Each national team independently and sealed scores detection outcomes. Divergence >10 percentage points between national scores is documented but both scores treated as valid; divergence itself becomes a transparency metric reported alongside verdict. If detection rate <85% in calibration exercises, investigation of filter adequacy or inspector presence issues; corrective action required or Phase One delayed.

**Adaptation Trigger:** Calibration-exercise detection rate <85% per event type (halt scored exercises for filter or training remediation); scored-exercise detection rate <90% per event type at Month 11.75 (2027-10-05) (Modify or Stop verdict); sealed-score divergence >10 percentage points (transparency metric, escalate if divergence reflects systemic difference in inspector training or filter application).

### 4. Critical Success Factor Monitoring: Reciprocal Access Parity
**Monitoring Tools/Platforms:**

  - Reciprocal-Access Denial and Delay Log (Project Management Office, tagged by reason code)
  - Site-Equivalent Activity Accounting by Matched Pair (Bilateral Operations Directors)
  - Monthly Parity-Variance Report (Project Management Office to co-chairs)

**Frequency:** Real-time denial logging at point of request; reason-code explanation required within 24 hours if denial exceeds tolerance. Weekly parity-variance summary by matched-site pair; monthly formal parity-variance review by co-chairs. Trip-point review within 48 hours if variance >15% or unexplained denials >5 per month

**Responsible Role:** Project Management Office and Operational Execution Team (daily access-request tracking and reason-code collection); Bilateral Operations Directors (weekly parity-variance analysis); Bilateral Steering Committee Co-Chairs (monthly formal review and trip-point authorization)

**Adaptation Process:** Each access request (inspector hours, staging-area inspections, evidence access, equipment-movement authorization) is logged in the ledger with accept/deny outcome and reason code. Denials within tolerance (proposed: +/-10% variance between matched sites) require explanation within 24 hours. If denials exceed tolerance (>15% variance sustained for 2 consecutive weeks, or >5 unexplained denials per month), escalation to co-chairs within 48 hours. Co-chairs review reason codes and authorize corrective action: rebalance inspection schedule, resolve operational bottleneck, or escalate to principals for parity-threshold amendment. Disputed denials (one country claims justified, other disputes) go to Bilateral Technical Referees panel for fact statement. Sustained parity variance >15% at Month 12 (2027-10-12) becomes a Stop-criterion candidate (asymmetric access).

**Adaptation Trigger:** Monthly parity variance >10% (tolerance band exceeded, requires explanation); >15% sustained for 2 consecutive weeks (automatic impaired-confidence review trigger); >5 unexplained denials per month (escalation to co-chairs within 48 hours); any denial with no acceptable reason-code within 24 hours (escalation to bilateral operations directors).

### 5. Critical Success Factor Monitoring: Ledger Divergence and Evidence Integrity
**Monitoring Tools/Platforms:**

  - Ledger Synchronization Checkpoint Log (hourly signed hash-chain validation by Ledger Node Operators)
  - Divergence Detection and Reconciliation Tracker (Evidence and Ledger Integrity Committee)
  - Neutral-Party Digest Custodian Archive (offline backup and forensic-recovery escrow)

**Frequency:** Hourly signed checkpoint validation; divergence detection within 4-hour KPI latency; reconciliation closure attempt within 24 hours. Daily ledger health check (15 minutes); weekly divergence-reconciliation review if any divergences occurred; emergency escalation within 2 hours if latency exceeds 4-hour KPI or sync latency exceeds 1 hour

**Responsible Role:** US and China Ledger Node Operators (checkpoint validation and local event recording); Divergence Reconciliation Lead (bilateral reconciliation authority); Evidence and Ledger Integrity Committee (daily oversight and KPI monitoring)

**Adaptation Process:** Each national ledger copy records events locally with immediate timestamp. Signed hash-chain checkpoints are exchanged hourly. On divergence detection (within 4-hour window), both operators independently review diverged events and attempt reconciliation within 24-hour deadline. If cause is clear (late-arriving event, corrected entry), reconciliation is logged and closed. If cause is unclear or disputed, unresolved status is recorded and escalated to co-chairs with both operators' independent assessments. Facility incidents (power loss, access anomalies, personnel changes) are logged in the ledger within 1 hour and trigger Facility Security Review Panel investigation within 4 hours. Unresolved divergence >10 days automatically triggers impaired-confidence review and potential site suspension; >15 days becomes a Stop-criterion candidate.

**Adaptation Trigger:** Synchronization latency exceeds 1 hour (alert); divergence detection exceeds 4-hour KPI (escalate to co-chairs and Facility Security Panel); reconciliation not closed within 8 hours (escalate to co-chairs); unresolved divergence >5 discrepancies per site per week (formal reconciliation review); unresolved divergence age >10 days (automatic impaired-confidence review); >15 days (Stop criterion triggered without bilateral principal override).

### 6. Risk Monitoring: Vendor Refusal and Equipment Unverifiability
**Monitoring Tools/Platforms:**

  - Pre-Qualified Vendor Registry and Refusal Tracking (Vendor and Operator Binding Unit)
  - Attestation-Validation Result Summary (Accredited Examiners, both countries)
  - Clean-Room Examination Testing Queue and Outcomes (Vendor and Operator Binding Unit)

**Frequency:** Vendor refusal events logged immediately; escalation within 24 hours to Vendor and Operator Binding Unit and bilateral co-chairs within 5 days. Attestation-validation checkpoint at Month 10 (2027-08-12) (mandatory validation deadline). Weekly vendor-compliance review (Months 7-8 = 2027-05-12 to 2027-06-12 preparation phase); immediate escalation meetings if a vendor refuses or operator consent is withdrawn

**Responsible Role:** Vendor and Operator Binding and Compliance Unit (vendor-refusal assessment and escalation); Accredited Examiners (attestation validation and confidence reporting); Bilateral Steering Committee Co-Chairs (refusal-handling authorization if disagreement between countries)

**Adaptation Process:** Vendor refusal or attestation-key compromise is escalated to Vendor and Operator Binding Unit within 24 hours. Unit proposes disposition: vendor-supervised testing, filtered evidence, accredited clean-room examination, validated attestation, or unverifiable status. If refusal handling diverges between countries (one recommends clean-room, other recommends unverifiable), escalation to co-chairs within 5 days. Co-chairs authorize disposition or escalate to principals. Clean-room examination centers accept refusing vendors' equipment for supervised testing without exposing source code. If attestation keys cannot be independently validated by Month 10 (2027-08-12), all equipment from that vendor automatically escalates to unverifiable status. If unverifiable count reaches >3% of a site's declared equipment, automatic site failure and Stop decision.

**Adaptation Trigger:** Vendor refusal or attestation-validation failure (immediate escalation to Vendor and Operator Binding Unit and co-chairs within 24 hours); refusal-handling disagreement between countries (co-chair decision required within 5 days); attestation unvalidated by Month 10 (2027-08-12) deadline (automatic unverifiable status); unverifiable equipment exceeding 3% per site (automatic site failure, Stop criterion).

### 7. Risk Monitoring: Deadlock and Unresolved Discrepancies (Governance Gridlock)
**Monitoring Tools/Platforms:**

  - Co-Chair Deadlock and Escalation Log (Bilateral Steering Committee)
  - Unresolved-Discrepancy Age Tracker (Project Management Office, daily age calculation)
  - Escalation Timer Status Report (Project Management Office)

**Frequency:** Contested findings logged immediately; deadlock status tracked from Day 1 through Day 5 (co-chair consensus window). Automatic escalation timer initiated at Day 5 if no consensus. Weekly unresolved-discrepancy age report to co-chairs (items >5 days, >10 days, >15 days flagged separately). Escalation-timer dashboard refreshed daily during Phase One

**Responsible Role:** Project Management Office (contested-finding logging and age tracking); Bilateral Steering Committee Co-Chairs (deadlock resolution, Days 1-5); Bilateral Technical Referees Panel (fact-statement generation, Days 5-8); Principal-Level Review (final decision, Days 8-13)

**Adaptation Process:** When co-chairs cannot reach consensus on a site finding or equipment-identity ruling within 5 days, automatic escalation to Bilateral Technical Referees panel within 24 hours (Day 6). Referees review sealed evidence and issue dual-signed advisory fact statement within 3 days (by Day 8). If referees reach consensus, fact statement goes back to co-chairs; if not, unsigned draft with both assessments escalates to principals. Principals must render a decision within 5 calendar days (by Day 13) or status quo defaults to heightened inspection (not suspension) while escalation continues. Unresolved discrepancies are tracked and aged in the KPI dashboard. Age >10 days triggers automatic impaired-confidence review and potential site suspension; >15 days becomes a Stop-criterion candidate (findings unresolved due to procedural gridlock rather than technical merits).

**Adaptation Trigger:** Contested finding at Day 5 with no co-chair consensus (automatic escalation to referees within 24 hours); discrepancy age >10 days (automatic impaired-confidence review trigger); >15 days (Stop criterion triggered unless principals render decision within that window).

# Governance Extra

## Governance Validation Checks

1. Completeness: All core governance components are present: internal governance bodies (8 committees with documented authorities), implementation plan (45 steps with timelines and outputs), decision-escalation matrix (6 major decision types with approval workflows), monitoring progress (6 critical success factors with KPIs), and audit procedures. Missing: detailed contingency-escalation decision tree for nested principal-level conflicts (e.g., when principal A is involved in a dispute about principal B's funding decision); explicit succession and continuity rules if a co-chair is removed or incapacitated mid-Phase One; written protocols for bilateral personnel disputes (e.g., if one side's inspector is caught in misconduct).
2. Internal Consistency: Implementation Plan (Stage 3) assigns all governance bodies to roles defined in Internal Governance Bodies (Stage 2); Decision Escalation Matrix (Stage 4) specifies which bodies receive escalations (Referees, Co-Chairs, Principals) and timers align with Deadlock and Suspension Mechanics lever (5/8/13-day sequence documented in co-chair bylaws). Monitoring Progress (Stage 5) tracks outputs from all committees (ledger sync, KPI dashboards, vendor refusals, identity confidence, parity variance, discrepancy age) and feeds escalation triggers correctly. Consistency check confirms: escalation timers (5 days co-chair, 3 days referees, 5 days principals) are locked in bylaws, ledger entries, and monitoring protocols; auto-suspension triggers (unverifiable >3%, divergence >5%, denial >15%, age >15 days) are consistent across all documents. Minor discrepancy: Decision Escalation Matrix lists 'Vendor Refusal' escalation time as '5 days' but Implementation Plan specifies 'within 5 days of refusal' with principal resolution within '5 calendar days'; both are acceptable but phrasing differs.
3. Potential Gaps and Clarity Needs: (1) Compartmentation boundaries between inspectors and specialist committees (referees, calibration panel) are vague—can a compartmented site inspector consult with a referee panel member on identity issues without compromising segregation? Response needed: define 'sealed evidence review' infrastructure and inspector isolation from cross-site knowledge that referee work generates. (2) Challenge-exercise partition from operational triggers is clear for suspension and KPI breaches, but unclear if a false-positive challenge (injected scenario misclassified as operational, triggering unverifiable-equipment escalation) also triggers the Bilateral Technical Referees cascade for identity review, which could consume 8+ days of operational time. Response needed: clarify whether challenge-triggered escalations skip normal deadlock procedures or follow them. (3) Principal-level decision authority is assumed (secretary of state level, top-level equivalent) but never formally appointed, vetted for continuity, or given a written charter. Response needed: define principal composition, decision-authority scope, continuity if a principal changes administrations, and how their decisions are recorded and enforced. (4) Reconciliation of ledger divergences requires 'both operators independently assess,' but if one ledger node is physically compromised or an operator is under counterintelligence pressure to claim divergence, unilateral recusal is not addressed. Response needed: define recusal and arbitration procedures if a ledger operator is suspected of compromise or coercion. (5) Budget parity accounting flags cumulative divergence >15% monthly but does not specify who enforces a tranche hold if one side is non-compliant (co-chairs, independent auditor, or principals?). Response needed: document tranche-release blocking authority and bilateral veto right.
4. Alignment of Strategic Decisions to Governance Bodies: 'Pioneer's Gambit' strategic path selected resident mirrored teams (Inspector Presence and Rotation Model), attestation-anchored identity (Equipment Identity Trust Anchor), automatic-suspension triggers (Deadlock and Suspension Mechanics), reciprocal red-teaming (Challenge Exercise Commitment), and operator-controlled redaction (Inspection Zone Geometry). Mapping confirmed: Resident teams -> Project Management Office / Operational Execution Team (daily ops), Counterintelligence Unit (compartmentation, tenure), and staffing model (350-500 FTE); Attestation anchor -> Evidence and Ledger Integrity Committee (identity confidence scoring), Vendor and Operator Binding Unit (attestation validation), and Bilateral Technical Referees Panel (identity dispute resolution); Auto-suspension triggers -> Bilateral Steering Committee (double-key authorization of suspension), Deadlock rules (5/8/13-day escalation), and enumerated triggers (codified in bylaws); Reciprocal red-teaming -> Independent Testing Unit (scenario design, injection, sealed scoring) and Threshold Calibration Panel (evidence mapping to verdict). Governance bodies are well-aligned to strategic choices. Weakness: no designated 'Escalation Tracker' or 'Escalation Authority' role responsible for enforcing timer compliance and preventing hidden stalls at any tier; recommend explicit appointment of bilateral Escalation Coordinator (funded from personnel envelope) accountable for timer enforcement.
5. Thresholds and Delegation: Go threshold (detection >=90%, identity >95%, unverifiable <=3%, parity +/-10%) is pre-registered and frozen by Month 10.5 (2027-08-27), meeting the requirement for evidence-based verdict. Proposed thresholds are marked as such, but validation method is vague for identity-confidence scoring (no algorithm documented for how attestation + customs + physical marks combine to produce a 0-100% score) and parity-variance normalization (no formula for how 'event-matched' parity is computed across sites of different sizes). Response needed: publish identity-confidence algorithm (e.g., 'all layers in agreement = 100%; two layers diverge = escalate to referees; maximum independent confidence if referees cannot reconcile = 85%') and parity-normalization formula (e.g., 'parity = |events_granted_US_site / declared_units_US - events_granted_CN_site / declared_units_CN| ≤ 10%'). Delegation below co-chair level is appropriate: budget draws <USD 10M approved by operations directors; evidence schema changes by bilateral specialists; escalation timers managed by Escalation Coordinator (role not yet named); contingency tranche holds authorized by auditor + co-chair (double-key consistent with governance model).
6. Risk Mitigation Adequacy: Top identified risks (entry-gate delay, vendor refusal, deadlock, ledger divergence, counterintelligence breach) are each assigned mitigation strategies with contingency accounts or procedural gates. Entry-gate delay is mitigated by: immediate bilateral negotiation (Month 5 = 2027-03-12 start), principal go/no-go checkpoint (Month 7.5 = 2027-05-27), and USD 50M gate-readiness contingency sub-account. Vendor refusal is mitigated by: pre-qualified registry, clean-room examination centers (USD 30-50M estimate, within envelope), and unverifiable fallback. Deadlock is mitigated by: enumerated fixed-timer escalation (5/8/13-day sequence), referee panel, and principal authority. Ledger divergence is mitigated by: hourly signed checkpoints, neutral-party digest escrow, and 4-hour divergence-detection KPI. Counterintelligence breach is mitigated by: continuous polygraph, 6-month tenure limits, compartmentation audits, and insider-threat red cell. Gaps: (1) Mitigation assumes both governments will enforce timers against their own nationals; no enforcement mechanism exists if one government stalls principals' decision beyond the 5-day window or pressure-stalls a ledger operator. Response needed: define escalation-to-top-level political authority and public disclosure rule for missed deadlines (e.g., 'unresolved disagreement >13 days published in KPI dashboard and reported to each government's legislature'). (2) Clean-room centers are assumed to work but are a new facility type with unproven chain-of-custody and vendor acceptance; no contingency if a critical vendor refuses clean-room testing. Response needed: define escalation path if clean-room mitigation fails (does equipment automatically become unverifiable, or does one side have a unilateral re-evaluation option?). (3) Filter-adequacy pre-test (Month 8.5 = 2027-06-27) must achieve >=85% detection to proceed; if it fails, no explicit contingency other than 'Phase One delayed.' Response needed: quantify the delay (weeks? months?) and decision authority to restart with revised filters or abort.

## Tough Questions

1. What specific algorithm or quantitative methodology will Evidence and Ledger Integrity Committee use to score equipment-identity confidence on a 0-100% scale, and how will the >95% threshold distinguish units that are escalated to Bilateral Technical Referees for identity dispute versus units classified as unverifiable at the intake stage? Current documentation states 'layered evidence with no single decisive source' but provides no scoring rule (e.g., if attestation is present and validated, customs record confirms arrival within 2 hours, and physical serial number matches, is that 100% or 95%? What mismatch drops confidence below 95%?).
2. If a critical vendor's cryptographic attestation keys are compromised between bilateral signature (Month 7 = 2027-05-12) and Phase One clock start (Month 9 = 2027-07-12), and that vendor supplies equipment representing 15% of one country's declared site, will the site immediately fail Phase One under the 'unverifiable >3%' auto-suspension trigger, or is there a bilateral dispute resolution allowing a principal-level decision to extend unverifiable tolerance or restart the site test? What happens to that country's 90-day clock—does it pause?
3. The bilateral instrument is targeted for signature by Month 7 (2027-05-12), but diplomatic negotiations typically require 6–12 months. What evidence confirms that negotiation has already begun and is on track for Month 7 (2027-05-12), and what is the contingency decision point if signature slips to Month 10 (2027-08-12) or later? At what point does sunk-cost preparation (estimated USD 100–200M by Month 8 = 2027-06-12) become politically unrecoverable and trigger program abandonment?
4. Monthly KPI dashboard will report blind-detection rate, identity-confidence scores, parity variance, ledger-sync latency, unverifiable-equipment count, and unresolved-discrepancy age. If any single metric falls below threshold mid-Phase One (e.g., detection rate drops to 82% in Month 10 = 2027-08-12 exercises), what is the automatic response: halt scored exercises for filter renegotiation, escalate to co-chairs for corrective-action decision, or convene the Threshold Calibration Panel to recommend a threshold downgrade? Who has authority to halt exercises versus lower the bar?
5. Deadlock is defined as no co-chair consensus within 5 days, escalating to Bilateral Technical Referees (Days 5–8) and then principals (Days 8–13). If principals cannot agree within 5 calendar days (Day 13) and status quo defaults to 'heightened inspection,' what does heightened inspection mean operationally (more frequent access requests? tighter filters on evidence? restricted personnel)? And if heightened inspection is still not resolving the underlying dispute, at what point does unresolved age (proposed >15 days) trigger automatic site suspension without further principal deliberation?
6. Equipment-identity confidence is anchored on attestation validated by accredited examiners from both countries, with customs records and physical marks as corroborating layers. If one country's accredited examiner flags an attestation as potentially forged (e.g., timestamp misaligned with customs entry by >2 hours), but the other country's examiner judges the attestation valid and the customs record is deemed unreliable, how is this two-layer disagreement resolved without becoming a bilateral political dispute that paralyzes the program? Does Bilateral Technical Referees panel take sealed testimony from both examiners, and if they still disagree, does the unit default to unverifiable?

## Summary

The Consortium's governance framework establishes a trust-free, bilateral US–China verification regime with layered evidence, double-key authorization, enumerated automatic-suspension triggers, and a hard 90-day Phase One test (Months 9–12 = 2027-07-12 to 2027-10-12). Strengths: exhaustive escalation procedures with fixed timers prevent indefinite deadlock; mirrored resident teams and independent ledger copies provide detection credibility; evidence-schema non-negotiability and equipment-identity layering resist single-point failures; challenge exercises and sealed scoring isolate verdicts from politics. Weaknesses: entry-gate timing (bilateral-instrument negotiation and vendor binding by Month 8 = 2027-06-12) compresses into a 14-month run-up and is the critical path; vendor-refusal handling concentrates risk in 3–4 manufacturers whose attestation-key compromise or refusal could render 10–40% of equipment unverifiable; compartmentation strictness (6-month tenure, site-bound knowledge) may degrade inspector context needed to detect anomalies; ledger synchronization KPIs (1-hour sync, 4-hour divergence detection) are aggressive and depend on hardened dedicated transport, which is under-detailed.