# Governance Audit


## Audit - Corruption Risks

- Inspectors from each country deployed to the other's datacenters could be pressured by their own government to conduct unauthorized intelligence collection, bypassing the Information Firewall Doctrine and compromising equipment identity findings with concealed observations or biased reporting.
- Equipment vendors or site operators could bribe inspectors or co-chair staff to misclassify equipment identity, falsify maintenance records, or suppress discrepancies in the ledger, leveraging the high-value frontier computing stakes and competitive sensitivity.
- A national government could instruct its co-chair representative to systematically block adjudication of discrepancies at the counterpart's site (exploiting the double-key no-casting-vote rule) to shield its own operators from suspension, creating systematic bias in findings.
- Critical vendors could offer side payments or preferential maintenance contracts to inspectors' home governments in exchange for favorable fallback-ladder rulings when reporting duties are refused, converting vendor-refusal procedures into a patronage gate.
- Dual-custody key material could be exploited: one country's key-custody officer, under duress or incentive, could leak or compromise the non-reconstructable share held by the other, enabling tampering with ledger entries and attestation validity without detection.
- Accredited independent examiners (third-country nationals) hired for vendor-refusal fallback procedures could be co-opted by either government or by vendors to produce favorable (or unfavorable) findings, compromising the chain of evidence when operators resist direct inspection.

## Audit - Misallocation Risks

- Envelope mapping misuse: Domestic operator compensation charged to each country's USD 2.5 billion contribution could be inflated or misdirected (e.g., paying non-participating operators, inflating per-site costs beyond the USD 167 million ceiling per facility) without itemized reconciliation, consuming site-preparation budget that should cover physical infrastructure.
- Personnel double-billing: Full-time inspectors, specialists and surge-pool staff could be paid from both the personnel envelope (USD 750 million) and from domestic operator-compensation budgets, or could be re-tasked to domestic counterintelligence duties while drawing Consortium salaries, inflating effective headcount without actual deployment.
- Contingency scope creep: The USD 500 million contingency could be drawn for non-emergency costs (e.g., routine personnel turnover, standard shift-relief coverage, office supplies) instead of reserved for entry-condition delays or mid-test crises, prematurely exhausting the buffer before Phase One conclusion.
- Neutral-facility cost overrun: Construction and staffing of the joint secure facility (Geneva or Singapore) could exceed the secure-facilities envelope without competitive bidding or cost controls, consuming shared funding meant for cybersecurity and counterintelligence infrastructure.
- Ledger and attestation infrastructure gold-plating: The USD 1.25 billion ledger-attestation-communications envelope could be spent on redundant or over-engineered systems (e.g., multiple hardware custody modules, excessive encryption layers) that exceed Phase One operational needs, reducing funds available for exercise testing or adjudication staffing.
- Exercise and red-team budget leakage: The USD 500 million testing envelope could fund overly elaborate or repeated exercises, independent-examiner teams with excessive staffing, or extended red-team deployments beyond the 90-day Phase One window, delaying detection results or inflating per-exercise costs.

## Audit - Procedures

- Monthly independent envelope reconciliation (100 percent sampling of invoices and supporting documents) mapped against the seven-envelope budget allocation, with unclassified summaries published by the 25th of each following month; escalation at 2 percent variance; quarterly external audit sign-off by an independent auditor cleared by both countries.
- Quarterly ledger-synchronization audit: sample five percent of recorded events across all sites, verify that each event appears in both national ledger copies within the one-hour synchronization bound, and reconcile any divergence within 72 hours; publish the audit exception count and resolution time in the monthly KPI dashboard.
- Quarterly contingency-burn rate review (Months 3, 6, 9 = 2027-01-08, 2027-04-08, 2027-07-08): validate actual spending against the compression reserve (USD 50–100 million) and free contingency (USD 400–450 million); trigger co-chair briefing if cumulative draws exceed 30 percent, scope-reduction planning at 50 percent, joint budget review at 75 percent.
- Biannual evidence-rule audit (Months 4.5, 8 = 2027-02-23, 2027-06-08): apply the locked evidence-weighting rule to a random sample of 20–30 adjudicated discrepancies from the prior period; verify that the rule's false-positive and false-negative rates remain within the calibrated band (±3 percentage points of target); flag any drift as a rule-adjustment candidate for post-Phase-One review.
- Annual key-custody ceremony audit (conducted at Months 1, 4, 8 = 2026-11-08, 2027-02-08, 2027-06-08 during Phase One): verify that both countries' key-custody officers were present, that dual shares were generated in joint ceremony, and that no share was held unilaterally; audit the key-recovery procedures and test time-to-recovery against the 8–24 hour standard.
- Post-Phase-One final audit (Month 9.5 = 2027-07-23): independent external auditor scores all five verdict criteria (detection rate, false positives, unverifiable equipment, parity, discrepancy age) against pre-registered thresholds; publishes unclassified audit opinion on Go/Modify/Stop decision logic; includes forensic sample of 10–15 exercise records and 5–10 discrepancy cases to confirm scoring integrity.

## Audit - Transparency Measures

- Weekly KPI dashboard (published to both co-chairs, bilingual) tracking: detection rate by event type, false-positive count, unverifiable-equipment count, reciprocal-access parity score, ledger-divergence incidents (count and resolution time), unresolved-discrepancy age distribution (percent >14 days, >21 days, >28 days), funding timeliness (tranche deposits, days elapsed since each release), contingency burn rate (percent of USD 500 million drawn), and audit exceptions; provide narrative interpretation of each metric.
- Monthly unclassified summary of audit findings and envelope reconciliation (25th of each month), distributed to both parliaments and published on a joint bilateral website, showing total spending year-to-date per envelope, percentage of budget consumed, and any reconciliation exceptions without sensitive operational details.
- Published adjudication case log (updated weekly, unclassified summary): count of open discrepancies by type and age cohort (0–7 days, 7–14 days, 14–21 days, 21–28 days, >28 days); count of cases resolved per week; partial-suspension events with timestamps and rationale; editorial narrative of systemic deadlock patterns if three or more suspensions occur in a month.
- Pre-registration document (locked Month 5.5 = 2027-03-23): bilateral memorandum co-signed by both co-chairs containing the evidence-weighting rule (versioned and confidential, but the fact of locking is public), verdict thresholds with confidence-interval bands, deadlock procedures, and suspension triggers; published in full text (unclassified summary) on the bilateral website.
- Bilateral monthly legislature briefing (unclassified, 15–20 minute oral or written summary): progress against entry-gate timeline, Phase One operational status (personnel deployment, exercise execution rate), detection results to date (binned by event type, without revealing scenario details), unresolved discrepancy count and age, and any funding or major-operational incidents; delivered jointly by both co-chairs or their designated representatives.
- Final Phase One verdict scoreboard (published within 5 days of Month 9 = 2027-07-08 clock conclusion, unclassified): detection rates achieved per event type with 95 percent confidence intervals, false-positive rate and confidence interval, unverifiable-equipment count and share, reciprocal-access parity score, maximum unresolved-discrepancy age, count of hard-stop triggers invoked, Go/Modify/Stop decision with explicit reference to which thresholds were met or missed, and external auditor sign-off on scoring logic.

# Internal Governance Bodies

### 1. Co-Chair Steering Board

**Rationale for Inclusion:** The Consortium is a bilateral US–China national-security program governed by equal national co-chairs with double-key authorization for budgets, protocol changes, site findings and sanctions. The plan explicitly forbids a single Project Sponsor, investor board or casting vote. This body provides strategic oversight, deadlock resolution and the final Go/Modify/Stop decision. It is essential to operationalize equal governance without stalling or brittle suspensions.

**Responsibilities:**

- Strategic direction and bilateral consensus on mission phases, scope changes and major milestones
- Double-key authorization of budgets (tranches), protocol amendments, and evidence-rule versioning
- Approval of entry-condition gates and matched-pair selections before Phase One begins
- Deadlock escalation: convening the Adjudication Panel and advisory technical board when co-chairs cannot resolve disputed findings or procedural disputes within 14 days
- Go/Modify/Stop verdict decision at Phase One conclusion, scored mechanically against pre-registered thresholds
- Partial-suspension triggers: authorizing the pause of a single disputed function when deadlock exceeds 14 days, without full program shutdown
- Tranche release authorization synchronized between both countries; withholding decision if funding conditions (14-day escalation, 30-day Stop) are triggered
- Emergency summit convening within 5 days if any entry-condition gate slips over 2 weeks

**Initial Setup Actions:**

- Establish bilateral Charter and Terms of Reference signed by both governments, locking deadlock procedures, partial-suspension rules and threshold-locking timeline
- Designate each country's co-chair representative (senior diplomat or national-security official) and appoint a co-chair office staff of 4–6 (1 chief of staff, 1 deputy per country, shared executive assistant)
- Pre-approve the roster of the Adjudication Panel (3 technical specialists per country) and the advisory technical board for deadlock referral
- Lock entry-condition roadmap with explicit 2-week slip triggers and emergency-summit procedures
- Schedule weekly steering-board meetings (Mondays, 2 hours, bilingual) and monthly co-chair summit (3 hours, in-person at neutral facility or video conference)
- Establish the KPI dashboard process: weekly bilingual dashboard, monthly unclassified legislature briefing

**Membership:**

- US national co-chair (senior diplomat or national-security official, full-time equivalent)
- Chinese national co-chair (senior diplomat or national-security official, full-time equivalent)
- US chief of staff to co-chair (1 FTE)
- Chinese chief of staff to co-chair (1 FTE)
- US executive staff (1 deputy chief of staff, 1 shared operations coordinator per co-chair)
- Chinese executive staff (1 deputy chief of staff, 1 shared operations coordinator per co-chair)

**Decision Rights:** Double-key authorization (both co-chairs must agree) required for: budgets over USD 50M in any single tranche or envelope, protocol amendments to evidence rule, site-finding sanctions (equipment classified unverifiable), partial-suspension orders, and Go/Modify/Stop verdict. Operational decisions under USD 50M per co-chair's authority independently (finance officer sign-off). Entry-gate certification and final verdict are joint decisions only. Tie-breaker: if deadlock on a Go/Modify/Stop verdict persists past 7 days, verdict defaults to Modify (not Go). If deadlock on a withholding decision persists past 30 days total co-chair impasse, both countries remain funded (status quo; no unilateral withholding allowed).

**Decision Mechanism:** Consensus-seeking: co-chairs meet weekly to pre-align. When consensus cannot be reached within 3 business days, formal double-key ballot by recorded vote. No casting vote by either co-chair or by an external party. For verdicts and deadlock escalations, the Adjudication Panel provides an advisory recommendation within 5 days of referral; co-chairs have 3 days to accept, override with published rationale, or escalate to emergency summit. Partial suspension can proceed unilaterally by the co-chair requesting it (no joint approval required); the suspension order is logged and both co-chairs are notified immediately, triggering a mandatory co-chair call within 2 hours.

**Meeting Cadence:** Weekly steering meetings (Mondays, 2 hours, bilingual video conference or in-person at neutral facility). Monthly in-person co-chair summit (3 hours, at neutral facility). Emergency summits convened within 5 days of any 2-week entry-condition slip, key-custody incident, ledger divergence, or unresolved deadlock exceeding 35 days. During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08), daily co-chair briefings (15 minutes) on KPI dashboard metrics.

**Typical Agenda Items:**

- KPI dashboard review (weekly): detection rates, false positives, unverifiable equipment, parity, discrepancy age, ledger-divergence incidents, funding timeliness, contingency burn rate, audit exceptions
- Entry-condition milestone tracking (Months 0–5 = 2026-10-08 to 2027-03-08.5): signed instrument, appropriations, access authority, site selection, inspector approval, vendor participation, schedule adoption; escalation of any slips over 2 weeks
- Deadlock escalations and Adjudication Panel referrals (as needed): disputes that inspectors or operational teams cannot resolve within 10 days
- Partial-suspension orders and impaired-confidence triggers (as needed): documentation of disputes exceeding 14–28 day thresholds by case type
- Tranche releases and budget contingency status (every Month 2, 4, 6, 8 = 2026-12-08, 2027-02-08, 2027-04-08, 2027-06-08 = quarterly plus go/no-go gates): authorization of synchronized tranches, review of contingency burn, escalation of overruns
- Phase One verdict preparation (Months 8–9 = 2027-06-08 to 2027-07-08): exercise results compilation, threshold scoring, confidence-interval analysis, preliminary Go/Modify/Stop assessment
- Go/Modify/Stop verdict and final decision (Month 9.5 = 2027-07-23): mechanical scoring against locked thresholds, independent auditor sign-off, public verdict release

**Escalation Path:** Deadlocked co-chair decisions escalate to the Adjudication Panel (technical recommendation within 5 days) and then back to co-chairs for final decision. If co-chair deadlock persists >35 days (including Adjudication Panel advisory time), the issue escalates to an emergency summit convened within 5 days by the Program Risk Officer, with authority to recommend scope reduction, supplemental appropriations, or formal Stop condition. For verdicts, the final decision is a mechanical co-chair application of pre-registered thresholds (no second-level appeal, but both co-chairs must formally confirm the scoring). For withholding of funding, the 30-day escalation threshold automatically triggers Stop condition without further co-chair negotiation.
### 2. Program Operations and Site Delivery

**Rationale for Inclusion:** Phase One requires operational execution of entry-condition sequencing, site preparation, inspectorate deployment and daily verification activities at 2–4 matched pairs across two countries. A dedicated operational-management team reports to the co-chairs and manages day-to-day decisions (below USD 50M threshold), operational-risk mitigation, personnel scheduling, logistics and vendor coordination. This separates strategic oversight from operational execution and avoids overloading the steering board with tactical details.

**Responsibilities:**

- Entry-condition task force leadership: coordinate bilateral roadmap (Months 0–5 = 2026-10-08 to 2027-03-08.5), manage milestone tracking, parallel negotiation tracks (site selection, vendor participation), and escalation procedures for 2-week gate slips
- Site-selection and matched-pair validation: lead reciprocal-access audits (Months 0–1 = 2026-10-08 to 2026-11-08), document functional equivalence (staging, lift capacity, 24-hour access), resolve asymmetric-access disputes, and certify co-chair approval of final matched-pair roster
- Inspectorate recruitment, vetting, training and deployment: manage simultaneous recruitment (Month -3 start, concurrent with entry gates), security-clearance processing (Months -1 to 4), joint training academy (Months -1 to 5), shift scheduling and leave rotations (4 months on-site, 2 months off-site, staggered cohorts), surge-pool mobilization and retention-bonus administration
- Vendor and operator liaison: secure written vendor-participation commitments by Month 2 (2026-12-08), conduct operator-compliance workshops at each site, establish baseline access expectations (4-hour staging access, 48-hour exercise notice), document refusal triggers and fallback-ladder sequencing, and manage vendor-refusal incidents in real-time
- Personnel cost tracking and payroll administration: manage USD 750M personnel envelope (distributed per country's contribution), track FTE deployment vs. budgeted headcount, monitor retention and turnover, submit monthly reconciliation to independent auditors, and flag overages requiring contingency draw
- Logistical and facilities coordination: staff liaison offices at each participating site (5–8 personnel per country total), manage 24/7 shift coverage, coordinate with operators for exercise windows and staging access, arrange transport and secure storage of evidence packages, oversee neutral-facility operations (staffing, security, ledger hosting)
- Operational-risk dashboard and mitigation: track leading indicators (entry-gate burn-down, vendor-refusal count, inspectorate-fill rate, discrepancy-age distribution, ledger-divergence incidents, contingency-burn rate), escalate risks >2 standard deviations from target to co-chairs within 48 hours, recommend scope adjustments or accelerated timelines in response to cumulative cascade risk

**Initial Setup Actions:**

- Establish the Program Operations Center as a joint entity staffed by operational leads from each country (1 US Program Director, 1 Chinese Program Director, co-located at neutral facility or connected by secure video) with direct reporting to co-chairs
- Publish the entry-condition roadmap by Month 0 (2026-10-08) with explicit deadlines, parallel-track assignments (site selection, vendor engagement, recruitment, vetting), and 2-week slip escalation thresholds
- Activate the entry-condition task force by Month -1 with bilingual coordinators for each gate (legal/diplomatic track, site-selection track, vendor-engagement track, personnel track)
- Conduct bilateral site-selection workshop by Month 0.5 (2026-10-23) to identify 4–6 candidate facilities per country and establish reciprocal-access audit criteria
- Begin inspector recruitment concurrently with entry-gate negotiations (Month -3, before formal clock) to compress timeline and reduce deployment gaps
- Establish the Vendor Liaison Office (5 personnel per country: legal, compliance, technical, logistics, adjudication) by Month 0.5 (2026-10-23) to negotiate vendor-participation agreements and document refusal triggers
- Schedule the training academy facility, curriculum development and instructor certification (Months -1 to 0) so first cohort training begins Month 1 (2026-11-08)

**Membership:**

- US Program Director (FTE operational lead, reports to US co-chair)
- Chinese Program Director (FTE operational lead, reports to Chinese co-chair)
- Entry-Condition Task Force Lead (shared bilingual coordinator, 1 per country)
- Site-Selection Lead (1 per country, leads reciprocal-access audits and asset documentation)
- Vendor Liaison Officer (5 per country: legal, compliance, technical, logistics, adjudication liaison)
- Inspectorate Deployment Officer (1 per country, manages recruitment, vetting, training, shift scheduling and leave rotations)
- Finance Officer (1 per country, tracks personnel costs, envelope reconciliation, contingency draws)
- Logistical Coordinator (1 per country, manages site operations, transport, evidence custody, neutral-facility staffing)
- Operational-Risk Officer (1 per country, co-reports to co-chairs and Program Directors, tracks leading indicators and escalates cascade risks)

**Decision Rights:** Operational decisions within approved budgets (single-envelope authority up to USD 50M per decision, contingency draws up to USD 10M per incident), personnel deployments and shift scheduling per established guidance, vendor-fallback-ladder sequencing and timing (with co-chair notification), site-access baselines and exercise-window coordination, and operational-risk escalations to co-chairs. Decisions requiring double-key co-chair approval: protocol amendments affecting inspectorate conduct, site-access restrictions, major cost overruns (>10% of an envelope), and entry-gate certification. Decisions escalated to co-chairs: vendor refusals affecting site eligibility, inspectorate staffing shortfalls exceeding 15%, and contingency-burn rate exceeding 30%.

**Decision Mechanism:** Daily Program Operations Center standup (bilateral video, 15 minutes) to review KPI dashboard and day-to-day issues. Operational decisions by Program Director consensus; if disagreement occurs, escalate to co-chairs within 4 hours. Personnel and shift scheduling by Deployment Officer with monthly auditor reconciliation. Vendor escalations decided by Vendor Liaison Officer in consultation with the counterpart country's liaison (majority of the 10-person office suffices; consensus preferred). Contingency-draw requests require Program Director sign-off and independent auditor concurrence before disbursement. Operational-risk cascades (3+ metrics >2 standard deviations) trigger an automated co-chair alert by the Risk Officer.

**Meeting Cadence:** Daily Program Operations standup (15 minutes, bilingual, 0800 UTC). Bi-weekly Program Directors' synoptic review (2 hours, deep-dive into entry-gate burn-down, inspectorate fill, vendor-refusal status, discrepancy age distribution, contingency burn). Weekly Vendor Liaison coordination call (1 hour, all 10 officers). Monthly full-program operational review with co-chairs (2 hours, prepare for steering-board meeting). Ad-hoc emergency calls as needed (within 4 hours of any 2-week gate slip or operational-risk cascade).

**Typical Agenda Items:**

- Entry-gate milestone tracking: signed instrument status, appropriations progress, access-authority enactment, site-selection audit progress, inspector-approval status, vendor-participation registry updates, covered-equipment-schedule finalization
- Site-selection and reciprocal-access audit: candidate-site documentation, functional-equivalence scoring, access-parity validation, audit exception resolution, matched-pair approval readiness
- Inspectorate deployment status: recruitment pipeline (# nominated, # in vetting, # cleared, # trained, # deployed), fill rate per cohort, leave-rotation scheduling, surge-pool mobilization, retention-bonus tracking
- Vendor-refusal incidents: fallback-ladder sequencing, independent-examiner availability, filter-certification status, evidence-package preparation timelines, unresolvable refusals (site eligibility impact)
- Personnel costs and payroll: monthly actuals vs. budget per country, FTE tracking (deployed vs. planned), contingency draws and approvals, reconciliation for independent auditors
- Logistical and facilities coordination: neutral-facility readiness (staffing, security, ledger hosting, key-custody ceremony prep), site-level operations (shift coverage, exercise-window scheduling, staging-area access), evidence-package custody and transport
- Operational-risk dashboard: entry-condition slip tracking, vendor-refusal count and resolution time, inspectorate-fill rate, discrepancy-age distribution, ledger-divergence incidents, contingency-burn status, audit-exception count; escalate any metric >2 standard deviations

**Escalation Path:** Operational decisions (<USD 50M, routine personnel/logistics) resolved by Program Directors and functional leads. Decisions >USD 50M or affecting entry-gate certification escalate to co-chairs within 4 hours. Vendor refusals or staffing shortfalls >15% escalate immediately. Contingency draws >USD 10M require co-chair and auditor approval. Any gate slipping >2 weeks triggers emergency-summit convening within 5 days. Cascade-risk alerts (3+ metrics >2 standard deviations) escalate to co-chairs via Risk Officer immediately, with recommended scope reductions or timeline adjustments.
### 3. Evidence and Verification Committee

**Rationale for Inclusion:** The Consortium's core mission is credible, reciprocal verification of declared-equipment changes. This requires specialized oversight of evidence standards, equipment-identity confidence rules, vendor-refusal fallback procedures, and detection-rate calibration. The plan explicitly specifies that no single evidence source is decisive and that evidence rules must be confidential, rotating, and validated against blind-exercise outcomes. This committee integrates technical expertise from both countries, manages the layered-evidence rule and its validation, oversees the Exercise Authority, and ensures detection results are defensible to both governments.

**Responsibilities:**

- Design, versioning and validation of the Layered Evidence Weighting Model: establish the confidential combination rule specifying how attestation, physical inspection, customs records, identifiers, maintenance logs, infrastructure changes and witnessed movement combine into equipment-identity confidence ratings; ensure no single source is decisive
- Evidence-rule calibration and pilot validation: apply the draft rule to 100–200 historical equipment-change records per participating site (Month 4.5 = 2027-02-23 through Month 5.5 = 2027-03-23); document false-positive and false-negative rates; adjust the rule if pilot results deviate >5 percentage points from target (false positives 10% ±3); lock the final rule by Month 5.5 (2027-03-23)
- Covered-Equipment Schedule maintenance: keep the confidential, versioned technical schedule technology-neutral; manage amendments at fixed review points (Months 3, 6, 9 = 2027-01-08, 2027-04-08, 2027-07-08); ensure each version is double-key approved and timestamped; prevent the schedule from lapsing into a product list
- Vendor-refusal fallback-ladder implementation: oversee the sequence (vendor-supervised testing → filtered evidence → independent examiners → clean-room → validated attestation); manage pre-staged accredited independent-examiner teams (1 per country, 5–8 specialists); coordinate with operators and vendors when refusals occur; document the disposition of each refusal and the evidence sufficiency of each fallback rung
- Oversight of the Exercise Authority: establish the mixed-nationality independent Exercise Authority (8 core staff); approve exercise scenarios and success criteria before execution (without disclosing scenarios to inspectors); verify that exercises are scored independently and that results are logged with witness attestations and cryptographic timestamps; ensure exercise load meets the target (54 exercises in 90 days, 6–8 replicates per event type)
- Detection-rate analysis and adjudication of exercise disputes: compile exercise results as they occur (weekly during Phase One); calculate detection rates per event type with 95% confidence intervals; flag any event type falling significantly below target (e.g., <50% for unplanned); recommend investigation if a single site's detection rate diverges >15% from the pooled rate (asymmetric access or operator resistance suspected)
- False-positive and unverifiable-equipment root-cause analysis: when a false positive is identified (inspector reported a discrepancy, but investigation cleared it) or when unverifiable-equipment counts surge, convene a technical review to determine whether the evidence rule, operator records or inspector procedures require adjustment
- Reciprocal-access parity assessment: monitor whether each side's inspectorate achieves equivalent detection rates and staging-area access; calculate a parity score (target ≥85%); flag asymmetric access or operator resistance that compromises parity

**Initial Setup Actions:**

- Establish the Committee co-chairs (1 senior technical officer per country) and recruit specialist members: technical/attestation (2 per country), cryptography/key custody (1 per country), equipment identifiers and maintenance records (1 per country), vendor-relation specialists (1 per country), red-team representatives (1 per country)
- Publish the draft Layered Evidence Weighting Model by Month 4.5 (2027-02-23) in a versioned escrow jointly approved by both co-chairs; mark it confidential but lock both countries' agreement on the approach
- Conduct the pilot-validation exercise at a non-production test facility by Month 5 (2027-03-08), applying the rule to all seven event types once and documenting detection procedures and scoring consistency
- Perform historical-record validation (Month 4.5 = 2027-02-23 to Month 5.5 = 2027-03-23) by applying the draft rule to 100–200 past equipment-change records per site; document false-positive and false-negative rates; if calibration is off, revise and re-validate with a second cohort
- Lock the final evidence rule and covered-equipment schedule by Month 5.5 (2027-03-23) with bilateral co-chair double-key approval; publish a declassified summary (rule principles, but not specific weighting values) to both legislatures
- Establish the Exercise Authority structure and charter by Month 3 (2027-01-08); recruit mixed-nationality staff (8 core, funded from testing envelope); pre-stage accredited independent-examiner teams (1 per country, 5–8 specialists) funded from testing envelope by Month 4 (2027-02-08)
- Develop exercise-scenario templates and scoring rubrics by Month 4 (2027-02-08); pre-register all scenarios before first Phase One exercise (Month 6 = 2027-04-08) without disclosing to inspectors

**Membership:**

- US Evidence and Verification Committee co-chair (senior technical officer, FTE)
- Chinese Evidence and Verification Committee co-chair (senior technical officer, FTE)
- US technical/attestation specialists (2 FTE)
- Chinese technical/attestation specialists (2 FTE)
- US cryptography/key-custody officer (1 FTE, liaison to Root-of-Trust Key Custody Architecture team)
- Chinese cryptography/key-custody officer (1 FTE, liaison to Root-of-Trust Key Custody Architecture team)
- US equipment-identifier and maintenance-records specialist (1 FTE)
- Chinese equipment-identifier and maintenance-records specialist (1 FTE)
- US vendor-relation specialist (1 FTE, liaison to vendor-liaison office)
- Chinese vendor-relation specialist (1 FTE, liaison to vendor-liaison office)
- US red-team representative (1 FTE, liaison to blind-challenge exercise design)
- Chinese red-team representative (1 FTE, liaison to blind-challenge exercise design)
- Exercise Authority Director (mixed-nationality, reports to committee co-chairs, 1 FTE + 7 staff per country split)
- Independent filter-auditor liaison (1 FTE, third-country national, reports to committee, validates disclosure-tier filters monthly)

**Decision Rights:** Committee co-chairs jointly approve the evidence-weighting rule, covered-equipment schedule, exercise scenarios and scoring rubrics, and the disposition of vendor refusals that affect site eligibility. Exercise Authority has full autonomy to design, schedule and score exercises without co-chair input until after execution; co-chairs can contest results through a formal double-key challenge (rare, documented). Detection-rate analysis is technical; if results fall clearly outside thresholds (e.g., <50% for unplanned), the committee recommends investigation but does not retroactively change thresholds. False-positive and unverifiable-equipment root-cause reviews are internal committee work; findings are reported to co-chairs but do not alter locked thresholds (adjustments deferred to post-Phase-One). Parity-score calculations are mechanical; asymmetric access flagged for co-chair escalation if score falls below 85% or a single site's detection rate diverges >15% from pooled.

**Decision Mechanism:** Consensus-seeking at bilateral co-chair level; drafts developed by specialist working groups and reviewed by full committee. For the evidence rule, a working group (2 technical specialists per country) drafts the rule, the committee debates it, and both co-chairs must approve in writing before it is locked. For exercise scenarios, the Exercise Authority proposes scenarios in writing; the committee reviews for scenario coverage and independence (no co-chair or inspector input until execution); both co-chairs formally acknowledge receipt but may not comment. Detection-rate calculations are automated from logged exercise results; threshold scoring is mechanical (no judgment call). If a technical dispute arises (e.g., whether a false positive is valid), the committee convenes a sub-group for technical investigation and reports findings to co-chairs without recommendation; co-chairs decide whether to re-investigate or accept findings.

**Meeting Cadence:** Bi-weekly Evidence Committee meetings (2 hours, bilateral, deep-dive on rule calibration, pilot data, schedule amendments, vendor-refusal fallback status). Weekly Exercise Authority status updates (1 hour, exercise load, detection rates to date, incident reports). Monthly parity-score and reciprocal-access review (1 hour, during Phase One). During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08), daily exercise-result compilation and incident log (automated, reviewed by co-chairs).

**Typical Agenda Items:**

- Evidence-rule development and validation: draft rule review, pilot-exercise results, historical-record calibration, false-positive and false-negative rate analysis, adjustment justification if calibration drifts >3 points
- Covered-equipment schedule maintenance: amendment proposals, technology-neutrality review, version control and effective-date timing, scope disputes (e.g., should new hardware generations be added mid-test)
- Vendor-refusal fallback-ladder implementation: refusal incidents and disposition (vendor-supervised testing, filtered evidence, independent examiners, clean-room, attestation), evidence sufficiency per rung, unresolvable refusals and site-eligibility impact
- Exercise Authority oversight: scenario development and pre-registration, exercise load tracking (target 6 per month per site = 54 total), detection-rate compilation per event type and per site, incident reports (production disruptions, access delays, equipment substitution scenarios failed to detect)
- False-positive and unverifiable-equipment root-cause analysis: investigation findings, evidence-rule adjustment recommendations (if any), inspector-procedure feedback, operator-record quality issues
- Reciprocal-access parity assessment: parity score (target ≥85%), per-site detection rates, asymmetric access flagged, operator-compliance baseline violations, recommendation for co-chair escalation if asymmetry suspected

**Escalation Path:** Technical disputes on evidence rules or exercise scoring escalate from the committee to the Adjudication Panel (technical recommendation within 5 days). If the panel recommendation is contested by a co-chair, the issue escalates to the co-chairs for final decision via the steering board. Vendor-refusal dispositions that affect site eligibility escalate to co-chairs immediately. Asymmetric access (parity score <85% or single-site detection divergence >15%) escalates to co-chairs for investigation and possible site-selection remediation. False-positive surges or unverifiable-equipment counts exceeding thresholds escalate for possible evidence-rule re-calibration post-Phase-One (not mid-test changes to locked rule).
### 4. Compliance and Audit Committee

**Rationale for Inclusion:** The plan requires rigorous fiscal accountability and auditing: every USD expense must map to one of seven budget envelopes; 100% of invoices are sampled by independent auditors; monthly envelope reconciliation and contingency-burn tracking; quarterly external audit sign-off. Additionally, the plan identifies multiple compliance risks: corruption, misallocation, envelope scope creep, operator-compensation inflation, and double-billing. The plan also specifies mandatory transparency: weekly KPI dashboard, monthly unclassified auditor findings, monthly legislature briefings. A dedicated Compliance and Audit Committee operates independently from the co-chairs and Program Operations to maintain audit integrity and compliance credibility.

**Responsibilities:**

- Envelope mapping and allocation governance: maintain the seven-envelope budget map (ledger/attestation/communications 1,250M; site prep/operator compensation 1,000M; personnel/training/translation 750M; secure facilities/cyber/counterintelligence 750M; testing/challenge/red teams 500M; legal/auditing 250M; contingency/surge 500M); classify every expense against an envelope; enforce maximum per-envelope spending (120% triggers supplemental-appropriation review); track per-country allocations (50/50 split, each 2,500M)
- Monthly independent envelope reconciliation: sample 100% of invoices and supporting documents submitted by both countries (consolidated by category: personnel, site prep, testing, facilities, legal); verify proper envelope classification; flag exceptions (>2% variance = re-check, >5% = co-chair escalation); publish unclassified monthly summary (total spend per envelope, % of budget consumed, reconciliation exceptions) by the 25th of each following month
- Contingency-burn tracking and escalation: monitor cumulative contingency draws against the USD 500M pool; trigger co-chair briefing at 30% spent (USD 150M), scope-reduction planning at 50% (USD 250M), joint budget review with external audit at 75% (USD 375M); maintain separate tracking of compression reserve (USD 50–100M, earmarked for entry-condition delays) vs. free contingency (USD 400–450M, for Phase-One operations)
- Quarterly budget actuals-vs-plan review: compile actuals through the end of the prior quarter; calculate variance per envelope and per country; identify overruns requiring contingency or supplemental appropriation; recommend scope reductions if free contingency approaches exhaustion
- Auditor coordination and independence assurance: recruit and vet independent auditors (third-country nationals, security-cleared by both countries) before Month 0 (2026-10-08); establish auditor charter guaranteeing independence and preventing interference by co-chairs or Program Ops; manage auditor schedule (monthly reconciliation sampling, quarterly external sign-off, final Phase-One audit at Month 9.5 = 2027-07-23)
- Personnel cost tracking and FTE reconciliation: collect monthly payroll and staffing data from both countries; verify FTE counts against planned headcount (180 per country target); flag turnover rates >5% monthly or <80% deployment rate; reconcile personnel costs within the USD 750M envelope; track retention-bonus spending against the budgeted 2–3% (USD 15–22.5M)
- Ledger-synchronization and key-custody audit: quarterly review of ledger divergences (sample 5% of recorded events, verify appearance in both national copies within 1-hour sync bound); audit key-custody ceremonies (verify both countries' officers present, dual shares generated jointly, no unilateral hold); test key-recovery procedures against 8–24 hour standard
- Public transparency and reporting: publish weekly KPI dashboard (bilingual) to both co-chairs tracking detection rates, false positives, unverifiable equipment, parity, discrepancy age, ledger-divergence incidents, funding timeliness, contingency burn, audit exceptions; monthly unclassified auditor findings and envelope summary (25th of each month); monthly unclassified legislature briefing (bilingual, 15–20 minutes, co-signed by both co-chairs); final Phase-One audit report and verdict scoreboard (within 5 days of Month 9 = 2027-07-08 clock conclusion)
- Compliance investigations and violations reporting: identify personnel, financial or procedural violations (unauthorized evidence handling, envelope misallocation, unauthorized vendor communications); escalate to co-chairs within 48 hours with investigation summary and recommended remediation; document all violations and remediation in the public ledger as events

**Initial Setup Actions:**

- Establish the Compliance and Audit Committee co-chairs (1 senior audit or finance official per country, reporting independently to co-chairs and ministries of finance) and recruit supporting staff: budget analysts (2 per country), envelope auditors (1 per country), FTE/payroll specialists (1 per country), transparency officer (1 shared, bilingual)
- Publish the Compliance and Audit Charter by Month -1 (2026-09-08, before Phase One starts) specifying auditor independence, escalation procedures, violation-reporting protocols and public transparency measures; sign jointly by both co-chairs
- Identify and recruit independent third-country auditors by Month -2 (2026-08-08); require biography review, security-clearance coordination and signed independence statement from each auditor; finalize auditor roster by Month 0 (2026-10-08)
- Establish the envelope-mapping protocol and budget-tracking system by Month 0 (2026-10-08): define invoice-submission requirements (envelope category, supporting docs, country and cost center), monthly reconciliation procedures, exception-reporting thresholds, and automated alerts when an envelope approaches 110% or 120% of plan
- Design the KPI dashboard and monthly reporting templates by Month 0 (2026-10-08) with input from co-chairs, Program Ops, Evidence Committee and counterintelligence offices; establish bilingual formats and distribution procedures
- Conduct a compliance-baseline audit of Months -1 and 0 (2026-09-08 to 2026-10-08) spending before Phase One, reconcile major cost categories and confirm that baseline auditor procedures work before the 90-day test begins
- Brief both countries' legislatures on compliance and audit procedures (Month 1 = 2026-11-08) as part of the monthly transparency-briefing series

**Membership:**

- US Compliance and Audit Committee co-chair (senior finance or audit official, FTE, reports to US finance ministry and co-chair)
- Chinese Compliance and Audit Committee co-chair (senior finance or audit official, FTE, reports to Chinese finance ministry and co-chair)
- US budget analyst (2 FTE, track invoices and envelope reconciliation)
- Chinese budget analyst (2 FTE, track invoices and envelope reconciliation)
- US envelope auditor (1 FTE, specialize in one or two high-risk envelopes like site prep, testing, facilities)
- Chinese envelope auditor (1 FTE, specialize in one or two high-risk envelopes)
- US FTE and payroll specialist (1 FTE, track personnel costs, headcount, turnover, retention bonuses)
- Chinese FTE and payroll specialist (1 FTE)
- Shared transparency officer (1 FTE, bilingual, prepares KPI dashboard and public monthly summaries)
- Independent external auditors (3–5 total, third-country nationals, 1–2 FTE each, security-cleared, hired on contract for the duration of Phase One through Month 9.5 = 2027-07-23)

**Decision Rights:** Committee co-chairs jointly approve budget amendments, contingency draws over USD 10M, and audit procedures. Budget analysts classify invoices and flag exceptions; co-chairs review exceptions >2% variance. Envelope auditors recommend reallocation or contingency draw if an envelope approaches overage; co-chairs authorize draws. Payroll specialist verifies FTE and cost reconciliation monthly; co-chairs approve or dispute. Transparency officer compiles and publishes reports on a fixed schedule (no editorial discretion; formats set in advance). Independent auditors operate under a charter that prohibits co-chair interference; auditors sign off on invoice sampling results and final verdict scoreboard independently. Violations identified by auditors are escalated to co-chairs immediately but reported publicly in the ledger within 48 hours (no suppression).

**Decision Mechanism:** Consensus-seeking at co-chair level for budget decisions. Automated invoice classification by category; exceptions reviewed by envelope auditors and escalated if variance exceeds threshold. Contingency-draw requests require both the requesting country's program director and the committee co-chair to sign off, plus auditor review and sign-off before disbursement. Quarterly actuals-vs-plan reviews conducted by bilateral working group (budget analyst + auditor from each country) with findings presented to committee co-chairs for decision on scope reductions or supplemental-appropriation requests. KPI dashboard compiled automatically from ledger and operational databases; no judgment call. Monthly legislature briefings scripted and approved in advance by both co-chairs (no ad-hoc commentary). Violations flagged by auditors trigger a co-chair conference call within 4 hours; investigation and remediation decision within 48 hours, with findings documented in the public ledger.

**Meeting Cadence:** Weekly budget status call (1 hour, budget analysts from both countries, review invoice submissions and flag exceptions). Bi-weekly Compliance Committee meeting (2 hours, full committee, deep-dive on envelope reconciliation, contingency burn, auditor findings, compliance incidents). Monthly KPI dashboard review with co-chairs (1 hour, part of steering-board meeting agenda). Quarterly external-auditor coordination (1 hour, independent auditors present findings, committee co-chairs discuss next-quarter audit plan). Contingency-burn escalation calls at 30%, 50% and 75% thresholds (emergency 1-hour co-chair + committee call). Monthly legislature briefings (15–20 minutes, co-signed by both co-chairs, delivered jointly).

**Typical Agenda Items:**

- Monthly envelope reconciliation: invoices submitted, classification accuracy, exceptions flagged (>2% variance), explanations and corrective actions, cumulative spend per envelope vs. plan, per-country allocations check (50/50 parity)
- Contingency-burn tracking: draws authorized and paid in prior month, cumulative draws against 500M total, percentage of compression reserve vs. free contingency spent, forecast through Phase One conclusion, escalation triggered (30%, 50%, 75%)
- Personnel cost and FTE tracking: monthly payroll actuals, FTE deployed vs. planned (target 180 per country), turnover rate and resignation reasons (if >5% monthly, investigate retention issues), retention-bonus spending (2–3% of 750M)
- Quarterly actuals-vs-plan review: variance per envelope (target <5%), causes of overruns, reductions possible in later quarters, supplemental-appropriation needed (if overrun >120% of envelope), free contingency remaining forecast
- Ledger-synchronization and key-custody audit: divergence incidents (count and resolution time), key-custody ceremony attendance and dual-share generation, key-recovery test results, audit exceptions (if any)
- Independent auditor coordination: monthly invoice-sampling results (% exceptions, re-check rate), quarterly external-audit scope and timeline, final Phase-One audit plan (Month 8 = 2027-06-08 prep)
- Compliance violations and remediation: unauthorized evidence handling, envelope misallocation, vendor-communication breaches, personnel-conduct violations; investigation findings, recommended remediation, public ledger entry documenting incident and resolution
- KPI dashboard metrics: detection rates, false positives, unverifiable equipment, parity, discrepancy age, ledger-divergence incidents, funding timeliness, contingency burn, audit exceptions; escalate any metric >2 standard deviations

**Escalation Path:** Invoice exceptions >5% variance escalate to co-chairs for decision on reclassification or contingency draw. Contingency draws >USD 10M require co-chair approval plus auditor concurrence before disbursement. Overruns >110% of an envelope trigger co-chair briefing; >120% requires supplemental-appropriation request (veto point). Compliance violations escalate immediately (within 48 hours) to co-chairs; investigation and remediation decision within 48 hours, with ledger documentation. Auditor disagreement with co-chair budget decision escalates to the independent auditor panel (3–5 auditors vote on final sign-off; majority rule, auditors do not veto but publish dissent if any). Major audit findings (e.g., systematic envelope misallocation, personnel double-billing) published in the monthly legislature briefing and the final Phase-One audit report (no suppression).
### 5. Counterintelligence Oversight Board

**Rationale for Inclusion:** Inspectors from each country are deployed to the other country's datacenters for extended periods (24/7 shifts, 4-month rotations), creating significant counterintelligence exposure and incentive for each side to conduct unauthorized intelligence collection or to suspect the other of doing so. The plan identifies this as a high-risk area (Estimated 40–60% chance of at least one breach attempt during a 90-day test; 30–40 day timeline to political withdrawal if a breach is discovered). The plan specifies Inspector Information Firewall Doctrine (compartmentalized knowledge, post-rotation debriefs, monitored cooling-off periods) but requires a dedicated oversight body to enforce compliance, adjudicate suspected breaches and prevent a single incident from derailing the entire mechanism. This board reports to co-chairs and operates with classified authority to investigate and sanction violations.

**Responsibilities:**

- Inspector vetting and continuous security review: coordinate baseline and periodic security clearance reviews (polygraph or equivalent) for all deployed inspectors (estimated 360 total, 180 per country) before deployment and at 4-month rotation intervals; maintain confidential security profiles; recommend removal of any inspector flagged as at-risk; approve security-cleared status for each rotation cohort
- Information-barrier enforcement: oversee implementation of the compartmentalized inspector knowledge model (isolated by role and site, post-rotation debriefs, monitored cooling-off periods before reassignment); conduct quarterly spot-check audits of inspector communications (secure on-site channels only, no personal phones) and compliance documentation; flag unauthorized access to sensitive areas or data
- Breach investigation and adjudication: receive breach allegations (from co-chairs, other inspectors, operator security, partner counterintelligence agencies); conduct expedited investigation (48-hour fact-finding, 72-hour recommendation to co-chairs, 7-day remediation decision); determine whether breach is substantiated and whether the inspector should be removed, recalled or sanctions applied
- Personnel rotation and cooling-off procedures: manage the 4-month on-site, 2-month off-site rotation schedule to ensure continuous, staggered coverage without requiring any inspector to stay deployed >4 months; enforce mandatory debriefs upon return from assignment; coordinate cooling-off periods (recommended 3–6 weeks off-site) before reassignment to other duties or other sites; track cooling-off compliance and exceptions
- Counterintelligence risk assessment and briefing: assess counterintelligence threats to the program (assessed foreign-intelligence targeting, identified collection attempts, known espionage methods); brief inspectors on threat awareness and reporting requirements during training (Months -1 to 5 = 2026-09-08 to 2027-03-08); provide on-site security briefings for each rotation cohort; track reported suspicious activity and investigation outcomes
- Interagency liaison and threat reporting: coordinate with national counterintelligence agencies of both countries on identified threats or investigation results; share threat intelligence bilaterally within the Board (classified, restricted compartment); report to co-chairs any evidence of systematic collection attempts or intelligence-service targeting; recommend program adjustments if counterintelligence posture requires strengthening
- Sanctions and personnel removal: recommend sanctions for confirmed breaches (removal from program, criminal referral, diplomatic notification if a foreign intelligence service is involved); enforce mandatory removal if an inspector is found to be conducting unauthorized collection or if counterintelligence agencies assess an unacceptable risk; coordinate with home-country governments on personnel consequences
- Public transparency within security constraints: maintain a confidential breach-incident log (shared with co-chairs) tracking all investigations opened, outcomes and personnel actions; publish a quarterly unclassified summary of breach-investigation activity (e.g., 'X investigations opened, Y substantiated, Z personnel removed') to establish public confidence that breaches are being monitored and adjudicated

**Initial Setup Actions:**

- Establish the Counterintelligence Oversight Board by Month -1 (2026-09-08) with 3 senior counterintelligence officers per country (6 total), each representing their national counterintelligence service; appoint a board chair (rotating annual chair, starting with US or mutual agreement) and executive secretary (1 bilingual FTE reporting to both co-chairs)
- Develop inspector vetting and security-review procedures by Month -1 (2026-09-08): establish baseline security-clearance requirements (national-security background check, polygraph or equivalent, compartment-specific clearance for classified evidence); schedule reviews at deployment and at each 4-month rotation interval; coordinate with national clearance authorities for pre-approval
- Draft the Information Firewall Doctrine enforcement procedures by Month -1 (2026-09-08): define compartmentalization rules (isolated by role, site, assignment duration), post-rotation debrief requirements (3–6 hours per inspector, conducted by neutral party), cooling-off periods (3–6 weeks off-site before reassignment), communication-security protocols (on-site secure channels only, monitored logging), and audit procedures (quarterly spot-checks of compliance documentation)
- Establish breach-investigation procedures by Month -1 (2026-09-08): define allegation-intake process (any co-chair or inspector can report), triage criteria (substantive allegations only, frivolous complaints not investigated), fact-finding teams (mixed-nationality, 2 senior officers per country), evidence-collection procedures, recommendation-drafting, and co-chair adjudication process (7-day timeline)
- Design personnel rotation schedule and cooling-off tracking by Month 0 (2026-10-08): establish 4-month on-site, 2-month off-site rotations staggered so 80–90% of each shift is always covered; create cooling-off tracking system to ensure every returning inspector completes mandatory cooling-off before reassignment
- Brief inspectors and Counterintelligence Threat Awareness Training during training academy (Months -1 to 5 = 2026-09-08 to 2027-03-08): cover threat landscape, reporting requirements, unauthorized-collection penalties, compartmentation rules, cooling-off procedures, and secure communication protocols; document training completion for each inspector before deployment
- Coordinate with national counterintelligence agencies (Month -1 to Month 0 = 2026-10-08 to 2026-10-08): establish liaison procedures, intelligence-sharing protocols (classified, bilateral only), and threat-briefing schedule; clarify how program-level breaches are reported vs. escalated to foreign-intelligence reporting channels

**Membership:**

- US Counterintelligence Oversight Board member (3 senior counterintelligence officers from US federal agency, representing counterintelligence, security and interagency liaison functions, 1–2 FTE shared across the three)
- Chinese Counterintelligence Oversight Board member (3 senior counterintelligence officers from Chinese national security authority, 1–2 FTE shared across the three)
- Board chair (rotating annual chair, chair officer is 1 of the 6 members, holds explicit chair authority)
- Executive secretary (1 bilingual FTE, not a voting member, reports to both co-chairs, maintains breach-incident log and schedules Board meetings)

**Decision Rights:** The Board jointly (all 6 members present) adjudicates breach investigations and makes recommendations to co-chairs on personnel removal, sanctions or program adjustments. Vetting approval (clearance sign-off for each rotation cohort) is delegated to each country's representatives (3 members per country can clear their own personnel; counterpart country does not veto but receives notification). Threat briefings and classified intelligence are compartmented (no dissemination outside the Board without explicit co-chair authorization). Breach-incident log is classified; quarterly unclassified summary published by Board consensus. Personnel removal recommendations require Board consensus; if disagreement (unlikely, but if both sides' representatives split), the issue escalates to co-chairs for final decision. Interagency liaison activities (threat sharing with national agencies) conducted by each country's representatives independently but with notification to Board chair.

**Decision Mechanism:** Breach allegations received and triaged by Board executive secretary; substantive allegations convene a fact-finding team (2 senior officers per country) for 48-hour investigation. Investigation team compiles evidence, interviews relevant personnel (inspector, co-workers, operator security contacts), and prepares a confidential report. Full Board (all 6 members) convenes within 72 hours of investigation completion to review findings and make a recommendation to co-chairs: substantiated breach (recommend removal), unsubstantiated (no action), partially substantiated (recommend monitoring or conditional reassignment), or insufficient evidence (file and monitor). Vetting decisions are mechanical: each country's clearance authority certifies its personnel; counterpart receives notification. Threat briefings and intelligence sharing occur through established liaison channels; Board chair ensures all members are informed of significant threats. Cooling-off compliance tracked by a shared database; quarterly audit verifies all inspectors completed required cooling-off before reassignment.

**Meeting Cadence:** Monthly Counterintelligence Oversight Board meeting (classified, 2 hours, full Board review of breach investigations, vetting status, threat briefings, cooling-off compliance). Emergency Board calls (within 24 hours) if a breach allegation is received or if a significant counterintelligence threat is identified. Quarterly unclassified summary preparation (1 hour working session before public release). Interagency liaison coordination calls (bilateral, each country's representatives, monthly, classified, 1 hour).

**Typical Agenda Items:**

- Breach allegations and investigations: status of open investigations (count, age, expected completion date), completed investigations (substantiation outcome, recommended sanctions, personnel actions), breaches identified and remediated in prior months
- Personnel vetting and clearance: rotation cohorts in vetting (% cleared, % pending), security-review results (any flags, repeat-reviewer issues), personnel removed or flagged as at-risk, clearance denials and appeals if any
- Information-barrier compliance: spot-check audit results (communications-protocol compliance, compartmentation violations, unauthorized access attempts), inspector self-reporting of alleged policy violations, cooling-off completion tracking (% on-site personnel who completed cooling-off before reassignment)
- Counterintelligence threat assessment: current threat landscape (foreign-intelligence targeting identified, collection-method assessments, specific-threat briefings per site or inspector category), briefing delivery to inspectors and program staff
- Personnel rotation and cooling-off: cohort schedule (% deployed, % in cooling-off, % available for reassignment), anomalies (any inspector exceeding 4-month deployment, cooling-off waivers requested), staffing impact on continuous-coverage targets
- Interagency liaison and intelligence sharing: threat intelligence received, shared with Board, and disseminated to co-chairs; coordination with national counterintelligence authorities on program-related investigations

**Escalation Path:** Breach allegations that appear substantiated escalate from Board to co-chairs immediately (within 24 hours of investigation completion) with a recommendation for personnel removal or sanctions. If co-chairs disagree on the appropriate remedy (rare), the issue escalates to emergency co-chair summit within 5 days. Vetting denials or security-clearance challenges escalate from the Board to the respective country's clearance authority for administrative appeal; the Board defers to national clearance decisions but can recommend retesting or reassignment conditions. Major counterintelligence threats (evidence of systematic foreign-intelligence targeting or collection attempts) escalate from the Board to co-chairs immediately and may trigger program-adjustment recommendations (e.g., revised compartmentation rules, additional security protocols). Recurring breaches or systematic policy violations escalate to a formal program-security review with co-chairs and the Compliance and Audit Committee.
### 6. Root-of-Trust Key Custody Architecture

**Rationale for Inclusion:** The Consortium's core infrastructure is a replicated, tamper-evident ledger with independently verifiable national copies. Every entry is signed and timestamped. Validated cryptographic attestations underpin equipment-identity confidence. The integrity of these systems depends entirely on the security of signing keys. The plan specifies dual-hold keys (non-reconstructable shares, both required to sign) to enforce the double-key governance principle. Key-custody ceremonies, key-recovery procedures and breach response are critical to operations. A compromise of key material would allow tampering with ledger entries and invalidating entire classes of evidence. This body is responsible for designing, implementing, securing and recovering key material, and for adjudicating key-custody disputes.

**Responsibilities:**

- Key-generation ceremonies and dual-share procedures: design secure ceremony procedures generating dual-hold (non-reconstructable shares) signing keys at a neutral secure facility; ensure both countries' key-custody officers are present and witness each generation; distribute shares immediately to secure custody (one share per country's secure facility, physically isolated); document each ceremony with a signed attestation from both officers and an independent witness; conduct key-generation ceremonies at Months 1, 4 and 8 (2026-11-08, 2027-02-08, 2027-06-08) with rehearsal at Month -1 (2026-09-08)
- Key-share custody and physical security: manage physical custody of non-reconstructable key shares (one per country) at secure facilities meeting classified-information standards; restrict access to authorized key-custody officers only (principal + deputy per country, total 4 personnel); implement two-person rule (both officers present for any access to key material); conduct monthly physical-security audits (verified custody, no unauthorized access, environmental controls functioning); document all key-access events in an access log
- Key-recovery procedures and lost-key response: establish an automated key-recovery procedure if a signing key is lost, compromised or contested: both countries' key-custody officers convene within 4 hours; conduct a 48-hour investigation (verify the loss, assess tampering scope, reconstruct any affected ledger entries from backup); issue a joint revocation attestation signed by both countries; generate a new signing key in a routine ceremony (within 24 hours of revocation); apply the new key to all entries after the revocation timestamp; estimate recovery time: 8–24 hours depending on scope and backup-restoration complexity
- Key-rotation and lifecycle management: rotate signing keys on a defined schedule (proposed: annual rotation, or after 1 million signatures, whichever is first, TBD) to limit the exposure window if a key is compromised mid-lifecycle; conduct each rotation in a ceremony with both key-custody officers present; archive retired keys in a secure, isolated vault with dual access control; maintain a version history of all active and archived keys with generation date, rotation date, retirement date and compromise status
- Cross-certification and ledger verification: if using mirrored independent signing hierarchies (alternative to dual-hold), establish a cross-certification process where each country's root key is independently validated by the other country's key-custody officer; periodically (monthly) both countries compare their key registries to verify no divergence; validate a sample of ledger entries (5–10 per week) by verifying cryptographic signatures against the published key registries
- Key-compromise investigation and remediation: if a key is suspected compromised (unauthorized signing, suspected theft or coercion of a key-custody officer), convene an emergency investigation (2 officers from each country) within 2 hours; assess the scope (which entries may have been tampered with), gather digital and physical evidence, and determine whether the compromise is confirmed or unsubstantiated; if confirmed, execute key revocation and recovery procedures immediately; if unsubstantiated, document findings and monitor for recurrence
- Audit and compliance: maintain a key-custody audit log (all ceremonies, all accesses, all rotations, all recoveries) accessible to independent auditors monthly; quarterly auditor review of key-custody procedures against the design (verify two-person rule, access-log integrity, ceremony documentation, backup-restore procedures); annual formal audit of the full key-lifecycle including archive storage and retention
- Training and deputy-capability maintenance: conduct annual training for all key-custody personnel (principal + deputy per country) on ceremony procedures, emergency response, evidence collection and recovery procedures; require all deputies to participate in at least one ceremony per year (by rotation with principals) to maintain capability if principal is unavailable; test the full key-recovery procedure annually (at Month 8 = 2027-06-08 during Phase One) with a simulated loss scenario

**Initial Setup Actions:**

- Establish the Root-of-Trust Key Custody Architecture team by Month -1 (2026-09-08): designate 1 principal key-custody officer and 1 deputy per country (4 total); recruit from national cryptography or information-security agencies; require background checks and compartmentalized security clearance for classified cryptographic material
- Design key-generation and key-recovery procedures by Month -1 (2026-09-08): document all ceremony steps, material flows, access controls, physical security requirements, witness roles and sign-off procedures; prepare draft procedures in English and Mandarin; circulate for peer review by cryptographic experts from both countries; finalize procedures by Month 0 (2026-10-08)
- Identify and prepare the neutral secure facility for key-custody operations by Month -1 (2026-09-08): ensure the facility has hardware-security modules (HSMs) or equivalent for key generation, an offline secure workspace for ceremony execution, dual-custody safe or vault for key-share storage, and audit-log capability; conduct a security dry-run at Month 0 (2026-10-08) and full operational test at Month 1.5 (2026-11-23)
- Conduct the first key-generation ceremony at Month 1 (2026-11-08) (or Month 1.5 = 2026-11-23 if facility readiness slips): both key-custody officers present, dual shares generated, distributed to secure storage in each country, ceremony documented with signed attestation
- Prepare backup-and-restore procedures for ledger recovery (if needed for key-loss recovery) by Month 0 (2026-10-08): establish daily encrypted backups of both national ledger copies at geographically separated secure locations; test restore time (target <2 hours) and verify integrity of restored entries; coordinate with the Ledger Synchronization team on backup procedures
- Document the key-custody audit trail and access-log procedures by Month -1 (2026-09-08): design a tamper-evident access log (hardware-enforced if possible) recording all key-access events with timestamp, accessing officer, purpose and outcome; ensure the log cannot be modified retroactively; test log integrity quarterly
- Train all key-custody officers by Month 0 (2026-10-08): hands-on training on ceremony execution, emergency procedures, evidence collection, and recovery procedures; require all four officers to sign off on understanding and capability; observe one officer executing a full ceremony from memory (without reference) before deployment

**Membership:**

- US principal key-custody officer (senior cryptography or information-security officer, 1 FTE, represents US national security authority)
- US deputy key-custody officer (1 FTE, fully trained and capable to substitute for principal, required to participate in ceremonies annually)
- Chinese principal key-custody officer (senior cryptography or information-security officer, 1 FTE, represents Chinese national security authority)
- Chinese deputy key-custody officer (1 FTE, fully trained and capable to substitute for principal, required to participate in ceremonies annually)
- Neutral independent witness (1 FTE, third-country national or independent security professional, observes all key-generation ceremonies and signs attestation; recruited by Month -1 = 2026-09-08)

**Decision Rights:** Key-generation ceremony execution requires both principal key-custody officers (or principal + deputy if principal unavailable, with advance authorization from co-chairs). Key-rotation decisions are made annually by the key-custody team and approved by co-chairs in advance (locked schedule, no ad-hoc rotation). Key-recovery procedures are triggered automatically by detecting a lost or compromised key (no co-chair pre-approval needed, but co-chairs are notified immediately). Key-compromise investigation decisions are made by the full four-person key-custody team (both countries represented); if there is disagreement on whether a compromise is confirmed, the issue escalates to co-chairs for final determination. Audit procedures are set by the independent auditors (audit scope and frequency); key-custody team provides access and documentation.

**Decision Mechanism:** Key-generation ceremonies are strictly procedural and scripted; decisions are binary (ceremony execution checklist: all steps completed, both officers present, independent witness present, shares generated and distributed, ceremony documented). Key-recovery is triggered by technical detection (key rejected by signing hardware, ledger-entry signature fails validation, or key-custody officer reports loss or suspected compromise); initiation is automatic (no decision-gate), but investigation of the cause and scope is conducted by the four-person team. Key-compromise assessment uses a four-step decision tree: (1) Is the potential compromise confirmed by technical evidence (unauthorized signatures) or by human report (officer coercion)? (2) If unconfirmed, what investigation will resolve it (2-hour technical audit, interviews)? (3) If confirmed, what is the scope (which ledger entries are affected)? (4) Proceed with key revocation and recovery. Disagreement among the four officers on whether a compromise is confirmed escalates to co-chairs (rare; most cases are clear-cut: either signatures fail verification or they don't).

**Meeting Cadence:** Monthly key-custody status review (1 hour, all four officers + independent auditor liaison, review access logs, ceremony schedule, upcoming rotations, and quarterly audit findings). Quarterly key-audit review (1 hour, with independent auditors, examine ceremony documentation, access-log integrity, backup-restore procedures). Annual training and testing (4 hours, all officers, simulated key-loss recovery, ceremony rehearsal, written exam on procedures). Emergency response calls (within 2 hours of suspected key loss or compromise).

**Typical Agenda Items:**

- Monthly key-custody operations: access-log review (all key-access events since prior month, no unauthorized access), upcoming ceremony schedule (next rotation date, facility readiness), key-version inventory (active keys, retired keys in archive, lifecycle status), and any incidents or near-misses since prior month
- Quarterly key-audit findings: independent auditor's assessment of ceremony documentation, access-control compliance, physical-security audits, and backup-restore procedure effectiveness; recommendations for procedural updates if any
- Annual key-rotation ceremony planning: schedule next annual rotation (proposed timing, facility readiness, both officers' availability), review updated procedures if any changes are made, coordinate with ledger team on transition procedures (old key retired, new key activated)
- Key-recovery and incident response: if any key loss or compromise occurs, emergency investigation findings, scope assessment, remediation timeline, and post-incident follow-up (how will this be prevented in future)
- Training and capability maintenance: annual refresher training agenda, all officers' certification status, deputy-officer participation in last ceremony, any identified training gaps

**Escalation Path:** Suspected key loss or compromise escalates immediately (within 2 hours) to co-chairs with a status report and preliminary assessment. If recovery procedures are needed, the key-custody team executes them without waiting for co-chair authorization (emergency procedures already pre-approved). If there is disagreement among the four officers on whether a compromise is confirmed, the issue escalates to co-chairs for decision on whether to proceed with revocation (risk: false revocation stalls ledger for 8–24 hours; risk: failure to revoke allows tampering to continue). Key-recovery time exceeding 24 hours (backup restore slow, multiple entries affected) escalates to co-chairs with a status briefing and expected completion time.

# Governance Implementation Plan

### 1. Senior leadership from both governments formally designate their national co-chair representatives (senior diplomat or national-security official, full-time equivalent) and appoint co-chair office staff (chief of staff, deputy, shared executive assistant per country). Execute and sign the bilateral Charter and Terms of Reference locking deadlock procedures, partial-suspension rules, threshold-locking timeline, and emergency-summit procedures.

**Responsible Body/Role:** Project Sponsor (Senior US and Chinese national-security leadership, pre-existing authority prior to any committee formation)

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- Bilateral Charter and Terms of Reference signed by both governments
- Named co-chair representatives and office staff (US and Chinese)
- Charter locked deadlock procedures, partial-suspension rules, and emergency-summit procedures

**Dependencies:**

- Project start authorized by both governments
- Senior leadership commitment to bilateral governance

### 2. Project Sponsor appoints the US and Chinese representatives to the co-chair office. The newly designated co-chairs begin weekly coordination meetings (Mondays, 2 hours). Establish the co-chair office workspace, secure communications (bilingual video, classified secure channels), and administrative support. Schedule monthly in-person co-chair summits at the neutral facility (site selection OPEN; decide by Month 1 = 2026-11-08).

**Responsible Body/Role:** Designated Co-Chairs (US and Chinese national co-chairs, now formally appointed and in office)

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Co-chair office operational with bilingual staff and secure communications
- First weekly steering-board meeting held and standing calendar established
- Neutral facility selection and host-country commitment (decision by Month 1 = 2026-11-08)

**Dependencies:**

- Bilateral Charter signed and co-chairs named
- Secure communications infrastructure available

### 3. Co-chairs jointly publish the entry-condition roadmap (signed by both) with explicit deadlines and parallel-track assignments: diplomatic/legal track (instrument signature Month 1 = 2026-11-08); site-selection track (candidate identification Month 0.5 = 2026-10-23, audit Month 1 = 2026-11-08); vendor-engagement track (outreach Month -1, commitments by Month 1 = 2026-11-08); personnel/vetting track (recruitment start Month -3, ongoing through Month 4 = 2027-02-08). Establish 2-week slip escalation thresholds and emergency-summit procedures.

**Responsible Body/Role:** Co-Chair Steering Board (both co-chairs, jointly deciding)

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- Published entry-condition roadmap signed by both co-chairs
- Parallel-track task assignments and deadlines
- 2-week slip escalation procedures documented

**Dependencies:**

- Co-Chair Steering Board operational
- Charter and Terms of Reference locked

### 4. Co-chairs formally establish the Program Operations Center as a joint entity. Appoint US Program Director and Chinese Program Director (1 each, co-located at neutral facility or connected by secure video, direct reporting to co-chairs). Publish detailed operational-execution charter specifying decision authorities (<USD 50M independent per director; >USD 50M double-key; entry-gate certification and verdicts joint only).

**Responsible Body/Role:** Co-Chair Steering Board

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Program Operations Center charter and governance structure
- Named Program Directors (US and Chinese)
- Decision-authority matrix published

**Dependencies:**

- Co-Chair Steering Board operational
- Neutral facility site selected or committed

### 5. Program Operations Center activates the entry-condition task force with bilingual coordinators for each gate: legal/diplomatic track, site-selection track, vendor-engagement track, and personnel/vetting track. Each track lead appointed and staffed with 2-3 coordinators per country (estimated 12-16 FTE total in the task force).

**Responsible Body/Role:** Program Operations Center (Program Directors, directing task-force activation)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- Entry-condition task force structure with named track leads
- Bilingual coordinators assigned to each gate
- Task-force charter and meeting schedule published

**Dependencies:**

- Program Operations Center appointed
- Entry-condition roadmap published

### 6. Co-chairs establish the Evidence and Verification Committee co-chairs (1 senior technical officer per country, FTE). Recruit specialist members: technical/attestation (2 per country), cryptography/key custody (1 per country), equipment identifiers/maintenance records (1 per country), vendor-relation specialists (1 per country), red-team representatives (1 per country). Total: 14-16 FTE.

**Responsible Body/Role:** Co-Chair Steering Board

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 1.5 (2026-11-23)

**Key Outputs/Deliverables:**

- Evidence and Verification Committee charter
- Named co-chairs and specialist members
- Committee meeting schedule and decision-authority matrix

**Dependencies:**

- Co-Chair Steering Board operational
- Senior technical personnel identified from both countries

### 7. Co-chairs establish the Compliance and Audit Committee co-chairs (1 senior finance or audit official per country, reporting independently to co-chairs and respective finance ministries). Recruit supporting staff: budget analysts (2 per country), envelope auditors (1 per country), FTE/payroll specialists (1 per country), shared transparency officer (1 bilingual FTE). Total: 9 FTE internal team.

**Responsible Body/Role:** Co-Chair Steering Board

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- Compliance and Audit Committee charter
- Named committee co-chairs and staff members
- Independence guarantee documented (auditors cannot be overruled by co-chairs)

**Dependencies:**

- Co-Chair Steering Board operational
- Finance and audit leadership from both countries identified

### 8. Compliance and Audit Committee publishes the Compliance and Audit Charter before Phase One begins, specifying auditor independence, escalation procedures, violation-reporting protocols, and public transparency measures. Sign jointly by both co-chairs.

**Responsible Body/Role:** Compliance and Audit Committee (co-chairs, jointly)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Published Compliance and Audit Charter
- Auditor independence guarantee in writing
- Public transparency measures documented

**Dependencies:**

- Compliance and Audit Committee co-chairs appointed
- Charter text reviewed by both countries' finance ministries

### 9. Compliance and Audit Committee identifies and recruits independent third-country auditors (estimated 3-5 total, 1-2 FTE each through Phase One conclusion). Require biography review, security-clearance coordination, and signed independence statement from each. Finalize auditor roster by Month 0 (2026-10-08).

**Responsible Body/Role:** Compliance and Audit Committee co-chairs

**Suggested Timeframe:** Month -2 (2026-08-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Named independent auditors (third-country nationals)
- Signed independence statements from all auditors
- Auditor security clearances coordinated and tracked

**Dependencies:**

- Compliance and Audit Committee co-chairs appointed
- Both countries' security-clearance authorities contacted

### 10. Compliance and Audit Committee establishes the envelope-mapping protocol and budget-tracking system. Define invoice-submission requirements (envelope category, supporting documents, country and cost center), monthly reconciliation procedures, exception-reporting thresholds, and automated alerts when an envelope approaches 110% or 120% of plan. Publish the system documentation bilingual.

**Responsible Body/Role:** Compliance and Audit Committee co-chairs and budget analysts

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Envelope-mapping protocol and budget-tracking system design (published)
- Invoice-submission form templates (bilingual)
- Automated-alert thresholds configured

**Dependencies:**

- Compliance and Audit Committee operational
- Both countries' finance officers briefed on system

### 11. Compliance and Audit Committee designs the KPI dashboard and monthly reporting templates with input from co-chairs, Program Operations, Evidence Committee and counterintelligence offices. Establish bilingual formats, automated data feeds from operational systems, and distribution procedures. Dashboard metrics: detection rates, false positives, unverifiable equipment, parity, discrepancy age, ledger-divergence incidents, funding timeliness, contingency burn, audit exceptions.

**Responsible Body/Role:** Compliance and Audit Committee (co-chairs, transparency officer, and IT support)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- KPI dashboard specification and screen mockups (bilingual)
- Weekly and monthly reporting templates (bilingual)
- Automated data-feed requirements from ledger and operational systems

**Dependencies:**

- Compliance and Audit Committee operational
- Co-chairs and operational-team leads identified

### 12. Co-chairs formally establish the Counterintelligence Oversight Board with 3 senior counterintelligence officers per country (6 total), each representing their national counterintelligence service. Designate a board chair (rotating annual chair, starting with US or by mutual agreement) and executive secretary (1 bilingual FTE reporting to both co-chairs). Establish Board charter guaranteeing independence from program operations.

**Responsible Body/Role:** Co-Chair Steering Board

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Counterintelligence Oversight Board charter
- Named board chair and members (3 per country)
- Executive secretary appointed and operational

**Dependencies:**

- Co-Chair Steering Board operational
- Senior counterintelligence representatives from both countries identified

### 13. Counterintelligence Oversight Board develops inspector vetting and security-review procedures. Establish baseline security-clearance requirements (national-security background check, polygraph or equivalent, compartment-specific clearance for classified evidence). Schedule reviews at deployment and at each 4-month rotation interval. Coordinate with national clearance authorities for pre-approval.

**Responsible Body/Role:** Counterintelligence Oversight Board (members representing both national CI services)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Inspector vetting and security-review procedures (published, classified)
- Clearance-requirement checklist
- Coordination protocols with national CI authorities documented

**Dependencies:**

- Counterintelligence Oversight Board appointed
- Both countries' CI and clearance authorities engaged

### 14. Counterintelligence Oversight Board drafts the Information Firewall Doctrine enforcement procedures. Define compartmentalization rules (isolated by role, site, assignment duration), post-rotation debrief requirements (3-6 hours per inspector, conducted by neutral party), cooling-off periods (3-6 weeks off-site before reassignment), communication-security protocols (on-site secure channels only, monitored logging), and audit procedures (quarterly spot-checks of compliance documentation).

**Responsible Body/Role:** Counterintelligence Oversight Board (members and executive secretary)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Information Firewall Doctrine enforcement procedures (published, classified)
- Compartmentalization rules documented
- Post-rotation debrief and cooling-off templates

**Dependencies:**

- Counterintelligence Oversight Board operational
- Inspector training and deployment schedules known

### 15. Counterintelligence Oversight Board establishes breach-investigation procedures. Define allegation-intake process (any co-chair or inspector can report), triage criteria (substantive allegations only), fact-finding teams (mixed-nationality, 2 senior officers per country), evidence-collection procedures, recommendation-drafting, and co-chair adjudication process (7-day timeline target).

**Responsible Body/Role:** Counterintelligence Oversight Board (members and executive secretary)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Breach-investigation procedures (published, classified)
- Allegation-intake form and triage criteria
- Fact-finding team charter and evidence-collection protocols

**Dependencies:**

- Counterintelligence Oversight Board operational
- Co-chair decision-making authority clarified

### 16. Co-chairs formally establish the Root-of-Trust Key Custody Architecture team by designating 1 principal key-custody officer and 1 deputy per country (4 total). Recruit from national cryptography or information-security agencies. Require background checks and compartmentalized security clearance for classified cryptographic material.

**Responsible Body/Role:** Co-Chair Steering Board

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Named principal and deputy key-custody officers (US and Chinese)
- Key-custody team charter
- Security-clearance applications submitted

**Dependencies:**

- Co-Chair Steering Board operational
- National cryptography and security agencies identified

### 17. Root-of-Trust Key Custody Architecture team designs key-generation and key-recovery procedures. Document all ceremony steps, material flows, access controls, physical security requirements, witness roles and sign-off procedures. Prepare procedures in English and Mandarin. Circulate for peer review by cryptographic experts from both countries. Finalize procedures by Month 0 (2026-10-08).

**Responsible Body/Role:** Root-of-Trust Key Custody Architecture team (principal and deputy officers, both countries)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Key-generation ceremony procedures (bilingual, classified)
- Key-recovery procedures (bilingual, classified)
- Witness role and sign-off requirements documented

**Dependencies:**

- Key-custody officers appointed
- Cryptographic experts from both countries identified

### 18. Root-of-Trust Key Custody Architecture team identifies and prepares the neutral secure facility for key-custody operations. Ensure the facility has hardware-security modules (HSMs) or equivalent for key generation, an offline secure workspace for ceremony execution, dual-custody safe or vault for key-share storage, and audit-log capability. Conduct a security dry-run at Month 0 (2026-10-08) and full operational test at Month 1.5 (2026-11-23).

**Responsible Body/Role:** Root-of-Trust Key Custody Architecture team with neutral facility director

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 1.5 (2026-11-23)

**Key Outputs/Deliverables:**

- Neutral facility key-custody infrastructure certified
- Hardware-security modules (HSMs) installed and tested
- Security dry-run report (Month 0 = 2026-10-08)
- Full operational test passed (Month 1.5 = 2026-11-23)

**Dependencies:**

- Neutral facility site selected and committed
- Key-custody procedures drafted and reviewed

### 19. Root-of-Trust Key Custody Architecture team prepares backup-and-restore procedures for ledger recovery (if needed for key-loss recovery). Establish daily encrypted backups of both national ledger copies at geographically separated secure locations. Test restore time (target <2 hours) and verify integrity of restored entries. Coordinate with the Ledger Synchronization team on backup procedures.

**Responsible Body/Role:** Root-of-Trust Key Custody Architecture team with Ledger Synchronization team (to be established later)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Backup-and-restore procedure design (classified)
- Recovery-time testing protocol
- Coordinate with ledger team (placeholder for later establishment)

**Dependencies:**

- Key-custody team appointed
- Ledger infrastructure design initiated

### 20. Root-of-Trust Key Custody Architecture team documents the key-custody audit trail and access-log procedures. Design a tamper-evident access log (hardware-enforced if possible) recording all key-access events with timestamp, accessing officer, purpose and outcome. Ensure the log cannot be modified retroactively. Test log integrity quarterly.

**Responsible Body/Role:** Root-of-Trust Key Custody Architecture team

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Key-custody audit trail and access-log procedures (classified)
- Tamper-evident log design specifications
- Quarterly audit-log-integrity test protocol

**Dependencies:**

- Key-custody team appointed
- Facility infrastructure finalized

### 21. Root-of-Trust Key Custody Architecture team conducts training for all key-custody officers (principal + deputy per country, 4 total). Provide hands-on training on ceremony execution, emergency procedures, evidence collection, and recovery procedures. Require all four officers to sign off on understanding and capability. Observe one officer executing a full ceremony from memory (without reference) before deployment.

**Responsible Body/Role:** Root-of-Trust Key Custody Architecture team (principals training deputies and peers)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Key-custody officer training completion certificates (4 officers)
- Training documentation and exam results
- Observed ceremony-execution validation (from memory)

**Dependencies:**

- Key-custody officers appointed
- Procedures documented and reviewed
- Facility ready for training exercises

### 22. Program Operations Center establishes detailed budget tracking and contingency-management procedures. Define monthly envelope reconciliation processes (100% invoice sampling, supporting-document verification), exception-reporting thresholds (>2% variance re-check, >5% co-chair escalation), and contingency-burn tracking against the USD 500M pool (trigger co-chair briefing at 30%, scope-reduction planning at 50%, joint budget review at 75%). Publish in bilingual format.

**Responsible Body/Role:** Compliance and Audit Committee co-chairs with Program Operations Center

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Monthly envelope reconciliation procedure (published)
- Exception-reporting thresholds and escalation process
- Contingency-burn tracking protocol

**Dependencies:**

- Budget envelope allocation documented (canonical facts)
- Compliance and Audit Committee operational

### 23. Compliance and Audit Committee conducts a compliance-baseline audit of Months -1 and 0 (2026-09-08 to 2026-10-08) spending before Phase One begins. Reconcile major cost categories, confirm that baseline auditor procedures work, and prepare processes for scaling to Phase One volume. Generate baseline audit report for co-chairs.

**Responsible Body/Role:** Independent external auditors (third-country nationals, under committee supervision)

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Compliance baseline audit report (Month -1 and 0 spending)
- Auditor-procedure validation and any recommended adjustments
- Invoice-sampling and exception-analysis templates tested

**Dependencies:**

- Independent auditors identified and cleared
- Envelope-mapping and tracking systems operational

### 24. Program Operations Center, Site-Selection Track Lead coordinates bilateral site-selection workshop (Month 0.5 = 2026-10-23). Identify 4-6 candidate facilities per country with both co-chairs' representatives, inspectorate leaders and operator executives present. Establish reciprocal-access audit criteria: staging area ≥500 sq m, 24-hour accessible, lift capacity ≥50 tons, ≥2 maintenance events per month. Document candidate profiles and hold a bilateral reconciliation meeting.

**Responsible Body/Role:** Program Operations Center, Site-Selection Track Lead (with co-chairs' observers)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- Candidate site identification and facility profiles (4-6 per country)
- Reciprocal-access audit criteria published
- Site-selection workshop notes and bilateral reconciliation

**Dependencies:**

- Program Operations Center operational
- Co-chairs' endorsement of site-selection approach

### 25. Program Operations Center, Site-Selection Track Lead conducts reciprocal-access audits (Months 0-1 = 2026-10-08 to 2026-11-08, compressed from Months -1 to 0 if timeline pressure). Each country's technical team visits the counterpart's proposed sites and documents access scope, timing, facility layouts and functional equivalence in sealed reports. Target completion Month 1 (2026-11-08).

**Responsible Body/Role:** Site-Selection Track Lead with bilateral audit teams (technical specialists from each country)

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Reciprocal-access audit reports (sealed, per site pair)
- Functional-equivalence scoring (staging, lift capacity, access timing)
- Asymmetric-access exceptions documented

**Dependencies:**

- Candidate site profiles documented
- Audit criteria locked

### 26. Co-chairs review audit reports and formally approve the matched pairs based on documented functional equivalence. Require explicit co-chair certification that each pair meets equivalence criteria. Publish audit results and any veto rationale. If access asymmetry cannot be reconciled, exclude that pair from Phase One; reduce the matched set rather than accept asymmetry. Target approval Month 1.5 (2026-11-23); decision locked by Month 3 (2027-01-08).

**Responsible Body/Role:** Co-Chair Steering Board (both co-chairs, jointly reviewing and approving)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 3 (2027-01-08)

**Key Outputs/Deliverables:**

- Co-chair-approved matched-pair roster (3 pairs / 6 sites or reduced count)
- Functional-equivalence certification (signed by both co-chairs)
- Published audit results and veto rationale (if any pairs excluded)

**Dependencies:**

- Reciprocal-access audit reports completed
- Co-chairs convened to review findings

### 27. Program Operations Center, Vendor Liaison Office establishes the Vendor Liaison Office (5 personnel per country: legal, compliance, technical, logistics, adjudication liaison). Begin pre-Phase-One vendor engagement (Months -2 to 0). Offer vendors a choice: participate in the Consortium and retain control over their own evidence package (sealed, accredited independent review), or agree to fallback testing and accept independent examiners' findings without veto.

**Responsible Body/Role:** Program Operations Center, with Vendor Liaison Office leads appointed

**Suggested Timeframe:** Month -2 (2026-08-08) to Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- Vendor Liaison Office charter and staffing (5 per country, named personnel)
- Vendor-engagement strategy and talking points (bilingual)
- Vendor-participation registry template and tracking

**Dependencies:**

- Program Operations Center operational
- Candidate sites and equipment lists identified

### 28. Vendor Liaison Office conducts bilateral vendor-participation negotiations (Months -2 to 2 = 2026-08-08 to 2026-12-08). Secure written commitments from all Tier-1 vendors (estimated 5-10 per country). Document participation commitments in the vendor-participation registry. Publish the registry as an entry-condition milestone by Month 2 (2026-12-08).

**Responsible Body/Role:** Vendor Liaison Office (5 per country: legal, compliance, technical, logistics, adjudication)

**Suggested Timeframe:** Month -2 (2026-08-08) to Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Vendor-participation commitments (signed agreements, estimated 5-10 per country)
- Published vendor-participation registry (entry-condition milestone)
- Fallback-ladder escalation procedures negotiated with vendors

**Dependencies:**

- Vendor Liaison Office staffed and operational
- Candidate sites and equipment identified

### 29. Program Operations Center, Inspectorate Deployment Officer begins inspector recruitment (concurrent with entry-gate negotiations, Month -3 start, before formal clock). Recruitment targets: 144-216 personnel per country (estimated 99 inspection corps + 36 surge pool + 45 specialist units). Establish recruitment pipeline with clear role definitions, qualifications, language requirements (English and Mandarin fluency for bilingual roles). Create recruitment timeline: nominations by Month 1 (2026-11-08), vetting pool ready by Month 2 (2026-12-08).

**Responsible Body/Role:** Program Operations Center, Inspectorate Deployment Officer (1 per country)

**Suggested Timeframe:** Month -3 (2026-07-08) to Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Inspector recruitment roadmap and pipeline (per country)
- Role definitions and qualification standards (bilingual)
- Nominations submitted by Month 1 (2026-11-08)

**Dependencies:**

- Program Operations Center operational
- Site count and layout finalized or estimated

### 30. Program Operations Center coordinates security-clearance processing for inspector nominees (Months 1-4 = 2026-11-08 to 2027-02-08). Each country's national security and counterintelligence authorities vet and clear personnel. Counterintelligence Oversight Board oversees baseline security-clearance reviews and polygraph or equivalent. Target: 80% of inspectors cleared by Month 4 (2027-02-08); 95% by Month 5 (2027-03-08).

**Responsible Body/Role:** Counterintelligence Oversight Board (vetting and clearance coordination) with Program Operations Center (tracking and escalation)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 5 (2027-03-08)

**Key Outputs/Deliverables:**

- Security-clearance applications submitted (estimated 360 total)
- Clearance-processing status tracking (% cleared per month)
- Personnel flagged for additional vetting or removal (if any)

**Dependencies:**

- Inspector nominations finalized
- Counterintelligence Oversight Board operational and trained

### 31. Program Operations Center establishes and funds the bilateral training academy (Months -1 to 5 = 2026-09-08 to 2027-03-08). Develop joint US-China curriculum covering: evidence-collection standards, information-barrier protocols, ledger operations, cryptographic attestation, vendor-refusal fallback procedures, red-team exercises, counterintelligence threat awareness, and compartmentation rules. Recruit instructors from both countries. Schedule first cohort training Month 1 (2026-11-08), ongoing cohorts through Month 5 (2027-03-08).

**Responsible Body/Role:** Program Operations Center with specialist units (Evidence and Verification Committee for curriculum content)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 5 (2027-03-08)

**Key Outputs/Deliverables:**

- Bilateral training academy curriculum (bilingual, classified)
- Facility and instructor resources secured
- First cohort trained by Month 1.5 (2026-11-23)

**Dependencies:**

- Program Operations Center operational
- Evidence Committee members identified to develop curriculum

### 32. Program Operations Center manages full inspector training and certification (Months 1-5 = 2026-11-08 to 2027-03-08). Conduct 2-3 week intensive training for each cohort covering evidence rules, field procedures, secure communications, compartmentation, cooling-off requirements, and operational security. Document training completion and certification for each inspector. Target: first pilot cohort (12-16 personnel, 6-8 per country) trained by Month 1.5 (2026-11-23); full deployment-ready cohorts by Month 5 (2027-03-08).

**Responsible Body/Role:** Training academy instructors with Program Operations Center oversight

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 5 (2027-03-08)

**Key Outputs/Deliverables:**

- Training completion certificates (per inspector, bilingual)
- First pilot cohort trained by Month 1.5 (2026-11-23)
- 80% of target strength trained by Month 4 (2027-02-08)

**Dependencies:**

- Bilateral training academy operational
- Curriculum approved by Evidence Committee

### 33. Program Operations Center, Inspectorate Deployment Officer designs personnel rotation schedule and cooling-off tracking system (Month 0 = 2026-10-08). Establish 4-month on-site, 2-month off-site rotations staggered so 80-90% of each shift is always covered. Create cooling-off tracking system ensuring every returning inspector completes mandatory cooling-off (3-6 weeks) before reassignment. Document rotation schedules and create automated alerts for cooling-off compliance.

**Responsible Body/Role:** Inspectorate Deployment Officer (1 per country) with Counterintelligence Oversight Board

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Personnel rotation schedule template (4 months on-site, 2 off-site)
- Cooling-off tracking system (automated alerts)
- Staggered deployment plan (80-90% shift coverage)

**Dependencies:**

- Inspectorate Deployment Officer appointed
- Information Firewall Doctrine procedures drafted

### 34. Program Operations Center establishes the 20% personnel surge buffer (estimated 30-40 additional inspectors per country on standby) to cover leave, illness and emergency rotations. Create a surge-pool roster, standby-alert procedures, and activation protocols. Document surge-pool costs within the USD 750M personnel envelope (estimated 2-3% additional cost for retention bonuses and standby compensation).

**Responsible Body/Role:** Inspectorate Deployment Officer (1 per country) with Program Operations Center

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 3 (2027-01-08)

**Key Outputs/Deliverables:**

- Surge-pool roster and standby-alert procedures
- Surge-activation protocols and timeline
- Budget allocation for surge costs (2-3% of 750M)

**Dependencies:**

- Personnel recruitment targets finalized
- Rotation schedule designed

### 35. Co-chairs draft and jointly approve bilateral instrument provisions covering: equal co-chair governance, double-key authorization for budgets/protocols/findings/sanctions, deadlock procedures (panel referral by day 10, advisory by day 15, co-chair decision by day 18), partial-suspension triggers (day 14), impaired-confidence triggers (day 21 for identity, day 28 for exit), and emergency-summit escalation (day 35). Target signature Month 1 (2026-11-08).

**Responsible Body/Role:** Co-Chair Steering Board with bilateral legal counsel (appointed by each government)

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Bilateral instrument draft (both language versions, English and Mandarin)
- Legal-counsel review and sign-off
- Signed bilateral instrument by Month 1 (2026-11-08)

**Dependencies:**

- Co-Chair Steering Board operational
- Charter and governance procedures locked

### 36. Each government enacts domestic appropriation acts authorizing its USD 2.5 billion contribution and its domestic access authority for inspectors to operate within its territory. Coordinate ratification timelines to allow synchronized deposit of first tranche (Month 2 = 2026-12-08, 25% = USD 625M per country). Publish evidence of appropriation to co-chairs as entry-condition milestone.

**Responsible Body/Role:** Project Sponsor (US and Chinese government leadership conducting legislative appropriations)

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Appropriation act enacted (each country, bilingual copy)
- Domestic access authority documented
- First tranche (USD 625M per country) deposited by Month 2 (2026-12-08)

**Dependencies:**

- Bilateral instrument signed (Month 1 = 2026-11-08)
- Each government's parliamentary or legislative process

### 37. Evidence and Verification Committee and Program Operations Center jointly establish and fund the independent Exercise Authority (mixed-nationality staff, 8 core personnel, funded from USD 500M testing envelope). Recruit Exercise Authority Director (mixed-nationality) and 7 core staff (split between both countries). Establish Exercise Authority charter guaranteeing independence from co-chair input until after exercise execution.

**Responsible Body/Role:** Evidence and Verification Committee co-chairs (designing scope) with Program Operations Center (recruiting and funding)

**Suggested Timeframe:** Month 1.5 (2026-11-23) to Month 3 (2027-01-08)

**Key Outputs/Deliverables:**

- Exercise Authority charter (independence guaranteed)
- Named Exercise Authority Director and core staff
- Budget allocation confirmed (USD 500M testing envelope)

**Dependencies:**

- Evidence Committee operational
- Program Operations Center and budget authority active

### 38. Evidence and Verification Committee and Program Operations Center pre-stage accredited independent-examiner teams (1 per country, 5-8 specialists per team, estimated 10-16 personnel total, funded from testing envelope). Recruit examiners with expertise in frontier-relevant computing equipment, cryptographic attestation and sealed-evidence procedures. Conduct initial training and dry-runs by Month 4 (2027-02-08). Prepare for rapid mobilization if vendor-refusal fallback procedures are triggered.

**Responsible Body/Role:** Evidence and Verification Committee (defining qualifications) with Program Operations Center (recruiting and staging)

**Suggested Timeframe:** Month 1.5 (2026-11-23) to Month 4 (2027-02-08)

**Key Outputs/Deliverables:**

- Accredited independent-examiner teams recruited (10-16 per country)
- Examiner credentials verified and documented
- Dry-run exercises completed (familiarity with procedures)

**Dependencies:**

- Vendor-refusal fallback procedures designed
- Testing envelope funding available

### 39. Evidence and Verification Committee publishes the draft Layered Evidence Weighting Model (confidential, versioned) in escrow jointly approved by both committee co-chairs by Month 4.5 (2027-02-23). Mark the rule confidential but lock both countries' agreement on the approach. Specify no single evidence source is decisive. Document how attestation, physical inspection, customs records, identifiers, maintenance logs, infrastructure changes and witnessed movement combine into equipment-identity confidence ratings.

**Responsible Body/Role:** Evidence and Verification Committee co-chairs (jointly approving evidence rule)

**Suggested Timeframe:** Month 3 (2027-01-08) to Month 4.5 (2027-02-23)

**Key Outputs/Deliverables:**

- Draft Layered Evidence Weighting Model (confidential, bilingual)
- Joint committee co-chair approval (signed)
- Rule placed in versioned escrow

**Dependencies:**

- Evidence Committee co-chairs and specialists recruited
- Evidence-rule drafting working group convened

### 40. Evidence and Verification Committee, with Program Operations Center support, conducts historical-record validation (Months 4.5-5 = 2027-02-23 to 2027-03-08). Apply the draft evidence-weighting rule to 100-200 historical equipment-change records per participating site, calculate identity-confidence outputs, and compare against known ground truth from operator records or maintenance logs. Target false-positive rate 7-13% (10% target +/- 3 points); false-negative rate <5%.

**Responsible Body/Role:** Evidence and Verification Committee (technical specialists, particularly technical/attestation and identifiers specialists)

**Suggested Timeframe:** Month 4.5 (2027-02-23) to Month 5.5 (2027-03-23)

**Key Outputs/Deliverables:**

- Historical-record validation report (false-positive and false-negative rates)
- Rule-calibration assessment (within target or requires adjustment)
- Adjustment justification (if calibration drifts >5 points)

**Dependencies:**

- Draft evidence rule in escrow
- Access to 100-200 historical records per site

### 41. Evidence and Verification Committee adjusts the evidence rule if pilot results deviate >5 percentage points from target (e.g., false positives 25% vs. 10% target, deviation 15 points = requires adjustment). If deviation is 3-5 points, flag as a review item but do not adjust. Conduct a second validation cohort if adjustment is made. Target completion by Month 5.5 (2027-03-23).

**Responsible Body/Role:** Evidence and Verification Committee (co-chairs, with technical specialists)

**Suggested Timeframe:** Month 5 (2027-03-08) to Month 5.5 (2027-03-23)

**Key Outputs/Deliverables:**

- Rule-adjustment decision (if any) with justification
- Second validation cohort (if adjustment made)
- Calibration confirmed within target range or flag review item

**Dependencies:**

- First historical-record validation completed
- Adjusted rule drafted (if needed)

### 42. Evidence and Verification Committee finalizes the evidence-weighting rule and publishes it in locked version with bilateral double-key co-chair approval by Month 5.5 (2027-03-23). Lock rule for the entire Phase One test window (Months 6-9 = 2027-04-08 to 2027-07-08); no mid-test amendments. Maintain a version-history log showing rule deployment date and which events were evaluated under which version.

**Responsible Body/Role:** Evidence and Verification Committee co-chairs (jointly locking the rule)

**Suggested Timeframe:** Month 5 (2027-03-08) to Month 5.5 (2027-03-23)

**Key Outputs/Deliverables:**

- Final locked evidence-weighting rule (confidential, bilingual, version v1.0)
- Joint co-chair approval (signed, double-key)
- Version-history log and deployment date

**Dependencies:**

- Historical-record validation completed
- Rule adjustments (if any) validated

### 43. Evidence and Verification Committee manages the covered-equipment schedule (confidential, versioned, technology-neutral). Establish maintenance procedures: fixed review points (Months 3, 6, 9 = 2027-01-08, 2027-04-08, 2027-07-08); each amendment double-key approved; effective dates applied to events recorded after amendment date. Freeze the schedule for Phase One operations (Months 6-9 = 2027-04-08 to 2027-07-08) unless emergency review is triggered. Ensure schedule defines which equipment classes are covered, not specific product models.

**Responsible Body/Role:** Evidence and Verification Committee co-chairs (jointly managing and approving amendments)

**Suggested Timeframe:** Month 2 (2026-12-08) to Month 5.5 (2027-03-23) and ongoing through Month 9 (2027-07-08)

**Key Outputs/Deliverables:**

- Covered-equipment schedule version control and amendment log
- Amendment review-point schedule (Months 3, 6, 9 = 2027-01-08, 2027-04-08, 2027-07-08)
- Frozen schedule confirmed for Phase One (Months 6-9 = 2027-04-08 to 2027-07-08)

**Dependencies:**

- Evidence Committee operational
- Initial equipment definitions provided by sites

### 44. Evidence and Verification Committee and Exercise Authority jointly develop exercise-scenario templates and scoring rubrics (Month 4 = 2027-02-08). Pre-register all scenario designs covering all seven event types (unreported arrival, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal, reluctant operator). Define success criteria and scoring procedures. Publish templates (not scenarios) so inspectors understand the event types but not the specific test cases.

**Responsible Body/Role:** Exercise Authority Director and core staff (designing scenarios) with Evidence Committee oversight

**Suggested Timeframe:** Month 3.5 (2027-01-23) to Month 4.5 (2027-02-23)

**Key Outputs/Deliverables:**

- Exercise-scenario templates (bilingual, defining all 7 types)
- Scoring rubrics and success-criteria definitions
- Exercise procedures manual (for inspectors, scenario-blind)

**Dependencies:**

- Exercise Authority appointed and staffed
- Evidence Committee operational

### 45. Program Operations Center coordinates the pilot exercise (Month 5 = 2027-03-08) at a non-production test facility (not a live participating site). Exercise Authority designs and executes all seven event types once (testing all types in parallel without disrupting other testing). Pilot exercise validates detection procedures, scoring consistency and inspector training readiness before Phase One. Inspectors participating in pilot are not blind (training event). Document detection outcomes and scoring, but pilot results do not count toward Phase One detection-rate calculations.

**Responsible Body/Role:** Exercise Authority Director and core staff (executing pilot), Program Operations Center (logistics and observer coordination)

**Suggested Timeframe:** Month 4.5 (2027-02-23) to Month 5.5 (2027-03-23)

**Key Outputs/Deliverables:**

- Pilot exercise execution report (all 7 types run once each)
- Detection and scoring results (pilot, non-binding)
- Inspector training validation and feedback

**Dependencies:**

- Exercise Authority and scenario templates finalized
- Pilot facility secured and prepared
- First inspector cohort trained

### 46. Co-chairs formally pre-approve the roster of the Adjudication Panel (3 technical specialists per country, 6 total) and the advisory technical board for deadlock referral (same 6 members or a second advisory panel, TBD by co-chairs). Document Panel charter, decision authority (technical recommendation only, non-binding on co-chairs but published), and 5-day turnaround target. Panel is convened automatically by the co-chair office when a discrepancy cannot be resolved by inspectors within 10 days.

**Responsible Body/Role:** Co-Chair Steering Board

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Adjudication Panel charter (decision authority and limits)
- Named panel members (3 per country, 6 total)
- Panel roster provided to co-chair office

**Dependencies:**

- Co-Chair Steering Board operational
- Senior technical specialists from both countries identified

### 47. Co-chairs establish the Counterintelligence Oversight Board's monthly classified meeting schedule and emergency-response protocols. Define when breach allegations trigger fact-finding investigations (within 2 hours), when full Board convenes (within 72 hours of investigation), and when recommendations go to co-chairs (with 7-day remediation decision target). Schedule monthly classified meetings, quarterly unclassified summary preparation, and annual security-training refresher.

**Responsible Body/Role:** Counterintelligence Oversight Board (members and executive secretary)

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 1.5 (2026-11-23)

**Key Outputs/Deliverables:**

- CI Board meeting schedule (monthly classified, quarterly unclassified prep)
- Emergency-response escalation procedures (timetable from allegation to co-chair decision)
- Standing agenda template (vetting status, threat assessment, breach investigations)

**Dependencies:**

- Counterintelligence Oversight Board appointed
- Breach-investigation procedures finalized

### 48. Program Operations Center and Counterintelligence Oversight Board jointly conduct bilateral inspector and counterintelligence threat-awareness training during the training academy (Months -1 to 5 = 2026-09-08 to 2027-03-08). Cover threat landscape, reporting requirements, unauthorized-collection penalties, compartmentation rules, cooling-off procedures, secure communication protocols. Document training completion for each inspector before deployment. Require all 360+ inspectors to sign legally binding statements that unauthorized collection or retention of sensitive information is a criminal violation.

**Responsible Body/Role:** Training academy instructors with Counterintelligence Oversight Board (content and legal review)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 5 (2027-03-08)

**Key Outputs/Deliverables:**

- CI threat-awareness training curriculum (bilingual, classified)
- Training completion certificates (per inspector)
- Signed legal statements (unauthorized collection consequences, 360+ inspectors)

**Dependencies:**

- Training academy operational
- Counterintelligence Oversight Board threat assessment completed

### 49. Root-of-Trust Key Custody Architecture team conducts the first key-generation ceremony at Month 1 (2026-11-08) or slips to Month 1.5 (2026-11-23) if facility readiness delayed. Both key-custody officers present (principal + deputy from each country, 4 total); independent witness observes and signs attestation. Dual-hold shares generated and immediately distributed to secure storage in each country. Ceremony documented with signed attestation. Ceremony is witnessed and recorded for audit.

**Responsible Body/Role:** Root-of-Trust Key Custody Architecture team (principals and deputies, both countries)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 1.5 (2026-11-23)

**Key Outputs/Deliverables:**

- Key-generation ceremony conducted and completed
- Dual-hold key shares generated, signed attestation
- Key shares distributed to secure custody (one per country)
- Ceremony documentation archived

**Dependencies:**

- Neutral facility key-custody infrastructure certified
- Key-custody officers trained and ready

### 50. Program Operations Center coordinates with co-chairs to select and commit to the neutral facility site (Geneva or Singapore, decision required by Month 1 = 2026-11-08) for bilateral governance, ledger hosting, key custody and evidence review. Secure host-country commitment for fast-track permitting and construction. Baseline facility needs: 1,000+ sq m secure space, bi-lingual staff, compartmented security architecture, redundant power and network. Target operational by Month 3 (2027-01-08).

**Responsible Body/Role:** Co-Chair Steering Board (site decision) with Program Operations Center (execution)

**Suggested Timeframe:** Month -3 (2026-07-08) to Month 3 (2027-01-08)

**Key Outputs/Deliverables:**

- Neutral facility site selected and committed (Geneva or Singapore)
- Host-country permits and construction authorization secured
- Facility operational by Month 3 (2027-01-08)

**Dependencies:**

- Co-Chair Steering Board operational
- Budget allocation for secure facilities confirmed

### 51. Program Operations Center begins inspectorate deployment and shift scheduling (Months 2-5 = 2026-12-08 to 2027-03-08). Deploy first trained cohort (12-16 personnel, 6-8 per country) to pilot sites by Month 2 (2026-12-08) for dry-run exercises and site-familiarization. Scale deployment: target 80% of full-strength inspectors deployed by Month 4 (2027-02-08), 95% by Month 5 (2027-03-08). Execute 4-month on-site, 2-month off-site rotation schedule. Maintain coverage logs and alert for any gaps.

**Responsible Body/Role:** Inspectorate Deployment Officer (1 per country) with Program Operations Center

**Suggested Timeframe:** Month 2 (2026-12-08) to Month 5.5 (2027-03-23)

**Key Outputs/Deliverables:**

- First cohort deployed by Month 2 (2026-12-08)
- Shift-coverage logs (% deployed per site, per shift)
- 80% deployment by Month 4 (2027-02-08)
- Cooling-off compliance tracking (all returning inspectors complete cooling-off)

**Dependencies:**

- Inspector training completed
- Matched sites approved and access granted
- Rotation schedule finalized

### 52. Program Operations Center coordinates operator-compliance workshops at each participating site (Months 1-2 = 2026-11-08 to 2026-12-08). With co-chairs' representatives present, inspectorate leaders and operator executives attend. Establish baseline access expectations: immediate access to staging areas (within 4 hours of request), cooperative exercise-window scheduling (48-hour advance notice, waived for unreported-arrival tests), staff availability for questions, confidentiality agreements. Require written operator commitments. Conduct dry-run exercises at each site by Month 2 (2026-12-08).

**Responsible Body/Role:** Program Operations Center, Vendor Liaison Office and Site-Selection Track Lead (coordinating with operators)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Operator-compliance workshop minutes (each site)
- Written operator commitments to baseline access
- Dry-run exercise results (access timing, staffing, cooperation)

**Dependencies:**

- Matched sites approved and operators identified
- First inspector cohort available for dry-runs

### 53. Evidence and Verification Committee establishes the independent filter-auditor liaison (1 FTE, third-country national, reports to committee, bilingual). The filter auditor validates disclosure-tier filters to ensure filtering removes no event-relevant detail while protecting sensitive IP and topology. Conduct initial filter-design workshop (Month 1.5 = 2026-11-23) where both sides' inspectors, operators and legal advisors jointly design evidence filters. Target filter-auditor certification by Month 2 (2026-12-08).

**Responsible Body/Role:** Evidence and Verification Committee (establishing filter governance) with filter auditor (validating filters)

**Suggested Timeframe:** Month 1.5 (2026-11-23) to Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Filter-design workshop and joint filter-approval process
- Named independent filter auditor (third-country)
- Filter specifications certified by auditor (bilingual)
- Disclosure-tier access policies locked

**Dependencies:**

- Evidence Committee operational
- Counterpart Evidence Disclosure Tiers concept approved by co-chairs

### 54. Program Operations Center establishes the Program Risk Dashboard process (weekly Month 0-3 = 2026-10-08 to 2027-01-08, bi-weekly Month 4-9 = 2026-10-08 to 2027-07-08). Assign a dedicated Program Risk Officer (1 per country, co-reporting to co-chairs) with authority to call emergency meetings and recommend scope reductions. Track leading indicators: entry-gate burn-down, vendor-refusal count, inspectorate-fill rate, discrepancy-age distribution, ledger-divergence incidents, contingency-burn rate, audit-exception count. Escalation rules: any indicator >2 standard deviations triggers co-chair alert within 48 hours; three or more alerts simultaneously activate emergency joint review.

**Responsible Body/Role:** Program Operations Center and Risk Officers (1 per country), Compliance and Audit Committee (providing dashboard data)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 3 (2027-01-08) setup; ongoing through Month 9 (2027-07-08)

**Key Outputs/Deliverables:**

- Program Risk Dashboard system designed and operational
- Named Risk Officers (1 per country)
- Weekly dashboard template and automated data feeds

**Dependencies:**

- Program Operations Center operational
- Compliance and Audit Committee providing data sources

### 55. Co-chairs jointly pre-register verdict thresholds by Month 5.5 (2027-03-23) in a bilateral memorandum locked by both. Thresholds include: detection rate ≥70% for planned-event class (proposed), ≥50% for unplanned class (proposed); false-positive rate ≤10% (proposed); unverifiable equipment ≤5% (proposed); reciprocal-access parity ≥85% (proposed, definition TBD); no discrepancy older than 21 days at conclusion (proposed); fewer than 5 open material discrepancies (proposed). Mark all provisional, validated against pilot data. Verdict logic: ≥80% thresholds met = Go; 50-80% = Modify; <50% = Stop.

**Responsible Body/Role:** Co-Chair Steering Board (jointly locking thresholds)

**Suggested Timeframe:** Month 5 (2027-03-08) to Month 5.5 (2027-03-23)

**Key Outputs/Deliverables:**

- Pre-registered verdict thresholds (bilateral memorandum, signed by co-chairs)
- Thresholds marked provisional with validation path
- Verdict-logic formula locked (mechanical scoring, no judgment call)

**Dependencies:**

- Pilot-exercise results available for calibration check
- Historical-record validation completed
- Co-chairs convened for threshold review

### 56. Program Operations Center and Compliance and Audit Committee conduct a final entry-gate certification review (Month 5.5 = 2027-03-23). Verify all entry conditions completed: bilateral instrument signed (Month 1 = 2026-11-08), appropriations and first tranche deposited (Month 2 = 2026-12-08), matched pairs approved (Month 3 = 2027-01-08), vendor-participation registry published (Month 2 = 2026-12-08), inspector approvals (vetting 95% complete by Month 5 = 2027-03-08), covered-equipment schedule adopted (Month 5.5 = 2027-03-23). Co-chairs jointly certify entry-gate completion and authorize the Phase One 90-day clock to begin Month 6 (2027-04-08).

**Responsible Body/Role:** Co-Chair Steering Board (final certification)

**Suggested Timeframe:** Month 5 (2027-03-08) to Month 5.5 (2027-03-23)

**Key Outputs/Deliverables:**

- Entry-gate completion checklist signed by co-chairs
- Entry-gate certification document (bilateral)
- Phase One clock authorization (start Month 6 = 2027-04-08)

**Dependencies:**

- All entry conditions milestones completed
- Risk Dashboard showing no critical cascade risks
- Co-chairs convened for final authorization

### 57. Co-chairs conduct an emergency co-chair summit if any entry-condition gate slips >2 weeks (proposed threshold). Summit convened within 5 days of slip confirmation. Agenda: assess impact on Phase One timeline, decide whether to accelerate subsequent gates, compress reserve, extend overall schedule, or reduce scope (fewer sites, shorter test window). Document summit decision and publish notice of timeline change to both legislatures if Phase One must be delayed or rescoped.

**Responsible Body/Role:** Co-Chair Steering Board

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 5.5 (2027-03-23) as needed (triggered by >2 week slip)

**Key Outputs/Deliverables:**

- Emergency summit convened (within 5 days of slip)
- Slip-impact assessment and decision document
- Timeline adjustment or scope-reduction decision published

**Dependencies:**

- Co-Chair Steering Board operational
- Risk Dashboard tracking gate-slip metrics

### 58. Co-chairs formally authorize the Phase One 90-day operational test to begin Month 6 (2027-04-08), with all governance bodies operational and trained. At this moment, all governance committees (Co-Chair Steering Board, Program Operations Center, Evidence and Verification Committee, Compliance and Audit Committee, Counterintelligence Oversight Board, Root-of-Trust Key Custody Architecture team) are formally constituted and staffed. They have standing meeting schedules, decision authorities locked, and operational procedures in place. The Phase One clock starts.

**Responsible Body/Role:** Co-Chair Steering Board (formal Phase One authorization)

**Suggested Timeframe:** Month 5.5 (2027-03-23) to Month 6 (2027-04-08)

**Key Outputs/Deliverables:**

- Phase One authorization signed by both co-chairs
- Governance-structure operational-readiness confirmation (all committees)
- Phase One clock start date: Month 6 (2027-04-08)

**Dependencies:**

- Entry-gate certification completed (Month 5.5 = 2027-03-23)
- All governance bodies appointed, trained and operational

### 59. During Phase One (Months 6-9 = 2027-04-08 to 2027-07-08), the Co-Chair Steering Board convenes weekly steering meetings (Mondays, 2 hours, bilingual video) and daily co-chair briefings (15 minutes) on KPI dashboard metrics. Program Operations Center runs daily standup (15 minutes) and bi-weekly deep-dive reviews. Evidence and Verification Committee meets bi-weekly, Exercise Authority reports weekly. Compliance and Audit Committee meets bi-weekly. Counterintelligence Oversight Board meets monthly (classified) with quarterly unclassified summaries. Risk Officer escalates any metric >2 standard deviations within 48 hours.

**Responsible Body/Role:** All governance bodies (Co-Chair Steering Board, Program Operations, Evidence Committee, Compliance and Audit, Counterintelligence, Root-of-Trust)

**Suggested Timeframe:** Month 6 (2027-04-08) to Month 9 (2027-07-08)

**Key Outputs/Deliverables:**

- Weekly KPI dashboard (detection rates, false positives, unverifiable equipment, parity, discrepancy age, funding timeliness, audit exceptions)
- Weekly exercise-result compilation and incident log
- Monthly unclassified legislature briefing (bilingual, co-signed by co-chairs)
- Monthly compliance and audit reconciliation

**Dependencies:**

- All governance bodies operational
- Phase One clock begun (Month 6 = 2027-04-08)

### 60. Exercise Authority scores all Phase One exercise results against the pre-registered thresholds as exercises occur (weekly during Months 6-9 = 2027-04-08 to 2027-07-08). Compile detection rates per event type with 95% confidence intervals, false-positive and false-negative tallies, unverifiable-equipment counts, and per-site detection-rate analysis (flag if single site diverges >15% from pooled rate). Publish weekly exercise-result log to Evidence Committee and co-chairs (bilingual, declassified summary for legislatures).

**Responsible Body/Role:** Exercise Authority Director and core staff (scoring and compiling)

**Suggested Timeframe:** Month 6 (2027-04-08) to Month 9 (2027-07-08)

**Key Outputs/Deliverables:**

- Weekly exercise-result compilation (events run, detection outcomes, scoring)
- Detection-rate calculations per event type with 95% confidence intervals
- Unverifiable-equipment analysis and root-cause investigation (if counts surge)

**Dependencies:**

- Exercise Authority operational
- Pre-registered thresholds locked

### 61. Co-chairs score Phase One verdict against locked thresholds and mechanical scoring rules by Month 9.2 (2027-07-14), within 5 days of Phase One clock conclusion (Month 9 = 2027-07-08). Independent auditor validates the scoring against pre-registered rules (no discretion). Verdict determined: ≥80% of thresholds met = Go; 50-80% = Modify; <50% or any hard Stop trigger = Stop. Publish unclassified verdict summary (detection rates, confidence intervals, thresholds, verdict outcome, Go/Modify/Stop decision) by Month 9.2 (2027-07-14).

**Responsible Body/Role:** Co-Chair Steering Board (final verdict decision) with independent auditor validation

**Suggested Timeframe:** Month 9 (2027-07-08) to Month 9.2 (2027-07-14)

**Key Outputs/Deliverables:**

- Final Phase One scorecard (all metrics vs. thresholds)
- Independent auditor sign-off on verdict scoring
- Unclassified verdict summary published (bilingual)

**Dependencies:**

- Exercise results compiled and analyzed
- Pre-registered thresholds and scoring rules locked

### 62. Co-chairs formally announce the Phase One Go, Modify or Stop decision by Month 9.5 (2027-07-23). If Go: the Consortium advances to Phase Two under the bilateral instrument. If Modify: co-chairs jointly determine Phase Two scope and conditions and report to legislatures. If Stop: co-chairs jointly declare Phase One concluded without proceeding; assess whether remediation is feasible before a restart is considered. Announce decision in a bilateral statement and brief both legislatures (classified detailed briefing, unclassified summary public).

**Responsible Body/Role:** Co-Chair Steering Board (announcing final decision)

**Suggested Timeframe:** Month 9.2 (2027-07-14) to Month 9.5 (2027-07-23)

**Key Outputs/Deliverables:**

- Joint co-chair announcement of Go/Modify/Stop decision
- Bilateral statement on Phase One outcome
- Classified legislature briefing (each country)
- Unclassified public summary of verdict and rationale

**Dependencies:**

- Verdict scored against locked thresholds
- Independent auditor validation completed

### 63. Compliance and Audit Committee conducts a final Phase One audit (Month 9.5 = 2027-07-23) with independent external auditors. Audit scope: 100% envelope reconciliation (all seven envelopes: ledger, site prep, personnel, facilities, testing, legal, contingency); 10% random sample of invoices and supporting documents; personnel roster and leave records (spot checks); ledger event sampling (5% of all recorded events). Prepare a comprehensive audit report (classified detail, unclassified summary) for co-chairs and legislatures.

**Responsible Body/Role:** Compliance and Audit Committee co-chairs and independent external auditors

**Suggested Timeframe:** Month 9 (2027-07-08) to Month 9.5 (2027-07-23)

**Key Outputs/Deliverables:**

- Final Phase One envelope reconciliation (all 7 envelopes audited)
- Invoice sampling and exception analysis (10% random sample)
- Personnel cost reconciliation and headcount verification
- Comprehensive audit report (classified and unclassified versions)

**Dependencies:**

- Phase One operations concluded (Month 9 = 2027-07-08)
- Monthly reconciliations throughout Phase One completed

### 64. All governance bodies prepare final close-out reports (Month 9.5 = 2027-07-23). Co-Chair Steering Board publishes final KPI dashboard and program summary. Program Operations Center documents all operational decisions, deviations from plan, and lessons learned. Evidence and Verification Committee compiles final detection-rate analysis, false-positive/negative breakdown, and evidence-rule calibration review. Compliance and Audit Committee publishes final budget statement. Counterintelligence Oversight Board submits classified breach-incident summary. All bodies maintain records in a central archive for post-Phase-One review and any Phase Two planning.

**Responsible Body/Role:** All governance bodies (close-out reporting)

**Suggested Timeframe:** Month 9 (2027-07-08) to Month 9.5 (2027-07-23)

**Key Outputs/Deliverables:**

- Co-Chair Steering Board final program summary and KPI dashboard
- Program Operations close-out report
- Evidence Committee final detection-rate and evidence-rule analysis
- Compliance final budget statement
- Counterintelligence Oversight Board classified breach summary
- Centralized record archive for Phase-Two planning

**Dependencies:**

- Phase One operations concluded
- Final verdict announced and legislatures briefed

# Decision Escalation Matrix

**Entry-Condition Gate Slip Exceeding 2 Weeks**
Escalation Level: Co-Chair Steering Board (Emergency Summit)
Approval Process: Emergency co-chair summit convened within 5 days of slip confirmation. Both co-chairs jointly assess impact on Phase One timeline, decide whether to accelerate subsequent gates, compress contingency reserve, extend overall schedule, or reduce scope (fewer sites, shorter test window). Published timeline-adjustment decision required.
Rationale: Entry conditions (signed instrument, appropriations, domestic authority, site selection, inspector approval, vendor participation, covered-equipment schedule) must complete before the 90-day Phase One clock begins. A 2-week slip compresses Phase One operations, reducing statistical power for detection-rate calculations and widening confidence intervals from ±10–15% to ±15–20%. Six sequential gates (Months 0–5 = 2026-10-08 to 2027-03-08.5) create compound delay risk; emergency escalation prevents passive schedule creep.
Negative Consequences: Cascading delays: four-week total slip reduces Phase One from 90 days to 60 days, producing 30–40 exercises instead of 54, cutting replicates per event type from 6–8 to 4–5, rendering detection-rate estimates statistically indefensible (±20–25% confidence intervals). Contingency consumption estimated USD 100–200M (20–40% of USD 500M contingency) for compressed timelines. Final verdict becomes ambiguous or contested; Go credibility lost.

**Bilateral Instrument or Appropriations Withheld Beyond 30 Days**
Escalation Level: Co-Chair Steering Board (Stop Trigger)
Approval Process: Either country's funding withholding beyond 30 cumulative days (14-day escalation triggering co-chair briefing, then 30-day auto-Stop threshold) activates the Stop condition without further co-chair negotiation. Automatic stop-work order and program suspension. Both co-chairs jointly declare Phase One halted and assess whether remediation is feasible.
Rationale: Synchronized USD 2.5 billion tranches (25% Month 2, 25 = 2026-12-08, 2028-11-08% Month 3, 30 = 2027-01-08, 2029-04-08% Month 5.5, 20 = 2027-03-23, 2028-06-08% Month 9.2 = 2027-07-14) are the mechanism for enforcing equal co-chair governance and preventing unilateral program control. Withholding funds is a Stop trigger under the plan's explicit design. Extended withholding (over 30 days) indicates political withdrawal or strategic dispute that cannot be resolved operationally.
Negative Consequences: Unequal funding stalls Phase One operations; both countries' inspectors cannot be deployed or paid. Unresolved withholding over 30 days consumes estimated USD 50–100M in committed personnel costs while operations are frozen. Program loses credibility if one country funds while the other blocks. Phase One cannot achieve the 90-day continuous-verification test. Bilateral relationship damage and domestic political liability for the withholding government.

**Deadlock on Material Site Finding or Sanction Exceeding 28 Days**
Escalation Level: Adjudication Panel (Technical Advisory Recommendation) → Co-Chair Steering Board (Final Decision with Automatic Partial Suspension)
Approval Process: Disputed finding cannot be resolved by inspectors within 10 days → Adjudication Panel convenes (3 specialists per country, 6 total) → panel issues non-binding technical recommendation within 5 days (day 15 from case opening) → co-chairs have 3 days to accept, override with published rationale, or escalate to emergency summit. If unresolved by day 28: automatic impaired-confidence status applied to the disputed function (intake paused, exit paused, or identity adjudication paused) without co-chair pre-approval; unrelated verification continues. Escalation to emergency summit if suspension exceeds 35 days cumulative.
Rationale: Double-key governance (no casting vote) creates deadlock risk. The Adjudication Panel provides technical credibility without altering the co-chair decision authority. Automatic partial suspension breaks stalling: one country cannot veto a finding indefinitely. Suspension is partial (only the disputed function pauses) to preserve operational continuity and avoid brittle full shutdowns. Age-based triggers (14, 21, 28 days) are pre-locked in the bilateral instrument to prevent disputes over the suspension threshold itself.
Negative Consequences: Unresolved discrepancies accumulate at an estimated 3–5 per 90 days. Each unresolved case stalls the ledger, compresses adjudication capacity (15 cases per month planned), and forces escalation to the Adjudication Panel. If deadlock persists past 35 days, partial suspension removes one function (e.g., intake verification) from operations, reducing detection capability by an estimated 30–50% for that class of events. Multiple simultaneous partial suspensions (e.g., intake and exit both paused) can render a site unverifiable. Unresolved discrepancy count >5 becomes a potential Stop trigger.

**Asymmetric Inspector Access or Operator Shielding Detected**
Escalation Level: Co-Chair Steering Board (Stop Trigger with Site Remediation or Exclusion)
Approval Process: Reciprocal-access parity audit during Phase One (monthly monitoring, target ≥85% parity score) flags asymmetric access: one side's inspectors denied 24-hour staging access or delayed >4 hours from request, vs. immediate access at the counterpart site. Single-site detection-rate divergence >15% from pooled rate is an indicator. Co-chairs jointly assess whether asymmetry is systematic (shielding suspected) or correctable (operator delay). If systematic: site excluded from verification or suspended; if correctable: enforcement action and remediation plan. Unresolvable asymmetry (one country refusing to mandate operator compliance) is a Stop trigger.
Rationale: Reciprocal access and parity are foundational to the bilateral verification model. The plan specifies matched-pair functional equivalence as an entry condition (staging ≥500 sq m, 24-hour access, lift capacity ≥50 tons). Asymmetric access undermines detection credibility: unreported arrivals in a restricted area cannot be detected, yet the site passes Phase One, invalidating the proof-of-concept. Operator shielding (a government preventing its operator from granting access) is explicitly listed as a Stop trigger.
Negative Consequences: Asymmetric detection capability: one country's operator allows access to all equipment changes; the other's operator grants access only during scheduled windows (48-hour notice), missing unreported arrivals. Estimated 20–30% detection-rate divergence per site (e.g., 75% at the cooperative site, 50% at the restricted site). Verdict becomes contested: the high-detection side claims Go is justified; the low-detection side argues results are non-comparable. Final decision collapses into political negotiation; Go is indefensible. If asymmetry is attributed to government shielding, Stop is automatic.

**Vendor-Refusal Fallback Ladder Cannot Produce Sufficient Evidence Before Phase One Entry**
Escalation Level: Co-Chair Steering Board (Site Eligibility Gate: Exclude Equipment or Fail Site Entry)
Approval Process: Vendor refusal identified by Month 2 (2026-12-08); escalation ladder initiated (vendor-supervised testing → filtered evidence → independent examiners → clean-room → validated attestation; each rung 8–12 weeks = 40–60 weeks total). If the full ladder cannot complete by entry (Month 5.5 = 2027-03-23), equipment remains unverifiable. Co-chairs jointly decide: (1) exclude the equipment from the covered-equipment schedule, or (2) fail the site from Phase One entry (remove from matched pairs). Fallback: pre-stage one accredited independent-examiner team per country (5–8 specialists) to accelerate the independent-examiner rung if vendor-supervised testing fails.
Rationale: The plan specifies no single evidence source is decisive and requires layered evidence. A vendor refusal that blocks all rungs of the fallback ladder leaves equipment unverifiable. Unverifiable equipment >5% triggers assessment for potential Stop. Allowing unverifiable equipment into Phase One with no credible evidence path undermines verification credibility. Entry-condition gate enforces resolution before the clock starts, preventing mid-test surprises that paralyze adjudication.
Negative Consequences: Vendor refusals at multiple sites (estimated 20–30% likelihood of ≥1 vendor refusal per 90 days) consume 8–12 weeks per rung. If 2–3 vendors refuse simultaneously, examiner capacity is exceeded (estimated 10–16 examiners per country, 1–2 sites at a time). Equipment goes unverifiable. Unverifiable-equipment count >5–10% overall or >15% at a single site becomes a potential Stop trigger. Site fails entry condition; matched pairs are reduced from 3 to 2 (4 sites instead of 6), exercise load drops from 54 to 36, statistical power halved.

**Inspector-Deployment Shortfall Exceeds 15% (Coverage Gaps)**
Escalation Level: Program Operations Center (Tactical Escalation) → Co-Chair Steering Board (Strategic Decision on Surge Buffer or Scope Reduction)
Approval Process: Inspectorate Deployment Officer tracks FTE deployed vs. planned (target 80% by Month 4, 95 = 2027-02-08, 2034-09-08% by Month 5, 100 = 2027-03-08, 2035-02-08% by Month 5.5 = 2027-03-23). If deployment falls short by >15% (fewer than 153 per country deployed instead of 180), escalate to Program Directors for immediate action: surge-pool activation, accelerated training completion, or emergency recruitment. If shortfall persists past Month 5 (2027-03-08) or at Phase One start, escalate to co-chairs for decision: reduce the number of matched sites (exclude 1–2 sites, retaining 2 pairs), reduce shift coverage to 24/5 (no weekends), or delay Phase One start. Co-chairs jointly authorize the scope reduction or coverage change.
Rationale: Inspectorate staffing drives detection capability: continuous presence in staging and spare-inventory areas is required to detect unreported arrivals. Staffing shortfalls create coverage gaps. Estimated gap impact: 15% under-staffing reduces continuous-presence coverage from 24/7 to ~20.4 hours per day, missing arrivals during ~3.6 unmonitored hours. Detection rate for unreported arrivals estimated to drop by 10–15% per coverage gap. Multiple gaps compound; a 15% shortfall across all sites is estimated to reduce overall detection by 10–15% and trigger potential Stop if results fall below the 70% threshold.
Negative Consequences: Coverage gaps during nights, weekends, or high-turnover periods allow unreported equipment arrivals and substitutions to occur undetected. Detection-rate estimates become biased (exercises run during high-coverage shifts, missing the effect of gaps). Adjudication load increases as undetected changes are later disputed. Staffing-driven shortfalls produce a detection artifact: Phase One appears successful because it exercises well-staffed periods, but deployment to longer continuous operation reveals gaps. Verdict loses credibility post-Phase-One when actual detection rates are lower than Phase One suggested.

**Ledger Divergence Between National Copies Unresolved Beyond 7 Days**
Escalation Level: Root-of-Trust Key Custody Architecture (Technical Investigation) → Co-Chair Steering Board (Double-Key Resolution Authority)
Approval Process: Ledger-synchronization bound: counterpart signed-digest exchange every 1 hour (escalation alert at 30-minute overdue). If a digest mismatch is detected, automated dual-ledger audit convenes within 4 hours. Both countries' ledger teams perform a cryptographic check: which entries differ, what timestamps, were they recorded locally in both copies? Co-chairs jointly determine the cause (network failure, key-custody incident, tampering suspicion, accidental deletion) and authorize remediation: restore from backup (target <2 hours), revoke and regenerate signing keys (estimated 8–24 hours), or escalate to forensic investigation if tampering is suspected. Unresolved divergence exceeding 7 days is escalated to emergency summit and triggers partial suspension of ledger-dependent functions (evidence disclosure paused until divergence is resolved).
Rationale: The tamper-evident replicated ledger is the core infrastructure. Divergence between national copies—even if unintentional (network failure, backup corruption)—breaks the fundamental assumption that both sides see the same events. Delayed resolution (>7 days) allows divergence to persist and grow; later events are recorded in only one copy, compounding the problem. Immediate detection and co-chair resolution within 7 days prevents the ledger from becoming a source of permanent dispute.
Negative Consequences: Unresolved ledger divergence blocks evidence validity: an entry recorded at site A but missing from site B cannot be used to prove equipment identity (the counterpart disputes it). Adjudication load escalates as all disputed entries require manual forensic comparison. Estimated divergence incidents: 10–15 in 90 days if synchronization latency is 4+ hours and event volume is 5–10 per day per site; each incident can stall evidence validity for 2–7 days. If divergence persists >7 days, the ledger is de facto compromised; both co-chairs lose confidence in its integrity. Ledger divergence >7 days unresolved is a potential Stop trigger.

**Contingency Depletion Exceeding 50% or Envelope Overage Exceeding 120%**
Escalation Level: Compliance and Audit Committee (Audit Escalation) → Co-Chair Steering Board (Scope-Reduction Decision or Supplemental-Appropriation Request)
Approval Process: Contingency tracked cumulatively: trigger at 30% (USD 150M spent = co-chair briefing), 50% (USD 250M = scope-reduction planning), 75% (USD 375M = joint budget review with external audit). Any single envelope exceeding 110% of plan triggers co-chair review; exceeding 120% requires approval for supplemental appropriations (veto point: either country can refuse, blocking the overage). Contingency-depletion trajectory is reviewed monthly; if burn rate suggests exhaustion before Phase One end, co-chairs jointly decide: reduce matched sites (2 pairs instead of 3), shorten Phase One (60 days instead of 90), reduce exercise frequency, or defer Phase Two. Supplemental-appropriation request must be approved by both governments' legislatures (estimated 2–4 week process), delaying operations.
Rationale: Budget envelopes (seven fixed allocations, USD 5 billion total) are tied to the program's scope and feasibility. Contingency represents 10% slack; depletion beyond 50% indicates systematic underestimation. Envelope overage beyond 120% exceeds the contingency ceiling and requires new funding authority. The plan specifies every expense must map to an envelope, creating transparency but also constraint: if personnel costs surge (attrition, retention bonuses) beyond the USD 750M envelope, the excess consumes contingency. Reaching 50% contingency depletion by Month 6 (2027-04-08) signals that Phase One cannot run the full 90 days without scope reduction.
Negative Consequences: Contingency exhaustion forces mid-test scope reduction. Reducing matched sites from 3 to 2 halves exercise load (54 → 36 exercises), reduces replicates per event type from 6–8 to 3–4, and increases confidence intervals from ±12% to ±20%, making verdict ambiguous. Shortening Phase One from 90 to 60 days prevents exercises from reaching planned frequency (6 per month per site = 36 total instead of 54), statistical power declines >50%. Deferring Phase Two forces supplemental-appropriation request (2–4 week legislative process, political veto risk). Budget crisis becomes a political liability; the withholding government can claim Phase One failed due to inefficiency or poor planning.

# Monitoring Progress

### 1. Entry-Condition Gate Milestone Tracking
**Monitoring Tools/Platforms:**

  - Entry-Condition Task Force Status Spreadsheet (bilateral, locked gates and slip thresholds)
  - Bilateral Instrument and Appropriations Status Log
  - Site-Selection and Reciprocal-Access Audit Report Repository
  - Vendor-Participation Registry and Fallback-Ladder Status Tracker
  - Inspector Vetting and Clearance Pipeline Dashboard

**Frequency:** Weekly (Months 0–5 = 2026-10-08 to 2027-03-08); escalation triggers within 48 hours of >2-week slip detection

**Responsible Role:** Program Operations Center (Entry-Condition Task Force Lead per country, 1 each) with bilateral coordination; escalates to Co-Chair Steering Board if any gate slips >2 weeks

**Adaptation Process:** Entry-condition slips (signed instrument, appropriations, site selection, inspector approval, vendor participation, schedule adoption) are tracked against locked deadlines (Months 0.5–3 = 2026-10-23 to 2027-01-08). If a gate slips >2 weeks, the Program Risk Officer alerts both co-chairs within 48 hours. Co-chairs convene an emergency summit within 5 days to assess impact: whether to accelerate subsequent gates (parallel tracks, compressed timelines, contingency reserve), extend overall schedule, or reduce scope (fewer sites, shorter test window). Task force submits an impact-assessment memo recommending timeline adjustment or scope reductions. Co-chairs jointly publish a timeline-change decision within 7 days of slip confirmation.

**Adaptation Trigger:** Any entry-condition gate (instrument signature, appropriations, domestic access authority, matched-pair approval, inspector approval, vendor-participation registry, covered-equipment schedule) slipping more than 2 weeks beyond locked deadline; cumulative entry-condition delay exceeding 8 weeks (compresses Phase One from 90 to ~45 days, degrading statistical power and confidence intervals from ±10–15% to ±15–20%, rendering detection-rate estimates indefensible); contingency budget consumption for compression reserve exceeding 10% of the USD 500M (USD 50M) within any single 4-week period

### 2. Reciprocal-Access Parity and Matched-Site Validation
**Monitoring Tools/Platforms:**

  - Reciprocal-Access Audit Report (sealed, per matched pair, Month 1 = 2026-11-08)
  - Functional-Equivalence Scoring Spreadsheet (staging area, lift capacity, access timing)
  - Monthly Site-Compliance Baseline Tracker (4-hour staging access, 48-hour exercise notice compliance)
  - Per-Site Detection-Rate Divergence Analysis (flag if >15% divergence from pooled rate, monthly during Phase One)

**Frequency:** Pre-Phase-One validation (Months 0–1 = 2026-10-08 to 2026-11-08); monthly parity monitoring during Phase One (Months 6–9 = 2027-04-08 to 2027-07-08)

**Responsible Role:** Site-Selection Track Lead (1 per country, Program Operations Center) for entry-condition audit; Evidence and Verification Committee for Phase-One parity monitoring and detection-rate divergence flagging

**Adaptation Process:** Entry-condition phase: bilateral site-selection audit teams (technical specialists from each country) visit proposed sites, document access scope, facility layouts and functional equivalence against criteria (staging ≥500 sq m, 24-hour access, lift ≥50 tons, ≥2 maintenance events/month). Mismatched pairs (asymmetric access, <<500 sq m staging, or lift <50 tons at one site) are flagged. Co-chairs review audit reports and jointly approve only pairs meeting functional-equivalence standard; asymmetric pairs are excluded from Phase One rather than included with footnotes. During Phase One: Evidence Committee monitors each site's detection rate monthly, flagging any single site whose detection rate diverges >15% from the pooled detection rate (indicator of asymmetric access or operator resistance). If divergence detected, Program Operations escalates to co-chairs within one week with an assessment of whether the asymmetry is correctable (operator delay, training gap) or systematic (operator shielding suspected). Correctable asymmetry: enforcement action and remediation plan. Systematic asymmetry: site suspension or exclusion from Phase One.

**Adaptation Trigger:** Reciprocal-access parity audit (Month 1 = 2026-11-08) reveals >1 matched pair with asymmetric access (e.g., one side denied 24-hour staging access, other side grants immediate access; one staging area <500 sq m vs. ≥500 sq m at counterpart). During Phase One, detection-rate divergence >15% between a single site and the pooled rate (e.g., pooled 70%, single site 50%), sustained for ≥2 consecutive months, indicates access asymmetry. Parity score (Definition TBD) falls <85% target (proposed threshold). Operator refusal to comply with baseline access expectations (4-hour staging access, 48-hour exercise notice) confirmed via written violation log; escalation to co-chairs if compliance violations >2 per site per month

### 3. Vendor-Refusal Fallback-Ladder Implementation and Equipment-Unverifiable-Count Monitoring
**Monitoring Tools/Platforms:**

  - Vendor-Participation Registry and Refusal Log (refusal incidents, fallback rung attempted, timeline, disposition)
  - Accredited Independent-Examiner Status Tracker (capacity, assignments, completion dates per rung per vendor refusal)
  - Unverifiable-Equipment Count Spreadsheet (by site, by equipment class, by cause: vendor refusal, IP-protection claim, attestation unavailable, filter dispute)

**Frequency:** Continuous incident tracking (refusals logged within 24 hours of occurrence); weekly Vendor Liaison Office status calls; monthly Evidence Committee review of unverifiable counts and fallback-ladder progress

**Responsible Role:** Vendor Liaison Office (5 per country: legal, compliance, technical, logistics, adjudication) for incident response and fallback-ladder sequencing; Evidence and Verification Committee for unverifiable-equipment root-cause analysis; independent examiner teams (1 per country, pre-staged from testing envelope) for fallback execution

**Adaptation Process:** Vendor refusal documented by Vendor Liaison Office within 24 hours of notification. Fallback ladder initiated immediately: (1) vendor-supervised testing offered (target 8–12 weeks, often declined); (2) if refused, filtered evidence pathway with filter auditor certification (2–3 days per package); (3) if refused or insufficient, accredited independent-examiner team deployed (8–12 weeks); (4) if access barriers remain, clean-room procedure or validated attestation. Each rung completion documented. If all rungs exhausted or timeline prevents completion before Phase One entry (Month 6 = 2027-04-08), equipment classified as unverifiable and escalated to co-chairs: decision to exclude equipment from the covered-equipment schedule or fail the site from Phase One entry. During Phase One, unverifiable-equipment count tracked monthly. If count exceeds 5% of all equipment at a site or >10% overall, Evidence Committee conducts root-cause analysis: is the evidence-rule too strict (false positives mimicking unverifiable), or are vendors/operators genuinely blocking evidence? Rule miscalibration triggers post-Phase-One review (rule adjustments deferred; thresholds locked for Phase One). Genuine unverifiable counts >10% at a single site become a potential Stop trigger.

**Adaptation Trigger:** Vendor refusal documented by Month 2 (2026-12-08); fallback ladder incomplete by Month 5.5 (2027-03-23) entry-condition deadline, leaving equipment unverifiable at entry. Unverifiable-equipment count at any site exceeds 5% of equipment assigned to that site (proposed threshold). Unverifiable counts surge to >10% overall across all sites (proposed threshold), triggering Stop-trigger assessment. Multiple simultaneous vendor refusals (≥3 vendors refusing in the same month) at different sites exceeding examiner capacity (estimated 10–16 examiners per country, ~1–2 sites simultaneously), causing queue delays and unresolved refusals to extend past Phase One entry. Vendor refusal attributed to government shielding (one government prevents its vendor/operator from participating in fallback procedures), confirmed via written non-cooperation notice; automatic Stop trigger

### 4. Evidence-Weighting Rule Calibration and False-Positive/False-Negative Validation
**Monitoring Tools/Platforms:**

  - Draft Layered Evidence Weighting Model (versioned escrow, Month 4.5 = 2027-02-23)
  - Historical-Record Validation Dataset (100–200 equipment-change records per site, applying draft rule to past events)
  - False-Positive and False-Negative Analysis Report (pilot and historical validation, target 10%±3% false positives, <5% false negatives)
  - Evidence-Rule Version-History Log (amendments with effective dates and application to each event)

**Frequency:** Draft rule placed in escrow Month 4.5 (2027-02-23); historical validation Months 4.5–5.5 (2027-02-23 to 2027-03-23); rule-adjustment decision by Month 5.5 (2027-03-23); final rule locked before Phase One (Month 6 = 2027-04-08). No mid-test amendments during Phase One (Months 6–9 = 2027-04-08 to 2027-07-08). Post-Phase-One review permitted.

**Responsible Role:** Evidence and Verification Committee (co-chairs jointly approving rule drafts and amendments); technical/attestation and equipment-identifier specialists (2 per country) conducting historical validation; independent auditors spot-checking rule application to recorded Phase-One events

**Adaptation Process:** Evidence Committee drafts the confidential evidence-weighting rule (no single source decisive; specify how attestation, physical inspection, customs records, identifiers, maintenance logs, infrastructure changes and witnessed movement combine into equipment-identity confidence ratings). Draft placed in versioned escrow by Month 4.5 (2027-02-23), jointly approved by both committee co-chairs. Committee applies draft rule to 100–200 historical equipment-change records per site (known ground truth from operator records or maintenance logs). Calculate identity-confidence outputs and compare against known results. Measure false-positive rate (rule flags identity change when operator records confirm no change) and false-negative rate (rule fails to flag an actual change). Target: false positives 7–13% (10% target ±3 points), false negatives <5%. If deviation >5 points (e.g., 25% false positives vs. 10% target), revise the rule and re-validate with a second cohort of historical records by Month 5.5 (2027-03-23). If calibration within 3–5 points of target, flag as a review item but lock the rule. Final rule locked and versioned by Month 5.5 (2027-03-23) for Phase One. During Phase One, maintain a version-history log showing which rule-version was applied to each event. Post-Phase-One, if false-positive or false-negative rates in Phase-One exercises differ materially from historical calibration (>5 points), conduct root-cause analysis (evidence sources differ, inspector procedures differ, equipment changed) and recommend adjustments for Phase Two.

**Adaptation Trigger:** Historical-record validation (Months 4.5–5 = 2027-02-23 to 2027-03-08) shows false-positive rate >15% or <7% (target 10%±3%, deviation >5 points = requires adjustment). False-negative rate >5% detected in historical validation (proposed threshold). Pilot exercise (Month 5 = 2027-03-08) detection outcomes for identity-verification events differ from historical false-positive prediction by >8 points (e.g., historical validation showed 10% false positives, pilot shows 2% or 18%). Post-Phase-One analysis (after Month 9 = 2027-07-08) reveals Phase-One false-positive or false-negative rates differing >5 points from historical calibration; rule is flagged for possible amendment in Phase Two

### 5. Blind-Challenge Exercise Design, Execution, and Detection-Rate Monitoring
**Monitoring Tools/Platforms:**

  - Exercise Authority Scenario Registry and Pre-Registration Log (all 54 scenarios locked before first Phase-One execution, Months 3–5 = 2027-01-08 to 2027-03-08)
  - Weekly Exercise-Result Compilation and Incident Log (during Phase One: events run per week, detection outcomes per event type, scoring documentation, cryptographic attestations)
  - Detection-Rate Estimates per Event Type (with 95% confidence intervals, updated weekly as results accumulate; target ≥70% planned, ≥50% unplanned)

**Frequency:** Pilot exercise Month 5 (2027-03-08), all seven types run once, results used to validate detection procedures but excluded from Phase-One verdict. Scenario pre-registration Months 3–5 (2027-01-08 to 2027-03-08). Phase-One exercises Months 6–9 (2027-04-08 to 2027-07-08): target 6 per month per site = 54 total (6–8 replicates per event type). Weekly exercise-result compilation and detection-rate calculation.

**Responsible Role:** Exercise Authority Director and core staff (8 total, mixed-nationality, independent from co-chairs) for scenario design, execution, and scoring; Evidence and Verification Committee for detection-rate analysis and asymmetry flagging; independent auditors for spot-check validation of exercise scoring and data integrity

**Adaptation Process:** Exercise Authority designs seven event-type scenarios (unreported arrival, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal, reluctant operator) covering all scenarios required by the bilateral instrument. All scenarios pre-registered before the first Phase-One exercise (locked by end of Month 5 = 2027-03-08) without disclosing specific test cases to inspectors. Pilot exercise (Month 5 = 2027-03-08) runs all seven types once at a non-production test facility to validate detection procedures and scoring consistency; pilot results are training-validation data, not counted toward Phase-One verdict. During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08), Exercise Authority executes scenarios in staging, spare-inventory, maintenance or expansion areas without interrupting active computation. Each exercise is scored independently: witness observation, video recording, cryptographic attestation of timestamps and outcomes. Weekly result compilation calculates detection rate per event type (# detected / # attempted) with 95% confidence intervals. If any event type falls significantly below target (e.g., unreported-arrival detection <50% vs. 70% target), Exercise Authority investigates whether procedure is deficient (inadequate inspector training, staging-area access gaps, timing issues) or scenario design is unrealistic. Evidence Committee reviews weekly results and flags any per-site detection divergence >15% from pooled rate (asymmetric access or operator resistance suspected). Monthly report to co-chairs includes detection-rate trajectory and any operational issues (production disruptions, access delays, scenario logistics failures). If exercise load falls below planned frequency due to site disruptions or operator resistance, note the impact on statistical power (fewer replicates per type = wider confidence intervals, reducing verdict defensibility).

**Adaptation Trigger:** Exercise load falls below 5 per month per site (54-exercise target unmet by Month 8 = 2027-06-08), reducing replicates per event type below minimum of 6, widening confidence intervals beyond ±15% at 95% CL (inadequate statistical power). Detection rate for any event type falls to <50% for planned class or <35% for unplanned class by Month 8 (2027-06-08), indicating procedure or operator-access deficiency. Single-site detection rate diverges >15% from pooled rate for ≥2 consecutive months (asymmetric access or systematic operator non-cooperation suspected). Exercises interrupted or delayed >4 hours from scheduled time (production disruption confirmed); >2 incidents per site per month triggers operator-compliance escalation. Cryptographic attestation discrepancies or witness-score disagreements on exercise outcomes (e.g., inspectors claim equipment was substituted, video shows no substitution); >2 scoring disputes per month escalated to Adjudication Panel for technical review

### 6. Equipment-Identity Confidence and Ledger Divergence Monitoring
**Monitoring Tools/Platforms:**

  - Replicated Tamper-Evident Ledger (national copies, one per country, hosted at neutral facility; synchronized via signed-digest exchange every 1 hour)
  - Ledger-Divergence Incident Log (timestamp, affected entries, cause: network failure, key-custody incident, backup corruption, tampering suspected; resolution time)
  - Equipment-Identity Confidence Distribution Spreadsheet (# entries scoring high/medium/low confidence per event class; root causes for low-confidence entries)

**Frequency:** Continuous local recording (at most 5 minutes latency); signed-digest exchange every 1 hour with 30-minute overdue alert; divergence incidents logged within 4 hours of detection. Weekly ledger-integrity audit (sample 5% of events, verify appearance in both national copies). Monthly ledger-divergence and key-custody review (co-chairs briefed).

**Responsible Role:** Root-of-Trust Key Custody Architecture team (1 principal + 1 deputy per country, 4 total) for key management and recovery procedures; ledger hosting and synchronization team (IT specialists, mapped to the secure-facilities envelope) for technical operations; Compliance and Audit Committee for ledger-integrity verification and post-Phase-One audit

**Adaptation Process:** Ledger records events locally at each site within 5 minutes of occurrence (cryptographic timestamp, witness signature). Both national copies are maintained in secure, audited facilities. Synchronization: each hour, both countries exchange cryptographic digests (SHA-256 or stronger) of recorded events. Digests are signed by both countries' keys (dual-hold, double-key authorization: both shares required to sign). If a digest mismatch is detected (one side's digest differs from the other's), an automated dual-ledger audit initiates within 4 hours: both countries' ledger teams perform cryptographic verification of affected entries. Co-chairs jointly determine the cause and authorize remediation. If the divergence is due to network failure (entry recorded locally but sync delayed), re-sync when network is restored and flag the delayed-sync event in the ledger. If key-custody incident is suspected (unauthorized signing, key theft), trigger key-recovery ceremony (both countries' key-custody officers convene within 4 hours; revoke compromised key, generate new key, re-sign affected entries). Unresolved divergence exceeding 7 days escalates to emergency summit and triggers partial suspension of ledger-dependent functions (evidence disclosure paused until divergence is resolved). Monthly, independent auditors sample 5% of recorded events (estimated 15–25 per month at typical volume of 5–10 events per day per site) and verify cryptographic signatures against the published key registries and check that each event appears in both national ledger copies within the 1-hour sync bound.

**Adaptation Trigger:** Ledger-divergence incident occurs (a digest mismatch between national copies); any divergence unresolved for >7 days (hard threshold, proposed). Multiple divergences (≥3) in a single month without clear resolution pattern (systematic sync failures or recurrent key-custody issues). Key-custody incident (lost key, suspected compromise, or contested key): key blocked from signing, ledger entries stall for >8 hours (recovery procedures not executing timely). Ledger audit finds >2% of sampled events (out of 5% sample) with missing signatures or non-matching cryptographic verification. Equipment-identity-confidence distribution shows >20% of entries scoring 'low confidence' due to ledger inconsistencies (unresolved divergence in prior sync)

### 7. Deadlock Resolution, Adjudication-Caseload, and Discrepancy-Age Monitoring
**Monitoring Tools/Platforms:**

  - Discrepancy Tracking Spreadsheet (case ID, opening date, classification: identity, exit disposition, access delay, vendor refusal, reluctant operator; current age, responsible adjudicators, resolution status)
  - Deadlock Escalation Timeline (case progress: inspector-level discussion [0–10 days], Adjudication Panel referral [day 10–18], co-chair decision [day 18–21]; partial-suspension trigger [day 14]; impaired-confidence trigger [day 21 for identity, day 28 for exit])
  - Adjudication Panel Status Log (cases open, recommendations issued, co-chair decisions, published rationale for overrides if any)

**Frequency:** Weekly discrepancy-age tracking (Mondays during Phase One, Months 6–9 = 2027-04-08 to 2027-07-08); automatic Adjudication Panel convening if case age reaches 10 days; co-chair briefing on cases >21 days (impaired-confidence trigger); escalation to emergency summit if >2 cases exceed 35 days simultaneously

**Responsible Role:** Program Operations Center (tracking case age and escalation timelines); Adjudication Panel (3 specialists per country, 6 total) for technical recommendations; Co-Chair Steering Board for final decisions and partial-suspension orders; Program Risk Officer for cascade-risk flagging (multiple unresolved discrepancies indicating systematic deadlock)

**Adaptation Process:** Discrepancies (equipment-identity questions, exit-disposition disputes, access-delay incidents, vendor-refusal outcomes, or reluctant-operator findings) are opened by inspectors or operational teams and logged in the tracking spreadsheet with timestamp. Case begins at day 0. Inspectors and site-level technical teams have 10 days to resolve through evidence review, supplemental inspection, or operator consultation. If unresolved by day 10, the case escalates to the Adjudication Panel (automatic trigger, no co-chair pre-approval needed). Adjudication Panel convenes (both countries' 3 specialists) and reviews the evidence: underlying facts, applicable evidence-weighting rule, any filter disputes or disclosure-tier issues. Panel issues a technical recommendation within 5 days (day 15 from case opening): is the discrepancy 'material' (affects Go/Modify/Stop verdict or creates an audit exception) or 'process' (administrative)? Which evidence category is most probative? Should a retry of the investigation occur? Panel recommendation is non-binding on co-chairs but is published and logged in the ledger; co-chairs must formally confirm or override it. Co-chairs have 3 days (day 18 from case opening) to decide. If co-chairs agree with the Panel's recommendation, case is resolved. If they disagree, co-chairs must publish their override rationale in the ledger (transparency requirement). If co-chairs still deadlock (neither accepts the Panel recommendation nor can agree on an override) by day 18, the case triggers automatic partial suspension at day 14 (earlier threshold): the disputed function (e.g., intake verification if the discrepancy is identity-related; exit procedures if it's a departure disposition) is automatically paused, recorded in the ledger as an event, and both co-chairs are notified. Unrelated verification continues (e.g., if intake is suspended, exit verification and equipment-maintenance monitoring continue). Partial suspension stalls the disputed function but preserves operational continuity. The suspended case remains open and moves to impaired-confidence status at day 21 (for identity disputes) or day 28 (for exit disposition disputes). If multiple cases pile up (estimated capacity ~15 cases per month in adjudication pipeline), and >2 cases simultaneously exceed day 35, a cascade-risk alert triggers: the Program Risk Officer notifies co-chairs that systematic deadlock is occurring, and an emergency summit is convened to assess whether the Adjudication Panel charter needs revision, evidence-rule clarity improved, or whether a broader scope change is warranted.

**Adaptation Trigger:** Discrepancy age exceeds 10 days without inspector resolution → Adjudication Panel automatically convenes. Discrepancy age exceeds 14 days without Panel recommendation → automatic partial suspension of disputed function (recorded in ledger). Discrepancy age exceeds 21 days (identity) or 28 days (exit) → impaired-confidence status applied (case remains open, function remains suspended; escalation to co-chair summit if suspension >35 days). Two or more cases simultaneously exceeding 35 days of age (≥3 cascading across time horizon suggests systematic co-chair deadlock on adjudication); or adjudication caseload exceeds 20 open cases (estimated capacity 15/month), backlog accumulating → Program Risk Officer flags as cascade risk, triggers emergency co-chair review. Unresolved discrepancies >5 at Phase One conclusion → potential Stop trigger (if combined with other metrics below thresholds)

### 8. Contingency-Budget Depletion and Envelope-Mapping Compliance
**Monitoring Tools/Platforms:**

  - Monthly Envelope Reconciliation Report (100% invoice sampling: envelope classification accuracy, supporting documents, dollar amount, country, cost center; exception tracking for >2% variance)
  - Contingency-Burn Dashboard (cumulative USD drawn against the 500M pool; percentage benchmarks: 30% [150M] = co-chair briefing, 50% [250M] = scope-reduction planning, 75% [375M] = joint budget review)
  - Quarterly Budget Actuals-vs-Plan Analysis (variance per envelope, per country; overruns >110% and >120% thresholds; forecast through Phase One conclusion)
  - Independent Auditor Reconciliation Report (monthly unclassified summary, audit exceptions and corrective actions)

**Frequency:** Monthly envelope reconciliation (invoices due by 10th of following month, audit review by 20th, findings published by 25th); weekly budget-status calls (budget analysts, 1 hour); bi-weekly Compliance and Audit Committee meeting (2 hours, deep-dive on envelope variances and contingency burn); quarterly actuals-vs-plan review with co-chairs (co-decision on scope reductions or supplemental-appropriation request if any envelope exceeds 120%)

**Responsible Role:** Compliance and Audit Committee co-chairs (1 per country, FTE, reporting independently to co-chairs and respective finance ministries); budget analysts (2 per country, tracking invoices and exceptions); independent external auditors (3–5, third-country nationals, signing off on monthly reconciliation and quarterly variance analysis)

**Adaptation Process:** Invoices and supporting documents from both countries submitted by 10th of following month, classified by envelope and cost center. Budget analysts and envelope auditors review 100% of invoices for proper classification, completeness of documentation, and accuracy of amounts. Exceptions (incorrect envelope, missing documentation, duplicate entries, unexplained variance >2%) are flagged and returned to submitter for correction by 15th. Corrected invoices reconciled by 20th; audit summary published by 25th showing total spend per envelope, percentage of budget consumed, exceptions found and resolved. Monthly reports are bilingual and unclassified (shared with legislatures). Contingency draw requests require approval from both the requesting country's program director and the Compliance Committee co-chair, plus independent auditor review, before disbursement. Contingency-burn rate tracked against cumulative draws: if draws reach 30% of the 500M (150M) by Month 4 (2027-02-08), a co-chair briefing is triggered alerting both to accelerated spending. If 50% (250M) is reached by Month 6 (2027-04-08), scope-reduction planning is initiated: co-chairs jointly decide whether to reduce matched sites (3 pairs → 2), shorten Phase One (90 → 60 days), or defer Phase Two. If 75% (375M) is reached by Month 8 (2027-06-08), a formal joint budget review occurs with independent auditors present, assessing whether the remaining contingency (125M) is sufficient to complete Phase One operations or whether supplemental appropriations are needed (veto point: either country can refuse). Any single envelope exceeding 110% of plan (e.g., personnel envelope USD 750M × 1.1 = 825M) triggers a co-chair review and decision on contingency draw or scope reduction. Exceeding 120% (e.g., 900M) requires a supplemental-appropriation request to both governments' legislatures (estimated 2–4 week process), delaying operations.

**Adaptation Trigger:** Monthly invoice reconciliation reveals >5% variance in an envelope classification (e.g., 10% of submitted invoices are reclassified to a different envelope), triggering budget-submission process review and training. Cumulative contingency draws reach 30% (150M) by Month 4 (2027-02-08) → co-chair briefing on burn rate and Phase-One feasibility. Cumulative draws reach 50% (250M) by Month 6 (2027-04-08) → mandatory scope-reduction planning (record decision to reduce sites or shorten test window). Any single envelope exceeds 110% (e.g., personnel at 825M vs. 750M plan) → co-chair review and contingency-draw decision. Any envelope exceeds 120% (e.g., personnel at 900M) → supplemental-appropriation request, stop-work risk. Contingency-burn trajectory predicts exhaustion before Phase One end → emergency co-chair summit to authorize scope reduction or budget cap-out. Per-country allocations diverge significantly (e.g., one country spending 2,600M while the other is at 2,400M; proposed threshold: >5% divergence from 50/50 parity) → investigation of cost drivers and rebalancing decision

### 9. Funding Timeliness and Tranche-Release Synchronization
**Monitoring Tools/Platforms:**

  - Synchronized Tranche-Release Schedule and Status Log (4 synchronized tranches per country: 25% Month 2, 25 = 2026-12-08, 2028-11-08% Month 3, 30 = 2027-01-08, 2029-04-08% Month 5.5, 20 = 2027-03-23, 2028-06-08% Month 9.2 = 2027-07-14; actual deposit dates, amount, country, reconciliation)
  - Tranche-Delay Escalation Tracker (if either tranche is delayed >14 days: co-chair briefing; if >30 days or asymmetric deposits: auto-Stop trigger recorded)

**Frequency:** Weekly funding-status verification (budget analysts, confirm deposits and timing); immediate escalation if >14-day delay detected (within 24 hours to co-chairs); monthly tranche-release reconciliation (Compliance and Audit Committee)

**Responsible Role:** Compliance and Audit Committee finance officers (1 per country) for deposit verification; Co-Chair Steering Board for tranche-release authorization and escalation

**Adaptation Process:** Both countries' tranches are released in synchronized pairs: Tranche 1 (25% = 625M per country) released by Month 2 (2026-12-08) upon instrument signature and appropriation enactment. Tranche 2 (25% = 625M) released by Month 3 (2027-01-08) upon matched-pair approval. Tranche 3 (30% = 750M) released by Month 5.5 (2027-03-23) upon entry-gate certification. Tranche 4 (20% = 500M) released by Month 9.2 (2027-07-14) upon Go/Modify verdict (not conditional on verdict outcome, just on Phase One conclusion). Each tranche is conditional on both countries depositing simultaneously (parity enforcement); if one country delays depositing its share, the other country does not release its portion. If a tranche is delayed >14 days beyond the scheduled release date (e.g., Tranche 1 due Month 2 = 2026-12-08, not deposited by Month 2.5 = 2026-12-23), a co-chair briefing is triggered automatically on day 14. Co-chairs jointly assess the cause (legislative delay, budgetary hold, political objection) and determine whether to extend the deadline, invoke an emergency summit, or escalate to Stop. If tranche delay exceeds 30 days cumulative (either country, any tranche), or if deposits are asymmetric (one country deposits 625M, the other deposits only 500M), the withholding is recorded as a Stop trigger and Phase One is halted without further negotiation (automatic stop-work order).

**Adaptation Trigger:** Tranche deposit delayed >14 days beyond scheduled release (automatic co-chair briefing and escalation). Tranche deposit delayed >30 days (automatic Stop trigger: funding withholding). Deposits asymmetric: one country's tranche USD amount differs from the other's (proposed threshold: >2% deviation = asymmetric, triggers investigation; >5% = Stop trigger). Tranche release withheld pending political conditions or dispute resolution (any tranche held hostage to a separate negotiation): flags as Stop trigger

# Governance Extra

## Governance Validation Checks

1. Completeness Confirmation: All core governance components have been generated across all five stages: (1) Audit details and corruption/misallocation risks identified; (2) Internal governance bodies established (Co-Chair Steering Board, Program Operations, Evidence and Verification, Compliance and Audit, Counterintelligence Oversight, Root-of-Trust Key Custody); (3) Comprehensive implementation plan with 44 sequential and parallel steps spanning Months -1 to 9.5 (2026-09-08 to 2027-07-23); (4) Decision escalation matrix mapping 12 critical issue types to approval authorities and adaptation triggers; (5) Monitoring and progress-tracking framework with six continuous approaches (entry gates, reciprocal access, vendor fallback, evidence-rule calibration, exercises, ledger integrity, deadlock resolution, contingency depletion). All components reference the bilateral instrument, double-key procedures, deadlock thresholds, and Stop triggers. Framework is operationally specific rather than generic.
2. Internal Consistency Check: Logical alignment across stages is strong but reveals one tension requiring clarification. Implementation plan correctly sequences entry conditions (gates Months 0.5–5.5 = 2026-10-23 to 2027-03-23) before Phase One begins Month 6 (2027-04-08). Escalation matrix maps material finding deadlocks to the Adjudication Panel (correct body from Stage 2) and partial suspension after day 14 (consistent with bilateral instrument threshold). Monitoring framework tracks discrepancy age against these thresholds automatically. However, the evidence-rule validation (pilot exercise Month 5 = 2027-03-08 plus historical validation Months 4.5–5.5 = 2027-02-23 to 2027-03-23) and the Exercise Authority's pre-registration of all 54 Phase-One scenarios (completed by end of Month 5 = 2027-03-08) occur simultaneously with critical entry-gate completions (matched-pair approval Month 3 = 2027-01-08, entry certification Month 5.5 = 2027-03-23). If entry gates slip 2–4 weeks (identified as high-likelihood risk), the evidence-rule calibration window (which depends on historical data from confirmed participating sites) and scenario pre-registration become compressed. The framework documents this risk and triggers emergency summits, but the operational dependency between entry-gate completion and exercise-authority readiness is not explicitly locked in the monitoring plan: it should add a check that scenario pre-registration cannot proceed without final site approval (Month 5.5 = 2027-03-23 entry certification must precede scenario finalization).
3. Specific Gap 1 – Clarity of Role Definition for Advisors and Independent Parties: The Evidence and Verification Committee includes 'red-team representatives (1 per country)' as voting members, yet the Exercise Authority is described as 'mixed-nationality, independent' and designed to be insulated from co-chair and inspector input until after execution. The distinction between the red-team role (designing scenarios that test what each side doubts most) and the Exercise Authority role (independent scenario execution) is operationally unclear. Specifically: (a) Do red-team representatives sit on the Exercise Authority, or do they propose scenarios to the Exercise Authority (which then accepts/rejects independently)? (b) If red-team members are on the Evidence Committee but not on the Exercise Authority, how do they influence Exercise Authority scenario selection without compromising independence? (c) Are red-team members' dual roles (committee advisor + scenario proposer) governed by conflict-of-interest rules? The framework specifies red-team participation in scenario design ('Each country's red team may nominate challenge types but the authority alone decides whether to execute it and when') yet does not document whether red-team members have access to Exercise Authority deliberations or result data before Phase One conclusion. Recommend explicit charter section on red-team/Exercise-Authority firewall and conflict-of-interest rules for dual-role members.
4. Specific Gap 2 – Insufficient Procedural Specificity for Key-Custody Compromise Response Under Dual-Hold Geometry: The Root-of-Trust Key Custody Architecture team (4 total: principal + deputy per country) is tasked with detecting and responding to key-custody incidents (lost keys, suspected compromise, coercion of an officer). The framework specifies that 'both shares required to sign' (dual-hold, double-key authorization principle), yet the key-recovery procedure defines: 'both countries' key-custody officers convene within 4 hours; conduct a 48-hour investigation; issue a joint revocation attestation signed by both countries.' This creates a logical circularity: if a key-custody officer from one country is compromised (coerced or bribed to sign unauthorized entries), how can the joint recovery procedure proceed if that officer is under duress? Specifically: (a) If the US officer is compromised, can the Chinese officer alone authorize a new key-generation ceremony? (b) If both countries' officers disagree on whether a compromise has occurred (one insists the key was lost, the other suspects intentional theft and unauthorized signing), which country can force a key revocation? (c) What is the protocol if one country claims the other's key-custody officer has been compromised and refuses to participate in ceremonies? The framework assigns the Counterintelligence Oversight Board authority to investigate 'suspected breaches,' yet key-custody incidents (cryptographic key compromise) are not explicitly assigned to the CI Board's investigative purview, only to the key-custody team's technical review. Recommend explicit escalation procedure linking CI Board breach investigations to key-custody incident response, including protocols for unilateral key revocation if dual agreement cannot be reached.
5. Specific Gap 3 – Ambiguous Termination Authority and Scope Reopening Clause for Stop/Modify Verdicts: The escalation matrix and monitoring framework define Stop triggers and Modify outcomes but do not specify who decides whether Phase One can be restarted, what Phase Two conditions must be met before restart (if Modify is chosen), or whether the bilateral instrument survives a Stop verdict or must be renegotiated. Specifically: (a) If Phase One is halted via a Stop trigger (e.g., government shields an operator), does the bilateral instrument remain in force for a future restart attempt, or is it terminated and renegotiation required? (b) If a Modify verdict is reached, is Phase Two automatically authorized (same bilateral instrument, same scope), or must both governments re-appropriate funds and amend the instrument? (c) Who has authority to declare Phase One complete versus 'inconclusive, awaiting Phase Two'—is it a joint co-chair decision (double-key) or is the verdict itself mechanically determined, leaving no decision authority? (d) The canonical facts state 'OPEN: whether Modify-directed rework or any Phase Two is funded from the unspent USD 5.0B or needs new appropriations.' This leaves Phase Two funding as an undefined veto point; if one country withholds Phase-Two funding after a Modify verdict, is that a separate Stop trigger, or does the program simply pause indefinitely? Recommend explicit closure rules stating: (i) Stop verdict = bilateral instrument remains in force pending restart negotiation (either country can propose restart); (ii) Modify verdict = Phase Two scope and conditions must be jointly defined by co-chairs within 30 days and submitted to legislatures for re-appropriation decision; (iii) Unresolved Phase-Two funding decision = program suspended indefinitely (treated as a de facto Stop).
6. Specific Gap 4 – Missing Definition of 'Material' vs. 'Process' Discrepancies and Adjudication Authority Boundary: The Adjudication Panel is tasked with classifying discrepancies as 'material' (affects Go/Modify/Stop verdict or audit exception) or 'process' (administrative), yet the governance framework does not provide the classification criteria or examples. The escalation matrix states the Panel 'recommends' classification but does not define when co-chairs can override the Panel's material/process determination or what happens if co-chairs disagree. Specifically: (a) Is a discrepancy 'material' if it involves a single piece of equipment (e.g., one server's identity status ambiguous at one site) or only if it affects an entire equipment class or site? (b) If the Panel classifies a case as 'process' but the co-chairs believe it is 'material,' do co-chairs have unilateral override authority, or must they jointly agree on reclassification? (c) If an unverifiable-equipment count is classified 'process' by the Panel because the vendor refusal fallback was attempted in good faith, can a co-chair unilaterally escalate it to 'material' status and use it as grounds for a Stop trigger? (d) The Compliance and Audit Committee has authority to flag 'envelope-mapping exceptions' (>2% variance) but not to classify their materiality; who decides if an envelope misallocation is a 'material' audit exception vs. a 'process' reclassification? Recommend explicit materiality rubric specifying: (i) material if affects Go/Modify/Stop thresholds or involves >3 equipment items; (ii) process if administrative or affects <3 items; (iii) Panel classification is binding on both co-chairs unless jointly overridden with published rationale.

## Tough Questions

1. Entry-Condition Compression Risk: If the bilateral instrument signature slips from the planned Month 1 (2026-11-08) deadline to Month 2 (2026-12-08) due to legislative delays, and this cascades to a 4-week cumulative slip in entry-gate completion (moved from Month 5.5 = 2027-03-23 to Month 6.5 = 2027-04-23), how will Phase One's 90-day window be preserved—by extending the clock to Month 15 (2028-01-08), compressing the test to 60 days (reducing exercises from 54 to 36 and statistical confidence from ±12% to ±20%), or by reducing matched sites from 3 to 2 pairs? Which scope reduction will co-chairs choose, and by what date must the decision be published to legislatures?
2. Evidence-Rule False-Positive Calibration Deficiency: The framework specifies that the draft evidence-weighting rule will be validated on 100–200 historical equipment-change records per site (Months 4.5–5 = 2027-02-23 to 2027-03-08) with a target false-positive rate of 10% ± 3 percentage points. If the pilot validation shows false-positive rate of 18% (within the acceptable band but near the upper bound), and Phase-One exercises subsequently yield a false-positive rate of 22%, does the Evidence Committee immediately suspend the rule pending adjustment (risking mid-test procedural disruption), or lock the rule as planned and defer adjustment to post-Phase-One review (risking inflation of discrepancy counts and adjudication overload)? What is the pre-agreed threshold for mid-test rule adjustment, and who has authority to override the 'rule frozen through Phase One' policy?
3. Deadlock-Triggered Partial-Suspension Operationalization: The framework specifies automatic partial suspension of a disputed function (e.g., intake verification paused, exit procedures paused) after 14 days of co-chair deadlock without pre-approval. If both countries' inspectors at a site are trained to conduct intake verification, and that function is suspended pending a deadlocked discrepancy resolution, who authorizes the suspension reversal when the deadlock is resolved (the co-chairs who were deadlocked, or an automatic procedure)? If suspension remains in effect for >35 days, does the site automatically fail Phase One, or does it continue operating under partial suspension? If 2+ sites are under partial suspension simultaneously (different disputed functions at each), how is Phase-One statistical validity maintained for exercises that depend on the suspended functions?
4. Vendor-Refusal Fallback-Ladder Timing and Feasibility: The framework pre-stages one accredited independent-examiner team per country (5–8 specialists) from the USD 500M testing envelope. If 3 vendors simultaneously refuse vendor-supervised testing during Phase One (Months 6–9 = 2027-04-08 to 2027-07-08) and all require independent-examiner validation (each taking 8–12 weeks), how are 3 concurrent examinations (estimated 15–24 weeks of work per country's team of 5–8) completed within a 90-day window? Specifically, provide the capacity constraint analysis: how many independent-examiner full-time-equivalents are actually available per country, how many concurrent examinations can each team conduct, and what is the maximum queue delay if vendor-refusal demand exceeds capacity? At what queue age does a refusal become a Stop trigger?
5. Reciprocal-Access Parity Detection and Remediation During Operations: The framework specifies that if a single site's detection rate diverges >15% from the pooled detection rate for 2+ consecutive months during Phase One, the Evidence Committee flags asymmetric access and escalates to co-chairs for investigation. However, the framework does not specify a remediation timeline: if the investigation confirms operator non-cooperation at a US site (denying immediate staging access), can the co-chairs unilaterally mandate the operator to comply, or does the US government have final authority? If operator non-compliance cannot be reversed mid-test, is the site immediately suspended (removing 1 of 3 matched pairs, halving exercise load), or does the site continue operating with acknowledged asymmetry, accepting lower statistical power and contested Go verdict? Provide the explicit authority chain: Program Operations → co-chairs → national government authority → operator enforcement mechanism, with timeline.
6. Ledger-Divergence Forensic Investigation Authority Under Dual-Custody Governance: If a ledger divergence is discovered (Site A's entry appears in the US national copy but missing from the Chinese copy, or vice versa) and investigation determines that one country's key-custody officer may have signed unauthorized entries, what is the forensic procedure? Does the Counterintelligence Oversight Board investigate (counterintelligence allegation)? Does the Root-of-Trust Key Custody Architecture team investigate (cryptographic anomaly)? Or does a joint trilateral team (both countries + independent auditor) investigate? Who has authority to declare a key-custody incident 'confirmed' vs. 'unconfirmed'? If both countries' co-chairs disagree on whether the divergence was caused by network failure (no misconduct) or by key compromise (requires revocation), how is the disagreement resolved without a casting vote, and how long can the ledger remain diverged pending resolution?
7. Final Verdict Threshold Ambiguity and Mechanical Scoring Enforcement: The framework specifies that verdict thresholds are 'pre-registered and locked before first Phase-One exercise' and that verdict scoring is 'mechanical, no judgment call.' However, if the pooled detection-rate estimate falls in the ambiguous zone (e.g., 72% with 95% confidence interval 60–84%, straddling the 70% Go threshold), and the two co-chairs interpret the interval differently (one says 'upper bound is 84%, well above 70%, Go is justified'; the other says 'lower bound is 60%, below 70%, Modify is required'), how is the mechanical scoring rule applied when both interpretations are arithmetically valid? Which co-chair's interpretation prevails, or must a mathematical rule be pre-specified (e.g., 'Go requires that the lower bound of the 95% confidence interval exceeds the threshold')? Provide the explicit mechanical rule for verdict determination when confidence intervals straddle thresholds.

## Summary

The Consortium governance framework is a rigorous, bilateral double-key structure designed to operate an unprecedented 90-day US–China frontier-computing equipment-verification proof-of-concept with USD 5 billion in fixed appropriations, mirrored national inspectorates (180 per country), and tamper-evident replicated ledgers. The framework balances credible detection (through blind-challenge exercises and layered evidence) with operational continuity (partial suspension instead of brittle shutdowns), transparent parity (reciprocal site selection and matching), and constrained scope (declared-equipment changes only, no hidden-facility detection). Strengths include explicit entry-condition gates with 2-week slip escalation, pre-registered verdict thresholds locked before exercises begin, automatic deadlock escalation via the Adjudication Panel, and comprehensive risk-tracking via weekly KPI dashboards and monthly audits. Key governance levers—evidence-weighting rule calibration, deadlock-and-suspension mechanics, exercise independence, verdict threshold clarity, and inspector information barriers—are identified and operationalized. However, critical ambiguities remain in red-team/Exercise-Authority firewall definitions, key-custody compromise response under dual-hold geometry, Stop/Modify scope-reopening authority, material-vs-process discrepancy classification criteria, and mechanical verdict-scoring rules when confidence intervals straddle thresholds. These gaps should be resolved in the bilateral instrument and committee charters before Phase One entry (Month 5.5 = 2027-03-23) to prevent mid-test disputes over procedure authority and threshold interpretation.