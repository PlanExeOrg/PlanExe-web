# Governance Audit


## Audit - Corruption Risks

- Inspectors using verified access to collect intelligence on undeclared equipment, workload topology, or operational security beyond the declared scope, either for personal advancement or coercion by their own services.
- Equipment-identity collusion between an operator and a manufacturer to falsify attestation credentials or maintenance records, concealing undeclared arrivals or substitutions from inspectors while maintaining false evidence in the ledger.
- Vendor-refusal gaming: a manufacturer deliberately refuses cooperation to delay verification, then provides substitute evidence (clean-room testing, independent examiner) that is pre-arranged to certify false identity, moving equipment through unverifiable status without detection.
- Bilateral adjudication-unit capture: personnel from one country steering forensic findings or identity rulings in favor of their own sites' equipment claims, either through selective evidence weighing or delayed escalation to co-chairs when findings are adverse.
- Asymmetric access exploitation: one government grants its inspectors wider zone access, longer maintenance windows or faster-track escalation authority than the counterpart, enabling unequal visibility and creating leverage for concealment or intelligence collection on the other side's equipment.
- Contingency-budget misappropriation: either government diverts emergency-access or surge-capacity contingency funds (USD 500M shared, USD 50M per-country fast-lane) to unrelated national-security or operational programs without co-chair approval, reducing tested reserves.

## Audit - Misallocation Risks

- Operator compensation absorbed into the USD 1.0B site-preparation envelope without rigorous cost controls; each country pays domestic operators from its own budget share, creating opacity and incentive for operator markup or fictitious staffing to justify equipment-access charges.
- Double-key budget releases requiring weekly co-chair consensus, but one co-chair delaying approval for procedural or political reasons, causing budget tranches to sit unspent and triggering either forced compressed deployment or cost variance >5%, consuming contingency.
- Pre-clock calibration exercise consuming equipment, inspector time and independent-examiner capacity (estimated 50–100 events per site, 3–5 staff weeks per site), reducing surge reserves and front-loading costs that squeeze formal-test budget late (estimate: USD 2–5M per site).
- Ledger and communications infrastructure (USD 1.25B envelope) front-loaded with cryptographic ceremonies, facility setup and redundant secure links by Month 1 (2026-11-08), but infrastructure underutilized during gate delays; extended vetting timelines leave ledger running idle for 2–4 months (estimate: USD 20–30M sunk cost per month of delay).
- Shift-roster staffing at approved baseline (144 inspectors per country, full-time with leave buffer), but actual utilization during early Phase One sparse if sites are not fully operational or equipment arrivals are lower than forecast, leaving personnel on standby; baseline USD 75–100M per-site annual cost partially wasted (estimate).
- Vendor-refusal escalation ladder consuming independent examiner and clean-room facility capacity for 10–20% of deployed equipment (estimate: 500–1,000 units per site), exhausting the USD 0.5–1.2M testing budget per site and forcing late engagement at 2–3x cost (estimate: USD 1.5–4.0M per site, overrun USD 0.9–2.8M).

## Audit - Procedures

- Monthly fiscal-accountability audit of actual spending per budget envelope (ledger USD 1.25B, site prep USD 1.0B, personnel USD 0.75B, facilities USD 0.75B, testing USD 0.5B, legal USD 0.25B, contingency USD 0.5B) against planned expenditure, variance flagged if >5% within Month 0–3 (2026-10-08 to 2027-01-08), with cost-center-level reconciliation and double-key co-chair sign-off on any tranche release >USD 25M.
- Quarterly independent audit of ledger integrity, cryptographic signing validity, and sync-divergence event counts; validation that <4-hour detection time and <7-day unresolved divergence thresholds are met or escalated; offline backup recovery drills and failover testing conducted and documented monthly.
- Post-exercise independent audit of challenge-exercise scenario design, blind integrity (whether operators or inspectors had advance knowledge), scoring methodology and result reproducibility; scoring reviewed by independent auditors per country and compared for bias; all exercise data retained and logged in the ledger.
- Monthly inspector conduct and access-log audit by a bilateral conduct-review panel, checking for zone-boundary violations, unauthorized device access, evidence-handling chain-of-custody, rotation compliance and rotation-compliance gaps; any Tier 2 or Tier 3 infraction documented and escalated within 24 hours.
- Bi-weekly entry-conditions gate review by equal national co-chairs, tracking progress on bilateral instrument, appropriations, domestic access authority, site selection, inspector vetting, operator/vendor agreements and equipment schedule; blockers escalated to political level if any condition lags >4 weeks behind plan.
- Ad-hoc event-level audit of contested equipment-identity findings within 48 hours of a divergence or discrepancy escalation; joint forensic panel reviews layered evidence (attestation, inspection, records, identifiers) against the fixed corroboration rule; findings documented in the ledger with provenance and reasoning; if unresolved at 7 days, automatic escalation to co-chairs for double-key decision.

## Audit - Transparency Measures

- Bilateral KPI dashboard published monthly and accessible to both co-chairs, listing detection rates by event type (unreported arrivals, substitutions, record falsification), false-positive and false-negative counts, equipment-identity confidence scores, ledger-sync divergence events and resolution time, reciprocal-access parity metrics, discrepancy age and tiering, unverifiable-equipment counts, vendor-refusal outcomes, production-disruption incidents, funding-timeliness status and audit exceptions; all figures marked provisional or validated; thresholds locked and published by Month 5.5 (2027-03-23).
- Published redacted ledger entries (with operational security filtering) accessible to both governments and independent auditors on a rolling 30-day delay, showing equipment identities, intake/exit dispositions, maintenance events, third-party access windows, discrepancies escalated and their tier, and decision outcomes; co-chairs review entries weekly for anomalies or asymmetric recording.
- Bilateral steering-committee meeting minutes published (redacted for classified details) monthly from Month 0 (2026-10-08), documenting entry-condition progress, budget releases, schedule changes, escalated disputes, and co-chair decisions on protocol amendments or threshold adjustments; published within 10 days of each meeting to both sides and to pre-agreed third-party auditors.
- Documented written rationale for every protocol change, threshold adjustment, site-level finding and co-chair decision; all justifications retained in a timestamped decision log co-signed by both co-chairs, making it auditable whether changes were made arbitrarily or according to pre-agreed rules; the log published (redacted for security) within 30 days of each decision.
- Three-tier inspector conduct-violation log (Tier 1 warnings, Tier 2 formal notices, Tier 3 removals) published in monthly summary form to both co-chairs, listing infraction type, date, alleged breach, investigation findings and outcome; full details retained in a secure bilateral database for auditor access; zero unauthorized collection incidents and zero substantiated espionage claims required for Go decision.
- Auditor-attestation report published quarterly (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08) by independent third-party auditors jointly selected by both co-chairs, covering ledger resilience, evidence-handling chain of custody, compliance with entry-condition timelines, spending against budget envelopes, personnel vetting and clearance status, and spot checks of zone-boundary enforcement and exercise integrity; report accessible to both governments and retained for post-Phase-One review.

# Internal Governance Bodies

### 1. Bilateral Executive Steering Committee (BESC)

**Rationale for Inclusion:** The Consortium is a high-stakes, dual-sovereignty US–China national-security program requiring equal, non-hierarchical strategic oversight. The BESC serves as the top-level governance body ensuring mutual accountability, reciprocity and double-key decision authority. It addresses the plan's core tension: both countries must retain veto power on strategic decisions (budgets, protocol changes, site findings, suspension) while avoiding deadlock paralysis. No single country can override the other; no casting vote is permitted.

**Responsibilities:**

- Approve all double-key strategic decisions: budget tranches >USD 25M, protocol changes, site-level findings, suspension or impaired-confidence triggers, and Go/Modify/Stop thresholds
- Resolve deadlock on decision-critical items within the escalation clock; escalate unresolved items >7 days to a neutral referee panel after 48 hours of co-chair negotiation
- Certify all mandatory entry conditions (bilateral instrument, appropriations, domestic authority, site selection, inspector vetting, operator/vendor binding, equipment schedule) by Month 6 (2027-04-08)
- Monitor entry-condition milestones weekly and escalate any condition lagging >4 weeks behind plan to political leadership
- Quarterly review of KPI dashboard, ledger integrity, inspector conduct, and reciprocal-access parity; monthly sign-off on tranche spending and variance flagging
- Authorize contingency-budget release: fast-lane decisions up to USD 50M (USD 25M per side) within 5 business days; larger contingency draws require extended co-chair consensus

**Initial Setup Actions:**

- Ratify the bilateral instrument and nominate equal national co-chairs by Month 0.5 (2026-10-23)
- Establish weekly steering-committee meeting schedule and decision-recording protocols, starting Month 0.5 (2026-10-23)
- Define written escalation and deadlock-resolution procedures, including neutral referee-panel selection and co-chair decision rights during Phase One
- Decompose domestic authority requirements per country and assign entry-condition owners with explicit milestones
- Pre-authorize the joint forensic panel, independent testing unit, and bilateral conduct-review panel leadership
- Lock the bilateral instrument governance terms: double-key requirement, no casting vote, veto scope, and suspension/escalation thresholds

**Membership:**

- US National Co-Chair (Cabinet-level or senior executive)
- Chinese National Co-Chair (equivalent State Council or Communist Party level)
- US Deputy: Head of US National Operations Unit or designated co-chair proxy
- Chinese Deputy: equivalent Head of National Operations Unit or proxy
- Observer: Neutral third-party facilitator (optional, non-voting; may be drawn from IAEA, OSCE or agreed neutral state)

**Decision Rights:** Unrestricted authority to approve or reject any strategic decision affecting Phase One scope, schedule, budget or outcome. Double-key required for: budgets >USD 25M, protocol changes, site findings, suspension/impaired-confidence status, threshold adjustments, entry-condition certification. Neither co-chair may unilaterally suspend a site; unilateral action by one co-chair invalidates the decision unless reversed within 24 hours by joint agreement. Escalation of unresolved disputes to a neutral referee panel after 7 days of disagreement is mandatory.

**Decision Mechanism:** Unanimous consent required for all double-key decisions; no voting, majority override, or casting vote. If consensus cannot be reached within 7 days on a decision-critical item, the matter escalates automatically to a neutral independent referee panel (3–5 senior officials, not from either country) who provides a non-binding written opinion within 5 days. Each co-chair retains veto authority; if both reject the panel's opinion, the item remains unresolved and escalates to political leadership via an agreed crisis-management protocol. No decision is final until both co-chairs sign and both national ledger copies record it.

**Meeting Cadence:** Weekly steering-committee meeting (minimum 1.5 hours) dedicated to entry-condition tracking, budget authorization, escalation review and consensus building, Months 0–6 (2026-10-08 to 2027-04-08). During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08), bi-weekly meetings for KPI review, incident escalation and contingency decisions. Post-Phase-One, monthly meetings for final-decision preparation.

**Typical Agenda Items:**

- Entry-condition milestone tracking and blocker escalation (weekly Months 0–6 = 2026-10-08 to 2027-04-08)
- Budget-tranche authorization, spending variance >5% flagging, and contingency-release decisions
- Ledger divergence and forensic-panel findings escalation; deadlock resolution
- Inspector-conduct incident review, Tier 2 and Tier 3 violations, and rotation compliance
- KPI dashboard review: detection rates, false positives/negatives, equipment-identity confidence, unverifiable count, vendor-refusal outcomes
- Protocol-change proposals and double-key amendment sign-off
- Reciprocal-access parity metrics and asymmetry allegations
- Final decision preparation: Go/Modify/Stop threshold validation, evidence quality review

**Escalation Path:** Deadlock unresolved after 7 days escalates to an independent neutral referee panel (3–5 senior officials from pre-agreed third countries or international organizations, jointly selected by co-chairs at Month 0.5 = 2026-10-23). Referee panel issues a non-binding opinion within 5 days. If co-chairs reject the opinion or remain deadlocked after the panel's opinion, the issue escalates to political leadership (ministers or equivalent) for crisis resolution. Automatic suspension of the affected site or event class triggers if deadlock persists >14 days on a contested equipment-identity or site-status matter, unless both co-chairs jointly authorize an extension.
### 2. Joint Forensic and Evidence Adjudication Panel

**Rationale for Inclusion:** Equipment-identity disputes and ledger divergence are at the core of Phase One risk. The plan requires that no single evidence source is decisive; corroboration across multiple layers is mandatory. When national teams disagree on whether evidence is sufficient (e.g., attestation vs. physical inspection vs. records), an independent internal adjudication mechanism is essential. The JFEAP resolves contested identities and divergences within 48 hours, preventing disputes from escalating to co-chairs and consuming deadlock time. This panel is neutral to both countries but internal to the program, ensuring fast binding or co-chair-delegated resolution.

**Responsibilities:**

- Review all contested equipment-identity findings within 48 hours of a discrepancy escalation or ledger divergence that involves identity uncertainty
- Apply the fixed, pre-agreed corroboration rule (physical inspection + identifier match + validated attestation where available; if attestation unavailable, physical inspection + 2 independent records) to disputed identities
- Determine whether evidence meets the corroboration threshold; if not, mark the item unverifiable or escalate to co-chairs with detailed justification
- Document all forensic findings in the ledger with full provenance: which layers agreed, which diverged, reasoning for acceptance/rejection of each layer
- Resolve equipment-identity disputes arising from ledger divergence between national copies; issue a binding finding on which copy's record is supported by evidence
- Adjudicate vendor-refusal escalations: determine whether fallback evidence (independent examiner, clean-room, validated attestation) is sufficient to confirm identity or justify unverifiable classification
- Track discrepancy-clock timers and escalate items that exceed Tier 1 (24h) and Tier 2 (72h) deadlines; provide technical opinion on whether additional fact-finding can close the item before Tier 3 (14d) expiry

**Initial Setup Actions:**

- Jointly select panel members (3–5 per country, equal membership, total 6–10 specialists) with expertise in hardware identity, cryptographic attestation, forensic analysis and supply-chain security, nominated by Month 1 (2026-11-08)
- Establish and document the fixed corroboration rule, signed by both co-chairs and published in the bilateral instrument by Month 2 (2026-12-08)
- Conduct a pre-test identity-verification exercise on non-covered equipment (Month 1.5 = 2026-11-23) to validate the panel's forensic procedures and corroboration application
- Define escalation protocols: minor disputes (equipment ID off by serial-number digit) resolved within 24 hours; major disputes (attestation vs. physical inspection conflict) escalated to co-chairs by hour 36
- Establish a secure shared evidence repository (ledger-integrated) where all contested identity claims, evidence layers and forensic findings are recorded with timestamps
- Create a dispute-resolution SOP specifying when the panel can issue binding findings vs. when consensus is required; clarify when disputes default to co-chair decision

**Membership:**

- Panel Chair: Senior neutral technical specialist (e.g., from an international cryptography or hardware-assurance body, agreed by both co-chairs)
- US Hardware Identity Specialist (3–5 FTE, including physical-inspection expert, attestation analyst, supply-chain forensics expert)
- Chinese Hardware Identity Specialist (3–5 FTE, equivalent expertise)
- Joint Ledger Forensics Officer (1–2 FTE, shared custody, responsible for data integrity and timestamp validation)
- Legal Advisor (1 FTE per country, binding advisor for disputed interpretations of corroboration rule)

**Decision Rights:** Authority to issue binding findings on equipment identity when evidence is unambiguous (both national teams agree on layer analysis, or the corroboration rule is clearly satisfied or violated). Authority to mark equipment unverifiable and justify the classification. Authority to escalate disputed findings to co-chairs with a detailed technical opinion if consensus cannot be reached within 36 hours. No authority to override the corroboration rule itself; rule changes require co-chair double-key amendment and ledger recording.

**Decision Mechanism:** Consensus within the panel (both country representatives must agree on findings) for binding decisions. If one country's panel members believe the corroboration rule is not met but the other disagree, the matter escalates to co-chairs as a contested finding, with the panel's technical opinion provided as non-binding input. Disputes are resolved by documented discussion and evidence review; if consensus fails after 36 hours, the panel issues a split or majority opinion, flags it as contested in the ledger, and refers the final call to co-chairs within 48 hours.

**Meeting Cadence:** On-demand activation for each contested identity or divergence escalation; target response time is 48 hours from escalation notification. Pre-test phase (Month 1.5 = 2026-11-23): weekly dry-run meetings to validate procedures. During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08): estimated 1–2 panels convened per week per site (4–8 across 4 sites) based on discrepancy rate; surge readiness for simultaneous multi-site disputes.

**Typical Agenda Items:**

- Equipment-identity evidence review: layer-by-layer analysis of attestation, physical inspection, customs records, identifiers, maintenance logs, infrastructure changes, witnessed movement
- Corroboration-rule application: does evidence meet minimum threshold? If not, justify unverifiable classification
- Ledger divergence forensics: which national copy's identity record is supported by evidence?
- Vendor-refusal escalation: is fallback evidence (independent examiner, clean-room, validated attestation) sufficient to confirm or deny identity?
- Discrepancy-clock escalation: is additional fact-finding likely to resolve the identity before the clock expires?
- Disputed findings escalation: prepare contested findings and technical opinions for co-chair review

**Escalation Path:** Unresolved contested identity disputes after 48 hours of panel review escalate to co-chairs for double-key decision within 24 hours. If co-chairs cannot agree within the escalation clock deadline (Tier 2 = 72 hours from initial discrepancy), the item is automatically marked as impaired-confidence status and the site enters escalation protocol. If consensus remains impossible at the 7-day ledger-divergence threshold, automatic suspension of the affected event or equipment class is triggered unless both co-chairs jointly authorize a further extension (documented in the ledger).
### 3. US National Operations Unit (USNOU)

**Rationale for Inclusion:** The Consortium requires full-time mirrored national inspection and operational teams at each participating site, with 24/7 shift coverage, separation of duties, and continuous evidence preservation. The USNOU is the US government's operational arm, responsible for deploying and managing US inspectors, coordinating with US participating sites, managing the US half of the replicated ledger, conducting US-side inspector vetting and conduct oversight, and ensuring compliance with US security and information-handling regulations. It mirrors the Chinese National Operations Unit in all operational functions, enabling reciprocal access and mutual accountability.

**Responsibilities:**

- Deploy and manage ~144 full-time US-side inspectors across 2 US participating sites with 24/7 shift coverage: day, evening and night shifts, plus leave buffer (~20%) and surge reserve (~10–15%)
- Conduct US-side counterintelligence vetting of all inspectors and support personnel to approval standard (Month 5 = 2027-03-08 entry condition); maintain vetting roster with clearance status, rotation schedule and rapid-replacement pool
- Manage the US copy of the replicated tamper-evident ledger: record all equipment arrivals, maintenance, third-party access, departures and inspector observations in real time; synchronize with Chinese copy at <1-hour bounded target; detect and escalate sync divergences within 2 hours
- Conduct US-side inspector conduct audit: monthly access-log review, zone-boundary compliance verification, device-access tracking, and three-tier infraction investigation (Tier 1 warnings, Tier 2 escalation, Tier 3 removal)
- Coordinate with US operators and vendors at participating sites: ensure binding agreements are in place (Month 4 = 2027-02-08), maintain liaison for maintenance scheduling, third-party access notification, and evidence preservation requirements
- Execute intake and exit protocols: verify equipment identity at arrival (staging) using layered evidence (attestation, physical inspection, customs, identifiers); assign exit dispositions (witnessed destruction, disablement, transfer, release or unresolved)
- Support independent testing unit: provide site access, facilitate challenge exercises in staging/spare/maintenance areas, ensure zero interruption of active computation, and record exercise outcomes in the US ledger copy
- Manage US contingency and surge capacity: maintain a rapid-call duty team for emergency maintenance responses, exercise escalations, and personnel replacement; coordinate surge activation with co-chairs

**Initial Setup Actions:**

- Nominate the US Deputy National Co-Chair and confirm USNOU operational leadership (Director, Deputy Director, Chief of Inspections, Chief of Ledger Operations) by Month 0.5 (2026-10-23)
- Identify and vet candidate US inspectors (144 FTE baseline, plus 20–30% surge pool = ~180–185 candidates) starting Month 0.5 (2026-10-23); coordinate with FBI, NSA and other security agencies for expedited counterintelligence clearances (14–16 week target)
- Establish incident-response and rapid-replacement protocols; pre-identify backup inspectors for every critical post
- Design the US-side ledger infrastructure: secure facility for ledger operations, cryptographic signing and key management, redundant secure communications links to China, offline backup and failover procedures; complete operational and stress-tested by Month 4 (2027-02-08)
- Pre-negotiate binding agreements with US operators and the top 5–8 equipment vendors per site, specifying attestation sharing, maintenance reporting, third-party escort and evidence preservation; sign by Month 1 (2026-11-08)
- Pre-stage independent examiner pool and clean-room facilities for vendor-refusal fallback routes; sign access agreements by Month 4 (2027-02-08)

**Membership:**

- US Deputy National Co-Chair (Cabinet-level designate or senior executive reporting to co-chair)
- Director of US National Operations Unit (~1 FTE, strategic operations leadership)
- Chief of Inspections (1 FTE, manages 144 inspectors, rosters, shift scheduling, leave and surge)
- Chief of Ledger Operations (1 FTE, US copy integrity, sync, forensics, offline backup and failover)
- US Inspector Vetting Officer (1 FTE, counterintelligence coordination, clearance status tracking, rapid replacement)
- Head of Operator Engagement (1 FTE, liaison with 2 US sites, vendor coordination, binding-agreement administration)
- Chief of Evidence Handling and Exit Protocol (1 FTE, intake/exit operations, disposition verification, chain of custody)
- 144 Full-Time US-Side Inspectors (36 per site, distributed across 3 shifts + leave/surge reserve)
- Support Staff (20–25 FTE, including ledger technicians, evidence handlers, analysts, training coordinators, logistics)

**Decision Rights:** Authority to deploy inspectors, manage shift rosters, approve leave and surge activations within the approved budget and staffing plan. Authority to escalate inspector-conduct Tier 2 or Tier 3 incidents to the bilateral conduct-review panel. Authority to recommend equipment-identity escalations to the Joint Forensic Panel. Authority to notify the Bilateral Executive Steering Committee of operational risks (understaffing, facility issues, vendor refusals) within 24 hours. No authority to override corroboration rules, site findings, or protocol changes; all such decisions are escalated to BESC or delegated panel authority.

**Decision Mechanism:** US Deputy Co-Chair and USNOU leadership make operational decisions by consensus or, if expedited (e.g., emergency inspector replacement), by the Director with next-business-day notification to the Deputy. Escalations to bilateral bodies (BESC, Joint Forensic Panel, bilateral conduct panel) follow written protocols specifying notification timelines and required documentation (evidence, findings, recommended action).

**Meeting Cadence:** Weekly USNOU leadership meeting for operational status, schedule/budget review, and escalation readiness (1 hour). Daily shift-handover briefing between outgoing and incoming shift leaders (30 minutes per site, 2 sites = 1 hour combined). Monthly US–China bilateral operations coordination call between USNOU and Chinese National Operations Unit directors for ledger sync status, protocol compliance, personnel matters and reciprocal-access parity review. Ad-hoc incident response meetings convened on Tier 2 conduct incidents, forensic escalations, or equipment-identity disputes.

**Typical Agenda Items:**

- Personnel status: vetting progress, clearance approvals, roster fill rate, leave scheduling, surge-reserve activation
- Ledger operations: sync status with Chinese copy, divergence events and resolution, offline backup testing, cryptographic key management
- Intake and exit: equipment-identity verification results, disposition assignments, vendor refusal escalations, unverifiable-equipment count
- Inspector conduct: monthly audit results, zone-boundary compliance, device-access review, Tier 1 warnings, escalation of Tier 2/3 incidents
- Operator engagement: vendor-agreement compliance, maintenance notification, third-party access scheduling, binding-agreement updates
- Exercise coordination: scheduling confirmation with independent testing unit, site access arrangements, exercise-security briefings, production-impact mitigation
- Budget and contingency: monthly spending against envelope, variance flagging, contingency-release requests

**Escalation Path:** Operational issues (understaffing, facility outages, vendor refusal) escalate to the US Deputy Co-Chair and the Bilateral Executive Steering Committee within 24 hours. Inspector-conduct Tier 2 and Tier 3 incidents escalate to the bilateral conduct-review panel within 12 hours. Equipment-identity disputes escalate to the Joint Forensic Panel within 6 hours of initial disagreement. Ledger divergence >4 hours unresolved escalates to ledger-operations escalation team (US and Chinese directors) within 30 minutes. Critical escalations (e.g., facility compromise, major vendor refusal cascading to multiple items, consent-withdrawal threat) escalate to BESC within 2 hours.
### 4. Chinese National Operations Unit (CNOU)

**Rationale for Inclusion:** Mirror to the US National Operations Unit, the CNOU is the Chinese government's operational arm. The bilateral mechanism requires full parity in operational capability, inspector deployment, ledger management and evidence handling. The CNOU ensures that Chinese government authority is exercised over Chinese operators, vendors and personnel; that domestic access authority is enforced; that vendor cooperation is secured; and that the Chinese national ledger copy is maintained with identical integrity and synchronization discipline as the US copy. Equal representation in all operational decisions (inspectors, ledger, evidence, facilities) reinforces mutual trust and reciprocal access.

**Responsibilities:**

- Deploy and manage ~144 full-time Chinese-side inspectors across 2 Chinese participating sites with 24/7 shift coverage: day, evening and night shifts, plus leave buffer (~20%) and surge reserve (~10–15%)
- Conduct Chinese-side counterintelligence vetting of all inspectors and support personnel to approval standard (Month 5 = 2027-03-08 entry condition); maintain vetting roster with clearance status, rotation schedule and rapid-replacement pool
- Manage the Chinese copy of the replicated tamper-evident ledger: record all equipment arrivals, maintenance, third-party access, departures and inspector observations in real time; synchronize with US copy at <1-hour bounded target; detect and escalate sync divergences within 2 hours
- Conduct Chinese-side inspector conduct audit: monthly access-log review, zone-boundary compliance verification, device-access tracking, and three-tier infraction investigation (Tier 1 warnings, Tier 2 escalation, Tier 3 removal)
- Coordinate with Chinese operators and vendors at participating sites: ensure binding agreements are in place (Month 4 = 2027-02-08), maintain liaison for maintenance scheduling, third-party access notification, and evidence preservation requirements
- Execute intake and exit protocols: verify equipment identity at arrival (staging) using layered evidence (attestation, physical inspection, customs, identifiers); assign exit dispositions (witnessed destruction, disablement, transfer, release or unresolved)
- Support independent testing unit: provide site access, facilitate challenge exercises in staging/spare/maintenance areas, ensure zero interruption of active computation, and record exercise outcomes in the Chinese ledger copy
- Manage Chinese contingency and surge capacity: maintain a rapid-call duty team for emergency maintenance responses, exercise escalations, and personnel replacement; coordinate surge activation with co-chairs

**Initial Setup Actions:**

- Nominate the Chinese Deputy National Co-Chair and confirm CNOU operational leadership (Director, Deputy Director, Chief of Inspections, Chief of Ledger Operations) by Month 0.5 (2026-10-23)
- Identify and vet candidate Chinese inspectors (144 FTE baseline, plus 20–30% surge pool = ~180–185 candidates) starting Month 0.5 (2026-10-23); coordinate with Ministry of State Security, Ministry of National Defense and other security organs for expedited counterintelligence clearances (14–16 week target)
- Establish incident-response and rapid-replacement protocols; pre-identify backup inspectors for every critical post
- Design the Chinese-side ledger infrastructure: secure facility for ledger operations, cryptographic signing and key management, redundant secure communications links to the US, offline backup and failover procedures; complete operational and stress-tested by Month 4 (2027-02-08)
- Pre-negotiate binding agreements with Chinese operators and the top 5–8 equipment vendors per site, specifying attestation sharing, maintenance reporting, third-party escort and evidence preservation; sign by Month 1 (2026-11-08)
- Pre-stage independent examiner pool and clean-room facilities for vendor-refusal fallback routes; sign access agreements by Month 4 (2027-02-08)

**Membership:**

- Chinese Deputy National Co-Chair (State Council or Communist Party designate, equivalent level reporting to co-chair)
- Director of Chinese National Operations Unit (~1 FTE, strategic operations leadership)
- Chief of Inspections (1 FTE, manages 144 inspectors, rosters, shift scheduling, leave and surge)
- Chief of Ledger Operations (1 FTE, Chinese copy integrity, sync, forensics, offline backup and failover)
- Chinese Inspector Vetting Officer (1 FTE, counterintelligence coordination, clearance status tracking, rapid replacement)
- Head of Operator Engagement (1 FTE, liaison with 2 Chinese sites, vendor coordination, binding-agreement administration)
- Chief of Evidence Handling and Exit Protocol (1 FTE, intake/exit operations, disposition verification, chain of custody)
- 144 Full-Time Chinese-Side Inspectors (36 per site, distributed across 3 shifts + leave/surge reserve)
- Support Staff (20–25 FTE, including ledger technicians, evidence handlers, analysts, training coordinators, logistics)

**Decision Rights:** Authority to deploy inspectors, manage shift rosters, approve leave and surge activations within the approved budget and staffing plan. Authority to escalate inspector-conduct Tier 2 or Tier 3 incidents to the bilateral conduct-review panel. Authority to recommend equipment-identity escalations to the Joint Forensic Panel. Authority to notify the Bilateral Executive Steering Committee of operational risks (understaffing, facility issues, vendor refusals) within 24 hours. No authority to override corroboration rules, site findings, or protocol changes; all such decisions are escalated to BESC or delegated panel authority.

**Decision Mechanism:** Chinese Deputy Co-Chair and CNOU leadership make operational decisions by consensus or, if expedited (e.g., emergency inspector replacement), by the Director with next-business-day notification to the Deputy. Escalations to bilateral bodies (BESC, Joint Forensic Panel, bilateral conduct panel) follow written protocols specifying notification timelines and required documentation (evidence, findings, recommended action).

**Meeting Cadence:** Weekly CNOU leadership meeting for operational status, schedule/budget review, and escalation readiness (1 hour). Daily shift-handover briefing between outgoing and incoming shift leaders (30 minutes per site, 2 sites = 1 hour combined). Monthly US–China bilateral operations coordination call between CNOU and US National Operations Unit directors for ledger sync status, protocol compliance, personnel matters and reciprocal-access parity review. Ad-hoc incident response meetings convened on Tier 2 conduct incidents, forensic escalations, or equipment-identity disputes.

**Typical Agenda Items:**

- Personnel status: vetting progress, clearance approvals, roster fill rate, leave scheduling, surge-reserve activation
- Ledger operations: sync status with US copy, divergence events and resolution, offline backup testing, cryptographic key management
- Intake and exit: equipment-identity verification results, disposition assignments, vendor refusal escalations, unverifiable-equipment count
- Inspector conduct: monthly audit results, zone-boundary compliance, device-access review, Tier 1 warnings, escalation of Tier 2/3 incidents
- Operator engagement: vendor-agreement compliance, maintenance notification, third-party access scheduling, binding-agreement updates
- Exercise coordination: scheduling confirmation with independent testing unit, site access arrangements, exercise-security briefings, production-impact mitigation
- Budget and contingency: monthly spending against envelope, variance flagging, contingency-release requests

**Escalation Path:** Operational issues (understaffing, facility outages, vendor refusal) escalate to the Chinese Deputy Co-Chair and the Bilateral Executive Steering Committee within 24 hours. Inspector-conduct Tier 2 and Tier 3 incidents escalate to the bilateral conduct-review panel within 12 hours. Equipment-identity disputes escalate to the Joint Forensic Panel within 6 hours of initial disagreement. Ledger divergence >4 hours unresolved escalates to ledger-operations escalation team (Chinese and US directors) within 30 minutes. Critical escalations (e.g., facility compromise, major vendor refusal cascading to multiple items, consent-withdrawal threat) escalate to BESC within 2 hours.
### 5. Independent Testing Unit (ITU)

**Rationale for Inclusion:** The credibility of the final Go/Modify/Stop decision rests entirely on the blind-challenge detection evidence. The plan requires challenge exercises to test whether inspectors can detect unreported arrivals, substituted equipment, record falsification, vendor refusal, delayed access and reluctant operators. An independent testing unit (not staffed by either national government, or staffed by both equally but controlled by neither unilaterally) is essential to prevent either country from gaming the exercises. The ITU designs scenarios on a sealed double-key schedule, runs exercises blind to inspectors, scores results objectively, and provides the detection data that feeds threshold calibration and the final verdict.

**Responsibilities:**

- Design challenge-exercise scenarios covering all 7 event types (unreported arrival, substituted equipment, record falsification, delayed access, disputed identity, vendor refusal, reluctant operator) with realistic complexity and adversarial credibility
- Maintain a sealed double-key exercise schedule: timing, sequence, venue, scenario details known only to a small group at each site; release schedule elements only as exercises occur, preventing advance preparation
- Coordinate with US National Operations Unit and Chinese National Operations Unit for site access, staging area reservation, and exercise logistics; ensure zero disruption to active computation
- Conduct exercises and record inspector response: detection time, evidence gathering, escalation behavior, interaction with operators and vendors
- Score detection outcomes: for each event type, measure whether inspectors detected the challenge (true positive), missed it (false negative), or falsely flagged non-existent anomalies (false positive)
- Provide blind-exercise detection data monthly to the Bilateral Executive Steering Committee and the Independent Auditor; track false-negative and false-positive rates against provisional thresholds
- Run pre-test calibration exercises on non-covered equipment (Months 4–5 = 2027-02-08 to 2027-03-08, outside formal clock) to validate detection capability and threshold realism before formal Go/Modify/Stop decision
- Conduct post-exercise independent audit of scenario design, blind integrity and scoring methodology; ensure scenarios are comparable and not biased toward either country's inspectors

**Initial Setup Actions:**

- Select and vet independent testing unit leadership (estimated 8–12 personnel per site, total 32–48 across 4 sites) by Month 1 (2026-11-08); staffing may include neutral international experts, academics, or retired national-security professionals acceptable to both countries
- Develop challenge-exercise scenario library: define the 7 event types, example scenarios per type, difficulty levels, and realism benchmarks (Month 1.5 = 2026-11-23)
- Design the sealed double-key exercise schedule: coordinate with BESC to lock timing, venue rotation across sites, and scenario sequence; finalize by Month 5.5 (2027-03-23)
- Establish exercise-response documentation and scoring templates; define true-positive, false-negative and false-positive criteria per event type with objective metrics (Month 1.5 = 2026-11-23)
- Run a pre-test exercise-design audit: peer-review scenarios against fairness and realism rubrics; both national red teams assess whether scenarios are realistic and comparable
- Pre-coordinate with site operators: schedule exercise windows in staging, spare-inventory, maintenance and expansion areas; establish communication protocols and real-time incident response for exercise-related events

**Membership:**

- Independent Testing Unit Director (1 FTE, non-national or jointly staffed, reports to BESC with no dual reporting)
- Scenario Design Lead (1 FTE, expertise in supply-chain attack methods, equipment substitution, falsification of records)
- Scoring and Data Analysis Lead (1 FTE, expertise in forensic analysis, detection metrics, statistical validation)
- Site Exercise Coordinators (2 per site, 8 total FTE, liaison with inspectors, logistics, real-time observation and documentation)
- Red-Team Facilitators (3–4 FTE per country, representing realistic adversary capabilities; conduct the unreported arrival, substitution, falsification and vendor-refusal scenarios)
- Independent Auditor (1 FTE, third-party observer of exercise integrity, blind maintenance and scoring objectivity)

**Decision Rights:** Authority to design and run exercises independently; neither national government may override exercise design or timing (once sealed schedule is locked by BESC at Month 5.5 = 2027-03-23). Authority to score detection outcomes objectively and report results to BESC monthly. Authority to declare an exercise void if contamination (advance notice to inspectors, unplanned interruption to active computation) is confirmed; void exercises are re-run if time permits, or excluded from the evidence base with documented justification. No authority to adjust thresholds or modify corroboration rules; all such changes are decided by BESC or the Joint Forensic Panel.

**Decision Mechanism:** Exercise scenario approval requires consensus of the ITU director and both national red-team facilitators; design disagreements are escalated to BESC as a fairness dispute. Exercise scoring is performed independently by the Scoring Lead and a designated observer from each country; if scores diverge, the Independent Auditor breaks the tie. Exercise timing and sequence are locked by double-key co-chair approval at Month 5.5 (2027-03-23); no changes to the sealed schedule are permitted after lock, except in case of a genuine operational emergency (site evacuation, major facility failure) authorized by both co-chairs.

**Meeting Cadence:** Weekly ITU leadership meeting (1 hour) during exercise-design phase (Months 1–2 = 2026-11-08 to 2026-12-08) and scenario-refinement phase (Months 3–5 = 2027-01-08 to 2027-03-08). Daily coordination during calibration exercise (Months 4–5 = 2027-02-08 to 2027-03-08), coordinating with sites and inspectors. During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08), exercise-execution meetings within 48 hours of each exercise; post-exercise scoring and documentation meetings within 72 hours. Monthly results briefings to BESC and Independent Auditor.

**Typical Agenda Items:**

- Scenario design and fairness review: challenge-exercise concept approval, realism validation, comparability across countries
- Sealed double-key schedule finalization: timing, venue, scenario sequence, red-team assignments, inspector blindness protocols
- Pre-test calibration-exercise execution: run dry-run on non-covered equipment, collect detection rates, validate scoring methodology
- Calibration results and threshold validation: compare observed false-negative/positive rates against provisional thresholds; recommend adjustments for co-chair approval
- Monthly detection-data summary: true positives, false negatives/positives by event type, detection-time distribution, escalation patterns
- Exercise-integrity and scoring audit: independent auditor results, fairness assessment, blind-maintenance confirmation
- Adverse findings and anomalies: unusual detection patterns, suspected exercise contamination, site-specific capability gaps

**Escalation Path:** Exercise-design disputes (fairness, realism, comparability) escalate to BESC within 5 days of disagreement. Scoring disputes (true positive vs. false positive, or detection time attribution) escalate to BESC within 72 hours of the disputed exercise, with the Independent Auditor providing a tie-breaking opinion. Exercise-integrity concerns (advance notice to inspectors, unplanned facility disruption) escalate to BESC within 24 hours with recommendation to void or re-run the exercise. Threshold-validation findings (calibration data suggesting provisional thresholds are unrealistic) escalate to BESC with a recommended protocol-change amendment to lock validated thresholds before formal Phase One begins.
### 6. Bilateral Inspector Conduct and Reciprocity Oversight Panel

**Rationale for Inclusion:** Inspector espionage and coercion risk is high in a low-trust bilateral environment. Inspectors from one country may be targeted for collection by the other's intelligence services, or may attempt unauthorized access to sensitive areas beyond the bounded zone. The plan requires full-time mirrored inspectors, rotation across sites, and continuous access-log audit. A bilateral conduct-review panel ensures that both governments maintain confidence that inspector access is for verification only and that conduct violations are investigated fairly and escalated promptly. This panel also tracks reciprocal-access parity: if one country grants its inspectors wider access, longer maintenance windows or faster escalations, the other side can request equivalent treatment.

**Responsibilities:**

- Conduct monthly inspector access-log audit: review device access, zone-boundary crossings, note-taking, device-usage patterns, and time-stamped evidence of inspector location and activities
- Investigate all reported conduct incidents: Tier 1 warnings (minor, first offense), Tier 2 formal notices (repeated or deliberate violations), Tier 3 removals (material espionage risk or serious unauthorized access)
- Document every zone boundary violation, alleged or substantiated, with photographs or access-log evidence; define material IP exposure as undisclosed photography of workload location, network topology, source code, weights or infrastructure beyond the bounded zone
- Manage inspector rotation across sites: ensure rotations are randomized or on a pre-agreed schedule so neither operator nor vendor can predict who is present; maintain a pre-approved rapid-replacement pool for every critical post
- Monitor reciprocal-access parity: compare metrics across both countries (inspectors deployed per site, hours of zone access per inspector, events witnessed, escalation items raised, maintenance-window access, emergency-response time); flag asymmetries >20% (estimated) and escalate to BESC within 5 days
- Authorize inspector removals: Tier 2 and Tier 3 incidents escalate to bilateral panel for investigation; panel may recommend removal with justification; removal of an inspector requires documented findings and written notice to the offending country's Deputy Co-Chair within 24 hours
- Maintain inspector-vetting status and clearance tracking: monitor clearance expiry dates, renewal timelines and surge-pool readiness; escalate clearance delays to the national operations units and vetting authorities

**Initial Setup Actions:**

- Jointly select bilateral panel members (estimated 3–5 per country, equal membership, total 6–10) with expertise in counterintelligence, inspector conduct and reciprocal-access verification by Month 1 (2026-11-08)
- Establish the three-tier infraction protocol and escalation procedures; document and sign by both co-chairs (Month 1 = 2026-11-08)
- Define material IP exposure and espionage-risk indicators that trigger Tier 3 investigation and potential removal (Month 1 = 2026-11-08)
- Establish inspector conduct-code; every inspector signs a code of conduct at induction, with zero-tolerance rules for unauthorized area access, recording, or collection (Month 2 = 2026-12-08)
- Set up continuous access-log infrastructure: badge-swipe systems, device-access logging, location tracking (GPS or secure beacon) for inspectors in defined zones; logs synchronized with both national ledger copies in real time (operational by Month 4 = 2027-02-08)
- Pre-identify a pre-approved rapid-replacement pool for every critical inspector post (3–5 alternates per post, all pre-vetted and cleared); maintain roster with backup-ready dates (Month 5 = 2027-03-08)

**Membership:**

- Panel Chair: Joint bilateral co-chair (1 per country, rotating leadership by 6-month term)
- US Counterintelligence Representative (1–2 FTE, expertise in inspector vetting, conduct monitoring, espionage risk assessment)
- Chinese Counterintelligence Representative (1–2 FTE, equivalent expertise)
- US Inspector Vetting Officer (shared with US National Operations Unit, 1 FTE liaison)
- Chinese Inspector Vetting Officer (shared with Chinese National Operations Unit, 1 FTE liaison)
- Independent Auditor (1 FTE, third-party observer of conduct investigations and removal decisions)

**Decision Rights:** Authority to conduct access-log audits and recommend Tier 1 warnings (minor, first offense) without escalation. Authority to initiate Tier 2 investigations (repeated or deliberate violations) and recommend formal notice and inspector retraining; Tier 2 findings escalate to BESC for confirmation within 24 hours. Authority to investigate Tier 3 cases (material espionage risk) and recommend removal; Tier 3 removal requires agreement of both panel co-chairs and BESC approval within 24 hours. Authority to track and report on reciprocal-access parity metrics and recommend corrective action if asymmetry >20% is detected. No authority to override corroboration rules, site findings or protocol changes; conduct matters are escalated appropriately within their tier.

**Decision Mechanism:** Monthly access-log audit conducted jointly by both national counterintelligence representatives; findings reviewed in panel meeting and documented. Tier 1 and Tier 2 incidents investigated by a joint panel team (both countries represented); consensus required for recommendations. Tier 3 cases require panel unanimity for removal recommendation; if one country's panel members object, the matter escalates to BESC with a contested finding. Reciprocal-access parity analysis conducted monthly and presented to BESC; asymmetries >20% trigger a bilateral review and proposed remediation within 10 days.

**Meeting Cadence:** Monthly bilateral conduct-review meeting (2 hours) to review access-log audit results, Tier 1/2 incidents, reciprocal-access parity metrics and pre-approved replacement-pool status (Months 0–10 = 2026-10-08 to 2027-08-08). Ad-hoc emergency meetings for Tier 3 investigations (within 24 hours of incident report). Weekly bilateral operations-coordination calls (30 minutes) during Phase One (Months 6–9 = 2027-04-08 to 2027-07-08) to track real-time conduct and access issues.

**Typical Agenda Items:**

- Monthly access-log audit results: zone-boundary compliance, device-access review, location tracking validation, anomaly flagging
- Tier 1 warnings: minor violations (off-boundary photograph, brief unauthorized area entry); disposition (retraining, additional supervision)
- Tier 2 formal notices: repeated or deliberate violations; investigation findings and recommended action (formal notice, escalation, potential removal)
- Tier 3 removal investigations: material espionage risk or serious unauthorized collection; investigation findings and removal recommendation
- Reciprocal-access parity metrics: inspector deployment per site and country, hours of zone access, witnessed events, escalation items, maintenance-window access, emergency-response time
- Inspector-vetting status: clearance expiry dates, renewal timeline, surge-pool readiness, rapid-replacement-pool updates
- Rotation compliance: site-rotation schedule, randomization validation, pre-vetting of incoming rotations

**Escalation Path:** Tier 1 and minor Tier 2 incidents are handled within the panel; findings documented in the monthly report to BESC. Tier 2 and Tier 3 incidents escalate to BESC within 24 hours with panel recommendation. Removal of an inspector (Tier 3) requires bilateral panel consensus and BESC approval; the offending country's Deputy Co-Chair is notified with written justification. If a Tier 2 incident escalates to repeated violations by the same inspector, automatic escalation to Tier 3 investigation is triggered. Reciprocal-access asymmetry >20% escalates to BESC with a remediation plan due within 10 days. Unresolved access-parity disputes escalate to the neutral referee panel after 7 days of BESC disagreement.
### 7. Independent Auditor and KPI Monitoring Office

**Rationale for Inclusion:** The bilateral mechanism must be subject to continuous independent audit and transparent KPI tracking so that both governments can verify that Phase One is proceeding according to plan and that the evidence base is sound. An independent auditor (not answerable to either national government, jointly selected by BESC) reviews ledger integrity, evidence-handling chain of custody, compliance with entry-condition timelines, spending against budget envelopes, personnel vetting, exercise integrity, and inspector conduct. A KPI monitoring office publishes monthly metrics (detection rates, false positives/negatives, ledger sync, reciprocal-access parity, discrepancy age, unverifiable equipment, vendor refusals, funding timeliness, audit exceptions) so both governments can track progress against thresholds and assess whether Phase One is credible.

**Responsibilities:**

- Quarterly independent audit of ledger integrity, cryptographic signing validity, and sync-divergence event counts; validate that <4-hour divergence detection and <7-day unresolved-divergence thresholds are met or properly escalated
- Monthly audit of evidence-handling chain of custody: intake records, exit dispositions, vendor-refusal escalations, forensic-panel findings; ensure all evidence is documented with provenance and timestamps
- Quarterly audit of compliance with entry-condition timelines: track bilateral instrument signature, appropriations clearance, domestic authority enactment, site selection, inspector vetting, operator/vendor binding, equipment schedule adoption; flag any condition lagging >4 weeks behind plan
- Monthly fiscal-accountability audit of spending against budget envelopes: reconcile actual vs. planned expenditure per envelope (ledger, site prep, personnel, facilities, testing, legal, contingency); flag variance >5% and cost-center-level details; sign-off on large tranches >USD 25M
- Quarterly inspector vetting and clearance audit: confirm all deployed inspectors have current counterintelligence clearances; verify that rapid-replacement pool is pre-vetted and ready; validate that no single-person critical functions exist
- Post-exercise independent audit of challenge-exercise scenario design, blind integrity, and scoring methodology; validate that scenarios are realistic, comparable across countries, and not biased toward either country's inspectors
- Monthly KPI dashboard: compile and publish detection rates by event type, false-positive and false-negative counts, equipment-identity confidence scores, ledger-sync divergence events and resolution time, reciprocal-access parity metrics, discrepancy age and tiering, unverifiable-equipment count, vendor-refusal outcomes, production-disruption incidents, funding-timeliness status and audit exceptions; mark all figures as provisional or validated; lock thresholds at Month 5.5 (2027-03-23)
- Quarterly auditor-attestation report: document findings on ledger resilience, evidence handling, entry-condition compliance, spending, personnel vetting, exercise integrity and spot checks of zone-boundary enforcement; report accessible to both governments

**Initial Setup Actions:**

- Jointly select independent auditor and KPI monitoring office leadership (estimated 5–8 FTE) by Month 1 (2026-11-08); staffing drawn from reputable international audit firms, accounting firms, or academic institutions acceptable to both countries; no prior employment by either government
- Establish audit scope, methodology and reporting templates by Month 1.5 (2026-11-23); document what constitutes 'variance >5%,' 'audit exception,' and 'material finding'; define escalation thresholds
- Design KPI dashboard: identify all metrics, data sources, collection procedures, publication schedule (monthly) and threshold validation (provisional vs. locked) (Month 1.5 = 2026-11-23)
- Set up secure data repositories for ledger audit, evidence audit and KPI data; ensure both governments have read access to redacted (classified details removed) auditor reports and KPI dashboard
- Conduct first pre-test audit at Month 4 (2027-02-08) on non-covered-equipment operations (ledger, evidence handling, exercise calibration) to validate audit procedures before formal Phase One begins

**Membership:**

- Independent Auditor (Senior audit partner from jointly selected international firm, reports to BESC with no dual reporting)
- KPI Monitoring Office Director (1 FTE, responsible for monthly dashboard compilation and threshold tracking)
- Ledger and Evidence Audit Lead (1–2 FTE, expertise in digital forensics, cryptographic verification, chain-of-custody validation)
- Financial Audit Lead (1 FTE, expertise in government appropriations, envelope-based budgeting, variance analysis)
- Personnel and Vetting Audit Lead (1 FTE, expertise in security clearances, vetting procedures, continuity-of-operations planning)
- Exercise and Detection Audit Lead (1 FTE, expertise in red-team methodology, scenario design and fairness, statistical analysis of detection rates)

**Decision Rights:** Authority to audit any aspect of Phase One operations and report findings to BESC monthly and to both governments quarterly. Authority to flag audit exceptions and escalate material findings (e.g., ledger divergence unresolved >7 days, spending variance >5%, vetting gaps, exercise-integrity concerns) to BESC within 24 hours. Authority to publish the KPI dashboard monthly with provisional and validated thresholds clearly marked. Authority to recommend corrective actions; no authority to enforce corrections (that is BESC's decision).

**Decision Mechanism:** Independent auditor conducts audits and issues findings according to pre-agreed audit scope and methodology; findings are reviewed and confirmed by the auditor before publication. If BESC disputes an audit finding, the auditor may request independent peer review by a third-party audit firm (cost paid from contingency); disputed finding remains published pending peer-review conclusion.

**Meeting Cadence:** Monthly KPI dashboard compilation and publication (internal working meetings 1–2 weeks before publication deadline). Quarterly auditor-attestation report preparation (internal working meetings 2–3 weeks before publication). Quarterly results briefing to BESC (1–2 hours). Ad-hoc meetings to investigate audit exceptions or material findings flagged by BESC within 24 hours.

**Typical Agenda Items:**

- Ledger integrity audit: cryptographic signing validation, sync-divergence counts, offline backup testing, forensic findings on disputed identities
- Evidence-handling audit: chain-of-custody verification, intake/exit protocols, vendor-refusal escalations, documentation completeness and accuracy
- Entry-condition compliance: tracking of bilateral instrument, appropriations, domestic authority, site selection, inspector vetting, operator/vendor binding, equipment schedule; flags for any condition >4 weeks behind plan
- Spending variance analysis: actual vs. planned expenditure per envelope, cost-center reconciliation, large-tranche authorization (>USD 25M)
- Personnel vetting status: clearance validation, rapid-replacement pool pre-vetting, single-person critical-function check
- Exercise audit: scenario fairness and realism, blind maintenance, scoring objectivity, statistical analysis of detection rates and false rates
- KPI dashboard monthly: detection rates by event type, false positive/negative counts, identity confidence, sync divergence resolution time, parity metrics, discrepancy age, unverifiable counts, vendor outcomes, production disruption, funding timeliness, audit exceptions
- Quarterly attestation findings: summary of key audit results, material findings, recommended corrective actions, validation of Phase One credibility

**Escalation Path:** Audit exceptions or material findings (e.g., ledger divergence >7 days unresolved, spending variance >5%, vetting gaps, exercise-integrity concerns) are escalated to BESC within 24 hours with recommended corrective actions. If BESC disputes an auditor finding, the auditor may be asked to provide supporting documentation; if disagreement persists, a peer-review audit by a third-party firm (cost from contingency) is initiated. KPI thresholds are locked at Month 5.5 (2027-03-23) by BESC; after that, KPI deviations from locked thresholds are tracked and reported monthly as evidence for the final Go/Modify/Stop decision.

# Governance Implementation Plan

### 1. Project sponsor (senior US and Chinese political leadership) jointly confirms commitment and authority to establish The Consortium; establishes co-chair mandate and decision-making authority framework in principle.

**Responsible Body/Role:** US and Chinese Political Leadership (Presidential/Prime-ministerial level or equivalent)

**Suggested Timeframe:** Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Joint political commitment statement or directive
- Co-chair mandate and authority scope (outlined, not yet signed)
- Authorization to proceed with bilateral instrument drafting

**Dependencies:**

- Project initiation decision by both governments

### 2. Bilateral instrument drafting team (legal counsel from both countries, nominated by political leadership) drafts the foundational bilateral agreement specifying double-key governance, decision thresholds, escalation procedures, deadlock resolution, reciprocity requirements, inspector immunity, technology-transfer rules and participant obligations.

**Responsible Body/Role:** Joint Bilateral Legal Drafting Team (US and Chinese legal counsel, co-led)

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 1.5 (2026-11-23 to 2026-11-23)

**Key Outputs/Deliverables:**

- Draft bilateral instrument v0.1 (internal working version)
- Governance structure and decision-rights framework section
- Double-key authority terms and deadlock-resolution protocols
- Inspector vetting, immunity and conduct-code provisions
- Entry-condition specification and certification procedures
- Dispute-escalation and referee-panel selection mechanism

**Dependencies:**

- Political leadership commitment in principle
- Nomination of US and Chinese lead legal counsel

### 3. Legal drafting team circulates draft bilateral instrument for review and comment by nominated members of the Bilateral Executive Steering Committee (both co-chairs designate), Joint Forensic Panel leads, and Independent Auditor designate.

**Responsible Body/Role:** Joint Bilateral Legal Drafting Team

**Suggested Timeframe:** Month 1.5 (2026-11-23) to Month 2 (2026-12-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Feedback summary from all reviewers
- Consolidated list of requested clarifications or amendments
- Redline draft v0.2 with tracked changes

**Dependencies:**

- Draft v0.1 completed and circulated to designated reviewers
- Reviewers identified and briefing materials prepared

### 4. Senior US political leadership (National Security Advisor or equivalent Cabinet-level sponsor) nominates the US National Co-Chair (Cabinet-level or equivalent senior executive) and the US Deputy National Co-Chair (Head of US National Operations Unit or designated proxy).

**Responsible Body/Role:** US Political Leadership (via National Security Council or Presidential directive)

**Suggested Timeframe:** Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- Written nomination and confirmation of US National Co-Chair
- Written nomination and confirmation of US Deputy National Co-Chair
- Authority delegation letter outlining decision-making scope

**Dependencies:**

- Political commitment in principle from US side

### 5. Senior Chinese political leadership (State Council or Communist Party equivalent) nominates the Chinese National Co-Chair (State Council or equivalent level) and the Chinese Deputy National Co-Chair (Head of Chinese National Operations Unit or designated proxy).

**Responsible Body/Role:** Chinese Political Leadership (via State Council or equivalent)

**Suggested Timeframe:** Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- Written nomination and confirmation of Chinese National Co-Chair
- Written nomination and confirmation of Chinese Deputy National Co-Chair
- Authority delegation letter outlining decision-making scope

**Dependencies:**

- Political commitment in principle from Chinese side

### 6. Nominated US and Chinese National Co-Chairs hold an inaugural bilateral meeting (in person or secure video) to ratify the bilateral instrument governance language, confirm their mutual understanding of double-key authority, and establish weekly steering-committee meeting schedule and decision-recording protocols.

**Responsible Body/Role:** US and Chinese National Co-Chairs (jointly)

**Suggested Timeframe:** Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Meeting minutes documenting governance agreement, weekly schedule confirmation and decision-recording SOP
- Bilateral instrument governance sections finalized and co-signed in principle
- Escalation and deadlock-resolution procedures confirmed in writing

**Dependencies:**

- Both co-chairs nominated and authorized
- Draft bilateral instrument reviewed and cleared for co-chair discussion

### 7. US National Co-Chair and Deputy nominate and select members of the US-side internal governance bodies: Joint Forensic Panel US specialist team (3–5 FTE hardware identity/forensics experts), US National Operations Unit leadership (Director, Deputy Director, Chief of Inspections, Chief of Ledger Operations, vetting officer, operator engagement head, evidence handler), and US inspector cadre leadership roles.

**Responsible Body/Role:** US National Co-Chair (with advice from US Deputy Co-Chair and US-side technical leads)

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 1 (2026-11-08 to 2026-11-08)

**Key Outputs/Deliverables:**

- US forensic panel team roster (3–5 confirmed members, resumes/qualifications)
- US National Operations Unit leadership team roster (6–8 confirmed positions and names)
- US inspector-selection criteria and rapid-replacement pool framework

**Dependencies:**

- US National Co-Chair and Deputy confirmed
- Job descriptions and authority scope for each role defined

### 8. Chinese National Co-Chair and Deputy nominate and select members of the Chinese-side internal governance bodies: Joint Forensic Panel Chinese specialist team (3–5 FTE hardware identity/forensics experts), Chinese National Operations Unit leadership (Director, Deputy Director, Chief of Inspections, Chief of Ledger Operations, vetting officer, operator engagement head, evidence handler), and Chinese inspector cadre leadership roles.

**Responsible Body/Role:** Chinese National Co-Chair (with advice from Chinese Deputy Co-Chair and Chinese-side technical leads)

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 1 (2026-11-08 to 2026-11-08)

**Key Outputs/Deliverables:**

- Chinese forensic panel team roster (3–5 confirmed members, resumes/qualifications)
- Chinese National Operations Unit leadership team roster (6–8 confirmed positions and names)
- Chinese inspector-selection criteria and rapid-replacement pool framework

**Dependencies:**

- Chinese National Co-Chair and Deputy confirmed
- Job descriptions and authority scope for each role defined

### 9. Both National Co-Chairs jointly nominate members of the bilateral (non-national-side) governance bodies: Bilateral Executive Steering Committee observer (neutral third-party facilitator, if agreed), Joint Forensic Panel Chair (senior neutral technical specialist), Independent Testing Unit Director (neutral, international or jointly staffed), Bilateral Inspector Conduct Panel co-chairs (one per country), and Independent Auditor (from jointly agreed international audit firm).

**Responsible Body/Role:** US and Chinese National Co-Chairs (jointly, via mutual nomination and double-key confirmation)

**Suggested Timeframe:** Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Bilateral-role nomination slate (Joint Forensic Panel Chair, ITU Director, Conduct Panel leads, Auditor)
- Conflict-of-interest and independence declarations from all nominees
- Confirmation of willingness to serve and authority limits

**Dependencies:**

- Both co-chairs confirmed and in communication
- Role descriptions and independence criteria defined

### 10. Joint Bilateral Legal Drafting Team (or designated co-chair delegates) finalizes the bilateral instrument with all governance, entry-condition, double-key, escalation and threshold language locked and approved by both co-chairs; instrument is prepared for signature by political leadership.

**Responsible Body/Role:** Joint Bilateral Legal Drafting Team (under co-chair oversight)

**Suggested Timeframe:** Month 1.5 (2026-11-23) to Month 2 (2026-12-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Bilateral instrument final draft (v1.0)
- Both co-chairs' written approval and signature authorization
- Redline history and change-control documentation
- Executive summary for political-leadership signature

**Dependencies:**

- All governance bodies' roles and decision rights defined and agreed
- Escalation procedures and deadlock rules finalized
- Entry-condition milestones and thresholds locked

### 11. Political leadership from both countries formally sign and ratify the bilateral instrument, conferring full legal authority on The Consortium governance structure, entry-condition certification authority and Phase One test mandate.

**Responsible Body/Role:** US and Chinese Political Leadership (Presidential/Prime-ministerial or Cabinet-level signatories)

**Suggested Timeframe:** Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Signed bilateral instrument (both governments' official copies)
- Public statement or notification to relevant domestic authorities (legislatures, security agencies, treasury)
- Authority delegation letters to National Co-Chairs

**Dependencies:**

- Bilateral instrument finalized with both co-chairs' approval
- Legal review completed by both governments' counsel
- Political decision to proceed made at highest level

### 12. Bilateral Executive Steering Committee formally constituted: both National Co-Chairs meet with US and Chinese Deputies and bilateral-role holders (neutral observer if appointed, co-chair proxies) to confirm governance structure, decision-recording protocols, weekly meeting schedule, and escalation procedures. First official BESC meeting convened.

**Responsible Body/Role:** Bilateral Executive Steering Committee (convened by co-chairs)

**Suggested Timeframe:** Month 2.5 (2026-12-23)

**Key Outputs/Deliverables:**

- Formal BESC charter or constitution (decision rights, meeting cadence, escalation rules)
- Signed decision-recording and confidentiality protocols
- First BESC meeting minutes documenting governance confirmation and entry-condition tracking kickoff
- Weekly steering-committee meeting schedule through Month 10 (2027-08-08)

**Dependencies:**

- Bilateral instrument signed by political leadership
- Both National Co-Chairs and Deputies confirmed and in position
- Bilateral-role holders (observer, panels, auditor) identified and accepted

### 13. Bilateral Executive Steering Committee establishes the Joint Forensic and Evidence Adjudication Panel: both co-chairs confirm the panel charter, corroboration rule (fixed rule: identity confirmed when ≥2 independent layers agree, physical inspection + identifier + validated attestation where available; if attestation unavailable, physical inspection + 2 independent records), dispute escalation procedures, and panel convening authority.

**Responsible Body/Role:** Bilateral Executive Steering Committee

**Suggested Timeframe:** Month 2 (2026-12-08) to Month 2.5 (2026-12-23 to 2026-12-23)

**Key Outputs/Deliverables:**

- Joint Forensic Panel charter and decision rights
- Fixed corroboration rule, double-key signed by both co-chairs and recorded in ledger
- Panel-convening SOP and evidence-review templates
- Panel members' conflict-of-interest and independence confirmations

**Dependencies:**

- BESC established and operational
- Bilateral instrument specifying panel authority completed
- Panel Chair and national specialist teams identified and confirmed

### 14. Bilateral Executive Steering Committee establishes the Bilateral Inspector Conduct and Reciprocity Oversight Panel: both co-chairs confirm the three-tier infraction protocol (Tier 1 = written warning, Tier 2 = formal notice and escalation, Tier 3 = removal investigation), zone-boundary enforcement procedures, reciprocal-access parity monitoring metrics, and monthly audit schedule.

**Responsible Body/Role:** Bilateral Executive Steering Committee

**Suggested Timeframe:** Month 2 (2026-12-08) to Month 2.5 (2026-12-23 to 2026-12-23)

**Key Outputs/Deliverables:**

- Bilateral Conduct Panel charter and decision rights
- Three-tier infraction protocol and escalation decision tree, double-key signed
- Inspector conduct code, to be signed by every deployed inspector
- Reciprocal-access parity metrics definition and monthly reporting SOP
- Tier 1, 2, 3 investigation procedures and timeline (Tier 1 = 48h, Tier 2 = 24h, Tier 3 = 12h)

**Dependencies:**

- BESC established and operational
- Bilateral instrument specifying conduct authority completed
- Conduct Panel co-chairs (one per country) and counterintelligence staff identified

### 15. Bilateral Executive Steering Committee establishes the Independent Testing Unit: both co-chairs confirm the ITU Director's authority to design and run blind challenge exercises, maintain a sealed double-key schedule, score results objectively, and provide monthly detection data to BESC. ITU charter locked; scenario-design methodology and fairness-review rubric documented.

**Responsible Body/Role:** Bilateral Executive Steering Committee

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 2 (2026-12-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Independent Testing Unit charter and independence confirmation
- ITU Director and core staff (Scenario Lead, Scoring Lead, Site Coordinators, Red-Team Facilitators, Auditor) identified
- Scenario-design library: 7 event types (unreported arrival, substitution, falsification, delayed access, disputed identity, vendor refusal, reluctant operator) with example scenarios per type
- Fairness-review rubric and peer-review process for scenario validation
- Detection-scoring criteria and metrics (true positive, false negative, false positive definitions per event type)

**Dependencies:**

- BESC established and operational
- Bilateral instrument specifying ITU authority completed
- ITU Director and lead staff identified and cleared for confidential information

### 16. Bilateral Executive Steering Committee establishes the Independent Auditor and KPI Monitoring Office: both co-chairs confirm the Auditor's independence, audit scope (ledger integrity, evidence chain of custody, entry-condition compliance, spending variance, personnel vetting, exercise integrity, KPI dashboard), reporting schedule (quarterly auditor report, monthly KPI dashboard) and escalation authority.

**Responsible Body/Role:** Bilateral Executive Steering Committee

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 2 (2026-12-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Independent Auditor charter and independence confirmation
- Audit scope, methodology and reporting templates
- KPI dashboard design: all metrics, data sources, publication schedule (monthly), threshold definitions (provisional vs. validated)
- Auditor and KPI team roster (Auditor partner, KPI Director, Audit Leads: Ledger/Evidence, Financial, Personnel/Vetting, Exercise/Detection)
- Audit-exception escalation thresholds (e.g., variance >5%, divergence >4 hours unresolved, vetting gap, exercise contamination)

**Dependencies:**

- BESC established and operational
- Bilateral instrument specifying Auditor authority completed
- Independent audit firm and Auditor partner identified and confirmed

### 17. US National Co-Chair and US National Operations Unit Director establish the US National Operations Unit as a formally constituted operational entity: define organizational structure, reporting lines, facility locations (secure ledger facility, inspector deployment sites, contingency operations center), secure communications architecture, and personnel budget allocation per envelope and role.

**Responsible Body/Role:** US National Co-Chair (via US Deputy Co-Chair and USNOU Director)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 2 (2026-12-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- USNOU organizational charter and authority structure
- Facility-location requirements specification (ledger ops, inspector deployment, backup facilities)
- US-side ledger infrastructure design document (cryptographic keys, synchronization architecture, offline backups)
- Personnel budget allocation by role and timeline (inspector vetting starting Month 0.5 = 2026-10-23, deployment by Month 5 = 2027-03-08)
- Incident-response procedures and rapid-replacement protocols for critical posts

**Dependencies:**

- US National Co-Chair and Deputy confirmed
- US National Operations Unit leadership team nominated and assigned
- Site selection begun (anticipated Month 2 = 2026-12-08 completion)

### 18. Chinese National Co-Chair and Chinese National Operations Unit Director establish the Chinese National Operations Unit as a formally constituted operational entity: define organizational structure, reporting lines, facility locations (secure ledger facility, inspector deployment sites, contingency operations center), secure communications architecture, and personnel budget allocation per envelope and role.

**Responsible Body/Role:** Chinese National Co-Chair (via Chinese Deputy Co-Chair and CNOU Director)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 2 (2026-12-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- CNOU organizational charter and authority structure
- Facility-location requirements specification (ledger ops, inspector deployment, backup facilities)
- Chinese-side ledger infrastructure design document (cryptographic keys, synchronization architecture, offline backups)
- Personnel budget allocation by role and timeline (inspector vetting starting Month 0.5 = 2026-10-23, deployment by Month 5 = 2027-03-08)
- Incident-response procedures and rapid-replacement protocols for critical posts

**Dependencies:**

- Chinese National Co-Chair and Deputy confirmed
- Chinese National Operations Unit leadership team nominated and assigned
- Site selection begun (anticipated Month 2 = 2026-12-08 completion)

### 19. Bilateral Executive Steering Committee receives and reviews site-selection proposals from both countries. Each country nominates 3–5 candidate datacenters according to agreed criteria (equipment-change frequency, vendor-mix diversity, staging/maintenance capacity, operator willingness, deliberately hard sites). Technical committee jointly evaluates candidates against objective criteria.

**Responsible Body/Role:** Bilateral Executive Steering Committee (with ad-hoc Technical Site-Selection Committee)

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 1.5 (2026-11-23 to 2026-11-23)

**Key Outputs/Deliverables:**

- US site-nomination package (3–5 candidates with technical data sheets, operator letters of interest, facility descriptions)
- Chinese site-nomination package (3–5 candidates with technical data sheets, operator letters of interest, facility descriptions)
- Joint technical-committee evaluation report: criteria scoring, shortlist recommendation (6–8 jointly vetted sites)

**Dependencies:**

- Site-selection criteria (frequency parity within 20%, vendor-mix diversity, staging capacity, at least 1 hard site per country) defined and signed by both co-chairs
- Operator contacts and interest-gathering begun in Month 0 (2026-10-08)

### 20. Bilateral Executive Steering Committee finalizes site selection: both co-chairs authorize a sealed random draw from the jointly vetted shortlist (6–8 sites), selecting 4 sites (2 US, 2 China). Sites are ratified by written co-chair agreement and published to selected operators.

**Responsible Body/Role:** Bilateral Executive Steering Committee (both co-chairs jointly)

**Suggested Timeframe:** Month 1.5 (2026-11-23) to Month 2 (2026-12-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Sealed-draw procedure documentation and witnesses
- Final 4-site selection: names, geographies, operator names, rationale
- Co-chair joint site-selection agreement (signed)
- Notification letters to selected operators and to non-selected candidates

**Dependencies:**

- Joint technical-committee shortlist evaluation completed
- Both co-chairs agreed on criteria and draw procedure

### 21. US National Operations Unit engages with US selected operators: initiates binding-agreement negotiation, specifying operator obligations (inspector access, equipment-identity verification, third-party escort, maintenance notification, evidence preservation, ledger compliance, exercise participation).

**Responsible Body/Role:** US National Operations Unit (Head of Operator Engagement)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 2 (2026-12-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Operator engagement kickoff meetings (in-person or secure video)
- Draft binding-agreement template tailored to US regulatory environment
- Operator questions/concerns log and responses

**Dependencies:**

- US sites selected and notified
- USNOU leadership and Operator Engagement head in place
- Bilateral instrument governance framework finalized

### 22. Chinese National Operations Unit engages with Chinese selected operators: initiates binding-agreement negotiation, specifying operator obligations (inspector access, equipment-identity verification, third-party escort, maintenance notification, evidence preservation, ledger compliance, exercise participation).

**Responsible Body/Role:** Chinese National Operations Unit (Head of Operator Engagement)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 2 (2026-12-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Operator engagement kickoff meetings (in-person or secure video)
- Draft binding-agreement template tailored to Chinese regulatory environment
- Operator questions/concerns log and responses

**Dependencies:**

- Chinese sites selected and notified
- CNOU leadership and Operator Engagement head in place
- Bilateral instrument governance framework finalized

### 23. US and Chinese National Operations Units jointly establish secure communications infrastructure for the replicated, tamper-evident bilateral ledger: design redundant, secure, encrypted communications links between US and Chinese ledger-operations facilities; specification of synchronization protocol (<1 hour target), cryptographic signing, offline backup, failover procedures and key-management ceremony.

**Responsible Body/Role:** US and Chinese National Operations Units (Chief of Ledger Operations, jointly)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 3 (2027-01-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- Bilateral ledger communications architecture design document
- Secure-link specifications: encryption algorithms, key-exchange protocol, sync-timeout bounds
- Cryptographic signing and verification procedures (who holds keys, access controls, key-rotation schedule)
- Offline-backup and recovery procedures, tested on non-covered equipment
- Scheduled joint key-ceremony plan (if applicable; if not using joint ceremony, two-independent-national-roots plan)

**Dependencies:**

- US and Chinese National Operations Units established
- Bilateral instrument governance and security requirements finalized
- Attestation trust-root strategy decided (joint ceremony vs. cross-validating national roots)

### 24. Bilateral Executive Steering Committee establishes the Reciprocity Gate Entry-Condition Steering Committee (a sub-committee of BESC, or BESC itself with ad-hoc expertise): designates owners for each of the 7 mandatory entry conditions (bilateral instrument, appropriations, domestic authority, sites, inspectors, operators/vendors, equipment schedule) and sets weekly milestone tracking from Month 0 (2026-10-08) onward.

**Responsible Body/Role:** Bilateral Executive Steering Committee

**Suggested Timeframe:** Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- Entry-Condition Steering Committee charter (members, meeting schedule, escalation authorities)
- Entry-condition ownership assignment and milestones spreadsheet
- Weekly tracking dashboard template (condition status, milestone completion %, blockers, escalation recommendations)

**Dependencies:**

- BESC established and first meeting held
- Entry-condition milestones and owners identified (from bilateral instrument and assumptions)

### 25. Bilateral Executive Steering Committee holds its first comprehensive entry-condition review: both co-chairs assess progress on bilateral instrument (signed), appropriations (pending), domestic authority legislation (initiated), site selection (completed), operator engagement (initiated), inspector-vetting workload (identified), equipment-schedule drafting (initiated). Escalates any condition >4 weeks behind plan to political leadership.

**Responsible Body/Role:** Bilateral Executive Steering Committee

**Suggested Timeframe:** Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- First comprehensive entry-condition status report (signed by both co-chairs)
- Blocker identification and escalation memos for any delayed condition
- Revised milestone forecast for remaining entry conditions (Months 2–6 = 2026-12-08 to 2027-04-08)

**Dependencies:**

- Bilateral instrument signed
- Site selection completed
- Operator engagement initiated
- Inspector-vetting planning commenced

### 26. US Treasury and National Operations Unit jointly allocate and secure the US appropriations tranche (USD 2.5 billion) according to the defined budget envelopes (Ledger 625M, Site Prep 500M, Personnel 375M, Facilities 375M, Testing 250M, Legal/Audit 125M, Contingency 250M). Appropriations authority confirms obligation and spending authorization by Month 3 (2027-01-08).

**Responsible Body/Role:** US Treasury and US National Co-Chair (or designated National Operations Unit financial officer)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 3 (2027-01-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- US appropriations legislation or spending authorization (Congressional or Executive)
- Tranche-release schedule: first tranche (Months 0–3 = 2026-10-08 to 2027-01-08) USD 625M, subsequent tranches quarterly
- Envelope allocation sign-off and ledger mapping
- Spending-authority delegation to USNOU

**Dependencies:**

- US political leadership committed and bilateral instrument signed
- Budget envelopes defined and ratified by co-chairs
- Spending plan (by month and envelope) documented

### 27. Chinese Treasury and National Operations Unit jointly allocate and secure the Chinese appropriations tranche (USD 2.5 billion equivalent) according to the defined budget envelopes (Ledger 625M, Site Prep 500M, Personnel 375M, Facilities 375M, Testing 250M, Legal/Audit 125M, Contingency 250M). Appropriations authority confirms obligation and spending authorization by Month 3 (2027-01-08).

**Responsible Body/Role:** Chinese Treasury and Chinese National Co-Chair (or designated National Operations Unit financial officer)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 3 (2027-01-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- Chinese appropriations authorization or spending directive
- Tranche-release schedule: first tranche (Months 0–3 = 2026-10-08 to 2027-01-08) equivalent USD 625M, subsequent tranches quarterly
- Envelope allocation sign-off and ledger mapping
- Spending-authority delegation to CNOU

**Dependencies:**

- Chinese political leadership committed and bilateral instrument signed
- Budget envelopes defined and ratified by co-chairs
- Spending plan (by month and envelope) documented

### 28. US National Operations Unit initiates counterintelligence vetting of approximately 180–185 candidate US inspectors (144 baseline FTE inspectors + 20–30% surge pool) through expedited clearance request to FBI, NSA and relevant security agencies; vetting timeline 14–16 weeks (expedited) to Month 5 (2027-03-08).

**Responsible Body/Role:** US National Operations Unit (Inspector Vetting Officer, in coordination with US counterintelligence agencies)

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 5 (2027-03-08 to 2027-03-08)

**Key Outputs/Deliverables:**

- Candidate inspector roster with resumes and vetting-request submissions
- Vetting-status tracking dashboard (status per candidate: submitted, in-review, cleared, conditional, denied)
- Cleared-inspector roster by Month 5 (2027-03-08), minimum 80% fill rate (144 baseline) confirmed

**Dependencies:**

- USNOU leadership in place and vetting request authority delegated
- Vetting criteria and expedited timeline requested from US security agencies in Month 0.5 (2026-10-23)
- Vetting capacity (human and IT infrastructure) available at agencies

### 29. Chinese National Operations Unit initiates counterintelligence vetting of approximately 180–185 candidate Chinese inspectors (144 baseline FTE inspectors + 20–30% surge pool) through expedited clearance request to Ministry of State Security, Ministry of National Defense and relevant security organs; vetting timeline 14–16 weeks (expedited) to Month 5 (2027-03-08).

**Responsible Body/Role:** Chinese National Operations Unit (Inspector Vetting Officer, in coordination with Chinese counterintelligence agencies)

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 5 (2027-03-08 to 2027-03-08)

**Key Outputs/Deliverables:**

- Candidate inspector roster with CVs and vetting-request submissions
- Vetting-status tracking dashboard (status per candidate: submitted, in-review, cleared, conditional, denied)
- Cleared-inspector roster by Month 5 (2027-03-08), minimum 80% fill rate (144 baseline) confirmed

**Dependencies:**

- CNOU leadership in place and vetting request authority delegated
- Vetting criteria and expedited timeline requested from Chinese security organs in Month 0.5 (2026-10-23)
- Vetting capacity (human and administrative infrastructure) available at agencies

### 30. US and Chinese National Operations Units jointly draft the provisional covered-equipment schedule: a confidential, versioned, manufacturer-neutral technical specification of equipment classes and categories covered by Phase One verification. Schedule incorporates input from independent testing unit (for challenge-exercise scenario design) and is reviewed by both national technical teams.

**Responsible Body/Role:** US and Chinese National Operations Units (Chief of Ledger Operations or designated technical lead, jointly)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 2.5 (2026-12-23 to 2026-12-23)

**Key Outputs/Deliverables:**

- Draft provisional covered-equipment schedule v0.1 (functional/risk-relevance based, not product/manufacturer specific)
- Equipment-class definitions (compute, storage, networking, power, cooling categories)
- Inclusion/exclusion rationale
- Versioning and amendment procedures (double-key protocol change required)

**Dependencies:**

- Sites selected and operator liaisons established (to confirm equipment profile)
- Independent Testing Unit in position to advise on exercise-scenario relevance
- Both co-chairs ready to review and approve

### 31. Bilateral Executive Steering Committee formally adopts the provisional covered-equipment schedule: both co-chairs sign off on the schedule, mark it confidential, assign it a version number, and record it in the bilateral ledger as a baseline reference. Schedule is frozen through Phase One, with amendments only via recorded protocol change.

**Responsible Body/Role:** Bilateral Executive Steering Committee (both co-chairs)

**Suggested Timeframe:** Month 3 (2027-01-08)

**Key Outputs/Deliverables:**

- Bilateral co-chair approval and signature on provisional covered-equipment schedule
- Version number and confidential marking
- Ledger entry recording adoption, signed by both national ledger operators
- Amendment procedure documentation (requires double-key protocol change, recorded in ledger)

**Dependencies:**

- Draft schedule completed and reviewed by both national technical teams
- Both co-chairs ready to lock the baseline for the 90-day test

### 32. US National Operations Unit engages with top 5–8 equipment manufacturers and logistics vendors at US participating sites: negotiates binding cooperation agreements specifying attestation sharing, equipment-identity disclosure, maintenance reporting, third-party escort and evidence-preservation requirements, with penalty clauses (contract termination, loss of market access) for refusal.

**Responsible Body/Role:** US National Operations Unit (Head of Operator Engagement, in coordination with USNOU Director)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 4 (2027-02-08 to 2027-02-08)

**Key Outputs/Deliverables:**

- Binding-agreement templates tailored to each vendor class (manufacturers, maintenance providers, logistics)
- Signed or nearly-signed cooperation agreements with 5–8 key vendors at each site (10–16 total US-side vendor agreements)
- Vendor questions/concerns log and responses

**Dependencies:**

- Sites selected and operator liaisons established
- Equipment schedule finalized (so vendors know what equipment is covered)
- Bilateral instrument completed (governance framework defined)

### 33. Chinese National Operations Unit engages with top 5–8 equipment manufacturers and logistics vendors at Chinese participating sites: negotiates binding cooperation agreements specifying attestation sharing, equipment-identity disclosure, maintenance reporting, third-party escort and evidence-preservation requirements, with penalty clauses (contract termination, loss of market access) for refusal.

**Responsible Body/Role:** Chinese National Operations Unit (Head of Operator Engagement, in coordination with CNOU Director)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 4 (2027-02-08 to 2027-02-08)

**Key Outputs/Deliverables:**

- Binding-agreement templates tailored to each vendor class (manufacturers, maintenance providers, logistics)
- Signed or nearly-signed cooperation agreements with 5–8 key vendors at each site (10–16 total Chinese-side vendor agreements)
- Vendor questions/concerns log and responses

**Dependencies:**

- Sites selected and operator liaisons established
- Equipment schedule finalized (so vendors know what equipment is covered)
- Bilateral instrument completed (governance framework defined)

### 34. US National Operations Unit pre-qualifies a pool of 3–5 independent hardware-identity examiners and pre-identifies 1 clean-room facility available for vendor-refusal fallback routes; signs access agreements and pricing schedules by Month 4 (2027-02-08).

**Responsible Body/Role:** US National Operations Unit (Chief of Evidence Handling or equivalent technical lead)

**Suggested Timeframe:** Month 2 (2026-12-08) to Month 4 (2027-02-08 to 2027-02-08)

**Key Outputs/Deliverables:**

- Pre-qualified independent-examiner pool roster (3–5 US labs with expertise, qualifications, contact information)
- Clean-room facility pre-identification (1 facility, location, capabilities, access procedures)
- Signed access agreements and pricing schedules (cost cap: USD 20–30k per examination estimate)

**Dependencies:**

- Equipment schedule finalized (to specify equipment classes needing examiner expertise)
- Budget envelope (USD 250M testing) confirmed available
- Vendor-refusal protocol procedures documented

### 35. Chinese National Operations Unit pre-qualifies a pool of 3–5 independent hardware-identity examiners and pre-identifies 1 clean-room facility available for vendor-refusal fallback routes; signs access agreements and pricing schedules by Month 4 (2027-02-08).

**Responsible Body/Role:** Chinese National Operations Unit (Chief of Evidence Handling or equivalent technical lead)

**Suggested Timeframe:** Month 2 (2026-12-08) to Month 4 (2027-02-08 to 2027-02-08)

**Key Outputs/Deliverables:**

- Pre-qualified independent-examiner pool roster (3–5 Chinese labs with expertise, qualifications, contact information)
- Clean-room facility pre-identification (1 facility, location, capabilities, access procedures)
- Signed access agreements and pricing schedules (cost cap: USD 20–30k per examination estimate, or Chinese currency equivalent)

**Dependencies:**

- Equipment schedule finalized (to specify equipment classes needing examiner expertise)
- Budget envelope (USD 250M testing) confirmed available
- Vendor-refusal protocol procedures documented

### 36. US and Chinese National Operations Units jointly finalize and sign bilateral operator and vendor binding agreements at all 4 participating sites: both countries' operators commit to inspector access, equipment-identity verification, third-party escort, maintenance notification, evidence preservation, ledger compliance and exercise participation. Vendor agreements commit to cooperation or trigger escalation ladder.

**Responsible Body/Role:** US and Chinese National Operations Units (Head of Operator Engagement, jointly; signatures authorized by National Co-Chair or Deputy)

**Suggested Timeframe:** Month 4 (2027-02-08)

**Key Outputs/Deliverables:**

- Signed bilateral operator and vendor binding agreements at all 4 sites
- Operator commitment confirmations (evidence of operator signature authority and commitment)
- Vendor cooperation confirmations from top 5–8 vendors per site
- Escalation ladder trigger points documented (vendor request date, escalation authority, penalties)

**Dependencies:**

- Operator engagement completed at all sites
- Vendor engagement completed with top vendors
- Bilateral instrument governance framework finalized
- Budget authorization and contingency procedures in place (to fund fallback routes if needed)

### 37. US National Operations Unit designs and deploys secure US-side ledger-operations facility: secure facility for cryptographic key management, ledger synchronization with Chinese copy, offline backup and failover, access-control logging, redundant power/comms, and 24/7 operations capability. Facility operational and stress-tested on non-covered equipment by Month 4 (2027-02-08).

**Responsible Body/Role:** US National Operations Unit (Chief of Ledger Operations, with IT/security engineering support)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 4 (2027-02-08 to 2027-02-08)

**Key Outputs/Deliverables:**

- US ledger-facility design document (physical security, access control, cryptographic key custody, failover architecture)
- Facility location confirmation and facility-management contracts
- Cryptographic key-ceremony procedures (either joint ceremony if using split custody, or US national root plan if dual-roots)
- Stress-test results on non-covered equipment: sync latency <1 hour, divergence detection <2 hours, recovery <4 hours, operational readiness confirmed

**Dependencies:**

- USNOU Chief of Ledger Operations in place
- Bilateral ledger communications architecture designed (joint with CNOU)
- Attestation trust-root strategy decided (joint ceremony vs. independent national roots)
- Budget envelope (USD 625M ledger/comms) confirmed available

### 38. Chinese National Operations Unit designs and deploys secure Chinese-side ledger-operations facility: secure facility for cryptographic key management, ledger synchronization with US copy, offline backup and failover, access-control logging, redundant power/comms, and 24/7 operations capability. Facility operational and stress-tested on non-covered equipment by Month 4 (2027-02-08).

**Responsible Body/Role:** Chinese National Operations Unit (Chief of Ledger Operations, with IT/security engineering support)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 4 (2027-02-08 to 2027-02-08)

**Key Outputs/Deliverables:**

- Chinese ledger-facility design document (physical security, access control, cryptographic key custody, failover architecture)
- Facility location confirmation and facility-management contracts
- Cryptographic key-ceremony procedures (either joint ceremony if using split custody, or Chinese national root plan if dual-roots)
- Stress-test results on non-covered equipment: sync latency <1 hour, divergence detection <2 hours, recovery <4 hours, operational readiness confirmed

**Dependencies:**

- CNOU Chief of Ledger Operations in place
- Bilateral ledger communications architecture designed (joint with USNOU)
- Attestation trust-root strategy decided (joint ceremony vs. independent national roots)
- Budget envelope (USD 625M ledger/comms) confirmed available

### 39. US and Chinese National Operations Units jointly conduct a full ledger synchronization and failover stress test using non-covered equipment (placeholder or surplus items) at participating sites: test sync latency, divergence detection, offline backup restoration, cryptographic signing and verification, access-log integrity and forensic recovery procedures. Confirm <1 hour sync, <2 hour divergence detection and <4 hour recovery.

**Responsible Body/Role:** US and Chinese National Operations Units (Chief of Ledger Operations, jointly, with Independent Auditor observing)

**Suggested Timeframe:** Month 4 (2027-02-08)

**Key Outputs/Deliverables:**

- Joint ledger stress-test plan (scenarios, equipment, timeline, success criteria)
- Stress-test execution log (real-time performance metrics, anomalies, resolution steps)
- Stress-test results summary: sync latency, divergence detection time, recovery time, cryptographic verification success rate
- Audit sign-off: Independent Auditor confirms ledger resilience meets Phase One requirements
- Operator of record: go/no-go decision by both Chiefs of Ledger Operations

**Dependencies:**

- Both US and Chinese ledger facilities deployed and operational
- Secure communications links configured and tested
- Cryptographic key material in place (either from joint ceremony or dual national roots)
- Non-covered equipment reserved for testing (100–150 units per site)

### 40. Independent Testing Unit designs challenge-exercise scenarios and fair-ness rubric: specifies 7 event types (unreported arrival, substituted equipment, record falsification, delayed access, disputed identity, vendor refusal, reluctant operator), example scenarios per type, difficulty levels and realism benchmarks. Scenario peer-review rubric defined to validate fairness and comparability across countries.

**Responsible Body/Role:** Independent Testing Unit (Scenario Design Lead, with red-team facilitators from both countries)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 2 (2026-12-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Challenge-exercise scenario library (7 event types, 2–3 example scenarios per type, difficulty levels and realism descriptions)
- Scenario-design guidelines (how scenarios are generated, tested for fairness, and approved)
- Fairness-review rubric (criteria for assessing whether scenarios are realistic, comparable across countries, not biased toward either national team of inspectors)
- Peer-review process documentation (both countries' red teams review scenarios before formal exercises)

**Dependencies:**

- Independent Testing Unit Director and Scenario Design Lead in place
- Red-team facilitators from both countries identified and briefed
- Equipment schedule finalized (to ensure scenarios are realistic for covered equipment)

### 41. Independent Testing Unit conducts scenario peer-review workshop: both countries' red teams jointly review challenge scenarios against the fairness rubric, assess realism and comparability, and certify that scenarios are unbiased. Any fairness disputes are escalated to BESC.

**Responsible Body/Role:** Independent Testing Unit (ITU Director, Scenario Design Lead, Red-Team Facilitators from both countries)

**Suggested Timeframe:** Month 1.5 (2026-11-23) to Month 2 (2026-12-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Peer-review meeting minutes documenting red-team assessment of fairness and realism
- Peer-review sign-off form: each national red team certifies scenarios meet fairness criteria
- Disputed-scenario list (if any) escalated to BESC with fairness objections noted

**Dependencies:**

- Scenario library completed and circulated to both red teams
- Fairness-review rubric finalized and agreed by both teams
- Bilateral assessment methodology established

### 42. Independent Testing Unit conducts pre-test calibration exercise on non-covered equipment (Months 4–5 = 2027-02-08 to 2027-03-08): runs 50–100 practice scenarios per site using the same blind-exercise methodology as formal Phase One challenges. Inspectors blind to timing/content; scenarios cover all 7 event types. ITU scores detection rates, false-positive/negative counts and identity-confidence results.

**Responsible Body/Role:** Independent Testing Unit (ITU Director, Scenario Design Lead, Scoring Lead, Site Coordinators, Red-Team Facilitators, Independent Auditor)

**Suggested Timeframe:** Month 4 (2027-02-08) to Month 5 (2027-03-08 to 2027-03-08)

**Key Outputs/Deliverables:**

- Calibration-exercise execution log (scenarios run, dates, sites, inspectors blind-maintained, anomalies)
- Detection-rate results by event type: false-negative rate (%)，false-positive rate (%), detection-time distribution
- Calibration report: observed performance vs. provisional thresholds, recommendation for threshold adjustment or confirmation
- Auditor sign-off: Independent Auditor confirms calibration exercise integrity and scoring objectivity

**Dependencies:**

- Scenario library finalized and peer-reviewed
- Sites operational with inspectors deployed at 80%+ fill
- Non-covered equipment reserved and accessible at each site (100–150 units)
- Blind protocols and scoring procedures validated in pre-test workshops

### 43. Bilateral Executive Steering Committee receives calibration-exercise results and validates or adjusts provisional Go/Modify/Stop thresholds: compares observed detection rates, false-positive rates and unverifiable-equipment counts against baseline provisional targets. If observed performance differs >20% from provisional, both co-chairs authorize a recorded double-key amendment to lock the validated thresholds.

**Responsible Body/Role:** Bilateral Executive Steering Committee (both co-chairs), advised by Independent Testing Unit, Independent Auditor and Joint Forensic Panel

**Suggested Timeframe:** Month 5 (2027-03-08)

**Key Outputs/Deliverables:**

- Calibration results briefing to co-chairs (summarizing observed vs. provisional thresholds)
- Threshold validation or adjustment decision: co-chair signed agreement
- Validated thresholds, double-key signed and recorded in bilateral ledger
- Amendment documentation (if thresholds adjusted): recorded protocol change, signed by both co-chairs

**Dependencies:**

- Calibration exercise completed and scored
- Auditor sign-off on calibration integrity
- Provisional thresholds defined and published pre-calibration

### 44. Bilateral Executive Steering Committee designs and locks the sealed double-key challenge-exercise schedule for Phase One (Months 6–9 = 2027-04-08 to 2027-07-08): specifies exercise timing, sequence, venue (per-site staging/spare/maintenance areas), scenario details, red-team assignments, and blind-maintenance protocols. Schedule is signed by both co-chairs and held in sealed custody by ITU.

**Responsible Body/Role:** Bilateral Executive Steering Committee (both co-chairs), with Independent Testing Unit

**Suggested Timeframe:** Month 5.5 (2027-03-23)

**Key Outputs/Deliverables:**

- Sealed double-key exercise schedule (timing, sequence, sites, scenarios, red-team leads, inspector-blind protocols)
- Exercise schedule lock agreement, signed by both co-chairs
- Sealed-custody procedures documented (ITU Director holds schedule; elements released only as exercises occur)
- Site-coordination schedule (maintenance window compatibility, production-impact mitigation plan)

**Dependencies:**

- Calibration exercise completed and thresholds validated
- Scenario library finalized and fairness-reviewed
- All 4 sites selected and operators committed
- Inspectors deployed at 80%+ fill (both countries)

### 45. Bilateral Executive Steering Committee holds final comprehensive entry-condition certification review and formally certifies that all 7 mandatory entry conditions have been met: (1) bilateral instrument signed; (2) appropriations secured; (3) domestic authority enacted; (4) sites selected and ratified; (5) inspectors approved; (6) operators/vendors binding agreements signed; (7) equipment schedule adopted. Co-chairs issue a joint entry-condition certification memo.

**Responsible Body/Role:** Bilateral Executive Steering Committee (both co-chairs)

**Suggested Timeframe:** Month 6 (2027-04-08)

**Key Outputs/Deliverables:**

- Entry-Condition Certification Memo (jointly signed by both co-chairs)
- Checklist of all 7 conditions with sign-off evidence (signed documents, approvals, documented confirmations)
- Ledger entry recording certification (both national copies)
- Formal authorization to start the 90-day Phase One test clock

**Dependencies:**

- All 7 entry conditions demonstrated to be complete
- Weekly steering-committee tracking confirms no major blockers remain
- Independent Auditor confirms compliance with entry-condition requirements
- All governance bodies (BESC, Forensic Panel, Conduct Panel, ITU, Auditor) formally established and operational

### 46. Phase One formal test clock starts: Bilateral Executive Steering Committee formally declares the start of the 90-day verification test (Months 6–9 = 2027-04-08 to 2027-07-08). All governance bodies enter full operational mode. Inspectors begin shift coverage at all 4 participating sites. First national ledger entries are recorded (site status, inspector rosters, equipment baseline, initial observations).

**Responsible Body/Role:** Bilateral Executive Steering Committee (both co-chairs), with all operational units (USNOU, CNOU, ITU, Conduct Panel, Auditor)

**Suggested Timeframe:** Month 6 (2027-04-08) — Day 1 of 90-day Phase One test

**Key Outputs/Deliverables:**

- Phase One Start Declaration (jointly signed by both co-chairs, recorded in ledger)
- Inspector deployment confirmation at all 4 sites (shift rosters, personnel, zone assignments)
- Baseline ledger entries (site status, equipment inventory baseline, initial observations)
- Weekly entry-condition tracking transitions to weekly KPI dashboard tracking

**Dependencies:**

- Entry-condition certification completed
- All governance bodies established and tested
- Inspectors deployed and in-place
- Ledger systems synchronized and baseline data recorded

### 47. During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08): Bilateral Executive Steering Committee meets bi-weekly to review KPI dashboard, escalation events, ledger divergence, inspector-conduct incidents and contingency status. Monthly KPI dashboard published by Independent Auditor. Any material findings (divergence >7 days unresolved, spending variance >5%, vetting gap, exercise contamination) escalated to co-chairs within 24 hours.

**Responsible Body/Role:** Bilateral Executive Steering Committee (both co-chairs), supported by all operational units and Independent Auditor

**Suggested Timeframe:** Months 6–9 (2027-04-08 to 2027-07-08) — Bi-weekly BESC meetings; monthly KPI publication

**Key Outputs/Deliverables:**

- Bi-weekly BESC meeting minutes (KPI review, escalations, decisions, co-chair directives)
- Monthly KPI dashboard (detection rates, false rates, divergence counts, reciprocal-access parity, unresolved discrepancies, unverifiable equipment, vendor refusals, funding status, audit exceptions)
- Escalation reports (any material finding triggering co-chair notification within 24 hours)
- Contingency activation decisions (if any; documented co-chair approvals for expenditures >USD 25M per side)

**Dependencies:**

- Phase One clock started
- All governance bodies operational and reporting

### 48. During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08): Independent Testing Unit executes sealed-schedule challenge exercises (up to 2 per site per month = 6 per site over 90 days, or ~24 total across 4 sites). Exercises run blind; inspectors and operators unaware of timing/content until arrival. ITU records detection outcomes (true positive, false negative, false positive) and synchronizes real-time results with national ledger copies.

**Responsible Body/Role:** Independent Testing Unit (ITU Director, Scenario Lead, Scoring Lead, Site Coordinators, Red-Team Facilitators)

**Suggested Timeframe:** Months 6–9 (2027-04-08 to 2027-07-08) — Exercises per sealed double-key schedule

**Key Outputs/Deliverables:**

- Exercise-execution logs (one per exercise: date, site, scenario, inspectors blind-maintained, anomalies, incident response)
- Exercise-scoring sheets (true positive/false negative/false positive per event type, detection time, evidence gathering quality)
- Monthly detection-rate summaries by event type, with false-negative and false-positive counts
- Post-exercise audit reports (Independent Auditor confirms blind integrity and scoring objectivity after each exercise)

**Dependencies:**

- Phase One clock started
- Sealed exercise schedule locked and in ITU custody
- Sites operational and inspectors deployed
- Scenario library finalized and fairness-reviewed

### 49. During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08): Bilateral Inspector Conduct and Reciprocity Oversight Panel conducts monthly access-log audits, reviews Tier 1/2/3 conduct incidents, monitors reciprocal-access parity, and validates inspector-rotation compliance. Any Tier 2 or Tier 3 incidents escalated to Conduct Panel within 12 hours for investigation and recommendation.

**Responsible Body/Role:** Bilateral Inspector Conduct and Reciprocity Oversight Panel (co-chairs per country, with counterintelligence staff)

**Suggested Timeframe:** Months 6–9 (2027-04-08 to 2027-07-08) — Monthly conduct audits; ad-hoc incident response

**Key Outputs/Deliverables:**

- Monthly access-log audit reports (zone-boundary compliance, device-access patterns, anomalies)
- Tier 1 warning documentation (minor infractions handled within panel, on-file)
- Tier 2/3 investigation findings (within 24 hours of incident report, with Conduct Panel recommendation)
- Monthly reciprocal-access parity report (inspector deployment parity, zone-access hours parity, event-witnessing parity, escalation parity)
- Asymmetry-remediation directives (if parity diverges >20%)

**Dependencies:**

- Conduct Panel established and operational
- Inspector code of conduct signed by all deployed inspectors
- Access-log infrastructure (badge-swipe, device-access logging, location tracking) operational at all sites

### 50. During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08): Joint Forensic and Evidence Adjudication Panel activates on-demand for each contested equipment-identity finding or ledger divergence escalation. Panel reviews evidence layers, applies fixed corroboration rule, and issues binding findings within 48 hours or escalates to co-chairs if consensus fails.

**Responsible Body/Role:** Joint Forensic and Evidence Adjudication Panel (Chair and national specialists from both countries)

**Suggested Timeframe:** Months 6–9 (2027-04-08 to 2027-07-08) — On-demand activation (estimated 1–2 panels per week per site)

**Key Outputs/Deliverables:**

- Forensic panel findings (one per contested identity or divergence: evidence layers reviewed, corroboration rule applied, finding issued, provenance recorded)
- Disputed-finding escalation memos (if panel cannot reach consensus, to co-chairs with technical opinion)
- Monthly forensic summary (number of panels convened, findings issued, disputed findings escalated, resolution rate)

**Dependencies:**

- Forensic Panel established and operational
- Fixed corroboration rule double-key signed and published
- Evidence layers (attestation, physical inspection, records, identifiers, maintenance logs, infrastructure, witnessed movement) available from field operations

### 51. During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08): Independent Auditor publishes monthly KPI dashboard with detection rates, false positives/negatives, equipment-identity confidence, ledger-sync divergence counts, reciprocal-access parity, discrepancy-clock tiering, unverifiable-equipment counts, vendor-refusal outcomes, production-disruption incidents, funding-timeliness status and audit exceptions. Auditor flags threshold deviations for BESC attention.

**Responsible Body/Role:** Independent Auditor and KPI Monitoring Office (Auditor partner, KPI Director, Audit Leads)

**Suggested Timeframe:** Months 6–9 (2027-04-08 to 2027-07-08) — Monthly dashboard publication (by day 5 of each month)

**Key Outputs/Deliverables:**

- Monthly KPI Dashboard (all metrics listed above, with current month and cumulative data, threshold targets and deviations flagged)
- Monthly Auditor Exception Report (any findings of variance >5%, divergence >7 days unresolved, vetting gap, exercise contamination, spending anomaly)
- Quarterly Auditor Attestation Report (comprehensive findings on ledger resilience, evidence handling, spending compliance, personnel status, exercise integrity)

**Dependencies:**

- Independent Auditor established and operational
- KPI dashboard templates and data-collection procedures in place
- All governance bodies reporting KPI data (ITU detection rates, JFEAP divergence counts, Conduct Panel parity metrics, USNOU/CNOU spending, etc.)

### 52. At end of Phase One (Month 9 = 2027-07-08): Bilateral Executive Steering Committee compiles final Go/Modify/Stop decision package: Independent Auditor prepares comprehensive evidence summary (detection rates vs. thresholds, false-rate analyses, ledger divergence and reconciliation time, reciprocal-access parity assessment, unresolved-discrepancy age, unverifiable-equipment count, vendor-refusal outcomes, no IP/counterintelligence incidents). Co-chairs review and prepare for final decision.

**Responsible Body/Role:** Bilateral Executive Steering Committee (both co-chairs), with Independent Auditor, Independent Testing Unit and all support bodies

**Suggested Timeframe:** Month 9 (2027-07-08) — End of 90-day Phase One

**Key Outputs/Deliverables:**

- Comprehensive Phase One Evidence Summary Report (90-day data, all KPIs, threshold comparison, anomaly analysis)
- Independent Testing Unit Final Report (challenge-exercise results by event type, detection-rate conclusions, false-rate analysis, confidence assessment)
- Independent Auditor Final Attestation (ledger resilience, evidence integrity, spending compliance, personnel vetting, exercise fairness, any material audit exceptions)
- Bilateral Forensic Panel Final Summary (number of identity disputes resolved, contested findings escalated to co-chairs, unresolved identity count)

**Dependencies:**

- 90 days of Phase One operations completed
- All KPI data collected and validated
- All exercise results scored and audited
- All inspector conduct audits completed
- Ledger final state documented and reconciled

### 53. At end of Phase One (Month 9.5 = 2027-07-23): Bilateral Executive Steering Committee (both co-chairs) issues the formal Go/Modify/Stop decision: assessment of whether blind-challenge detection, false-positive rates, equipment-identity confidence, reciprocal-access parity, unverifiable-equipment counts, vendor-refusal outcomes and funding timeliness meet or exceed thresholds for a Go decision; or whether correctable weaknesses remain (Modify); or whether material failures (asymmetric access, unverifiable >10%, ledger divergence unresolved, funding withheld, low detection) warrant a Stop.

**Responsible Body/Role:** Bilateral Executive Steering Committee (both co-chairs), jointly; decision requires double-key (unanimous) agreement

**Suggested Timeframe:** Month 9.5 (2027-07-23)

**Key Outputs/Deliverables:**

- Go/Modify/Stop Decision Memo (jointly signed by both co-chairs)
- Decision rationale: evidence mapping to thresholds, threshold justification, any waived or adjusted criteria
- If Go: Phase Two authorization or timeline. If Modify: corrective actions, revised timeline and scope. If Stop: explanation of which threshold failures drove the decision and remediation requirements if restart is contemplated
- Ledger entry recording the decision (both national copies signed)

**Dependencies:**

- 90 days of Phase One operations completed and data compiled
- Independent Auditor attestation completed
- All KPI thresholds locked and validated pre-Phase One
- Both co-chairs reviewed and deliberated final evidence package

### 54. At Month 10 (2027-08-08), Bilateral Executive Steering Committee publishes the final Go/Modify/Stop decision to relevant stakeholders (both governments' leadership, participating operators, independent observers if designated, and (redacted for security) to relevant legislative/oversight bodies). Specifies next steps: if Go, Phase Two planning; if Modify, remediation timeline; if Stop, shutdown or hold procedures.

**Responsible Body/Role:** Bilateral Executive Steering Committee (both co-chairs), with communication coordination

**Suggested Timeframe:** Month 10 (2027-08-08)

**Key Outputs/Deliverables:**

- Final Go/Modify/Stop Decision Publication (redacted version for public/oversight audiences, full version for bilateral archives)
- Next-steps directive: Phase Two authorization or timeline; or remediation plan; or shutdown/hold notice
- Stakeholder notification letters to operators, vendors, governments, oversight bodies
- Lessons-learned summary for bilateral reflection and improvement planning

**Dependencies:**

- Go/Modify/Stop decision issued at Month 9.5 (2027-07-23)
- Redaction procedures applied to protect classified/sensitive details
- All governance bodies' final reports completed and archived

# Decision Escalation Matrix

**Budget Request Exceeding Envelope Authority**
Escalation Level: Bilateral Executive Steering Committee (BESC)
Approval Process: Double-key co-chair consensus. Budget tranches >USD 25M per side require written joint approval. Contingency releases up to USD 50M per side (USD 25M each) approved within 5 business days via fast-lane double-key signature. Larger contingency draws require extended BESC deliberation with spending justification documented in the ledger.
Rationale: National Operations Units (US and Chinese) have authority over operational spending within their USD 2.5B envelopes. Any tranche authorization >USD 25M or contingency request >USD 50M total (USD 25M per country) exceeds standard approval authority and requires double-key co-chair consensus to ensure mutual accountability and prevent unilateral budget overspend.
Negative Consequences: Unauthorized spending or tranche delays cascade to facility deployment, inspector vetting, vendor-fallback activation or exercise coordination. A delayed USD 25M+ tranche approval can defer Phase One start by 2-4 weeks, consuming the calibration window and increasing risk of mis-set thresholds. Uncontrolled contingency draws could exhaust the USD 500M reserve, leaving no surge capacity and forcing a Modify or Stop decision if additional failures occur.

**Ledger Divergence Unresolved Beyond Threshold**
Escalation Level: Joint Forensic and Evidence Adjudication Panel; if unresolved beyond 7 days, automatic escalation to Bilateral Executive Steering Committee for double-key decision on site suspension or impaired-confidence status
Approval Process: Joint Forensic Panel issues binding or co-chair-delegated findings within 48 hours of escalation. If consensus fails or divergence persists >4 hours, escalate immediately to both National Operations Units' Chiefs of Ledger Operations for forensic troubleshooting within 2 hours. If divergence >7 days unresolved, automatic impaired-confidence status triggers; lifting requires double-key co-chair authorization. Automatic site suspension follows at 14 days unresolved unless co-chairs jointly extend in writing.
Rationale: The replicated ledger is the foundational evidence record. Unresolved divergence between national copies (target <1 hour sync, detection within 2 hours) indicates either a technical failure or contested identity claims that undermine verification integrity. A divergence persisting >7 days blocks discrepancy resolution and triggers mandatory escalation to prevent indefinite disputes from stalling Phase One.
Negative Consequences: Unresolved ledger divergence >7 days forces automatic impaired-confidence status or site suspension, effectively ending Phase One operations at that site. A material unresolved divergence (contested equipment identity with no forensic consensus) can render a site's evidence base unreliable and trigger a Modify or Stop outcome. Repeated divergence events suggest either technical fragility or adversarial ledger manipulation, either of which undermines the entire bilateral mechanism's credibility.

**Critical Vendor Refusal Cascading to Unverifiable Equipment Count >Threshold**
Escalation Level: Bilateral Executive Steering Committee (BESC), with Joint Forensic Panel input on unverifiable classification
Approval Process: Vendor refusal activates the 10-day escalation ladder: direct request (day 0) → operator (day 1) → independent examiner notification (day 2) → examination (day 3-5) → report (day 10). At day 10, if no evidence is available, equipment is marked unverifiable. If unverifiable equipment exceeds 5% of deployed at a site (proposed threshold), the site risks Go-threshold failure. BESC double-key reviews the vendor-refusal outcome and either approves alternative fallback (clean-room, validated attestation) or certifies unverifiable status for final-decision impact.
Rationale: Vendor refusal on critical equipment (e.g., a major manufacturer withholding attestation or maintenance records) can block identity verification for 5-20% of deployed items per site (estimate). If fallback routes (independent examiners, clean-room facilities, validated attestations) are not pre-positioned or fail, material equipment becomes unverifiable. Equipment unverifiable >5% at a site violates the Go threshold and requires co-chair decision on whether the site passes Phase One.
Negative Consequences: A major vendor refusal (e.g., 10-15% of equipment affected) can cascade to unverifiable counts exceeding the 5% Go threshold, forcing a site to fail Phase One. Unresolved vendor refusals consume the 10-day escalation clock and may collide with discrepancy deadlines, triggering multiple escalations. If multiple vendors refuse at the same site, the site may become entirely unverifiable, triggering a Modify or Stop outcome. Cost impact: late-engaged independent examiners cost USD 50-100k per exam vs. USD 20-30k planned, consuming contingency funds.

**Inspector Conduct Violation—Tier 3 (Material Espionage Risk or Serious Unauthorized Access)**
Escalation Level: Bilateral Inspector Conduct and Reciprocity Oversight Panel (for investigation within 12 hours); if Tier 3 removal is recommended, immediate escalation to Bilateral Executive Steering Committee for double-key authorization of inspector removal
Approval Process: Tier 3 incident (undisclosed photography of workload location, network topology, unauthorized collection) triggers joint panel investigation within 12 hours. Panel issues removal recommendation within 24 hours if consensus is reached. Removal of an inspector requires written findings from both national panel members and joint Conduct Panel chair approval; the offending government's Deputy Co-Chair is notified with justification within 24 hours. BESC may be asked to confirm the removal if the offending government contests the finding.
Rationale: Inspector espionage or coerced collection risk is high in a low-trust bilateral environment. A Tier 3 incident (material breach of conduct code or serious unauthorized access) signals potential intelligence collection by or against the inspector, which could collapse reciprocal trust if not escalated and resolved immediately. Immediate removal prevents further exposure and demonstrates that both governments enforce conduct rules equally.
Negative Consequences: Failure to escalate and remove a Tier 3 offender can trigger the other government to suspect espionage and reciprocally expel counterpart inspectors, collapsing reciprocal access and failing Phase One. A substantiated Tier 3 incident discovered post-Phase One (e.g., unauthorized device access or photography) undermines the credibility of that inspector's observations and potentially invalidates evidence from their shift. If 1-2 Tier 3 incidents occur per country during Phase One, both governments may withdraw consent and terminate the mechanism.

**Discrepancy Escalation Clock Expiry Without Resolution (Tier 2 or Tier 3 Deadlock)**
Escalation Level: Bilateral Executive Steering Committee (co-chairs), with Independent Auditor input; if both co-chairs disagree on resolution, neutral referee panel escalation
Approval Process: Tier 2 (72-hour) clock managed by Joint Adjudication Unit: allows one 36-hour extension with written reasons. If Tier 2 is not resolved by hour 108 (72 hours + extension), escalate to BESC within 2 hours with the Adjudication Unit's technical findings. BESC has 12 hours to issue a co-chair decision on disposition (resolved, escalated to Tier 3, or marked impaired-confidence). If co-chairs disagree, neutral referee panel (3-5 senior officials) provides a non-binding opinion within 5 days. Tier 3 (14-day) automatic suspension fires at day 14 unless BESC jointly authorizes a further extension (recorded in ledger).
Rationale: Discrepancy clocks (Tier 1 = 24h, Tier 2 = 72h, Tier 3 = 14d) prevent indefinite delays and test whether the mechanism can resolve disputes within operationally acceptable timeframes. A Tier 2 clock expiry without resolution indicates either a legitimate fact-finding dispute (requiring co-chair or referee arbitration) or gaming/obstruction (requiring escalation to suspension). Automatic Tier 3 suspension at day 14 prevents unresolved items from accumulating and clouding the final decision.
Negative Consequences: If Tier 2 clocks expire at multiple sites within a short period, automatic escalation to BESC overwhelms governance bandwidth and delays other decisions. A Tier 3 automatic suspension, even if the mechanism is working correctly, forces the final decision to account for suspension events and may falsely lower confidence in Phase One. Repeated Tier 2/3 expirations (>3 unresolved items per site) suggest either insufficient fact-finding resources or adversarial obstruction by one side, either of which can trigger a Modify or Stop outcome.

**Reciprocal Access Parity Breach—Asymmetric Access or Evidence Denial**
Escalation Level: Bilateral Inspector Conduct and Reciprocity Oversight Panel (for parity analysis); if asymmetry >20% and unresolved after 10 days, escalation to Bilateral Executive Steering Committee with potential neutral referee arbitration
Approval Process: Monthly Conduct Panel audit compares inspector deployment, zone-access hours, event-witnessing parity and escalation authority across both countries. If parity diverges >20% (proposed threshold), Conduct Panel flags asymmetry to BESC within 5 days with remediation options (e.g., expanding one side's access, reducing the other's, rebalancing escalation authority). BESC has 10 days to resolve the asymmetry by mutual agreement or authorize a neutral referee panel to recommend parity restoration. If unresolved >10 days, the offending country must restore parity or face equivalent counter-restriction by the other side (automatic parity-restoration mechanism).
Rationale: The bilateral mechanism is founded on reciprocal access and mutual trust. If one country grants its inspectors narrower zone access, longer maintenance windows, or faster escalations than its counterpart receives, the other side has grounds to suspect unequal verification and may object to the Go decision. Asymmetry >20% is material (proposed threshold) and requires immediate escalation to prevent confidence collapse.
Negative Consequences: Asymmetric access discovered late in Phase One (e.g., at Month 8 = 2027-06-08, near final decision) can trigger the disadvantaged country to reject the Go verdict as invalid, delaying the final decision by 2-4 weeks. One country's unilateral access restriction citing national security (which cannot be disputed by referees) can activate the other side's equivalent counter-restriction, cascading into mutual narrowing of access that undermines detection effectiveness. If asymmetry persists >14 days unresolved, both countries may withdraw consent and terminate Phase One.

# Monitoring Progress

### 1. Tracking Entry-Condition Certification Progress and Reciprocity Gate Status
**Monitoring Tools/Platforms:**

  - Entry-Condition Steering Committee Weekly Tracking Dashboard (spreadsheet with milestone status, blockers, escalation flags)
  - Bilateral Instrument and Legal Authority Checklist (signed documents, domestic legislation status tracker)
  - Inspector Vetting Status Tracker (counterintelligence clearance progress by candidate, agency delays flagged)
  - Site Selection and Operator Binding-Agreement Log (contracts signed, ratification status)

**Frequency:** Weekly steering-committee review (Months 0–6 = 2026-10-08 to 2027-04-08); escalation to political leadership if any condition lags >4 weeks behind plan

**Responsible Role:** Bilateral Executive Steering Committee (both co-chairs jointly), with designated entry-condition owners (US and Chinese) for each of the 7 mandatory conditions

**Adaptation Process:** If a single condition (e.g., inspector vetting, domestic legislation) extends >4 weeks beyond plan, co-chairs immediately escalate to political leadership with a decision memo: either expedite the lagging condition, or authorize a conditional/partial-start fallback (e.g., pre-clock dry run on non-covered equipment). If delay persists to Month 9 (2027-07-08), co-chairs invoke the gate backstop and double-key decide to extend Phase One start or stop. Any entry-condition failure is escalated to BESC and reflected in monthly KPI reporting.

**Adaptation Trigger:** Any single entry condition >4 weeks behind plan (Month 2 = 2026-12-08 baseline for site selection, Month 3 = 2027-01-08 for appropriations/authority, Month 4 = 2027-02-08 for operator/vendor binding, Month 5 = 2027-03-08 for inspector approval); or any condition not certified by Month 6 (2027-04-08) triggers the Month 9 (2027-07-08) backstop review for extend-or-stop decision

### 2. Monitoring Critical Success Factor: Ledger Divergence and Forensic Identity Resolution
**Monitoring Tools/Platforms:**

  - Bilateral Ledger Synchronization Dashboard (real-time or hourly update of sync latency, divergence counts, reconciliation status per site)
  - Joint Forensic Panel Findings Log (contested identities escalated, evidence layers analyzed, findings issued, status of resolution)
  - Discrepancy Clock Tracking (Tier 1/2/3 escalation status, clock expirations, extensions granted, automatic suspensions triggered)
  - Ledger Divergence Event Report (monthly summary: divergence count, detection time, resolution time, unresolved cases)

**Frequency:** Real-time divergence detection and escalation within 2 hours of divergence discovery; forensic panel activation on-demand (estimated 1–2 per week per site); monthly divergence and forensic summary report by Independent Auditor

**Responsible Role:** US and Chinese National Operations Units (Chiefs of Ledger Operations, jointly for forensic escalation); Joint Forensic and Evidence Adjudication Panel (for identity findings); Independent Auditor (for monthly reporting on ledger integrity)

**Adaptation Process:** Divergence >4 hours unresolved escalates to both Ledger Chiefs within 30 minutes for technical root-cause analysis and recovery. If divergence persists >7 days unresolved, automatic impaired-confidence status fires and the site enters escalation protocol; lifting requires double-key co-chair authorization and must be documented in the ledger. Any unresolved ledger divergence is flagged in monthly KPI reporting and counted as an audit exception. If forensic panel consensus fails on a contested identity, the matter escalates to co-chairs for decision within 24 hours; if co-chairs cannot agree, a neutral referee panel provides a non-binding opinion within 5 days.

**Adaptation Trigger:** Ledger divergence >4 hours unresolved (triggers technical escalation to Ledger Chiefs); divergence >7 days unresolved (automatic impaired-confidence status and escalation to BESC); contested equipment identity unresolved by forensic panel within 48 hours (escalation to co-chairs); Tier 2 or Tier 3 discrepancy clock expiry without forensic resolution

### 3. Monitoring Critical Success Factor: Vendor Refusal Escalation and Equipment Unverifiability
**Monitoring Tools/Platforms:**

  - Vendor Cooperation Status Tracker (pre-binding agreement status, signed vs. pending, refusal alerts)
  - Vendor Refusal Escalation Ladder Log (each refusal tracked day-by-day: request, operator escalation, examiner notification, exam scheduling, report, unverifiable classification)
  - Unverifiable Equipment Count Dashboard (equipment count by site, reason for unverifiable status, percentage of deployed)
  - Independent Examiner and Clean-Room Facility Utilization Report (pool availability, actual engagement, cost tracking against budget)

**Frequency:** Weekly vendor-cooperation status review (Months 1–4 = 2026-11-08 to 2027-02-08 during pre-binding phase); daily escalation ladder tracking once a refusal is reported; monthly unverifiable-equipment count report

**Responsible Role:** US and Chinese National Operations Units (Head of Operator Engagement, jointly for vendor coordination); Joint Forensic Panel (for unverifiable classification review); US and Chinese Technical Leads (for independent-examiner engagement)

**Adaptation Process:** Vendor refusal activates the 10-day escalation ladder automatically: if no fallback evidence is available by day 10, equipment is marked unverifiable. If unverifiable count approaches or exceeds 5% of deployed at a site, a bilateral review convenes to assess whether alternative evidence routes (clean-room, validated attestation) can recover the equipment or whether the site will fail the Go threshold. If a major vendor (affecting 5–15% of equipment) refuses cooperation, both co-chairs are notified within 24 hours and decide whether to escalate to operator/government level or invoke the vendor-refusal Stop condition (equipment unverifiable >10% per site). Monthly unverifiable counts are tracked in the KPI dashboard and feed the final Go/Modify/Stop decision.

**Adaptation Trigger:** Vendor refusal reported (activates 10-day escalation ladder); vendor refusal affecting 5% or more of site equipment (escalates to BESC for remediation decision); unverifiable equipment reaching 5% of deployed per site (triggers bilateral review of Go-threshold risk); unverifiable >10% at a site (Stop condition candidate)

### 4. Monitoring Critical Success Factor: Blind-Challenge Detection Performance and Exercise Integrity
**Monitoring Tools/Platforms:**

  - Independent Testing Unit Sealed Exercise Schedule and Execution Log (exercises run, timing, scenarios, real-time incident tracking)
  - Detection Scorecard by Event Type (monthly: unreported arrivals, substitutions, record falsification, delayed access, disputed identity, vendor refusal, reluctant operator; true positives, false negatives, false positives per type)
  - Monthly Detection Rate Summary and Threshold Deviation Report (observed rates vs. locked thresholds for Go decision, deviation flags)
  - Exercise Audit and Fairness Report (post-exercise independent auditor sign-off on blind integrity, scoring objectivity, scenario realism)

**Frequency:** Per-exercise real-time incident logging and immediate post-exercise scoring (within 72 hours); monthly detection-rate compilation and threshold-deviation analysis; quarterly fairness and integrity audit by Independent Auditor

**Responsible Role:** Independent Testing Unit (Scoring Lead, Site Coordinators, Red-Team Facilitators; reports to BESC); Independent Auditor (quarterly fairness review); Bilateral Executive Steering Committee (monthly threshold-deviation review)

**Adaptation Process:** Monthly detection-rate data is compiled and compared against locked thresholds (90% unreported arrival, 85% substitution, 80% falsification, <5% false positives, proposed). If observed detection for any event type falls >10% below locked threshold by Month 7 (2027-05-08), BESC is notified and reviews whether corrective training, protocol clarification or evidence-layer adjustment is needed. If detection remains <70% for a category at Month 8 (2027-06-08), that feeds into the final Go/Modify/Stop decision as evidence of a weakness. If any exercise is discovered to be compromised (advance notice to inspectors, unplanned facility disruption), the Independent Auditor flags it as void and recommends re-execution or exclusion from the evidence base. Monthly detection reports are published in the KPI dashboard.

**Adaptation Trigger:** Observed detection rate for any event type falls >10% below locked threshold by Month 7 (2027-05-08); any exercise detection <70% at any site; post-exercise audit discovers exercise contamination or fairness violation (void the exercise, recommend re-run or exclusion from evidence base); disparity in detection rates between US and Chinese inspectors suggests asymmetric training or capability (triggers bilateral review and potential rebalancing of inspector roles)

### 5. Monitoring Critical Success Factor: Inspector Conduct and Reciprocal-Access Parity
**Monitoring Tools/Platforms:**

  - Monthly Access-Log Audit Report (inspector zone-boundary compliance, device-access patterns, location-tracking validation, anomaly flags)
  - Tier 1/2/3 Conduct Incident Log (infraction severity, investigation status, resolution/removal recommendation, status tracking)
  - Reciprocal-Access Parity Dashboard (inspector deployment per country per site, zone-access hours, witnessed events, escalation authority—all metrics compared for >20% asymmetry)
  - Inspector Rotation and Rapid-Replacement Pool Status (rotation schedule compliance, surge-pool readiness, clearance expiry tracking)

**Frequency:** Monthly access-log audits and conduct-incident review (conducted by Bilateral Conduct Panel); monthly reciprocal-access parity metrics (compared by Conduct Panel); ad-hoc Tier 2/3 incident investigation (within 12–24 hours of report)

**Responsible Role:** Bilateral Inspector Conduct and Reciprocity Oversight Panel (co-chairs per country, counterintelligence staff); US and Chinese National Operations Units (liaison and rapid-replacement coordination)

**Adaptation Process:** Monthly access-log audits flag any zone-boundary infractions, device-access anomalies or location-tracking gaps. Tier 1 infractions (minor, first offense) are handled as written warnings within the panel; Tier 2 (repeated or deliberate violation) escalates to formal notice and Conduct Panel review within 24 hours; Tier 3 (material espionage risk, serious unauthorized access) triggers immediate removal investigation and removal recommendation to co-chairs within 12 hours. Reciprocal-access parity metrics are compared monthly; if asymmetry >20% (proposed threshold) is detected, Conduct Panel flags it to BESC within 5 days with remediation options (expand one side's access, rebalance escalation authority). If asymmetry persists >10 days, an automatic counter-restriction activates (the advantaged side voluntarily narrows its access to match the disadvantaged side). Any substantiated Tier 3 incident or material parity breach is escalated to BESC and tracked as a potential Go-decision risk factor.

**Adaptation Trigger:** Tier 2 or Tier 3 conduct incident reported (escalation within 12–24 hours for investigation); reciprocal-access asymmetry >20% detected (5-day BESC notification and remediation planning); Tier 3 removal recommendation (immediate co-chair authorization required); repeated Tier 2 incidents by same inspector (automatic escalation to Tier 3 investigation)

### 6. Monitoring Budget Timeliness and Contingency Drawdown
**Monitoring Tools/Platforms:**

  - Monthly Spending Variance Report (actual vs. planned spending per envelope; flags variance >5%; cost-center reconciliation)
  - Contingency Fund Release Log (all contingency tranches >USD 25M tracked; fast-lane releases <USD 50M documented)
  - Tranche Timing Tracker (each USD 625M (US) and USD 625M (China) quarterly tranche release and obligation timeline; 45-day appropriation-release window monitored)
  - Deficit or Overrun Alert Dashboard (cumulative spending vs. remaining budget by envelope and month; red-flag if overrun threatened)

**Frequency:** Monthly spending-variance audit (by Independent Auditor); monthly tranche-release timing review (by Bilateral Executive Steering Committee); quarterly comprehensive budget-reconciliation audit

**Responsible Role:** US and Chinese National Operations Units (financial officers, spending authorization); Independent Auditor (variance flagging and monthly reporting); Bilateral Executive Steering Committee (contingency authorization)

**Adaptation Process:** Each month, actual spending is reconciled against planned spending per envelope. If variance >5% (proposed threshold) is detected in Months 0–3 (2026-10-08 to 2027-01-08), the Independent Auditor flags the variance to BESC within 5 days; the relevant National Operations Unit must provide explanation and corrective action plan within 10 days. If variance persists or repeats, it signals budget-execution risk and may trigger early contingency release or spending restraint in other envelopes. If tranche release is delayed beyond 45 days (plus a 30-day cure window = 75 days total), the delay counts as funding withheld (a Stop condition). If contingency drawdown approaches USD 400M of the USD 500M total (80% utilization), BESC is alerted and must review whether surge capacity is being depleted faster than planned; if contingency is fully drawn before Month 8 (2027-06-08), BESC must authorize either austerity measures or notify both governments of funding shortfall risk.

**Adaptation Trigger:** Spending variance >5% in Months 0–3 (2026-10-08 to 2027-01-08) (5-day escalation to BESC); tranche late beyond 75 days (45-day release window + 30-day cure) (counts as funding withheld, Stop condition); contingency utilization >80% (alerts BESC for surge-capacity review); any single cost overrun >USD 100M (escalates to BESC for authorization)

### 7. Monitoring Go/Modify/Stop Decision Threshold Readiness and KPI Dashboard Convergence
**Monitoring Tools/Platforms:**

  - Locked Thresholds Validation Document (all Go/Modify/Stop decision thresholds, double-key signed, baseline and validated by calibration exercise, recorded in ledger)
  - Monthly KPI Dashboard (detection rates, false rates, identity confidence, sync divergence, reciprocal-access parity, discrepancy age, unverifiable counts, vendor refusals, funding timeliness, audit exceptions; all metrics compared to locked thresholds with deviation flags)
  - Final-Decision Evidence Summary Report (compiled at Month 9 = 2027-07-08, summarizing all 90-day data against Go/Modify/Stop rubric)

**Frequency:** Thresholds locked by Month 5.5 (2027-03-23), before first formal blind exercise; monthly KPI dashboard published by Independent Auditor (Months 6–9 = 2027-04-08 to 2027-07-08); final decision package assembled at Month 9 (2027-07-08)

**Responsible Role:** Bilateral Executive Steering Committee (threshold lock and Go/Modify/Stop decision); Independent Testing Unit (detection-rate data); Independent Auditor (KPI compilation and final-decision package)

**Adaptation Process:** Locked thresholds are published pre-Phase One (by Month 5.5 = 2027-03-23) with full justification documented in the bilateral ledger. During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08), monthly KPI data is compiled and compared to thresholds; any material deviation (detection <70%, false positives >10%, unverifiable >10%, unresolved divergence >7 days, reciprocal-access asymmetry >20%) is flagged in real-time reporting and escalated to BESC. At Month 9 (2027-07-08), a comprehensive evidence summary is prepared, comparing all 90-day metrics to the locked thresholds. If performance exceeds Go thresholds, BESC authorizes a Go decision (Phase Two or continuation). If performance is correctable (Modify criteria: detection 70–85%, unverifiable 5–10%), BESC issues Modify with remediation timeline. If performance triggers Stop criteria (asymmetric access, unverifiable >10%, divergence unresolved, funding withheld, detection <70%), BESC issues Stop and closure procedures.

**Adaptation Trigger:** Thresholds not locked by Month 5.5 (2027-03-23) (escalates to BESC for emergency lock; formal clock start may be delayed); any monthly KPI showing detection <70%, false positives >10%, or unverifiable >10% (real-time escalation to BESC and trigger for corrective action or early warning); final-decision readiness at Month 9 (2027-07-08) showing any Stop criteria met (automatic escalation to co-chairs for Go/Modify/Stop final decision at Month 9.5 = 2027-07-23)

# Governance Extra

## Governance Validation Checks

1. Completeness: All core governance components are generated: 5 primary internal bodies (BESC, Joint Forensic Panel, USNOU, CNOU, ITU), 2 oversight bodies (Conduct Panel, Independent Auditor), 28-step implementation plan, 5-item escalation matrix with approval processes and triggers, and 6-area monitoring plan with adaptation procedures. Bilateral instrument, entry-condition tracking, KPI dashboard, and Go/Modify/Stop decision framework are present. The architecture directly addresses double-key governance, deadlock resolution, forensic identity adjudication, ledger divergence handling and vendor-refusal fallbacks specified in the strategic decisions.
2. Internal Consistency: The governance bodies align logically with the decision-escalation matrix and implementation timeline. BESC (equal co-chairs, no casting vote) makes all strategic decisions; Joint Forensic Panel (equal national teams, consensus or co-chair escalation) resolves contested identities within 48 hours; bilateral Conduct Panel (one co-chair per country) manages inspector conduct with three-tier escalation (Tier 3 removal requires BESC); ITU (independent) runs blind exercises on sealed schedule; Independent Auditor (external, jointly selected) publishes monthly KPI dashboard and quarterly attestation. National Operations Units (USNOU and CNOU) are mirror entities with identical roles but no authority over each other, reporting to co-chairs and BESC. Timeline is internally consistent: entry-condition certification by Month 6 (2027-04-08), Phase One Months 6–9 (2027-04-08 to 2027-07-08), decision Month 10 (2027-08-08). Escalation paths are documented (Tier 1→2→3 for conduct; Tier 2→Tier 3→automatic suspension for discrepancies; 7-day deadlock→referee panel→automatic suspension for contested identity). No contradictions detected between stages.
3. Critical Gaps—Forensic Authority and Contested Identity Deadlock: The Joint Forensic Panel is empowered to issue 'binding or co-chair-delegated findings' on equipment identity within 48 hours, but the decision-escalation matrix does not specify under what conditions findings are binding vs. delegated to co-chairs. If both national panel members dispute the evidence (one says identity confirmed, the other says unverifiable), does the panel issue a 'split finding' or immediately escalate to co-chairs? The escalation matrix states disputed findings escalate within 48 hours with a 'technical opinion' to co-chairs for final decision, but does not specify the co-chair decision window before automatic escalation to the neutral referee panel (the deadlock rule says 7 days for decision-critical items, but forensic escalations are time-sensitive within discrepancy clocks). If a Tier 2 discrepancy clock expires while awaiting a contested forensic finding, which takes precedence: the forensic escalation timeline (48 hours to co-chairs) or the discrepancy clock (72 hours + 36-hour extension = 108 hours)? The governance does not explicitly bind these two critical timelines or define what happens if a forensic finding cannot be issued before a discrepancy clock expires. Recommendation: Define forensic consensus rules (e.g., panel consensus required for binding finding; split finding with >36 hours to co-chair decision triggers automatic one-time extension of discrepancy clock by 24 hours) and document the interaction between forensic and discrepancy-clock timelines in the bilateral instrument.
4. Critical Gaps—Operator Non-Compliance Escalation and Site Suspension Authority: The implementation plan specifies binding operator agreements by Month 4 (2027-02-08) and operator engagement as a mandatory entry condition, but the escalation matrix and implementation plan do not define what happens if an operator breaches the agreement during Phase One (e.g., refuses inspector access to a maintenance window, withholds evidence, disrupts an exercise, or shields a vendor refusal). The governance bodies are authorized to escalate vendor refusals, discrepancy clocks, and inspector conduct violations, but there is no escalation path for operator non-compliance that doesn't match those categories. If an operator claims force majeure (production emergency, facility failure) to deny access, who decides whether the access denial is justified or a violation? Does the BESC have authority to suspend a site if the operator breaches the binding agreement, or does that require a formal renegotiation of the bilateral instrument? The governance implicitly assumes operator cooperation; the absence of an escalation path for operator refusal or non-compliance is a gap. Recommendation: Add an Operator Breach Escalation procedure: (1) USNOU or CNOU escalates alleged operator non-compliance to BESC within 24 hours with evidence; (2) BESC reviews and, if justified, issues a co-chair notice to the operator with cure deadline (3–7 days depending on severity); (3) if not cured, site enters impaired-confidence status or suspension; (4) an uncooperative operator is grounds for site replacement (activate fallback site from shortlist within 4–8 weeks) or Phase One termination.
5. Critical Gaps—Ledger Key Material Custody and Compromise Response: The implementation plan specifies a joint key ceremony (or two independent national roots) by Month 4 (2027-02-08), but does not define who physically holds the cryptographic keys between ceremonies, access controls, audit procedures, or the incident-response protocol if key material is suspected compromised. If one government's copy of a shared key is suspected exposed to unauthorized access, does that trigger an automatic key rotation (taking 1–2 weeks) and re-signing of all ledger entries? The governance assumes cryptographic integrity but does not specify how divergence due to key compromise is distinguished from technical faults or adversarial manipulation. The stress test for the ledger (Month 4 = 2027-02-08) includes cryptographic signing validation, but does not specify whether the test includes simulated key-compromise recovery. Recommendation: Document the key-custody protocol (who holds keys, access logs, multi-factor controls, audit frequency—recommend monthly cryptographic-material audit); define a key-compromise incident response procedure (immediate key rotation, re-signing, forensic investigation, notification to co-chairs within 4 hours); include key-compromise recovery drill in the Month 4 (2027-02-08) ledger stress test.
6. Critical Gaps—Threshold Calibration and Provisional-to-Validated Conversion: The implementation plan locks thresholds at Month 5.5 (2027-03-23) after calibration exercise (Months 4–5 = 2027-02-08 to 2027-03-08); the calibration report is supposed to 'validate or adjust' thresholds if observed performance differs >20% from provisional. However, the decision-escalation matrix does not specify the approval process for threshold amendment: Is a >20% adjustment a 'recorded protocol change' requiring full bilateral instrument amendment and double-key signature, or can BESC approve it with a simple recorded memo? The implementation plan says 'documented protocol change signed by both co-chairs before formal clock starts,' implying a lightweight amendment process, but the bilateral instrument (user constraints) specifies that 'protocol changes' require double-key authorization. If the calibration exercise reveals that provisional thresholds are unrealistic (e.g., observed false-negative rate is 15% instead of 5% target), a threshold adjustment from <5% to 15% is a material change that redefines what constitutes Go success. Does that amendment require renegotiation of the bilateral instrument itself, or is it treated as an operational parameter adjustment by co-chairs? The governance does not clarify this distinction. Recommendation: Define 'protocol change' vs. 'operational adjustment' in the bilateral instrument: Protocol changes (double-key, recorded amendment) include decision thresholds, escalation clocks, infraction tiers, and corroboration rule; operational adjustments (co-chair memo) include exercise scheduling, inspection-roster details, and facility-deployment timelines. Threshold amendments post-calibration but pre-Phase One are treated as protocol changes and must be double-key signed and recorded in the ledger before formal clock starts.

## Tough Questions

1. By Month 2 (2026-12-08), what is the documented status of domestic access-authority legislation in each country? Specifically: (US) What is the legislative vehicle and Congressional committee timeline for authorization? (China) What State Council directive number, agency assignment and enforcement mechanism have been designated? If either is delayed >4 weeks beyond the Month 2–3 baseline (2026-12-08 to 2027-01-08), what is the contingency—a pre-clock dry run, or does Phase One clock start defer to Month 9 (2027-07-08) backstop decision?
2. At the Month 5 (2027-03-08) inspector-vetting completion milestone, provide the actual fill rate (cleared inspectors ÷ 144 baseline per country). If fill rate is <80% at either country, name which critical posts remain unfilled, provide the specific reason for each vetting delay (security-agency backlog, candidate disqualification, clearance hold), and specify the date by which remaining clearances will be obtained or how surge-pool activation will compensate. A shortfall at clock start (Month 6 = 2027-04-08) is an entry-condition failure; do not proceed without documented recovery plan.
3. Before Month 5.5 (2027-03-23) threshold lock, provide evidence that the calibration exercise detected at least one substitution, one record falsification, and one vendor-refusal scenario with >70% inspector detection rate. If calibration detected any event type with <70% detection (proposed threshold for Stop consideration), explain why the detection gap is acceptable under Go criteria or justify the threshold adjustment. Do not lock thresholds on provisional figures without calibration validation.
4. At Month 6 (2027-04-08), when Phase One clock formally starts, produce a signed entry-condition certification memo from both co-chairs attesting that all 7 mandatory conditions are complete: bilateral instrument, appropriations, domestic authority, sites, inspectors, operators/vendors, and equipment schedule. If any condition is incomplete or partially satisfied (e.g., 'equipment schedule in draft,' 'inspectors subject to final clearance clearance'), the clock does not start; escalate to Month 9 (2027-07-08) backstop for double-key extend-or-stop decision. No partial starts are permitted.
5. During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08), track and report monthly the count of ledger divergences, divergence detection time, divergence resolution time, and number of divergences unresolved at 7 days. If any divergence exceeds 7 days unresolved, document the reason (technical fault, contested identity, co-chair disagreement) and whether automatic impaired-confidence status or suspension was triggered. A pattern of >2 divergences per site per month or >1 unresolved divergence per site suggests ledger unreliability; provide immediate mitigation or recommend site suspension.
6. At the final Go/Modify/Stop decision (Month 9.5 = 2027-07-23), provide the blind-challenge detection scorecard by event type (unreported arrivals, substitutions, record falsifications, delayed-access tests, disputed identities, vendor refusals, reluctant-operator scenarios), with true-positive count, false-negative count, false-positive count, and detection time distribution for each. State whether observed detection rates meet or exceed the locked thresholds (90% arrival, 85% substitution, 80% falsification, <5% false positives). If any event type falls short of its threshold, justify whether the mechanism still merits a Go decision or whether the deficiency warrants Modify or Stop.

## Summary

The Consortium governance framework establishes a bilateral US–China verification mechanism for frontier computing equipment changes at 4 matched datacenters over a 90-day Phase One test (Months 6–9 = 2027-04-08 to 2027-07-08). The framework emphasizes procedural rigor, double-key authority with mutual veto and no casting vote, bounded inspection zones with operator-run redaction, mirrored full-time national teams, a replicated tamper-evident ledger with <1-hour synchronization, fixed corroboration rules requiring ≥2 independent evidence layers for equipment identity, and sealed independent-examiner challenge exercises scoring detection against locked thresholds. Entry-condition gating defers the 90-day clock until all 7 mandatory conditions (bilateral instrument, appropriations, domestic authority, sites, inspectors, operators/vendors, equipment schedule) are certified by Month 6 (2027-04-08). Go/Modify/Stop decision is issued at Month 10 (2027-08-08) based on blind-challenge detection (90% unreported arrival, 85% substitution, 80% falsification), false-positive rates (<5%), reciprocal-access parity (±20%), unverifiable equipment (<5%), and zero material asymmetry or IP exposure. The design prioritizes auditability, reciprocity and measured risk acceptance over speed, reflecting low-trust bilateral context and exclusive focus on declared-equipment change verification at monitored sites.