**Primary domain:** Arms Control Verification

**Secondary domains:** Cybersecurity, International Law, Hardware Supply Chain Security

**Rationale:** Arms Control Verification best names a jointly governed bilateral inspectorate verifying declared equipment changes at matched sites with reciprocity and a Go/Modify/Stop decision. Hardware Supply Chain Security ties on score but covers only the identity-verification mechanism; other candidates are methods or constraints.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Arms Control Verification | 5 | 5 | outcome | Bilateral inspectorate verifying declared equipment changes at matched sites is a treaty-verification regime. |
| Hardware Supply Chain Security | 5 | 5 | outcome | Equipment identity, intake, chain of custody and tamper evidence are the core verification mechanism. |
| Cybersecurity | 4 | 4 | method | Tamper-evident ledger, attestation, evidence filtering and counterintelligence protect IP and evidence integrity. |
| Counterintelligence | 4 | 4 | constraint | Mirrored inspectorates must be shielded from espionage and sensitive technology exposure. |
| Applied Cryptography | 4 | 4 | method | Tamper-evident replicated ledger and validated attestation depend on cryptographic design. |
| Digital Forensics | 4 | 4 | method | Layered evidence, chain of custody and tamper-evident records underpin equipment identity verification. |
| Data Center Operations | 4 | 4 | stakeholder | Installation, maintenance and decommissioning at declared sites must proceed without disrupting active compute. |
| International Law | 4 | 3 | constraint | Bilateral instrument, domestic access authority, reciprocity and double-key governance require legal implementation. |
| Bilateral Diplomacy | 4 | 3 | constraint | Reciprocity, double-key governance and deadlock procedures require negotiated US–China diplomatic mechanisms. |