**Primary domain:** Arms Control Verification

**Secondary domains:** Hardware Supply Chain Security, Counterintelligence and Cybersecurity, Treaty Verification Law

**Rationale:** Arms Control Verification is the only outcome role and scores highest (5×5), matching the bilateral inspection-based verification mission and Go/Modify/Stop decision. Supply chain security, cryptography, red teaming, law and diplomacy are subordinate methods, constraints or stakeholders.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Arms Control Verification | 5 | 5 | outcome | Core mission is bilateral inspection-based verification of declared equipment changes with Go/Modify/Stop decision. |
| Hardware Supply Chain Security | 4 | 4 | method | Equipment identity, attestation, custody chain, and vendor-bound evidence underpin intake, maintenance, and exit protocols. |
| Counterintelligence and Cybersecurity | 4 | 4 | constraint | Protecting IP, topology and weights while running tamper-evident ledgers and information barriers. |
| Treaty Verification Law | 4 | 4 | constraint | Bilateral instrument, reciprocal access authority, double-key governance and deadlock procedures require treaty and international law expertise. |
| Applied Cryptography | 4 | 4 | method | Tamper-evident replicated ledger and validated cryptographic attestation underpin layered evidence and synchronization. |
| Data Center Operations | 4 | 4 | stakeholder | Intake, installation, maintenance and decommissioning of equipment occur within operators' datacenters without disrupting production. |
| Red Team Testing | 4 | 4 | method | Blind live challenge exercises and independent testing determine the Go/Modify/Stop decision. |
| International Security Diplomacy | 4 | 3 | stakeholder | Bilateral US–China governance, reciprocity, double-key authorization and deadlock procedures require diplomatic negotiation expertise. |
| Public Financial Management | 3 | 3 | constraint | Appropriations governance, 50/50 funding, envelope mapping and fiscal accountability demand public budgeting discipline. |