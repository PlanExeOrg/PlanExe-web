**Primary domain:** Arms Control Verification

**Secondary domains:** Hardware Supply Chain Security, Treaty Law, Counterintelligence and Information Security

**Rationale:** Arms Control Verification is the outcome discipline with the highest importance × specificity (25). Its mission is bilateral verification of declared equipment changes under mutual distrust. Bilateral Program Management is also an outcome but scores lower (20) and is a delivery vehicle. Treaty Law, Counterintelligence and Information Security, and the method candidates are subordinate.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Arms Control Verification | 5 | 5 | outcome | Core mission is bilateral inspection and verification of declared equipment changes under mutual distrust. |
| Counterintelligence and Information Security | 5 | 4 | constraint | Protecting sensitive IP, security architecture and inspector conduct under mutual distrust is a blocking requirement. |
| Distributed Ledger Engineering | 4 | 5 | method | Replicated tamper-evident ledger with independent national copies and bounded synchronization is a core mechanism. |
| Bilateral Program Management | 5 | 4 | outcome | Owns delivery of the 90-day test, workstreams, staffing, and Go/Modify/Stop decision. |
| Hardware Supply Chain Security | 4 | 4 | method | Intake, identity verification, custody, vendor binding and attestation of computing equipment. |
| Treaty Law | 4 | 4 | constraint | Bilateral instrument, double-key governance, domestic access authority and reciprocity require legal structuring. |
| Red Team Testing | 4 | 4 | method | Blind live challenge exercises determine detection credibility and drive the Go/Modify/Stop decision. |
| Public Financial Management | 4 | 4 | constraint | Governs the 50/50 USD 5 billion appropriations, envelopes, contingency, and fiscal accountability. |
| Datacenter Operations | 4 | 4 | method | Staging, installation, maintenance, and decommissioning of equipment at declared sites without disrupting production. |