
## Risk 1 - Regulatory & Permitting
Mandatory entry conditions (signed bilateral instrument, appropriations, domestic access authority, site approval, inspector vetting, vendor participation, equipment schedule) sit outside the 90-day clock. Delays in any condition block Phase One start indefinitely. Most vulnerable are inspector vetting (counterintelligence clearances on both sides), domestic legislation enacting legal authority to compel operator and vendor cooperation, and approval of the confidential covered-equipment schedule. Neither government controls the other's administrative pace.

**Impact:** Phase One clock not starting by Month 6–9 (2027-04-08 to 2027-07-08), or starting with partial entry conditions that degrade verification validity. If domestic authority legislation stalls in either parliament, the test cannot start. If inspector vetting extends beyond Month 3–4 (2027-01-08 to 2027-02-08), competing security priorities may deprioritize clearances. Estimated delay: 4–8 months per unresolved condition; total risk: 50% probability of Month 6+ delay in starting the formal 90-day test.

**Likelihood:** High

**Severity:** High

**Action:** Establish a bilateral entry-conditions steering committee with both co-chairs meeting weekly starting Month 0 (2026-10-08). Decompose each condition (signed instrument, appropriations, domestic authority, sites, inspectors, vendors, schedule) into weekly milestones with explicit owners. Identify critical-path blockers (e.g., parliament session dates, security-clearance agency backlogs) and escalate to political leadership Month 1 (2026-11-08). Create a written fallback for any single-country delay: allow that country to begin testing on its own side with foreign observers while the other country completes entry conditions, or use a pre-clock dry-run gate on non-covered equipment to surface authority gaps and buy negotiating time.

## Risk 2 - Operational
Ledger divergence: the two national replicated ledgers may record events differently, disagree on timing, or develop conflicting identity claims for the same equipment. Causes include network latency, local time-sync failures, competing equipment-identity evidence, inspector disputes over witnessed events, and deliberate operator falsification. If divergence persists beyond a bounded reconciliation window, the plan defines automatic impaired-confidence or suspension triggers, but the 90-day test window is tight for forensic recovery.

**Impact:** Unresolved ledger divergence lasting >7 days (estimate) escalates to automatic site suspension or Stop decision. If a critical equipment-identity dispute (equipment X is two different things in each national ledger) cannot be resolved within 3–5 days, a site may fail Phase One even if the mechanism is working. Estimated impact: 20–30% probability of at least one ledger divergence event per site; 30–50% of divergences take >5 days to reconcile if both governments contest the evidence. One unresolved divergence per 90-day test per site is plausible.

**Likelihood:** High

**Severity:** High

**Action:** Implement shift-boundary cross-signing by mirrored national inspectors at handover to catch divergences within hours, not days. Establish a pre-authorized forensic team (3–5 technical staff plus counterpart) with authority to issue binding evidential findings on identity disputes within 48 hours, feeding into the escalation clock. Maintain a neutral third-party escrow ledger record under strict double-key control, used only to arbitrate which national copy diverged, with access logs audited. Pre-agree on a divergence-resolution hierarchy: cryptographic attestation > physical inspection + chain of custody > maintenance records > third-party logs. Run a Month 1–2 (2026-11-08 to 2026-12-08) ledger-sync stress test using non-covered equipment to validate latency bounds and forensic response before the formal clock starts.

## Risk 3 - Technical
Attestation trust root provenance: cryptographic identity attestation is one evidence layer among several, but if joint key ceremonies are compromised, delayed or rejected by either government, or if vendor-specific key material is unavailable, the entire attestation layer collapses. A joint ceremony facility becomes a single point of failure and a high-value espionage target. Delayed or refused vendor cooperation (e.g., a manufacturer withholds device-identity credentials) forces fallback to independent examiners or clean-room testing, which may lack vendor-specific expertise.

**Impact:** Loss of cryptographic attestation evidence layer for 5–15% of deployed equipment (estimate); reduction in equipment-identity confidence score from 90%+ to 60–70%. If joint ceremony cannot be scheduled before Month 2 (2026-12-08), ceremony delays feed back into the reciprocity gate and defer the clock. If a major manufacturer (e.g., NVIDIA, AMD alternative) withholds attestation hooks, all chips from that vendor become dependent on physical inspection + third-party logs + clean-room testing, lengthening verification time by 2–4 weeks per batch and increasing dispute risk.

**Likelihood:** Medium

**Severity:** High

**Action:** Pre-qualify a shared neutral location and ceremony procedures (e.g., in a third country or under UN auspices) by Month 0.5 (2026-10-23), with both governments signing off on physical security, logging and audit controls. If either government objects to a joint facility, immediately trigger a two-independent-national-roots contingency in which each government maintains its own attestation root and cross-validates the other's certificates, accepting doubled infrastructure cost. Identify the top 5–10 manufacturers of covered equipment and pre-negotiate attestation-cooperation agreements with each, documenting the fallback route (vendor-supervised testing, accredited examiners, clean-room access) if they refuse full cooperation. Establish a pre-qualified independent-examiner pool (3–5 labs per country) with access agreements signed before Month 1 (2026-11-08), so vendor refusal can be bypassed without renegotiating individual refusals.

## Risk 4 - Financial
Budget appropriations and spending pace misalignment: each country controls its USD 2.5 billion share domestically, but domestic operators and vendors are paid from the national budget share, creating a split-currency and governance complexity. If China's domestic budget execution is slower, operator compensation or vendor participation agreements may not materialize on time, delaying site readiness. Contingency budget (USD 500 million) is allocated but mechanisms for activating surge capacity across both countries are not specified.

**Impact:** Site preparation delays of 2–4 weeks if operator compensation budgets are not cleared by Month 2 (2026-12-08). A 10–15% budget variance in either country's domestic spending (estimated) could reduce personnel deployment, equipment staging preparation, or third-party vendor access agreements. If contingency funds cannot be mobilized by both countries on short notice (e.g., a ledger facility failure or exercise escalation needs emergency repairs), critical Path items could stall for 1–2 weeks. Estimated impact: 25% probability of a 2–4 week site-readiness delay due to budget execution; 15% probability of contingency-activation friction.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish a bilateral budget-execution working group meeting bi-weekly from Month 0 (2026-10-08), with spending plans from each country broken into monthly milestones. Create a contractual obligation (via bilateral instrument) that each government funds its approved budget within 45 days of fiscal-year start (Month 0 = 2026-10-08 for US, aligned timing for China), with automatic penalties or rephasing if delays occur. Pre-authorize a joint contingency-access committee with authority to release up to USD 50 million (USD 25 million per side) on a joint signature within 5 business days for emergency repairs, ledger restoration, or exercise escalation. Separate operator compensation (paid to national entities by each government) from program overhead, and have both governments audit their own spending monthly.

## Risk 5 - Technical
Vendor refusal cascade: if one or more critical manufacturers (e.g., semiconductor suppliers, cooling-system vendors, data-center infrastructure providers) refuse to cooperate with evidence-gathering, equipment-identity verification, or maintenance reporting, the fallback routes (vendor-supervised testing, independent examiners, clean-room procedures, validated attestation) may be unable to produce sufficient evidence. Material unverifiable equipment could accumulate and fail a site during Phase One.

**Impact:** One or two major vendor refusals (estimated 15–25% probability per site over 90 days) could classify 5–15% of deployed equipment as unverifiable (estimate). If a site accumulates >10% unverifiable equipment, the plan permits a site to fail Phase One. Estimated cascade risk: 20–30% probability that at least one site faces a material vendor-refusal outcome during the test, potentially failing Phase One for that site even if the mechanism otherwise works.

**Likelihood:** Medium

**Severity:** High

**Action:** Pre-qualify and bind critical vendors via legal agreements signed before Month 1 (2026-11-08), requiring participation in equipment-identity verification, maintenance reporting, and evidence-preservation under penalty of non-renewal of service contracts at the participating site. Establish a vendor-escalation protocol: (1) direct request for cooperation; (2) operator mediation; (3) independent examiner or clean-room testing; (4) validated attestation fallback; (5) unverifiable classification. Pre-stage independent examiners and clean-room facilities for at least the top 3 vendors per equipment class before the clock starts. If a vendor refuses at all stages, that equipment must be classified as unverifiable within 10 days and reported to the bilateral adjudication unit. Document every refusal and its reason in the ledger under both national copies.

## Risk 6 - Operational
Inspector conduct and espionage risk: full-time mirrored inspector teams at each site create a counterintelligence exposure. Inspectors from one country may attempt to gather intelligence on the other country's equipment, operational security, or supply-chain dependencies beyond the declared scope. Conversely, inspectors may be coerced by their own government or service into unauthorized collection. Vetting and conduct oversight reduce but do not eliminate the risk.

**Impact:** A confirmed or credibly alleged espionage incident could cause one government to withdraw consent or expel counterpart inspectors, collapsing reciprocal access and failing the test. Estimated probability: 5–10% of at least one minor conduct incident (suspicious activity, undisclosed note-taking, access to off-limits areas) within 90 days; 1–3% probability of a major incident that triggers consent withdrawal. Reputational impact on the bilateral relationship extends beyond Phase One.

**Likelihood:** Medium

**Severity:** High

**Action:** Establish a joint bilateral inspector-conduct committee with equal national co-chairs, empowered to investigate allegations, discipline or replace inspectors, and veto any inspector from the counterpart. Implement continuous access-log audit and counterintelligence monitoring of inspector activities, with logs shared between governments in redacted form (focused on access patterns, not details). Pair every inspector with a host-country observer for access to sensitive areas (e.g., staging zones, ledger facilities), providing transparency and reducing temptation. Rotate inspectors across paired sites on a quarterly basis to prevent entrenchment and operator familiarity. Establish a clear conduct code signed by every inspector at induction, with zero-tolerance rules for unauthorized area access, recording, or collection. Run surprise spot audits of inspector notes and device access logs monthly.

## Risk 7 - Operational
Inspection zone boundary creep and IP exposure: the plan requires narrow, marked inspection zones limited to staging, spare inventory, and maintenance areas. Evidence must be filtered (operator-run redaction audited by inspectors) before leaving the site. If inspectors pressure to expand zones, or if operators refuse to redact, the boundary can blur, exposing workloads, model weights, source code or network topology that one or both governments wish to protect.

**Impact:** Exposure of sensitive IP or counterintelligence data could trigger consent withdrawal or legal disputes over the bilateral instrument. A single significant exposure incident (estimated 10% probability within 90 days) could cause one government to halt Phase One. Zone-boundary disputes during maintenance or third-party-access events could delay inspections by 1–3 days and escalate to co-chair mediation.

**Likelihood:** Medium

**Severity:** High

**Action:** Define the boundary as a physically marked perimeter with access-control gates logged on both national ledgers. Conduct a pre-clock boundary audit with both governments' security teams and operators present, photographing and documenting exact limits. Require operator-run evidence redaction for all departing data, with inspectors auditing the redaction step (spot-check sample review, not pre-approval). Establish an escalation protocol: minor boundary infractions trigger a written warning and re-training; repeated or serious infractions (e.g., unauthorized photography beyond the zone) trigger a co-chair review and potential inspector removal. Use sealed capture instruments in the zones (e.g., camera traps recording only equipment identifiers and movement, not topology or workloads) so inspectors review filtered metadata rather than entering live areas unnecessarily.

## Risk 8 - Operational
Matched site selection deadlock: identifying a small set of comparable US and Chinese datacenters that are representative, willing to participate, and acceptable to both governments is a non-trivial task sitting outside the 90-day clock. If one country nominates sites the other views as unrepresentative or too easy, mutual vetoes can delay site agreement by weeks. Conversely, if selection is too structured or rushed, chosen sites may be unrepresentative of real operations.

**Impact:** Delay in site approval extending the entry-condition gate by 4–8 weeks (estimate). Disagreement over site difficulty, parity, and vendor mix could lower the credibility of Phase One results; a Go decision from unrepresentative sites may not transfer to broader future operations. Estimated risk: 30% probability of site-selection friction extending gate by >4 weeks.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Pre-agree on site-selection criteria by Month 0 (2026-10-08): equipment-change frequency (within 20% parity), vendor mix diversity, staging and maintenance area capacity, and operator willingness to participate. Establish a structured nomination process: each country nominates 3–5 candidates; a joint technical committee evaluates them against agreed criteria without veto power; a sealed random draw from the jointly vetted shortlist selects the final sites, preventing either side from steering toward easy targets. Include at least one deliberately hard site on each side (higher vendor dependencies, more complex maintenance) explicitly to test the mechanism under stress conditions. Complete site selection by Month 1.5 (2026-11-23), with bilateral site-selection ratification signed by both co-chairs.

## Risk 9 - Operational
Mirrored shift roster staffing and vetting delays: the plan requires full-time mirrored national inspectors covering 24/7 shifts, plus technical, legal, counterintelligence, and adjudication personnel. Counterintelligence vetting of ~100–200 personnel per side is a slow process. Security clearances, background checks, and conduct-rule sign-offs can delay hiring by 8–12 weeks (estimate). If rosters are incomplete at clock start, coverage gaps increase blind spots and escalation bottlenecks.

**Impact:** Incomplete rosters at clock start: estimated 15–25% of planned positions unfilled. Coverage gaps during nights, weekends or leave periods could miss equipment changes or delay event response by 4–8 hours. Estimated impact: 10–15% of events in the first Month 1–2 (2026-11-08 to 2026-12-08) may lack real-time coverage, increasing false negatives. Vetting delays of 8–12 weeks (estimate) could defer clock start if entry conditions include 'all inspectors approved.'

**Likelihood:** High

**Severity:** Medium

**Action:** Initiate counterintelligence vetting of candidate inspectors by Month -2 (8 weeks before planned clock start), using pre-agreed vetting standards and expedited timelines. Identify and vet a 20–30% surge pool above planned roster strength to cover leave, illness and turnover. Conduct rapid-induction training on ledger protocols, evidence-handling and zone rules by Month 0.5 (2026-10-23), so inspectors can deploy to sites by Month 1.5 (2026-11-23) at the latest. Allow Phase One clock to start with 80% roster strength if critical positions are filled; defer low-priority roles (e.g., administrative, some audit) to Month 1 (2026-11-08). Pre-identify and pre-vet a rapid-replacement pool for any inspector removed during the test.

## Risk 10 - Operational
Challenge exercise coordination and production disruption: live exercises (unreported arrivals, substituted equipment, record falsification, vendor refusal, reluctant operators) are meant to occur in staging, spare-inventory, maintenance and expansion areas without interrupting live computation. However, exercises require coordinated operator, inspector, vendor and red-team participation, scheduled around maintenance windows and equipment cycles. Tight coordination can delay exercises, or an exercise can inadvertently intrude on active-computation areas, causing outages.

**Impact:** Exercises delayed or cancelled due to production-schedule conflicts: estimated 20–30% of planned exercises (5–10 per site over 90 days) may be postponed. If an exercise disrupts live computation, the operator may object and refuse future cooperation, or demand compensation. Estimated impact: 1–2 unplanned production incidents per site over 90 days; USD 100,000–500,000 per incident in operational-recovery costs (not in budget). Missed or compromised exercises reduce blind-challenge evidence quality and could weaken the Go decision.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish a quarterly exercise schedule at Month 0.5 (2026-10-23), coordinating with each operator's maintenance windows, equipment-procurement cycles and production calendars. Reserve dedicated staging and spare-inventory areas that are segregated from live computation and available exclusively for exercises. Run a pre-test exercise in Month 1 (2026-11-08) at each site to validate coordination procedures and identify conflicts before the formal clock. Establish an exercise-dispute resolution protocol: if an exercise causes unexpected outages, the bilateral adjudication unit investigates whether it was conducted according to plan, and compensation is paid from contingency budget if fault is shared. Cap exercises to no more than 2 per month per site to balance testing frequency against disruption risk.

## Risk 11 - Operational
Maintenance and third-party-access scheduling abuse: the plan requires advance notice of maintenance, repair and vendor visits, with inspectors present at start and end of windows. However, operators have an incentive to classify urgent maintenance as emergencies to bypass scheduling rules, or to defer non-urgent work until after the test to avoid scrutiny. Emergency-access abuse controls are defined but may be weak in practice.

**Impact:** Repeated emergency-access claims could create 5–10 unscheduled, unsupervised maintenance windows per site during the 90-day test (estimate), some hiding real equipment changes. If emergency-access audit trails are weak, distinguishing true emergencies from scheduled-work misclassifications becomes difficult, adding 2–3 hours per incident to investigation and escalation. Estimated impact: 20–30% of claimed emergencies require escalation; 5–10% are ruled abusive and trigger discrepancy escalation clocks.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Define emergency maintenance as repairs needed to restore failed systems within 4 hours, requiring operator notification to an on-site inspector and continuous recording (video, access logs) during the unscheduled window. Establish a post-event audit requiring operators to file a detailed report within 24 hours on what failed, why, and what was repaired, with inspectors reviewing maintenance logs against the reported damage. Set a per-site cap: if any site claims >3 emergencies per month, an independent technical auditor reviews the claims; if >50% are ruled non-emergency, the operator faces escalation and potential sanctions. Require operators to pre-stage spare parts and maintenance personnel outside emergency windows to reduce claims for true emergencies. Run monthly reconciliation audits of scheduled vs. emergency maintenance to detect abuse patterns.

## Risk 12 - Operational
Exit disposition verification gaps: the plan defines five exit dispositions (witnessed destruction, verified disablement, transfer to another site, documented release beyond monitored system, unresolved). Inspectors may not have access to third-party destruction or recycling facilities, making full end-to-end witnessing impractical. If dispositions are recorded as 'documented release' or 'unresolved,' the ledger loses visibility of where equipment goes, creating a gap where re-entry or diversion could occur undetected.

**Impact:** If 20–30% of departures are recorded as 'release beyond monitored system' (estimate), and equipment secretly re-enters use unseen, detection depends entirely on later identity verification of arrivals. Blind-challenge exercises involving equipment re-entry or substitution may fail if disposition data is weak. Estimated impact: 5–10% false-negative rate on re-entry detection if exit witnessing is weak; one undetected re-entry per site over 90 days is plausible.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish a tiered exit-witnessing standard: Tier 1 (destruction/disablement) requires inspector presence at the destruction facility or independent certification from an accredited recycler; Tier 2 (transfer to another site) requires witnessed handoff and ledger entry at receiving site; Tier 3 (documented release) accepts operator sign-off with supporting vendor receipts; Tier 4 (unresolved) is used only when no evidence is available, flagged for auditor review. Require operators to bind recyclers and disposal vendors to reporting agreements and evidence preservation, as for maintenance vendors. Pre-qualify a pool of accredited recyclers in each geography (estimate 2–3 per country) with bilateral audit rights. For a random sample of Tier 3 releases (20–30% per month), conduct post-release verification calls to the receiving party to confirm receipt. Run blind-challenge exercises where equipment is reportedly destroyed but secretly re-enters the site, testing detection sensitivity to weak exit records.

## Risk 13 - Operational
Discrepancy escalation clock and deadlock: the plan defines fixed time limits for resolving discrepancies (record mismatches, disputed identity, delayed access, vendor refusal outcomes). Automatic suspension fires when clocks expire. However, in a 90-day test, fact-finding can take longer than allocated deadlines, and both countries may contest what counts as resolution, leading to escalation grid-lock.

**Impact:** Automatic site suspension triggered by expired discrepancy clocks (estimated 3–5 unresolved items per site over 90 days), even if the mechanism is functioning. Estimated probability: 15–25% of discrepancies exceed their fixed deadline, cascading to impaired-confidence status or suspension. One site suspension per test phase is plausible. False suspensions from administrative lag damage the credibility of Phase One results.

**Likelihood:** Medium

**Severity:** High

**Action:** Define three clock tiers: Tier 1 (24 hours) for minor record discrepancies (serial-number typos, timestamp mismatches); Tier 2 (72 hours) for medium-severity items (delayed maintenance access, incomplete evidence); Tier 3 (14 days) for major issues (disputed identity, vendor refusal, concerning events). Allow the bilateral adjudication unit to extend any clock once by up to 50% (e.g., 24h → 36h, 72h → 108h) with written reasons, but not twice. Create an independent technical referee panel (3–5 senior specialists per country) that can issue non-binding evidential opinions within 48 hours, giving co-chairs a shared factual basis for closing discrepancies before clocks expire. Establish a protocol: if a clock expires and no resolution is agreed, the matter escalates to co-chairs for double-key decision; unilateral escalation to automatic suspension is not permitted without written co-chair sign-off.

## Risk 14 - Operational
Evidence layer weighting disputes: the plan specifies that no single evidence source is decisive; identity requires corroboration across multiple layers (attestation, physical inspection, records, witnesses, infrastructure changes). However, the fixed corroboration rule (e.g., 'identity confirmed when 3 of 5 independent layers agree') may be too rigid or too loose. If an equipment-identity dispute arises, both governments may dispute the weight assigned to different layers, or claim that some layers were tainted by the other side.

**Impact:** Contested identity findings (estimated 5–10 per site over 90 days) delay closure by 3–5 days while adjudication units debate evidence weights. One major identity dispute per site that requires co-chair resolution is plausible. Disputed findings weaken the credibility of blind-challenge results if both governments contest the standards used to score them.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Pre-define the corroboration rule and document the rationale before the clock starts, signed by both co-chairs. Example: 'Equipment identity is confirmed if (a) cryptographic attestation AND (b) physical inspection + serial-number match agree, OR (c) if attestation is unavailable, physical inspection + two independent records (maintenance log, customs receipt, vendor certificate) agree.' Every identity finding must cite the specific layers used and their provenance. If a disputed identity finding arises, the bilateral adjudication unit applies the pre-agreed rule; co-chairs may not override the rule without a documented protocol change recorded in the ledger. Run a pre-test identity-verification exercise at Month 1.5 (2026-11-23) using non-covered equipment, comparing how the two national teams apply the corroboration rule and resolving any divergence before formal clocks start.

## Risk 15 - Operational
Provisional threshold mis-calibration: the plan requires that decision thresholds for Go/Modify/Stop be fixed and justified before the first challenge exercise. Most figures start as provisional (e.g., 'false-negative rate target: 5–10%, TBD'). If provisional thresholds turn out to be mis-set based on early blind exercises, they cannot be changed without a documented protocol change; this can force a Modify outcome that reflects the yardstick rather than real mechanism performance.

**Impact:** Early blind exercises reveal that the provisional false-negative threshold (e.g., 5–10%) is unrealistic; real performance is 12–15%, or alternatively, the mechanism performs at 2–3%, making the original threshold overly stringent. A Go decision based on a mis-set high threshold may not reflect real capability; a Modify decision may be forced simply to recalibrate the metrics, not to fix mechanism defects. Estimated impact: 30–50% probability that at least one threshold will need adjustment based on early exercise data; 15–25% probability that this forces a Modify outcome rather than Go.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Conduct a pre-test calibration exercise on non-covered equipment in Month 1–2 (2026-11-08 to 2026-12-08), outside the formal 90-day clock. Use this exercise to validate provisional thresholds and adjust them based on observed performance before the blind challenges that feed the final decision. Document every provisional figure and its source (expert opinion, historical analogy, theoretical model). Before locking thresholds, conduct a sensitivity analysis: if the false-negative rate is actually 2x higher than the provisional target, does the mechanism still meet the Go criteria, or does it shift to Modify? If a threshold needs adjustment after the calibration exercise, do so via a documented protocol change signed by both co-chairs before the formal clock starts. Classify the post-calibration thresholds as 'validated' rather than provisional in the ledger.

## Risk 16 - Operational
Blind-challenge realism and gaming risk: challenge exercises are meant to be blind to inspectors, but both governments can attempt to game the exercises. A government might design challenges biased toward detecting its counterpart's evasion methods while concealing its own; conversely, red teams might design exercises so hard that the mechanism cannot pass, discrediting the other side.

**Impact:** Exercise results appear credible but are biased by national gaming. Blind-challenge detection rates may be artificially high (if easier challenges are run against the counterpart) or artificially low (if deliberately impossible tests are designed). Go/Modify/Stop decision based on biased evidence lacks legitimacy. Estimated impact: 20–30% probability that at least one side perceives exercise bias; 10–15% probability that this triggers a formal dispute over exercise fairness, delaying the final decision by 1–2 weeks.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Vest all exercise design, scheduling and scoring in an independent testing unit staffed by neutral technical experts from neither country, or from a third country. Require scenario peer review: before each exercise is run, both red teams review the scenario against a fairness rubric and certify that it is realistic, non-biased and comparable to exercises run against their own inspectors. Document every objection and its resolution. Randomize exercise sequence and timing using a sealed double-key schedule so neither government knows in advance when its inspectors will be tested. Score results using a pre-agreed rubric (e.g., 'detection = equipment correctly identified as unauthorized within 24 hours'), with both national audit teams independently scoring each result; if scores diverge, a neutral third party breaks the tie.

## Risk 17 - Operational
Asymmetric access and reciprocity breakdown: the bilateral mechanism is founded on reciprocal access: each government must grant the other's inspectors equivalent access, zone coverage, evidence, and escalation rights. However, one country may claim national-security grounds to restrict counterpart access (e.g., deny access to certain zones due to proximity to classified infrastructure), or may restrict evidence-sharing, creating asymmetric conditions.

**Impact:** If one country grants narrower access than the other, reciprocal-access parity breaks down, and the counterpart may object to the Go decision or withdraw consent. One asymmetry incident per test is plausible (estimated 10–20% probability). Estimated impact: 1–3 week delay to resolve access disputes; 5–10% probability of consent withdrawal if asymmetry cannot be resolved.

**Likelihood:** Medium

**Severity:** High

**Action:** Define reciprocal access as a core entry condition: before the clock starts, both governments certify that each country's inspectors have been granted equivalent zone access, evidence-sharing rights, and escalation authority. During the test, measure reciprocal-access parity monthly: compare the number of inspectors deployed per country, hours of zone access per inspector, events each side has documented as witnessed, and escalation items raised by each side. If parity metrics diverge by >20% (estimate), trigger a bilateral review within 5 days to identify the gap and restore parity. Establish an automatic parity-restoration mechanism: if one side restricts access citing national security, the other side has the right to equivalent restriction on its side, maintaining symmetry. Record every access restriction in the ledger with justification, so any asymmetry is visible to auditors and the final decision panel.

## Risk 18 - Operational
Operator withdrawal or non-compliance: participating operators must commit to binding vendors, allowing inspectors on-site, maintaining the ledger, enabling exercises, and accepting evidence redaction. If an operator withdraws consent or refuses a specific protocol step during Phase One, the test may be disrupted.

**Impact:** Operator refusal of one protocol element (e.g., 'we will not allow inspectors in the maintenance bay') requires escalation and potentially site suspension. Operator withdrawal of consent (estimated 5–10% probability per site over 90 days due to operational friction or political pressure) terminates testing at that site. Estimated impact: 1 site operational disruption or early withdrawal per test phase is plausible; mitigation requires alternate site availability or protocol modifications.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Lock operator participation via legally binding bilateral agreements signed before the clock starts, specifying binding of vendors, inspector access, maintenance procedures and exercise participation as non-negotiable terms. Include penalty clauses (e.g., reduced future contracting, loss of equipment certification) for mid-test withdrawal or non-compliance. Establish a rapid operator-dispute resolution channel: if an operator objects to a protocol step, convene a joint bilateral operator-engagement team within 48 hours to understand the concern and propose workarounds (e.g., alternative scheduling, additional escorts, expanded redaction). Pre-identify a standby alternate operator at a nearby site who has agreed to rapid deployment if primary operator withdraws. Monitor operator sentiment monthly via confidential interviews with operations leadership; escalate concerns to government co-chairs before friction reaches withdrawal risk.

## Risk 19 - Regulatory & Permitting
Bilateral instrument ratification delays: the plan depends on both governments signing a bilateral instrument before entry conditions are certified. Domestic parliamentary or administrative approval of the instrument may be delayed by legal reviews, amendments, or political objections.

**Impact:** Instrument ratification delayed by 4–8 weeks (estimate) extends entry-condition timeline and defers clock start. Disputes over instrument language (e.g., dispute-resolution procedures, suspension triggers, inspector rights) may require renegotiation. Estimated impact: 20–30% probability of ratification extending beyond Month 2 (2026-12-08).

**Likelihood:** Medium

**Severity:** Medium

**Action:** Complete draft bilateral instrument by Month 0 (2026-10-08) and begin simultaneous domestic approval processes in both countries immediately. Identify all domestic approval authorities (legislature, executive, security agencies) and map their decision timelines. Pre-socialize controversial terms (automatic suspension, inspector immunity, evidence-sharing scope) with key stakeholders in Month 0 (2026-10-08) to avoid late surprises. Establish a negotiation protocol: if either government objects to specific language, trigger a structured resolution process within 2 weeks, with escalation to co-chairs if agreement cannot be reached. Consider provisional entry on non-controversial terms (site selection, operator binding) while final ratification is completing, if the bilateral instrument permits it.

## Risk 20 - Operational
Ledger synchronization latency and technology failure: the replicated ledger requires bounded synchronization between national copies (target: <1 hour, TBD). Network outages, system crashes, or cybersecurity incidents could delay synchronization, creating temporary divergence that escalates to impaired-confidence status.

**Impact:** Network outages or system failures causing >4-hour ledger divergence (estimated 5–10% probability per site over 90 days) trigger automatic escalation. Estimated impact: 2–4 ledger-sync escalation events per site over 90 days; each requiring 1–2 hours of bilateral technical troubleshooting and forensic review. A major ledger-system failure could require recovery from backup, delaying reconciliation by 8–24 hours and triggering automatic suspension if recovery takes >7 days.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Design the ledger system for high availability: duplicate facilities in each country connected by redundant, physically separate secure communications links. Test failover procedures monthly to ensure recovery time meets <4-hour sync-divergence tolerance. Implement continuous integrity checking: each national ledger runs cryptographic verification that the counterpart's copy has not diverged beyond bounds; divergences are logged and escalated automatically within 2 hours. Maintain secure offline backups that can restore the ledger to any point in time within 6 hours. Establish a bilateral ledger-technology working group that meets monthly to review system performance, plan upgrades, and address technical issues before they become crises. Conduct a full ledger-system resilience test in Month 0.5 (2026-10-23), simulating network outages, system crashes and recovery scenarios.

## Risk 21 - Operational
Equipment identity falsification or substitution undetected in exercises: challenge exercises are designed to test whether inspectors can detect unreported arrivals, substituted equipment, or record falsification. However, if the operator or a sophisticated adversary can defeat the evidence layers, undetected substitutions become possible, and exercises may provide false confidence.

**Impact:** A sophisticated substitution (e.g., identical equipment with modified internals, or a substitute with altered identifiers) goes undetected in blind exercises, providing false evidence of mechanism effectiveness. Estimated impact: 5–10% probability of one undetected substitution per site in blind exercises (estimate); if discovered during audits, it undermines the credibility of the Go decision. One major undetected-substitution discovery per test phase is plausible, potentially forcing a Modify or Stop outcome.

**Likelihood:** Medium

**Severity:** High

**Action:** Design challenge exercises to include deliberately sophisticated scenarios: internal modification with identical externals, altered serial numbers or attestation credentials, substitution during maintenance or third-party-access windows. Require independent technical experts to validate that exercises are capable of detecting such sophisticated attacks, and adjust evidence layers or detection procedures if not. Use red-team adversarial testing to probe for gaps in the detection logic. Implement cryptographic hardware-security modules or tamper-evidence seals on critical equipment to make substitution more detectable. Conduct a pre-test sophistication assessment at Month 1.5 (2026-11-23): run exercises where both governments are aware of the test scenario and the adversary strategy, then compare detection effectiveness to blind exercises; large gaps suggest the mechanism is vulnerable to sophisticated evasion.

## Risk 22 - Technical
Attestation and cryptography vulnerabilities: the cryptographic layers (attestation, ledger integrity, key ceremony) may be vulnerable to attack, delay or compromise. Cryptographic root compromise could undermine the entire identity-verification foundation.

**Impact:** Discovery of a cryptographic weakness in attestation methods (estimated 5% probability) requires rapid key rotation and re-attestation of affected equipment, delaying Phase One by 1–2 weeks. A key ceremony failure or compromise could invalidate all attestation evidence and require fallback to physical inspection and records, increasing verification latency by 3–5 days per equipment batch.

**Likelihood:** Low

**Severity:** High

**Action:** Subject the cryptographic design to independent third-party assessment by a reputable cryptographic audit firm before Month 1 (2026-11-08). Include a pre-defined rapid-response protocol for key compromise: immediate key rotation, re-signing of all attestation records, and forensic investigation of which equipment was signed with compromised keys. Maintain offline cryptographic root backups and rehearse key-recovery procedures quarterly. Use cryptographic agility in the design so that hash algorithms, key sizes or signing methods can be upgraded without wholesale system redesign if vulnerabilities emerge.

## Risk 23 - Operational
Information asymmetry and claim disputes: if one government claims the other has violated a protocol (e.g., unauthorized zone access, espionage, falsified records), and the other denies it, resolution depends on evidence credibility and both governments trusting the adjudication process. Without independent verification, disputes can become intractable.

**Impact:** One serious allegation of protocol violation (estimated 5–10% probability per test) triggers bilateral dispute escalation. If both governments dispute the facts, adjudication by neutral referees becomes necessary but may not be trusted by one side. Estimated impact: 1–2 weeks to resolve a serious dispute; 10–15% probability that one side rejects the adjudication finding and escalates to political level.

**Likelihood:** Medium

**Severity:** High

**Action:** Pre-agree on evidence standards for adjudication: ledger entries, timestamped witness statements, video recordings, cryptographic signatures. Establish an independent adjudication panel (3–5 senior technical or legal figures from neutral countries or international organizations) that reviews disputed claims using the pre-agreed standards and issues binding findings. Allow limited appeal rights (e.g., one appeal per government per Phase One), but make clear that repeated disputes trigger automatic escalation to co-chairs for political resolution. Document the adjudication process and outcomes in the ledger so both governments have a shared record.

## Risk 24 - Strategic
Geopolitical escalation or political will withdrawal: the underlying bilateral relationship between the US and China could deteriorate during Phase One, causing one or both governments to withdraw support or reinterpret the bilateral instrument in hostile ways. Political will for the project could wane due to competing priorities or electoral cycles.

**Impact:** Political pressure from either government could lead to inspector removal, consent withdrawal, or reinterpretation of the bilateral instrument that collapses the mechanism. Estimated impact: 15–25% probability of a significant political incident (trade tensions, military provocations) during the 90-day test that strains the bilateral relationship and raises risk of Phase One interruption.

**Likelihood:** Medium

**Severity:** High

**Action:** Insulate the Phase One test from routine political friction by securing high-level political commitment (presidential or prime-ministerial level) at project launch. Establish a bilateral political steering committee of senior government officials who meet quarterly to reinforce commitment and resolve any political-level disputes before they impact operations. Include escape clauses in the bilateral instrument that allow Phase One to pause (but not terminate) if international crises warrant, so short-term political friction does not destroy the entire mechanism. Brief elected officials and media on the project's strategic importance and the mutual benefits of verification, building sustained political support. If political support wanes, identify alternative implementation models (e.g., extend Phase One, reduce site count) that preserve core testing while reducing operational burden.

## Risk summary
The Consortium is a novel, high-stakes US–China bilateral verification mechanism for frontier computing equipment at matched datacenters. The 90-day Phase One test follows mandatory entry conditions and relies on fixed decision thresholds, double-key governance, and bounded inspection zones. The most critical risks are: (1) Entry-condition delays that defer the 90-day clock indefinitely, especially inspector vetting and domestic authority enactment across two sovereigns; (2) Ledger divergence and forensic disputes over contested equipment identity under asymmetric operational security postures; (3) Vendor refusal cascades that classify material equipment as unverifiable and fail a site before Phase One concludes. Secondary but significant risks include IP/counterintelligence exposure leading to consent withdrawal, fixed threshold miscalibration driving a Modify verdict, and asymmetric access or evidence claiming that collapses reciprocity. The plan's strength—procedural rigor and double-key authority—is also its vulnerability: any impasse over entry conditions, ledger reconciliation, or threshold interpretation can trigger automatic suspension. Success depends on both governments sustaining political commitment through procedural friction, maintaining reciprocal access even under adversarial inspection, and accepting independent evidence layers as sufficient when vendor cooperation fails.