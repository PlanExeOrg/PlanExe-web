
## Risk 1 - Regulatory & Permitting
Mandatory entry conditions—signed bilateral instrument, both governments' appropriations, domestic access authority, site selection, inspector approval, vendor/operator participation, and provisional schedule—may not be simultaneously satisfied before the 90-day clock starts. A single condition lagging (e.g., China's domestic access authority delayed by legislative procedures, US vendor binding incomplete) halts the entire program, burning preparation costs without operational start.

**Impact:** Delay of 2–6 months from current Month 0 (2026-10-12) target start; loss of stakeholder momentum; accumulated operational costs (facility rental, staff deployment) without revenue/benefit; political embarrassment that either government weaponizes to withdraw entirely. Estimated sunk cost: USD 100–200 million in preparation and preliminary staffing without Phase One operational data.

**Likelihood:** High

**Severity:** High

**Action:** Establish a certified entry-gate workstream with a single project-manager cadre tracking each condition weekly; assign a bilateral contingency account (USD 50 million from contingency envelope) to accelerate rate-critical path items such as site-preparation infrastructure and inspector clearances; pre-position escrow funding mechanisms so matched tranches can be released immediately upon joint certification; define a 'near-ready' grace period and partial operational start with subset of sites if only one condition has a defined near-term resolution.

## Risk 2 - Technical
Vendor-issued cryptographic attestation keys, if concentrated in a small number of manufacturers and those keys are compromised, forged or withheld, render identity verification unachievable despite layered corroboration. A critical vendor (e.g., NVIDIA, AMD, or their Chinese equivalent) may refuse verification terms or withdraw cooperation under government pressure, leaving unknown quantities of equipment unverifiable and triggering site failure.

**Impact:** One or more declared sites fail Phase One outright due to unverifiable equipment count; Go decision blocked; reputational damage to both governments as evidence of a failed inspectorate; estimated 10–40% of declared equipment becomes unverifiable depending on vendor mix; estimated 2–4 week delay per site to escalate vendor disputes or explore alternative evidence layers.

**Likelihood:** High

**Severity:** High

**Action:** Finalize vendor binding by Month -1 (before entry gate) with non-negotiable confidentiality and reporting requirements; establish pre-qualified vendor registry with supply-chain consequences for refusal; for each critical vendor, pre-stage accredited clean-room examination centers (funded from USD 500M testing envelope) where refusing vendors can submit units for supervised testing without exposing source code; document fallback evidence ladder (customs, maintenance logs, physical marks) for each vendor tier before Phase One; require operators to declare supplier list by Month -0.5 so missing vendors can trigger entry-gate delays rather than operational surprises.

## Risk 3 - Governance & Procedural
Deadlock on a contested site finding or equipment identity creates an unresolved discrepancy with no casting vote and no defined escalation path. Automatic-suspension triggers, if inadequately defined or gaming-prone, allow one government to stall through manufactured incidents (seeding a false positive challenge result) while appearing to comply. Status-quo defaults let findings age without resolution, which itself becomes a Stop criterion if unresolved discrepancy age exceeds agreed thresholds.

**Impact:** Phase One extends beyond 90 days without conclusion, exhausting time-sensitive political goodwill; unresolved discrepancies age and feed Stop criteria even if the underlying technical facts are minor; estimated 2–8 week delay per escalated dispute; a manufactured false-positive challenge can trigger automatic suspension at a performing site, stranding that country's inspectors on home ground without reciprocal access; political crisis if one government claims the other seeded a fake incident.

**Likelihood:** Medium

**Severity:** High

**Action:** Define deadlock and suspension procedures with exacting precision before entry gate: enumerate objective triggers (e.g., divergence > 5% on ledger checkpoints, unresolved discrepancy age > 10 days, equipment unverifiable > 3% of installed base per site) that suspend automatically without co-chair discretion; establish a three-tier escalation (site co-chairs → bilateral technical referees → principal-level review) with fixed timers at each step; exclude all deliberate challenge-exercise events from triggering suspension so manufactured incidents are administratively partitioned; require joint pre-approval of challenge-exercise design so neither side can later claim seeding; define resumption conditions requiring documented corrective action, not merely time passage.

## Risk 4 - Security & Counterintelligence
Resident mirrored inspector teams stationed continuously at counterpart sites become targets for espionage, blackmail, or relationship-capture operations. A compromised inspector or translator can exfiltrate equipment identifiers, facility layouts, vendor information or classified inspection procedures. Compartmentation rules meant to limit exposure can fragment site context so severely that inspectors miss substitution patterns or accept redacted evidence they should question.

**Impact:** A counterintelligence breach surfaces mid-Phase One, requiring all affected inspectors to be rotated or stood down, losing 2–3 weeks of coverage; security incident report triggers impaired-confidence review or site suspension; estimated loss of detection confidence at affected site; diplomatic friction from espionage accusations; estimated cost of investigation and replacement: USD 20–40 million. Conversely, tight compartmentation may cause false negatives—inspectors miss a substitution because they lack prior context.

**Likelihood:** Medium

**Severity:** High

**Action:** Establish a standing counterintelligence unit (funded from USD 750M facilities/security envelope) to vet, clear and continuously monitor all inspectors, technical staff and translators; implement regular polygraph testing and compartmentation audits; limit inspector tenure at a single site to 6 months with mandatory breaks between assignments; compartment inspectors by event type and site, prohibiting cross-site knowledge holdings; embed host-country counterintelligence liaison officers at each site who review inspector outputs and evidence before release, with reciprocal liaison review at counterpart sites; fund a bilateral insider-threat red team that attempts to compromise staff and reports findings directly to the audit record and suspension criteria.

## Risk 5 - Technical & Operational
Ledger divergence between the two national cryptographic copies occurs due to network latency, synchronization delays, or deliberate tampering. No bounded reconciliation procedure, unclear divergence-detection latency, or asymmetric divergence resolution allows one side to drift its copy ahead while claiming the other is lagging, feeding deadlock and impaired-confidence triggers without objective truth.

**Impact:** Divergence detection latency exceeds agreed KPI thresholds (proposed: synchronization within 1 hour, detection within 4 hours), causing escalations on equipment identity or exit disposition before truth is established; estimated 1–3 day delay per divergence incident; if unresolved divergence exceeds agreed tolerance (proposed: > 5% of events disputed), the program triggers impaired-confidence or automatic suspension; unresolved divergence is a Stop criterion, potentially ending Phase One prematurely even if operational work is sound.

**Likelihood:** Medium

**Severity:** High

**Action:** Establish a dedicated Ledger Synchronization and Divergence Doctrine before entry gate: define checkpoint format, cadence and signed-hash-chain validation; choose authenticated transport (e.g., dedicated IPsec tunnel with mutual TLS) over shared internet; set divergence-detection latency KPI (proposed: 4-hour maximum) and reconciliation time budget (proposed: 24 hours to closure); employ neutral-party digest escrow or coupled-ledger attestation so either side can prove its copy was not rewritten post hoc; automate reconciliation logging with reason codes and dispute classification; agree on materiality threshold (proposed: > 5 discrepancies per site per week) that triggers formal reconciliation review rather than immediate escalation.

## Risk 6 - Operational
Inspector rotation, shift coverage and leave management across mirrored teams at multiple sites is modeled as a high-complexity staffing problem but no detailed surge-capacity or multi-site cross-coverage plan is defined. A health emergency, geopolitical crisis or cascading operational incident (e.g., two challenge exercises in rapid succession) strains availability below detection requirements. Single-person critical functions in any unit (e.g., the only bilingual legal specialist or the sole audit lead) create bottlenecks that compound surge risk.

**Impact:** Detection capability drops below thresholds during surge periods (e.g., Month 1–2 = 2026-11-12 to 2026-12-12 when multiple challenge exercises overlap with routine maintenance windows); estimated 20–40% reduction in inspector availability during peak operational load; an uncovered event window leads to missed arrival or substitution that feeds false-negative statistics; estimated cost overrun on personnel budget if backfill or surge staffing is required: USD 50–100 million against USD 750M personnel envelope.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Model full-time mirrored staffing from site count with explicit surge and leave buffers before entry gate: assume 3-person teams per site per shift (intake, monitoring, exit); calculate 7-day rotation with 2-person minimum staffing per function; model 15% leave allowance and 10% surge reserve; establish no single-person critical functions—every role must have a trained backup; pre-deploy cross-site floaters from both countries (estimated 20–30% surge capacity) before clock start; conduct staffing dry-run exercises in Month -1 to validate shift coverage under challenge-exercise load; define staffing KPIs (proposed: minimum 80% of target staff deployed, no single function below 2 FTE) with automatic operational curtailment if targets slip.

## Risk 7 - Technical & Operational
Evidence filtering at the operator-controlled gateway—where raw records and telemetry are reduced to schema-limited packets before crossing to inspectors—may strip critical fields needed to detect substitution or equipment movement. The operator has incentive to filter aggressively; the counterpart's engineers audit gateway rules but not inputs, creating asymmetric visibility. Filter adequacy is not tested until live exercises, at which point failures trigger suspension or discredit the entire inspection system.

**Impact:** A substituted piece of equipment passes intake because the redacted records lack the serial-number or firmware-version fields that would have triggered identity questions; false-negative detection costs credibility of the entire pilot; estimated 5–15% of substitution scenarios undetectable under aggressive filtering; if discovered post Phase One, triggers Go decision reversal; estimated reputational damage: program discredited and bilateral cooperation undermined.

**Likelihood:** Medium

**Severity:** High

**Action:** Design filter rules jointly before entry gate, with each country's sensitive-asset experts writing the filters applied at the counterpart's sites so exposure concerns are credibly mitigated; require operator-operated redaction gateways to log every filter decision (which fields redacted, why, by which rule) in the tamper-evident ledger so auditing can verify filtering consistency; run filter-adequacy blind exercises in Month 0.5 (2026-10-27) (before scored exercises) using staging areas to test whether critical fields are preserved; define a minimum evidence schema (proposed: equipment serial number, firmware version, cryptographic attestation digest, maintenance-event timestamp, physical identifiers) that is non-negotiable; if filtering strips any schema field, automatic escalation to unverifiable-equipment status; calibrate challenge exercises to include scenarios that test filter edge cases.

## Risk 8 - Operational & Governance
Matched site equivalence is vague: US Northern Virginia datacenters and Chinese Beijing–Hebei or Shanghai facilities may have vastly different staging-area sizes, customs-access latency, operator types and logistics infrastructure. Reciprocal-access parity accounting struggles to define what 'equivalent' inspection activity means when one country's matched site is a commercial facility and the other's is state-owned, or when staging areas are 10x different in size.

**Impact:** Parity disputes on whether access denial at one site is justified by asymmetric site characteristics; estimated 2–4 week stalls per parity dispute; one country claims the other's site is easier to inspect, therefore unequal access is unfair; impaired-confidence review triggered without clear resolution; estimated 10–20% of access denials become parity disputes rather than resolved technical issues.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Define 'matched' explicitly before site selection: either match by verification function (e.g., both sites have staging, spare-inventory, maintenance and expansion areas of defined footprint), by operator type (commercial with commercial, state-owned with state-owned), or by capacity tier (e.g., both handle 5–10 MW declared equipment); establish a Matched Site Equivalence working group by Month -2 to conduct physical surveys and document site characteristics that justify parity comparisons; publish site-pairing rationale before entry gate so both governments can contest equivalence claims; define normalization factors for parity accounting (e.g., 'access per unit of declared equipment' rather than 'total access hours') so asymmetric site size does not create spurious parity disputes; require a joint site-equivalence certification step at the entry gate so site mismatch does not emerge during Phase One.

## Risk 9 - Political & Governance
One government shields an operator or vendor from verification duties by invoking national security, refusing domestic access authority or withdrawing political backing. This violates reciprocity but lacks a clear enforcement path: automatic suspension is defined as a trigger, but resumption conditions require that government to reverse course, which may never happen.

**Impact:** Equipment at that government's site remains partially unverified; material equipment count unverifiable, triggering site failure and Phase One Stop decision; the shielding government claims the other's inspectors are unreliable, justifying its own access restrictions as tit-for-tat retaliation; diplomatic crisis and program termination; estimated cost: entire USD 5 billion pilot rendered inconclusive and politically contested.

**Likelihood:** Medium

**Severity:** High

**Action:** Define operator and vendor binding requirements explicitly before entry gate as non-negotiable conditions: each government must certify that it has legal authority to compel operator and vendor participation and that all critical vendors have agreed to verification terms or will use accredited clean-room examination. Make binding certification an entry condition so lack of authority emerges before clock start, not mid-Phase One; embed escalation procedure: any access refusal by an operator or vendor triggers an automatic two-tier response: first, escalation to principal-level bilateral review within 48 hours; second, if unresolved within 5 days, automatic site suspension until resumption conditions are met; document resumption conditions in bilateral instrument as non-negotiable (e.g., 'operator must grant full access or equipment is classified unverifiable and site fails'); publish suspension events in the KPI dashboard immediately so political cost of shielding is visible.

## Risk 10 - Technical
Cryptographic attestation from vendors may be forged, time-delayed or tied to firmware that does not match physical hardware. A vendor supplies attested identity credentials that validate against its root keys, yet the physical device in the staging area is counterfeit or substituted. Layered corroboration (customs records, maintenance logs, physical marks) may be insufficient if the counterpart disputes the corroboration layers' reliability or origin.

**Impact:** Equipment identity confidence falls short of agreed thresholds (proposed: > 95% confidence required); equipment escalated to unverifiable status; estimated 2–5% of declared equipment at a site becomes unverifiable due to attestation-corroboration mismatches; if unverifiable count exceeds site threshold (proposed: > 3% of installed base), site fails Phase One; estimated 1–2 week delay per escalation while bilateral technical referees adjudicate equipment identity.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish an Equipment Identity Trust Anchor before entry gate that specifies the evidentiary hierarchy: cryptographic attestation is primary but requires independent validation by accredited examiners from both countries; customs records and shipment tracking are secondary layers; physical inspection and equipment identifiers (serial numbers, tamper seals, burn-in marks) are tertiary layers; no single layer is decisive; a mismatch across any two layers triggers escalation to technical referees for dual-signed adjudication; require attestation timestamps to bind to customs-entry and staging-arrival events within a fixed tolerance (proposed: ±2 hours); pre-stage bilateral attestation-validation laboratories (funded from testing envelope) to independently verify vendor signatures before intake; develop a physical-mark and tamper-seal specification that is agnostic to vendor but recognizable by both sides; if attestation cannot be validated by Month 1 (2026-11-12), automatically elevate all equipment from that vendor to unverifiable status and escalate to bilateral principals.

## Risk 11 - Technical & Operational
Blind challenge exercises designed to test unreported arrival, substituted equipment, inaccurate records, delayed access and vendor refusal may serendipitously trigger automatic-suspension conditions, stranding inspectors or equipment and creating a cascading operational crisis. A false-positive challenge (e.g., a seeded unreported arrival that is misinterpreted as a real breach) collides with automatic-suspension triggers, halting Phase One work until the false positive is adjudicated.

**Impact:** A challenge exercise injects a test substitution; the intake team flags it as unverifiable; automatic-suspension trigger fires (unverifiable equipment exceeds threshold); site suspends; all inspectors at that site stood down; estimated 3–7 day operational halt to adjudicate the challenge event; estimated 10–20% schedule slip if multiple challenges trigger false-suspension cascades; bilateral recrimination if one government claims the other weaponized a challenge to manufacture a pretext for suspension.

**Likelihood:** Medium

**Severity:** High

**Action:** Partition challenge-exercise events administratively from operational triggers: explicitly exclude all deliberate challenge-exercise events from triggering automatic suspension, impaired-confidence review or KPI threshold violations; mark every injected scenario in the ledger with a 'CHALLENGE' tag before injection so scoring and suspension logic can filter them out; require independent testers to design blind challenges in a sealed, pre-committed catalog agreed by both governments before Phase One starts, so neither side can accuse the other of seeding a fake incident; publish challenge-exercise schedule in advance so teams are expecting injection and can distinguish exercises from operational anomalies; run filter-adequacy and presence-detection exercises in Month 0.5 (2026-10-27) before Phase One operational clock starts; if a challenge-exercise event is misclassified as operational and triggers suspension, treat escalation to principals as immediate (within 2 hours) without waiting for normal deadlock timers, with automatic reinstatement pending adjudication.

## Risk 12 - Financial
Budget envelopes are fixed (USD 1.25B ledger, USD 1B site preparation, USD 750M personnel, USD 750M facilities, USD 500M testing, USD 250M legal/audit, USD 500M contingency). Surge costs during Phase One (extra inspector shifts, challenge-exercise staging, vendor escalation or litigation) are not pre-allocated and must draw from contingency, which is insufficient if multiple surges overlap. No budget flexibility mechanism is defined; overspends require bilateral re-appropriation, which stalls decisions.

**Impact:** Contingency budget exhausted by Month 1.5 (2026-11-27) due to vendor escalations, vendor-refusal litigation and inspector surge staffing; subsequent cost overruns (e.g., a critical vendor demands paid testing at USD 30M instead of budgeted USD 5M) have no funding source; operational corners are cut, detection capability reduced or Phase One curtailed early; estimated 10–20% of planned scope cancelled due to budget exhaustion; estimated cost overrun: USD 200–300 million if not absorbed by cutting scope.

**Likelihood:** Low

**Severity:** Medium

**Action:** Reserve USD 500M contingency envelope explicitly for surge and unexpected costs; allocate contingency thresholds by risk category (estimated 20% overrun on personnel surge, 25% on vendor escalation, 15% on IT/ledger security) before entry gate; establish a contingency-release workstream with joint bilateral approval for any drawdown above USD 10M (every major surge release requires explicit co-chair sign-off); model budget profiles for low/medium/high surge scenarios by Month -1 so overruns are anticipated, not reactive; establish a bilateral rapid-funding trigger: if contingency draw approaches 75% before Month 2 (2026-12-12), automatic escalation to principals for a supplementary appropriation decision; require monthly budget-burn reports (tracking actual vs. planned by envelope) in the KPI dashboard so overspends are visible within 30 days.

## Risk 13 - Operational & Technical
The 90-day Phase One operational window (Months 1–3 = 2026-11-12 to 2027-01-12) is very short for detecting all material changes at multiple sites while running challenge exercises, adjudicating disputes, producing a validated ledger and reaching a Go/Modify/Stop decision. Late entry-gate delays, late vendor binding or cascading operational incidents compress the actual operational window to 60 days or less, leaving insufficient time for challenge-exercise cycles and consensus on verdict thresholds.

**Impact:** Insufficient operational data to validate Go thresholds; Go decision forced by calendar pressure rather than evidence sufficiency; estimated 50% reduction in blind-exercise cycles if entry gate slips by 6 weeks; unresolved discrepancies accumulate with no time for adjudication, forcing a Modify or Stop verdict by default; reputational damage: program appears rushed and inconclusive.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Front-load all entry conditions by Month -1 (8 weeks before operational clock): bilateral instrument signed, appropriations allocated, domestic access authority enacted, sites selected and certified equivalent, inspectors cleared, vendors bound, and provisional schedule adopted. Do not start the 90-day clock until all conditions are met. Establish an entry-gate go/no-go decision point by Month -1.5 (12 weeks before operational start) so if conditions cannot be met, both governments can decide to restart or abandon before sunk costs mount. Reserve the first 5 days of operational Phase One (Month 1 = 2026-11-12, Days 1–5) purely for opening inventory baseline and starting-state seal with no challenge exercises or equipment movements. Compress challenge-exercise schedule to Month 1.5–2.5 (2026-11-27 to 2026-12-27) so results are available for verdict calibration by Month 2.75 (2027-01-04). Define a mandatory verdict decision point at Month 3.25 (2027-01-20) (13 weeks after clock start, 1 month buffer) so unresolved issues do not push verdict beyond political deadlines.

## Risk 14 - Governance & Procedural
No casting vote and double-key authorization requirements mean deadlocked decisions on suspended sites, equipment disposition or vendor refusal cannot be resolved without escalation to principals. Escalation procedures are not defined, timers are vague ('designated principals' review 'unresolved findings'), and no automatic resolution rule exists. A unilateral country can delay indefinitely by stalling at co-chair level, feeding aging discrepancies into the Stop criterion.

**Impact:** An unresolved discrepancy at one site ages beyond proposed 10-day threshold; Stop criterion triggered not because of technical failure but because of deadlock; entire pilot terminated mid-Phase One due to procedural gridlock; estimated political crisis as one government claims the other weaponized deadlock to kill the program.

**Likelihood:** Medium

**Severity:** High

**Action:** Define Deadlock and Suspension Mechanics exhaustively before entry gate: specify deadlock as 'failure to reach bilateral consensus on a finding within 5 days'; define automatic escalation path: deadlock triggers automatic escalation to a Bilateral Technical Referees panel (2 experts per side, pre-cleared and funded before clock start) within 24 hours; referees must issue a joint advisory fact statement within 3 days; if referees cannot agree, escalate to Principal-level Review (e.g., deputy secretary-level or equivalent) within 2 days; principals must decide within 5 days or the status quo defaults to heightened inspection (not suspension) while escalation continues; unresolved discrepancies older than 10 days are reported as aging in the KPI dashboard and trigger impaired-confidence review, not automatic suspension; unresolved discrepancies older than 15 days become Stop-criterion candidates, triggering principal-level intervention before suspension; define escalation timers in the bilateral instrument as non-negotiable so neither side can reinterpret them.

## Risk 15 - Security & Operational
Operator and vendor willingness to participate depends on trust in compartmentation and confidentiality boundaries. If an operator perceives that inspectors are collecting information beyond the agreed boundary (e.g., learning about production-floor topology or customer workloads), or if evidence leaks to the foreign government despite filtering, the operator will withdraw consent, refuse future access or escalate politically to their government.

**Impact:** An operator withdraws from Phase One or refuses to allow inspectors on-site; that country's declared site fails outright; Go decision blocked; estimated 20–40% of all operator support at risk if a single operator breach surfaces; if a US operator withdraws, estimated USD 200–300M in cascading vendor and operator defections as others follow. Political crisis as operator's home government claims foreign intelligence exploitation and demands compensation.

**Likelihood:** Medium

**Severity:** High

**Action:** Establish Inspection Zone Geometry and Evidence Filtering Design before entry gate with operator input and signed confidentiality commitments: define physical boundaries (staging, spare-inventory, maintenance, expansion areas only; production halls and customer-data areas strictly off-limits) and paint boundaries in the facilities; admit only pre-validated inspector instruments (no recording devices, no connected IT systems without air-gap protocols); require operator-controlled redaction gateways so raw data never leaves the facility; have each country's specialists design the filters applied at the counterpart's sites so exposure concerns are credibly addressed; embed operator liaisons in the inspectorate to audit field work against agreed boundaries; publish quarterly operator-confidence reports in the KPI dashboard (proposed metric: 'Operator consent status: full/degraded/withdrawn') so political cost of boundary violations is visible; run Inspection Zone Geometry validation exercises in Month 0.5 (2026-10-27) with staged incursions to test boundary enforcement and operator confidence; if an operator withdraws consent, automatic escalation to principals and suspension of that site pending diplomatic resolution.

## Risk 16 - Financial & Governance
The plan specifies that compensation to domestic operators and vendors is 'administered by their own government and charged against its contribution,' but no mechanism for transparent parity accounting is defined. China may compensate vendors at rates 5–10x higher than US market rates; US may negotiate lower rates to preserve budget; asymmetric spending leaves one country ahead on its USD 2.5B allocation while the other is depleted, creating visible spending parity disputes that feed impaired-confidence allegations.

**Impact:** By Month 2 (2026-12-12), cumulative disbursement parity diverges (e.g., US has spent USD 1.2B, China USD 800M); one country claims the other is front-loading contingency or over-compensating domestic players; triggers bilateral accounting dispute; estimated 1–2 week delay per parity audit; if divergence exceeds agreed tolerance (proposed: ±10% of allocated portion), automatic impaired-confidence review; reputational damage: program appears unequal and one side appears to be looting the budget.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish transparent, matched-tranche spending protocols before entry gate: each country's USD 2.5B contribution is divided into equal quarterly tranches (USD 625M per quarter); tranche release is contingent on matched cumulative disbursement parity (neither side's cumulative spend leads the other's by more than ±10% of pro-rata share); require monthly spending reports by envelope category (personnel, site preparation, testing, etc.) published in the KPI dashboard so spending divergence is visible; establish an independent bilateral budget auditor (funded from USD 250M legal/audit envelope) to verify each tranche release; if spending divergence exceeds 15% at any month, automatic review and explanation required before next tranche release; define parity not as identical line-item spending but as matched cumulative portfolio so one country can spend more on personnel and less on testing if total burn is equal; establish a spending-parity trip point (proposed: 20% divergence) that triggers impaired-confidence review and holds tranche release until corrected.

## Risk 17 - Regulatory & Permitting
Domestic legal authority to compel operator and vendor participation may be incomplete or challenged in litigation. A US federal court may find that compelling a private vendor to accept Chinese inspectors violates constitutional due process; a Chinese vendor may have state-owned-enterprise status that creates legal ambiguity about who can authorize participation. Unresolved legal challenges delay vendor binding and leave the entry gate uncertified.

**Impact:** Vendor binding delayed by 2–4 months due to litigation or reauthorization efforts; entry gate cannot be certified; Phase One operational start delayed or cancelled; estimated USD 50–100M in legal fees and preliminary operational costs absorbed without benefit.

**Likelihood:** Low

**Severity:** High

**Action:** Conduct comprehensive legal review before entry gate to identify any domestic legal barriers to compulsory operator/vendor participation; have the US government seek expedited legislative clearance (if needed) or Office of Legal Counsel opinion affirming authority to require participation; have the Chinese government issue binding directive affirming domestic enterprise authority to participate; establish a bilateral legal working group by Month -3 to resolve anticipated challenges and publish legal opinions before entry gate; build a 6-week legal-clearance contingency into the entry-gate timeline so challenges surface early and do not slip Phase One start; if legal barriers remain unresolved by Month -1.5, escalate to principals for a decision to delay or proceed with partial participation.

## Risk 18 - Operational
Covered-Equipment Schedule Abstraction Ladder is meant to be vendor-neutral and hardware-generation-agnostic, yet it must be sufficiently specific to classify equipment at intake and exit. Vague schedule definitions (e.g., 'frontier-relevant computing equipment' without thresholds) lead to boundary disputes: is a GPU from 2 years ago still covered, or has it been superseded? Who decides? Classification thresholds held in split escrow invite suspicion that one side is hiding the true definition.

**Impact:** Boundary-case equipment disputed at intake; estimated 5–15% of equipment arrives at the declared sites without clear classification status, delaying intake; every classification dispute escalates to bilateral specialists or principals; estimated 1–2 week delay per dispute; if 10+ disputes accumulate, schedule specialists become the bottleneck and Phase One intake stalls.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Define covered-equipment schedule by functional role before entry gate, not by specific product: e.g., 'any device performing tensor-accelerated parallel computation exceeding 1 exaflops per second in aggregate cluster configuration'; avoid manufacturer-specific definitions; include a schedule-update process allowing both governments' technical specialists to revise classifications on a quarterly basis through versioned, double-key updates; establish a boundary-case resolution procedure: items within 10% of threshold triggers a joint technical review within 2 days; if specialists cannot agree, defaulting rule is: 'when in doubt, classify as covered' to avoid undercount; publish schedule version and update history in the ledger so both sides can verify that definitions are not being surreptitiously changed; require accountable specialists from both sides to sign off on all schedule updates before they take effect.

## Risk 19 - Operational & Governance
Reciprocal-Access Parity Accounting Method is meant to ensure both governments' inspectors have equivalent access rights, but 'equivalent' is ambiguous when sites are asymmetric, operator responsiveness differs, or operational incidents disrupt access schedules. One country may claim that access denials at the counterpart's site are unjustified operational friction, while the counterpart claims that equivalent access is impossible given facility constraints. Parity disputes age without resolution, feeding Stop criteria.

**Impact:** Parity disputes accumulate (proposed threshold: > 5 unexplained denials per month becomes trip point); estimated 1–2 week delay per major parity escalation; if denials exceed threshold, impaired-confidence review triggered; if unresolved, automatic suspension of reciprocal access reviews (inspectors paused while dispute resolved); operational halt estimated 3–5 days per incident; estimated 10–20% of Phase One time consumed in parity adjudication rather than productive inspections.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Define parity operationally before entry gate with reason-coded denial logging: each access request, inspection event and evidence request is logged in the ledger with accept/deny status and reason (e.g., 'operator emergency maintenance,' 'facility security hold,' 'schedule conflict,' 'vendor refusing access'); establish equivalence yardstick: parity is judged by matched events (inspector hours, staging-area accesses, equipment inspections) rather than raw time, normalized by site size and equipment count; set tolerance bands (proposed: ±10% variance between matched sites' reciprocal-access rates) below which no trip point is triggered; denials above tolerance require reason-code explanations within 24 hours; any denial with no acceptable reason-code triggers escalation to bilateral operations directors within 48 hours; unresolved denials older than 5 days become aging-discrepancy entries in KPI dashboard; trip point set at > 15% divergence for consecutive weeks, triggering impaired-confidence review but not automatic suspension.

## Risk 20 - Technical
Opening Inventory Baseline and Starting-State Seal requires establishing which equipment is declared as present at each site at Month 1 (2026-11-12), Day 0. If the baseline is not sealed (e.g., progressive verification of items only when maintenance events touch them), then early discrepancies are ambiguous: is an unexpected unit a new arrival, or was it present before? If the baseline is sealed by full census, operator exposure is maximized and some operators may withdraw consent.

**Impact:** If baseline is not sealed, false-positive and false-negative rates on early arrival detection are both high; estimated 20–30% of detected arrivals disputed because baseline status is unclear; escalations consume 2–3 days each; if baseline is sealed by census, estimated 1–2 weeks of intake time consumed on Month 1 (2026-11-12), and some operators withdraw due to exposure, failing sites outright.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Choose a baseline strategy before entry gate and commit to it: either (1) seal a declared opening inventory through joint count of covered-equipment categories within declared zones by Month 1 (2026-11-12), Day 5, treating it as zero-point reference for all later changes, with explicit disclosure in reports that starting population is verified, or (2) accept operator self-declaration without a count and verify only changes after entry, explicitly labeling all reports with 'starting population unverified' disclaimer; a third option is progressive baselining (verify items only when maintenance events touch them), documented as such with explicit disclaimer that early arrivals cannot be distinguished from pre-existing items. Do not attempt a hybrid approach; choose one and publish the choice in the bilateral instrument before entry gate. If option 1 (sealed census), schedule intensive intake for Month 1 (2026-11-12), Days 1–7, with additional inspectors pre-deployed for surge capacity. If option 2 (unverified baseline), schedule challenge exercises to inject known arrivals in Month 1.5 (2026-11-27) so detection capability is tested with clear baselines.

## Risk 21 - Governance
Verdict Evidence Sufficiency and Threshold Calibration requires pre-registering Go, Modify and Stop thresholds (proposed KPIs: blind-challenge detection rate > 95%, false-negative rate < 3%, ledger-divergence latency < 4 hours), but these figures are assumed, not validated. Challenge exercises may reveal that detection rates are only 80% under realistic filtering, forcing a Modify or Stop verdict even if operational procedures are sound. Alternatively, if thresholds are calibrated during Phase One using early exercise data, political incentives push each government to interpret results favorably, feeding re-definition-of-success accusations.

**Impact:** Go thresholds set at 95% detection rate; exercises reveal 85% actual rate; threshold-not-met triggers Modify or Stop verdict despite operational soundness; political crisis as one government claims thresholds were rigged by the other. Conversely, if thresholds are calibrated mid-Phase One, scoring divergence emerges at Month 2.5 (2026-12-27); one side claims 92% detection (Go), the other 87% (Modify); estimated 2–3 week stall while principals adjudicate threshold-setting methodology.

**Likelihood:** Medium

**Severity:** High

**Action:** Pre-register Go, Modify and Stop thresholds before entry gate with documented validation method for every figure: for each KPI (detection rate, false-negative rate, ledger latency, parity variance, unverifiable-equipment ratio), publish the source of the estimate (historical precedent, expert consensus, preliminary testing) and mark unsupported figures explicitly as '(provisional—validated by Month 1.5 = 2026-11-27 exercises)'; establish a Threshold Calibration Panel of bilateral technical experts (pre-cleared, funded from testing envelope) who will independently evaluate early blind-exercise results by Month 1.5 (2026-11-27) and recommend threshold adjustments if empirical data diverges >10% from assumptions; freeze all thresholds by Month 2 (2026-12-12), before scored exercises, so calibration is complete before final verdicts; publish threshold-calibration records and any recommended adjustments in the ledger so both governments can verify the process was rigorous; if scoring divergence persists at verdict time (e.g., one side scores 92%, the other 87%), publish both national scores sealed and let the divergence magnitude itself become a metric reported alongside the verdict.

## Risk 22 - Operational
Exit Protocol and Departure Disposition Evidence Ladder requires witnesses to every departure: witnessed destruction, verified permanent disablement, transfer to another site, or documented release beyond monitoring. In a surge environment (e.g., Month 2 = 2026-12-12 when a vendor moves units from one site to another), witness availability is insufficient; disposition closures age without completion; unresolved dispositions feed Stop criteria.

**Impact:** During Month 2 (2026-12-12) surge, 50 units scheduled for transfer or decommissioning but only 15 witness-slots available per week; estimated 3–4 week backlog on disposition closure; unresolved-disposition age climbs to 15+ days at some units; Stop criterion triggered (unresolved dispositions > agreed threshold) even though operational work is sound; estimated 1–2 week operational halt while adjudication catches up.

**Likelihood:** Low

**Severity:** Medium

**Action:** Model Departure Disposition Evidence Ladder staffing by maximum monthly departure rate before Phase One: if typical surge is 100 units/month requiring witness closure, allocate 4–6 mirrored witness teams per site with availability for 20–30 witnesses per week per site; establish pre-positioned surge capacity (bilingual logistics specialists, mobile inspection teams) funded from contingency envelope. Require operators to pre-declare intended disposition path (destruction/disablement/transfer/release) at least 5 days in advance so witness schedules can be pre-planned. Define evidence requirements by disposition type: witnessed destruction requires 2 inspectors + residual sampling; permanent disablement requires 2 inspectors + state verification; transfer requires 2 inspectors + receiving-site attestation; release beyond boundary requires sealed handover only, no further tracking. If witness capacity is exceeded, automatic escalation to bilateral logistics directors for surge staffing authorization within 24 hours; mark unresolved dispositions older than 10 days in the KPI dashboard as aging, triggering accelerated witness scheduling.

## Risk 23 - Security
Secure facilities (ledger nodes, clean rooms, counterintelligence-protected workspaces) must themselves be protected against espionage, sabotage or physical compromise. A compromised ledger node could silently alter records; compromised clean-room surveillance could leak equipment details; compromised evidence storage could allow post-hoc falsification. Facility security responsibility is split between host and inspectorate, creating ambiguity in accountability.

**Impact:** A security incident at a ledger facility surfaces mid-Phase One; entire ledger integrity questioned; estimated 2–4 week forensic investigation; Go decision blocked or reversed due to evidence-system distrust; reputational damage: bilateral verification program's core asset (the ledger) is compromised; estimated cost of investigation and facility re-hardening: USD 20–40M.

**Likelihood:** Low

**Severity:** High

**Action:** Establish secure-facility security protocols before entry gate, funded from USD 750M facilities/security envelope: ledger nodes in geographically diverse, hardened facilities with biometric access control, continuous intrusion detection and mirrored backup at both countries; clean rooms designed with physical evidence-handling zones where neither government's equipment or personnel can access raw data (operator-operated redaction gateways only); secure facilities staffed by host-country security professionals with bilateral observation (host government operates facility, counterpart government has 24/7 observer presence); all facility incidents (access anomalies, surveillance anomalies, system alerts) logged in the tamper-evident ledger within 1 hour; establish a bilateral Facility Security Review Panel that conducts quarterly unannounced inspections of the counterpart's secure facilities; fund redundant ledger copies and offline backup media stored in neutral-party escrow for forensic recovery if primary nodes are compromised.

## Risk 24 - Organizational & Staffing
Bilateral governance with equal co-chairs and no casting vote creates structural paralysis if both chairs hold incompatible positions on a critical decision. No defined escalation to principals, no automatic arbitration and no time limits on deadlock resolution mean disputes age indefinitely while operations stall. A political change in either country (e.g., a new administration or cabinet) can trigger re-evaluation of Phase One cooperation, delaying decisions and paralyzing governance.

**Impact:** A deadlock on a site finding ages from Day 5 to Day 15; no escalation triggered; unresolved discrepancy feeds Stop criterion without bilateral agreement; program stalls or terminates mid-Phase One; estimated political crisis and reputational damage globally as the bilateral pilot is seen as dysfunctional.

**Likelihood:** Low

**Severity:** High

**Action:** Embed deadlock procedures exhaustively in the bilateral instrument before signature: define a three-tier escalation: (1) Co-Chair Level, Days 1–5; (2) Technical Referee Panel, Days 5–8; (3) Principal-Level Review, Days 8–13; at each tier, define required actions (fact-finding, option generation, recommendation); if principals cannot agree by Day 13, status quo defaults to heightened inspection (not suspension) while further escalation continues; require principals to render a decision within 5 calendar days of receiving the referee recommendation, or declare impasse in writing to trigger automatic re-escalation to the top political level (e.g., national-security advisor or equivalent). Embed a continuity mechanism: if a chair leaves office or a government changes, designate a successor chair before transition; ensure Phase One operations continue under interim governance until a new chair assumes duties. Document all deadlock escalations in the ledger with timestamps and decision outcomes so both governments can verify the process was followed.

## Risk 25 - Regulatory & Permitting
The bilateral instrument—the treaty, memorandum of understanding or executive agreement that binds both governments—must be negotiated, approved and signed before entry conditions can be certified. Diplomatic negotiations typically consume 6–12 months. The plan assumes signing by Month 0 (2026-10-12), leaving no time for formal negotiation, legal review or legislative ratification (if required by US Senate or Chinese Standing Committee).

**Impact:** Instrument not signed until Month 4 (2027-02-12) or later; entry-gate clock slips; Phase One operational start delayed by 3–6 months; accumulated preparation costs (facility rental, staff onboarding) burn without operational benefit; estimated USD 100–200M sunk cost before Phase One can begin.

**Likelihood:** High

**Severity:** High

**Action:** Begin bilateral-instrument negotiation immediately (parallel to plan development, Month -6 to Month -3) so signature is achievable by Month -1 at the latest; establish a bilateral steering committee to track negotiation progress and escalate bottlenecks weekly; commit both governments to a fixed instrument-signature deadline by Month -2 so Phase One operational start is not delayed; if formal ratification is required, conduct parallel ratification efforts (US Senate or Chinese Standing Committee approval) so formal approval coincides with signature; use a phased approach: sign a skeletal executive agreement by Month -1 to freeze core governance principles and enter conditions, then negotiate detailed operating procedures via subsidiary annexes that can be finalized during Phase One if needed; establish a standing legal working group (funded from USD 250M legal/audit envelope) to identify legal, commercial and regulatory barriers to implementation before they delay entry conditions.

## Risk summary
The Consortium is a first-of-kind, USD 5 billion bilateral verification program with extraordinary operational, governance and security complexity. The 90-day Phase One operational test depends critically on mutual trust-free evidence systems, resident mirrored teams, double-key governance without casting votes, and layered detection. The three highest-risk domains are: (1) Entry-gate stalling and incomplete mandatory conditions that delay or prevent the 90-day clock from starting; (2) Attestation-key compromise or vendor refusal that renders equipment identity unverifiable despite full operational readiness; and (3) Ledger divergence or manufactured-incident cascades that trigger deadlock or impaired-confidence suspension without resolution paths, causing either government to withdraw. Secondary risks span counterintelligence penetration, operator shielding, inspector capture, evidence filtering adequacy, parity disputes on non-identical sites, false-positive challenge exercises, and the inherent political fragility of a verification program that cannot prove the absence of hidden facilities or total capacity. Mitigation requires early vendor binding, cryptographic ledger commitments before clock start, containment of exercise events from triggering suspension, and explicit escalation procedures that prevent deadlock from aging unresolved.