This plan involves money.

## Currencies

- **USD:** Primary budget allocation currency. Both governments contribute USD 2.5 billion each (total USD 5 billion) across seven fixed envelopes: secure ledger (USD 1.25B), site preparation (USD 1B), personnel (USD 750M), facilities (USD 750M), testing (USD 500M), legal/audit (USD 250M), contingency (USD 500M). All international reporting, bilateral tracking and budget reconciliation use USD.
- **CNY:** Required for Chinese domestic administration of operator and vendor compensation charged against China's USD 2.5 billion contribution. The Chinese government must convert or allocate its share into RMB for payments to Chinese operators, vendors, staff and facilities. Exchange-rate tracking and conversion rules should be set at the entry gate to ensure transparent 50/50 parity accounting.

**Primary currency:** USD

**Currency strategy:** USD serves as the consolidated primary currency for all bilateral budgeting, appropriations, reporting and accountability. The Chinese government administers its domestic contribution (operator compensation, vendor payments, staff salaries, facility costs) in CNY against its USD 2.5 billion share, requiring a transparent conversion methodology or fixed exchange rate established before the appropriation-release entry gate. Parity accounting between the two governments' cumulative disbursements is tracked in USD to detect one-sided spending drift. The 90-day Phase One window (Months 0–3 = 2026-10-12 to 2027-01-12) presents minimal exchange-rate exposure, but the plan should document the conversion rule and any revaluation provisions in the bilateral instrument and budget governance. No external hedging or derivative instruments are anticipated for a sovereign government-to-government transaction.