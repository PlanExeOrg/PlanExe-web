This plan involves money.

## Currencies

- **USD:** Primary budget currency (user constraint). All bilateral budgeting, appropriations governance, tranche disbursement, envelope tracking, auditing and final reporting are conducted in USD. Each country's USD 2.5 billion contribution is tracked and reconciled in USD.
- **CNY:** Chinese domestic expenses. Operator compensation, site preparation, personnel and facility costs within China are incurred and administered in CNY by the Chinese government, then converted to USD equivalents at agreed bilateral exchange-rate milestones for consolidated envelope reconciliation.

**Primary currency:** USD

**Currency strategy:** USD is the primary currency for all bilateral governance, auditing and reporting. Domestic expenses within each country are incurred in local currency (USD in the United States, CNY in China) but reconciled to USD equivalents at fixed bilateral exchange-rate milestones (entry conditions, Phase One start, final audit) to ensure budget accountability, prevent currency-fluctuation disputes and support the symmetric 50/50 appropriations structure. This approach aligns with arms-control-style verification precedent, where international settlement occurs in a stable reference currency while domestic administration remains in local currency.