35 explicit calculations found in the documents re-computed without an LLM; 4 do not match their stated result.

| Section | Statement | Stated | Computed |
|---|---|---|---|
| Assumptions | 4–6 inspectors per site per shift × 3 shifts × 2–4 sites × 2 countries = 96–144 on-site at any time | 96–144 | 12–24 |
| Data Collection | (B) Two-shift 16-hour (6 per shift × 2 shifts × 3 sites × 2 countries × 1.2 multiplier = ~288 per country | 288 | 14.4 |
| Data Collection | 00 UTC + 4 hours = 08 | 08 | 4 |
| Team | total 6 sites x USD 2.5B / 6 sites ≈ USD 417M | 417M | 2.5B |
