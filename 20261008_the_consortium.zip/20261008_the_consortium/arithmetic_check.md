11 explicit calculations found in the documents re-computed without an LLM; 1 does not match its stated result.

| Section | Statement | Stated | Computed |
|---|---|---|---|
| Canonical Facts | per-country halves 625/500/375/375/250/125/250M = 2,500M | 2,500M | 5e-07 |
