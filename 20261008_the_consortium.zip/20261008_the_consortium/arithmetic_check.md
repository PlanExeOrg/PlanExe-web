22 explicit calculations found in the documents were re-computed without an LLM; 0 do not match their stated result.

