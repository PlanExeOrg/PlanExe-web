## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Are the signed bilateral instrument (with deadlock timers, auto-suspension triggers and CHALLENGE partition) and both countries' appropriations in place by Month 7 (2027-05-12), with domestic access authority by Month 7.5 (2027-05-27)? | Instrument signed and appropriations enacted at Month 7 (2027-05-12); access authority and supplier-list declarations at Month 7.5 (2027-05-27); no entry condition 14 or more days behind its deadline; principal go/no-go checkpoint at Month 7.5 (2027-05-27). | Signed instrument text, enacted appropriation acts, enacted access-authority instruments and the weekly condition tracker, reviewed at the Month 7.5 (2027-05-27) principal checkpoint. Early signal: unresolved instrument articles at Month 5 (2027-03-12). | Principals give a written defer, reduced-scope (subset of matched pairs) or stop decision within 48 hours. The 90-day clock does not start. Cancel or formally restart if any condition is uncertified at Month 12 (2027-10-12). |
| 2 | Are critical vendors bound and attestation keys validated, so that the unverifiable-equipment forecast is at or below 3% per site and at least 2 clean-room centers will be operational by Month 9 (2027-07-12)? | Vendor binding, site selection, inspector approval and provisional schedule by Month 8 (2027-06-12); no vendor above 5% of units unbound; key-validation median latency within 4 hours; unverifiable forecast at or below 3% of covered units per site; at least 2 clean-room centers (one per country). | Vendor census with binding status per supplier, key-validation dry-run results and clean-room acceptance, due at Month 8 (2027-06-12) and before the single gate at Month 9 (2027-07-12). | Run the refusal ladder (supervised testing, filtered evidence, accredited examination, clean room, validated attestation) and escalate to principals within 5 days. Reduce scope to the pairs that pass, or defer: an unresolved vendor costs 2-4 months, and a delay beyond 3 months passes the Month 12 (2027-10-12) outer limit. Equipment still unvalidated at Month 10 (2027-08-12) is unverifiable. |
| 3 | Do the readiness rehearsals pass: staffing dry-run (Month 8 = 2027-06-12), ledger stress test (Month 8 = 2027-06-12) and filter-adequacy blind pre-test (Month 8.5 = 2027-06-27)? | Cleared staff at least 80% of target and no function under 2 FTE; checkpoint synchronization within 1 hour (breaches on 5% of checkpoints or fewer), divergence detection within 4 hours, false-positive divergence alerts at most 5%; pre-test with at least 10 injected substitutions, target 9 of 10 detected, halt scored exercises below 85%. | Staffing dry-run report at Month 8 (2027-06-12), ledger stress-test log under 10x event load at Month 8 (2027-06-12), and independently scored pre-test results at Month 8.5 (2027-06-27), all before the Month 9 (2027-07-12) gate. | Do not start the clock. Below 85% detection, halt scored exercises and renegotiate filter rules by double-key protocol change. Staffing below 80% means a reduced site set or delayed start. Unresolved ledger transport faults mean a delayed start with hardened transport. |
| 4 | Is funding timely and in parity at the Month 10 (2027-08-12) tranche release? | Cumulative disbursement within +/-10% of pro-rata share; more than 15% monthly divergence needs explanation before the next tranche; 20% divergence means impaired-confidence review and tranche hold; a tranche more than 30 days late without double-key deferral counts as funding withheld (Stop); contingency draws above USD 10M need double-key approval; 75% drawn (USD 375M) escalates to principals. | Independent budget auditor's monthly burn reports by envelope and country, the documented CNY conversion rule (due before appropriation release) and tranche release records at Months 7 and 10 (2027-05-12, 2027-08-12). | Hold the tranche and require an explanation, or an impaired-confidence review at 20%. If a tranche stays more than 30 days late without double-key deferral, funding is withheld and the program moves to Stop. |
| 5 | Do scored exercises (Months 10.5-11.5 = 2027-08-27 to 2027-09-27) show credible detection, with at least 10 injections per event type and zero disruption of active compute? | Blind detection at least 90% for each of 7 event types (false negatives at most 10%) from at least 10 injections each (70 total); Modify band 80% to under 90%; under 80% is not Go; zero production disruption; thresholds frozen at Month 10.5 (2027-08-27) before scoring; sealed national scores compared at Month 11.75 (2027-10-05). | Independent testers' scoring against the hash-committed scenario catalog, sealed national scores compared at Month 11.75 (2027-10-05), and the disruption log. | Modify if weaknesses are correctable or coverage is insufficient (retry or corrective trials). Stop if detection is below 80% with no correctable cause, or if repeated disruption recurs after redesign. Score divergence above 10 points goes to referees and an independent scoring audit before the verdict. |
| 6 | At the verdict (Month 12.25 = 2027-10-20), is reciprocal access shown and are all Stop triggers absent? | Reciprocal-access variance within 10% between matched sites (more than 15% for 2 consecutive weeks or more than 5 unexplained denials per month means review); unverifiable at most 3% per site; no ledger divergence or discrepancy unresolved beyond 15 days; no shielded operator; no withheld funding. | Parity report, unverifiable-equipment counts per site, aging-discrepancy log, operator consent status and auditor certification, presented in the joint verdict report at Month 12.25 (2027-10-20). | Stop if access is asymmetric, material equipment is unverifiable, an operator is shielded, ledgers diverge unresolved or funding is withheld. Modify for correctable weaknesses or insufficient exercise coverage. Success is reported only for monitored changes at participating declared sites. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: self audit item 11 (and review plan Review 14 item 2)
    canonical: detection_thresholds = Go: blind detection >=90% for each of 7 event types; Modify: 80% to <90% or correctable cause; <80% not Go; >=10 injections per event type
    observed:  >=90% mean across all 7 types with no type <85%
HIGH CF-002  document: review plan Review 1/2/4 (and project plan Time-bound / canonical_facts for the fixed verdict date)
    canonical: phase_one_window_and_baseline = 90 days, Months 9-12 (2027-07-12 to 2027-10-12); clock begins only after certification
    observed:  window compresses from 90 days to 30-60 days; outer limit Month 12 (2027-10-12) with verdict still Month 12.25 (2027-10-20)
HIGH CF-003  document: review plan Review 14 / self audit item 15 / pitch Long-term Vision
    canonical: budget_horizon_open_decision = Open decision: documents do not state what the USD 5B funds after the Phase One verdict; no Phase Two scope, criteria or funding defined
    observed:  Phase Two Go = USD 2.5B additional for 8-12 sites; Phase One allocated USD 5.0B only
HIGH CF-004  document: premortem FM1/FM4, review plan Reviews 4/5/10/11, self audit item 6
    canonical: tranche_schedule = Tranches at Months 7, 10, 13, 16 (2027-05-12, 2027-08-12, 2027-11-12, 2028-02-12); supplementary appropriation exceeds USD 5B cap (estimate)
    observed:  Gate-readiness draws and supplementary appropriations scheduled before Month 6 (2027-04-12)
MEDIUM CF-005  document: review plan Review 14 item 2; self audit items 15 and 6
    canonical: tranche_schedule = 4 equal matched tranches of USD 625M per country (USD 1.25B combined)
    observed:  Tranches 3-4 (USD 1.25B combined)
MEDIUM CF-006  document: self audit items 4 and 7; premortem A7
    canonical: contingent_exposure_estimate = Exposures USD 160-340M vs USD 450M free contingency; entry-gate sunk cost USD 100-200M absorbed in envelopes, not contingency
    observed:  sunk cost consumes free contingency; exposures plus sunk cost vs USD 450M
MEDIUM CF-007  document: review plan Review 11 item 3 / Review 14 item 3
    canonical: compensation_and_currency_rule = inside the site-preparation envelope (USD 500M per-country share)
    observed:  its USD 1.0B site-preparation share
MEDIUM CF-008  document: executive summary (Risks, Action Orientation, Overall Takeaway)
    canonical: entry_condition_deadlines = vendor binding, site selection, inspector approval, provisional schedule Month 8 (2027-06-12)
    observed:  vendor binding by Month 7 (2027-05-12)
MEDIUM CF-009  document: review plan Review 2 item 2, Review 8 item 3, Review 13 item 1
    canonical: readiness_rehearsals = Filter-adequacy blind pre-test Month 8.5 (2027-06-27) with >=10 injected substitutions, target 9 of 10, halt scored exercises if <85%
    observed:  15+ substitutions, halt below 90%; pre-test Month 8.5 (2027-06-27) must precede finalization at Month 7.5 (2027-05-27)
MEDIUM CF-010  document: review plan Review 13 item 3
    canonical: staffing_buffers_and_tenure = Curtail below 80% of target staffing or any function under 2 FTE; 6-month site tenure with 2-month break
    observed:  all 350-500 staff vetted by Month 2 (2026-12-12)
MEDIUM CF-011  document: review plan Review 1 item 3, Review 12 item 3, Review 15 item 2, Review 4 item 2
    canonical: deadlock_escalation_and_aging = Deadlock = no consensus in 5 days; referee panel Days 5-8; principal review Days 8-13; >10 days impaired-confidence review; >15 days Stop candidate and automatic suspension
    observed:  discrepancy age >10 days triggers automatic suspension; principals at Day 5
MEDIUM CF-012  document: review plan Review 2/10 and premortem FM3
    canonical: detection_thresholds = false-positive limit TBD (proposed threshold)
    observed:  >3 total; <=2 per site; >=2 at any site; 3 per site
```

### 1. Go detection criterion: per-type vs mean with floor (🔴 High)

- **Canonical facts (detection_thresholds); project plan SMART Measurable; pitch Metrics; premortem A5:** Go: blind detection >=90% for each of 7 event types (false negatives <=10%); Modify 80% to <90%.
- **Self audit item 11 mitigation; review plan Review 14 item 2:** Acceptance = '>=90% mean across all 7 types with no type <85%'; Modify-acceptance example 'detection >85%'.
- **Why it conflicts:** A mean with an 85% per-type floor lets a weak event type pass Go, so the Go bar differs between documents and the verdict can flip depending on which text is used.
- **Suggested resolution:** Keep the canonical per-type rule: every one of the 7 event types at 90% or above from at least 10 injections, Modify at 80% to under 90%. Delete the mean/85% floor in the Verdict Specification and treat the '>85%' Modify-acceptance value as an example only.

### 2. Gate slippage: 90-day window compresses vs clock starts only after certification (🔴 High) — needs a project decision

- **User constraint / canonical phase_one_window_and_baseline; project plan Goal Statement and Time-bound:** The 90-day clock starts only after all entry conditions are certified, so slippage costs money, not test time. Phase One is Months 9-12 (2027-07-12 to 2027-10-12) and the verdict is at Month 12.25 (2027-10-20).
- **Review plan Review 1 item 1, Review 2 items 1-2, Review 4; project plan Time-bound (outer limit Month 12 = 2027-10-12) and canonical gate_checkpoint_and_outer_limit:** If the gate slips, the operational window 'compresses from 90 days to 30-60 days' and the exercise window 'from 70 days to 30-40 days'. Certification outer limit is Month 12 (2027-10-12) while the verdict stays at Month 12.25 (2027-10-20).
- **Why it conflicts:** A 90-day clock that starts at certification cannot be shortened by a late gate. Certification at Month 12 (2027-10-12) would put the end of Phase One at about Month 15 (2028-01-12), not before a verdict at Month 12.25 (2027-10-20). The documents mix a fixed calendar verdict with a floating clock.
- **Suggested resolution:** Keep the user constraint: the clock starts at certification and always runs 90 days with Days 1-5 reserved for the baseline. Define the verdict date as clock start plus 90 days plus about 0.25 month (Month 12.25 = 2027-10-20 holds only for a Month 9 = 2027-07-12 start). Remove the 'compressed window' statements. Slippage consequences are cost, political risk and the Month 12 (2027-10-12) outer limit.

### 3. What the USD 5B funds after the verdict (tranches 3-4 vs Phase Two vs cap) (🔴 High) — needs a project decision

- **Canonical tranche_schedule and total_budget_usd; executive summary Timeline and Budget; pitch Stakeholder Benefits:** 4 equal tranches of USD 625M per country; tranches 3-4 (Months 13, 16 = 2027-11-12, 2028-02-12) released only after a non-Stop verdict and new double-key authorization. Total budget USD 5B is a hard cap.
- **Review plan Review 14 items 1-2; self audit items 6 and 15; project plan Related Goals; pitch Long-term Vision:** 'The plan allocates USD 5.0B to Phase One only'; Phase Two needs USD 2.5-5.0B (estimate) additional appropriation, e.g. USD 2.5B for 8-12 sites; Modify trials USD 500M-1.0B. Phase Two scope is 'open, undefined'.
- **Why it conflicts:** Half the budget (tranches 3-4) is held until after a 90-day test, yet the same documents say the USD 5B covers Phase One only and that Phase Two needs new money outside the cap. It is unstated what tranches 3-4 pay for.
- **Suggested resolution:** A project decision is needed before the instrument is signed. Options: (a) tranches 3-4 are an explicit Phase Two or corrective-trial seed with scope criteria set before Month 11 (2027-09-12); (b) tranches 3-4 fund Phase One close-out and sustainment only, with unspent funds returned; (c) release only a minimum share and treat anything beyond USD 5B as a new appropriation outside this plan. Until decided, drop the '8-12 sites / USD 2.5B' figures as plan facts.

### 4. Funding source for entry-gate work before appropriations exist (🔴 High) — needs a project decision

- **Canonical entry_condition_deadlines, tranche_schedule and contingent_exposure_estimate; executive summary; review plan Review 1:** Appropriations are enacted and tranche 1 released at Month 7 (2027-05-12). Entry-gate sunk cost USD 100-200M (estimate) lands in the spending envelopes; USD 50M gate-readiness sub-account sits inside contingency.
- **Premortem FM1/FM4, review plan Reviews 4, 5, 10, 11; self audit items 6 and 18:** Work and spending start immediately: steering committee at Month 0.5 (2026-10-27), vetting of 200 candidates by Month 1.5 (2026-11-27), legal working group, gate-readiness draws of USD 20-40M 'before Month 6 (2027-04-12)', and 'supplementary' staffing/legal appropriations 'by Month 6 (2027-04-12)'.
- **Why it conflicts:** The envelopes, contingency and gate sub-account are funded by appropriations that exist only from Month 7 (2027-05-12), so sunk cost and draws before Month 7 (2027-05-12) have no identified source. A 'supplementary' appropriation also cannot precede the base appropriation, and any addition exceeds the USD 5B hard cap.
- **Suggested resolution:** Decide how Months 0-7 (2026-10-12 to 2027-05-12) work is financed, for example (a) a bridging or advance authority creditable against each country's USD 2.5B, (b) deferring non-essential spending to Month 7 (2027-05-12), or (c) accepting a smaller pre-Month 7 (2027-05-12) scope. State whether pre-Month 7 (2027-05-12) spend counts against the cap. Remove supplementary-appropriation remedies and use contingency draws or de-scoping instead.

### 5. Tranche 3-4 arithmetic (🟡 Medium)

- **Canonical tranche_schedule; executive summary Timeline and Budget:** 4 equal tranches of USD 625M per country = USD 1.25B combined per tranche, so tranches 3-4 = USD 1.25B per country = USD 2.5B combined.
- **Review plan Review 14 item 2; self audit items 15 and 6:** 'Tranches 3-4 (USD 1.25B combined)'; 'Tranche 1 (USD 1.25B for Months 9-12 = 2027-07-12 to 2027-10-12)'.
- **Why it conflicts:** USD 1.25B is one combined tranche, or two tranches for one country. Two combined tranches are USD 2.5B, so the text understates the amount held back by half. Tranche 1 is also released at Month 7 (2027-05-12), not for Months 9-12 (2027-07-12 to 2027-10-12).
- **Suggested resolution:** Correct to USD 2.5B combined (USD 1.25B per country) for tranches 3-4, and describe tranche 1 as USD 1.25B combined released at Month 7 (2027-05-12). Recompute any Phase Two or tranche-hold analysis that used the smaller figure.

### 6. Entry-gate sunk cost charged to contingency vs spending envelopes (🟡 Medium)

- **Canonical contingent_exposure_estimate; review plan Review 1; premortem FM1 and FM7:** Entry-gate sunk cost USD 100-200M (estimate) is absorbed within the spending envelopes, not contingency; identified exposures of USD 160-340M (estimate) are tested against USD 450M free contingency.
- **Self audit items 4 and 7; premortem A7:** Entry-gate sunk cost 'consumes free contingency before Phase One'; exposures including sunk cost consume 'up to 60%' of the USD 450M; failure trigger 'exposures plus entry-gate sunk cost exceed USD 450M'.
- **Why it conflicts:** The same USD 100-200M is charged to two different pools. The test for contingency adequacy changes depending on which treatment is used. Recomputed: 160-340M is 36-76% of 450M, so 'up to 60%' fits neither the canonical range nor a coherent sum.
- **Suggested resolution:** Keep the canonical split: sunk cost reduces envelope headroom, while contingency is tested only against USD 160-340M (36-76% of USD 450M). Correct self audit items 4 and 7 and the A7 trigger. Track the envelope headroom hit separately.

### 7. Per-country compensation envelope: USD 1.0B vs USD 500M (🟡 Medium)

- **Canonical compensation_and_currency_rule and envelope_allocation_usd:** Each government compensates its own operators and vendors from its own contribution inside the site-preparation envelope: USD 500M per-country share (envelope USD 1.0B total).
- **Review plan Review 11 item 3 and Review 14 item 3:** 'Each country compensates its operators and vendors from its USD 1.0B site-preparation share.'
- **Why it conflicts:** USD 1.0B is the combined envelope. Using it as the per-country ceiling doubles the headroom for compensation and weakens the parity and CNY-conversion analysis.
- **Suggested resolution:** Use USD 500M per country (the USD 1.0B envelope split 50/50) as the compensation ceiling and re-run the parity-divergence sensitivity on that base.

### 8. Vendor binding milestone: Month 7 (2027-05-12) vs Month 8 (2027-06-12) (🟡 Medium)

- **Canonical entry_condition_deadlines; project plan Mitigation Plans; review plan Review 3 action 1 and Review 13:** Vendor binding, site selection, inspector approval and provisional schedule by Month 8 (2027-06-12); project plan: 'Vendor binding by Month 8 (2027-06-12)'.
- **Executive summary Risks, Action Orientation and Overall Takeaway; review plan Review 3 action 3, Review 2 item 2, Review 9 item 3:** 'Vendor binding by Month 7 (2027-05-12)', 'Complete vendor binding and attestation validation by Month 7 (2027-05-12)', clean-room centers by Month 6.5 (2027-04-27).
- **Why it conflicts:** The same milestone has two month numbers across the summary, plan and review. Month 7 (2027-05-12) is also the instrument-signature month, and canonical supplier-list declarations are due only at Month 7.5 (2027-05-27), so binding before declarations cannot be complete. Clean rooms at Month 6.5 (2027-04-27) also differ from the canonical 'operational by Month 9 (2027-07-12)'.
- **Suggested resolution:** Use Month 8 (2027-06-12) for vendor binding (canonical), with supplier-list declarations at Month 7.5 (2027-05-27). If Month 7 (2027-05-12) is wanted as an internal target for the attestation-validation dry run and Month 6.5 (2027-04-27) for clean rooms, label them as internal early targets. Clean rooms operational by Month 9 (2027-07-12).

### 9. Filter pre-test halt threshold and sequencing against instrument lock (🟡 Medium)

- **Canonical readiness_rehearsals, evidence_schema, entry_condition_deadlines; executive summary; pitch; review plan Review 3 action 2:** Filter-adequacy blind pre-test at Month 8.5 (2027-06-27) with at least 10 injected substitutions, target 9 of 10, halt scored exercises if <85%. Instrument signed Month 7 (2027-05-12) with the evidence schema.
- **Review plan Review 2 item 2, Review 8 item 3, Review 13 item 1:** '15+ substitutions and halt if detection falls below 90%'; 'if simulation reveals <90% detection, escalate'; non-redactable fields locked in the instrument by Month 7.5 (2027-05-27), and Month 8.5 (2027-06-27) pre-test 'must precede' gateway finalization at Month 7.5 (2027-05-27).
- **Why it conflicts:** Two halt thresholds (85% and 90%) and two sample sizes are given for the same test. The sequencing text places a Month 8.5 (2027-06-27) test before a Month 7.5 (2027-05-27) step and proposes locking the schema after the Month 7 (2027-05-12) signature, while a failed pre-test would require renegotiating filter rules in an already signed instrument.
- **Suggested resolution:** Keep the canonical halt below 85%, at least 10 injections and target 9 of 10. A 90% result is the Go-level goal, not a halt. Lock the non-redactable schema in the instrument at signature (Month 7 = 2027-05-12), use the pre-test only to validate gateway implementation, and make any later filter change a double-key protocol change through an annex.

### 10. Staff vetting completion: Month 2 (2026-12-12) vs Month 8 (2027-06-12) vs 6-12 month norm (🟡 Medium)

- **Review plan Review 13 item 3 and Review 4 item 3 / Review 5 item 3 recommendations:** All 350-500 staff vetted by Month 2 (2026-12-12); initial 200 by Month 1.5 (2026-11-27).
- **Review plan Review 4 item 3 and Review 5 item 3; premortem A4/FM4; self audit item 5:** Vetting 'cannot be expedited below 2-3 months'; typical CI vetting 6-12 months; staffing deployed by the Month 8 (2027-06-12) dry-run; early warning is fewer than 200 candidates cleared by Month 2 (2026-12-12); start rule is 80% of target staff at Month 9 (2027-07-12).
- **Why it conflicts:** Completing 350-500 clearances in 2 months contradicts the 2-3 month minimum for a smaller batch and the 6-12 month typical cycle, and premortem treats fewer than 200 cleared at Month 2 (2026-12-12) as only an early warning.
- **Suggested resolution:** Treat 'at least 200 cleared by Month 2 (2026-12-12)' as the interim milestone and 'at least 80% of target staff cleared at Month 8 (2027-06-12), none of the functions under 2 FTE' as the gate. Remove 'all staff by Month 2 (2026-12-12)' and re-derive the dry-run window from actual vetting throughput (pilot of 10-20 candidates per country).

### 11. Escalation and suspension timers differ from canonical (🟡 Medium)

- **Canonical deadlock_escalation_and_aging and auto_suspension_triggers; premortem A3; pitch Ethical Considerations:** Deadlock = no consensus in 5 days; referees Days 5-8; principal review Days 8-13. Age above 10 days = impaired-confidence review only; above 15 days = automatic suspension absent a written principal decision. Above 5% of events disputed = automatic suspension.
- **Review plan Review 1 item 3, Review 12 item 3, Review 15 item 2, Review 4 item 2:** Suspension triggers e.g. 'unverifiable >3% or discrepancy age >10 days'; duty officers 'escalate to principals at Day 5'; findings 'over 10 days to principals within 24 hours with automatic reinstatement'; '>5% disputed events' treated as an impaired-confidence trigger.
- **Why it conflicts:** The review text moves principals to Day 5 (skipping the referee tier), makes day 10 a suspension trigger and mixes reinstatement language into an aging rule. Operators and auditors could not tell which clock governs suspension.
- **Suggested resolution:** Apply the canonical timers everywhere: referee panel Days 5-8, principals Days 8-13, impaired-confidence review at over 10 days, suspension at over 15 days or at over 5% of events disputed (separate from the 5 discrepancies per site per week formal review). Principal escalation is at 48 hours only for operator or vendor refusal and at 2 hours for CHALLENGE misclassification.

### 12. Limit on misclassified challenge events (false positives) (🟡 Medium) — needs a project decision

- **Canonical detection_thresholds and challenge_partition; pitch ('false-positive tolerance enforced'):** False-positive limit is TBD; tagged CHALLENGE events cannot trigger suspension, impaired-confidence review or KPI violation.
- **Review plan Review 2 item 3 and Review 10 item 3; premortem FM3:** 'More than 3 false positives' triggers impaired-confidence review; cap '<=2 per site per phase'; tripwire 'misclassifications >=2 at any site'; halt at 3 'per site' before scored exercises.
- **Why it conflicts:** Four incompatible limits (more than 3 total, at most 2 per site, 2 or more per site, 3 per site) are given for the same event. It is also unclear whether 'false positive' means a misclassified exercise event or a spurious detection in the KPI dashboard (false positives and negatives are a separate KPI).
- **Suggested resolution:** A decision is needed to define the metric (misclassified CHALLENGE events vs spurious findings) and a single limit and scope (per site or per program), validated during unscored calibration at Months 9.5-10.5 (2027-07-27 to 2027-08-27) and frozen at Month 10.5 (2027-08-27). Options: per-site cap with principal review on breach, or program-wide cap with auto-halt of injections. Until then mark all four figures as provisional/TBD.

## Summary

The plan is largely coherent on its core architecture: entry conditions, 50/50 funding, double-key governance, the 5/8/13-day escalation, the ledger thresholds and the exercise schedule are mostly consistent across documents and with the canonical facts. The main problems are in the review plan and self-audit, which restate several values loosely (Go detection rule, pre-test halt threshold, vendor binding month, per-country compensation base, tranche 3-4 amount, suspension timers). Three issues need project decisions rather than text fixes: what the second half of the budget funds after the verdict, how entry-gate work is financed before appropriations exist, and the limit on misclassified challenge events. The dating logic is also unresolved: the verdict is fixed at Month 12.25 (2027-10-20) while certification may slip to Month 12 (2027-10-12), and some text wrongly says a late gate shortens the 90-day window. The decision kernel is workable: all six questions have thresholds already stated in the documents.