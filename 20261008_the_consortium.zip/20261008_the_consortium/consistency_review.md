## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Have both governments signed the bilateral instrument and have both co-chairs ratified the four matched sites (2 US, 2 China, including at least one deliberately hard site per country) by double-key? | Instrument signed and 4 sites ratified at Month 2 (2026-12-08); each country's nominations came from 3-5 candidates and the sealed draw was held; written decomposition of domestic acts and vetting-agency commitments obtained by Month 0.5 (2026-10-23) | Signed instrument, co-chair ratification record and written domestic-act decompositions, Month 0.5 (2026-10-23) to Month 2 (2026-12-08) | Delay. The strict gate allows no conditional start, so every month of slip adds USD 50-100M holding cost (estimate). Re-run the shortlist for a withdrawn site (4-8 weeks, USD 50-200M, estimate). If this cannot be fixed, the Month 9 (2027-07-08) backstop leads to a double-key extend-or-stop decision. |
| 2 | Are both USD 2.5B contributions appropriated within the funding-timeliness rule, with the covered-equipment schedule adopted (Month 3 = 2027-01-08) and domestic access authority enacted (Month 3.5 = 2027-01-23)? | Tranche funded within 45 days plus 30-day cure (75 days total); variance <=5% in Months 0-3 (2026-10-08 to 2027-01-08); schedule adopted Month 3 (2027-01-08); authority enacted Month 3.5 (2027-01-23); no domestic act more than 4 weeks late | Treasury confirmations, enacted statutes or directives, and the fiscal-year clock reference agreed (see contradictions) by Month 3.5 (2027-01-23) | Delay with holding cost against contingency (150M cumulative is the premortem tripwire). If either tranche is withheld past day 75, Stop. If authority is more than 4 weeks late, escalate to co-chairs for an extend-or-stop decision. |
| 3 | Are operator and vendor binding agreements signed and the fallback pool (3-5 examiner labs per country, 2 clean-room facilities per geography) under contract, with the ledger stress-tested? | 4 of 4 operator agreements and >=80% of Tier-1 vendors (8-12 per site) signed by Month 4 (2027-02-08); examiner quotes <=USD 75k per exam and capacity of 5 exams per week; ledger passes divergence detection within 2 hours and 48-hour forensic findings on non-covered equipment | Signed agreements, examiner and clean-room MOUs and RFQs, ledger stress-test report, Month 4 (2027-02-08) | Delay, or replace the failing site from the shortlist (4-8 weeks, about USD 50-200M, estimate). If the fallback pool cannot be put in place, expect unverifiable equipment above 5% (Modify) or above 10% (Stop). If the combined fallbacks exceed the contingency, a project funding decision is needed. |
| 4 | Is the full inspector roster counterintelligence-approved with critical posts filled and a pre-approved bench in place? | All deployed inspectors approved; all critical posts filled; at least 80% of the planned 434 FTE roster (217 per country, 144 inspectors per country) filled; no single-person critical functions, full-time staff only | Vetting status by named individual, roster report from both governments, Month 5 (2027-03-08) | Delay. The 80% roster floor is a gate condition. Use the bench to fill vacancies, and a 4-week slip pushes calibration/lock to Month 5.5 (2027-03-23) or later. If critical posts remain unfilled at Month 9 (2027-07-08), reduce sites or stop. |
| 5 | Did calibration on non-covered equipment support the provisional thresholds, and were all Go/Modify/Stop thresholds double-key signed before the first blind exercise? | 50-100 events per site completed in Months 4-5 (2027-02-08 to 2027-03-08); detection >=70% for every event type; deviation from provisional targets <=20% or documented by recorded protocol change; thresholds locked at Month 5.5 (2027-03-23); scenario difficulty parity gap <=20% | Independent testing unit scorecards with confidence intervals and the signed threshold-lock document, Month 5.5 (2027-03-23) | If calibration shows detection of 70-90% or a deviation above 20%, make a recorded double-key threshold change and repeat. Or accept a likely Modify. Calibration detection below 70% for any event type calls for a design fix and delays the clock. The thresholds must not be moved down to hide a weak mechanism (needs co-chair decision). |
| 6 | Did Phase One (90 days, Months 6-9 = 2027-04-08 to 2027-07-08) show reciprocal access and credible detection, and does the Month 10 (2027-08-08) double-key decision meet the Go thresholds? | Detection >=90% unreported arrival, >=85% substitution, >=80% record falsification; false positives <5%; parity within 20%; unresolved discrepancies <10% of events; unverifiable <5% per site; zero unresolved ledger divergence >7 days; zero material asymmetric-access or IP/CI incidents | Independent testing unit results from up to 6 sessions per site, parity report, ledger divergence log and audit, Month 10 (2027-08-08) | Modify if a correctable weakness remains (detection 70% up to target, unverifiable 5-10%). Stop if access is asymmetric and unresolved, unverifiable >10% at a site, a government shields an operator, divergence is unresolved, funding is withheld or detection is <70%. Success covers only monitored changes at participating declared sites. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: executive_summary / review_plan / self_audit
    canonical: entry_gate_model = Strict gate: all 7 entry conditions fully certified by both sides, no partial or per-site conditional start
    observed:  conditional-start fallback permitting Phase One clock at each site once that site's entry conditions are met
HIGH CF-002  document: self_audit item 11
    canonical: go_other_thresholds = Go also requires parity within 20%; unresolved discrepancies <10%; unverifiable <5% per site; zero unresolved divergence >7 days; zero material asymmetric-access/IP incidents
    observed:  Go requires ≥3 of 5 primary KPI targets met
HIGH CF-003  document: executive_summary (also review_plan, self_audit)
    canonical: entry_conditions_milestones = Operator and vendor binding agreements Month 4 (2027-02-08); instrument and site selection Month 2 (2026-12-08)
    observed:  80% Tier-1 vendor agreements signed by Month 1 (2026-11-08); examiner pool by Month 1.5 (2026-11-23); forensic panel vetted by Month 0.5 (2026-10-23)
HIGH CF-004  document: canonical_facts
    canonical: contingency_worst_case_exposure_usd = About USD 515M, exceeding the USD 500M contingency by about 15M
    observed:  Supplemental appropriation of USD 25-50M suggested; no funding source for the USD 15M gap
HIGH CF-005  document: canonical_facts
    canonical: funding_timeliness = Each government funds its tranche within 45 days of fiscal-year start; late beyond 45 days plus 30-day cure counts as withheld (Stop)
    observed:  Fiscal-year start undefined and misaligned with the Month 3 (2027-01-08) appropriation milestone
MEDIUM CF-006  document: pitch
    canonical: contingency_worst_case_exposure_usd = About USD 515M, exceeding the USD 500M contingency by about 15M
    observed:  USD 500M absorbs identified fallbacks
MEDIUM CF-007  document: canonical_facts
    canonical: impaired_confidence_and_suspension = Automatic suspension at 7 days unresolved divergence or Tier 3 expiry; deadlock on contested identity suspends at 14 days
    observed:  7-day divergence, 14-day Tier 3 and 14-day deadlock suspension on overlapping cases
MEDIUM CF-008  document: review_plan / self_audit
    canonical: modify_and_stop_rules = Modify: unverifiable 5-10%. Stop: unverifiable >10% at a site
    observed:  Exceeding the 5% Go threshold triggers site failure
MEDIUM CF-009  document: review_plan / self_audit
    canonical: contingency_governance = USD 500M released only by double-key; fast lane up to USD 50M (25M per side) on joint signature within 5 business days
    observed:  Single-signature release; fast lane up to USD 100M; 'USD 50M per side'
MEDIUM CF-010  document: review_plan
    canonical: ledger_sync_and_detection_bounds = Divergence detected within 2 hours; sync divergence >4 hours escalated
    observed:  Hash comparison every 4 hours; automated alert if detection exceeds 4 hours
MEDIUM CF-011  document: executive_summary
    canonical: calibration_exercise = 50-100 events per site on non-covered equipment, Months 4-5 (2027-02-08 to 2027-03-08), excluded from Go evidence
    observed:  ≥50 blind-challenge scenarios per site delivered in Phase One; calibration 6 weeks
MEDIUM CF-012  document: pitch
    canonical: program_nature = Sovereign public-sector national-security verification program; revenue, investors, customers, ROI, sponsorship and market demand = Not applicable
    observed:  Call to Action, Collaboration Opportunities, extension to pharmaceuticals and other domains
```

### 1. Conditional-start fallback vs strict entry gate (🔴 High)

- **Canonical facts (entry_gate_model, gate_backstop); project_plan Time-bound:** Strict gate: all 7 entry conditions certified by both sides, no partial or per-site conditional start; backstop is double-key extend-or-stop with no conditional start
- **executive_summary Risks and Action Orientation; review_plan Review 1, 2, 9; self_audit items 4, 5, 14, 18, 20:** 'conditional-start fallback by Month 1 (2026-11-08)' and 'operationalize conditional-start fallback'; reviews and self-audit repeatedly recommend per-site clock initiation permitting each site to start once its own conditions are met
- **Why it conflicts:** A per-site or per-country conditional start is exactly what the strict gate excludes. The documents plan for a mechanism the entry gate forbids, and the Month 10 (2027-08-08) decision date assumes one common clock.
- **Suggested resolution:** Keep the strict gate. Remove the conditional-start fallback from the executive summary, review actions and self-audit mitigations. Replace it with the Month 9 (2027-07-08) double-key extend-or-stop backstop and, if wanted, a pre-clock dry run on non-covered equipment that does not start the 90 days. If the project wants a conditional start, that is a change to the user-level gate design and must be decided explicitly.

### 2. Go rubric: all thresholds vs '3 of 5 targets' (🔴 High)

- **Canonical facts (go_detection_thresholds, go_other_thresholds, modify_and_stop_rules); executive_summary success criteria:** Go requires detection targets by event type, false positives <5%, parity within 20%, unresolved <10%, unverifiable <5%, zero divergence >7 days, zero material asymmetric-access and IP/CI incidents; Stop if detection <70%
- **self_audit item 11 mitigation:** 'Go requires ≥3 of 5 primary KPI targets met... Modify requires ≥2 of 5... Stop if <2 targets met'
- **Why it conflicts:** A 3-of-5 rule would allow Go with failing detection or unverifiable equipment. It also puts Stop at fewer than 2 targets met, which differs from the canonical Stop conditions such as detection <70% and unverifiable >10%. It changes the go/no-go economics of the program.
- **Suggested resolution:** Keep the canonical rule: Go only if all thresholds are met. Modify applies when correctable weaknesses remain (detection 70% up to target, unverifiable 5-10%). Stop applies on the canonical Stop triggers. Delete the 3-of-5 counting rubric.

### 3. Vendor/forensic/vetting pre-binding dates vs gate order and canonical Month 4 (2027-02-08) (🔴 High)

- **Canonical facts (entry_conditions_milestones, vendor_fallback_pool, inspector_roster_rules); project_plan Dependencies:** Operator and vendor binding agreements and the examiner/clean-room pool are due Month 4 (2027-02-08). Sites are ratified and the instrument signed at Month 2 (2026-12-08). Counterintelligence vetting starts Month 0.5 (2026-10-23) and takes 14-16 weeks.
- **executive_summary Risks, Action Orientation, Overall Takeaway; review_plan Review 3, 8, 13; self_audit items 4, 13, 17:** 80% of Tier-1 vendors pre-bound and examiners pre-qualified by Month 1/1.5 (2026-11-08, 2026-11-23), with 8-12 vendors per site identified by Month 0.5 (2026-10-23). Vetting is 'initiated at Month 0 (2026-10-08)'. The forensic panel is recruited and vetted by Month 0.5 (2026-10-23) and locked by Month 1 (2026-11-08). 'If all three lock by Month 1 (2026-11-08)' the clock starts on schedule.
- **Why it conflicts:** Vendors cannot be bound per site before the sites are selected (Month 2 = 2026-12-08) or the instrument is signed (Month 2 = 2026-12-08). Month 1 (2026-11-08) conflicts with the Month 4 (2027-02-08) gate in the same executive summary. A panel cannot pass 14-16 week counterintelligence vetting by Month 0.5 (2026-10-23) or Month 1 (2026-11-08). Vetting also starts at Month 0.5 (2026-10-23), not Month 0 (2026-10-08).
- **Suggested resolution:** Keep the canonical Month 4 (2027-02-08) binding deadline. Reword the Month 0.5-1.5 items as early outreach and letter-of-intent targets (not signed site-specific agreements) and as early-warning tripwires. Move forensic-panel lock-in to after vetting, or allow provisional appointment pending clearance. Start vetting at Month 0.5 (2026-10-23).

### 4. Contingency worst case exceeds reserve under a hard cap (🔴 High) — needs a project decision

- **Canonical facts (total_budget_usd, contingency_governance); project_plan SMART Achievable:** USD 5.0B is a hard cap, fully allocated to envelopes. Contingency of USD 500M is released only by double-key.
- **Canonical contingency_worst_case_exposure_usd; executive_summary Timeline and Budget; review_plan Review 2, 7, 14:** Worst case about USD 515M exceeds the reserve by about USD 15M (free contingency about -15M). Reviews suggest a 'supplemental funding (USD 25-50M)', a supplemental appropriation request or scope reduction.
- **Why it conflicts:** A supplemental appropriation breaks the hard cap and the exact 50/50 split. Scope reduction is not mapped to any envelope. No document states who funds the shortfall or which fallback is cut first.
- **Suggested resolution:** A project decision is needed. Options: (a) accept scope reduction, with a double-key priority order of fallbacks (for example gate delay, then site replacement, then examiner overrun); (b) reallocate from other envelopes by double-key within the cap, 50/50; (c) formally raise the cap, which is a change to a user constraint. Do not assume a supplement.

### 5. Funding-timeliness clock vs appropriation milestone (🔴 High) — needs a project decision

- **Canonical facts (funding_timeliness); premortem FM7:** A tranche late beyond 45 days of fiscal-year start plus a 30-day cure (75 days) counts as funding withheld (Stop)
- **Canonical entry_conditions_milestones; review_plan Review 10; self_audit item 6:** Appropriations are secured at Month 3 (2027-01-08). Treasury fiscal calendars are 'not aligned' (US and Chinese cycles differ), and fiscal-year start is not defined for the plan.
- **Why it conflicts:** If the clock runs from a fiscal-year start that falls before or near Month 0 (2026-10-08) (for example a US year already begun), day 75 can fall before the Month 3 (2027-01-08) appropriation milestone, so Stop could fire before the plan expects funding. The reference date is undefined, so the Stop trigger cannot be tested.
- **Suggested resolution:** Decide which event starts the clock for each government (fiscal-year start, enactment of the appropriation, or the Month 3 = 2027-01-08 milestone). Record it in the instrument and align FM7 and the KPI dashboard. Until then the Stop trigger stays unverifiable.

### 6. Pitch says USD 500M contingency absorbs fallbacks (🟡 Medium)

- **executive_summary Timeline and Budget; Canonical facts; project_plan Key Risks:** Worst-case fallback exposure is about USD 515M, exceeding the USD 500M reserve by about USD 15M with no surge margin
- **pitch Risks and Mitigation Strategies:** 'A contingency fund of USD 500M (double-key release, fast lane up to USD 50M) absorbs identified fallbacks.'
- **Why it conflicts:** The pitch presents as fact what the plan itself says fails in the coincident worst case. Readers of the pitch (appropriators) would miss the shortfall.
- **Suggested resolution:** Reword to 'covers each identified fallback individually; the coincident worst case (about USD 515M) exceeds it by about USD 15M (estimate)'.

### 7. Ledger-divergence suspension clock vs referee/deadlock and Tier 3 clocks (🟡 Medium) — needs a project decision

- **Canonical facts (impaired_confidence_and_suspension, deadlock_definition); project_plan engagement strategies:** Automatic suspension at 7 days unresolved divergence. Deadlock lasts more than 7 days, then the referee gives an opinion within 5 days. Deadlock on contested identity suspends at 14 days.
- **Canonical discrepancy_clock_tiers and ledger_identity_forensics; premortem FM1/FM9:** Tier 3 clock is 14 days, extendable by 50% (up to 21 days). Forensic panel 48 hours plus co-chair 24 hours. Referee opinion is reached only about day 12.
- **Why it conflicts:** For a contested identity divergence, the 7-day suspension fires before the deadlock path (day 7 + 5 days) or the 14-day Tier 3 clock can run. It is unclear whether 7 or 14 days governs, and the referee step is unreachable for such cases.
- **Suggested resolution:** A decision is needed on precedence, for example: divergence suspension applies only to technical sync divergence while contested identity follows Tier 3/deadlock timing; or the referee window is shortened to fit inside 7 days. Record the choice in the canonical facts.

### 8. Unverifiable 5% treated as site failure (🟡 Medium)

- **Canonical facts (modify_and_stop_rules); premortem FM2 stop rule:** Go if unverifiable <5%; Modify at 5-10%; Stop only if >10% at a site (after day-15 extension)
- **review_plan Review 2 item 2, Review 5; self_audit item 17:** 'unverifiable equipment accumulates... exceeding the <5% Go threshold... and failing one or both sites'; 'will exceed the 5% Go threshold, triggering site failure'
- **Why it conflicts:** Exceeding 5% moves the outcome to Modify, not to site failure. Failure is above 10%.
- **Suggested resolution:** Replace 'fails the site' with 'forces Modify' for 5-10%, and keep site failure for >10%.

### 9. Fast-lane contingency release authority (🟡 Medium)

- **Canonical facts (contingency_governance); project_plan Mitigation Plans:** Contingency released only by double-key; fast lane up to USD 50M total (25M per side) on joint signature within 5 business days
- **review_plan Reviews 2, 11, 12, 14; self_audit item 6:** 'single-signature release up to USD 50M is binding without co-chair counter-approval'; fast lane raised to USD 100M; 'USD 50M per side (USD 25M per country)'; escrow of USD 50-100M per side
- **Why it conflicts:** Single-signature release breaks double-key governance for budgets. USD 100M and USD 50-100M per side do not match the USD 50M cap, and 'USD 50M per side' contradicts 'USD 25M per country' in the same sentence.
- **Suggested resolution:** Keep joint-signature release up to USD 50M total (25M per side). Any increase is a double-key budget change. Delete the single-signature wording.

### 10. Ledger divergence detection interval (🟡 Medium)

- **Canonical facts (ledger_sync_and_detection_bounds); executive_summary deliverables:** Divergence detected within 2 hours; sync divergence >4 hours escalated; sync target <1 hour
- **review_plan Review 16 item 1 and Review 6 item 2:** Hash-comparison algorithms run every 4 hours on both copies; alert if detection exceeds 4 hours
- **Why it conflicts:** A 4-hour comparison cycle cannot guarantee detection within 2 hours, and a 4-hour detection alert is looser than the 2-hour bound.
- **Suggested resolution:** Set the comparison interval to no more than 1 hour (or continuous) and alert at 2 hours for detection. The 4 hours applies to escalation of sync divergence.

### 11. Scenario counts: Phase One vs calibration vs exercise cap (🟡 Medium)

- **Canonical facts (exercise_design_and_cap, calibration_exercise):** Formal exercises are capped at 2 sessions per site per month (up to 6 per site, 24 across 4 sites in 90 days). The 50-100 events per site are calibration events in Months 4-5 (2027-02-08 to 2027-03-08), excluded from the Go evidence base.
- **executive_summary Key Deliverables; self_audit items 12; review_plan Review 3:** Phase One delivers '≥50 blind-challenge detection scenarios per site across 7 event types'. Calibration is described as 6 weeks, but Months 4-5 (2027-02-08 to 2027-03-08) span about 4 weeks.
- **Why it conflicts:** The 50 events per site belong to calibration, not Phase One. If ≥50 per site were Phase One scenarios, it is unclear how they fit 6 sessions per site. With 7 event types, about 7 per type would give very weak confidence for 80-90% thresholds.
- **Suggested resolution:** State the number of scenarios per session and per event type for Phase One. Assign the 50-100 events to calibration only. Correct the calibration length to the Month 4-5 (2027-02-08 to 2027-03-08) window, or move the window. Mark the statistical power of the detection thresholds as provisional.

### 12. Pitch uses promotional framing and out-of-scope expansion (🟡 Medium)

- **Canonical facts (program_nature, scope_and_success_statement); project_plan Relevant:** Program is a sovereign national-security program; promotional calls to action and investor/partnership framing are 'Not applicable'. Scope excludes comprehensive AI governance.
- **pitch Project Overview, Collaboration Opportunities, Long-Term Vision, Call to Action, Metrics:** 'revolutionary' mechanism; 'Collaboration Opportunities... co-creation'; 'Call to Action'; extension to semiconductors, supply chains, pharmaceuticals; 'asymmetry triggers automatic suspension'; 'parity between US and China results within 20%'
- **Why it conflicts:** The pitch adopts a promotional and partnership register the user constraint excludes and implies scope beyond declared-equipment change verification. Asymmetry leads to Stop (unresolved), not automatic suspension. The parity metric is access parity, not results parity.
- **Suggested resolution:** Mark the call to action and collaboration opportunities 'Not applicable'; replace them with mission justification and appropriations governance. Remove the extension to other technologies. Align asymmetry handling and the parity wording with the canonical thresholds.

## Summary

The plan is largely consistent on its core structure: budget envelopes, 50/50 split, staffing (434 FTE, 217 per country), phase windows, double-key governance and the Month 10 (2027-08-08) decision all reconcile. The main problems come from later documents that kept pre-reconciliation or advisory ideas. These include the conditional-start fallback, a 3-of-5 Go rubric, Month 1 (2026-11-08) vendor pre-binding, single-signature or 100M contingency release, and a pitch that says USD 500M "absorbs" fallbacks. Three gaps need real project decisions: how the USD 15M worst-case contingency shortfall is financed under the hard cap, when the 45+30-day funding clock starts, and which clock governs a contested ledger divergence. The pitch also drifts into promotional and out-of-scope language that the user constraints exclude.