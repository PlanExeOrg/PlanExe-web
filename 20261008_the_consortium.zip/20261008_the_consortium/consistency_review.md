## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Have both governments signed the bilateral instrument (Month 1 = 2026-11-08) and, by Month 2 (2026-12-08), enacted domestic access authority and deposited equal first tranches (USD 625M each), with no gate more than 2 weeks late? | Instrument signed Month 1 (2026-11-08); access authority and appropriation Month 2 (2026-12-08); equal deposits. Gate slip over 2 weeks means a co-chair summit within 5 days. Tranche delay over 14 days means co-chair escalation. Delay over 30 days or unequal deposits unresolved is a Stop trigger (proposed threshold). | Signed instrument containing the deadlock, suspension and mechanical-verdict clauses (Month 1 = 2026-11-08). Enacted access authority and equal tranche deposits confirmed by the Joint Budget Authority (Month 2 = 2026-12-08). | Slip of 2 weeks or less: continue with a summit. Longer slip: invoke the pre-agreed re-scope to 2 pairs rather than extend. Funding withheld over 30 days: Stop (withheld funding). |
| 2 | Are the neutral facility (at least 1,000 sq m) and at least 2 matched, parity-confirmed site pairs approved by Month 3 (2027-01-08), with operators committed to 4-hour staging access and 48-hour window notice? | Facility site chosen Month 1 (2026-11-08) and operational Month 3 (2027-01-08). Each pair meets staging at least 500 sq m, 24-hour access, lift at least 50 tons, and at least 2 maintenance events per month. A pair with asymmetric access is excluded, and fewer than 2 pairs is not viable (proposed thresholds). | Host-country MOU (about Month 1.5 = 2026-11-23), hardening certification (Month 3 = 2027-01-08), sealed reciprocal-access audit reports, co-chair pair approval and signed operator commitments (by Month 3 = 2027-01-08). Dry-run access times are measured before the Month 5.5 (2027-03-23) gate. | Drop the asymmetric pair and re-scope to 2 pairs (48 exercises). Activate the secondary facility host. Below 2 pairs, delay or stop; shielding is a hard Stop. |
| 3 | Is projected unverifiable or excluded equipment at entry within limits after the vendor-refusal ladder (only one 8-12 week rung can finish before Month 6 = 2027-04-08)? | At most 5% overall; over 10% at a site or overall is a hard Stop trigger; 5-10% is a Modify-level weakness (proposed thresholds). | Vendor refusals documented by Month 3 (2027-01-08). Vendor-participation registry published Month 4 (2027-02-08). Unverifiable/excluded share computed per site at Month 4-5 (2027-02-08 to 2027-03-08). | Exclude the unresolved items and publish the registry. Over 10% at a site: drop that site or re-scope to 2 pairs. Over 10% overall: Stop or re-scope. |
| 4 | Are the inspectorates certified and able to staff the shift minimum at no fewer than 2 pairs by Month 5.5 (2027-03-23)? | At least 80% of about 180 staff per country certified by Month 5 (2027-03-08) and full deployment by Month 5.5 (2027-03-23). All 6 positions filled on every shift. Monthly attrition below 5% (estimate and proposed thresholds). | Clearance and certification counts (Month 2 early warning, Month 5 = 2027-03-08 checkpoint). Roster simulation. Pilot training cohort results. | Release the surge pool and extend training, which slips the clock. If fewer than 2 pairs can be staffed at Month 5.5 (2027-03-23), re-scope or Stop. |
| 5 | Is the pre-clock calibration passed: evidence-rule false positives 7-13% and false negatives under 5%, key-recovery rehearsal successful, all seven event types piloted, and thresholds plus the mechanical scoring rule locked by Month 5.5 (2027-03-23)? | False positives 7-13% (deviation of 3-5 points is flagged; over 5 points needs adjustment and a second cohort). Key recovery within 24 hours. Both cohorts showing false positives above 18% means Stop or re-scope (proposed thresholds). | Calibration Confidence Memo (Month 5.5 = 2027-03-23). Escrowed rule (Month 4.5 = 2027-02-23). Historical validation on 100-200 events per site (Months 4.5-5). Pilot and rehearsal (Month 5 = 2027-03-08). Independent statistician sign-off. | Run the second cohort. If it cannot finish by Month 5.5 (2027-03-23), delay the clock; the 2-week gate-slip rules apply. If calibration is still failing, reduce scope or Stop. Do not start the 90-day clock with unvalidated rules. |
| 6 | Do Phase One results meet the pre-registered Go rule: at least 4 of 5 criteria including detection and parity, fewer than 5 open material discrepancies, no Stop trigger and intervals not straddling a threshold? | Detection at least 70% planned and 50% unplanned. False positives at most 10%. Unverifiable at most 5%. Parity at least 85%. No discrepancy older than 21 days. Modify: 3 of 5 or straddling intervals. Stop: 2 or fewer, or any hard Stop trigger (proposed thresholds). | Independent scoring of 54 exercises over Months 6-9 (2027-04-08 to 2027-07-08). Verdict scored and published within 5 days (about Month 9.2 = 2027-07-14). Final decision by Month 9.5 (2027-07-23). | Modify: rework route, with funding OPEN. Stop: document what broke. Success covers only monitored changes at participating declared sites. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: canonical_facts
    canonical: verdict_logic = Go: at least 4 of 5 criteria, intervals not straddling a threshold
    observed:  Expected detection 70-85% with ±22% planned-class interval
HIGH CF-002  document: executive summary / review_plan / self_audit
    canonical: pre_clock_calibration = Rule and thresholds locked and entry gate certified Month 5.5 (2027-03-23)
    observed:  Thresholds locked by Month 1 (2026-11-08) / Month 2.5 (2026-12-23)
HIGH CF-003  document: executive summary / self_audit / review_plan
    canonical: verdict_logic = Go: at least 4 of 5 including detection and parity; Modify 3 of 5; Stop 2 or fewer
    observed:  Go lower bound ≥75% at 90% CL; Modify 55-75%; Stop <55%
HIGH CF-004  document: executive summary / review_plan
    canonical: exercise_load = 2 pairs: 4 per site per month = 48 total; 36 (3 per month) is below the minimum
    observed:  2 pairs, 60-day test preserving the 54-exercise load
HIGH CF-005  document: canonical_facts
    canonical: entry_slip_backstop = Gate slip over 2 weeks: summit within 5 days; not certified by Month 9 (2027-07-08): Stop/re-scope
    observed:  4-week re-scope backstop; summit within 48 hours; 2-week slip triggers USD 100-200M depletion
MEDIUM CF-006  document: review_plan / premortem / self_audit
    canonical: tranche_structure = 20% (500M each) on Go/Modify verdict
    observed:  Tranche 4 released on verdict publication, decoupled from outcome
MEDIUM CF-007  document: review_plan / self_audit
    canonical: site_financing_per_unit = about USD 167M per site ceiling (USD 500M per country over 3 sites)
    observed:  USD 350M compensation per country vs USD 30-50M per site; '3-4 sites exhaust USD 500M'
MEDIUM CF-008  document: self_audit
    canonical: hard_stop_triggers = Stop if unverifiable equipment is over 10% at a site or overall
    observed:  Unverifiable/excluded at most 5% per site or site dropped (hard Stop); 3-rung rule
MEDIUM CF-009  document: review_plan / self_audit / executive summary
    canonical: contingency_rules = Over 75% = joint review with external audit; envelope over 120% = supplemental appropriation (veto point)
    observed:  Over 75% or 120% = Stop trigger; draws up to USD 50M without co-chair approval
MEDIUM CF-010  document: self_audit / review_plan / pitch
    canonical: entry_gate_timeline = Matched pairs approved Month 3 (2027-01-08)
    observed:  Parity locked Month 4-5 (2027-02-08 to 2027-03-08); Statements of Cooperation Month 5.5 (2027-03-23)
MEDIUM CF-011  document: review_plan
    canonical: inspection_corps_arithmetic = 3 shifts; 99 inspection corps per country
    observed:  2-shift 16-hour model; 300 required; 201 gap
MEDIUM CF-012  document: self_audit / review_plan
    canonical: pre_clock_calibration = Second cohort if needed, completed by Month 5.5 (2027-03-23)
    observed:  40-60 synthetic cases per site; 4-week delay accepted
```

### 1. Go verdict is statistically near-unreachable under the 'intervals not straddling a threshold' rule (🔴 High) — needs a project decision

- **Canonical verdict_logic; executive summary Feedback 3; pitch Go threshold:** Go requires 'intervals not straddling a threshold'. Exec summary: lower confidence bound must exceed the Go threshold.
- **Canonical statistical_limits; assumptions Risk 8:** Planned class n about 16, p=0.7: about ±22%. Pooled about ±12%. Detection is expected at 70-85%.
- **Why it conflicts:** With ±22% on the planned class, a lower bound of at least 70% needs an observed rate of about 92% or more (about 82% or more pooled). Expected detection is 70-85%, so Go is practically unreachable and the Modify default is almost guaranteed. The 'credible detection' test is therefore not really a three-way verdict.
- **Suggested resolution:** Decide before the instrument is signed. Options: (a) keep the strict rule and state openly that Go needs about 90%+ observed detection; (b) use one-sided or 90% bounds on a pooled statistic; (c) add exercises; (d) accept Modify as the expected outcome. Do not leave this implicit.

### 2. When the verdict thresholds are locked (🔴 High)

- **Executive summary (Deliverables, Risks, Feedback 3); review_plan Reviews 5, 9; self_audit #8:** Thresholds and mechanical scoring rule locked in the bilateral instrument by Month 1 (2026-11-08), or by Month 2.5 (2026-12-23). Review 7 says locked by Month 6 (2027-04-08).
- **Canonical pre_clock_calibration; project_plan Measurable:** Rule and thresholds are locked at Month 5.5 (2027-03-23) after the Month 5 (2027-03-08) pilot. Thresholds are 'validated on pilot data'.
- **Why it conflicts:** Thresholds cannot be both locked before the Month 5 (2027-03-08) pilot and recalibrated from pilot data. The lock dates also vary (Month 1, 2.5, 3, 5.5, 6 = 2026-11-08, 2026-12-23, 2027-01-08, 2027-03-23, 2027-04-08) across documents.
- **Suggested resolution:** Keep Month 5.5 (2027-03-23). Month 1 (2026-11-08) locks only the scoring method (mechanical rule, interval handling, no-amendment clause). Numeric thresholds are locked at Month 5.5 (2027-03-23) after the pilot. Publish before the Month 6 (2027-04-08) clock.

### 3. Verdict bands described in incompatible forms (🔴 High)

- **Canonical verdict_logic and detection_thresholds; project_plan Measurable (omits 'including detection and parity'):** Go: at least 4 of 5 criteria including detection and parity; Modify 3 of 5; Stop 2 or fewer. Go detection threshold is 70%.
- **Executive summary Risks; self_audit #8 and #11; review_plan Review 9:** Go at lower bound of 75% (90% CL), Modify 55-75%, Stop below 55%. Exec summary says 70% ±15% straddles Go, Modify (55-75%) and Stop.
- **Why it conflicts:** Two incompatible scoring schemes are in play: a criteria count and detection-only bands. The Go detection value is 70% in one and 75% in the other. The Modify band overlaps Go. The ±15% example matches no canonical interval (±12 pooled, ±22 planned, ±25 unplanned). The 90% vs 95% CL also differs.
- **Suggested resolution:** Use the canonical criteria-count logic. State the interval rule (straddling means Modify) per criterion at one confidence level. Delete the detection-only bands (75% lower bound, 55-75% Modify, Stop below 55%). Use the canonical intervals in examples.

### 4. Scope-reduction fallback: '2 pairs, 60-day test' vs exercise minimums (🔴 High)

- **Canonical exercise_load:** Fallback to 2 pairs (4 sites) needs 4 exercises per site per month, giving 48 in 90 days. At 3 per month only 36 (about 5 per type) is below the minimum of 6.
- **Executive summary Overall Takeaway; review_plan Review 3 #1, Review 2 #3, Review 5 #2:** Scope reduction (2 pairs, 60-day test) 'preserves the 54-exercise load'. A 50-60 day window gives 32-36 exercises.
- **Why it conflicts:** A 60-day test with 2 pairs cannot reach 54 exercises. At most about 32 are possible, below the 6-per-type minimum and with wider intervals. The backstop undermines the credibility it is meant to protect. The 2-pair fallback is only viable over the full 90 days.
- **Suggested resolution:** Define the fallback as 2 pairs over the full 90 days with 4 exercises per site per month (48 total). Remove '60-day test' and the claim that 54 exercises are preserved. If the clock is shortened, state that the sample falls below the minimum and the result cannot support Go.

### 5. Entry-gate slip backstop: deadline, response time and authority (🔴 High) — needs a project decision

- **Canonical entry_slip_backstop; project_plan Time-bound; pitch Risks and Call to Action:** Entry gate not certified by Month 9 (2027-07-08) means a formal Stop/re-scope decision.
- **pitch Risks; review_plan Review 3 and 12; executive summary Timeline:** Pitch: '2-week escalation and 4-week re-scope backstop'. Review 12: summit within 48 hours. Exec: a gate slip over 2 weeks 'triggers USD 100-200M contingency depletion'. Review 12: a third-country authority decides scope reduction.
- **Why it conflicts:** Month 9 (2027-07-08) is when the 90-day Phase One window ends, so a certification deadline then is not a deadline. It conflicts with a 4-week re-scope backstop and with a Month 6 (2027-04-08) clock start. The summit timing differs (5 days vs 48 hours). The USD 100-200M cost belongs to an 8-week slip, not a 2-week trigger. A binding third-party scope-reduction power also conflicts with double-key governance.
- **Suggested resolution:** Keep the 2-week gate trigger and 5-day summit. Fix one certification long-stop date earlier than the end of the 90 days, and decide it explicitly. Give any scope-reduction authority a rule pre-approved by both countries rather than an overriding third party. Attach the USD 100-200M figure to 8-week slips only.

### 6. Tranche 4 release vs Go/Modify verdict and decoupling (🟡 Medium) — needs a project decision

- **Canonical tranche_structure and post_phase_funding_open_decision; review_plan Review 5 #3:** Tranche 4 (20%, USD 500M each) is released on a Go/Modify verdict. Post-Phase funding for rework or Phase Two is OPEN.
- **review_plan Reviews 11 and 14; premortem FM6; self_audit #6 and #15:** Release tranche 4 on 'verdict publication, not pending rework scope', 'separating tranche release from outcome'. Rework is 'USD 250-400M within the existing USD 5B'.
- **Why it conflicts:** A tranche tied to Go/Modify cannot also be independent of the outcome. After a Stop it would be unreleased. It is unclear what a USD 1B final tranche pays for after the Month 9 (2027-07-08) clock ends. The rework figure of USD 250-400M is unsupported, and the 'within existing USD 5B' option contradicts the OPEN status.
- **Suggested resolution:** Decide and record in the instrument: what tranche 4 funds (wind-down, archive, rework), whether a Stop releases a wind-down portion, and whether rework is within the USD 5B or needs new appropriations. Until decided, keep canonical wording and mark the USD 250-400M estimate as an estimate.

### 7. Operator compensation ceiling vs allocation and arithmetic (🟡 Medium)

- **Canonical site_financing_per_unit:** Site preparation plus operator/vendor compensation is about USD 167M per site ceiling (USD 500M per country over 3 sites).
- **review_plan Review 11 #1, Review 14 #2; self_audit #7:** Proposed split of USD 150M hardening and USD 350M compensation per country, against a compensation ceiling of USD 30-50M per site. 'USD 50-75M exhausts USD 500M by 3-4 sites.' 'USD 50M per site exhausts a USD 167M envelope in 3 sites.'
- **Why it conflicts:** USD 350M per country over 3 sites is about USD 117M per site, against a USD 30-50M ceiling (USD 90-150M per country). Recomputed: USD 500M divided by USD 50-75M covers about 7-10 sites, not 3-4. USD 50M is below USD 167M, so it does not exhaust it. The claimed breach (USD 50-100M overrun) is not supported.
- **Suggested resolution:** Pick one compensation basis. Either keep the USD 30-50M ceiling with a smaller compensation sub-envelope, or reset the ceiling to match USD 350M per country. Correct the arithmetic. Treat the overrun as unquantified (estimate) until operator cost proposals exist.

### 8. Vendor-refusal disposition rules vs canonical thresholds (🟡 Medium)

- **Canonical vendor_refusal_fallback and hard_stop_triggers; premortem A7, FM7:** Only one 8-12 week rung can finish before Month 6 (2027-04-08). Unresolved equipment is unverifiable or excluded and counts against the share. Hard Stop over 10% at a site or overall; 5-10% is Modify.
- **self_audit #11:** 'Equipment attempting at least 3 rungs = unverifiable; fewer than 3 = excluded; both excluded from the Go gate.' Unverifiable/excluded share at most 5% per site 'or site is dropped (hard Stop)'.
- **Why it conflicts:** Three rungs take 24-36 weeks and cannot complete before the clock. Excluding both categories from the gate hides the unverifiable share that the Go threshold measures. The per-site 5% hard Stop contradicts the canonical 10% hard Stop and the 5-10% Modify band.
- **Suggested resolution:** Use canonical rules. Unresolved equipment at entry counts as unverifiable or excluded, within the 5% Go threshold. Over 10% at a site or overall is a hard Stop. Remove the 3-rung rule and the 5% hard Stop.

### 9. Contingency percentages, draw triggers and draw authority (🟡 Medium)

- **Canonical entry_delay_cost_fit and contingency_rules; user constraint:** 8-week slip costs USD 100-200M, which is 20-40% of the 500M contingency and 22-50% of the free contingency. Draw triggers: over 75% means joint review; over 120% of an envelope means supplemental appropriation. Budgets require double-key.
- **review_plan Reviews 1, 5, 6, 15; self_audit #6, #7:** USD 100-200M is '20-40% of free contingency'. An 8-week slip uses 'free contingency USD 300-350M (60-70%)'. Over 75% drawn or an envelope over 120% is a 'Stop Trigger'. A Finance Authority approves draws up to USD 50M 'without co-chair approval'.
- **Why it conflicts:** The percentage bases are wrong or inconsistent (USD 300-350M is not USD 100-200M). Stop triggers are added that the canonical rules make review or veto points. Approving draws without co-chair approval conflicts with double-key authorization for budgets. Exec also attaches the 8-week cost to a 2-week slip.
- **Suggested resolution:** Use canonical percentages. Restate the over-75% and over-120% triggers as review or supplemental-appropriation points. Require any pre-authorized draw limits to be set by both co-chairs in the instrument and executed jointly by both countries' budget officers. Say which pot funds the adjudication surge: the compression reserve is for entry negotiation and vetting only.

### 10. Parity definition and operator commitments come after matched-pair approval (🟡 Medium)

- **Canonical tranche_structure and entry_gate_timeline; project_plan Dependencies:** Matched pairs are approved at Month 3 (2027-01-08) with parity confirmed, and tranche 2 is released on that approval.
- **canonical other_go_thresholds; self_audit #3, #10, #16; review_plan Reviews 4, 8, 9; pitch Call to Action:** Parity definition TBD, locked at Month 1, 4 or 5 (2026-11-08, 2027-02-08, 2027-03-08) depending on the document. Operator Statements of Cooperation are due Month 3 (2027-01-08) (pitch), Month 5.5 (2027-03-23) (review, self-audit), and are described as both non-binding and embedded binding in the instrument by Month 1 (2026-11-08).
- **Why it conflicts:** Parity and operator cooperation cannot be confirmed at Month 3 (2027-01-08) if they are defined or committed at Month 4-5 (2027-02-08 to 2027-03-08).5. The aggregation of the four sub-indicators into 'at least 85%' is also not defined.
- **Suggested resolution:** Lock the parity definition, aggregation method and operator commitments before Month 3 (2027-01-08) matched-pair approval. Keep Month 5.5 (2027-03-23) only for the dry-run confirmation. State whether the commitments are binding.

### 11. Inspector shift model and headcount (🟡 Medium)

- **Canonical inspection_corps_arithmetic and staffing_per_country:** Per country: 3 sites × 3 shifts × 6 positions = 54; ×1.4 = 76; +30% = 99 inspection corps. About 180 staff per country (360 total) including surge and specialists.
- **review_plan Reviews 1 #3, 2 #3, 15:** The plan 'assumes 2-shift 16-hour coverage at 180 per country'. Continuous 24/7 coverage 'requires about 300 inspectors per country, a 201-inspector gap'. '360 deployed inspectors'.
- **Why it conflicts:** The plan uses 3 shifts with 24/7 coverage. 99 is the inspection corps, not the 180 total staff. 360 is all staff, not inspectors. The 300 requirement and the night-gap analysis rest on a shift model the plan does not use. Personnel-cost text also treats Months 6-9 (2027-04-08 to 2027-07-08) as 4 months and quotes USD 116M instead of 115M for the 4-month full-strength window (Month 5.5-9.5).
- **Suggested resolution:** Restate review items using the 3-shift, 99-corps model. Replace '360 inspectors' with '360 staff'. Align the personnel cost windows: about USD 86M for 3 months and about USD 115M for 4 months.

### 12. Evidence-rule validation scope and re-test time (🟡 Medium)

- **Canonical pre_clock_calibration and evidence_rule_calibration; executive summary; premortem A2 (20-30 synthetic cases per site):** Validation on 100-200 historical events per site. A second cohort, if needed, completes by Month 5.5 (2027-03-23). Rule is in escrow at Month 4.5 (2027-02-23).
- **self_audit #2 and #10; review_plan Review 8 #2:** 40-60 (or 40-50) adversarial synthetic cases per site, with a 4-week delay accepted if deviation exceeds 5 points. Second cohort also described as a rule 'halt' with a 4-week re-test.
- **Why it conflicts:** Documents give two different synthetic-case counts (20-30 vs 40-60) with no justification. The pass criterion depends on the count. A 4-week re-test cannot fit between the Month 5 (2027-03-08) pilot and the Month 5.5 (2027-03-23) lock (about 2 weeks) without delaying the clock, which then triggers the gate-slip rules.
- **Suggested resolution:** Pick one synthetic-case count (the larger number is more defensible given false-negative targets below 5%) and mark it a proposed threshold. State that a second cohort is run within the Month 4.5-5.5 window or the clock slips and the 2-week gate-slip procedure applies. Consider moving escrow earlier.

## Summary

The plan is coherent on its core design: equal envelopes, double-key governance, the entry-gate sequence and the pre-clock calibration schedule. The later review layers repeatedly depart from the canonical facts on threshold lock dates, verdict bands, scope-reduction mechanics, percentage bases for contingency, and shift and cost models. The most serious problems change the go/no-go economics: the strict 'no straddling' Go rule is almost unreachable at the stated sample sizes, the thresholds are locked before the pilot meant to validate them, and the fallback and Month 9 (2027-07-08) certification backstop do not preserve statistical validity. Tranche 4 and post-Phase funding remain a genuine missing decision. Most other items are repairable by aligning text with canonical values.