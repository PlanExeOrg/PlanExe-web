### 1. Tracking Entry-Condition Certification Progress and Reciprocity Gate Status
**Monitoring Tools/Platforms:**

  - Entry-Condition Steering Committee Weekly Tracking Dashboard (spreadsheet with milestone status, blockers, escalation flags)
  - Bilateral Instrument and Legal Authority Checklist (signed documents, domestic legislation status tracker)
  - Inspector Vetting Status Tracker (counterintelligence clearance progress by candidate, agency delays flagged)
  - Site Selection and Operator Binding-Agreement Log (contracts signed, ratification status)

**Frequency:** Weekly steering-committee review (Months 0–6 = 2026-10-08 to 2027-04-08); escalation to political leadership if any condition lags >4 weeks behind plan

**Responsible Role:** Bilateral Executive Steering Committee (both co-chairs jointly), with designated entry-condition owners (US and Chinese) for each of the 7 mandatory conditions

**Adaptation Process:** If a single condition (e.g., inspector vetting, domestic legislation) extends >4 weeks beyond plan, co-chairs immediately escalate to political leadership with a decision memo: either expedite the lagging condition, or authorize a conditional/partial-start fallback (e.g., pre-clock dry run on non-covered equipment). If delay persists to Month 9 (2027-07-08), co-chairs invoke the gate backstop and double-key decide to extend Phase One start or stop. Any entry-condition failure is escalated to BESC and reflected in monthly KPI reporting.

**Adaptation Trigger:** Any single entry condition >4 weeks behind plan (Month 2 = 2026-12-08 baseline for site selection, Month 3 = 2027-01-08 for appropriations/authority, Month 4 = 2027-02-08 for operator/vendor binding, Month 5 = 2027-03-08 for inspector approval); or any condition not certified by Month 6 (2027-04-08) triggers the Month 9 (2027-07-08) backstop review for extend-or-stop decision

### 2. Monitoring Critical Success Factor: Ledger Divergence and Forensic Identity Resolution
**Monitoring Tools/Platforms:**

  - Bilateral Ledger Synchronization Dashboard (real-time or hourly update of sync latency, divergence counts, reconciliation status per site)
  - Joint Forensic Panel Findings Log (contested identities escalated, evidence layers analyzed, findings issued, status of resolution)
  - Discrepancy Clock Tracking (Tier 1/2/3 escalation status, clock expirations, extensions granted, automatic suspensions triggered)
  - Ledger Divergence Event Report (monthly summary: divergence count, detection time, resolution time, unresolved cases)

**Frequency:** Real-time divergence detection and escalation within 2 hours of divergence discovery; forensic panel activation on-demand (estimated 1–2 per week per site); monthly divergence and forensic summary report by Independent Auditor

**Responsible Role:** US and Chinese National Operations Units (Chiefs of Ledger Operations, jointly for forensic escalation); Joint Forensic and Evidence Adjudication Panel (for identity findings); Independent Auditor (for monthly reporting on ledger integrity)

**Adaptation Process:** Divergence >4 hours unresolved escalates to both Ledger Chiefs within 30 minutes for technical root-cause analysis and recovery. If divergence persists >7 days unresolved, automatic impaired-confidence status fires and the site enters escalation protocol; lifting requires double-key co-chair authorization and must be documented in the ledger. Any unresolved ledger divergence is flagged in monthly KPI reporting and counted as an audit exception. If forensic panel consensus fails on a contested identity, the matter escalates to co-chairs for decision within 24 hours; if co-chairs cannot agree, a neutral referee panel provides a non-binding opinion within 5 days.

**Adaptation Trigger:** Ledger divergence >4 hours unresolved (triggers technical escalation to Ledger Chiefs); divergence >7 days unresolved (automatic impaired-confidence status and escalation to BESC); contested equipment identity unresolved by forensic panel within 48 hours (escalation to co-chairs); Tier 2 or Tier 3 discrepancy clock expiry without forensic resolution

### 3. Monitoring Critical Success Factor: Vendor Refusal Escalation and Equipment Unverifiability
**Monitoring Tools/Platforms:**

  - Vendor Cooperation Status Tracker (pre-binding agreement status, signed vs. pending, refusal alerts)
  - Vendor Refusal Escalation Ladder Log (each refusal tracked day-by-day: request, operator escalation, examiner notification, exam scheduling, report, unverifiable classification)
  - Unverifiable Equipment Count Dashboard (equipment count by site, reason for unverifiable status, percentage of deployed)
  - Independent Examiner and Clean-Room Facility Utilization Report (pool availability, actual engagement, cost tracking against budget)

**Frequency:** Weekly vendor-cooperation status review (Months 1–4 = 2026-11-08 to 2027-02-08 during pre-binding phase); daily escalation ladder tracking once a refusal is reported; monthly unverifiable-equipment count report

**Responsible Role:** US and Chinese National Operations Units (Head of Operator Engagement, jointly for vendor coordination); Joint Forensic Panel (for unverifiable classification review); US and Chinese Technical Leads (for independent-examiner engagement)

**Adaptation Process:** Vendor refusal activates the 10-day escalation ladder automatically: if no fallback evidence is available by day 10, equipment is marked unverifiable. If unverifiable count approaches or exceeds 5% of deployed at a site, a bilateral review convenes to assess whether alternative evidence routes (clean-room, validated attestation) can recover the equipment or whether the site will fail the Go threshold. If a major vendor (affecting 5–15% of equipment) refuses cooperation, both co-chairs are notified within 24 hours and decide whether to escalate to operator/government level or invoke the vendor-refusal Stop condition (equipment unverifiable >10% per site). Monthly unverifiable counts are tracked in the KPI dashboard and feed the final Go/Modify/Stop decision.

**Adaptation Trigger:** Vendor refusal reported (activates 10-day escalation ladder); vendor refusal affecting 5% or more of site equipment (escalates to BESC for remediation decision); unverifiable equipment reaching 5% of deployed per site (triggers bilateral review of Go-threshold risk); unverifiable >10% at a site (Stop condition candidate)

### 4. Monitoring Critical Success Factor: Blind-Challenge Detection Performance and Exercise Integrity
**Monitoring Tools/Platforms:**

  - Independent Testing Unit Sealed Exercise Schedule and Execution Log (exercises run, timing, scenarios, real-time incident tracking)
  - Detection Scorecard by Event Type (monthly: unreported arrivals, substitutions, record falsification, delayed access, disputed identity, vendor refusal, reluctant operator; true positives, false negatives, false positives per type)
  - Monthly Detection Rate Summary and Threshold Deviation Report (observed rates vs. locked thresholds for Go decision, deviation flags)
  - Exercise Audit and Fairness Report (post-exercise independent auditor sign-off on blind integrity, scoring objectivity, scenario realism)

**Frequency:** Per-exercise real-time incident logging and immediate post-exercise scoring (within 72 hours); monthly detection-rate compilation and threshold-deviation analysis; quarterly fairness and integrity audit by Independent Auditor

**Responsible Role:** Independent Testing Unit (Scoring Lead, Site Coordinators, Red-Team Facilitators; reports to BESC); Independent Auditor (quarterly fairness review); Bilateral Executive Steering Committee (monthly threshold-deviation review)

**Adaptation Process:** Monthly detection-rate data is compiled and compared against locked thresholds (90% unreported arrival, 85% substitution, 80% falsification, <5% false positives, proposed). If observed detection for any event type falls >10% below locked threshold by Month 7 (2027-05-08), BESC is notified and reviews whether corrective training, protocol clarification or evidence-layer adjustment is needed. If detection remains <70% for a category at Month 8 (2027-06-08), that feeds into the final Go/Modify/Stop decision as evidence of a weakness. If any exercise is discovered to be compromised (advance notice to inspectors, unplanned facility disruption), the Independent Auditor flags it as void and recommends re-execution or exclusion from the evidence base. Monthly detection reports are published in the KPI dashboard.

**Adaptation Trigger:** Observed detection rate for any event type falls >10% below locked threshold by Month 7 (2027-05-08); any exercise detection <70% at any site; post-exercise audit discovers exercise contamination or fairness violation (void the exercise, recommend re-run or exclusion from evidence base); disparity in detection rates between US and Chinese inspectors suggests asymmetric training or capability (triggers bilateral review and potential rebalancing of inspector roles)

### 5. Monitoring Critical Success Factor: Inspector Conduct and Reciprocal-Access Parity
**Monitoring Tools/Platforms:**

  - Monthly Access-Log Audit Report (inspector zone-boundary compliance, device-access patterns, location-tracking validation, anomaly flags)
  - Tier 1/2/3 Conduct Incident Log (infraction severity, investigation status, resolution/removal recommendation, status tracking)
  - Reciprocal-Access Parity Dashboard (inspector deployment per country per site, zone-access hours, witnessed events, escalation authority—all metrics compared for >20% asymmetry)
  - Inspector Rotation and Rapid-Replacement Pool Status (rotation schedule compliance, surge-pool readiness, clearance expiry tracking)

**Frequency:** Monthly access-log audits and conduct-incident review (conducted by Bilateral Conduct Panel); monthly reciprocal-access parity metrics (compared by Conduct Panel); ad-hoc Tier 2/3 incident investigation (within 12–24 hours of report)

**Responsible Role:** Bilateral Inspector Conduct and Reciprocity Oversight Panel (co-chairs per country, counterintelligence staff); US and Chinese National Operations Units (liaison and rapid-replacement coordination)

**Adaptation Process:** Monthly access-log audits flag any zone-boundary infractions, device-access anomalies or location-tracking gaps. Tier 1 infractions (minor, first offense) are handled as written warnings within the panel; Tier 2 (repeated or deliberate violation) escalates to formal notice and Conduct Panel review within 24 hours; Tier 3 (material espionage risk, serious unauthorized access) triggers immediate removal investigation and removal recommendation to co-chairs within 12 hours. Reciprocal-access parity metrics are compared monthly; if asymmetry >20% (proposed threshold) is detected, Conduct Panel flags it to BESC within 5 days with remediation options (expand one side's access, rebalance escalation authority). If asymmetry persists >10 days, an automatic counter-restriction activates (the advantaged side voluntarily narrows its access to match the disadvantaged side). Any substantiated Tier 3 incident or material parity breach is escalated to BESC and tracked as a potential Go-decision risk factor.

**Adaptation Trigger:** Tier 2 or Tier 3 conduct incident reported (escalation within 12–24 hours for investigation); reciprocal-access asymmetry >20% detected (5-day BESC notification and remediation planning); Tier 3 removal recommendation (immediate co-chair authorization required); repeated Tier 2 incidents by same inspector (automatic escalation to Tier 3 investigation)

### 6. Monitoring Budget Timeliness and Contingency Drawdown
**Monitoring Tools/Platforms:**

  - Monthly Spending Variance Report (actual vs. planned spending per envelope; flags variance >5%; cost-center reconciliation)
  - Contingency Fund Release Log (all contingency tranches >USD 25M tracked; fast-lane releases <USD 50M documented)
  - Tranche Timing Tracker (each USD 625M (US) and USD 625M (China) quarterly tranche release and obligation timeline; 45-day appropriation-release window monitored)
  - Deficit or Overrun Alert Dashboard (cumulative spending vs. remaining budget by envelope and month; red-flag if overrun threatened)

**Frequency:** Monthly spending-variance audit (by Independent Auditor); monthly tranche-release timing review (by Bilateral Executive Steering Committee); quarterly comprehensive budget-reconciliation audit

**Responsible Role:** US and Chinese National Operations Units (financial officers, spending authorization); Independent Auditor (variance flagging and monthly reporting); Bilateral Executive Steering Committee (contingency authorization)

**Adaptation Process:** Each month, actual spending is reconciled against planned spending per envelope. If variance >5% (proposed threshold) is detected in Months 0–3 (2026-10-08 to 2027-01-08), the Independent Auditor flags the variance to BESC within 5 days; the relevant National Operations Unit must provide explanation and corrective action plan within 10 days. If variance persists or repeats, it signals budget-execution risk and may trigger early contingency release or spending restraint in other envelopes. If tranche release is delayed beyond 45 days (plus a 30-day cure window = 75 days total), the delay counts as funding withheld (a Stop condition). If contingency drawdown approaches USD 400M of the USD 500M total (80% utilization), BESC is alerted and must review whether surge capacity is being depleted faster than planned; if contingency is fully drawn before Month 8 (2027-06-08), BESC must authorize either austerity measures or notify both governments of funding shortfall risk.

**Adaptation Trigger:** Spending variance >5% in Months 0–3 (2026-10-08 to 2027-01-08) (5-day escalation to BESC); tranche late beyond 75 days (45-day release window + 30-day cure) (counts as funding withheld, Stop condition); contingency utilization >80% (alerts BESC for surge-capacity review); any single cost overrun >USD 100M (escalates to BESC for authorization)

### 7. Monitoring Go/Modify/Stop Decision Threshold Readiness and KPI Dashboard Convergence
**Monitoring Tools/Platforms:**

  - Locked Thresholds Validation Document (all Go/Modify/Stop decision thresholds, double-key signed, baseline and validated by calibration exercise, recorded in ledger)
  - Monthly KPI Dashboard (detection rates, false rates, identity confidence, sync divergence, reciprocal-access parity, discrepancy age, unverifiable counts, vendor refusals, funding timeliness, audit exceptions; all metrics compared to locked thresholds with deviation flags)
  - Final-Decision Evidence Summary Report (compiled at Month 9 = 2027-07-08, summarizing all 90-day data against Go/Modify/Stop rubric)

**Frequency:** Thresholds locked by Month 5.5 (2027-03-23), before first formal blind exercise; monthly KPI dashboard published by Independent Auditor (Months 6–9 = 2027-04-08 to 2027-07-08); final decision package assembled at Month 9 (2027-07-08)

**Responsible Role:** Bilateral Executive Steering Committee (threshold lock and Go/Modify/Stop decision); Independent Testing Unit (detection-rate data); Independent Auditor (KPI compilation and final-decision package)

**Adaptation Process:** Locked thresholds are published pre-Phase One (by Month 5.5 = 2027-03-23) with full justification documented in the bilateral ledger. During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08), monthly KPI data is compiled and compared to thresholds; any material deviation (detection <70%, false positives >10%, unverifiable >10%, unresolved divergence >7 days, reciprocal-access asymmetry >20%) is flagged in real-time reporting and escalated to BESC. At Month 9 (2027-07-08), a comprehensive evidence summary is prepared, comparing all 90-day metrics to the locked thresholds. If performance exceeds Go thresholds, BESC authorizes a Go decision (Phase Two or continuation). If performance is correctable (Modify criteria: detection 70–85%, unverifiable 5–10%), BESC issues Modify with remediation timeline. If performance triggers Stop criteria (asymmetric access, unverifiable >10%, divergence unresolved, funding withheld, detection <70%), BESC issues Stop and closure procedures.

**Adaptation Trigger:** Thresholds not locked by Month 5.5 (2027-03-23) (escalates to BESC for emergency lock; formal clock start may be delayed); any monthly KPI showing detection <70%, false positives >10%, or unverifiable >10% (real-time escalation to BESC and trigger for corrective action or early warning); final-decision readiness at Month 9 (2027-07-08) showing any Stop criteria met (automatic escalation to co-chairs for Go/Modify/Stop final decision at Month 9.5 = 2027-07-23)