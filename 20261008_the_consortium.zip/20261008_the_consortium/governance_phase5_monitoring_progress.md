### 1. Key Performance Indicator (KPI) Tracking Against Project Targets
**Monitoring Tools/Platforms:**

  - Monthly KPI Dashboard (reconciled by Evidence and Ledger Integrity Committee)
  - Sealed Independent-Score Tracking (Threshold Calibration Panel)
  - Equipment-Identity Confidence Spreadsheet (Evidence and Ledger Integrity Committee)
  - Ledger Synchronization and Divergence Log (Ledger Node Operators)

**Frequency:** Daily operational KPI tracking; weekly informal co-chair review; monthly formal co-chair decision session (1st of each month)

**Responsible Role:** Evidence and Ledger Integrity Committee (daily collection); Project Management Office (aggregation); Bilateral Steering Committee Co-Chairs (monthly formal review and threshold-sufficiency assessment)

**Adaptation Process:** Monthly co-chair decision sessions review KPI results (detection rates, identity confidence, parity variance, ledger sync latency, unverifiable-equipment count, unresolved-discrepancy age) against frozen thresholds. KPI shortfalls >5 percentage points from threshold trigger investigation and corrective-action assignment. If a KPI breaches threshold (e.g., identity confidence drops below 95%, unverifiable exceeds 3%, parity variance exceeds 15%), automatic escalation to co-chairs within 2 hours with recommended mitigation (staffing surge, filter renegotiation, site access rebalancing). Adaptation decisions recorded in ledger with bilateral sign-off.

**Adaptation Trigger:** Monthly: Any KPI result diverges >5 percentage points from target; Daily: identity confidence <95%, unverifiable >3%, parity variance >15%, ledger sync >4 hours, unresolved discrepancy >10 days. Immediate escalation if auto-suspension threshold is approached (5 consecutive days of unverifiable >3%, divergence >5%, denial >15% for 2 consecutive weeks).

### 2. Critical Success Factor Monitoring: Equipment Identity Confidence and Attestation Validation
**Monitoring Tools/Platforms:**

  - Attestation-Key Validation Confidence Log (Vendor and Operator Binding Unit)
  - Identity Corroboration Analysis Spreadsheet (Bilateral Technical Referees Panel)
  - Equipment Classification and Unverifiable Status Tracker (Evidence and Ledger Integrity Committee)

**Frequency:** Real-time tagging at intake; daily escalation of units approaching unverifiable status (identity confidence trending below 95%); weekly summary to co-chairs; mandatory checkpoint at Month 10 (2027-08-12) for all vendor attestations

**Responsible Role:** Vendor and Operator Binding and Compliance Unit (attestation validation); Bilateral Technical Referees Panel (identity dispute resolution); Evidence and Ledger Integrity Committee (confidence scoring and escalation)

**Adaptation Process:** Equipment identity confidence is scored at intake and maintenance events on a scale of 0-100%. Units below 95% are flagged and corroboration layers reviewed (attestation, customs records, physical marks). If two independent layers cannot validate identity (e.g., attestation timestamp misaligned with customs entry by >2 hours), escalation to Bilateral Technical Referees panel within 24 hours. Referees issue dual-signed fact statement within 3 days confirming identity or classifying unit as unverifiable. If unverifiable count per site reaches 3%, automatic escalation to co-chairs for site-failure determination. Attestation keys unvalidated by Month 10 (2027-08-12) automatically escalate all equipment from that vendor to unverifiable status.

**Adaptation Trigger:** Identity confidence <95% on any unit; attestation validation failure or timeout at Month 10 (2027-08-12); two-layer corroboration mismatch; unverifiable count reaching 3% of declared units per site (material threshold, automatic site failure).

### 3. Critical Success Factor Monitoring: Blind Detection Capability and Challenge Exercise Results
**Monitoring Tools/Platforms:**

  - Sealed Challenge-Scenario Catalog (hash-committed before Phase One)
  - Blind-Exercise Injection and Detection Log (Independent Testing Unit)
  - Detection-Rate Summary by Event Type (Detection-Measurement Analysts per country)
  - Sealed Independent-Score Sheets (Threshold Calibration Panel)

**Frequency:** Calibration exercises (Months 9.5-10.5 = 2027-07-27 to 2027-08-27): daily injection and response tracking; unscored preliminary summary weekly. Scored exercises (Months 10.5-11.5 = 2027-08-27 to 2027-09-27): daily injection and detection tracking; sealed scores submitted end of each week. Sealed-score comparison at Month 11.75 (2027-10-05); final verdict-mapping analysis before Month 12.25 (2027-10-20) decision

**Responsible Role:** Independent Testing Director and Red-Team Leads (injection and scenario management); Detection-Measurement Analysts per country (blind-scenario detection tracking and sealed scoring); Threshold Calibration and Verdict Panel (score comparison and verdict-evidence mapping)

**Adaptation Process:** Calibration exercises (unscored) measure baseline detection rates by event type (7 types: unreported arrival, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal, reluctant operator). If calibration detection rate diverges >10 percentage points from provisional assumption (e.g., 80% actual vs. 90% assumed), Threshold Calibration Panel recommends threshold adjustment. Thresholds frozen by Month 10.5 (2027-08-27) before scored exercises begin. Scored exercises (Month 10.5-11.5 = 2027-08-27 to 2027-09-27) test against frozen thresholds (>=90% detection per event type for Go). Each national team independently and sealed scores detection outcomes. Divergence >10 percentage points between national scores is documented but both scores treated as valid; divergence itself becomes a transparency metric reported alongside verdict. If detection rate <85% in calibration exercises, investigation of filter adequacy or inspector presence issues; corrective action required or Phase One delayed.

**Adaptation Trigger:** Calibration-exercise detection rate <85% per event type (halt scored exercises for filter or training remediation); scored-exercise detection rate <90% per event type at Month 11.75 (2027-10-05) (Modify or Stop verdict); sealed-score divergence >10 percentage points (transparency metric, escalate if divergence reflects systemic difference in inspector training or filter application).

### 4. Critical Success Factor Monitoring: Reciprocal Access Parity
**Monitoring Tools/Platforms:**

  - Reciprocal-Access Denial and Delay Log (Project Management Office, tagged by reason code)
  - Site-Equivalent Activity Accounting by Matched Pair (Bilateral Operations Directors)
  - Monthly Parity-Variance Report (Project Management Office to co-chairs)

**Frequency:** Real-time denial logging at point of request; reason-code explanation required within 24 hours if denial exceeds tolerance. Weekly parity-variance summary by matched-site pair; monthly formal parity-variance review by co-chairs. Trip-point review within 48 hours if variance >15% or unexplained denials >5 per month

**Responsible Role:** Project Management Office and Operational Execution Team (daily access-request tracking and reason-code collection); Bilateral Operations Directors (weekly parity-variance analysis); Bilateral Steering Committee Co-Chairs (monthly formal review and trip-point authorization)

**Adaptation Process:** Each access request (inspector hours, staging-area inspections, evidence access, equipment-movement authorization) is logged in the ledger with accept/deny outcome and reason code. Denials within tolerance (proposed: +/-10% variance between matched sites) require explanation within 24 hours. If denials exceed tolerance (>15% variance sustained for 2 consecutive weeks, or >5 unexplained denials per month), escalation to co-chairs within 48 hours. Co-chairs review reason codes and authorize corrective action: rebalance inspection schedule, resolve operational bottleneck, or escalate to principals for parity-threshold amendment. Disputed denials (one country claims justified, other disputes) go to Bilateral Technical Referees panel for fact statement. Sustained parity variance >15% at Month 12 (2027-10-12) becomes a Stop-criterion candidate (asymmetric access).

**Adaptation Trigger:** Monthly parity variance >10% (tolerance band exceeded, requires explanation); >15% sustained for 2 consecutive weeks (automatic impaired-confidence review trigger); >5 unexplained denials per month (escalation to co-chairs within 48 hours); any denial with no acceptable reason-code within 24 hours (escalation to bilateral operations directors).

### 5. Critical Success Factor Monitoring: Ledger Divergence and Evidence Integrity
**Monitoring Tools/Platforms:**

  - Ledger Synchronization Checkpoint Log (hourly signed hash-chain validation by Ledger Node Operators)
  - Divergence Detection and Reconciliation Tracker (Evidence and Ledger Integrity Committee)
  - Neutral-Party Digest Custodian Archive (offline backup and forensic-recovery escrow)

**Frequency:** Hourly signed checkpoint validation; divergence detection within 4-hour KPI latency; reconciliation closure attempt within 24 hours. Daily ledger health check (15 minutes); weekly divergence-reconciliation review if any divergences occurred; emergency escalation within 2 hours if latency exceeds 4-hour KPI or sync latency exceeds 1 hour

**Responsible Role:** US and China Ledger Node Operators (checkpoint validation and local event recording); Divergence Reconciliation Lead (bilateral reconciliation authority); Evidence and Ledger Integrity Committee (daily oversight and KPI monitoring)

**Adaptation Process:** Each national ledger copy records events locally with immediate timestamp. Signed hash-chain checkpoints are exchanged hourly. On divergence detection (within 4-hour window), both operators independently review diverged events and attempt reconciliation within 24-hour deadline. If cause is clear (late-arriving event, corrected entry), reconciliation is logged and closed. If cause is unclear or disputed, unresolved status is recorded and escalated to co-chairs with both operators' independent assessments. Facility incidents (power loss, access anomalies, personnel changes) are logged in the ledger within 1 hour and trigger Facility Security Review Panel investigation within 4 hours. Unresolved divergence >10 days automatically triggers impaired-confidence review and potential site suspension; >15 days becomes a Stop-criterion candidate.

**Adaptation Trigger:** Synchronization latency exceeds 1 hour (alert); divergence detection exceeds 4-hour KPI (escalate to co-chairs and Facility Security Panel); reconciliation not closed within 8 hours (escalate to co-chairs); unresolved divergence >5 discrepancies per site per week (formal reconciliation review); unresolved divergence age >10 days (automatic impaired-confidence review); >15 days (Stop criterion triggered without bilateral principal override).

### 6. Risk Monitoring: Vendor Refusal and Equipment Unverifiability
**Monitoring Tools/Platforms:**

  - Pre-Qualified Vendor Registry and Refusal Tracking (Vendor and Operator Binding Unit)
  - Attestation-Validation Result Summary (Accredited Examiners, both countries)
  - Clean-Room Examination Testing Queue and Outcomes (Vendor and Operator Binding Unit)

**Frequency:** Vendor refusal events logged immediately; escalation within 24 hours to Vendor and Operator Binding Unit and bilateral co-chairs within 5 days. Attestation-validation checkpoint at Month 10 (2027-08-12) (mandatory validation deadline). Weekly vendor-compliance review (Months 7-8 = 2027-05-12 to 2027-06-12 preparation phase); immediate escalation meetings if a vendor refuses or operator consent is withdrawn

**Responsible Role:** Vendor and Operator Binding and Compliance Unit (vendor-refusal assessment and escalation); Accredited Examiners (attestation validation and confidence reporting); Bilateral Steering Committee Co-Chairs (refusal-handling authorization if disagreement between countries)

**Adaptation Process:** Vendor refusal or attestation-key compromise is escalated to Vendor and Operator Binding Unit within 24 hours. Unit proposes disposition: vendor-supervised testing, filtered evidence, accredited clean-room examination, validated attestation, or unverifiable status. If refusal handling diverges between countries (one recommends clean-room, other recommends unverifiable), escalation to co-chairs within 5 days. Co-chairs authorize disposition or escalate to principals. Clean-room examination centers accept refusing vendors' equipment for supervised testing without exposing source code. If attestation keys cannot be independently validated by Month 10 (2027-08-12), all equipment from that vendor automatically escalates to unverifiable status. If unverifiable count reaches >3% of a site's declared equipment, automatic site failure and Stop decision.

**Adaptation Trigger:** Vendor refusal or attestation-validation failure (immediate escalation to Vendor and Operator Binding Unit and co-chairs within 24 hours); refusal-handling disagreement between countries (co-chair decision required within 5 days); attestation unvalidated by Month 10 (2027-08-12) deadline (automatic unverifiable status); unverifiable equipment exceeding 3% per site (automatic site failure, Stop criterion).

### 7. Risk Monitoring: Deadlock and Unresolved Discrepancies (Governance Gridlock)
**Monitoring Tools/Platforms:**

  - Co-Chair Deadlock and Escalation Log (Bilateral Steering Committee)
  - Unresolved-Discrepancy Age Tracker (Project Management Office, daily age calculation)
  - Escalation Timer Status Report (Project Management Office)

**Frequency:** Contested findings logged immediately; deadlock status tracked from Day 1 through Day 5 (co-chair consensus window). Automatic escalation timer initiated at Day 5 if no consensus. Weekly unresolved-discrepancy age report to co-chairs (items >5 days, >10 days, >15 days flagged separately). Escalation-timer dashboard refreshed daily during Phase One

**Responsible Role:** Project Management Office (contested-finding logging and age tracking); Bilateral Steering Committee Co-Chairs (deadlock resolution, Days 1-5); Bilateral Technical Referees Panel (fact-statement generation, Days 5-8); Principal-Level Review (final decision, Days 8-13)

**Adaptation Process:** When co-chairs cannot reach consensus on a site finding or equipment-identity ruling within 5 days, automatic escalation to Bilateral Technical Referees panel within 24 hours (Day 6). Referees review sealed evidence and issue dual-signed advisory fact statement within 3 days (by Day 8). If referees reach consensus, fact statement goes back to co-chairs; if not, unsigned draft with both assessments escalates to principals. Principals must render a decision within 5 calendar days (by Day 13) or status quo defaults to heightened inspection (not suspension) while escalation continues. Unresolved discrepancies are tracked and aged in the KPI dashboard. Age >10 days triggers automatic impaired-confidence review and potential site suspension; >15 days becomes a Stop-criterion candidate (findings unresolved due to procedural gridlock rather than technical merits).

**Adaptation Trigger:** Contested finding at Day 5 with no co-chair consensus (automatic escalation to referees within 24 hours); discrepancy age >10 days (automatic impaired-confidence review trigger); >15 days (Stop criterion triggered unless principals render decision within that window).