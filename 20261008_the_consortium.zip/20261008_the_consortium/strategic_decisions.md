## Primary Decisions
The vital few decisions that have the most impact.


The five Critical levers address the plan's core tensions. Reciprocity Gate Stringency covers validity versus delay. Evidence Layer Weighting covers detection versus gaming. Inspection Zone Boundary Design covers coverage versus IP exposure. Challenge Exercise Independence covers credibility versus disruption. Threshold Calibration covers principled versus tuned verdicts. The High levers cover execution, including ledger integrity, vendor refusal, escalation, staffing and vetting. No major dimension is missing, though funding-timeliness governance is only implicit.

### Decision 1: Reciprocity Gate Stringency
**Lever ID:** `223d1d0c-a010-4db9-a7a0-d8ccbfe91ea7`

**The Core Decision:** Defines the entry certification that separates setup work from the 90-day Phase One test. Its scope covers the signed instrument, appropriations, domestic access authority, approved sites and inspectors, operator and vendor participation, and the provisional schedule. Success is measured by the time from Month 0 (2026-10-08) to certified start, the number of authority gaps found before the clock, and zero setup failures later logged as verification failures.

**Why It Matters:** This sets how completely the bilateral instrument, appropriations, domestic access authority, site selection, inspector approvals, operator and vendor participation, and covered-equipment schedule must be in place before the 90-day clock starts. A strict gate protects the validity of the test but can delay the start indefinitely. A loose gate starts the clock sooner but lets setup failures be recorded as verification failures.

**Strategic Choices:**

1. Require every entry condition to be fully satisfied and independently certified by both sides before the Phase One clock starts, with no partial-start exceptions.
2. Allow a conditional start in which the clock begins at each site once the conditions for that site are met, while the final decision requires all matched sites to complete the full period.
3. Run a pre-clock dry-run gate where both sides exchange access credentials and test the legal authority on non-covered equipment, so that authority gaps appear before the formal clock and the entry certification.

**Trade-Off / Risk:** A strict gate keeps the 90-day result clean, but it hands whichever side is slower on domestic authority an effective veto over timing. Conditional starts reduce that leverage but weaken the comparability of the evidence.

**Strategic Connections:**

**Synergy:** Amplifies Provisional Covered-Equipment Schedule Governance, because a certified gate requires an adopted schedule before the clock, and strengthens Go-Modify-Stop Threshold Calibration by keeping the evidence base clean enough to support a defensible decision.

**Conflict:** Trades off against Matched Site Selection Logic and Inspector Vetting and Conduct Oversight: a strict gate makes slow site pairing or inspector approval a timing veto, and one side's domestic delay can postpone the whole test.

**Justification:** *Critical*, Critical because it separates setup failure from verification failure and sets the start of the 90-day clock. It links to schedule governance, site selection, vetting and attestation ceremonies, and controls the validity-versus-delay trade-off. Without it, the Go/Modify/Stop evidence base is unreliable.

### Decision 2: Evidence Layer Weighting
**Lever ID:** `e7828387-7f21-405e-99a5-6c0a7388782d`

**The Core Decision:** Specifies how attestation, physical inspection, customs and shipment records, identifiers, maintenance logs, infrastructure changes and witnessed movement combine into an equipment-identity confidence rating. It is the main driver of false-negative and false-positive rates and of how contested a finding becomes. Success is measured by detection rates in blind exercises, reproducible ratings across the mirrored teams, and provenance recorded for every layer.

**Why It Matters:** This decides how cryptographic attestation, physical inspection, customs and shipment records, identifiers, maintenance logs, infrastructure changes, and witnessed movement are combined into an equipment-identity confidence rating. Because no single source is decisive, the weighting rules drive both false-negative and false-positive rates. Rules that are too rigid can be learned and gamed by an adversary, while rules that are too flexible invite disputes.

**Strategic Choices:**

1. Use a fixed, pre-agreed corroboration rule in which identity is confirmed only when a stated minimum number of independent evidence layers agree, with every layer's provenance recorded.
2. Use a graded confidence score derived from layer-specific reliability ratings that are recalibrated after each exercise round by the independent testing group, with both co-chairs approving every change.
3. Randomize which evidence layers are required for each event, with the selection drawn from a sealed double-key schedule, so that no operator can predict which checks to defeat.

**Trade-Off / Risk:** Fixed rules are easy to audit but easy to defeat once learned. Graded scoring adapts, but it adds numerical judgment that both governments may contest, and recalibrating thresholds mid-test can be seen as moving the goalposts.

**Strategic Connections:**

**Synergy:** Works with Attestation Trust Root Provenance, since weighting is only as sound as the independently validated trust roots feeding it, and with Challenge Exercise Independence, which supplies the blind results used to justify or recalibrate weights.

**Conflict:** Conflicts with Go-Modify-Stop Threshold Calibration and Inspection Zone Boundary Design: recalibrating weights mid-test can appear to move the goalposts, and narrow zones deprive some layers of evidence, which limits any weighting scheme.

**Justification:** *Critical*, Critical because it is the analytical core. It sets equipment-identity confidence and drives false-negative and false-positive rates. It connects to attestation, vendor fallbacks, zones, exit evidence, escalation and thresholds, and it controls the rigidity-versus-gaming trade-off.

### Decision 3: Inspection Zone Boundary Design
**Lever ID:** `43d82cbd-f2f1-4301-a824-728309d4358d`

**The Core Decision:** Defines the physical and informational perimeter of inspection: which staging, spare-inventory, maintenance and expansion areas inspectors may enter, and how evidence is filtered before leaving the site. It balances detection coverage against protection of workloads, weights, topology and source code. Success is measured by zero material IP or counterintelligence incidents, no consent withdrawal, and low blind-spot exposure in challenge exercises.

**Why It Matters:** This sets where inspectors may go, what they may see, and how evidence is filtered before it leaves the site. Narrow zones protect workloads, model weights, topology, and source code but leave blind spots where substitution or unreported arrivals can occur. Wider zones raise detection but increase intellectual-property and counterintelligence exposure, which could cause one government to withdraw consent.

**Strategic Choices:**

1. Fix narrow, physically marked zones limited to staging, spare inventory, and maintenance bays, with all evidence passing through an operator-run redaction step that inspectors can audit.
2. Use dynamic zones that expand only for a specific event under double-key approval and shrink when it closes, with escorted access and time-limited credentials.
3. Place sealed capture instruments in the zones that record only identifiers, seals, and movement metadata, so that inspectors review filtered data and enter only when a discrepancy is open.

**Trade-Off / Risk:** Narrower zones lower the spying risk that makes governments hesitate, but the unseen margin is where a motivated operator would hide a substitution. Dynamic zones add procedural friction that can delay access and create their own disputes.

**Strategic Connections:**

**Synergy:** Amplifies Maintenance and Third-Party Access Scheduling, because defined zones and escort rules make vendor visits predictable and auditable, and supports Inspector Vetting and Conduct Oversight by limiting what any inspector can observe.

**Conflict:** Trades off against Evidence Layer Weighting and Discrepancy Escalation Clock and Tiering: tighter zones reduce evidence available for identity confidence, while dynamic expansion needs double-key approvals that consume time inside escalation deadlines.

**Justification:** *Critical*, Critical because it controls the central trade-off between detection coverage and IP and counterintelligence exposure, which decides whether governments keep consenting. It constrains evidence availability, escalation timing, exit witnessing and maintenance access, and it determines where blind spots exist.

### Decision 4: Challenge Exercise Independence
**Lever ID:** `746e5a9f-762c-4613-b60a-be2ef724f82f`

**The Core Decision:** Determines who designs, schedules and scores the live challenge exercises, and how blind inspectors and operators remain to timing and content. It governs the credibility of the detection evidence behind the final decision. Key measures: blind-challenge detection by event type, false negatives and positives, comparability of scenarios between countries, and absence of production disruption during exercises in staging and spare areas.

**Why It Matters:** This sets who designs and runs the unreported arrival, substitution, record-falsification, delayed-access, disputed-identity, vendor-refusal, and reluctant-operator exercises, and how blind they are to inspectors. More independence improves the credibility of the detection results that drive the Go/Modify/Stop decision. It also raises coordination cost and the risk that an exercise disturbs live operations.

**Strategic Choices:**

1. Have an independent testing unit designed by both governments run all exercises in a sealed, double-key schedule, with only a small group at each site aware of the timing.
2. Let each country's red team design challenges against the other country's inspectors, then have an audit unit review the scenarios for fairness and comparability before and after the exercise.
3. Blend scheduled exercises with unannounced real events, scoring detection on real changes recorded in the ledger as well as the staged ones, to measure performance under ordinary conditions.

**Trade-Off / Risk:** Cross-national red teams create adversarial realism but also an opening for each side to design tests that favor its own inspectors. Mixing in real events increases validity but risks interfering with active computational work.

**Strategic Connections:**

**Synergy:** Supplies the detection evidence that Go-Modify-Stop Threshold Calibration needs to be meaningful, and tests Discrepancy Escalation Clock and Tiering and Vendor Refusal Response Path under realistic, unannounced conditions.

**Conflict:** Competes with Mirrored Shift Roster Architecture and Maintenance and Third-Party Access Scheduling: stronger blindness and real-event mixing raise coordination burden and the risk of disturbing live operations in staging and maintenance areas.

**Justification:** *Critical*, Critical because blind exercises produce the detection evidence that justifies the Go/Modify/Stop decision and recalibrates weights. It feeds thresholds, escalation and vendor paths, and balances credibility against live-operations disruption and coordination burden.

### Decision 5: Go-Modify-Stop Threshold Calibration
**Lever ID:** `453c25dc-ed80-4416-8ce0-d6182c098250`

**The Core Decision:** Determines how numeric and categorical thresholds for detection, false results, parity and unverifiable equipment are justified, validated and locked before the final Go, Modify or Stop decision. It also fixes which failures are non-negotiable Stop conditions. Success means a verdict that both governments accept as principled rather than tuned, with provisional figures validated against calibration or exercise evidence and recorded under double-key authority.

**Why It Matters:** Determines how KPI thresholds for detection, false results, parity and unverifiable equipment are set and validated before the final decision. Thresholds fixed in advance by the co-chairs make the verdict resistant to post-hoc bargaining, but they rest on provisional figures that exercises may show to be mis-set. Thresholds derived from exercise results are better grounded but invite accusations of tuning the outcome.

**Strategic Choices:**

1. Fix every decision threshold and its justification before the first exercise, double-key sign them, and permit changes only through a documented protocol change that is itself recorded.
2. Set provisional thresholds, run a short pre-test calibration exercise outside the formal clock, and lock the validated values before the blind challenges that feed the decision.
3. Define the decision as a rule over trends and categories rather than single numbers, with independent auditors scoring each KPI band and a rubric stating which failure types are non-negotiable Stop conditions.

**Trade-Off / Risk:** Locking thresholds early protects against motivated reinterpretation, but because most figures start as provisional, a mis-set value can force a Modify outcome that reflects the yardstick rather than the mechanism's real performance.

**Strategic Connections:**

**Synergy:** Amplifies Challenge Exercise Independence, because independently run blind challenges give locked thresholds credible test data, and Discrepancy Escalation Clock and Tiering, whose unresolved-age limits become explicit decision criteria.

**Conflict:** Early locking constrains Challenge Exercise Independence and Reciprocity Gate Stringency, since mis-set values cannot be adjusted after exercises reveal real performance, while calibration-based options risk accusations of tuning the outcome.

**Justification:** *Critical*, Critical because it turns KPI evidence into a verdict both governments accept as principled rather than tuned. It governs the lock-early versus calibrate-later trade-off and ties together exercises, escalation clocks, the gate and unverifiable-equipment outcomes.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Matched Site Selection Logic
**Lever ID:** `6afa6cea-9703-48d2-90d2-e450c9a1a380`

**The Core Decision:** Sets the method for choosing the small matched set of declared datacenters and the degree of resemblance required between US and Chinese sites. It governs whether the Go decision rests on representative conditions or convenient ones. Success is measured by documented parity in event frequency, vendor mix and staging layout (thresholds TBD), neither side steering selection, and inclusion of sites hard enough to test detection.

**Why It Matters:** This determines how the small set of declared datacenters is chosen and how closely the US and Chinese sites must resemble each other in equipment turnover, vendor mix, and layout. Tighter matching strengthens reciprocal-access parity and the fairness of the Go decision. It narrows the candidate pool and may favor sites that are unrepresentative of real operations.

**Strategic Choices:**

1. Select sites by structured pairing on observable characteristics such as event frequency, staging layout, and vendor dependence, with each side vetoing sites it considers to be unrepresentative.
2. Let each government nominate a longer list, then use a sealed double-key draw from the jointly vetted shortlist, so neither side can steer the other toward easy or hard sites.
3. Include one deliberately hard site on each side, chosen for complex maintenance and third-party access, so the test exercises the protocol under the conditions where it is most likely to fail.

**Trade-Off / Risk:** Pairing improves parity on paper, but sites that look matched on paper can differ in operator cooperation and vendor leverage. Random draws offset gaming but may select sites too trivial to prove detection credibility.

**Strategic Connections:**

**Synergy:** Enables Challenge Exercise Independence, since comparable or deliberately hard sites make blind-challenge results meaningful, and supports Vendor Refusal Response Path by exposing real vendor dependence early in the test.

**Conflict:** Constrains Reciprocity Gate Stringency, because a narrow candidate pool and mutual vetoes delay site agreement before the clock starts. It also conflicts with Inspection Zone Boundary Design where hard sites carry wider exposure.

**Justification:** *High*, High because site matching drives reciprocal-access parity and whether challenge results are meaningful. It enables exercise independence and vendor exposure, but constrains the gate and zone design. Its influence is large but mostly upstream and one-time, rather than a continuing hub.

### Decision 7: Ledger Divergence Handling
**Lever ID:** `b0c99e97-ad27-4a5a-88e4-f36b872595c1`

**The Core Decision:** Governs how the two national ledger copies record events locally, synchronize within a bounded delay, and are reconciled when they disagree. It turns divergence into a defined status: technical fault, impaired confidence, or automatic suspension. Success is measured by synchronization latency, ledger divergence counts, reconciliation time, and the absence of unresolved divergence, which is a Stop condition.

**Why It Matters:** This determines how the two national ledger copies record events locally, synchronize within a bounded delay, and resolve differences when they disagree. Immediate local recording preserves evidence but permits temporary divergence. The resolution method decides whether divergence is a technical fault, a trigger for impaired-confidence status, or grounds for automatic suspension.

**Strategic Choices:**

1. Treat any unresolved divergence beyond a stated time bound as an automatic impaired-confidence trigger, with reconciliation led by a jointly staffed forensic team working from both copies.
2. Maintain a third neutral escrow record held under double-key control, used only to arbitrate which copy diverged, with its access rules fixed in the bilateral instrument.
3. Reconcile through event-by-event cross-signing by mirrored inspectors at shift handover, so most divergences are caught within hours rather than at periodic synchronization.

**Trade-Off / Risk:** A neutral escrow record helps settle disputes, but it creates a new high-value target and a trust question about who hosts it. Handover cross-signing is cheap and fast but depends on inspectors acting at the same shift boundaries.

**Strategic Connections:**

**Synergy:** Strengthens Discrepancy Escalation Clock and Tiering, since divergence time bounds can feed the same escalation tiers, and Mirrored Shift Roster Architecture, because shift handover cross-signing uses the paired national teams already on duty.

**Conflict:** Constrains Mirrored Shift Roster Architecture and Go-Modify-Stop Threshold Calibration: handover cross-signing depends on aligned shifts, and strict divergence triggers may produce Stop outcomes from technical faults rather than real concealment.

**Justification:** *High*, High because unresolved divergence is an explicit Stop condition, and the lever links ledger integrity to escalation tiers, rosters and thresholds. It defines the status path from technical fault to automatic suspension. It is narrower than the evidence and zone hubs.

### Decision 8: Vendor Refusal Response Path
**Lever ID:** `1475e028-59f1-437f-b52e-a71b5b2afb8a`

**The Core Decision:** Defines the sequence of fallback evidence routes when a critical manufacturer, maintenance provider or logistics firm refuses cooperation, and the documentation needed before equipment is labelled unverifiable. Scope covers who decides each step, how trade-secret exposure is bounded, and how refusals are timed within the 90-day test. Key metrics: vendor-refusal outcomes, unverifiable-equipment count, and time from refusal to disposition.

**Why It Matters:** This defines what happens when a critical manufacturer, maintenance provider, or logistics firm declines to cooperate. The fallback options (vendor-supervised testing, filtered evidence, accredited independent examiners, clean-room procedures, validated attestation) vary in evidentiary strength and in exposure of trade secrets. The chosen order determines how often equipment ends up classified as unverifiable, which can fail a site.

**Strategic Choices:**

1. Apply a fixed escalation ladder that starts with vendor-supervised testing and moves to accredited independent examiners and clean-room examination, with each step documented before unverifiable status is assigned.
2. Require operators to contract vendor cooperation as a condition of covered-equipment installation, so refusal becomes a pre-installation barrier rather than a post-arrival crisis.
3. Pre-qualify a pool of independent examiners and validated attestation methods for each equipment class before the clock starts, so refusals can be bypassed without negotiating with the vendor.

**Trade-Off / Risk:** Contract-based binding shifts risk to operators and slows deployments, which may breach the no-disruption commitment. Independent examiners reduce vendor leverage but need enough vendor-specific knowledge to be credible, which refusing vendors may deny them.

**Strategic Connections:**

**Synergy:** Works with Evidence Layer Weighting, which sets how much substitute evidence from examiners or clean rooms counts, and with Attestation Trust Root Provenance, since validated attestation is a fallback route when a vendor withholds access.

**Conflict:** Strains Maintenance and Third-Party Access Scheduling, because contract-binding or escalation steps delay maintenance windows, and Go-Modify-Stop Threshold Calibration, since a stricter ladder raises unverifiable counts that can fail a site.

**Justification:** *High*, High because it determines how often equipment becomes unverifiable, which can fail a site. It governs a fundamental tension between evidence sufficiency and trade-secret exposure, and it interacts with attestation, weighting, maintenance and escalation clocks.

### Decision 9: Mirrored Shift Roster Architecture
**Lever ID:** `da397295-b325-4d20-af2c-35654594f345`

**The Core Decision:** Sets the full-time headcount and rostering model per site: shift coverage, mirrored national pairing, leave cover, separation of duties and surge reserve. It is the main driver of the personnel envelope and of vetting workload before the clock starts. Key measures: coverage gaps by shift, event-recording latency, roster fill rate, inspector turnover, and surge activation time.

**Why It Matters:** Determines how many full-time inspectors, technicians and adjudicators are needed per participating site, based on shift coverage, leave cover and separation of duties. A leaner roster conserves the USD 750 million personnel envelope but leaves thin cover during leave or surge. A deeper roster improves continuity and detection at night and weekends, but enlarges the counterintelligence vetting load and the entry-condition timeline for approving inspectors.

**Strategic Choices:**

1. Staff each site with a fixed round-the-clock mirrored roster sized to peak expected equipment traffic, accepting higher fixed payroll in exchange for uninterrupted coverage of staging and maintenance areas.
2. Staff each site with a core day-shift mirrored roster and a rapid-call duty team that activates on declared arrivals or maintenance windows, trading continuous presence for lower cost and a bounded detection gap.
3. Rotate inspectors across paired sites on a scheduled and randomized basis so that neither operator nor vendor can predict who is present, using a shared bench that doubles as the surge reserve.

**Trade-Off / Risk:** A randomized rotation pool defeats operator familiarity and cuts idle headcount, but it multiplies travel, clearances and information-barrier handoffs, and it could break the shift continuity that separation-of-duties rules depend on.

**Strategic Connections:**

**Synergy:** Enables Inspector Vetting and Conduct Oversight by fixing how many people need clearance, and supports Inspection Zone Boundary Design by determining who can staff bounded zones continuously across shifts.

**Conflict:** Trades off against Inspector Vetting and Conduct Oversight, since deeper or rotating rosters enlarge the counterintelligence vetting load and entry timeline, and against Challenge Exercise Independence, which needs small, discreet groups.

**Justification:** *High*, High because it is the main driver of the personnel envelope, coverage gaps and vetting workload. It connects to vetting, zones, divergence cross-signing, exit witnessing and exercise discretion. It mostly sizes capability rather than shaping the core verdict logic.

### Decision 10: Attestation Trust Root Provenance
**Lever ID:** `1e85fd29-a525-4d04-ac84-b263511f158e`

**The Core Decision:** Decides who creates, holds, validates and can revoke the cryptographic roots behind device-identity attestation, and therefore how far attestation can be trusted as one evidence layer. It frames resistance to unilateral forgery, key-ceremony security and exposure of vendor secrets. Key measures: equipment-identity confidence, attestation validation failure rate, key-custody audit exceptions, and ceremony delay.

**Why It Matters:** Sets who generates, holds and validates the cryptographic keys and device-identity roots behind attestation evidence. A jointly generated root limits unilateral forgery, but it needs hardware and ceremonies that each side may distrust. Choices here shape equipment-identity confidence and determine how much weight attestation can carry among the layered evidence sources, none of which is decisive.

**Strategic Choices:**

1. Run a joint key ceremony in a shared secure facility with split custody, so neither government alone can mint or revoke attestation credentials for covered equipment.
2. Maintain two independent national attestation roots that cross-validate each other's claims, accepting duplicate infrastructure cost in return for the removal of any shared trusted component.
3. Delegate attestation validation to accredited third-country laboratories that hold no key material and re-derive device identity from physical measurement, treating cryptographic claims only as corroboration.

**Trade-Off / Risk:** Split custody avoids unilateral forgery, but a joint ceremony facility becomes a high-value espionage target and a single point of delay, while third-country labs introduce a political dependency neither government fully controls.

**Strategic Connections:**

**Synergy:** Strengthens Evidence Layer Weighting by giving attestation a defensible weight, and supports Ledger Divergence Handling by providing a trusted identity basis for reconciling conflicting national ledger entries.

**Conflict:** Conflicts with Vendor Refusal Response Path when vendors withhold attestation hooks, and with Reciprocity Gate Stringency, as joint ceremonies and facilities may lengthen entry conditions and create a shared espionage target.

**Justification:** *High*, High because it decides how much weight cryptographic attestation can carry and whether unilateral forgery is possible. It supports evidence weighting and ledger reconciliation, but it is one layer among several, with no single source decisive.

### Decision 11: Provisional Covered-Equipment Schedule Governance
**Lever ID:** `70f3602e-c67e-401a-9efc-9e60c8862cdb`

**The Core Decision:** Governs how the confidential, versioned, manufacturer-neutral schedule defining covered equipment is drafted, amended and protected during Phase One. It balances stable test baselines against hardware evolution and threshold gaming. Key measures: amendment count and cycle time, disputes over coverage, share of real changes falling outside the schedule, and double-key approval timeliness.

**Why It Matters:** Controls how the confidential, versioned technical schedule of covered equipment is drafted, amended and kept manufacturer-neutral. Frequent amendment keeps coverage aligned to evolving hardware but creates repeated double-key negotiation points and potential disputes over what counts. A stable schedule is predictable, but it may become obsolete or leave a threshold-gaming gap during the test.

**Strategic Choices:**

1. Freeze the schedule for the full Phase One test and defer all revisions to the Go/Modify/Stop decision, ensuring a stable baseline for measuring detection performance.
2. Allow scheduled amendment windows with double-key approval and a short notice period, letting specialists add equipment categories while keeping all changes recorded in the ledger.
3. Define coverage by function and risk-relevance criteria evaluated by a standing technical panel, and have each side submit sealed candidate lists that are reconciled only at the panel stage.

**Trade-Off / Risk:** A frozen schedule gives clean test data, but any mid-test hardware shift would leave real changes outside coverage, so the exercise results could overstate how well the mechanism works against current equipment.

**Strategic Connections:**

**Synergy:** Provides the scope basis for Matched Site Selection Logic and Inspection Zone Boundary Design, and gives Challenge Exercise Independence a clear, comparable set of equipment classes against which detection is scored.

**Conflict:** Tension with Challenge Exercise Independence and Go-Modify-Stop Threshold Calibration: frequent amendments disturb clean test baselines, while a frozen schedule risks results that overstate detection against current hardware.

**Justification:** *Medium*, Medium because it sets the scope baseline for site selection, zones and exercise scoring and creates tension between a stable baseline and hardware evolution. It is largely a scoping input to higher-level levers rather than a hub of the core trade-offs.

### Decision 12: Discrepancy Escalation Clock and Tiering
**Lever ID:** `de71d074-72ff-46d0-bec4-aae42aa77c9a`

**The Core Decision:** Defines severity tiers, clock start events, and expiry consequences for every open discrepancy, from minor record mismatches to disputed equipment identity. Its scope includes who may pause a clock, what counts as resolution, and how aged items feed the unresolved-discrepancy-age KPI. Success means timely closure without turning administrative lag into a spurious Stop trigger within the 90-day window.

**Why It Matters:** Sets time limits and severity tiers for resolving discrepancies, which determines unresolved-discrepancy age and when automatic suspension fires. Short clocks force prompt resolution and deter stalling, but increase false suspensions during a short test. Long clocks give room for fact-finding but allow unresolved items to accumulate and cloud the final decision.

**Strategic Choices:**

1. Apply short fixed deadlines by severity tier, with automatic suspension of the affected site or event class when a clock expires, prioritizing deterrence over fact-finding thoroughness.
2. Use extendable clocks that a joint adjudication unit may lengthen once per case with written reasons, balancing fact-finding against the risk of indefinite delay.
3. Run an independent technical referee panel that can issue a non-binding evidential opinion before the clock expires, giving co-chairs a shared factual basis without removing their double-key authority.

**Trade-Off / Risk:** Automatic suspension on expiry removes the option to stall, but in a 90-day test it can turn routine paperwork lag into a Stop trigger, distorting the dashboard and the final decision.

**Strategic Connections:**

**Synergy:** Works with Go-Modify-Stop Threshold Calibration, since fixed tier deadlines supply the unresolved-age thresholds the verdict relies on, and with Evidence Layer Weighting, which gives adjudicators a defensible basis for closing items before a clock expires.

**Conflict:** Tight clocks trade off against Vendor Refusal Response Path, where clean-room or accredited-examiner routes take longer than deadlines allow, and against Maintenance and Third-Party Access Scheduling, whose post-event reviews can age out.

**Justification:** *High*, High because it defines when automatic suspension fires and supplies the unresolved-age thresholds behind the verdict. It conflicts with vendor routes and maintenance reviews, and short clocks risk turning administrative lag into spurious Stop triggers.

### Decision 13: Exit Disposition Assurance Depth
**Lever ID:** `8809b39b-c070-479f-bf53-dae39ec692d6`

**The Core Decision:** Sets the evidentiary standard for assigning each departure one of the five dispositions: witnessed destruction, verified permanent disablement, transfer to another participating site, documented release beyond the monitored system, or unresolved. It determines inspector presence at recycling, destruction and transit points, and how honestly the ledger records the limit of knowledge. Key metrics are the share of departures per disposition and re-entry detection in exercises.

**Why It Matters:** Controls how much evidence is needed before a departure is labelled witnessed destruction, permanent disablement, transfer or release. Deeper witnessing reduces the chance that equipment re-enters use unseen, but it requires inspectors at recycling, destruction and transit points that may sit outside the inspection zone. Shallower witnessing keeps the boundary clean but increases the share of departures recorded as released beyond the monitored system or unresolved.

**Strategic Choices:**

1. Witness every destruction or disablement end-to-end with inspectors present at the process, including at third-party facilities, and record chain of custody until the equipment is demonstrably unusable.
2. Witness the departure at the site boundary and the receiving party's acknowledgement, then record the disposition as released beyond the monitored system without claiming further knowledge.
3. Apply full witnessing to a randomly selected subset of departures chosen after the fact, and record the remainder at boundary-level assurance, using the sample to estimate reliability of declared dispositions.

**Trade-Off / Risk:** Full end-to-end witnessing is the most defensible against re-entry claims, but it stretches inspectors into third-party sites and blurs the agreed boundary the plan insists must never be implied beyond.

**Strategic Connections:**

**Synergy:** Reinforces Evidence Layer Weighting by supplying chain-of-custody and destruction evidence for departures, and supports Ledger Divergence Handling because a clearly bounded disposition record leaves fewer ambiguous exit entries to reconcile between national copies.

**Conflict:** Deeper witnessing pulls against Inspection Zone Boundary Design, since inspectors at third-party facilities extend beyond bounded zones, and strains Mirrored Shift Roster Architecture by requiring mirrored staff for off-site, travel-heavy events.

**Justification:** *Medium*, Medium because it sets the evidence standard for departures and keeps the knowledge boundary honest. It is an important protocol, but it mostly affects one event class and trades off with zone design and rosters without governing the system's core conflicts.

### Decision 14: Inspector Vetting and Conduct Oversight
**Lever ID:** `54ab2b1c-93af-4168-a9fc-e9dbe66f2dd4`

**The Core Decision:** Governs how inspectors are screened, approved, rotated and monitored so they cannot be used for intelligence collection or coerced by their own services. It also covers conduct rules, access-log audit, discipline and replacement. Because inspector approval is a mandatory entry condition, it sets the pace of start-up. Success is measured by zero substantiated collection incidents, timely approvals and reciprocal acceptance of each side's roster.

**Why It Matters:** Defines how approved inspectors are screened, rotated and monitored so that they cannot be used for intelligence collection or be coerced by their own service. Strict vetting and rotation reduce espionage and capture risk, but they lengthen the entry-condition timeline for approving inspectors and reduce accumulated site familiarity. Looser oversight shortens onboarding but invites mutual suspicion that can collapse reciprocity.

**Strategic Choices:**

1. Subject inspectors to joint bilateral review of their conduct, with rotation across sites and a standing mirrored counterintelligence unit that audits each inspector's access logs and notes.
2. Allow each government to vet and discipline its own inspectors under shared published conduct rules, with the counterpart empowered only to veto an individual and request replacement.
3. Pair every inspector with a counterpart observer from the host country for all activities, accepting reduced independence in exchange for continuous transparency about what the inspector sees and records.

**Trade-Off / Risk:** Joint conduct review builds mutual confidence, but giving each side visibility into the other's personnel files and access logs is itself a sensitive disclosure that either government may resist.

**Strategic Connections:**

**Synergy:** Strengthens Mirrored Shift Roster Architecture by supplying a trusted, rotatable pool for mirrored teams, and supports Reciprocity Gate Stringency because credible conduct controls make each government more willing to grant counterpart access.

**Conflict:** Strict vetting and rotation constrain Mirrored Shift Roster Architecture through slower approvals and lost site familiarity, and joint personnel-file review conflicts with Reciprocity Gate Stringency where either government resists disclosure.

**Justification:** *High*, High because inspector approval is a mandatory entry condition that sets start-up pace and mutual trust. It addresses the espionage-versus-speed tension and links to rosters, the gate and zones, but it is more of an enabling control than a core strategy choice.

### Decision 15: Maintenance and Third-Party Access Scheduling
**Lever ID:** `6f1dc358-8cd8-4a5c-84a1-ba37cd139bf2`

**The Core Decision:** Sets how maintenance, repair and vendor visits are notified, escorted, sealed and logged in spare-inventory, maintenance and expansion areas so hardware changes stay visible without halting computation. Beyond the scheduling mechanics, it defines what qualifies as an emergency and the abuse controls on it. Key metrics are the share of changes with inspector coverage, emergency-use frequency and production disruption.

**Why It Matters:** Governs how maintenance, repair and vendor visits are announced, escorted and logged so that they are visible without interrupting active computational work. Advance-notice scheduling gives inspectors time to prepare and keeps disruption low, but it blocks urgent repairs and creates an incentive to misclassify emergencies. Open-ended emergency access protects uptime but opens a route for unlogged hardware changes.

**Strategic Choices:**

1. Require advance notice for all maintenance and third-party access, with inspectors present at the start and end of each window and sealed work areas during the intervening period.
2. Create a rapid-response emergency lane where operators may proceed immediately but must file a continuous recording and a post-event inspector review, with repeated emergency use triggering escalation.
3. Consolidate all hardware-affecting maintenance into pre-agreed recurring windows with inspector teams on standby, and defer non-urgent work outside those windows.

**Trade-Off / Risk:** Pre-agreed windows reduce disruption and ease inspector planning, but a rigid schedule invites operators to bypass it through claimed emergencies, so the emergency lane's abuse controls decide whether the design holds.

**Strategic Connections:**

**Synergy:** Amplifies Vendor Refusal Response Path by giving a predictable window in which vendor-supervised testing or escorted access can be arranged, and feeds Evidence Layer Weighting with maintenance records and witnessed movement as independent evidence layers.

**Conflict:** Fixed windows and standby teams strain Mirrored Shift Roster Architecture by raising peak staffing demand, and an emergency lane conflicts with Discrepancy Escalation Clock and Tiering, as repeated emergencies create discrepancies needing fast resolution.

**Justification:** *Medium*, Medium because it manages the uptime-versus-visibility trade-off for hardware changes and feeds maintenance evidence into weighting. It matters operationally, especially through the emergency lane, but it mainly supports other levers such as zones, vendor paths and rosters.
