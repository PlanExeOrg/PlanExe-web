## Primary Decisions
The vital few decisions that have the most impact.


The Critical levers address the central tensions of the plan: detection credibility versus exposure and cost (Identity Trust Anchor, Inspector Presence, Zone Geometry and Filtering), empirical defensibility versus realism (Challenge Exercises), and continuity versus obstruction without a casting vote (Deadlock and Suspension). High levers cover ledger integrity, parity measurement, vendor binding, entry gating, counterintelligence and verdict thresholds. No major dimension is missing, though an explicit staffing and surge-capacity lever is absent.

### Decision 1: Equipment Identity Trust Anchor
**Lever ID:** `a3421ed3-ab90-4c56-9cd2-07f23e2a35da`

**The Core Decision:** Sets the evidentiary hierarchy the Intake Protocol uses to conclude that a unit in controlled staging is the declared unit. It drives inspector shift counts, staging-area layout, accredited examiner demand and the false-negative profile for substituted equipment. Success is measured by equipment-identity confidence in blind challenges, intake time per unit and the share of units resolved without escalation to unverifiable status.

**Why It Matters:** This sets which evidence layer carries the most weight when the Intake Protocol decides that a unit in staging is the unit declared. Leaning on cryptographic attestation scales across many units but depends on vendor cooperation and key custody. Leaning on physical marks and witnessed movement is slower and more labor-intensive but less exposed to a single compromised vendor or firmware chain, and it directly shapes inspector headcount and staging-area design.

**Strategic Choices:**

1. Anchor identity primarily on vendor-issued cryptographic attestation validated independently by accredited examiners from both countries, using physical inspection and customs records as corroborating layers at intake.
2. Anchor identity primarily on physical inspection and witnessed movement in controlled staging areas, treating attestation, customs records and maintenance logs as layers that can raise or lower confidence but never settle it alone.
3. Apply bilateral tamper-evident tags jointly in the staging area by both mirrored teams, so identity continuity rests on markers neither country's manufacturers or logistics firms controlled before arrival.

**Trade-Off / Risk:** Attestation scales but concentrates trust in vendor keys and firmware; physical anchoring resists that failure yet multiplies inspector shifts and staging time, so the choice quietly determines both staffing cost and the single-source-failure profile.

**Strategic Connections:**

**Synergy:** Amplifies Opening Inventory Baseline and Starting-State Seal, since a trusted anchor lets baseline units be re-identified consistently, and Departure Disposition Evidence Ladder, since the same identity method supports witnessed destruction and transfer records.

**Conflict:** Trades off against Inspector Presence and Rotation Model: physical anchoring demands resident shift coverage and staging time, while attestation reliance shifts cost to Vendor and Operator Binding Mechanism and vendor key cooperation.

**Justification:** *Critical*, Central hub: it sets the evidentiary hierarchy for intake, which drives inspector shifts, staging design, vendor dependence and the false-negative profile for substitution. It feeds baseline and exit evidence and trades directly against Inspector Presence and Vendor Binding.

### Decision 2: Inspector Presence and Rotation Model
**Lever ID:** `1cc2d357-5ce9-4e5f-a937-f7cb5e021cf6`

**The Core Decision:** Determines when and how mirrored inspectors are physically present: continuous residence, event-triggered response or randomized rotation. It sets workforce size, shift and leave coverage, exposure to unreported events and the cumulative risk to individual inspectors. Success is measured by detection rate for unreported arrivals, response-window compliance, delayed-access incidents and staffing cost against the personnel envelope.

**Why It Matters:** This determines whether inspectors sit continuously at sites, arrive on event notification, or move on randomized schedules. Continuous presence maximizes detection of unreported arrivals but enlarges the counterintelligence surface and the shift-coverage workforce. Event-triggered presence is cheaper and less intrusive but depends on the operator reporting the event, which is exactly what the unreported-arrival exercise tests.

**Strategic Choices:**

1. Station resident mirrored teams at every participating site on continuous shift coverage, confined to bounded inspection zones with escorted movement and filtered evidence handling.
2. Deploy inspectors on operator notification within fixed response windows, supplementing with filtered remote evidence and unannounced spot visits to test whether declarations are complete.
3. Rotate inspectors across sites on randomized schedules with no repeat assignment to the same zone in succession, limiting relationship capture, site familiarity and cumulative exposure of any one inspector.

**Trade-Off / Risk:** Resident teams give the strongest detection but concentrate espionage risk and cost; notification-based models are cheaper yet rest on the operator honesty being tested, and random rotation erodes the site knowledge inspectors need to spot anomalies.

**Strategic Connections:**

**Synergy:** Amplifies Challenge Exercise Commitment and Scoring, since presence mode decides which unreported-arrival events can be detected, and strengthens Equipment Identity Trust Anchor when physical inspection and witnessed movement carry identity decisions.

**Conflict:** Conflicts with Counterintelligence and Compartmentation Posture, because continuous presence enlarges the espionage surface, and with the inspector and security budget envelopes, where resident teams compete with other funding needs.

**Justification:** *Critical*, Controls the detection-versus-espionage-exposure-versus-cost trade-off and sets workforce size, shift coverage and unreported-arrival detectability. It connects to identity anchoring, exercises, counterintelligence, exit witnessing and the budget envelopes.

### Decision 3: Deadlock and Suspension Mechanics
**Lever ID:** `213da8e6-7982-4d9e-bd77-042854f828cb`

**The Core Decision:** Defines how a contested site finding is resolved without a casting vote, and which enumerated events suspend a site or the whole test. Scope covers deadlock, impaired-confidence and automatic-suspension states, escalation timers, and resumption conditions. Success metrics: unresolved discrepancy age, time from trigger to suspension, share of triggers later judged spurious, and absence of any unilateral override path.

**Why It Matters:** This defines what happens when co-chairs cannot agree on a site finding, and which events suspend the test without any chair action. Automatic triggers protect against one side stalling to shield an operator but can be gamed by manufactured incidents. Defaulting to the status quo keeps the pilot running but lets a blocked finding age, which is itself a tracked KPI and a Stop-criterion risk.

**Strategic Choices:**

1. Define enumerated objective triggers that suspend a site automatically, with resumption requiring double-key authorization and a documented corrective action from the responsible government.
2. Hold the status quo on deadlock but start escalating timers that move the dispute from co-chair level to designated principals, with unresolved findings reported as aging discrepancies.
3. Convene paired technical referees from both countries to issue dual-signed advisory fact statements, with deadlock defaulting to heightened inspection and impaired-confidence status instead of suspension.

**Trade-Off / Risk:** Automatic suspension prevents one side from stalling but invites manufactured triggers; status-quo defaults protect continuity yet reward delay, so neither design removes the underlying incentive to obstruct a finding.

**Strategic Connections:**

**Synergy:** Strengthens Verdict Evidence Sufficiency and Threshold Calibration by turning evidence thresholds into objective trigger definitions, and gives Vendor and Operator Binding Mechanism enforcement force, since a shielded or refusing operator has a defined suspension consequence.

**Conflict:** Automatic triggers can be set off by seeded scenarios, so they collide with Challenge Exercise Commitment and Scoring unless exercise events are excluded; heavy escalation timers also slow resolution of Reciprocal Access Parity Accounting Method disputes.

**Justification:** *Critical*, Controls the core governance tension between continuity and obstruction without a casting vote. It converts evidence thresholds and parity trip points into consequences, enforces vendor and operator duties, and determines whether blocked findings age into a Stop condition.

### Decision 4: Challenge Exercise Commitment and Scoring
**Lever ID:** `71663499-b57e-4749-ab29-21230bb34c8e`

**The Core Decision:** Governs who authors, injects and scores live challenges for unreported arrival, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal and reluctant operators. The aim is a Go/Modify/Stop basis that neither government can later contest. Success metrics: blind-detection rate by event type, false positives and negatives, scoring-criteria agreement before injection, and zero disruption to active computation.

**Why It Matters:** This controls who designs and injects the live challenges, and how detection results are scored so neither government can later dispute the outcome. Independent seeding yields credible blind-detection data but needs careful containment so staging, spare-inventory and maintenance areas are not disrupted. Pre-committed scenarios make scoring defensible but constrain adaptive tests that might expose unanticipated weaknesses.

**Strategic Choices:**

1. Have independent testers design and inject blind scenarios in staging, spare-inventory, maintenance and expansion areas, unknown to operating inspectors and scored against jointly agreed detection criteria.
2. Have each country's red team challenge the counterpart's inspectorate at the other's site, using reciprocal adversarial exercises so both detection capability and access parity are tested in a single event.
3. Publish cryptographic commitments to a sealed catalog of challenge scenarios before Phase One, then reveal and score them afterward so neither government can redefine success post hoc.

**Trade-Off / Risk:** Independent seeding gives credible blind results but cannot fully replicate a determined state adversary; sealed catalogs make scoring defensible while constraining adaptive tests, so the Go decision may rest on scenarios anticipated in advance.

**Strategic Connections:**

**Synergy:** Supplies the empirical test for Inspection Zone Geometry and Evidence Filtering Design and Equipment Identity Trust Anchor, showing whether filtered evidence still catches substitution, and feeds Verdict Evidence Sufficiency and Threshold Calibration with defensible detection data.

**Conflict:** Sealed or pre-committed scenarios limit adaptive testing, trading realism against defensibility; injecting blind challenges also risks tripping Deadlock and Suspension Mechanics triggers and straining Inspector Presence and Rotation Model coverage during staging and maintenance windows.

**Justification:** *Critical*, Produces the only empirical evidence for the Go/Modify/Stop verdict and validates filtering, identity and presence choices. It sits between realism and defensibility and interacts with suspension triggers, coverage and thresholds.

### Decision 5: Inspection Zone Geometry and Evidence Filtering Design
**Lever ID:** `2d8049b3-25c0-44b9-be65-c968e82934b5`

**The Core Decision:** Specifies physical boundaries for inspector access and the reduction of raw records, sensor outputs and telemetry before data leaves the host site. It protects workloads, model weights, topology, security architecture and source code while retaining enough evidence to establish identity. Success metrics: IP or cybersecurity incidents, identity-confidence scores under filtering, operator acceptance, and filter-adequacy results from challenge exercises.

**Why It Matters:** Sets where inspectors may stand, what they may see, and how raw sensor or record data is reduced before leaving the host site. Tight zones and heavy filtering protect workloads, topology and source code, but every filtered field removes corroborating detail and raises the odds that identity confidence falls short. Looser zones improve evidence quality at the expense of the operator's willingness to participate.

**Strategic Choices:**

1. Fix physical inspection zones to staging, spare-inventory, maintenance and expansion areas with painted and access-controlled boundaries, and admit only inspector-carried instruments that have been pre-validated.
2. Run an operator-operated redaction gateway that converts raw records and telemetry into schema-limited evidence packets, with the counterpart's engineers auditing the gateway rules but not its inputs.
3. Have each side's cleared engineers design the filters that will be applied at the counterpart's sites, so the party most worried about leakage writes the rules and the host executes them.

**Trade-Off / Risk:** Filters designed by the exposed party minimize leakage but can quietly strip the very fields needed to detect substitution, so filter adequacy must be tested by challenge exercises rather than asserted.

**Strategic Connections:**

**Synergy:** Enables Vendor and Operator Binding Mechanism by giving operators and vendors credible containment guarantees, and supports Counterintelligence and Compartmentation Posture by defining what information can cross national boundaries at all.

**Conflict:** Tighter zones and heavier filtering reduce evidence available to Equipment Identity Trust Anchor and Verdict Evidence Sufficiency and Threshold Calibration, raising false-negative and unverifiable-equipment risk; looser zones instead erode operator willingness and Counterintelligence and Compartmentation Posture.

**Justification:** *Critical*, Controls the fundamental tension between protecting sensitive assets and retaining enough evidence to detect substitution. It determines operator willingness, identity confidence, false negatives and unverifiable equipment, and is a hub across binding, counterintelligence and verdict levers.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Matched Site Equivalence Basis
**Lever ID:** `f2b187bc-f45f-463a-a734-daa54f767583`

**The Core Decision:** Defines the yardstick for 'matched' declared datacenters and thereby the baseline against which reciprocal-access parity is scored. The choice determines whether the pilot tests verification activity, legal and commercial friction, or an idealized interface. Success is measured by the parity disputes avoided, how defensible the pairing is to both national authorities, and how well Phase One findings transfer to operating sites.

**Why It Matters:** This defines what 'matched' means when selecting the small set of declared datacenters, and therefore what reciprocal-access parity is measured against. Matching by function keeps the test about verification activity rather than capacity, but invites disputes over whether a staging area in one country is comparable to one in the other. Purpose-built interfaces lower exposure of production halls but narrow what the pilot can say about real operating sites.

**Strategic Choices:**

1. Match sites by verification function, pairing staging, spare-inventory, maintenance and expansion areas across countries so that parity is judged on equivalent inspection activity rather than equivalent compute.
2. Match sites by operator type and ownership model, pairing commercial with commercial and state-run with state-run facilities, and accept uneven scale as the price of comparable legal and commercial friction.
3. Build dedicated bonded staging annexes beside participating datacenters in both countries, so every declared equipment flow passes through an identical-by-design verification interface before reaching production halls.

**Trade-Off / Risk:** Functional matching makes parity measurable but hides scale asymmetries, while purpose-built annexes give clean symmetry at the cost of testing a controlled artifact rather than the messy operating facilities Phase One is meant to represent.

**Strategic Connections:**

**Synergy:** Enables Reciprocal Access Parity Accounting Method, which needs a stable definition of equivalence to count access, and supports Inspection Zone Geometry and Evidence Filtering Design by fixing which zones are comparable.

**Conflict:** Constrains Entry Gate Certification and Appropriation Release Order, because purpose-built annexes or contested pairings delay site selection and site preparation spending, and strains Challenge Exercise Commitment and Scoring where realism is reduced.

**Justification:** *Medium*, Defines the yardstick for parity and comparable zones, enabling Reciprocal Access Parity Accounting. Important for defensibility, but it is largely a selection-time choice and mostly feeds other levers rather than controlling core trade-offs.

### Decision 7: Ledger Synchronization and Divergence Doctrine
**Lever ID:** `bd7671a4-4f75-4033-876d-b6da5078c203`

**The Core Decision:** Specifies how the two national ledger copies remain independently verifiable yet reconcilable within a bounded delay, including checkpoint format, cadence, transport and the mismatch response. It governs how quickly tampering or error is detected and how large the reconciliation workload becomes. Success is measured by synchronization latency, divergence detection time, reconciliation time and the count of unresolved divergences.

**Why It Matters:** This fixes how the two national ledger copies stay independently verifiable while remaining reconcilable within a bounded delay. Tighter synchronization shrinks the window in which one side can alter records but increases network exposure between national secure systems. Looser or offline synchronization reduces cyber risk but lengthens divergence-detection time and raises the reconciliation workload that feeds the Stop criterion on unresolved divergence.

**Strategic Choices:**

1. Record events locally at once on each national copy and exchange signed hash-chain checkpoints over a dedicated authenticated link at fixed intervals, triggering formal reconciliation on any mismatch.
2. Exchange checkpoint digests only, with no event content, through an escrow held by a mutually accepted neutral custodian, so either side can prove after the fact that its copy was not rewritten.
3. Synchronize by air-gapped physical media carried by paired mirrored couriers on a fixed schedule, accepting longer divergence-detection windows in exchange for no live connection between national systems.

**Trade-Off / Risk:** A neutral digest custodian strengthens non-repudiation but introduces a third party into a strictly bilateral design, and offline courier sync removes network risk while making the bounded-latency KPI harder to meet.

**Strategic Connections:**

**Synergy:** Feeds Deadlock and Suspension Mechanics with a defined divergence trigger for impaired-confidence and automatic suspension, and supports Verdict Evidence Sufficiency and Threshold Calibration by giving a trustworthy evidence record.

**Conflict:** Trades off against Counterintelligence and Compartmentation Posture, since tighter synchronization widens network exposure between national secure systems, and against the bounded-latency KPI when offline couriers or neutral escrow lengthen detection windows.

**Justification:** *High*, Governs tamper-evidence, divergence detection and reconciliation workload, supplying the trigger for impaired-confidence suspension and the Stop criterion on unresolved divergence. It trades cyber exposure against latency, but is narrower in reach than the hub levers.

### Decision 8: Vendor and Operator Binding Mechanism
**Lever ID:** `53d3ae18-4058-41e6-9a09-d2e16db7abcd`

**The Core Decision:** Governs how reporting, confidentiality, escort and evidence-preservation duties reach manufacturers, maintenance providers and logistics firms through contracts, eligibility registries or shared examination centers. It determines vendor-refusal outcomes, supply continuity and the evidence available when a critical vendor withholds cooperation. Success is measured by binding coverage of declared equipment flows, refusal resolution time, compensation cost and unverifiable-equipment counts.

**Why It Matters:** This decides how reporting, confidentiality, escort and evidence-preservation duties are pushed from operators down to manufacturers, maintenance providers and logistics firms. Binding through supplier eligibility is durable but may remove critical vendors from the pilot entirely. Shared accredited examination facilities preserve vendor secrets and widen the evidence pool but add capital cost and a new facility to protect.

**Strategic Choices:**

1. Require operators to flow verification duties into every vendor contract, with each government compelling its own operators and charging resulting compensation against its own contribution.
2. Establish a pre-qualified vendor registry so only suppliers who have accepted verification terms may service declared sites, making refusal a supply-eligibility event rather than a bilateral dispute.
3. Operate shared accredited clean-room examination centers where refusing vendors submit units for supervised testing, producing filtered evidence without exposing source code, firmware or design details.

**Trade-Off / Risk:** A registry makes refusal costly but may exclude the vendors whose equipment matters most; clean-room centers keep those vendors in play yet add a high-value target whose security burden falls on the very envelopes funding inspection.

**Strategic Connections:**

**Synergy:** Enables Covered-Equipment Schedule Abstraction Ladder and Equipment Identity Trust Anchor, because bound vendors supply the identifiers, attestations and maintenance records needed to apply schedule categories and corroborate identity.

**Conflict:** Constrains Entry Gate Certification and Appropriation Release Order, as vendor binding must finish before Phase One starts, and competes with Counterintelligence and Compartmentation Posture when clean-room centers add a high-value target.

**Justification:** *High*, Determines vendor-refusal outcomes and unverifiable-equipment counts, which can fail a site outright. It enables schedule and identity evidence, and binds entry-gate timing, but its effect is concentrated on a single failure pathway.

### Decision 9: Covered-Equipment Schedule Abstraction Ladder
**Lever ID:** `26c8332c-6546-4970-84be-0bdaebf704f9`

**The Core Decision:** Sets how abstractly the confidential, versioned technical schedule defines frontier-relevant equipment so that it outlives any manufacturer, product or architecture. It determines boundary-case handling, update cadence and who may change definitions. Success metrics: share of boundary cases resolved within an agreed time (TBD), schedule-version change latency, count of unlisted devices discovered, and absence of vendor-specific anchors.

**Why It Matters:** Determines whether the confidential technical schedule describes covered equipment by functional role, by performance tier, or by operator declaration. A role-based schedule resists obsolescence and avoids tying the regime to any manufacturer or architecture, but needs specialist judgment at every boundary case. A looser schedule is easier to agree on but widens the gap through which unlisted equipment can arrive unseen.

**Strategic Choices:**

1. Define covered equipment by functional role, such as any device performing accelerated parallel computation, and let accountable specialists on both sides revise the role definitions through versioned, double-key schedule updates.
2. Adopt a tiered schedule with core, watch and exempt categories, where items migrate between tiers at fixed review points and each migration is recorded in the ledger with a justification.
3. Hold the exact classification thresholds in split escrow between the two national specialist groups, so inspectors verify equipment against a classification result without ever seeing the underlying thresholds.

**Trade-Off / Risk:** A schedule abstract enough to survive hardware generations may be too vague to adjudicate at the margin, and a sealed threshold regime invites each side to suspect the other of tuning it.

**Strategic Connections:**

**Synergy:** Gives Equipment Identity Trust Anchor a stable classification target and makes Opening Inventory Baseline and Starting-State Seal comparable across hardware generations, so intake and exit records share one definition of covered equipment.

**Conflict:** A more abstract schedule needs specialist judgment that strains Counterintelligence and Compartmentation Posture, since classification thresholds are sensitive, and it can complicate Matched Site Equivalence Basis when each side's declared equipment maps differently onto roles.

**Justification:** *Medium*, Provides the stable classification target that keeps the regime vendor-neutral and durable. Useful and connected to identity and baseline, but a mandated design requirement with fewer open trade-offs and limited effect within a 90-day test.

### Decision 10: Entry Gate Certification and Appropriation Release Order
**Lever ID:** `2e34687c-0915-4e1c-8571-953b896a8dba`

**The Core Decision:** Determines how the mandatory entry conditions (signed instrument, appropriations, domestic access authority, site selection, inspector approval, operator and vendor participation, provisional schedule) are certified, and how each USD 2.5 billion contribution is released before the 90-day clock starts. Success metrics: funding timeliness, certification completeness at clock start, matched cumulative disbursement, and time lost to single-condition stalls.

**Why It Matters:** Controls how the mandatory entry conditions are certified and how the two USD 2.5 billion contributions flow before the 90-day clock starts. Strict single-gate certification prevents a half-ready start but can stall the whole program on the slowest condition. Staged certification with tranche release speeds visible progress, yet creates partial commitments that a government could abandon after the other has already spent.

**Strategic Choices:**

1. Require one simultaneous gate in which every entry condition is certified by both co-chairs before any operational funds beyond preparation are released and before the Phase One clock starts.
2. Certify entry conditions individually with joint countersignature, and release each national contribution in matched tranches so neither side's cumulative disbursement leads the other's.
3. Place both appropriations in a reciprocal escrow whose release is triggered by a single ledger event signed by both national copies, making funding timeliness itself a verifiable gate output.

**Trade-Off / Risk:** Matched tranches protect against one-sided exposure, but they also give each government a visible, low-cost way to stall by delaying a single certification while appearing compliant.

**Strategic Connections:**

**Synergy:** Provides a verified clean start for Opening Inventory Baseline and Starting-State Seal and Matched Site Equivalence Basis, because sites, schedule and funds are fixed before baselining, which also gives Reciprocal Access Parity Accounting Method a fair opening position.

**Conflict:** A strict single gate delays deployment of Inspector Presence and Rotation Model, which needs funded, cleared staff early; staged tranche release conflicts with Deadlock and Suspension Mechanics by letting a government stall while appearing compliant.

**Justification:** *High*, Governs how mandatory entry conditions and the USD 2.5 billion contributions are certified before the clock starts, tied to funding timeliness and a Stop trigger. It is a precondition lever with significant timing conflicts, but is largely one-time.

### Decision 11: Departure Disposition Evidence Ladder
**Lever ID:** `2089051f-2718-4437-854f-e03ef413d4ce`

**The Core Decision:** Defines the proof tier each of the five Exit Protocol dispositions must reach before the ledger records closure, and the exact wording that marks where Consortium knowledge ends. Key metrics: share of departures with a closed disposition, count and age of unresolved dispositions, witness-hours consumed per departure, and zero entries implying tracking beyond the agreed boundary. Penalties for vague or deviating declarations should be set.

**Why It Matters:** Defines how much proof each Exit Protocol disposition requires and how the boundary of knowledge is stated once equipment leaves. Strong evidence for destruction and disablement raises inspector workload and facility needs. Weak evidence for release beyond the boundary risks overstating what the Consortium knows, which undermines the explicit limit of the program's claims.

**Strategic Choices:**

1. Set an evidence ladder in which witnessed destruction and verified permanent disablement each require two mirrored witnesses plus residual-material or state sampling before the ledger may record closure.
2. Require operators to pre-declare the intended disposition path before any removal, so any deviation between declared and observed path triggers an automatic unresolved-disposition entry.
3. Treat every release beyond the monitored system as a hard boundary event, recording a sealed handover and then marking the item permanently out of scope without any later tracking claims.

**Trade-Off / Risk:** Rigorous destruction witnessing consumes scarce mirrored-team capacity during surge periods, and a pre-declared path rewards operators who declare vaguely, so the ladder needs a defined penalty for unresolved cases.

**Strategic Connections:**

**Synergy:** Builds on Equipment Identity Trust Anchor, since exit witnesses can only close a disposition if the departing item matches its intake identity, and relies on Ledger Synchronization and Divergence Doctrine so closure entries stay consistent across both national copies.

**Conflict:** Competes with Inspector Presence and Rotation Model for scarce mirrored witness capacity during surges, and residual-material sampling presses against Inspection Zone Geometry and Evidence Filtering Design by requiring closer access to removed equipment.

**Justification:** *Low*, Tactical refinement of the Exit Protocol that depends on the identity anchor and ledger doctrine. It affects witness capacity during surges but does not control a foundational trade-off for the Phase One verdict.

### Decision 12: Counterintelligence and Compartmentation Posture
**Lever ID:** `3b7b12d2-cad3-43bb-b4f5-034c46d06631`

**The Core Decision:** Sets the shielding rules that keep inspectors, evidence handlers and secure facilities from becoming a collection channel for the counterpart government, and thereby protects host consent. Scope covers personnel segregation, device controls, evidence-handling spaces and insider-threat testing. Success metrics: IP or cybersecurity incidents, time to reconcile compartmented findings, inspector-context loss in substitution cases, and host-government confidence in the regime.

**Why It Matters:** Establishes how inspectors, evidence systems and secure facilities are shielded from espionage while inspectors hold sensitive visibility at the counterpart's sites. Heavy compartmentation limits exposure but isolates teams, slows reconciliation and raises staffing needs. Light compartmentation speeds work and trust-building yet increases the risk that the inspectorate becomes a collection channel, which could cause the host government to withdraw consent.

**Strategic Choices:**

1. Compartment inspectors by site and by event type, with no individual holding cross-site knowledge, supported by rotation schedules and device-free secure facilities for all evidence handling.
2. Embed a standing host-side counterintelligence liaison at each site who reviews inspector notes and outputs before release, with the counterpart's reciprocal liaison reviewing the same class of material.
3. Fund a jointly authorized insider-threat red cell that attempts to compromise inspectors and evidence handlers on both sides, with findings feeding directly into the audit record and suspension criteria.

**Trade-Off / Risk:** Compartmentation that is strict enough to reassure the host may fragment the very context inspectors need to recognize a substitution, and a joint red cell requires trust that the regime has yet to earn.

**Strategic Connections:**

**Synergy:** Reinforces Inspection Zone Geometry and Evidence Filtering Design, because compartment boundaries and physical zone limits protect the same sensitive assets, and supports Vendor and Operator Binding Mechanism by making escort and confidentiality obligations credible to hosts.

**Conflict:** Strict siloing conflicts with Inspector Presence and Rotation Model, since rotation and site-bound knowledge fragment continuity, and it slows Ledger Synchronization and Divergence Doctrine reconciliation when compartmented findings must be cleared before comparison.

**Justification:** *High*, Protects host consent and constrains inspector presence, ledger synchronization and schedule specialists. It governs the exposure-versus-context trade-off with many conflicts, but is largely a constraint on the more central detection levers.

### Decision 13: Verdict Evidence Sufficiency and Threshold Calibration
**Lever ID:** `b420a001-5aa3-44a2-8507-76b5a0d5a1bc`

**The Core Decision:** Fixes how Go, Modify and Stop are defined and defended so that verdicts rest on evidence sufficiency rather than political preference. Covers threshold-setting method, provisional-figure labeling, validation of detection-rate assumptions, and the rule mapping outcomes to verdicts. Success metrics: share of thresholds with a documented validation method, number of post-start threshold changes, and scoring divergence between national teams at verdict time.

**Why It Matters:** Establishes how the Go, Modify and Stop thresholds are set and defended, and how evidence of sufficiency is separated from either government's political preference. Thresholds fixed in advance reduce post-hoc bargaining but may rest on unvalidated assumptions about detection rates. Thresholds calibrated during the test are better grounded, though they open the door to goalposts moving after results appear.

**Strategic Choices:**

1. Pre-register every Go, Modify and Stop threshold before the clock starts, marking each unsupported figure provisional, with a documented validation method and a fixed rule for how outcomes map to verdicts.
2. Calibrate thresholds against a baseline of early blind exercises and then freeze them before the scored exercises, with the calibration and freezing steps both recorded in the ledger.
3. Have each national team score the evidence independently and sealed, then compare, so the size and direction of scoring divergence becomes a reported measure alongside the verdict itself.

**Trade-Off / Risk:** Pre-registration guards against moving the goalposts, but locking thresholds before any real detection data exists risks encoding guesses that either force an unwarranted Modify or hide a genuine weakness.

**Strategic Connections:**

**Synergy:** Draws its empirical grounding from Challenge Exercise Commitment and Scoring, whose blind-challenge results validate thresholds, and converts Reciprocal Access Parity Accounting Method trip points into defined verdict conditions rather than ad hoc judgments.

**Conflict:** Pre-registered thresholds must be locked under Entry Gate Certification and Appropriation Release Order before real detection data exists, while calibrating inside Challenge Exercise Commitment and Scoring risks moving goalposts; the two cannot both be satisfied fully.

**Justification:** *High*, Determines whether the Go/Modify/Stop outcome rests on evidence rather than politics, balancing pre-registration against calibration. It consumes exercise data and parity trip points, but is downstream of the levers that produce evidence.

### Decision 14: Opening Inventory Baseline and Starting-State Seal
**Lever ID:** `5ec44ee7-e60c-4d2e-9b0d-6a4d3ca0a070`

**The Core Decision:** Establishes the zero point against which every later arrival, removal and maintenance change is read, without becoming a capacity estimate. Choice governs how much of each operator's installed base is exposed, and how confidently early discrepancies can be interpreted. Metrics: share of declared zones with a sealed count, baseline-related discrepancies per site, time to seal, and explicit disclosure of any unverified starting population in reports.

**Why It Matters:** Because Phase One verifies changes rather than total capacity, this lever decides how the starting state of each site is established so that later changes have a reference point. A full opening census gives clearer change detection but exposes more of each operator's installed base. A thin or progressive baseline limits exposure but leaves early discrepancies harder to interpret and may let pre-existing undeclared items persist unseen.

**Strategic Choices:**

1. Seal a declared opening inventory at each site through a joint count of covered-equipment categories within the declared zones, and treat it as the zero point for all later changes.
2. Accept each operator's self-declared inventory without a count and verify only changes after entry, stating explicitly in every report that the starting population is unverified.
3. Build the baseline progressively, verifying each item only when a maintenance or movement event first touches it, so coverage grows without a full opening census.

**Trade-Off / Risk:** A progressive baseline protects operator secrecy and avoids an intrusive census, but it leaves long periods where the covered population is unknown, which weakens the credibility of a Go conclusion within a 90-day window.

**Strategic Connections:**

**Synergy:** Works with Covered-Equipment Schedule Abstraction Ladder, which defines the categories to be counted, and Matched Site Equivalence Basis, which keeps the starting-state seals comparable across the two countries' sites.

**Conflict:** A full census strains Inspection Zone Geometry and Evidence Filtering Design by exposing more installed base, and heightens operator reluctance under Vendor and Operator Binding Mechanism; a thin baseline instead weakens change-detection credibility.

**Justification:** *Medium*, Sets the reference point for change detection and trades operator exposure against early discrepancy interpretability. Dependent on the schedule and site matching, with moderate connectivity, and secondary to the intake and presence choices.

### Decision 15: Reciprocal Access Parity Accounting Method
**Lever ID:** `2f26510b-2612-4944-a42d-4d71d11be910`

**The Core Decision:** Defines operationally what reciprocal access means and how it is measured, since parity underpins both the Go and Stop conditions and triggers impaired-confidence review. Scope covers the unit of comparison, tolerance bands, reason-coded denials and delays, and how non-identical sites are normalized. Metrics: parity variance between matched sites, count and age of unexplained denials, and time from trip point to review.

**Why It Matters:** This lever defines what 'reciprocal access' means in operation and how it is measured, since parity drives the Go and Stop conditions. Counting access events is simple and auditable but can be satisfied with low-value access, while measuring outcomes captures real verification capability but requires comparable test conditions. The chosen method also determines when impaired-confidence procedures are triggered.

**Strategic Choices:**

1. Count parity by matched events, requiring that each entry, inspector-hour and evidence request granted at one country's site be mirrored at its counterpart within a jointly set tolerance.
2. Measure parity by outcome, comparing the detection performance and evidence sufficiency each side achieves at its matched site in blind challenges rather than the amount of access granted.
3. Keep a standing parity ledger that logs every denial, delay and filter with a reason code, and tie jointly set trip points in it to automatic impaired-confidence review.

**Trade-Off / Risk:** Outcome-based parity is the more meaningful measure, but it depends on exercise comparability across non-identical sites, so a disputed comparison can stall the very Go decision the metric is meant to support.

**Strategic Connections:**

**Synergy:** Feeds Deadlock and Suspension Mechanics with objective trip points for impaired-confidence and automatic suspension, and depends on Matched Site Equivalence Basis to make site comparisons defensible.

**Conflict:** Outcome-based parity requires comparable trials from Challenge Exercise Commitment and Scoring across non-identical sites, and disputed comparisons can stall Verdict Evidence Sufficiency and Threshold Calibration, delaying the very decision parity is meant to support.

**Justification:** *High*, Defines how reciprocal access, a Go and Stop condition, is measured and supplies objective trip points for impaired-confidence review. It links site matching, exercises, suspension and verdict, with disputes able to stall the decision.
