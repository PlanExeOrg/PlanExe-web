## Primary Decisions
The vital few decisions that have the most impact.


The Critical levers (Layered Evidence Weighting, Inspector Information Firewall, Blind Challenge Exercise Control, Verdict Threshold Calibration, Deadlock and Suspension) address the core tensions: verification strength versus protection of sensitive technology, detection credibility versus production disruption, and stalling versus brittle suspension under equal co-chairs. High levers govern cost, parity and exposure trade-offs. No major strategic dimension appears missing, though operator and host-government compliance incentives are only indirectly covered.

### Decision 1: Layered Evidence Weighting Model
**Lever ID:** `c2bc2403-915c-45b2-a589-b97885c08f92`

**The Core Decision:** Specifies the rule by which attestation, physical inspection, customs and shipment records, identifiers, maintenance logs, infrastructure changes and witnessed movement combine into an equipment-identity confidence rating. It must honor the principle that no single source is decisive. Success metrics: calibration of confidence against blind-exercise ground truth, false-positive and false-negative rates, and adjudication caseload generated per month.

**Why It Matters:** This lever decides how attestation, physical inspection, customs and shipment records, identifiers, maintenance logs, infrastructure changes and witnessed movement combine into an equipment-identity confidence rating. A transparent rule makes findings defensible to both governments. A rigid rule can be gamed by an operator who knows which evidence types carry the most weight, and a loose one produces disputes that overload adjudication.

**Strategic Choices:**

1. Apply a published rule requiring corroboration from a minimum number of independent evidence categories, with no category sufficient alone, and keep the category list in the confidential versioned schedule.
2. Use a confidential, rotating combination rule set by accountable specialists from both sides, so operators cannot learn which evidence combinations suffice, with weights validated against blind-exercise outcomes.
3. Score identity confidence by contradiction rather than accumulation, so any unresolved conflict between two evidence layers lowers the rating regardless of how much other evidence supports identity.

**Trade-Off / Risk:** Contradiction-based scoring resists gaming and fits the rule that no single source is decisive, but it may flag benign record errors as discrepancies and push adjudication workload above what the inspectorate can absorb.

**Strategic Connections:**

**Synergy:** Supplies the scoring basis for Verdict Threshold Calibration Method and works with Covered-Equipment Schedule Revision Rhythm, because the confidential schedule defines which evidence categories exist and can be reweighted as equipment changes.

**Conflict:** Conflicts with Deadlock and Suspension Mechanics and Inspector Information Firewall Doctrine: stricter or contradiction-based scoring raises discrepancy counts and aging pressure, while filtered evidence limits the layers inspectors may combine.

**Justification:** *Critical*, Central hub: converts all evidence layers into identity confidence, feeds verdict scoring, vendor fallback credit and schedule alignment. Controls the false-positive/negative versus adjudication-load trade-off and the 'no single source decisive' principle, and conflicts with firewall and deadlock levers.

### Decision 2: Deadlock and Suspension Mechanics
**Lever ID:** `65da5760-ec8d-4347-90c0-b34edded6de6`

**The Core Decision:** Defines how the equal co-chairs' deadlocks over budgets, protocol changes, site findings and sanctions are handled, and when impaired-confidence or automatic suspension applies without a casting vote. It protects the mission from both stalling and brittle shutdowns. Success metrics: time to resolve deadlocks, unresolved discrepancy age, suspension frequency and duration, and share of verification kept running.

**Why It Matters:** This lever determines what happens when the co-chairs cannot agree on a budget, protocol change, site finding or sanction. Without a casting vote, the design of deadlock, impaired-confidence and automatic-suspension rules decides whether a dispute pauses the mission safely or lets one side stall. Rules that suspend too readily make the program fragile, and rules that suspend too rarely allow unresolved findings to build up.

**Strategic Choices:**

1. Pause only the disputed function through automatic partial suspension after a fixed period, leaving unrelated verification running and recording each pause in the ledger as an event.
2. Refer deadlocked findings to a standing panel of technical specialists nominated equally by both sides, whose advisory conclusion is non-binding but is published to both co-chairs and logged.
3. Link suspension to the age of unresolved discrepancies, so a finding left open past a set limit moves the site into impaired-confidence status without a decision by either co-chair.

**Trade-Off / Risk:** Age-triggered impaired-confidence status removes the need for a joint decision, yet the age limit is itself a figure both governments must agree on, so the stalling problem is shifted to its calibration.

**Strategic Connections:**

**Synergy:** Reinforces Appropriations Tranche and Audit Cadence, since funding disputes can use the same pause rules, and Verdict Threshold Calibration Method, by tying aged discrepancies to explicit Modify or Stop triggers.

**Conflict:** Conflicts with Layered Evidence Weighting Model and Ledger Synchronization Bounds: higher discrepancy volume or ledger divergence accelerates suspension triggers, while the agreed age limit moves the stalling risk into calibration.

**Justification:** *Critical*, Controls the foundational governance tension of equal co-chairs with no casting vote: stalling versus brittle shutdown. Connects to evidence volume, ledger divergence, funding, schedule amendments and verdict triggers, making it a hub for mission continuity.

### Decision 3: Blind Challenge Exercise Control
**Lever ID:** `1474c892-bbc3-4e7a-85cc-9fe1974499b2`

**The Core Decision:** Sets who designs, schedules, executes and scores the live challenge exercises that produce the only direct detection evidence in Phase One. Key success metrics are scenario coverage across all seven event types, scorer independence accepted by both governments, zero interruption of active computation, and enough trials per event type to state detection rates with explicit, labeled uncertainty.

**Why It Matters:** This lever decides who designs, schedules and scores the live exercises covering unreported arrival, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal and a reluctant operator. Control over the design affects whether detection results are credible to both governments. Independent control costs more and complicates operator coordination, and exercises must run in staging, spare-inventory, maintenance or expansion areas without interrupting active computational work.

**Strategic Choices:**

1. Fund an independent test authority with mixed-nationality staff to design and run all exercises, with each government's inspectorate blind to the scenarios until execution.
2. Have each country's red team design challenges for the other country's inspectorate, so each side tests the verification it has the most reason to doubt, with an independent referee scoring results.
3. Interleave unannounced challenges with routine operations throughout the test rather than scheduling discrete exercise windows, so inspectors cannot adjust their behavior for known test periods.

**Trade-Off / Risk:** Unannounced challenges give more realistic detection data, but they raise the risk of production disruption and operator resistance, and a few events per type may be too few to support any statistical claim about false negatives.

**Strategic Connections:**

**Synergy:** Supplies the detection data that Verdict Threshold Calibration Method needs to score Go, Modify or Stop. It also stress-tests the Vendor Refusal Fallback Ladder and Mirrored Shift Coverage Architecture under realistic, unannounced conditions.

**Conflict:** Unannounced or interleaved challenges strain Mirrored Shift Coverage Architecture and risk production disruption. Exercise secrecy also competes with Matched Site Selection Doctrine, because operators must still grant staging-area access and coordinate cover.

**Justification:** *Critical*, Exercises produce the only direct detection evidence in Phase One, so credibility of the Go/Modify/Stop decision depends on who designs and scores them. Hub linking site selection, shift coverage, vendor ladder and verdict calibration, with production-disruption trade-offs.

### Decision 4: Verdict Threshold Calibration Method
**Lever ID:** `719358dc-940c-4de4-93a1-e852e5d255cc`

**The Core Decision:** Converts exercise outcomes (detection by event type, false positives and negatives, unverifiable equipment, parity) into Go, Modify or Stop. It determines whether the final decision reads as technical or negotiated. Success means thresholds fixed before results are known, each marked provisional or TBD with a stated validation path, and statistical limits from few events per type stated openly.

**Why It Matters:** This sets how detection rates, false positives and unverifiable equipment are converted into Go, Modify or Stop. Fixed numeric cutoffs give clarity but would rest on figures that cannot be validated before the first exercises. Judgment-based thresholds adapt to evidence but invite dispute and political reading of ambiguous results. The choice determines whether the final decision is seen as technical or negotiated.

**Strategic Choices:**

1. Set provisional thresholds before the first exercise, mark each as provisional or TBD, and lock them only after a mirrored panel validates them against pilot data.
2. Define thresholds as bands rather than points, so results inside a band trigger Modify by default and only results clearly outside it support Go or Stop.
3. Have an independent testing body, not the co-chairs, score exercise results against a pre-registered rubric, with the co-chairs allowed only to confirm or contest the scoring through double-key procedure.

**Trade-Off / Risk:** Pre-registered thresholds resist post-hoc bargaining, but with only a short operational test and few events per type, the statistical basis is thin, so confidence in any numeric cutoff must be labeled provisional.

**Strategic Connections:**

**Synergy:** Builds directly on data from Blind Challenge Exercise Control and on the evidence confidence outputs of Layered Evidence Weighting Model, giving the final decision a traceable, pre-registered basis that both governments can audit.

**Conflict:** Strict pre-registered cutoffs constrain Appropriations Tranche and Audit Cadence, since funding releases may depend on interim results. They also conflict with Covered-Equipment Schedule Revision Rhythm when mid-test schedule changes make results non-comparable.

**Justification:** *Critical*, Converts exercise data into Go, Modify or Stop and decides whether the outcome is technical or negotiated. Consumes outputs of exercises and evidence weighting and ties to suspension triggers and funding; thin statistics make its design decisive for credibility.

### Decision 5: Inspector Information Firewall Doctrine
**Lever ID:** `31c8cfb6-de4f-4767-b4d9-8d881591e887`

**The Core Decision:** Governs what inspectors can observe, carry, record and disclose, and how knowledge is contained after rotation, protecting workloads, topology, source code and unrelated infrastructure. It sets the trust balance between operator confidence and inspector ability to resolve identity questions. Metrics: IP or cybersecurity incidents, unverifiable-equipment count, filter-dispute rate, and the audit trail of raw-observation access.

**Why It Matters:** Controls what inspectors may see, carry, record and say, and how their knowledge is contained after rotation. Tighter firewalls protect workloads, topology and source code but can leave inspectors unable to resolve ambiguous identity evidence, raising the unverifiable-equipment count and pushing more cases to adjudication.

**Strategic Choices:**

1. Run inspectors through a sealed observation-and-report model in which they hold only the filtered evidence interface, with raw observations retained in site custody for later audited review.
2. Pair each inspector with an operator-side security officer who pre-screens each view and recording, trading some speed for operator confidence that no unrelated infrastructure was exposed.
3. Compartmentalize inspector knowledge by role and site, with post-assignment debriefs and monitored cooling-off periods before any reassignment to other duties.

**Trade-Off / Risk:** A sealed interface best protects sensitive technology, but it makes inspectors depend on the filtering rules, so disputes shift from what was seen to who wrote the filter and whether it hides discrepancies.

**Strategic Connections:**

**Synergy:** Pairs with Counterpart Evidence Disclosure Tiers, which sets what filtered evidence reaches the other side, and with Root-of-Trust Key Custody Architecture, which can secure raw observations held in site custody.

**Conflict:** Tighter firewalls work against Vendor Refusal Fallback Ladder and Layered Evidence Weighting Model, because filtered views leave less evidence for identity confidence. That raises unverifiable counts and adjudication load.

**Justification:** *Critical*, Controls the core tension between protecting sensitive technology and giving inspectors enough evidence to verify. Determines unverifiable counts, adjudication load and incident risk, and conflicts with evidence weighting, vendor fallback and shift coverage, making it a foundational hub.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Matched Site Selection Doctrine
**Lever ID:** `d352cbea-8bbf-460f-a173-29715cf307e8`

**The Core Decision:** Defines how the small set of declared datacenters is nominated, paired and confirmed before the Phase One clock starts. Scope covers pairing logic, veto or reconciliation rights, and documented rationale for each pairing. Success metrics: reciprocal-access parity score, share of exercise-eligible staging, spare-inventory, maintenance and expansion areas per pair, and time to complete site selection as an entry condition.

**Why It Matters:** This lever sets how the small set of declared datacenters is chosen and paired. It determines whether reciprocal-access parity can be demonstrated and whether the exercises are representative or flattering. Sites that are easy to inspect make the test pass but say little about harder cases. Sites that are too sensitive may stall the entry conditions before the 90-day clock starts.

**Strategic Choices:**

1. Pair sites by functional equivalence of staging, spare-inventory and maintenance areas, with each side proposing candidates and the other holding a veto over any site it judges unrepresentative.
2. Pair sites through a sealed, simultaneous exchange of nominations, then reconcile mismatches in a structured negotiation that weights parity of inspector access over similarity of facility scale.
3. Pair each declared site with a deliberately contrasting counterpart, such as a hyperscale operator against a government-run facility, so the test exposes asymmetries in operator reluctance and legal authority.

**Trade-Off / Risk:** Functional equivalence makes parity measurable, but no two datacenters across both systems are truly equivalent, so every pairing embeds a judgment that either side can later cite as grounds for discounting an unfavorable result.

**Strategic Connections:**

**Synergy:** Feeds Mirrored Shift Coverage Architecture, since site count and layout drive staffing, and strengthens Blind Challenge Exercise Control by supplying representative, comparable areas where unreported-arrival and substitution tests can be run.

**Conflict:** Pressures Vendor Refusal Fallback Ladder and Counterpart Evidence Disclosure Tiers: sites chosen for comparable access may host vendors or equipment that resist disclosure, and sensitive sites may stall entry conditions.

**Justification:** *High*, Determines whether reciprocal-access parity is demonstrable and whether exercises are representative. Feeds staffing and exercise design and pressures vendor and disclosure levers. It is an entry condition, so it can stall the clock, but it is largely a one-time gate decision.

### Decision 7: Ledger Synchronization Bounds
**Lever ID:** `f86475f4-cfae-44c1-b1a9-4be1ec3739f4`

**The Core Decision:** Sets the timing and mechanism by which locally recorded events become visible in the counterpart's ledger copy, and how divergence is detected and reconciled. It governs the trade-off between tamper-detection window and cross-border exposure. Success metrics: event-recording latency, synchronization latency, divergence incidents, reconciliation time, and number of unresolved ledger divergences.

**Why It Matters:** This lever sets how quickly local events become visible to the counterpart and how divergence between the two national copies is detected and resolved. Tighter bounds shrink the window for undetected tampering but increase network exposure and operational burden at sites. Looser bounds reduce the attack surface but allow divergence to build before anyone can see it.

**Strategic Choices:**

1. Record every event locally at once and exchange signed digests with the counterpart copy on a fixed short interval, escalating automatically when any digest fails to match.
2. Synchronize only at defined custody handover points, such as completion of intake or exit dispositions, and rely on witnessed local recording in between, which reduces continuous cross-border data flow.
3. Introduce a neutral third-party notary for digest escrow only, holding no event content, so a divergence dispute can be resolved by checking against an independently held commitment.

**Trade-Off / Risk:** A third-party notary adds a tie-breaker for divergence, but it introduces a party neither government fully controls, and the premise of double-key governance with no casting vote makes its acceptance politically uncertain.

**Strategic Connections:**

**Synergy:** Depends on and reinforces Root-of-Trust Key Custody Architecture, since signed digests need trustworthy keys, and supports Departure Disposition Closure Rules by timestamping custody handovers so exits stay verifiable within the boundary.

**Conflict:** Trades off against Inspector Information Firewall Doctrine and Mirrored Shift Coverage Architecture: tighter synchronization widens network exposure and adds shift workload, while looser bounds weaken the evidence base for discrepancy adjudication.

**Justification:** *High*, Governs the tamper-detection window versus cross-border exposure trade-off for the core ledger. Depends on key custody and supports exit closure, but it is a technical parameter choice with fewer system-wide strategic consequences than the evidence or governance levers.

### Decision 8: Vendor Refusal Fallback Ladder
**Lever ID:** `732264f2-7f1a-4800-8ac0-6fcc15081e37`

**The Core Decision:** Determines how the Consortium responds when a critical vendor declines reporting, escort or evidence-preservation duties, and how each fallback method is credited toward verification. It governs whether equipment is classed as unverifiable and whether a site fails Phase One. Success metrics: vendor-refusal outcomes by rung, unverifiable-equipment count, and evidence sufficiency per fallback.

**Why It Matters:** This lever sets the order and conditions under which vendor-supervised testing, filtered evidence, accredited independent examiners, clean-room procedures or validated attestations are used when a critical vendor refuses. A fixed ladder gives predictability, but a vendor can aim for the weakest rung. Whether equipment ends up classed as unverifiable, and whether a site fails Phase One, depends on how each rung is credited.

**Strategic Choices:**

1. Follow a fixed escalation order from vendor-supervised testing to accredited independent examination, and classify equipment as unverifiable once the last rung has been tried without sufficient evidence.
2. Let the receiving national team choose the fallback for each refusal, subject to the counterpart's right to demand a stronger method, so neither side is bound to a method it distrusts.
3. Make vendor participation a condition of listing equipment on the covered schedule, so refusal is settled at entry by excluding the item or the site rather than discovered later during operations.

**Trade-Off / Risk:** Settling refusal at the entry gate avoids mid-test surprises, but it lets vendors shape which equipment is verifiable at all, and the resulting schedule may omit exactly the items the Consortium most needs to see.

**Strategic Connections:**

**Synergy:** Works with Layered Evidence Weighting Model, which determines how much evidentiary credit each fallback rung earns, and with Blind Challenge Exercise Control, which tests vendor-refusal scenarios against the ladder.

**Conflict:** Constrains Covered-Equipment Schedule Revision Rhythm and Matched Site Selection Doctrine: entry-gate exclusion lets vendors shape the schedule and site set, while a fixed ladder invites aiming at the weakest rung.

**Justification:** *High*, Decides when equipment becomes unverifiable and whether a site fails Phase One, a direct Stop trigger. Linked to evidence weighting, exercises, schedule and site selection, but it addresses one specific scenario rather than the whole system.

### Decision 9: Covered-Equipment Schedule Revision Rhythm
**Lever ID:** `95d82a58-50fa-4a12-b4d8-63c145be0524`

**The Core Decision:** Governs how the confidential, versioned technical schedule of covered equipment is amended so it stays technology-neutral and does not lapse into a product list. It sets amendment timing, approval path, effective-time rules and version traceability. Success is measured by coverage gaps found, amendment cycle time, scope disputes opened, and exercise results that remain comparable across schedule versions.

**Why It Matters:** This determines how the confidential, versioned technical schedule is amended as hardware generations, form factors and performance characteristics change. A tight rhythm keeps coverage relevant and prevents the schedule from lapsing into a product list. It also gives each side frequent openings to argue scope and to learn what the other treats as frontier-relevant. A loose rhythm reduces negotiation friction but risks gaps that undercut credibility of detection.

**Strategic Choices:**

1. Freeze the provisional schedule for the entire Phase One test and defer all amendments to the final decision, trading coverage freshness for stability and fewer scope disputes.
2. Allow amendments at fixed review points set by the accountable specialists, with each version double-key approved and applied only to events recorded after its effective time.
3. Maintain a standing mirrored technical panel that proposes amendments continuously, with each change held in escrow and activated only after the counterpart panel independently reproduces the classification logic.

**Trade-Off / Risk:** Frequent revisions keep the schedule from being outflanked by new hardware, but each amendment is a double-key negotiation that can stall under deadlock, and mid-test changes complicate comparing exercise results across versions.

**Strategic Connections:**

**Synergy:** Keeps the Layered Evidence Weighting Model aligned with current hardware, so identity and attestation evidence classify correctly. A stable version history also supports Verdict Threshold Calibration Method by making exercise results comparable.

**Conflict:** Each amendment needs double-key approval, so frequent revisions load Deadlock and Suspension Mechanics. They also reveal frontier-relevance judgments, pulling against Counterpart Evidence Disclosure Tiers, which aim to limit what the counterpart learns.

**Justification:** *Medium*, Keeps the confidential schedule technology-neutral and preserves comparability of results, but within a 90-day test a freeze or fixed review points is a manageable option. Moderate coupling to deadlock and disclosure levers; mainly an optimization.

### Decision 10: Counterpart Evidence Disclosure Tiers
**Lever ID:** `e993aa9d-6f74-47e1-9ec6-e3db52e53680`

**The Core Decision:** Defines how much of each event record and its underlying evidence the counterpart national team can see, from identifiers only to supervised full-detail reading. It sets the balance between challengeability and protection of workloads, topology, security architecture and unrelated infrastructure. Metrics include disputes caused by opaque records, IP or cybersecurity incidents, filtering-certification latency and the share of findings the counterpart can check.

**Why It Matters:** This defines what the counterpart national team sees of each event record: identifiers only, filtered images and attestations, or full detail inside a controlled room. Wider disclosure raises the ability to challenge a finding but exposes network layout, security architecture and unrelated infrastructure. Narrower disclosure protects intellectual property but pushes more disputes into adjudication because the counterpart cannot check the basis for a record.

**Strategic Choices:**

1. Give the counterpart only hashed event summaries and equipment identifiers by default, releasing underlying evidence solely when a discrepancy is formally opened by double-key authorization.
2. Provide the counterpart with filtered evidence packages prepared by the host side's inspectors, with an independent examiner certifying that filtering removed nothing event-relevant.
3. Hold raw evidence in a joint secure reading room where counterpart specialists can query it under supervision but cannot copy or retain it, trading convenience for tighter exposure control.

**Trade-Off / Risk:** Tiered disclosure protects sensitive detail, but filtering is itself a point where a host can omit inconvenient evidence, so the filtering step needs independent certification that adds latency and cost.

**Strategic Connections:**

**Synergy:** Strengthens Inspector Information Firewall Doctrine by applying the same boundaries to counterpart access, and gives Layered Evidence Weighting Model credible inputs because each side can check the basis of a record.

**Conflict:** Narrow tiers push disputes into Deadlock and Suspension Mechanics, since the counterpart cannot verify records. Wider tiers add exposure risk and certification delay, which can lengthen the synchronization times set by Ledger Synchronization Bounds.

**Justification:** *High*, Sets the challengeability versus IP-protection balance between national teams. Narrow tiers push disputes into deadlock, wide tiers add exposure and latency. Strongly coupled with firewall, evidence weighting and ledger timing, though overlapping the firewall lever.

### Decision 11: Root-of-Trust Key Custody Architecture
**Lever ID:** `7cb65114-fa5d-4343-9281-05785a8b8877`

**The Core Decision:** Specifies who generates, holds, rotates, recovers and revokes the signing keys that make ledger entries and validated attestations trustworthy to both countries. Scope covers ceremonies, hardware modules, compromise response and recovery. Success metrics include zero unauthorized signings, key-rotation timeliness, recovery time after a lost or contested key, and cross-certification disputes that cause ledger divergence.

**Why It Matters:** Determines who generates, holds and rotates the signing keys behind the tamper-evident ledger and validated attestations. Split custody strengthens the double-key principle but adds ceremony overhead and recovery complexity, and a lost or contested key can stall evidence validity at a site until the deadlock procedures resolve it.

**Strategic Choices:**

1. Generate keys in joint ceremonies at a neutral secure facility, with each country holding a non-reconstructable share and both shares required for any ledger signing or attestation validation.
2. Give each country fully independent signing hierarchies for its own national ledger copy, cross-certified through audited exchange, so neither side's evidence depends on the other's key material.
3. Issue short-lived signing keys from hardware modules sealed inside inspection zones and destroyed on a fixed cycle, so compromise exposure is bounded even if custody procedures are later challenged.

**Trade-Off / Risk:** Shared key shares match the double-key design, but they create a single ceremony chokepoint; independent hierarchies avoid that and instead push the risk into cross-certification disputes that could surface as ledger divergence.

**Strategic Connections:**

**Synergy:** Underpins Ledger Synchronization Bounds by making each replicated copy verifiable, and reinforces the double-key principle in Deadlock and Suspension Mechanics through shared custody and clear key-contest procedures.

**Conflict:** Joint-share ceremonies create chokepoints that can stall Ledger Synchronization Bounds and Mirrored Shift Coverage Architecture during round-the-clock recording. Independent hierarchies avoid this but risk disputes that Deadlock and Suspension Mechanics must resolve.

**Justification:** *Medium*, Underpins ledger trustworthiness and the double-key principle, but is largely an enabling security mechanism. Its main impact flows through ledger synchronization and deadlock procedures, so it is important to implement well yet less of a strategic choice.

### Decision 12: Departure Disposition Closure Rules
**Lever ID:** `4a4a2789-ec70-4325-b658-b90fa7c74631`

**The Core Decision:** Sets the ledger rules that turn every departure into one of the five Exit Protocol dispositions: witnessed destruction, verified permanent disablement, transfer to another participating site, documented release beyond the monitored system, or unresolved disposition. Key metrics are the share of departures closed within window, unresolved discrepancy age, and the rate of closures later contested. Closure windows (proposed, TBD) need validation in exercises.

**Why It Matters:** Governs how each removal is classified and closed in the ledger, and when an open disposition becomes a finding. Strict closure deadlines keep the ledger honest about the monitored boundary, but they can force premature classification of unresolved items and trigger suspensions from ordinary logistics delays.

**Strategic Choices:**

1. Require every departure to reach one of the defined dispositions within a fixed period, and automatically escalate any item still open to a formal discrepancy at expiry.
2. Allow tiered closure windows by disposition type, giving transfers between participating sites a shorter period and destruction or disablement witnessing a longer, scheduled period.
3. Treat release beyond the monitored system as a terminal ledger state that records the handover point only, and bar any later inspector entries about that equipment's whereabouts.

**Trade-Off / Risk:** Terminal release entries respect the rule against implying knowledge beyond the boundary, but they also let a party move equipment out cleanly; the closure deadline then does little to address what the release hides.

**Strategic Connections:**

**Synergy:** Works with Layered Evidence Weighting Model, which supplies the evidence standard for each disposition, and Deadlock and Suspension Mechanics, which gives expired open items a defined route to formal discrepancy and suspension.

**Conflict:** Strict deadlines pressure Mirrored Shift Coverage Architecture, since witnessing destruction or transfers on schedule needs inspectors available. They also tighten Verdict Threshold Calibration Method, because ordinary logistics delays can inflate unresolved counts.

**Justification:** *Medium*, Operationalizes the Exit Protocol and closure deadlines for ledger honesty, with links to evidence standards, shift scheduling and unresolved counts. Mostly a procedural rule set whose effects are contained to departures rather than the core trade-offs.

### Decision 13: Mirrored Shift Coverage Architecture
**Lever ID:** `547dc5ad-0929-4c4c-bbef-e871d96babf5`

**The Core Decision:** Determines how mirrored national teams are rostered at each participating site, including shift patterns, minimum paired presence, leave cover and surge capacity. It converts site count and coverage choices into full-time headcount, so it drives the inspector envelope and exposure to operator friction. Metrics: detection rate for unreported arrivals, coverage gaps per shift, roster fill rate, and personnel cost per site (TBD).

**Why It Matters:** Defines whether inspectors are continuously present or deployed around expected events, which drives headcount, leave coverage and surge needs. Continuous presence improves detection of unreported arrivals but multiplies personnel cost within the inspector envelope and increases operator friction and counterintelligence exposure.

**Strategic Choices:**

1. Station mirrored teams at each site around the clock in rotating shifts, with fixed minimum paired presence in staging and spare-inventory areas at all times.
2. Maintain continuous coverage of staging and loading points only, and cover maintenance and expansion areas through scheduled and short-notice event-triggered deployments.
3. Use a hybrid roster with a continuous core crew and a pooled national surge unit that deploys to whichever site shows rising event volume or unresolved discrepancies.

**Trade-Off / Risk:** Continuous presence maximizes detection of unreported arrivals but strains the USD 750 million personnel envelope; event-triggered coverage saves headcount but leaves gaps that a determined party can schedule around.

**Strategic Connections:**

**Synergy:** Amplifies Blind Challenge Exercise Control, because continuous presence in staging and spare areas gives exercises a fair test of detection. It also supports Departure Disposition Closure Rules by making witnessed removals schedulable.

**Conflict:** Heavy headcount competes with Appropriations Tranche and Audit Cadence for the fixed USD 750 million personnel envelope. Continuous presence also strains Inspector Information Firewall Doctrine, since more inspector hours mean more exposure to protect.

**Justification:** *High*, Drives headcount, the USD 750 million personnel envelope, detection of unreported arrivals and operator friction. Strongly connected to exercises, exit scheduling, firewall exposure and funding, governing a major cost versus detection trade-off.

### Decision 14: Language of Record and Interpretive Authority
**Lever ID:** `c0308540-c69b-4ade-9d36-c505d5a58ea1`

**The Core Decision:** Defines which language text governs protocols, ledger entries and findings, and how translation disputes are resolved before they harden into contested findings. It sizes the translation unit and sets leakage risk when sensitive evidence is translated. Metrics: translation turnaround, count of divergence rulings, findings returned for terminology disputes, and adjudication cycle time (targets TBD).

**Why It Matters:** Establishes which language version of protocols, evidence entries and findings is authoritative and how translation disputes are resolved. This choice shapes how fast discrepancies are adjudicated and whether a mistranslated term can itself become a contested finding. It also affects translation unit size and the risk of information leakage during translation.

**Strategic Choices:**

1. Designate both language versions as equally authoritative, with a joint terminology board issuing a controlled glossary and ruling on divergences before they enter the ledger.
2. Record evidence entries in a structured, language-neutral schema with coded fields, limiting free text and using translation only for narrative annotations and findings.
3. Require independent bilingual reviewers from each country to back-translate every finding before double-key sign-off, rejecting any finding whose back-translations materially differ.

**Trade-Off / Risk:** Dual authoritative texts avoid a language hierarchy but invite divergent readings; coded schemas reduce ambiguity yet may squeeze out context that inspectors need to describe an unusual discrepancy.

**Strategic Connections:**

**Synergy:** Strengthens Ledger Synchronization Bounds, because shared coded fields and a controlled glossary make the two national copies easier to reconcile. It also supports Counterpart Evidence Disclosure Tiers by standardizing what each tier means in both languages.

**Conflict:** Back-translation and glossary rulings slow Deadlock and Suspension Mechanics, which depend on timely findings. Coded schemas can also limit the context that Layered Evidence Weighting Model needs to describe unusual discrepancies.

**Justification:** *Low*, Affects translation turnaround and terminology disputes but is mostly a supporting, tactical standard. Its synergies with ledger and disclosure levers are real yet secondary, and its slowing effect on adjudication can be managed through glossary design.

### Decision 15: Appropriations Tranche and Audit Cadence
**Lever ID:** `783534e4-1c16-4932-9535-bd26bb241c0a`

**The Core Decision:** Specifies how the two USD 2.5 billion contributions are drawn down and audited against the seven-envelope map, with every expense mapped to an envelope. It makes funding timeliness and audit exceptions measurable and supports the Stop condition for withheld funding. Metrics: deposit parity, days of tranche delay, envelope reconciliation exceptions, and contingency draw rate. Domestic operator compensation is charged to each government's own contribution.

**Why It Matters:** Sets how the two equal contributions are drawn down and audited against the envelope map. Frequent tranches and audits expose funding shortfalls and mis-mapped expenses early, which supports the stop condition on withheld funding, but they create recurrent leverage points where either government can slow disbursement.

**Strategic Choices:**

1. Release both contributions in synchronized tranches tied to entry-condition milestones, with the next tranche conditional on matching deposits and clean envelope reconciliation.
2. Hold each country's full contribution in escrow-style national accounts under joint visibility and let drawdown occur on invoice, with independent auditors testing envelope mapping continuously.
3. Fund inspectorate and ledger envelopes first and defer site preparation and testing draws until site eligibility is confirmed, limiting committed spend if a gate fails.

**Trade-Off / Risk:** Synchronized tranches make withholding visible and symmetric, but each release is a veto point; escrow-style accounts lessen that leverage while relying on audit quality to catch misuse, which the plan cannot yet demonstrate.

**Strategic Connections:**

**Synergy:** Supports Deadlock and Suspension Mechanics by giving funding delay a defined trigger and visibility. Also supports Mirrored Shift Coverage Architecture by letting surge and contingency spending be planned against audited envelopes.

**Conflict:** Tranche gates create veto points that can delay Matched Site Selection Doctrine and site preparation. Frequent audit cycles also add administrative load on Mirrored Shift Coverage Architecture and inspectorate staffing.

**Justification:** *Medium*, Makes funding timeliness and audit exceptions measurable and supports the withheld-funding Stop condition. Creates veto points affecting site selection and staffing, but is mainly financial-governance optimization rather than a driver of detection credibility.
