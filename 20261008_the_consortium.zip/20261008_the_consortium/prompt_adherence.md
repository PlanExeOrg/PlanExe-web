**Overall Adherence: 98%**

```
IMPORTANCE_ADHERENCE_SUM = (5×5 + 5×5 + 5×5 + 4×5 + 5×5 + 5×5 + 5×5 + 5×5 + 5×5 + 5×5 + 4×4 + 4×5 + 5×5 + 4×4 + 5×5 + 2×5 + 5×5) = 382
IMPORTANCE_SUM = 5 + 5 + 5 + 4 + 5 + 5 + 5 + 5 + 5 + 5 + 4 + 4 + 5 + 4 + 5 + 2 + 5 = 78
OVERALL_ADHERENCE = IMPORTANCE_ADHERENCE_SUM / (IMPORTANCE_SUM × 5) = 382 / 390 = 98%
```

## Summary

| ID | Directive | Type | Importance | Adherence | Category |
|----|-----------|------|------------|-----------|----------|
| 1 | Both countries' leaders believe uncontrolled frontier AI threatens national security and their continued political control, providing direct backing and sufficient domestic authority to compel participation. | Stated fact | 5/5 | 5/5 | Fully honored |
| 2 | Phase One is a 90-day operational test; its clock begins only after bilateral instrument signature, appropriations, enacted domestic access authority, selected participating sites, approved inspectors, secured operator/vendor participation, and adopted provisional covered-equipment schedule. | Requirement | 5/5 | 5/5 | Fully honored |
| 3 | Total budget USD 5.0 billion, exactly 50/50 split (USD 2.5 billion per country), allocated to seven envelopes: ledger/attestation/evidence/comms 1,250M; site prep/operator compensation 1,000M; inspectors/personnel/training/translation 750M; secure facilities/cyber/counterintelligence 750M; testing/challenge/red teams 500M; legal/auditing 250M; contingency/surge 500M. | Constraint | 5/5 | 5/5 | Fully honored |
| 4 | Domestic operator and vendor compensation administered by the home government and charged to its own USD 2.5B contribution, within the site-preparation/compensation envelope. | Constraint | 4/5 | 5/5 | Fully honored |
| 5 | The Consortium is a sovereign public-sector national-security program, not a for-profit project, business, nonprofit, investment, partnership, or revenue-generating institution. | Stated fact | 5/5 | 5/5 | Fully honored |
| 6 | Address only declared-equipment change verification at participating sites. Do not estimate total computing capacity, verify workloads, inspect model weights, prove absence of hidden facilities, cover foreign-hosted infrastructure, or create comprehensive AI-governance regime. | Requirement | 5/5 | 5/5 | Fully honored |
| 7 | Governance uses equal national co-chairs and double-key authorization for budgets, protocol changes, site findings, sanctions and suspension. No chair may have a casting vote; no majority may overrule the other country. Define deadlock, impaired-confidence and automatic-suspension procedures. | Requirement | 5/5 | 5/5 | Fully honored |
| 8 | Model staffing from participating-site count, shift coverage, mirrored national teams, separation of duties, leave coverage and surge requirements. No single-person critical functions, part-time/temporary-agency inspectors, or fictional biographies. Full-time mirrored inspection, technical, legal, cybersecurity, counterintelligence, translation, audit, logistics and adjudication units. | Constraint | 5/5 | 5/5 | Fully honored |
| 9 | Create replicated, tamper-evident ledger with independently verifiable national copies, immediate local event recording and bounded counterpart synchronization. Establish Intake Protocol verifying equipment identity in controlled staging areas before installation using layered evidence. | Requirement | 5/5 | 5/5 | Fully honored |
| 10 | Protect workloads, customer data, model weights, network topology, security architecture, source code and unrelated infrastructure through bounded inspection zones and filtered evidence. When critical vendor refuses, use vendor-supervised testing, filtered evidence, accredited independent examiners, clean-room or validated attestations. If insufficient, classify equipment as unverifiable; if material, site fails Phase One. | Requirement | 5/5 | 5/5 | Fully honored |
| 11 | Define Exit Protocol assigning every departure a disposition: witnessed destruction, verified permanent disablement, transfer to another participating site, documented release beyond monitored system, or unresolved disposition. Never imply continued knowledge beyond agreed boundary. | Requirement | 4/5 | 4/5 | Partially honored |
| 12 | Run live exercises involving unreported arrival, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal and reluctant operator. Conduct tests in staging, spare-inventory, maintenance or expansion areas without interrupting active computational work. | Requirement | 4/5 | 5/5 | Fully honored |
| 13 | Organize work around these top-level workstreams: bilateral authority/reciprocity gate; site eligibility/matched selection; inspectorate deployment/information barriers; intake/identity verification; ledger/synchronization; installation/maintenance/third-party access; exit/disposition; live exercises; discrepancy adjudication/suspension; final decision. Do not substitute generic initiation/stakeholder/requirements/closure phases. | Requirement | 5/5 | 5/5 | Fully honored |
| 14 | KPI dashboard covers blind-challenge detection by event type, false negatives/positives, equipment-identity confidence, event-recording/synchronization latency, ledger divergence/reconciliation time, reciprocal-access parity, unresolved discrepancy age, unverifiable equipment, vendor-refusal outcomes, IP/cybersecurity incidents, production disruption, funding timeliness and audit exceptions. Justify thresholds; mark unsupported figures provisional or TBD. | Requirement | 4/5 | 4/5 | Partially honored |
| 15 | Conclude Go only if exercises demonstrate reciprocal access and credible detection; Modify if correctable weaknesses remain; Stop if access asymmetric, material equipment unverifiable, government shields operator, evidence systems diverge unresolved, or either country withholds funding. Success covers only monitored changes at participating declared sites. | Requirement | 5/5 | 5/5 | Fully honored |
| 16 | Banned word: blockchain. | Banned | 2/5 | 5/5 | Fully honored |
| 17 | Do not assume trust, legal symmetry, or willingness to expose sensitive technology. Assume both countries' leaders need verification mechanisms that prevent uncontrolled frontier AI and sustain political control. | Intent | 5/5 | 5/5 | Fully honored |

## Issues

### Issue 11 - Define Exit Protocol assigning every departure a disposition: witnessed destruction, verified permanent disablement, transfer to another participating site, documented release beyond monitored system, or unresolved disposition. Never imply continued knowledge beyond agreed boundary.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Project plan references 'Definition of disposition' and risk assessment mentions 'exit-disposition conflicts' with a 28-day threshold, but explicit disposition categories (witnessed destruction, permanent disablement, transfer to another site, documented release, unresolved) are not detailed in the provided artifacts.
- **Explanation:** The plan acknowledges the Exit Protocol and auto-suspension thresholds for exit-disposition disputes (28 days), indicating an Exit Protocol exists. However, the five explicit disposition categories required by the directive (witnessed destruction, verified permanent disablement, transfer to another site, documented release beyond monitored system, unresolved disposition) are referenced implicitly but not listed and detailed in the artifacts provided. The principle is honored; the specification is incomplete in the visible plan.

### Issue 14 - KPI dashboard covers blind-challenge detection by event type, false negatives/positives, equipment-identity confidence, event-recording/synchronization latency, ledger divergence/reconciliation time, reciprocal-access parity, unresolved discrepancy age, unverifiable equipment, vendor-refusal outcomes, IP/cybersecurity incidents, production disruption, funding timeliness and audit exceptions. Justify thresholds; mark unsupported figures provisional or TBD.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Executive summary lists KPI targets: 'detection rates with confidence intervals; false negatives and positives; equipment-identity confidence; event-recording/synchronization latency; ledger divergence/reconciliation time; reciprocal-access parity; unresolved discrepancy age; unverifiable equipment; vendor-refusal outcomes; IP/cybersecurity incidents; production disruption; funding timeliness and audit exceptions.' Thresholds marked 'provisional' or 'TBD'.
- **Explanation:** The plan covers all 12 KPI dashboard elements requested and justifies most thresholds (e.g., detection ≥70%, false positives ≤10%, reciprocal parity ≥85%, discrepancy age ≤21 days). However, several thresholds remain marked 'TBD' (reciprocal-access parity definition, detection thresholds for three event types, exact unverifiable-equipment cutoff), and the plan does not provide all supporting figures for validation paths (e.g., how reciprocal-access parity will be measured is marked 'definition TBD'). The KPI framework is comprehensive but incompletely specified.
