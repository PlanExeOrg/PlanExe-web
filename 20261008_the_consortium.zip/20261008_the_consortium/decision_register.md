**8 open decisions: 5 high and 3 medium severity.** The most urgent items are the Go test statistic, the last-viable-start date, the external authority's powers, the asymmetry rule and interim financing for Months 0-2 (2026-10-08 to 2026-12-08). They must be settled by Month 1 (2026-11-08), when the instrument is signed. Until then, the plan can safely start the task force, roadmap, drafting and recruitment planning. Tranche 4 use and post-phase rework funding can wait until Month 8 (2027-06-08), before the verdict.

| # | Decision | Severity | Owner | Decide by | Blocks |
|---|---|---|---|---|---|
| 1 | Go test statistic and effective thresholds | 🔴 High | Co-Chair Steering Board (double-key), via the bilateral instrument | Month 1 (2026-11-08): the scoring rule must be locked in the instrument. | Month 1 (2026-11-08) instrument signature, tranche 1 release (Month 2 = 2026-12-08), and the Go/Modify/Stop verdict. |
| 2 | Last viable start and entry-slip backstop | 🔴 High | Co-Chair Steering Board | Month 1 (2026-11-08): set in the instrument, before gates start slipping. | Entry-gate certification (Month 5.5 = 2027-03-23) and clock start (Month 6 = 2027-04-08). |
| 3 | Authority of external escalation body | 🔴 High | Both national co-chairs (double-key) | Month 0.5 (2026-10-23), before any appointment, and in time for the Month 1 (2026-11-08) instrument. | Month 1 (2026-11-08) instrument; gate-slip escalation procedure. |
| 4 | Mid-test access asymmetry rule | 🔴 High | Co-Chair Steering Board | Month 1 (2026-11-08): written into the instrument; parity locked before Month 3 (2027-01-08). | Month 3 (2027-01-08) matched-pair approval; Phase One scoring. |
| 5 | Interim financing for Months 0-2 (2026-10-08 to 2026-12-08) | 🟡 Medium | Joint Budget Authority and both finance ministries | Month 0.5 (2026-10-23): spending begins immediately. | Recruitment, vetting, neutral facility, and the Month 1 (2026-11-08) instrument work. |
| 6 | Adjudication surge size and source | 🟡 Medium | Joint Budget Authority, with co-chairs | Month 1 (2026-11-08): pre-authorised in the instrument; needed before Month 4 (2027-02-08) recruitment. | Adjudication readiness for Phase One; contingency draw rules. |
| 7 | Tranche 4 purpose and release | 🟡 Medium | Co-Chair Steering Board and both finance authorities | Month 8 (2027-06-08), before scoring and verdict. | Tranche 4 release (Month 9.2-9.5); final decision. |
| 8 | Post-Phase funding for rework or Phase Two | 🔴 High | Both governments' finance authorities via the co-chairs | Month 8 (2027-06-08), before the verdict at Month 9.5 (2027-07-23). | Final decision (Month 9.5 = 2027-07-23) Modify branch. |

## 1. Go test statistic and effective thresholds (🔴 High)

**Decision:** Which statistic is compared with each Go threshold (point estimate, or a lower confidence bound), and are the 70%/50% class thresholds kept or reset?

**Why it is open:** Verdict logic says Go needs intervals not straddling a threshold. With ±22% (planned) and ±25% (unplanned), Go needs about 92% and 75% detection (recomputed). Executive summary, review plan and self-audit use inconsistent examples and an unsupported 50-60% success estimate.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Compare point estimates with thresholds; intervals reported but not gating. | Go reachable at 70%/50% detection. Weaker statistical defensibility; contested verdict risk. | verdict_logic; executive summary; review plan 5.3, 9.1; self-audit item 8. |
| B. Compare lower bound at a stated one-sided confidence level; state effective Go detection levels. | Rigorous, but Go needs very high detection; most outcomes become Modify. | verdict_logic; detection_thresholds; scoring rubric. |
| C. Reset class thresholds (proposed thresholds) so the interval rule is reachable. | Keeps the straddle rule; changes the detection bar and needs revalidation at pre-registration. | detection_thresholds; verdict_logic; KPI dashboard. |

- **If nobody decides:** The rule stays as written; Go is nearly unreachable, and tranche 1 is not released without a mechanical verdict rule.
- **Owner:** Co-Chair Steering Board (double-key), via the bilateral instrument
- **Decide by:** Month 1 (2026-11-08): the scoring rule must be locked in the instrument.
- **Blocks:** Month 1 (2026-11-08) instrument signature, tranche 1 release (Month 2 = 2026-12-08), and the Go/Modify/Stop verdict.

## 2. Last viable start and entry-slip backstop (🔴 High)

**Decision:** What is the last viable Phase One clock-start date, and what happens after it (re-scope to 2 pairs or Stop)?

**Why it is open:** Canonical backstop is Month 9 (2027-07-08) certification, but Month 9 (2027-07-08) is when the 90-day window would end. Other documents say a slip shortens the clock to 50-60 days or adds a 4-week re-scope. A slip actually delays the start.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Set a last-viable-start date that fits 90 days plus 5-day scoring inside funded period; after it, re-scope or Stop. | Clock stays 90 days. Slip costs are delay costs (8 weeks: USD 100-200M estimate). Needs the funded period defined. | entry_slip_backstop; exec summary; review plan 1.1, 2.3, 13.3; pitch. |
| B. After the date, automatically re-scope to 2 pairs, 90 days, 48 exercises. | Keeps a test alive with lower power; pairs reduce to 4 sites. | entry_slip_backstop; exercise_load; site_unit_and_count. |
| C. After the date, Stop with no re-scope. | Caps cost exposure; no verdict. | entry_slip_backstop; hard_stop_triggers. |

- **If nobody decides:** Month 9 (2027-07-08) backstop stays, leaving no test window; slips are handled by ad hoc summits.
- **Owner:** Co-Chair Steering Board
- **Decide by:** Month 1 (2026-11-08): set in the instrument, before gates start slipping.
- **Blocks:** Entry-gate certification (Month 5.5 = 2027-03-23) and clock start (Month 6 = 2027-04-08).

## 3. Authority of external escalation body (🔴 High)

**Decision:** Does the external or neutral escalation authority only convene and report, or hold a delegated decision right limited to a pre-agreed fallback?

**Why it is open:** The review plan gives a third-country official a 48-hour summit, binding scope-reduction power and a voting chair, which conflicts with double-key governance and the canonical 5-day summit. The authority is appointed before the instrument that would grant its powers.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Convene, monitor and report only; scope reduction is a pre-agreed mechanical double-key rule (e.g. fall back to 2 pairs). | Preserves double-key; slower in deadlock. | Review plan 3.1, 12.2, 12.3, 15.2; instrument. |
| B. Both co-chairs delegate in advance a decision right limited to the single fallback. | Faster, with bounded neutral power; needs both legislatures' comfort. | Instrument; governance matrix; review plan. |
| C. No external authority; co-chair summit only. | Simplest; deadlock relies on automatic partial suspension. | Remove authority from review plan and exec summary. |

- **If nobody decides:** Summit within 5 days, co-chairs only; the neutral authority is not appointed.
- **Owner:** Both national co-chairs (double-key)
- **Decide by:** Month 0.5 (2026-10-23), before any appointment, and in time for the Month 1 (2026-11-08) instrument.
- **Blocks:** Month 1 (2026-11-08) instrument; gate-slip escalation procedure.

## 4. Mid-test access asymmetry rule (🔴 High)

**Decision:** What size and duration of access asymmetry is a hard Stop, is any cure period allowed, and is mid-clock site substitution permitted?

**Why it is open:** Constraints and review plan say asymmetry is an immediate Stop. The premortem and self-audit allow a 30-day cure at a gap over 10% and substitution within 48 hours, which breaks matched-set parity and exercise load.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Immediate Stop on defined asymmetry; no substitution. | Matches user constraint; fragile to operator delay; parity ≥85% scored. | Premortem FM3; self-audit 20; hard_stop_triggers. |
| B. Short defined cure period, then Stop; no substitution. | Tolerates fixable delays; the cure must be defined (threshold, days) and may cut exercises. | Instrument; parity definition; deadlock clocks. |
| C. Allow substitution with a pre-clock-equivalent audit. | Keeps pairs but resets the parity baseline and may drop to 48 or 36 exercises. | exercise_load; site eligibility; schedule. |

- **If nobody decides:** Canonical text applies: access asymmetry is a Stop trigger, and conflicting documents are unresolved.
- **Owner:** Co-Chair Steering Board
- **Decide by:** Month 1 (2026-11-08): written into the instrument; parity locked before Month 3 (2027-01-08).
- **Blocks:** Month 3 (2027-01-08) matched-pair approval; Phase One scoring.

## 5. Interim financing for Months 0-2 (2026-10-08 to 2026-12-08) (🟡 Medium)

**Decision:** How are costs incurred before tranche 1 (Month 2 = 2026-12-08) financed while keeping 50/50 and an envelope mapping?

**Why it is open:** Task force, legal, recruitment, vetting and neutral facility start at Month 0-1 (2026-10-08 to 2026-11-08), and a compression reserve is authorised at Month 0.5 (2026-10-23). First funds arrive at Month 2 (2026-12-08). Ramp-up before Month 5.5 (2027-03-23) is TBD.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Pre-instrument bridge appropriation from each government. | Clean, equal; needs fast legislative action. | tranche_structure; entry_gate_timeline. |
| B. Each government advances own funds, recorded against its USD 2.5B. | Fast; must be matched exactly to protect 50/50. | tranche_structure; envelope mapping. |
| C. Release part of tranche 1 earlier. | Needs an earlier instrument; moves signature or appropriation earlier. | tranche_structure; funding_stop_threshold. |
| D. Defer spending until Month 2 (2026-12-08). | Pushes recruitment and vetting, risking later gate slips. | entry_gate_timeline. |

- **If nobody decides:** Month 0-2 (2026-10-08 to 2026-12-08) spending lacks funding authority; recruitment and facility work stall.
- **Owner:** Joint Budget Authority and both finance ministries
- **Decide by:** Month 0.5 (2026-10-23): spending begins immediately.
- **Blocks:** Recruitment, vetting, neutral facility, and the Month 1 (2026-11-08) instrument work.

## 6. Adjudication surge size and source (🟡 Medium)

**Decision:** What is the surge headcount (per country or total), how is it costed, and is it funded from the personnel envelope or free contingency, with what pre-authorised limit?

**Why it is open:** The review plan states 8-12 specialists at USD 2-3M, funded from the personnel envelope, but elsewhere from free contingency. Recomputed cost of 16-24 specialists is about USD 1.3-1.9M per month, so USD 2-3M covers 1-2 months.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Use the existing 36-person surge pool inside the personnel envelope. | No extra draw; may strain other surge needs. | Review plan 3.3, 6.3; exec summary. |
| B. Free-contingency draw with a pre-authorised limit. | Covers peaks; reduces the USD 400-450M free contingency. | contingency_rules; instrument. |
| C. Hybrid: pool first, contingency above 15 cases per month. | Matches adjudication_capacity; needs a trigger rule. | adjudication_capacity; review plan. |

- **If nobody decides:** Surge funding is ambiguous, and adjudication backlog risks 21-day discrepancy limits.
- **Owner:** Joint Budget Authority, with co-chairs
- **Decide by:** Month 1 (2026-11-08): pre-authorised in the instrument; needed before Month 4 (2027-02-08) recruitment.
- **Blocks:** Adjudication readiness for Phase One; contingency draw rules.

## 7. Tranche 4 purpose and release (🟡 Medium)

**Decision:** What does tranche 4 (USD 500M per country) fund, and when is it released under Go, Modify and Stop?

**Why it is open:** Canonical: released on Go/Modify verdict. Review plan says released on publication regardless of rework. Stop would withhold funds, yet withholding is a Stop trigger. The USD 250-400M rework figure has no basis.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Fund verdict scoring, closure and archive only; release on any verdict. | Separates verdict from funding leverage; much of the USD 1B may go unspent. | tranche_structure; funding_stop_threshold. |
| B. Release on Go/Modify only; Stop exempt from the withheld-funding trigger. | Follows canonical; includes rework under Modify. | tranche_structure; hard_stop_triggers; review plan 11.3. |
| C. Hold tranche 4 for rework or Phase Two pending the post-phase funding decision. | Ties to the OPEN funding question. | post_phase_funding_open_decision; economic_chain_closure. |

- **If nobody decides:** Canonical release on Go/Modify applies; Stop leaves the use of funds and the trigger undefined.
- **Owner:** Co-Chair Steering Board and both finance authorities
- **Decide by:** Month 8 (2027-06-08), before scoring and verdict.
- **Blocks:** Tranche 4 release (Month 9.2-9.5); final decision.

## 8. Post-Phase funding for rework or Phase Two (🔴 High)

**Decision:** Is Modify-directed rework or any Phase Two funded from the unspent USD 5B or by new appropriations?

**Why it is open:** Marked OPEN in canonical facts. Rework cost is unsupported. The 'if NO' path of the final decision gate depends on it.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Fund from unspent budget, including contingency and tranche 4. | Fast Modify path; may exceed the USD 5B cap only if overrun. | post_phase_funding_open_decision; economic_chain_closure. |
| B. Require new appropriations from both governments. | Adds legislative time (estimated 2-4 weeks or more) and a veto point. | tranche_structure; final decision timeline. |
| C. Defer; Modify only recommends scope. | No commitments; rework waits for a later decision. | final decision section. |

- **If nobody decides:** No rework is funded; a Modify verdict has no funded route.
- **Owner:** Both governments' finance authorities via the co-chairs
- **Decide by:** Month 8 (2027-06-08), before the verdict at Month 9.5 (2027-07-23).
- **Blocks:** Final decision (Month 9.5 = 2027-07-23) Modify branch.

## Choices made on your behalf

Set when the scenario was selected, not by you. Confirm or change them.

| Lever | Chosen | Strongest alternative | Why it matters | Revisit by |
|---|---|---|---|---|
| Layered Evidence Weighting Model | Confidential rotating combination rule set by specialists from both sides, validated against blind outcomes. | Contradiction-based scoring (Pioneer's Gambit), or published corroboration rule (Conservative Anchor). | It sets gaming resistance versus false-positive load. | Month 5.5 (2027-03-23) evidence-rule lock. |
| Deadlock and Suspension Mechanics | Automatic partial suspension of only the disputed function after a fixed period, logged in the ledger. | Age-triggered impaired-confidence without co-chair decision, or an advisory panel only. | It decides whether deadlock can stall or brittlely stop verification. | Month 1 (2026-11-08) instrument. |
| Blind Challenge Exercise Control | Each country's red team designs challenges for the other's inspectorate, scored by an independent referee. | Unannounced interleaved challenges, or an independent authority running all exercises. | It determines reciprocity testing and the disruption risk. | Month 5 (2027-03-08) pilot exercise. |
| Verdict Threshold Calibration Method | Provisional thresholds before the first exercise, locked after mirrored-panel validation on pilot data. | Independent body scoring a pre-registered rubric, or Modify-default bands. | It sets how reachable Go is on thin 90-day data. | Month 5.5 (2027-03-23) lock. |
| Inspector Information Firewall Doctrine | Compartmentalization by role and site, with debriefs and monitored cooling-off before reassignment. | Sealed filtered-interface model, or operator-side security officers pre-screening each view. | It balances IP protection against operator shielding. | Month 3 (2027-01-08) inspector approval. |
