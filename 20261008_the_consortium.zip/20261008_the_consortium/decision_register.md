**8 open decisions: 3 high and 5 medium severity.** The urgent decisions are the three high ones: who covers the contingency gap, the funding Stop reference date, and the decision date after a late start. All three must be settled by Month 2 (2026-12-08), before the instrument is signed. Until then the plan can safely run the Month 0.5 (2026-10-23) domestic-act decompositions, site nominations, vetting and generic vendor outreach. The medium items on calibration, clocks, statistics, the contingency ladder and Phase Two fall due by Months 3 to 10 (2027-01-08 to 2027-08-08).

| # | Decision | Severity | Owner | Decide by | Blocks |
|---|---|---|---|---|---|
| 1 | Contingency shortfall under hard cap | 🔴 High | Bilateral Executive Steering Committee (BESC), double-key co-chairs; the governments if the cap is amended. | Month 2 (2026-12-08), before the instrument is signed, since the cap is written into it. | Instrument signature (Month 2 = 2026-12-08) and appropriations (Month 3 = 2027-01-08). |
| 2 | Reference date for the 75-day funding Stop | 🔴 High | Both co-chairs (double-key), with each treasury. | Month 2 (2026-12-08), in the instrument. | Funding gate (Month 3.5 = 2027-01-23) and the Stop rule. |
| 3 | Decision date after a late start; pause clauses | 🔴 High | Both co-chairs (double-key), via BESC. | Month 2 (2026-12-08), before the instrument is signed. | The Month 9 (2027-07-08) backstop and the Month 10 (2027-08-08) decision. |
| 4 | Calibration inspector cohort | 🟡 Medium | Joint technical committee, with co-chair double-key approval. | Month 3.5 (2027-01-23), to leave time for vetting before Month 4 (2027-02-08). | Calibration (Month 4 = 2027-02-08) and the threshold lock (Month 5.5 = 2027-03-23). |
| 5 | Suspension clock precedence | 🟡 Medium | Both co-chairs (double-key), on advice from the Joint Forensic Panel. | Month 5.5 (2027-03-23), when thresholds are locked. | The threshold lock and the adjudication protocol. |
| 6 | Statistical basis for the Go rule | 🟡 Medium | Independent testing unit, with co-chair double-key approval. | Month 5.5 (2027-03-23), since the rule locks then. | The threshold lock (Month 5.5 = 2027-03-23) and the Month 10 (2027-08-08) decision. |
| 7 | Contingency trigger ladder | 🟡 Medium | BESC, double-key co-chairs. | Month 3 (2027-01-08), when appropriations are set. | First contingency releases and the fiscal reporting from Month 3 (2027-01-08). |
| 8 | Phase Two funding path | 🟡 Medium | Both governments through the co-chairs; legislatures for appropriations. | Month 10 (2027-08-08), at the final decision. | Any post-Go expansion. |

## 1. Contingency shortfall under hard cap (🔴 High)

**Decision:** How is the roughly USD 15M gap between worst-case exposure (about USD 515M) and the USD 500M contingency covered under the USD 5.0B hard cap?

**Why it is open:** The canonical facts show a hard cap and exact 50/50. Reviews 2 and 10 propose USD 25-50M supplemental funding. That breaks the cap. No owner or source is named.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Accept the gap as residual risk with a pre-agreed scope-reduction order. | Cap and 50/50 stay intact. Worst case leaves no surge margin and forces cuts. | Add a scope-reduction order. Delete the supplemental appropriation language. |
| B. Double-key reallocation from another envelope, shared equally (USD 7.5M per side at about 15M). | Cap holds. One envelope shrinks. Exercise or site preparation may be cut. | envelope_allocation_usd; contingency_governance. |
| C. Amend the cap explicitly by a supplement shared 50/50. | Needs new appropriations in both countries. This could delay Month 3 (2027-01-08) milestones. | total_budget_usd; per-country tranche; instrument. |

- **If nobody decides:** The cap stays hard, and an overrun forces an ad hoc Modify or Stop at the point of exhaustion.
- **Owner:** Bilateral Executive Steering Committee (BESC), double-key co-chairs; the governments if the cap is amended.
- **Decide by:** Month 2 (2026-12-08), before the instrument is signed, since the cap is written into it.
- **Blocks:** Instrument signature (Month 2 = 2026-12-08) and appropriations (Month 3 = 2027-01-08).

## 2. Reference date for the 75-day funding Stop (🔴 High)

**Decision:** What reference date starts the 45-day payment period plus the 30-day cure for each country's tranche?

**Why it is open:** The canonical text says 'fiscal-year start', which is undefined. Appropriations are due Month 3 (2027-01-08). A day-75 Stop could fire before funds are expected, and the US and China cycles differ.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Use the appropriation enactment date, per country. | The Stop is testable and aligns with the Month 3 (2027-01-08) milestone. Funding is later than a fiscal-year anchor. | funding_timeliness; premortem FM7. |
| B. Use a fixed shared date in the instrument (for example the Month 2 = 2026-12-08 signing date). | Symmetric and simple. The 75-day limit falls near Month 4.5 (2027-02-23), after the Month 3 (2027-01-08) milestone. | funding_timeliness; entry_conditions_milestones. |
| C. Keep fiscal-year start with each country's date written into the instrument. | Stays close to the current text. A date before Month 0 (2026-10-08) could fire a Stop early. | funding_timeliness. |

- **If nobody decides:** The Stop trigger cannot be tested, and funding disputes go to the co-chairs ad hoc.
- **Owner:** Both co-chairs (double-key), with each treasury.
- **Decide by:** Month 2 (2026-12-08), in the instrument.
- **Blocks:** Funding gate (Month 3.5 = 2027-01-23) and the Stop rule.

## 3. Decision date after a late start; pause clauses (🔴 High)

**Decision:** Is the final decision date defined as clock start plus 90 days plus a decision interval, and are pause clauses adopted or deleted?

**Why it is open:** The canonical text fixes Month 10 (2027-08-08) and a strict 90-day clock. Reviews 1 and 4 and Self-audit 20 add pause clauses (6-month, 2-week) and costed slips that assume Month 10 (2027-08-08) still holds.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Decision date = clock start + 90 days + decision interval. No pause clauses. | Strict gate preserved. Slip costs (USD 50-100M per month) run to the moved date. | final_decision_timing; Reviews 1, 4; Self-audit 20. |
| B. Adopt a pause clause by double-key protocol change, with the effect on the 90 days defined. | Flexibility during a running clock. It weakens the strict gate and needs a defined clock effect. | phase_one_duration; gate model; add pause rules. |

- **If nobody decides:** The Month 10 (2027-08-08) date is read as fixed. A late start leaves the decision date unclear, and pauses are not allowed.
- **Owner:** Both co-chairs (double-key), via BESC.
- **Decide by:** Month 2 (2026-12-08), before the instrument is signed.
- **Blocks:** The Month 9 (2027-07-08) backstop and the Month 10 (2027-08-08) decision.

## 4. Calibration inspector cohort (🟡 Medium)

**Decision:** Which inspector cohort is approved by Month 4 (2027-02-08) for calibration, or is calibration moved later?

**Why it is open:** Calibration (Months 4-5 = 2027-02-08 to 2027-03-08) needs cleared inspectors, but full approval completes at Month 5 (2027-03-08). Thresholds lock at Month 5.5 (2027-03-23) on that data.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Approve a defined calibration cohort by Month 4 (2027-02-08) (staged approval). | Dates are kept. Thresholds are validated on a subset, and a partial roster risks mis-set thresholds. | inspector_roster_rules; calibration_exercise. |
| B. Move calibration later and lock thresholds after Month 5.5 (2027-03-23). | Calibration uses the full team. Certification slips beyond Month 6 (2027-04-08) at USD 50-100M per month (estimate). | threshold_lock; entry_conditions_milestones. |
| C. Calibrate with simulated performance and re-lock after the real roster is in place. | Keeps the schedule. Needs a recorded protocol change and weakens the evidence. | threshold_lock; protocol change record. |

- **If nobody decides:** Calibration runs on whoever is cleared, and the Month 5.5 (2027-03-23) lock rests on unrepresentative data.
- **Owner:** Joint technical committee, with co-chair double-key approval.
- **Decide by:** Month 3.5 (2027-01-23), to leave time for vetting before Month 4 (2027-02-08).
- **Blocks:** Calibration (Month 4 = 2027-02-08) and the threshold lock (Month 5.5 = 2027-03-23).

## 5. Suspension clock precedence (🟡 Medium)

**Decision:** Does the 7-day divergence suspension override the 14-day deadlock and Tier 3 clocks, or does contested identity get 14 days?

**Why it is open:** Auto-suspension at 7 days of unresolved divergence fires before the referee path (7 days plus 5) and the 14-day Tier 3 clock. The escalation matrix itself shows both 7 and 14 days.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. The 7-day suspension takes precedence, with the referee step inside the first 7 days. | Matches the zero-divergence-beyond-7-days Go rule. Less time for contested identity. | deadlock_definition; discrepancy_clock_tiers. |
| B. Contested-identity divergence gets a 14-day clock; technical divergence keeps 7 days. | Allows the referee path. Needs a classification rule and alters the Go rule. | impaired_confidence_and_suspension; go_other_thresholds. |

- **If nobody decides:** The 7-day suspension fires first, and the referee step is never reached.
- **Owner:** Both co-chairs (double-key), on advice from the Joint Forensic Panel.
- **Decide by:** Month 5.5 (2027-03-23), when thresholds are locked.
- **Blocks:** The threshold lock and the adjudication protocol.

## 6. Statistical basis for the Go rule (🟡 Medium)

**Decision:** How is detection tested with at most 24 sessions across 7 event types?

**Why it is open:** 24 sessions give about 3-4 trials per event type. Thresholds of 80-90% and 95% confidence intervals cannot be supported. Calibration data is excluded from Go evidence.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Define events per session and per type to give enough power. | Needs more events per session. Stays inside the cap of 2 sessions per site per month and zero disruption. | exercise_design_and_cap; go_detection_thresholds. |
| B. Use a pooled or Bayesian rule across types. | Workable with 24 sessions. Per-type thresholds weaken. | go_detection_thresholds; KPI dashboard. |
| C. Treat the Go rule as indicative and drop the 95% CI claim. | No design change. The verdict is less defensible. | Review 6 KPI 1; Self-audit 11. |

- **If nobody decides:** The rule stays untestable, and the Month 10 (2027-08-08) verdict is open to dispute.
- **Owner:** Independent testing unit, with co-chair double-key approval.
- **Decide by:** Month 5.5 (2027-03-23), since the rule locks then.
- **Blocks:** The threshold lock (Month 5.5 = 2027-03-23) and the Month 10 (2027-08-08) decision.

## 7. Contingency trigger ladder (🟡 Medium)

**Decision:** What single ordered ladder, on cumulative contingency drawdown, sets the warning, review, reallocation and scope-reduction levels?

**Why it is open:** Triggers at USD 150M, 200M, 350M, 400M and 450M use different bases (drawdown, spend, reserve left) and are unordered. The fast lane covers up to USD 50M.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Four-level ladder on cumulative drawdown, values labelled (proposed threshold). | A clear escalation order. Values need agreement. It links to the scope-reduction order if C1 is decided. | contingency_governance; Reviews 6 and 14; premortem. |
| B. Keep only the canonical rules (USD 50M fast lane, 5% variance). | Simple. Large draws (the worst case is about USD 515M) have no early warning. | Delete the other triggers. |

- **If nobody decides:** Conflicting triggers stay, and escalation depends on the document consulted.
- **Owner:** BESC, double-key co-chairs.
- **Decide by:** Month 3 (2027-01-08), when appropriations are set.
- **Blocks:** First contingency releases and the fiscal reporting from Month 3 (2027-01-08).

## 8. Phase Two funding path (🟡 Medium)

**Decision:** Does any expansion after Go need a separate instrument amendment and new appropriation, or an extended window?

**Why it is open:** The USD 5.0B cap is fully allocated and appropriations lapse at Month 18 (2028-04-08). The pitch says expansion leverages existing envelopes. Review 14 says expansion needs USD 2-3B more. The FTE cost range is miscomputed.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Require a separate amendment and new appropriation. | The cap holds. Expansion cannot start until funded, so a gap after Month 18 (2028-04-08) is possible. | Pitch; Exec Summary; Reviews 2, 14. |
| B. Extend the appropriation window beyond Month 18 (2028-04-08). | Staffing is funded for longer (about 3 years at most). Needs both legislatures. | appropriation_window; instrument. |
| C. Treat Phase Two as out of scope until the Month 10 (2027-08-08) decision. | No commitment now. Planning for continuity is deferred. | Remove expansion wording. |

- **If nobody decides:** Phase Two has no funding, and appropriations lapse at Month 18 (2028-04-08).
- **Owner:** Both governments through the co-chairs; legislatures for appropriations.
- **Decide by:** Month 10 (2027-08-08), at the final decision.
- **Blocks:** Any post-Go expansion.

## Choices made on your behalf

Set when the scenario was selected, not by you. Confirm or change them.

| Lever | Chosen | Strongest alternative | Why it matters | Revisit by |
|---|---|---|---|---|
| Reciprocity gate stringency | All 7 entry conditions certified by both sides before the clock starts. No partial start. | Pioneer's Gambit: per-site conditional start. | Sets whether either government can delay the start, and keeps setup failures out of the verdict. | Month 9 (2027-07-08) backstop. |
| Evidence layer weighting | Fixed rule: identity confirmed when at least 2 independent layers agree. Provenance recorded. | Pragmatic Foundation: graded confidence score recalibrated after each round. | Sets how hard evasion is and how much room exists for disputes. | Month 5.5 (2027-03-23) threshold lock. |
| Inspection zone boundary design | Narrow marked zones (staging, spare, maintenance, expansion) with operator-run redaction that inspectors audit. | Pioneer's Gambit: sealed capture instruments with filtered data. | Balances IP protection against detection reach. | Month 2 (2026-12-08) site ratification. |
| Challenge exercise independence | Independent testing unit runs a sealed double-key schedule, with a small group aware at each site. | Pioneer's Gambit: blend scheduled exercises with unannounced real events. | Determines how realistic and how disruption-free the detection scores are. | Month 5.5 (2027-03-23). |
| Go-Modify-Stop threshold calibration | Thresholds fixed and double-key signed after pre-clock calibration. Changes only by recorded protocol change. | Pioneer's Gambit: trend and category rubric scored by auditors. | The numbers are provisional, so a mis-set figure could drive a Modify outcome. | Month 5.5 (2027-03-23) lock. |
