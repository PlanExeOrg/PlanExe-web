**3 open decisions: 2 high and 1 medium severity.** The pre-Month 7 (2027-05-12) funding source is the most urgent: early vetting and clean-room work needs it by about Month 1 (2026-11-12), and it can be resolved before the instrument is signed. The tranche 3-4 scope must be settled before signature at Month 7 (2027-05-12), and the misclassification limit before the Month 10.5 (2027-08-27) threshold freeze. Until then the plan can safely proceed with the Month 0.5 (2026-10-27) legal tabletop, the funding charter, a small vetting pilot within the sub-account and design work.

| # | Decision | Severity | Owner | Decide by | Blocks |
|---|---|---|---|---|---|
| 1 | Pre-appropriation funding for entry-gate work | 🔴 High | Principals (national leads), advised by the legal working group and independent budget auditor | Month 1 (2026-11-12): the vetting pilot and clean-room construction must start then to meet Month 8-9 (2027-06-12 to 2027-07-12) readiness. | Vetting pilot, clean-room construction, Month 0.5 (2026-10-27) funding charter and the Month 7.5 (2027-05-27) principal checkpoint. |
| 2 | Scope of tranches 3-4 and Phase Two budget horizon | 🔴 High | Principals, via double-key budget authorization on the Bilateral Steering Committee | Before the instrument is signed at Month 7 (2027-05-12); scope inputs by Month 11 (2027-09-12) so tranche 3 can release at Month 13 (2027-11-12). | Instrument signature (Month 7 = 2027-05-12), tranche 3 at Month 13 (2027-11-12) and tranche 4 at Month 16 (2028-02-12). |
| 3 | Misclassified-challenge-event limit | 🟡 Medium | Bilateral Steering Committee co-chairs (double-key), with exercise design panel input | Month 7 (2027-05-12) for the form in the instrument; value by Month 10.5 (2027-08-27) when thresholds freeze before scored exercises. | Threshold freeze at Month 10.5 (2027-08-27) and start of scored exercises. |

## 1. Pre-appropriation funding for entry-gate work (🔴 High)

**Decision:** What lawful funding source pays for vetting, clean rooms and site preparation before appropriations are enacted at Month 7 (2027-05-12), and when does the USD 50M gate-readiness sub-account become available?

**Why it is open:** Spending is scheduled from Month 0-6 (2026-10-12 to 2027-04-12), but envelopes, contingency and the sub-account are funded only from Month 7 (2027-05-12). The sub-account is described both as usable before Month 6 (2027-04-12) and as 'accessible only at certification' (Month 9 = 2027-07-12). Sunk cost USD 100-200M (estimate) has no named source.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Each government bridges pre-appropriation work from its own budget as a pre-agreed national advance, credited later to its contribution. | Early targets (vetting, clean rooms) stay on schedule; needs domestic authority before Month 1 (2026-11-12); parity of advances must be tracked within +/-10%. | contingency_draw_rules; tranche_schedule; cost_attribution_and_cap_scope; add advance-crediting rule. |
| B. Release tranche 1 or the sub-account earlier than Month 7 (2027-05-12) under an interim authority. | Keeps early work funded inside the USD 5B cap; needs interim legal instrument; sub-account (USD 25M per country) is small against USD 100-200M (estimate). | tranche_schedule; entry_condition_deadlines; contingency_draw_rules. |
| C. Move early targets after Month 7 (2027-05-12) or shrink them to what the sub-account covers. | No new legal source needed; vetting and clean rooms slip, risking the 80% staffing level at Month 8 (2027-06-12) and Month 9 (2027-07-12) certification; clock start may move toward Month 12 (2027-10-12). | staffing_buffers_and_tenure; clean_room_cost_estimate; phase_one_clock_start. |

- **If nobody decides:** No staffing or site commitments beyond the sub-account; early targets slip and the Month 9 (2027-07-12) clock start becomes unlikely.
- **Owner:** Principals (national leads), advised by the legal working group and independent budget auditor
- **Decide by:** Month 1 (2026-11-12): the vetting pilot and clean-room construction must start then to meet Month 8-9 (2027-06-12 to 2027-07-12) readiness.
- **Blocks:** Vetting pilot, clean-room construction, Month 0.5 (2026-10-27) funding charter and the Month 7.5 (2027-05-27) principal checkpoint.

## 2. Scope of tranches 3-4 and Phase Two budget horizon (🔴 High)

**Decision:** What do tranches 3-4 (USD 1.25B per country combined USD 2.5B) fund after the Phase One verdict, and is any Phase Two inside or outside the USD 5B cap?

**Why it is open:** Documents say USD 5B is 'Phase One only', yet also that Phase Two needs USD 2.5-5.0B additional and that tranche 3 releases 'automatically by Month 14 (2027-12-12)' (canonical: Month 13 = 2027-11-12 with new double-key authorization). No Phase Two scope, criteria or funding is defined.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Tranches 3-4 are the Phase Two/continuation budget inside the cap, scope and criteria set by Month 11 (2027-09-12). | Continuation funded without new appropriation; requires Phase Two scope work before the verdict; Phase Two scope grows the program's reach. | budget_horizon_open_decision; tranche_schedule; verdict rules; Phase Two scope definition. |
| B. Tranches 3-4 fund Phase One tail costs (verdict, adjudication, disposition closure, wind-down); Phase Two sits entirely outside the cap. | Keeps Phase One scope bounded; Phase Two needs separate appropriation and instrument; part of tranches may go unused. | budget_horizon_open_decision; envelope narrative; tranche conditions. |
| C. Tranches 3-4 are an unreleased reserve, returned on Stop or Modify. | Strongest fiscal control; no continuation money exists after Modify corrective trials unless re-authorized. | tranche_schedule; revenue_and_debt_chain note; return and wind-down rules. |

- **If nobody decides:** Tranches 3-4 remain unreleased at Month 13 and 16 (2027-11-12, 2028-02-12) pending a new double-key authorization; no continuation or Phase Two work is funded.
- **Owner:** Principals, via double-key budget authorization on the Bilateral Steering Committee
- **Decide by:** Before the instrument is signed at Month 7 (2027-05-12); scope inputs by Month 11 (2027-09-12) so tranche 3 can release at Month 13 (2027-11-12).
- **Blocks:** Instrument signature (Month 7 = 2027-05-12), tranche 3 at Month 13 (2027-11-12) and tranche 4 at Month 16 (2028-02-12).

## 3. Misclassified-challenge-event limit (🟡 Medium)

**Decision:** What single limit on misclassified CHALLENGE events applies (per site or per phase, and '>' or '>='), and how is it kept distinct from KPI false positives?

**Why it is open:** The false-positive limit is TBD in the canonical facts. Reviews give four incompatible limits (>3 total, <=2 per site, >=2 per site, 3 per site). 'False positive' also names both a misclassified exercise event and a spurious detection.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Per-site limit, for example no more than 2 misclassified events per site per phase (proposed threshold). | Localizes accountability to each site and supports parity; calibrate in unscored exercises Months 9.5-10.5 (2027-07-27 to 2027-08-27); frozen at Month 10.5 (2027-08-27). | detection_thresholds; challenge_partition; KPI dashboard definitions. |
| B. Per-phase total limit across all sites (proposed threshold). | Simpler to administer; one site could carry all errors without tripping; frozen at Month 10.5 (2027-08-27). | detection_thresholds; challenge_partition; impaired-confidence trigger text. |
| C. Defer value to calibration, fixing only the form (per-site, '>' bar) now. | Instrument can sign with a procedure rather than a number; value final at Month 10.5 (2027-08-27); later change is a Stop-path event. | detection_thresholds; exercise_schedule; instrument annex. |

- **If nobody decides:** The limit stays TBD; at the Month 10.5 (2027-08-27) freeze no scored exercise can start with a defined misclassification bar, leaving Modify as the likely verdict.
- **Owner:** Bilateral Steering Committee co-chairs (double-key), with exercise design panel input
- **Decide by:** Month 7 (2027-05-12) for the form in the instrument; value by Month 10.5 (2027-08-27) when thresholds freeze before scored exercises.
- **Blocks:** Threshold freeze at Month 10.5 (2027-08-27) and start of scored exercises.

## Choices made on your behalf

Set when the scenario was selected, not by you. Confirm or change them.

| Lever | Chosen | Strongest alternative | Why it matters | Revisit by |
|---|---|---|---|---|
| Equipment identity trust anchor | Vendor attestation validated by accredited examiners from both countries, with physical inspection and customs records as corroboration. | Bilateral tamper-evident tags applied jointly in staging, independent of vendor supply chains. | Concentrates trust in a few vendor keys, so a key compromise or refusal can make 10-40% of equipment unverifiable. | Month 8 (2027-06-12) attestation dry-run and vendor binding deadline |
| Inspector presence and rotation | Resident mirrored teams on continuous shift coverage at every site, in bounded zones with escort. | Randomized rotation across sites, or notification-based deployment with spot checks. | Drives staffing of about 350-500 cleared staff and espionage exposure. | Month 8 (2027-06-12) staffing dry-run |
| Deadlock and suspension mechanics | Enumerated objective triggers suspend a site automatically; resumption needs double-key authorization and corrective action. | Referee advisory statements with deadlock defaulting to heightened inspection, no suspension. | Prevents delay as obstruction but raises the risk of manufactured triggers causing suspension. | Month 7 (2027-05-12) instrument signature |
| Challenge exercise commitment and scoring | Reciprocal red teams inject hash-committed scenarios at the counterpart's sites, scored by independent testers. | Independent testers design blind scenarios, or a sealed catalog revealed after Phase One. | Tests detection and access parity in one event and determines the Go criteria. | Month 10.5 (2027-08-27) threshold freeze |
| Inspection zone geometry and evidence filtering | Operator-run redaction gateway producing schema-limited packets, with counterpart engineers auditing the rules but not inputs. | Fixed painted zones admitting only pre-validated inspector-carried instruments. | Relies on filter adequacy, which the Month 8.5 (2027-06-27) pre-test must prove (halt if <85%). | Month 8.5 (2027-06-27) filter-adequacy pre-test |
