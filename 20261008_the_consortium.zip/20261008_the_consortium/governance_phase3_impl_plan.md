### 1. Senior leadership from both governments formally designate their national co-chair representatives (senior diplomat or national-security official, full-time equivalent) and appoint co-chair office staff (chief of staff, deputy, shared executive assistant per country). Execute and sign the bilateral Charter and Terms of Reference locking deadlock procedures, partial-suspension rules, threshold-locking timeline, and emergency-summit procedures.

**Responsible Body/Role:** Project Sponsor (Senior US and Chinese national-security leadership, pre-existing authority prior to any committee formation)

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- Bilateral Charter and Terms of Reference signed by both governments
- Named co-chair representatives and office staff (US and Chinese)
- Charter locked deadlock procedures, partial-suspension rules, and emergency-summit procedures

**Dependencies:**

- Project start authorized by both governments
- Senior leadership commitment to bilateral governance

### 2. Project Sponsor appoints the US and Chinese representatives to the co-chair office. The newly designated co-chairs begin weekly coordination meetings (Mondays, 2 hours). Establish the co-chair office workspace, secure communications (bilingual video, classified secure channels), and administrative support. Schedule monthly in-person co-chair summits at the neutral facility (site selection OPEN; decide by Month 1 = 2026-11-08).

**Responsible Body/Role:** Designated Co-Chairs (US and Chinese national co-chairs, now formally appointed and in office)

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Co-chair office operational with bilingual staff and secure communications
- First weekly steering-board meeting held and standing calendar established
- Neutral facility selection and host-country commitment (decision by Month 1 = 2026-11-08)

**Dependencies:**

- Bilateral Charter signed and co-chairs named
- Secure communications infrastructure available

### 3. Co-chairs jointly publish the entry-condition roadmap (signed by both) with explicit deadlines and parallel-track assignments: diplomatic/legal track (instrument signature Month 1 = 2026-11-08); site-selection track (candidate identification Month 0.5 = 2026-10-23, audit Month 1 = 2026-11-08); vendor-engagement track (outreach Month -1, commitments by Month 1 = 2026-11-08); personnel/vetting track (recruitment start Month -3, ongoing through Month 4 = 2027-02-08). Establish 2-week slip escalation thresholds and emergency-summit procedures.

**Responsible Body/Role:** Co-Chair Steering Board (both co-chairs, jointly deciding)

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- Published entry-condition roadmap signed by both co-chairs
- Parallel-track task assignments and deadlines
- 2-week slip escalation procedures documented

**Dependencies:**

- Co-Chair Steering Board operational
- Charter and Terms of Reference locked

### 4. Co-chairs formally establish the Program Operations Center as a joint entity. Appoint US Program Director and Chinese Program Director (1 each, co-located at neutral facility or connected by secure video, direct reporting to co-chairs). Publish detailed operational-execution charter specifying decision authorities (<USD 50M independent per director; >USD 50M double-key; entry-gate certification and verdicts joint only).

**Responsible Body/Role:** Co-Chair Steering Board

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Program Operations Center charter and governance structure
- Named Program Directors (US and Chinese)
- Decision-authority matrix published

**Dependencies:**

- Co-Chair Steering Board operational
- Neutral facility site selected or committed

### 5. Program Operations Center activates the entry-condition task force with bilingual coordinators for each gate: legal/diplomatic track, site-selection track, vendor-engagement track, and personnel/vetting track. Each track lead appointed and staffed with 2-3 coordinators per country (estimated 12-16 FTE total in the task force).

**Responsible Body/Role:** Program Operations Center (Program Directors, directing task-force activation)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- Entry-condition task force structure with named track leads
- Bilingual coordinators assigned to each gate
- Task-force charter and meeting schedule published

**Dependencies:**

- Program Operations Center appointed
- Entry-condition roadmap published

### 6. Co-chairs establish the Evidence and Verification Committee co-chairs (1 senior technical officer per country, FTE). Recruit specialist members: technical/attestation (2 per country), cryptography/key custody (1 per country), equipment identifiers/maintenance records (1 per country), vendor-relation specialists (1 per country), red-team representatives (1 per country). Total: 14-16 FTE.

**Responsible Body/Role:** Co-Chair Steering Board

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 1.5 (2026-11-23)

**Key Outputs/Deliverables:**

- Evidence and Verification Committee charter
- Named co-chairs and specialist members
- Committee meeting schedule and decision-authority matrix

**Dependencies:**

- Co-Chair Steering Board operational
- Senior technical personnel identified from both countries

### 7. Co-chairs establish the Compliance and Audit Committee co-chairs (1 senior finance or audit official per country, reporting independently to co-chairs and respective finance ministries). Recruit supporting staff: budget analysts (2 per country), envelope auditors (1 per country), FTE/payroll specialists (1 per country), shared transparency officer (1 bilingual FTE). Total: 9 FTE internal team.

**Responsible Body/Role:** Co-Chair Steering Board

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- Compliance and Audit Committee charter
- Named committee co-chairs and staff members
- Independence guarantee documented (auditors cannot be overruled by co-chairs)

**Dependencies:**

- Co-Chair Steering Board operational
- Finance and audit leadership from both countries identified

### 8. Compliance and Audit Committee publishes the Compliance and Audit Charter before Phase One begins, specifying auditor independence, escalation procedures, violation-reporting protocols, and public transparency measures. Sign jointly by both co-chairs.

**Responsible Body/Role:** Compliance and Audit Committee (co-chairs, jointly)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Published Compliance and Audit Charter
- Auditor independence guarantee in writing
- Public transparency measures documented

**Dependencies:**

- Compliance and Audit Committee co-chairs appointed
- Charter text reviewed by both countries' finance ministries

### 9. Compliance and Audit Committee identifies and recruits independent third-country auditors (estimated 3-5 total, 1-2 FTE each through Phase One conclusion). Require biography review, security-clearance coordination, and signed independence statement from each. Finalize auditor roster by Month 0 (2026-10-08).

**Responsible Body/Role:** Compliance and Audit Committee co-chairs

**Suggested Timeframe:** Month -2 (2026-08-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Named independent auditors (third-country nationals)
- Signed independence statements from all auditors
- Auditor security clearances coordinated and tracked

**Dependencies:**

- Compliance and Audit Committee co-chairs appointed
- Both countries' security-clearance authorities contacted

### 10. Compliance and Audit Committee establishes the envelope-mapping protocol and budget-tracking system. Define invoice-submission requirements (envelope category, supporting documents, country and cost center), monthly reconciliation procedures, exception-reporting thresholds, and automated alerts when an envelope approaches 110% or 120% of plan. Publish the system documentation bilingual.

**Responsible Body/Role:** Compliance and Audit Committee co-chairs and budget analysts

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Envelope-mapping protocol and budget-tracking system design (published)
- Invoice-submission form templates (bilingual)
- Automated-alert thresholds configured

**Dependencies:**

- Compliance and Audit Committee operational
- Both countries' finance officers briefed on system

### 11. Compliance and Audit Committee designs the KPI dashboard and monthly reporting templates with input from co-chairs, Program Operations, Evidence Committee and counterintelligence offices. Establish bilingual formats, automated data feeds from operational systems, and distribution procedures. Dashboard metrics: detection rates, false positives, unverifiable equipment, parity, discrepancy age, ledger-divergence incidents, funding timeliness, contingency burn, audit exceptions.

**Responsible Body/Role:** Compliance and Audit Committee (co-chairs, transparency officer, and IT support)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- KPI dashboard specification and screen mockups (bilingual)
- Weekly and monthly reporting templates (bilingual)
- Automated data-feed requirements from ledger and operational systems

**Dependencies:**

- Compliance and Audit Committee operational
- Co-chairs and operational-team leads identified

### 12. Co-chairs formally establish the Counterintelligence Oversight Board with 3 senior counterintelligence officers per country (6 total), each representing their national counterintelligence service. Designate a board chair (rotating annual chair, starting with US or by mutual agreement) and executive secretary (1 bilingual FTE reporting to both co-chairs). Establish Board charter guaranteeing independence from program operations.

**Responsible Body/Role:** Co-Chair Steering Board

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Counterintelligence Oversight Board charter
- Named board chair and members (3 per country)
- Executive secretary appointed and operational

**Dependencies:**

- Co-Chair Steering Board operational
- Senior counterintelligence representatives from both countries identified

### 13. Counterintelligence Oversight Board develops inspector vetting and security-review procedures. Establish baseline security-clearance requirements (national-security background check, polygraph or equivalent, compartment-specific clearance for classified evidence). Schedule reviews at deployment and at each 4-month rotation interval. Coordinate with national clearance authorities for pre-approval.

**Responsible Body/Role:** Counterintelligence Oversight Board (members representing both national CI services)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Inspector vetting and security-review procedures (published, classified)
- Clearance-requirement checklist
- Coordination protocols with national CI authorities documented

**Dependencies:**

- Counterintelligence Oversight Board appointed
- Both countries' CI and clearance authorities engaged

### 14. Counterintelligence Oversight Board drafts the Information Firewall Doctrine enforcement procedures. Define compartmentalization rules (isolated by role, site, assignment duration), post-rotation debrief requirements (3-6 hours per inspector, conducted by neutral party), cooling-off periods (3-6 weeks off-site before reassignment), communication-security protocols (on-site secure channels only, monitored logging), and audit procedures (quarterly spot-checks of compliance documentation).

**Responsible Body/Role:** Counterintelligence Oversight Board (members and executive secretary)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Information Firewall Doctrine enforcement procedures (published, classified)
- Compartmentalization rules documented
- Post-rotation debrief and cooling-off templates

**Dependencies:**

- Counterintelligence Oversight Board operational
- Inspector training and deployment schedules known

### 15. Counterintelligence Oversight Board establishes breach-investigation procedures. Define allegation-intake process (any co-chair or inspector can report), triage criteria (substantive allegations only), fact-finding teams (mixed-nationality, 2 senior officers per country), evidence-collection procedures, recommendation-drafting, and co-chair adjudication process (7-day timeline target).

**Responsible Body/Role:** Counterintelligence Oversight Board (members and executive secretary)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Breach-investigation procedures (published, classified)
- Allegation-intake form and triage criteria
- Fact-finding team charter and evidence-collection protocols

**Dependencies:**

- Counterintelligence Oversight Board operational
- Co-chair decision-making authority clarified

### 16. Co-chairs formally establish the Root-of-Trust Key Custody Architecture team by designating 1 principal key-custody officer and 1 deputy per country (4 total). Recruit from national cryptography or information-security agencies. Require background checks and compartmentalized security clearance for classified cryptographic material.

**Responsible Body/Role:** Co-Chair Steering Board

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Named principal and deputy key-custody officers (US and Chinese)
- Key-custody team charter
- Security-clearance applications submitted

**Dependencies:**

- Co-Chair Steering Board operational
- National cryptography and security agencies identified

### 17. Root-of-Trust Key Custody Architecture team designs key-generation and key-recovery procedures. Document all ceremony steps, material flows, access controls, physical security requirements, witness roles and sign-off procedures. Prepare procedures in English and Mandarin. Circulate for peer review by cryptographic experts from both countries. Finalize procedures by Month 0 (2026-10-08).

**Responsible Body/Role:** Root-of-Trust Key Custody Architecture team (principal and deputy officers, both countries)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Key-generation ceremony procedures (bilingual, classified)
- Key-recovery procedures (bilingual, classified)
- Witness role and sign-off requirements documented

**Dependencies:**

- Key-custody officers appointed
- Cryptographic experts from both countries identified

### 18. Root-of-Trust Key Custody Architecture team identifies and prepares the neutral secure facility for key-custody operations. Ensure the facility has hardware-security modules (HSMs) or equivalent for key generation, an offline secure workspace for ceremony execution, dual-custody safe or vault for key-share storage, and audit-log capability. Conduct a security dry-run at Month 0 (2026-10-08) and full operational test at Month 1.5 (2026-11-23).

**Responsible Body/Role:** Root-of-Trust Key Custody Architecture team with neutral facility director

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 1.5 (2026-11-23)

**Key Outputs/Deliverables:**

- Neutral facility key-custody infrastructure certified
- Hardware-security modules (HSMs) installed and tested
- Security dry-run report (Month 0 = 2026-10-08)
- Full operational test passed (Month 1.5 = 2026-11-23)

**Dependencies:**

- Neutral facility site selected and committed
- Key-custody procedures drafted and reviewed

### 19. Root-of-Trust Key Custody Architecture team prepares backup-and-restore procedures for ledger recovery (if needed for key-loss recovery). Establish daily encrypted backups of both national ledger copies at geographically separated secure locations. Test restore time (target <2 hours) and verify integrity of restored entries. Coordinate with the Ledger Synchronization team on backup procedures.

**Responsible Body/Role:** Root-of-Trust Key Custody Architecture team with Ledger Synchronization team (to be established later)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Backup-and-restore procedure design (classified)
- Recovery-time testing protocol
- Coordinate with ledger team (placeholder for later establishment)

**Dependencies:**

- Key-custody team appointed
- Ledger infrastructure design initiated

### 20. Root-of-Trust Key Custody Architecture team documents the key-custody audit trail and access-log procedures. Design a tamper-evident access log (hardware-enforced if possible) recording all key-access events with timestamp, accessing officer, purpose and outcome. Ensure the log cannot be modified retroactively. Test log integrity quarterly.

**Responsible Body/Role:** Root-of-Trust Key Custody Architecture team

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Key-custody audit trail and access-log procedures (classified)
- Tamper-evident log design specifications
- Quarterly audit-log-integrity test protocol

**Dependencies:**

- Key-custody team appointed
- Facility infrastructure finalized

### 21. Root-of-Trust Key Custody Architecture team conducts training for all key-custody officers (principal + deputy per country, 4 total). Provide hands-on training on ceremony execution, emergency procedures, evidence collection, and recovery procedures. Require all four officers to sign off on understanding and capability. Observe one officer executing a full ceremony from memory (without reference) before deployment.

**Responsible Body/Role:** Root-of-Trust Key Custody Architecture team (principals training deputies and peers)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Key-custody officer training completion certificates (4 officers)
- Training documentation and exam results
- Observed ceremony-execution validation (from memory)

**Dependencies:**

- Key-custody officers appointed
- Procedures documented and reviewed
- Facility ready for training exercises

### 22. Program Operations Center establishes detailed budget tracking and contingency-management procedures. Define monthly envelope reconciliation processes (100% invoice sampling, supporting-document verification), exception-reporting thresholds (>2% variance re-check, >5% co-chair escalation), and contingency-burn tracking against the USD 500M pool (trigger co-chair briefing at 30%, scope-reduction planning at 50%, joint budget review at 75%). Publish in bilingual format.

**Responsible Body/Role:** Compliance and Audit Committee co-chairs with Program Operations Center

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Monthly envelope reconciliation procedure (published)
- Exception-reporting thresholds and escalation process
- Contingency-burn tracking protocol

**Dependencies:**

- Budget envelope allocation documented (canonical facts)
- Compliance and Audit Committee operational

### 23. Compliance and Audit Committee conducts a compliance-baseline audit of Months -1 and 0 (2026-09-08 to 2026-10-08) spending before Phase One begins. Reconcile major cost categories, confirm that baseline auditor procedures work, and prepare processes for scaling to Phase One volume. Generate baseline audit report for co-chairs.

**Responsible Body/Role:** Independent external auditors (third-country nationals, under committee supervision)

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Compliance baseline audit report (Month -1 and 0 spending)
- Auditor-procedure validation and any recommended adjustments
- Invoice-sampling and exception-analysis templates tested

**Dependencies:**

- Independent auditors identified and cleared
- Envelope-mapping and tracking systems operational

### 24. Program Operations Center, Site-Selection Track Lead coordinates bilateral site-selection workshop (Month 0.5 = 2026-10-23). Identify 4-6 candidate facilities per country with both co-chairs' representatives, inspectorate leaders and operator executives present. Establish reciprocal-access audit criteria: staging area ≥500 sq m, 24-hour accessible, lift capacity ≥50 tons, ≥2 maintenance events per month. Document candidate profiles and hold a bilateral reconciliation meeting.

**Responsible Body/Role:** Program Operations Center, Site-Selection Track Lead (with co-chairs' observers)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- Candidate site identification and facility profiles (4-6 per country)
- Reciprocal-access audit criteria published
- Site-selection workshop notes and bilateral reconciliation

**Dependencies:**

- Program Operations Center operational
- Co-chairs' endorsement of site-selection approach

### 25. Program Operations Center, Site-Selection Track Lead conducts reciprocal-access audits (Months 0-1 = 2026-10-08 to 2026-11-08, compressed from Months -1 to 0 if timeline pressure). Each country's technical team visits the counterpart's proposed sites and documents access scope, timing, facility layouts and functional equivalence in sealed reports. Target completion Month 1 (2026-11-08).

**Responsible Body/Role:** Site-Selection Track Lead with bilateral audit teams (technical specialists from each country)

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Reciprocal-access audit reports (sealed, per site pair)
- Functional-equivalence scoring (staging, lift capacity, access timing)
- Asymmetric-access exceptions documented

**Dependencies:**

- Candidate site profiles documented
- Audit criteria locked

### 26. Co-chairs review audit reports and formally approve the matched pairs based on documented functional equivalence. Require explicit co-chair certification that each pair meets equivalence criteria. Publish audit results and any veto rationale. If access asymmetry cannot be reconciled, exclude that pair from Phase One; reduce the matched set rather than accept asymmetry. Target approval Month 1.5 (2026-11-23); decision locked by Month 3 (2027-01-08).

**Responsible Body/Role:** Co-Chair Steering Board (both co-chairs, jointly reviewing and approving)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 3 (2027-01-08)

**Key Outputs/Deliverables:**

- Co-chair-approved matched-pair roster (3 pairs / 6 sites or reduced count)
- Functional-equivalence certification (signed by both co-chairs)
- Published audit results and veto rationale (if any pairs excluded)

**Dependencies:**

- Reciprocal-access audit reports completed
- Co-chairs convened to review findings

### 27. Program Operations Center, Vendor Liaison Office establishes the Vendor Liaison Office (5 personnel per country: legal, compliance, technical, logistics, adjudication liaison). Begin pre-Phase-One vendor engagement (Months -2 to 0). Offer vendors a choice: participate in the Consortium and retain control over their own evidence package (sealed, accredited independent review), or agree to fallback testing and accept independent examiners' findings without veto.

**Responsible Body/Role:** Program Operations Center, with Vendor Liaison Office leads appointed

**Suggested Timeframe:** Month -2 (2026-08-08) to Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- Vendor Liaison Office charter and staffing (5 per country, named personnel)
- Vendor-engagement strategy and talking points (bilingual)
- Vendor-participation registry template and tracking

**Dependencies:**

- Program Operations Center operational
- Candidate sites and equipment lists identified

### 28. Vendor Liaison Office conducts bilateral vendor-participation negotiations (Months -2 to 2 = 2026-08-08 to 2026-12-08). Secure written commitments from all Tier-1 vendors (estimated 5-10 per country). Document participation commitments in the vendor-participation registry. Publish the registry as an entry-condition milestone by Month 2 (2026-12-08).

**Responsible Body/Role:** Vendor Liaison Office (5 per country: legal, compliance, technical, logistics, adjudication)

**Suggested Timeframe:** Month -2 (2026-08-08) to Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Vendor-participation commitments (signed agreements, estimated 5-10 per country)
- Published vendor-participation registry (entry-condition milestone)
- Fallback-ladder escalation procedures negotiated with vendors

**Dependencies:**

- Vendor Liaison Office staffed and operational
- Candidate sites and equipment identified

### 29. Program Operations Center, Inspectorate Deployment Officer begins inspector recruitment (concurrent with entry-gate negotiations, Month -3 start, before formal clock). Recruitment targets: 144-216 personnel per country (estimated 99 inspection corps + 36 surge pool + 45 specialist units). Establish recruitment pipeline with clear role definitions, qualifications, language requirements (English and Mandarin fluency for bilingual roles). Create recruitment timeline: nominations by Month 1 (2026-11-08), vetting pool ready by Month 2 (2026-12-08).

**Responsible Body/Role:** Program Operations Center, Inspectorate Deployment Officer (1 per country)

**Suggested Timeframe:** Month -3 (2026-07-08) to Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Inspector recruitment roadmap and pipeline (per country)
- Role definitions and qualification standards (bilingual)
- Nominations submitted by Month 1 (2026-11-08)

**Dependencies:**

- Program Operations Center operational
- Site count and layout finalized or estimated

### 30. Program Operations Center coordinates security-clearance processing for inspector nominees (Months 1-4 = 2026-11-08 to 2027-02-08). Each country's national security and counterintelligence authorities vet and clear personnel. Counterintelligence Oversight Board oversees baseline security-clearance reviews and polygraph or equivalent. Target: 80% of inspectors cleared by Month 4 (2027-02-08); 95% by Month 5 (2027-03-08).

**Responsible Body/Role:** Counterintelligence Oversight Board (vetting and clearance coordination) with Program Operations Center (tracking and escalation)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 5 (2027-03-08)

**Key Outputs/Deliverables:**

- Security-clearance applications submitted (estimated 360 total)
- Clearance-processing status tracking (% cleared per month)
- Personnel flagged for additional vetting or removal (if any)

**Dependencies:**

- Inspector nominations finalized
- Counterintelligence Oversight Board operational and trained

### 31. Program Operations Center establishes and funds the bilateral training academy (Months -1 to 5 = 2026-09-08 to 2027-03-08). Develop joint US-China curriculum covering: evidence-collection standards, information-barrier protocols, ledger operations, cryptographic attestation, vendor-refusal fallback procedures, red-team exercises, counterintelligence threat awareness, and compartmentation rules. Recruit instructors from both countries. Schedule first cohort training Month 1 (2026-11-08), ongoing cohorts through Month 5 (2027-03-08).

**Responsible Body/Role:** Program Operations Center with specialist units (Evidence and Verification Committee for curriculum content)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 5 (2027-03-08)

**Key Outputs/Deliverables:**

- Bilateral training academy curriculum (bilingual, classified)
- Facility and instructor resources secured
- First cohort trained by Month 1.5 (2026-11-23)

**Dependencies:**

- Program Operations Center operational
- Evidence Committee members identified to develop curriculum

### 32. Program Operations Center manages full inspector training and certification (Months 1-5 = 2026-11-08 to 2027-03-08). Conduct 2-3 week intensive training for each cohort covering evidence rules, field procedures, secure communications, compartmentation, cooling-off requirements, and operational security. Document training completion and certification for each inspector. Target: first pilot cohort (12-16 personnel, 6-8 per country) trained by Month 1.5 (2026-11-23); full deployment-ready cohorts by Month 5 (2027-03-08).

**Responsible Body/Role:** Training academy instructors with Program Operations Center oversight

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 5 (2027-03-08)

**Key Outputs/Deliverables:**

- Training completion certificates (per inspector, bilingual)
- First pilot cohort trained by Month 1.5 (2026-11-23)
- 80% of target strength trained by Month 4 (2027-02-08)

**Dependencies:**

- Bilateral training academy operational
- Curriculum approved by Evidence Committee

### 33. Program Operations Center, Inspectorate Deployment Officer designs personnel rotation schedule and cooling-off tracking system (Month 0 = 2026-10-08). Establish 4-month on-site, 2-month off-site rotations staggered so 80-90% of each shift is always covered. Create cooling-off tracking system ensuring every returning inspector completes mandatory cooling-off (3-6 weeks) before reassignment. Document rotation schedules and create automated alerts for cooling-off compliance.

**Responsible Body/Role:** Inspectorate Deployment Officer (1 per country) with Counterintelligence Oversight Board

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Personnel rotation schedule template (4 months on-site, 2 off-site)
- Cooling-off tracking system (automated alerts)
- Staggered deployment plan (80-90% shift coverage)

**Dependencies:**

- Inspectorate Deployment Officer appointed
- Information Firewall Doctrine procedures drafted

### 34. Program Operations Center establishes the 20% personnel surge buffer (estimated 30-40 additional inspectors per country on standby) to cover leave, illness and emergency rotations. Create a surge-pool roster, standby-alert procedures, and activation protocols. Document surge-pool costs within the USD 750M personnel envelope (estimated 2-3% additional cost for retention bonuses and standby compensation).

**Responsible Body/Role:** Inspectorate Deployment Officer (1 per country) with Program Operations Center

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 3 (2027-01-08)

**Key Outputs/Deliverables:**

- Surge-pool roster and standby-alert procedures
- Surge-activation protocols and timeline
- Budget allocation for surge costs (2-3% of 750M)

**Dependencies:**

- Personnel recruitment targets finalized
- Rotation schedule designed

### 35. Co-chairs draft and jointly approve bilateral instrument provisions covering: equal co-chair governance, double-key authorization for budgets/protocols/findings/sanctions, deadlock procedures (panel referral by day 10, advisory by day 15, co-chair decision by day 18), partial-suspension triggers (day 14), impaired-confidence triggers (day 21 for identity, day 28 for exit), and emergency-summit escalation (day 35). Target signature Month 1 (2026-11-08).

**Responsible Body/Role:** Co-Chair Steering Board with bilateral legal counsel (appointed by each government)

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Bilateral instrument draft (both language versions, English and Mandarin)
- Legal-counsel review and sign-off
- Signed bilateral instrument by Month 1 (2026-11-08)

**Dependencies:**

- Co-Chair Steering Board operational
- Charter and governance procedures locked

### 36. Each government enacts domestic appropriation acts authorizing its USD 2.5 billion contribution and its domestic access authority for inspectors to operate within its territory. Coordinate ratification timelines to allow synchronized deposit of first tranche (Month 2 = 2026-12-08, 25% = USD 625M per country). Publish evidence of appropriation to co-chairs as entry-condition milestone.

**Responsible Body/Role:** Project Sponsor (US and Chinese government leadership conducting legislative appropriations)

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Appropriation act enacted (each country, bilingual copy)
- Domestic access authority documented
- First tranche (USD 625M per country) deposited by Month 2 (2026-12-08)

**Dependencies:**

- Bilateral instrument signed (Month 1 = 2026-11-08)
- Each government's parliamentary or legislative process

### 37. Evidence and Verification Committee and Program Operations Center jointly establish and fund the independent Exercise Authority (mixed-nationality staff, 8 core personnel, funded from USD 500M testing envelope). Recruit Exercise Authority Director (mixed-nationality) and 7 core staff (split between both countries). Establish Exercise Authority charter guaranteeing independence from co-chair input until after exercise execution.

**Responsible Body/Role:** Evidence and Verification Committee co-chairs (designing scope) with Program Operations Center (recruiting and funding)

**Suggested Timeframe:** Month 1.5 (2026-11-23) to Month 3 (2027-01-08)

**Key Outputs/Deliverables:**

- Exercise Authority charter (independence guaranteed)
- Named Exercise Authority Director and core staff
- Budget allocation confirmed (USD 500M testing envelope)

**Dependencies:**

- Evidence Committee operational
- Program Operations Center and budget authority active

### 38. Evidence and Verification Committee and Program Operations Center pre-stage accredited independent-examiner teams (1 per country, 5-8 specialists per team, estimated 10-16 personnel total, funded from testing envelope). Recruit examiners with expertise in frontier-relevant computing equipment, cryptographic attestation and sealed-evidence procedures. Conduct initial training and dry-runs by Month 4 (2027-02-08). Prepare for rapid mobilization if vendor-refusal fallback procedures are triggered.

**Responsible Body/Role:** Evidence and Verification Committee (defining qualifications) with Program Operations Center (recruiting and staging)

**Suggested Timeframe:** Month 1.5 (2026-11-23) to Month 4 (2027-02-08)

**Key Outputs/Deliverables:**

- Accredited independent-examiner teams recruited (10-16 per country)
- Examiner credentials verified and documented
- Dry-run exercises completed (familiarity with procedures)

**Dependencies:**

- Vendor-refusal fallback procedures designed
- Testing envelope funding available

### 39. Evidence and Verification Committee publishes the draft Layered Evidence Weighting Model (confidential, versioned) in escrow jointly approved by both committee co-chairs by Month 4.5 (2027-02-23). Mark the rule confidential but lock both countries' agreement on the approach. Specify no single evidence source is decisive. Document how attestation, physical inspection, customs records, identifiers, maintenance logs, infrastructure changes and witnessed movement combine into equipment-identity confidence ratings.

**Responsible Body/Role:** Evidence and Verification Committee co-chairs (jointly approving evidence rule)

**Suggested Timeframe:** Month 3 (2027-01-08) to Month 4.5 (2027-02-23)

**Key Outputs/Deliverables:**

- Draft Layered Evidence Weighting Model (confidential, bilingual)
- Joint committee co-chair approval (signed)
- Rule placed in versioned escrow

**Dependencies:**

- Evidence Committee co-chairs and specialists recruited
- Evidence-rule drafting working group convened

### 40. Evidence and Verification Committee, with Program Operations Center support, conducts historical-record validation (Months 4.5-5 = 2027-02-23 to 2027-03-08). Apply the draft evidence-weighting rule to 100-200 historical equipment-change records per participating site, calculate identity-confidence outputs, and compare against known ground truth from operator records or maintenance logs. Target false-positive rate 7-13% (10% target +/- 3 points); false-negative rate <5%.

**Responsible Body/Role:** Evidence and Verification Committee (technical specialists, particularly technical/attestation and identifiers specialists)

**Suggested Timeframe:** Month 4.5 (2027-02-23) to Month 5.5 (2027-03-23)

**Key Outputs/Deliverables:**

- Historical-record validation report (false-positive and false-negative rates)
- Rule-calibration assessment (within target or requires adjustment)
- Adjustment justification (if calibration drifts >5 points)

**Dependencies:**

- Draft evidence rule in escrow
- Access to 100-200 historical records per site

### 41. Evidence and Verification Committee adjusts the evidence rule if pilot results deviate >5 percentage points from target (e.g., false positives 25% vs. 10% target, deviation 15 points = requires adjustment). If deviation is 3-5 points, flag as a review item but do not adjust. Conduct a second validation cohort if adjustment is made. Target completion by Month 5.5 (2027-03-23).

**Responsible Body/Role:** Evidence and Verification Committee (co-chairs, with technical specialists)

**Suggested Timeframe:** Month 5 (2027-03-08) to Month 5.5 (2027-03-23)

**Key Outputs/Deliverables:**

- Rule-adjustment decision (if any) with justification
- Second validation cohort (if adjustment made)
- Calibration confirmed within target range or flag review item

**Dependencies:**

- First historical-record validation completed
- Adjusted rule drafted (if needed)

### 42. Evidence and Verification Committee finalizes the evidence-weighting rule and publishes it in locked version with bilateral double-key co-chair approval by Month 5.5 (2027-03-23). Lock rule for the entire Phase One test window (Months 6-9 = 2027-04-08 to 2027-07-08); no mid-test amendments. Maintain a version-history log showing rule deployment date and which events were evaluated under which version.

**Responsible Body/Role:** Evidence and Verification Committee co-chairs (jointly locking the rule)

**Suggested Timeframe:** Month 5 (2027-03-08) to Month 5.5 (2027-03-23)

**Key Outputs/Deliverables:**

- Final locked evidence-weighting rule (confidential, bilingual, version v1.0)
- Joint co-chair approval (signed, double-key)
- Version-history log and deployment date

**Dependencies:**

- Historical-record validation completed
- Rule adjustments (if any) validated

### 43. Evidence and Verification Committee manages the covered-equipment schedule (confidential, versioned, technology-neutral). Establish maintenance procedures: fixed review points (Months 3, 6, 9 = 2027-01-08, 2027-04-08, 2027-07-08); each amendment double-key approved; effective dates applied to events recorded after amendment date. Freeze the schedule for Phase One operations (Months 6-9 = 2027-04-08 to 2027-07-08) unless emergency review is triggered. Ensure schedule defines which equipment classes are covered, not specific product models.

**Responsible Body/Role:** Evidence and Verification Committee co-chairs (jointly managing and approving amendments)

**Suggested Timeframe:** Month 2 (2026-12-08) to Month 5.5 (2027-03-23) and ongoing through Month 9 (2027-07-08)

**Key Outputs/Deliverables:**

- Covered-equipment schedule version control and amendment log
- Amendment review-point schedule (Months 3, 6, 9 = 2027-01-08, 2027-04-08, 2027-07-08)
- Frozen schedule confirmed for Phase One (Months 6-9 = 2027-04-08 to 2027-07-08)

**Dependencies:**

- Evidence Committee operational
- Initial equipment definitions provided by sites

### 44. Evidence and Verification Committee and Exercise Authority jointly develop exercise-scenario templates and scoring rubrics (Month 4 = 2027-02-08). Pre-register all scenario designs covering all seven event types (unreported arrival, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal, reluctant operator). Define success criteria and scoring procedures. Publish templates (not scenarios) so inspectors understand the event types but not the specific test cases.

**Responsible Body/Role:** Exercise Authority Director and core staff (designing scenarios) with Evidence Committee oversight

**Suggested Timeframe:** Month 3.5 (2027-01-23) to Month 4.5 (2027-02-23)

**Key Outputs/Deliverables:**

- Exercise-scenario templates (bilingual, defining all 7 types)
- Scoring rubrics and success-criteria definitions
- Exercise procedures manual (for inspectors, scenario-blind)

**Dependencies:**

- Exercise Authority appointed and staffed
- Evidence Committee operational

### 45. Program Operations Center coordinates the pilot exercise (Month 5 = 2027-03-08) at a non-production test facility (not a live participating site). Exercise Authority designs and executes all seven event types once (testing all types in parallel without disrupting other testing). Pilot exercise validates detection procedures, scoring consistency and inspector training readiness before Phase One. Inspectors participating in pilot are not blind (training event). Document detection outcomes and scoring, but pilot results do not count toward Phase One detection-rate calculations.

**Responsible Body/Role:** Exercise Authority Director and core staff (executing pilot), Program Operations Center (logistics and observer coordination)

**Suggested Timeframe:** Month 4.5 (2027-02-23) to Month 5.5 (2027-03-23)

**Key Outputs/Deliverables:**

- Pilot exercise execution report (all 7 types run once each)
- Detection and scoring results (pilot, non-binding)
- Inspector training validation and feedback

**Dependencies:**

- Exercise Authority and scenario templates finalized
- Pilot facility secured and prepared
- First inspector cohort trained

### 46. Co-chairs formally pre-approve the roster of the Adjudication Panel (3 technical specialists per country, 6 total) and the advisory technical board for deadlock referral (same 6 members or a second advisory panel, TBD by co-chairs). Document Panel charter, decision authority (technical recommendation only, non-binding on co-chairs but published), and 5-day turnaround target. Panel is convened automatically by the co-chair office when a discrepancy cannot be resolved by inspectors within 10 days.

**Responsible Body/Role:** Co-Chair Steering Board

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Adjudication Panel charter (decision authority and limits)
- Named panel members (3 per country, 6 total)
- Panel roster provided to co-chair office

**Dependencies:**

- Co-Chair Steering Board operational
- Senior technical specialists from both countries identified

### 47. Co-chairs establish the Counterintelligence Oversight Board's monthly classified meeting schedule and emergency-response protocols. Define when breach allegations trigger fact-finding investigations (within 2 hours), when full Board convenes (within 72 hours of investigation), and when recommendations go to co-chairs (with 7-day remediation decision target). Schedule monthly classified meetings, quarterly unclassified summary preparation, and annual security-training refresher.

**Responsible Body/Role:** Counterintelligence Oversight Board (members and executive secretary)

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 1.5 (2026-11-23)

**Key Outputs/Deliverables:**

- CI Board meeting schedule (monthly classified, quarterly unclassified prep)
- Emergency-response escalation procedures (timetable from allegation to co-chair decision)
- Standing agenda template (vetting status, threat assessment, breach investigations)

**Dependencies:**

- Counterintelligence Oversight Board appointed
- Breach-investigation procedures finalized

### 48. Program Operations Center and Counterintelligence Oversight Board jointly conduct bilateral inspector and counterintelligence threat-awareness training during the training academy (Months -1 to 5 = 2026-09-08 to 2027-03-08). Cover threat landscape, reporting requirements, unauthorized-collection penalties, compartmentation rules, cooling-off procedures, secure communication protocols. Document training completion for each inspector before deployment. Require all 360+ inspectors to sign legally binding statements that unauthorized collection or retention of sensitive information is a criminal violation.

**Responsible Body/Role:** Training academy instructors with Counterintelligence Oversight Board (content and legal review)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 5 (2027-03-08)

**Key Outputs/Deliverables:**

- CI threat-awareness training curriculum (bilingual, classified)
- Training completion certificates (per inspector)
- Signed legal statements (unauthorized collection consequences, 360+ inspectors)

**Dependencies:**

- Training academy operational
- Counterintelligence Oversight Board threat assessment completed

### 49. Root-of-Trust Key Custody Architecture team conducts the first key-generation ceremony at Month 1 (2026-11-08) or slips to Month 1.5 (2026-11-23) if facility readiness delayed. Both key-custody officers present (principal + deputy from each country, 4 total); independent witness observes and signs attestation. Dual-hold shares generated and immediately distributed to secure storage in each country. Ceremony documented with signed attestation. Ceremony is witnessed and recorded for audit.

**Responsible Body/Role:** Root-of-Trust Key Custody Architecture team (principals and deputies, both countries)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 1.5 (2026-11-23)

**Key Outputs/Deliverables:**

- Key-generation ceremony conducted and completed
- Dual-hold key shares generated, signed attestation
- Key shares distributed to secure custody (one per country)
- Ceremony documentation archived

**Dependencies:**

- Neutral facility key-custody infrastructure certified
- Key-custody officers trained and ready

### 50. Program Operations Center coordinates with co-chairs to select and commit to the neutral facility site (Geneva or Singapore, decision required by Month 1 = 2026-11-08) for bilateral governance, ledger hosting, key custody and evidence review. Secure host-country commitment for fast-track permitting and construction. Baseline facility needs: 1,000+ sq m secure space, bi-lingual staff, compartmented security architecture, redundant power and network. Target operational by Month 3 (2027-01-08).

**Responsible Body/Role:** Co-Chair Steering Board (site decision) with Program Operations Center (execution)

**Suggested Timeframe:** Month -3 (2026-07-08) to Month 3 (2027-01-08)

**Key Outputs/Deliverables:**

- Neutral facility site selected and committed (Geneva or Singapore)
- Host-country permits and construction authorization secured
- Facility operational by Month 3 (2027-01-08)

**Dependencies:**

- Co-Chair Steering Board operational
- Budget allocation for secure facilities confirmed

### 51. Program Operations Center begins inspectorate deployment and shift scheduling (Months 2-5 = 2026-12-08 to 2027-03-08). Deploy first trained cohort (12-16 personnel, 6-8 per country) to pilot sites by Month 2 (2026-12-08) for dry-run exercises and site-familiarization. Scale deployment: target 80% of full-strength inspectors deployed by Month 4 (2027-02-08), 95% by Month 5 (2027-03-08). Execute 4-month on-site, 2-month off-site rotation schedule. Maintain coverage logs and alert for any gaps.

**Responsible Body/Role:** Inspectorate Deployment Officer (1 per country) with Program Operations Center

**Suggested Timeframe:** Month 2 (2026-12-08) to Month 5.5 (2027-03-23)

**Key Outputs/Deliverables:**

- First cohort deployed by Month 2 (2026-12-08)
- Shift-coverage logs (% deployed per site, per shift)
- 80% deployment by Month 4 (2027-02-08)
- Cooling-off compliance tracking (all returning inspectors complete cooling-off)

**Dependencies:**

- Inspector training completed
- Matched sites approved and access granted
- Rotation schedule finalized

### 52. Program Operations Center coordinates operator-compliance workshops at each participating site (Months 1-2 = 2026-11-08 to 2026-12-08). With co-chairs' representatives present, inspectorate leaders and operator executives attend. Establish baseline access expectations: immediate access to staging areas (within 4 hours of request), cooperative exercise-window scheduling (48-hour advance notice, waived for unreported-arrival tests), staff availability for questions, confidentiality agreements. Require written operator commitments. Conduct dry-run exercises at each site by Month 2 (2026-12-08).

**Responsible Body/Role:** Program Operations Center, Vendor Liaison Office and Site-Selection Track Lead (coordinating with operators)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Operator-compliance workshop minutes (each site)
- Written operator commitments to baseline access
- Dry-run exercise results (access timing, staffing, cooperation)

**Dependencies:**

- Matched sites approved and operators identified
- First inspector cohort available for dry-runs

### 53. Evidence and Verification Committee establishes the independent filter-auditor liaison (1 FTE, third-country national, reports to committee, bilingual). The filter auditor validates disclosure-tier filters to ensure filtering removes no event-relevant detail while protecting sensitive IP and topology. Conduct initial filter-design workshop (Month 1.5 = 2026-11-23) where both sides' inspectors, operators and legal advisors jointly design evidence filters. Target filter-auditor certification by Month 2 (2026-12-08).

**Responsible Body/Role:** Evidence and Verification Committee (establishing filter governance) with filter auditor (validating filters)

**Suggested Timeframe:** Month 1.5 (2026-11-23) to Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Filter-design workshop and joint filter-approval process
- Named independent filter auditor (third-country)
- Filter specifications certified by auditor (bilingual)
- Disclosure-tier access policies locked

**Dependencies:**

- Evidence Committee operational
- Counterpart Evidence Disclosure Tiers concept approved by co-chairs

### 54. Program Operations Center establishes the Program Risk Dashboard process (weekly Month 0-3 = 2026-10-08 to 2027-01-08, bi-weekly Month 4-9 = 2026-10-08 to 2027-07-08). Assign a dedicated Program Risk Officer (1 per country, co-reporting to co-chairs) with authority to call emergency meetings and recommend scope reductions. Track leading indicators: entry-gate burn-down, vendor-refusal count, inspectorate-fill rate, discrepancy-age distribution, ledger-divergence incidents, contingency-burn rate, audit-exception count. Escalation rules: any indicator >2 standard deviations triggers co-chair alert within 48 hours; three or more alerts simultaneously activate emergency joint review.

**Responsible Body/Role:** Program Operations Center and Risk Officers (1 per country), Compliance and Audit Committee (providing dashboard data)

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 3 (2027-01-08) setup; ongoing through Month 9 (2027-07-08)

**Key Outputs/Deliverables:**

- Program Risk Dashboard system designed and operational
- Named Risk Officers (1 per country)
- Weekly dashboard template and automated data feeds

**Dependencies:**

- Program Operations Center operational
- Compliance and Audit Committee providing data sources

### 55. Co-chairs jointly pre-register verdict thresholds by Month 5.5 (2027-03-23) in a bilateral memorandum locked by both. Thresholds include: detection rate ≥70% for planned-event class (proposed), ≥50% for unplanned class (proposed); false-positive rate ≤10% (proposed); unverifiable equipment ≤5% (proposed); reciprocal-access parity ≥85% (proposed, definition TBD); no discrepancy older than 21 days at conclusion (proposed); fewer than 5 open material discrepancies (proposed). Mark all provisional, validated against pilot data. Verdict logic: ≥80% thresholds met = Go; 50-80% = Modify; <50% = Stop.

**Responsible Body/Role:** Co-Chair Steering Board (jointly locking thresholds)

**Suggested Timeframe:** Month 5 (2027-03-08) to Month 5.5 (2027-03-23)

**Key Outputs/Deliverables:**

- Pre-registered verdict thresholds (bilateral memorandum, signed by co-chairs)
- Thresholds marked provisional with validation path
- Verdict-logic formula locked (mechanical scoring, no judgment call)

**Dependencies:**

- Pilot-exercise results available for calibration check
- Historical-record validation completed
- Co-chairs convened for threshold review

### 56. Program Operations Center and Compliance and Audit Committee conduct a final entry-gate certification review (Month 5.5 = 2027-03-23). Verify all entry conditions completed: bilateral instrument signed (Month 1 = 2026-11-08), appropriations and first tranche deposited (Month 2 = 2026-12-08), matched pairs approved (Month 3 = 2027-01-08), vendor-participation registry published (Month 2 = 2026-12-08), inspector approvals (vetting 95% complete by Month 5 = 2027-03-08), covered-equipment schedule adopted (Month 5.5 = 2027-03-23). Co-chairs jointly certify entry-gate completion and authorize the Phase One 90-day clock to begin Month 6 (2027-04-08).

**Responsible Body/Role:** Co-Chair Steering Board (final certification)

**Suggested Timeframe:** Month 5 (2027-03-08) to Month 5.5 (2027-03-23)

**Key Outputs/Deliverables:**

- Entry-gate completion checklist signed by co-chairs
- Entry-gate certification document (bilateral)
- Phase One clock authorization (start Month 6 = 2027-04-08)

**Dependencies:**

- All entry conditions milestones completed
- Risk Dashboard showing no critical cascade risks
- Co-chairs convened for final authorization

### 57. Co-chairs conduct an emergency co-chair summit if any entry-condition gate slips >2 weeks (proposed threshold). Summit convened within 5 days of slip confirmation. Agenda: assess impact on Phase One timeline, decide whether to accelerate subsequent gates, compress reserve, extend overall schedule, or reduce scope (fewer sites, shorter test window). Document summit decision and publish notice of timeline change to both legislatures if Phase One must be delayed or rescoped.

**Responsible Body/Role:** Co-Chair Steering Board

**Suggested Timeframe:** Month -1 (2026-09-08) to Month 5.5 (2027-03-23) as needed (triggered by >2 week slip)

**Key Outputs/Deliverables:**

- Emergency summit convened (within 5 days of slip)
- Slip-impact assessment and decision document
- Timeline adjustment or scope-reduction decision published

**Dependencies:**

- Co-Chair Steering Board operational
- Risk Dashboard tracking gate-slip metrics

### 58. Co-chairs formally authorize the Phase One 90-day operational test to begin Month 6 (2027-04-08), with all governance bodies operational and trained. At this moment, all governance committees (Co-Chair Steering Board, Program Operations Center, Evidence and Verification Committee, Compliance and Audit Committee, Counterintelligence Oversight Board, Root-of-Trust Key Custody Architecture team) are formally constituted and staffed. They have standing meeting schedules, decision authorities locked, and operational procedures in place. The Phase One clock starts.

**Responsible Body/Role:** Co-Chair Steering Board (formal Phase One authorization)

**Suggested Timeframe:** Month 5.5 (2027-03-23) to Month 6 (2027-04-08)

**Key Outputs/Deliverables:**

- Phase One authorization signed by both co-chairs
- Governance-structure operational-readiness confirmation (all committees)
- Phase One clock start date: Month 6 (2027-04-08)

**Dependencies:**

- Entry-gate certification completed (Month 5.5 = 2027-03-23)
- All governance bodies appointed, trained and operational

### 59. During Phase One (Months 6-9 = 2027-04-08 to 2027-07-08), the Co-Chair Steering Board convenes weekly steering meetings (Mondays, 2 hours, bilingual video) and daily co-chair briefings (15 minutes) on KPI dashboard metrics. Program Operations Center runs daily standup (15 minutes) and bi-weekly deep-dive reviews. Evidence and Verification Committee meets bi-weekly, Exercise Authority reports weekly. Compliance and Audit Committee meets bi-weekly. Counterintelligence Oversight Board meets monthly (classified) with quarterly unclassified summaries. Risk Officer escalates any metric >2 standard deviations within 48 hours.

**Responsible Body/Role:** All governance bodies (Co-Chair Steering Board, Program Operations, Evidence Committee, Compliance and Audit, Counterintelligence, Root-of-Trust)

**Suggested Timeframe:** Month 6 (2027-04-08) to Month 9 (2027-07-08)

**Key Outputs/Deliverables:**

- Weekly KPI dashboard (detection rates, false positives, unverifiable equipment, parity, discrepancy age, funding timeliness, audit exceptions)
- Weekly exercise-result compilation and incident log
- Monthly unclassified legislature briefing (bilingual, co-signed by co-chairs)
- Monthly compliance and audit reconciliation

**Dependencies:**

- All governance bodies operational
- Phase One clock begun (Month 6 = 2027-04-08)

### 60. Exercise Authority scores all Phase One exercise results against the pre-registered thresholds as exercises occur (weekly during Months 6-9 = 2027-04-08 to 2027-07-08). Compile detection rates per event type with 95% confidence intervals, false-positive and false-negative tallies, unverifiable-equipment counts, and per-site detection-rate analysis (flag if single site diverges >15% from pooled rate). Publish weekly exercise-result log to Evidence Committee and co-chairs (bilingual, declassified summary for legislatures).

**Responsible Body/Role:** Exercise Authority Director and core staff (scoring and compiling)

**Suggested Timeframe:** Month 6 (2027-04-08) to Month 9 (2027-07-08)

**Key Outputs/Deliverables:**

- Weekly exercise-result compilation (events run, detection outcomes, scoring)
- Detection-rate calculations per event type with 95% confidence intervals
- Unverifiable-equipment analysis and root-cause investigation (if counts surge)

**Dependencies:**

- Exercise Authority operational
- Pre-registered thresholds locked

### 61. Co-chairs score Phase One verdict against locked thresholds and mechanical scoring rules by Month 9.2 (2027-07-14), within 5 days of Phase One clock conclusion (Month 9 = 2027-07-08). Independent auditor validates the scoring against pre-registered rules (no discretion). Verdict determined: ≥80% of thresholds met = Go; 50-80% = Modify; <50% or any hard Stop trigger = Stop. Publish unclassified verdict summary (detection rates, confidence intervals, thresholds, verdict outcome, Go/Modify/Stop decision) by Month 9.2 (2027-07-14).

**Responsible Body/Role:** Co-Chair Steering Board (final verdict decision) with independent auditor validation

**Suggested Timeframe:** Month 9 (2027-07-08) to Month 9.2 (2027-07-14)

**Key Outputs/Deliverables:**

- Final Phase One scorecard (all metrics vs. thresholds)
- Independent auditor sign-off on verdict scoring
- Unclassified verdict summary published (bilingual)

**Dependencies:**

- Exercise results compiled and analyzed
- Pre-registered thresholds and scoring rules locked

### 62. Co-chairs formally announce the Phase One Go, Modify or Stop decision by Month 9.5 (2027-07-23). If Go: the Consortium advances to Phase Two under the bilateral instrument. If Modify: co-chairs jointly determine Phase Two scope and conditions and report to legislatures. If Stop: co-chairs jointly declare Phase One concluded without proceeding; assess whether remediation is feasible before a restart is considered. Announce decision in a bilateral statement and brief both legislatures (classified detailed briefing, unclassified summary public).

**Responsible Body/Role:** Co-Chair Steering Board (announcing final decision)

**Suggested Timeframe:** Month 9.2 (2027-07-14) to Month 9.5 (2027-07-23)

**Key Outputs/Deliverables:**

- Joint co-chair announcement of Go/Modify/Stop decision
- Bilateral statement on Phase One outcome
- Classified legislature briefing (each country)
- Unclassified public summary of verdict and rationale

**Dependencies:**

- Verdict scored against locked thresholds
- Independent auditor validation completed

### 63. Compliance and Audit Committee conducts a final Phase One audit (Month 9.5 = 2027-07-23) with independent external auditors. Audit scope: 100% envelope reconciliation (all seven envelopes: ledger, site prep, personnel, facilities, testing, legal, contingency); 10% random sample of invoices and supporting documents; personnel roster and leave records (spot checks); ledger event sampling (5% of all recorded events). Prepare a comprehensive audit report (classified detail, unclassified summary) for co-chairs and legislatures.

**Responsible Body/Role:** Compliance and Audit Committee co-chairs and independent external auditors

**Suggested Timeframe:** Month 9 (2027-07-08) to Month 9.5 (2027-07-23)

**Key Outputs/Deliverables:**

- Final Phase One envelope reconciliation (all 7 envelopes audited)
- Invoice sampling and exception analysis (10% random sample)
- Personnel cost reconciliation and headcount verification
- Comprehensive audit report (classified and unclassified versions)

**Dependencies:**

- Phase One operations concluded (Month 9 = 2027-07-08)
- Monthly reconciliations throughout Phase One completed

### 64. All governance bodies prepare final close-out reports (Month 9.5 = 2027-07-23). Co-Chair Steering Board publishes final KPI dashboard and program summary. Program Operations Center documents all operational decisions, deviations from plan, and lessons learned. Evidence and Verification Committee compiles final detection-rate analysis, false-positive/negative breakdown, and evidence-rule calibration review. Compliance and Audit Committee publishes final budget statement. Counterintelligence Oversight Board submits classified breach-incident summary. All bodies maintain records in a central archive for post-Phase-One review and any Phase Two planning.

**Responsible Body/Role:** All governance bodies (close-out reporting)

**Suggested Timeframe:** Month 9 (2027-07-08) to Month 9.5 (2027-07-23)

**Key Outputs/Deliverables:**

- Co-Chair Steering Board final program summary and KPI dashboard
- Program Operations close-out report
- Evidence Committee final detection-rate and evidence-rule analysis
- Compliance final budget statement
- Counterintelligence Oversight Board classified breach summary
- Centralized record archive for Phase-Two planning

**Dependencies:**

- Phase One operations concluded
- Final verdict announced and legislatures briefed