### 1. Project sponsor (senior US and Chinese political leadership) jointly confirms commitment and authority to establish The Consortium; establishes co-chair mandate and decision-making authority framework in principle.

**Responsible Body/Role:** US and Chinese Political Leadership (Presidential/Prime-ministerial level or equivalent)

**Suggested Timeframe:** Month 0 (2026-10-08)

**Key Outputs/Deliverables:**

- Joint political commitment statement or directive
- Co-chair mandate and authority scope (outlined, not yet signed)
- Authorization to proceed with bilateral instrument drafting

**Dependencies:**

- Project initiation decision by both governments

### 2. Bilateral instrument drafting team (legal counsel from both countries, nominated by political leadership) drafts the foundational bilateral agreement specifying double-key governance, decision thresholds, escalation procedures, deadlock resolution, reciprocity requirements, inspector immunity, technology-transfer rules and participant obligations.

**Responsible Body/Role:** Joint Bilateral Legal Drafting Team (US and Chinese legal counsel, co-led)

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 1.5 (2026-11-23 to 2026-11-23)

**Key Outputs/Deliverables:**

- Draft bilateral instrument v0.1 (internal working version)
- Governance structure and decision-rights framework section
- Double-key authority terms and deadlock-resolution protocols
- Inspector vetting, immunity and conduct-code provisions
- Entry-condition specification and certification procedures
- Dispute-escalation and referee-panel selection mechanism

**Dependencies:**

- Political leadership commitment in principle
- Nomination of US and Chinese lead legal counsel

### 3. Legal drafting team circulates draft bilateral instrument for review and comment by nominated members of the Bilateral Executive Steering Committee (both co-chairs designate), Joint Forensic Panel leads, and Independent Auditor designate.

**Responsible Body/Role:** Joint Bilateral Legal Drafting Team

**Suggested Timeframe:** Month 1.5 (2026-11-23) to Month 2 (2026-12-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Feedback summary from all reviewers
- Consolidated list of requested clarifications or amendments
- Redline draft v0.2 with tracked changes

**Dependencies:**

- Draft v0.1 completed and circulated to designated reviewers
- Reviewers identified and briefing materials prepared

### 4. Senior US political leadership (National Security Advisor or equivalent Cabinet-level sponsor) nominates the US National Co-Chair (Cabinet-level or equivalent senior executive) and the US Deputy National Co-Chair (Head of US National Operations Unit or designated proxy).

**Responsible Body/Role:** US Political Leadership (via National Security Council or Presidential directive)

**Suggested Timeframe:** Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- Written nomination and confirmation of US National Co-Chair
- Written nomination and confirmation of US Deputy National Co-Chair
- Authority delegation letter outlining decision-making scope

**Dependencies:**

- Political commitment in principle from US side

### 5. Senior Chinese political leadership (State Council or Communist Party equivalent) nominates the Chinese National Co-Chair (State Council or equivalent level) and the Chinese Deputy National Co-Chair (Head of Chinese National Operations Unit or designated proxy).

**Responsible Body/Role:** Chinese Political Leadership (via State Council or equivalent)

**Suggested Timeframe:** Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- Written nomination and confirmation of Chinese National Co-Chair
- Written nomination and confirmation of Chinese Deputy National Co-Chair
- Authority delegation letter outlining decision-making scope

**Dependencies:**

- Political commitment in principle from Chinese side

### 6. Nominated US and Chinese National Co-Chairs hold an inaugural bilateral meeting (in person or secure video) to ratify the bilateral instrument governance language, confirm their mutual understanding of double-key authority, and establish weekly steering-committee meeting schedule and decision-recording protocols.

**Responsible Body/Role:** US and Chinese National Co-Chairs (jointly)

**Suggested Timeframe:** Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Meeting minutes documenting governance agreement, weekly schedule confirmation and decision-recording SOP
- Bilateral instrument governance sections finalized and co-signed in principle
- Escalation and deadlock-resolution procedures confirmed in writing

**Dependencies:**

- Both co-chairs nominated and authorized
- Draft bilateral instrument reviewed and cleared for co-chair discussion

### 7. US National Co-Chair and Deputy nominate and select members of the US-side internal governance bodies: Joint Forensic Panel US specialist team (3–5 FTE hardware identity/forensics experts), US National Operations Unit leadership (Director, Deputy Director, Chief of Inspections, Chief of Ledger Operations, vetting officer, operator engagement head, evidence handler), and US inspector cadre leadership roles.

**Responsible Body/Role:** US National Co-Chair (with advice from US Deputy Co-Chair and US-side technical leads)

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 1 (2026-11-08 to 2026-11-08)

**Key Outputs/Deliverables:**

- US forensic panel team roster (3–5 confirmed members, resumes/qualifications)
- US National Operations Unit leadership team roster (6–8 confirmed positions and names)
- US inspector-selection criteria and rapid-replacement pool framework

**Dependencies:**

- US National Co-Chair and Deputy confirmed
- Job descriptions and authority scope for each role defined

### 8. Chinese National Co-Chair and Deputy nominate and select members of the Chinese-side internal governance bodies: Joint Forensic Panel Chinese specialist team (3–5 FTE hardware identity/forensics experts), Chinese National Operations Unit leadership (Director, Deputy Director, Chief of Inspections, Chief of Ledger Operations, vetting officer, operator engagement head, evidence handler), and Chinese inspector cadre leadership roles.

**Responsible Body/Role:** Chinese National Co-Chair (with advice from Chinese Deputy Co-Chair and Chinese-side technical leads)

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 1 (2026-11-08 to 2026-11-08)

**Key Outputs/Deliverables:**

- Chinese forensic panel team roster (3–5 confirmed members, resumes/qualifications)
- Chinese National Operations Unit leadership team roster (6–8 confirmed positions and names)
- Chinese inspector-selection criteria and rapid-replacement pool framework

**Dependencies:**

- Chinese National Co-Chair and Deputy confirmed
- Job descriptions and authority scope for each role defined

### 9. Both National Co-Chairs jointly nominate members of the bilateral (non-national-side) governance bodies: Bilateral Executive Steering Committee observer (neutral third-party facilitator, if agreed), Joint Forensic Panel Chair (senior neutral technical specialist), Independent Testing Unit Director (neutral, international or jointly staffed), Bilateral Inspector Conduct Panel co-chairs (one per country), and Independent Auditor (from jointly agreed international audit firm).

**Responsible Body/Role:** US and Chinese National Co-Chairs (jointly, via mutual nomination and double-key confirmation)

**Suggested Timeframe:** Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Bilateral-role nomination slate (Joint Forensic Panel Chair, ITU Director, Conduct Panel leads, Auditor)
- Conflict-of-interest and independence declarations from all nominees
- Confirmation of willingness to serve and authority limits

**Dependencies:**

- Both co-chairs confirmed and in communication
- Role descriptions and independence criteria defined

### 10. Joint Bilateral Legal Drafting Team (or designated co-chair delegates) finalizes the bilateral instrument with all governance, entry-condition, double-key, escalation and threshold language locked and approved by both co-chairs; instrument is prepared for signature by political leadership.

**Responsible Body/Role:** Joint Bilateral Legal Drafting Team (under co-chair oversight)

**Suggested Timeframe:** Month 1.5 (2026-11-23) to Month 2 (2026-12-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Bilateral instrument final draft (v1.0)
- Both co-chairs' written approval and signature authorization
- Redline history and change-control documentation
- Executive summary for political-leadership signature

**Dependencies:**

- All governance bodies' roles and decision rights defined and agreed
- Escalation procedures and deadlock rules finalized
- Entry-condition milestones and thresholds locked

### 11. Political leadership from both countries formally sign and ratify the bilateral instrument, conferring full legal authority on The Consortium governance structure, entry-condition certification authority and Phase One test mandate.

**Responsible Body/Role:** US and Chinese Political Leadership (Presidential/Prime-ministerial or Cabinet-level signatories)

**Suggested Timeframe:** Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Signed bilateral instrument (both governments' official copies)
- Public statement or notification to relevant domestic authorities (legislatures, security agencies, treasury)
- Authority delegation letters to National Co-Chairs

**Dependencies:**

- Bilateral instrument finalized with both co-chairs' approval
- Legal review completed by both governments' counsel
- Political decision to proceed made at highest level

### 12. Bilateral Executive Steering Committee formally constituted: both National Co-Chairs meet with US and Chinese Deputies and bilateral-role holders (neutral observer if appointed, co-chair proxies) to confirm governance structure, decision-recording protocols, weekly meeting schedule, and escalation procedures. First official BESC meeting convened.

**Responsible Body/Role:** Bilateral Executive Steering Committee (convened by co-chairs)

**Suggested Timeframe:** Month 2.5 (2026-12-23)

**Key Outputs/Deliverables:**

- Formal BESC charter or constitution (decision rights, meeting cadence, escalation rules)
- Signed decision-recording and confidentiality protocols
- First BESC meeting minutes documenting governance confirmation and entry-condition tracking kickoff
- Weekly steering-committee meeting schedule through Month 10 (2027-08-08)

**Dependencies:**

- Bilateral instrument signed by political leadership
- Both National Co-Chairs and Deputies confirmed and in position
- Bilateral-role holders (observer, panels, auditor) identified and accepted

### 13. Bilateral Executive Steering Committee establishes the Joint Forensic and Evidence Adjudication Panel: both co-chairs confirm the panel charter, corroboration rule (fixed rule: identity confirmed when ≥2 independent layers agree, physical inspection + identifier + validated attestation where available; if attestation unavailable, physical inspection + 2 independent records), dispute escalation procedures, and panel convening authority.

**Responsible Body/Role:** Bilateral Executive Steering Committee

**Suggested Timeframe:** Month 2 (2026-12-08) to Month 2.5 (2026-12-23 to 2026-12-23)

**Key Outputs/Deliverables:**

- Joint Forensic Panel charter and decision rights
- Fixed corroboration rule, double-key signed by both co-chairs and recorded in ledger
- Panel-convening SOP and evidence-review templates
- Panel members' conflict-of-interest and independence confirmations

**Dependencies:**

- BESC established and operational
- Bilateral instrument specifying panel authority completed
- Panel Chair and national specialist teams identified and confirmed

### 14. Bilateral Executive Steering Committee establishes the Bilateral Inspector Conduct and Reciprocity Oversight Panel: both co-chairs confirm the three-tier infraction protocol (Tier 1 = written warning, Tier 2 = formal notice and escalation, Tier 3 = removal investigation), zone-boundary enforcement procedures, reciprocal-access parity monitoring metrics, and monthly audit schedule.

**Responsible Body/Role:** Bilateral Executive Steering Committee

**Suggested Timeframe:** Month 2 (2026-12-08) to Month 2.5 (2026-12-23 to 2026-12-23)

**Key Outputs/Deliverables:**

- Bilateral Conduct Panel charter and decision rights
- Three-tier infraction protocol and escalation decision tree, double-key signed
- Inspector conduct code, to be signed by every deployed inspector
- Reciprocal-access parity metrics definition and monthly reporting SOP
- Tier 1, 2, 3 investigation procedures and timeline (Tier 1 = 48h, Tier 2 = 24h, Tier 3 = 12h)

**Dependencies:**

- BESC established and operational
- Bilateral instrument specifying conduct authority completed
- Conduct Panel co-chairs (one per country) and counterintelligence staff identified

### 15. Bilateral Executive Steering Committee establishes the Independent Testing Unit: both co-chairs confirm the ITU Director's authority to design and run blind challenge exercises, maintain a sealed double-key schedule, score results objectively, and provide monthly detection data to BESC. ITU charter locked; scenario-design methodology and fairness-review rubric documented.

**Responsible Body/Role:** Bilateral Executive Steering Committee

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 2 (2026-12-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Independent Testing Unit charter and independence confirmation
- ITU Director and core staff (Scenario Lead, Scoring Lead, Site Coordinators, Red-Team Facilitators, Auditor) identified
- Scenario-design library: 7 event types (unreported arrival, substitution, falsification, delayed access, disputed identity, vendor refusal, reluctant operator) with example scenarios per type
- Fairness-review rubric and peer-review process for scenario validation
- Detection-scoring criteria and metrics (true positive, false negative, false positive definitions per event type)

**Dependencies:**

- BESC established and operational
- Bilateral instrument specifying ITU authority completed
- ITU Director and lead staff identified and cleared for confidential information

### 16. Bilateral Executive Steering Committee establishes the Independent Auditor and KPI Monitoring Office: both co-chairs confirm the Auditor's independence, audit scope (ledger integrity, evidence chain of custody, entry-condition compliance, spending variance, personnel vetting, exercise integrity, KPI dashboard), reporting schedule (quarterly auditor report, monthly KPI dashboard) and escalation authority.

**Responsible Body/Role:** Bilateral Executive Steering Committee

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 2 (2026-12-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Independent Auditor charter and independence confirmation
- Audit scope, methodology and reporting templates
- KPI dashboard design: all metrics, data sources, publication schedule (monthly), threshold definitions (provisional vs. validated)
- Auditor and KPI team roster (Auditor partner, KPI Director, Audit Leads: Ledger/Evidence, Financial, Personnel/Vetting, Exercise/Detection)
- Audit-exception escalation thresholds (e.g., variance >5%, divergence >4 hours unresolved, vetting gap, exercise contamination)

**Dependencies:**

- BESC established and operational
- Bilateral instrument specifying Auditor authority completed
- Independent audit firm and Auditor partner identified and confirmed

### 17. US National Co-Chair and US National Operations Unit Director establish the US National Operations Unit as a formally constituted operational entity: define organizational structure, reporting lines, facility locations (secure ledger facility, inspector deployment sites, contingency operations center), secure communications architecture, and personnel budget allocation per envelope and role.

**Responsible Body/Role:** US National Co-Chair (via US Deputy Co-Chair and USNOU Director)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 2 (2026-12-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- USNOU organizational charter and authority structure
- Facility-location requirements specification (ledger ops, inspector deployment, backup facilities)
- US-side ledger infrastructure design document (cryptographic keys, synchronization architecture, offline backups)
- Personnel budget allocation by role and timeline (inspector vetting starting Month 0.5 = 2026-10-23, deployment by Month 5 = 2027-03-08)
- Incident-response procedures and rapid-replacement protocols for critical posts

**Dependencies:**

- US National Co-Chair and Deputy confirmed
- US National Operations Unit leadership team nominated and assigned
- Site selection begun (anticipated Month 2 = 2026-12-08 completion)

### 18. Chinese National Co-Chair and Chinese National Operations Unit Director establish the Chinese National Operations Unit as a formally constituted operational entity: define organizational structure, reporting lines, facility locations (secure ledger facility, inspector deployment sites, contingency operations center), secure communications architecture, and personnel budget allocation per envelope and role.

**Responsible Body/Role:** Chinese National Co-Chair (via Chinese Deputy Co-Chair and CNOU Director)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 2 (2026-12-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- CNOU organizational charter and authority structure
- Facility-location requirements specification (ledger ops, inspector deployment, backup facilities)
- Chinese-side ledger infrastructure design document (cryptographic keys, synchronization architecture, offline backups)
- Personnel budget allocation by role and timeline (inspector vetting starting Month 0.5 = 2026-10-23, deployment by Month 5 = 2027-03-08)
- Incident-response procedures and rapid-replacement protocols for critical posts

**Dependencies:**

- Chinese National Co-Chair and Deputy confirmed
- Chinese National Operations Unit leadership team nominated and assigned
- Site selection begun (anticipated Month 2 = 2026-12-08 completion)

### 19. Bilateral Executive Steering Committee receives and reviews site-selection proposals from both countries. Each country nominates 3–5 candidate datacenters according to agreed criteria (equipment-change frequency, vendor-mix diversity, staging/maintenance capacity, operator willingness, deliberately hard sites). Technical committee jointly evaluates candidates against objective criteria.

**Responsible Body/Role:** Bilateral Executive Steering Committee (with ad-hoc Technical Site-Selection Committee)

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 1.5 (2026-11-23 to 2026-11-23)

**Key Outputs/Deliverables:**

- US site-nomination package (3–5 candidates with technical data sheets, operator letters of interest, facility descriptions)
- Chinese site-nomination package (3–5 candidates with technical data sheets, operator letters of interest, facility descriptions)
- Joint technical-committee evaluation report: criteria scoring, shortlist recommendation (6–8 jointly vetted sites)

**Dependencies:**

- Site-selection criteria (frequency parity within 20%, vendor-mix diversity, staging capacity, at least 1 hard site per country) defined and signed by both co-chairs
- Operator contacts and interest-gathering begun in Month 0 (2026-10-08)

### 20. Bilateral Executive Steering Committee finalizes site selection: both co-chairs authorize a sealed random draw from the jointly vetted shortlist (6–8 sites), selecting 4 sites (2 US, 2 China). Sites are ratified by written co-chair agreement and published to selected operators.

**Responsible Body/Role:** Bilateral Executive Steering Committee (both co-chairs jointly)

**Suggested Timeframe:** Month 1.5 (2026-11-23) to Month 2 (2026-12-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Sealed-draw procedure documentation and witnesses
- Final 4-site selection: names, geographies, operator names, rationale
- Co-chair joint site-selection agreement (signed)
- Notification letters to selected operators and to non-selected candidates

**Dependencies:**

- Joint technical-committee shortlist evaluation completed
- Both co-chairs agreed on criteria and draw procedure

### 21. US National Operations Unit engages with US selected operators: initiates binding-agreement negotiation, specifying operator obligations (inspector access, equipment-identity verification, third-party escort, maintenance notification, evidence preservation, ledger compliance, exercise participation).

**Responsible Body/Role:** US National Operations Unit (Head of Operator Engagement)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 2 (2026-12-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Operator engagement kickoff meetings (in-person or secure video)
- Draft binding-agreement template tailored to US regulatory environment
- Operator questions/concerns log and responses

**Dependencies:**

- US sites selected and notified
- USNOU leadership and Operator Engagement head in place
- Bilateral instrument governance framework finalized

### 22. Chinese National Operations Unit engages with Chinese selected operators: initiates binding-agreement negotiation, specifying operator obligations (inspector access, equipment-identity verification, third-party escort, maintenance notification, evidence preservation, ledger compliance, exercise participation).

**Responsible Body/Role:** Chinese National Operations Unit (Head of Operator Engagement)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 2 (2026-12-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Operator engagement kickoff meetings (in-person or secure video)
- Draft binding-agreement template tailored to Chinese regulatory environment
- Operator questions/concerns log and responses

**Dependencies:**

- Chinese sites selected and notified
- CNOU leadership and Operator Engagement head in place
- Bilateral instrument governance framework finalized

### 23. US and Chinese National Operations Units jointly establish secure communications infrastructure for the replicated, tamper-evident bilateral ledger: design redundant, secure, encrypted communications links between US and Chinese ledger-operations facilities; specification of synchronization protocol (<1 hour target), cryptographic signing, offline backup, failover procedures and key-management ceremony.

**Responsible Body/Role:** US and Chinese National Operations Units (Chief of Ledger Operations, jointly)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 3 (2027-01-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- Bilateral ledger communications architecture design document
- Secure-link specifications: encryption algorithms, key-exchange protocol, sync-timeout bounds
- Cryptographic signing and verification procedures (who holds keys, access controls, key-rotation schedule)
- Offline-backup and recovery procedures, tested on non-covered equipment
- Scheduled joint key-ceremony plan (if applicable; if not using joint ceremony, two-independent-national-roots plan)

**Dependencies:**

- US and Chinese National Operations Units established
- Bilateral instrument governance and security requirements finalized
- Attestation trust-root strategy decided (joint ceremony vs. cross-validating national roots)

### 24. Bilateral Executive Steering Committee establishes the Reciprocity Gate Entry-Condition Steering Committee (a sub-committee of BESC, or BESC itself with ad-hoc expertise): designates owners for each of the 7 mandatory entry conditions (bilateral instrument, appropriations, domestic authority, sites, inspectors, operators/vendors, equipment schedule) and sets weekly milestone tracking from Month 0 (2026-10-08) onward.

**Responsible Body/Role:** Bilateral Executive Steering Committee

**Suggested Timeframe:** Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- Entry-Condition Steering Committee charter (members, meeting schedule, escalation authorities)
- Entry-condition ownership assignment and milestones spreadsheet
- Weekly tracking dashboard template (condition status, milestone completion %, blockers, escalation recommendations)

**Dependencies:**

- BESC established and first meeting held
- Entry-condition milestones and owners identified (from bilateral instrument and assumptions)

### 25. Bilateral Executive Steering Committee holds its first comprehensive entry-condition review: both co-chairs assess progress on bilateral instrument (signed), appropriations (pending), domestic authority legislation (initiated), site selection (completed), operator engagement (initiated), inspector-vetting workload (identified), equipment-schedule drafting (initiated). Escalates any condition >4 weeks behind plan to political leadership.

**Responsible Body/Role:** Bilateral Executive Steering Committee

**Suggested Timeframe:** Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- First comprehensive entry-condition status report (signed by both co-chairs)
- Blocker identification and escalation memos for any delayed condition
- Revised milestone forecast for remaining entry conditions (Months 2–6 = 2026-12-08 to 2027-04-08)

**Dependencies:**

- Bilateral instrument signed
- Site selection completed
- Operator engagement initiated
- Inspector-vetting planning commenced

### 26. US Treasury and National Operations Unit jointly allocate and secure the US appropriations tranche (USD 2.5 billion) according to the defined budget envelopes (Ledger 625M, Site Prep 500M, Personnel 375M, Facilities 375M, Testing 250M, Legal/Audit 125M, Contingency 250M). Appropriations authority confirms obligation and spending authorization by Month 3 (2027-01-08).

**Responsible Body/Role:** US Treasury and US National Co-Chair (or designated National Operations Unit financial officer)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 3 (2027-01-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- US appropriations legislation or spending authorization (Congressional or Executive)
- Tranche-release schedule: first tranche (Months 0–3 = 2026-10-08 to 2027-01-08) USD 625M, subsequent tranches quarterly
- Envelope allocation sign-off and ledger mapping
- Spending-authority delegation to USNOU

**Dependencies:**

- US political leadership committed and bilateral instrument signed
- Budget envelopes defined and ratified by co-chairs
- Spending plan (by month and envelope) documented

### 27. Chinese Treasury and National Operations Unit jointly allocate and secure the Chinese appropriations tranche (USD 2.5 billion equivalent) according to the defined budget envelopes (Ledger 625M, Site Prep 500M, Personnel 375M, Facilities 375M, Testing 250M, Legal/Audit 125M, Contingency 250M). Appropriations authority confirms obligation and spending authorization by Month 3 (2027-01-08).

**Responsible Body/Role:** Chinese Treasury and Chinese National Co-Chair (or designated National Operations Unit financial officer)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 3 (2027-01-08 to 2027-01-08)

**Key Outputs/Deliverables:**

- Chinese appropriations authorization or spending directive
- Tranche-release schedule: first tranche (Months 0–3 = 2026-10-08 to 2027-01-08) equivalent USD 625M, subsequent tranches quarterly
- Envelope allocation sign-off and ledger mapping
- Spending-authority delegation to CNOU

**Dependencies:**

- Chinese political leadership committed and bilateral instrument signed
- Budget envelopes defined and ratified by co-chairs
- Spending plan (by month and envelope) documented

### 28. US National Operations Unit initiates counterintelligence vetting of approximately 180–185 candidate US inspectors (144 baseline FTE inspectors + 20–30% surge pool) through expedited clearance request to FBI, NSA and relevant security agencies; vetting timeline 14–16 weeks (expedited) to Month 5 (2027-03-08).

**Responsible Body/Role:** US National Operations Unit (Inspector Vetting Officer, in coordination with US counterintelligence agencies)

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 5 (2027-03-08 to 2027-03-08)

**Key Outputs/Deliverables:**

- Candidate inspector roster with resumes and vetting-request submissions
- Vetting-status tracking dashboard (status per candidate: submitted, in-review, cleared, conditional, denied)
- Cleared-inspector roster by Month 5 (2027-03-08), minimum 80% fill rate (144 baseline) confirmed

**Dependencies:**

- USNOU leadership in place and vetting request authority delegated
- Vetting criteria and expedited timeline requested from US security agencies in Month 0.5 (2026-10-23)
- Vetting capacity (human and IT infrastructure) available at agencies

### 29. Chinese National Operations Unit initiates counterintelligence vetting of approximately 180–185 candidate Chinese inspectors (144 baseline FTE inspectors + 20–30% surge pool) through expedited clearance request to Ministry of State Security, Ministry of National Defense and relevant security organs; vetting timeline 14–16 weeks (expedited) to Month 5 (2027-03-08).

**Responsible Body/Role:** Chinese National Operations Unit (Inspector Vetting Officer, in coordination with Chinese counterintelligence agencies)

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 5 (2027-03-08 to 2027-03-08)

**Key Outputs/Deliverables:**

- Candidate inspector roster with CVs and vetting-request submissions
- Vetting-status tracking dashboard (status per candidate: submitted, in-review, cleared, conditional, denied)
- Cleared-inspector roster by Month 5 (2027-03-08), minimum 80% fill rate (144 baseline) confirmed

**Dependencies:**

- CNOU leadership in place and vetting request authority delegated
- Vetting criteria and expedited timeline requested from Chinese security organs in Month 0.5 (2026-10-23)
- Vetting capacity (human and administrative infrastructure) available at agencies

### 30. US and Chinese National Operations Units jointly draft the provisional covered-equipment schedule: a confidential, versioned, manufacturer-neutral technical specification of equipment classes and categories covered by Phase One verification. Schedule incorporates input from independent testing unit (for challenge-exercise scenario design) and is reviewed by both national technical teams.

**Responsible Body/Role:** US and Chinese National Operations Units (Chief of Ledger Operations or designated technical lead, jointly)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 2.5 (2026-12-23 to 2026-12-23)

**Key Outputs/Deliverables:**

- Draft provisional covered-equipment schedule v0.1 (functional/risk-relevance based, not product/manufacturer specific)
- Equipment-class definitions (compute, storage, networking, power, cooling categories)
- Inclusion/exclusion rationale
- Versioning and amendment procedures (double-key protocol change required)

**Dependencies:**

- Sites selected and operator liaisons established (to confirm equipment profile)
- Independent Testing Unit in position to advise on exercise-scenario relevance
- Both co-chairs ready to review and approve

### 31. Bilateral Executive Steering Committee formally adopts the provisional covered-equipment schedule: both co-chairs sign off on the schedule, mark it confidential, assign it a version number, and record it in the bilateral ledger as a baseline reference. Schedule is frozen through Phase One, with amendments only via recorded protocol change.

**Responsible Body/Role:** Bilateral Executive Steering Committee (both co-chairs)

**Suggested Timeframe:** Month 3 (2027-01-08)

**Key Outputs/Deliverables:**

- Bilateral co-chair approval and signature on provisional covered-equipment schedule
- Version number and confidential marking
- Ledger entry recording adoption, signed by both national ledger operators
- Amendment procedure documentation (requires double-key protocol change, recorded in ledger)

**Dependencies:**

- Draft schedule completed and reviewed by both national technical teams
- Both co-chairs ready to lock the baseline for the 90-day test

### 32. US National Operations Unit engages with top 5–8 equipment manufacturers and logistics vendors at US participating sites: negotiates binding cooperation agreements specifying attestation sharing, equipment-identity disclosure, maintenance reporting, third-party escort and evidence-preservation requirements, with penalty clauses (contract termination, loss of market access) for refusal.

**Responsible Body/Role:** US National Operations Unit (Head of Operator Engagement, in coordination with USNOU Director)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 4 (2027-02-08 to 2027-02-08)

**Key Outputs/Deliverables:**

- Binding-agreement templates tailored to each vendor class (manufacturers, maintenance providers, logistics)
- Signed or nearly-signed cooperation agreements with 5–8 key vendors at each site (10–16 total US-side vendor agreements)
- Vendor questions/concerns log and responses

**Dependencies:**

- Sites selected and operator liaisons established
- Equipment schedule finalized (so vendors know what equipment is covered)
- Bilateral instrument completed (governance framework defined)

### 33. Chinese National Operations Unit engages with top 5–8 equipment manufacturers and logistics vendors at Chinese participating sites: negotiates binding cooperation agreements specifying attestation sharing, equipment-identity disclosure, maintenance reporting, third-party escort and evidence-preservation requirements, with penalty clauses (contract termination, loss of market access) for refusal.

**Responsible Body/Role:** Chinese National Operations Unit (Head of Operator Engagement, in coordination with CNOU Director)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 4 (2027-02-08 to 2027-02-08)

**Key Outputs/Deliverables:**

- Binding-agreement templates tailored to each vendor class (manufacturers, maintenance providers, logistics)
- Signed or nearly-signed cooperation agreements with 5–8 key vendors at each site (10–16 total Chinese-side vendor agreements)
- Vendor questions/concerns log and responses

**Dependencies:**

- Sites selected and operator liaisons established
- Equipment schedule finalized (so vendors know what equipment is covered)
- Bilateral instrument completed (governance framework defined)

### 34. US National Operations Unit pre-qualifies a pool of 3–5 independent hardware-identity examiners and pre-identifies 1 clean-room facility available for vendor-refusal fallback routes; signs access agreements and pricing schedules by Month 4 (2027-02-08).

**Responsible Body/Role:** US National Operations Unit (Chief of Evidence Handling or equivalent technical lead)

**Suggested Timeframe:** Month 2 (2026-12-08) to Month 4 (2027-02-08 to 2027-02-08)

**Key Outputs/Deliverables:**

- Pre-qualified independent-examiner pool roster (3–5 US labs with expertise, qualifications, contact information)
- Clean-room facility pre-identification (1 facility, location, capabilities, access procedures)
- Signed access agreements and pricing schedules (cost cap: USD 20–30k per examination estimate)

**Dependencies:**

- Equipment schedule finalized (to specify equipment classes needing examiner expertise)
- Budget envelope (USD 250M testing) confirmed available
- Vendor-refusal protocol procedures documented

### 35. Chinese National Operations Unit pre-qualifies a pool of 3–5 independent hardware-identity examiners and pre-identifies 1 clean-room facility available for vendor-refusal fallback routes; signs access agreements and pricing schedules by Month 4 (2027-02-08).

**Responsible Body/Role:** Chinese National Operations Unit (Chief of Evidence Handling or equivalent technical lead)

**Suggested Timeframe:** Month 2 (2026-12-08) to Month 4 (2027-02-08 to 2027-02-08)

**Key Outputs/Deliverables:**

- Pre-qualified independent-examiner pool roster (3–5 Chinese labs with expertise, qualifications, contact information)
- Clean-room facility pre-identification (1 facility, location, capabilities, access procedures)
- Signed access agreements and pricing schedules (cost cap: USD 20–30k per examination estimate, or Chinese currency equivalent)

**Dependencies:**

- Equipment schedule finalized (to specify equipment classes needing examiner expertise)
- Budget envelope (USD 250M testing) confirmed available
- Vendor-refusal protocol procedures documented

### 36. US and Chinese National Operations Units jointly finalize and sign bilateral operator and vendor binding agreements at all 4 participating sites: both countries' operators commit to inspector access, equipment-identity verification, third-party escort, maintenance notification, evidence preservation, ledger compliance and exercise participation. Vendor agreements commit to cooperation or trigger escalation ladder.

**Responsible Body/Role:** US and Chinese National Operations Units (Head of Operator Engagement, jointly; signatures authorized by National Co-Chair or Deputy)

**Suggested Timeframe:** Month 4 (2027-02-08)

**Key Outputs/Deliverables:**

- Signed bilateral operator and vendor binding agreements at all 4 sites
- Operator commitment confirmations (evidence of operator signature authority and commitment)
- Vendor cooperation confirmations from top 5–8 vendors per site
- Escalation ladder trigger points documented (vendor request date, escalation authority, penalties)

**Dependencies:**

- Operator engagement completed at all sites
- Vendor engagement completed with top vendors
- Bilateral instrument governance framework finalized
- Budget authorization and contingency procedures in place (to fund fallback routes if needed)

### 37. US National Operations Unit designs and deploys secure US-side ledger-operations facility: secure facility for cryptographic key management, ledger synchronization with Chinese copy, offline backup and failover, access-control logging, redundant power/comms, and 24/7 operations capability. Facility operational and stress-tested on non-covered equipment by Month 4 (2027-02-08).

**Responsible Body/Role:** US National Operations Unit (Chief of Ledger Operations, with IT/security engineering support)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 4 (2027-02-08 to 2027-02-08)

**Key Outputs/Deliverables:**

- US ledger-facility design document (physical security, access control, cryptographic key custody, failover architecture)
- Facility location confirmation and facility-management contracts
- Cryptographic key-ceremony procedures (either joint ceremony if using split custody, or US national root plan if dual-roots)
- Stress-test results on non-covered equipment: sync latency <1 hour, divergence detection <2 hours, recovery <4 hours, operational readiness confirmed

**Dependencies:**

- USNOU Chief of Ledger Operations in place
- Bilateral ledger communications architecture designed (joint with CNOU)
- Attestation trust-root strategy decided (joint ceremony vs. independent national roots)
- Budget envelope (USD 625M ledger/comms) confirmed available

### 38. Chinese National Operations Unit designs and deploys secure Chinese-side ledger-operations facility: secure facility for cryptographic key management, ledger synchronization with US copy, offline backup and failover, access-control logging, redundant power/comms, and 24/7 operations capability. Facility operational and stress-tested on non-covered equipment by Month 4 (2027-02-08).

**Responsible Body/Role:** Chinese National Operations Unit (Chief of Ledger Operations, with IT/security engineering support)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 4 (2027-02-08 to 2027-02-08)

**Key Outputs/Deliverables:**

- Chinese ledger-facility design document (physical security, access control, cryptographic key custody, failover architecture)
- Facility location confirmation and facility-management contracts
- Cryptographic key-ceremony procedures (either joint ceremony if using split custody, or Chinese national root plan if dual-roots)
- Stress-test results on non-covered equipment: sync latency <1 hour, divergence detection <2 hours, recovery <4 hours, operational readiness confirmed

**Dependencies:**

- CNOU Chief of Ledger Operations in place
- Bilateral ledger communications architecture designed (joint with USNOU)
- Attestation trust-root strategy decided (joint ceremony vs. independent national roots)
- Budget envelope (USD 625M ledger/comms) confirmed available

### 39. US and Chinese National Operations Units jointly conduct a full ledger synchronization and failover stress test using non-covered equipment (placeholder or surplus items) at participating sites: test sync latency, divergence detection, offline backup restoration, cryptographic signing and verification, access-log integrity and forensic recovery procedures. Confirm <1 hour sync, <2 hour divergence detection and <4 hour recovery.

**Responsible Body/Role:** US and Chinese National Operations Units (Chief of Ledger Operations, jointly, with Independent Auditor observing)

**Suggested Timeframe:** Month 4 (2027-02-08)

**Key Outputs/Deliverables:**

- Joint ledger stress-test plan (scenarios, equipment, timeline, success criteria)
- Stress-test execution log (real-time performance metrics, anomalies, resolution steps)
- Stress-test results summary: sync latency, divergence detection time, recovery time, cryptographic verification success rate
- Audit sign-off: Independent Auditor confirms ledger resilience meets Phase One requirements
- Operator of record: go/no-go decision by both Chiefs of Ledger Operations

**Dependencies:**

- Both US and Chinese ledger facilities deployed and operational
- Secure communications links configured and tested
- Cryptographic key material in place (either from joint ceremony or dual national roots)
- Non-covered equipment reserved for testing (100–150 units per site)

### 40. Independent Testing Unit designs challenge-exercise scenarios and fair-ness rubric: specifies 7 event types (unreported arrival, substituted equipment, record falsification, delayed access, disputed identity, vendor refusal, reluctant operator), example scenarios per type, difficulty levels and realism benchmarks. Scenario peer-review rubric defined to validate fairness and comparability across countries.

**Responsible Body/Role:** Independent Testing Unit (Scenario Design Lead, with red-team facilitators from both countries)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 2 (2026-12-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Challenge-exercise scenario library (7 event types, 2–3 example scenarios per type, difficulty levels and realism descriptions)
- Scenario-design guidelines (how scenarios are generated, tested for fairness, and approved)
- Fairness-review rubric (criteria for assessing whether scenarios are realistic, comparable across countries, not biased toward either national team of inspectors)
- Peer-review process documentation (both countries' red teams review scenarios before formal exercises)

**Dependencies:**

- Independent Testing Unit Director and Scenario Design Lead in place
- Red-team facilitators from both countries identified and briefed
- Equipment schedule finalized (to ensure scenarios are realistic for covered equipment)

### 41. Independent Testing Unit conducts scenario peer-review workshop: both countries' red teams jointly review challenge scenarios against the fairness rubric, assess realism and comparability, and certify that scenarios are unbiased. Any fairness disputes are escalated to BESC.

**Responsible Body/Role:** Independent Testing Unit (ITU Director, Scenario Design Lead, Red-Team Facilitators from both countries)

**Suggested Timeframe:** Month 1.5 (2026-11-23) to Month 2 (2026-12-08 to 2026-12-08)

**Key Outputs/Deliverables:**

- Peer-review meeting minutes documenting red-team assessment of fairness and realism
- Peer-review sign-off form: each national red team certifies scenarios meet fairness criteria
- Disputed-scenario list (if any) escalated to BESC with fairness objections noted

**Dependencies:**

- Scenario library completed and circulated to both red teams
- Fairness-review rubric finalized and agreed by both teams
- Bilateral assessment methodology established

### 42. Independent Testing Unit conducts pre-test calibration exercise on non-covered equipment (Months 4–5 = 2027-02-08 to 2027-03-08): runs 50–100 practice scenarios per site using the same blind-exercise methodology as formal Phase One challenges. Inspectors blind to timing/content; scenarios cover all 7 event types. ITU scores detection rates, false-positive/negative counts and identity-confidence results.

**Responsible Body/Role:** Independent Testing Unit (ITU Director, Scenario Design Lead, Scoring Lead, Site Coordinators, Red-Team Facilitators, Independent Auditor)

**Suggested Timeframe:** Month 4 (2027-02-08) to Month 5 (2027-03-08 to 2027-03-08)

**Key Outputs/Deliverables:**

- Calibration-exercise execution log (scenarios run, dates, sites, inspectors blind-maintained, anomalies)
- Detection-rate results by event type: false-negative rate (%)，false-positive rate (%), detection-time distribution
- Calibration report: observed performance vs. provisional thresholds, recommendation for threshold adjustment or confirmation
- Auditor sign-off: Independent Auditor confirms calibration exercise integrity and scoring objectivity

**Dependencies:**

- Scenario library finalized and peer-reviewed
- Sites operational with inspectors deployed at 80%+ fill
- Non-covered equipment reserved and accessible at each site (100–150 units)
- Blind protocols and scoring procedures validated in pre-test workshops

### 43. Bilateral Executive Steering Committee receives calibration-exercise results and validates or adjusts provisional Go/Modify/Stop thresholds: compares observed detection rates, false-positive rates and unverifiable-equipment counts against baseline provisional targets. If observed performance differs >20% from provisional, both co-chairs authorize a recorded double-key amendment to lock the validated thresholds.

**Responsible Body/Role:** Bilateral Executive Steering Committee (both co-chairs), advised by Independent Testing Unit, Independent Auditor and Joint Forensic Panel

**Suggested Timeframe:** Month 5 (2027-03-08)

**Key Outputs/Deliverables:**

- Calibration results briefing to co-chairs (summarizing observed vs. provisional thresholds)
- Threshold validation or adjustment decision: co-chair signed agreement
- Validated thresholds, double-key signed and recorded in bilateral ledger
- Amendment documentation (if thresholds adjusted): recorded protocol change, signed by both co-chairs

**Dependencies:**

- Calibration exercise completed and scored
- Auditor sign-off on calibration integrity
- Provisional thresholds defined and published pre-calibration

### 44. Bilateral Executive Steering Committee designs and locks the sealed double-key challenge-exercise schedule for Phase One (Months 6–9 = 2027-04-08 to 2027-07-08): specifies exercise timing, sequence, venue (per-site staging/spare/maintenance areas), scenario details, red-team assignments, and blind-maintenance protocols. Schedule is signed by both co-chairs and held in sealed custody by ITU.

**Responsible Body/Role:** Bilateral Executive Steering Committee (both co-chairs), with Independent Testing Unit

**Suggested Timeframe:** Month 5.5 (2027-03-23)

**Key Outputs/Deliverables:**

- Sealed double-key exercise schedule (timing, sequence, sites, scenarios, red-team leads, inspector-blind protocols)
- Exercise schedule lock agreement, signed by both co-chairs
- Sealed-custody procedures documented (ITU Director holds schedule; elements released only as exercises occur)
- Site-coordination schedule (maintenance window compatibility, production-impact mitigation plan)

**Dependencies:**

- Calibration exercise completed and thresholds validated
- Scenario library finalized and fairness-reviewed
- All 4 sites selected and operators committed
- Inspectors deployed at 80%+ fill (both countries)

### 45. Bilateral Executive Steering Committee holds final comprehensive entry-condition certification review and formally certifies that all 7 mandatory entry conditions have been met: (1) bilateral instrument signed; (2) appropriations secured; (3) domestic authority enacted; (4) sites selected and ratified; (5) inspectors approved; (6) operators/vendors binding agreements signed; (7) equipment schedule adopted. Co-chairs issue a joint entry-condition certification memo.

**Responsible Body/Role:** Bilateral Executive Steering Committee (both co-chairs)

**Suggested Timeframe:** Month 6 (2027-04-08)

**Key Outputs/Deliverables:**

- Entry-Condition Certification Memo (jointly signed by both co-chairs)
- Checklist of all 7 conditions with sign-off evidence (signed documents, approvals, documented confirmations)
- Ledger entry recording certification (both national copies)
- Formal authorization to start the 90-day Phase One test clock

**Dependencies:**

- All 7 entry conditions demonstrated to be complete
- Weekly steering-committee tracking confirms no major blockers remain
- Independent Auditor confirms compliance with entry-condition requirements
- All governance bodies (BESC, Forensic Panel, Conduct Panel, ITU, Auditor) formally established and operational

### 46. Phase One formal test clock starts: Bilateral Executive Steering Committee formally declares the start of the 90-day verification test (Months 6–9 = 2027-04-08 to 2027-07-08). All governance bodies enter full operational mode. Inspectors begin shift coverage at all 4 participating sites. First national ledger entries are recorded (site status, inspector rosters, equipment baseline, initial observations).

**Responsible Body/Role:** Bilateral Executive Steering Committee (both co-chairs), with all operational units (USNOU, CNOU, ITU, Conduct Panel, Auditor)

**Suggested Timeframe:** Month 6 (2027-04-08) — Day 1 of 90-day Phase One test

**Key Outputs/Deliverables:**

- Phase One Start Declaration (jointly signed by both co-chairs, recorded in ledger)
- Inspector deployment confirmation at all 4 sites (shift rosters, personnel, zone assignments)
- Baseline ledger entries (site status, equipment inventory baseline, initial observations)
- Weekly entry-condition tracking transitions to weekly KPI dashboard tracking

**Dependencies:**

- Entry-condition certification completed
- All governance bodies established and tested
- Inspectors deployed and in-place
- Ledger systems synchronized and baseline data recorded

### 47. During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08): Bilateral Executive Steering Committee meets bi-weekly to review KPI dashboard, escalation events, ledger divergence, inspector-conduct incidents and contingency status. Monthly KPI dashboard published by Independent Auditor. Any material findings (divergence >7 days unresolved, spending variance >5%, vetting gap, exercise contamination) escalated to co-chairs within 24 hours.

**Responsible Body/Role:** Bilateral Executive Steering Committee (both co-chairs), supported by all operational units and Independent Auditor

**Suggested Timeframe:** Months 6–9 (2027-04-08 to 2027-07-08) — Bi-weekly BESC meetings; monthly KPI publication

**Key Outputs/Deliverables:**

- Bi-weekly BESC meeting minutes (KPI review, escalations, decisions, co-chair directives)
- Monthly KPI dashboard (detection rates, false rates, divergence counts, reciprocal-access parity, unresolved discrepancies, unverifiable equipment, vendor refusals, funding status, audit exceptions)
- Escalation reports (any material finding triggering co-chair notification within 24 hours)
- Contingency activation decisions (if any; documented co-chair approvals for expenditures >USD 25M per side)

**Dependencies:**

- Phase One clock started
- All governance bodies operational and reporting

### 48. During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08): Independent Testing Unit executes sealed-schedule challenge exercises (up to 2 per site per month = 6 per site over 90 days, or ~24 total across 4 sites). Exercises run blind; inspectors and operators unaware of timing/content until arrival. ITU records detection outcomes (true positive, false negative, false positive) and synchronizes real-time results with national ledger copies.

**Responsible Body/Role:** Independent Testing Unit (ITU Director, Scenario Lead, Scoring Lead, Site Coordinators, Red-Team Facilitators)

**Suggested Timeframe:** Months 6–9 (2027-04-08 to 2027-07-08) — Exercises per sealed double-key schedule

**Key Outputs/Deliverables:**

- Exercise-execution logs (one per exercise: date, site, scenario, inspectors blind-maintained, anomalies, incident response)
- Exercise-scoring sheets (true positive/false negative/false positive per event type, detection time, evidence gathering quality)
- Monthly detection-rate summaries by event type, with false-negative and false-positive counts
- Post-exercise audit reports (Independent Auditor confirms blind integrity and scoring objectivity after each exercise)

**Dependencies:**

- Phase One clock started
- Sealed exercise schedule locked and in ITU custody
- Sites operational and inspectors deployed
- Scenario library finalized and fairness-reviewed

### 49. During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08): Bilateral Inspector Conduct and Reciprocity Oversight Panel conducts monthly access-log audits, reviews Tier 1/2/3 conduct incidents, monitors reciprocal-access parity, and validates inspector-rotation compliance. Any Tier 2 or Tier 3 incidents escalated to Conduct Panel within 12 hours for investigation and recommendation.

**Responsible Body/Role:** Bilateral Inspector Conduct and Reciprocity Oversight Panel (co-chairs per country, with counterintelligence staff)

**Suggested Timeframe:** Months 6–9 (2027-04-08 to 2027-07-08) — Monthly conduct audits; ad-hoc incident response

**Key Outputs/Deliverables:**

- Monthly access-log audit reports (zone-boundary compliance, device-access patterns, anomalies)
- Tier 1 warning documentation (minor infractions handled within panel, on-file)
- Tier 2/3 investigation findings (within 24 hours of incident report, with Conduct Panel recommendation)
- Monthly reciprocal-access parity report (inspector deployment parity, zone-access hours parity, event-witnessing parity, escalation parity)
- Asymmetry-remediation directives (if parity diverges >20%)

**Dependencies:**

- Conduct Panel established and operational
- Inspector code of conduct signed by all deployed inspectors
- Access-log infrastructure (badge-swipe, device-access logging, location tracking) operational at all sites

### 50. During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08): Joint Forensic and Evidence Adjudication Panel activates on-demand for each contested equipment-identity finding or ledger divergence escalation. Panel reviews evidence layers, applies fixed corroboration rule, and issues binding findings within 48 hours or escalates to co-chairs if consensus fails.

**Responsible Body/Role:** Joint Forensic and Evidence Adjudication Panel (Chair and national specialists from both countries)

**Suggested Timeframe:** Months 6–9 (2027-04-08 to 2027-07-08) — On-demand activation (estimated 1–2 panels per week per site)

**Key Outputs/Deliverables:**

- Forensic panel findings (one per contested identity or divergence: evidence layers reviewed, corroboration rule applied, finding issued, provenance recorded)
- Disputed-finding escalation memos (if panel cannot reach consensus, to co-chairs with technical opinion)
- Monthly forensic summary (number of panels convened, findings issued, disputed findings escalated, resolution rate)

**Dependencies:**

- Forensic Panel established and operational
- Fixed corroboration rule double-key signed and published
- Evidence layers (attestation, physical inspection, records, identifiers, maintenance logs, infrastructure, witnessed movement) available from field operations

### 51. During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08): Independent Auditor publishes monthly KPI dashboard with detection rates, false positives/negatives, equipment-identity confidence, ledger-sync divergence counts, reciprocal-access parity, discrepancy-clock tiering, unverifiable-equipment counts, vendor-refusal outcomes, production-disruption incidents, funding-timeliness status and audit exceptions. Auditor flags threshold deviations for BESC attention.

**Responsible Body/Role:** Independent Auditor and KPI Monitoring Office (Auditor partner, KPI Director, Audit Leads)

**Suggested Timeframe:** Months 6–9 (2027-04-08 to 2027-07-08) — Monthly dashboard publication (by day 5 of each month)

**Key Outputs/Deliverables:**

- Monthly KPI Dashboard (all metrics listed above, with current month and cumulative data, threshold targets and deviations flagged)
- Monthly Auditor Exception Report (any findings of variance >5%, divergence >7 days unresolved, vetting gap, exercise contamination, spending anomaly)
- Quarterly Auditor Attestation Report (comprehensive findings on ledger resilience, evidence handling, spending compliance, personnel status, exercise integrity)

**Dependencies:**

- Independent Auditor established and operational
- KPI dashboard templates and data-collection procedures in place
- All governance bodies reporting KPI data (ITU detection rates, JFEAP divergence counts, Conduct Panel parity metrics, USNOU/CNOU spending, etc.)

### 52. At end of Phase One (Month 9 = 2027-07-08): Bilateral Executive Steering Committee compiles final Go/Modify/Stop decision package: Independent Auditor prepares comprehensive evidence summary (detection rates vs. thresholds, false-rate analyses, ledger divergence and reconciliation time, reciprocal-access parity assessment, unresolved-discrepancy age, unverifiable-equipment count, vendor-refusal outcomes, no IP/counterintelligence incidents). Co-chairs review and prepare for final decision.

**Responsible Body/Role:** Bilateral Executive Steering Committee (both co-chairs), with Independent Auditor, Independent Testing Unit and all support bodies

**Suggested Timeframe:** Month 9 (2027-07-08) — End of 90-day Phase One

**Key Outputs/Deliverables:**

- Comprehensive Phase One Evidence Summary Report (90-day data, all KPIs, threshold comparison, anomaly analysis)
- Independent Testing Unit Final Report (challenge-exercise results by event type, detection-rate conclusions, false-rate analysis, confidence assessment)
- Independent Auditor Final Attestation (ledger resilience, evidence integrity, spending compliance, personnel vetting, exercise fairness, any material audit exceptions)
- Bilateral Forensic Panel Final Summary (number of identity disputes resolved, contested findings escalated to co-chairs, unresolved identity count)

**Dependencies:**

- 90 days of Phase One operations completed
- All KPI data collected and validated
- All exercise results scored and audited
- All inspector conduct audits completed
- Ledger final state documented and reconciled

### 53. At end of Phase One (Month 9.5 = 2027-07-23): Bilateral Executive Steering Committee (both co-chairs) issues the formal Go/Modify/Stop decision: assessment of whether blind-challenge detection, false-positive rates, equipment-identity confidence, reciprocal-access parity, unverifiable-equipment counts, vendor-refusal outcomes and funding timeliness meet or exceed thresholds for a Go decision; or whether correctable weaknesses remain (Modify); or whether material failures (asymmetric access, unverifiable >10%, ledger divergence unresolved, funding withheld, low detection) warrant a Stop.

**Responsible Body/Role:** Bilateral Executive Steering Committee (both co-chairs), jointly; decision requires double-key (unanimous) agreement

**Suggested Timeframe:** Month 9.5 (2027-07-23)

**Key Outputs/Deliverables:**

- Go/Modify/Stop Decision Memo (jointly signed by both co-chairs)
- Decision rationale: evidence mapping to thresholds, threshold justification, any waived or adjusted criteria
- If Go: Phase Two authorization or timeline. If Modify: corrective actions, revised timeline and scope. If Stop: explanation of which threshold failures drove the decision and remediation requirements if restart is contemplated
- Ledger entry recording the decision (both national copies signed)

**Dependencies:**

- 90 days of Phase One operations completed and data compiled
- Independent Auditor attestation completed
- All KPI thresholds locked and validated pre-Phase One
- Both co-chairs reviewed and deliberated final evidence package

### 54. At Month 10 (2027-08-08), Bilateral Executive Steering Committee publishes the final Go/Modify/Stop decision to relevant stakeholders (both governments' leadership, participating operators, independent observers if designated, and (redacted for security) to relevant legislative/oversight bodies). Specifies next steps: if Go, Phase Two planning; if Modify, remediation timeline; if Stop, shutdown or hold procedures.

**Responsible Body/Role:** Bilateral Executive Steering Committee (both co-chairs), with communication coordination

**Suggested Timeframe:** Month 10 (2027-08-08)

**Key Outputs/Deliverables:**

- Final Go/Modify/Stop Decision Publication (redacted version for public/oversight audiences, full version for bilateral archives)
- Next-steps directive: Phase Two authorization or timeline; or remediation plan; or shutdown/hold notice
- Stakeholder notification letters to operators, vendors, governments, oversight bodies
- Lessons-learned summary for bilateral reflection and improvement planning

**Dependencies:**

- Go/Modify/Stop decision issued at Month 9.5 (2027-07-23)
- Redaction procedures applied to protect classified/sensitive details
- All governance bodies' final reports completed and archived