### 1. Initiate parallel bilateral-instrument negotiation and establish a bilateral steering group to track negotiation progress weekly, with both governments committing to a fixed instrument-signature deadline of Month 7 (2027-05-12). Begin negotiation by Month 5 (2027-03-12) to allow 16-month runway.

**Responsible Body/Role:** US Department of State and China Ministry of Foreign Affairs (diplomatic leads); designated negotiation teams from both countries.

**Suggested Timeframe:** Month 5 (2027-03-12) to Month 7 (2027-05-12 to 2027-05-12); ongoing weekly progress reviews.

**Key Outputs/Deliverables:**

- Signed bilateral instrument (executive agreement or treaty), fixing co-chair roles, double-key procedures, escalation rules, deadlock definitions, and entry-condition certification logic
- Weekly negotiation status report with blockers and escalation triggers
- Documented instrument-signature target of Month 7 (2027-05-12) with accountability for delays

**Dependencies:**

- Project initiation decision
- US and Chinese government political backing confirmed
- Negotiation team recruitment and briefing

### 2. Establish a bilateral Legal and Regulatory Working Group to identify domestic legal barriers to compulsory operator/vendor participation, export controls, facility clearances and data-transfer rules. Conduct comprehensive legal review for both countries and recommend legislative or regulatory amendments needed before entry gate.

**Responsible Body/Role:** US Department of Justice (Office of Legal Counsel), US Department of Commerce (Bureau of Industry and Security), and China's State Council, Ministry of Commerce and counterpart legal authorities; legal working group co-leads from each country.

**Suggested Timeframe:** Month 5 (2027-03-12) to Month 7.5 (2027-05-27 to 2027-05-27); final legal opinions published by Month 7.5 (2027-05-27).

**Key Outputs/Deliverables:**

- Comprehensive legal barrier assessment (US and China)
- OLC opinion affirming US authority to compel operator/vendor participation
- Chinese legal directive affirming domestic compulsion authority
- Export-control and data-transfer clearance documentation
- Recommended legislative or regulatory amendments (if any) with fast-track timetable

**Dependencies:**

- Bilateral instrument scope and entry conditions defined
- Domestic authority requirements documented
- Negotiation team input on substantive legal terms

### 3. Identify participating datacenters and operators in both countries and conduct preliminary site surveys to document staging areas, spare-inventory zones, maintenance and expansion areas, operator types, logistics access, customs proximity and security posture. Develop a matched-site pairing rationale (by verification function, operator type, or capacity tier) for bilateral agreement.

**Responsible Body/Role:** US project lead (designated by NSC or State Department) and China project lead (designated by relevant ministry); supported by site-survey technical teams.

**Suggested Timeframe:** Month 5 (2027-03-12) to Month 8 (2027-06-12 to 2027-06-12); site selection finalized by Month 8 (2027-06-12).

**Key Outputs/Deliverables:**

- Inventory of candidate sites (≥6 per country, narrowed to 2 per country)
- Physical site-survey reports documenting staging, spare-inventory, maintenance, expansion areas and operator characteristics
- Matched-site pairing rationale document approved by bilateral agreement
- Site selection certification by both countries confirming 4 declared sites ready for Phase One

**Dependencies:**

- Preliminary political backing confirmed
- Budget allocation decision (USD 5B 50/50)
- Covered-equipment schedule draft available to define which equipment zones are in scope

### 4. Draft a provisional, vendor-neutral, hardware-generation-agnostic Covered-Equipment Schedule defining frontier-relevant equipment by functional role (e.g., tensor-accelerated parallel computation exceeding X exaflops per second) rather than manufacturer or product. Establish a double-key schedule-update process for quarterly revisions by bilateral specialist teams.

**Responsible Body/Role:** Bilateral technical specialists (≥2 per country) with security clearances; accountable to the designated project leads from each country.

**Suggested Timeframe:** Month 5 (2027-03-12) to Month 8 (2027-06-12 to 2027-06-12); provisional schedule published for bilateral approval by Month 8 (2027-06-12).

**Key Outputs/Deliverables:**

- Provisional Covered-Equipment Schedule defining covered equipment by functional role with numerical thresholds and abstraction layers
- Schedule version-control procedure and quarterly-update process documented
- Boundary-case resolution rule ('when in doubt, classify as covered') and specialist-review protocols
- Bilateral sign-off on provisional schedule by both countries' technical leads

**Dependencies:**

- Site identification and equipment inventory available from site surveys
- Ledger and attestation system requirements documented
- Legal authority to classify equipment confirmed

### 5. Identify all critical equipment vendors (manufacturers, maintenance providers, logistics firms) for both countries' participating sites. Draft vendor-binding agreements committing vendors to reporting, confidentiality, escort and evidence-preservation duties. Establish a pre-qualified vendor registry with supply-chain consequences for refusal.

**Responsible Body/Role:** Bilateral Vendor and Operator Binding Lead (designated); supported by national vendor-liaison teams (US and China).

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 8 (2027-06-12 to 2027-06-12); vendor-binding agreements signed by Month 8 (2027-06-12).

**Key Outputs/Deliverables:**

- Vendor-identification list (manufacturers, maintenance, logistics) by participating site
- Drafted vendor-binding agreements with confidentiality, reporting and evidence-preservation terms
- Pre-qualified vendor registry roster and supply-chain consequence policy
- Executed vendor-binding agreements signed by each critical vendor and both governments

**Dependencies:**

- Participating sites and operators identified
- Covered-equipment schedule published
- Legal authority to bind vendors confirmed

### 6. Plan and construct accredited clean-room examination centers (≥1 per country) where refusing vendors can submit equipment for supervised testing without exposing source code or proprietary details. Establish accredited-examiner vetting, cryptographic-attestation validation protocols and chain-of-custody procedures.

**Responsible Body/Role:** Bilateral Clean-Room and Accredited-Examiner Lead (designated technical authority); national facility-design and construction leads.

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 9 (2027-07-12 to 2027-07-12); operational by Month 9 (2027-07-12) for Phase One.

**Key Outputs/Deliverables:**

- Clean-room facility design and security specifications (≥2 centers, one per country)
- Attestation-validation laboratory protocols and equipment list
- Accredited-examiner vetting and clearance procedures (bilateral)
- Facility security certification and operational readiness attestation by Month 9 (2027-07-12)

**Dependencies:**

- Vendor-refusal escalation procedures documented
- Budget allocation to secure-facilities envelope (USD 750M)
- Site locations finalized
- Security and facility-access requirements defined

### 7. Recruit, vet, clear and pre-position the Bilateral Steering Committee co-chairs (US deputy secretary level, China vice-minister level) and their deputies. Hold co-chair appointment confirmation meeting with both governments and document succession protocols for continuity.

**Responsible Body/Role:** US government (State Department, NSC) and China's relevant ministry; co-chair nominees subject to bilateral confirmation.

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 7 (2027-05-12 to 2027-05-12); co-chairs confirmed by Month 7 (2027-05-12).

**Key Outputs/Deliverables:**

- Named co-chairs (one per country) with security clearances and confirmed tenure
- Documented succession and continuity plan
- Co-chair confirmation letter from each government
- Deputy co-chair appointments and continuity roster

**Dependencies:**

- Bilateral instrument framework defining co-chair roles published
- Government political backing and personnel authorization confirmed

### 8. Establish a principal-level go/no-go decision checkpoint at Month 7.5 (2027-05-27) to assess entry-condition readiness. Review status of bilateral instrument, appropriations, domestic access authority, site selection, vendor binding and inspector clearance pipeline. Decide whether to proceed to full entry-gate certification by Month 9 (2027-07-12) or defer.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs (newly confirmed); supported by designated project leads and legal working group.

**Suggested Timeframe:** Month 7.5 (2027-05-27); decision documented same day.

**Key Outputs/Deliverables:**

- Principal-level go/no-go checkpoint decision report documenting status of all 7 entry conditions
- Documented decision: proceed to full gate by Month 9 (2027-07-12), defer, or restart with revised scope
- Escalation of any condition lagging timeline with corrective action and revised target date

**Dependencies:**

- Bilateral instrument signature target of Month 7 (2027-05-12) achieved or near-certain
- Status updates on all 6 remaining entry conditions available
- Co-chairs in place and first decision authority confirmed

### 9. Conduct comprehensive legal enactment of domestic access authority in each country, including any required legislative authorization, executive orders or ministerial directives to compel operator and vendor participation. Publish final legal findings confirming domestic compulsion authority is in effect.

**Responsible Body/Role:** US Department of Justice (OLC), Office of Management and Budget; China State Council and relevant ministries; each government's legal/legislative authorities.

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 8 (2027-06-12 to 2027-06-12); final legal authority published by Month 8 (2027-06-12).

**Key Outputs/Deliverables:**

- Published US domestic access authority (legal opinion, executive order or statute)
- Published China domestic access authority (State Council directive or ministerial order)
- Certification by each government that compulsion authority is enacted and in effect
- Legal opinion summary for bilateral record

**Dependencies:**

- Legal barrier assessment completed
- Bilateral instrument framework defining authority scope published
- Operator and vendor participation requirements documented

### 10. Initiate recruitment, vetting and security-clearance processing for all inspectors, technical specialists, legal staff, counterintelligence officers, translators, logistics personnel and support functions (estimated 350-500 cleared full-time staff). Conduct background investigation and polygraph scheduling for all personnel.

**Responsible Body/Role:** US National Security Agency and equivalent China security authorities (personnel vetting agencies); designated recruiting leads from each country's inspectorate-to-be.

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 8 (2027-06-12 to 2027-06-12); clearance processing complete by Month 8.75 (2027-07-05).

**Key Outputs/Deliverables:**

- Recruitment target list (350-500 personnel by function and country) with no single-person critical positions
- Personnel clearance processing status report (polygraph, background investigation, CI vetting)
- Final clearance roster by Month 8.75 (2027-07-05) confirming all Phase One staff cleared
- Clearance denial documentation and appeal resolution for any rejected candidates

**Dependencies:**

- Staffing model and functional unit structure defined
- CI and personnel-vetting protocols established
- Site locations and operational structure finalized

### 11. Recruit and appoint senior technical and CI specialists to establish the Evidence and Ledger Integrity Committee, Counterintelligence and Compartmentation Oversight Unit, and Bilateral Technical Referees Panel. Confirm appointment of committee members and document their operational authorities before Phase One.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs (newly confirmed); supported by designated project leads and recruiting teams.

**Suggested Timeframe:** Month 7 (2027-05-12) to Month 8.5 (2027-06-27 to 2027-06-27); all committee members confirmed by Month 8.5 (2027-06-27).

**Key Outputs/Deliverables:**

- Named members of Evidence and Ledger Integrity Committee (ledger architects, node operators, divergence-reconciliation lead per country)
- Named members of Counterintelligence and Compartmentation Oversight Unit (CI directors, vetting leads, insider-threat red-cell coordinators per country)
- Named members of Bilateral Technical Referees Panel (2 technical experts per country, independent of inspectorate)
- Appointment letters documenting authorities and tenure for each role

**Dependencies:**

- Clearance pipeline complete
- Budget authorization for specialist staffing
- Committee charter and responsibility documents finalized

### 12. Establish the legal and procedural framework for the Bilateral Steering Committee: publish operational bylaws documenting double-key governance, no-casting-vote rule, 5/8/13-day escalation-timer sequence, deadlock definition, enumerated auto-suspension triggers, and decision recording in the tamper-evident ledger.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs; supported by Legal and Regulatory Working Group.

**Suggested Timeframe:** Month 7 (2027-05-12) to Month 8 (2027-06-12 to 2027-06-12); bylaws published and co-chair approved by Month 8 (2027-06-12).

**Key Outputs/Deliverables:**

- Bilateral Steering Committee Operational Bylaws documenting governance procedures, decision thresholds (budgets >USD 10M, protocol changes, personnel assignments), escalation rules and timers, and ledger-recording requirements
- Co-chair decision-authority charter
- Deadlock-definition document with 5-day trigger and escalation sequence
- Enumerated auto-suspension trigger list with objective thresholds (unverifiable >3%, divergence >5%, denial >15%, age >15 days)

**Dependencies:**

- Bilateral instrument signature and co-chair confirmation
- Entry conditions and decision framework defined
- Ledger and KPI architecture specified

### 13. Finalize the ledger and attestation-system architecture, including cryptographic hash-chain design, signed checkpoint format (hourly cadence proposed), transport security (dedicated IPsec tunnel), divergence-detection algorithms and reconciliation procedures. Award contracts for ledger system development and deployment.

**Responsible Body/Role:** US and China national leads for ledger systems; bilateral ledger architect and cybersecurity specialists.

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 8.5 (2027-06-27 to 2027-06-27); system design complete and procurement awarded by Month 8.5 (2027-06-27).

**Key Outputs/Deliverables:**

- Ledger Architecture and Security Specification document
- Cryptographic checkpoint format and hourly validation procedures
- Divergence-detection and reconciliation algorithms
- Transport-security specifications (dedicated IPsec, mutual TLS, no shared internet)
- Ledger system development and deployment contract awards

**Dependencies:**

- Budget allocation to ledger envelope (USD 1.25B)
- Attestation validation and evidence-schema requirements defined
- Facility security and facility access specifications available
- KPI targets (1-hour sync, 4-hour divergence detection, 24-hour reconciliation) published

### 14. Arrange neutral-party digest-custodian services (third-country entity or trusted international organization) to hold encrypted hash-chain digests of both national ledger copies and serve as offline backup and forensic-recovery escrow. Execute escrow agreement by both governments.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs and Legal Working Group; designated neutral custodian organization.

**Suggested Timeframe:** Month 7 (2027-05-12) to Month 8 (2027-06-12 to 2027-06-12); escrow agreement signed by Month 8 (2027-06-12).

**Key Outputs/Deliverables:**

- Neutral-party custodian identification and selection (bilateral agreement)
- Escrow agreement specifying digest format, release triggers, audit rights and offline-backup protocols
- Custodian security vetting and facility inspection completed
- Escrow operational readiness confirmed by Month 8.75 (2027-07-05)

**Dependencies:**

- Ledger architecture and checkpoint format defined
- Budget for custodian services (USD 20-30M estimate, within ledger envelope)
- Bilateral agreement on neutral-party selection criteria

### 15. Hire and deploy the independent testing director, red-team leads (≥1 per country), detection-measurement analysts and filter-adequacy testers. Design sealed 70 blind challenge scenarios (≥10 per event type) covering unreported arrivals, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal and reluctant operators.

**Responsible Body/Role:** Independent testing director (bilingual, cleared, no ties to inspectorate); national red-team leads and testing teams from each country.

**Suggested Timeframe:** Month 7 (2027-05-12) to Month 8 (2027-06-12 to 2027-06-12); scenario design and hash-commitment complete by Month 8.5 (2027-06-27).

**Key Outputs/Deliverables:**

- Independent testing director and red-team leads confirmed with clearances
- 70 sealed blind-challenge scenarios (10 per event type minimum) with injection protocols
- Hash-committed scenario catalog published before Phase One (Month 9, 2027-07-12)
- CHALLENGE-tagging partition protocol and detection-measurement procedures

**Dependencies:**

- Budget allocation to testing envelope (USD 500M)
- Event types and detection thresholds (≥90% proposed) defined
- Cleared independent-tester recruitment and vetting complete

### 16. Draft minimum evidence-schema specification (serial number, firmware version, attestation digest, maintenance-event timestamp, physical identifiers) and establish evidence-filtering rules. Jointly design operator-controlled redaction-gateway rules ensuring non-redactable schema fields are preserved. Publish redaction rules and gateway-logging requirements.

**Responsible Body/Role:** Bilateral Evidence and Ledger Integrity Committee chair; supported by sensitive-asset specialists from each country and operator liaisons.

**Suggested Timeframe:** Month 7 (2027-05-12) to Month 8 (2027-06-12 to 2027-06-12); rules published by Month 8 (2027-06-12).

**Key Outputs/Deliverables:**

- Non-redactable evidence-schema specification (serial number, firmware version, attestation digest, timestamp, physical marks)
- Operator-controlled redaction-gateway rules and field-preservation requirements
- Gateway-logging protocol (every redaction decision logged in ledger with reason code and timestamp)
- Bilateral agreement that stripping any schema field escalates equipment to unverifiable status

**Dependencies:**

- Covered-equipment schedule and identity-verification architecture defined
- Operator compartmentation and IP-protection boundaries agreed
- Ledger system and evidence-recording infrastructure designed

### 17. Conduct a staffing dry-run exercise simulating 7 consecutive days of Phase One intake and monitoring operations at a test site (or by simulation). Validate that 24/7 shift coverage with minimum 2-person teams per function, 15% leave allowance and 10% surge reserve meet readiness requirements. Document staffing KPIs and identify any gaps.

**Responsible Body/Role:** Project Management Office and Operational Execution Team (formation in progress); simulation directors from each country.

**Suggested Timeframe:** Month 8 (2027-06-12); dry-run conducted and results published by Month 8 (2027-06-12).

**Key Outputs/Deliverables:**

- Staffing dry-run scenario and simulation protocol
- Readiness report documenting 7-day coverage by shift, function and site
- Identified staffing gaps or surge-capacity shortfalls
- Corrective actions (cross-site floaters, additional recruiting, shift-rotation adjustments) and timeline

**Dependencies:**

- Staffing model and functional units defined
- Personnel clearance processing substantially complete
- Operational procedures and intake protocols drafted

### 18. Conduct filter-adequacy blind pre-test by injecting ≥10 test substitutions in a controlled staging area and measuring detection rate and false-positive rate under the proposed redaction-gateway rules. Verify that ≥9 of 10 substitutions are detected without exposing redacted fields.

**Responsible Body/Role:** Independent testing director and filter-adequacy testers (both countries); supported by operations and evidence-integrity teams.

**Suggested Timeframe:** Month 8.5 (2027-06-27); pre-test completed and results published by Month 8.5 (2027-06-27).

**Key Outputs/Deliverables:**

- Filter-adequacy blind pre-test protocol and test-substitution design
- Detection rate and false-positive-rate results (target ≥9 of 10, i.e., ≥90%)
- Redaction-rule audit confirming no non-negotiable schema fields were stripped
- Halt-or-proceed recommendation: if <85% detected, exercises halted for filter renegotiation and re-test; if ≥85%, proceed to Phase One

**Dependencies:**

- Sealed challenge-scenario design and injection protocols finalized
- Redaction-gateway rules and schema published
- Staging area and inspector teams ready for pre-test injection
- Co-chairs prepared to halt Phase One if filter adequacy fails

### 19. Establish the Threshold Calibration and Verdict Panel with bilateral technical specialists. Pre-register all Go, Modify and Stop thresholds with documented validation source (proposed: detection ≥90% per event type for Go, identity confidence >95%, unverifiable ≤3%, parity variance ±10%). Mark unsupported figures as provisional and specify validation method.

**Responsible Body/Role:** Bilateral Threshold Calibration and Verdict Panel lead (bilateral); national threshold specialists (1 per country minimum).

**Suggested Timeframe:** Month 7.5 (2027-05-27) to Month 8.5 (2027-06-27 to 2027-06-27); pre-registered thresholds published by Month 8.5 (2027-06-27).

**Key Outputs/Deliverables:**

- Pre-registered threshold table: Go (detection ≥90%, identity >95%, unverifiable ≤3%, parity ±10%), Modify, Stop criteria
- Validation-method documentation for each figure (blind exercises, historical data, expert assessment)
- Provisional-figure labeling and TBD fields with planned validation by Month 1.5 (2026-11-27) exercises (estimate)
- Sealed independent-score templates for later bilateral comparison

**Dependencies:**

- KPI and success-criteria definitions finalized
- Challenge-exercise design and 70-scenario plan published
- Co-chairs authorized to freeze thresholds by Month 10.5 (2027-08-27)

### 20. Complete appropriations legislation and budgetary authorization in both countries. Allocate USD 2.5 billion per country across seven envelopes (ledger 1.25B, site 1B, personnel 750M, security 750M, testing 500M, legal 250M, contingency 500M). Establish matched-tranche release rules: four equal quarterly tranches of USD 625M per country with parity tolerance ±10% and contingency-draw thresholds (>USD 10M = co-chair sign-off, 75% drawn = principal escalation).

**Responsible Body/Role:** US Congress (appropriations committee) and China's National People's Congress or equivalent; national finance ministers and OMB/State Department (US) or Ministry of Finance (China).

**Suggested Timeframe:** Month 4 (2027-02-12) to Month 8 (2027-06-12 to 2027-06-12); appropriations enacted by Month 8 (2027-06-12).

**Key Outputs/Deliverables:**

- Enacted appropriations legislation (US and China) providing USD 2.5B authorization per country
- Budget-envelope allocation and spending caps by category
- Tranche schedule (Months 7, 10, 13, 16 = 2027-05-12, 2027-08-12, 2027-11-12, 2028-02-12)
- Parity-tolerance rule documentation (±10% cumulative, 15% monthly triggers review, 20% divergence triggers hold)
- Contingency sub-account reservation (USD 50M gate-readiness, USD 450M free contingency)

**Dependencies:**

- Total budget (USD 5B) and envelope allocation finalized
- Bilateral Steering Committee and co-chair governance framework published
- Spending-accountability and tranche-release procedures defined

### 21. Hire independent bilateral budget auditor (funded from USD 250M legal/audit envelope) to verify all tranche releases and provide monthly spending reports by envelope category. Establish auditor protocols for parity-divergence detection and tranche-hold triggers.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs; national finance leads; independent auditor selection committee.

**Suggested Timeframe:** Month 7 (2027-05-12) to Month 8 (2027-06-12 to 2027-06-12); independent auditor appointed and operational by Month 8.75 (2027-07-05).

**Key Outputs/Deliverables:**

- Independent bilateral budget auditor identified and hired
- Auditor charter documenting monthly reporting requirements, tranche-verification procedures and parity-divergence thresholds
- Monthly budget-burn dashboard template by envelope and country
- Tranche-release authorization procedures (auditor confirmation + co-chair double-key approval)

**Dependencies:**

- Appropriations enacted and budget authority confirmed
- Tranche schedule and parity rules published
- Co-chair governance framework established

### 22. Conduct comprehensive entry-condition certification at a single gate decision point by Month 9 (2027-07-12). Verify all seven mandatory conditions: (1) bilateral instrument signed, (2) appropriations enacted, (3) domestic access authority enacted, (4) participating sites selected and certified equivalent, (5) inspectors approved and cleared, (6) operators and vendors committed to participation, (7) provisional covered-equipment schedule adopted. Issue joint certification or defer Phase One if any condition is unmet.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs (formally convened for entry-gate decision); supported by project leads, legal working group and condition-tracking teams.

**Suggested Timeframe:** Month 9 (2027-07-12); single certification decision made by Month 9 (2027-07-12), Day 1.

**Key Outputs/Deliverables:**

- Entry-Condition Certification Report documenting status of all 7 conditions (Met / Not Met / Near-Ready with path)
- Joint certification decision: 'Entry Gate Certified - Phase One Clock Starts Month 9 (2027-07-12)' OR 'Gate Deferred - Remediation Timeline: [specific condition and target date]'
- If certified: Phase One baseline-collection schedule published (Days 1-5 reserved for opening-inventory seal)
- If deferred: revised gate re-evaluation date and contingency-sunk-cost tracking

**Dependencies:**

- All entry-condition status reports delivered by Month 9 (2027-07-12), Day 0
- Bilateral instrument signed
- Appropriations enacted
- Legal authority confirmed
- Sites selected and surveys complete
- Vendor binding agreements signed
- Personnel clearances complete
- Provisional schedule published

### 23. Establish the Project Management Office and Operational Execution Team structure, appointing a Program Director (accountable to co-chairs), US and China National Operations Directors, Site Operations Managers (one per declared site, ≥4 total), Evidence and Ledger Manager, and Inspector Deployment and Leave Coordinator. Confirm operational authorities and decision thresholds in writing.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs (newly confirmed and in formal session); supported by designated project leads.

**Suggested Timeframe:** Month 8 (2027-06-12) to Month 9 (2027-07-12 to 2027-07-12); full team confirmed and operational by Month 9 (2027-07-12) if entry gate is certified.

**Key Outputs/Deliverables:**

- Named Program Director (bilateral accountability, accountable to co-chairs for KPI delivery and schedule)
- Named US National Operations Director and China National Operations Director with bilateral-coordination authority
- Named Site Operations Managers for all 4 declared sites with escalation authorities
- Evidence and Ledger Manager and Inspector Deployment Coordinator confirmed
- Operational-authority charter documenting decision rights (personnel deployments <20% surge, evidence handling within schema, challenge logistics, incident response)

**Dependencies:**

- Entry gate certified
- Personnel clearance roster complete
- Operational procedures and site-level protocols drafted
- Co-chair governance framework and escalation rules published

### 24. Conduct bilateral co-chair formal inaugural meeting, confirming operational readiness, reviewing KPI targets and monthly decision cadence (1st of each month), publishing first-month operational briefing agenda, and authorizing Phase One clock start at Month 9 (2027-07-12).

**Responsible Body/Role:** Bilateral Steering Committee co-chairs (formally convened); all committee members and project leads present.

**Suggested Timeframe:** Month 9 (2027-07-12); inaugural meeting held on Day 1 of Phase One.

**Key Outputs/Deliverables:**

- Co-chair Inaugural Meeting Minutes documenting readiness confirmation, KPI targets published, monthly meeting schedule locked (1st of month), escalation procedures confirmed
- First-month briefing agenda (opening-inventory baseline, KPI monitoring, facility status, contingency budget, early challenge exercises)
- Co-chair joint authorization letter confirming Phase One operations are live and Budget Tranche 1 (USD 625M per country) is released

**Dependencies:**

- Entry gate certified and Phase One clock started
- All governance bodies and executive teams appointed and confirmed
- Operational procedures and monthly decision cadence documented

### 25. Establish the bilateral Counterintelligence and Compartmentation Oversight Unit, confirming CI Directors and specialist staff from both countries. Publish compartmentation rules (inspectors segregated by site and event type, no cross-site knowledge), tenure limits (6-month site tenure with 2-month breaks), and insider-threat red-cell protocols. Issue clearance-status confirmation for all Phase One personnel.

**Responsible Body/Role:** Bilateral Steering Committee; national CI directors (recruited and cleared Month 7 = 2027-05-12); supported by vetting and polygraph specialists.

**Suggested Timeframe:** Month 8 (2027-06-12) to Month 9 (2027-07-12 to 2027-07-12); CI protocols published and compartmentation rules enforced by Month 9 (2027-07-12), Day 1.

**Key Outputs/Deliverables:**

- Named CI Directors (one per country) with decision authorities documented
- Compartmentation Rules and Access-Control Matrix (inspectors segregated by site and event type, no individual cross-site knowledge)
- 6-month tenure limits and mandatory 2-month breaks between site assignments
- Insider-threat red-cell charter and monthly exercise schedule (three planned exercises at Months 9.75, 10.75, 11.75 = 2027-08-04, 2027-09-04, 2027-10-05)
- Personnel clearance-status roster (all Phase One staff confirmed cleared) with any denials and appeals resolved

**Dependencies:**

- Personnel vetting and polygraph processing complete
- Compartmentation and IP-protection boundaries defined
- Insider-threat red-team protocols and staffing approved

### 26. Formally establish the Bilateral Technical Referees Panel (2 technical experts per country, independent of inspectorate). Confirm members, publish technical-referee charter, establish sealed evidence-review facility, train referees on identity-verification layering and corroboration rules, and document escalation triggers (co-chair deadlock escalates to referees within 24 hours; referees must produce dual-signed fact statement within 3 days or escalate to principals).

**Responsible Body/Role:** Bilateral Steering Committee co-chairs; recruited technical-referee panel members (cleared, independent).

**Suggested Timeframe:** Month 8 (2027-06-12) to Month 9 (2027-07-12 to 2027-07-12); panel operational by Month 9 (2027-07-12), Day 1.

**Key Outputs/Deliverables:**

- Named Bilateral Technical Referees Panel members (2 from US, 2 from China) with independence certification and sealed facility access
- Technical-Referee Charter documenting authorities (dual-signed advisory statements), decision timers (3-day closure for fact statements), and escalation rules
- Training on identity-verification layering, corroboration analysis, evidence-schema validation and threshold-sufficiency assessment
- Sealed evidence-review facility operational and CI-protected

**Dependencies:**

- Technical-expert recruitment and clearance complete
- Identity-verification architecture and corroboration rules published
- Evidence-schema and threshold-sufficiency criteria defined

### 27. Formally establish the Evidence and Ledger Integrity Committee, confirming Ledger System Architect, US and China Ledger Node Operators, Evidence-Schema and Classification Specialists (≥1 per country), and Divergence Reconciliation Lead. Publish ledger operational procedures (hourly checkpoint validation, divergence detection within 4 hours, reconciliation closure within 24 hours, facility incidents logged within 1 hour) and KPI monitoring protocols.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs; recruited committee members (systems architects, node operators, cryptographers, cleared).

**Suggested Timeframe:** Month 8 (2027-06-12) to Month 9 (2027-07-12 to 2027-07-12); committee operational and ledger systems live by Month 9 (2027-07-12), Day 1.

**Key Outputs/Deliverables:**

- Named Evidence and Ledger Integrity Committee members with appointed roles and authorities
- Ledger Operational Procedures: hourly hash-chain checkpoint validation, signed checkpoint format, divergence-detection algorithms, reconciliation procedures
- KPI monitoring protocols (synchronization ≤1 hour, divergence detection ≤4 hours, reconciliation ≤24 hours, facility incidents ≤1 hour logging)
- Equipment-identity-confidence scoring methodology and escalation to unverifiable status when confidence falls below 95% (proposed threshold)
- Schedule-versioning and double-key update procedures for covered-equipment classification

**Dependencies:**

- Ledger system design and architecture finalized
- Cryptographic checkpoint format and transport security implemented
- Neutral-party custodian escrow agreement signed
- Ledger nodes deployed and synchronized for testing

### 28. Formally establish the Vendor and Operator Binding and Compliance Unit, confirming Vendor and Operator Liaison Director, national Binding and Compliance Leads, Accredited Examiner and Clean-Room Lead (per country) and Attestation-Key Validation Specialist. Confirm all vendor-binding agreements are signed and enforce compliance with verification duties. Certify clean-room examination centers operational.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs; recruited vendor-binding unit members (cleared, contracts specialists, technical examiners).

**Suggested Timeframe:** Month 8 (2027-06-12) to Month 9 (2027-07-12 to 2027-07-12); unit operational and all vendor binding confirmed by Month 9 (2027-07-12), Day 1.

**Key Outputs/Deliverables:**

- Named Vendor and Operator Liaison Director (bilateral accountability) with national leads
- Confirmed pre-qualified vendor registry roster (all critical vendors on registry with signed binding agreements)
- Supply-chain consequence policy enforcement (refusers denied supply-chain access or escalated to clean-room testing)
- Accredited clean-room examination centers (≥1 per country) certified operational and ready to accept refusing vendors' equipment
- Attestation-key validation result summary: all critical vendors' cryptographic keys validated by independent examiners or flagged for Month 10 (2027-08-12) unverifiable status

**Dependencies:**

- Vendor-binding agreements drafted and signed
- Clean-room facilities constructed and security-hardened
- Accredited-examiner vetting and protocols published

### 29. Formally establish the Threshold Calibration and Verdict Panel (bilateral lead, 1 specialist per country). Confirm members and freeze the pre-registered threshold table by bilateral signature. Establish sealed independent-score storage and comparison protocols. Train panel on evidence-sufficiency analysis and thresholds-to-verdict mapping.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs; recruited Threshold Calibration Panel members (technical specialists, cleared, independent).

**Suggested Timeframe:** Month 8 (2027-06-12) to Month 9 (2027-07-12 to 2027-07-12); panel operational and thresholds frozen (by Month 10.5 = 2027-08-27) with interim confirmation by Month 9 (2027-07-12).

**Key Outputs/Deliverables:**

- Named Threshold Calibration and Verdict Panel members with independence attestation
- Frozen threshold table (by Month 10.5, 2027-08-27) signed by bilateral members: Go criteria (detection ≥90%, identity >95%, unverifiable ≤3%, parity ±10%), Modify, Stop
- Sealed independent-score process: each national team scores evidence independently and sealed; scores compared at Month 11.75 (2027-10-05) with divergence magnitude reported
- Training documentation for evidence-sufficiency analysis and verdict-mapping rules

**Dependencies:**

- Pre-registered threshold table published and validated
- Challenge-exercise design finalized
- Early blind-exercise data available for calibration (if scheduled before freeze)

### 30. Formally establish the Independent Testing, Challenge Exercise and Red Team Unit, confirming Independent Testing Director (bilateral), US and China Red Team Leads, Detection-Measurement Analysts and Filter-Adequacy Testers. Publish sealed challenge-exercise catalog (hash-committed, 70 scenarios ≥10 per event type), exercise-injection timeline (calibration Months 9.5-10.5 = 2027-07-27 to 2027-08-27, scored Months 10.5-11.5 = 2027-08-27 to 2027-09-27), and CHALLENGE-tagging partition protocol confirming exercises cannot trigger suspension or KPI violations.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs; recruited testing unit members (cleared, scenario designers, red-team operational leads).

**Suggested Timeframe:** Month 8 (2027-06-12) to Month 9 (2027-07-12 to 2027-07-12); unit operational and sealed scenario catalog published by Month 9 (2027-07-12), Day 0 (before Phase One clock starts).

**Key Outputs/Deliverables:**

- Named Independent Testing Director (bilateral) and Red Team Leads (US and China) with operational authorities
- Hash-committed sealed challenge-scenario catalog (70 scenarios: ≥10 each for 7 event types), published and locked before Phase One
- Exercise-injection schedule: calibration exercises Months 9.5-10.5 (2027-07-27 to 2027-08-27), unscored; scored exercises Months 10.5-11.5 (2027-08-27 to 2027-09-27)
- CHALLENGE-tagging partition protocol: every injected scenario tagged CHALLENGE in the ledger before injection; tagged events excluded from triggering suspension, impaired-confidence review or KPI violations
- Misclassification escalation rule: if a CHALLENGE-tagged exercise is mistakenly flagged as operational and triggers suspension, automatic escalation to principals within 2 hours with reinstatement pending adjudication

**Dependencies:**

- Challenge-scenario design and hash-commitment complete
- Ledger CHALLENGE-tagging infrastructure and partition rules implemented
- Co-chairs authorized to exclude exercises from suspension triggers

### 31. Conduct opening-inventory baseline collection and sealing during Days 1-5 of Phase One (Month 9 = 2027-07-12). Deploy joint mirrored teams to each of the four declared sites to count and verify covered-equipment categories within declared zones (staging, spare-inventory, maintenance, expansion areas). Seal and sign the baseline ledger entry with bilateral co-chair confirmation. No challenge exercises or equipment movements during baseline Days 1-5.

**Responsible Body/Role:** Project Management Office and Operational Execution Team (Program Director, Site Operations Managers); mirrored inspection teams (US and China) at each site.

**Suggested Timeframe:** Month 9 (2027-07-12), Days 1-5 (2027-07-12 to 2027-07-17); baseline sealing completed and ledger entry signed by Month 9 (2027-07-12), Day 5.

**Key Outputs/Deliverables:**

- Opening-Inventory Baseline Count Report for each of 4 sites: equipment categories, serial numbers or identifiers, location within declared zones, cryptographic attestation digest, baseline sealed date/time
- Bilateral co-chair signature on baseline ledger entry
- Baseline-change reconciliation log (any discrepancies between observers resolved before seal)
- Confirmation that Days 1-5 baseline work did not trigger any challenge exercises or include equipment movements

**Dependencies:**

- Phase One clock started and entry gate certified
- Mirrored teams deployed and operational
- Covered-equipment schedule published
- Intake protocols and baseline-counting procedures finalized

### 32. Execute Monthly Decision and Oversight Cadence: co-chairs convene on the 1st of each month (Months 9, 10, 11, 12 = 2027-07-12, 2027-08-12, 2027-09-12, 2027-10-12) to review KPI dashboard, approve budget draws >USD 10M, authorize personnel assignments and surge staffing, evaluate escalated site findings, receive CI briefings and manage contingency allocation. All decisions and deadlocks recorded in the tamper-evident ledger.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs (formally convened); Project Management Office, Evidence and Ledger Integrity Committee, Counterintelligence Oversight Unit, Vendor and Operator Binding Unit provide briefing materials.

**Suggested Timeframe:** Monthly formal sessions: Months 9, 10, 11, 12 (2027-07-12, 2027-08-12, 2027-09-12, 2027-10-12); plus weekly informal reviews during Phase One.

**Key Outputs/Deliverables:**

- Monthly Co-Chair Decision Minutes documenting: KPI results (detection rates, identity confidence, parity variance, ledger sync, unresolved discrepancies), budget-burn status and tranche-release authorizations, approved personnel assignments and surge staffing, escalated site findings and deadlock resolutions, CI and facility security briefings, contingency allocation decisions
- Any budget draws approved with bilateral signature and ledger entry
- Escalation decisions and escalation timers started (5/8/13-day sequence for deadlocked disputes)
- Monthly KPI dashboard published with all metrics, thresholds and status

**Dependencies:**

- Bilateral Steering Committee governance framework and decision rules established
- KPI targets and monthly reporting protocols finalized
- Co-chair informal-review schedule (weekly) and emergency-escalation triggers defined

### 33. Execute Calibration Exercise Phase (Months 9.5-10.5 = 2027-07-27 to 2027-08-27): Independent Testing Unit injects unscored blind scenarios in staging, spare-inventory, maintenance and expansion areas to establish baseline detection rates and false-positive/negative rates under realistic filtering and inspector presence. No scoring against Go/Modify/Stop thresholds during calibration; results inform Threshold Calibration Panel's recommendation for threshold adjustments if empirical data diverges >10% from provisional assumptions.

**Responsible Body/Role:** Independent Testing Director and Red Team Leads; Detection-Measurement Analysts; mirrored inspectors at each site.

**Suggested Timeframe:** Months 9.5-10.5 (2027-07-27 to 2027-08-27); calibration-exercise summary published by Month 10.5 (2027-08-27).

**Key Outputs/Deliverables:**

- Calibration-Exercise Injection Log: scenario type, injection timing, site, whether detected by inspectors, false-positive incidents, detection latency
- Baseline detection rate and false-positive/negative rate by event type (7 types)
- Filter-adequacy assessment: evidence-schema field preservation under operator redaction, any schema fields stripped (escalation trigger)
- Threshold-calibration recommendation: if empirical detection rate diverges >10% from provisional assumption (e.g., 85% detected vs. 90% assumed), Threshold Calibration Panel recommends threshold adjustment

**Dependencies:**

- Sealed challenge-scenario catalog published and tagged CHALLENGE
- Mirrored inspectors trained on blind-exercise partition (exercises don't trigger suspension)
- Filter-adequacy pre-test complete and filters validated
- Detection-measurement protocols established

### 34. Freeze all Go, Modify and Stop thresholds by Month 10.5 (2027-08-27) following bilateral Threshold Calibration Panel review of early calibration-exercise data. Both national specialists must sign off on final thresholds; disagreement escalates to co-chairs for decision. Thresholds cannot be changed after freeze except by bilateral co-chair amendment, which is recorded in the ledger.

**Responsible Body/Role:** Bilateral Threshold Calibration and Verdict Panel members; Bilateral Steering Committee co-chairs if disagreement.

**Suggested Timeframe:** Month 10.5 (2027-08-27); threshold-freeze meeting convened and decision published by Month 10.5 (2027-08-27), Day 15.

**Key Outputs/Deliverables:**

- Frozen Threshold Table: final Go criteria (detection ≥X%, identity confidence >X%, unverifiable ≤X%, parity variance ±X%), Modify and Stop criteria, signed by bilateral panel members
- Threshold-adjustment documentation: calibration-exercise findings, any divergence from provisional assumptions, recommended adjustments, reason for each adjustment
- If disagreement: disputed threshold(s) escalated to co-chairs with both panel members' recommendations; co-chair decision published and recorded in ledger
- Confirmation: thresholds are now frozen and cannot be changed except by bilateral amendment (recorded in ledger)

**Dependencies:**

- Calibration-exercise data available and summarized
- Threshold Calibration Panel review completed
- Co-chairs prepared to resolve any disagreement on freeze decision

### 35. Execute Scored Exercise Phase (Months 10.5-11.5 = 2027-08-27 to 2027-09-27): Independent Testing Unit injects sealed blind scenarios from the hash-committed catalog in staging, spare-inventory, maintenance and expansion areas. Each national team's Detection-Measurement Analyst independently and sealed scores whether each scenario was detected. Results are recorded in the ledger with CHALLENGE tags and tracked by event type, false-positive/negative rate.

**Responsible Body/Role:** Independent Testing Director and Red Team Leads; Detection-Measurement Analysts (per country, independent scoring); mirrored inspectors at each site.

**Suggested Timeframe:** Months 10.5-11.5 (2027-08-27 to 2027-09-27); scored-exercise summary and sealed-score data delivered to Threshold Calibration Panel by Month 11.75 (2027-10-05).

**Key Outputs/Deliverables:**

- Scored Exercise Injection Log: scenario type, injection date, site, detection outcome (detected/missed by inspectors), false-positive incidents, detection latency
- Sealed independent-score sheets from US and China teams: detection results by event type, summarized detection rate per event type and overall (proposed target ≥90%)
- Event-type-specific false-positive/negative rate
- Filter-adequacy assessment during scored exercises: evidence-schema field preservation, any schema stripping (escalation)
- Summary statistics ready for sealed-score comparison at Month 11.75 (2027-10-05)

**Dependencies:**

- Thresholds frozen by Month 10.5 (2027-08-27)
- Sealed challenge-scenario catalog locked and tagged CHALLENGE
- Mirrored inspectors trained on partition and scoring rules
- Ledger CHALLENGE-tagging infrastructure operational

### 36. Conduct sealed independent-score comparison at Month 11.75 (2027-10-05): Threshold Calibration Panel compares US and China's sealed detection scores by event type and overall. Measure scoring divergence; divergence >10 percentage points is documented but both scores are treated as valid assessments. Prepare joint evidence-mapping analysis showing how detection results and other KPI metrics (identity confidence, parity variance, unverifiable count, ledger sync) map to Go, Modify, Stop verdict criteria.

**Responsible Body/Role:** Bilateral Threshold Calibration and Verdict Panel members; Detection-Measurement Analysts from each country (sealed scores unsealed only at comparison meeting).

**Suggested Timeframe:** Month 11.75 (2027-10-05); sealed-score comparison meeting and verdict-evidence analysis completed by Month 11.75 (2027-10-05), Day 15.

**Key Outputs/Deliverables:**

- Sealed-Score Comparison Report: US team detection rate by event type vs. China team detection rate, overall divergence magnitude, assessment of causes (filter differences, inspector training, site differences)
- Joint Evidence-Mapping Analysis: how all KPI metrics (detection ≥90%, identity >95%, unverifiable ≤3%, parity ±10%, ledger sync ≤1 hour, no unresolved discrepancies >15 days) align with Go (all green), Modify (some correctable) and Stop (any red) verdicts
- Sealed-Score Comparison Minutes documenting any disagreement and both national assessments
- Preliminary verdict recommendation for co-chairs: 'Evidence Supports Go / Modify / Stop Criteria'

**Dependencies:**

- Scored exercises complete and sealed scores delivered
- Thresholds frozen and final KPI values established
- All Phase One operational data (KPIs, escalations, incidents) collected and verified

### 37. Hold the final co-chair Bilateral Steering Committee session at Month 12 (2027-10-12) to receive the Threshold Calibration Panel's evidence-mapping analysis and sealed-score comparison. Review all operational KPI results, any outstanding escalations or unresolved discrepancies, and facility security briefing. Co-chairs jointly decide Go, Modify or Stop verdict based on evidence presented.

**Responsible Body/Role:** Bilateral Steering Committee co-chairs (formally convened); Threshold Calibration Panel, Project Management Office, Evidence and Ledger Integrity Committee, Counterintelligence Oversight Unit provide briefing materials.

**Suggested Timeframe:** Month 12 (2027-10-12); co-chair verdict decision convened and published by Month 12.25 (2027-10-20).

**Key Outputs/Deliverables:**

- Final Co-Chair Verdict Minutes documenting: Threshold Calibration Panel evidence-mapping analysis, sealed-score comparison (divergence magnitude reported), all Phase One KPI results (detection, identity confidence, parity variance, ledger sync, unresolved discrepancies), outstanding escalations (if any) and their status, CI and facility-security briefing summary
- Bilateral co-chair Go / Modify / Stop Verdict Decision, jointly signed by both co-chairs
- Verdict Justification Document: evidence supporting the decision, with reference to frozen thresholds and sealed-score data
- Verdict Publication and Post-Phase-One Recommendation (if applicable): Go → proceed to Phase Two or continuation negotiations; Modify → identify corrective actions and re-test timeline; Stop → documented reasons for termination

**Dependencies:**

- Sealed-score comparison complete by Month 11.75 (2027-10-05)
- All Phase One operations and data collection complete
- Outstanding escalations resolved or documented as unresolved
- Co-chairs authorized to issue binding verdict

### 38. Publish final Phase One Operational Report and KPI Dashboard summarizing 90-day test results: detection rates by event type, identity-confidence metrics, parity variance, ledger synchronization performance, unverifiable-equipment counts, unresolved-discrepancy age, vendor-refusal outcomes, IP/cybersecurity incidents, budget burn and contingency spend, and audit exceptions. Mark all unsupported or provisional figures as such. Conclude Go, Modify or Stop and state that success covers only monitored changes at participating declared sites.

**Responsible Body/Role:** Project Management Office and Operational Execution Team (Program Director); supported by all governance committees (Evidence and Ledger, Counterintelligence, Threshold Calibration, Independent Testing, Vendor and Operator Binding).

**Suggested Timeframe:** Month 12.25 (2027-10-20); final report published within 10 days of co-chair verdict decision.

**Key Outputs/Deliverables:**

- Phase One Operational Report: KPI dashboard with all metrics (detection rates, identity confidence, parity variance, ledger sync, discrepancy age, vendor refusals, unverifiable equipment, cybersecurity incidents, funding timeliness)
- Sealed-score comparison summary and voting divergence (if any)
- Vendor-refusal outcomes and clean-room testing results
- Exit-disposition evidence ladder results (witnessed destruction, permanent disablement, transfers, releases beyond boundary, unresolved)
- Contingency-spend accounting and parity-divergence summary
- CI briefing summary and facilities security incident log
- Conclusion: Go (reciprocal access and credible detection demonstrated) / Modify (correctable weaknesses identified) / Stop (asymmetric access, unverifiable equipment, shielded operator, diverged ledger, withheld funding) with explicit statement that success covers only monitored changes at participating declared sites

**Dependencies:**

- Co-chair verdict decision published
- All Phase One data collection and KPI calculation complete
- Audit exception log from independent auditor delivered
- All governance committees' final briefing materials consolidated