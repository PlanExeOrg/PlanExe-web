### 1. Bilateral Executive Steering Committee (BESC)

**Rationale for Inclusion:** The Consortium is a high-stakes, dual-sovereignty US–China national-security program requiring equal, non-hierarchical strategic oversight. The BESC serves as the top-level governance body ensuring mutual accountability, reciprocity and double-key decision authority. It addresses the plan's core tension: both countries must retain veto power on strategic decisions (budgets, protocol changes, site findings, suspension) while avoiding deadlock paralysis. No single country can override the other; no casting vote is permitted.

**Responsibilities:**

- Approve all double-key strategic decisions: budget tranches >USD 25M, protocol changes, site-level findings, suspension or impaired-confidence triggers, and Go/Modify/Stop thresholds
- Resolve deadlock on decision-critical items within the escalation clock; escalate unresolved items >7 days to a neutral referee panel after 48 hours of co-chair negotiation
- Certify all mandatory entry conditions (bilateral instrument, appropriations, domestic authority, site selection, inspector vetting, operator/vendor binding, equipment schedule) by Month 6 (2027-04-08)
- Monitor entry-condition milestones weekly and escalate any condition lagging >4 weeks behind plan to political leadership
- Quarterly review of KPI dashboard, ledger integrity, inspector conduct, and reciprocal-access parity; monthly sign-off on tranche spending and variance flagging
- Authorize contingency-budget release: fast-lane decisions up to USD 50M (USD 25M per side) within 5 business days; larger contingency draws require extended co-chair consensus

**Initial Setup Actions:**

- Ratify the bilateral instrument and nominate equal national co-chairs by Month 0.5 (2026-10-23)
- Establish weekly steering-committee meeting schedule and decision-recording protocols, starting Month 0.5 (2026-10-23)
- Define written escalation and deadlock-resolution procedures, including neutral referee-panel selection and co-chair decision rights during Phase One
- Decompose domestic authority requirements per country and assign entry-condition owners with explicit milestones
- Pre-authorize the joint forensic panel, independent testing unit, and bilateral conduct-review panel leadership
- Lock the bilateral instrument governance terms: double-key requirement, no casting vote, veto scope, and suspension/escalation thresholds

**Membership:**

- US National Co-Chair (Cabinet-level or senior executive)
- Chinese National Co-Chair (equivalent State Council or Communist Party level)
- US Deputy: Head of US National Operations Unit or designated co-chair proxy
- Chinese Deputy: equivalent Head of National Operations Unit or proxy
- Observer: Neutral third-party facilitator (optional, non-voting; may be drawn from IAEA, OSCE or agreed neutral state)

**Decision Rights:** Unrestricted authority to approve or reject any strategic decision affecting Phase One scope, schedule, budget or outcome. Double-key required for: budgets >USD 25M, protocol changes, site findings, suspension/impaired-confidence status, threshold adjustments, entry-condition certification. Neither co-chair may unilaterally suspend a site; unilateral action by one co-chair invalidates the decision unless reversed within 24 hours by joint agreement. Escalation of unresolved disputes to a neutral referee panel after 7 days of disagreement is mandatory.

**Decision Mechanism:** Unanimous consent required for all double-key decisions; no voting, majority override, or casting vote. If consensus cannot be reached within 7 days on a decision-critical item, the matter escalates automatically to a neutral independent referee panel (3–5 senior officials, not from either country) who provides a non-binding written opinion within 5 days. Each co-chair retains veto authority; if both reject the panel's opinion, the item remains unresolved and escalates to political leadership via an agreed crisis-management protocol. No decision is final until both co-chairs sign and both national ledger copies record it.

**Meeting Cadence:** Weekly steering-committee meeting (minimum 1.5 hours) dedicated to entry-condition tracking, budget authorization, escalation review and consensus building, Months 0–6 (2026-10-08 to 2027-04-08). During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08), bi-weekly meetings for KPI review, incident escalation and contingency decisions. Post-Phase-One, monthly meetings for final-decision preparation.

**Typical Agenda Items:**

- Entry-condition milestone tracking and blocker escalation (weekly Months 0–6 = 2026-10-08 to 2027-04-08)
- Budget-tranche authorization, spending variance >5% flagging, and contingency-release decisions
- Ledger divergence and forensic-panel findings escalation; deadlock resolution
- Inspector-conduct incident review, Tier 2 and Tier 3 violations, and rotation compliance
- KPI dashboard review: detection rates, false positives/negatives, equipment-identity confidence, unverifiable count, vendor-refusal outcomes
- Protocol-change proposals and double-key amendment sign-off
- Reciprocal-access parity metrics and asymmetry allegations
- Final decision preparation: Go/Modify/Stop threshold validation, evidence quality review

**Escalation Path:** Deadlock unresolved after 7 days escalates to an independent neutral referee panel (3–5 senior officials from pre-agreed third countries or international organizations, jointly selected by co-chairs at Month 0.5 = 2026-10-23). Referee panel issues a non-binding opinion within 5 days. If co-chairs reject the opinion or remain deadlocked after the panel's opinion, the issue escalates to political leadership (ministers or equivalent) for crisis resolution. Automatic suspension of the affected site or event class triggers if deadlock persists >14 days on a contested equipment-identity or site-status matter, unless both co-chairs jointly authorize an extension.
### 2. Joint Forensic and Evidence Adjudication Panel

**Rationale for Inclusion:** Equipment-identity disputes and ledger divergence are at the core of Phase One risk. The plan requires that no single evidence source is decisive; corroboration across multiple layers is mandatory. When national teams disagree on whether evidence is sufficient (e.g., attestation vs. physical inspection vs. records), an independent internal adjudication mechanism is essential. The JFEAP resolves contested identities and divergences within 48 hours, preventing disputes from escalating to co-chairs and consuming deadlock time. This panel is neutral to both countries but internal to the program, ensuring fast binding or co-chair-delegated resolution.

**Responsibilities:**

- Review all contested equipment-identity findings within 48 hours of a discrepancy escalation or ledger divergence that involves identity uncertainty
- Apply the fixed, pre-agreed corroboration rule (physical inspection + identifier match + validated attestation where available; if attestation unavailable, physical inspection + 2 independent records) to disputed identities
- Determine whether evidence meets the corroboration threshold; if not, mark the item unverifiable or escalate to co-chairs with detailed justification
- Document all forensic findings in the ledger with full provenance: which layers agreed, which diverged, reasoning for acceptance/rejection of each layer
- Resolve equipment-identity disputes arising from ledger divergence between national copies; issue a binding finding on which copy's record is supported by evidence
- Adjudicate vendor-refusal escalations: determine whether fallback evidence (independent examiner, clean-room, validated attestation) is sufficient to confirm identity or justify unverifiable classification
- Track discrepancy-clock timers and escalate items that exceed Tier 1 (24h) and Tier 2 (72h) deadlines; provide technical opinion on whether additional fact-finding can close the item before Tier 3 (14d) expiry

**Initial Setup Actions:**

- Jointly select panel members (3–5 per country, equal membership, total 6–10 specialists) with expertise in hardware identity, cryptographic attestation, forensic analysis and supply-chain security, nominated by Month 1 (2026-11-08)
- Establish and document the fixed corroboration rule, signed by both co-chairs and published in the bilateral instrument by Month 2 (2026-12-08)
- Conduct a pre-test identity-verification exercise on non-covered equipment (Month 1.5 = 2026-11-23) to validate the panel's forensic procedures and corroboration application
- Define escalation protocols: minor disputes (equipment ID off by serial-number digit) resolved within 24 hours; major disputes (attestation vs. physical inspection conflict) escalated to co-chairs by hour 36
- Establish a secure shared evidence repository (ledger-integrated) where all contested identity claims, evidence layers and forensic findings are recorded with timestamps
- Create a dispute-resolution SOP specifying when the panel can issue binding findings vs. when consensus is required; clarify when disputes default to co-chair decision

**Membership:**

- Panel Chair: Senior neutral technical specialist (e.g., from an international cryptography or hardware-assurance body, agreed by both co-chairs)
- US Hardware Identity Specialist (3–5 FTE, including physical-inspection expert, attestation analyst, supply-chain forensics expert)
- Chinese Hardware Identity Specialist (3–5 FTE, equivalent expertise)
- Joint Ledger Forensics Officer (1–2 FTE, shared custody, responsible for data integrity and timestamp validation)
- Legal Advisor (1 FTE per country, binding advisor for disputed interpretations of corroboration rule)

**Decision Rights:** Authority to issue binding findings on equipment identity when evidence is unambiguous (both national teams agree on layer analysis, or the corroboration rule is clearly satisfied or violated). Authority to mark equipment unverifiable and justify the classification. Authority to escalate disputed findings to co-chairs with a detailed technical opinion if consensus cannot be reached within 36 hours. No authority to override the corroboration rule itself; rule changes require co-chair double-key amendment and ledger recording.

**Decision Mechanism:** Consensus within the panel (both country representatives must agree on findings) for binding decisions. If one country's panel members believe the corroboration rule is not met but the other disagree, the matter escalates to co-chairs as a contested finding, with the panel's technical opinion provided as non-binding input. Disputes are resolved by documented discussion and evidence review; if consensus fails after 36 hours, the panel issues a split or majority opinion, flags it as contested in the ledger, and refers the final call to co-chairs within 48 hours.

**Meeting Cadence:** On-demand activation for each contested identity or divergence escalation; target response time is 48 hours from escalation notification. Pre-test phase (Month 1.5 = 2026-11-23): weekly dry-run meetings to validate procedures. During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08): estimated 1–2 panels convened per week per site (4–8 across 4 sites) based on discrepancy rate; surge readiness for simultaneous multi-site disputes.

**Typical Agenda Items:**

- Equipment-identity evidence review: layer-by-layer analysis of attestation, physical inspection, customs records, identifiers, maintenance logs, infrastructure changes, witnessed movement
- Corroboration-rule application: does evidence meet minimum threshold? If not, justify unverifiable classification
- Ledger divergence forensics: which national copy's identity record is supported by evidence?
- Vendor-refusal escalation: is fallback evidence (independent examiner, clean-room, validated attestation) sufficient to confirm or deny identity?
- Discrepancy-clock escalation: is additional fact-finding likely to resolve the identity before the clock expires?
- Disputed findings escalation: prepare contested findings and technical opinions for co-chair review

**Escalation Path:** Unresolved contested identity disputes after 48 hours of panel review escalate to co-chairs for double-key decision within 24 hours. If co-chairs cannot agree within the escalation clock deadline (Tier 2 = 72 hours from initial discrepancy), the item is automatically marked as impaired-confidence status and the site enters escalation protocol. If consensus remains impossible at the 7-day ledger-divergence threshold, automatic suspension of the affected event or equipment class is triggered unless both co-chairs jointly authorize a further extension (documented in the ledger).
### 3. US National Operations Unit (USNOU)

**Rationale for Inclusion:** The Consortium requires full-time mirrored national inspection and operational teams at each participating site, with 24/7 shift coverage, separation of duties, and continuous evidence preservation. The USNOU is the US government's operational arm, responsible for deploying and managing US inspectors, coordinating with US participating sites, managing the US half of the replicated ledger, conducting US-side inspector vetting and conduct oversight, and ensuring compliance with US security and information-handling regulations. It mirrors the Chinese National Operations Unit in all operational functions, enabling reciprocal access and mutual accountability.

**Responsibilities:**

- Deploy and manage ~144 full-time US-side inspectors across 2 US participating sites with 24/7 shift coverage: day, evening and night shifts, plus leave buffer (~20%) and surge reserve (~10–15%)
- Conduct US-side counterintelligence vetting of all inspectors and support personnel to approval standard (Month 5 = 2027-03-08 entry condition); maintain vetting roster with clearance status, rotation schedule and rapid-replacement pool
- Manage the US copy of the replicated tamper-evident ledger: record all equipment arrivals, maintenance, third-party access, departures and inspector observations in real time; synchronize with Chinese copy at <1-hour bounded target; detect and escalate sync divergences within 2 hours
- Conduct US-side inspector conduct audit: monthly access-log review, zone-boundary compliance verification, device-access tracking, and three-tier infraction investigation (Tier 1 warnings, Tier 2 escalation, Tier 3 removal)
- Coordinate with US operators and vendors at participating sites: ensure binding agreements are in place (Month 4 = 2027-02-08), maintain liaison for maintenance scheduling, third-party access notification, and evidence preservation requirements
- Execute intake and exit protocols: verify equipment identity at arrival (staging) using layered evidence (attestation, physical inspection, customs, identifiers); assign exit dispositions (witnessed destruction, disablement, transfer, release or unresolved)
- Support independent testing unit: provide site access, facilitate challenge exercises in staging/spare/maintenance areas, ensure zero interruption of active computation, and record exercise outcomes in the US ledger copy
- Manage US contingency and surge capacity: maintain a rapid-call duty team for emergency maintenance responses, exercise escalations, and personnel replacement; coordinate surge activation with co-chairs

**Initial Setup Actions:**

- Nominate the US Deputy National Co-Chair and confirm USNOU operational leadership (Director, Deputy Director, Chief of Inspections, Chief of Ledger Operations) by Month 0.5 (2026-10-23)
- Identify and vet candidate US inspectors (144 FTE baseline, plus 20–30% surge pool = ~180–185 candidates) starting Month 0.5 (2026-10-23); coordinate with FBI, NSA and other security agencies for expedited counterintelligence clearances (14–16 week target)
- Establish incident-response and rapid-replacement protocols; pre-identify backup inspectors for every critical post
- Design the US-side ledger infrastructure: secure facility for ledger operations, cryptographic signing and key management, redundant secure communications links to China, offline backup and failover procedures; complete operational and stress-tested by Month 4 (2027-02-08)
- Pre-negotiate binding agreements with US operators and the top 5–8 equipment vendors per site, specifying attestation sharing, maintenance reporting, third-party escort and evidence preservation; sign by Month 1 (2026-11-08)
- Pre-stage independent examiner pool and clean-room facilities for vendor-refusal fallback routes; sign access agreements by Month 4 (2027-02-08)

**Membership:**

- US Deputy National Co-Chair (Cabinet-level designate or senior executive reporting to co-chair)
- Director of US National Operations Unit (~1 FTE, strategic operations leadership)
- Chief of Inspections (1 FTE, manages 144 inspectors, rosters, shift scheduling, leave and surge)
- Chief of Ledger Operations (1 FTE, US copy integrity, sync, forensics, offline backup and failover)
- US Inspector Vetting Officer (1 FTE, counterintelligence coordination, clearance status tracking, rapid replacement)
- Head of Operator Engagement (1 FTE, liaison with 2 US sites, vendor coordination, binding-agreement administration)
- Chief of Evidence Handling and Exit Protocol (1 FTE, intake/exit operations, disposition verification, chain of custody)
- 144 Full-Time US-Side Inspectors (36 per site, distributed across 3 shifts + leave/surge reserve)
- Support Staff (20–25 FTE, including ledger technicians, evidence handlers, analysts, training coordinators, logistics)

**Decision Rights:** Authority to deploy inspectors, manage shift rosters, approve leave and surge activations within the approved budget and staffing plan. Authority to escalate inspector-conduct Tier 2 or Tier 3 incidents to the bilateral conduct-review panel. Authority to recommend equipment-identity escalations to the Joint Forensic Panel. Authority to notify the Bilateral Executive Steering Committee of operational risks (understaffing, facility issues, vendor refusals) within 24 hours. No authority to override corroboration rules, site findings, or protocol changes; all such decisions are escalated to BESC or delegated panel authority.

**Decision Mechanism:** US Deputy Co-Chair and USNOU leadership make operational decisions by consensus or, if expedited (e.g., emergency inspector replacement), by the Director with next-business-day notification to the Deputy. Escalations to bilateral bodies (BESC, Joint Forensic Panel, bilateral conduct panel) follow written protocols specifying notification timelines and required documentation (evidence, findings, recommended action).

**Meeting Cadence:** Weekly USNOU leadership meeting for operational status, schedule/budget review, and escalation readiness (1 hour). Daily shift-handover briefing between outgoing and incoming shift leaders (30 minutes per site, 2 sites = 1 hour combined). Monthly US–China bilateral operations coordination call between USNOU and Chinese National Operations Unit directors for ledger sync status, protocol compliance, personnel matters and reciprocal-access parity review. Ad-hoc incident response meetings convened on Tier 2 conduct incidents, forensic escalations, or equipment-identity disputes.

**Typical Agenda Items:**

- Personnel status: vetting progress, clearance approvals, roster fill rate, leave scheduling, surge-reserve activation
- Ledger operations: sync status with Chinese copy, divergence events and resolution, offline backup testing, cryptographic key management
- Intake and exit: equipment-identity verification results, disposition assignments, vendor refusal escalations, unverifiable-equipment count
- Inspector conduct: monthly audit results, zone-boundary compliance, device-access review, Tier 1 warnings, escalation of Tier 2/3 incidents
- Operator engagement: vendor-agreement compliance, maintenance notification, third-party access scheduling, binding-agreement updates
- Exercise coordination: scheduling confirmation with independent testing unit, site access arrangements, exercise-security briefings, production-impact mitigation
- Budget and contingency: monthly spending against envelope, variance flagging, contingency-release requests

**Escalation Path:** Operational issues (understaffing, facility outages, vendor refusal) escalate to the US Deputy Co-Chair and the Bilateral Executive Steering Committee within 24 hours. Inspector-conduct Tier 2 and Tier 3 incidents escalate to the bilateral conduct-review panel within 12 hours. Equipment-identity disputes escalate to the Joint Forensic Panel within 6 hours of initial disagreement. Ledger divergence >4 hours unresolved escalates to ledger-operations escalation team (US and Chinese directors) within 30 minutes. Critical escalations (e.g., facility compromise, major vendor refusal cascading to multiple items, consent-withdrawal threat) escalate to BESC within 2 hours.
### 4. Chinese National Operations Unit (CNOU)

**Rationale for Inclusion:** Mirror to the US National Operations Unit, the CNOU is the Chinese government's operational arm. The bilateral mechanism requires full parity in operational capability, inspector deployment, ledger management and evidence handling. The CNOU ensures that Chinese government authority is exercised over Chinese operators, vendors and personnel; that domestic access authority is enforced; that vendor cooperation is secured; and that the Chinese national ledger copy is maintained with identical integrity and synchronization discipline as the US copy. Equal representation in all operational decisions (inspectors, ledger, evidence, facilities) reinforces mutual trust and reciprocal access.

**Responsibilities:**

- Deploy and manage ~144 full-time Chinese-side inspectors across 2 Chinese participating sites with 24/7 shift coverage: day, evening and night shifts, plus leave buffer (~20%) and surge reserve (~10–15%)
- Conduct Chinese-side counterintelligence vetting of all inspectors and support personnel to approval standard (Month 5 = 2027-03-08 entry condition); maintain vetting roster with clearance status, rotation schedule and rapid-replacement pool
- Manage the Chinese copy of the replicated tamper-evident ledger: record all equipment arrivals, maintenance, third-party access, departures and inspector observations in real time; synchronize with US copy at <1-hour bounded target; detect and escalate sync divergences within 2 hours
- Conduct Chinese-side inspector conduct audit: monthly access-log review, zone-boundary compliance verification, device-access tracking, and three-tier infraction investigation (Tier 1 warnings, Tier 2 escalation, Tier 3 removal)
- Coordinate with Chinese operators and vendors at participating sites: ensure binding agreements are in place (Month 4 = 2027-02-08), maintain liaison for maintenance scheduling, third-party access notification, and evidence preservation requirements
- Execute intake and exit protocols: verify equipment identity at arrival (staging) using layered evidence (attestation, physical inspection, customs, identifiers); assign exit dispositions (witnessed destruction, disablement, transfer, release or unresolved)
- Support independent testing unit: provide site access, facilitate challenge exercises in staging/spare/maintenance areas, ensure zero interruption of active computation, and record exercise outcomes in the Chinese ledger copy
- Manage Chinese contingency and surge capacity: maintain a rapid-call duty team for emergency maintenance responses, exercise escalations, and personnel replacement; coordinate surge activation with co-chairs

**Initial Setup Actions:**

- Nominate the Chinese Deputy National Co-Chair and confirm CNOU operational leadership (Director, Deputy Director, Chief of Inspections, Chief of Ledger Operations) by Month 0.5 (2026-10-23)
- Identify and vet candidate Chinese inspectors (144 FTE baseline, plus 20–30% surge pool = ~180–185 candidates) starting Month 0.5 (2026-10-23); coordinate with Ministry of State Security, Ministry of National Defense and other security organs for expedited counterintelligence clearances (14–16 week target)
- Establish incident-response and rapid-replacement protocols; pre-identify backup inspectors for every critical post
- Design the Chinese-side ledger infrastructure: secure facility for ledger operations, cryptographic signing and key management, redundant secure communications links to the US, offline backup and failover procedures; complete operational and stress-tested by Month 4 (2027-02-08)
- Pre-negotiate binding agreements with Chinese operators and the top 5–8 equipment vendors per site, specifying attestation sharing, maintenance reporting, third-party escort and evidence preservation; sign by Month 1 (2026-11-08)
- Pre-stage independent examiner pool and clean-room facilities for vendor-refusal fallback routes; sign access agreements by Month 4 (2027-02-08)

**Membership:**

- Chinese Deputy National Co-Chair (State Council or Communist Party designate, equivalent level reporting to co-chair)
- Director of Chinese National Operations Unit (~1 FTE, strategic operations leadership)
- Chief of Inspections (1 FTE, manages 144 inspectors, rosters, shift scheduling, leave and surge)
- Chief of Ledger Operations (1 FTE, Chinese copy integrity, sync, forensics, offline backup and failover)
- Chinese Inspector Vetting Officer (1 FTE, counterintelligence coordination, clearance status tracking, rapid replacement)
- Head of Operator Engagement (1 FTE, liaison with 2 Chinese sites, vendor coordination, binding-agreement administration)
- Chief of Evidence Handling and Exit Protocol (1 FTE, intake/exit operations, disposition verification, chain of custody)
- 144 Full-Time Chinese-Side Inspectors (36 per site, distributed across 3 shifts + leave/surge reserve)
- Support Staff (20–25 FTE, including ledger technicians, evidence handlers, analysts, training coordinators, logistics)

**Decision Rights:** Authority to deploy inspectors, manage shift rosters, approve leave and surge activations within the approved budget and staffing plan. Authority to escalate inspector-conduct Tier 2 or Tier 3 incidents to the bilateral conduct-review panel. Authority to recommend equipment-identity escalations to the Joint Forensic Panel. Authority to notify the Bilateral Executive Steering Committee of operational risks (understaffing, facility issues, vendor refusals) within 24 hours. No authority to override corroboration rules, site findings, or protocol changes; all such decisions are escalated to BESC or delegated panel authority.

**Decision Mechanism:** Chinese Deputy Co-Chair and CNOU leadership make operational decisions by consensus or, if expedited (e.g., emergency inspector replacement), by the Director with next-business-day notification to the Deputy. Escalations to bilateral bodies (BESC, Joint Forensic Panel, bilateral conduct panel) follow written protocols specifying notification timelines and required documentation (evidence, findings, recommended action).

**Meeting Cadence:** Weekly CNOU leadership meeting for operational status, schedule/budget review, and escalation readiness (1 hour). Daily shift-handover briefing between outgoing and incoming shift leaders (30 minutes per site, 2 sites = 1 hour combined). Monthly US–China bilateral operations coordination call between CNOU and US National Operations Unit directors for ledger sync status, protocol compliance, personnel matters and reciprocal-access parity review. Ad-hoc incident response meetings convened on Tier 2 conduct incidents, forensic escalations, or equipment-identity disputes.

**Typical Agenda Items:**

- Personnel status: vetting progress, clearance approvals, roster fill rate, leave scheduling, surge-reserve activation
- Ledger operations: sync status with US copy, divergence events and resolution, offline backup testing, cryptographic key management
- Intake and exit: equipment-identity verification results, disposition assignments, vendor refusal escalations, unverifiable-equipment count
- Inspector conduct: monthly audit results, zone-boundary compliance, device-access review, Tier 1 warnings, escalation of Tier 2/3 incidents
- Operator engagement: vendor-agreement compliance, maintenance notification, third-party access scheduling, binding-agreement updates
- Exercise coordination: scheduling confirmation with independent testing unit, site access arrangements, exercise-security briefings, production-impact mitigation
- Budget and contingency: monthly spending against envelope, variance flagging, contingency-release requests

**Escalation Path:** Operational issues (understaffing, facility outages, vendor refusal) escalate to the Chinese Deputy Co-Chair and the Bilateral Executive Steering Committee within 24 hours. Inspector-conduct Tier 2 and Tier 3 incidents escalate to the bilateral conduct-review panel within 12 hours. Equipment-identity disputes escalate to the Joint Forensic Panel within 6 hours of initial disagreement. Ledger divergence >4 hours unresolved escalates to ledger-operations escalation team (Chinese and US directors) within 30 minutes. Critical escalations (e.g., facility compromise, major vendor refusal cascading to multiple items, consent-withdrawal threat) escalate to BESC within 2 hours.
### 5. Independent Testing Unit (ITU)

**Rationale for Inclusion:** The credibility of the final Go/Modify/Stop decision rests entirely on the blind-challenge detection evidence. The plan requires challenge exercises to test whether inspectors can detect unreported arrivals, substituted equipment, record falsification, vendor refusal, delayed access and reluctant operators. An independent testing unit (not staffed by either national government, or staffed by both equally but controlled by neither unilaterally) is essential to prevent either country from gaming the exercises. The ITU designs scenarios on a sealed double-key schedule, runs exercises blind to inspectors, scores results objectively, and provides the detection data that feeds threshold calibration and the final verdict.

**Responsibilities:**

- Design challenge-exercise scenarios covering all 7 event types (unreported arrival, substituted equipment, record falsification, delayed access, disputed identity, vendor refusal, reluctant operator) with realistic complexity and adversarial credibility
- Maintain a sealed double-key exercise schedule: timing, sequence, venue, scenario details known only to a small group at each site; release schedule elements only as exercises occur, preventing advance preparation
- Coordinate with US National Operations Unit and Chinese National Operations Unit for site access, staging area reservation, and exercise logistics; ensure zero disruption to active computation
- Conduct exercises and record inspector response: detection time, evidence gathering, escalation behavior, interaction with operators and vendors
- Score detection outcomes: for each event type, measure whether inspectors detected the challenge (true positive), missed it (false negative), or falsely flagged non-existent anomalies (false positive)
- Provide blind-exercise detection data monthly to the Bilateral Executive Steering Committee and the Independent Auditor; track false-negative and false-positive rates against provisional thresholds
- Run pre-test calibration exercises on non-covered equipment (Months 4–5 = 2027-02-08 to 2027-03-08, outside formal clock) to validate detection capability and threshold realism before formal Go/Modify/Stop decision
- Conduct post-exercise independent audit of scenario design, blind integrity and scoring methodology; ensure scenarios are comparable and not biased toward either country's inspectors

**Initial Setup Actions:**

- Select and vet independent testing unit leadership (estimated 8–12 personnel per site, total 32–48 across 4 sites) by Month 1 (2026-11-08); staffing may include neutral international experts, academics, or retired national-security professionals acceptable to both countries
- Develop challenge-exercise scenario library: define the 7 event types, example scenarios per type, difficulty levels, and realism benchmarks (Month 1.5 = 2026-11-23)
- Design the sealed double-key exercise schedule: coordinate with BESC to lock timing, venue rotation across sites, and scenario sequence; finalize by Month 5.5 (2027-03-23)
- Establish exercise-response documentation and scoring templates; define true-positive, false-negative and false-positive criteria per event type with objective metrics (Month 1.5 = 2026-11-23)
- Run a pre-test exercise-design audit: peer-review scenarios against fairness and realism rubrics; both national red teams assess whether scenarios are realistic and comparable
- Pre-coordinate with site operators: schedule exercise windows in staging, spare-inventory, maintenance and expansion areas; establish communication protocols and real-time incident response for exercise-related events

**Membership:**

- Independent Testing Unit Director (1 FTE, non-national or jointly staffed, reports to BESC with no dual reporting)
- Scenario Design Lead (1 FTE, expertise in supply-chain attack methods, equipment substitution, falsification of records)
- Scoring and Data Analysis Lead (1 FTE, expertise in forensic analysis, detection metrics, statistical validation)
- Site Exercise Coordinators (2 per site, 8 total FTE, liaison with inspectors, logistics, real-time observation and documentation)
- Red-Team Facilitators (3–4 FTE per country, representing realistic adversary capabilities; conduct the unreported arrival, substitution, falsification and vendor-refusal scenarios)
- Independent Auditor (1 FTE, third-party observer of exercise integrity, blind maintenance and scoring objectivity)

**Decision Rights:** Authority to design and run exercises independently; neither national government may override exercise design or timing (once sealed schedule is locked by BESC at Month 5.5 = 2027-03-23). Authority to score detection outcomes objectively and report results to BESC monthly. Authority to declare an exercise void if contamination (advance notice to inspectors, unplanned interruption to active computation) is confirmed; void exercises are re-run if time permits, or excluded from the evidence base with documented justification. No authority to adjust thresholds or modify corroboration rules; all such changes are decided by BESC or the Joint Forensic Panel.

**Decision Mechanism:** Exercise scenario approval requires consensus of the ITU director and both national red-team facilitators; design disagreements are escalated to BESC as a fairness dispute. Exercise scoring is performed independently by the Scoring Lead and a designated observer from each country; if scores diverge, the Independent Auditor breaks the tie. Exercise timing and sequence are locked by double-key co-chair approval at Month 5.5 (2027-03-23); no changes to the sealed schedule are permitted after lock, except in case of a genuine operational emergency (site evacuation, major facility failure) authorized by both co-chairs.

**Meeting Cadence:** Weekly ITU leadership meeting (1 hour) during exercise-design phase (Months 1–2 = 2026-11-08 to 2026-12-08) and scenario-refinement phase (Months 3–5 = 2027-01-08 to 2027-03-08). Daily coordination during calibration exercise (Months 4–5 = 2027-02-08 to 2027-03-08), coordinating with sites and inspectors. During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08), exercise-execution meetings within 48 hours of each exercise; post-exercise scoring and documentation meetings within 72 hours. Monthly results briefings to BESC and Independent Auditor.

**Typical Agenda Items:**

- Scenario design and fairness review: challenge-exercise concept approval, realism validation, comparability across countries
- Sealed double-key schedule finalization: timing, venue, scenario sequence, red-team assignments, inspector blindness protocols
- Pre-test calibration-exercise execution: run dry-run on non-covered equipment, collect detection rates, validate scoring methodology
- Calibration results and threshold validation: compare observed false-negative/positive rates against provisional thresholds; recommend adjustments for co-chair approval
- Monthly detection-data summary: true positives, false negatives/positives by event type, detection-time distribution, escalation patterns
- Exercise-integrity and scoring audit: independent auditor results, fairness assessment, blind-maintenance confirmation
- Adverse findings and anomalies: unusual detection patterns, suspected exercise contamination, site-specific capability gaps

**Escalation Path:** Exercise-design disputes (fairness, realism, comparability) escalate to BESC within 5 days of disagreement. Scoring disputes (true positive vs. false positive, or detection time attribution) escalate to BESC within 72 hours of the disputed exercise, with the Independent Auditor providing a tie-breaking opinion. Exercise-integrity concerns (advance notice to inspectors, unplanned facility disruption) escalate to BESC within 24 hours with recommendation to void or re-run the exercise. Threshold-validation findings (calibration data suggesting provisional thresholds are unrealistic) escalate to BESC with a recommended protocol-change amendment to lock validated thresholds before formal Phase One begins.
### 6. Bilateral Inspector Conduct and Reciprocity Oversight Panel

**Rationale for Inclusion:** Inspector espionage and coercion risk is high in a low-trust bilateral environment. Inspectors from one country may be targeted for collection by the other's intelligence services, or may attempt unauthorized access to sensitive areas beyond the bounded zone. The plan requires full-time mirrored inspectors, rotation across sites, and continuous access-log audit. A bilateral conduct-review panel ensures that both governments maintain confidence that inspector access is for verification only and that conduct violations are investigated fairly and escalated promptly. This panel also tracks reciprocal-access parity: if one country grants its inspectors wider access, longer maintenance windows or faster escalations, the other side can request equivalent treatment.

**Responsibilities:**

- Conduct monthly inspector access-log audit: review device access, zone-boundary crossings, note-taking, device-usage patterns, and time-stamped evidence of inspector location and activities
- Investigate all reported conduct incidents: Tier 1 warnings (minor, first offense), Tier 2 formal notices (repeated or deliberate violations), Tier 3 removals (material espionage risk or serious unauthorized access)
- Document every zone boundary violation, alleged or substantiated, with photographs or access-log evidence; define material IP exposure as undisclosed photography of workload location, network topology, source code, weights or infrastructure beyond the bounded zone
- Manage inspector rotation across sites: ensure rotations are randomized or on a pre-agreed schedule so neither operator nor vendor can predict who is present; maintain a pre-approved rapid-replacement pool for every critical post
- Monitor reciprocal-access parity: compare metrics across both countries (inspectors deployed per site, hours of zone access per inspector, events witnessed, escalation items raised, maintenance-window access, emergency-response time); flag asymmetries >20% (estimated) and escalate to BESC within 5 days
- Authorize inspector removals: Tier 2 and Tier 3 incidents escalate to bilateral panel for investigation; panel may recommend removal with justification; removal of an inspector requires documented findings and written notice to the offending country's Deputy Co-Chair within 24 hours
- Maintain inspector-vetting status and clearance tracking: monitor clearance expiry dates, renewal timelines and surge-pool readiness; escalate clearance delays to the national operations units and vetting authorities

**Initial Setup Actions:**

- Jointly select bilateral panel members (estimated 3–5 per country, equal membership, total 6–10) with expertise in counterintelligence, inspector conduct and reciprocal-access verification by Month 1 (2026-11-08)
- Establish the three-tier infraction protocol and escalation procedures; document and sign by both co-chairs (Month 1 = 2026-11-08)
- Define material IP exposure and espionage-risk indicators that trigger Tier 3 investigation and potential removal (Month 1 = 2026-11-08)
- Establish inspector conduct-code; every inspector signs a code of conduct at induction, with zero-tolerance rules for unauthorized area access, recording, or collection (Month 2 = 2026-12-08)
- Set up continuous access-log infrastructure: badge-swipe systems, device-access logging, location tracking (GPS or secure beacon) for inspectors in defined zones; logs synchronized with both national ledger copies in real time (operational by Month 4 = 2027-02-08)
- Pre-identify a pre-approved rapid-replacement pool for every critical inspector post (3–5 alternates per post, all pre-vetted and cleared); maintain roster with backup-ready dates (Month 5 = 2027-03-08)

**Membership:**

- Panel Chair: Joint bilateral co-chair (1 per country, rotating leadership by 6-month term)
- US Counterintelligence Representative (1–2 FTE, expertise in inspector vetting, conduct monitoring, espionage risk assessment)
- Chinese Counterintelligence Representative (1–2 FTE, equivalent expertise)
- US Inspector Vetting Officer (shared with US National Operations Unit, 1 FTE liaison)
- Chinese Inspector Vetting Officer (shared with Chinese National Operations Unit, 1 FTE liaison)
- Independent Auditor (1 FTE, third-party observer of conduct investigations and removal decisions)

**Decision Rights:** Authority to conduct access-log audits and recommend Tier 1 warnings (minor, first offense) without escalation. Authority to initiate Tier 2 investigations (repeated or deliberate violations) and recommend formal notice and inspector retraining; Tier 2 findings escalate to BESC for confirmation within 24 hours. Authority to investigate Tier 3 cases (material espionage risk) and recommend removal; Tier 3 removal requires agreement of both panel co-chairs and BESC approval within 24 hours. Authority to track and report on reciprocal-access parity metrics and recommend corrective action if asymmetry >20% is detected. No authority to override corroboration rules, site findings or protocol changes; conduct matters are escalated appropriately within their tier.

**Decision Mechanism:** Monthly access-log audit conducted jointly by both national counterintelligence representatives; findings reviewed in panel meeting and documented. Tier 1 and Tier 2 incidents investigated by a joint panel team (both countries represented); consensus required for recommendations. Tier 3 cases require panel unanimity for removal recommendation; if one country's panel members object, the matter escalates to BESC with a contested finding. Reciprocal-access parity analysis conducted monthly and presented to BESC; asymmetries >20% trigger a bilateral review and proposed remediation within 10 days.

**Meeting Cadence:** Monthly bilateral conduct-review meeting (2 hours) to review access-log audit results, Tier 1/2 incidents, reciprocal-access parity metrics and pre-approved replacement-pool status (Months 0–10 = 2026-10-08 to 2027-08-08). Ad-hoc emergency meetings for Tier 3 investigations (within 24 hours of incident report). Weekly bilateral operations-coordination calls (30 minutes) during Phase One (Months 6–9 = 2027-04-08 to 2027-07-08) to track real-time conduct and access issues.

**Typical Agenda Items:**

- Monthly access-log audit results: zone-boundary compliance, device-access review, location tracking validation, anomaly flagging
- Tier 1 warnings: minor violations (off-boundary photograph, brief unauthorized area entry); disposition (retraining, additional supervision)
- Tier 2 formal notices: repeated or deliberate violations; investigation findings and recommended action (formal notice, escalation, potential removal)
- Tier 3 removal investigations: material espionage risk or serious unauthorized collection; investigation findings and removal recommendation
- Reciprocal-access parity metrics: inspector deployment per site and country, hours of zone access, witnessed events, escalation items, maintenance-window access, emergency-response time
- Inspector-vetting status: clearance expiry dates, renewal timeline, surge-pool readiness, rapid-replacement-pool updates
- Rotation compliance: site-rotation schedule, randomization validation, pre-vetting of incoming rotations

**Escalation Path:** Tier 1 and minor Tier 2 incidents are handled within the panel; findings documented in the monthly report to BESC. Tier 2 and Tier 3 incidents escalate to BESC within 24 hours with panel recommendation. Removal of an inspector (Tier 3) requires bilateral panel consensus and BESC approval; the offending country's Deputy Co-Chair is notified with written justification. If a Tier 2 incident escalates to repeated violations by the same inspector, automatic escalation to Tier 3 investigation is triggered. Reciprocal-access asymmetry >20% escalates to BESC with a remediation plan due within 10 days. Unresolved access-parity disputes escalate to the neutral referee panel after 7 days of BESC disagreement.
### 7. Independent Auditor and KPI Monitoring Office

**Rationale for Inclusion:** The bilateral mechanism must be subject to continuous independent audit and transparent KPI tracking so that both governments can verify that Phase One is proceeding according to plan and that the evidence base is sound. An independent auditor (not answerable to either national government, jointly selected by BESC) reviews ledger integrity, evidence-handling chain of custody, compliance with entry-condition timelines, spending against budget envelopes, personnel vetting, exercise integrity, and inspector conduct. A KPI monitoring office publishes monthly metrics (detection rates, false positives/negatives, ledger sync, reciprocal-access parity, discrepancy age, unverifiable equipment, vendor refusals, funding timeliness, audit exceptions) so both governments can track progress against thresholds and assess whether Phase One is credible.

**Responsibilities:**

- Quarterly independent audit of ledger integrity, cryptographic signing validity, and sync-divergence event counts; validate that <4-hour divergence detection and <7-day unresolved-divergence thresholds are met or properly escalated
- Monthly audit of evidence-handling chain of custody: intake records, exit dispositions, vendor-refusal escalations, forensic-panel findings; ensure all evidence is documented with provenance and timestamps
- Quarterly audit of compliance with entry-condition timelines: track bilateral instrument signature, appropriations clearance, domestic authority enactment, site selection, inspector vetting, operator/vendor binding, equipment schedule adoption; flag any condition lagging >4 weeks behind plan
- Monthly fiscal-accountability audit of spending against budget envelopes: reconcile actual vs. planned expenditure per envelope (ledger, site prep, personnel, facilities, testing, legal, contingency); flag variance >5% and cost-center-level details; sign-off on large tranches >USD 25M
- Quarterly inspector vetting and clearance audit: confirm all deployed inspectors have current counterintelligence clearances; verify that rapid-replacement pool is pre-vetted and ready; validate that no single-person critical functions exist
- Post-exercise independent audit of challenge-exercise scenario design, blind integrity, and scoring methodology; validate that scenarios are realistic, comparable across countries, and not biased toward either country's inspectors
- Monthly KPI dashboard: compile and publish detection rates by event type, false-positive and false-negative counts, equipment-identity confidence scores, ledger-sync divergence events and resolution time, reciprocal-access parity metrics, discrepancy age and tiering, unverifiable-equipment count, vendor-refusal outcomes, production-disruption incidents, funding-timeliness status and audit exceptions; mark all figures as provisional or validated; lock thresholds at Month 5.5 (2027-03-23)
- Quarterly auditor-attestation report: document findings on ledger resilience, evidence handling, entry-condition compliance, spending, personnel vetting, exercise integrity and spot checks of zone-boundary enforcement; report accessible to both governments

**Initial Setup Actions:**

- Jointly select independent auditor and KPI monitoring office leadership (estimated 5–8 FTE) by Month 1 (2026-11-08); staffing drawn from reputable international audit firms, accounting firms, or academic institutions acceptable to both countries; no prior employment by either government
- Establish audit scope, methodology and reporting templates by Month 1.5 (2026-11-23); document what constitutes 'variance >5%,' 'audit exception,' and 'material finding'; define escalation thresholds
- Design KPI dashboard: identify all metrics, data sources, collection procedures, publication schedule (monthly) and threshold validation (provisional vs. locked) (Month 1.5 = 2026-11-23)
- Set up secure data repositories for ledger audit, evidence audit and KPI data; ensure both governments have read access to redacted (classified details removed) auditor reports and KPI dashboard
- Conduct first pre-test audit at Month 4 (2027-02-08) on non-covered-equipment operations (ledger, evidence handling, exercise calibration) to validate audit procedures before formal Phase One begins

**Membership:**

- Independent Auditor (Senior audit partner from jointly selected international firm, reports to BESC with no dual reporting)
- KPI Monitoring Office Director (1 FTE, responsible for monthly dashboard compilation and threshold tracking)
- Ledger and Evidence Audit Lead (1–2 FTE, expertise in digital forensics, cryptographic verification, chain-of-custody validation)
- Financial Audit Lead (1 FTE, expertise in government appropriations, envelope-based budgeting, variance analysis)
- Personnel and Vetting Audit Lead (1 FTE, expertise in security clearances, vetting procedures, continuity-of-operations planning)
- Exercise and Detection Audit Lead (1 FTE, expertise in red-team methodology, scenario design and fairness, statistical analysis of detection rates)

**Decision Rights:** Authority to audit any aspect of Phase One operations and report findings to BESC monthly and to both governments quarterly. Authority to flag audit exceptions and escalate material findings (e.g., ledger divergence unresolved >7 days, spending variance >5%, vetting gaps, exercise-integrity concerns) to BESC within 24 hours. Authority to publish the KPI dashboard monthly with provisional and validated thresholds clearly marked. Authority to recommend corrective actions; no authority to enforce corrections (that is BESC's decision).

**Decision Mechanism:** Independent auditor conducts audits and issues findings according to pre-agreed audit scope and methodology; findings are reviewed and confirmed by the auditor before publication. If BESC disputes an audit finding, the auditor may request independent peer review by a third-party audit firm (cost paid from contingency); disputed finding remains published pending peer-review conclusion.

**Meeting Cadence:** Monthly KPI dashboard compilation and publication (internal working meetings 1–2 weeks before publication deadline). Quarterly auditor-attestation report preparation (internal working meetings 2–3 weeks before publication). Quarterly results briefing to BESC (1–2 hours). Ad-hoc meetings to investigate audit exceptions or material findings flagged by BESC within 24 hours.

**Typical Agenda Items:**

- Ledger integrity audit: cryptographic signing validation, sync-divergence counts, offline backup testing, forensic findings on disputed identities
- Evidence-handling audit: chain-of-custody verification, intake/exit protocols, vendor-refusal escalations, documentation completeness and accuracy
- Entry-condition compliance: tracking of bilateral instrument, appropriations, domestic authority, site selection, inspector vetting, operator/vendor binding, equipment schedule; flags for any condition >4 weeks behind plan
- Spending variance analysis: actual vs. planned expenditure per envelope, cost-center reconciliation, large-tranche authorization (>USD 25M)
- Personnel vetting status: clearance validation, rapid-replacement pool pre-vetting, single-person critical-function check
- Exercise audit: scenario fairness and realism, blind maintenance, scoring objectivity, statistical analysis of detection rates and false rates
- KPI dashboard monthly: detection rates by event type, false positive/negative counts, identity confidence, sync divergence resolution time, parity metrics, discrepancy age, unverifiable counts, vendor outcomes, production disruption, funding timeliness, audit exceptions
- Quarterly attestation findings: summary of key audit results, material findings, recommended corrective actions, validation of Phase One credibility

**Escalation Path:** Audit exceptions or material findings (e.g., ledger divergence >7 days unresolved, spending variance >5%, vetting gaps, exercise-integrity concerns) are escalated to BESC within 24 hours with recommended corrective actions. If BESC disputes an auditor finding, the auditor may be asked to provide supporting documentation; if disagreement persists, a peer-review audit by a third-party firm (cost from contingency) is initiated. KPI thresholds are locked at Month 5.5 (2027-03-23) by BESC; after that, KPI deviations from locked thresholds are tracked and reported monthly as evidence for the final Go/Modify/Stop decision.