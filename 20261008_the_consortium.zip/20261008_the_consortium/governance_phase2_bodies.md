### 1. Bilateral Steering Committee (Co-Chair Level)

**Rationale for Inclusion:** Provides strategic direction and high-level oversight for The Consortium's 90-day Phase One operational test. Equal national co-chairs enforce double-key governance without casting votes, approve budgets above USD 10M thresholds, authorize protocol changes, and manage escalations from operational teams. Required for bilateral equity and sovereign accountability.

**Responsibilities:**

- Set strategic priorities and governance posture for Phase One
- Approve major budget draws (>USD 10M) and contingency allocations, with matched parity accountability
- Authorize protocol changes, site findings and suspension decisions via double-key
- Oversee entry-condition certification and gate readiness
- Receive and act on escalations from technical referees and operational deadlocks within fixed timers
- Authorize personnel assignments, inspector rotations and staffing surge

**Initial Setup Actions:**

- Confirm bilateral instrument signature and co-chair appointment by Month 7 (2027-05-12)
- Establish monthly decision cadence and escalation timer protocols before Month 9 (2027-07-12)
- Document no-casting-vote and double-key procedures in operational bylaws
- Pre-position deputy co-chairs and continuity succession before transition
- Certify all entry conditions at simultaneous gate decision point by Month 9 (2027-07-12)

**Membership:**

- National co-chair from United States (deputy secretary or equivalent)
- National co-chair from China (vice-minister or equivalent)
- Each co-chair's designated alternate and successor (for continuity)

**Decision Rights:** Strategic and policy decisions, budget allocations above USD 10M thresholds, protocol changes, suspension authorizations, personnel assignments, and escalation disputes from operational teams. Decisions require bilateral consensus; no majority vote or casting vote permitted. Disagreement triggers escalation to principals within fixed timers (5/8/13-day sequence).

**Decision Mechanism:** Bilateral consensus required on all decisions. Deadlock is defined as failure to reach consensus within 5 days. No casting vote or majority procedure. If co-chairs cannot agree, automatic escalation to designated principals (e.g., secretary of state level) within 2 days. Principals must decide within 5 calendar days or status quo defaults to heightened inspection (not suspension) while further escalation continues. All decisions and deadlocks recorded in the tamper-evident ledger with timestamps.

**Meeting Cadence:** Monthly formal decision sessions (1st of each month, Months 9–12 = 2027-07-12 to 2027-10-12); weekly informal reviews during Phase One operations; emergency convocation within 24 hours if escalation from operational level is triggered. All deadlocks escalate by Day 5 automatically.

**Typical Agenda Items:**

- Budget-burn reports and contingency-draw requests with parity accounting
- Monthly KPI dashboard review (detection rates, parity variance, ledger sync, unresolved discrepancies)
- Escalated site findings, deadlocked identity disputes or vendor-refusal outcomes
- Personnel and staffing-surge authorization requests
- Facility security incidents and counterintelligence briefings
- Challenge-exercise schedule and threshold-calibration panel recommendations

**Escalation Path:** Deadlocked co-chair disagreements automatically escalate to Bilateral Technical Referees panel (composed of 2 pre-cleared experts per country) within 24 hours. If referees issue dual-signed advisory fact statement and co-chairs still cannot agree, escalation triggers automatic Principal-Level Review (secretary-level or equivalent) within 2 days, with mandatory decision required within 5 calendar days.
### 2. Project Management Office and Operational Execution Team

**Rationale for Inclusion:** Manages day-to-day operational execution, tactical risk management, evidence handling, personnel scheduling and coordination of mirrored national teams across 4 declared sites. Directly accountable to co-chairs for meeting KPI targets, managing surges and maintaining the 90-day schedule. Required because the operational scope is large (350-500 staff), geographically distributed and time-constrained.

**Responsibilities:**

- Coordinate day-to-day operations at all 4 declared sites with zero disruption to active compute
- Schedule and deploy mirrored inspection teams across sites, managing shifts, leave coverage and surge capacity
- Manage intake, identity verification, maintenance monitoring and exit-disposition activities at each site
- Record all events in the tamper-evident ledger with immediate local posting and checkpoint synchronization
- Monitor and escalate KPI performance (detection rates, identity confidence, parity variance, ledger latency)
- Manage evidence handling, redaction-gateway audits and filter-adequacy compliance
- Coordinate challenge-exercise logistics in staging and spare-inventory areas without operator disruption

**Initial Setup Actions:**

- Establish operational command structure and site-level teams by Month 8 (2027-06-12)
- Deploy and clear all inspector, technical and support personnel by Month 8.75 (2027-07-05)
- Conduct staffing dry-run and attestation-validation rehearsal by Month 8 (2027-06-12)
- Run filter-adequacy blind pre-test with >=10 substitutions by Month 8.5 (2027-06-27)
- Prepare opening-inventory baseline collection protocols for Days 1-5 of Phase One
- Finalize challenge-exercise staging protocols and site-specific logistics

**Membership:**

- Program Director (project lead, accountable for schedule and KPI delivery)
- US National Operations Director (US mirrored team lead)
- China National Operations Director (China mirrored team lead)
- Site Operations Managers (one per declared site, minimum 4)
- Evidence and Ledger Manager (local recording, synchronization, checkpoint validation)
- Inspector Deployment and Leave Coordinator (shift scheduling, surge management)

**Decision Rights:** Operational decisions within defined thresholds: personnel deployments and rotations up to 20% surge; evidence-handling redactions within approved schema; challenge-exercise logistics; incident response and containment. Decisions exceeding thresholds (e.g., site access suspension, unverifiable-equipment escalation, contingency spend >USD 10M) escalate to co-chairs. Day-to-day tactical decisions made at site level without escalation unless a KPI threshold is breached or an enumerated auto-suspension trigger is approached.

**Decision Mechanism:** National operations directors make operational decisions within their country's mirrored teams by consensus of site managers and functional leads. Cross-site or bilateral operational decisions require agreement between national operations directors; disagreement escalates to co-chairs within 24 hours. All event recording, ledger entries and KPI-threshold violations logged automatically and escalated using reason codes and severity classification.

**Meeting Cadence:** Daily operational sync (15 minutes, all site managers) during Phase One; weekly bilateral operations review with national directors and co-chairs (1 hour); emergency tactical huddles within 2 hours if a KPI threshold is breached or auto-suspension trigger is approached.

**Typical Agenda Items:**

- Daily equipment arrivals, movements, maintenance and departures by site
- Shift staffing status, leave coverage and unplanned absences
- Identity-verification escalations and unverifiable-equipment counts
- Ledger synchronization status and divergence-reconciliation updates
- Parity-denial logs and access-request outcomes
- Challenge-exercise progress and injected-scenario status
- Facility security incidents and counterintelligence alerts
- Contingency-spend requests and budget-burn tracking

**Escalation Path:** Site-level issues escalate to national operations director within 4 hours. Bilateral operational disputes escalate to co-chairs within 24 hours. Any KPI threshold breach (identity confidence <95%, unverifiable >3%, parity >15%, ledger sync >4 hours, unresolved discrepancy >10 days) automatically triggers an escalation report to co-chairs with recommended corrective action within 2 hours of detection. Auto-suspension triggers escalate to co-chairs immediately for double-key authorization of suspension or heightened inspection.
### 3. Bilateral Technical Referees Panel

**Rationale for Inclusion:** Provides independent technical fact-finding and advisory decision-making for deadlocked co-chair disagreements on site findings, equipment identity disputes, vendor-refusal outcomes and evidence sufficiency. Composed of 2 pre-cleared technical experts per country with no political incentive to obstruct. Required because the plan explicitly forbids casting votes and requires escalation of deadlocks to a non-political fact-based process.

**Responsibilities:**

- Issue dual-signed advisory fact statements on contested site findings within 3 days of referral
- Adjudicate disputed equipment-identity rulings by reviewing layered evidence and independence-of-layers analysis
- Evaluate vendor-refusal escalations and recommend appropriate disposition (supervised testing, clean-room examination, unverifiable status)
- Assess equipment-identity confidence and corroboration adequacy for borderline units
- Review filter-adequacy audit findings and recommend protocol adjustments if schema fields are at risk
- Provide technical input to Threshold Calibration Panel on detection-rate assumptions and blind-exercise data

**Initial Setup Actions:**

- Recruit, vet and clear 4 technical experts (2 per country) with certification authority by Month 7 (2027-05-12)
- Establish technical-referee protocols and evidence-review procedures by Month 8 (2027-06-12)
- Train referees on identity-verification layering, evidence schema and corroboration rules
- Establish secure facilities for sealed evidence review and dual-signed advisory production
- Define escalation rules: when a co-chair disagreement on a technical matter becomes a referee referral

**Membership:**

- Senior Technical Expert from United States (cleared, independent of inspectorate)
- Senior Technical Expert from China (cleared, independent of inspectorate)
- Each country's alternate referee (for continuity if primary is unavailable)

**Decision Rights:** Authority to issue dual-signed advisory fact statements on specific technical disputes referred by co-chairs. Statements are advisory; co-chairs remain accountable for final decision. Referees have no authority to bind co-chairs, but their facts become part of the escalation record and inform principal-level review if co-chairs remain deadlocked.

**Decision Mechanism:** Both referees review evidence independently and sealed, then convene to draft a joint fact statement that both must sign. Disagreement between referees becomes part of the record; they may issue a statement saying 'Referees assessed evidence independently; assessment differs on [specific point]' and recommend principal-level review. No casting vote or majority ruling; if consensus cannot be reached on a fact statement, the extent of disagreement is documented and escalated with the unsigned draft to principals.

**Meeting Cadence:** On-demand; convenes within 24 hours of co-chair referral. Must produce dual-signed advisory statement within 3 days. No regular cadence; purely triggered by escalated disputes.

**Typical Agenda Items:**

- Review of sealed evidence (identity documentation, customs records, attestation validation, physical inspection notes, maintenance logs)
- Assessment of whether layered evidence meets independence-of-layers requirement and identity-confidence threshold (>95% provisional)
- Evaluation of vendor-refusal outcomes and recommendation among: vendor-supervised testing, filtered evidence, clean-room examination, or unverifiable status
- Filter-adequacy assessment if redaction decisions are in dispute
- Corroboration-mismatch analysis (e.g., attestation timestamp misaligned with customs entry)

**Escalation Path:** If referees cannot produce a dual-signed fact statement (disagreement on core findings), the unsigned draft, areas of disagreement and both referees' independent assessments escalate automatically to Principal-Level Review within 2 days. If co-chairs receive a dual-signed fact statement but remain deadlocked on the policy decision, the matter escalates to principals with the referees' statement attached.
### 4. Evidence and Ledger Integrity Committee

**Rationale for Inclusion:** Ensures the tamper-evident replicated ledger remains trustworthy, synchronization stays within KPI bounds, divergences are detected and reconciled within 24 hours, and all evidence handling meets schema and chain-of-custody standards. Central to the entire verification program because evidence credibility is the sole basis for the Go/Modify/Stop verdict. Required because ledger integrity is a foundational technical requirement and a Stop criterion.

**Responsibilities:**

- Operate and monitor each country's independent ledger copy and synchronization checkpoints
- Detect divergences between national copies and initiate reconciliation within 4 hours of detection
- Validate cryptographic checkpoint signatures and hash-chain integrity hourly
- Log all facility incidents (power loss, physical access, personnel changes) in the ledger within 1 hour
- Audit operator-controlled redaction gateways and confirm all non-redactable evidence schema fields are preserved
- Monitor equipment-identity confidence scores and escalate units approaching the unverifiable threshold (>5% at a site)
- Maintain equipment-classification schedule versioning and track all double-key schedule updates

**Initial Setup Actions:**

- Establish ledger-node security hardening and geographically diverse deployment by Month 8 (2027-06-12)
- Deploy hash-chain checkpoint validation infrastructure with hourly cryptographic validation by Month 8.5 (2027-06-27)
- Establish neutral-party digest custodian arrangement for ledger escrow and offline backup by Month 8 (2027-06-12)
- Train operators on redaction-gateway logging and run filter-adequacy pre-test by Month 8.5 (2027-06-27)
- Establish reconciliation procedures and timers (4-hour detection, 24-hour closure) and log every step in the ledger
- Pre-stage offline backup media and recovery procedures for forensic ledger reconstruction

**Membership:**

- Ledger System Architect (design, cryptography, checkpoint validation)
- US Ledger Node Operator (national copy management, synchronization, security)
- China Ledger Node Operator (national copy management, synchronization, security)
- Evidence Schema and Classification Specialist (each country, 1 per country minimum)
- Divergence Reconciliation Lead (bilateral, accountable for 24-hour closure SLA)

**Decision Rights:** Authority to record all events in the ledger with immediate local posting; to validate checkpoint signatures and detect divergences; to classify divergences as resolved or unresolved based on evidence; to escalate unresolved divergences or sync-latency KPI breaches. Authority to partition challenge-exercise events from operational events using CHALLENGE tagging. No authority to alter event records post hoc or override reconciliation; all changes tracked and escalated.

**Decision Mechanism:** Ledger operators record events as they occur with immediate local timestamp. National copies exchange signed hourly checkpoints. On divergence detection, both operators independently review the diverged events and logs; if cause is clear and correction is made (e.g., late-arriving event), reconciliation is logged and closed. If cause is unclear or disputed, unresolved status is recorded and escalated to co-chairs; 24-hour closure deadline applies. If divergence cannot be resolved at ledger-operator level, escalation goes to co-chairs with no discretion to override the reconciliation process.

**Meeting Cadence:** Daily ledger health check (15 minutes, all operators and schema specialists) during Phase One; weekly bilateral reconciliation review (1 hour) if any divergences occurred; emergency convocation within 2 hours if divergence-detection latency exceeds 4-hour KPI or sync latency exceeds 1 hour.

**Typical Agenda Items:**

- Hourly checkpoint validation results and signature verification status
- Any divergence events detected: event count, age, content and root cause
- Reconciliation progress and closure status for any open divergences
- Facility security incidents affecting ledger integrity (power loss, access, personnel changes)
- Redaction-gateway audit results and evidence-schema compliance checks
- Equipment-identity confidence trend (units trending toward >5% unverifiable at any site)
- Schedule-version update requests and bilateral signature status
- Offline backup and forensic-recovery readiness status

**Escalation Path:** Divergence detected -> immediate escalation report to co-chairs with summary and cause analysis within 2 hours. Reconciliation not closed within 8 hours -> escalation to co-chairs flagging age and recommending co-chair review. Unresolved divergence age >10 days -> automatic impaired-confidence review trigger; >15 days -> Stop-criterion candidate. Sync latency exceeding 4-hour KPI or checkpoint validation failure -> immediate escalation to co-chairs and Facility Security Review Panel.
### 5. Counterintelligence and Compartmentation Oversight Unit

**Rationale for Inclusion:** Protects inspector and evidence-handler personnel from espionage, blackmail and relationship-capture by counterpart intelligence services. Enforces compartmentation rules, manages personnel vetting and tenure limits, runs insider-threat red-cell operations and conducts security incident investigations. Required because resident mirrored teams at counterpart sites face extraordinary CI risk and operator willingness depends on credible compartmentation assurances.

**Responsibilities:**

- Vet, polygraph and continuously monitor all inspectors, technical staff and translators for CI risk
- Enforce compartmentation rules: inspectors segregated by site and event type, with no individual holding cross-site knowledge
- Manage inspector tenure limits (6-month site tenure with 2-month breaks) and rotation scheduling
- Conduct quarterly unannounced facility-security inspections of ledger nodes, clean rooms and secure workspaces
- Operate bilateral insider-threat red cell attempting to compromise inspectors and evidence handlers
- Investigate and log all suspected CI incidents in the tamper-evident ledger within 1 hour
- Audit boundary-violation allegations and operator-complaint investigations
- Review and approve all cross-border evidence movement and communications

**Initial Setup Actions:**

- Recruit and clear CI specialists (minimum 4 per country: 2 counterintelligence officers, 1 polygraph examiner, 1 forensic investigator) by Month 7 (2027-05-12)
- Establish CI vetting protocols and polygraph schedule for all 350-500 personnel by Month 8 (2027-06-12)
- Establish compartmentation rules, access-control matrices and event-type segregation by Month 8 (2027-06-12)
- Deploy insider-threat red cell (2 officers per country) and establish red-team exercise protocols by Month 8.5 (2027-06-27)
- Establish secure facilities and compartmented workspaces at each site by Month 9 (2027-07-12)
- Conduct pre-Phase-One CI baseline briefing for all inspectors and clearance-status confirmation

**Membership:**

- CI Director from United States (senior counterintelligence official, cleared)
- CI Director from China (senior counterintelligence official, cleared)
- Senior CI Officer per country (2 FTE minimum per country)
- Polygraph and Personnel Vetting Lead (per country, 1 per country minimum)
- Insider-Threat Red Cell Coordinator (per country, bilingual, 2 per country recommended)
- Forensic Investigator and Incident Response Lead (joint or per-country)

**Decision Rights:** Authority to deny personnel access to Phase One operations if vetting reveals CI risk; to enforce tenure limits and rotations; to initiate investigations of suspected CI incidents; to recommend compartmentation changes if operational needs conflict with security. No authority to override co-chair decisions on site suspension or personnel assignments, but findings feed directly into co-chair briefings and suspension criteria.

**Decision Mechanism:** CI decisions are made independently by each country's CI director on vetting and tenure; bilateral agreement is required for compartmentation rule changes, clearance denials that affect operations, and red-cell exercise protocols. CI incidents are investigated by both sides jointly when cross-border elements are present. Disagreement on CI risk assessments is escalated to co-chairs; vetting denial stands until resolved by principals if either side objects.

**Meeting Cadence:** Weekly CI briefing (1 hour, both CI directors) during Phase One; monthly compartmentation-compliance review; quarterly unannounced facility inspections (concurrent, both sides); insider-threat red-cell exercises at Month 9.75, 10.75, 11.75 (2027-08-04, 2027-09-04, 2027-10-05) (roughly monthly during Phase One).

**Typical Agenda Items:**

- Polygraph results and new vetting completions for incoming personnel
- Tenure-limit compliance and upcoming rotations by site and function
- Suspected or confirmed CI incidents and investigation status
- Compartmentation compliance audits and access-control log review
- Insider-threat red-cell exercise results and attempted-compromise summaries
- Facility security incidents affecting compartmented areas
- Operator-complaint investigations and boundary-violation allegations
- Recommended compartmentation adjustments based on operational experience

**Escalation Path:** Suspected CI incident -> immediate investigation initiation and co-chair notification within 2 hours. Confirmed CI breach -> automatic co-chair briefing and Facility Security Review Panel convocation within 4 hours. Disputed vetting denial (one country clears, other rejects) -> escalation to co-chairs within 24 hours for resolution. Compartmentation-rule conflict (operational need vs. security requirement) -> escalation to co-chairs for policy adjustment. Red-cell successful compromise of an inspector -> incident investigation and personnel removal within 24 hours, with co-chair notification.
### 6. Threshold Calibration and Verdict Panel

**Rationale for Inclusion:** Establishes and defends the Go, Modify and Stop thresholds so verdicts rest on evidence rather than political preference. Pre-registers unsupported figures with documented validation methods, calibrates thresholds using early blind-exercise data, freezes thresholds before scored exercises, and produces sealed independent scores to prevent post-hoc goalpost-moving. Required because the plan explicitly demands thresholds separated from political decision-making and evidence-based verdict criteria.

**Responsibilities:**

- Pre-register all Go, Modify and Stop thresholds before Month 9 (2027-07-12) with documented validation source for each figure
- Mark provisional or TBD figures explicitly and specify validation method
- Calibrate thresholds using early blind-exercise results (Months 9.5-10.5 = 2027-07-27 to 2027-08-27) and recommend adjustments if empirical data diverges >10% from assumptions
- Freeze all thresholds by Month 10.5 (2027-08-27) before scored exercises begin
- Score blind-exercise results independently and sealed by each national team
- Compare sealed scores at Month 11.75 (2027-10-05) to measure scoring divergence
- Produce a Verdict Evidence Report documenting how evidence maps to Go/Modify/Stop criteria

**Initial Setup Actions:**

- Recruit bilateral technical calibration experts (2 per country minimum, cleared) by Month 7 (2027-05-12)
- Publish pre-registered threshold table with provisional-figure labeling and validation-method source by Month 8.5 (2027-06-27)
- Establish scoring criteria and evidence-sufficiency rules for each KPI before Phase One starts
- Establish secure facilities for sealed score storage and comparison protocols by Month 8 (2027-06-12)
- Conduct threshold-calibration dry-run using historical or simulated exercise data by Month 8.5 (2027-06-27)

**Membership:**

- Calibration Panel Lead (bilateral, senior technical authority accountable for pre-registration and freeze decisions)
- US Threshold Specialist (technical expert, cleared, independent of inspectorate)
- China Threshold Specialist (technical expert, cleared, independent of inspectorate)
- Evidence Sufficiency Analyst (per country, 1 per country minimum, responsible for scoring protocol)

**Decision Rights:** Authority to set and publish pre-registered thresholds; to recommend threshold adjustments based on early-exercise calibration; to freeze thresholds by Month 10.5 (2027-08-27); to score exercise results against frozen thresholds. No authority to change thresholds after freeze except by bilateral co-chair amendment. Sealed scoring is independent; panel does not gate the Go/Modify/Stop verdict, but provides the evidence basis for co-chair decision.

**Decision Mechanism:** Thresholds are pre-registered by bilateral agreement (both specialists sign off) and published by Month 8.5 (2027-06-27). Calibration recommendations require both specialists' agreement; disagreement on a calibration recommendation is documented and escalated to co-chairs. Threshold freeze at Month 10.5 (2027-08-27) requires both specialists' sign-off; disagreement is escalated to co-chairs for final decision. Sealed scoring is done independently by each country; scoring divergence is measured but both scores are treated as valid assessments and reported alongside the verdict.

**Meeting Cadence:** Monthly during preparation (Months 7-8 = 2027-05-12 to 2027-06-12); weekly during calibration exercises (Months 9.5-10.5 = 2027-07-27 to 2027-08-27); sealed-score comparison meeting at Month 11.75 (2027-10-05); no regular cadence after freeze, only convened if co-chairs request threshold amendment.

**Typical Agenda Items:**

- Pre-registration table review: threshold values, provisional-figure labels, validation-method documentation
- Early blind-exercise results and divergence analysis (actual vs. provisional assumption)
- Recommended threshold adjustments (if empirical data diverges >10% from assumptions)
- Freeze-readiness assessment and final specialist sign-off
- Sealed-score comparison and measurement of scoring divergence between national assessments
- Evidence-mapping review: how KPI results translate to Go/Modify/Stop verdict criteria

**Escalation Path:** Disagreement on threshold values before pre-registration -> escalation to co-chairs by Month 8 (2027-06-12) with recommendations from both specialists. Disagreement on calibration recommendations -> documented in the calibration report with both positions published. Disagreement on freeze decision -> escalation to co-chairs for final authorization. Scoring divergence >10 percentage points between national teams -> both scores reported alongside verdict, with divergence magnitude itself become a transparency metric.
### 7. Vendor and Operator Binding and Compliance Unit

**Rationale for Inclusion:** Ensures vendors and operators accept and comply with verification duties (reporting, confidentiality, escort, evidence preservation) before Phase One starts. Manages vendor-refusal escalations, operates clean-room examination centers for refusing vendors, and enforces consequences for non-compliance. Required because vendor refusal and operator shielding are listed Stop criteria and must be contractually bound before entry gate.

**Responsibilities:**

- Draft and execute verification-duty contracts with all equipment manufacturers, maintenance providers and logistics firms
- Establish pre-qualified vendor registry and enforce supply-chain consequences for refusal
- Operate accredited clean-room examination centers for vendors unwilling to participate directly
- Manage attestation-key validation by accredited examiners (both countries) for each critical vendor
- Track vendor-attestation confidence and flag vendors whose signatures cannot be independently validated by Month 10 (2027-08-12)
- Escalate vendor-refusal outcomes and recommend supervisory-testing, filtered-evidence or unverifiable status
- Audit operator adherence to access-control and compartmentation boundaries
- Monitor operator-consent status and escalate any withdrawal or degradation as immediate impaired-confidence trigger

**Initial Setup Actions:**

- Identify critical vendors and suppliers (manufacturers, maintenance, logistics) by Month 7 (2027-05-12)
- Draft vendor-binding agreements with confidentiality, reporting and evidence-preservation terms by Month 7.5 (2027-05-27)
- Obtain operator and vendor signatures on binding agreements by Month 8 (2027-06-12)
- Establish pre-qualified vendor registry and communicate supply-chain consequences by Month 8 (2027-06-12)
- Construct clean-room examination centers (at least 1 per country) by Month 8.5 (2027-06-27)
- Establish accredited-examiner vetting and attestation-validation protocols by Month 8.5 (2027-06-27)
- Confirm all critical vendors' attestation keys are validated by Month 10 (2027-08-12) or flag for unverifiable status

**Membership:**

- Vendor and Operator Liaison Director (bilateral, accountable for binding and compliance)
- US Vendor Binding and Compliance Lead (national, manages US operator and vendor relationships)
- China Vendor Binding and Compliance Lead (national, manages China operator and vendor relationships)
- Accredited Examiner and Clean-Room Lead (per country, 1 per country, manages supervised testing)
- Attestation-Key Validation Specialist (technical, cryptography, 1 per country minimum)

**Decision Rights:** Authority to require vendors and operators to sign binding agreements as a condition of participation; to deny supply-chain access to refusers; to escalate vendor-refusal outcomes and recommend disposition (clean-room, filtered evidence, unverifiable); to flag attestation-validation failures. No authority to override co-chair decisions on suspension or equipment disposition, but vendor-refusal and attestation-validation findings feed directly into escalation.

**Decision Mechanism:** Binding agreements are drafted jointly and signed by each country with counterpart vendors and operators. Vendor-refusal escalations are jointly assessed; if refusal handling diverges (one country recommends clean-room, other recommends unverifiable), escalation goes to co-chairs within 5 days of refusal with both country's recommendations. Attestation-validation results are assessed independently by each country's examiner; if validation fails for a critical vendor, automatic escalation to co-chairs and principal-level resolution within 5 days.

**Meeting Cadence:** Weekly vendor-compliance review (1 hour) during preparation (Months 7-8 = 2027-05-12 to 2027-06-12) and through Phase One; monthly operator-consent-status report shared with co-chairs; immediate escalation meetings within 24 hours if a vendor refuses or an operator withdraws consent.

**Typical Agenda Items:**

- Vendor-binding-agreement execution status and signature tracking
- Pre-qualified registry roster and supply-chain consequence enforcement
- Vendor-refusal incidents and escalation status (clean-room testing, filtered evidence, unverifiable classification)
- Attestation-key validation results by vendor tier and confidence status
- Clean-room examination capacity and schedule; refusing-vendor testing queue
- Operator-consent status by site; any degradation or withdrawal incidents
- Operator-complaint investigations and boundary-violation allegations
- Attestation-validation confidence trending and Month 10 (2027-08-12) certification readiness

**Escalation Path:** Vendor refusal -> escalation to co-chairs within 24 hours with both countries' recommendations for disposition. Vendor-refusal handling disagreement -> co-chairs decision required within 5 days; absent agreement, equipment from refuser becomes unverifiable if material (>3% of site). Attestation-validation failure for critical vendor -> immediate escalation to co-chairs and principals within 2 hours; principal-level resolution required within 5 days. Operator-consent withdrawal -> automatic site suspension and diplomatic escalation to principals within 4 hours.
### 8. Independent Testing, Challenge Exercise and Red Team Unit

**Rationale for Inclusion:** Designs and executes blind challenge exercises (unreported arrivals, substitutions, inaccurate records, delayed access, vendor refusal, reluctant operators) in staging, spare-inventory, maintenance and expansion areas without disrupting active compute. Validates detection capability and filter adequacy through empirical testing. Produces evidence for the Go/Modify/Stop verdict and ensures neither government can redefine success post hoc. Required because blind detection is a stated Go criterion and challenge exercises are the only empirical basis for credible verdicts.

**Responsibilities:**

- Design blind challenge scenarios for 7 event types with >=10 injections each (70 total) before Phase One starts
- Hash-commit sealed scenario catalog before Month 9 (2027-07-12) so neither government can redefine scenarios
- Conduct filter-adequacy pre-test (Month 8.5, 2027-06-27) with >=10 substitutions to validate redaction rules before scored exercises
- Run unscored calibration exercises (Months 9.5-10.5, 2027-07-27 to 2027-08-27) to establish baseline detection and false-positive/negative rates
- Execute scored blind exercises (Months 10.5-11.5, 2027-08-27 to 2027-09-27) with detection tracking by event type
- Score exercise results against frozen thresholds (>=90% detection per event type for Go)
- Operate reciprocal red-team challenges where each country's team tests the counterpart's inspectorate at matched sites

**Initial Setup Actions:**

- Recruit independent testing director and red-team leads (2 per country minimum, cleared, no ties to inspectorate) by Month 7 (2027-05-12)
- Design 70 blind scenarios (>=10 per event type) by Month 8 (2027-06-12)
- Hash-commit sealed scenario catalog by Month 8.5 (2027-06-27)
- Prepare filter-adequacy pre-test injections and detection-measurement protocols by Month 8.5 (2027-06-27)
- Establish scenario-tagging (CHALLENGE tag) and reconciliation protocols with ledger unit by Month 8 (2027-06-12)
- Brief inspectors on exercise partitioning: CHALLENGE tags exclude exercises from triggering suspension or KPI violations

**Membership:**

- Independent Testing Director (bilateral, accountable for blind scenario integrity and scoring independence)
- US Red Team Lead (challenges China's inspectorate at US site, 1-2 FTE minimum)
- China Red Team Lead (challenges US's inspectorate at China site, 1-2 FTE minimum)
- Detection-Measurement Analyst (per country, tracks blind-scenario injection, detection and false-positive rates)
- Filter-Adequacy Tester (per country, conducts pre-test and validates redaction-rule preservation of schema fields)

**Decision Rights:** Authority to design sealed scenarios, hash-commit the scenario catalog and set injection schedules; to tag exercises CHALLENGE and partition them from operational triggers; to score results against frozen thresholds. No authority to change scenarios after hash-commit or to override Threshold Calibration Panel freeze decisions; testing feeds evidence to the verdict but does not bind the verdict.

**Decision Mechanism:** Scenario design is done jointly by both countries' red-team leads; disagreement on scenarios is resolved by co-chairs before hash-commit. Scenario hash-commitment is done by bilateral agreement and published before Phase One starts. Scored results are recorded independently by each national testing team and compared by Threshold Calibration Panel; disagreements on how to classify a result are documented and escalated to the panel.

**Meeting Cadence:** Weekly scenario-design review (Month 8 = 2027-06-12); monthly during Phase One preparation and execution (Months 9-11 = 2027-07-12 to 2027-09-12); sealed-score comparison with Threshold Calibration Panel at Month 11.75 (2027-10-05).

**Typical Agenda Items:**

- Blind-scenario design and validation for 7 event types
- Hash-commitment and sealed-catalog publication
- Filter-adequacy pre-test results: preservation of evidence-schema fields, detection rate, false-positive rate
- Calibration-exercise results and baseline detection/false-positive rates by event type
- Scored-exercise progress: injections per event type, detections and misses, false-positive incidents
- Reciprocal red-team challenges: each country's outcomes at matched sites
- CHALLENGE-tag partition compliance: exercises not triggering suspension or KPI violations
- Detection trending toward >=90% Go threshold

**Escalation Path:** Filter-adequacy pre-test detects missing schema fields -> exercise halt; filters renegotiated and re-tested by Month 9 (2027-07-12) or Phase One delayed. Blind exercise detected by inspectors as unverifiable equipment or triggered an auto-suspension -> immediate escalation to co-chairs with CHALLENGE-tag verification; automatic reinstatement if confirmed as exercise. Scoring divergence >10 percentage points on a given event type -> documented in Threshold Calibration Panel report with both countries' assessments. Detection rate below 85% in calibration exercises -> investigation of filter or presence issues; corrective action or Phase One delay if root cause cannot be remedied.