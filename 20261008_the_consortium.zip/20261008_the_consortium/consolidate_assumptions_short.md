# Purpose
and

# Domain
# Primary domain: Arms Control Verification

Secondary domains: Hardware Supply Chain Security, Counterintelligence and Cybersecurity, Treaty Verification Law

## Rationale

Arms Control Verification is the only outcome role and scores highest (5×5), matching the bilateral inspection-based verification mission and Go/Modify/Stop decision. Supply chain security, cryptography, red teaming, law and diplomacy are subordinate methods, constraints or stakeholders.

## Disciplines this project involves

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Arms Control Verification | 5 | 5 | outcome | Core mission is bilateral inspection-based verification of declared equipment changes with Go/Modify/Stop decision. |
| Hardware Supply Chain Security | 4 | 4 | method | Equipment identity, attestation, custody chain, and vendor-bound evidence underpin intake, maintenance, and exit protocols. |
| Counterintelligence and Cybersecurity | 4 | 4 | constraint | Protecting IP, topology and weights while running tamper-evident ledgers and information barriers. |
| Treaty Verification Law | 4 | 4 | constraint | Bilateral instrument, reciprocal access authority, double-key governance and deadlock procedures require treaty and international law expertise. |
| Applied Cryptography | 4 | 4 | method | Tamper-evident replicated ledger and validated cryptographic attestation underpin layered evidence and synchronization. |
| Data Center Operations | 4 | 4 | stakeholder | Intake, installation, maintenance and decommissioning of equipment occur within operators' datacenters without disrupting production. |
| Red Team Testing | 4 | 4 | method | Blind live challenge exercises and independent testing determine the Go/Modify/Stop decision. |
| International Security Diplomacy | 4 | 3 | stakeholder | Bilateral US–China governance, reciprocity, double-key authorization and deadlock procedures require diplomatic negotiation expertise. |
| Public Financial Management | 3 | 3 | constraint | Appropriations governance, 50/50 funding, envelope mapping and fiscal accountability demand public budgeting discipline. |

# Plan Type
and

# Physical Locations
# Requirements for physical locations

- Declared frontier-relevant computing datacenters with existing operational infrastructure
- Staging, spare-inventory, maintenance and expansion areas suitable for live challenge exercises without interrupting active computation
- Reciprocally accessible sites: matched pairs demonstrating functional parity of inspector access
- Capacity to support full-time mirrored national inspectorates (estimated 150–200+ personnel per country across multiple sites in shifts)
- Secure facilities meeting physical and electronic security standards for classified ledger hosting, evidence review, key custody and counterintelligence
- Facilities for continuous monitoring and witness capability during intake, installation, maintenance and exit procedures
- Space and infrastructure for secure clean-room procedures, vendor-supervised testing and accredited independent examinations
- Proximity or accessibility to customs, logistics and shipment tracking infrastructure for intake verification
- Capacity to host secured reading rooms and joint secure governance spaces accessible to both national teams
- Isolated secure areas for post-rotation inspector debriefs and cooling-off periods to enforce information barriers
- Network infrastructure capable of supporting tamper-evident ledger synchronization with bounded latency and signed-digest exchange
- Physical separation enabling independent national ledger copies and secure key custody

## Location 1: United States

Tier-1 hyperscale datacenter regions (Northern Virginia, Oregon, Texas, or equivalent critical computing hubs); declared hyperscale operator facilities with multiple isolated staging and maintenance areas, existing access-control infrastructure, and capacity for sustained 24/7 inspectorate presence.

## Rationale

US sites must host frontier-relevant computing equipment and demonstrate existing operational security standards, physical logistics infrastructure for equipment intake/exit, and capacity for continuous mirrored staffing. Northern Virginia and Oregon align with established US computing infrastructure and federal-security precedent. Hyperscale operators have documented equipment-change procedures and maintenance areas suitable for blind-challenge exercises without disrupting active workloads.

## Location 2: China

Major regional computing hubs (Beijing, Shanghai, Shenzhen, or state-approved tier-1 datacenter zones); declared state-operated or state-approved frontier computing facilities with government-controlled access, documented equipment schedules, and existing maintenance and spare-equipment areas.

## Rationale

Chinese sites must be selected through bilateral Matched Site Selection Doctrine and represent frontier-relevant computing capacity. Selection at major regional hubs reflects where state-directed frontier research and computing infrastructure concentrate. Sites must be government-accessible under the domestic-authority provision and include documented procedures for equipment arrival, installation, maintenance and removal. Pairing with US hyperscale sites requires functional equivalence in staging and spare-inventory areas.

## Location 3: Neutral or joint secure facility

Proposed: Geneva, Singapore, or equivalent diplomatically neutral jurisdiction; secure bilateral governance and evidence-review facility outside both countries' direct territorial control, with established secure-communications and classified-document handling standards.

## Facility functions

- Dual national ledger-hosting infrastructure
- Bilateral co-chair workspace
- Secure reading rooms for counterpart evidence review
- Key-custody ceremonies
- Inspector debriefing and cooling-off spaces
- Independent auditor workspace

## Rationale

The Consortium's equal co-chair governance, double-key authorization, no-casting-vote structure and Inspector Information Firewall Doctrine require a neutral space where neither government has unilateral physical control. A Geneva-based facility (aligning with IAEA, OPCW and START verification precedent) or Singapore (neutral in US–China context, strong secure-infrastructure capability) supports joint operations without territorial sovereignty complications. This facility hosts replicated ledgers, bilateral dispute adjudication, root-of-trust key material and secure evidence review rooms that apply Counterpart Evidence Disclosure Tiers without either side controlling the filtering environment.

## Location Summary

The Consortium is a bilateral US–China verification mechanism with inherently localized physical operations. Phase One requires declared datacenters in both countries as primary operational sites where inspectors deploy full-time, where intake and exit protocols are executed, where staged equipment is physically inspected, and where live challenge exercises are conducted. Selection is constrained to a small matched set of declared datacenters through a bilateral gate before the 90-day clock begins. Secure facilities are needed to host replicated national ledgers, conduct evidence review in secure reading rooms, hold key-custody ceremonies, staff full-time mirrored inspectorates, run training and translation units, and maintain counterintelligence capability. Joint secure spaces support co-chair governance, double-key authorization protocols and dispute adjudication.

# Currency Strategy
and

# Identify Risks
# Risk 1 - Regulatory & Permitting

Entry conditions (signed bilateral instrument, appropriations, domestic access authority, site selection, inspector approval, vendor participation, covered-equipment schedule) are mandatory gates before the 90-day clock starts. Each is subject to political or bureaucratic review, veto or amendment. Misalignment on 'matched' or 'frontier-relevant' sites can stall site selection indefinitely. Vendor participation requirements create leverage points where a critical vendor's refusal can block a site from entering Phase One.

Impact: Phase One clock never starts or starts 6–12 months late, rendering the 90-day test infeasible. Delayed entry conditions consume contingency budget (estimated 5–10% of USD 500 million contingency) and force rescoping. Political withdrawal risk increases as deadlines slip. If vendor participation is used as a veto, critical frontier equipment may be excluded from the schedule.

Likelihood: High

Severity: High

## Action

Establish a pre-Phase-One entry-condition task force with binding timelines: signed instrument by Month 0.5 (2026-10-23), domestic authority by Month 1 (2026-11-08), site nominations by Month 1 (2026-11-08), inspector selections by Month 2 (2026-12-08), vendor agreements by Month 2.5 (2026-12-23), schedule adoption by Month 3 (2027-01-08). Separate technical feasibility (which sites can support inspectors) from political feasibility (which governments will approve) and handle each track in parallel. Publish a preliminary entry-condition roadmap at Month 0 (2026-10-08) with explicit deadlines and escalation procedures for any gate that slips past 2 weeks. Reserve contingency funding for compressed timelines and emergency negotiation.

---

# Risk 2 - Governance & Deadlock

The design uses equal co-chairs with double-key authorization and no casting vote for budgets, protocol changes, site findings and sanctions. Deadlock procedures define automatic partial suspension after a fixed period, but the age threshold for automatic impaired-confidence status must itself be double-key approved and can become a target for political leverage. If one country delays approving an age threshold, disputes cannot escalate.

Impact: A single unresolved discrepancy or suspended function can paralyze the ledger and adjudication for weeks. Estimated 3–5 unresolved-discrepancy-age deadlocks in a 90-day test if thresholds are disputed. Each stall delays the final Go/Modify/Stop decision by 1–2 weeks per instance. If automatic suspension triggers are weak or delayed, the mission can drift into unmanaged contradiction.

Likelihood: Medium

Severity: High

## Action

Pre-approve the age threshold for automatic impaired-confidence status as an entry condition, not a negotiated item within Phase One. Set thresholds separately for different discrepancy types (e.g., 14 days for equipment-identity disputes, 21 days for exit-disposition conflicts) and embed them in the bilateral instrument before Phase One begins. Define escalation: at 75% of threshold, trigger a mandatory senior technical review; at 100%, automatic partial suspension and public ledger annotation. Appoint an independent timekeeper with mandatory weekly dashboard reporting on unresolved discrepancy age.

---

# Risk 3 - Evidence & Verification

The plan specifies no single evidence source is decisive, but the confidential rotating evidence-weighting rule is set by accountable specialists and validated only post-hoc. If the rule is too strict, false positives and unverifiable-equipment counts surge. If too loose, gaming becomes possible.

Impact: Estimated 15–25% false-positive rate if contradiction-based scoring is applied; estimated 5–10% if corroboration-based scoring is applied (proposed threshold TBD). Each unverifiable-equipment finding triggers a formal discrepancy, potentially overloading adjudication if inspectorate capacity is 10–15 cases per month. Disputes over rule validity can expand the discrepancy caseload by 20–30%.

Likelihood: Medium

Severity: High

## Action

Publish the confidential evidence-weighting rule in versioned escrow before the first challenge exercise, jointly approved by both sides' accountable specialists and locked for the duration of Phase One. Conduct a pilot validation exercise in Month 1.5 (2026-11-23) using historical equipment-change records from participating sites, applying the rule to past events and comparing identity-confidence outputs against known ground truth. Adjust the rule only if pilot results show material miscalibration (>20% false-positive deviation from target). Maintain an independent evidence-audit log showing which rule-version was applied to each finding.

---

# Risk 4 - Technical & Integration

The replicated tamper-evident ledger requires synchronized copies in both countries with bounded latency and signed-digest exchange. If synchronization latency exceeds the agreed bound, divergence can accumulate before detection. If a ledger divergence occurs, resolving it requires double-key agreement, which is itself a deadlock scenario. Key-custody disputes can block ledger entries.

Impact: Estimated 10–15 ledger-divergence incidents in 90 days if synchronization latency is 4+ hours and event volume is 5–10 per day per site. Each divergence can stall evidence validity for 2–7 days pending double-key resolution. A lost or contested signing key can block the ledger entirely for 8–24 hours, creating an observation blackout during which equipment changes are not recorded.

Likelihood: Medium

Severity: Medium

## Action

Set synchronization latency bound at 1 hour for routine events, with escalation triggers at 30 minutes. Implement a secondary asynchronous audit trail for events that cannot be synchronized within the bound, recording them locally and re-syncing when connectivity is restored, with a flag marking the delayed sync. Pre-stage key-recovery ceremonies at Month 1.5 (2026-11-23) and Month 5 (2027-03-08) with full rehearsal. Assign one key-custody officer per country with deputy backup, and require both to be present at key-rotation ceremonies. In case of key loss, fall back to a signed attestation by both countries that the lost key is revoked and a new one generated, recorded in the ledger as an event.

---

# Risk 5 - Operational & Personnel

The plan requires full-time mirrored national inspectorates (estimated 150–200+ personnel across multiple sites in shifts) working 24/7, with no single-person critical functions and mandatory leave coverage. Staffing this scale is operationally unprecedented. High turnover or absences can create coverage gaps. Training and deployment of 300+ personnel on both sides takes 2–3 months, compressed into Months 1–3 (2026-11-08 to 2027-01-08).

Impact: Estimated 10–15% personnel availability shortfall in Month 3 (2027-01-08) due to incomplete training or vetting. A single week of inadequate shift coverage during unreported-arrival or substitution tests can miss evidence. Burnout from 24/7 rotations can cause quality-of-life attrition, cascading into coverage gaps in Months 6–8 (2027-04-08 to 2027-06-08). Estimated 5–8% monthly turnover rate mid-test if morale fails.

Likelihood: Medium

Severity: Medium

## Action

Begin inspector recruitment and vetting at Month -3, not at Month 0 (2026-10-08), so that by Month 1.5 (2026-11-23) the full complement is trained and ready for rapid deployment. Establish a dedicated training academy for bilateral exercises, with joint US–China curriculum starting at Month -1. Create a 20% personnel surge buffer (30–40 additional inspectors per country on standby) to cover leave, illness and emergency rotations. Implement a 6-month rotation schedule with 4 months on-site and 2 months off-site, staggered so at least 80% of each shift's strength is always present. Tie inspector retention bonuses to full-year commitment through Phase One conclusion; budget an estimated 2–3% additional cost within the USD 750 million personnel envelope.

---

# Risk 6 - Security & Counterintelligence

Inspectors from each country are deployed to the other country's datacenters for extended periods, creating counterintelligence exposure. Both governments have incentive to use inspectors as intelligence collectors and to suspect the other of doing so. The Information Firewall Doctrine is designed to limit what each inspector can retain and communicate, but enforcement depends on trust and discipline. A single inspector breach can compromise the entire mechanism.

Impact: Estimated 40–60% chance that at least one breach attempt occurs during a 90-day test with 300+ personnel deployed internationally. If either government concludes the other is conducting espionage through the inspectorate, withdrawal becomes politically likely, with estimated 30–40 day timeline to decision. If a breach becomes public, both governments face domestic political pressure to withdraw.

Likelihood: Medium

Severity: High

## Action

Establish a bilateral Counterintelligence Oversight Board (3 senior counterintelligence officers per side, reporting to co-chairs) with monthly classified meetings to monitor and adjudicate suspected breaches. Pre-deploy polygraph or equivalent security-vetting capability at the neutral facility and conduct baseline and periodic security reviews of all deployed inspectors, with results held confidentially by the Oversight Board. Require all inspectors to sign legally binding statements that unauthorized collection or retention of sensitive information is a criminal violation. Implement secure on-site communication only (no personal phones, no external internet) for inspectors at datacenters, with monitored single-channel communication to their respective governments via the neutral facility. Establish a fast-track adjudication process for suspected breaches: 48-hour investigation, 72-hour recommendation to co-chairs, 7-day decision on remediation.

---

# Risk 7 - Supply Chain & Vendor

Critical vendors must agree to reporting, confidentiality, escort and evidence-preservation requirements. The plan anticipates vendor refusal and defines a fallback ladder: vendor-supervised testing, filtered evidence, accredited independent examiners, clean-room procedures, validated attestations. If a critical vendor refuses all rungs of the ladder, equipment is classed unverifiable and the site fails Phase One. A vendor refusal cascade can render Phase One impossible.

Impact: Estimated 20–30% likelihood that at least one Tier-1 vendor refuses full participation, citing IP protection or customer-confidentiality concerns. If a major vendor refuses, the fallback ladder is invoked, consuming estimated 8–12 weeks to execute clean-room exams or attestation validations. If multiple vendors refuse, the site may fail the entry condition for 'sufficient vendor participation.'

Likelihood: Medium

Severity: High

## Action

Conduct pre-Phase-One vendor engagement (Months -2 to 0) to secure written commitments from all Tier-1 vendors before the bilateral instrument is signed. Offer vendors a choice: participate in the Consortium and retain control over their own evidence package (sealed, accredited independent review), or agree to fallback testing and accept independent examiners' findings without veto. Publish a vendor-participation registry as an entry-condition milestone. Establish a Vendor Liaison Office (5 personnel per country) with authority to negotiate fallback procedures and to escalate to co-chairs if a vendor's refusal threatens to fail a site. Pre-stage one accredited independent examiner team per country. If a vendor cannot be accommodated, document the reason in the ledger and classify affected equipment as unverifiable at entry.

---

# Risk 8 - Exercise Design & Detection Credibility

Phase One success hinges on blind-challenge exercises proving detection capability for seven event types: unreported arrival, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal, and reluctant operator. With a 90-day test and discrete exercise windows (proposed: 2–3 exercises per month per site), the plan yields only 5–10 trials per event type across all sites. This sample is too small to support any statistical claim about false-negative rate.

Impact: Estimated detection rate of 70–85% for planned-event types (unreported arrival, substitution) and 50–65% for unplanned types (vendor refusal, reluctant operator), with confidence intervals of ±15–20% at 95% CL due to thin sample size. If results fall in the 65–75% range, both Go and Stop are defensible, and the verdict defaults to Modify or becomes a political negotiation. If either country suspects the other gamed exercise design, the entire exercise data becomes contested.

Likelihood: High

Severity: High

## Action

Pre-register all exercise scenarios, detection success criteria and scoring rubric before the first challenge. Establish an Independent Exercise Authority (mixed-nationality staff, 5–8 personnel, funded from the USD 500 million testing envelope) to design, schedule and score all exercises without input from co-chairs or participating inspectors until execution. Each country's red team may nominate challenge types but the authority alone decides whether to execute it and when. Conduct a pilot exercise in Month 2 (2026-12-08) using a spare datacenter, running all seven event types once to validate detection procedures and scoring. Schedule 3–4 exercises per month per site during Phase One (targeting 6–8 replicates per event type per site for defensible detection rates at ±10% confidence interval). Require independent video, witness and cryptographic attestation of each exercise.

---

# Risk 9 - Site Selection & Access Parity

The plan requires 'a small, matched set of declared datacenters' with reciprocal access and functional equivalence. Matching sites across US and China is difficult: US hyperscale operators are commercial entities with independent security policies, while Chinese sites are likely state-operated with different authority structures. A US operator may deny certain areas access on commercial grounds, while a Chinese site may deny access for national-security reasons. Mismatched access creates an asymmetry.

Impact: Estimated 40–50% likelihood that the 'matched set' includes at least one pair with asymmetric access. If asymmetry is discovered during Phase One, it becomes a contested finding and invalidates the reciprocal-access parity claim. Asymmetric exercise results cannot be compared, and the final verdict is compromised. Site-selection deadlock can delay entry conditions by 2–3 months.

Likelihood: Medium

Severity: High

## Action

Conduct a pre-Phase-One reciprocal-access audit (Months -1 to 0) at candidate sites, with each country's technical team visiting the counterpart's proposed site and documenting access scope, timing and facility layouts in sealed reports. Require both co-chairs to approve the matched pairs based on the audit, with explicit certification that each pair meets 'functional equivalence' criteria (e.g., staging area ≥500 sq m, 24-hour accessible, equipment lift capacity ≥50 tons). Publish the audit results and any veto rationale. If access asymmetry cannot be reconciled, do not include that pair in Phase One; reduce the matched set rather than accept asymmetry.

---

# Risk 10 - Financial & Budgeting

The USD 5 billion budget is split into seven fixed envelopes. Every expense must map to an envelope. If a major cost overrun occurs, it consumes contingency. A contingency depletion >20% by Month 3 (2027-01-08) signals a budget crisis by Month 6 (2027-04-08).

Impact: Estimated 30–40% contingency depletion by Month 3 (2027-01-08) due to entry-condition delays and accelerated personnel deployment. If contingency reaches 50% before Month 6 (2027-04-08), the program must either reduce scope or request supplemental appropriations, introducing a veto point.

Likelihood: Medium

Severity: Medium

## Action

Establish a Joint Budget Authority (one finance officer per country) with monthly envelope reconciliation and a weekly contingency-burn dashboard visible to both co-chairs. Set escalation triggers: contingency >30% → co-chair briefing; >50% → mandatory scope-reduction planning; >75% → formal joint budget review with external audit. Front-load large fixed costs into Months -1 to 1 so contingency is spent early and remaining contingency can cover Phase-One operations. Reserve 20% of each envelope for over-runs. Conduct a full actuals-vs-budget audit at Month 3 (2027-01-08) and at Month 6 (2027-04-08) with independent auditor sign-off.

---

# Risk 11 - Political & Strategic Withdrawal

Either government can withdraw from the Consortium for reasons unrelated to Phase One outcomes: domestic political change, escalation in US–China relations, public disclosure of a security incident, or discovery of intelligence activity. A withdrawal before Phase One concludes invalidates the proof-of-concept. Domestic political pressure can build rapidly if the public perceives the Consortium as a surrender of sovereignty, capitulation to the adversary, or failure to protect national IP.

Impact: Estimated 20–30% probability of political withdrawal by either government during Months 1–6 (2026-11-08 to 2027-04-08). Early withdrawal (Months 1–2 = 2026-11-08 to 2026-12-08, entry-condition phase) costs estimated USD 200–400 million in sunk setup. Late withdrawal (Months 6–9, mid-to-late Phase One) costs USD 800M–1.2B. A public disclosure of a counterintelligence incident, security breach or IP leak can trigger withdrawal within days.

Likelihood: Medium

Severity: High

## Action

Secure written commitments from both governments at the outset that Phase One will run for the full 90 days unless a specific Stop condition is triggered. Publish a Stop condition checklist that both co-chairs agree to use, removing subjective reasons for withdrawal. Establish a public communication strategy (coordinated statements, regular briefings to legislatures, published KPI dashboards) that normalizes the Consortium and pre-empts criticism. Brief both countries' legislatures monthly on progress (declassified summary). If a domestic political event threatens withdrawal, activate an emergency co-chair summit within 5 days.

---

# Risk 12 - Disclosure & Information Barriers

The Counterpart Evidence Disclosure Tiers define what each national team sees of the other's findings and underlying evidence. Narrow tiers protect IP but force disputes into adjudication. Wide tiers allow verification but risk exposure of topology, security architecture and unrelated infrastructure. The plan requires 'bounded inspection zones and filtered evidence' but does not specify how filtering is certified independent.

Impact: Estimated 10–15 disclosure disputes in 90 days if tiered access is narrow and one side claims key evidence is being withheld. Each dispute requires dual investigation and can delay adjudication by 2–3 weeks. If filtering certification is done by the host side only, disputes multiply.

Likelihood: Medium

Severity: Medium

## Action

Establish a pre-Phase-One filter-design workshop (Month 1 = 2026-11-08) where both sides' inspectors, operators and legal advisors jointly design the evidence filters that will apply to disclosure. Document the filtering logic explicitly and certify that the filter preserves all event-relevant detail. Appoint an independent filter auditor (a qualified security or IT specialist from a third country or international organization) who validates the filters at Month 1.5 (2026-11-23) and spot-checks compliance monthly. For disputes, implement a challenge procedure: if the counterpart believes a filter is hiding evidence, they can request raw-evidence access under escort, with a log entry and dual certification.

---

# Risk 13 - Adjudication & Discrepancy Resolution

The plan identifies discrepancies but does not specify how they are adjudicated or who decides. If both co-chairs cannot agree on a discrepancy's resolution, the case remains open and the discrepancy ages. Automatic impaired-confidence status triggers if the case exceeds an age threshold, but that status is itself a contested decision if the co-chairs disagree.

Impact: Estimated 20–30 unresolved discrepancies accumulated by Month 6 (2027-04-08) if adjudication lacks a clear tie-breaker procedure. Each unresolved case stalls the ledger. At the 90-day Phase One conclusion, outstanding discrepancies complicate the Go/Modify/Stop verdict: Go requires <5 material unresolved cases (estimated threshold, TBD).

Likelihood: Medium

Severity: Medium

## Action

Establish a formal Adjudication Panel (3 senior technical specialists per country, 6 total) with binding authority over discrepancy classification only (not outcomes, sanctions or suspensions). The Panel is convened by co-chairs when a discrepancy cannot be resolved by inspectors within 10 days. Panel authority is limited to: (1) deciding which evidence category is most probative; (2) classifying the discrepancy as 'material' (affects Go/Modify/Stop verdict) or 'process' (administrative); (3) recommending a retry of the investigation if evidence gaps remain. Panel decisions are non-binding on the co-chairs but are published and logged in the ledger, so co-chairs must overturn the Panel's recommendation explicitly. Set a target: Panel convenes within 10 days of case opening, renders a recommendation within 5 days, and co-chairs decide within 3 days. Any case exceeding 28 days total becomes an automatic impaired-confidence flag.

---

# Risk 14 - Statistics & Verdict Credibility

The final Go/Modify/Stop verdict is based on exercise detection rates, false positives and negatives, unverifiable-equipment count, and parity metrics. The plan provides no formula for converting binary outcomes into a final verdict. If detection rates are 75% (borderline), false positives are 8% (acceptable) and unverifiable equipment is 3% (low), the verdict could be Go, Modify or Stop depending on how the scorecard weights these factors.

Impact: Estimated 40–60% likelihood that final-verdict thresholds are ambiguous or disputed by one or both governments. If results fall in the ambiguous range, the verdict can be justified as Go, Modify or Stop using different weighting schemes. A Modify verdict is the likely default if outcomes are ambiguous, but it commits both countries to Phase Two without clarity on what Phase Two should achieve.

Likelihood: High

Severity: Medium

## Action

Pre-register verdict thresholds before the first Phase One exercise, published in a joint bilateral memorandum locked by both co-chairs. Thresholds must include: (1) minimum detection rate per event type (proposed: ≥70% for planned events, ≥50% for unplanned); (2) maximum false-positive rate (proposed: ≤10%); (3) maximum unverifiable-equipment share (proposed: ≤5%); (4) minimum reciprocal-access parity score (proposed: ≥85%); (5) maximum unresolved-discrepancy age at Phase One conclusion (proposed: ≤21 days). Outcomes ≥80% of Go thresholds → Go. Outcomes 50–80% → Modify. Outcomes <50% → Stop. Conduct the pilot exercise (Month 2 = 2026-12-08) to test whether thresholds are calibrated realistically. Adjust only if pilot data shows material miscalibration (>30% deviation from expected range), and publish the adjustment justification. At Phase One conclusion (Month 9 = 2027-07-08), score results against the locked thresholds with an independent auditor sign-off.

---

# Risk 15 - Asymmetric Operator Compliance & Shielding

US hyperscale operators are commercial entities with competitive incentives and contractual customer relationships. Chinese frontier-computing sites are likely state-operated. A US operator can cite customer confidentiality or competitive harm to resist Consortium access, while a Chinese site cannot resist but can obscure or delay access through bureaucratic friction. Asymmetric compliance undermines the reciprocal-access parity claim.

Impact: Estimated 20–30% likelihood of asymmetric operator resistance. If a US operator refuses to open a maintenance area without 72-hour notice (vs. immediate access at the Chinese site), detection of unreported substitution during maintenance is impossible at that site. A detection-rate gap >10% per matched pair is a potential Stop condition.

Likelihood: Medium

Severity: High

## Action

At the entry-condition stage (Months 0–2 = 2026-10-08 to 2026-12-08), conduct joint operator-compliance workshops at each participating site, with both co-chairs' representatives, inspectorate leaders and operator executives present. Establish baseline expectations: (1) immediate access to staging areas (within 4 hours of request); (2) cooperative scheduling of exercise windows (48-hour advance notice required, unless testing unreported-arrival scenarios); (3) staff availability for questions during and after exercises; (4) confidentiality agreements for sensitive equipment specs. Require written commitments from each operator. Test compliance with a dry-run exercise at each site at Month 2 (2026-12-08). If an operator refuses baseline access, do not include that site in Phase One; substitute a more-cooperative site. Asymmetric resistance is the Stop trigger.

---

# Risk 16 - Schedule Amendments & Coverage Drift

The confidential, versioned technical schedule of covered equipment must remain technology-neutral. Hardware generations, form factors and performance metrics change during Phase One. The schedule must be updated to stay current, but each amendment is a double-key decision and a source of scope dispute. If the schedule drifts toward older, more easily verifiable equipment, the test becomes less relevant. If it drifts toward newer, harder-to-verify equipment, unverifiable-equipment counts surge.

Impact: Estimated 5–10 schedule-amendment disputes in 90 days if amendments are handled ad-hoc. Each dispute consumes 1–2 weeks of co-chair negotiation. If amendments are frozen, the schedule becomes obsolete by Month 6 (2027-04-08), new frontier equipment is unverifiable by default, and results become less credible.

Likelihood: Medium

Severity: Low

## Action

Establish a Covered-Equipment Schedule Review Cadence before Phase One begins: fixed update points at Months 3, 6 and 9 (2027-01-08, 2027-04-08, 2027-07-08), with no amendments between these points. Each update is a double-key decision but is scheduled and anticipated, not ad-hoc. During each review, both sides' accountable specialists propose amendments based on equipment arrivals and departures observed in the prior period. Amendments become effective only for events recorded after the effective date; prior events remain classified under the prior schedule version. Document the version history in the ledger. If a major mid-test technology shift makes the current schedule manifestly obsolete, convene an emergency review at Month 4.5 (2027-02-23), with both sides' agreement.

---

# Risk 17 - Neutral Facility Establishment & Staffing

Phase One requires a neutral secure facility (proposed: Geneva or Singapore) to host bilateral governance, co-chair workspace, secure reading rooms, ledger hosting, key custody and inspector debriefing. Establishing and securing this facility by Month 0 (2026-10-08) is a hard constraint. Host-country delays, security certification challenges or construction overruns can push facility readiness to Month 2–3 (2026-12-08 to 2027-01-08). Staffing requires bilingual, security-cleared personnel from both countries, plus independent facility staff.

Impact: Estimated 30–40% likelihood of 4–8 week delay in neutral-facility readiness. A delayed facility stalls co-chair coordination, forces meetings via video conference (less effective for double-key decisions), and delays key-custody ceremonies. If the facility is not ready by Month 2 (2026-12-08), entry conditions can slip by 4–8 weeks.

Likelihood: Medium

Severity: Medium

## Action

Pre-identify a neutral-facility site by Month -3 and secure host-country commitment for fast-track permitting and construction. Baseline facility needs: (1) 1,000+ sq m of secure space including co-chair boardroom, secure reading room with multi-workstation evidence-review capability, 24/7 staffed ledger-hosting center with redundant power and network; (2) physical security meeting or exceeding IAEA or OPCW standards; (3) bilingual staff (English and Mandarin) with security clearances from both countries or pre-clearance procedures; (4) network isolation from both countries' national networks. Start facility build-out at Month -2 with a pre-positioned project manager from each country and independent facility director. Conduct a security dry-run at Month 0 (2026-10-08) and a full operational test at Month 1.5 (2026-11-23). Identify backup facilities so if primary is delayed >4 weeks, migration occurs without losing time.

---

# Risk 18 - Compliance & Audit Deficiency

The plan requires independent auditing against the seven-envelope budget map and KPI dashboard verification. Auditors must be bilingual or trilingual, security-cleared, and capable of reviewing both classified evidence and sensitive financial documents. Finding or training sufficient independent auditors with the right clearances is a challenge.

Impact: Estimated 8–12 week delay in finding independent auditors and securing their clearances by Month 1.5 (2026-11-23). If audit starts late, the first quarterly reconciliation (Month 3 = 2027-01-08) is compressed, and discrepancies found then become rushed adjudications. An audit that finds 2–5% envelope discrepancies will trigger disputes if either government suspects the other misdirected funds.

Likelihood: Medium

Severity: Low

## Action

Identify independent auditors at Month -2 and secure bilateral pre-approval by Month -1. Auditors should be from a third country or international organization. Require auditors to sign a charter that commits them to publish unclassified summaries of audit findings monthly. Establish audit scope: envelope mapping (100% sampling), invoices and supporting docs (10% random sample), personnel roster and leave records (spot checks), ledger event sampling (5% of events). Conduct a financial-audit dry-run at Month 1 (2026-11-08) using Months -1 and 0 spending. Set audit timeline: invoices due by 10th of following month, audit review by 20th, findings published by 25th, disputes closed by end of month.

---

# Risk 19 - Interdependencies & Cascading Failures

The plan has multiple critical interdependencies: entry conditions gate the 90-day Phase One clock; exercise outcomes inform the verdict thresholds and final decision; ledger integrity depends on key custody and synchronization; equipment-identity confidence depends on evidence weighting and disclosure tiers; vendor refusal fallback depends on independent-examiner availability; and adjudication depends on deadlock procedures. A failure in any one area cascades: a delayed entry condition delays Phase One, compressing the test window and producing thin statistical data; a key-custody incident stalls the ledger; a vendor-refusal cascade stalls site preparation. The program has few redundancies.

Impact: Estimated 30–50% probability of at least one significant cascade incident by Month 6 (2027-04-08). Each cascade adds 2–4 weeks to the timeline and consumes 5–10% of contingency budget. If cascades are not caught and resolved early, they compound, potentially making Phase One operationally infeasible by Month 9 (2027-07-08).

Likelihood: High

Severity: Medium

## Action

Establish a Program Risk Dashboard (updated weekly Month 0–3 = 2026-10-08 to 2027-01-08, bi-weekly Month 4–9 = 2027-02-08 to 2027-07-08) tracking leading indicators of cascade risk: (1) entry-condition milestone burn-down (% complete vs. target); (2) key-custody ceremony readiness; (3) vendor-refusal count and fallback-method availability; (4) discrepancy-age distribution (% open >14 days, >21 days, >28 days); (5) ledger-divergence incidents (count and resolution time); (6) contingency-burn rate (% spent vs. elapsed time); (7) inspectorate-staffing fill rate (% deployed vs. planned). Escalation rules: any indicator >2 std devs from target triggers a co-chair alert within 48 hours; three or more alerts simultaneously activate an emergency joint review. Assign a dedicated Program Risk Officer (one per country, co-reporting to co-chairs) with authority to call emergency meetings and to recommend scope reductions if cascades appear irreversible.

---

# Risk Summary

The Consortium is an unprecedented bilateral US–China arms-control-style verification mechanism with extreme complexity, high political risk and thin operational data. Phase One is a 90-day test of frontier-computing equipment change verification at declared sites, with a USD 5 billion budget and mirrored national inspectorates. Critical risks center on: (1) entry-condition deadlock before operations begin, blocking the 90-day clock; (2) asymmetric access, operator shielding or evidence withholding that undermines reciprocal credibility; (3) thin detection statistics that make final Go/Modify/Stop verdicts undefendable; (4) ledger divergence or key-custody disputes that create unresolvable evidence conflicts; and (5) IP exposure or production disruption that alienates operators and governments mid-test. Success depends on strict entry-condition enforcement, reciprocal transparency in exercises and adjudication, and honest statistical reporting that foregrounds limits and provisional status.

# Make Assumptions
# Question 1 – Contingency Spending Prioritization Under Entry-Condition Delays

## Funding & Budget Risk Mitigation

Contingency allocation strategy under entry-condition delay scenarios and mid-Phase-One cost pressures.

- Entry-condition completion target: Month 3 (2027-01-08), with 2–4 week slippage per gate
- If total entry-condition delay exceeds 8 weeks, contingency depletion reaches 15–20% by Month 4 (2027-02-08)
- Estimated entry-condition delay costs: 5–10% of contingency (USD 250–500M) before Phase One operations
- Budget envelope: operator compensation charged to each government's contribution (USD 2.5B); shared expenses (ledger, facilities, personnel, testing, legal, contingency) from USD 5B pool
- Trade-off rules must pre-exist to prevent mid-test budget disputes

## Assumptions

- Entry-condition delay risks: signed instrument, domestic authority, site selection, inspector approval, vendor participation, covered-equipment schedule
- If single-envelope overrun occurs (e.g., neutral-facility construction exceeds site-prep allocation), pre-existing trade-off hierarchy applies

## Recommended Action

Front-load all fixed-cost envelopes (neutral facility, key custody ceremonies, auditor clearances, personnel recruitment) into Months -2 to 1, consuming 40% of contingency early to confirm actual costs vs. estimates by Month 1 (2026-11-08). Reserve 60% contingency for Phase-One surge (estimated 10–15 personnel per-country deployments, accredited independent-examiner mobilization, ledger-recovery procedures).

- Envelope trade-off hierarchy: contingency covers overgas; any envelope exceeding 110% of plan triggers co-chair review; >120% requires supplemental appropriations (stop-work veto point)
- Monthly envelope reconciliation (independent auditor) against locked USD 5B allocation
- Unclassified monthly summaries prevent either government from claiming financial surprise

---

# Question 2 – Matched Set of Declared Datacenters and Reciprocal-Access Parity

## Timeline & Milestones Entry-Condition Validation

Site-selection and reciprocal-access parity audit process and schedule.

- Functional equivalence definition: staging ≥500 sq m, 24-hour accessible, equipment lift capacity ≥50 tons, maintenance schedule ≥2 events per month per site (proposed)
- Matched set: 2–4 paired sites (4–8 total facilities), one per country per pair
- Reciprocal access: each country's inspectors have equivalent timing and area scope
- Parity validation: pre-Phase-One audit (Months -1 to 0, compressed into Month 0 = 2026-10-08 if timeline pressures)
- Asymmetric access at entry is a gate failure; mismatched sites are excluded, not included with a footnote

## Critical Path

- Site nominations: Month 0.5 (2026-10-23)
- Reciprocal-access audit: Months -1 to 0 (compressed into Month 0 = 2026-10-08 if needed)
- Audit reports: Month 0.5 (2026-10-23)
- Co-chair reconciliation of mismatched sites: Month 1 (2026-11-08)
- Final matched-pair approval: Month 1.5 (2026-11-23)
- Risk: reciprocal-access audit revealing >1 asymmetric pair likely causes 2–4 week delay

## Mitigation

Pre-identify 4–6 candidate sites per country (Month -2) and run audit in parallel with diplomatic negotiations to accelerate approval.

## Milestone Success Metric

Matched-pair approval locked by Month 1.5 (2026-11-23), with explicit co-chair certification of functional equivalence and access parity. Phase One clock cannot start without this gate completion.

---

# Question 3 – Mirrored National Inspectorates Recruitment, Training and Deployment

## Resources & Personnel Deployment

Full-time inspectorate staffing model, training timeline and coverage sustainability.

## Staffing Model

- Estimated personnel per country: 150–200+ across multiple sites, 24/7 shifts
- Minimum on-site staffing: 4–6 inspectors per site per shift × 3 shifts × 2–4 sites × 2 countries = 96–144 on-site at any time
- Surge buffer (20%): 19–29 additional per country
- Leave and illness coverage (30%): 29–43 additional per country
- Total per country: 144–216 personnel
- Leave rotation: 4 months on-site, 2 months off-site, staggered across cohorts
- Single-person critical functions forbidden; minimum of 2 assigned personnel with overlapping shifts for all duties

## Timeline

- Recruitment begins: Month -3 (before Phase One entry conditions finalize)
- Vetting and security clearances: Month -1
- Training academy starts: Month -1 with joint US–China curriculum (2–3 weeks)
- Full deployment target: Month 2.5 (2026-12-23)
- Critical risk: 10–15% personnel availability shortfall in Month 3 (2027-01-08) due to incomplete training or vetting

## Mitigation

- Concurrent recruitment-vetting-training tracks (vetting begins Month -3 while recruitment ongoing; training starts Month -1 with first cohorts while later cohorts vetting)
- Pilot training exercise Month 1 (2026-11-08) using historical datacenter records to validate training efficacy and identify shortfalls
- Retention bonuses (estimated 2–3% additional cost within USD 750M personnel envelope) for 12-month commitment through Phase One conclusion

## Coverage Model

- Baseline for small matched set: 6 inspectors per shift (2 countries × 3 inspectors each) × 3 shifts × 2–4 sites = 36–72 baseline per country
- 20% surge = 7–14 additional
- 30% leave = 11–22 additional
- Total = 54–108 per country baseline
- Estimated monthly personnel cost (fully loaded, with surge and leave): USD 5–8M per country (total USD 10–16M/month), consuming ~USD 120–192M over 90 days within USD 750M envelope

---

# Question 4 – Double-Key Governance Deadlock Resolution

## Governance & Regulations Deadlock Resolution

Equal co-chair decision-making framework without casting vote, automatic escalation and public transparency.

## Deadlock Procedures

- Automatic partial suspension after 14 days of impasse, affecting only disputed function while unrelated verification continues
- Automatic impaired-confidence status triggers at 21 days (open for identity disputes), 28 days (exit dispositions)
- If age threshold itself becomes disputed, tertiary referee procedure applies: independent technical panel (3 specialists per side, 6 total) issues advisory recommendation within 5 days; co-chairs have 3 days to accept or override (with published rationale)
- No casting vote exists; if co-chairs still deadlock after panel review, case escalates to automatic partial suspension and public ledger annotation
- Estimated deadlock frequency: 3–5 substantive deadlocks in 90 days across 2–4 sites

## Partial-Suspension Model

- Each 14-day partial suspension removes one disputed function from operations (intake verification paused, exit procedures paused, or equipment-identity adjudication paused) while continuous monitoring of other sites continues
- Preserves operational continuity; estimated total Phase-One delay if all 5 deadlocks max suspension period: 2–3 weeks

## Recommendation

- Pre-approve advisory-panel charter and independent-panel specialist roster as entry conditions for immediate convening
- Age thresholds (14, 21, 28 days) locked in bilateral memorandum before Phase One starts
- Threshold-compliance disputes resolved by independent timekeeper (dedicated staff from neutral facility, tracking bilateral clock)
- Public ledger annotation of every partial suspension creates political pressure for timely resolution and provides audit trail for final verdict

---

# Question 5 – Live Challenge Exercises Design, Execution and Scoring

## Safety & Risk Management Exercise Credibility

Blind-challenge exercise design, independence and detection-rate validation under realistic operational conditions.

## Exercise Authority and Design

- Independent Exercise Authority (mixed-nationality staff, 5–8 personnel, funded from USD 500M testing envelope) designs, schedules and scores all exercises without input from co-chairs or participating inspectors until execution
- Each country's red team may nominate challenge types but cannot control selection or timing
- Events run in staging, spare-inventory, maintenance or expansion areas without interrupting active computation

## Exercise Load and Replication

- Target exercise load: 3–4 exercises per month per site (9–12 total per month across 2–4 sites)
- Goal: 6–8 replicates per event type across all sites in 90 days (45–60 total exercises)
- Scoring by independent video, witness and cryptographic attestation; no retroactive claims credible
- Sample size <5 per event type insufficient (insufficient statistical power); 6–8 replicates per type per site over 90 days provides 50–80 total data points at ±10–15% confidence interval (95% CL)

## Event Types and Pilot Exercise

- Seven event types: unreported arrival, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal, reluctant operator
- Pilot exercise (Month 2 = 2026-12-08) tests all seven event types once at a test facility (not a production site) to validate detection procedures before Phase One
- Pilot exercise validates that exercises can run without production disruption; operators must grant access to staging/spare areas and tolerate instrumented equipment moves
- If operators refuse pilot-exercise cooperation, Phase One site selection fails

## Exercise Script and Execution

- Each exercise fully scripted before execution: scenario description, success criteria (detected within N hours), expected inspector actions, witness assignments
- Scenario secrecy essential; if inspectors know a challenge is scheduled, they adjust behavior, rendering detection rates unrepresentative

## Independence and Reporting

- Exercise Authority reports to neither co-chair; findings published to both simultaneously
- Any co-chair contest requires a formal double-key challenge (rare, documented, logged)
- Exercises are the only direct detection evidence; verdict thresholds pre-registered and applied mechanically to results, not negotiated post-hoc

---

# Question 6 – Environmental and Workload Protection Information Barriers

## Environmental Impact Data Protection

Evidence filtering, information barriers and vendor-refusal fallback procedures to protect sensitive technology and infrastructure.

## Inspector Information Firewall Doctrine

- Compartmentalizes knowledge by role and site with post-rotation debriefs and monitored cooling-off periods before reassignment
- Sealed observation-and-report model: inspectors hold only filtered evidence packages; raw observations retained in site custody for audited review only
- Filters remove IP addresses (hashed), network paths (redacted), maintenance-provider identities (blinded), model weights, customer lists and security architecture details
- Filters co-designed by both sides' teams and audited by independent certifier at Month 1.5 (2026-11-23) and monthly thereafter

## Vendor Refusal Fallback Ladder

- Vendor-supervised testing → filtered evidence → accredited independent examiners → clean-room procedures → validated attestations
- If vendor refuses all rungs, equipment is classed unverifiable
- Access to raw evidence granted only under dual escort in joint secure reading room, with no copying or retention allowed
- Estimated vendor-refusal incidents: 2–4 per 90 days

## Filtering Operations and Risks

- Filtering adds latency (2–3 days per evidence package prepared and certified) but essential to prevent IP leakage
- Risk: if filters too aggressive, event-relevant detail removed, raising unverifiable-equipment counts by 10–15%
- Mitigation: independent filter auditor validates that filters preserve all event-relevant data (timestamps, equipment identifiers, arrival/departure records, maintenance logs) while removing unrelated details
- Filter disputes (counterpart claims key evidence hidden) resolved by dual-escort secure-room access, adding 3–5 days per dispute

## Fallback Procedures

- Each fallback consumes 8–12 weeks (clean-room exam or independent-examiner validation)
- Multiple simultaneous vendor refusals can stall site preparation
- Mitigation: pre-stage one accredited independent-examiner team per country by Month 0 (2026-10-08), funded from USD 500M testing envelope, so fallback procedures activated immediately if vendor refuses
- Vendor-refusal fallback ladder stress-tested during pilot exercise (Month 2 = 2026-12-08)

---

# Question 7 – Phase One Success Criteria and Go/Modify/Stop Verdict

## Stakeholder Involvement Verdict Credibility

Pre-registered thresholds, statistical rigor acknowledgment and bilateral confidence-building in Phase One outcomes.

## Provisional Success Thresholds

Thresholds marked TBD (to be validated post-hoc against pilot-exercise data at Month 2 = 2026-12-08):

- Detection rate ≥70% for planned events (unreported arrival, substitution), ≥50% for unplanned (vendor refusal, reluctant operator)
- False-positive rate ≤10%
- Unverifiable-equipment share ≤5%
- Reciprocal-access parity ≥85%
- Maximum unresolved-discrepancy age ≤21 days at Phase One conclusion

## Stop Triggers

- Asymmetric inspector access
- Material unverifiable equipment (>5–10%)
- Evidence ledger divergence without resolution
- One country shielding an operator
- Funding withholding

## Verdict Outcomes

- ≥80% of threshold targets → Go
- 50–80% → Modify
- <50% → Stop
- Ambiguous outcome zones (65–80% detection rate) handled by default Modify trigger, avoiding false Go claims on marginal results

## Threshold Validation and Lock

- Thresholds must be locked before first Phase One exercise (Month 3 = 2027-01-08) to prevent post-hoc bargaining
- Thin data (6–8 trials per type) is normal for proof-of-concept test; confidence intervals ±10–15% (95% CL)
- Pilot-exercise validation (Month 2 = 2026-12-08) refines thresholds; if pilot detection rate differs from assumption (e.g., unreported arrival 85% vs. assumed 70%), threshold can be recalibrated to 75%
- Go requires <5 open discrepancies at conclusion and ≥70% detection rates across all event types

## Verdict Scoring and Publication

- Independent auditor with both co-chairs present
- Results published unclassified (detection rates, thresholds met or missed, Go/Modify/Stop conclusion) so legislatures and public see objective outcome
- Phase One covers only monitored changes at participating declared sites; does not estimate total computing capacity, verify workloads, or prove absence of hidden facilities

---

# Question 8 – Replicated Tamper-Evident Ledger and Cryptographic Attestation

## Operational Systems Ledger Architecture

Replicated tamper-evident ledger, event recording, synchronization bounds and key custody procedures.

## Ledger Architecture

- Replicated: each country hosts its own national copy in secure, audited facility (or in neutral facility with dual-custody key material)
- Events recorded locally at each site with timestamps and witness signatures
- Immediate entry into national ledger copy (latency <1 hour)
- Synchronized digests (cryptographic hashes of recorded events) exchanged between national copies every N hours (proposed bound: 1-hour interval for routine events, escalation triggers at 30 minutes)
- Divergence detected by failed digest match; escalates to double-key co-chair review and adjudication

## Key Custody

- Dual-hold: each country holds non-reconstructable share of signing keys; both shares required for ledger entry signing or attestation validation
- Alternative: mirrored independent signing hierarchy per country, cross-certified through audited exchange
- Lost or contested signing key triggers key-recovery ceremonies, stalling ledger entries for 8–24 hours pending both countries' agreement on key revocation and new-key generation
- Key-recovery ceremonies scheduled at Months 1.5 and 5 (2026-11-23, 2027-03-08) with full rehearsal, deputy key-custody officers, pre-approved key-revocation procedures

## Ledger Integrity Risks and Mitigation

- Synchronization latency >1 hour creates windows for undetected local tampering (mitigation: escalation triggers at 30 min, redundant digest verification)
- Ledger divergence (missing event in one copy) requires 2–7 days to resolve through double-key adjudication (mitigation: automated divergence detection, immediate co-chair notification, pre-approved resolution procedures)
- Estimated ledger-divergence incidents: 10–15 in 90 days if synchronization latency is 4+ hours and event volume is 5–10 per day per site
- Each incident adds 2–7 days to evidence validity

## Recommended Synchronization Architecture

- Local recorder at each site (hardware module, tamper-sealed) stores events with cryptographic timestamp and witness signature
- Periodic batch sync (hourly) of signed digests to both national copies via monitored network
- Any digest mismatch triggers automatic dual-ledger audit and co-chair escalation within 4 hours
- Secondary asynchronous audit trail for events exceeding 1-hour sync bound, re-syncing when connectivity restored, with ledger flag marking delayed sync

## Operational Cost

Estimated ledger-hosting operational cost: USD 20–30M (within USD 1.25B ledger-and-attestation envelope).

# Distill Assumptions
# Project Overview

## Entry Conditions
Bilateral instrument signature, appropriations, domestic authority, site selection, inspector approval, vendor participation, and covered-equipment schedule must be completed before Phase One operational test begins.

## Budget
USD 5 billion total, split 50/50 between countries (USD 2.5 billion each); domestic operator compensation charged to each government's contribution.

## Budget Allocation

- Ledger/attestation/communications: USD 1.25B
- Site preparation/operator compensation: USD 1B
- Inspectors/personnel/training: USD 750M
- Facilities/cybersecurity/counterintelligence: USD 750M
- Testing/exercises/red teams: USD 500M
- Legal/auditing: USD 250M
- Contingency: USD 500M

## Governance

- Equal national co-chairs with double-key authorization
- No casting vote
- Predefined deadlock, impaired-confidence, and automatic-suspension procedures

## Mission Scope
Verification of declared-equipment changes only. Does not include estimates of total computing capacity, workload verification, model-weight inspection, or hidden-facility detection.

# Site Configuration

## Matched Sets
Estimated 2–4 paired sites (4–8 total). Reciprocal-access parity validated as entry condition. Asymmetric access excludes sites from verification.

# Inspectorates

## Personnel Structure
Estimated 144–216 personnel per country; 24/7 shifts; minimum 4–6 inspectors per site per shift; 20% surge buffer; 30% leave coverage.

## Recruitment and Deployment Timeline

- Recruitment begins Month -3
- Vetting and clearances Month -1
- Training Month -1 to Month 2 (2026-12-08)
- Deployment target Month 2.5 (2026-12-23)

## Inspector Information Firewall
Compartmentalized by role and site with post-rotation debriefs and cooling-off periods before reassignment.

# Evidence and Verification

## Layered Evidence Rule
Confidential, rotating rule designed by accountable specialists from both sides and validated against blind-exercise outcomes. No single evidence source is decisive.

## Evidence Sources

- Attestation
- Physical inspection
- Customs/shipment records
- Identifiers
- Maintenance logs
- Infrastructure changes
- Witnessed movement

## Vendor Refusal Fallback Ladder

- Vendor-supervised testing
- Filtered evidence
- Accredited independent examiners
- Clean-room procedures
- Validated attestations

# Blind-Challenge Exercises

## Event Types

- Unreported arrival
- Substituted equipment
- Inaccurate records
- Delayed access
- Disputed identity
- Vendor refusal
- Reluctant operator

## Exercise Authority
Mixed-nationality, independent, 5–8 personnel; designs, schedules, and scores all exercises. Each country's red team tests what it doubts most.

## Timeline and Targets

- Pilot exercise Month 2 (2026-12-08) tests all seven event types once at non-production facility
- Phase One target: 6–8 replicates per event type (45–60 total exercises)

# Verdict Framework

## Verdict Thresholds
Pre-registered and marked provisional or TBD with validation path; locked before first Phase One exercise.

## Provisional Thresholds (proposed)

- Detection rate: ≥70% planned events, ≥50% unplanned
- False-positive rate: ≤10%
- Unverifiable equipment: ≤5%
- Reciprocal-access parity: ≥85%
- Unresolved discrepancies: ≤21 days

## Decision Logic

- ≥80% thresholds met → Go
- 50–80% → Modify
- <50% → Stop

## Stop Triggers

- Asymmetric inspector access
- Material unverifiable equipment (>5–10%)
- Ledger divergence without resolution
- Government shielding of operator
- Funding withholding

# Ledger and Record Management

## Replicated Ledger
Independent national copies; events recorded locally within 1 hour; digest synchronization every 1 hour. Divergence escalates to co-chair review.

## Key Custody
Dual-hold (non-reconstructable shares) or mirrored (independent hierarchies, cross-certified). Lost key stalls entries 8–24 hours pending recovery.

# Review Assumptions
# Bilateral Arms-Control Verification & International Governance
## Expert Review: Critical Missing Assumptions and Mitigation Priorities

## Domain-Specific Considerations

- Double-key governance without casting vote under asymmetric trust and strategic ambiguity
- Detection credibility and statistical rigor under thin operational data (90-day window, 6–8 event samples per type)
- Reciprocal transparency versus protection of frontier computing IP and unrelated infrastructure
- Operational feasibility of 24/7 mirrored inspectorates across adversary borders under full counterintelligence exposure
- Transition from Phase One proof-of-concept to Phase Two commitment without credible interim verdict

## Issue 1: Entry Conditions Stalling

Phase One clock starts only after six sequential gates: signed bilateral instrument, appropriations, domestic authority, matched-site selection, inspector approval, vendor participation, and covered-equipment schedule. No parallel-track acceleration is proposed. Entry-condition delays compound: site-selection disputes can stall for 6–8 weeks; vendor-participation deadlock forces fallback-ladder negotiations, consuming 4–6 weeks. Estimated total timeline: 12–16 weeks.

If completion slips to Month 4 (2027-02-08), Phase One operationally runs Months 4–7 (2027-02-08 to 2027-05-08), compressing by 4 weeks from planned Months 3–6 (2027-01-08 to 2027-04-08). Thin detection statistics worsen: 6–8 event replicates per type become 4–5, reducing statistical power and widening confidence intervals from ±10–15% to ±15–20% (95% CL). Final verdict thresholds become more ambiguous, and Stop credibility weakens.

### Recommendation

- Establish pre-Phase-One entry-condition task force with binding timelines and external escalation authority
- Hard deadlines: bilateral instrument signature Month 0.5 (2026-10-23); domestic authority Month 1 (2026-11-08); site nominations Month 1 (2026-11-08); site-selection audit Month 1.5 (2026-11-23); inspector selections Month 2 (2026-12-08); vendor participation Month 2.5 (2026-12-23); schedule adoption Month 3 (2027-01-08)
- Conduct site-selection and vendor-participation negotiations in parallel (not sequentially) starting Month -1
- Pre-identify 4–6 candidate sites per country by Month -2; vendor outreach begins Month -2 (written commitments required by Month 1 = 2026-11-08)
- Activate emergency co-chair summit and publish public timeline if any gate slips >2 weeks
- Reserve USD 50–100M (5–10% of contingency) for compressed negotiation timelines
- If entry conditions cannot complete by Month 3 (2027-01-08), publicly announce scope reduction (fewer matched sites, shorter test window from 90 to 60 days) rather than stretching timeline

### Sensitivity

Baseline: Phase One start Month 3 (2027-01-08), 90-day test duration, 45–60 total exercises, 6–8 replicates per event type, confidence intervals ±10–15% (95% CL).

Scenario 1: 4-week delay (Month 4 = 2027-02-08 start) → test runs 60 days, 30–40 exercises, 4–5 replicates per type, confidence intervals widen to ±15–20%, final verdict becomes ambiguous.

Scenario 2: 8-week delay (Month 5 = 2027-03-08 start) → test runs 32 days, insufficient operational time for pilot exercises, Phase One becomes infeasible, contingency consumed (estimated USD 100–200M), supplemental appropriations required.

Scenario 3: 12-week delay (Month 4.5 = 2027-02-23 start) → sunk entry-condition costs estimated USD 300–500M, Phase One reduced to 45 days, test ceases to be credible proof-of-concept.

## Issue 2: Evidence Ambiguity Under Equal Co-Chairs Deadlock

The design specifies a confidential, rotating Layered Evidence Weighting Model combination rule set by accountable specialists and validated only post-hoc against blind-exercise outcomes. The rule is locked before Phase One (Month 3 = 2027-01-08) but its accuracy is unknown.

If the rule is too strict (requires corroboration from 4+ evidence layers), false-positive rates surge to 20–30%, unverifiable-equipment counts spike, and adjudication load exceeds inspectorate capacity (estimated 10–15 cases per month vs. 50+ generated). If too loose, gaming becomes possible: an operator can learn which evidence categories weigh most by watching adjudication patterns and engineer evidence to pass the rule.

Disputes over rule validity are unresolvable within the double-key framework (no tie-breaker, no appeal to external authority), so the evidence basis for the entire verdict becomes suspect.

### Recommendation

- Publish the confidential evidence-weighting rule in versioned escrow locked by both co-chairs by Month 1.5 (2026-11-23), three months before first Phase One exercises
- Conduct pilot-validation exercise at Month 2 (2026-12-08) using historical equipment-change records from participating sites (estimated 100–200 past events per site)
- Apply the proposed rule to historical records, calculate identity-confidence outputs, and compare against known ground truth from operator records or maintenance logs
- Target pilot results: false-positive rate within ±3% of threshold (e.g., if threshold is ≤10%, pilot should produce 7–13%), false-negative rate <5%
- If pilot shows material miscalibration (e.g., 25% false positives vs. 10% target), adjust the rule and re-validate with a second cohort before Phase One begins
- Maintain a versioned rule-change log: every amendment is double-key approved and timestamped; every evidentiary output shows which rule-version was applied
- Document rule-validation uncertainty explicitly in final verdict: if confidence intervals for detection rates include Go/Modify/Stop thresholds, default verdict is Modify, not Go

### Sensitivity

Baseline: proposed rule targets 10% false positives, 5% false negatives over 45–60 Phase One exercises.

Scenario 1: Rule too strict (actual false-positive rate 20–25% vs. 10% target) → 10–15 unverifiable-equipment findings per 90 days, adjudication load unsustainable, 30–50% of discrepancies unresolved at Phase One conclusion, Go verdict impossible.

Scenario 2: Rule too loose (gaming possible) → 50% likelihood either government contests rule legitimacy, rule-validity dispute consumes 4–8 weeks of co-chair negotiation, verdict delayed or invalidated.

Scenario 3: Rule validated post-hoc only (no pilot validation) → false-positive rate unknown until Month 6 (2027-04-08), corrective action impossible, contingency consumed by unanticipated adjudication costs (estimated USD 50–100M additional), Phase One credibility compromised.

## Issue 3: Thin Detection Statistics and Ambiguous Verdict Thresholds

Phase One success rests entirely on blind-challenge exercise detection rates (no continuous monitoring, no other detection mechanisms). With 45–60 total exercises across 2–4 matched sites over 90 days targeting 6–8 replicates per event type per site, each event type has only 12–32 total data points. This sample size supports detection-rate estimates at 95% confidence with ±10–15% intervals.

Pre-registered verdict thresholds (proposed: detection rate ≥70% for planned events, ≥50% for unplanned) place the threshold at or near the confidence-interval boundary. If actual detection rates fall in the 60–80% zone, the estimate is statistically ambiguous: Go, Modify and Stop are all defensible readings of the same data. Additionally, if either country suspects the other gamed exercise design, the entire exercise data becomes contested.

### Recommendation

- Pre-register verdict thresholds before the first Phase One exercise (Month 2.5 = 2026-12-23) in a joint bilateral memorandum locked by both co-chairs
- Thresholds must include explicit confidence-interval bands, not point estimates: e.g., 'Go threshold: detection rate for planned events ≥75% at 90% confidence (lower bound); Modify threshold: 55–75%; Stop threshold: <55% at 90% confidence (upper bound)'
- Mark all thresholds 'provisional, validated against pilot-exercise data'
- Conduct pilot exercise at Month 2 (2026-12-08) running all seven event types once at a non-production test facility; score against draft thresholds and document adjustments
- Publish pilot results (declassified: detection rates per type, false-positive/negative rates, unverifiable counts) by Month 2.5 (2026-12-23); lock final thresholds by Month 3 (2027-01-08)
- At Phase One conclusion (Month 9 = 2027-07-08), score results using pre-registered mechanical rules: if lower bound of confidence interval exceeds Go threshold, verdict is Go; if upper bound falls below Stop threshold, verdict is Stop; otherwise Modify
- Publish unclassified verdict summary (detection rates, confidence intervals, thresholds, verdict logic)
- If thresholds fall in ambiguous zone, explicitly state that Modify commits both countries to Phase Two with credible transition criteria

### Sensitivity

Baseline: 6–8 replicates per event type, detection rate estimate 70±12% (95% CL), Go threshold ≥70%, Modify 50–70%, Stop <50%.

Scenario 1: Actual detection rate 72±13% (confidence intervals widen due to higher variance) → all three verdicts defensible, 50% likelihood of co-chair disagreement on verdict interpretation, final decision requires political negotiation (2–4 week stalling risk).

Scenario 2: Sample size compressed by entry-condition delay (4–5 replicates per type) → confidence intervals widen to ±18–22%, ambiguous zone expands to 45–85%, Go becomes indefensible statistically.

Scenario 3: One country contests exercise integrity → detection-rate dataset becomes subject to forensic adjudication (4–6 weeks), delayed verdict, Phase One conclusion passes without credible Go decision.

## Review Conclusion

The Consortium is an unprecedented bilateral US–China verification mechanism of very high complexity and political risk. Three critical missing assumptions create cascading vulnerabilities:

- Entry-condition gates lack explicit deadlines and parallel-track acceleration, risking 4–8 week slippage that compresses Phase One from 90 to 45–60 days, degrading statistical credibility
- The confidential evidence-weighting rule is locked without pre-validation, risking material miscalibration (false-positive rates 20–30% vs. 10% target) that paralyzes adjudication
- Verdict thresholds are pre-registered but statistical confidence intervals are so wide (±10–15%) that Go/Modify/Stop boundaries become ambiguous, requiring political negotiation to resolve

## Mitigation Priorities

- (A) Lock entry-condition deadlines and activate parallel negotiation tracks by Month -1, front-loading fixed costs to confirm budget realism by Month 1 (2026-11-08)
- (B) Conduct mandatory pilot-validation exercise (Month 2 = 2026-12-08) of the evidence-weighting rule against 100–200 historical events per site, with adjustment and re-validation before Phase One exercises begin
- (C) Publish verdict thresholds with explicit confidence-interval bands and mechanical scoring rules locked by Month 3 (2027-01-08), with unclassified verdict scoring and rationale at conclusion

These three actions reduce stalling risk, evidence disputes and political renegotiation of verdicts, improving Phase One credibility as a proof-of-concept.