# Purpose
and

# Domain
# Primary domain: Arms Control Verification

Secondary domains: Hardware Supply Chain Security, Treaty Law, Counterintelligence and Information Security

## Rationale

Arms Control Verification is the outcome discipline with the highest importance × specificity (25). Its mission is bilateral verification of declared equipment changes under mutual distrust. Bilateral Program Management is also an outcome but scores lower (20) and is a delivery vehicle. Treaty Law, Counterintelligence and Information Security, and the method candidates are subordinate.

## Disciplines involved

- Arms Control Verification (Importance 5, Specificity 5, outcome): Core mission is bilateral inspection and verification of declared equipment changes under mutual distrust.
- Counterintelligence and Information Security (Importance 5, Specificity 4, constraint): Protecting sensitive IP, security architecture and inspector conduct under mutual distrust is a blocking requirement.
- Distributed Ledger Engineering (Importance 4, Specificity 5, method): Replicated tamper-evident ledger with independent national copies and bounded synchronization is a core mechanism.
- Bilateral Program Management (Importance 5, Specificity 4, outcome): Owns delivery of the 90-day test, workstreams, staffing, and Go/Modify/Stop decision.
- Hardware Supply Chain Security (Importance 4, Specificity 4, method): Intake, identity verification, custody, vendor binding and attestation of computing equipment.
- Treaty Law (Importance 4, Specificity 4, constraint): Bilateral instrument, double-key governance, domestic access authority and reciprocity require legal structuring.
- Red Team Testing (Importance 4, Specificity 4, method): Blind live challenge exercises determine detection credibility and drive the Go/Modify/Stop decision.
- Public Financial Management (Importance 4, Specificity 4, constraint): Governs the 50/50 USD 5 billion appropriations, envelopes, contingency, and fiscal accountability.
- Datacenter Operations (Importance 4, Specificity 4, method): Staging, installation, maintenance, and decommissioning of equipment at declared sites without disrupting production.


# Plan Type
# Physical Locations Required

This plan requires one or more physical locations. It cannot be executed digitally.

## Explanation

The plan establishes a bilateral inspection and verification mechanism for computing equipment at declared datacenters in the United States and China. Nearly every component requires real-world presence:

- Inspectors work in shifts at sites, requiring travel, secure facilities, and mirrored national teams on the ground
- Intake Protocol checks equipment identity in controlled staging areas before installation via physical inspection, equipment identifiers, and witnessed movement
- Exit Protocol covers witnessed destruction, verified permanent disablement, and transfers between sites as observed physical acts
- Live challenge exercises run in staging, spare-inventory, maintenance, and expansion areas of operating datacenters, involving unreported arrivals, substituted equipment, delayed access, and vendor refusal
- Site preparation, operator compensation (USD 1 billion), secure facilities, and secure clean-room procedures require construction, hardware, and physical security
- The replicated, tamper-evident ledger, attestation systems, and double-key governance are digital components that depend on physical hardware, secure communications facilities, and in-person meetings of co-chairs
- Their purpose is to record and support physical events

The plan cannot be completed entirely online and benefits heavily from physical presence.

# Physical Locations
# Physical Location Requirements

- United States and China territory (one datacenter in each country or a small matched set in each)
- Declared frontier-relevant computing equipment at the datacenter
- Staging and controlled intake areas for equipment identity verification
- Spare-inventory, maintenance, and expansion bays for third-party access and live exercises
- Secure facilities for shift-based inspector teams (24/7 coverage)
- Secure communications infrastructure for replicated, tamper-evident ledger synchronization
- Facilities for operator-run evidence redaction and inspector audit
- Emergency response and rapid-call access for urgent maintenance windows
- Accessibility for bilateral meetings and adjudication activities
- Proximity to third-party maintenance, logistics and destruction facilities (for exit disposition witnessing)
- Observable parity in event frequency, staging layout, and vendor dependence (for matched-site selection)
- Sufficient complexity and third-party-access traffic to test detection credibly (at least one deliberately hard site per country)
- Operator willingness to participate and bind vendors to reporting, confidentiality and escort requirements

## Location 1: United States – Silicon Valley / San Francisco Bay Area, California

Major hyperscaler datacenter campus (e.g., within Google, Meta, or AWS regional cluster) with existing security infrastructure, staging facilities, and vendor ecosystem.

## Rationale

Datacenters in this region host frontier computing equipment, have mature staging and maintenance areas, established third-party vendor and logistics networks, secure facilities for personnel, and operator experience with bilateral agreements. Bay Area geography allows secure facility co-location for ledger, communications and bilateral operations. High equipment-change frequency and complex vendor dependencies provide realistic testing ground for detection and vendor-refusal protocols.

## Location 2: United States – Northern Virginia (Loudoun County area)

Tier-1 hyperscaler or US government contractor datacenter with existing government security clearances and facility hardening.

## Rationale

Northern Virginia hosts multiple large-scale datacenters with existing government contracts, integrated cybersecurity infrastructure, and established secure communications capabilities. Proximity to Washington DC enables bilateral government coordination. Existing personnel vetting and security protocols reduce entry-condition timeline. Government contractor experience with bilateral oversight and classified operations reduces compliance friction.

## Location 3: China – Beijing or Shanghai metropolitan region

Tier-1 state-owned or state-backed datacenter operator facility (e.g., within China Telecom, China Unicom, or Alibaba infrastructure) with government relationships and existing security hardening.

## Rationale

State-owned or aligned operators in Beijing and Shanghai have frontier computing equipment, established maintenance and staging areas, and direct government authority needed to compel participation and bind vendors. Government-backed operators facilitate Chinese government's direct political backing and domestic access authority. Shanghai's East-West geography mirrors US site accessibility for bilateral operations.

## Location 4: China – Shenzhen or Chengdu

Alternative Tier-1 state-backed datacenter with complex equipment mix and high third-party-access traffic.

## Rationale

Shenzhen and Chengdu datacenters offer geographic diversity from Beijing/Shanghai, differ in equipment profiles and vendor dependencies, and provide harder test cases for detection. Chengdu's distance from coast tests logistics and exit-disposition witnessing capabilities. Alternative selection reduces either government's ability to steer site pairing.

## Location Summary

The Consortium is a bilateral US–China verification mechanism with operations at "a small, matched set of declared datacenters" in both countries. The plan explicitly requires physical presence: shift-based inspector deployment at participating sites, controlled staging areas for equipment intake, maintenance and expansion bays, third-party escort and access areas, and secure facilities for bilateral meetings and ledger operations. Phase One cannot proceed without site selection and matching as a mandatory entry condition. No specific datacenter locations are named in the plan; site selection is deferred to a structured decision process.

# Currency Strategy
and

# Identify Risks
# Risk 1 - Regulatory & Permitting

Mandatory entry conditions (signed bilateral instrument, appropriations, domestic access authority, site approval, inspector vetting, vendor participation, equipment schedule) sit outside the 90-day clock. Delays in any condition block Phase One start indefinitely.

Likelihood: High

Severity: High

## Key Vulnerabilities

Inspector vetting (counterintelligence clearances on both sides), domestic legislation enacting legal authority to compel operator and vendor cooperation, and approval of the confidential covered-equipment schedule are most vulnerable. Neither government controls the other's administrative pace.

## Impact

Phase One clock not starting by Month 6–9 (2027-04-08 to 2027-07-08), or starting with partial entry conditions that degrade verification validity. If domestic authority legislation stalls in either parliament, the test cannot start. If inspector vetting extends beyond Month 3–4 (2027-01-08 to 2027-02-08), competing security priorities may deprioritize clearances. Estimated delay: 4–8 months per unresolved condition; total risk: 50% probability (estimate) of Month 6+ delay in starting the formal 90-day test.

## Actions

Establish a bilateral entry-conditions steering committee with both co-chairs meeting weekly starting Month 0 (2026-10-08). Decompose each condition into weekly milestones with explicit owners. Identify critical-path blockers (parliament session dates, security-clearance agency backlogs) and escalate to political leadership Month 1 (2026-11-08). Create a written fallback for any single-country delay: allow that country to begin testing on its own side with foreign observers while the other completes entry conditions, or use a pre-clock dry-run gate on non-covered equipment to surface authority gaps and buy negotiating time.

# Risk 2 - Operational

Ledger divergence: the two national replicated ledgers may record events differently, disagree on timing, or develop conflicting identity claims for the same equipment.

Likelihood: High

Severity: High

## Causes

Network latency, local time-sync failures, competing equipment-identity evidence, inspector disputes over witnessed events, and deliberate operator falsification.

## Impact

Unresolved ledger divergence lasting >7 days (estimate) escalates to automatic site suspension or Stop decision. If a critical equipment-identity dispute cannot be resolved within 3–5 days, a site may fail Phase One. Estimated impact: 20–30% probability (estimate) of at least one ledger divergence event per site; 30–50% of divergences take >5 days to reconcile if both governments contest the evidence. One unresolved divergence per 90-day test per site is plausible.

## Actions

Implement shift-boundary cross-signing by mirrored national inspectors at handover to catch divergences within hours. Establish a pre-authorized forensic team (3–5 technical staff plus counterpart) with authority to issue binding evidential findings on identity disputes within 48 hours. Maintain a neutral third-party escrow ledger record under strict double-key control, used only to arbitrate which national copy diverged. Pre-agree on a divergence-resolution hierarchy: cryptographic attestation > physical inspection + chain of custody > maintenance records > third-party logs. Run a Month 1–2 (2026-11-08 to 2026-12-08) ledger-sync stress test using non-covered equipment to validate latency bounds and forensic response before the formal clock starts.

# Risk 3 - Technical

Attestation trust root provenance: cryptographic identity attestation is one evidence layer among several, but if joint key ceremonies are compromised, delayed or rejected by either government, or if vendor-specific key material is unavailable, the entire attestation layer collapses.

Likelihood: Medium

Severity: High

## Impact

Loss of cryptographic attestation evidence layer for 5–15% of deployed equipment (estimate); reduction in equipment-identity confidence score from 90%+ to 60–70%. If joint ceremony cannot be scheduled before Month 2 (2026-12-08), ceremony delays feed back into the reciprocity gate and defer the clock. If a major manufacturer withholds attestation hooks, all chips from that vendor become dependent on physical inspection + third-party logs + clean-room testing, lengthening verification time by 2–4 weeks per batch.

## Actions

Pre-qualify a shared neutral location and ceremony procedures by Month 0.5 (2026-10-23), with both governments signing off on physical security, logging and audit controls. If either government objects to a joint facility, immediately trigger a two-independent-national-roots contingency in which each government maintains its own attestation root and cross-validates the other's certificates. Identify the top 5–10 manufacturers of covered equipment and pre-negotiate attestation-cooperation agreements with each, documenting the fallback route (vendor-supervised testing, accredited examiners, clean-room access) if they refuse full cooperation. Establish a pre-qualified independent-examiner pool (3–5 labs per country) with access agreements signed before Month 1 (2026-11-08).

# Risk 4 - Financial

Budget appropriations and spending pace misalignment: each country controls its USD 2.5 billion share domestically, but domestic operators and vendors are paid from the national budget share, creating split-currency and governance complexity.

Likelihood: Medium

Severity: Medium

## Impact

Site preparation delays of 2–4 weeks if operator compensation budgets are not cleared by Month 2 (2026-12-08). A 10–15% budget variance (estimate) in either country's domestic spending could reduce personnel deployment, equipment staging preparation, or third-party vendor access agreements. If contingency funds (USD 500 million total) cannot be mobilized by both countries on short notice, critical path items could stall for 1–2 weeks. Estimated impact: 25% probability (estimate) of a 2–4 week site-readiness delay due to budget execution; 15% probability (estimate) of contingency-activation friction.

## Actions

Establish a bilateral budget-execution working group meeting bi-weekly from Month 0 (2026-10-08), with spending plans from each country broken into monthly milestones. Create a contractual obligation that each government funds its approved budget within 45 days of fiscal-year start, with automatic penalties or rephasing if delays occur. Pre-authorize a joint contingency-access committee with authority to release up to USD 50 million (USD 25 million per side) on a joint signature within 5 business days for emergency repairs, ledger restoration, or exercise escalation. Separate operator compensation (paid to national entities by each government) from program overhead, and have both governments audit their own spending monthly.

# Risk 5 - Technical

Vendor refusal cascade: if one or more critical manufacturers refuse to cooperate with evidence-gathering, equipment-identity verification, or maintenance reporting, the fallback routes may be unable to produce sufficient evidence.

Likelihood: Medium

Severity: High

## Impact

One or two major vendor refusals (estimated 15–25% probability per site over 90 days) could classify 5–15% of deployed equipment as unverifiable. If a site accumulates >10% unverifiable equipment, the plan permits a site to fail Phase One. Estimated cascade risk: 20–30% probability (estimate) that at least one site faces a material vendor-refusal outcome during the test, potentially failing Phase One for that site.

## Actions

Pre-qualify and bind critical vendors via legal agreements signed before Month 1 (2026-11-08), requiring participation in equipment-identity verification, maintenance reporting, and evidence-preservation under penalty of non-renewal of service contracts at the participating site. Establish a vendor-escalation protocol: (1) direct request for cooperation; (2) operator mediation; (3) independent examiner or clean-room testing; (4) validated attestation fallback; (5) unverifiable classification. Pre-stage independent examiners and clean-room facilities for at least the top 3 vendors per equipment class before the clock starts. Document every refusal and its reason in the ledger under both national copies.

# Risk 6 - Operational

Inspector conduct and espionage risk: full-time mirrored inspector teams at each site create a counterintelligence exposure. Inspectors from one country may attempt to gather intelligence on the other country's equipment, operational security, or supply-chain dependencies beyond the declared scope.

Likelihood: Medium

Severity: High

## Impact

A confirmed or credibly alleged espionage incident could cause one government to withdraw consent or expel counterpart inspectors, collapsing reciprocal access and failing the test. Estimated probability: 5–10% (estimate) of at least one minor conduct incident within 90 days; 1–3% probability (estimate) of a major incident that triggers consent withdrawal.

## Actions

Establish a joint bilateral inspector-conduct committee with equal national co-chairs, empowered to investigate allegations, discipline or replace inspectors, and veto any inspector from the counterpart. Implement continuous access-log audit and counterintelligence monitoring of inspector activities, with logs shared between governments in redacted form. Pair every inspector with a host-country observer for access to sensitive areas, providing transparency and reducing temptation. Rotate inspectors across paired sites on a quarterly basis. Establish a clear conduct code signed by every inspector at induction, with zero-tolerance rules for unauthorized area access, recording, or collection. Run surprise spot audits of inspector notes and device access logs monthly.

# Risk 7 - Operational

Inspection zone boundary creep and IP exposure: the plan requires narrow, marked inspection zones limited to staging, spare inventory, and maintenance areas. Evidence must be filtered before leaving the site.

Likelihood: Medium

Severity: High

## Impact

Exposure of sensitive IP or counterintelligence data could trigger consent withdrawal or legal disputes. A single significant exposure incident (estimated 10% probability within 90 days) could cause one government to halt Phase One. Zone-boundary disputes during maintenance or third-party-access events could delay inspections by 1–3 days.

## Actions

Define the boundary as a physically marked perimeter with access-control gates logged on both national ledgers. Conduct a pre-clock boundary audit with both governments' security teams and operators present, photographing and documenting exact limits. Require operator-run evidence redaction for all departing data, with inspectors auditing the redaction step. Establish an escalation protocol: minor boundary infractions trigger a written warning; repeated or serious infractions trigger a co-chair review and potential inspector removal. Use sealed capture instruments in the zones (e.g., camera traps recording only equipment identifiers and movement) so inspectors review filtered metadata rather than entering live areas unnecessarily.

# Risk 8 - Operational

Matched site selection deadlock: identifying comparable US and Chinese datacenters that are representative, willing to participate, and acceptable to both governments is a non-trivial task outside the 90-day clock.

Likelihood: Medium

Severity: Medium

## Impact

Delay in site approval extending the entry-condition gate by 4–8 weeks (estimate). Disagreement over site difficulty, parity, and vendor mix could lower the credibility of Phase One results. Estimated risk: 30% probability (estimate) of site-selection friction extending gate by >4 weeks.

## Actions

Pre-agree on site-selection criteria by Month 0 (2026-10-08): equipment-change frequency (within 20% parity), vendor mix diversity, staging and maintenance area capacity, and operator willingness to participate. Establish a structured nomination process: each country nominates 3–5 candidates; a joint technical committee evaluates them against agreed criteria without veto power; a sealed random draw from the jointly vetted shortlist selects the final sites. Include at least one deliberately hard site on each side. Complete site selection by Month 1.5 (2026-11-23), with bilateral site-selection ratification signed by both co-chairs.

# Risk 9 - Operational

Mirrored shift roster staffing and vetting delays: the plan requires full-time mirrored national inspectors covering 24/7 shifts, plus technical, legal, counterintelligence, and adjudication personnel. Counterintelligence vetting of ~100–200 personnel per side is a slow process.

Likelihood: High

Severity: Medium

## Impact

Incomplete rosters at clock start: estimated 15–25% of planned positions unfilled. Coverage gaps during nights, weekends or leave periods could miss equipment changes or delay event response by 4–8 hours. Vetting delays of 8–12 weeks could defer clock start if entry conditions include 'all inspectors approved.'

## Actions

Initiate counterintelligence vetting of candidate inspectors by Month -2 (8 weeks before planned clock start), using pre-agreed vetting standards and expedited timelines. Identify and vet a 20–30% surge pool above planned roster strength to cover leave, illness and turnover. Conduct rapid-induction training by Month 0.5 (2026-10-23). Allow Phase One clock to start with 80% roster strength if critical positions are filled; defer low-priority roles to Month 1 (2026-11-08). Pre-identify and pre-vet a rapid-replacement pool for any inspector removed during the test.

# Risk 10 - Operational

Challenge exercise coordination and production disruption: live exercises are meant to occur in staging, spare-inventory, maintenance and expansion areas without interrupting live computation. However, exercises require coordinated operator, inspector, vendor and red-team participation.

Likelihood: Medium

Severity: Medium

## Impact

Exercises delayed or cancelled due to production-schedule conflicts: estimated 20–30% (estimate) of planned exercises (5–10 per site over 90 days) may be postponed. If an exercise disrupts live computation, the operator may refuse future cooperation. Estimated impact: 1–2 unplanned production incidents per site over 90 days; USD 100,000–500,000 per incident in operational-recovery costs (not in budget). Missed or compromised exercises reduce blind-challenge evidence quality.

## Actions

Establish a quarterly exercise schedule at Month 0.5 (2026-10-23), coordinating with each operator's maintenance windows, equipment-procurement cycles and production calendars. Reserve dedicated staging and spare-inventory areas segregated from live computation and available exclusively for exercises. Run a pre-test exercise in Month 1 (2026-11-08) at each site to validate coordination procedures. Establish an exercise-dispute resolution protocol: if an exercise causes unexpected outages, the bilateral adjudication unit investigates whether it was conducted according to plan, and compensation is paid from contingency budget if fault is shared. Cap exercises to no more than 2 per month per site.

# Risk 11 - Operational

Maintenance and third-party-access scheduling abuse: the plan requires advance notice of maintenance, repair and vendor visits, with inspectors present at start and end of windows. However, operators have an incentive to classify urgent maintenance as emergencies to bypass scheduling rules.

Likelihood: Medium

Severity: Medium

## Impact

Repeated emergency-access claims could create 5–10 unscheduled, unsupervised maintenance windows per site during the 90-day test (estimate), some hiding real equipment changes. If emergency-access audit trails are weak, distinguishing true emergencies from scheduled-work misclassifications becomes difficult. Estimated impact: 20–30% (estimate) of claimed emergencies require escalation; 5–10% are ruled abusive and trigger discrepancy escalation clocks.

## Actions

Define emergency maintenance as repairs needed to restore failed systems within 4 hours, requiring operator notification to an on-site inspector and continuous recording during the unscheduled window. Establish a post-event audit requiring operators to file a detailed report within 24 hours, with inspectors reviewing maintenance logs against the reported damage. Set a per-site cap: if any site claims >3 emergencies per month, an independent technical auditor reviews the claims; if >50% are ruled non-emergency, the operator faces escalation. Require operators to pre-stage spare parts and maintenance personnel outside emergency windows to reduce claims for true emergencies. Run monthly reconciliation audits of scheduled vs. emergency maintenance to detect abuse patterns.

# Risk 12 - Operational

Exit disposition verification gaps: the plan defines five exit dispositions (witnessed destruction, verified disablement, transfer to another site, documented release beyond monitored system, unresolved). Inspectors may not have access to third-party destruction or recycling facilities.

Likelihood: Medium

Severity: Medium

## Impact

If 20–30% of departures are recorded as 'release beyond monitored system' (estimate), and equipment secretly re-enters use unseen, detection depends entirely on later identity verification of arrivals. Blind-challenge exercises involving equipment re-entry or substitution may fail if disposition data is weak. Estimated impact: 5–10% (estimate) false-negative rate on re-entry detection if exit witnessing is weak; one undetected re-entry per site over 90 days is plausible.

## Actions

Establish a tiered exit-witnessing standard: Tier 1 (destruction/disablement) requires inspector presence at the destruction facility or independent certification from an accredited recycler; Tier 2 (transfer to another site) requires witnessed handoff and ledger entry at receiving site; Tier 3 (documented release) accepts operator sign-off with supporting vendor receipts; Tier 4 (unresolved) is used only when no evidence is available. Require operators to bind recyclers and disposal vendors to reporting agreements and evidence preservation. Pre-qualify a pool of accredited recyclers in each geography (estimate 2–3 per country) with bilateral audit rights. For a random sample of Tier 3 releases (20–30% per month), conduct post-release verification calls to the receiving party. Run blind-challenge exercises where equipment is reportedly destroyed but secretly re-enters the site, testing detection sensitivity to weak exit records.

# Risk 13 - Operational

Discrepancy escalation clock and deadlock: the plan defines fixed time limits for resolving discrepancies. Automatic suspension fires when clocks expire. However, fact-finding can take longer than allocated deadlines, and both countries may contest what counts as resolution.

Likelihood: Medium

Severity: High

## Impact

Automatic site suspension triggered by expired discrepancy clocks (estimated 3–5 unresolved items per site over 90 days), even if the mechanism is functioning. Estimated probability: 15–25% (estimate) of discrepancies exceed their fixed deadline, cascading to impaired-confidence status or suspension. One site suspension per test phase is plausible.

## Actions

Define three clock tiers: Tier 1 (24 hours) for minor record discrepancies; Tier 2 (72 hours) for medium-severity items; Tier 3 (14 days) for major issues. Allow the bilateral adjudication unit to extend any clock once by up to 50% with written reasons, but not twice. Create an independent technical referee panel (3–5 senior specialists per country) that can issue non-binding evidential opinions within 48 hours, giving co-chairs a shared factual basis for closing discrepancies before clocks expire. If a clock expires and no resolution is agreed, escalate to co-chairs for double-key decision; unilateral escalation to automatic suspension is not permitted without written co-chair sign-off.

# Risk 14 - Operational

Evidence layer weighting disputes: the plan specifies that no single evidence source is decisive; identity requires corroboration across multiple layers. However, the fixed corroboration rule may be too rigid or too loose.

Likelihood: Medium

Severity: Medium

## Impact

Contested identity findings (estimated 5–10 per site over 90 days) delay closure by 3–5 days while adjudication units debate evidence weights. One major identity dispute per site that requires co-chair resolution is plausible.

## Actions

Pre-define the corroboration rule and document the rationale before the clock starts, signed by both co-chairs. Example: Equipment identity is confirmed if (a) cryptographic attestation AND (b) physical inspection + serial-number match agree, OR (c) if attestation is unavailable, physical inspection + two independent records agree. Every identity finding must cite the specific layers used and their provenance. If a disputed identity finding arises, the bilateral adjudication unit applies the pre-agreed rule; co-chairs may not override the rule without a documented protocol change recorded in the ledger. Run a pre-test identity-verification exercise at Month 1.5 (2026-11-23) using non-covered equipment.

# Risk 15 - Operational

Provisional threshold mis-calibration: the plan requires that decision thresholds for Go/Modify/Stop be fixed and justified before the first challenge exercise. Most figures start as provisional (e.g., 'false-negative rate target: 5–10%, TBD').

Likelihood: Medium

Severity: Medium

## Impact

Early blind exercises reveal that provisional thresholds are unrealistic; real performance diverges significantly from the original targets. A Go decision based on a mis-set high threshold may not reflect real capability; a Modify decision may be forced simply to recalibrate the metrics. Estimated impact: 30–50% probability (estimate) that at least one threshold will need adjustment; 15–25% probability (estimate) that this forces a Modify outcome rather than Go.

## Actions

Conduct a pre-test calibration exercise on non-covered equipment in Month 1–2 (2026-11-08 to 2026-12-08), outside the formal 90-day clock. Use this exercise to validate provisional thresholds and adjust them based on observed performance before the blind challenges. Document every provisional figure and its source. Conduct a sensitivity analysis: if the false-negative rate is actually 2x higher than the provisional target, does the mechanism still meet the Go criteria? If a threshold needs adjustment after the calibration exercise, do so via a documented protocol change signed by both co-chairs before the formal clock starts. Classify the post-calibration thresholds as 'validated' in the ledger.

# Risk 16 - Operational

Blind-challenge realism and gaming risk: challenge exercises are meant to be blind to inspectors, but both governments can attempt to game the exercises.

Likelihood: Medium

Severity: Medium

## Impact

Exercise results appear credible but are biased by national gaming. Blind-challenge detection rates may be artificially high or artificially low. Estimated impact: 20–30% probability (estimate) that at least one side perceives exercise bias; 10–15% probability (estimate) that this triggers a formal dispute over exercise fairness, delaying the final decision by 1–2 weeks.

## Actions

Vest all exercise design, scheduling and scoring in an independent testing unit staffed by neutral technical experts from neither country, or from a third country. Require scenario peer review: before each exercise is run, both red teams review the scenario against a fairness rubric and certify that it is realistic, non-biased and comparable to exercises run against their own inspectors. Randomize exercise sequence and timing using a sealed double-key schedule so neither government knows in advance when its inspectors will be tested. Score results using a pre-agreed rubric, with both national audit teams independently scoring each result; if scores diverge, a neutral third party breaks the tie.

# Risk 17 - Operational

Asymmetric access and reciprocity breakdown: the bilateral mechanism is founded on reciprocal access. However, one country may claim national-security grounds to restrict counterpart access, or may restrict evidence-sharing.

Likelihood: Medium

Severity: High

## Impact

If one country grants narrower access than the other, reciprocal-access parity breaks down, and the counterpart may object to the Go decision or withdraw consent. One asymmetry incident per test is plausible (estimated 10–20% probability). Estimated impact: 1–3 week delay to resolve access disputes; 5–10% probability (estimate) of consent withdrawal if asymmetry cannot be resolved.

## Actions

Define reciprocal access as a core entry condition: before the clock starts, both governments certify that each country's inspectors have been granted equivalent zone access, evidence-sharing rights, and escalation authority. During the test, measure reciprocal-access parity monthly: compare the number of inspectors deployed per country, hours of zone access per inspector, events each side has documented as witnessed, and escalation items raised by each side. If parity metrics diverge by >20% (estimate), trigger a bilateral review within 5 days. Establish an automatic parity-restoration mechanism: if one side restricts access citing national security, the other side has the right to equivalent restriction on its side. Record every access restriction in the ledger with justification.

# Risk 18 - Operational

Operator withdrawal or non-compliance: participating operators must commit to binding vendors, allowing inspectors on-site, maintaining the ledger, enabling exercises, and accepting evidence redaction.

Likelihood: Medium

Severity: Medium

## Impact

Operator refusal of one protocol element requires escalation and potentially site suspension. Operator withdrawal of consent (estimated 5–10% probability per site over 90 days due to operational friction or political pressure) terminates testing at that site. Estimated impact: 1 site operational disruption or early withdrawal per test phase is plausible.

## Actions

Lock operator participation via legally binding bilateral agreements signed before the clock starts, specifying binding of vendors, inspector access, maintenance procedures and exercise participation as non-negotiable terms. Include penalty clauses (e.g., reduced future contracting, loss of equipment certification) for mid-test withdrawal or non-compliance. Establish a rapid operator-dispute resolution channel: if an operator objects to a protocol step, convene a joint bilateral operator-engagement team within 48 hours to understand the concern and propose workarounds. Pre-identify a standby alternate operator at a nearby site who has agreed to rapid deployment. Monitor operator sentiment monthly via confidential interviews with operations leadership; escalate concerns to government co-chairs before friction reaches withdrawal risk.

# Risk 19 - Regulatory & Permitting

Bilateral instrument ratification delays: the plan depends on both governments signing a bilateral instrument before entry conditions are certified. Domestic parliamentary or administrative approval may be delayed.

Likelihood: Medium

Severity: Medium

## Impact

Instrument ratification delayed by 4–8 weeks (estimate) extends entry-condition timeline and defers clock start. Disputes over instrument language may require renegotiation. Estimated impact: 20–30% probability (estimate) of ratification extending beyond Month 2 (2026-12-08).

## Actions

Complete draft bilateral instrument by Month 0 (2026-10-08) and begin simultaneous domestic approval processes in both countries immediately. Identify all domestic approval authorities and map their decision timelines. Pre-socialize controversial terms with key stakeholders in Month 0 (2026-10-08) to avoid late surprises. Establish a negotiation protocol: if either government objects to specific language, trigger a structured resolution process within 2 weeks, with escalation to co-chairs if agreement cannot be reached. Consider provisional entry on non-controversial terms while final ratification is completing, if the bilateral instrument permits it.

# Risk 20 - Operational

Ledger synchronization latency and technology failure: the replicated ledger requires bounded synchronization between national copies (target: <1 hour, TBD). Network outages, system crashes, or cybersecurity incidents could delay synchronization.

Likelihood: Medium

Severity: Medium

## Impact

Network outages or system failures causing >4-hour ledger divergence (estimated 5–10% probability per site over 90 days) trigger automatic escalation. Estimated impact: 2–4 ledger-sync escalation events per site over 90 days; each requiring 1–2 hours of bilateral technical troubleshooting. A major ledger-system failure could require recovery from backup, delaying reconciliation by 8–24 hours and triggering automatic suspension if recovery takes >7 days.

## Actions

Design the ledger system for high availability: duplicate facilities in each country connected by redundant, physically separate secure communications links. Test failover procedures monthly to ensure recovery time meets <4-hour sync-divergence tolerance. Implement continuous integrity checking: each national ledger runs cryptographic verification that the counterpart's copy has not diverged beyond bounds; divergences are logged and escalated automatically within 2 hours. Maintain secure offline backups that can restore the ledger to any point in time within 6 hours. Establish a bilateral ledger-technology working group that meets monthly. Conduct a full ledger-system resilience test in Month 0.5 (2026-10-23).

# Risk 21 - Operational

Equipment identity falsification or substitution undetected in exercises: challenge exercises are designed to test whether inspectors can detect unreported arrivals, substituted equipment, or record falsification.

Likelihood: Medium

Severity: High

## Impact

A sophisticated substitution (e.g., identical equipment with modified internals, or a substitute with altered identifiers) goes undetected in blind exercises, providing false evidence of mechanism effectiveness. Estimated impact: 5–10% probability (estimate) of one undetected substitution per site in blind exercises; if discovered during audits, it undermines the credibility of the Go decision. One major undetected-substitution discovery per test phase is plausible, potentially forcing a Modify or Stop outcome.

## Actions

Design challenge exercises to include deliberately sophisticated scenarios: internal modification with identical externals, altered serial numbers or attestation credentials, substitution during maintenance or third-party-access windows. Require independent technical experts to validate that exercises are capable of detecting such sophisticated attacks, and adjust evidence layers or detection procedures if not. Use red-team adversarial testing to probe for gaps in the detection logic. Implement cryptographic hardware-security modules or tamper-evidence seals on critical equipment. Conduct a pre-test sophistication assessment at Month 1.5 (2026-11-23): run exercises where both governments are aware of the test scenario and the adversary strategy, then compare detection effectiveness to blind exercises; large gaps suggest vulnerability to sophisticated evasion.

# Risk 22 - Technical

Attestation and cryptography vulnerabilities: the cryptographic layers may be vulnerable to attack, delay or compromise. Cryptographic root compromise could undermine the entire identity-verification foundation.

Likelihood: Low

Severity: High

## Impact

Discovery of a cryptographic weakness in attestation methods (estimated 5% probability) requires rapid key rotation and re-attestation of affected equipment, delaying Phase One by 1–2 weeks. A key ceremony failure or compromise could invalidate all attestation evidence and require fallback to physical inspection and records.

## Actions

Subject the cryptographic design to independent third-party assessment by a reputable cryptographic audit firm before Month 1 (2026-11-08). Include a pre-defined rapid-response protocol for key compromise: immediate key rotation, re-signing of all attestation records, and forensic investigation of which equipment was signed with compromised keys. Maintain offline cryptographic root backups and rehearse key-recovery procedures quarterly. Use cryptographic agility in the design so that hash algorithms, key sizes or signing methods can be upgraded without wholesale system redesign if vulnerabilities emerge.

# Risk 23 - Operational

Information asymmetry and claim disputes: if one government claims the other has violated a protocol, and the other denies it, resolution depends on evidence credibility and both governments trusting the adjudication process.

Likelihood: Medium

Severity: High

## Impact

One serious allegation of protocol violation (estimated 5–10% probability per test) triggers bilateral dispute escalation. If both governments dispute the facts, adjudication by neutral referees becomes necessary but may not be trusted by one side. Estimated impact: 1–2 weeks to resolve a serious dispute; 10–15% probability (estimate) that one side rejects the adjudication finding and escalates to political level.

## Actions

Pre-agree on evidence standards for adjudication: ledger entries, timestamped witness statements, video recordings, cryptographic signatures. Establish an independent adjudication panel (3–5 senior technical or legal figures from neutral countries or international organizations) that reviews disputed claims using the pre-agreed standards and issues binding findings. Allow limited appeal rights (e.g., one appeal per government per Phase One), but make clear that repeated disputes trigger automatic escalation to co-chairs for political resolution. Document the adjudication process and outcomes in the ledger so both governments have a shared record.

# Risk 24 - Strategic

Geopolitical escalation or political will withdrawal: the underlying bilateral relationship between the US and China could deteriorate during Phase One, causing one or both governments to withdraw support or reinterpret the bilateral instrument.

Likelihood: Medium

Severity: High

## Impact

Political pressure from either government could lead to inspector removal, consent withdrawal, or reinterpretation of the bilateral instrument that collapses the mechanism. Estimated impact: 15–25% probability (estimate) of a significant political incident during the 90-day test that strains the bilateral relationship and raises risk of Phase One interruption.

## Actions

Insulate the Phase One test from routine political friction by securing high-level political commitment (presidential or prime-ministerial level) at project launch. Establish a bilateral political steering committee of senior government officials who meet quarterly to reinforce commitment and resolve any political-level disputes before they impact operations. Include escape clauses in the bilateral instrument that allow Phase One to pause (but not terminate) if international crises warrant. Brief elected officials and media on the project's strategic importance and the mutual benefits of verification, building sustained political support. If political support wanes, identify alternative implementation models (e.g., extend Phase One, reduce site count) that preserve core testing while reducing operational burden.

# Risk Summary

The Consortium is a novel, high-stakes US–China bilateral verification mechanism for frontier computing equipment at matched datacenters. The 90-day Phase One test follows mandatory entry conditions and relies on fixed decision thresholds, double-key governance, and bounded inspection zones.

## Most Critical Risks

- Entry-condition delays that defer the 90-day clock indefinitely, especially inspector vetting and domestic authority enactment across two sovereigns
- Ledger divergence and forensic disputes over contested equipment identity under asymmetric operational security postures
- Vendor refusal cascades that classify material equipment as unverifiable and fail a site before Phase One concludes

## Secondary Risks

IP/counterintelligence exposure leading to consent withdrawal, fixed threshold miscalibration driving a Modify verdict, asymmetric access or evidence claiming that collapses reciprocity.

## Key Vulnerability

The plan's strength—procedural rigor and double-key authority—is also its vulnerability: any impasse over entry conditions, ledger reconciliation, or threshold interpretation can trigger automatic suspension. Success depends on both governments sustaining political commitment through procedural friction, maintaining reciprocal access even under adversarial inspection, and accepting independent evidence layers as sufficient when vendor cooperation fails.

# Make Assumptions
# Question 1 – Budget Disbursement and Underspend Risk

## Assumptions

- Disbursement schedule tied to milestone completion rather than calendar dates, with both governments authorized to defer spending if entry conditions are unmet.
- Contingency budget (USD 500 million) held in reserve, released only upon joint co-chair approval.
- Operator compensation and site preparation (USD 1.75 billion combined) most at risk of delay if site selection or operator vetting extends beyond Month 3 (2027-01-08).
- Personnel and training budgets (USD 750 million) can be phased: core roster at Month 1 (2026-11-08), surge pool at Month 2 (2026-12-08).

## Financial Sustainability and Appropriations Timing

Risk is high if entry conditions extend beyond Month 6 (2027-04-08), as budget authorities may redirect unspent funds or face year-end reversion. Mitigation: lock appropriations in both countries for 18 months (Months 0–18 = 2026-10-08 to 2028-04-08), contingent on Phase One start by Month 6 (2027-04-08); if delayed, trigger automatic reallocation to surge/contingency categories without requiring new legislative approval.

Personnel costs (USD 750 million) are most flexible; site preparation (USD 1 billion) is rigid if tied to real-estate contracts. Operator compensation requires pre-signed operator agreements by Month 0.5 (2026-10-23) to trigger fund release.

Success metric: zero budget variance >5% between planned and actual spending in Months 0–3 (2026-10-08 to 2027-01-08); zero funds returned to treasury before Phase One starts.

# Question 2 – Critical Path and Entry-Condition Gating

## Assumptions

- Critical path: (1) bilateral instrument signature (Month 0.5 = 2026-10-23); (2) domestic appropriations clearance (Month 1.5 = 2026-11-23); (3) domestic access-authority legislation (Month 2–3 = 2026-12-08 to 2027-01-08); (4) site selection and mutual vetting (Month 1.5 = 2026-11-23); (5) inspector vetting and security clearances (Month 3–4 = 2027-01-08 to 2027-02-08); (6) operator and vendor binding agreements (Month 1 = 2026-11-08); (7) provisional covered-equipment schedule (Month 2.5 = 2026-12-23).
- Inspector vetting is the longest-pole activity, taking 12–16 weeks for counterintelligence clearances across two sovereigns.
- Legislative authority enactment is politically unpredictable; both are external and difficult to accelerate.

## Critical-Path and Entry-Condition Gating Timeline

Inspector vetting is the critical bottleneck, requiring counterintelligence clearance of ~100–150 personnel per country and cross-vetting of counterparts. Estimated duration: 14–16 weeks if expedited, or 20+ weeks if security agencies deprioritize. Domestic access-authority legislation is the second critical risk.

Mitigation: (1) initiate vetting in pre-positioning phase using candidate lists; (2) parallel-path domestic legislation drafting before bilateral instrument signature; (3) allow Phase One to start with 80% of roster if critical positions are filled by Month 3 (2027-01-08); (4) secure high-level political commitment for expedited domestic processes.

Success metric: all entry conditions certified by Month 4 (2027-02-08); any single condition delay >8 weeks triggers escalation to co-chairs for alternate-start procedures or protocol modification.

# Question 3 – Personnel Deployment and Staffing

## Assumptions

- Two participating sites require ~30–40 FTE inspectors per country per site (total 60–80 FTE per site, mirrored). Four sites multiply this to 240–320 FTE inspectors combined.
- Add ~40–50 FTE technical, legal, counterintelligence, audit and adjudication staff per country (total 80–100).
- Estimated total: 320–420 FTE personnel per country, or 640–840 combined.
- This aligns with 24/7 shift coverage: three shifts + leave coverage (~20% buffer) + separation-of-duties specialization + surge reserve (~10–15%).
- USD 750 million personnel budget supports ~1,200–1,500 FTE at average USD 500,000–625,000 per-year cost.

## Resources and Personnel Deployment Architecture

Two sites with 24/7 shift coverage require 60–80 FTE inspectors per site (mirrored). Personnel envelope supports estimated 1,200–1,500 FTE at blended rates.

Risk: if average cost exceeds USD 625,000, headcount shortfall emerges; if sites scale to four, mirrored staffing doubles without corresponding budget increase.

Mitigation: (1) model staffing from actual site selection and confirmed shift model by Month 1.5 (2026-11-23); (2) use core roster (day shifts) supplemented by rapid-call duty teams for nights/weekends; (3) rotate inspectors across paired sites to pool surge capacity and reduce per-site fixed cost. Personnel vetting workload is front-loaded (Months 0–3 = 2026-10-08 to 2027-01-08) and can be partially outsourced to domestic security agencies.

Success metric: roster 80% filled by Month 1, 100 (2026-11-08, 2035-02-08)% by Month 3 (2027-01-08); zero unfilled critical positions; surge-pool mobilization time <24 hours.

# Question 4 – Governance and Deadlock Resolution

## Assumptions

- Double-key authorization for budgets, protocol changes, site findings and sanctions requires both co-chairs' signatures, with no casting vote and no majority override.
- Deadlock is defined as disagreement persisting >7 days on a decision-critical item.
- Automatic procedures trigger: (1) escalation to neutral independent referee panel (3–5 senior officials) with non-binding opinion within 5 days; (2) if unresolved, decision deferred without prejudicing either side's rights; (3) automatic deferral of site findings pending resolution; (4) automatic suspension trigger if deadlock persists >14 days on contested identity or equipment status.

## Governance, Reciprocity and Double-Key Authority

Double-key authority with no casting vote creates mutual veto, which can cause paralysis if either government acts in bad faith. Deadlock risk is medium (15–25% probability per 90-day test). Escalation to independent referee panel introduces third-party credibility but delays decisions by 5 days, acceptable for most items but problematic for urgent escalations. Automatic suspension trigger prevents indefinite stalling but can produce false stops if deadlock results from legitimate fact-finding disputes.

Mitigation: (1) pre-agree on referee-panel membership and authority limits before Phase One starts; (2) exclude time-sensitive safety/security items from referee escalation, instead triggering immediate co-chair call; (3) document every deadlock and resolution in the ledger.

Success metric: average deadlock resolution time <10 days; zero unilateral suspensions without co-chair sign-off; zero disputes over referee findings.

# Question 5 – Cybersecurity and Tamper Evidence

## Assumptions

- Plan requires two independent national ledger copies with bounded synchronization (<1 hour), redundant secure communications links, offline cryptographic backups, and continuous integrity verification.
- Inspectors operate under conduct rules, rotation protocols, and continuous access-log audit.
- Bilateral counterintelligence unit reviews inspector activities monthly and audits note-taking and device access.
- Physical inspection zones are marked and access-controlled, with badge-swipe logs and video recording.
- Evidence handling includes chain-of-custody documentation and tamper-evident seals.
- Cybersecurity hardening includes air-gapped offline backup systems, cryptographic signing of ledger entries, and multi-factor authentication.

## Safety, Risk Management and Cybersecurity Resilience

Cybersecurity risk is medium-high (20–30% probability of at least one security incident). Ledger divergence from cyber attack is estimated 5–10% probability per site over 90 days. Inspector compromise risk (espionage or coercion) is estimated at 5–10% probability of one incident per side.

Mitigation: (1) design ledger for cyber resilience—redundancy, offline backups, air-gapped recovery systems; (2) implement continuous integrity checking so divergence is detected within 2 hours; (3) conduct monthly cybersecurity audits of ledger systems and inspector access logs; (4) rehearse incident-response procedures quarterly.

Success metrics: zero undetected ledger tampering; zero successful cyberattacks on core systems; ledger-sync divergence detected and resolved within 4 hours; zero substantiated inspector compromise incidents.

# Question 6 – Environmental Impact and Regulatory Compliance

## Assumptions

- Exit-disposition verification includes witnessed destruction, disablement, or transfer of frontier computing equipment.
- Destruction and recycling may require environmental compliance (hazardous-waste handling, e-waste regulations) under US EPA, Chinese Ministry of Ecology regulations, and local jurisdictions.
- Estimated 10–20% of deployed equipment will be retired or replaced during Phase One.
- Disablement procedures may involve data destruction, chemical destruction, or physical shredding.
- Participating sites have existing environmental-compliance protocols; inspectors verify disposition without substituting for operator environmental responsibility.

## Environmental Impact and Regulatory Compliance

Environmental impact is low-to-medium. Destruction and recycling of semiconductor equipment generate hazardous waste and e-waste requiring permitted facilities. Risk: if witness-verification procedures interfere with environmental-compliance inspection, equipment disposition may be blocked. Estimated probability of a permit-related delay: 10–15% per site over 90 days; average delay: 1–2 weeks.

Mitigation: (1) pre-coordinate with environmental regulators in each jurisdiction; (2) allow third-party recyclers/destruction vendors to maintain environmental-compliance procedures without interruption; (3) inspectors witness disposition at defined checkpoints rather than continuous oversight; (4) pre-qualify a pool of recyclers/destruction vendors in each jurisdiction with existing permits before Phase One starts.

Success metric: zero environmentally non-compliant dispositions; zero regulatory delays attributable to inspection procedures; 100% of departures assigned to final disposition within 10 days of site removal.

# Question 7 – Operator and Vendor Engagement

## Assumptions

- Operators at participating sites sign binding bilateral agreements committing to inspector access, equipment-identity verification, third-party escort, maintenance notification, evidence preservation, and ledger compliance.
- Vendors are contractually bound by operators to cooperate with evidence-gathering, attestation validation, and equipment tracking.
- Operator refusal triggers escalation to bilateral co-chairs and potential site suspension or Phase One failure.
- Vendor refusal triggers fallback protocol: vendor-supervised testing → accredited independent examiners → clean-room validation → validated attestation → unverifiable classification.
- Penalties for operator non-compliance include reduced future contracting, loss of equipment certification, or financial sanctions (USD 1–10 million per breach, estimate).

## Stakeholder Involvement and Operator/Vendor Engagement

Operator cooperation is critical and at medium risk of failure. Estimated probability of at least one operator refusing a specific protocol element during Phase One: 15–25% per site. Vendor refusal is higher risk (20–30% per site per 90 days), especially for proprietary-equipment suppliers.

Mitigation: (1) lock operator participation in binding bilateral agreements by Month 0.5 (2026-10-23), with clear consequences for withdrawal or non-compliance; (2) pre-negotiate vendor-cooperation agreements with top 5–10 manufacturers and logistics firms before Phase One starts; (3) establish penalty tiering: minor delays → written warning; repeated non-compliance → escalation and site review; willful obstruction → facility suspension and Phase One failure. Operators and vendors benefit from assured equipment tracking and supply-chain transparency.

Success metric: zero unresolved operator or vendor refusals; >95% compliance with binding agreements; <5% of events requiring vendor-refusal escalation protocol.

# Question 8 – Go/Modify/Stop Decision Criteria

## Assumptions

- Go decision requires: (1) blind-challenge detection rates by event type meeting or exceeding targets (proposed: 90%+ for unreported arrivals, 85%+ for substitutions, 80%+ for record falsification; TBD); (2) false-positive rate <5% (proposed); (3) reciprocal-access parity metrics within 20% (proposed); (4) unresolved discrepancies <10% of total events (proposed); (5) unverifiable equipment <5% of deployed (proposed); (6) zero material ledger divergence unresolved beyond 7 days; (7) zero material asymmetric access incidents.
- Modify decision required if correctable weakness remains (e.g., detection rates 70–85%, or training improvements can raise performance).
- Stop decision required if access is asymmetric without resolution, equipment remains unverifiable, vendor refusals prevent verification of critical infrastructure, ledger divergence cannot be reconciled, or either government withholds funding.
- Thresholds are provisional and marked TBD pending pre-test calibration.
- Calibration exercise runs outside formal clock in Months 1–2 (2026-11-08 to 2026-12-08) on non-covered equipment; results validate or adjust thresholds before formal clock starts.

## Operational Systems and Go-Modify-Stop Decision Criteria

KPI threshold calibration is critical and at medium-to-high risk of misalignment. Proposed thresholds (detection 80–90%, false positives <5%, unverifiable <5%) are estimates pending calibration. Early blind exercises may reveal that thresholds are mis-set; a rigid threshold can force a Modify outcome reflecting the yardstick rather than mechanism defects.

Mitigation: (1) conduct calibration exercise on non-covered equipment in Months 1–2 (2026-11-08 to 2026-12-08), outside formal clock, measuring actual detection and false-positive rates; (2) document every threshold and its rationale; (3) if calibration results differ >20% from provisional thresholds, adjust via documented protocol change signed by both co-chairs before formal clock starts; (4) classify post-calibration thresholds as 'validated' in the ledger.

Success metric: all thresholds locked and signed by Month 3 (2027-01-08); zero threshold changes during formal 90-day test without documented co-chair amendment; final Go/Modify/Stop decision made by Month 4.5 (2027-02-23).

# Distill Assumptions
# Project Overview

- Phase One 90-day clock starts only after all mandatory entry conditions are certified: bilateral instrument, appropriations, domestic access authority, site selection, inspector approval, operator/vendor participation, and covered-equipment schedule.
- USD 5 billion budget split 50/50; disbursement tied to milestone completion with USD 500M contingency reserve.
- Inspector vetting is critical-path bottleneck requiring 14–16 weeks for counterintelligence clearance across both sovereigns.
- Two participating sites require 60–80 FTE inspectors per site mirrored; total 320–420 FTE per country with USD 750M personnel budget.
- Mirrored national inspection teams provide 24/7 shift coverage with separation of duties, leave buffer, and surge reserve.

## Governance and Decision-Making

- Equal co-chairs; double-key authorization required for budgets, protocol changes, findings, sanctions.
- No casting vote, no majority override.
- Deadlock unresolved beyond 7 days escalates to neutral independent referee panel for non-binding opinion within 5 days.
- Bilateral instrument specifies reciprocity gate, deadlock resolution, penalty tiering, and prohibited actions (no unilateral suspension without co-chair).

## Ledger and System Integrity

- Automatic suspension triggers if ledger divergence exceeds 7 days unresolved; divergence detected within 2 hours.
- Ledger replicated with independent national copies, bounded <1-hour synchronization, offline cryptographic backups, tamper-evident recording.
- No blockchain-based systems; uses cryptographic signing and dual national copies with bounded sync.

## Equipment Verification and Corroboration

- Narrow marked inspection zones limited to staging, spare inventory, maintenance bays; operator-run redaction auditable by inspectors.
- Fixed corroboration rule: equipment identity confirmed when minimum independent evidence layers agree; all provenance recorded.
- No single evidence source decisive: attestation, physical inspection, customs, identifiers, maintenance, infrastructure, witnessed movement layered.
- Equipment classified unverifiable if material evidence cannot be produced; unverifiable equipment >threshold fails site.

## Intake and Exit Protocols

- Intake Protocol verifies equipment identity in controlled staging before installation using layered independent evidence and cryptographic attestation.
- Exit Protocol assigns witnessed, verified, transferred, released or unresolved disposition; inspectors do not claim knowledge beyond boundary.
- Exit disposition assigns every departure: witnessed destruction, verified disablement, transfer to site, documented release, or unresolved.

## Testing and Challenges

- Independent testing unit runs blind challenges on sealed double-key schedule; only small group aware of timing.
- Challenge exercises limited to staging, spare, maintenance, expansion areas; no interruption of active computation.
- Calibration exercise on non-covered equipment in Months 1–2 (2026-11-08 to 2026-12-08) validates thresholds outside formal clock before blind challenges.
- All KPI thresholds fixed and double-key signed before first exercise; changes only via documented protocol amendment.

## Performance Thresholds

- Provisional thresholds include: detection 80–90% by event type, false positives <5%, unverifiable <5%, reciprocal-access parity within 20%.
- Go decision requires: detection targets met, false positives <5%, parity within 20%, unresolved <10%, no asymmetric access.
- Modify decision required if correctable weaknesses remain; Stop if access asymmetric, material unverifiable, vendor refusals block verification.

## Vendor Oversight

- Vendor refusal follows escalation: supervised testing → independent examiners → clean-room → validated attestation → unverifiable.
- Operator and vendor binding agreements signed by Month 0.5 (2026-10-23); non-compliance triggers escalation to co-chairs and potential site suspension.

## Inspector Operations and Conduct

- Mirrored national inspection teams provide 24/7 shift coverage with separation of duties, leave buffer, and surge reserve.
- Inspector conduct audit continuous; monthly reviews, rotation across sites, counterintelligence vetting, zero solo-critical functions.
- Counterintelligence unit conducts monthly inspector activity review; conduct rules, device access audit, rotation protocol, zero substantiated compromise incidents required.
- Maintenance and third-party access scheduled with advance notice, inspector coverage, sealed work areas, and emergency-use escalation controls.

## Unresolved Discrepancies

- Unresolved discrepancies escalate by severity tier with fixed deadlines; auto-suspension if clock expires per protocol.

## Equipment Schedule and Confidentiality

- Equipment schedule confidential, versioned, manufacturer-neutral; frozen for Phase One test or amended via double-key protocol change.

## Scope and Limitations

- Success limited to monitored changes at participating declared sites; no capacity estimates, workload inspection, hidden-facility verification, or comprehensive AI governance.
- Environmental compliance for equipment destruction/recycling managed by operators under existing regulations; inspectors witness disposition without replacing compliance authority.

## Budget and Contingency

- Contingency and surge capacity (USD 500M) released on joint co-chair approval for rapid deployment if entry conditions delay.
- Budget variance >5% in Months 0–3 (2026-10-08 to 2027-01-08) triggers escalation; zero funds returned to treasury before Phase One starts.


# Review Assumptions
# Bilateral Government Verification Program: Critical Assumptions Review

## Domain of Expert Review

Bilateral Government Verification Program Management & Strategic Infrastructure Risk Analysis

- Dual-sovereignty decision-making with no casting vote and mutual-veto deadlock risk
- Critical-path dependency on domestic legislative authority and counterintelligence vetting across two countries
- Ledger divergence, cryptographic trust roots, and cybersecurity resilience under adversarial inspection
- Vendor refusal cascades and fallback evidence routes when cooperation is denied
- Reciprocity gate timing and mandatory entry conditions sitting outside the 90-day test clock
- IP/counterintelligence exposure risk in narrow bounded zones and redacted evidence handoff

## Issue 1: Domestic Authority Enactment Timeline and Legislative Risk

Domestic access authority is treated as a mandatory entry condition but lacks specification of required legal authority, approving legislatures or agencies, or realistic enactment timelines. US Congressional authorization and Chinese government delegation of verification authority are assumed but not detailed. No fallback is defined if either domestic process stalls beyond the plan's control.

## Recommendation

By Month 0 (2026-10-08), decompose domestic authority into specific legislative or executive acts required in each country (e.g., US: bilateral instrument ratification, authorization for site access, inspector immunity; China: State Council directive authorizing operator participation, enforcement against vendors). Identify approval authorities and map realistic timelines based on similar past authorizations. Establish a bilateral steering committee meeting weekly from Month 0 (2026-10-08) to track progress. If either country's domestic process lags >4 weeks behind plan, trigger political escalation to co-chairs. Consider provisional partial-start: allow Phase One to begin on non-covered equipment at Month 2.5 (2026-12-23) while formal authority enactment is pending, using a pre-clock dry run to surface authority gaps before the formal 90-day clock.

## Sensitivity

A 4-week delay in either country's domestic authority enactment (baseline: Month 2, 2026-12-08) extends the reciprocity gate and defers Phase One clock start by 4–8 weeks, shifting start to Month 4–6 (2027-02-08 to 2027-04-08). This compresses the operational window and increases risk that entry conditions slip further (inspector vetting completing by Month 3.5 = 2027-01-23 instead of Month 3 = 2027-01-08, reducing pre-test calibration time from 6 weeks to 2 weeks). If authority enactment is delayed 8+ weeks in either country, Phase One clock start moves to Month 6+ (2027-04-08), eliminating the pre-test calibration window and forcing threshold lockdown on provisional data, increasing probability of Modify decision by 15–25%.

## Issue 2: Ledger Divergence Forensic Resolution Authority and Escalation Timeline

The plan specifies that unresolved ledger divergence >7 days triggers automatic impaired-confidence or suspension, but does not define: who has authority to declare divergence 'resolved' when evidence is contested by both governments; what evidentiary standard closes a dispute (majority of layers agree, or unanimous?); whether an independent referee panel can issue binding findings on identity disputes, or only non-binding opinions; how fast forensics can be conducted (target: <48 hours assumed, not stated). Without defined forensic authority, divergence disputes escalate to co-chairs, consuming time within the 7-day clock.

## Recommendation

Before Phase One starts (by Month 2, 2026-12-08), establish a pre-authorized joint forensic panel (3–5 senior technical staff per country) with authority to issue binding or co-chair-delegated findings on equipment-identity disputes within 48 hours. Define a divergence-resolution hierarchy by evidence layer: cryptographic attestation (if both copies agree) > physical inspection + chain-of-custody > maintenance records > third-party logs. Require the forensic panel to issue findings within 48 hours; if both governments dispute the finding, escalate to co-chairs for decision within 24 hours. Implement shift-boundary cross-signing by mirrored inspectors to catch most divergences within hours. If divergence persists >7 days unresolved despite escalation, automatic site suspension fires, with decision auditable and justified in the ledger.

## Sensitivity

If forensic resolution takes 5–7 days (instead of target 2–3 days), unresolved divergence clocks expire and trigger automatic suspension (50–100% of divergence events estimated at 20–30 total divergences per site over 90 days = 10–30 automatic suspensions per site). One automatic suspension per site per Phase One is plausible, causing 1–2 week operational disruption per site per suspension and reducing effective test window from 90 days to 75–80 days. This increases probability of incomplete exercise coverage and lowers confidence in final decision. If forensic authority is not pre-agreed and divergence resolution defaults to co-chair negotiation (no binding panel), average resolution time extends to 7–10 days, triggering automatic suspensions for 50–70% of divergences and making the mechanism appear to fail when it is actually working correctly.

## Issue 3: Vendor Refusal Escalation Path Clearance Timeline and Trade-Secret Exposure Boundary

The plan specifies vendor-refusal fallbacks (vendor-supervised testing, independent examiners, clean-room procedures, validated attestation) but does not specify: which vendors must be pre-bound before Phase One starts; how much lead time is needed to pre-qualify independent examiners and clean-room facilities for each equipment class; what trade-secret exposure is acceptable for independent examiners to accept a vetting job; whether vendors can refuse after sites are already selected, or if binding must occur before Month 1.5 (2026-11-23); how long each fallback route takes (estimate: vendor-supervised 1–2 weeks, independent exam 2–3 weeks, clean-room 3–4 weeks). Vendor refusal is estimated at 20–30% probability per site over 90 days, and if fallback routes are not pre-cleared, material equipment will be classified unverifiable faster than thresholds allow, failing the site.

## Recommendation

By Month 0.5 (2026-10-23), identify the top 8–12 manufacturers and logistics vendors whose equipment or services are essential to each participating site. Conduct bilateral negotiations with each to secure pre-signed vendor-cooperation agreements committing to attestation sharing, equipment-identity disclosure, and evidence preservation, with penalty clauses (loss of market access, contract termination) for refusal. Simultaneously, pre-qualify a pool of 3–5 independent examiners per country and equipment class, with pre-signed access agreements allowing in-situ testing if vendors refuse. Establish binding cost-sharing: if vendor refuses and independent examiner must substitute, the operator bears 50% of additional examination cost (capped at USD 50,000 per equipment class). Define the fallback escalation clock: first vendor request (Day 0), escalation to operator (Day 1), independent examiner notification (Day 2), examination scheduled (Day 3–5), results reported (Day 10). If no evidence is produced by Day 10, equipment is marked unverifiable. Document every vendor refusal in the ledger with justification.

## Sensitivity

If key vendors (estimated 3–5 per country) refuse to participate and are not pre-bound, the fallback routes activate for 10–20% of deployed equipment (estimate 500–1,000 items per site). If independent examiners or clean-room facilities are not pre-qualified, fallback procedures take 4–6 weeks instead of 2–3 weeks, compressing the 90-day test window and increasing probability of material equipment remaining unverifiable at final decision (10–20% unverifiable instead of target <5%). This would fail the site under Go-Modify-Stop thresholds. Cost impact: if independent examiners are engaged late, average cost per examination is USD 50,000–100,000 instead of budgeted USD 20,000–30,000 (30–40 examinations per site = USD 1.2–4M additional cost per site, consuming contingency budget). Estimated probability of vendor refusal forcing Modify or Stop outcome: 20–30% per site.

## Issue 4: Pre-Test Calibration Exercise Scope and Data Reuse Constraints

The plan assumes a calibration exercise on non-covered equipment in Months 1–2 (2026-11-08 to 2026-12-08) will validate provisional thresholds before the formal clock starts. However, several details are missing: what equipment is 'non-covered' available at the site for testing?; can data from the calibration exercise be reused in the formal Go/Modify/Stop decision, or must it be discarded?; who designs and scores the calibration exercise (same independent testing unit as formal exercises, or separate)?; how many scenarios must run to be statistically valid (estimate: 50–100 events per site, taking 3–4 weeks)?

## Recommendation

By Month 0.5 (2026-10-23), confirm in the bilateral instrument whether calibration-exercise data can be reused in the final Go/Modify/Stop decision (recommended: yes, with caveats—calibration data is valid if equipment and procedures match formal test). Define non-covered equipment as surplus, refurbished, or decommissioned equipment available at each site but not in active computational use. Reserve 100–150 units per site for calibration use. Require the independent testing unit to design calibration scenarios using the same blind-exercise methodology as formal challenges (unreported arrivals, substitutions, record falsification, vendor refusal, reluctant operators). Run calibration from Month 1 (2026-11-08) to Month 2.5 (2026-12-23), allowing 6 weeks for scenario design, execution, scoring and threshold adjustment. If calibration data is reusable, formally integrate it into the evidence base; if not, acknowledge the limitation in the final decision rationale. Success metric: calibration exercise completes by Month 2.5 (2026-12-23) with detection rates, false-positive rates and unverifiable-equipment counts documented, thresholds locked by Month 3 (2027-01-08).

## Sensitivity

If calibration exercise cannot be completed by Month 2.5 (2026-12-23) due to schedule conflicts or equipment unavailability (15–20% probability), thresholds remain provisional and unvalidated, increasing probability of Modify outcome by 10–15%. If calibration data cannot be reused and must be discarded, the formal 90-day test produces all detection evidence, reducing total evidence-event count from estimated 600–800 (if calibration included) to 400–500, lowering statistical confidence in detection-rate estimates by 20–25% and increasing probability of threshold mis-calibration (30–40% instead of 20–25%).

## Issue 5: Reciprocity Gate Stringency and Partial-Start Fallback Absence

The plan specifies a strict reciprocity gate (all entry conditions certified before clock starts, no exceptions). However, if one country completes its entry conditions (sites selected, inspectors approved, authority enacted) but the other country is delayed 8–12 weeks, the first country has a veto over timing unless a partial-start fallback is explicit. The plan does not specify what happens if the gate cannot be met by Month 3–4 (2027-01-08 to 2027-02-08). Strict gating assumes both countries complete entry work at identical pace, which historical bilateral programs (IAEA, OPCW) show is unrealistic; whichever side is slower gains a veto, creating negotiating leverage; no fallback is defined if the gate cannot be met before political will erodes or budgets expire.

## Recommendation

Supplement the strict gate with an explicit fallback: if all entry conditions cannot be certified by Month 4 (2027-02-08), trigger an automatic conditional-start protocol in which each country begins Phase One independently once its own conditions are met, with the formal Go/Modify/Stop decision deferred until both sites have run the full 90-day test. This preserves the clean test baseline while removing either country's unilateral veto over timing. Document the conditional-start option in the bilateral instrument before Month 1 (2026-11-08), so both governments accept it in advance rather than negotiating it as a crisis measure. Alternatively, pre-authorize a 'non-binding pre-clock dry run' on non-covered equipment starting Month 2 (2026-12-08) at whichever sites are ready, with formal clock deferral acceptable up to Month 5 (2027-03-08) without triggering crisis escalation.

## Sensitivity

If the strict gate is enforced and one country delays past Month 4 (2027-02-08), Phase One does not start until Month 5–6 (2027-03-08 to 2027-04-08), compressing the formal 90-day window. If Phase One starts late, pre-test calibration (originally planned Months 1–2 = 2026-11-08 to 2026-12-08) is compressed to 1–2 weeks or eliminated, forcing decision thresholds to be locked on unvalidated provisional data. Estimated probability: 30–40% probability of >4 week delay in one country's entry-condition completion. Cost of delay: USD 50–100M in personnel and facility holding costs for each delayed month. Reputational cost: late start or failure to start Phase One by Month 5 (2027-03-08) signals weak bilateral commitment and may trigger political reassessment of the entire program.

## Issue 6: Inspection Zone Boundary Enforcement and Infractions Protocol Weakness

The plan specifies narrow marked zones with operator-run redaction and inspector audit. However, enforcement procedures for zone boundary violations are minimal. The plan states 'narrowly marked zones' and 'auditable redaction' but does not define: what happens if an inspector is found photographing or accessing beyond the marked boundary; what counts as a 'material' IP-exposure incident requiring consent withdrawal vs. a 'minor' infraction; whether minor infractions accumulate to trigger removal, or if first serious incident is grounds for immediate expulsion; how quickly alleged violations are adjudicated.

## Recommendation

Establish a three-tier infraction protocol: Tier 1 (minor, first offense) = written warning and mandatory re-training within 48 hours (e.g., inspector photographed zone boundary by accident); Tier 2 (moderate, repeated or deliberate) = formal notice to counterpart, co-chair review, and proposed removal; Tier 3 (material espionage risk, serious unauthorized access) = immediate removal without co-chair review. Define material IP exposure as: undisclosed photography of workload location, network topology, source code, weight values, or infrastructure details beyond the bounded zone. For Tier 2 and 3 infractions, a joint bilateral conduct-review panel issues a finding within 48 hours; the offending government may appeal to co-chairs within 24 hours, but the decision stands pending co-chair override. Document every zone violation, alleged or substantiated, in the ledger with photographs or access-log evidence. Run monthly zone-boundary audits during inspector shift changes, spot-checking access logs and reviewing any flagged boundary crossings within 24 hours.

## Sensitivity

If zone-boundary enforcement is weak, estimated 10–20% of inspectors will test or attempt boundary violations (e.g., wandering near classified areas, recording without authorization). If violations are not escalated or penalized quickly, the risk of unauthorized collection increases by 30–50%, raising probability of material IP exposure (from baseline 10% to 15–25%) and consent withdrawal (from baseline 5% to 10–15%). Estimated cost of zone-violation discovery: 1–2 week delay in Phase One operations while adjudication occurs; reputational damage to bilateral trust.

## Conclusion

The Consortium plan is well-structured for bilateral verification of frontier computing equipment, with strong procedural rigor and double-key governance. Three critical missing assumptions create highest risk:

- Domestic legislative authority timelines and lack of fallback if one country's enactment stalls >4 weeks (defers Phase One clock start by 4–8 months, compresses calibration window, forces Modify outcomes)
- Ledger divergence forensic authority and 7-day suspension cliff (without pre-authorized forensic panel, disputes escalate to co-chairs, consuming the clock and triggering automatic suspensions that appear to fail a working mechanism)
- Vendor refusal escalation-path pre-clearance and trade-secret exposure (if vendors are not pre-bound and independent examiners not pre-qualified by Month 0.5 = 2026-10-23, material equipment becomes unverifiable by Month 3–4 = 2027-01-08 to 2027-02-08, failing sites under thresholds)

Secondary but significant gaps: pre-test calibration scope and data-reuse constraints (if calibration is incomplete or data cannot be reused, formal evidence base shrinks by 20–30%); reciprocity gate lacks conditional-start fallback if entry-condition timing diverges >4 weeks (strict gate creates unilateral veto risk); zone-boundary enforcement protocol is minimal, risking IP exposure and consent withdrawal if violations are not escalated promptly.

## Immediate Actions

- By Month 0 (2026-10-08): decompose domestic authority requirements and map legislative timelines per country; establish weekly bilateral steering committee to track entry-condition milestones.
- By Month 0.5 (2026-10-23): pre-authorize forensic panel and pre-bind top 8–12 vendors to cooperation agreements; pre-qualify independent examiners and clean-room facilities for each equipment class.
- By Month 1 (2026-11-08): establish explicit partial-start fallback if strict gate cannot be met by Month 4 (2027-02-08).

These actions reduce probability of Phase One start delay from 50% to 20%, vendor-refusal failures from 30% to 10%, and ledger-divergence suspension cascades from 50% to 15%, materially improving likelihood of a credible Go decision or defensible Modify outcome.