# Purpose
and

# Domain
# Primary domain: Arms Control Verification

Secondary domains: Cybersecurity, International Law, Hardware Supply Chain Security

## Rationale

Bilateral inspectorate verifying declared equipment changes at matched sites with reciprocity and a Go/Modify/Stop decision best names this project. Hardware Supply Chain Security ties on score but covers only the identity-verification mechanism; other candidates are methods or constraints.

## Disciplines this project involves

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Arms Control Verification | 5 | 5 | outcome | Bilateral inspectorate verifying declared equipment changes at matched sites is a treaty-verification regime. |
| Hardware Supply Chain Security | 5 | 5 | outcome | Equipment identity, intake, chain of custody and tamper evidence are the core verification mechanism. |
| Cybersecurity | 4 | 4 | method | Tamper-evident ledger, attestation, evidence filtering and counterintelligence protect IP and evidence integrity. |
| Counterintelligence | 4 | 4 | constraint | Mirrored inspectorates must be shielded from espionage and sensitive technology exposure. |
| Applied Cryptography | 4 | 4 | method | Tamper-evident replicated ledger and validated attestation depend on cryptographic design. |
| Digital Forensics | 4 | 4 | method | Layered evidence, chain of custody and tamper-evident records underpin equipment identity verification. |
| Data Center Operations | 4 | 4 | stakeholder | Installation, maintenance and decommissioning at declared sites must proceed without disrupting active compute. |
| International Law | 4 | 3 | constraint | Bilateral instrument, domestic access authority, reciprocity and double-key governance require legal implementation. |
| Bilateral Diplomacy | 4 | 3 | constraint | Reciprocity, double-key governance and deadlock procedures require negotiated US–China diplomatic mechanisms. |

# Plan Type
` and `

# Physical Locations
# Physical Locations

## Requirements for physical locations

- Matched set of declared datacenters in the United States and China with comparable staging, spare-inventory, maintenance and expansion areas
- Controlled staging areas for pre-installation identity verification with bounded inspection zones
- Secure facilities for evidence handling, clean rooms, ledger nodes and counterintelligence-protected workspaces
- Proximity to logistics hubs (airports, ports, customs) for shipment records and witnessed movement
- Operator and vendor willingness plus domestic legal authority to compel access
- Neutral-feeling or jointly acceptable venue for co-chair double-key governance sessions
- Capacity to house full-time mirrored resident inspection, technical, legal, translation and adjudication units
- No disruption to active computational work; separation from production halls

## Location 1: United States

Northern Virginia datacenter corridor (Loudoun and Prince William Counties). Declared commercial or operator datacenter campus with dedicated staging and spare-inventory zone near Washington Dulles International Airport.

## Rationale

Dense datacenter cluster with airport and customs access, many operators and vendors, and proximity to federal authority for domestic access enactment. Supports a US-side matched site with staging, maintenance and expansion areas.

## Location 2: China

Beijing–Hebei (Zhangjiakou/Langfang) or Shanghai region datacenter cluster. Declared datacenter campus with bonded staging and spare-inventory area near a major airport or port with customs facilities.

## Rationale

Large datacenter clusters with strong logistics and customs access and state authority to compel operator participation. Offers a functional match to the US site on staging, maintenance and expansion areas.

## Location 3: Third-country or jointly agreed venue

Geneva, Switzerland or Singapore. Secure meeting and adjudication facility for co-chair double-key sessions, technical referees and ledger reconciliation reviews.

## Rationale

A jointly acceptable venue for governance, deadlock handling and Go/Modify/Stop deliberation, without placing either government on home ground. Site inspection work stays at the matched US and Chinese datacenters.

## Location Summary

The plan requires physical presence at a small matched set of declared datacenters in the United States and China, where equipment arrivals, changes and departures are verified. Suggested locations: US Northern Virginia campus, matched Chinese datacenter cluster (Beijing–Hebei or Shanghai region), and jointly acceptable venue for co-chair governance and adjudication. Final site selection is an entry condition decided by both governments before the 90-day clock starts.

# Currency Strategy
# Budget Overview

USD serves as the primary currency for bilateral budgeting, reporting and accountability. Both governments contribute USD 2.5 billion each (total USD 5 billion) across seven fixed envelopes:

- Secure ledger: USD 1.25B
- Site preparation: USD 1B
- Personnel: USD 750M
- Facilities: USD 750M
- Testing: USD 500M
- Legal/audit: USD 250M
- Contingency: USD 500M

## CNY Administration

Chinese domestic compensation for operators, vendors, staff and facilities is charged against China's USD 2.5 billion contribution in CNY. Exchange-rate tracking and conversion rules must be established at the entry gate to ensure transparent 50/50 parity accounting.

## Currency Strategy

USD consolidates all bilateral budgeting, appropriations and accountability. Parity accounting between the two governments' cumulative disbursements is tracked in USD to detect one-sided spending drift. The conversion methodology or fixed exchange rate between USD and CNY must be documented in the bilateral instrument and budget governance before appropriation release. The 90-day Phase One window (Months 0–3 = 2026-10-12 to 2027-01-12) presents minimal exchange-rate exposure. No external hedging or derivative instruments are anticipated for a sovereign government-to-government transaction.

# Identify Risks
# Risk 1 - Regulatory & Permitting

Mandatory entry conditions—signed bilateral instrument, both governments' appropriations, domestic access authority, site selection, inspector approval, vendor/operator participation, and provisional schedule—may not be simultaneously satisfied before the 90-day clock starts. A single lagging condition halts the entire program, burning preparation costs without operational start.

Impact: Delay of 2–6 months from Month 0 (2026-10-12) target start; loss of stakeholder momentum; accumulated operational costs without revenue/benefit; political embarrassment triggering potential withdrawal. Estimated sunk cost: USD 100–200 million (estimate).

Likelihood: High

Severity: High

Action: Establish a certified entry-gate workstream tracking each condition weekly; assign a bilateral contingency account (USD 50 million from contingency envelope) to accelerate rate-critical path items; pre-position escrow funding mechanisms for immediate release upon joint certification; define a 'near-ready' grace period and partial operational start with subset of sites if one condition has a defined near-term resolution.

# Risk 2 - Technical

Vendor-issued cryptographic attestation keys, if concentrated in a small number of manufacturers and those keys are compromised, forged or withheld, render identity verification unachievable. A critical vendor may refuse verification terms or withdraw cooperation under government pressure, leaving unknown quantities of equipment unverifiable.

Impact: One or more declared sites fail Phase One outright due to unverifiable equipment count; Go decision blocked; estimated 10–40% of declared equipment becomes unverifiable depending on vendor mix (estimate); estimated 2–4 week delay per site to escalate vendor disputes.

Likelihood: High

Severity: High

Action: Finalize vendor binding by Month -1 with non-negotiable confidentiality and reporting requirements; establish pre-qualified vendor registry with supply-chain consequences for refusal; pre-stage accredited clean-room examination centers (funded from USD 500M testing envelope) where refusing vendors can submit units for supervised testing without exposing source code; document fallback evidence ladder for each vendor tier before Phase One; require operators to declare supplier list by Month -0.5 so missing vendors trigger entry-gate delays.

# Risk 3 - Governance & Procedural

Deadlock on a contested site finding or equipment identity creates an unresolved discrepancy with no casting vote and no defined escalation path. Automatic-suspension triggers, if inadequately defined, allow one government to stall through manufactured incidents.

Impact: Phase One extends beyond 90 days without conclusion, exhausting time-sensitive political goodwill; estimated 2–8 week delay per escalated dispute (estimate); a manufactured false-positive challenge can trigger automatic suspension at a performing site.

Likelihood: Medium

Severity: High

Action: Define deadlock and suspension procedures with exacting precision before entry gate: enumerate objective triggers (e.g., divergence > 5% on ledger checkpoints, unresolved discrepancy age > 10 days, equipment unverifiable > 3% of installed base per site) that suspend automatically without co-chair discretion; establish a three-tier escalation (site co-chairs → bilateral technical referees → principal-level review) with fixed timers at each step; exclude all deliberate challenge-exercise events from triggering suspension so manufactured incidents are administratively partitioned; require joint pre-approval of challenge-exercise design; define resumption conditions requiring documented corrective action.

# Risk 4 - Security & Counterintelligence

Resident mirrored inspector teams stationed continuously at counterpart sites become targets for espionage, blackmail, or relationship-capture operations. A compromised inspector or translator can exfiltrate equipment identifiers, facility layouts, vendor information or classified inspection procedures. Compartmentation rules can fragment site context so severely that inspectors miss substitution patterns.

Impact: Counterintelligence breach surfaces mid-Phase One, requiring all affected inspectors to be rotated or stood down, losing 2–3 weeks of coverage; security incident report triggers impaired-confidence review or site suspension; estimated cost of investigation and replacement: USD 20–40 million (estimate).

Likelihood: Medium

Severity: High

Action: Establish a standing counterintelligence unit (funded from USD 750M facilities/security envelope) to vet, clear and continuously monitor all inspectors, technical staff and translators; implement regular polygraph testing and compartmentation audits; limit inspector tenure at a single site to 6 months with mandatory breaks between assignments; compartment inspectors by event type and site; embed host-country counterintelligence liaison officers at each site who review inspector outputs and evidence before release; fund a bilateral insider-threat red team that attempts to compromise staff and reports findings directly to the audit record and suspension criteria.

# Risk 5 - Technical & Operational

Ledger divergence between the two national cryptographic copies occurs due to network latency, synchronization delays, or deliberate tampering. No bounded reconciliation procedure or asymmetric divergence resolution allows one side to drift its copy ahead.

Impact: Divergence detection latency exceeds agreed KPI thresholds; estimated 1–3 day delay per divergence incident (estimate); if unresolved divergence exceeds agreed tolerance (proposed: > 5% of events disputed), the program triggers impaired-confidence or automatic suspension; unresolved divergence is a Stop criterion.

Likelihood: Medium

Severity: High

Action: Establish a dedicated Ledger Synchronization and Divergence Doctrine before entry gate: define checkpoint format, cadence and signed-hash-chain validation; choose authenticated transport (e.g., dedicated IPsec tunnel with mutual TLS) over shared internet; set divergence-detection latency KPI (proposed: 4-hour maximum) and reconciliation time budget (proposed: 24 hours to closure); employ neutral-party digest escrow or coupled-ledger attestation; automate reconciliation logging with reason codes and dispute classification; agree on materiality threshold (proposed: > 5 discrepancies per site per week) that triggers formal reconciliation review rather than immediate escalation.

# Risk 6 - Operational

Inspector rotation, shift coverage and leave management across mirrored teams at multiple sites is a high-complexity staffing problem with no detailed surge-capacity or multi-site cross-coverage plan. A health emergency, geopolitical crisis or cascading operational incident strains availability below detection requirements. Single-person critical functions create bottlenecks that compound surge risk.

Impact: Detection capability drops below thresholds during surge periods; estimated 20–40% reduction in inspector availability during peak operational load (estimate); an uncovered event window leads to missed arrival or substitution; estimated cost overrun on personnel budget: USD 50–100 million (estimate) against USD 750M personnel envelope.

Likelihood: Medium

Severity: Medium

Action: Model full-time mirrored staffing from site count with explicit surge and leave buffers before entry gate: assume 3-person teams per site per shift (intake, monitoring, exit); calculate 7-day rotation with 2-person minimum staffing per function; model 15% leave allowance and 10% surge reserve; establish no single-person critical functions; pre-deploy cross-site floaters from both countries (estimated 20–30% surge capacity) before clock start; conduct staffing dry-run exercises in Month -1; define staffing KPIs (proposed: minimum 80% of target staff deployed, no single function below 2 FTE) with automatic operational curtailment if targets slip.

# Risk 7 - Technical & Operational

Evidence filtering at the operator-controlled gateway may strip critical fields needed to detect substitution or equipment movement. The operator has incentive to filter aggressively; the counterpart's engineers audit gateway rules but not inputs, creating asymmetric visibility. Filter adequacy is not tested until live exercises.

Impact: A substituted piece of equipment passes intake because the redacted records lack the serial-number or firmware-version fields that would have triggered identity questions; estimated 5–15% of substitution scenarios undetectable under aggressive filtering (estimate); if discovered post Phase One, triggers Go decision reversal; reputational damage discredits the entire pilot.

Likelihood: Medium

Severity: High

Action: Design filter rules jointly before entry gate, with each country's sensitive-asset experts writing the filters applied at the counterpart's sites; require operator-operated redaction gateways to log every filter decision in the tamper-evident ledger; run filter-adequacy blind exercises in Month 0.5 (2026-10-27) using staging areas to test whether critical fields are preserved; define a minimum evidence schema (proposed: equipment serial number, firmware version, cryptographic attestation digest, maintenance-event timestamp, physical identifiers) that is non-negotiable; if filtering strips any schema field, automatic escalation to unverifiable-equipment status; calibrate challenge exercises to include scenarios that test filter edge cases.

# Risk 8 - Operational & Governance

Matched site equivalence is vague: US Northern Virginia datacenters and Chinese Beijing–Hebei or Shanghai facilities may have vastly different staging-area sizes, customs-access latency, operator types and logistics infrastructure. Reciprocal-access parity accounting struggles to define what 'equivalent' inspection activity means.

Impact: Parity disputes on whether access denial at one site is justified by asymmetric site characteristics; estimated 2–4 week stalls per parity dispute (estimate); estimated 10–20% of access denials become parity disputes rather than resolved technical issues (estimate).

Likelihood: Medium

Severity: Medium

Action: Define 'matched' explicitly before site selection: either match by verification function, by operator type, or by capacity tier; establish a Matched Site Equivalence working group by Month -2 to conduct physical surveys and document site characteristics that justify parity comparisons; publish site-pairing rationale before entry gate so both governments can contest equivalence claims; define normalization factors for parity accounting (e.g., 'access per unit of declared equipment' rather than 'total access hours'); require a joint site-equivalence certification step at the entry gate.

# Risk 9 - Political & Governance

One government shields an operator or vendor from verification duties by invoking national security, refusing domestic access authority or withdrawing political backing. This violates reciprocity but lacks a clear enforcement path.

Impact: Equipment at that government's site remains partially unverified; material equipment count unverifiable, triggering site failure and Phase One Stop decision; diplomatic crisis and program termination; estimated cost: entire USD 5 billion pilot rendered inconclusive and politically contested.

Likelihood: Medium

Severity: High

Action: Define operator and vendor binding requirements explicitly before entry gate as non-negotiable conditions: each government must certify that it has legal authority to compel operator and vendor participation and that all critical vendors have agreed to verification terms. Make binding certification an entry condition; embed escalation procedure: any access refusal by an operator or vendor triggers an automatic two-tier response: first, escalation to principal-level bilateral review within 48 hours; second, if unresolved within 5 days, automatic site suspension until resumption conditions are met; document resumption conditions in bilateral instrument as non-negotiable; publish suspension events in the KPI dashboard immediately so political cost of shielding is visible.

# Risk 10 - Technical

Cryptographic attestation from vendors may be forged, time-delayed or tied to firmware that does not match physical hardware. Layered corroboration (customs records, maintenance logs, physical marks) may be insufficient if the counterpart disputes the corroboration layers' reliability or origin.

Impact: Equipment identity confidence falls short of agreed thresholds (proposed: > 95% confidence required); equipment escalated to unverifiable status; estimated 2–5% of declared equipment at a site becomes unverifiable due to attestation-corroboration mismatches (estimate); if unverifiable count exceeds site threshold (proposed: > 3% of installed base), site fails Phase One; estimated 1–2 week delay per escalation.

Likelihood: Medium

Severity: Medium

Action: Establish an Equipment Identity Trust Anchor before entry gate that specifies the evidentiary hierarchy: cryptographic attestation is primary but requires independent validation by accredited examiners from both countries; customs records and shipment tracking are secondary layers; physical inspection and equipment identifiers are tertiary layers; no single layer is decisive; a mismatch across any two layers triggers escalation to technical referees for dual-signed adjudication; require attestation timestamps to bind to customs-entry and staging-arrival events within a fixed tolerance (proposed: ±2 hours); pre-stage bilateral attestation-validation laboratories to independently verify vendor signatures before intake; develop a physical-mark and tamper-seal specification that is agnostic to vendor; if attestation cannot be validated by Month 1 (2026-11-12), automatically elevate all equipment from that vendor to unverifiable status and escalate to bilateral principals.

# Risk 11 - Technical & Operational

Blind challenge exercises designed to test unreported arrival, substituted equipment, inaccurate records, delayed access and vendor refusal may serendipitously trigger automatic-suspension conditions. A false-positive challenge (e.g., a seeded unreported arrival that is misinterpreted as a real breach) collides with automatic-suspension triggers.

Impact: A challenge exercise injects a test substitution; the intake team flags it as unverifiable; automatic-suspension trigger fires; site suspends; all inspectors at that site stood down; estimated 3–7 day operational halt to adjudicate the challenge event (estimate); estimated 10–20% schedule slip if multiple challenges trigger false-suspension cascades (estimate).

Likelihood: Medium

Severity: High

Action: Partition challenge-exercise events administratively from operational triggers: explicitly exclude all deliberate challenge-exercise events from triggering automatic suspension, impaired-confidence review or KPI threshold violations; mark every injected scenario in the ledger with a 'CHALLENGE' tag before injection; require independent testers to design blind challenges in a sealed, pre-committed catalog agreed by both governments before Phase One starts; publish challenge-exercise schedule in advance; run filter-adequacy and presence-detection exercises in Month 0.5 (2026-10-27) before Phase One operational clock starts; if a challenge-exercise event is misclassified as operational and triggers suspension, treat escalation to principals as immediate (within 2 hours) without waiting for normal deadlock timers, with automatic reinstatement pending adjudication.

# Risk 12 - Financial

Budget envelopes are fixed (USD 1.25B ledger, USD 1B site preparation, USD 750M personnel, USD 750M facilities, USD 500M testing, USD 250M legal/audit, USD 500M contingency). Surge costs during Phase One are not pre-allocated and must draw from contingency, which is insufficient if multiple surges overlap. No budget flexibility mechanism is defined.

Impact: Contingency budget exhausted by Month 1.5 (2026-11-27) due to vendor escalations, vendor-refusal litigation and inspector surge staffing; subsequent cost overruns have no funding source; operational corners are cut, detection capability reduced or Phase One curtailed early; estimated 10–20% of planned scope cancelled due to budget exhaustion (estimate); estimated cost overrun: USD 200–300 million (estimate) if not absorbed by cutting scope.

Likelihood: Low

Severity: Medium

Action: Reserve USD 500M contingency envelope explicitly for surge and unexpected costs; allocate contingency thresholds by risk category (estimated 20% overrun on personnel surge, 25% on vendor escalation, 15% on IT/ledger security) before entry gate; establish a contingency-release workstream with joint bilateral approval for any drawdown above USD 10M; model budget profiles for low/medium/high surge scenarios by Month -1; establish a bilateral rapid-funding trigger: if contingency draw approaches 75% before Month 2 (2026-12-12), automatic escalation to principals for a supplementary appropriation decision; require monthly budget-burn reports in the KPI dashboard.

# Risk 13 - Operational & Technical

The 90-day Phase One operational window (Months 1–3 = 2026-11-12 to 2027-01-12) is very short for detecting all material changes at multiple sites while running challenge exercises, adjudicating disputes, producing a validated ledger and reaching a Go/Modify/Stop decision. Late entry-gate delays, late vendor binding or cascading operational incidents compress the actual operational window to 60 days or less.

Impact: Insufficient operational data to validate Go thresholds; Go decision forced by calendar pressure rather than evidence sufficiency; estimated 50% reduction in blind-exercise cycles if entry gate slips by 6 weeks (estimate); unresolved discrepancies accumulate with no time for adjudication, forcing a Modify or Stop verdict by default; reputational damage: program appears rushed and inconclusive.

Likelihood: Medium

Severity: Medium

Action: Front-load all entry conditions by Month -1: bilateral instrument signed, appropriations allocated, domestic access authority enacted, sites selected and certified equivalent, inspectors cleared, vendors bound, and provisional schedule adopted. Do not start the 90-day clock until all conditions are met. Establish an entry-gate go/no-go decision point by Month -1.5 so if conditions cannot be met, both governments can decide to restart or abandon before sunk costs mount. Reserve the first 5 days of operational Phase One (Month 1 = 2026-11-12, Days 1–5) purely for opening inventory baseline and starting-state seal with no challenge exercises or equipment movements. Compress challenge-exercise schedule to Month 1.5–2.5 (2026-11-27 to 2026-12-27) so results are available for verdict calibration by Month 2.75 (2027-01-04). Define a mandatory verdict decision point at Month 3.25 (2027-01-20) (1 month buffer after clock start) so unresolved issues do not push verdict beyond political deadlines.

# Risk 14 - Governance & Procedural

No casting vote and double-key authorization requirements mean deadlocked decisions cannot be resolved without escalation to principals. Escalation procedures are not defined, timers are vague, and no automatic resolution rule exists. A unilateral country can delay indefinitely by stalling at co-chair level.

Impact: An unresolved discrepancy at one site ages beyond proposed 10-day threshold; Stop criterion triggered not because of technical failure but because of procedural gridlock; entire pilot terminated mid-Phase One due to deadlock; estimated political crisis as one government claims the other weaponized deadlock to kill the program.

Likelihood: Medium

Severity: High

Action: Define Deadlock and Suspension Mechanics exhaustively before entry gate: specify deadlock as 'failure to reach bilateral consensus on a finding within 5 days'; define automatic escalation path: deadlock triggers automatic escalation to a Bilateral Technical Referees panel (2 experts per side, pre-cleared and funded) within 24 hours; referees must issue a joint advisory fact statement within 3 days; if referees cannot agree, escalate to Principal-level Review within 2 days; principals must decide within 5 days or the status quo defaults to heightened inspection (not suspension); unresolved discrepancies older than 10 days are reported as aging in the KPI dashboard and trigger impaired-confidence review, not automatic suspension; unresolved discrepancies older than 15 days become Stop-criterion candidates, triggering principal-level intervention before suspension; define escalation timers in the bilateral instrument as non-negotiable.

# Risk 15 - Security & Operational

Operator and vendor willingness to participate depends on trust in compartmentation and confidentiality boundaries. If an operator perceives that inspectors are collecting information beyond the agreed boundary, or if evidence leaks to the foreign government, the operator will withdraw consent, refuse future access or escalate politically.

Impact: An operator withdraws from Phase One or refuses to allow inspectors on-site; that country's declared site fails outright; Go decision blocked; estimated 20–40% of all operator support at risk if a single operator breach surfaces (estimate); if a US operator withdraws, estimated USD 200–300M in cascading vendor and operator defections (estimate). Political crisis as operator's home government claims foreign intelligence exploitation.

Likelihood: Medium

Severity: High

Action: Establish Inspection Zone Geometry and Evidence Filtering Design before entry gate with operator input and signed confidentiality commitments: define physical boundaries (staging, spare-inventory, maintenance, expansion areas only; production halls and customer-data areas strictly off-limits); paint boundaries in the facilities; admit only pre-validated inspector instruments (no recording devices, no connected IT systems without air-gap protocols); require operator-controlled redaction gateways; have each country's specialists design the filters applied at the counterpart's sites; embed operator liaisons in the inspectorate to audit field work against agreed boundaries; publish quarterly operator-confidence reports in the KPI dashboard (proposed metric: 'Operator consent status: full/degraded/withdrawn'); run Inspection Zone Geometry validation exercises in Month 0.5 (2026-10-27) with staged incursions to test boundary enforcement; if an operator withdraws consent, automatic escalation to principals and suspension of that site pending diplomatic resolution.

# Risk 16 - Financial & Governance

The plan specifies that compensation to domestic operators and vendors is 'administered by their own government and charged against its contribution,' but no mechanism for transparent parity accounting is defined. China may compensate vendors at rates 5–10x higher than US market rates; asymmetric spending leaves one country ahead on its USD 2.5B allocation while the other is depleted.

Impact: By Month 2 (2026-12-12), cumulative disbursement parity diverges; one country claims the other is front-loading contingency or over-compensating domestic players; estimated 1–2 week delay per parity audit (estimate); if divergence exceeds agreed tolerance (proposed: ±10% of allocated portion), automatic impaired-confidence review; reputational damage: program appears unequal and one side appears to be looting the budget.

Likelihood: Medium

Severity: Medium

Action: Establish transparent, matched-tranche spending protocols before entry gate: each country's USD 2.5B contribution is divided into equal quarterly tranches (USD 625M per quarter); tranche release is contingent on matched cumulative disbursement parity (neither side's cumulative spend leads the other's by more than ±10% of pro-rata share); require monthly spending reports by envelope category published in the KPI dashboard; establish an independent bilateral budget auditor (funded from USD 250M legal/audit envelope) to verify each tranche release; if spending divergence exceeds 15% at any month, automatic review and explanation required before next tranche release; define parity not as identical line-item spending but as matched cumulative portfolio; establish a spending-parity trip point (proposed: 20% divergence) that triggers impaired-confidence review and holds tranche release.

# Risk 17 - Regulatory & Permitting

Domestic legal authority to compel operator and vendor participation may be incomplete or challenged in litigation. A US federal court may find that compelling a private vendor to accept Chinese inspectors violates constitutional due process; a Chinese vendor may have state-owned-enterprise status that creates legal ambiguity. Unresolved legal challenges delay vendor binding.

Impact: Vendor binding delayed by 2–4 months due to litigation or reauthorization efforts; entry gate cannot be certified; Phase One operational start delayed or cancelled; estimated USD 50–100 million (estimate) in legal fees and preliminary operational costs absorbed without benefit.

Likelihood: Low

Severity: High

Action: Conduct comprehensive legal review before entry gate to identify any domestic legal barriers to compulsory operator/vendor participation; have the US government seek expedited legislative clearance (if needed) or Office of Legal Counsel opinion affirming authority; have the Chinese government issue binding directive affirming domestic enterprise authority to participate; establish a bilateral legal working group by Month -3 to resolve anticipated challenges and publish legal opinions before entry gate; build a 6-week legal-clearance contingency into the entry-gate timeline; if legal barriers remain unresolved by Month -1.5, escalate to principals for a decision to delay or proceed with partial participation.

# Risk 18 - Operational

Covered-Equipment Schedule Abstraction Ladder must be vendor-neutral and hardware-generation-agnostic, yet sufficiently specific to classify equipment at intake and exit. Vague definitions lead to boundary disputes: is a GPU from 2 years ago still covered, or has it been superseded? Classification thresholds held in split escrow invite suspicion.

Impact: Boundary-case equipment disputed at intake; estimated 5–15% of equipment arrives at the declared sites without clear classification status, delaying intake (estimate); every classification dispute escalates to bilateral specialists or principals; estimated 1–2 week delay per dispute (estimate); if 10+ disputes accumulate, schedule specialists become the bottleneck.

Likelihood: Medium

Severity: Medium

Action: Define covered-equipment schedule by functional role before entry gate, not by specific product: e.g., 'any device performing tensor-accelerated parallel computation exceeding 1 exaflops per second in aggregate cluster configuration'; avoid manufacturer-specific definitions; include a schedule-update process allowing both governments' technical specialists to revise classifications on a quarterly basis through versioned, double-key updates; establish a boundary-case resolution procedure: items within 10% of threshold trigger a joint technical review within 2 days; if specialists cannot agree, defaulting rule is: 'when in doubt, classify as covered'; publish schedule version and update history in the ledger; require accountable specialists from both sides to sign off on all schedule updates before they take effect.

# Risk 19 - Operational & Governance

Reciprocal-Access Parity Accounting Method is meant to ensure both governments' inspectors have equivalent access rights, but 'equivalent' is ambiguous when sites are asymmetric, operator responsiveness differs, or operational incidents disrupt access schedules. Parity disputes age without resolution.

Impact: Parity disputes accumulate (proposed threshold: > 5 unexplained denials per month becomes trip point); estimated 1–2 week delay per major parity escalation (estimate); if denials exceed threshold, impaired-confidence review triggered; operational halt estimated 3–5 days per incident (estimate); estimated 10–20% of Phase One time consumed in parity adjudication (estimate).

Likelihood: Medium

Severity: Medium

Action: Define parity operationally before entry gate with reason-coded denial logging: each access request, inspection event and evidence request is logged in the ledger with accept/deny status and reason; establish equivalence yardstick: parity is judged by matched events (inspector hours, staging-area accesses, equipment inspections) rather than raw time, normalized by site size and equipment count; set tolerance bands (proposed: ±10% variance between matched sites' reciprocal-access rates) below which no trip point is triggered; denials above tolerance require reason-code explanations within 24 hours; any denial with no acceptable reason-code triggers escalation to bilateral operations directors within 48 hours; unresolved denials older than 5 days become aging-discrepancy entries in KPI dashboard; trip point set at > 15% divergence for consecutive weeks, triggering impaired-confidence review but not automatic suspension.

# Risk 20 - Technical

Opening Inventory Baseline and Starting-State Seal requires establishing which equipment is declared as present at each site at Month 1 (2026-11-12), Day 0. If the baseline is not sealed, then early discrepancies are ambiguous: is an unexpected unit a new arrival, or was it present before? If the baseline is sealed by full census, operator exposure is maximized and some operators may withdraw consent.

Impact: If baseline is not sealed, false-positive and false-negative rates on early arrival detection are both high; estimated 20–30% of detected arrivals disputed because baseline status is unclear (estimate); escalations consume 2–3 days each; if baseline is sealed by census, estimated 1–2 weeks of intake time consumed on Month 1 (2026-11-12), and some operators withdraw due to exposure, failing sites outright.

Likelihood: Medium

Severity: Medium

Action: Choose a baseline strategy before entry gate and commit to it: either (1) seal a declared opening inventory through joint count of covered-equipment categories within declared zones by Month 1 (2026-11-12), Day 5, treating it as zero-point reference for all later changes, with explicit disclosure in reports that starting population is verified, or (2) accept operator self-declaration without a count and verify only changes after entry, explicitly labeling all reports with 'starting population unverified' disclaimer; a third option is progressive baselining (verify items only when maintenance events touch them), documented as such with explicit disclaimer that early arrivals cannot be distinguished from pre-existing items. Do not attempt a hybrid approach. If option 1 (sealed census), schedule intensive intake for Month 1 (2026-11-12), Days 1–7, with additional inspectors pre-deployed for surge capacity. If option 2 (unverified baseline), schedule challenge exercises to inject known arrivals in Month 1.5 (2026-11-27) so detection capability is tested with clear baselines.

# Risk 21 - Governance

Verdict Evidence Sufficiency and Threshold Calibration requires pre-registering Go, Modify and Stop thresholds, but these figures are assumed, not validated. Challenge exercises may reveal that detection rates are only 80% under realistic filtering, forcing a Modify or Stop verdict. Alternatively, if thresholds are calibrated during Phase One using early exercise data, political incentives push each government to interpret results favorably.

Impact: Go thresholds set at 95% detection rate; exercises reveal 85% actual rate; threshold-not-met triggers Modify or Stop verdict despite operational soundness; political crisis as one government claims thresholds were rigged by the other. If thresholds are calibrated mid-Phase One, scoring divergence emerges at Month 2.5 (2026-12-27); one side claims 92% detection (Go), the other 87% (Modify); estimated 2–3 week stall (estimate) while principals adjudicate threshold-setting methodology.

Likelihood: Medium

Severity: High

Action: Pre-register Go, Modify and Stop thresholds before entry gate with documented validation method for every figure: for each KPI (detection rate, false-negative rate, ledger latency, parity variance, unverifiable-equipment ratio), publish the source of the estimate and mark unsupported figures explicitly as '(provisional—validated by Month 1.5 = 2026-11-27 exercises)'; establish a Threshold Calibration Panel of bilateral technical experts (pre-cleared, funded from testing envelope) who will independently evaluate early blind-exercise results by Month 1.5 (2026-11-27) and recommend threshold adjustments if empirical data diverges >10% from assumptions; freeze all thresholds by Month 2 (2026-12-12), before scored exercises; publish threshold-calibration records and any recommended adjustments in the ledger; if scoring divergence persists at verdict time, publish both national scores sealed and let the divergence magnitude itself become a metric reported alongside the verdict.

# Risk 22 - Operational

Exit Protocol and Departure Disposition Evidence Ladder requires witnesses to every departure: witnessed destruction, verified permanent disablement, transfer to another site, or documented release beyond monitoring. In a surge environment, witness availability is insufficient; disposition closures age without completion.

Impact: During Month 2 (2026-12-12) surge, 50 units scheduled for transfer or decommissioning but only 15 witness-slots available per week; estimated 3–4 week backlog on disposition closure (estimate); unresolved-disposition age climbs to 15+ days at some units; Stop criterion triggered even though operational work is sound; estimated 1–2 week operational halt (estimate) while adjudication catches up.

Likelihood: Low

Severity: Medium

Action: Model Departure Disposition Evidence Ladder staffing by maximum monthly departure rate before Phase One: if typical surge is 100 units/month requiring witness closure, allocate 4–6 mirrored witness teams per site with availability for 20–30 witnesses per week per site; establish pre-positioned surge capacity (bilingual logistics specialists, mobile inspection teams) funded from contingency envelope. Require operators to pre-declare intended disposition path at least 5 days in advance. Define evidence requirements by disposition type: witnessed destruction requires 2 inspectors + residual sampling; permanent disablement requires 2 inspectors + state verification; transfer requires 2 inspectors + receiving-site attestation; release beyond boundary requires sealed handover only. If witness capacity is exceeded, automatic escalation to bilateral logistics directors for surge staffing authorization within 24 hours; mark unresolved dispositions older than 10 days in the KPI dashboard as aging.

# Risk 23 - Security

Secure facilities (ledger nodes, clean rooms, counterintelligence-protected workspaces) must themselves be protected against espionage, sabotage or physical compromise. A compromised ledger node could silently alter records; compromised clean-room surveillance could leak equipment details. Facility security responsibility is split between host and inspectorate.

Impact: A security incident at a ledger facility surfaces mid-Phase One; entire ledger integrity questioned; estimated 2–4 week forensic investigation (estimate); Go decision blocked or reversed due to evidence-system distrust; estimated cost of investigation and facility re-hardening: USD 20–40 million (estimate).

Likelihood: Low

Severity: High

Action: Establish secure-facility security protocols before entry gate, funded from USD 750M facilities/security envelope: ledger nodes in geographically diverse, hardened facilities with biometric access control, continuous intrusion detection and mirrored backup at both countries; clean rooms designed with physical evidence-handling zones where neither government's equipment or personnel can access raw data; secure facilities staffed by host-country security professionals with bilateral observation; all facility incidents logged in the tamper-evident ledger within 1 hour; establish a bilateral Facility Security Review Panel that conducts quarterly unannounced inspections of the counterpart's secure facilities; fund redundant ledger copies and offline backup media stored in neutral-party escrow for forensic recovery.

# Risk 24 - Organizational & Staffing

Bilateral governance with equal co-chairs and no casting vote creates structural paralysis if both chairs hold incompatible positions on a critical decision. No defined escalation to principals and no automatic arbitration mean disputes age indefinitely. A political change in either country can trigger re-evaluation of Phase One cooperation.

Impact: A deadlock on a site finding ages from Day 5 to Day 15; no escalation triggered; unresolved discrepancy feeds Stop criterion without bilateral agreement; program stalls or terminates mid-Phase One; estimated political crisis and reputational damage globally as the bilateral pilot is seen as dysfunctional.

Likelihood: Low

Severity: High

Action: Embed deadlock procedures exhaustively in the bilateral instrument before signature: define a three-tier escalation: (1) Co-Chair Level, Days 1–5; (2) Technical Referee Panel, Days 5–8; (3) Principal-Level Review, Days 8–13; at each tier, define required actions (fact-finding, option generation, recommendation); if principals cannot agree by Day 13, status quo defaults to heightened inspection (not suspension) while further escalation continues; require principals to render a decision within 5 calendar days of receiving the referee recommendation, or declare impasse in writing to trigger automatic re-escalation to the top political level. Embed a continuity mechanism: if a chair leaves office or a government changes, designate a successor chair before transition; ensure Phase One operations continue under interim governance.

# Risk 25 - Regulatory & Permitting

The bilateral instrument—the treaty, memorandum of understanding or executive agreement that binds both governments—must be negotiated, approved and signed before entry conditions can be certified. Diplomatic negotiations typically consume 6–12 months. The plan assumes signing by Month 0 (2026-10-12), leaving no time for formal negotiation or legislative ratification.

Impact: Instrument not signed until Month 4 (2027-02-12) or later; entry-gate clock slips; Phase One operational start delayed by 3–6 months; accumulated preparation costs burn without operational benefit; estimated USD 100–200 million (estimate) sunk cost before Phase One can begin.

Likelihood: High

Severity: High

Action: Begin bilateral-instrument negotiation immediately (parallel to plan development, Month -6 to Month -3) so signature is achievable by Month -1 at the latest; establish a bilateral steering committee to track negotiation progress and escalate bottlenecks weekly; commit both governments to a fixed instrument-signature deadline by Month -2; if formal ratification is required, conduct parallel ratification efforts so formal approval coincides with signature; use a phased approach: sign a skeletal executive agreement by Month -1 to freeze core governance principles and enter conditions, then negotiate detailed operating procedures via subsidiary annexes finalized during Phase One if needed; establish a standing legal working group (funded from USD 250M legal/audit envelope) to identify legal, commercial and regulatory barriers before they delay entry conditions.

## Risk Summary

The Consortium is a first-of-kind, USD 5 billion bilateral verification program with extraordinary operational, governance and security complexity. The 90-day Phase One operational test depends critically on mutual trust-free evidence systems, resident mirrored teams, double-key governance without casting votes, and layered detection. The three highest-risk domains are: (1) Entry-gate stalling and incomplete mandatory conditions that delay or prevent the 90-day clock from starting; (2) Attestation-key compromise or vendor refusal that renders equipment identity unverifiable despite full operational readiness; and (3) Ledger divergence or manufactured-incident cascades that trigger deadlock or impaired-confidence suspension without resolution paths. Secondary risks span counterintelligence penetration, operator shielding, inspector capture, evidence filtering adequacy, parity disputes on non-identical sites, false-positive challenge exercises, and the inherent political fragility of a verification program that cannot prove the absence of hidden facilities or total capacity. Mitigation requires early vendor binding, cryptographic ledger commitments before clock start, containment of exercise events from triggering suspension, and explicit escalation procedures that prevent deadlock from aging unresolved.

# Make Assumptions
# Financial Feasibility Assessment

## USD 2.5 Billion Contribution Release and Tracking

- Contributions released in matched tranches (proposed: four quarterly tranches)
- Fixed CNY conversion rule set at entry gate
- Parity tolerance of ±10% of pro-rata share (proposed threshold, subject to independent auditor validation)

## Budget and Contingency Management

- Total budget: USD 5 billion (50/50 split)
- Contingency: USD 500M (10% of budget, user constraint)
- Co-chair sign-off required for draws above USD 10M (proposed)
- Monthly burn reports per envelope
- 75% contingency-draw trigger (proposed) escalating to principals
- Funding timeliness is a Stop criterion

---

# Schedule Feasibility Assessment

## Entry Gate and Phase One Timeline

- Entry conditions certified in single gate before Month 0 (2026-10-12) clock start
- Phase One: Months 0–3 (2026-10-12 to 2027-01-12) (user constraint)
- Baseline sealing in first days
- Challenge exercises in roughly Months 1–2 (2026-11-12 to 2026-12-12) (proposed)
- Threshold freeze before scored exercises
- Verdict by Month 3.25 (2027-01-20) (proposed)

## Critical Path and Mitigation

- Bilateral instruments, appropriations and domestic access authority typically take 6–12 months (estimate)
- Gate readiness is the critical path, not Phase One
- Clock starts only after certification; slippage costs money, not test time
- Mitigate with weekly condition tracking, go/no-go checkpoint, documented grace rule, and reserved early days for baseline with no exercises

---

# Staffing Adequacy Assessment

## Staffing Model

- 24/7 full-time mirrored resident teams per country at each matched site
- Functions: inspection, technical, legal, cybersecurity, counterintelligence, translation, audit, logistics, adjudication
- Minimum two trained people per function
- Leave allowance: 15% (proposed)
- Surge reserve: 10–30% (proposed)

## Personnel Envelope and Risk

- Budget: USD 750M (user constraint)
- Estimate: hundreds of cleared full-time staff required for continuous multi-site coverage
- No single-person critical functions; no temporary-agency inspectors
- Availability loss in surges: 20–40% (estimate)
- Cost overrun risk: USD 50–100M (estimate)
- Mitigations: cross-site floaters, trained backups, curtailment rules if deployment falls below 80% of target (proposed)

---

# Governance and Legal Assessment

## Bilateral Instrument and Authority

- Signed bilateral instrument fixes equal co-chairs and double-key authorization
- Enumerated triggers for actions
- Both governments enact domestic compulsion authority before gate

## Deadlock and Suspension Procedures

- Deadlock defined as no consensus within 5 days (proposed)
- Escalation to technical referees then principals
- Status quo defaults to heightened inspection while aging discrepancies are reported
- Automatic suspension triggers and excluded exercise events reduce stalling

## Legal Risk and Mitigation

- Litigation or state-enterprise ambiguity over compelling vendors: 2–4 month delay (estimate)
- Mitigate with early legal working group, binding certification as entry condition, and documented resumption conditions requiring corrective action

---

# Security and Risk Assessment

## Personnel and Evidence Protection

- Inspectors work in bounded zones with escorted movement
- Pre-validated instruments only; no recording devices beyond approved tools
- Compartmentation by site and event type
- Host liaison review
- Insider-threat red cell and continuous vetting
- Tenure limits: 6 months (proposed)

## Breach Impact and Controls

- Breach could remove 2–3 weeks of coverage and cost USD 20–40M (estimate)
- Resident teams enlarge collection surface; over-compartmentation can cause missed substitutions
- Hardened ledger nodes
- Incident logging within one hour (proposed)
- Unannounced facility reviews and clean-room safety
- Challenge exercises must test filtering adequacy before scored runs
- Residual risk stays high

---

# Environmental Impact Assessment

## Site and Equipment Footprint

- Site preparation uses existing datacenter space with modest fit-out rather than new construction
- Destruction and disablement occur at licensed, host-country facilities under witness
- Environmental impact minor relative to datacenter operations and governed by host-country law

## Mitigation and Impacts

- Main impacts: e-waste from witnessed destruction, energy use of ledger nodes and secure facilities, international staff travel
- Risk scale low for small matched site set (estimate)
- Mitigate with licensed recycling, no-disruption rules for active compute, remote reconciliation where secure, and disposal compliance in exit protocol evidence

---

# Stakeholder Engagement Assessment

## Party Engagement and Compulsion

- Each government compels its own operators and vendors
- Compensation charged to contributing government
- Flow-down of reporting, confidentiality, escort and preservation duties required
- Refusing vendors: use vendor-supervised testing, filtered evidence or accredited clean-room examination; otherwise equipment unverifiable
- Pre-qualified vendor registry and supplier declarations required before gate

## Participation Risk and Mitigation

- Vendor refusal or operator withdrawal can fail a site
- Unverifiable equipment under vendor concentration: 10–40% (estimate)
- Compensation asymmetry between countries may feed parity disputes
- Mitigations: operator liaisons and visible operator-consent status in dashboard

---

# Operational Systems Assessment

## Evidence Systems and Ledgers

- Each country holds independently verifiable ledger copy
- Immediate local recording and signed checkpoint exchange
- Proposed thresholds:

  - Synchronization within 1 hour (proposed)
  - Divergence detection within 4 hours (proposed)
  - Identity confidence above 95% (proposed)
  - Unverifiable equipment under 3% (proposed)

## Budget and Technical Risks

- Budget: USD 1.25B (user constraint) for ledger, attestation and communications
- Key risks: attestation-key concentration, divergence between ledger copies, filters stripping fields needed to detect substitution
- Mitigations: layered evidence with no single decisive source, minimum evidence schema, filter decisions logged, calibration panel, and threshold freeze before scored exercises
- Unsupported figures marked provisional or TBD


# Distill Assumptions
# Consortium Overview

Consortium is a sovereign US–China public-sector verification program limited to change verification of declared equipment at a small matched set of participating sites.

## Phase One

- 90-day operational test (Months 0–3 = 2026-10-12 to 2027-01-12) ending in a Go/Modify/Stop verdict
- The 90-day clock starts only after all mandatory entry conditions are certified at a single gate
- Entry conditions take an estimated 6–12 months, making the gate the critical path

## Budget

- Total: USD 5 billion, contributed 50/50 at USD 2.5 billion per country (user constraint)
- Envelopes: ledger systems 1.25B, site preparation 1B, personnel 750M, security 750M, testing 500M, legal/audit 250M, contingency 500M
- Contributions release in matched tranches (proposed four quarterly) with parity tolerance of ±10% (proposed)
- Each government compels and compensates its own operators and vendors from its own contribution

## Governance

- Equal co-chairs and double-key authorization with no casting vote or majority override
- Deadlock is proposed as no consensus within 5 days, escalating to referees then principals
- Automatic suspension uses enumerated objective triggers; resumption needs double-key authorization and documented corrective action

# Operations

## Staffing

- 24/7 full-time mirrored resident teams per site with at least two trained people per function
- Leave allowance (proposed 15%) and surge reserve (proposed 10–30%) are provisional until validated by a staffing dry-run
- No single-person critical functions, temporary-agency inspectors, or part-time inspectors are used

## Identity Verification

- Anchored on independently validated attestation, corroborated by physical inspection and customs records; no single source decisive
- Each country holds an independently verifiable ledger copy with immediate local recording and signed checkpoint exchange
- Provisional thresholds (sync 1 hour, divergence detection 4 hours, identity confidence above 95%, unverifiable under 3%) need validation by blind exercises

## Inspection

- Inspectors work in bounded zones with escorted movement, pre-validated instruments, and filtered evidence through a redaction gateway
- Vendor refusal is handled by supervised testing, filtered evidence, clean rooms or attestations; otherwise equipment is unverifiable
- Material unverifiable equipment fails the site; an estimated 10–40% could be unverifiable

## Exit Protocol

- Assigns every departure one of five dispositions with no tracking claims beyond the boundary

# Verification Exercises

- Reciprocal red-team challenge exercises run in staging, spare, maintenance and expansion areas without disrupting active compute
- Challenge exercises run roughly Months 1–2 (2026-11-12 to 2026-12-12) (proposed), with thresholds frozen before scored exercises and verdict by Month 3.25 (2027-01-20) (proposed)
- Go requires demonstrated reciprocal access and credible detection; Stop follows asymmetry, unverifiable equipment, shielding, divergence or withheld funding
- Success covers only monitored changes at participating declared sites

# Risk and Constraints

## Counterintelligence

- Relies on compartmentation, insider-threat red cell and tenure limits (proposed 6 months)
- Espionage risk remains high

## Legal and Operational Delays

- Legal challenges over compelling vendors could delay by an estimated 2–4 months
- Surge overlaps could exhaust contingency, with a proposed 75% draw trigger escalating to principals


# Review Assumptions
# Domain of the expert reviewer

Bilateral sovereign public-sector verification program management, with focus on governance, operational complexity, financial accountability and evidence systems under conditions of mutual distrust.

## Domain-specific considerations

- Deadlock resolution without casting vote or majority override; escalation procedures must prevent indefinite stalling.
- Attestation and evidence credibility as the core technical pillar; single-source failures in identity anchoring are fatal to the Go verdict.
- Vendor refusal and operator shielding as failure pathways; binding must be complete before gate or equipment becomes unverifiable.
- Entry-gate certification as the critical path; 90-day Phase One clock does not start until all conditions are met simultaneously.
- Matched-tranche parity accounting to prevent one-sided budget exposure or asymmetric spending feeding impaired-confidence allegations.
- Challenge-exercise containment; manufactured or false-positive exercises must not trigger automatic suspension or collapse the regime credibility.

# Issue 1 - Entry-Gate Certification as Critical Path

Bilateral instruments typically require 6–12 months to negotiate, approve and sign. If even one condition slips, the entire program stalls while sunk operational costs accumulate.

## Recommendation

Begin bilateral-instrument negotiation immediately (Month -6 to Month -3) in parallel to plan finalization. Establish a weekly bilateral steering committee to track negotiation progress and escalate bottlenecks within 48 hours. Commit both governments to a binding instrument-signature deadline by Month -2. Conduct vendor-binding certification by Month -1 and domestic-access-authority enactment by Month -1.5. Establish a phased gate: sign a skeletal executive agreement by Month -2 freezing core governance, then finalize operating procedures via annexes during Phase One if needed. If any condition cannot be certified by Month -1, escalate to principals for a documented go/no-go decision whether to delay or proceed with reduced scope. Document the grace-period rule: if one condition has a defined near-term resolution path within 4 weeks, allow partial operational start with a subset of sites.

## Sensitivity

Baseline: entry gate certification targeted by Month 0 (2026-10-12). If bilateral instrument signature slips by 6 weeks, estimated sunk cost in preliminary staffing, facility rental and site preparation: USD 100–200 million without operational data. If instrument signature delays to Month 4 (2027-02-12), Phase One operational start shifts by 3–6 months, compressing time for challenge exercises and verdict calibration and increasing political risk of withdrawal. If entry gate is certified by Month -1 (earliest feasible with aggressive parallel negotiation), Phase One can run uninterrupted Months 0–3 (2026-10-12 to 2027-01-12) with full data for a credible Go/Modify/Stop verdict. Gate-certification timeline is the single largest driver of whether Phase One completes as planned.

# Issue 2 - Attestation-Key Compromise and Vendor Refusal

Identity is anchored primarily on vendor-issued cryptographic attestation. If a critical vendor's keys are compromised, forged or withheld, or if the vendor refuses participation, layered corroboration (customs, maintenance logs, physical marks) may be insufficient to meet the proposed 95% identity-confidence threshold. Vendor concentration means 10–40% of declared equipment could become unverifiable.

## Recommendation

Finalize vendor binding by Month -1 with documented signatures from each critical vendor committing to verification terms. Establish a pre-qualified vendor registry so only suppliers accepting verification may serve declared sites; make refusal a supply-chain consequence. For each critical vendor tier, pre-stage accredited clean-room examination centers (funded from the USD 500M testing envelope) where refusing vendors can submit units for supervised testing without exposing source code. Require operators to declare their supplier list by Month -0.5 so missing vendors trigger entry-gate delays. Develop a multi-layer fallback evidence ladder for each vendor: (1) cryptographic attestation with independent validation; (2) customs records and shipment tracking; (3) physical inspection and equipment identifiers; (4) maintenance logs and witnessed movement. Mark no single layer as decisive; require at least two layers in agreement to confirm identity. If attestation cannot be independently validated for any vendor by Month 1 (2026-11-12), automatically escalate all equipment from that vendor to unverifiable status and demand bilateral principal-level resolution within 5 days.

## Sensitivity

Baseline: assume 10–15% of declared equipment comes from 3–4 critical vendors whose attestation keys are central to identity confidence. If one critical vendor's keys are compromised or withheld (estimated: medium likelihood), estimated 10–40% of all declared equipment becomes unverifiable depending on vendor mix. A 15% compromise of one vendor's attestation could reduce site identity confidence from 95% (target) to 80–85%, triggering site failure or a Modify verdict. Cost of clean-room examination centers for multiple vendor tiers: estimated USD 30–50 million (within USD 500M testing envelope). If vendor binding is incomplete at the entry gate, estimated delay to Phase One start: 2–4 months per unresolved vendor. Mitigation cost (pre-qualified registry, clean rooms, fallback evidence protocols): estimated USD 50–80 million, justified by reducing vendor-refusal risk from high to medium.

# Issue 3 - Deadlock and Suspension Mechanics

The plan does not specify how deadlocked decisions (e.g., disagreement on a site finding, disputed equipment identity, vendor-refusal response) are escalated to principals or resolved. Status-quo defaults allow findings to age without resolution, which itself becomes a Stop criterion. A government can obstruct by stalling at co-chair level while appearing compliant, weaponizing delay against the other side.

## Recommendation

Define Deadlock and Suspension Mechanics exhaustively in the bilateral instrument before signature (Month -2): specify deadlock as 'failure to reach bilateral consensus on a finding within 5 days' (proposed); establish a mandatory three-tier escalation path with fixed timers: Tier 1 — Co-Chair consensus attempt, Days 1–5; Tier 2 — Bilateral Technical Referee Panel (2 pre-cleared experts per side, funded from the USD 750M facilities envelope) issues dual-signed advisory fact statement within 3 days (Days 5–8); Tier 3 — Principal-Level Review (deputy secretary or equivalent) within 2 days (Days 8–10). Principals must render a decision within 5 calendar days or the status quo defaults to heightened inspection (not suspension) while escalation continues to the top political level. Enumerate automatic-suspension triggers using objective thresholds: (1) unverifiable equipment exceeds 3% of installed base per site; (2) ledger divergence exceeds 5% of events disputed; (3) reciprocal-access denial rate exceeds 15% variance between matched sites; (4) unresolved discrepancies age beyond 10 days. Explicitly exclude all deliberate challenge-exercise events from triggering suspension, impaired-confidence review or KPI violations; mark every injected scenario in the ledger with a 'CHALLENGE' tag before injection. If a challenge event is misclassified as operational and triggers suspension, escalate to principals immediately (within 2 hours) without waiting for normal deadlock timers, with automatic reinstatement pending adjudication. Document all escalation steps in the ledger with timestamps and decision outcomes.

## Sensitivity

Baseline: proposed 5-day co-chair consensus window, 3-day technical referee cycle, 5-day principal decision. If escalation timers are vague or absent, estimated deadlock age grows to 15–30 days per contested finding, feeding unresolved-discrepancy Stop criterion even if technical facts are minor. A single manufactured-incident false positive (estimate: 2–3 per Phase One if challenge exercises are not partitioned) can cascade into suspension, losing 3–7 days of operational work. Cost of principals-level crisis response per incident: estimated USD 10–20 million in emergency coordination and delay impact. Conversely, if escalation timers are locked in the bilateral instrument with no discretion to reinterpret, deadlock age remains bounded at ~13 days (Tier 1–3 cycles) and principals are forced to decide rather than defer, reducing suspension-cascade risk by an estimated 60–70%.

# Issue 4 - Evidence Filtering Adequacy

The chosen strategic path uses an operator-operated redaction gateway to convert raw records and telemetry into schema-limited evidence packets before they reach inspectors. The operator has strong incentive to filter aggressively to protect topology, workload details and source code. The counterpart's engineers audit gateway rules but not the inputs or outputs, creating asymmetric visibility. If filtered records lack serial numbers, firmware versions, cryptographic attestation digests or maintenance timestamps, identity confidence falls below the 95% (proposed) threshold and equipment is escalated to unverifiable status. This risk is not validated until live exercises.

## Recommendation

Design filter rules jointly before entry gate (Month -2), with each country's sensitive-asset experts writing the filters applied at the counterpart's sites. Require operator-operated redaction gateways to log every filter decision (which fields redacted, why, by which rule, timestamp) in the tamper-evident ledger for auditing. Define a non-negotiable minimum evidence schema (proposed): equipment serial number, firmware version, cryptographic attestation digest, maintenance-event timestamp, physical identifiers (markings, tamper seals), cluster membership and power-consumption state. Prohibit filtering of any schema field; if the gateway strips a schema field, automatically escalate to unverifiable-equipment status. Run filter-adequacy blind exercises in Month 0.5 (2026-10-27), before scored exercises begin, using staging areas to test whether critical fields are preserved under proposed filtering rules. Inject test substitutions and verify that redacted evidence still contains enough detail for intake inspectors to detect the substitution. If filter-adequacy exercises reveal missing critical fields, halt all scored exercises and renegotiate filters before proceeding. Calibrate challenge exercises to include substitution scenarios targeting edge cases where filtering might strip identity-critical information.

## Sensitivity

Baseline: proposed minimum evidence schema (serial number, firmware version, attestation digest, timestamp, physical marks) is sufficient for 95% identity confidence under conservative filtering. If aggressive filtering strips 1–2 schema fields (estimated: 20–30% risk), identity confidence drops to 80–85%, triggering unverifiable-equipment escalation for ~5–10% of units (estimate). Cost of filter-adequacy testing and renegotiation: estimated USD 10–20 million and 2–3 week delay. If filter-adequacy is not tested before scored exercises and substitution-detection failures emerge mid-Phase One, estimated reputational cost: program discredited, bilateral cooperation damaged, and Go verdict reversed or replaced with Stop. Mitigation: pre-designed joint filters and filter-adequacy exercises by Month 0.5 (2026-10-27) reduce this risk to medium; residual risk stays notable because operator incentives are always to filter more, not less.

# Issue 5 - Ledger Divergence and Reconciliation Latency

Each country holds an independently verifiable cryptographic ledger copy. Entries are recorded locally, and signed checkpoint exchanges keep the copies in sync. But if network latency, synchronization delays or deliberate tampering occur, the two copies diverge. No bounded reconciliation procedure exists if a divergence is detected; one side could claim its copy is authoritative while the other disputes. Unresolved divergence is listed as a Stop criterion, but the path from divergence detection to Stop decision is unclear.

## Recommendation

Establish Ledger Synchronization and Divergence Doctrine before entry gate (Month -2): specify checkpoint format (proposed: signed hash-chain with event count and timestamp), cadence (proposed: hourly checkpoints), and transport (dedicated authenticated IPsec tunnel with mutual TLS, not shared internet). Set divergence-detection latency KPI (proposed: 4-hour maximum). On divergence detection, trigger automatic reconciliation: exchange detailed event logs for the diverged period, compare and resolve mismatches within a fixed timeline (proposed: 24-hour reconciliation window). Employ neutral-party digest escrow or coupled-ledger attestation so either side can independently prove its copy was not rewritten post hoc. Log all reconciliation steps (which events diverged, why, root cause, resolution) in both ledgers. Define materiality threshold (proposed: >5 discrepancies per site per week) above which divergence triggers formal review rather than routine reconciliation; if unresolved divergence exceeds this threshold at any site, automatically flag as impaired-confidence candidate and escalate. If divergence age exceeds 10 days at any site, trigger automatic impaired-confidence review and potential suspension until resolved.

## Sensitivity

Baseline: proposed 1-hour checkpoint cadence and 4-hour divergence-detection latency keep the truth-finding window tight. If divergence detection slips to 12+ hours (realistic under poor network conditions), contested findings age without ground truth, estimated delay per incident: 1–3 days and escalations on equipment identity or exit disposition before truth is established. If synchronization transport relies on shared internet rather than dedicated pipe, estimated cyber-attack risk: medium (exfiltration of ledger copies or cryptographic keys). Cost of dedicated transport and neutral-party escrow: estimated USD 20–30 million within the USD 1.25B ledger envelope. If ledger divergence exceeds agreed thresholds, Phase One triggers impaired-confidence suspension automatically; estimated operational halt: 2–5 days per incident. Conversely, if synchronization is hardened with dedicated transport, frequent checkpoints and neutral escrow, divergence risk is reduced to low; estimated 95%+ confidence that divergences are detected and resolved within 4-hour window.

# Review conclusion

The Consortium is an extraordinarily complex bilateral verification program whose success depends entirely on credible, hard-to-contest evidence of detection capability and reciprocal access within a short 90-day window. The three most critical missing or under-explored assumptions are: (1) Entry-gate readiness is assumed by Month 0 (2026-10-12), but bilateral-instrument negotiation and vendor binding typically consume 6–12 months; unless negotiation begins immediately in parallel, Phase One will not start on schedule, burning USD 100–200 million in sunk costs. (2) Identity confidence is anchored on attestation-key validation, but vendor refusal or key compromise could render 10–40% of equipment unverifiable; vendor binding must be complete by Month -1 with fallback evidence ladders and clean-room examination centers. (3) Deadlock resolution lacks defined escalation timers and automatic resolution rules; without fixed timers and principal-level enforcement, contested findings age indefinitely, weaponizing delay as an obstruction tool. Secondary risks span evidence-filtering adequacy (not validated until exercises), ledger divergence (4-hour KPI is aggressive and depends on hardened transport), matched-site equivalence (asymmetric sites invite parity disputes), and the inherent political fragility of a bilateral verification program. Mitigation requires starting bilateral negotiation now, completing vendor binding by Month -1, locking escalation procedures and automated suspension triggers in the bilateral instrument, and testing filter adequacy and ledger synchronization before Phase One operational clock starts.