## Suggestion 1 - New START Treaty Inspection and Verification Regime (US–Russia)

Bilateral treaty (in force 2011, expired February 2026 per public record; status after expiry not verified) with reciprocal on-site inspections, data exchanges, unique identifiers on strategic delivery vehicles, and a Bilateral Consultative Commission (BCC) for disputes. Inspectors verified declared items at declared facilities under mutual distrust. Inspections were suspended in 2020 (COVID) and later disputed by Russia.

### Success Metrics

Number of inspections completed per year against treaty quota (see US State Department reports)
Unique-identifier coverage of declared items
Suspension of inspections in 2020 and Russia's 2023 suspension show reciprocity can fail; use as a Stop-condition analogue

### Risks and Challenges Faced

Asymmetric access and reciprocity disputes: addressed through quota parity and the BCC; ultimately not fully resolved.
Inspector escort and sensitive-site protection: managed through agreed inspection procedures and pre-notified timelines.
Political deterioration: the treaty lacked a mechanism to insulate verification from politics; the Consortium needs double-key and a gate backstop.

### Where to Find More Information

US State Department Bureau of Arms Control, Deterrence and Stability: state.gov (New START pages)
Arms Control Association: armscontrol.org (New START fact sheets)
Congressional Research Service reports on New START

### Actionable Steps

Contact the State Department Bureau of Arms Control, Deterrence and Stability via its public press and congressional liaison channels.
Approach the Arms Control Association research staff via armscontrol.org for former-inspector referrals.
Seek former On-Site Inspection Agency or Defense Threat Reduction Agency inspection-unit alumni via DTRA public affairs.

### Rationale for Suggestion

Closest bilateral analogue: reciprocal inspections of declared items by mutually distrustful great powers, with unique identifiers and a dispute body. Geographically and politically distant from US–China, but the structure of parity, quotas and dispute resolution maps directly onto the reciprocity gate and double-key governance.
## Suggestion 2 - OPCW Chemical Weapons Convention Industry Verification and Challenge Inspections

The Organisation for the Prohibition of Chemical Weapons (The Hague, operating since 1997) inspects declared industrial facilities worldwide, including in both the US and China. It uses managed access to protect confidential business information, with inspected parties able to shield sensitive equipment. Challenge inspections are provided for but rarely invoked.

### Success Metrics

Annual inspection counts and declared-facility coverage in OPCW annual reports
Clean-audit results of the OPCW budget and financial statements
Confidentiality-breach incidents (OPCW reports few public cases; exact figures not verified)

### Risks and Challenges Faced

Protecting confidential commercial information: handled through managed access, inspector confidentiality undertakings and an internal confidentiality regime.
Inspector conduct and espionage concerns: addressed by the staff confidentiality code, sworn secrecy and investigation procedures.
State disputes over findings: handled through the Executive Council and a consultation process.

### Where to Find More Information

OPCW website: opcw.org (verification, managed access and confidentiality policy)
OPCW Annual Reports and Programme and Budget documents
Chemical Weapons Convention text, Verification Annex

### Actionable Steps

Contact the OPCW Verification Division and the Office of Confidentiality and Security via the opcw.org contact page.
Request a briefing from OPCW Inspectorate on managed-access practice.
Consult US and Chinese National Authorities for the CWC, which each country maintains, for national implementation experience.

### Rationale for Suggestion

Both the US and China already host OPCW inspections of private and state-owned industry, so this is the most culturally and jurisdictionally proximate example of inspectors working inside both countries. It directly informs bounded zones, filtered evidence and operator-run protection of IP.
## Suggestion 3 - IAEA Safeguards and Euratom Joint Inspection Arrangements

IAEA safeguards verify declared nuclear material and equipment through containment and surveillance (seals, cameras), material accountancy and inspections. In the EU, IAEA and Euratom ran partnership approaches with shared and cross-checked verification, including independent measurements and analytical laboratories.

### Success Metrics

Annual Safeguards Implementation Report conclusions per state
Seal and surveillance coverage rates and anomaly resolution (aggregate figures in IAEA reports)
Independent-lab sample cross-check consistency (qualitative; figures not verified)

### Risks and Challenges Faced

Layered evidence without a single decisive source: addressed by combining accountancy, seals, surveillance and sampling.
Duplicated inspection burden between two verifiers: reduced via joint use of equipment and data-sharing arrangements.
Open anomalies lingering: handled by state-level evaluation and follow-up requests.

### Where to Find More Information

IAEA Safeguards: iaea.org/topics/safeguards
IAEA Safeguards Implementation Reports (annual)
Euratom Safeguards: energy.ec.europa.eu

### Actionable Steps

Contact the IAEA Department of Safeguards through iaea.org press and information office.
Approach the European Commission DG ENER Euratom Safeguards directorate for joint-verification experience.
Engage the Institute of Nuclear Materials Management (INMM) for retired safeguards inspectors.

### Rationale for Suggestion

Provides the model for layered evidence (seals, surveillance, accountancy), cross-checking by two verifiers, and a bounded knowledge claim, matching the Consortium's rule that no single source is decisive. Distant domain, but mature and well documented.
## Suggestion 4 - SECONDARY: US DMEA Trusted Foundry / Trusted Supplier Accreditation Program

Secondary suggestion. A US Department of Defense program accrediting microelectronics suppliers for supply-chain integrity, using audits and chain-of-custody controls. Fewer details are given; confirm scope and current status with the program office.

### Success Metrics

Number of accredited suppliers (public figure not verified)
Audit pass rates (not published; ask the program office)

### Risks and Challenges Faced

Vendor cooperation with audits: handled through accreditation as a condition of defence business.
Protecting trade secrets during audits: managed through confidentiality agreements and cleared auditors.

### Where to Find More Information

Defense Microelectronics Activity: dmea.osd.mil
DoD Trusted Systems and Networks policy documents

### Actionable Steps

Contact the Defense Microelectronics Activity public affairs or accreditation office listed at dmea.osd.mil.

### Rationale for Suggestion

Informs vendor binding, chain-of-custody and accredited-examiner pools for the vendor-refusal ladder. Secondary because it is unilateral, not bilateral, and covers only the US.

## Summary

No precedent exists for bilateral US–China verification of computing equipment (not verified), so the references below are analogues from arms control, chemical weapons inspection and supply-chain assurance. The strongest are the New START inspection regime, OPCW industry inspections under the Chemical Weapons Convention, and the IAEA safeguards regime with Euratom. A secondary suggestion is the US Trusted Foundry / DMEA accreditation program. They inform mirrored inspection, bounded access with IP protection, challenge inspections, and entry-condition sequencing. Geographic or cultural proximity is limited: only the US–Russia case is bilateral, and no US–China verification case exists. All figures and contacts should be confirmed directly with the named organizations. Fiscal and revenue framing is Not applicable; value is measured as mission justification and public accountability.