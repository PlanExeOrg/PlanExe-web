## Suggestion 1 - New START Treaty inspection regime and Bilateral Consultative Commission (US–Russia)

Bilateral treaty (entered into force 2011) with on-site inspections, unique identifiers on treaty-limited items, data exchanges and notifications, and a standing Bilateral Consultative Commission (BCC) resolving compliance questions. Inspections were paused from 2020 and Russia suspended participation in 2023; the treaty expired in February 2026 (status after expiry not verified). Relevant to equal-party verification, unique identifiers, and dispute handling without a supranational authority.

### Success Metrics

Inspections conducted under agreed annual quotas from 2011 until the 2020 pause (counts not verified)
Regular data exchanges and notifications maintained through the treaty period
Dispute channel (BCC) met repeatedly; later sessions lapsed
Weakness: inspections halted, showing the regime's dependence on political will

### Risks and Challenges Faced

Reciprocity disputes over access: handled via BCC sessions, ultimately not fully resolved
Intrusiveness vs. secrecy: managed by limiting inspections to declared sites and types
Political breakdown: no enforcement path; relevant to the Consortium's funding and suspension triggers
Inspector safety/health disruptions (2020): paused inspections, showing need for surge and leave coverage

### Where to Find More Information

US Department of State, Bureau of Arms Control, Deterrence and Stability: New START Treaty pages (state.gov)
Treaty Protocol on Inspection Activities (published on state.gov)
Arms Control Association fact sheets on New START (armscontrol.org)
Congressional Research Service reports on New START (crs.gov)

### Actionable Steps

Contact the State Department Bureau of Arms Control, Deterrence and Stability, requesting former inspection and BCC delegation staff for interviews
Approach the Arms Control Association research staff via armscontrol.org for expert referrals
Ask the Defense Threat Reduction Agency (on-site inspection directorate legacy) for lessons-learned briefings via its public affairs office

### Rationale for Suggestion

Closest bilateral, adversarial, reciprocal equipment-verification precedent. Unique identifiers, notification of movements, and inspection quotas map to the Intake and Exit Protocols and parity accounting. Geographic proximity to a US–China setting is limited; the US–Russia precedent is the nearest bilateral one. Its breakdown also illustrates the Stop conditions (access asymmetry, suspended inspections).
## Suggestion 2 - IAEA Safeguards: surveillance, seals and Additional Protocol verification

The International Atomic Energy Agency verifies declared nuclear material and equipment in states using seals, tamper-indicating devices, surveillance cameras, inventory verification, and complementary access under the Additional Protocol. Operating continuously since the 1970s across many states, including remote data transmission and ledger-like inspection records. Includes the Department of Safeguards' evidence evaluation and the Safeguards Analytical Laboratories.

### Success Metrics

Annual Safeguards Implementation Report conclusions per state (public)
Number of facilities and states under safeguards (published annually)
Independent seal and surveillance methods accepted by states
Weakness: cannot prove absence of undeclared material, matching the Consortium's stated limits

### Risks and Challenges Faced

Host-state confidentiality concerns: addressed through confidentiality rules, managed access and information security
Tamper risk to surveillance and seals: mitigated by tamper-indicating designs and independent authentication of instruments
Inspector workload and resource limits: handled by risk-informed scheduling
Disputed findings: referred to the Board of Governors (a mechanism the Consortium lacks, so double-key escalation is required)

### Where to Find More Information

IAEA Safeguards pages (iaea.org/topics/safeguards-and-verification)
IAEA Safeguards Glossary and Additional Protocol model text (INFCIRC/540)
IAEA Safeguards Implementation Report (annual)
IAEA Safeguards Techniques and Equipment handbook

### Actionable Steps

Contact the IAEA Department of Safeguards, Division of Technical and Scientific Services, via the agency's public contact channels for technique briefings
Request expert exchange via national laboratories with safeguards programs (e.g., US DOE national laboratories' safeguards groups)
Engage the ESARDA or INMM safeguards communities via their secretariats for practitioner introductions

### Rationale for Suggestion

Strongest real precedent for identity continuity (seals, unique identification), layered evidence with no single decisive source, and design of inspection zones that protect proprietary information (managed access and confidentiality rules). Differs because it is multilateral and agency-led rather than a mirrored bilateral body, so the Consortium's equal co-chair mechanism must be added.
## Suggestion 3 - OPCW Chemical Weapons Convention verification: challenge inspections and managed access

The Organisation for the Prohibition of Chemical Weapons verifies the CWC (in force 1997) through declarations, routine industry inspections, destruction verification with continuous monitoring, and challenge inspections with managed access to protect sensitive information. Destruction-witnessing at declared facilities for stockpiles has been verified by inspectors; the Technical Secretariat runs proficiency-tested designated laboratories.

### Success Metrics

Verified destruction of declared stockpiles reported by OPCW (the US completed destruction in 2023, per OPCW; confirm)
Industry inspections completed each year (annual OPCW report)
Proficiency tests for designated laboratories
Mock challenge inspection exercises conducted

### Risks and Challenges Faced

Protecting sensitive information during inspections: addressed through managed-access rules and negotiated perimeters
Credibility of destruction evidence: mitigated by continuous monitoring and sampling
Politicization of challenge inspections: rarely invoked in practice, showing limits of untested procedures
Laboratory reliability: addressed by proficiency testing and accreditation

### Where to Find More Information

OPCW website (opcw.org), Verification and Inspections pages
Chemical Weapons Convention Verification Annex text
OPCW Annual Reports
OPCW Designated Laboratories pages

### Actionable Steps

Contact the OPCW Inspectorate and Verification Division via opcw.org contact channels
Ask the US and Chinese National Authorities for the CWC (NAs) for implementation lessons
Request participation in an observer-style briefing on managed access via OPCW external relations

### Rationale for Suggestion

Direct precedent for the Exit Protocol (witnessed destruction with verification), managed access in bounded zones (protecting unrelated sensitive information), accredited independent laboratories for evidence, and mock challenge-inspection exercises. Multilateral rather than mirrored bilateral; US and China are both states parties, giving some cultural proximity of participation.
## Suggestion 4 - [Secondary] CTBTO International Monitoring System and Integrated Field Exercise

The Comprehensive Nuclear-Test-Ban Treaty Organization operates a global network of monitoring stations with authenticated data transmission and tests on-site inspection capability through Integrated Field Exercises (e.g., IFE08 in Kazakhstan, IFE14 in Jordan).

### Success Metrics

Number of certified IMS stations (published by CTBTO)
Exercise lessons-learned reports published after IFE events

### Risks and Challenges Faced

Station data authenticity: addressed with digital signatures and authentication
Exercise realism vs. cost: addressed with scenario-based exercise design

### Where to Find More Information

CTBTO website (ctbto.org), Verification Regime and On-Site Inspection pages

### Actionable Steps

Contact the CTBTO Preparatory Commission's Public Information office or On-Site Inspection Division via ctbto.org

### Rationale for Suggestion

Secondary: informs authenticated data chains, calibrated detection thresholds, and large-scale blind-style exercise design. Treaty not in force, and it does not cover declared-equipment inventories.

## Summary

The Consortium is a first-of-kind bilateral US–China verification pilot, so no exact precedent exists. The closest real references are: (1) the New START/INF on-site inspection and Bilateral Consultative Commission regimes, (2) the IAEA safeguards and Additional Protocol system, including surveillance and seals, (3) the Chemical Weapons Convention verification regime run by the OPCW, with its challenge inspections and managed access, and (4) the CTBTO International Monitoring System and its Integrated Field Exercises. Secondary references cover the Open Skies Treaty. Geographic and cultural proximity is limited: US–Russia and multilateral precedents dominate, and no real US–China equipment-verification regime exists. Figures below are not verified; confirm with the named organizations.