## Suggestion 1 - IAEA Safeguards System (including JCPOA Verification and Monitoring in Iran, 2016 onward)

The International Atomic Energy Agency verifies declared nuclear material and equipment through inventory accounting, seals, cameras, and inspections. Under the 2015 JCPOA, the IAEA added continuous monitoring of declared centrifuge manufacturing and storage, plus a procurement channel for dual-use items. It is a multi-decade, multinational program run from Vienna. The JCPOA monitoring was sharply curtailed after 2021, which shows the regime's fragility.

### Success Metrics

Continuity of knowledge on declared items (qualitative, per IAEA reports).
Regular public IAEA verification reports (quarterly during JCPOA).
Number of inspection days and installed monitoring devices (figures not verified; request from IAEA).
Loss of continuity after curtailed access, a failure indicator.

### Risks and Challenges Faced

Host-state access limits: mitigated by pre-agreed access arrangements and managed-access rules; later curtailment shows the limit of this mitigation.
Protecting proprietary information: handled through confidentiality regimes and restricted inspector knowledge.
Data gaps when monitoring lapses: mitigated by sealed recordings and continuity-of-knowledge rules; lesson for ledger synchronization bounds.
Political contestation of findings: partly handled by Board of Governors reporting; the Consortium needs its own double-key deadlock rules.

### Where to Find More Information

https://www.iaea.org (Safeguards section and Board of Governors reports)
IAEA Safeguards Glossary and Safeguards Implementation Reports on iaea.org
https://www.armscontrol.org (Arms Control Association JCPOA monitoring summaries)

### Actionable Steps

Contact the IAEA Department of Safeguards through its public information office at iaea.org to request technical briefings on seals, surveillance and continuity of knowledge.
Approach the IAEA Office of Legal Affairs for the structure of safeguards agreements and managed access.
Seek former inspectors via IAEA alumni and think-tank networks (for example Arms Control Association or Federation of American Scientists) for interviews.

### Rationale for Suggestion

Closest analogue for declared-equipment change verification: tracking arrival, storage, transfer and removal of declared items with layered evidence (seals, surveillance, records, physical checks) while excluding undeclared-site detection. It also shows how to protect proprietary information through managed access. Geographic proximity is limited; chosen for mechanism fit. Not a bilateral US–China arrangement.
## Suggestion 2 - OPCW Chemical Weapons Convention Industry Verification Regime

The Organisation for the Prohibition of Chemical Weapons, based in The Hague, conducts declared-facility inspections under the Chemical Weapons Convention (in force since 1997). It uses declarations, data monitoring, on-site inspections and managed-access procedures at commercial and state facilities, including destruction verification witnessed by inspectors.

### Success Metrics

Share of declared chemical weapons stockpiles destroyed under verification (OPCW reports; exact figure not verified here).
Number of industry inspections per year (published in OPCW annual reports).
Absence of confirmed proprietary information breaches (OPCW states confidentiality as a core principle; verify with OPCW).

### Risks and Challenges Faced

Protecting commercial secrets during inspections: mitigated by managed-access rules, inspector confidentiality obligations and inspection-zone limits.
Inspector burden and cost: handled via sampling and risk-based site selection.
Disputes over findings: addressed through consultation and clarification procedures and an Executive Council.
Verification of destruction timelines: handled with continuous witnessed monitoring.

### Where to Find More Information

https://www.opcw.org (Verification and Industry pages)
OPCW annual reports on opcw.org
Chemical Weapons Convention Verification Annex text on opcw.org

### Actionable Steps

Contact the OPCW Verification Division via the public contact form on opcw.org for briefings on managed access and confidentiality.
Request the Confidentiality Policy and Verification Annex guidance from OPCW Legal Office.
Interview national authority staff (for example the US Commerce Department Bureau of Industry and Security CWC office) on industry inspection preparation.

### Rationale for Suggestion

Strong fit for managed access at commercial operators, confidentiality for proprietary processes, and witnessed destruction as a disposition type like the Exit Protocol. Covers both private firms and state sites, similar to the US hyperscale versus Chinese state-operated asymmetry. Not US–China bilateral, but both states are parties.
## Suggestion 3 - US–Russia START I / New START Verification and Joint Compliance and Inspection Commission

The START I Treaty (1991–2009) and New START (2011–2026) used on-site inspections, unique identifiers on declared items, notifications, data exchanges and a bilateral commission (Joint Compliance and Inspection Commission, later the Bilateral Consultative Commission) to resolve disputes. Inspections were suspended in 2020 and Russia suspended participation in New START in 2023; the treaty expired in February 2026.

### Success Metrics

Multiple thousands of inspections conducted under START I (approximate; verify with State Department archives).
Treaty-limited deployed warhead data exchanged twice yearly under New START (State Department records).
Sustained operation for roughly 25 years across both treaties, ending in suspension and expiry.

### Risks and Challenges Faced

Inspector reciprocity disputes: managed through equal rights written into the treaty.
Disagreement on compliance findings: handled in the bilateral commission without a casting vote.
Protecting sensitive design data: handled by limited-access inspection protocols.
Political breakdown: not fully mitigated; inspections lapsed, supporting the Consortium's Stop triggers and funding conditions.

### Where to Find More Information

https://www.state.gov (Bureau of Arms Control, Deterrence and Stability archives)
https://www.armscontrol.org (New START fact sheets)
https://www.sipri.org (arms control yearbook chapters)

### Actionable Steps

Contact the State Department Bureau of Arms Control, Deterrence and Stability public affairs office for declassified verification history.
Approach SIPRI's arms control program or the Arms Control Association research staff for expert interviews.
Consult former US On-Site Inspection Agency (now DTRA) alumni via the Defense Threat Reduction Agency public affairs office.

### Rationale for Suggestion

Best bilateral precedent for mirrored inspection, unique identifiers on declared items, notification rules and equal-footing dispute commissions between adversaries. Also shows failure modes: suspension and eventual lapse. Not a computing regime and not US–China.
## Suggestion 4 - CTBTO International Monitoring System and International Data Centre (SECONDARY SUGGESTION)

The Comprehensive Nuclear-Test-Ban Treaty Organization, in Vienna, operates a global network of monitoring stations and a data centre that distributes authenticated data to member states. Stations use tamper-protected, digitally signed data transmission to the data centre. The treaty has not entered into force, but the system operates provisionally.

### Success Metrics

Share of planned stations certified (CTBTO publishes; figure not verified here).
Data availability rates published by CTBTO.

### Risks and Challenges Faced

Data authentication across rivals: handled with digital signatures and certified stations.
Station host cooperation: handled by host agreements and certification.

### Where to Find More Information

https://www.ctbto.org (Verification Regime pages)

### Actionable Steps

Contact the CTBTO Public Information office via ctbto.org to request technical contacts on data authentication and station certification.

### Rationale for Suggestion

Secondary: relevant for authenticated, signed data flows shared with all parties, equal data access for rival states, and station certification procedures, informing ledger synchronization and key custody. Less relevant for physical inspection.

## Summary

No direct precedent exists for US–China hardware-change verification of frontier computing. The closest real references are arms-control and nonproliferation verification regimes: the IAEA safeguards system, the OPCW industry inspection regime, and US–Soviet/Russian START verification with its Joint Compliance and Inspection Commission. The IAEA–Iran Joint Comprehensive Plan of Action (JCPOA) monitoring adds a relevant example of continuous, equipment-focused monitoring. Secondary reference: the Comprehensive Nuclear-Test-Ban Treaty Organization (CTBTO) International Monitoring System. Geographic and cultural proximity is limited: none of these is US–China, so each is chosen for its mechanisms (declared-item accounting, seals and surveillance, managed access, bilateral commissions, dispute procedures). Figures are not independently verified here; contact the named organizations for authoritative data. Commercial elements are Not applicable; the lessons concern mission justification, governance and fiscal accountability.