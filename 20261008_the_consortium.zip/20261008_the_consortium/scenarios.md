# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** Very high ambition at national-security scale: a first-of-kind bilateral US–China verification mechanism with a USD 5 billion budget (user constraint), split 50/50, full-time mirrored inspectorates and replicated national ledgers. Operational scope is deliberately narrow: a 90-day Phase One test at a small matched set of declared sites, limited to declared-equipment change verification.

**Risk and Novelty:** High novelty and high political and technical risk. There is no direct precedent for hardware-change verification of frontier computing equipment between adversaries. Trust is assumed absent. Main risks are IP exposure, operator or government shielding, gaming of evidence rules, thin statistics from few events per exercise type, and disputes over thresholds. Phase One is an experimental proof-of-concept whose clock starts only after strict entry conditions are met.

**Complexity and Constraints:** Very complex. Constraints: equal co-chairs with double-key authorization and no casting vote; defined deadlock, impaired-confidence and automatic-suspension procedures; no single decisive evidence source; no workload, model-weight or hidden-facility verification; exercises must not interrupt active computation; thresholds must be marked provisional or TBD with a validation path. Staffing is large, mirrored and full-time, with separation of duties. Budget envelopes are fixed, and every expense must map to one.

**Domain and Tone:** Sovereign public-sector arms-control-style verification. The tone is formal, impersonal and governance-heavy. Commercial elements (revenue, investors, customers) are not applicable and are replaced by mission justification, appropriations governance and fiscal accountability.

**Holistic Profile:** A rigorous but bounded, reciprocity-driven experimental verification pilot between mutually distrustful great powers. It needs credible detection and visible parity to both sides, preserves operations and sensitive technology, resists gaming and stalling without brittle shutdowns, and states its statistical limits honestly. Its ideal strategy balances rigor with workability, with reciprocal test design, partial suspension and provisional validated thresholds.

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Pragmatic Foundation: Reciprocal Proof with Controlled Risk
**Strategic Logic:** This pathway balances rigor and workability. Confidential rotating evidence rules validated against blind outcomes resist gaming without the false-positive load of pure contradiction scoring. Each side's red team tests the verification it most doubts, under an independent referee, which builds reciprocal confidence. Partial suspension keeps unrelated verification running, and thresholds are provisional until validated, which fits the thin data from a short test.

**Fit Score:** 9/10

**Why This Path Was Chosen:** Rotating confidential evidence rules resist gaming, each side's red team tests what it doubts most (directly supporting reciprocal-access parity), and partial suspension keeps unrelated verification running. Provisional, validated thresholds match the thin-data reality and the plan's provisional/TBD requirement. Compartmentalized inspectors fit the information-barrier workstream.

**Key Strategic Decisions:**

- **Layered Evidence Weighting Model:** Use a confidential, rotating combination rule set by accountable specialists from both sides, so operators cannot learn which evidence combinations suffice, with weights validated against blind-exercise outcomes.
- **Deadlock and Suspension Mechanics:** Pause only the disputed function through automatic partial suspension after a fixed period, leaving unrelated verification running and recording each pause in the ledger as an event.
- **Blind Challenge Exercise Control:** Have each country's red team design challenges for the other country's inspectorate, so each side tests the verification it has the most reason to doubt, with an independent referee scoring results.
- **Verdict Threshold Calibration Method:** Set provisional thresholds before the first exercise, mark each as provisional or TBD, and lock them only after a mirrored panel validates them against pilot data.
- **Inspector Information Firewall Doctrine:** Compartmentalize inspector knowledge by role and site, with post-assignment debriefs and monitored cooling-off periods before any reassignment to other duties.

**The Decisive Factors:**

- **Fit with the plan's profile:** The plan is an ambitious but bounded first-of-kind test between distrustful parties. It needs credible detection, visible reciprocity and operational safety at once, and the Pragmatic Foundation balances all three.
- **Reciprocity:** Cross-designed red-team challenges under an independent referee directly test parity. Each side probes the verification it doubts most.
- **Anti-gaming without overload:** Confidential rotating evidence rules, validated against blind outcomes, resist gaming and avoid the false-positive load of contradiction scoring.
- **Resilient governance:** Partial suspension of only the disputed function fits double-key rules with no casting vote and keeps verification running.
- **Honest statistics:** Provisional thresholds, locked after validation, match the thin 90-day data.
- **Why not the Pioneer's Gambit:** Its unannounced challenges and automatic suspension risk production disruption and brittle shutdowns.
- **Why not the Conservative Anchor:** Its operator-side screening invites shielding, and its advisory-only panel and Modify-default bands weaken detection credibility and deadlock resolution.

---
## Alternative Paths
### The Pioneer's Gambit: Maximum Detection Pressure
**Strategic Logic:** This pathway treats Phase One as a hard stress test of the verification concept. It uses contradiction-based identity scoring, unannounced interleaved challenges, automatic age-triggered impaired-confidence status, and independent scoring. It accepts higher adjudication load, more operator friction and some disruption risk in exchange for the most realistic detection data. It also removes any chance for a government or operator to stall or bargain over outcomes.

**Fit Score:** 5/10

**Assessment of this Path:** Maximizes detection realism and removes stalling, but contradiction scoring, unannounced interleaved challenges and a sealed interface raise false positives, adjudication overload and production-disruption risk. Age-triggered automatic impaired-confidence can also cause brittle suspension in a 90-day test with thin data, and it conflicts with the no-interruption constraint.

**Key Strategic Decisions:**

- **Layered Evidence Weighting Model:** Score identity confidence by contradiction rather than accumulation, so any unresolved conflict between two evidence layers lowers the rating regardless of how much other evidence supports identity.
- **Deadlock and Suspension Mechanics:** Link suspension to the age of unresolved discrepancies, so a finding left open past a set limit moves the site into impaired-confidence status without a decision by either co-chair.
- **Blind Challenge Exercise Control:** Interleave unannounced challenges with routine operations throughout the test rather than scheduling discrete exercise windows, so inspectors cannot adjust their behavior for known test periods.
- **Verdict Threshold Calibration Method:** Have an independent testing body, not the co-chairs, score exercise results against a pre-registered rubric, with the co-chairs allowed only to confirm or contest the scoring through double-key procedure.
- **Inspector Information Firewall Doctrine:** Run inspectors through a sealed observation-and-report model in which they hold only the filtered evidence interface, with raw observations retained in site custody for later audited review.

### The Conservative Anchor: Proven Rules, Wide Bands, Operator Comfort
**Strategic Logic:** This pathway puts stability, operator acceptance and protection of sensitive infrastructure first. It uses a published corroboration rule, an advisory technical panel for deadlocks, an independent test authority running all exercises, outcome bands that default to Modify when results are ambiguous, and operator-side security officers on every view. It gives up some speed, detection sharpness and gaming-resistance to lower the risk of IP exposure, production disruption and early political breakdown. The advisory panel and operator-side officers also carry risks: weaker deadlock resolution and possible operator shielding, which the Stop criteria must catch.

**Fit Score:** 4/10

**Assessment of this Path:** Protects operators and IP, but operator-side screeners on every view invite the shielding the plan lists as a Stop trigger. An advisory-only deadlock panel is weak against stalling, a published corroboration rule is easier to game, and bands defaulting to Modify weaken the credible-detection requirement for Go.

**Key Strategic Decisions:**

- **Layered Evidence Weighting Model:** Apply a published rule requiring corroboration from a minimum number of independent evidence categories, with no category sufficient alone, and keep the category list in the confidential versioned schedule.
- **Deadlock and Suspension Mechanics:** Refer deadlocked findings to a standing panel of technical specialists nominated equally by both sides, whose advisory conclusion is non-binding but is published to both co-chairs and logged.
- **Blind Challenge Exercise Control:** Fund an independent test authority with mixed-nationality staff to design and run all exercises, with each government's inspectorate blind to the scenarios until execution.
- **Verdict Threshold Calibration Method:** Define thresholds as bands rather than points, so results inside a band trigger Modify by default and only results clearly outside it support Go or Stop.
- **Inspector Information Firewall Doctrine:** Pair each inspector with an operator-side security officer who pre-screens each view and recording, trading some speed for operator confidence that no unrelated infrastructure was exposed.
