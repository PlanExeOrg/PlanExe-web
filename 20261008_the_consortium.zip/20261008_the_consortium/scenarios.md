# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** Sovereign, bilateral US–China program with USD 5 billion (user constraint) split 50/50. Scope is deliberately narrow: verify declared-equipment changes at a small matched set of datacenters. Staffing is large, with full-time mirrored units. It is high-stakes in geopolitical terms but bounded in technical scope, with explicit exclusions: no total-capacity estimates, no workload or weight inspection, no hidden-facility claims.

**Risk and Novelty:** Novel and politically high-risk, with no known precedent for bilateral verification of frontier computing equipment (not verified). Trust is assumed absent. The main risks are IP and counterintelligence exposure, consent withdrawal, asymmetric access, vendor refusal, and ledger divergence. The plan is a 90-day test whose outcome (Go/Modify/Stop) depends on credible and defensible evidence, so it needs a conservative, auditable design rather than an exploratory one.

**Complexity and Constraints:** High operational complexity: shift coverage, mirrored teams, separation of duties, a replicated tamper-evident ledger, Intake and Exit Protocols, and third-party access. Hard constraints: mandatory entry conditions that sit outside the 90-day clock; double-key authority with no casting vote; exercises limited to staging, spare, maintenance or expansion areas with no interruption of active computation; bounded zones and filtered evidence; KPI thresholds that must be justified, with unsupported figures marked provisional and validated.

**Domain and Tone:** Government national-security and fiscal-accountability tone. It is formal, procedural, and neutral on trust. It is not commercial. Emphasis is on auditability, reciprocity, protection of sensitive technology, and principled decision rules.

**Holistic Profile:** A cautious, rules-first, audit-heavy sovereign verification pilot. It is built to produce a clean, defensible, mutually acceptable Go/Modify/Stop result. That calls for strict entry gating, bounded inspection zones, independent blind exercises kept away from live production, and pre-committed decision criteria. Adaptive or exploratory mechanisms are secondary to predictability and non-reinterpretability.

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Fixed-Rules Bastion
**Strategic Logic:** Predictability, auditability and minimal exposure of sensitive technology come first. Every entry condition is certified before the clock starts. Corroboration rules, zone boundaries and decision thresholds are fixed and double-key signed in advance. A single independent testing unit runs the exercises on a sealed schedule. This minimizes room for reinterpretation, goalpost disputes and production disruption. In exchange, it accepts slower entry, more exposure to learned evasion, and a higher chance that a mis-set provisional figure drives a Modify outcome.

**Fit Score:** 8/10

**Why This Path Was Chosen:** Fully certified entry conditions match the plan's explicit gate-before-clock logic. Fixed narrow zones, operator-run auditable redaction, fixed corroboration rules and double-key-signed thresholds fit the low-trust, IP-protective, audit-centred posture. The main weakness is that fixed provisional thresholds may be mis-set; the plan's own Modify outcome and the protocol-change route partly absorb this.

**Key Strategic Decisions:**

- **Reciprocity Gate Stringency:** Require every entry condition to be fully satisfied and independently certified by both sides before the Phase One clock starts, with no partial-start exceptions.
- **Evidence Layer Weighting:** Use a fixed, pre-agreed corroboration rule in which identity is confirmed only when a stated minimum number of independent evidence layers agree, with every layer's provenance recorded.
- **Inspection Zone Boundary Design:** Fix narrow, physically marked zones limited to staging, spare inventory, and maintenance bays, with all evidence passing through an operator-run redaction step that inspectors can audit.
- **Challenge Exercise Independence:** Have an independent testing unit designed by both governments run all exercises in a sealed, double-key schedule, with only a small group at each site aware of the timing.
- **Go-Modify-Stop Threshold Calibration:** Fix every decision threshold and its justification before the first exercise, double-key sign them, and permit changes only through a documented protocol change that is itself recorded.

**The Decisive Factors:**

- **Gate:** the plan treats signed instruments, appropriations, domestic authority, sites, inspectors, vendor participation and the equipment schedule as mandatory entry conditions outside the 90 days. Full certification before the clock is the direct expression of this. It also keeps setup failures from being logged as verification failures.
- **Low trust and IP protection:** narrow, marked zones with auditable operator-run redaction fit the bounded-zone, filtered-evidence requirement. They limit counterintelligence exposure and the risk of consent withdrawal.
- **No goalpost disputes:** fixed corroboration rules and double-key-signed thresholds support a Go/Modify/Stop verdict that neither government can reinterpret. Provisional figures remain marked and are changed only through recorded protocol changes.
- **Pioneer's Gambit is less suitable:** conditional starts, real-event scoring and randomized evidence rules conflict with the entry conditions and the no-disruption constraint, and they invite disputes.
- **Pragmatic Foundation is less suitable:** per-round recalibration and dynamic zones add negotiation friction and delay inside the escalation clocks, at the cost of the stability the decision needs.

---
## Alternative Paths
### The Pioneer's Gambit
**Strategic Logic:** Detection is tested under realistic, unpredictable conditions. Per-site conditional starts remove either government's timing veto. Randomized evidence checks, sealed capture instruments and blended real-event scoring make the mechanism hard to game, and show whether it works in ordinary operations rather than only in staged ones. The cost is higher procedural complexity, more risk of friction with active computational work, and greater exposure to disputes over judgment-based scoring. Both sides must accept that risk to learn faster.

**Fit Score:** 3/10

**Assessment of this Path:** Conditional per-site starts contradict the plan's mandatory entry conditions. Blending unannounced real events into scoring conflicts with the requirement not to interrupt active computation. Randomized evidence rules and trend-based judgment add dispute risk that an adversarial, low-trust setting cannot absorb.

**Key Strategic Decisions:**

- **Reciprocity Gate Stringency:** Allow a conditional start in which the clock begins at each site once the conditions for that site are met, while the final decision requires all matched sites to complete the full period.
- **Evidence Layer Weighting:** Randomize which evidence layers are required for each event, with the selection drawn from a sealed double-key schedule, so that no operator can predict which checks to defeat.
- **Inspection Zone Boundary Design:** Place sealed capture instruments in the zones that record only identifiers, seals, and movement metadata, so that inspectors review filtered data and enter only when a discrepancy is open.
- **Challenge Exercise Independence:** Blend scheduled exercises with unannounced real events, scoring detection on real changes recorded in the ledger as well as the staged ones, to measure performance under ordinary conditions.
- **Go-Modify-Stop Threshold Calibration:** Define the decision as a rule over trends and categories rather than single numbers, with independent auditors scoring each KPI band and a rubric stating which failure types are non-negotiable Stop conditions.

### The Pragmatic Foundation
**Strategic Logic:** A pre-clock dry run exposes authority and credential gaps on non-covered equipment before the formal clock starts. This keeps the 90-day test clean without handing a veto to the slower side. Graded evidence scoring, dynamic event-specific zones and an independent sealed exercise schedule add adaptability. Calibrating thresholds outside the formal clock and locking them before the blind challenges keeps the yardstick fixed for the decision. Every adaptive element stays under double-key control.

**Fit Score:** 6/10

**Assessment of this Path:** The dry run on non-covered equipment and the pre-test calibration of provisional thresholds suit the plan's 'provisional, then validate' requirement. However, recalibrating evidence weights after each round invites goalpost disputes. Dynamic zones add double-key delays that can interfere with the delayed-access tests and expand exposure.

**Key Strategic Decisions:**

- **Reciprocity Gate Stringency:** Run a pre-clock dry-run gate where both sides exchange access credentials and test the legal authority on non-covered equipment, so that authority gaps appear before the formal clock and the entry certification.
- **Evidence Layer Weighting:** Use a graded confidence score derived from layer-specific reliability ratings that are recalibrated after each exercise round by the independent testing group, with both co-chairs approving every change.
- **Inspection Zone Boundary Design:** Use dynamic zones that expand only for a specific event under double-key approval and shrink when it closes, with escorted access and time-limited credentials.
- **Challenge Exercise Independence:** Have an independent testing unit designed by both governments run all exercises in a sealed, double-key schedule, with only a small group at each site aware of the timing.
- **Go-Modify-Stop Threshold Calibration:** Set provisional thresholds, run a short pre-test calibration exercise outside the formal clock, and lock the validated values before the blind challenges that feed the decision.
