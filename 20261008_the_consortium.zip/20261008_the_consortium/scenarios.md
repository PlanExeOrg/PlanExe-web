# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** Very high. A first-of-kind bilateral US–China verification inspectorate with USD 5 billion (user constraint, 50/50), full-time mirrored national teams, a replicated tamper-evident ledger and double-key governance. Scale is bounded by design: a small matched set of declared sites, change verification only, and a 90-day Phase One operational test that starts only after mandatory entry conditions are met.

**Risk and Novelty:** Highly novel and adversarial. There is no trust, legal symmetry or willingness to expose sensitive technology. Main risks: espionage and counterintelligence exposure, IP leakage, vendor refusal, operator shielding, manufactured incidents, ledger divergence and asymmetric access. The Go/Modify/Stop decision must be hard for either government to contest later, so evidence credibility is the dominant concern.

**Complexity and Constraints:** High operational complexity. Staffing is modelled from site count, shift coverage, mirrored teams, separation of duties, leave and surge, with no single-person critical functions. Required: layered evidence with no single decisive source, deadlock, impaired-confidence and automatic-suspension procedures, blind live exercises without disrupting active compute, and a KPI dashboard covering detection, parity, latency, divergence and fiscal timeliness. Fixed budget envelopes and a short 90-day clock constrain design choices.

**Domain and Tone:** Sovereign public-sector national-security verification program. Formal, adversarial-realist and governance-heavy; explicitly not a business, nonprofit or governance regime. Physical, in-person work at declared datacenters, supported by secure digital ledger and attestation systems.

**Holistic Profile:** A high-ambition, high-risk, trust-free bilateral verification test whose value depends on credible, hard-to-contest evidence of detection capability and reciprocal access within a short 90-day window. It favours strong physical presence, blind and adversarial testing, objective suspension triggers and layered evidence over cost minimisation or political comfort.

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Pioneer's Gambit
**Strategic Logic:** Maximizes detection power and reciprocal-access testing from Month 0 (2026-10-12) by pairing continuous resident mirrored presence with attestation-anchored identity, automatic suspension triggers and adversarial reciprocal red-teaming. Accepts higher cost, vendor-key concentration, espionage exposure and the risk of manufactured triggers in exchange for the most demanding evidence base for a Go, Modify or Stop decision. Filter adequacy and attestation integrity must be proven by the exercises themselves rather than assumed.

**Fit Score:** 8/10

**Why This Path Was Chosen:** Resident mirrored shift teams, objective automatic-suspension triggers and reciprocal adversarial red-teaming match the plan's full-time mirrored staffing, required automatic-suspension procedures and reciprocity-as-Go-criterion. Weaknesses are vendor-key concentration and manufactured-trigger risk, which the plan's layered-evidence rule and exercise exclusions must contain.

**Key Strategic Decisions:**

- **Equipment Identity Trust Anchor:** Anchor identity primarily on vendor-issued cryptographic attestation validated independently by accredited examiners from both countries, using physical inspection and customs records as corroborating layers at intake.
- **Inspector Presence and Rotation Model:** Station resident mirrored teams at every participating site on continuous shift coverage, confined to bounded inspection zones with escorted movement and filtered evidence handling.
- **Deadlock and Suspension Mechanics:** Define enumerated objective triggers that suspend a site automatically, with resumption requiring double-key authorization and a documented corrective action from the responsible government.
- **Challenge Exercise Commitment and Scoring:** Have each country's red team challenge the counterpart's inspectorate at the other's site, using reciprocal adversarial exercises so both detection capability and access parity are tested in a single event.
- **Inspection Zone Geometry and Evidence Filtering Design:** Run an operator-operated redaction gateway that converts raw records and telemetry into schema-limited evidence packets, with the counterpart's engineers auditing the gateway rules but not its inputs.

**The Decisive Factors:**

- **Fit with ambition and risk:** a trust-free US–China test with a short 90-day clock needs the strongest, hardest-to-contest evidence base. Continuous resident mirrored shift teams match the plan's full-time staffing model and detect unreported arrivals directly.
- **Governance:** enumerated automatic-suspension triggers with double-key resumption implement the required suspension procedure and the Stop condition for a government shielding an operator.
- **Reciprocity:** reciprocal red-teaming tests detection and access parity in one event, the two Go criteria.
- **Why not Pragmatic Foundation:** randomized rotation and suspension-free deadlock defaults dilute detection and let obstruction persist.
- **Why not Consolidator's Ledger:** notification-based presence, aging-discrepancy deadlocks and a sealed catalog depend on the operator honesty under test.
- **Residual risk:** attestation concentration and manufactured triggers must be managed through layered corroboration and exercise-event exclusions.

---
## Alternative Paths
### The Pragmatic Foundation
**Strategic Logic:** Balances detection credibility against exposure and cost by anchoring identity on bilateral tamper-evident tags that neither side's supply chain controlled, rotating inspectors to limit capture, and using paired technical referees to keep deadlocks factual rather than political. Independent blind exercises supply a defensible Go/Modify/Stop basis, while fixed, access-controlled zones keep the leakage boundary simple and testable.

**Fit Score:** 6/10

**Assessment of this Path:** Independent blind exercises and bilateral tags are credible and cost-aware, but randomized rotation erodes site familiarity and continuous shift coverage. Deadlock defaulting to heightened inspection instead of suspension weakens the plan's Stop logic against a government shielding an operator.

**Key Strategic Decisions:**

- **Equipment Identity Trust Anchor:** Apply bilateral tamper-evident tags jointly in the staging area by both mirrored teams, so identity continuity rests on markers neither country's manufacturers or logistics firms controlled before arrival.
- **Inspector Presence and Rotation Model:** Rotate inspectors across sites on randomized schedules with no repeat assignment to the same zone in succession, limiting relationship capture, site familiarity and cumulative exposure of any one inspector.
- **Deadlock and Suspension Mechanics:** Convene paired technical referees from both countries to issue dual-signed advisory fact statements, with deadlock defaulting to heightened inspection and impaired-confidence status instead of suspension.
- **Challenge Exercise Commitment and Scoring:** Have independent testers design and inject blind scenarios in staging, spare-inventory, maintenance and expansion areas, unknown to operating inspectors and scored against jointly agreed detection criteria.
- **Inspection Zone Geometry and Evidence Filtering Design:** Fix physical inspection zones to staging, spare-inventory, maintenance and expansion areas with painted and access-controlled boundaries, and admit only inspector-carried instruments that have been pre-validated.

### The Consolidator's Ledger
**Strategic Logic:** Prioritizes continuity, cost control and political survivability by relying on proven physical inspection and witnessed movement, notification-based deployment with unannounced spot checks, and status-quo deadlock handling with escalating timers and aging-discrepancy reporting. A sealed, pre-committed challenge catalog makes scoring defensible and prevents post hoc redefinition of success, at the cost of weaker adaptive testing and greater reliance on operator honesty.

**Fit Score:** 3/10

**Assessment of this Path:** Notification-based deployment leans on operator honesty, which the unreported-arrival and reluctant-operator exercises are meant to test. Status-quo deadlock lets findings age, and a sealed catalog limits adaptive blind detection, which undercuts the credible-detection requirement for a Go.

**Key Strategic Decisions:**

- **Equipment Identity Trust Anchor:** Anchor identity primarily on physical inspection and witnessed movement in controlled staging areas, treating attestation, customs records and maintenance logs as layers that can raise or lower confidence but never settle it alone.
- **Inspector Presence and Rotation Model:** Deploy inspectors on operator notification within fixed response windows, supplementing with filtered remote evidence and unannounced spot visits to test whether declarations are complete.
- **Deadlock and Suspension Mechanics:** Hold the status quo on deadlock but start escalating timers that move the dispute from co-chair level to designated principals, with unresolved findings reported as aging discrepancies.
- **Challenge Exercise Commitment and Scoring:** Publish cryptographic commitments to a sealed catalog of challenge scenarios before Phase One, then reveal and score them afterward so neither government can redefine success post hoc.
- **Inspection Zone Geometry and Evidence Filtering Design:** Fix physical inspection zones to staging, spare-inventory, maintenance and expansion areas with painted and access-controlled boundaries, and admit only inspector-carried instruments that have been pre-validated.
