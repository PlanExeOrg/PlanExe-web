A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Principals can be bound to the 7 entry conditions, with the instrument and appropriations signed by Month 7 (2027-05-12) and single certification at Month 9 (2027-07-12), without a binding escalation rule. | Run a Month 0.5 (2026-10-27) tabletop with both co-chairs' legal leads: draft the instrument skeleton and list every domestic approval step with its realistic duration for each country. | Either legal lead documents any required approval (legislative, appropriations or access authority) that cannot finish by Month 7.5 (2027-05-27) without a negotiating exception. |
| A2 | Vendor-issued attestation keys will be validated within a 4-hour SLA by accredited examiners from both countries, and critical vendors will accept binding, keeping unverifiable equipment at or below 3% per site. | Send the vendor census to operators and run a dry-run key-validation workflow on sample vendor key fingerprints with examiners from both countries. | Any vendor representing more than 5% of declared units declines binding or key custody validation, or median validation latency exceeds 4 hours. |
| A3 | Inspectors, operators and both governments will observe the CHALLENGE-tag partition and the deadlock timers (5/8/13 days) in good faith, so manufactured or misclassified events and delay tactics cannot cascade into suspension or Stop. | Run a red-team tabletop where each side tries to manufacture a suspension trigger or stall a finding past 10 days, and test 2-hour principal escalation across time zones. | A seeded or misclassified event triggers suspension that is not reversed within 2 hours, or any contested finding passes Day 13 without a recorded principal decision. |
| A4 | About 350-500 cleared full-time staff (estimate) can be recruited, vetted and deployed with reciprocal clearances accepted by both governments in time for the Month 8 (2027-06-12) staffing dry-run, while holding 6-month tenure limits. | Pilot the vetting checklist on 10-20 candidates per country and time each stage, including reciprocal-clearance review and supplementary investigation of high-sensitivity candidates. | Median vetting time projects fewer than 80% of target staff cleared by Month 8 (2027-06-12), or rejection or reciprocal-clearance refusal exceeds 10% (proposed threshold) of candidates. |
| A5 | Operator-run redaction gateways will preserve the non-redactable evidence schema fields, so filtered evidence still lets blind inspectors detect at least 9 of 10 substitutions, and operators will accept inspectors in bounded zones without withdrawing consent. | Run a simulated filter-adequacy test with at least 10 injected substitutions on redacted records, and hold an operator workshop to obtain written positions on zone boundaries and gateway audit rules. | Detection on redacted evidence falls below 85% (proposed threshold), or any operator refuses the minimum evidence schema or signed confidentiality terms. |
| A6 | Hourly signed checkpoints over a dedicated authenticated link, with a neutral digest custodian, will keep ledger copies synchronized within 1 hour and detect divergence within 4 hours with a tolerable false-positive rate, without exposing national secure systems. | Stand up mock ledger nodes at two separated sites, exchange hourly signed checkpoints under 10x simulated event load, and inject seeded divergences. | Synchronization exceeds 1 hour on more than 5% of checkpoints (proposed threshold), divergence detection exceeds 4 hours, or false-positive divergence alerts exceed 5% (proposed threshold). |
| A7 | Contingency of USD 450M free (after the USD 50M gate-readiness sub-account) plus matched tranches and a fixed CNY conversion rule will keep cumulative disbursement within +/-10% of pro-rata share and absorb identified exposures of USD 160-340M (estimate). | Build a two-country spend model by envelope with a draft CNY conversion rule and compensation ceilings, then run low, medium and high surge cases with the legal/audit working group. | Any modeled case shows cumulative divergence above 15% (proposed threshold) before Month 10 (2027-08-12), or identified exposures exceed USD 450M free contingency (tested against USD 160-340M, 36-76% of USD 450M; entry-gate sunk cost of USD 100-200M (estimate) is tracked separately against envelope headroom, not contingency). |
| A8 | Seeded blind exercises can be injected in staging, spare-inventory, maintenance and expansion areas without disrupting active compute, and the active-compute boundary can be monitored objectively enough to avoid disputed disruption claims. | Walk a candidate Northern Virginia and a candidate Chinese site with operator facilities staff, mapping each zone's adjacency to live systems and defining a measurable disruption log. | Any zone shares power, cooling or network paths with live production halls such that an injection cannot be isolated, or operators reject a joint disruption-measurement method. |
| A9 | Both governments and the public will tolerate a Modify or Stop verdict, and neither side will contest the verdict, leak selective results or withdraw backing when sealed national scores diverge at Month 11.75 (2027-10-05). | Hold a closed scenario workshop with both co-chairs' staffs presenting divergent sealed scores (e.g. Go versus Modify) and recording each side's stated next step and public messaging. | Either delegation declares in the workshop that it would reject a Modify or Stop outcome, publish its own score, or seek reopening of thresholds after results are known. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Gate That Never Opened | Process/Financial | A1 | Bilateral Co-Chair and Governance Lead | CRITICAL (20/25) |
| FM2 | The Key That Wouldn't Turn | Technical/Logistical | A2 | Vendor Binding and Equipment Identity Verification Lead | CRITICAL (20/25) |
| FM3 | The Manufactured Incident | Market/Human | A3 | Bilateral Dispute Resolution and Deadlock-Escalation Manager | HIGH (12/25) |
| FM4 | The Empty Watch Floor | Process/Financial | A4 | Counterintelligence and Personnel Security Unit Lead | CRITICAL (16/25) |
| FM5 | The Ledgers That Drifted Apart | Technical/Logistical | A6 | Bilateral Ledger and Cryptographic Systems Architect | CRITICAL (15/25) |
| FM6 | The Operator Who Walked Out | Market/Human | A5 | Participating Datacenter Operator Liaison Lead | CRITICAL (15/25) |
| FM7 | The Ledger of Unequal Spending | Process/Financial | A7 | Independent Budget Auditor and Fiscal Accountability Officer | HIGH (12/25) |
| FM8 | The Injection That Tripped the Hall | Technical/Logistical | A8 | Challenge Exercise Design and Independent Testing Lead | HIGH (12/25) |
| FM9 | The Verdict Nobody Owned | Market/Human | A9 | Bilateral Co-Chair and Governance Lead | CRITICAL (15/25) |


### Failure Modes

#### FM1 - The Gate That Never Opened

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Bilateral Co-Chair and Governance Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Instrument negotiation, appropriations and access authority each need legislative steps that run in parallel but are certified only together.
- One lagging condition holds the whole gate while staffing, vetting and site preparation burn money.
- Sunk cost of USD 100-200M (estimate) lands in spending envelopes, not contingency.
- Month 7.5 (2027-05-27) checkpoint lacks binding consequences, so drift passes Month 12 (2027-10-12).

##### Early Warning Signs
- Instrument draft has unresolved articles at Month 5 (2027-03-12)
- Weekly tracker shows any condition behind by more than 2 weeks
- Gate-readiness sub-account draws exceed USD 20M before Month 6 (2027-04-12)
- Appropriations committee calendar has no hearing before Month 6.5 (2027-04-27)

##### Tripwires
- Any entry condition >=14 days behind its deadline
- Instrument not signed by Month 7 (2027-05-12)
- Gate-readiness draws >=USD 40M before Month 6 (2027-04-12)

##### Response Playbook
- Contain: Freeze new site-preparation commitments and hiring beyond the USD 50M gate-readiness sub-account within 48 hours.
- Assess: Rebuild the critical path per condition with the legal leads and price sunk cost per week of delay within 5 days.
- Respond: Put defer, reduced-scope pair start or stop to principals for a written decision within 48 hours of the Month 7.5 (2027-05-27) checkpoint.


**STOP RULE:** Cancel or formally restart the program if any entry condition is uncertified at Month 12 (2027-10-12).

---

#### FM2 - The Key That Wouldn't Turn

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Vendor Binding and Equipment Identity Verification Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Identity rests on vendor attestation keys; refusal, forgery or slow validation pushes units to unverifiable.
- Vendor binding is scheduled for Month 8 (2027-06-12), leaving about 1 month to recover.
- Clean-room centers and examiner protocols are untested at clock start.
- Estimated 10-40% unverifiable (estimate) exceeds the 3% limit, so sites suspend automatically and Go becomes impossible.

##### Early Warning Signs
- Vendor census under 95% of equipment by supplier at Month 1 (2026-11-12)
- Key-validation dry-run median latency above 4 hours
- Any critical vendor silent for 14 days after binding request
- Clean-room examination protocols unapproved at Month 8 (2027-06-12)

##### Tripwires
- Unverifiable forecast >3% at any site
- Key-validation latency >4 hours on >=10% of samples
- Any vendor >5% of units unbound at Month 7 (2027-05-12)

##### Response Playbook
- Contain: Reclassify unbound vendors' units as Tier C unverifiable and stop intake of their equipment within 24 hours.
- Assess: Run supervised examination of at least 10 units per refusing vendor and recompute per-site unverifiable counts within 10 days.
- Respond: Escalate to principals within 5 days to approve clean-room capacity, alternate suppliers or reduced declared-equipment scope.


**STOP RULE:** Stop the site if unverifiable equipment exceeds 3% and no validated fallback brings it under 3% within 4 weeks.

---

#### FM3 - The Manufactured Incident

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Bilateral Dispute Resolution and Deadlock-Escalation Manager
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- A government or operator facing unwelcome findings stalls at co-chair level or seeds a trigger.
- Misclassified CHALLENGE events cause suspension, spending 3-7 operational days each (estimate).
- Each cascade erodes operator consent and political backing, and compresses scored exercises.
- Verdict is then contested as procedural gaming rather than evidence.

##### Early Warning Signs
- Any finding aged beyond 7 days without referee panel convened
- Two or more untagged anomalies traced to exercises in one month
- Operator consent status moves to degraded at any site
- Access denials without reason code within 24 hours

##### Tripwires
- Discrepancy age >=10 days at any site
- CHALLENGE misclassifications >=2 at any site
- Unexplained denials >5 in a month

##### Response Playbook
- Contain: Reinstate any site suspended on a CHALLENGE-tagged event within 2 hours and pause further injections at that site.
- Assess: Audit the tag chain and trigger log with the independent auditor within 5 days to separate error from manipulation.
- Respond: Refer proven manipulation to principals for sanction and retrain or replace taggers, with resumption conditions documented.


**STOP RULE:** Stop Phase One if a government is shown to have manufactured or shielded a trigger and fails corrective action within 15 days.

---

#### FM4 - The Empty Watch Floor

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Counterintelligence and Personnel Security Unit Lead
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Vetting of 350-500 staff (estimate) runs on a compressed cycle with reciprocal-clearance disputes.
- Rejections consume the 10% surge reserve and floaters before leave is applied.
- Staffing falls below 80% of target, forcing curtailment and fewer blind injections.
- Supplementary staffing cost (estimate) competes with the USD 450M free contingency; tenure limits are breached.

##### Early Warning Signs
- Fewer than 200 candidates cleared by Month 2 (2026-12-12)
- Reciprocal-clearance disputes open for more than 21 days
- Dry-run at Month 8 (2027-06-12) shows any function under 2 FTE
- Candidate rejection rate above 10% in any batch

##### Tripwires
- Cleared staff <80% of target at Month 8 (2027-06-12)
- Rejection rate >10% in any batch of 150 candidates
- Any inspector beyond 6 months at one site

##### Response Playbook
- Contain: Stop assigning inspectors beyond tenure limits and pause lower-priority recruitment within 48 hours.
- Assess: Rerun the staffing model with actual clearance counts, leave and surge assumptions within 7 days.
- Respond: Seek principal authorization for reduced site set, delayed start or supplementary staffing within 10 days.


**STOP RULE:** Do not start the clock if cleared staff are below 80% of target or any critical function is under 2 FTE at Month 9 (2027-07-12).

---

#### FM5 - The Ledgers That Drifted Apart

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A6
- **Owner**: Bilateral Ledger and Cryptographic Systems Architect
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Checkpoint exchange crosses a link exposed to latency, partition and key-custody faults.
- Synchronization slips past 1 hour and divergence goes undetected beyond 4 hours.
- Disputed events accumulate toward the 5% suspension trigger or 15-day age limit.
- Forensic recovery of 2-7 days (estimate) per incident erodes the evidence basis for the verdict.

##### Early Warning Signs
- Stress test shows checkpoint latency above 1 hour
- Divergence false-positive rate above 5% in simulation
- Key ceremony not audited by Month 1.5 (2026-11-27)
- Custodian recovery drill exceeds 24 hours

##### Tripwires
- Synchronization >1 hour on >5% of checkpoints
- Divergence detection >4 hours on any incident
- Disputed events >5% at any site

##### Response Playbook
- Contain: Switch affected nodes to offline courier sync and freeze ledger-dependent adjudications within 4 hours.
- Assess: Compare escrowed digests with both copies to isolate fault versus tampering within 24 hours.
- Respond: Rotate keys, harden transport and present reconciliation results to principals before resuming within 5 days.


**STOP RULE:** Stop the affected site if any divergence stays unresolved beyond 15 days.

---

#### FM6 - The Operator Who Walked Out

- **Archetype**: Market/Human
- **Root Cause**: Assumption A5
- **Owner**: Participating Datacenter Operator Liaison Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Operators see foreign inspectors and audited filters as a collection channel.
- Gateways redact aggressively, detection on filtered evidence drops, and inspectors report weak evidence.
- One boundary incident or leak perception turns consent degraded, then withdrawn.
- Withdrawal auto-suspends the site and can trigger vendor defections (estimate), blocking Go.

##### Early Warning Signs
- Operator consent status degraded at any site
- Operator declines signed confidentiality terms by Month 6 (2027-04-12)
- Gateway redacts a non-redactable field in testing
- Boundary violation reports exceed 3 per site per month

##### Tripwires
- Filter-test detection <85%
- Consent status degraded for >14 days
- Boundary violations >3 per site in a month

##### Response Playbook
- Contain: Pause inspector access to affected zones and quarantine disputed evidence within 24 hours.
- Assess: Audit gateway logs and boundary incidents with the independent auditor and operator within 7 days.
- Respond: Renegotiate filter rules and confidentiality terms bilaterally and escalate to principals if consent stays degraded.


**STOP RULE:** Suspend the site if consent is withdrawn and not restored within 5 days of principal escalation.

---

#### FM7 - The Ledger of Unequal Spending

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Independent Budget Auditor and Fiscal Accountability Officer
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Compensation in CNY and USD follows different cost drivers; disbursement drifts apart.
- Entry-gate sunk cost USD 100-200M (estimate) lands in envelopes, not contingency.
- Parity audits hold tranches; a tranche more than 30 days late without double-key deferral counts as withheld funding (Stop).
- Contingency draws reach 75% (USD 375M) before surge peaks, leaving no buffer for staffing or vendor escalation.

##### Early Warning Signs
- Monthly burn reports show divergence above 10% at any month-end
- Conversion rule undocumented at Month 6 (2027-04-12)
- Contingency draws above USD 10M approved more than twice in a quarter
- Auditor re-audit requests open for more than 14 days

##### Tripwires
- Cumulative divergence >15% in any month
- Contingency drawn >=75% (USD 375M)
- Any tranche >30 days late without double-key deferral

##### Response Playbook
- Contain: Freeze non-essential draws above USD 10M and publish a joint spend ledger within 48 hours.
- Assess: Re-run the parity model by envelope and country with the auditor and quantify drivers of divergence within 7 days.
- Respond: Agree compensation ceilings and a re-phased tranche plan with principals within 14 days, or invoke the funding-withheld Stop path.


**STOP RULE:** Stop if a tranche stays more than 30 days late without double-key deferral or divergence stays above 20% for 30 days.

---

#### FM8 - The Injection That Tripped the Hall

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Challenge Exercise Design and Independent Testing Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Staging and maintenance zones share power, cooling or network paths with live halls.
- Injected test units or inspector activity cause a transient on active workloads.
- Operator and inspectors dispute causation without objective logs.
- Exercises halt at the site, scored injections fall below 10 per event type, and operator consent degrades.

##### Early Warning Signs
- Site survey finds a zone with a shared power or cooling path
- No agreed disruption definition at Month 6 (2027-04-12)
- Any unplanned workload transient logged during calibration at Months 9.5-10.5 (2027-07-27 to 2027-08-27)
- Operator withholds facility monitoring logs for more than 5 days

##### Tripwires
- Any disruption incident attributed to exercises
- Fewer than 10 injections completed for any event type by Month 11 (2027-09-12)
- Operator denies >=2 injection windows in a month

##### Response Playbook
- Contain: Halt injections in the affected zone and preserve facility monitoring logs within 2 hours.
- Assess: Reconstruct causation jointly with operator facilities staff and independent testers within 5 days.
- Respond: Relocate or redesign the affected injection pathway, then re-baseline exercise counts with principals if coverage is short.


**STOP RULE:** Pivot to Modify scope if disruption of active compute recurs after redesign, since zero disruption is a user constraint.

---

#### FM9 - The Verdict Nobody Owned

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Bilateral Co-Chair and Governance Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Sealed national scores diverge near the 90% threshold; each side prefers its own reading.
- Political audiences expect Go; a Modify or Stop result is framed as the other side's rigging.
- Selective leaks or reopened thresholds destroy the claim that evidence, not politics, drives the verdict.
- Phase Two scope is undefined, so no agreed path follows a disputed result and backing erodes.

##### Early Warning Signs
- Score divergence above 10 points (proposed threshold) on any event type in calibration
- Either delegation proposes threshold changes after Month 10.5 (2027-08-27)
- Public statements pre-judging the outcome before Month 11.75 (2027-10-05)
- No agreed post-verdict decision framework by Month 11 (2027-09-12)

##### Tripwires
- National score divergence >10 points on any event type
- Threshold change requested after freeze at Month 10.5 (2027-08-27)
- Verdict unsigned by both co-chairs at Month 12.5 (2027-10-27)

##### Response Playbook
- Contain: Lock the sealed scores and ledger record and suspend public statements by both delegations within 24 hours.
- Assess: Commission referee fact statements and independent scoring audit on divergent event types within 10 days.
- Respond: Issue a joint verdict report showing both scores and divergence, with principals fixing the Modify or Stop follow-up path.


**STOP RULE:** Close the program as inconclusive if either government publicly rejects the frozen thresholds after Month 10.5 (2027-08-27).
