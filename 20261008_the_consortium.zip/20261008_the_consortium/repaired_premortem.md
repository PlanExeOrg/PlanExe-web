A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Both governments will complete domestic access authority, appropriations and inspector vetting within roughly 4 weeks of each other, so the strict gate certifies at Month 6 (2027-04-08) without a timing veto. | By Month 0.5 (2026-10-23), obtain written decompositions of required domestic acts, approving bodies and realistic timelines from both governments, plus vetting-agency capacity commitments. | Either country's critical-path act or vetting is projected more than 4 weeks behind the Month 3.5 (2027-01-23) or Month 5 (2027-03-08) milestones, or no written commitment is obtained. |
| A2 | Critical vendors will sign binding cooperation agreements, and independent examiners and clean-room facilities exist at the assumed cost (USD 20-30k per exam budgeted, estimate) and capacity (5 parallel exams per week, estimate). | Run confidential outreach to 3-4 Tier 1 vendors per country and an RFQ to at least 3 examiner labs per country for firm pricing and capacity. | Fewer than 60% of contacted vendors are receptive, or firm quotes exceed USD 75k per exam, or capacity is below 5 exams per week. |
| A3 | Both governments will accept the evidence rules, locked thresholds and independent testing unit as principled, so a Go, Modify or Stop verdict is not contested as tuned or biased. | Run a tabletop with both red teams and technical leads, scoring five paired scenarios for difficulty parity and testing calibration results against provisional thresholds. | Paired scenario difficulty scores diverge by more than 20%, or calibration results diverge more than 20% from provisional thresholds, or either co-chair rejects the fairness rubric. |
| A4 | Narrow marked zones with operator-run redaction will give inspectors enough evidence to meet identity-confidence targets without leaking IP, so neither government withdraws consent. | Run a walkthrough at one candidate site with security teams from both sides, mapping evidence available per zone against the 2-layer corroboration rule and logging every redaction removal. | More than 20% (proposed threshold) of sampled intake events cannot reach 2 independent layers inside the zones, or either security team identifies an IP exposure path it will not accept. |
| A5 | Operators will accept binding agreements, exercise participation and the USD 250M per-site planning allocation (decision) without demanding compensation or protections that exceed the site-preparation envelope. | Hold confidential talks with candidate operators in both countries to obtain written compensation expectations, disruption-liability terms and willingness to bind vendors. | Any operator demands compensation that pushes its site above USD 250M, or refuses vendor binding or the exercise cap in writing. |
| A6 | Staffing of about 434 FTE (estimate) at USD 0.5-0.625M loaded cost (estimate) can be recruited, cleared, retained and rotated across 4 sites with 24/7 coverage and no single-person critical functions. | Survey both governments' personnel and security agencies for candidate pool size, bilingual availability, loaded-cost benchmarks and rotation constraints for 144 inspectors per country. | Qualified candidates are fewer than 120 per country, or loaded cost exceeds USD 0.625M per FTE, or 24/7 coverage cannot be rostered within the 750M envelope. |
| A7 | Both governments will keep political will and fund each tranche within 45 days of fiscal-year start (proposed threshold) despite geopolitical shocks, so no tranche counts as withheld funding. | Obtain written confirmation from both treasuries of tranche-release schedules, fiscal-year alignment and recess calendars, plus a leadership-level commitment letter from each government. | Either treasury cannot confirm release within 45 days, or schedules show a legislative recess or budget-cycle gap longer than 30 days before Month 6 (2027-04-08). |
| A8 | Cryptographic attestation and the split-custody key ceremony will work as one trusted evidence layer, with both governments accepting a shared facility and no key compromise. | Commission an independent cryptographic design review and a tabletop of the joint key ceremony with security teams from both countries, including the national-roots fallback. | Either security team rejects the joint facility, the review finds a critical weakness, or the national-roots fallback takes more than 4 weeks (estimate) to stand up. |
| A9 | Mirrored inspectors and operators will cooperate in good faith, and neither government will shield an operator or use infractions and vetoes as political weapons during Phase One. | Run a tabletop with conduct-committee members from both countries on five contested infraction and veto cases, scoring whether outcomes are accepted by both sides. | Either side rejects more than 1 of 5 tabletop outcomes as politically motivated, or an operator refuses a protocol element in writing. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Slow Key Gambit | Process/Financial | A1 | Bilateral Co-Chair (Entry-Conditions Steering Lead) | CRITICAL (20/25) |
| FM2 | The Unverifiable Cascade | Technical/Logistical | A2 | Head of Vendor Management and Evidence Fallback | CRITICAL (15/25) |
| FM3 | The Rigged Yardstick | Market/Human | A3 | Director, Independent Testing Unit | HIGH (12/25) |
| FM4 | The Blind Margin | Technical/Logistical | A4 | Head of Inspection and Verification Unit | HIGH (12/25) |
| FM5 | The Compensation Squeeze | Process/Financial | A5 | Budget Working Group Lead (per country) | HIGH (12/25) |
| FM6 | The Thin Night Shift | Market/Human | A6 | Head of Inspector Staffing and Rotation | HIGH (12/25) |
| FM7 | The Frozen Tranche | Process/Financial | A7 | Budget Working Group Lead (per country) | CRITICAL (15/25) |
| FM8 | The Broken Root | Technical/Logistical | A8 | Head of Ledger Operations and Cryptographic Custody | MEDIUM (8/25) |
| FM9 | The Weaponized Rulebook | Market/Human | A9 | Chair, Inspector Conduct Committee | CRITICAL (15/25) |


### Failure Modes

#### FM1 - The Slow Key Gambit

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Bilateral Co-Chair (Entry-Conditions Steering Lead)
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Strict gate has no conditional start; the slower government holds a timing veto.
- Domestic authority slips past Month 3.5 (2027-01-23) and vetting past Month 5 (2027-03-08).
- Holding cost USD 50-100M per month (estimate) drains the USD 500M contingency.
- Calibration is compressed and thresholds lock on provisional data.
- The Month 9 (2027-07-08) backstop forces a rushed extend-or-stop decision.

##### Early Warning Signs
- Any domestic act more than 2 weeks behind baseline on the weekly dashboard
- Counterintelligence vetting below 60% of candidates submitted at Month 2 (2026-12-08)
- Tranche release not confirmed 30 days after fiscal-year start

##### Tripwires
- Any domestic authority item >= 4 weeks late
- Roster approved < 80% at Month 5 (2027-03-08)
- Cumulative gate-delay cost >= USD 150M (estimate)

##### Response Playbook
- Contain: Freeze discretionary spending and put non-critical staff on standby to cap holding cost.
- Assess: Rebuild the critical path per country within 5 working days and quantify the slip and contingency drawdown.
- Respond: Co-chairs decide by double-key on extension, pause clause or stop, with written rationale.


**STOP RULE:** Stop if entry conditions are not certified by Month 9 (2027-07-08) and the co-chairs cannot agree by double-key on an extension.

---

#### FM2 - The Unverifiable Cascade

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Vendor Management and Evidence Fallback
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Tier 1 vendors refuse attestation or records.
- Examiner and clean-room pools are not contracted before Month 4 (2027-02-08).
- The day-10 ladder expires and equipment is classed unverifiable.
- A hard site exceeds 10% unverifiable, which is a Stop condition.
- Late examiners at USD 50-100k per exam overrun contingency, which is already short by about USD 15M (estimate).

##### Early Warning Signs
- Fewer than 80% of Tier 1 vendors giving letters of intent by Month 1 (2026-11-08)
- Mock examinations exceeding 10 days
- Vendor refusals at more than 2 vendors per site in calibration

##### Tripwires
- Tier 1 vendor letters of intent < 80% at Month 1 (2026-11-08)
- Unverifiable equipment >= 5% at any site
- Examiner quote > USD 75k per exam

##### Response Playbook
- Contain: Invoke the fast lane contingency release (up to USD 50M) to book examiner and clean-room capacity immediately.
- Assess: Rank refused vendors by equipment share and project each site's unverifiable percentage within 3 days.
- Respond: Rebind vendors through operators and governments, or reselect the failing hard site from the shortlist.


**STOP RULE:** Stop or replace a site if unverifiable equipment exceeds 10% at that site after the day-15 extension.

---

#### FM3 - The Rigged Yardstick

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Director, Independent Testing Unit
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Calibration shows detection well below the provisional 90/85/80% targets.
- Recalibration is read as moving the goalposts.
- One government alleges exercise scenarios favored the other's inspectors.
- Parity diverges above 20%, and trust erodes.
- The verdict is rejected and consent is withdrawn.

##### Early Warning Signs
- Fairness scores differ between US and China scenarios
- Calibration detection more than 20% below target
- Public or leadership statements disputing exercise fairness

##### Tripwires
- Scenario difficulty parity gap > 20%
- Calibration detection rate < 70% for any event type
- Parity divergence > 20% for 2 consecutive months

##### Response Playbook
- Contain: Pause the contested exercise series and freeze reporting of results to both sides.
- Assess: Commission a neutral third-party audit of scenarios and scoring within 10 days.
- Respond: Agree a recorded protocol change on thresholds or scenarios, then resume under double-key sign-off.


**STOP RULE:** Stop or pivot if either co-chair rejects the audited scoring methodology and the referee panel cannot restore agreement within 14 days.

---

#### FM4 - The Blind Margin

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A4
- **Owner**: Head of Inspection and Verification Unit
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Fixed narrow zones leave blind spots around staging and expansion areas.
- Redaction strips identifiers needed for the 2-layer corroboration rule.
- Identity confidence falls below the 90% intake target (TBD).
- A substitution is missed in blind exercises.
- Tightening zones after an IP scare deepens the gap.

##### Early Warning Signs
- Redaction removes identifier fields in over 10% of sampled intake events
- Calibration substitution detection below 85%
- Security teams request zone shrinkage after a boundary incident

##### Tripwires
- Intake events confirmed < 90% (TBD) in calibration
- Substitution detection < 85% (provisional) in any exercise round
- Redaction-caused evidence gaps >= 10% of events (proposed threshold)

##### Response Playbook
- Contain: Suspend further zone shrinkage and freeze redaction rule changes pending review.
- Assess: Map each missed or degraded event to the zone and redaction step that removed evidence, within 5 working days.
- Respond: Agree a recorded protocol change on redaction fields or sensor placement, then retest on non-covered equipment.


**STOP RULE:** Pivot or stop if substitution detection stays below 70% after one recorded protocol change.

---

#### FM5 - The Compensation Squeeze

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A5
- **Owner**: Budget Working Group Lead (per country)
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Operators demand compensation and liability cover beyond expectations.
- The split of the USD 1.0B envelope is unfixed, so physical preparation is squeezed.
- Zone certification slips and binding agreements miss Month 4 (2027-02-08).
- Gate delay costs USD 50-100M per month (estimate) from contingency.
- Contingency is already about USD 15M short in the worst case.

##### Early Warning Signs
- Operator compensation asks exceed 50% of the USD 250M site allocation
- Binding agreements unsigned 30 days before Month 4 (2027-02-08)
- Zone certification behind plan by more than 2 weeks

##### Tripwires
- Any site allocation forecast > USD 250M
- Operator agreements signed < 4 of 4 at Month 4 (2027-02-08)
- Variance > 5% in Months 0-3 (2026-10-08 to 2027-01-08)

##### Response Playbook
- Contain: Freeze new commitments within the site envelope and hold remaining funds for zone and ledger work.
- Assess: Rebuild per-site cost with operator asks within 7 days and test coverage by contingency.
- Respond: Co-chairs fix the envelope split by double-key, or reselect a site from the shortlist.


**STOP RULE:** Stop or replace the site if the operator will not sign by Month 6 (2027-04-08) within the site allocation.

---

#### FM6 - The Thin Night Shift

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Head of Inspector Staffing and Rotation
- **Risk Level:** HIGH 12/25 (Likelihood 4/5 × Impact 3/5)

##### Failure Story
- Cleared bilingual inspectors are scarce and costs exceed estimates.
- Roster stays near the 80% entry minimum.
- Night and weekend shifts run thin, fatigue rises and turnover follows.
- Events are missed or recorded late, and parity between countries slips.
- Vacancies can be filled only from a small pre-approved bench.

##### Early Warning Signs
- Candidate pool below 120 per country
- Night-shift vacancy rate above 20%
- Inspector attrition at or above 2 per site in a month

##### Tripwires
- Roster filled < 85% at Month 5 (2027-03-08)
- Surge bench < 15% of roster
- Loaded cost > USD 0.625M per FTE (estimate)

##### Response Playbook
- Contain: Redirect surge-bench inspectors to uncovered night shifts and cap non-essential rotations.
- Assess: Compute coverage gaps by shift and site, and parity impact, within 5 working days.
- Respond: Co-chairs approve reduced scope or sites, or fund targeted recruitment from contingency by double-key.


**STOP RULE:** Stop or reduce site count if critical posts remain unfilled at Month 9 (2027-07-08).

---

#### FM7 - The Frozen Tranche

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Budget Working Group Lead (per country)
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- One treasury misses the 45-day release window (proposed threshold).
- Budget-cycle misalignment or political shift delays the tranche.
- The 30-day cure expires and funding counts as withheld.
- Holding cost of USD 50-100M per month (estimate) drains contingency, already about USD 15M short in the worst case.
- Stop fires on a fiscal process failure, not on mechanism performance.

##### Early Warning Signs
- Tranche not confirmed 30 days after fiscal-year start
- Monthly spend variance above 5% in Months 0-3 (2026-10-08 to 2027-01-08)
- Treasury signals a recess or reprioritization

##### Tripwires
- Tranche late >= 45 days after fiscal-year start
- Budget variance > 5% in Months 0-3 (2026-10-08 to 2027-01-08)
- Cumulative contingency drawdown >= USD 150M (estimate)

##### Response Playbook
- Contain: Pause new commitments outside critical-path items and hold remaining funds for ledger and vetting work.
- Assess: Establish the cause of the delay with the treasury within 5 working days and compute days remaining to day 75.
- Respond: Co-chairs escalate to leadership level and agree by double-key a recorded cure plan or a pause.


**STOP RULE:** Stop if either tranche remains unpaid at day 75 after fiscal-year start.

---

#### FM8 - The Broken Root

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Head of Ledger Operations and Cryptographic Custody
- **Risk Level:** MEDIUM 8/25 (Likelihood 2/5 × Impact 4/5)

##### Failure Story
- The joint key ceremony is rejected or delayed by one government.
- A weakness is found in the attestation design.
- The attestation layer is lost and identity relies on physical inspection plus 2 independent records.
- Identity confidence falls below the 90% intake target (TBD).
- Ledger signing and reconciliation are disrupted, with a 2-4 week delay (estimate).

##### Early Warning Signs
- Ceremony facility not agreed by Month 1 (2026-11-08)
- Audit finding rated critical
- Attestation validation failures in stress tests

##### Tripwires
- Ceremony not scheduled by Month 2 (2026-12-08)
- Attestation validation failure rate > 5% (proposed threshold)
- Fallback readiness > 4 weeks (estimate)

##### Response Playbook
- Contain: Suspend signing with the affected keys and move to offline backups.
- Assess: Determine which equipment and entries depend on the affected roots within 3 working days.
- Respond: Activate the two national cross-validating roots and re-attest affected equipment under double-key approval.


**STOP RULE:** Pivot or stop if neither joint nor national roots are operational by Month 5 (2027-03-08).

---

#### FM9 - The Weaponized Rulebook

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Chair, Inspector Conduct Committee
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Infraction findings and inspector vetoes become retaliation tools.
- Tier 3 access suspensions follow contested incidents.
- A government shields an operator, which is a Stop condition.
- Parity diverges above 20% (proposed threshold) and trust collapses.
- Consent is withdrawn.

##### Early Warning Signs
- Vetoes of counterpart inspectors rise after a political incident
- Disputed infraction findings
- Operator refuses a protocol element

##### Tripwires
- Inspector vetoes > 5 in one month (estimate)
- Parity divergence > 20% for 2 consecutive months
- Tier 3 suspensions >= 2 at one site

##### Response Playbook
- Contain: Pause new vetoes and suspensions pending co-chair review within 24 hours.
- Assess: Audit access logs and evidence for each contested case within 7 days.
- Respond: Refer disputed cases to the referee panel and restore reciprocal access by double-key decision.


**STOP RULE:** Stop if access asymmetry or operator shielding remains unresolved after 14 days.
