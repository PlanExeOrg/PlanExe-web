Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 12 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 5 | Material risk with plausible path. |
| ✅ Low | 3 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is a bilateral government national-security inspection and verification program relying on physical inspection, cryptographic ledgers, institutional governance, and human personnel—all mechanisms grounded in physics and engineering. The plan does not require breaking conservation laws, causality, or any named physical law, and does not depend on non-physical causation. Challenges around vendor cooperation, operational feasibility, and trust are real but not physics violations.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel five-subsystem combination (confidential evidence-weighting rule, reciprocal exercises, double-key deadlock, mirrored inspectorates, replicated ledger) without independent validation at operational scale before the 90-day Phase One clock starts. Failure in any subsystem cascades: evidence-rule miscalibration → adjudication overload → deadlock stalling → automatic partial suspensions → unresolved discrepancies aging → forced Stop by default. Plan names validation steps (pilot Month 5 = 2027-03-08, rule calibration Months 4.5–5) but they occur sequentially within entry-condition window (Months 0–5 = 2026-10-08 to 2027-03-08), so a single failed validation forces 4–8 week re-test, consuming compression reserve, compressing Phase One to 45–60 days, widening confidence intervals from ±12% to ±18–22%, invalidating proof-of-concept.

**Mitigation**: Bilateral Evidence Validation Task Force: Execute three parallel validation tracks (Evidence Rule, Reciprocal Exercises, Ledger) spanning Months 1–5 (2026-11-08 to 2027-03-08), each with explicit NO-GO gates and independent sign-off. (1) Evidence Rule Track: validate on 100–200 historical events per site AND 40–60 adversarial synthetic cases per site; false-positive rate must be 7–13% (10% ±3 points); false-negative rate <5% on synthetic; if deviation exceeds ±5 points, halt Phase One and run a second cohort (4-week delay accepted). (2) Reciprocal Exercises Track: conduct live dry-run exercises at all 3 candidate sites (Months 4.5–5 = 2027-02-23 to 2027-03-08); measure operator access time, exercise feasibility, red-team scenario credibility; confirm 54-exercise load is operationally schedulable or reduce to 48 (4 sites, 2 pairs). (3) Ledger Track: full key-recovery dress rehearsal (Month 5 = 2027-03-08) with both key-custody officers, independent timekeeper, and neutral-facility staff; produce bilateral Ledger-Recovery SOP with recovery time <24 hours confirmed or escalate to Stop. Define two global NO-GO gates: (1) empirical/engineering validity—any evidence-rule deviation >5 points, exercise detection <50% on pilot, or key recovery >24 hours is a NO-GO; (2) legal/compliance clearance—any co-chair cannot pre-commit to the evidence rule, thresholds, or deadlock procedures in writing is a NO-GO. Failure in any critical track → overall NO-GO and formal 4-week re-test or Phase One delay/rescoping decision by Month 6 (2027-04-08). No subsystem is deployed without independent validation sign-off by both co-chairs and an independent auditor.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the five critical decision levers have explicit mechanisms-of-action, owners, and success metrics. However, three named strategic concepts—reciprocal-access parity (scored Go criterion, ≥85%), post-Phase-One funding route (Modify rework vs. Phase Two), and asymmetry detection (hard Stop trigger)—lack operationalized definitions, measurement procedures, or assigned owners. This gap is material but not foundational: if parity definition remains TBD until Phase One conclusion, either co-chair can contest the Go verdict by redefining parity post-hoc. If post-Phase funding is unspecified, a Modify verdict triggers 4–8 week renegotiation, delaying final decision past Month 9.5 (2027-07-23).

**Mitigation**: Bilateral Strategic Clarity Taskforce: Assign three owner-roles by Month 0.5 (2026-10-23) to operationalize reciprocal parity (measure via inspector-hour balance ≥90%, exercise-opportunity distribution, data-access turnaround ≤3 days, challenge-outcome agreement ≥80%), post-Phase funding (pre-authorize Modify rework within USD 5B or supplemental by Month 8 = 2027-06-08), and asymmetry detection (staging access >4 hours or inspector-hour gap >10% triggers 14-day adjudication). Fix the parity definition, aggregation rule and signed operator Statements of Cooperation at Month 3 (2027-01-08) matched-pair approval, stating the commitments are binding (embedded in the instrument with home-government enforcement); dry runs at Months 4.5–5.5 only confirm. Lock definitions and owners in the bilateral instrument by Month 1 (2026-11-08) as binding procedural law.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan explicitly identifies 19 specific risks (entry-gate compression, evidence-rule miscalibration, adjudication overload, facility delays, operator withdrawal, ledger divergence, staffing gaps, inspector breaches, vendor refusals) but cascading failure pathways are incompletely operationalized. Second-order cascade risk example: entry-condition slip (8 weeks) → contingency consumed USD 100–200M → Phase One compressed to 50–60 days → statistical confidence widens from ±12% to ±18–20% → Go/Modify/Stop verdict becomes ambiguous (interval straddles threshold) → renegotiation pressure on thresholds → tranche 4 (USD 500M per country) released conditionally, not on verdict publication → funding leverage inverted, bilateral trust erodes, political withdrawal risk rises to 40–60%. The 15 documented second-order risks (premortem, expert review, SWOT) lack explicit control owners, measurement triggers, and response escalation sequences locked into the bilateral instrument. Adjudication paralysis cascade (rule miscalibration 15–20% false positives → 30–50 cases/month vs. 15 capacity → discrepancies age past day 21 → automatic impaired-confidence suspensions → 3+ sites partially suspended → ledger credibility questioned → Stop by default) is mapped but mitigation (adjudication surge USD 2–3M, pre-positioned by Month 4 = 2027-02-08) lacks binding authorization mechanism.

**Mitigation**: Bilateral Risk Cascade Council: Establish by Month 0 (2026-10-08) with one officer per country (program risk, finance, legal, CI) meeting weekly. Map all 19 documented risks into an integrated cascade graph (if A fails → B fails → C fails = Stop); for each cascade path, assign a trigger metric, threshold (e.g., "contingency draw ≥30%" or "unresolved discrepancy age ≥21 days"), a single named escalation owner, and a pre-authorized response (e.g., "activate surge adjudication within 48 hours," "convene emergency summit within 5 days," "invoke scope reduction to 2 pairs"). Embed the cascade cascade thresholds and owner assignments in the bilateral instrument by Month 1 (2026-11-08) as binding procedural law. Publish unclassified monthly cascade-status dashboard (cumulative risk exposures, active mitigations, contingency draw, age of open items) to both legislatures by Month 6 (2027-04-08) Phase One start.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan allocates 5.5 months for entry conditions (bilateral instrument, domestic authority, site selection, entry certification by Month 5.5 = 2027-03-23) feeding a 90-day Phase One clock (Months 6–9 = 2027-04-08 to 2027-07-08), but lacks binding weekly milestones, external escalation authority with scope-reduction power, or contingency reserve authorization for compressed negotiation. An 8-week gate slip (plausible per JCPOA/START precedent) consumes USD 100–200M (20–40% of the 500M contingency) and compresses Phase One to 50–60 days, widening statistical confidence from ±12% to ±18–22%, making Go/Modify/Stop verdicts indefensible. Critical-path chokepoint: neutral-facility site selection (OPEN, Month 1 = 2026-11-08) cascades into hardening (Month 3 = 2027-01-08), key ceremony (Month 4 = 2027-02-08), and entry certification (Month 5.5 = 2027-03-23); a 4-week facility slip consumes the pre-clock calibration window. Evidence-rule and threshold lock-down occur late (Months 4.5–5.5), leaving no recovery time if validation fails.

**Mitigation**: Bilateral Entry-Condition Task Force: Launch by Month 0 (2026-10-08) with binding weekly milestones, external escalation authority empowered to invoke scope reduction (2 pairs over the full 90 days, 4 exercises per site per month = 48 total) within 5 days of any gate slipping >2 weeks, and USD 50–100M compression reserve pre-authorized for parallel-track activation (simultaneous site nomination, vendor outreach, inspector vetting starting Month 1 = 2026-11-08 and running to Month 4 = 2027-02-08). Lock gate deadlines in bilateral instrument by Month 1 (2026-11-08): instrument signature Month 1 (2026-11-08), domestic authority and first tranche Month 2 (2026-12-08), matched-pair approval Month 3 (2027-01-08), entry certification Month 5.5 (2027-03-23). Designate Geneva and Singapore as co-nominated neutral-facility candidates by Month 0.5 (2026-10-23); lock site selection by Month 1 (2026-11-08); complete hardening and security certification by Month 3 (2027-01-08).


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because committed funding sources (USD 2.5B per country, 4 synchronized tranches) cover the 9.5-month entry-conditions-and-Phase-One runway with double-key authorization gates and 30-day Stop triggers for withheld funds. However, three covenants are unresolved: (1) no binding external escalation authority with pre-authorized scope-reduction power (2 pairs over the full 90 days, 48 exercises total) if entry gates slip >2 weeks, risking Phase One compression and statistical confidence loss; (2) post-Phase-One funding (Modify rework estimated USD 250–400M) is OPEN, creating renegotiation leverage on final-tranche release; (3) contingency surge draws (adjudication surge USD 2–3M, ledger recovery USD 5–10M, personnel overruns TBD) lack explicit pre-authorized limits, requiring mid-Phase-One co-chair approval.

**Mitigation**: Bilateral Finance and Contingency Authority: Establish by Month 0 (2026-10-08) with binding pre-authorization of contingency draw thresholds (compression reserve USD 50–100M for entry acceleration; draws above the compression reserve requiring double-key approval; facility slips funded from free contingency, not the reserve) and explicit escalation rules (delay >14 days = escalate; >30 days = Stop trigger). Lock post-Phase-One funding decision (Modify rework authorized within USD 5B or supplemental by Month 8 = 2027-06-08) and publish framework by Month 8 (2027-06-08) so tranche 4 release is decoupled from rework negotiation.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the stated USD 5.0B budget is mapped to seven fixed envelopes with 100% audit sampling required, and no hard contradictions emerge between budget and the planned scope (3 matched pairs, 90-day Phase One, 360 inspectors, 54 exercises). However, three material gaps prevent confirming cost realism: (1) Operator compensation ceiling undefined—no binding cost proposals from candidate sites obtained; operator cost is unquantified (estimate) until proposals exist; the ceiling is about USD 167M per site (1,000M / 6), so a USD 30–50M operator compensation sub-line fits within the envelope; (2) Vendor-refusal fallback-ladder funding (USD 5–15M estimated for clean-room and examiner deployment) not itemized separately from the USD 500M testing envelope, risking exercise-load reduction if ladder activates; (3) Contingency burn hierarchy and spending authorization undefined—USD 30–50M estimated mid-Phase-One overruns (personnel surge, ledger recovery, adjudication surge) lack pre-authorized draw limits, risking co-chair approval delays that compound into contingency exhaustion (50–75% of USD 500M = USD 250–375M). Adequacy unknown unless operator proposals are obtained and contingency drawdown hierarchy is locked by Month 2 (2026-12-08).

**Mitigation**: Finance and Procurement Lead: Obtain binding operator cost proposals from all 6 candidate sites and lock operator-compensation ceiling (proposed USD 30–50M per site, total USD 180–300M for 6 sites) in bilateral instrument by Month 2 (2026-12-08). Separately itemize vendor-refusal fallback-ladder budget (USD 5–15M) within the USD 500M testing envelope by Month 1 (2026-11-08). Establish pre-authorized contingency-draw hierarchy (compression reserve USD 50–100M for entry acceleration; draws above the compression reserve require double-key approval; tiers at 30% = co-chair briefing, 50% = scope-reduction planning, 75% = joint review with external audit, of the 500M) locked in bilateral instrument by Month 1 (2026-11-08). Reconcile all three allocations within the envelope map and publish envelope-reconciliation audit by Month 3 (2027-01-08).


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because verdict logic (Go: at least 4 of 5 criteria including detection and parity; Modify: 3 of 5; Stop: 2 or fewer) lacks an explicit per-criterion interval rule locked before Phase One. With ±12% pooled intervals, a 70% detection result spans [58–82%], straddling the threshold. No binding amendment-prevention clause or mechanical rule mapping intervals to verdicts exists, enabling post-hoc renegotiation and 4–8 week verdict-delay risk.

**Mitigation**: Bilateral Verification Lead: Draft and bilaterally sign the verdict method in the instrument by Month 1 (2026-11-08), with numeric thresholds locked at Month 5.5 (2027-03-23) after pilot and calibration, specifying one confidence level per criterion, class thresholds of 70%/50%, mechanical scoring rule (Go at least 4 of 5 criteria; straddles = Modify default), and no-amendment clause. Publish unclassified thresholds before first exercise. Lock in bilateral instrument.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan specifies detailed engineering artifacts for build-critical components: bilateral instrument (80–120 pages, locked procedures for deadlock, suspension, thresholds, evidence rules) by Month 1 (2026-11-08); evidence-weighting rule in versioned escrow by Month 4.5 (2027-02-23) with specifications for layered evidence combination logic; replicated ledger architecture with dual-redundancy hardware, hourly digest exchange, and 72-hour reconciliation procedures documented by Month 3 (2027-01-08); key-custody ceremonies with explicit dual-share generation and recovery procedures rehearsed by Month 5 (2027-03-08); adjudication panel charter with decision workflows and escalation triggers locked by Month 1 (2026-11-08); Exercise Authority charter specifying scenario design, independence protocols, and scoring rubrics by Month 3 (2027-01-08). Integration testing occurs through bilateral stress tests (deadlock procedures, verdict thresholds, breach adjudication) and a full operational dry-run (key-custody ceremony, ledger synchronization, inspector debriefing simulation) by Month 5.5 (2027-03-23), validating both technical integration and governance coherence. Only minor follow-up remains: obtain final co-chair sign-off on locked procedures (by Month 1 = 2026-11-08), and validate pilot-exercise results against pre-registered rules (by Month 5 = 2027-03-08).

**Mitigation**: Bilateral Engineering Verification Lead: Produce and validate specifications for three critical components by Month 1 (2026-11-08): (1) Bilateral Instrument (containing deadlock clock definition, automatic-suspension triggers at days 14/21/28, evidence-rule lock-down language, threshold mechanical-scoring rule with no-amendment clause, hard Stop triggers, and ledger-recovery procedures). (2) Ledger Technical Specifications (dual-redundancy architecture, hourly digest-exchange workflow, mismatch escalation within 4 hours, 72-hour reconciliation, key-custody interfaces). (3) Adjudication Panel Charter (membership, convening timeline, decision authority, escalation paths). Each specification shall include interface contracts (what inputs/outputs each component exchanges), acceptance criteria (falsifiable benchmarks for correctness), and integration ownership (named roles and sign-off). Conduct bilateral acceptance-test dry-runs by Month 5.5 (2027-03-23): key-recovery ceremony with time-to-recovery <24 hours confirmed, ledger divergence reconciliation within 72 hours validated, deadlock clock advancing/resetting per bilateral authorization rules confirmed, adjudication-panel recommendation delivered within 5 days verified. Lock final specifications and dry-run sign-offs by Month 5.5 (2027-03-23) before Phase One clock (Month 6 = 2027-04-08).


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because three critical operational claims lack verifiable evidence before Phase One clock starts (Month 6 = 2027-04-08): (1) Evidence-weighting rule validated false-positive rate 7–13% and false-negative rate <5%—only historical-record validation is documented; no adversarial synthetic-case validation artifact exists. (2) Operator access commitments—no signed Statements of Cooperation with performance baselines (staging access within 4 hours, 48-hour exercise notice, maintenance calendar). (3) Reciprocal-access parity definition and measurement—operationalized method missing; 'parity ≥85%' lacks measurable indicators. Without these evidential artifacts locked by Month 5.5 (2027-03-23 entry-gate certification), adjudication load miscalibration (false positives 15–20% instead of 10%), operator mid-Phase-One withdrawal, and asymmetry disputes will cascade into automatic partial suspensions and Stop-by-default outcomes, invalidating Phase One as proof-of-concept. The plan names validation steps (pilot Month 5 = 2027-03-08, rule escrow Month 4.5 = 2027-02-23) occurring within the entry-condition window, but no binding approval or sign-off procedures are specified; validation gaps become apparent only after expensive parallel work is committed.

**Mitigation**: Bilateral Evidence Validation and Lock-Down Team: Complete three parallel evidence-acquisition workstreams by Month 5.5 (2027-03-23, entry-gate certification deadline), each with independent sign-off and a written certification artifact: (1) Evidence Rule Validation Memo (Bilateral Verification Lead + Rule Owners): execute pilot on 100–200 historical events and 40–60 adversarial synthetic cases per site; deliver Calibration Confidence Memo confirming false positives 7–13%, false negatives <5%, or document miscalibration and rework plan by Month 5 (2027-03-08). (2) Operator Cooperation Certificates (Operator Liaison Officer + 3 Site Operators): collect signed Statements of Cooperation locking staging access within 4 hours, 48-hour exercise notice, maintenance calendar, and compensation ceiling by Month 5.5 (2027-03-23); publish unclassified registry. (3) Parity Measurement Framework (Finance and Program Risk Officer): operationalize ≥85% parity via four quantified indicators (inspector-hour balance ≥90%, exercise distribution within 10%, data-access turnaround ≤3 days, challenge-outcome agreement ≥80%); lock definitions and measurement procedures in bilateral instrument by Month 5 (2027-03-08).


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because two major deliverables lack specific, verifiable qualities: (1) Go/Modify/Stop Verdict hinges on five scoring criteria, three of which are abstract—reciprocal-access parity ≥85% (definition TBD), verdict thresholds marked provisional without locked mechanical rule for interval-straddling cases, and scoring intervals with no pre-registered tie-breaker. (2) Vendor-Refusal Fallback Ladder's acceptance criteria are contradictory: the five-rung sequence requires 40–60 weeks but only 5.5 months exist before Phase One clock, so equipment will inevitably be unverifiable, yet the disposition rule (unverifiable vs. excluded, and impact on Go gate) is absent. Without locked SMART criteria (method by Month 1 = 2026-11-08; numeric thresholds by Month 5.5 = 2027-03-23) for verdict thresholds and Month 2 (2026-12-08) for vendor ladder disposition, verdict contestation and equipment-classification disputes will cascade into deadlock delays and verdict-credibility loss.

**Mitigation**: Bilateral Verification Lead and Vendor Liaison Officer: (1) Draft and co-chair-sign the verdict method in the instrument by Month 1 (2026-11-08), with numeric thresholds locked at Month 5.5 (2027-03-23), specifying operationalized parity definition (inspector-hour balance ≥90%, exercise distribution symmetric, data-access turnaround ≤3 days, challenge-outcome agreement ≥80%; ≥85% weighted average = parity met), one confidence level per criterion with mechanical scoring rule (class thresholds 70%/50%; straddles = Modify default), and no-amendment clause locked before Phase One clock. (2) Lock Vendor-Disposition Procedure by Month 2 (2026-12-08) specifying: equipment attempting ≥3 rungs = classed unverifiable; <3 rungs available = classed excluded; both classifications count in the unverifiable share; share ≤5% = Go limit, 5–10% = Modify, over 10% at a site or overall = hard Stop (proposed thresholds). Document the disposition decision for every vendor refusal in the ledger.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the multilingual language-of-record system with controlled glossary and mandatory back-translation (Decision 14) adds 2–5 day turnaround per evidence package, 6 FTE translation staff, and joint terminology-board overhead without demonstrably supporting the core detection objective (serial numbers, timestamps, identity-confidence scores are language-independent) or the reciprocal-access objective (measured operationally, not linguistically). The plan marks this as LOW-risk, indicating secondary impact; yet it consumes unbudgeted translation capacity (estimated 6 person-months, USD 480k–720k annually within the 750M personnel envelope) and delays adjudication (54 filtered packages × 2–3 days per package = 108–162 person-days cumulative latency). Comparable bilateral mechanisms (START, JCPOA) operate in English for technical findings, with post-hoc translation for legislative summaries. No binding legal/contractual requirement mandates dual-language findings (the bilateral instrument, user constraint, does not specify it).

**Mitigation**: Bilateral Legal Implementation Lead: Produce a one-page Benefit Case Review (by Month 0.5 = 2026-10-23) quantifying (1) KPI: reduction in translation-dispute-triggered discrepancies (expected baseline 0; target benefit if disputes avoided), (2) Cost: 6 FTE @ USD 80k per person-month (estimate) = USD 480k per month, about USD 5.8M annually; 2–3 day latency per evidence package × 54 exercises = 108–162 person-days, (3) Owner: named lead for translation unit and terminology board, (4) Alternative: single-language English findings with post-verdict legislative translation (cost USD 50–100k, zero latency impact). English-only Phase One is a rejected alternative: English and Mandarin remain equally authoritative, with a 6-person translation unit per country.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan designates a 'unicorn role'—the Bilateral Arms-Control Verification Lead—who must simultaneously master five specialized domains (arms-control treaty verification precedent, frontier-computing equipment authentication, cryptographic ledger design, bilateral governance under no-casting-vote deadlock rules, and detection credibility under thin-statistics constraints). This combination is rare: START and JCPOA verification experts exist, but few have hands-on cryptographic-ledger operationalization experience or have designed bilateral evidence-weighting rules resisting gaming. The role is both essential (single point of failure for detection credibility, evidence-rule validation, and Go/Modify/Stop verdict logic) and mission-critical (no substitute authority exists; double-key governance forbids casting-vote delegation). Talent market validation is absent: no labor survey, no comparable-role recruitment precedent from bilateral mechanisms, and no evidence that qualified candidates exist in sufficient numbers or are willing to deploy for 9.5 months in high-stakes conditions with compartmentalization restrictions.

**Mitigation**: Bilateral Talent Acquisition and Risk Officer: Conduct a talent-market validation study (within 60 days, by Month 1.5 = 2026-11-23) surveying the talent pool of 15–25 candidates per country meeting unicorn-role criteria (demonstrated experience in arms-control verification + cryptographic systems + bilateral governance + detection-threshold design). Document willingness to commit, security-clearance compatibility, and salary expectations. Identify 3–5 primary candidates and 2–3 backups per country by Month 2 (2026-12-08). If fewer than 3 primary candidates per country meet criteria or decline to commit, escalate to co-chairs within 5 days as a go/no-go check; re-scope or delay entry conditions.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because legal/regulatory feasibility for a bilateral US–China frontier-computing equipment-change verification mechanism depends on: (1) Bilateral instrument embedding deadlock procedures, automatic suspensions, evidence rules, verdict thresholds, and ledger protocols as binding procedural law (signed by both co-chairs by Month 1 = 2026-11-08); (2) Domestic access-authority legislation in each country granting compulsory operator participation and inspector immunity (enacted by Month 2 = 2026-12-08); (3) Neutral-facility host-country diplomatic status and immunity (signed MOU by Month 1.5 = 2026-11-23); (4) Evidence-rule lock-down and no-amendment clause preventing unilateral modification after validation; (5) Verdict-threshold mechanical-scoring rule preventing post-hoc renegotiation of Go/Modify/Stop. None of these are confirmed in writing by both co-chairs or their legal offices. Absence of binding legal lock-down on procedures, thresholds, and rules before Phase One clock (Month 6 = 2027-04-08) enables either co-chair to contest procedures, challenge thresholds, or claim the evidence rule was miscalibrated, triggering 4–8 week renegotiation, delayed verdict, and political withdrawal. The bilateral instrument is identified as a critical artifact due Month 1 (2026-11-08) but no specimen draft or legal-team sign-off is documented. Neutral-facility host-country agreement is OPEN (site not yet selected). Domestic access-authority legislation is labeled as entry condition but no draft language, timeline, or legislative-liaison authority is assigned. Operator Statements of Cooperation are due Month 5.5 (2027-03-23) but lack binding enforcement mechanisms or compensation ceilings. Risk is HIGH because legal lock-down failures cascade into governance stalling and verdict contestation.

**Mitigation**: Bilateral Legal Implementation and Instrument Specialist: Commission an independent bilateral legal team (3 attorneys per side, arms-control treaty experience) by Month 0 (2026-10-08) to produce three binding legal artifacts locked by Month 2 (2026-12-08): (1) Bilateral Instrument (80–120 pages, classified) embedding deadlock clock, automatic-suspension triggers (days 14/21/28), evidence-rule confidentiality and no-amendment clause, verdict-threshold mechanical-scoring rule with no-amendment lock, hard Stop triggers, neutral-facility status, and inspector immunity. (2) Domestic Access Authority legislation (specimen draft per country) granting compulsory operator participation, inspector privileges, and security-vetting authority. (3) Operator Cooperation Framework with binding compensation ceiling (proposed USD 30–50M per site) and performance baselines (access ≤4 hours, 48-hour exercise notice). Obtain independent legal audit (Month 1.5 = 2026-11-23) confirming internal consistency and enforceability. Lock all three by bilateral co-chair signature by Month 2 (2026-12-08) before first-tranche release.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because post-Phase-One funding, ledger archival, neutral-facility sustainability, and inspector repatriation are unresolved. A Modify verdict (40–60% probability) requires rework authorization (USD 250–400M, unfunded). A Stop verdict requires orderly shutdown (inspector repatriation, ledger archival USD 5–10M, facility handoff). Neither scenario has pre-authorized transition funding or procedures, risking abandoned infrastructure, stranded personnel, and bilateral relationship damage at verdict conclusion. The plan omits post-Phase operational authority and budgets entirely.

**Mitigation**: Program Risk Officer: Produce Post-Phase-One Sustainability Framework by Month 8 (2027-06-08) specifying Modify rework funding (USD 250–400M from existing budget or supplemental), Stop shutdown procedures (inspector repatriation, ledger archival USD 7–15M escrow, facility handoff), and maintenance contracts for 7-year archive preservation. Separate tranche-4 release from rework authorization so verdict is not held hostage.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan designates three critical hard-constraint gates (reciprocal-access parity confirmed at entry, operator-cooperation statements signed by Month 5.5 = 2027-03-23, neutral-facility hardening certified by Month 3 = 2027-01-08) but lacks binding legal/operational enforcement and pre-validation. Bilateral MOU with the host country for the neutral facility is OPEN (site location Geneva or Singapore not yet selected as of Month 0 = 2026-10-08). Operator Statements of Cooperation lack compensation ceilings or performance baselines (proposed USD 30–50M per site, access within 4 hours); no operator has provided written commitments. Reciprocal-access parity definition is marked TBD—measurement method undefined. If any constraint remains unresolved at the entry-gate certification deadline (Month 5.5 = 2027-03-23), Phase One is delayed 4–8 weeks (compressing the test from 90 to 50–60 days, widening statistical confidence from ±12% to ±18–20%, invalidating proof-of-concept credibility). Viable alternatives exist for site selection (fallback to 2 pairs instead of 3, contingent upon pre-authorized scope reduction) and for facility location (secondary host-country candidate), but these backstops require pre-commitment by Month 0.5 (2026-10-23).

**Mitigation**: Bilateral Hard-Constraint Validation Team: Confirm three constraints in parallel by Month 5.5 (2027-03-23, entry-gate certification). (1) Neutral Facility Constraint: Designate Geneva and Singapore as co-nominated candidates by Month 0.5 (2026-10-23); obtain bilateral host-country MOUs confirming site availability, diplomatic immunity, permits, and hardening-completion timeline by Month 1.5 (2026-11-23); certify ISO 27001 and Tempest-equivalent security by Month 3 (2027-01-08) or activate secondary site within 48 hours. (2) Operator-Cooperation Constraint: Collect signed Statements of Cooperation from all 6 candidate sites locking compensation ceiling (USD 30–50M per site), staging access (within 4 hours), and exercise notice (48 hours minimum) by Month 5.5 (2027-03-23); publish unclassified operator-participation registry. (3) Reciprocal-Access Parity Constraint: Operationalize parity via four quantified indicators (inspector-hour balance ≥90%, exercise-opportunity distribution within 10%, data-access turnaround ≤3 days, challenge-outcome agreement ≥80%) and lock measurement procedures in bilateral instrument by Month 5 (2027-03-08). If any constraint remains unresolved by Month 5.5 (2027-03-23), invoke the pre-authorized scope-reduction backstop (2 pairs instead of 3, all-in commitment by Month 0.5 = 2026-10-23) or formal Stop decision.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan designates three critical external dependencies (neutral facility site selection OPEN as of Month 0 = 2026-10-08, operator access commitments lacking binding enforcement mechanisms, and vendor-refusal fallback ladder with 40-60 week resolution window against a 5.5 month entry-condition gate) without tested failover procedures or secondary suppliers locked before Phase One begins. The neutral facility chokepoint (no signed host-country MOU, site undecided between Geneva/Singapore, hardening timeline unvalidated) directly blocks key-custody ceremony (Month 4 = 2027-02-08) and ledger validation (Month 5 = 2027-03-08); a 4-week facility slip exhausts the pre-clock calibration window and delays entry certification (Month 5.5 = 2027-03-23), compressing Phase One from 90 to 50-60 days and widening statistical confidence intervals from ±12% to ±18-22%, rendering detection thresholds indefensible. Operator cooperation statements (due Month 5.5 = 2027-03-23) lack compensation ceilings or performance baselines; mid-Phase-One operator withdrawal (Month 7-8 = 2027-05-08 to 2027-06-08) triggers asymmetric access, a hard Stop. Vendor-refusal fallback ladder cannot complete its five rungs in time, leaving equipment unverifiable or excluded at entry.

**Mitigation**: Bilateral External Dependency Resilience Lead: (1) Designate both Geneva and Singapore as competing host-country nominees by Month 0.5 (2026-10-23) and open parallel procurement at both sites; lock bilateral host-country MOUs with both candidates confirming site availability, diplomatic immunity, permits, and hardening-completion timeline by Month 1.5 (2026-11-23); obtain ISO 27001 and Tempest-equivalent security certification by Month 3 (2027-01-08) for the primary site, or activate secondary site immediately. (2) Collect signed Operator Cooperation Statements locking compensation ceiling (USD 30-50M per site), staging access (within 4 hours), and exercise cooperation by Month 5.5 (2027-03-23); pre-stage fallback: substitute cooperative sites if asymmetry emerges, or reduce to 2 pairs. (3) Document all vendor refusals by Month 3 (2027-01-08) and start fallback procedures immediately; start the first rung for each refusal by Month 3 (2027-01-08); equipment unresolved at entry is counted in the unverifiable share.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because Operators (incentivized to minimize disruption and protect IP via restricted access windows and limited staging-area occupancy) and Inspectorates (incentivized to maximize detection via 24/7 presence and unannounced exercises) have a fundamental conflict: tighter operator access control reduces unreported-arrival detection (detection rates fall below 70% threshold at constrained sites), while loosened access increases production-disruption risk and motivates operator mid-Phase-One withdrawal. This unstated conflict is critical because an operator access restriction or site withdrawal at Month 7–8 (2027-05-08 to 2027-06-08) triggers asymmetric detection across matched pairs, breaching the reciprocal-access parity Go criterion (≥85%, proposed), invoking the hard Stop condition for asymmetric access, wasting USD 30–50M sunk costs, and potentially invalidating Phase One as a credible bilateral proof-of-concept.

**Mitigation**: Bilateral Operator-Inspectorate Alignment Lead: Create a jointly owned OKR locked by Month 4 (2027-02-08) specifying "Reciprocal Detection Under Operational Continuity" with four quantified, symmetric targets: (1) Exercise Access Parity: both paired sites grant exercises within committed windows (staging access <4 hours, 48-hour notice for scheduled, 0 for unreported-arrival), measured weekly (target ≥90% parity within 10% variance), (2) Detection Opportunity Balance: exercises scheduled symmetrically across day/night/maintenance windows (target unreported-arrival detection ≥70% at both sites), (3) Operator Satisfaction Metric: zero unplanned access restrictions mid-Phase-One (target withdrawal probability <5%), (4) Shared KPI Dashboard: weekly publication of access parity, detection rates per site, and operator cooperation score visible to both inspectorate and operators, creating mutual accountability. Owner: Joint Operator-Inspectorate Liaison Officer (one per country). Deliverable: Operator-Inspectorate OKR Charter signed by both site operators and inspection leads by Month 4 (2027-02-08). Timeframe: OKR measured continuously during Phase One (Months 6–9 = 2027-04-08 to 2027-07-08), with monthly reconciliation and escalation to co-chairs if any metric falls below 80% of target.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan embeds an explicit feedback loop: weekly KPI dashboard (discrepancy age, contingency burn, personnel certification, envelope status) with named owners (Joint Finance Authority, Independent Timekeeper, Program Risk Officer), monthly bilateral review cadence (Budget Authority, CI Oversight Board, facility audits), and pre-registered change-control thresholds with measurable triggers (contingency >30% = briefing, >50% = re-scope planning, >75% = review; tranche delay >14 days = escalation, >30 days = Stop; discrepancy age >14 days = partial suspension, >21–28 days = impaired-confidence status). Vague 'we will monitor' language is absent; all triggers are quantified, owned, and linked to decision gates (e.g., automatic partial suspension without co-chair discretion). Minor follow-up: validate that weekly reporting actually occurs and that decision-makers respond within the specified timelines (escalation <5 days, decisions <7 days).

**Mitigation**: Program Risk Officer and Joint Finance Authority: Establish automated KPI dashboard generation by Month 3 (2027-01-08) pulling from ledger infrastructure (hourly digest sync, event logs) and personnel/vetting databases; validate that weekly report-outs (every Monday, 09:00 CET) are delivered to both co-chairs within 2 hours of deadline; confirm that escalation triggers (contingency draw >30%, tranche delay >14 days, discrepancy age >14 days) automatically notify co-chairs within 5 days per the bilateral instrument; conduct a monthly feedback-loop dry-run (Month 5 = 2027-03-08) simulating a cascade breach (e.g., contingency draw hitting 40%, triggering a briefing and scope-reduction assessment) to verify decision-maker response time meets SLA (&lt;5 days).


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan exhibits three strongly coupled critical-risk clusters creating multi-domain cascades: (1) Entry-condition sequencing + statistical compression: gates slip 8 weeks → contingency consumed USD 100–200M → Phase One compresses from 90 to 50–60 days → confidence intervals widen from ±12% to ±18–22% → Go/Modify/Stop thresholds become ambiguous (interval straddles all three) → verdict contestation → renegotiation delays final decision past Month 9.5 (2027-07-23). (2) Evidence-rule miscalibration + adjudication overload + automatic deadlock: false positives rise from 10% to 15–20% → 30–50 discrepancies per month vs. 15-case capacity → cases age past day 21 impaired-confidence → automatic partial suspension cascades across multiple sites → unrelated verification stalled → cascade of partial suspensions triggers emergency summit → Stop by default from unresolved-caseload failure. (3) Operator mid-Phase-One withdrawal + shift-coverage gaps + exercise-timing predictability: operator restricts access Month 7–8 (2027-05-08 to 2027-06-08) → detection drops 15–25% at restricted site → asymmetric parity within matched pair → hard Stop trigger (asymmetric access) → sunk USD 30–50M investment wasted. The plan names these risks individually but does not operationalize the cascade-detection triggers or pre-authorize the mitigation sequencing that would prevent one co-chair from stalling while the cascade develops. No independent Cascade Council or automated escalation authority exists to force timely decisions when multi-domain failures are detected simultaneously.

**Mitigation**: Bilateral Risk Cascade Authority: Establish by Month 0 (2026-10-08) with one program-risk officer per country, reporting jointly to both co-chairs. Map all 19 documented risks into an integrated cascade graph (if A fails → B fails → C fails = Stop); for each cascade path identify: (1) trigger metric (e.g., "contingency draw ≥30%" or "discrepancy age ≥14 days"), (2) threshold, (3) detection owner, (4) pre-authorized response (e.g., "activate adjudication surge within 48 hours," "convene emergency summit within 5 days," "invoke scope reduction to 2 pairs"). Embed cascade-detection procedures and owner assignments in the bilateral instrument by Month 1 (2026-11-08) as binding procedural law. Deploy automated cascade-status dashboard (weekly report-out every Monday, 09:00 CET) pulling ledger data and metrics to flag when any metric reaches 75% of threshold (yellow alert) or exceeds threshold (red alert/auto-escalation). Operator Cascade: pre-stage fallback cooperative sites by Month 4 (2027-02-08); if operator restricts access at Month 7–8 (2027-05-08 to 2027-06-08), substitute site within 48 hours or invoke 2-pair scope reduction. Entry-Condition Cascade: appoint external escalation authority empowered to convene co-chair summit within 48 hours of any gate slipping >2 weeks, with 5-day binding authority to reduce scope (2 pairs, full 90 days, 4 exercises per site per month = 48 exercises) rather than extend timeline, pre-authorized by Month 0.5 (2026-10-23).