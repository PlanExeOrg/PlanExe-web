A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Both governments will release tranches on time and will not use appropriations, domestic authority or contingency approvals as leverage during entry gates and Phase One. | Obtain written preliminary concurrence from both finance committees on tranche triggers and the Month 2 (2026-12-08) appropriation date. Walk the contingency draw hierarchy with the Joint Budget Authority. | Either government declines to pre-commit tranche release or draw authority in writing, or projects appropriation beyond Month 2 (2026-12-08) by more than 2 weeks. |
| A2 | The confidential rotating evidence rule, validated on benign historical records plus synthetic cases, will hold false positives near 10% and keep discrepancies near 15 per month under adversarial operator behavior. | Run the draft rule on 100-200 historical events per site and 20-30 adversarial synthetic cases per site. Model the caseload at 10%, 15% and 20% false positives. | False positives fall outside 7-13%, false negatives on synthetic cases are 5% or higher, or modeled caseload exceeds 15 per month with no funded surge. |
| A3 | Operators, host governments and vendors will give matched, symmetric access (including unreported-arrival injections) for all of Phase One without shielding, withdrawal or throttling. | Hold dry-run exercises at each candidate site. Obtain operator Statements of Cooperation and 12-month maintenance calendars. Measure staging access time against the 4-hour baseline. | Any operator refuses blind injections, access takes over 4 hours, or the detection-opportunity gap within a pair exceeds 10%. |
| A4 | The neutral facility (Geneva or Singapore) can be sited, hardened and staffed by Month 3 (2027-01-08), and dual-share key ceremonies and ledger hosting there will run without a host-country or custody chokepoint. | Open parallel host-country talks with both candidates. Request written timelines for permits and hardening. Schedule a key-ceremony rehearsal slot at each candidate. | Neither host confirms a signed MOU by Month 1.5 (2026-11-23), or certified hardening is projected after Month 3 (2027-01-08) by more than 4 weeks (estimate). |
| A5 | About 180 full-time staff per country (estimate) can be recruited, vetted and certified (80% by Month 5 = 2027-03-08) and held through 4-month rotations without breaching counterintelligence rules or coverage minimums. | Audit both clearance systems for throughput. Run a pilot training cohort. Simulate the rotation roster against the 6-position shift minimum and the 48-hour weekly limit. | Projected certification by Month 5 (2027-03-08) is below 80%, vetting attrition exceeds 20% (proposed threshold), or the roster cannot fill 6 positions per shift. |
| A6 | A Modify or ambiguous verdict will be accepted by both governments and legislatures as a real, binding outcome, with the 20% final tranche released on publication and not used as leverage. | Hold a verdict-consensus stress test with both co-chairs using a hypothetical result whose interval straddles a threshold. Obtain written positions on tranche 4 and on the post-Phase funding route (OPEN). | Either co-chair or legislature refuses in writing to accept Modify as binding, or insists on linking tranche 4 release to a Go outcome. |
| A7 | The vendor-refusal fallback ladder can resolve critical equipment before the Month 6 (2027-04-08) clock, so unverifiable or excluded equipment stays at or below 5% and the covered schedule remains representative. | Collect written vendor positions by Month 3 (2027-01-08). Map each refusal to the rung that can finish before Month 6 (2027-04-08), given 8-12 weeks per rung. Compute the share of scheduled equipment left unverifiable or excluded. | Projected unverifiable or excluded equipment exceeds 5% overall or 10% at any site (proposed threshold), or two or more Tier-1 vendors refuse all rungs. |
| A8 | The mirrored inspectorate and ledger operators will keep the sealed-communication, compartmentalization and cooling-off discipline for 9.5 months without a counterintelligence breach or IP disclosure that forces political withdrawal. | Run a 48-hour tabletop breach case with both CI officers. Time the 48-hour investigation, 72-hour recommendation and 7-day decision. Obtain written confirmation from both CI agencies and legal offices that the fast-track is lawful domestically. | Either government cannot legally accept the 7-day adjudication timeline, the tabletop exceeds 7 days, or baseline vetting flags a sustained breach among more than 1% of candidates (proposed threshold). |
| A9 | Domestic legislatures, media and public opinion in both countries will tolerate reciprocal foreign inspection of frontier-computing sites for the full entry and Phase One period without forcing withdrawal over sovereignty or competitiveness concerns. | Brief the oversight committees of both countries with the unclassified summary by Month 1.5 (2026-11-23). Record written positions and monitor public and press framing for sovereignty concessions. | A committee in either country conditions funding or access authority on changes to inspector immunity, IP language or scope, or hostile framing prompts a formal withdrawal motion before Month 6 (2027-04-08). |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Tranche Tug-of-War | Process/Financial | A1 | Joint Finance and Contingency Officer | CRITICAL (15/25) |
| FM2 | The Flood of False Alarms | Technical/Logistical | A2 | Bilateral Arms-Control Verification Lead | CRITICAL (16/25) |
| FM3 | The Closing Gate | Market/Human | A3 | Operator and Vendor Liaison Lead | CRITICAL (15/25) |
| FM4 | The Vault With No Door | Process/Financial | A4 | Joint Facility Director | CRITICAL (15/25) |
| FM5 | The Empty Night Shift | Technical/Logistical | A5 | Inspector Recruitment, Vetting and Shift-Coverage Coordinator | CRITICAL (16/25) |
| FM6 | The Verdict Nobody Owns | Market/Human | A6 | Bilateral Arms-Control Verification Lead | CRITICAL (16/25) |
| FM7 | The Ladder That Ran Out of Rungs | Process/Financial | A7 | Vendor Liaison and Fallback-Ladder Manager | CRITICAL (16/25) |
| FM8 | The Leaking Firewall | Technical/Logistical | A8 | Counterintelligence Oversight Board Chair | CRITICAL (15/25) |
| FM9 | The Sovereignty Backlash | Market/Human | A9 | Legislative Liaison and Communications Lead | CRITICAL (15/25) |


### Failure Modes

#### FM1 - The Tranche Tug-of-War

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Joint Finance and Contingency Officer
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Appropriation in one country slips past Month 2 (2026-12-08); first tranche is unequal.
- Entry gates slip 8 weeks, costing USD 100-200M (estimate) of the 500M contingency.
- Each side uses releases as a veto point.
- Delay over 30 days triggers the funding Stop; the test is compressed or cancelled with sunk setup costs.

##### Early Warning Signs
- Appropriation bill not tabled in either legislature by Month 1.5 (2026-11-23)
- Task force reports a gate slipping over 2 weeks
- Joint Budget Authority dashboard shows deposits unequal

##### Tripwires
- Tranche deposit delayed >= 14 days
- Cumulative contingency draw >= 30% before Month 4 (2027-02-08)
- Any envelope >= 110% of plan

##### Response Playbook
- Contain: Freeze non-committed spending outside the compression reserve and notify both co-chairs within 48 hours.
- Assess: Reconcile envelopes, quantify slip cost against the 400-450M free contingency, and identify which gate drives the delay.
- Respond: Convene the emergency summit within 5 days and invoke the pre-authorized scope reduction to 2 pairs rather than extend.


**STOP RULE:** Stop if either tranche is delayed > 30 days or deposits stay unequal beyond 30 days.

---

#### FM2 - The Flood of False Alarms

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Bilateral Arms-Control Verification Lead
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Rule validated only on cooperative records misjudges adversarial cases.
- False positives reach 15-20%; caseload hits 30-50 per month against 15 capacity.
- Discrepancies age past day 14 and 21; partial suspensions cascade across sites.
- Rule is frozen during Phase One, so surge is the only response; verdict becomes unreadable.

##### Early Warning Signs
- Pilot false positives outside 7-13%
- Adjudication queue grows for 2 consecutive weeks
- Synthetic-case miss rate rises in rehearsal

##### Tripwires
- Open discrepancies >= 15 in any month
- Any discrepancy age >= 14 days
- Pilot false-positive deviation >= 5 points

##### Response Playbook
- Contain: Activate the pre-staged adjudication surge unit and triage by discrepancy age.
- Assess: Compare rule outputs with ground truth on the open cases; separate rule error from real findings.
- Respond: Run a second validation cohort before the clock; if it fails, delay the clock or reduce scope.


**STOP RULE:** Stop or re-scope if the pilot and second cohort both show false positives above 18% before Month 6 (2027-04-08).

---

#### FM3 - The Closing Gate

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Operator and Vendor Liaison Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- A commercial operator cites customer confidentiality and restricts maintenance-area access.
- A state site slows access through bureaucracy.
- Detection gap within a pair exceeds 10%, breaching parity.
- Public leaks of disputes cause political pressure; shielding or asymmetry becomes a hard Stop.

##### Early Warning Signs
- Operators delay Statements of Cooperation past Month 3 (2027-01-08)
- Dry-run access takes over 4 hours
- Press or legislative criticism of sovereignty concessions

##### Tripwires
- Staging access time >= 4 hours on 2 requests in a month
- Inspector-hour imbalance within a pair >= 10%
- Exercise deferrals by an operator >= 2 per site

##### Response Playbook
- Contain: Hold a same-week co-chair call with the operator and host government; log each denial in the ledger.
- Assess: Measure parity metrics for the pair and decide whether the cause is circumstantial or shielding.
- Respond: Substitute a cooperative site or drop to 2 pairs; invoke the Stop trigger if asymmetry persists.


**STOP RULE:** Stop if a matched pair's access or detection gap stays above 10% for 30 days or shielding is confirmed.

---

#### FM4 - The Vault With No Door

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Joint Facility Director
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Host-country MOU, permits and hardening slip past Month 3 (2027-01-08).
- First key ceremony (Month 4 = 2027-02-08) and recovery rehearsal (Month 5 = 2027-03-08) are compressed.
- Slip draws on the compression reserve (USD 50-100M, estimate); an 8-week slip costs USD 100-200M (estimate).
- Entry certification at Month 5.5 (2027-03-23) fails and the test shrinks.

##### Early Warning Signs
- No signed host MOU by Month 1.5 (2026-11-23)
- Hardening certification audit not scheduled by Month 2.5 (2026-12-23)
- Procurement of ledger hardware unordered at Month 2 (2026-12-08)

##### Tripwires
- Host MOU unsigned >= 14 days after Month 1.5 (2026-11-23)
- Hardening completion forecast >= 4 weeks after Month 3 (2027-01-08)
- Key-recovery rehearsal not held by Month 5 (2027-03-08)

##### Response Playbook
- Contain: Activate the pre-staged secondary host site within 48 hours and freeze further spend at the primary.
- Assess: Quantify the schedule loss and compression-reserve draw, and identify which ceremony and ledger tests can move.
- Respond: Convene the emergency summit within 5 days and approve relocation or scope reduction to 2 pairs.


**STOP RULE:** Stop or re-scope if no certified facility exists by Month 5.5 (2027-03-23).

---

#### FM5 - The Empty Night Shift

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Inspector Recruitment, Vetting and Shift-Coverage Coordinator
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Clearance throughput and training lag leave certification below 80% at Month 5 (2027-03-08).
- Shifts run below 6 positions; unreported-arrival detection becomes predictable.
- Overtime breaches the 48-hour week or coverage gaps open.
- Attrition during rotation widens gaps and lowers detection below the 70% planned-class threshold.

##### Early Warning Signs
- Clearance completion below 50% at Month 2 (2026-12-08)
- Pilot cohort certification below target
- Roster simulation shows unfilled positions

##### Tripwires
- Certified inspectors < 80% at Month 5 (2027-03-08)
- Positions filled per shift < 6 on any shift
- Monthly attrition >= 5% (proposed threshold)

##### Response Playbook
- Contain: Release the surge pool to the thinnest shifts and halt reassignments that break compartmentalization.
- Assess: Recompute coverage and the detection exposure by hour, and test shift boundaries against the exercise calendar.
- Respond: Publish the revised roster, extend training cohorts, or reduce to 2 pairs if minimums cannot be met.


**STOP RULE:** Stop or re-scope if fewer than 2 pairs can be staffed to the shift minimum at Month 5.5 (2027-03-23).

---

#### FM6 - The Verdict Nobody Owns

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Bilateral Arms-Control Verification Lead
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Results land with intervals straddling a threshold; mechanical rule yields Modify.
- One legislature reads Modify as failure or a quiet Go; the other as capitulation.
- Tranche 4 (USD 500M per country) and rework funding (OPEN) become leverage.
- Public framing diverges, and renegotiation delays the final decision past Month 9.5 (2027-07-23).

##### Early Warning Signs
- Co-chair declines to sign the stress-test acceptance
- Legislative committees request threshold changes
- Public statements frame Modify as success or failure

##### Tripwires
- Verdict publication slips >= 5 days past Month 9.2 (2027-07-14)
- Tranche 4 deposit delayed >= 14 days
- Threshold amendment requested >= 1 time after the lock

##### Response Playbook
- Contain: Issue a joint holding statement within 48 hours that restates the locked rule and the mechanical outcome.
- Assess: Have the independent statistician confirm the scoring against the pre-registered rule.
- Respond: Hold a co-chair summit and publish the funding route for Modify, separating tranche release from outcome.


**STOP RULE:** Stop or pivot if either government publicly rejects the mechanical verdict or withholds tranche 4 beyond 30 days.

---

#### FM7 - The Ladder That Ran Out of Rungs

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Vendor Liaison and Fallback-Ladder Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Vendor refusals are documented late; each rung takes 8-12 weeks (estimate), so the full five-rung sequence (40-60 weeks) cannot finish before the clock.
- Unresolved equipment is excluded or unverifiable, so the schedule omits frontier items.
- Examiner teams, clean-room and attestation work draw on the testing envelope and contingency.
- Unverifiable share breaches the 10% hard Stop.

##### Early Warning Signs
- Refusals not documented by Month 3 (2027-01-08)
- No rung started for a refused vendor by Month 3.5 (2027-01-23)
- Examiner teams not pre-staged by Month 2 (2026-12-08)

##### Tripwires
- Unverifiable or excluded equipment >= 5% overall
- Vendor refusals >= 2 Tier-1 vendors
- Refused vendors with no rung started >= 1 at Month 3.5 (2027-01-23)

##### Response Playbook
- Contain: Start the first available rung for every refused vendor within 5 days and activate the pre-staged examiner teams.
- Assess: Compute unverifiable and excluded share by site, and the draw on testing and contingency envelopes.
- Respond: Exclude unresolved items at entry, publish the registry, and re-scope to 2 pairs if the share stays above 10%.


**STOP RULE:** Stop or re-scope if unverifiable equipment exceeds 10% at a site or overall at entry certification (proposed threshold).

---

#### FM8 - The Leaking Firewall

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Counterintelligence Oversight Board Chair
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- An inspector retains notes or a sealed channel is misused.
- Filtering and debrief controls fail under 24/7 rotation load.
- Investigation (48 hours, 72 hours, 7 days) pauses the affected site and shrinks coverage.
- Confirmed IP disclosure triggers a hard Stop path, since 0 incidents are tolerated.

##### Early Warning Signs
- Debriefs completed late or skipped
- Sealed-channel call logs show unreviewed anomalies
- Filter audit finds omitted event-relevant fields

##### Tripwires
- Suspected breach cases opened >= 2 in a month
- Debriefs overdue >= 3 days
- Filter audit error rate >= 5% of sampled packages (proposed threshold)

##### Response Playbook
- Contain: Suspend the inspector's access, seal affected records and isolate the channel within 24 hours.
- Assess: Run the 48-hour investigation with both CI officers and the filter auditor to scope what was exposed.
- Respond: Issue the 72-hour recommendation, decide recall or remediation within 7 days, and re-certify filters before resuming.


**STOP RULE:** Stop if a confirmed IP or cyber disclosure is sustained and either government suspends participation.

---

#### FM9 - The Sovereignty Backlash

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Legislative Liaison and Communications Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Opposition frames inspections as surrender of sovereignty or loss of competitive advantage.
- Committees demand changes to immunity, IP language or scope.
- A leak of an operator dispute or incident accelerates pressure.
- Appropriation or access authority is delayed or withdrawn, and the test is cancelled with sunk setup cost.

##### Early Warning Signs
- Committee hearing scheduled to review the instrument
- Critical coverage rises across several outlets in one week
- Operators report customer or shareholder complaints

##### Tripwires
- Committee amendment demands >= 1 before Month 2 (2026-12-08)
- Appropriation vote delayed >= 14 days
- Withdrawal motion tabled >= 1 in either legislature

##### Response Playbook
- Contain: Issue a coordinated joint statement and brief committee chairs within 48 hours.
- Assess: Identify which clauses drive objections and quantify the delay and cost against the compression reserve.
- Respond: Negotiate compromise text with both ministries and publish the unclassified KPI dashboard to rebuild confidence.


**STOP RULE:** Stop if either legislature withholds appropriation or access authority for more than 30 days.
