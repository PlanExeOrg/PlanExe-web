### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] The Consortium spends USD 5 billion to verify only declared equipment at a few matched, declared sites. The leaders' stated fear is uncontrolled frontier AI, and the real risk lies in undeclared capacity, workloads and weights, which the mandate excludes by design, so a Go verdict would reassure without reducing that risk.**

**Bottom Line:** REJECT: A USD 5 billion mechanism that can only confirm the movement of declared equipment at agreed sites cannot address the threat that justifies it, and it would give both capitals false assurance about everything outside its scope.


#### Reasons for Rejection

- The scope excludes total computing capacity, hidden facilities, workloads, model weights and foreign-hosted infrastructure, so a state that wants uncontrolled AI simply keeps the work off the declared sites and the Consortium cannot see it.
- The mandatory entry conditions (signed treaty, appropriated funds, domestic access law, selected sites, approved inspectors, vendor participation, agreed equipment schedule) are the hard, uncertain part, and they sit outside the 90-day clock, so the test measures only the easy residue.
- The USD 5 billion (USD 2.5 billion per side) buys ledgers, mirrored shift teams and counterintelligence for a handful of sites, and a Go would cover only monitored changes at those sites, a result with no stated link to reduced risk.
- Each country must admit full-time, mirrored inspectors from its main rival into datacenters while USD 750 million goes to counterintelligence, so the program spends heavily to defend against the access it exists to create.
- Double-key authorization with no casting vote means any site finding, sanction or suspension can be vetoed by the accused, and the Stop triggers (asymmetry, shielded operators, diverging ledgers, withheld funds) can all be induced by one side at will.

#### Second-Order Effects

- 0–6 months: Both governments spend political capital on the entry conditions, and the declared-site list and covered-equipment schedule become bargaining chips, so the first output is a negotiated choice of what each side shows and not an inspection result.
- 1–3 years: Matched sites that pass become a showcase, while sensitive compute moves to undeclared locations, and a clean ledger is cited as evidence of restraint it cannot support.
- 5–10 years: A narrow verified-sites regime becomes the accepted ceiling of US–China AI verification, which makes broader capacity or workload verification harder to demand, and any collapse of the double-key process leaves both countries worse informed and more suspicious than before.

#### Evidence

- Case/Incident — New START inspections (2020–2023): on-site inspections stopped in March 2020 and Russia barred inspections on its territory in August 2022, which shows that inspection regimes between rivals end when one side stops cooperating.
- Case/Incident — IAEA cameras in Iran (2022): Iran removed 27 IAEA surveillance cameras in June 2022, and the Director General warned that continuity of knowledge was nearly lost, which shows monitoring at declared sites can be switched off unilaterally.



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[STRATEGIC] — Lamppost Ledger: A $5 billion US–China apparatus that can only count equipment both governments have already declared, at sites they chose together, cannot detect the hidden capacity that actually threatens either regime, and its tamper-evident record would give a false sense of safety.**

**Bottom Line:** REJECT: The Lamppost Ledger certifies only what the parties are willing to show, spends USD 5 billion to do it, and risks replacing real uncertainty with documented false assurance. A program built to leave out concealment cannot answer the question that justifies it.


#### Reasons for Rejection

- Compelling operators, vendors, maintenance firms, logistics contractors and their staff to open staging areas, spare inventory and records to a rival state's inspectors takes their consent by state order, and the workers carry the personal and legal risk of being treated as intelligence conduits.
- Every site finding, sanction and suspension needs both national keys, with no casting vote and a mandatory exclusion of hidden facilities, so the accused government can block any finding against its own side and each state judges its own conduct behind classified technical schedules and confidential evidence.
- A model of joint state inspectors inside commercial datacenters would be copied by other rivals and allies, and inspectors who have seen a site's staging layout, vendors and logistics routes keep that knowledge permanently, so no later rollback can remove the exposure.
- The design pays billions to certify the easiest thing to certify (declared equipment at volunteered sites) and excludes total capacity, workloads, hidden facilities and foreign-hosted infrastructure, so the 'credible detection' it could show says nothing about the diversion and concealment that matter.

#### Second-Order Effects

- **Month 0–12 (2026-10-08 to 2027-10-08) — The Gate Becomes the Project:** The mandatory entry conditions (signed instrument, appropriations, domestic access law, site selection, inspector approval, vendor participation, equipment schedule) take longer than any test they precede, so the 90-day exercise starts late, if it starts at all.
- **Month 12–36 (2027-10-08 to 2029-10-08) — The Clean Sites Get Cleaner:** Both sides move frontier-relevant equipment out of the matched declared sites and into undeclared ones, so the ledger records orderly, accurate and increasingly irrelevant activity.
- **Month 36–60 (2029-10-08 to 2031-10-08) — Copycats Arrive:** Other governments demand the same inside-the-datacenter access for their own rivals, and commercial operators, vendors and shipping firms face overlapping inspection regimes with conflicting secrecy obligations.
- **Month 60–120 (2031-10-08 to 2036-10-08) — The Reckoning:** When concealed capacity surfaces, the Consortium's clean record becomes evidence of its blindness, and the lasting results are a discredited verification idea and a generation of inspectors who know each other's supply chains.

#### Evidence

- Case/Report — In August 2022 Russia barred New START inspections at its facilities and cited disputes over reciprocal access. A verification system that lacks symmetric access and a shared reading of the rules can be shut off by one party.
- Case/Report — The US Department of Justice has brought criminal cases against China-connected rings accused of smuggling more than USD 160 million of Nvidia chips (figure from press reporting, not independently verified). The diversion that matters happens through shell companies and third countries, which this program expressly excludes.
- Law/Standard — US Export Administration Regulations controls on advanced computing items (introduced October 2022). These show that the equipment flows the Consortium would observe are already contested by law and enforcement, and that the main evasion routes lie outside any declared-site ledger.
- Narrative — Front-Page Test: 'Joint US–China inspectors certify every declared AI chip at the agreed sites; a hidden facility is then found elsewhere.' The headline would be about the Consortium's blind spot and would undermine the idea of verification.



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] A USD 5 billion verifier that watches only declared chips at matched sites certifies the easiest thing to stage and manufactures false assurance about everything outside its boundary.**

**Bottom Line:** REJECT: A treaty-grade, USD 5 billion inspectorate that can only confirm what each side chooses to declare is a monument to false assurance, and it should never be built.


#### Reasons for Rejection

- Scope: the mandate excludes total computing capacity, workloads, model weights, hidden facilities and foreign-hosted infrastructure, so a spotless ledger at declared sites says nothing about where frontier capability is actually being built.
- Gate design: the instrument, both appropriations (USD 2.5 billion each, user constraint), domestic access law, site selection, inspector approval and vendor participation must all exist before the 90-day clock starts, so the test measures cooperation among parties who have already surrendered the hard concessions.
- Governance: double-key authorization over site findings, sanctions and suspension hands each country a veto over accusations against its own operators, so the mechanism's output on the one question that matters is structurally bound to be deadlock or silence.
- Security: mirrored inspectors posted full-time into staging, spare-inventory and maintenance areas of the most sensitive datacenters give each state a standing intelligence platform inside the other's industry, and USD 750 million for counterintelligence cannot prove that bounded zones stay bounded.
- Budget and design: USD 500 million (10%) contingency and USD 250 million (5%) for bilateral legal implementation and auditing leave thin reserves for a regime spanning two incompatible legal systems, while a confidential, versioned covered-equipment schedule lets each side quietly redefine what counts as frontier-relevant.

#### Second-Order Effects

- 0–6 months: Both governments commit the full USD 5 billion and political capital to satisfy the entry conditions, and the staged exercises at pre-selected, cooperative sites produce encouraging detection figures that officials treat as proof of workability.
- 1–3 years: Declared-site verification becomes the public yardstick for AI restraint, while capacity migrates to undeclared or foreign-hosted facilities the mandate cannot see, and a contested site finding freezes the double-key system into suspension.
- 5–10 years: A clean ledger is cited as proof of compliance and defended by both capitals, so its failure to cover undeclared compute leaves a discredited verifier, a precedent of legitimized blind spots, and no credible route to later verification.

#### Evidence

- Case/Incident — Russia's suspension of New START on-site inspections (2022–2023): a bilateral verification regime depending on the consent of both parties was halted unilaterally, and the treaty was then suspended in February 2023.
- Case/Incident — Iran's removal of 27 IAEA surveillance cameras at nuclear sites (2022): the IAEA Director General warned that continuity of knowledge was nearly lost, showing monitoring collapses when a host withdraws cooperation.



### Premise Attack 4 — Cascade
_Tracks second/third-order effects and copycat propagation._

**This is a Strategic Flaw. The plan builds an elaborate, expensive and double-locked verification machine for the one question that doesn't matter to the leaders' stated fear. It confirms that declared equipment at volunteered sites moved as declared. It excludes total capacity, hidden facilities, workloads and weights, which is where uncontrolled frontier AI actually lives. Its entry conditions also assume the hardest diplomatic achievements (signed treaty, domestic access law, vendor compliance, approved inspectors) are already done, so the "90-day test" measures nothing about whether they can be done.**

**Bottom Line:** Abandon the premise. A mechanism that can verify only what each government agrees to declare, run under mutual vetoes and with entry conditions that assume away all the real diplomacy, produces false assurance, not security. The flaw is the scope (declared equipment at chosen sites), not the implementation, and no staffing model, ledger design or KPI set can fix it.


#### Reasons for Rejection

- The Lamppost Paradox: The mission is verification of declared-equipment changes at a small, matched set of declared sites. Every exclusion (no capacity estimate, no hidden-facility assurance, no workload or weight inspection, no foreign-hosted infrastructure) removes the leaders' real fear. A "Go" verdict will certify only that a handful of sites that were chosen to be inspected behaved well. Each government decides what is declared and where, so the observed set is the set it is happy to show. The sites with a perfect record are exactly the ones that tell you nothing.
- The Pre-Solved Problem Gate: The 90-day clock starts only after the treaty is signed, funds are appropriated, domestic access law is enacted, sites are chosen, inspectors are approved, vendors and operators are bound, and the covered-equipment schedule is adopted. Those steps are the whole difficulty. In the US they mean compelling private operators and foreign-linked vendors. In China they mean letting adversary inspectors into state-aligned facilities. The test that follows is a demonstration run in a room that diplomacy has already cleaned, and its "Go" will be read as proof that the hard parts are feasible when they were assumed.
- The Mutual-Veto Tripwire: Double-key authorization on budgets, protocol changes, site findings, sanctions and suspension, with no casting vote and no majority override, means any ambiguous finding can be blocked by the accused side's co-chair. Automatic suspension rules and deadlock rules pull in opposite directions. Either the system suspends whenever one party wants out, so every discrepancy becomes a political exit ramp, or deadlock freezes findings until they are stale. It is built to agree that nothing happened, not to find out whether something did.
- The Mirror-Image Fiction: Matched sites and reciprocal access treat two very different systems as symmetric. US datacenters are commercial, multi-tenant and bound by export-control and privacy law. Chinese sites sit within a party-state that can compel or conceal. Equal inspectors, equal budget and equal sites do not create equal information. The side with the less permeable state can meet the letter of parity and still expose far less of what matters. "Reciprocal-access parity" as a KPI can be satisfied with identical, uninformative access.
- The Vendor Chokepoint Illusion: Verification depends on the cooperation of chip, server, maintenance and logistics vendors who are subject to both countries' export controls and to jurisdictions outside the Consortium (not verified in detail). The plan's answer to refusal is a menu of workarounds (filtered evidence, clean rooms, attestations) that all rely on the vendor's own data or tooling, and a fallback label, "unverifiable". A refusing critical vendor therefore decides the verdict. The plan makes the vendor, not the governments, the most powerful actor.
- The Counterintelligence Self-Poisoning: A joint inspectorate puts each side's trained technical staff inside the other's most sensitive computing facilities, with a shared evidence ledger. That is the best collection platform either intelligence service could ask for. The USD 750 million security envelope (user constraint) assumes the insider threat can be budgeted away. It cannot, because the inspectors are themselves the threat. Each side's suspicion that the other is collecting will become the main driver of access disputes.

#### Second-Order Effects

- Months 0-12 (2026-10-08 to 2027-10-08) (pre-clock): Negotiation of the entry conditions absorbs all the political capital, with each of the seven conditions becoming a bargaining chip. Appropriation of USD 2.5 billion per side (user constraint) is sought before any capability is demonstrated. The Phase One clock may not start for a long and unbounded period (estimate), while the budget and staffing commitments accrue.
- Months 12-24 (2027-10-08 to 2028-10-08): Domestic access authority is enacted with carve-outs written by operators, vendors and security agencies. The inspection zones that survive are narrow staging and spare-inventory areas. Operators learn that anything beyond those zones is off-limits, and this becomes the de facto boundary of what the system will ever see.
- Months 24-30 (2028-10-08 to 2029-04-08) (90-day test): Exercises on unreported arrival, substitution and vendor refusal run in controlled areas with pre-warned operators. Detection looks strong because the challenges are scripted and the adversary is cooperative. The KPI dashboard reports good numbers from a population too small to support error-rate claims (estimate). The decision is Go or Modify, and the political incentive to call it Go is large.
- Months 30-48 (2029-04-08 to 2030-10-08): Expansion pressure follows the Go. Officials and the press describe the Consortium as an AI-safety or AI-control achievement, even though success covers only monitored changes at participating declared sites. Both sides continue building outside the boundary. The first serious allegation of hidden capacity cannot be addressed by the mechanism and is used instead to question its value.
- Months 48-72 (2030-10-08 to 2032-10-08): Disputes over a single adjudicated finding (a disputed equipment identity or a vendor refusal) hit the double-key deadlock. Automatic suspension is triggered or used as leverage, and one or both governments withhold funding. The ledger copies diverge and the 'unresolved' category grows. The institution ends as a standing diplomatic grievance with a USD 5 billion sunk cost (user constraint) and a record that each side can cite against the other.

#### Evidence

- New START: Inspections of US and Russian sites were paused by both sides in March 2020 because of COVID-19. Russia then unilaterally suspended cooperation with the treaty's inspection provisions in August 2022, and the US accused it in early 2023 of blocking inspections. A far more mature, treaty-based, bilateral, narrowly-scoped verification regime, which both sides had spent years negotiating and in which each side had a direct interest, was switched off by one party's political decision. Double-key rules and automatic suspension would give the Consortium the same off-switch with more triggers (source: NBC News / PBS NewsHour / Arms Control Association coverage).
- UNSCOM and Iraq: In 1999, major newspapers reported that the US had covertly used UN weapons inspectors to collect intelligence on the Iraqi military. Iraq expelled the inspectors in December 1998, charging that UNSCOM had become a spy agency, and the commission was disbanded the following year. The reported use of inspection data in target selection for the December 1998 bombing is cited as damaging the credibility of the process (Wikipedia and FAIR coverage; details of the allegations were contested, not independently verified here). The same counterintelligence dynamic is built into a mirrored inspectorate sitting inside each country's most sensitive compute facilities.
- The Consortium is dangerously unprecedented in its specific folly: no verified precedent exists for a jointly governed US–China inspectorate of commercial datacenter hardware, with vendor-bound private operators and a ledger shared across rival intelligence services. The closest analogues, nuclear arms verification, show that verification works only where the object is large, discrete, countable and tied to a treaty both sides are invested in. Commodity accelerators in racks are none of these (assessment, not verified).



### Premise Attack 5 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[STRATEGIC] — The Verified Island Illusion: a double-key regime that can only certify changes inside a small, declared, matched set of sites manufactures confidence about the one place that matters least, while it hands each rival a permanent, treaty-protected foothold inside the other's most sensitive computing infrastructure.**

**Bottom Line:** REJECT: A mutually vetoable inspection regime that can see only what each government agrees to declare, and that costs both sides a standing intelligence exposure, is an assurance ritual and not a safeguard, and it should not exist.


#### Reasons for Rejection

- Rights and dignity: the premise relies on domestic authority to compel operators, vendors, site staff and inspectors into a permanent foreign-state presence, which turns private employees and contractors into involuntary participants in a rival's intelligence-adjacent access regime, with no meaningful consent, recourse or protection from counterintelligence suspicion.
- Accountability and oversight: double-key authorization with no casting vote and no majority path means every finding, sanction and suspension can be vetoed by the party under scrutiny, so the body that is meant to hold each government accountable cannot act against either one without that government's agreement.
- Systemic risk and scale: the replicated ledger, evidence stores and inspector access channels concentrate a map of each side's frontier hardware flows into the highest-value espionage target in both countries, and the declared-site boundary invites activity to migrate to undeclared locations, which the scope excludes by design.
- Value-proposition rot: the plan promises 'credible detection' while excluding total capacity, workloads, weights, hidden facilities and foreign-hosted infrastructure, and it places every politically hard commitment (signature, appropriation, access law, site selection, vendor buy-in) before the 90-day clock starts, so the test can pass while proving nothing about the risk that motivated it.

#### Second-Order Effects

- T+0–6 months — The Cracks Appear: the entry conditions (signature, appropriation, domestic access law, site selection, inspector approval, vendor participation, equipment schedule) stall one by one, each side stages concessions to avoid being first, and the 90-day test clock does not start; meanwhile 'Consortium readiness' statements substitute for evidence.
- T+1–3 years — Copycats Arrive: if sites are matched and exercises are staged, other states and blocs demand their own bilateral or minilateral equipment-verification pacts, and a 'verified' label spreads as a diplomatic currency, while vendors face conflicting confidentiality, escort and reporting obligations across jurisdictions.
- T+5–10 years — Norms Degrade: both sides learn that compliance means declaring clean sites and moving sensitive work elsewhere, 'unverifiable' and 'unresolved disposition' categories become routine, deadlocks go unresolved without consequence, and the regime's clean record is cited to oppose broader scrutiny of hidden capacity.
- T+10+ years — The Reckoning: a major undeclared build-out or an inspector-linked intellectual-property or espionage scandal exposes that the ledger certified only what each side chose to show, the regime is suspended in mutual recrimination, and the lost continuity of knowledge cannot be rebuilt, leaving less trust and less transparency than before.

#### Evidence

- Case/Report — New START on-site inspections: the two parties conducted 328 on-site inspections through Feb 2023, yet inspections were paused from March 2020 (COVID) and Russia refused to resume them from Aug 2022, so a long-running, treaty-based regime lost its central verification function when one party chose to withhold access (Arms Control Association, https://www.armscontrol.org/act/2023-03/news/russia-suspends-new-start; Arms Control Center FAQ, https://armscontrolcenter.org/new-start-frequently-asked-questions/).
- Case/Report — IAEA and Iran, June 2022: at Iran's request the IAEA removed its JCPOA surveillance and monitoring equipment, including 27 cameras, and reported that it could not re-establish continuity of knowledge for some production and inventory items and would need a new baseline (IAEA GOV/2023/39, https://www.iaea.org/sites/default/files/23/09/gov2023-39.pdf; Iran Watch, https://www.iranwatch.org/node/12164).
- Principle/Analogue — Arms-control verification theory: 'continuity of knowledge' is lost the moment monitoring lapses, and verification of declared items says nothing about undeclared items; a regime that proves only the declared boundary gives a durable but misleading sense of assurance.
- Principle/Analogue — Counterintelligence: any standing foreign-access channel into sensitive facilities is simultaneously a collection platform, so the more rigorous the inspection, the larger the exposure that the receiving state must defend against.