### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] A US–China body that verifies only equipment changes at a few declared, matched datacenters certifies the one thing a determined party would never risk (what it chose to show) while excluding hidden facilities, total capacity and workloads, so even its best result, a "Go", does not reduce the threat that justifies it.**

**Bottom Line:** REJECT: Spending USD 5 billion on a double-vetoed, declared-sites-only equipment ledger buys a certificate that cannot speak to the threat it was created for, and it creates a standing intelligence interface between the two rivals.


#### Reasons for Rejection

- The scope bars verification of total computing capacity, workloads and hidden facilities, so a clean ledger at the 'small, matched set of declared datacenters' is fully compatible with unlimited frontier compute elsewhere, and a 'Go' says nothing about the national-security risk the leaders fear.
- Sites are chosen by the governments themselves and 'matched', and the live exercises run in staging, spare-inventory, maintenance or expansion areas 'without interrupting active computational work', so the 90-day test measures detection in the least sensitive corners of the least sensitive sites and cannot extrapolate to anything that matters.
- Every site finding, sanction and suspension needs double-key authorization with no casting vote, so the country whose site is implicated can block the finding against itself; the body is built to adjudicate violations yet gives the accused a veto over its own verdict.
- USD 750 million (user constraint) is earmarked for secure facilities, cybersecurity and counterintelligence, plus mirrored inspectors from each side inside the other's frontier datacenters: the budget openly treats the inspectorate as an intelligence threat, so the mechanism doubles as an espionage channel that each state has reason to exploit and to exaggerate.
- The 90-day test begins only after treaty signature, appropriation, domestic access law, site selection, inspector approval, vendor buy-in and the covered-equipment schedule are all complete, so the hard question of whether two rivals will ever accept these terms is answered before the USD 5 billion (user constraint) is spent, and the test then only proves a mechanism that already needed political consensus to exist.

#### Second-Order Effects

- 0–6 months: Site selection becomes a contest to offer the least revealing facilities and the most favorable 'matched' pairs; each country's agencies treat inspector vetting as a counterintelligence opportunity and slow-roll approvals, so the entry conditions never fully close.
- 1–3 years: The ledger becomes the only authoritative record, so unrecorded capacity migrates to undeclared sites and the declared set turns into a showcase, while both governments cite 'verified' status in public to deflect scrutiny of everything outside the boundary.
- 5–10 years: The institution is entrenched with its own budget lines and legal standing, and either becomes a diplomatic shield for unmonitored AI buildup or collapses in a mutual accusation of inspector espionage that leaves less bilateral contact than before it was created.

#### Evidence

- Case/Incident — Russia's suspension of New START participation (2023): Moscow announced it would stop implementing the treaty's inspection and verification provisions, showing that bilateral inspection regimes between rivals end when political interest does.
- Case/Incident — Iran's removal of 27 IAEA surveillance cameras (June 2022): the IAEA stated it could no longer have confidence in continuity of knowledge about centrifuge and related production, showing how fast monitoring lapses once the host withdraws consent.
- Case/Incident — Collapse of the Biological Weapons Convention verification protocol talks (2001): the US rejected the draft protocol, citing risks to proprietary commercial and security information, the same industry-secrecy conflict this plan tries to manage with filtered evidence.



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[STRATEGIC] — Sealed Door, Open Barn: a USD 5 billion (user constraint) two-key mechanism that, by its own charter, verifies only declared equipment changes at a small matched set of declared sites, and so certifies the one thing a cheating state would never put on the table while staying silent on hidden facilities, total capacity, workloads and model weights, the things that decide whether frontier AI is controlled.**

**Bottom Line:** REJECT: Sealed Door, Open Barn describes a mechanism that locks the entrance it chose to guard and says nothing about the barn behind it, while handing each rival a view of the other's supply chain and a veto over the verdict. A narrowly verified ledger at declared sites will be mistaken for control of frontier AI, and that false assurance is worse than no mechanism at all.


#### Reasons for Rejection

- It conscripts private operators, maintenance firms and logistics companies that never signed the bilateral instrument, forcing foreign-state inspectors into their staging areas, shipping records and maintenance logs under domestic compulsion, with no consent from them or from the customers whose data sits next door.
- Every budget, finding, sanction and suspension needs both national keys with no casting vote, so each government can stall any finding against its own operator and nothing outside the two capitals can compel a verdict; the mechanism sits in a gap that neither state's courts nor any neutral body can reach.
- Once rival intelligence services have mapped each other's equipment identifiers, vendor firmware paths and datacenter supply chains through escorted access, that knowledge cannot be recalled, and the template of foreign inspectors inside commercial facilities will be demanded by every other capital.
- The money buys a narrow, self-selected sample: compliant sites, declared equipment, a 90-day test that starts only after treaty signature, appropriation, domestic access law, site selection, vendor buy-in and a covered-equipment schedule are all complete, and a clean ledger at those sites says nothing about compute placed anywhere else.

#### Second-Order Effects

- **Months 0–12 (2026-10-12 to 2027-10-12) — The Gate Becomes the Project:** the mandatory entry conditions (signed instrument, matched appropriations, domestic access authority, vendor participation) absorb all political energy, so the test itself is repeatedly postponed while the mechanism's existence is already being cited as progress.
- **Months 12–48 (2027-10-12 to 2030-10-12) — Copycats Arrive:** other states and blocs demand equal inspection rights or build rival regimes, and the declared-site model teaches every actor that the safe place to put sensitive compute is any site that is not declared.
- **Months 48–84 (2030-10-12 to 2033-10-12) — Assurance Theatre:** clean ledger results at participating sites are read by officials and the public as evidence that frontier compute is under control, easing political pressure while capacity grows outside the monitored boundary.
- **Months 84–120 (2033-10-12 to 2036-10-12) — The Reckoning:** the discovery of significant equipment or capability outside the boundary, or a leak from an inspected zone, discredits the ledger, leaves each government holding a detailed map of the other's supply chain, and collapses the mechanism the way inspection regimes have collapsed before.

#### Evidence

- Case/Report — New START: on-site inspections were suspended in March 2020, Russia barred inspections at its facilities in August 2022, and Putin announced suspension of the treaty on 21 February 2023 (Arms Control Association reporting, https://www.armscontrol.org/act/2023-03/news/russia-suspends-new-start); the bilateral inspection model failed when politics soured, with no neutral party to restore it.
- Case/Report — Iran and the IAEA: Iran stopped voluntary implementation of the Additional Protocol on 23 February 2021 under a parliamentary law and threatened to delete camera recordings after a three-month holding arrangement (reported by IranWatch/IRNA and others, https://www.iranwatch.org/library/governments/iran/islamic-republic-news-agency-irna/iran-disable-iaea-cameras-if-sanctions-not-lifted-3-months); monitoring equipment and evidence are only as durable as the host's consent.
- Law/Standard — IAEA INFCIRC/153 (model comprehensive safeguards agreement): rests on a standing neutral international inspectorate with its own reporting line, a structure the Consortium's two-key, no-casting-vote design deliberately lacks.
- Narrative — Front-Page Test: a leak from an escorted inspection reveals that a foreign government's inspectors recorded a commercial datacenter's maintenance contractors and shipment routes, and the headline writes itself: 'Rival-state inspectors given a map of our AI supply chain.'



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] A USD 5 billion US–China inspectorate verifying only declared equipment at matched sites certifies nothing about undeclared compute, manufacturing confidence while the real threat sits outside its boundary.**

**Bottom Line:** REJECT: A bilateral inspectorate that can see only what two rivals choose to declare, and can be silenced by whichever rival it accuses, buys the appearance of control and not control itself.


#### Reasons for Rejection

- The mandate expressly excludes total-capacity estimates, workload verification and proof of no hidden facilities, so a spotless ledger at the declared sites is fully compatible with unlimited compute elsewhere, leaving the leaders' stated fear of uncontrolled frontier AI untouched.
- Double-key authorization with no casting vote and no majority override over site findings, sanctions and suspension lets the accused country veto the finding against itself, so the body meant to name violations can be gagged by the violator.
- The 90-day clock starts only after the treaty is signed, funds appropriated, domestic access law enacted, sites chosen, inspectors approved, vendors secured and the schedule adopted, so Phase One tests cooperation only after every contested concession has already been won.
- Allocating USD 750 million to secure facilities, cybersecurity and counterintelligence concedes that the inspectorate is itself an espionage conduit, since mirrored teams sit inside the most sensitive datacenters of two adversaries holding evidence about their equipment.
- Equipment identity rests on vendor attestation, maintenance records and shipping paperwork from manufacturers and logistics firms outside the Consortium's control, and a refusing critical vendor leaves only the label 'unverifiable', so evidence quality is governed by the parties least bound to supply it.

#### Second-Order Effects

- 0–6 months: Entry-condition negotiations over the provisional covered-equipment schedule, site matching and inspector approvals consume the opening months, with each country trading access concessions for narrower definitions, so the schedule that emerges is whatever both sides could afford to be seen.
- 1–3 years: A Go verdict on 'monitored changes at participating declared sites' is quoted in diplomacy and markets as proof of oversight, while compute migrates to undeclared sites and foreign-hosted infrastructure that the mandate cannot see, hollowing out the assurance it advertises.
- 5–10 years: Hardware generations turn over, the double-key schedule fights stall every revision, one funder withholds its USD 2.5 billion share or shields an operator, and the apparatus becomes a vestigial, permanently suspended structure that has still embedded inspectors and ledgers inside two national security perimeters.

#### Evidence

- Case/Incident — New START on-site inspections (2020–2023): inspections were halted from 2020 and Russia suspended participation in the treaty on 21 February 2023, showing that bilateral verification between adversaries stops when political will lapses.
- Case/Incident — Treaty on Open Skies withdrawals (2020–2021): the United States' withdrawal took effect on 22 November 2020 amid disputes over restricted access, and Russia's withdrawal followed in 2021, showing that reciprocal access regimes collapse over asymmetric access complaints.



### Premise Attack 4 — Cascade
_Tracks second/third-order effects and copycat propagation._

**The plan builds an elaborate, USD 5 billion verification apparatus around the one thing that cannot threaten either leader's goals: declared, cooperative sites. Everything that determines whether frontier AI is "uncontrolled" (undeclared capacity, diverted chips, workloads) is excluded by design, while the genuinely hard problems (espionage, vendor control, adjudicating an accused party) are pushed into pre-conditions that, if solved, would make a 90-day test unnecessary. The result is a certification machine that converts a narrow, easily staged success into a false impression of control.**

**Bottom Line:** Abandon the premise: verifying change events at a handful of declared, hand-picked sites cannot deliver control over frontier AI, and the entry-condition structure ensures the real obstacles (undeclared capacity, espionage, adjudication of the accused) are never tested. The flaw is in what the Consortium is defined to see, not in how well it is run.


#### Reasons for Rejection

- The Declared-Island Illusion: verification is limited to equipment changes at a small matched set of sites the host governments themselves choose and declare. The risk both leaders fear lives in the undeclared remainder, which the plan expressly refuses to examine (no capacity estimates, no hidden-facility assurance, no foreign-hosted infrastructure). A perfect score proves only that cooperative sites behave cooperatively. Worse, the existence of a clean ledger gives each side a plausible-looking shield behind which to shift real build-out off-ledger.
- The Pre-Solved Test Paradox: the 90-day clock starts only after the treaty, appropriation, domestic access law, site selection, inspector approval, vendor participation and covered-equipment schedule are all complete. Every decision that could actually fail is placed outside the test. What is left to 'test' is the operation of a system whose entire political and legal difficulty was assumed away. If these entry conditions can be met, trust and access already exist; if they cannot, Phase One never begins. The plan has no honest path from today to Month 0 (2026-10-12) of its own clock.
- The Inspector-as-Sensor Trap: mirrored full-time inspectors embedded in the other side's most sensitive compute facilities are, structurally, the best-placed intelligence collectors either state could ask for. 'Information barriers' and 'filtered evidence' require the host to decide what is filtered, which is exactly what the inspector cannot trust, while the inspector's competence is the same competence that yields espionage. Counterintelligence units on both sides will treat every inspector as a presumed collector, so the inspection access that the Go criterion demands is eroded by the counterintelligence posture the plan itself funds.
- The Double-Key Doorstop: equal co-chairs, no casting vote, no majority procedure and double-key authorization for budgets, protocol changes, site findings, sanctions and suspension means the accused party holds a key to its own finding. Deadlock, impaired-confidence and automatic-suspension procedures can be defined on paper, but automatic suspension becomes a unilateral off-switch (any side can trigger a dispute and freeze the regime) while adjudication of a real violation requires the violator's consent. The body is simultaneously unable to convict and trivially able to be killed.
- The Staged-Honesty Gap: live exercises run in staging, spare-inventory, maintenance or expansion areas without touching active computation, and are conducted by the same governments that control the sites, schedule and the 'blind' challenge pool. Both hosts know a 90-day test is under way and that a Go verdict is the political prize. Detection rates measured against short, bounded, non-production scenarios say nothing about a determined actor operating in production halls over years, and the plan's thresholds are 'provisional or TBD' by its own admission. Equipment identity also depends on vendor-supplied attestation and cooperation from firms subject to export-control and sanctions pressure, which neither government fully commands.

#### Second-Order Effects

- Months 0-18 (2026-10-12 to 2028-04-12) (estimate): the entry-condition list consumes all the time and political capital. The bilateral instrument, domestic access authority, matched-site selection and covered-equipment schedule each become separate bargaining arenas, and each side trades site 'matching' against the other's most sensitive facility. The 90-day clock does not start; the program is described as 'on track' while only the pre-gate is progressing.
- Months 18-36 (2028-04-12 to 2029-10-12) (estimate): to satisfy 'matched' selection, both sides nominate sanitized, purpose-chosen sites that are not representative of frontier build-out. Intake staging areas become theatre, the real procurement flows are routed around them, and inspector approval lists are filled with the least-risky, least-capable candidates, hollowing out the detection capability the KPIs claim to measure.
- Months 36-48 (2029-10-12 to 2030-10-12) (estimate): Phase One runs and almost certainly produces Go or Modify, because both governments are invested in a positive result, challenge scenarios are bounded and operators were prepared. Public and allied narratives start to treat the Consortium as evidence that frontier compute is being governed, even though the scope statement says it covers only monitored changes at declared sites.
- Months 48-84 (2030-10-12 to 2033-10-12) (estimate): off-ledger expansion accelerates because the ledger sites are now the 'legitimate' compute and everything else is outside the regime. Each side accuses the other of using inspection data for targeting or exploiting vendor supply-chain secrets; a single publicized IP or counterintelligence incident, or a disputed finding that the double-key rules cannot resolve, triggers automatic suspension, and the half-built trust is spent.
- Months 84-120 (2033-10-12 to 2036-10-12) (estimate): the Consortium becomes a stranded USD 5 billion institution with entrenched mirrored bureaucracies, a ledger whose national copies disagree about disputed history, and no political path to either expansion (the hard problems remain excluded) or dissolution (leaders cannot admit failure). The most dangerous residual is false confidence: policymakers who believe verification exists will be slower to react to the compute build-out that matters.

#### Evidence

- UNSCOM (UN Special Commission, Iraq, 1991-1998): a verification body with a Security Council mandate and intrusive access was brought down by allegations that its inspections had been used for intelligence collection. Iraq expelled the inspectors in December 1998 on the charge that UNSCOM had become a spy agency, and former chief inspector Scott Ritter has stated that US intelligence penetrated the teams. This directly parallels the Inspector-as-Sensor Trap, and in the Consortium the inspected party is a peer with a far stronger counterintelligence service. Sources: https://www.pbs.org/wgbh/pages/frontline/shows/unscom/etc/synopsis.html ; https://en.wikipedia.com/wiki/UNSCOM
- New START (US-Russia): even a mature treaty with a well-defined, countable object (deployed strategic launchers), decades of inspection practice and a purpose-built compliance commission saw on-site inspections stop in 2020 (initially attributed to COVID-19), Russia suspend participation in February 2023, and the treaty was due to expire in 2026. Post-expiry status is not verified. Verification regimes that depend on continuing mutual consent dissolve when politics change, and compute is far harder to count and far more fungible than missiles. Sources: https://www.armscontrol.org/act/2023-03/news/russia-suspends-new-start
- The plan itself concedes that it will not estimate total computing capacity, prove the absence of hidden facilities, verify workloads or inspect model weights. There is no directly comparable bilateral on-site compute-verification regime between rivals; the plan is dangerously unprecedented in its specific folly of treating change-logging at declared sites as a proxy for control.



### Premise Attack 5 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[STRATEGIC] — The Lamppost Ledger: By design, the Consortium verifies only the equipment changes that adversaries have already agreed to show, at sites they chose, on a schedule they control, so it will manufacture a flawless record of the one place the danger is not and let two rival governments read that record as safety.**

**Bottom Line:** REJECT: A jointly governed inspectorate that can only confirm what two adversaries chose to declare, cannot compel either of them to accept a finding, and will be sold as assurance it cannot provide has no right to exist. The gate is closed.


#### Reasons for Rejection

- It embeds the other side's permanent, full-time, mirrored inspectors, translators and technical staff inside each country's most sensitive compute facilities, and compels operators, vendors and site workers to submit to adversary scrutiny under domestic authority they cannot contest; the people carrying that burden never consented to being the verification surface of a geopolitical rivalry.
- Double-key authorization on budgets, protocol changes, site findings, sanctions and suspension, with no casting vote and no majority rule, means every adverse finding needs the consent of the party being found against; the plan itself names a government shielding its operator as a Stop condition, which concedes that the accountability structure has no mechanism to prevent the very failure it defines.
- The mission explicitly excludes total capacity, workloads, hidden facilities and foreign-hosted infrastructure, so the monitored perimeter is the cheapest part of the system to cheat around: a compliant ledger at declared sites coexists with unlimited undeclared build-out, and a USD 5 billion jointly held evidence apparatus, ledger copies, clean rooms and vendor channels becomes a single high-value espionage and sabotage target for both sides.
- The value proposition rots at the point of use: the plan's own caveat that success covers only monitored changes at participating declared sites will not survive contact with politicians, press and markets, and a 'Go' verdict will be consumed as assurance about frontier AI risk generally, converting a narrow bookkeeping tool into false comfort that discourages the harder controls it cannot replace.

#### Second-Order Effects

- T+0–6 months — The Cracks Appear: The mandatory entry conditions (signed instrument, appropriations, domestic access law, matched sites, approved inspectors, vendor participation, covered-equipment schedule) stall on the first asymmetry dispute, so the 90-day clock never starts; each side briefs that the other is stonewalling, and the first inspector approvals are contested as intelligence vetting.
- T+1–3 years — Copycats Arrive: If any exercise is declared a pass, other states and blocs demand equivalent matched-site mechanisms or claim exemption, while the declared-site model teaches both parties to route frontier build-out through undeclared, foreign-hosted or reclassified capacity that is outside the mandate by definition.
- T+5–10 years — Norms Degrade: 'Verified' becomes a diplomatic currency; unresolved discrepancies and 'unverifiable equipment' findings are traded as bargaining chips under double-key deadlock, and the inspectorate's access is quietly treated as a licence to collect intelligence on the host's security architecture, vendors and supply chain.
- T+10+ years — The Reckoning: A major undetected frontier capability emerges outside the monitored perimeter while the Consortium's ledgers show a spotless record, destroying the credibility of verification as a concept, leaving a hardened, institutionalized suspicion between the two states and no trusted instrument at the moment one is most needed.

#### Evidence

- Case/Report — New START inspections: The only comparable US–Russia on-site verification regime saw inspections suspended in March 2020 (pandemic) and then barred by Russia at its facilities in August 2022, followed by Russia's 'suspension' of participation in 2023; the treaty's scheduled expiry was in February 2026 (post-expiry status not verified). A mutual inspection regime between rivals survived only as long as the political climate did (https://www.armscontrol.org/act/2023-03/news/russia-suspends-new-start).
- Case/Report — DOJ 'Operation Gatekeeper' (Hao Global): The Justice Department announced in December 2025 the disruption of a network that moved roughly USD 160 million of Nvidia H100/H200 GPUs to China between October 2024 and May 2025, using straw purchasers, domestic warehouses, falsified export paperwork and fake-brand relabeling; about USD 50 million of chips were seized. This shows that equipment identity and paperwork can be forged at scale, and that diversion happens in the channels a declared-site ledger does not see (https://www.justice.gov/usao-sdtx/pr/us-authorities-shut-down-major-china-linked-ai-tech-smuggling-network).
- Case/Report — UNSCOM in Iraq (1990s): The UN weapons inspectorate was publicly accused by Iraq of espionage, and in 1999 press reports said US intelligence had used the inspection mission to collect information beyond its mandate; the episode shows that adversarial access to sensitive sites is inherently dual-use and ends in expulsion and delegitimization (details not re-verified).
- Principle/Analogue — Verification theory (arms control): A verification regime is only as meaningful as the share of the threat inside its observation boundary; a precisely bounded regime that is blind to undeclared activity gives high confidence in a small subset and creates a 'streetlight effect' that substitutes measurability for relevance.