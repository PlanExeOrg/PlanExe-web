### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] A double-key US–China body that verifies only declared equipment at a few matched declared sites cannot support the leaders' real concern, which is uncontrolled frontier AI. It would produce a credible-looking Go while the risk sits in undeclared capacity, workloads and weights that the plan excludes by design.**

**Bottom Line:** REJECT: A verification regime confined to declared equipment at hand-picked sites, with a veto on every finding and a pre-cleared 90-day test, would give both governments false assurance and leave unverified the capacity and weights where the risk actually is.


#### Reasons for Rejection

- The plan excludes total capacity, hidden facilities, workloads and model weights, so a clean ledger for a small matched set of declared datacenters says nothing about the compute that matters; a party that wants to cheat declares only what it is willing to show.
- Nine mandatory entry conditions must be met before the 90-day clock starts: signed treaty, appropriations, domestic access law, site selection, approved inspectors, vendor participation and a covered-equipment schedule. Those conditions contain every hard political fight, so the 90-day test measures only a pre-cooperating, hand-picked sample and its Go result is close to guaranteed.
- Double-key authorization with no casting vote applies to site findings, sanctions and suspension, so the side whose site is implicated can block the finding; a detection capability that the accused can veto produces records but no consequences.
- The USD 750M security and counterintelligence envelope shows the plan expects mirrored inspectors, ledger nodes and vendor-escorted clean rooms to become espionage channels; full-time foreign teams inside each country's frontier datacenters give each side standing access to its rival's supply chain and operators.
- Five Stop triggers are defined (asymmetric access, material unverifiable equipment, a government shielding an operator, unresolved ledger divergence, withheld funding). Given legal asymmetry between the two systems and vendors who can refuse, at least one is likely, so the USD 5B (USD 2.5B each, user constraint) buys either a failed test or a Go that is reported as more than the narrow scope supports.
- The plan assumes vendors, maintenance providers and logistics firms can be bound to reporting and evidence preservation by each government. The same equipment supply chains are currently subject to export-control and sanctions conflicts between the two states, so the participating vendors are the least neutral party in the design.

#### Second-Order Effects

- 0–6 months: Negotiating the nine entry conditions becomes the real contest; each side tries to shape the covered-equipment schedule and site list in its favour, and the Phase One clock may never start.
- 1–3 years: A Go limited to monitored changes at declared sites is cited by officials and the press as proof that frontier compute is under mutual control, which reduces pressure for broader verification while undeclared capacity grows.
- 5–10 years: A permanent bilateral body holding filtered records of each side's compute inventory, and with staff embedded at both sides' sites, becomes a political and intelligence target and a template that third countries cannot join, so it either hardens into a bilateral duopoly or collapses after the first disputed finding.

#### Evidence

- Case/Incident — Russia's halt to New START inspections (2022): after inspections were paused in 2020, Russia prohibited them in August 2022, showing that on-site access is the first thing a party withdraws once it is politically inconvenient.
- Case/Incident — OPCW challenge inspection mechanism (1997–present): the Chemical Weapons Convention's challenge inspection has never been invoked, showing that strong adversarial access rights go unused because accusing a rival is politically costly.
- Law/Standard — US BIS advanced computing and semiconductor export controls on China (2022): the US government restricts advanced computing items to China, which conflicts directly with the plan's assumption of cooperative vendor participation.



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[STRATEGIC] — The Lit Window Fallacy: a USD 5 billion (user constraint) program that verifies only declared equipment at a few matched sites certifies the one place nobody needs to hide anything, while the hidden capacity, workloads and model weights that make frontier AI a threat are excluded by design.**

**Bottom Line:** REJECT: The Lit Window Fallacy spends USD 5 billion (user constraint) to prove that declared equipment at volunteered sites changed as declared, and it leaves the threat that justifies the program outside the frame. A verification regime that cannot test the claim it will be cited for does not deserve to exist.


#### Reasons for Rejection

- Operators, vendors, maintenance crews and logistics firms are compelled by their own governments to host a rival state's inspectors and bind their suppliers, and the people who work there never consent to being a counterintelligence surface for either side.
- Double-key control with no casting vote means every site finding, sanction and suspension needs the signature of the government whose operator may be the one accused, and each government pays and manages its own operators, so shielding a favored company costs nothing and no outside body can overrule it.
- A Phase One pass would be advertised as proof of safety, and other states and companies would copy the template of monitoring only what is declared, so the declaration line becomes the accepted place to hide capacity and the public claim cannot be taken back.
- The money buys assurance about changes in a small, matched, volunteered set of sites while explicitly ruling out total capacity, hidden facilities, workloads, weights and foreign-hosted infrastructure, so it pays for confidence in exactly the part that was never in doubt.

#### Second-Order Effects

- **T+0–6 months — The Cracks Appear:** Both sides choose their most sanitized sites and most cooperative operators, and the matched set becomes a showroom whose clean results are read by politicians as evidence about the whole national stack.
- **T+1–3 years — Copycats Arrive:** Allies, rival states and large companies demand similar declared-site arrangements, which spreads a verification label that says nothing about undeclared compute.
- **T+3–5 years — The Quiet Migration:** Frontier-relevant buildout shifts to undeclared locations and foreign-hosted capacity that the mandate cannot touch, and the monitored sites become a decoy that draws all scrutiny.
- **T+10+ years — The Reckoning:** When a hidden-capacity breakthrough surfaces, the record of years of clean ledgers becomes the evidence that the arrangement gave false comfort and blocked a harder, more honest accounting.

#### Evidence

- Case/Report — New START on-site inspections were paused by both sides in March 2020 because of COVID-19, Russia then unilaterally stopped cooperating with the inspection provisions in August 2022, and Putin announced a suspension of participation in February 2023 (Arms Control Association reporting). Even a mature, treaty-based, two-party inspection regime collapsed once one government decided access was no longer in its interest.
- Case/Report — The US–China intergovernmental AI dialogue opened in Geneva in May 2024, and in November 2024 Biden and Xi agreed only that humans, not AI, should control decisions on nuclear weapons use. After years of talks, the highest-level agreement reached was a narrow statement of principle, with no verification mechanism and no stated plan for further action.
- Law/Standard — IAEA comprehensive safeguards (INFCIRC/153 model) are built on a state declaration plus verification, and they needed a separate Additional Protocol to address undeclared activity. Declared-material verification alone was understood to be insufficient, and this plan deliberately excludes that second layer.
- Narrative — Front-Page Test: 'US and China certify their AI datacenters clean' runs on Monday. On Friday, reporting shows that frontier training happened at undeclared sites outside the mechanism's scope, and the certification becomes the headline.



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] A $5 billion inspectorate that audits only declared equipment at matched sites certifies the one thing a rival would never hide, while buying cover for everything it cannot see.**

**Bottom Line:** REJECT: A $5 billion, veto-bound inspection of declared boxes at a few matched sites cannot detect the evasion that matters, so it should not exist.


#### Reasons for Rejection

- Utility: USD 5 billion (USD 2.5 billion per country) buys verification of only declared equipment at a small matched set of sites, while total capacity, workloads, hidden facilities and foreign-hosted infrastructure are expressly excluded, so a cheater loses nothing by passing.
- Feasibility: the 90-day test starts only after treaty signature, twin appropriations, domestic access law, site selection, inspector approval, vendor participation and a covered-equipment schedule are all complete, so the real political fight sits outside the test and its outcome is mostly decided before it begins.
- Governance: double-key control over budgets, protocol changes, site findings, sanctions and suspension, with no casting vote, lets either government veto any finding against itself, so the body can record discrepancies but cannot ever convict anyone.
- Security: placing a rival state's full-time mirrored inspectors, ledger systems and translators inside frontier datacenters, guarded by USD 750 million for facilities, cybersecurity and counterintelligence, creates a permanent espionage channel into the very leaders' assets the plan claims they fear losing.
- Legitimacy: the covered schedule is deliberately not anchored to any manufacturer, product or performance unit and the rule is that no single evidence source is decisive, so the definition of what counts as frontier-relevant is permanently contestable and a clean ledger will be read as proof of safety that it cannot provide.

#### Second-Order Effects

- 0–6 months: The entry conditions (bilateral instrument, appropriations, domestic access authority, inspector approval, vendor participation) consume the political bandwidth, and each government's security services fight over which sites and inspectors qualify, so the Month 0 (2026-10-08) start produces negotiation rather than inspection.
- 1–3 years: Even if the Phase One test begins, a clean result on declared equipment at matched sites is cited by both capitals as evidence that frontier AI is under control, and pressure to fund further oversight of undeclared capacity, workloads and hidden facilities fades.
- 5–10 years: Frontier compute moves into undeclared, foreign-hosted or newly redefined hardware categories outside the monitored boundary, and the Consortium is left as an expensive record of compliance that cannot detect the change, collapsing when one side invokes a veto or suspends access over an espionage incident.

#### Evidence

- Case/Incident — New START on-site inspections (2020–2023): inspections paused in March 2020 and then not resumed. Russia suspended its participation in the treaty in February 2023, showing that rival-state inspection access is revoked when relations sour.
- Case/Incident — Open Skies Treaty withdrawals (2020–2021): the US withdrawal took effect in November 2020 and Russia's was complete in December 2021, after mutual accusations of restricted access. A reciprocal access regime was dismantled by compliance disputes.
- Case/Incident — UNSCOM Iraq inspections (1991–1998): US intelligence reportedly used the inspection teams to collect signals intelligence, which damaged the inspectors' credibility and shows how an inspectorate becomes an espionage channel.



### Premise Attack 4 — Cascade
_Tracks second/third-order effects and copycat propagation._

**This is a Strategic Flaw: the plan puts a tightly bounded, honest-actor audit of declared racks at declared sites at the centre of a rivalry whose real risk sits in undeclared capacity, workloads and weights, which are all excluded from scope. It then wraps that audit in a veto-everything governance structure and a 90-day test whose clock starts only after the hard part (the political, legal and vendor groundwork) is done. A "Go" would certify only that compliant parties behave compliantly, and would be read as much more than that.**

**Bottom Line:** Abandon the premise: verifying declared-equipment changes at a few matched sites cannot answer the question that makes leaders fear frontier AI (where the compute is and what it is doing). It does this inside a governance design in which any party can veto findings about itself. Better implementation cannot fix that, because the premise itself produces false assurance.


#### Reasons for Rejection

- The Lamppost Ledger: The mechanism verifies only declared equipment at declared, matched sites. It excludes hidden facilities, total capacity, workloads and foreign-hosted infrastructure. A party intent on cheating simply keeps frontier-relevant compute outside the lit area. 'Credible detection' therefore measures only how well the Consortium catches mistakes by parties who already comply. The plan's own caveat ('success covers only monitored changes') will be dropped in every political summary, and a Go will be sold as arms-control assurance it cannot give.
- The Pre-Dawn Clock: Treaty signature, appropriations, domestic access law, site selection, inspector approval, operator and vendor participation, and the covered-equipment schedule are all declared 'entry conditions' outside the 90 days. Those items are the whole difficulty of the project. The 90-day test therefore exercises only the easy remainder, and the plan states no duration or failure mode for the gate. 'Start ASAP' describes only a bureaucratic act at Month 0 (2026-10-08). Operationally nothing starts until every entry condition is met, and any one of them can stall indefinitely.
- The Mutual Veto Lock: Double-key authorization covers budgets, protocol changes, site findings, sanctions and suspension, with no casting vote and no majority override. The country whose site is accused can therefore block the finding about its own site. The deadlock procedure, impaired-confidence status and automatic suspension are the only exits, so the default outcome of every serious discrepancy is suspension or paralysis. Either side can trigger suspension at will, and neither can be compelled to resolve a finding. The same rule means an inconvenient finding never has to become official.
- The Inspector-as-Intelligence-Collector Paradox: Serial numbers, arrival cadence, maintenance cycles, spare inventories and shipment records are themselves strategic intelligence about each side's compute supply chain. Full-time mirrored teams inside rival datacenters, plus two synchronized national ledger copies, create exactly the flow the security envelope exists to prevent. Because the evidence is filtered, no one can check what was filtered out. Each side will suspect the other of over-collecting, and neither can disprove it. The USD 750 million counterintelligence envelope is spent defending against the plan's own design.
- The Parity Mirage: 'Reciprocal-access parity' is the central Go/Stop criterion, yet matched sites are not equivalent. US sites are privately operated and legally constrained, while Chinese sites operate under state direction, and the vendors, export-control exposure and hardware supply chains differ. Any parity metric rests on arbitrary equivalence choices that the parties will contest. Cryptographic attestation depends on vendor-held roots of trust that sit outside the Consortium, and a refusing vendor leaves equipment 'unverifiable', which fails a site. The Consortium is thus hostage to the third parties it cannot compel.
- The Sunk Vault: A fixed USD 5 billion (user constraint), split into arbitrary envelopes, is committed against a 'small' site set and a 90-day test. These are the capital costs of a permanent institution, and no cost-per-site or per-inspector basis is given (estimate: unvalidated). After spending that much, a Stop verdict is politically costly, which biases decisions toward Modify forever. Most Stop triggers (withheld funding, a government shielding an operator) can also be produced by either side at will.

#### Second-Order Effects

- Months 0-18 (2026-10-08 to 2028-04-08): Negotiation of the entry conditions absorbs the programme. Each country's legal and security agencies fight over what 'domestic access authority' means. The Phase One clock never starts, but money is already being pledged and early hiring begins. Sites are chosen by haggling over equivalence, not by technical suitability.
- Months 18-36 (2028-04-08 to 2029-10-08) (if the gate is eventually cleared): Inspectorate deployment starts. Each side privately concludes the other's inspectors are collecting more than the declared scope. Information barriers harden and evidence filtering increases, so equipment-identity confidence falls and the unverifiable-equipment count rises. Several vendors refuse or condition participation on their own governments' export-control positions (not verified in detail).
- Months 36-48 (2029-10-08 to 2030-10-08): The 90-day test runs and is scored by an inherently contested instrument. Blind-challenge detection looks good because the challenges were designed within the bounded zones. Parity is disputed, because 'matched' is a negotiated fiction. Any finding against a site hits the double-key deadlock, and unresolved discrepancy age becomes the dominant KPI.
- Months 48-72 (2030-10-08 to 2032-10-08): The verdict is Modify, extended repeatedly. A Go is unattainable under strict reading, and a Stop is unthinkable once USD 5 billion is spent. The Consortium becomes a permanent institution whose existence is read as assurance. Meanwhile frontier compute grows in undeclared or foreign-hosted facilities that nobody is permitted to look at.
- Years 6-10 (Months 72-120 = 2032-10-08 to 2036-10-08): The first serious allegation, such as a cluster outside the declared sites, finds the Consortium formally blind to it. Its clean record is cited by both governments as evidence of compliance, or by each as proof of the other's bad faith. Either way it gives false comfort exactly when scepticism was needed, and the mechanism's credibility collapses with its first real test.

#### Evidence

- INF Treaty, Votkinsk portal monitoring: The closest precedent is the most favourable one. The treaty entered into force on 1 June 1988, and US inspectors (a first team of 24, arriving 2 July) were stationed at the Votkinsk missile plant to monitor portals and the perimeter around the clock, with X-ray of the canisters leaving the plant. It worked because the objects were large, discrete and countable, the treaty was ratified law, the site was singular and the question was binary (an SS-20 hidden in an SS-25 canister). Accelerator chips are small, fungible and moved in huge numbers through maintenance and spares, and have no such physical signature. That is a much harder problem than the one Votkinsk solved. Source: Federation of American Scientists INF Treaty history (nuke.fas.org/control/inf/infbook/ch5.html).
- New START inspections: On-site inspections were paused by both sides in March 2020 (COVID-19). Russia then unilaterally suspended its cooperation with the inspection provisions in August 2022, and by early 2023 the US was accusing Russia of endangering the treaty because inspections had not resumed. Even a ratified treaty with a standing bilateral commission lost its inspection leg once political conditions changed. This mechanism has no such treaty basis for the equivalent control and rests on a more hostile relationship. Status after 2023 is not verified.
- Neither precedent involved dual-use, privately operated commercial compute, vendor-held cryptographic roots of trust, or a requirement that two adversaries co-govern evidence systems with double-key authority over their own findings. No direct precedent exists for a jointly governed US-China verification body of this type, so the plan is dangerously unprecedented in its specific folly.



### Premise Attack 5 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[STRATEGIC] — The Verified Island Fallacy: a US–China inspectorate certifying only declared equipment changes at a few matched sites delivers a precise answer to a question that no longer matters, because the rivals' dangerous compute stays outside the boundary, while the inspectors themselves become the most intimate intelligence-collection channel either side has ever built.**

**Bottom Line:** REJECT: A jointly vetoed inspectorate that can certify only declared changes at a handful of matched sites creates false assurance and a shared intelligence-exposure surface, and a clean result would prove nothing about the threat it was built for; the gate is closed.


#### Reasons for Rejection

- Rights and dignity: the plan puts full-time foreign inspectors, mirrored national teams and a bounded-zone regime inside private operators' and vendors' facilities by compulsion, so companies, engineers and escorts become instruments of state access with no meaningful consent, no independent recourse and no protection for staff who are leaned on to cooperate.
- Accountability and oversight: double-key authorization for every budget, protocol change, finding and sanction means each government holds a permanent veto, so the body can never impose a finding on a protected operator, and automatic-suspension and impaired-confidence rules turn the first hard case into a political dispute rather than a verdict.
- Systemic risk at scale: a ledger of arrivals, removals and maintenance at matched sites is a precise map of each side's frontier-hardware supply chain, vendors, logistics and refresh cadence, so the instrument that is meant to reduce risk concentrates the most sensitive counterintelligence target in one jointly accessible system and gives both sides a standing motive to compromise it.
- Value-proposition rot: the explicit exclusions (no total-capacity estimate, no hidden-facility assurance, no workload or weight checks, no foreign-hosted infrastructure) mean a clean Go verdict proves almost nothing about frontier AI risk, yet it will be read as reassurance, so the program sells a feeling of control that its own design disclaims, while the $5 billion (user constraint) and 90-day clock lend it an air of rigor that the boundary does not support.

#### Second-Order Effects

- T+0–6 months — The Cracks Appear: the entry conditions (signed instrument, enacted access law, selected sites, approved inspectors, vendor buy-in) are themselves the unresolvable negotiation; each is held hostage to the others, and the first disputed site selection or inspector approval is read at home as a concession, so the pre-clock phase stalls while the program's budget is already committed.
- T+1–3 years — Copycats Arrive: once a matched-site model exists, other states and blocs demand their own sites and inspectors, and both founding powers learn that choosing which sites are declared is the real lever, so declared datacenters become showcase facilities while frontier-relevant expansion migrates to undeclared locations the mandate cannot see.
- T+5–10 years — Norms Degrade: officials treat 'no unverifiable changes at declared sites' as a clean bill of health, funding and political attention for broader oversight shrinks, and each side's inspectors, trained for years on the other's supply chain, become a standing talent pool for both national intelligence services.
- T+10+ years — The Reckoning: a major undetected capability surge or ledger compromise emerges from outside the monitored boundary, both governments disown the mechanism's limited scope, the shielded-operator and divergent-ledger stop conditions have already been triggered and quietly waived, and the collapse leaves mutual suspicion deeper than before and the precedent of verification discredited.

#### Evidence

- Case/Report — New START (US–Russia): on-site inspections were suspended in March 2020 for the pandemic, Russia then barred US inspections in August 2022 and invoked reciprocal-access grievances, and Russia suspended participation in February 2023; a treaty with decades of verification practice failed once political trust failed. Source: https://www.armscontrol.org/act/2023-03/news/russia-suspends-new-start
- Case/Report — UNSCOM (Iraq): inspectors were withdrawn in December 1998 amid Iraqi charges that the commission served as cover for US espionage; the Washington Post reported in 1999 that UN arms inspectors helped collect eavesdropping intelligence used against the Iraqi government, which shows how an inspectorate becomes an intelligence channel and collapses once that is known. Source: https://www.globalsecurity.org/wmd/library/news/iraq/1999/990308-unscom.htm (secondary summaries; detailed attribution not fully verified)
- Principle/Analogue — Arms-control verification theory: a regime can only verify what is inside its declared baseline, and without detection of undeclared activity (which this plan explicitly excludes) the value of compliance at declared sites is capped and invites displacement of activity outside the boundary.
- Principle/Analogue — Game theory and the security dilemma: when two rivals hold mutual vetoes over every finding and sanction, the equilibrium is to protect your own operator and accuse the other's, so the mechanism converges on deadlock exactly when a violation matters.