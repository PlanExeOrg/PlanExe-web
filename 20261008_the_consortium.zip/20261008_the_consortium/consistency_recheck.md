_Consistency: first pass found 3 high / 6 medium / 0 low contradictions. Repair: round 1: 33 edits → 2 high / 5 medium; round 2: 33 edits → 1 high / 4 medium; round 3: 17 edits → 0 high / 4 medium. Published: round 3 (fewest high-severity issues). Shown below: the final check of the repaired documents (0 high / 4 medium / 1 low)._

## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Is the bilateral instrument signed by both governments with deadlock, suspension, double-key and the mechanical verdict rule (including how intervals are treated) locked? | Signed by Month 1; no casting vote; deadlock clocks (panel by day 10, partial suspension day 14, impaired confidence day 21/28); Go needs at least 4 of 5 criteria including detection and parity, and a straddling interval means Modify. Any gate slipping over 2 weeks triggers a summit within 5 days. | Co-signed instrument text and an unclassified copy of the scoring rule, checked at Month 1 (Month 0.5 for the escalation roadmap). | DELAY: emergency summit within 5 days. Without a mechanical verdict rule, do not release tranche 1. If the signature is still missing by the funding Stop window (30 days), stop. Settle first how the Go test treats intervals, because as written it is nearly unreachable. |
| 2 | Are both appropriations and domestic access authority enacted, with equal first-tranche deposits? | USD 625M per country (25%) deposited at Month 2, equal on both sides; access authority enacted; tranche delay of 14 days or less. A delay over 14 days goes to co-chair escalation, and over 30 days or unresolved unequal deposits is a Stop trigger. | Treasury deposit records and the enacted statutes or equivalent, at Month 2. Written finance-committee concurrence beforehand (Month 1.5). | DELAY and escalate at 14 days. STOP at 30 days or if the deposits stay unequal (withheld funding). Resolve how Months 0-2 are financed before tranche 1 arrives. |
| 3 | Are 3 matched pairs (minimum 2) approved, with parity defined and operator Statements of Cooperation signed? | Each pair meets the functional-equivalence criteria (at least 500 sq m staging, 24-hour access, at least 50-ton lift, at least 2 maintenance events per month, all proposed). Staging access within 4 hours of request. 48-hour window notice. Parity definition and aggregation rule locked. Operators signed. Approval at Month 3. | Co-chair certification of the reciprocal-access audit, signed Statements of Cooperation, locked parity definition and dry-run access timings, by Month 3 (dry-run confirmation Months 4.5-5). | DOWNSIZE: exclude the asymmetric pair and fall back to 2 pairs (4 sites) at 4 exercises per site per month (48 total). Below 2 pairs, or if shielding is found, STOP. |
| 4 | Is the neutral facility certified and is the ledger, key custody and recovery chain proven? | Facility of at least 1,000 sq m operational and hardened by Month 3; first dual-share key ceremony Month 4; recovery rehearsal Month 5 with key loss recovered within the estimated 24 hours; 1-hour digest exchange with 30-minute overdue alert; mismatch escalated within 4 hours; reconciliation target 72 hours. | Host-country MOU (Month 1.5), hardening certificate (Month 3), ceremony and rehearsal records, ledger divergence drill results (Months 4-5). | DELAY then DOWNSIZE: switch to the pre-staged backup host. If no certified facility exists by Month 5.5, re-scope or stop. Gate slips over 2 weeks escalate to a summit. |
| 5 | Is the pre-clock calibration passed and the entry gate certified? | Evidence rule: false positives 7-13%, false negatives under 5% on a 100-200-event historical cohort (second cohort if deviation over 5 points). Pilot of all 7 event types done. At least 80% of staff certified by Month 5 and at least 6 positions per shift on at least 2 pairs. Unverifiable or excluded equipment at most 5% (over 10% at a site or overall is a Stop). Thresholds locked at Month 5.5. | Calibration Confidence Memo, pilot report, certification roster, vendor-participation registry and unverifiable-share calculation, all at Month 5.5. | DELAY or MODIFY SCOPE: a failed second cohort or staffing shortfall postpones the clock start under the gate-slip rules. Unverifiable equipment over 10% at a site or overall means re-scope or STOP. Fix the last viable start date, since the Month 9 backstop leaves no test. |
| 6 | Does the 90-day test score Go, Modify or Stop against the locked thresholds? | 54 exercises (48 at 2 pairs) with at least 6 per event type. Detection at least 70% (planned class) and 50% (unplanned class), false positives at most 10%, unverifiable at most 5%, parity at least 85%, no discrepancy over 21 days, fewer than 5 open material cases, no hard Stop trigger. Go needs at least 4 of 5 including detection and parity. Modify is 3 of 5 or correctable weaknesses. Stop is 2 or fewer or any hard Stop. | Independent scoring of exercises, ledger and parity dashboards, scored within 5 days after Month 9. Final decision by Month 9.5. | A NO means Modify or Stop. Modify means rework or a later phase. Funding for it is OPEN, so tranche 4 use and the rework route must be decided before Month 8. Stop means shutdown, with success claimed only for monitored changes at participating declared sites. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: executive summary; review plan; self-audit
    canonical: verdict_logic = Go: at least 4 of 5 criteria incl. detection and parity, fewer than 5 open material discrepancies, no Stop trigger, intervals not straddling a threshold
    observed:  Success probability 50-60%; examples '70% ±15%' and pooled '[58-82%]'
HIGH CF-002  document: canonical_facts
    canonical: entry_slip_backstop = Entry gate not certified by Month 9 (2027-07-08): formal Stop/re-scope decision
    observed:  Phase One compressed from 90 to 50-60 days; 4-week re-scope backstop
HIGH CF-003  document: review plan
    canonical: entry_slip_backstop = emergency co-chair summit within 5 days
    observed:  summit within 48 hours; external authority with binding scope-reduction power; neutral chair votes
HIGH CF-004  document: premortem FM3; self-audit item 20
    canonical: hard_stop_triggers = Stop if access asymmetric (user constraint)
    observed:  Stop only if gap above 10% persists 30 days; substitute site within 48 hours
MEDIUM CF-005  document: review plan; premortem; self-audit
    canonical: tranche_structure = 20% (500M per country) on Go/Modify verdict (about Month 9.2-9.5)
    observed:  released on verdict publication, independent of rework; rework USD 250-400M
MEDIUM CF-006  document: canonical_facts
    canonical: tranche_structure = 25% on instrument signature and appropriation (Month 2)
    observed:  spending and compression-reserve authorization from Month 0-0.5
MEDIUM CF-007  document: self-audit; executive summary
    canonical: entry_gate_timeline = matched pairs approved Month 3 (2027-01-08)
    observed:  parity locked Month 4-5; Statements of Cooperation due Month 5.5
MEDIUM CF-008  document: executive summary; review plan; self-audit
    canonical: evidence_rule_calibration = 100-200 historical events per site; false positives 7-13%; false negatives under 5%; second cohort if deviation over 5 points
    observed:  synthetic cohorts 20-30 / 40-50 / 40-60; false negatives under 10%; 4-week re-test
MEDIUM CF-009  document: review plan Review 10.2
    canonical: schedule_freeze = frozen for the whole Phase One window; amendments only by double-key approval before the clock or at the final decision
    observed:  single-case re-classification within 10 days without double-key
MEDIUM CF-010  document: review plan
    canonical: compression_reserve_and_free_contingency = Reserve USD 50-100M for compressed negotiation and expedited vetting; free contingency USD 400-450M for slips
    observed:  legislative-delay cost drawn from the reserve; scope reduction funded from the reserve
LOW CF-011  document: review plan; self-audit
    canonical: personnel_cost_estimate = About USD 29M per month; ceiling about USD 274M for all 9.5 months
    observed:  USD 565M left for specialist units; translation USD 480k-720k annually
```

### 1. Go verdict nearly unreachable under the 'interval must not straddle' rule (🔴 High) — needs a project decision

- **Executive summary (Risks, Overall Takeaway); canonical verdict_logic:** Go requires intervals not straddling a threshold, per criterion at one confidence level (planned-class threshold 70%, interval about ±22%, n about 16).
- **Executive summary (Overall Takeaway); review plan Review 5.3, 9.1; self-audit item 8:** 'Success probability 50-60%'. Review and self-audit illustrate with '70% ±15% spanning 55-85%' and '70% pooled spans 58-82%'.
- **Why it conflicts:** A lower bound of at least 70% with ±22% needs a planned-class detection of about 92% or more (recomputed). The unplanned class (±25%) needs about 75% or more against a 50% threshold. The stated 70%/50% thresholds are therefore not the real Go bar, and almost every outcome becomes Modify. The 50-60% success estimate has no stated basis. The ±15% and pooled ±12% examples match neither the class-level intervals nor the thresholds they are applied to.
- **Suggested resolution:** Decide before the Month 1 instrument which statistic is compared with each threshold (point estimate, or a lower bound at a stated one-sided confidence level). Then state the effective Go detection levels. Alternatively re-set the class thresholds. Mark the success probability as (estimate) with its method, or remove it. Use the class-level intervals (±22% / ±25%) in all examples.

### 2. Entry-slip backstop: Month 9 deadline and 'compressed to 50-60 days' (🔴 High) — needs a project decision

- **Canonical entry_slip_backstop; project plan Time-bound; pitch Call to Action:** Phase One clock starts only after all gates are certified (Month 5.5 target), and runs 90 days (Months 6-9). If the entry gate is not certified by Month 9, a formal Stop/re-scope decision follows.
- **Executive summary (Risks); review plan Review 1.1, 2.3, 13.3; pitch Risks:** An 8-week slip 'compresses Phase One from 90 to 50-60 days' and widens the interval to ±18-22%. The pitch adds a '4-week re-scope backstop'.
- **Why it conflicts:** Month 9 is when the planned 90-day window ends, so a certification deadline there allows no test. Because the clock begins only after the gates, a slip delays the start. It does not shorten a fixed 90-day clock, and the plan elsewhere says a shortened clock cannot support Go. Losing 8 weeks from 90 days leaves about 34 days (recomputed), not 50-60. The '4-week re-scope backstop' is a third variant.
- **Suggested resolution:** Replace the Month 9 backstop with a last-viable-start date. This is the latest clock start that still fits a full 90 days plus the 5-day scoring inside the authorized and funded period. Past it, the decision is re-scope (2 pairs, 90 days, 48 exercises) or Stop. Restate slip effects as delayed start and cost, not a shorter clock, or drop the 50-60-day text. Remove the '4-week' variant.

### 3. External escalation authority with binding scope power vs double-key governance (🔴 High) — needs a project decision

- **User constraint; canonical entry_slip_backstop; executive summary:** Governance uses double-key authorization with no casting vote and no outcome that one country can impose. Emergency co-chair summit within 5 days of a gate slipping over 2 weeks.
- **Review plan Review 3.1, 12.2, 12.3, 15.2; executive summary Risks (scope-reduction power by Month 0.5):** A neutral third-country official (or deputies) convenes a summit within 48 hours and decides scope reduction within 5 days. A neutral panel chair 'votes' under a 'binding panel-decision protocol'. Authority is appointed by Month 0 or Month 0.5.
- **Why it conflicts:** A body that binds the scope of the program can overrule a co-chair, and a voting neutral chair acts as a casting vote. Scope reduction is a protocol and budget change that must be double-key. The 48-hour and 5-day variants differ. The authority is appointed before the Month 1 instrument that would grant its powers.
- **Suggested resolution:** Options: (a) the authority only convenes, monitors and reports, and scope reduction is a pre-agreed mechanical double-key rule in the instrument (for example, fall back to 2 pairs); (b) a delegated decision right granted by both co-chairs in advance and limited to that single pre-agreed fallback. Use the canonical 5-day summit. Keep the panel advisory, with a non-voting chair.

### 4. Mid-Phase-One access asymmetry: immediate Stop vs 30-day tolerance vs site substitution (🔴 High) — needs a project decision

- **User constraint / canonical hard_stop_triggers; review plan Review 4.2, 9.2; assumptions Risk 15:** Stop if access is asymmetric. Operator access restriction mid-test 'triggers a hard Stop'. 'Asymmetric resistance is the Stop trigger'.
- **Premortem FM3 stop rule and playbook; self-audit item 20:** Stop only if a pair's access or detection gap stays above 10% for 30 days. Response is to substitute a cooperative site or drop to 2 pairs. Substitute a site 'within 48 hours'.
- **Why it conflicts:** The documents disagree on whether a mid-test gap is an immediate Stop, a 30-day correctable weakness (Modify), or fixable by substitution. A substituted site would not have passed the pre-clock parity audit or Statements of Cooperation. It would change the matched set and exercise load (54 to 48 at 4 per site-month, or only 36 at 3). It would also reset the parity baseline of at least 85% / inspector-hour balance of at least 90%.
- **Suggested resolution:** Decide the rule and write it into the instrument: the asymmetry size and duration that make it a hard Stop (threshold and cure period). Say whether any cure period is allowed. Either forbid mid-clock substitution or define what substitution requires. Use one metric (parity at least 85% with its four indicators) in all documents.

### 5. Tranche 4: release condition and what it pays for (🟡 Medium) — needs a project decision

- **Canonical tranche_structure and hard_stop_triggers; review plan Review 5.3, 11.3:** 20% (USD 500M per country) released on Go/Modify verdict. Withholding funds by either country is a hard Stop trigger.
- **Review plan Review 11.3, 14.1; premortem A6/FM6; self-audit items 6, 15:** Tranche 4 is released 'on verdict publication (not pending rework scope agreement)', 'separating verdict from funding leverage'. Rework estimated at USD 250-400M, funding route OPEN.
- **Why it conflicts:** A release conditional on Go/Modify cannot also be independent of the outcome. After a Stop verdict it is not released, yet withholding is a funding Stop trigger. Nothing says what the combined USD 1B buys after the Month 9 clock ends. The USD 250-400M rework figure has no basis because rework funding is OPEN.
- **Suggested resolution:** Decide what tranche 4 funds (verdict scoring, closure, archive, rework or Phase Two). State its release condition for each of Go, Modify and Stop, and exempt the Stop case from the withheld-funding trigger. Label the 250-400M as (estimate) with its derivation, or remove it until the OPEN decision is made.

### 6. Spending from Month 0 vs first funds only at Month 2 (🟡 Medium) — needs a project decision

- **Canonical tranche_structure and entry_gate_timeline:** First tranche (25%, USD 625M per country) is paid on instrument signature and appropriation at Month 2.
- **Executive summary Action Orientation; review plan Review 11.2, 12.3, 14.3; self-audit items 6, 14:** Task force, Joint Budget Authority and legal team start at Month 0. Recruitment starts at Month 0 and vetting at Month 1. Neutral-facility site is chosen at Month 1 and operational by Month 3. The compression reserve is authorized by Month 0.5. Ramp-up cost of USD 60-80M (TBD) is incurred before Month 5.5.
- **Why it conflicts:** Costs and the reserve draw begin before any appropriated money is available. Contingency and the compression reserve come from the same tranches. No document says who finances Months 0-2.
- **Suggested resolution:** Decide the interim financing: a pre-instrument bridge appropriation, an advance from each government's own funds recorded against its USD 2.5B, or an earlier release of part of tranche 1. State that it maps to an envelope and stays 50/50.

### 7. Timing and bindingness of parity definition and operator commitments (🟡 Medium)

- **Review plan Review 8.3, 9.2; pitch Call to Action; self-audit item 3:** Parity definition, aggregation rule and signed Statements of Cooperation are locked before Month 3 matched-pair approval; Month 5.5 is a dry-run only. Binding operator agreements are in the instrument at Month 1.
- **Executive summary Feedback 5; self-audit items 10, 14, 16, 17, 18 (OKR charter Month 4); pitch Call to Action:** Parity defined by Month 4, or locked by Month 5. Statements of Cooperation due Month 5.5. Operator cost proposals Month 1.5 and ceiling Month 2. Whether commitments are binding is 'to be stated' in the instrument.
- **Why it conflicts:** Parity and operator cooperation cannot be confirmed for the Month 3 pair approval (which releases tranche 2) if they are defined or signed at Month 4-5.5. A Month 1 instrument cannot embed a compensation ceiling that is only set at Month 2. Commitments are called both binding and undecided. Without an aggregation rule the 85% criterion cannot be scored.
- **Suggested resolution:** Keep Month 3. Parity definition, aggregation rule and signed Statements of Cooperation come before pair approval, and later dates are for dry-run confirmation only. Move operator cost proposals and the ceiling before Month 3, or exclude the ceiling from the Month 1 instrument. State in the instrument that the commitments are binding with home-government enforcement.

### 8. Evidence-rule validation: cohort sizes, false-negative bar, re-test time and lock date (🟡 Medium)

- **Canonical evidence_rule_calibration and pre_clock_calibration:** Validation on 100-200 historical events per site; pilot false positives 7-13% and false negatives under 5%; second cohort if deviation exceeds 5 points, completed by Month 5.5; draft in escrow Month 4.5, locked Month 5.5.
- **Executive summary; premortem A2; review plan Review 8.2, 13.1; self-audit item 2:** Adversarial synthetic cohort is 20-30 per site (executive summary, premortem), 40-50 (review plan) or 40-60 (self-audit). False-negative bar is under 10% (executive summary, review 8.2). A failed validation means 'halt Phase One and run a second cohort (4-week delay accepted)'. The Month 4.5 escrow is called 'locked'; the Month 1 instrument 'locks evidence-weighting rules'.
- **Why it conflicts:** The cohort sizes differ with no statistical justification, and the pass criterion depends on cohort size. With 100-200 events at a 10% rate the 95% interval is about ±4-6 points (recomputed), wider than the ±3-point pass band. A 4-week re-test cannot fit between the Month 5 pilot and Month 5.5, so it delays the clock and triggers the gate-slip rules. A rule 'locked' at Month 4.5 cannot be adjusted at Months 5-5.5, and the rule content cannot be locked in the Month 1 instrument.
- **Suggested resolution:** Use the canonical false-negative bar (under 5%). Set one synthetic-cohort size with a stated justification. Describe Month 4.5 as draft escrow and Month 5.5 as the lock. Say that a failed second cohort delays certification and triggers the 2-week gate-slip rule. The Month 1 instrument locks the governance of the rule (escrow, versioning, no amendment after the lock), not its content.

### 9. Schedule-amendment exception bypasses double-key and the schedule freeze (🟡 Medium)

- **Canonical schedule_freeze; user constraint on double-key authorization for protocol changes:** Covered-equipment schedule is frozen for the whole Phase One window. Amendments need double-key approval, before the clock or at the final decision, and apply only to later events.
- **Review plan Review 10.2:** Negotiate a 'schedule amendment exception' clause allowing single-case re-classification of new equipment within 10 days 'without double-key deadlock'.
- **Why it conflicts:** A mid-clock re-classification without double-key breaks both the freeze and the rule that protocol changes need double-key. It would also let one country change what counts as covered equipment during the test.
- **Suggested resolution:** Delete the exception. Handle new generations by a pre-clock double-key amendment (by Month 5.5) or as an unscheduled-equipment finding that does not change the schedule version. Re-classification then waits for the final-decision amendment window.

### 10. Compression reserve vs free contingency; slip cost inconsistencies (🟡 Medium)

- **Canonical compression_reserve_and_free_contingency, entry_delay_cost_fit; executive summary; review plan Review 6.3; premortem FM1, FM4:** Compression reserve (USD 50-100M) is for compressed entry negotiation and expedited vetting only. Slip costs (8-week slip USD 100-200M) and facility slips come from the free contingency (USD 400-450M).
- **Review plan Review 10.1, 12.3, 4.1:** A 4-6 week legislative delay 'consumes USD 50-100M of the compression reserve'. Scope reduction is 'funded from compression reserve'. A 4-week facility slip costs USD 30-50M, against USD 100-200M for an 8-week gate slip.
- **Why it conflicts:** The same slip cost is charged to two different pots in different documents. A 4-week facility slip at 30-50M does not scale to the 100-200M estimate for 8 weeks, and the 5-10M re-certification figure is not tied to either.
- **Suggested resolution:** Charge slip costs (legislative, facility, gate) to the free contingency. Restrict the reserve to negotiation and vetting acceleration, and fund scope-reduction planning from it only if defined as negotiation. Align the 4-week facility cost with the 8-week estimate (proportional range) or label it as a separate (estimate).

### 11. Adjudication surge: headcount, cost and funding source (🟡 Medium) — needs a project decision

- **Review plan Review 3.3; executive summary Risks and Feedback 4 ('8-12 specialists, dual-country'):** Surge unit of 8-12 specialists per country, total USD 2-3M, funded from the 750M personnel envelope; adjudication base is 5 per country.
- **Review plan Review 6.3; premortem FM2; review plan Review 14.3 (draw source unclear):** The adjudication surge is funded 'from free contingency'. Surge must absorb 25-40 cases per month against 30-50 expected and 15 planned.
- **Why it conflicts:** 16-24 specialists in total at about USD 80k per person-month cost about USD 1.3-1.9M per month (recomputed). USD 2-3M therefore covers only 1-2 months, not Month 4 to Month 9.5. The unit is 1.6-2.4 times the base unit. The per-country vs total reading is ambiguous. The funding source differs (personnel envelope vs free contingency), and the 36-person surge pool may already cover it.
- **Suggested resolution:** Decide the source (surge pool within the personnel envelope or a free-contingency draw with a pre-authorized limit). Recompute the cost for the stated headcount and duration, and state whether the headcount is per country or total. Pre-authorize the limit in the instrument.

### 12. Personnel and translation cost arithmetic (⚪ Low)

- **Canonical personnel_cost_estimate and staffing_per_country:** About 360 staff, including 45 specialist-unit staff per country, cost about USD 29M per month. Ceiling about USD 274M for 9.5 months at full strength. USD 80k is per person-month.
- **Review plan Review 11.2, 15.3; self-audit item 12:** After about USD 185M personnel spend, 'USD 565M remains for all other personnel roles (specialist units, adjudication, CI, legal, translation)'. Translation 6 FTE cost 'USD 480k-720k annually' in the justification, but 'USD 480k per month, about USD 5.8M annually' in the mitigation. '360 deployed inspectors'.
- **Why it conflicts:** Specialist units are already in the 360-person cost, so counting them again against the remaining 565M double-counts them. 6 FTE at USD 80k per person-month is about USD 480k per month, about 5.8M per year (recomputed), not 480-720k per year. Only about 198 of the 360 are inspection corps, not 360 inspectors.
- **Suggested resolution:** Use the canonical staffing and cost figures. Describe the 750M as covering the 360 staff plus training, translation, retention and surge. Say what the roughly 475M above the 274M ceiling is reserved for, or flag it for rebalancing. Use the 5.8M per year translation figure throughout, and say 'staff' rather than 'inspectors' when referring to the 360.

## Summary

The plan is largely aligned with the canonical facts. Budget envelopes, the tranche structure, staffing counts, the entry-gate timeline and the 54/48-exercise loads are mostly consistent, and most previously reported errors are fixed. Several problems remain that change the economics or the go/no-go logic. The Go rule is nearly unreachable at the stated interval widths. The Month 9 "deadline" and the "compress to 50-60 days" logic conflict with a 90-day clock that starts only after the gates. An external escalation authority with binding scope power conflicts with double-key governance. A mid-test access gap is treated three different ways. Tranche 4 has no stated purpose after Stop. No funding exists for Months 0-2, although spending starts then. The remaining items are timing and number mismatches in the reviews and the self-audit, which can be fixed by aligning them to the canonical facts.