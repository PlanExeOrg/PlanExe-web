_Consistency: first pass found 3 high / 6 medium / 0 low contradictions. Repair: round 1: 62 edits → 3 high / 3 medium; round 2: 36 edits → 1 high / 4 medium; round 3: 21 edits → 1 high / 3 medium. Published: round 3 (fewest high-severity issues). Shown below: the final check of the repaired documents (1 high / 3 medium / 0 low)._

## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Are the bilateral instrument signed and the 4 matched sites ratified by both co-chairs, with the strict gate and the Month 9 extend-or-stop backstop written into the instrument? | Instrument signed and sites ratified (sealed double-key draw, at least 1 deliberately hard site per country) by Month 2. Written decomposition of each country's domestic acts exists. No critical-path item is more than 4 weeks behind baseline. | Signed instrument and co-chair ratification record at Month 2. Weekly entry-conditions dashboard. Written domestic-act decompositions from Month 0.5. | DELAY. The clock cannot start. Each month of slip costs USD 50-100M (estimate), charged to contingency. A slip of more than 4 weeks goes to co-chair double-key review. If certification is not reached by Month 9, co-chairs decide by double-key to extend or stop. No partial or per-site start. |
| 2 | Has each government funded its USD 2.5B tranche within 45 days of fiscal-year start plus the 30-day cure, and are the covered-equipment schedule adopted and domestic access authority enacted? | Tranche paid within 75 days (45 + 30). Appropriations and schedule adopted by Month 3. Access authority enacted by Month 3.5. Budget variance of 5% or less in Months 0-3. The reference date for 'fiscal-year start' must be fixed for each country first. | Treasury confirmations, enacted statute or directive, and the adopted schedule record, all by Month 3.5. Monthly fiscal accountability reports. | DELAY if the cure period is still running. STOP if either tranche is unpaid at day 75, because that counts as funding withheld. If access authority is missing at Month 3.5, escalate to co-chairs (delay path toward the Month 9 backstop). |
| 3 | Are operator and Tier-1 vendor binding agreements signed, examiner and clean-room fallbacks contracted, and the ledger stress-tested on non-covered equipment? | Operator agreements signed 4 of 4. Top 8-12 vendors per site bound. 3-5 examiner labs per country and 2 clean-room facilities per geography under signed agreements. Examiner quotes at or below USD 75k per exam (proposed threshold), with capacity of 5 exams per week (estimate). Ledger divergence detected within 2 hours and forensic findings within 48 hours, by Month 4. | Signed agreements and MOUs at Month 4. Stress-test report. LOI rate (80% at Month 1) is an early-warning indicator only. | DELAY and replace a site from the shortlist, which takes 4-8 weeks and about USD 50-200M (estimate), before the clock starts. Do not run Phase One with unbound Tier-1 vendors. Repeated failure points to Modify or Stop in the Month 9 backstop review. |
| 4 | Are all deployed inspectors counterintelligence-approved, with all critical posts filled and at least 80% of the planned roster filled? | All deployed inspectors approved. At least 80% of the planned roster (about 217 per country) filled. All critical posts filled. Vacancies filled only from the pre-approved bench. | Vetting completion report at Month 5. Roster fill and bench reports. | DELAY the clock. Gate certification is blocked. Holding cost of USD 50-100M per month (estimate) applies. No reduction of site count (this would break the matched 2+2 pairing and the strict gate). Escalate through the Month 9 backstop. |
| 5 | Are thresholds double-key locked after calibration, and are all 7 entry conditions certified so the 90-day clock can start? | Calibration (Months 4-5, 50-100 events per site, 100-150 reserved non-covered units per site) is complete. Thresholds are locked by Month 5.5. Divergence of more than 20% from provisional targets is resolved by recorded protocol change. All 7 conditions are certified by Month 6. | Calibration report with detection rates by event type. Double-key signed threshold document at Month 5.5. Certification record at Month 6. | DELAY. Recalibrate by recorded protocol change before the clock, without starting the 90 days. Otherwise apply the Month 9 double-key extend-or-stop backstop. Calibration data is excluded from the Go evidence base. |
| 6 | Do Phase One exercises demonstrate reciprocal access and credible detection against the locked thresholds? | Detection of at least 90% for unreported arrivals, 85% for substitutions and 80% for record falsification (provisional). False positives below 5%. Parity within 20%. Unresolved discrepancies below 10% of events. Unverifiable equipment below 5% per site. Zero unresolved ledger divergence beyond 7 days. Zero material asymmetric-access or IP/CI incidents. | Independent testing unit scoring of the 24 sessions across Months 6-9. Ledger and KPI dashboard. Double-key decision at Month 10. | MODIFY if a correctable weakness remains (detection 70% up to target, or unverifiable 5-10%). STOP if access is asymmetric and unresolved, unverifiable equipment exceeds 10% at a site, a government shields an operator, evidence divergence is unresolved, funding is withheld, or detection is below 70%. Success covers only monitored changes at participating declared sites. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: review_plan (Review 2, Review 10) and exec summary
    canonical: contingency_worst_case_exposure_usd = About USD 515M, exceeding the USD 500M contingency by about 15M
    observed:  Supplemental funding USD 25–50M / supplemental appropriation request
HIGH CF-002  document: canonical_facts / premortem FM7 / self-audit 6
    canonical: funding_timeliness = 45 days of fiscal-year start + 30-day cure (75 days)
    observed:  'day 75 after fiscal-year start' with no defined date
HIGH CF-003  document: review_plan (Review 1, 4) and self-audit 20
    canonical: final_decision_timing = Go/Modify/Stop decision at Month 10; backstop extend-or-stop at Month 9
    observed:  6-month pause clause; 2-week exercise pause with 'no impact to 90-day window'; extension
HIGH CF-004  document: self_audit and review_plan (Reviews 5, 7, 13); premortem A2
    canonical: entry_conditions_milestones = Instrument and sites Month 2; binding agreements Month 4
    observed:  Instrument terms locked Month 1; vendor agreements Month 0.5; 4 sites locked Month 2.5; LOI 80% at Month 1.5; 60% receptive
MEDIUM CF-005  document: self_audit item 4
    canonical: modify_and_stop_rules = Modify: unverifiable 5-10%; Stop: unverifiable >10% at a site
    observed:  unverifiable-equipment >5% per site (Stop condition)
MEDIUM CF-006  document: review_plan (Review 4) and premortem FM2/FM5/FM6
    canonical: fallback_site_replacement = 4-8 weeks, about USD 50-200M
    observed:  within 2 weeks; standby alternate; reduce site count
MEDIUM CF-007  document: review_plan (Reviews 5, 8, 10)
    canonical: fallback_vendor_examiners_cost = Overrun about USD 3.6-11.2M over 4 sites
    observed:  USD 8-15M overrun; shortfall USD 8-19M
MEDIUM CF-008  document: canonical_facts
    canonical: deadlock_definition = Auto-suspension at 14 days of deadlock on contested identity
    observed:  Auto-suspension at 7 days of unresolved divergence
MEDIUM CF-009  document: review_plan (Review 6) and self_audit 11
    canonical: exercise_design_and_cap = At most 2 sessions per site per month; 24 across 4 sites; all 7 event types
    observed:  95% confidence intervals by event type
MEDIUM CF-010  document: pitch / exec summary / review_plan (Review 2, 14)
    canonical: appropriation_window = Appropriations held 18 months (through Month 18); USD 5.0B hard cap
    observed:  Phase Two over 24-36 months using existing envelopes
MEDIUM CF-011  document: project_plan Dependencies / review_plan
    canonical: entry_conditions_milestones = All inspectors approved Month 5; calibration Months 4-5
    observed:  Calibration with real inspectors before Month 5 approval
MEDIUM CF-012  document: review_plan (Reviews 6, 14) and premortem
    canonical: contingency_governance = USD 500M released only by double-key; fast lane up to USD 50M (25M per side)
    observed:  Triggers at USD 150M, 200M, 350M, 400M, 450M
```

### 1. Contingency shortfall under hard cap has no owner (🔴 High) — needs a project decision

- **Canonical facts; Exec Summary 'Timeline and Budget'; Project Plan:** USD 5.0B is a hard cap, exactly 50/50. Contingency is USD 500M, released only by double-key.
- **Exec Summary; Pitch; Review 2 item 2; Review 10 item 3; Self-audit 6:** Worst case is about USD 515M, exceeding the reserve by about USD 15M. Review 2 recommends 'supplemental funding (USD 25–50M)' or a supplemental appropriation request.
- **Why it conflicts:** Any supplement breaks the hard cap and the exact 50/50 split. The documents state the gap but do not say who covers it, from which envelope, or what is cut first.
- **Suggested resolution:** Decision needed. Options: (a) accept the gap as residual risk, with a pre-agreed scope-reduction order; (b) a double-key reallocation from another envelope, shared equally; (c) an explicit cap amendment. Remove the 'supplemental appropriation' language until one is chosen.

### 2. 75-day funding Stop clock has no reference date (🔴 High) — needs a project decision

- **Canonical funding_timeliness; Premortem FM7 ('day 75 after fiscal-year start'):** Tranche late beyond 45 days of fiscal-year start plus a 30-day cure (75 days) counts as funding withheld (Stop).
- **Exec Summary entry gates; Project Plan Dependencies; Review 10 item 1:** Appropriations are due at Month 3. Fiscal-year start is not defined for either country.
- **Why it conflicts:** If the US fiscal year began before Month 0, day 75 falls near Month 2, before the Month 3 appropriation milestone, so a Stop could fire before funds are expected. The China cycle differs. The trigger cannot be tested.
- **Suggested resolution:** Decision needed: define the reference date per country (for example, the date the appropriation is enacted or the tranche is scheduled). Align the 45+30 days with the Month 3 milestone. Do not leave 'fiscal-year start' undefined.

### 3. Month 10 decision vs fixed 90 days, extension, and pause clauses (🔴 High) — needs a project decision

- **Canonical; Exec Summary; Project Plan:** Phase One is exactly 90 days (Months 6-9). The Go/Modify/Stop decision is at Month 10. Strict gate, no conditional start.
- **Review 1; Review 4 items 1-3; Self-audit 20; Risk 24; Pitch:** A late start to the Month 9 backstop is costed as a 3-month slip with the Month 10 decision still intact. A 6-month pause clause (Review 4), a 2-week exercise pause 'with no impact to the 90-day window', and a scope pause after a sanctions change (Self-audit 20) are also proposed. Pitch: 'Phase One completes on schedule'.
- **Why it conflicts:** A fixed 90-day clock can be started later, not extended. No document gives the decision date after a late start, yet costs are computed as if the decision still happens. Pause clauses during a running clock sit outside the strict-gate design and are not in the canonical facts. The backstop date equals the planned end of Phase One.
- **Suggested resolution:** Decision needed: state that the decision date is clock start plus 90 days plus the decision interval, and cost the slip to that date. Either adopt a pause clause by recorded double-key protocol change, with its effect on the 90 days defined, or delete it.

### 4. Vendor, examiner, forensic and instrument dates precede their prerequisites (🔴 High)

- **Canonical entry_conditions_milestones and vendor_fallback_pool:** Instrument signed and sites ratified at Month 2. Binding agreements and examiner/clean-room MOUs due Month 4.
- **Self-audit items 4, 5, 14, 16, 17, 20; Review 5; Review 7 item 3; Review 13 items 2-3; Premortem A2:** Self-audit: evidence hierarchy 'codified in the bilateral instrument by Month 1', gate written into the instrument 'by Month 1', LOIs from 8-12 vendors per site by Month 1, 4 sites locked by Month 2.5, zoning checks at candidate sites by Month 0.5, LOI tripwire at Month 1.5. Review 7: 'vendor agreements' at Month 0.5. Review 13: pre-binding at Month 0.5, examiner MOUs by Month 1.5 'only after' binding at Month 4. Premortem A2: 60% receptive.
- **Why it conflicts:** Instrument terms cannot be locked before the instrument is signed (Month 2). Per-site vendor lists and walkthroughs need selected sites (Month 2). The LOI threshold is 80% at Month 1, 80% at Month 1.5 and 60% receptive. Examiner steps carry Month 1, 1.5 and 4 dates. Sites are 'locked' at Month 2.5 but ratified at Month 2.
- **Suggested resolution:** Keep canonical dates. Label Month 1 and Month 1.5 items as generic, draft, early-warning actions. Use a single LOI measure (80% of Tier-1 at Month 1, early-warning only). Bind instrument terms at Month 2 and agreements at Month 4. Site clearances are due by Month 2.

### 5. Unverifiable equipment >5% called a Stop condition (🟡 Medium)

- **Canonical modify_and_stop_rules; Review 1 item 2; Self-audit 17:** Unverifiable 5-10% is Modify; Stop only above 10% at a site.
- **Self-audit 4 (Underestimating Risks) justification:** Unverifiable equipment above 5% per site is described as a 'Stop condition'.
- **Why it conflicts:** It misstates the decision rule and would turn a Modify outcome into a Stop.
- **Suggested resolution:** Rewrite: above 5% = Modify-level weakness; above 10% at a site = Stop (site fails Phase One).

### 6. Replacement site timing and mid-test replacement or site reduction (🟡 Medium)

- **Canonical fallback_site_replacement; Exec Summary Feedback:** Replacing a failed or withdrawn site from the shortlist takes 4-8 weeks, about USD 50-200M. Strict gate; matched 2+2 sites; sealed draw.
- **Review 4 item 1; Premortem FM2, FM5, FM6; Risk 18:** Review 4: 'activate the alternate within 2 weeks' using a pre-vetted standby operator, and a replacement 'delays the clock start' after a Month 6 withdrawal. Premortem FM2/FM5 'replace' the site and FM6 'reduce site count' at Month 9.
- **Why it conflicts:** Two weeks conflicts with 4-8 weeks. A running clock cannot be delayed retroactively. A pre-picked standby bypasses the sealed draw. Fewer sites breaks the matched pairing and the strict gate.
- **Suggested resolution:** Use 4-8 weeks. Allow replacement only before clock start, from the drawn shortlist. A site loss after clock start is handled by the Modify/Stop rules, not a replacement or reduced site count.

### 7. Examiner overrun arithmetic and contingency effect (🟡 Medium)

- **Canonical; Exec Summary:** Examiner overrun is about USD 3.6-11.2M (already about USD 11M inside the USD 515M worst case). The shortfall is about USD 15M.
- **Review 5 item 2; Review 8 items 1 and 3; Review 10 item 3:** Overrun 'balloons to USD 8-15M' and the shortfall becomes 'about USD 8-19M' (against 512-519M). Review 5 says unaffordable examiners leave a shortfall of USD 8-19M.
- **Why it conflicts:** Recomputed: 504M + 8-15M = 512-519M, so the shortfall is 12-19M, not 8-19M. The overrun is already counted inside the 515M. An overrun alone (8-15M) cannot exhaust a 500M reserve.
- **Suggested resolution:** Restate as: worst case rises from about 515M to about 519M, shortfall about 15-19M (estimate). Do not present the overrun as an independent cause of the gap.

### 8. 7-day divergence suspension vs 14-day deadlock and Tier 3 clocks (🟡 Medium) — needs a project decision

- **Canonical impaired_confidence_and_suspension; Exec Summary; Review 6 KPI 2:** Automatic suspension at 7 days unresolved divergence or Tier 3 expiry.
- **Canonical deadlock_definition and discrepancy_clock_tiers; Review 1 item 3; Review 4 item 3:** Deadlock is more than 7 days, then a referee opinion within 5 days; automatic suspension for contested identity only after 14 days. Tier 3 = 14 days.
- **Why it conflicts:** For a contested identity divergence, the 7-day suspension fires before the deadlock path (7+5 days) or the 14-day Tier 3 clock can run. The referee step is unreachable and it is unclear which clock governs.
- **Suggested resolution:** Decision needed: state that the 7-day suspension takes precedence for ledger divergence, with the referee step inside the first 7 days, or give contested-identity divergence a 14-day clock. Record the precedence rule.

### 9. Statistical power of 24 sessions across 7 event types (🟡 Medium) — needs a project decision

- **Canonical go_detection_thresholds; Review 6 KPI 1; Self-audit 11:** Go requires detection of at least 90%/85%/80% by event type, with 95% confidence intervals by event type.
- **Canonical exercise_design_and_cap; Exec Summary deliverable 4:** At most 24 sessions across 4 sites in 90 days, covering all 7 event types (about 3-4 per type if a session is one scenario). The 50-100 events per site are in calibration and excluded from Go evidence.
- **Why it conflicts:** With a few trials per type, an 80-90% detection rate cannot be tested and a 95% interval cannot be computed. The Go rule rests on numbers the design cannot support. The Exec Summary only says power is 'provisional'.
- **Suggested resolution:** Decision needed: define events per session and per event type, or switch to a pooled or Bayesian rule, or accept that the Go rule is indicative. Remove the 95% CI claim until power is computed.

### 10. Phase Two expansion has no funding source under the hard cap (🟡 Medium) — needs a project decision

- **Pitch; Exec Summary; Review 2 item 1; Project Plan Related Goals:** A Go enables phased expansion, leveraging the existing USD 750M personnel envelope and the ledger envelope; over 24-36 months the mechanism becomes a standing body.
- **Canonical appropriation_window and staffing_baseline_fte; Review 14; Self-audit 15:** Appropriations are held for 18 months only. The USD 750M envelope covers at most about 3 years of baseline staffing. Review 14 says expansion needs USD 2-3B additional appropriation; Self-audit 15 says sustainment funding is not defined.
- **Why it conflicts:** The USD 5B cap is fully allocated and its window ends at Month 18. Expansion is presented as following from Go, but nothing commits to funding it. Review 14's range (USD 244-400M/yr) is also miscomputed: 434-650 FTE x USD 0.5-0.625M = about USD 217-406M/yr.
- **Suggested resolution:** Decision needed: state that Phase Two requires a separate instrument amendment and new appropriation, or extend the window. Remove 'leverages existing envelopes' wording and correct the FTE cost range.

### 11. Calibration needs approved inspectors before inspector approval is complete (🟡 Medium) — needs a project decision

- **Canonical entry_conditions_milestones, calibration_exercise; Project Plan Dependencies:** All inspectors approved by Month 5; vetting runs Month 0.5 through Month 4.5-5. Calibration runs Months 4-5 and the ledger is stress-tested by Month 4.
- **Review 10 item 2; Review 3 item 3; Review 13 item 1:** Calibration measures inspector detection rates (50-100 events per site) and 'thresholds lock on simulated (not real-inspector) performance' if rosters are not filled by Month 5.
- **Why it conflicts:** Calibration needs cleared inspectors, but full approval completes at the end of the calibration window. Calibration on a partial roster would not validate thresholds for the final team. No staged-approval rule exists.
- **Suggested resolution:** Decision needed: specify which inspector cohort is approved by Month 4 for calibration, or move calibration later (affecting the Month 5.5 lock). Do not assume full roster during calibration.

### 12. Inconsistent contingency burn and stop-loss triggers (🟡 Medium) — needs a project decision

- **Review 6 KPI 3; Premortem FM1, FM7; Self-audit 18:** Review 6: target cumulative spend below USD 200M through Month 6; reserve below USD 150M triggers review; burn above USD 75M per month; burn above USD 150M by Month 4 convenes co-chairs. Premortem: drawdown at or above USD 150M is a tripwire.
- **Review 14 item 3; Canonical contingency_governance:** Review 14: stop-loss at USD 400M cumulative; remedies when spend 'approaches USD 450M by Month 6'. Canonical: fast lane up to USD 50M; variance above 5% escalates.
- **Why it conflicts:** The same USD 500M reserve has triggers at USD 150M drawdown, USD 200M spend, USD 350M drawdown (reserve below USD 150M), USD 400M and USD 450M. The bases (spend vs drawdown vs reserve left) differ and the escalation levels are not ordered.
- **Suggested resolution:** Decision needed: set one ordered ladder on a single basis (cumulative contingency drawdown), for example warning, co-chair review, double-key reallocation and scope-reduction levels. Label all values (proposed threshold).

## Summary

The plan is largely consistent on its core structure: USD 5.0B split 50/50, the envelope allocation, the strict gate, the entry-condition milestones, the 90-day window and the Go/Modify/Stop thresholds. The executive summary, project plan and pitch were repaired and agree with the canonical facts. The remaining problems are in the review and self-audit, which still carry old dates (vendor, examiner, forensic and instrument steps at Month 0.5-1.5) and a few non-canonical rules. They also leave several decisions open: who covers the USD 15M contingency gap under the hard cap, the reference date for the 75-day funding Stop, the decision date after a late start, the 7-day versus 14-day suspension clocks, Phase Two funding, and whether 24 sessions can statistically support the detection thresholds. Resolve the four high items first, because they affect the economics and the go/no-go gates.