_Consistency: first pass found 1 high / 7 medium / 0 low contradictions. Repair: round 1: 32 edits → 1 high / 6 medium; round 2: 47 edits → 1 high / 8 medium. Published: round 1 (fewest high-severity issues). Shown below: the final check of the repaired documents (1 high / 6 medium / 1 low)._

## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Can both governments show a dated path to enacted appropriations and domestic access authority by Month 7 / Month 7.5, and a lawful source for gate work done before Month 7? | No required legislative, appropriations or access-authority step that cannot finish by Month 7.5 without a negotiating exception (A1 trigger); USD 2.5B per country (50/50, USD 5B hard cap); USD 50M gate-readiness sub-account (USD 25M per country) usable before certification. | Month 0.5 tabletop with both legal leads listing every approval step and its duration; signed funding commitment charter and lead-time matrix by Month 1. | Do not begin staffing, vetting or site-preparation commitments beyond the sub-account. Principals decide defer, reduced pair-count start, or stop. Do not rely on a supplementary appropriation, which exceeds the cap. |
| 2 | Does the vetting pilot show about 350-500 cleared staff can reach at least 80% of target, with no function under 2 FTE, by Month 8? | >=80% of target staff cleared by Month 8; rejection or reciprocal-clearance refusal <=10% of candidates (proposed threshold); interim >=200 cleared on a date consistent with measured vetting time. | Timed pilot of 10-20 candidates per country in the first quarter; batch rejection data; Month 8 staffing dry-run. | Delay the clock start, or split to a reduced site set (subset-of-pairs start fits the cap). Staffing below 80% is a curtailment condition, so the clock must not start. |
| 3 | At the Month 7.5 principal checkpoint, are the instrument (with deadlock timers, auto-suspension triggers and CHALLENGE-tag partition) signed, appropriations enacted, access authority enacted and the CNY conversion rule fixed? | Instrument signed and appropriations enacted by Month 7; access authority and supplier-list declarations by Month 7.5; no entry condition >=14 days behind; fixed CNY conversion rule documented before appropriation release. | Signed instrument, enacted appropriation and access-authority texts; weekly condition tracker; independent auditor's confirmation of the conversion rule and compensation ceilings. | Principals issue a written defer, reduced-scope or stop decision within 48 hours. Tranche 1 and the clock do not proceed. Certification beyond Month 12 means cancel or formally restart. |
| 4 | Is vendor binding complete, with unverifiable equipment forecast at or below 3% per site and at least 2 clean-room centers ready? | No vendor >5% of units unbound by Month 8 (tripwire at Month 7); key-validation latency within 4 hours on >=90% of samples; unverifiable forecast <=3% per site; >=2 clean-room centers operational by Month 9. | Vendor binding certificates and supplier-list declarations (Month 7.5-8), attestation dry-run results, clean-room acceptance tests. | Reclassify unbound vendors' units as unverifiable (Tier C) and apply the refusal ladder. If the forecast stays >3% for a site, drop that pair (subset-of-pairs start) or delay 2-4 months. A delay beyond 3 months breaches the Month 12 limit and means cancel or restart. |
| 5 | Do the readiness rehearsals pass, so the 90-day clock can start at single certification (Month 9)? | Filter-adequacy pre-test: >=10 injected substitutions, target 9 of 10, halt if <85%; checkpoint synchronization <=1 hour on >=95% of checkpoints; divergence detection <=4 hours; divergence false positives <=5% (proposed thresholds); staffing >=80% with no function <2 FTE; all 7 entry conditions certified together. | Staffing dry-run (Month 8); ledger stress test under 10x event load (Month 8); filter-adequacy blind pre-test (Month 8.5); misclassification drill (Month 8.75); joint certification at Month 9. | Halt scored exercises and do not start the clock. Redesign filters or transport through a double-key annex and re-test. Certification still cannot pass Month 12. Verdict date moves with the clock start, so it is not fixed at Month 12.25. |
| 6 | Do the sealed scored exercises show reciprocal access and credible detection with no Stop trigger, supporting a Go verdict? | Blind detection >=90% for each of 7 event types from >=10 injections each (70 total); parity variance within 10%; unverifiable <=3% per site; no ledger divergence or discrepancy unresolved >15 days; zero disruption to active compute; no tranche >30 days late. | Hash-committed scenario catalog scored by independent testers; sealed national scores compared at Month 11.75; auditor's parity and funding report; verdict at Month 12.25 (for a Month 9 start). | Detection 80% to <90% or a correctable cause means Modify (corrective trials, tranches 3-4 not released). Asymmetric access, material unverifiable equipment, a shielded operator, unresolved divergence or withheld funding means Stop. Insufficient exercise coverage means Modify. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: repaired_review_plan Reviews 1, 2, 4, 10; self-audit #5; canonical_facts (clock start range vs fixed verdict)
    canonical: phase_one_window_and_baseline = 90 days, Months 9-12; clock starts only after single certification
    observed:  window compresses from 90 days to 30-60 days; start Month 11-12 with verdict still Month 12.25
HIGH CF-002  document: repaired_review_plan (Reviews 4, 5, 10, 11); repaired_self_audit #6
    canonical: total_budget_usd = USD 5.0 billion hard cap; supplementary appropriation exceeds cap
    observed:  supplementary staffing/legal appropriation USD 30-50M (estimate) by Month 6
HIGH CF-003  document: repaired_review_plan Review 14; repaired_self_audit #15; repaired_pitch
    canonical: budget_horizon_open_decision = Open decision: documents do not state what the USD 5B funds after the Phase One verdict
    observed:  Phase One only vs Phase Two USD 2.5B additional; tranche 3 'automatically by Month 14'
HIGH CF-004  document: repaired_self_audit #18; repaired_premortem FM1; repaired_review_plan Reviews 4, 11
    canonical: contingent_exposure_estimate = Entry-gate sunk cost USD 100-200M (estimate) absorbed within spending envelopes, not contingency
    observed:  sub-account 'accessible only at certification' vs draws before Month 6
MEDIUM CF-005  document: repaired_review_plan (Reviews 2, 3, 5, 8, 9, 13)
    canonical: entry_condition_deadlines = Vendor binding Month 8; supplier-list declarations Month 7.5
    observed:  vendor binding and attestation validation by Month 7; clean rooms by Month 6.5
MEDIUM CF-006  document: repaired_review_plan Reviews 2, 10; repaired_premortem FM3; repaired_pitch
    canonical: detection_thresholds = false-positive limit TBD (proposed threshold)
    observed:  >3 total; <=2 per site; >=2 per site; 3 per site
MEDIUM CF-007  document: repaired_review_plan Reviews 4, 5, 13; repaired_premortem FM4
    canonical: staffing_buffers_and_tenure = Curtail below 80% of target staffing or any function under 2 FTE; 6-month tenure with 2-month break (proposed threshold)
    observed:  200 cleared by Month 2 vs 2-3 month minimum vetting
MEDIUM CF-008  document: repaired_review_plan Reviews 3, 8, 13; repaired_pitch
    canonical: readiness_rehearsals = Filter-adequacy blind pre-test Month 8.5 with >=10 injected substitutions, target 9 of 10, halt if <85%
    observed:  per-event-type samples; schema lock at Month 7.5; pre-test preceding a Month 7.5 step; '>85%'
MEDIUM CF-009  document: repaired_review_plan Review 7; repaired_self_audit #3, #11
    canonical: exercise_schedule = Thresholds frozen Month 10.5 (2027-08-27), before scored exercises start
    observed:  all thresholds locked at Month 7 signature; changes after Month 10.5 allowed by double-key
MEDIUM CF-010  document: repaired_self_audit #11
    canonical: identity_confidence_threshold = >95% equipment-identity confidence required per unit (provisional)
    observed:  >=95% of units with >=2 layers agreeing; divergence >5 points
MEDIUM CF-011  document: repaired_pitch
    canonical: scope_exclusions = No total-compute estimate, no hidden-facility proof, no foreign-hosted infrastructure, no comprehensive AI-governance regime
    observed:  federate with non-participating sites; integrate with broader AI governance; other strategic domains; vendor partnerships
LOW CF-012  document: repaired_review_plan Reviews 9, 13; repaired_self_audit #20
    canonical: auto_suspension_triggers = unverifiable >3% of covered units for 5 consecutive days
    observed:  suspension at Phase One start / Month 9.25 / Month 9.5; CHALLENGE event in Days 1-5
```

### 1. Late gate 'compresses' the 90-day window vs clock that starts only after certification, with a fixed verdict date (🔴 High) — needs a project decision

- **Project plan, SMART Time-bound; canonical phase_one_window_and_baseline / gate outer limit:** Project plan (Time-bound): clock starts Month 9 (range Months 6-12), runs Months 9-12, verdict at Month 12.25; entry certification outer limit Month 12. The 90 days starts only after all conditions are certified.
- **Review 1 #1, Review 2 #1, Review 4 #2, Review 10 #2, Self-audit #5 mitigation:** A delayed gate 'compresses Phase One operational window from 90 days to 30-60 days'; 'shifting Phase One start to Month 11-12'; 'defer Phase One to Month 11'; 'exercise window from 70 days to 30-40 days'.
- **Why it conflicts:** A clock that starts at certification cannot be shortened by a late gate. A Month 11-12 start would end near Months 14-15, so a verdict at Month 12.25 is impossible. The documents mix a fixed calendar verdict with a floating clock and a 'compressed' 90 days. The '70-day exercise window' also matches neither the calibration plus scored windows (about 2 months) nor the 90-day window.
- **Suggested resolution:** Keep the user constraint that the 90-day clock runs in full after certification. Define the verdict as clock end plus about 0.25 month, so Month 12.25 applies only to a Month 9 start. State the consequence of a later start (verdict, tranche 3 and tranche 4 dates shift), and drop 'compression to 30-60 days' wording. If a shorter window is wanted, treat it as a changed design and a double-key decision.

### 2. Supplementary appropriations vs USD 5B hard cap and Month 7 appropriation date (🔴 High)

- **Canonical total_budget_usd, fallback_fit_to_cap_and_dates, entry_condition_deadlines:** USD 5.0B hard cap, 50/50; a supplementary appropriation exceeds the cap; appropriations are enacted at Month 7.
- **Review 4 #3, Review 5 #3, Review 10 #2, Review 11 #1, Self-audit #6:** 'authorize supplementary staffing appropriation (USD 30-50M estimate) by Month 6'; 'authorize supplementary legal appropriation (USD 30-50M) by Month 6'; 'supplementary appropriation' for contingency/gate readiness.
- **Why it conflicts:** A supplementary appropriation adds money above the hard cap, and it is scheduled for Month 6, before the base appropriation exists at Month 7. Several mitigations therefore rest on a funding source the plan excludes.
- **Suggested resolution:** Replace 'supplementary appropriation' with in-cap options: double-key contingency draw (>USD 10M), envelope reallocation, or descoping/subset-of-pairs. Any request to raise the cap is a separate principal decision outside this plan.

### 3. What tranches 3-4 (USD 2.5B combined) fund vs 'Phase One only' vs Phase Two needing new money (🔴 High) — needs a project decision

- **Review 14 #1-2; Exec summary Timeline and Budget; canonical tranche_schedule:** USD 5B is allocated to 'Phase One only'; tranches 3-4 (USD 2.5B combined, USD 1.25B per country) release at Months 13 and 16 only after a non-Stop verdict and new double-key budget authorization.
- **Review 14 #1-2, Self-audit #15, Pitch Stakeholder Benefits:** Phase Two 'requires USD 2.5-5.0B additional appropriation' (8-12 sites, 'USD 2.5B additional'); Modify corrective trials USD 500M-1.0B; 'tranche 3 releases automatically by Month 14' once criteria are met; Pitch claims 'full USD 5 billion accountability'.
- **Why it conflicts:** Half the budget is held until after a 90-day test that ends at Month 12, yet the documents say Phase One alone uses the USD 5B and that Phase Two needs new money. It is not stated what tranches 3-4 pay for or whether Phase Two money counts inside or beyond the cap. 'Automatically by Month 14' also conflicts with canonical tranche 3 at Month 13 and with the new double-key authorization.
- **Suggested resolution:** Decision required before the instrument is signed. Options: (a) tranches 3-4 are the Phase Two/continuation budget inside the cap, with scope and criteria defined by Month 11; (b) tranches 3-4 fund Phase One tail costs (verdict, adjudication, disposition closure, wind-down) and Phase Two is entirely outside the cap; (c) tranches 3-4 are unreleased reserve returned on Stop or Modify. Whichever is chosen, remove 'automatic' release and keep the double-key authorization.

### 4. Funding for entry-gate work before appropriations; sub-account availability (🔴 High) — needs a project decision

- **Canonical entry_condition_deadlines / tranche_schedule; Self-audit #18:** Appropriations are enacted and tranche 1 released at Month 7. The USD 50M gate-readiness sub-account (inside contingency) is 'accessible only at certification' (Month 9).
- **Premortem FM1, Review 4 #3, Review 11 #1, Exec summary Risks, Review 3 #3:** Gate-readiness draws are tracked 'before Month 6' (tripwire USD 40M); 200 staff cleared by Month 2; clean rooms operational by Month 6.5; entry-gate sunk cost USD 100-200M (estimate) absorbed in envelopes from Month 0.
- **Why it conflicts:** Spending is scheduled from Month 0-6, but the envelopes, contingency and sub-account are funded by appropriations that exist only from Month 7. The sub-account is described both as usable before Month 6 and as available only at certification. No document identifies the source of pre-Month 7 sunk cost.
- **Suggested resolution:** Decision required. Options: (a) each government bridges pre-appropriation work from its own budget as a pre-agreed national advance later credited to its contribution; (b) tranche 1 or the sub-account is released earlier than Month 7 by an interim authority; (c) pre-Month 7 early targets (vetting, clean rooms) move after Month 7 or shrink to what the sub-account covers. Whichever is chosen, state when the sub-account becomes available and what the USD 100-200M sunk cost is charged to.

### 5. Vendor binding, attestation dry-run and clean-room dates (🟡 Medium)

- **Canonical entry_condition_deadlines, clean_room_cost_estimate; Review 3 #1; FM2:** Vendor binding, site selection, inspector approval and schedule at Month 8; supplier-list declarations at Month 7.5; clean rooms operational by Month 9. Review 3 #1's own tracker lists 'vendor binding Month 8'.
- **Review 3 #3, Review 2 #2, Review 8 #1, Review 9 #3, Review 13 #2, Review 5 #1:** 'Complete vendor binding and attestation-key validation by Month 7'; clean rooms 'by Month 6.5'; attestation dry-runs 'by Month 7' (Review 8) vs 'Month 8' (Review 5); 'Month 5.5' census compression.
- **Why it conflicts:** The same milestone has two month numbers, sometimes in one review. Binding at Month 7 precedes the Month 7.5 supplier declarations needed to know which vendors exist, and falls in the instrument-signature month. Clean rooms at Month 6.5 precede tranche 1 (Month 7) and differ from 'operational by Month 9'. Only the Exec summary labels Month 7 and Month 6.5 as internal early targets.
- **Suggested resolution:** Keep Month 8 as the binding deadline and Month 9 as clean-room operational readiness. Label Month 7 (dry-run, census) and Month 6.5 as internal early targets everywhere. Move the supplier-list-dependent census or binding step to follow the Month 7.5 declarations, and pick one attestation dry-run month.

### 6. Limit on misclassified challenge events (false positives) (🟡 Medium) — needs a project decision

- **Canonical detection_thresholds, challenge_partition:** False-positive limit is TBD; tagged CHALLENGE events cannot trigger suspension, impaired-confidence review or KPI violation.
- **Review 2 #3, Review 10 #3, Premortem FM3, Pitch:** 'more than 3 false positives' triggers impaired-confidence review; 'cap at <=2 per site per phase'; 'below 3 incidents per Phase One' vs 'exceeds 3 per site'; 'CHALLENGE misclassifications >=2 at any site' tripwire; 'false-positive tolerance enforced'.
- **Why it conflicts:** Four incompatible limits (total vs per site; >3, <=2, >=2, =3) are given for the same event. 'False positive' also means both a misclassified exercise event and a spurious detection in the false-positive/negative KPI.
- **Suggested resolution:** Decision required: set one limit, state per-site or per-phase and whether the bar is '>' or '>=', and calibrate it in the unscored exercises (Months 9.5-10.5). Name misclassified exercise events separately from KPI false positives.

### 7. Staff vetting: 200 cleared by Month 2 vs 2-3 month minimum and 6-12 month norm (🟡 Medium)

- **Review 4 #3, Review 5 #3, Review 13 #3, Self-audit #5:** Vetting 'cannot be expedited below 2-3 months'; typical cycles 6-12 months (estimate); >=80% of target staff cleared by Month 8.
- **Review 4 #3, Review 5 #3, Review 13 #3, Premortem FM4:** 'Begin expedited vetting on initial 200 ... by Month 1.5, clear at least 200 by Month 2' (Review 13); 'complete expedited CI vetting ... by Month 1.5' (Review 4); 'begin by Month 1' (Review 5); premortem early warning '<200 cleared by Month 2'.
- **Why it conflicts:** A start at Month 1.5 with completion by Month 2 (or completion by Month 1.5) allows 0-2 weeks, against a stated 2-3 month minimum. Start dates also differ (Month 1 vs Month 1.5). The Month 2 date also falls before any appropriation.
- **Suggested resolution:** Keep the stated minimum vetting duration, then derive the interim milestone from it. Set one start date and an interim date at least the minimum duration later, and recalibrate the early-warning tripwire to the Month 8 gate of 80%. The pilot of 10-20 candidates per country should set the realistic cycle time.

### 8. Filter-schema lock and pre-test sequencing against the signed instrument (🟡 Medium)

- **Review 13 #1 body; canonical readiness_rehearsals, evidence_schema:** Non-redactable schema is locked in the instrument at signature (Month 7); pre-test at Month 8.5 uses >=10 injected substitutions, target 9 of 10, halt if <85%.
- **Review 13 #1, Review 8 #3, Review 3 #2, Pitch Risks:** Review 13 #1 title: pre-test 'Month 8.5 must precede operator-gateway finalization Month 7.5'; Review 8 #3: lock non-redactable fields 'by Month 7.5' (after Month 7 signing); Review 3 #2: '>=10 injected substitutions per event type'; Pitch: '>85% detection gate'.
- **Why it conflicts:** A Month 8.5 step is required to precede a Month 7.5 step. The schema lock falls both at and after signature. Two sample sizes (10 vs 70) are given for the same pre-test. The pitch's '>85%' differs from 'halt if <85%' at exactly 85%. A failed pre-test would force renegotiation of an already signed instrument without an agreed path.
- **Suggested resolution:** Lock the non-redactable schema at signature (Month 7). Treat filter-rule changes after the pre-test as double-key annexes. Use one pre-test definition (>=10 injected substitutions, target 9 of 10, halt <85%) and keep the 70-injection simulation as a separate Month 8 activity. Fix the reversed heading and the Pitch wording.

### 9. Thresholds locked at signature vs calibrated and frozen at Month 10.5 (🟡 Medium)

- **Canonical exercise_schedule; Premortem FM9:** Calibration exercises run Months 9.5-10.5; thresholds are frozen at Month 10.5 before scored exercises; figures are proposed until then.
- **Review 7 #3, Self-audit #3 and #11:** 'Locking all provisional thresholds ... directly in the bilateral instrument (signed Month 7)'; 'any threshold change post-signing requires principal double-key re-authorization within 5 days'; 'any threshold change after Month 10.5 requires principal double-key reauthorization'.
- **Why it conflicts:** Thresholds cannot be both final at Month 7 and calibrated against Month 9.5-10.5 data. A permitted double-key change after the Month 10.5 freeze also conflicts with FM9, where a threshold change after freeze is a tripwire and rejection of frozen thresholds closes the program.
- **Suggested resolution:** State that the instrument locks the proposed thresholds and the calibration/freeze procedure. Values become final at Month 10.5, and a change after the freeze is a Stop-path event, not a routine re-authorization.

### 10. Verdict specification differs from canonical and premortem values (🟡 Medium)

- **Canonical identity_confidence_threshold, unverifiable_threshold; Premortem FM9:** Identity confidence >95% required per unit; unverifiable <=3% per site. FM9 tripwire: national score divergence >10 points on any event type.
- **Self-audit #11 mitigation:** Identity KPI: 'acceptance = >=95% of units with >=2 layers agreeing'; dispute rule: 'if country scores diverge >5 points, convene technical referees'; parity 'for final 4 weeks'.
- **Why it conflicts:** A per-unit confidence of >95% is a different metric from '>=95% of units agree', which would admit up to 5% disagreeing units against an unverifiable cap of 3%. Score divergence triggers at 5 points in one document and 10 in another, so the sealed-score dispute path is unclear.
- **Suggested resolution:** Keep per-unit confidence >95% (provisional) and the 3% unverifiable cap. Keep the 5-point level as the referee trigger and the 10-point level as the FM9 tripwire only if both are labelled as stages, otherwise pick one. Mark all as proposed thresholds.

### 11. Pitch and long-term vision exceed declared-equipment verification scope (🟡 Medium)

- **Canonical scope_exclusions, business_framing_not_applicable:** Scope is declared-equipment change verification at participating sites only. No total-compute estimate, no hidden-facility proof, no foreign-hosted infrastructure, no comprehensive AI-governance regime. Partnership and promotional framing is not applicable.
- **Pitch: Collaboration Opportunities and Long-term Vision:** Operators 'can federate with non-participating sites to define the broader AI-infrastructure landscape'; Phase Two '8-12 global' sites; 'integrated with broader AI-governance frameworks'; extend to semiconductor manufacturing, power systems, critical infrastructure; 'Vendor Partnerships', 'competitive' roles, 'relationship capital'.
- **Why it conflicts:** Federating with non-participating sites and mapping the 'broader landscape' edges toward capacity and hidden-facility questions that are excluded. The long-term vision adds a comprehensive governance and multi-domain regime. Partnership and procurement language contradicts the not-applicable business framing.
- **Suggested resolution:** Delete the federation item and the multi-domain, allied-expansion and governance-integration claims, or mark them explicitly out of scope. Replace 'partnership/competitive' wording with governance and fiscal-accountability language. Phase Two scope stays 'open'.

### 12. Timing of unverifiable-equipment suspension and challenge events in baseline days (⚪ Low)

- **Canonical auto_suspension_triggers, phase_one_window_and_baseline:** Suspension requires unverifiable >3% of covered units for 5 consecutive days; Days 1-5 are reserved for the opening-inventory seal, with no challenge exercises or equipment movements.
- **Review 13 #2, Review 9 #3, Self-audit #20:** Exceeding 3% 'at Phase One start triggers automatic site suspension ... before a single exercise injection'; suspension 'at Month 9.5'; 'by Month 9.25'; a 'misclassified CHALLENGE event during opening-inventory baseline (Days 1-5, Months 9-9.25)'.
- **Why it conflicts:** Suspension is described as immediate, at Month 9.25, or at Month 9.5, though it requires 5 consecutive days. A CHALLENGE event cannot occur in Days 1-5 because exercises are barred then, and Days 1-5 do not span Months 9 to 9.25.
- **Suggested resolution:** Use '>3% for 5 consecutive days' everywhere and give relative dates (Day 6 at the earliest). Remove the CHALLENGE-in-baseline cascade or recast it as a violation of the baseline rule.

## Summary

The plan is largely consistent with the canonical facts on budget envelopes, tranche amounts, compensation share (USD 500M per country), deadlock and aging timers and the exercise schedule, and most earlier repairs hold. Remaining gaps concern money and time: the verdict date versus a floating 90-day clock, funding of pre-appropriation work, supplementary appropriations that breach the hard cap, and what tranches 3-4 actually fund. Several review recommendations still carry pre-reconciliation dates (vendor binding Month 7, vetting Month 2) and inconsistent false-positive limits. Three of the findings need a project decision rather than text edits: the pre-Month 7 funding source, the use of tranches 3-4, and the misclassification limit.