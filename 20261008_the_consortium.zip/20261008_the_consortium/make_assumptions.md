
## Question 1 - How will each USD 2.5 billion contribution be released, tracked in USD/CNY, and held to matched cumulative disbursement across the seven envelopes?

**Assumptions:** Assumption: Each contribution is released in matched tranches (proposed: four quarterly tranches), with a fixed conversion rule for CNY set at the entry gate. Parity tolerance of ±10% of pro-rata share is a proposed threshold, to be validated by the independent auditor.

**Assessments:** Title: Financial Feasibility Assessment
Description: Fiscal accountability of the fixed 50/50 USD 5 billion budget.
Details: Matched tranches limit one-sided exposure but give each side a low-cost stalling lever. Contingency (USD 500M, user constraint) is 10% of budget; surge overlaps could exhaust it early (estimate). Mitigation: co-chair sign-off for draws above a proposed USD 10M, monthly burn reports per envelope, and a 75% contingency-draw trigger (proposed) escalating to principals. Funding timeliness is a Stop criterion.

## Question 2 - What is the timeline for certifying all entry conditions before the 90-day clock starts, and what are the milestones through the Go/Modify/Stop verdict?

**Assumptions:** Assumption: Entry conditions are certified in a single gate before Month 0 (2026-10-12) clock start is declared; no clock runs until certified. Phase One then runs Months 0-3 (2026-10-12 to 2027-01-12) (user constraint), with baseline sealing in the first days, challenge exercises in roughly Months 1-2 (2026-11-12 to 2026-12-12) (proposed), threshold freeze before scored exercises, and verdict by Month 3.25 (2027-01-20) (proposed).

**Assessments:** Title: Schedule Feasibility Assessment
Description: Realism of entry-gate readiness and the compressed 90-day test.
Details: Bilateral instruments, appropriations and domestic access authority typically take far longer than weeks (estimate: 6-12 months), so the gate, not Phase One, is the critical path. Because the clock starts only after certification, slippage costs money, not test time. Mitigate with weekly condition tracking, a go/no-go checkpoint, and a documented grace rule. Reserve early days for baseline with no exercises.

## Question 3 - What staffing model (headcount per site, shifts, mirrored teams, leave, surge, separation of duties) is needed, and how are inspectors cleared and trained?

**Assumptions:** Assumption: Each matched site has 24/7 full-time mirrored resident teams per country across inspection, technical, legal, cybersecurity, counterintelligence, translation, audit, logistics and adjudication units, with at least two trained people per function. Leave allowance (proposed 15%) and surge reserve (proposed 10-30%) are provisional until validated by a Month -1 staffing dry-run.

**Assessments:** Title: Staffing Adequacy Assessment
Description: Workforce sizing against the USD 750M personnel envelope.
Details: Continuous coverage of a few sites implies hundreds of cleared full-time staff (estimate), with vetting as the long-lead item. No single-person critical functions; no temporary-agency inspectors. Risks: 20-40% availability loss in surges (estimate) and cost overrun of USD 50-100M (estimate). Mitigations: cross-site floaters, trained backups, curtailment rules if deployment falls under a proposed 80% of target.

## Question 4 - What bilateral instrument, domestic legal authority and double-key procedures (deadlock, impaired-confidence, automatic suspension) govern the Consortium?

**Assumptions:** Assumption: A signed bilateral instrument fixes equal co-chairs, double-key authorization, and enumerated triggers; both governments enact domestic compulsion authority before the gate. Deadlock is proposed as no consensus within 5 days, escalating to technical referees then principals, with status quo defaulting to heightened inspection while aging discrepancies are reported.

**Assessments:** Title: Governance and Legal Assessment
Description: Enforceability of governance without casting vote.
Details: Absent casting votes, delay is the main obstruction tool. Fixed timers, objective automatic triggers and excluded exercise events reduce stalling and manufactured incidents. Legal risk: litigation or state-enterprise ambiguity over compelling vendors (estimate: 2-4 month delay). Mitigate with early legal working group, binding certification as an entry condition, and documented resumption conditions requiring corrective action.

## Question 5 - What are the principal safety, counterintelligence and security risks to personnel, evidence systems and operators, and what controls address them?

**Assumptions:** Assumption: Inspectors work in bounded zones with escorted movement, pre-validated instruments and no recording devices beyond approved tools. Compartmentation by site and event type, host liaison review, insider-threat red cell and continuous vetting apply. Tenure limits (proposed 6 months) are provisional.

**Assessments:** Title: Security and Risk Assessment
Description: Espionage, physical safety and evidence-system integrity.
Details: Resident teams enlarge the collection surface; over-compartmentation can cause missed substitutions. A breach could remove 2-3 weeks of coverage and cost USD 20-40M (estimate). Controls: hardened ledger nodes, incident logging within one hour (proposed), unannounced facility reviews, and clean-room safety. Residual risk stays high; challenge exercises must test filtering adequacy before scored runs.

## Question 6 - What environmental and site-footprint impacts arise from staging areas, clean rooms, secure facilities, equipment destruction and disablement, and e-waste handling?

**Assumptions:** Assumption: Site preparation uses existing datacenter space with modest fit-out rather than new construction; destruction and disablement occur at licensed, host-country facilities under witness. Environmental impact is minor relative to datacenter operations and is governed by host-country environmental and e-waste law.

**Assessments:** Title: Environmental Impact Assessment
Description: Footprint of fit-out, travel and equipment disposal.
Details: Main impacts: e-waste and residual materials from witnessed destruction, energy use of ledger nodes and secure facilities, and international staff travel. Risks are low in scale for a small matched site set (estimate). Mitigate with licensed recycling, no-disruption rules for active compute, remote reconciliation where secure, and including disposal compliance in the exit protocol evidence.

## Question 7 - Which parties (operators, vendors, logistics firms, customs, auditors, technical referees) must be engaged, and how is their participation secured without a public satisfaction process?

**Assumptions:** Assumption: Each government compels its own operators and vendors, charges compensation to its own contribution, and requires flow-down of reporting, confidentiality, escort and preservation duties. Refusing vendors use vendor-supervised testing, filtered evidence or accredited clean-room examination; otherwise equipment is unverifiable.

**Assessments:** Title: Stakeholder Engagement Assessment
Description: Operator and vendor participation as a failure pathway.
Details: Vendor refusal or operator withdrawal can fail a site; estimated 10-40% of equipment could be unverifiable under vendor concentration (estimate). Binding must finish before the gate. Compensation asymmetry between countries may feed parity disputes. Mitigations: pre-qualified vendor registry, supplier declarations before the gate, operator liaisons, and visible operator-consent status in the dashboard.

## Question 8 - What operational systems (ledger, attestation validation, intake and exit protocols, filtering gateways, KPI dashboard) are required, and how are thresholds validated?

**Assumptions:** Assumption: Each country holds an independently verifiable ledger copy with immediate local recording and signed checkpoint exchange. Proposed thresholds (e.g. synchronization within 1 hour, divergence detection within 4 hours, identity confidence above 95%, unverifiable equipment under 3%) are provisional, to be validated by early blind exercises.

**Assessments:** Title: Operational Systems Assessment
Description: Integrity and sufficiency of evidence systems and KPIs.
Details: USD 1.25B (user constraint) funds ledger, attestation and communications. Key risks: attestation-key concentration, divergence between copies, and filters stripping fields needed to detect substitution. Mitigations: layered evidence with no single decisive source, minimum evidence schema, filter decisions logged, calibration panel and threshold freeze before scored exercises. Unsupported figures stay marked provisional or TBD.