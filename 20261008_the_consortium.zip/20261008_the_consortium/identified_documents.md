
## Documents to Create

### 1. Bilateral Instrument and Treaty Framework

**ID:** 97ca4dad-0c3b-42f4-82d3-7aa7fc9b0079

**Description:** The foundational legal agreement between US and China governing The Consortium's structure, authority, obligations, double-key governance, deadlock procedures, reciprocity rules, inspector immunity, equipment verification scope, confidentiality, dispute escalation, and amendment procedures. International agreement type; audience: both governments' legal and foreign-affairs bodies; essential for entry-condition certification and domestic legislative authority enactment.

**Responsible Role Type:** Bilateral Legal Counsel and Treaty Negotiator

**Primary Template:** World Bank Bilateral Instrument Template

**Secondary Template:** IAEA Safeguards Bilateral Agreement Structure

**Steps:**

- Identify both governments' key legal issues and negotiating positions by Month 0 (2026-10-08).
- Draft core articles covering: double-key governance, deadlock resolution, suspension triggers, conditional-start fallback, forensic-panel authority, vendor-refusal ladder, zone boundaries, thresholds, amendment procedure.
- Circulate draft to both co-chairs and named legal teams for comment (Month 0.5 = 2026-10-23).
- Negotiate contentious articles (e.g., deadlock tie-breaker, neutral referee eligibility, suspension reversibility) through bilateral working group.
- Obtain both co-chairs' signatures by Month 1 (2026-11-08) on a near-final version; reserve ratification for parliamentary/executive approval.

**Approval Authorities:** Both co-chairs (equal national leaders); domestic ratification by each country's parliament or executive authority by Month 2 (2026-12-08).

### 2. Domestic Access Authority Decomposition and Enactment Plan

**ID:** 9c53809c-e2d2-41d5-b1c2-7b367ee24fcc

**Description:** Country-by-country breakdown of specific legislative or executive acts required to compel operator and vendor participation, grant inspector legal authority, enable access to datacenters, and authorize inspector immunity and evidence handling. Includes approval bodies, committee schedules, critical-path dependencies and fallback authority triggers. Document type: legislative roadmap and authority-tracking framework; audience: domestic governments' legislative/executive leadership and co-chairs; essential for entry-condition certification.

**Responsible Role Type:** Domestic Authority Legal Lead (named representative per country)

**Steps:**

- By Month 0 (2026-10-08), each country's legal lead identifies all required domestic acts (e.g., Congressional resolution, State Council directive, ministry enforcement authorization).
- Map each act through its approval bodies and committee schedule; identify single-item critical path.
- For US: identify bill sponsors, committee jurisdiction (Foreign Relations, Armed Services, Appropriations), likely approval timeline (6-12 weeks for ratification, 4-8 weeks for access authority, 2-4 weeks for appropriations).
- For China: identify State Council process, Ministry of Industry & Information Technology (MIIT) delegation, and domestic confidentiality regulations.
- Document anticipated delays and escalation: if any item slips >4 weeks, trigger bilateral entry-conditions steering committee review within 2 working days.
- Obtain signatures confirming each authority is enacted by each government by Month 3.5 (2027-01-23).

**Approval Authorities:** Domestic legislative bodies in each country (US Congress, China State Council and applicable ministries); co-chairs certify completion by Month 6 (2027-04-08).

### 3. Entry-Conditions Steering Committee Charter and Weekly Tracking Dashboard

**ID:** 685d0abf-4a5c-4246-8e6c-f5bbeb66f732

**Description:** Charter establishing the bilateral steering committee (both co-chairs, named domestic-authority leads per country, bilateral program manager) with weekly review authority, escalation triggers, and documented decision-log. Weekly dashboard tracks all 7 entry conditions' milestone completion percentage, flags >4 week delays in red, and documents any agreed fallback invocation. Document type: governance and project-management charter; audience: co-chairs, domestic leads, bilateral team; enables real-time escalation of delays.

**Responsible Role Type:** Bilateral Program Manager and Co-Chair Executive Assistants

**Primary Template:** Project Steering Committee Charter (PMI PMBOK)

**Steps:**

- Draft charter specifying meeting schedule (weekly, same day/time), attendees, decision authority (consensus recommended; escalation to political level if deadlock >7 days), minutes-taking and action-item tracking.
- Create a dashboard template with rows for each of 7 entry conditions and columns for: baseline target date, current status (% complete), risk flag (red/yellow/green), owner, last-update date, and agreed fallback trigger.
- Both co-chairs sign the charter by Month 0 (2026-10-08).
- Hold first steering committee meeting in Week 1 of Month 0 (2026-10-08); establish weekly rhythm.
- Update and circulate dashboard every Friday with status snapshots and escalation notes.
- Document every agreed fallback invocation (conditional-start trigger, timeline extension, scope reduction) in the ledger.

**Approval Authorities:** Both co-chairs; escalation authority delegated to named domestic leads for tactical decision-making within 5 working days.

### 4. Conditional-Start Fallback Authority and Protocol

**ID:** e3482059-2e7c-4b69-8d11-240f45c51879

**Description:** Bilateral instrument article (or separate protocol) explicitly permitting Phase One clock to begin at each site independently once that site's entry conditions are met, rather than requiring all conditions simultaneously before clock start. Specifies how to maintain joint final-decision authority, evidence-combination rules for multi-site result, and how asymmetric start dates do not invalidate the verdict. Document type: treaty amendment or protocol; audience: both governments, co-chairs, bilateral legal team; enables deadlock-breaking if one country's authority or vetting is slower.

**Responsible Role Type:** Bilateral Legal Counsel

**Primary Template:** Treaty Protocol or Instrument Amendment (IAEA/OPCW model)

**Steps:**

- Draft language by Month 0.5 (2026-10-23) permitting independent per-site clock starts while final Go/Modify/Stop decision requires joint certification that all sites completed 90 days (unless one site is formally exempted due to force majeure or withdrawal).
- Specify that evidence from per-site delayed starts is combined with full-duration sites in a composite Go/Modify/Stop verdict, with notation of which sites operated for compressed timelines.
- Circulate draft to both co-chairs for acceptance by Month 1 (2026-11-08).
- Obtain both signatures; embed in bilateral instrument.

**Approval Authorities:** Both co-chairs; both governments' parliaments/executives if treated as instrument amendment (Month 1-2 = 2026-11-08 to 2026-12-08).

### 5. Forensic Panel Charter and Evidence-Weighting Hierarchy

**ID:** 0afe4c98-a152-43f6-87d6-7844fa779619

**Description:** Codified mandate for the joint forensic-identity panel (3–5 specialists per country, 6–10 total, equal national membership, no casting vote), specifying decision authority, evidence-weighting corroboration rule (e.g., attestation > physical inspection > maintenance records > third-party logs), 48-hour investigation and finding timeline, deadlock escalation to co-chairs (24 hours), and enforcement authority. Document type: bilateral governance charter; audience: forensic panel members, co-chairs, bilateral legal and technical teams; foundation of ledger-divergence resolution.

**Responsible Role Type:** Bilateral Legal Counsel and Senior Technical Advisor (Joint)

**Secondary Template:** IAEA Technical Panel Authority Charter (adapted)

**Steps:**

- Convene both co-chairs and technical leads to draft the evidence-weighting hierarchy and panel's scope by Month 0.5 (2026-10-23).
- Define hierarchy with worked examples (e.g., 'if cryptographic attestation diverges but physical inspection matches, accept physical inspection; if both diverge, request independent examiner arbitration within 48 hours').
- Specify panel composition criteria: security clearance, technical expertise in equipment identity verification, counterpart nationality approval (veto right).
- Lock the charter in the bilateral instrument by Month 1 (2026-11-08).
- Publish the named panel members' bios and credentials by Month 1.5 (2026-11-23) for mutual acceptance.

**Approval Authorities:** Both co-chairs sign the charter (bilateral instrument); both governments' counterintelligence agencies approve panel members by Month 1 (2026-11-08).

### 6. Shift-Boundary Cross-Signing Protocol and Ledger Divergence Detection Procedure

**ID:** a2befc94-9b48-42b9-b3d7-33b749ed0db0

**Description:** Operational procedure specifying how mirrored inspectors from each country jointly certify ledger entries at every shift handover (08:00, 16:00, 24:00 UTC minimum), with both signatures confirming no undisclosed divergences in the prior shift. Defines automated divergence-detection algorithm (cryptographic hash comparison every 4 hours, alert within 2 hours if divergence >tolerance), forensic-panel escalation routing (within 15 minutes), and resolution timeline (48 hours for panel finding, 24 hours for co-chair decision if panel deadlocks). Document type: operational/technical procedure; audience: ledger operations teams, inspectors, forensic panel, co-chairs; critical to preventing divergence-clock cascades.

**Responsible Role Type:** Ledger Operations Manager and Forensic Panel Lead

**Secondary Template:** IAEA Safeguards Ledger Verification Procedure (adapted)

**Steps:**

- Design the shift-handover cross-signing ceremony: two inspectors (one per country) review prior-shift ledger entries side-by-side, sign jointly, and immediately alert if any divergence is found.
- Specify the cryptographic divergence-detection algorithm: both ledgers compute SHA256 hash of all entries; hashes compared every 4 hours; alert within 2 hours if hashes diverge.
- Define forensic-panel dispatch: divergence alert triggers automated notification to the duty forensic-panel member and co-chairs within 15 minutes.
- Specify panel investigation: panel applies evidence hierarchy, issues finding within 48 hours, or co-chairs decide within 24 hours.
- Implement shift-handover cross-signing on non-covered equipment by Month 1 (2026-11-08); stress-test and validate by Month 4 (2027-02-08).

**Approval Authorities:** Co-chairs ratify the procedure in the bilateral instrument by Month 1 (2026-11-08); ledger operations teams and forensic panel conduct operationalize by Month 4 (2027-02-08).

### 7. Vendor Pre-Binding Cooperation Agreements and Penalty Clauses

**ID:** e3a9ad40-ec41-485a-8252-24f164a4c907

**Description:** Master agreement template and executed bilateral agreements with each of the top 8–12 Tier-1 vendors per participating site, binding each vendor to: equipment-identity attestation disclosure within 2 business days; maintenance records and evidence preservation for 90 days post-departure; inspector escort and site access; and liquidated-damage penalties (USD 500k–2M per material refusal, loss of future market access). Document type: commercial/legal contract; audience: operators, vendors, bilateral procurement teams; de-risks vendor-refusal cascades by locking cooperation in advance.

**Responsible Role Type:** Bilateral Procurement Lead and Operator Counsel (Joint)

**Primary Template:** Standard Government Supply/Service Agreement with Penalty Clauses

**Steps:**

- By Month 0 (2026-10-08), identify top 8–12 Tier-1 vendors per site; rank by dependency (failure means site fails vs. fallback available).
- Draft master agreement template specifying vendor obligations: attestation disclosure (48-hour SLA), maintenance records (preservation 90+ days), inspector escort, confidentiality, penalties.
- Begin bilateral negotiations with Tier-1 vendors by Month 0.5 (2026-10-23); target execution by Month 1 (2026-11-08) for at least 80% of Tier-1 vendors.
- Each country's operators handle their own vendor negotiations (charged to their half of the USD 1.0B site-preparation envelope).
- Publish the signed-vendor roster (without details, only vendor names and attestation commitment status) in the bilateral instrument by Month 2 (2026-12-08).
- Track vendor-refusal escalations in the ledger starting Month 3 (2027-01-08).

**Approval Authorities:** Each country's operators sign agreements with their vendors; co-chairs certify that Tier-1 vendor cooperation is locked by Month 1 (2026-11-08).

### 8. Independent Examiner and Clean-Room Pre-Qualification Agreements

**ID:** afea23d1-1a13-44d0-ae97-804af66ff71f

**Description:** Executed agreements with 3–5 independent equipment-identity examination labs per country and 2 accredited clean-room facilities per geography (8 facilities total), specifying: scope of examination (equipment-identity verification without vendor cooperation), cost per exam (target USD 20–50k), capacity (minimum 5 parallel exams per week per facility), confidentiality and access rules, and binding availability for Phase One (Months 6–9 = 2027-04-08 to 2027-07-08). Document type: service contract; audience: bilateral procurement, operators, examiners, fallback-path coordinators; foundation of vendor-refusal escalation ladder.

**Responsible Role Type:** Bilateral Procurement Lead and Independent Lab Accreditation Specialist

**Primary Template:** Government Services Agreement (Testing/Examination)

**Steps:**

- Identify candidate independent labs and clean-room facilities per country and geography by Month 0.5 (2026-10-23) through trade associations, government referrals, and prior IAEA/OPCW relationships.
- Conduct technical qualification: visit candidate facilities, verify equipment and technical expertise, confirm capacity for parallel exams and quick turnaround.
- Negotiate and execute binding agreements by Month 1 (2026-11-08), specifying exam scope, cost, capacity, availability and confidentiality.
- Publish the pre-qualified examiner roster (names and services) in the bilateral instrument by Month 2 (2026-12-08).
- Conduct a joint bilateral test of each facility by Month 4 (2027-02-08) to verify equipment, staff and turnaround-time credibility.

**Approval Authorities:** Both co-chairs certify examiner pre-qualification by Month 1 (2026-11-08); operators and bilateral procurement verify facility readiness by Month 4 (2027-02-08).

### 9. Vendor-Refusal Escalation Ladder and Unverifiable-Equipment Protocol

**ID:** ba03cf1e-f437-412f-904b-50b21b6ff86e

**Description:** Documented day-0 to day-10 (with one extension to day-15) escalation procedure for each vendor refusal: Day 0–1 operator escalates; Day 2 examiner notified; Day 5 exam complete; Day 10 report submitted; then clean-room or validated attestation; Day 15 final disposition (unverifiable classification if no evidence). Specifies who owns each step, escalation contacts, and logging procedures. Document type: operational/procedural guide; audience: operators, bilateral vendor-refusal coordinators, forensic panel, inspectors, ledger custodians; critical to preventing unverifiable-equipment accumulation.

**Responsible Role Type:** Bilateral Vendor Refusal Coordinator and Operator Compliance Officer

**Secondary Template:** Escalation Ladder Template (IAEA Safeguards model)

**Steps:**

- Design the day-0 to day-10 ladder with specific owners and contact information for each step (operator, co-chairs, examiner, ledger custodian).
- Define 'material refusal': vendor explicitly declines to provide attestation keys, maintenance records, or inspector access when requested; vendor silence >24 hours = presumed refusal.
- Create a vendor-refusal escalation form (one-page) documenting: date of request, vendor name, refusal reason (if stated), examiner assigned, exam scheduling, and outcome.
- Specify logging: every refusal logged in both national ledgers with reason, escalation outcome, and final disposition.
- Lock the ladder in the bilateral instrument by Month 1 (2026-11-08); publish to operators by Month 2 (2026-12-08).
- Train all site operators and inspectors on the ladder procedure by Month 5 (2027-03-08).

**Approval Authorities:** Both co-chairs approve the ladder in the bilateral instrument by Month 1 (2026-11-08); bilateral vendor-refusal coordinator owns operational enforcement.

### 10. Ledger System Design Specification and Cryptographic Custody Protocol

**ID:** 1ef7eb8d-ef22-4999-9b7a-8592ed33b337

**Description:** Technical specification for the replicated tamper-evident ledger: two independent air-gapped national ledger copies connected by secure communications link (target sync <60 minutes), cryptographically signed entries (no unilateral insertion), offline backup protocols, and split-key custody ceremony procedure. Covers system architecture, synchronization bounds, divergence-detection algorithm, recovery procedures, backup encryption, and dual-signature requirements. Document type: technical specification; audience: ledger architects, cryptography specialists, co-chairs, bilateral security teams; foundation of evidence integrity.

**Responsible Role Type:** Cryptographic Systems Architect and Ledger Operations Lead

**Primary Template:** Byzantine Fault-Tolerant Ledger Design (Academic Standard)

**Secondary Template:** IAEA Safeguards Digital Ledger Specification

**Steps:**

- By Month 0.5 (2026-10-23), design the ledger architecture: two independent servers per country (national locations), secure communications (dedicated fiber or radio-frequency links), cryptographic signing (split keys, no single-actor insertion), offline backup (air-gapped encryption).
- Specify synchronization: target <60 minutes; sync failure >4 hours triggers escalation; both copies remain operational and independently signed.
- Define divergence detection: every 4 hours both copies compute SHA256 hash; divergence alerts within 2 hours; forensic-panel investigation within 24 hours.
- Design key ceremony: split-key generation in a mutually agreed secure facility with video recording, witness signatures, and tamper-evident hardware seals. Neither government alone can sign entries.
- Specify recovery: offline backup recovers from any timestamp; 6-hour recovery-time target from backup; cryptographic validation upon recovery.
- Lock the specification in the bilateral instrument by Month 1 (2026-11-08); operationalize and stress-test by Month 4 (2027-02-08).

**Approval Authorities:** Both co-chairs and bilateral cryptography teams approve the specification by Month 1 (2026-11-08); ledger operations teams implement and validate by Month 4 (2027-02-08).

### 11. Bilateral Key Ceremony Protocol and Schedule

**ID:** 3f130a72-7736-479a-a39a-79074ae4efba

**Description:** Detailed procedure for the bilateral split-custody cryptographic root-key generation ceremony: facility selection (mutually agreed secure location), attendees (cryptography specialists from both governments, witness officials, video recording crew), sequence of operations (random-number generation, key splitting, distribution, testing), documentation (video recording, witness signatures, tamper-evident seals), storage (each government holds one half of the split key in separate encrypted vaults). Document type: ceremonial procedure and security protocol; audience: cryptography teams, facility operators, co-chairs, bilateral security; ensures neither government alone can compromise attestation or ledger signing.

**Responsible Role Type:** Bilateral Cryptography Lead and Facility Security Officer

**Primary Template:** Split-Key Ceremony Protocol (NSA/NIST Standards)

**Steps:**

- By Month 1 (2026-11-08), both co-chairs nominate a mutually agreed secure facility (government SCIF, embassy, or neutral third-country location).
- Agree on ceremony date, attendees (5–10 per country: cryptographers, witnesses, security officers), equipment (random-number generators, key-splitting appliances, video recording).
- Draft detailed ceremony sequence: setup, randomness validation, key generation, splitting, distribution to both governments, testing on non-live systems, backup encryption and sealing.
- Schedule the ceremony for Month 1.5 (2026-11-23 09:00); allow 8 hours for the full ceremony.
- Record the ceremony on video with at least two witnesses per country signing the recording and tamper seals.
- Each government stores its half of the split key in a separate, geographically distinct encrypted vault with independent backup encryption.
- Document recovery procedures: how to reconstruct the full key if either half is lost (cross-national recovery to be scheduled post-ceremony).

**Approval Authorities:** Both co-chairs schedule and authorize the ceremony; bilateral cryptography leads execute; both governments' facility security officers certify sealing and storage.

### 12. Site-Boundary Marking and Access-Control Installation Plan

**ID:** 7aa96124-2ad1-45db-ac05-f8966e517748

**Description:** Bilateral survey and physical marking of inspection-zone boundaries at each participating site, with painted lines, permanent signage, photographic documentation, and installed access-control gates logging all entries to both national ledgers in real time. Covers staging, spare-inventory, maintenance, and expansion areas; excludes live-computation spaces. Includes redaction procedures for operator-run evidence filtering and monthly boundary-compliance audits. Document type: site-preparation and operations manual; audience: site operators, security teams, inspectors, zone auditors; foundation of bounded-zone IP protection.

**Responsible Role Type:** Site Preparation Manager and Bilateral Security Coordinator

**Secondary Template:** Security Perimeter Design and Access Control Standard (US DoD, adapted)

**Steps:**

- By Month 1.5 (2026-11-23), conduct a bilateral pre-clock survey at each site with both countries' security teams, operators, and inspectors present.
- Walk the site and identify boundaries of staging, spare-inventory, maintenance, and expansion areas; designate live-computation areas as off-limits.
- Mark boundaries with: painted lines (high-visibility color), permanent signage every 10 meters, and landmark photographs from cardinal directions.
- Install access-control gates at all entry/exit points with proximity-card readers and real-time logging to both national ledgers.
- Establish operator-run evidence redaction workflow: evidence leaves the zone through a redaction-audit workspace where an operator reviews documents/video for classified workload data before inspectors certify passage.
- Produce a signed photographic record of the exact boundary, approved by both co-chairs by Month 1.5 (2026-11-23).
- Implement monthly boundary-compliance audits: random inspector access logs reviewed, any boundary-adjacent activity investigated within 48 hours.

**Approval Authorities:** Both co-chairs approve the marked boundary by photographic record by Month 1.5 (2026-11-23); site operators certify access-control operationality by Month 5 (2027-03-08).

### 13. Three-Tier Zone-Infraction Escalation Protocol and Conduct Acknowledgment

**ID:** 1e23be8d-5a57-4e07-9bed-23de0d3b50a5

**Description:** Codified escalation rules for inspector zone-boundary violations: Tier 1 (minor, first offense: written warning + 48-hour re-training); Tier 2 (moderate, repeated: formal notice, joint conduct-committee review, removal within 5 working days); Tier 3 (material espionage/counterintelligence risk: immediate removal + legal action). Includes 2-hour allegation-reporting hotline, 24-hour investigation, 72-hour findings, and 5-working-day disciplinary decision. Requires every inspector to sign a zone-conduct acknowledgment before Phase One clock start. Document type: disciplinary and operational procedure; audience: inspectors, conduct committee, co-chairs, site security; prevents unauthorized information collection.

**Responsible Role Type:** Bilateral Conduct Committee Chair and Inspector Vetting Lead

**Primary Template:** Disciplinary Procedure (IAEA Inspector Code of Conduct, adapted)

**Steps:**

- Draft the three-tier protocol specifying offenses in each tier with examples (Tier 1: inadvertent boundary crossing <2m; Tier 2: deliberate photography of non-zone infrastructure; Tier 3: suspected espionage, coercion, or unauthorized classified-data transfer).
- Establish a zone-violation hotline: alleged violations reported to bilateral conduct committee within 2 hours; acknowledged within 15 minutes; investigation initiated within 24 hours.
- Specify investigation procedures: written statement from accused inspector, witness interviews, access-log review, video analysis if available; findings within 72 hours.
- Define disciplinary outcomes by tier: Tier 1 = co-chair-signed written warning + bilingual re-training within 48 hours; Tier 2 = formal notice + committee hearing + removal recommendation within 5 days; Tier 3 = immediate removal without hearing pending investigation.
- Create a zone-conduct acknowledgment form (one-page) specifying boundary location, prohibited activities (unauthorized photography, access beyond marked lines, collection of workload data), escalation procedures, and consequences. Every inspector signs before deployment (Month 6 = 2027-04-08).
- Lock the protocol in the bilateral instrument by Month 2 (2026-12-08); publish to inspectors by Month 3 (2027-01-08).

**Approval Authorities:** Both co-chairs approve the protocol in the bilateral instrument by Month 1 (2026-11-08); bilateral conduct committee implements and investigates infractions.

### 14. Counterintelligence Vetting Acceleration Plan and Expedited-Clearance Request

**ID:** 50622309-9aa0-411d-a590-8898d75f96fd

**Description:** Request to both countries' counterintelligence services to vet 120–150 candidate inspectors per country on an expedited 14–16 week schedule (starting Month 0.5 = 2026-10-23, completing by Month 4.5 = 2027-02-23 at latest to support Month 5 = 2027-03-08 roster approval). Identifies vetting standards, counterpart-approval procedures (veto right), replacement-bench surge (20–30% additional pre-vetted candidates), and fallback conditional-start authority if vetting is not complete by Month 5 (2027-03-08). Document type: government process request and acceleration plan; audience: counterintelligence agencies, co-chairs, bilateral vetting coordinator; critical path bottleneck.

**Responsible Role Type:** Bilateral Vetting Coordinator and Counterintelligence Liaison

**Secondary Template:** Government Personnel Security Clearance Expedited Review Request

**Steps:**

- By Month 0 (2026-10-08), bilateral vetting coordinator provides both countries' counterintelligence services with the list of 120–150 candidate inspectors per country, along with justification (bilateral verification program, 14-week vetting window, start date Month 5 = 2027-03-08).
- Request expedited vetting: provide clear vetting standards (counterintelligence, security-clearance level, polygraphy, background investigation, travel history, foreign contacts).
- Establish counterpart-approval procedure: once vetted, candidates from Country A are sent to Country B's counterintelligence for veto-right review (5 working days); failure to object = approval.
- Request joint designation of a vetting liaison from each country to coordinate progress and escalate bottlenecks weekly.
- Identify a surge bench of 20–30% additional candidates per country and include them in the vetting queue; these serve as replacement pool if primary roster has attrition.
- If vetting is not 80% complete by Month 4.5 (2027-02-23), activate the conditional-start fallback: allow Phase One to begin with 80% approved roster and 20% provisional (subject to counterpart veto), with final vetted rosters catching up during Month 6 (2027-04-08).

**Approval Authorities:** Both countries' counterintelligence agencies execute vetting; bilateral conduct committee approves or vetoes counterpart candidates; co-chairs certify 80% roster approval by Month 5 (2027-03-08).

### 15. Joint Bilateral Inspector Conduct Committee Charter and Monthly Review Procedure

**ID:** 900537da-0c7d-47ba-8806-e36167aba73f

**Description:** Charter establishing the bilateral conduct committee with equal national co-chairs, authority to approve/veto counterpart inspectors (5-day turnaround), investigate misconduct (48-hour preliminary), recommend action (72-hour finding), and implement the three-tier infraction protocol. Includes continuous access-log audit procedures (monthly review by independent auditor per country within 10 days) and quarterly inspector-rotation schedule to prevent site-specific familiarity and espionage capture. Document type: governance charter; audience: conduct committee members, inspectors, counterintelligence liaisons, co-chairs; ensures mutual inspector trust.

**Responsible Role Type:** Bilateral Conduct Committee Co-Chair and Access-Log Audit Specialist

**Primary Template:** Personnel Review Committee Charter (IAEA Inspector Conduct, adapted)

**Steps:**

- By Month 1 (2026-11-08), both co-chairs appoint equal-rank national conduct-committee co-chairs, typically a senior counterintelligence or security officer.
- Draft charter specifying: committee composition (2 co-chairs + 1-2 technical advisors per country), decision authority (consensus for approval, co-chair signature for discipline), meeting frequency (monthly routine, 48-hour emergency convening).
- Define inspector-approval process: each government nominates inspectors; counterpart has 5 working days to approve or veto without detailed justification (security grounds acceptable).
- Specify misconduct investigation: allegation triggers a preliminary assessment within 48 hours; full investigation (if warranted) within 5–7 days; disciplinary hearing (if Tier 2) within 5 working days; decision within 72 hours.
- Establish access-log audit: every inspector wears a proximity badge; monthly (within 10 days of month-end), an independent auditor from each country reviews badge swipes, zone entry/exit logs, and compared actual times against inspector activity logs. Any discrepancy >15 minutes investigated within 24 hours.
- Define quarterly rotation: every inspector rotates to a different site every 3 months; rosters are randomly drawn so neither inspectors nor operators can predict assignments.
- Lock the charter in the bilateral instrument by Month 1 (2026-11-08); conduct committee begins monthly meetings starting Month 5 (2027-03-08).

**Approval Authorities:** Both co-chairs appoint conduct-committee co-chairs by Month 1 (2026-11-08); bilateral conduct committee conducts operationally from Month 5 (2027-03-08).

### 16. Pre-Test Calibration Exercise Scenario Suite and Detection-Performance Measurement Protocol

**ID:** f8c661c1-c6d0-4701-92fb-a7da5475fe31

**Description:** 100–150 non-covered equipment units per site reserved for calibration (Months 4–5 = 2027-02-08 to 2027-03-08), with 50–100 blind-challenge events per site covering: ≥10 unreported-arrival scenarios, ≥10 equipment-substitution scenarios (including internal modification), ≥10 record-falsification scenarios, ≥5 vendor-refusal scenarios, ≥5 reluctant-operator scenarios. Specifies blind-exercise methodology (sealed double-key schedule, minimal advance notice), detection-success metrics (change recorded in ledger within 48 hours), false-positive and false-negative measurement, and unverifiable-equipment counting. Document type: testing protocol; audience: independent testing unit, inspectors, operators, technical leads, co-chairs; validates thresholds before formal 90-day test.

**Responsible Role Type:** Independent Testing Unit Director and Detection-Performance Analyst

**Primary Template:** Experimental Design and Measurement Protocol (NIST/ASTM Standard)

**Steps:**

- By Month 1 (2026-11-08), commission the independent testing unit to design scenario templates for each of the 7 event types (unreported arrival, substitution, record falsification, delayed access, disputed identity, vendor refusal, reluctant operator), with realistic parameters drawn from Phase One expectations.
- Reserve 100–150 surplus/refurbished non-covered equipment units per site by Month 1.5 (2026-11-23); confirm operator agreement to use these units for calibration.
- Design a sealed double-key schedule: exercise dates and scenarios drawn at random, sealed in two encrypted envelopes (one per country), opened only when the exercise executes. This prevents advance preparation.
- Define detection-success metrics: change detected = entry appears in both national ledgers within 48 hours, with identity confirmed by the corroboration rule (at least 2 independent layers agree). False positive = reported change that did not occur (change logged but no actual event). False negative = actual change not detected in ledger.
- Specify scoring: for each event type, count true positives (detected), false negatives (missed), false positives (spurious), and cases where equipment is unverifiable (vendor refusal or insufficient evidence). Calculate rates: detection = TP / (TP + FN); false positive rate = FP / (FP + true negatives, estimated from background event rate).
- Execute calibration Months 4–5 (2027-02-08 to 2027-03-08) at each site; document raw results by event type and site.
- Publish calibration results (detection rates, FP/FN, unverifiable counts, confidence intervals) to both co-chairs by Month 5 (2027-03-08).
- Adjust provisional thresholds based on calibration evidence by Month 5.5 (2027-03-23).

**Approval Authorities:** Independent testing unit director designs and executes calibration; bilateral technical leads and co-chairs review results and approve threshold adjustments by Month 5.5 (2027-03-23).

### 17. Provisional Go/Modify/Stop Thresholds and Decision Rubric

**ID:** 16a76b6c-f3a7-4022-a4de-e284f9dbda1b

**Description:** Locked decision thresholds specifying: Go requires detection ≥90% unreported arrivals, ≥85% substitutions, ≥80% record falsification, false positives <5%, reciprocal-access parity within 20%, unresolved discrepancies <10% of events, unverifiable equipment <5% per site, zero unresolved ledger divergence >7 days. Modify requires correctable weakness (detection 70–90%, unverifiable 5–10%, fixable by training/procedure); Stop requires asymmetric access, unverifiable >10%, ledger divergence unreconciled, funding withheld, or detection <70%. All thresholds documented with justification (source: calibration exercise, prior program benchmark, expert judgment), validation method, and provisional-vs.-validated status. Includes tie-breaking rule if co-chairs deadlock on Go/Modify. Document type: decision framework; audience: co-chairs, bilateral technical leads, independent testing unit, neutral referee panel; prevents post-hoc threshold reinterpretation.

**Responsible Role Type:** Bilateral Technical Lead and Decision-Framework Designer

**Primary Template:** Decision Criteria and Scoring Rubric (PMI/PRINCE2 Gate Criteria)

**Steps:**

- By Month 3 (2027-01-08), compile proposed detection thresholds from prior bilateral verification programs (New START, OPCW, IAEA experience) and expert judgment on realistic detection performance against intelligent adversaries. Default proposal: 90% unreported, 85% substitution, 80% record falsification.
- Document the source and assumption for each threshold (e.g., '90% unreported arrivals: based on IAEA prior-notice-inspection detection rates in 50+ global nuclear facilities; assumes inspectors have <2-hour arrival notification').
- Mark each threshold as 'provisional' if not yet validated by calibration, or 'estimated' if from prior programs.
- Execute calibration Months 4–5 (2027-02-08 to 2027-03-08); collect actual detection data by event type.
- By Month 5 (2027-03-08), reconcile calibration results against provisional thresholds: if actual detection is >10% above provisional (e.g., 92% vs. 90% proposed), validate the provisional value; if detection is >10% below (e.g., 78% vs. 90% proposed), flag as 'threshold mis-set' and recommend recalibration.
- By Month 5.5 (2027-03-23), both co-chairs jointly sign the final-decision rubric confirming: Go criteria (all thresholds met), Modify criteria (correctable weakness), Stop criteria (asymmetry, funding, >10% unverifiable, <70% detection). Include a tie-breaking rule: if one co-chair votes Go and the other Modify, the more conservative Modify outcome is adopted unless the neutral referee panel votes unanimously for Go within 48 hours.
- Lock the rubric in the bilateral instrument; mark as 'calibrated and validated' in the ledger.

**Approval Authorities:** Both co-chairs jointly sign the rubric by double-key by Month 5.5 (2027-03-23); no changes to thresholds or criteria thereafter except through recorded protocol amendment.

### 18. Independent Testing Unit Charter and Sealed Double-Key Exercise Schedule

**ID:** 7e4651eb-d555-43c6-8f03-913f133fabbf

**Description:** Charter for the independent testing unit (neutral-country staffing or third-party organization, no direct national loyalty), specifying governance (both co-chairs appoint members but have no veto), scenario-design authority (sealed double-key mechanism prevents either government from knowing exercise timing in advance), scoring methodology (fixed pre-agreed rubric, both co-chairs attest to fairness), and result archiving (confidential until final decision, then disclosed to both co-chairs simultaneously). Includes sealed-schedule encryption procedures (two encrypted envelopes per scenario, opened only when exercise executes), fairness peer-review by red teams from both countries (certifying scenarios are realistic and unbiased), and monthly exercise-execution log. Document type: governance and procedural charter; audience: independent testing unit, co-chairs, bilateral technical leads; prevents exercise bias and maintains Go/Modify/Stop verdict credibility.

**Responsible Role Type:** Independent Testing Unit Director and Neutral-Country Representative

**Primary Template:** Independent Test Authority Charter (ISO/IEC Standard)

**Steps:**

- By Month 0.5 (2026-10-23), both co-chairs jointly appoint the independent testing unit director and core staff (20–30 people), preferably from a neutral third country with no bilateral stake (e.g., Switzerland, Sweden, Canada). No unilateral appointment or veto by either government.
- Draft charter specifying: independence (no national loyalty, no briefings to either government until final decision), scenario design (both red teams review for fairness before execution), sealed-schedule mechanism (two encrypted-key envelopes, one per co-chair, opened simultaneously during the exercise), scoring (fixed rubric, documented result, witness signatures), and result confidentiality (results disclosed only after final decision to avoid mid-test pressure).
- Specify fairness peer-review: before each exercise, both countries' red teams receive a copy of the scenario and a fairness-review rubric; they certify (separately) that the scenario is realistic, unbiased, and comparable to exercises they have designed for their own inspectors. If either red team objects, the scenario is revised or deferred.
- Design the sealed double-key schedule mechanism: each scenario is encrypted using a different AES-256 key; Country A's co-chair holds Key A (half of the pair), Country B holds Key B. To execute an exercise, both keys must be provided, decrypting the scenario. Neither country alone can trigger or modify an exercise.
- Specify monthly exercise-execution log: public disclosure (after Phase One) of all exercises run, their dates, outcomes (detection rates), and fairness-review results.
- Lock the charter in the bilateral instrument by Month 1 (2026-11-08).

**Approval Authorities:** Both co-chairs jointly appoint the independent testing unit director by Month 1 (2026-11-08); testing unit operates under its own charter, reporting results to co-chairs only after Phase One ends.

### 19. Phase One Blind-Challenge Exercise Schedule and Event-Type Coverage Plan

**ID:** 2599b3ff-b4bc-45cd-b059-238ac36aca6b

**Description:** Sealed double-key schedule of Phase One blind exercises (Months 6–9 = 2027-04-08 to 2027-07-08), with at most 2 sessions per site per month, total ~24 exercises across 4 sites, covering all 7 event types (unreported arrival, substitution, record falsification, delayed access, disputed identity, vendor refusal, reluctant operator). Schedule specifies: execution dates (drawn from sealed envelopes), equipment or scenario identifiers, expected inspector-detection response, and redaction/audit procedures. Confirms all exercises occur in staging, spare-inventory, maintenance, or expansion areas; zero interruption of active computation. Includes contingency for exercise postponement due to production conflicts (reschedule within 2 weeks). Document type: operational schedule and execution plan; audience: independent testing unit, site operators, inspectors, co-chairs; governs Phase One credibility.

**Responsible Role Type:** Independent Testing Unit Director and Site Operations Coordinator

**Secondary Template:** Test Execution Schedule (ISO/IEC 62304 Software Testing Standard)

**Steps:**

- By Month 3 (2027-01-08), the independent testing unit designs exercise templates for each of 7 event types, with realistic parameters (e.g., unreported arrival = equipment arrives at site without advance manifest entry; substitution = identical external ID with modified internals).
- Generate a pool of ~30 potential exercises (~4 per site x 7 types, plus 2 spares per site); randomize order and assign execution dates uniformly across Months 6–9 (2027-04-08 to 2027-07-08), aiming for 2 per site per month (never more than 2 in consecutive weeks).
- Encrypt each exercise scenario and its expected outcome (detection success, equipment IDs involved, inspector response latency) using split-key mechanism: Co-Chair A's key encrypts half the metadata, Co-Chair B's key encrypts the other half. Neither can read the full scenario until both keys are provided.
- Produce a sealed double-key schedule document: one encrypted envelope per co-chair, locked in tamper-evident seals. Both envelopes remain in secure custody until exercise execution.
- Coordinate with site operators to identify preferred exercise windows (Months 6–9 = 2027-04-08 to 2027-07-08), avoiding critical production schedules. Reserve staging, spare-inventory, maintenance, and expansion areas exclusively for exercises.
- Specify postponement rules: if an exercise must be postponed due to production conflicts, reschedule within 2 weeks; document the reason in the ledger.
- By Month 5.5 (2027-03-23), finalize the sealed schedule; both co-chairs acknowledge receipt of their encrypted envelopes and attest to the seals' integrity.

**Approval Authorities:** Independent testing unit director designs the schedule; both co-chairs jointly certify seal integrity by Month 5.5 (2027-03-23); testing unit executes exercises under sealed-schedule authority.

### 20. Covered-Equipment Schedule Lock Certificate and Amendment Protocol

**ID:** 096e39bf-acda-4ed4-9f1b-24d5439075d7

**Description:** Confidential, manufacturer-neutral, versioned schedule of equipment classes subject to verification (e.g., GPU, FPGA, custom ASIC, accelerator interconnect), with functional-risk-based criteria (top 5% by performance metric, frontier-relevant designation). Schedule is adopted and frozen at Month 3 (2027-01-08) via double-key signature on a 'Schedule Lock Certificate' stating the schedule is complete, will not be amended until after the final decision (Month 10 = 2027-08-08), and any mid-test amendment requests are denied and logged. Protocol specifies amendment-request procedures post-decision (Month 10 = 2027-08-08 onwards) and for Phase Two (if approved). Document type: scope control and confidential asset; audience: bilateral technical leads, co-chairs, operators, independent testing unit; prevents threshold-gaming through scope creep or contraction.

**Responsible Role Type:** Bilateral Technical Lead and Equipment-Schedule Custodian

**Primary Template:** Configuration Control and Change-Management Plan (PMI PMBOK)

**Steps:**

- By Month 2 (2026-12-08), convene both countries' technical equipment specialists to draft the covered-equipment schedule using a functional-risk taxonomy: equipment in the top 5% by compute density (FLOPS per Watt), training throughput, or inference latency in the prior 12 months is designated frontier-relevant.
- Ensure the schedule is manufacturer-neutral and product-neutral: list equipment classes (GPU, FPGA, custom accelerator) with functional specs, not product names. Example: 'AI accelerator with >100 TFLOPS FP32 compute' rather than 'NVIDIA H100.'
- Include physical equipment identifiers (serial numbers, MAC addresses, cryptographic device IDs) for equipment already at participating sites at Month 2 (2026-12-08); confidential annex.
- Classify the schedule as confidential bilateral document; both governments hold identical versions with cryptographic attestation.
- Lock the schedule via double-key signature (Schedule Lock Certificate) by Month 3 (2027-01-08), stating: (a) the schedule is complete; (b) no amendments are permitted during Phase One; (c) any mid-test amendment requests are formally logged and denied; (d) amendments are possible post-decision (Month 10 = 2027-08-08 onwards) only by double-key protocol change.
- Document every mid-test amendment request in the ledger with the requestor, reason, and decision (denied).
- Maintain the schedule in a secure repository accessible to both national ledger custodians and the independent testing unit for exercise design reference.

**Approval Authorities:** Both co-chairs jointly sign the Schedule Lock Certificate by Month 3 (2027-01-08); bilateral technical leads maintain the schedule; any post-Phase-One amendments require double-key protocol change.

### 21. Maintenance and Third-Party Access Scheduling Protocol and Emergency-Response Procedures

**ID:** 1b37885a-8617-4c3f-a076-765f6dc77a84

**Description:** Rules governing operator notification of maintenance, repair, and vendor visits within inspection zones (staging, spare-inventory, maintenance, expansion areas): advance notice required (target 5–10 business days), inspectors present at start and end of each maintenance window, sealed work areas during maintenance (operators conduct work, inspectors observe from designated areas), and continuous recording of maintenance activities. Defines emergency-response procedure: operator may proceed immediately for repairs restoring a failed system within 4 hours (e.g., power-supply replacement), but must file a continuous recording and post-event inspector review within 24 hours. Specifies abuse control: >3 emergency claims per site per month triggers independent technical review; >50% ruled non-emergency triggers escalation to co-chairs. Document type: operational procedure; audience: operators, inspectors, bilateral maintenance coordinators; balances uptime protection with visibility of hardware changes.

**Responsible Role Type:** Bilateral Maintenance Coordinator and Operator Compliance Officer

**Secondary Template:** Work-Order and Scheduled-Maintenance Procedure (ISO 9001 Quality Standard)

**Steps:**

- By Month 2 (2026-12-08), draft the maintenance scheduling rules specifying: advance-notice requirement (5–10 business days), inspector notification (site contact list), staffing (mirrored inspectors present at start/end), escort procedures (operator work in sealed areas, inspectors view from designated observation points), and recording (continuous video of maintenance zone showing equipment movement and any replacements).
- Define emergency procedures: operator may bypass advance-notice requirement only if a critical system (power supply, cooling, network connectivity essential for Consortium operations) has failed and repair is needed within 4 hours to prevent data loss or compute shutdown. Emergency claim requires continuous recording and a post-event report within 24 hours with technical justification.
- Establish abuse controls: count emergency claims monthly; if any site claims >3 per month, bilateral maintenance coordinator conducts a technical audit of the claimed failures; if >50% are ruled non-emergency (deferred work misclassified as emergency), the operator faces escalation (written notice, review of future emergency claims, potential Tier 2 conduct violation).
- Specify maintenance-event logging: every maintenance window and emergency claim logged in both national ledgers with: date, time, system affected, work performed, inspector names, and outcome (system restored, replacement parts used, etc.).
- Lock the protocol in the bilateral instrument by Month 1 (2026-11-08); publish to operators by Month 2 (2026-12-08).

**Approval Authorities:** Both co-chairs approve the protocol in the bilateral instrument by Month 1 (2026-11-08); bilateral maintenance coordinator enforces abuse controls and escalates violations to co-chairs.

### 22. Exit-Disposition Protocol and Departure-Event Witnessing Plan

**ID:** 052dbef7-b5b9-4503-9c1f-b6c5d70e5c2c

**Description:** Procedure assigning every departure of equipment from a participating site to one of five dispositions: (1) witnessed destruction (inspector present at destruction facility, verified permanent disablement); (2) verified permanent disablement (modified hardware certified unusable, locked in secure storage pending destruction, inspector audit quarterly); (3) transfer to another participating site (witnessed handoff, ledger entry at receiving site); (4) documented release beyond the monitored system (operator sign-off with vendor receipt, transfer-of-custody form); (5) unresolved (no evidence obtained within 10 days post-departure). Tiered witnessing standard: Tier 1 requires full end-to-end inspector presence; Tier 2 requires witnessed site exit + receiving-party acknowledgment; Tier 3 accepts operator documentation. For random sample of Tier 3 releases (20–30% per month), conduct post-release verification call to receiving party. Document type: operational protocol; audience: operators, inspectors, logistics providers, exit auditors; prevents re-entry of undisclosed equipment.

**Responsible Role Type:** Exit-Protocol Coordinator and Logistics Auditor

**Secondary Template:** Chain-of-Custody Procedure (US DoD Property Management Standard)

**Steps:**

- By Month 2 (2026-12-08), draft the tiered exit-witnessing standard: Tier 1 (destruction/disablement) requires inspector presence at the destruction facility or independent certification from an accredited recycler; Tier 2 (transfer to another site) requires witnessed handoff at departure and arrival; Tier 3 (documented release) accepts operator signature with vendor receipt and transfer-of-custody form.
- Define disposition-assignment timeline: every departure must be assigned to a final disposition within 10 days of equipment removal from the site; if evidence is not obtained by day 10, the disposition is marked 'unresolved,' which triggers escalation and counts toward the 'unresolved discrepancies' KPI.
- Specify Tier 1 procedures: operator notifies inspectors of a scheduled destruction event ≥5 business days in advance; at least one inspector from each country (bilateral pair) attends the destruction; they verify the equipment's identity pre-destruction, witness the destruction process, and obtain a destruction certificate from the facility. Chain-of-custody signed by inspectors and facility operator.
- For Tier 2 (transfer): operator notifies both inspectors of an inter-site transfer; inspectors confirm the equipment identity and seal status at departure, verify receipt at the receiving site (via video call or in-person, depending on geography), and both sites' ledger entries are cross-linked.
- For Tier 3 (release beyond monitored system): operator completes a departure form specifying equipment ID, receiving party (vendor, customer, logistics firm), release date, and operator authorization. Inspector audits the form completeness. For a random sample (20–30% monthly), coordinator calls the receiving party to verify receipt and current status; results logged in the ledger.
- Specify unresolved disposition: if no evidence is provided by day 10, the equipment is marked 'unresolved' and escalated; unresolved departures count toward the 'unresolved discrepancies' KPI (target <10%).
- Lock the protocol in the bilateral instrument by Month 1 (2026-11-08); operators and inspectors trained by Month 5 (2027-03-08).

**Approval Authorities:** Both co-chairs approve the protocol in the bilateral instrument by Month 1 (2026-11-08); exit-protocol coordinator manages dispositions and verification calls; inspectors certify Tier 1/2 dispositions.

### 23. Phase One Entry-Condition Certification Procedure and Bilateral Readiness Checklist

**ID:** 2b32208f-d7cc-4c70-8b35-f0c3b803e349

**Description:** Bilateral formal procedure to certify that all 7 mandatory entry conditions are fully satisfied (instrument ratified, sites selected and ratified, appropriations secured, domestic access authority enacted, operators and vendors bound, inspectors approved, equipment schedule locked) before issuing the official Phase One clock-start authorization. Includes a 100-item bilateral readiness checklist (ledger operational, forensic panel staffed, exercises designed, thresholds locked, boundary marked, access control installed, conduct rules published, etc.) requiring independent verification by both countries and final sign-off by both co-chairs. Document type: certification and audit procedure; audience: co-chairs, bilateral audit teams, domestic authorities; prevents clock start before setup is complete.

**Responsible Role Type:** Bilateral Program Manager and Independent Audit Team Lead

**Primary Template:** Project Readiness Review and Gate Certification (PMI PMBOK)

**Steps:**

- By Month 5 (2027-03-08), assemble a bilateral readiness-audit team (2–3 senior personnel per country, independent of day-to-day operations) to conduct the Phase One entry-condition and readiness certification.
- Develop a 100-item bilateral readiness checklist covering: (a) entry conditions (instrument signature, site selection, appropriations, authority, operator/vendor agreements, inspector approval, schedule lock); (b) operational systems (ledger operational and stress-tested, forensic panel staffed and trained, access control gates installed and logged, forensic-identity divergence-detection validated); (c) procedures (shift-boundary cross-signing rehearsed, maintenance scheduling tested, exit-disposition procedures drafted and socialized, three-tier infraction protocol published); (d) personnel (inspectors inducted, briefed on zone conduct, assigned to sites, surge bench in place); (e) exercises (calibration completed, thresholds validated, Phase One exercise schedule sealed, blind-exercise procedures rehearsed).
- Conduct bilateral readiness review at Month 5.5 (2027-03-23): each country's audit team independently verifies 50 items, then both teams jointly verify the final 50 items at a bilateral readiness meeting.
- If any item is non-conforming, document the gap, assign a corrective action, and set a completion date (target: all gaps closed by Month 6 = 2027-04-08).
- By Month 6 (2027-04-08 09:00 UTC), issue a bilateral readiness report certifying that all 100 items are satisfied (or documenting any residual gaps and their impact on Phase One credibility).
- Both co-chairs jointly sign the Phase One Entry-Condition Certification by Month 6 (2027-04-08 16:00 UTC), authorizing the official clock start.
- Publish a summary (unclassified) of the certification result (e.g., 'All 100 entry-condition and readiness items certified; Phase One begins Month 6, 2027-04-08').

**Approval Authorities:** Both countries' independent audit teams verify readiness; both co-chairs jointly sign the certification by Month 6 (2027-04-08); any unresolved gaps are escalated to co-chairs with a decision to proceed, defer, or modify scope.

### 24. Go/Modify/Stop Final Decision Report and Verdict Justification

**ID:** 1d4a7e80-a6dc-459d-816c-f35afacb832c

**Description:** Bilateral final report issued by both co-chairs at Month 10 (2027-08-08) summarizing all Phase One evidence, threshold performance, and the joint Go/Modify/Stop verdict with full justification. Report includes: blind-challenge detection rates by event type and site (with confidence intervals), false-positive and false-negative counts, reciprocal-access parity metrics, unverifiable-equipment counts, unresolved discrepancies, ledger-divergence incidents and their resolutions, vendor refusals and fallback outcomes, IP/counterintelligence incidents (if any), and contingency spending. Verdict justifies which Go/Modify/Stop criteria were met or not met, how tied or borderline cases were resolved, and any caveats or cautions about the mechanism's performance. Report is classified initially; an unclassified executive summary is released within 6 months. Document type: final decision and public accountability report; audience: both governments' leadership, legislatures, public; concludes Phase One and justifies Phase Two or termination decision.

**Responsible Role Type:** Bilateral Decision Report Compiler and Policy Advisor

**Primary Template:** Final Project Report and Decision Rationale (Audit Standard)

**Steps:**

- Throughout Phase One (Months 6–9 = 2027-04-08 to 2027-07-08), both national teams compile evidence: blind-challenge detection results, ledger-divergence incidents and forensic resolutions, vendor-refusal escalations and outcomes, inspector misconduct investigations, and contingency spending.
- By Month 9.5 (2027-07-23), both co-chairs' analytic teams produce a draft final report containing all evidence and preliminary findings (detection rates, parity, thresholds met/missed, incidents and resolutions).
- By Month 10 (2027-08-08), both co-chairs jointly review the draft, discuss any interpretation disagreements, and issue a final joint verdict.
- If both co-chairs agree on the verdict (Go, Modify, or Stop), they jointly sign the final report.
- If they disagree (e.g., one says Go, the other says Modify), apply the tie-breaking rule: more conservative outcome (Modify) is adopted unless the neutral referee panel votes unanimously for the optimistic outcome (Go) within 48 hours.
- Final report includes: (a) executive summary (1–2 pages) stating the verdict and top 3–5 supporting findings; (b) detailed results table (detection by event type, parity, unverifiable, discrepancies, divergences); (c) incident summaries (vendor refusals, IP/CI incidents, zone violations, ledger divergences) with resolutions; (d) contingency spending summary; (e) justification of the verdict against the pre-locked thresholds; (f) any caveats or recommendations for Phase Two.
- Classify the full report; release an unclassified executive summary to public and legislatures within 6 months of Month 10 (2027-08-08), approximately by Month 16 (2028-02-08).

**Approval Authorities:** Both co-chairs jointly sign the final report by Month 10 (2027-08-08); domestic governments receive classified full report; public receives unclassified summary within 6 months.

### 25. Funding Timeliness and Contingency-Release Governance Framework

**ID:** 884edf00-d432-4d4e-b08b-1dcfbc53b36c

**Description:** Bilateral governance structure and procedural rules governing the USD 5.0B appropriations, USD 2.5B per country, and USD 500M contingency reserve. Specifies: each government must fund its tranche within 45 days of fiscal-year start; variance >5% in Months 0–3 (2026-10-08 to 2027-01-08) triggers escalation; tranche late beyond 75 days (45 + 30-day cure) counts as funding withheld (a Stop trigger). Contingency release requires double-key co-chair authorization; fast lane up to USD 50M per side on joint signature within 5 business days. Contingency sub-envelopes: USD 200M for gate delay, USD 150M for site replacement, USD 100M for vendor fallbacks, USD 50M for surge/exercises. Monthly fiscal-accountability reporting to both treasuries. Document type: financial governance and accountability framework; audience: both countries' treasuries, co-chairs, budget working group, auditors; ensures continuous funding and contingency visibility.

**Responsible Role Type:** Bilateral Budget Director and Fiscal Accountability Officer

**Primary Template:** Government Budget Execution and Contingency Management Procedures

**Steps:**

- By Month 0 (2026-10-08), establish a bilateral budget working group with representatives from both countries' finance ministries, co-chairs' offices, and the Consortium program manager.
- Draft the funding-timeliness governance procedures specifying: tranche schedule (each government obligates its USD 2.5B by 45 days into the fiscal year), variance thresholds (>5% variance in Months 0–3 = 2026-10-08 to 2027-01-08 triggers escalation to co-chairs), cure period (30 days to correct variance), and Stop trigger (funding withheld >75 days total).
- Design contingency-release procedures: (a) fast-lane release up to USD 50M per side (USD 100M total) on joint co-chair signature within 5 business days, no veto; (b) releases >USD 50M per side require formal co-chair agreement within 48 hours; (c) if co-chairs deadlock on a release decision >USD 50M, escalate to neutral referee panel for a non-binding opinion within 5 days, then co-chairs re-vote.
- Define contingency sub-envelopes within the USD 500M reserve: (1) gate delay costs (USD 200M, released on monthly assessment if entry conditions slip); (2) site replacement (USD 150M, released if operator withdraws); (3) vendor-refusal fallbacks/examiners (USD 100M, released if vendors exceed quota; (4) surge/exercises (USD 50M, released for contingency exercises or emergency personnel).
- Establish monthly fiscal-accountability reporting: by the 10th of each month, both countries' finance teams submit a spending report (actual vs. planned, variance analysis, contingency burn) to the bilateral budget working group and both co-chairs.
- Lock the governance framework in the bilateral instrument by Month 1 (2026-11-08); publish financial reporting timelines to both treasuries by Month 2 (2026-12-08).

**Approval Authorities:** Both co-chairs jointly authorize contingency releases >USD 50M per side; both countries' finance ministries authorize their tranches; bilateral budget working group monitors timeliness and variance monthly.

### 26. Monthly Contingency Burn-Rate Tracking Report and Variance Analysis

**ID:** bab55534-f96e-4214-ba5d-c699a47f9345

**Description:** Monthly report (by 10th of each month) submitted to both co-chairs and bilateral budget working group, tracking actual contingency spending against the sub-envelope allocations (USD 200M gate delay, USD 150M site replacement, USD 100M vendor fallbacks, USD 50M surge/exercises). Includes: actual spend by category, variance from planned burn rate (flagged red if >10% variance), commitments pending payment, and remaining reserve balance. Document type: financial management and variance-tracking report; audience: co-chairs, treasuries, bilateral budget team; enables real-time contingency-reserve visibility and early warning of insufficient reserve.

**Responsible Role Type:** Bilateral Budget Director and Contingency-Reserve Manager

**Primary Template:** Government Program Cost-Tracking and Variance Report Template

**Steps:**

- By Month 6 (2027-04-08), establish a contingency-tracking spreadsheet with rows for each sub-envelope and columns for: budgeted amount, actual spend to date, committed spend (pending), variance (amount and %), remaining balance, and flags (red/yellow/green).
- Designate a bilateral contingency manager responsible for collecting spend reports from both countries monthly (by 5th of each month).
- Reconcile reported spending with actual payments (verify both countries' treasury records match reported figures).
- Calculate variance: if actual + committed spend exceeds 120% of the budgeted sub-envelope, flag as red and escalate to co-chairs within 24 hours.
- Identify cost-containment measures if variance is trending high (e.g., defer non-critical testing, reduce surge staffing, renegotiate vendor contracts).
- Produce a written report by the 10th of each month summarizing: overall reserve status (% remaining), any red-flag line items, recommended corrective actions, and a 12-month contingency-burn forecast.

**Approval Authorities:** Bilateral budget director prepares report; both co-chairs review and approve corrective actions by the 15th of each month.

### 27. Weekly Entry-Conditions Tracking Dashboard and Status Update

**ID:** 2f348620-2fb0-4f8a-aed7-03bd26c70dc7

**Description:** Weekly dashboard (updated every Friday) tracking the completion percentage of each of the 7 entry conditions (instrument signature, site selection, appropriations, domestic access authority, operator/vendor binding, inspector approval, equipment schedule lock). Rows: entry condition name, baseline target date, current status (%), risk flag (red/yellow/green), owner, last update, and notes. Distributed to both co-chairs and bilateral entry-conditions steering committee by Friday 17:00 UTC. Flagged red if any item is >4 weeks behind baseline. Document type: project-tracking dashboard; audience: co-chairs, steering committee, domestic leads; enables rapid escalation of delays.

**Responsible Role Type:** Bilateral Program Manager and Entry-Conditions Tracking Officer

**Primary Template:** Project Status Dashboard (PMI PMBOK)

**Steps:**

- By Month 0 (2026-10-08), create a master spreadsheet with 7 rows (one per entry condition) and columns for: condition name, baseline target date, current completion %, owner, last-update date (time-stamped), risk flag (red/yellow/green criteria: green <2 weeks late, yellow 2–4 weeks late, red >4 weeks late), and notes field for blockers/mitigation.
- Assign an owner per condition (e.g., 'instrument signature' owned by bilateral legal counsel; 'domestic authority' owned by each country's named lead).
- Collect status updates from all owners by Thursday 16:00 UTC each week; owners provide estimated completion date and any blockers.
- Update the dashboard Friday morning; apply color flags (green/yellow/red) based on variance from baseline target.
- Distribute the dashboard to both co-chairs and steering committee by Friday 17:00 UTC.
- If any item is flagged red (>4 weeks late), include a mitigation proposal in the notes field and schedule a steering committee follow-up call for the following Monday.

**Approval Authorities:** Bilateral program manager maintains the dashboard; both co-chairs review weekly and authorize corrective actions or timeline extensions.

### 28. Inspector Roster and Critical-Post Fill-Rate Tracking

**ID:** 422bc877-fee7-494d-8c8a-2c6d2bf82d58

**Description:** Monthly roster tracking (updated by 5th of each month) showing approved inspector names, assignment to sites, security-clearance status (cleared, pending, rejected, deferred), leave schedule, and surge-bench fill rate. Includes: total planned roster (e.g., 217 per country), actual approved count, pending vetting count, vacancy list, and monthly turnover/attrition rate. Document type: personnel and staffing report; audience: co-chairs, conduct committee, site operations, counterintelligence liaisons; enables early identification of staffing gaps before Phase One.

**Responsible Role Type:** Bilateral Vetting Coordinator and Personnel Manager

**Primary Template:** Government Personnel Roster and Staffing Report

**Steps:**

- By Month 0.5 (2026-10-23), establish a confidential inspector roster database with columns: name, nationality/country, position (inspector, technician, lead, surge), site assignment, vetting status (clearance level, approval date, expiration), leave schedule (if applicable), and notes (performance issues, rotation history).
- Designate a bilateral personnel manager responsible for updating the roster monthly from both countries' counterintelligence and HR agencies.
- Define target roster size: 217 per country (total 434); critical-post fill requirement: 100% (shift leads, zone gatekeepers, ledger custodians); overall roster fill requirement by Month 5 (2027-03-08): ≥80%; surge-bench fill by Month 5 (2027-03-08): ≥20%.
- Produce a monthly report (by 5th) showing: actual approved count vs. target, vetting status breakdown (cleared, pending, rejected), vacancy list by position and site, recent approvals/denials, and any vetting delays >2 weeks.
- If critical posts are not 100% filled by Month 5 (2027-03-08), escalate to co-chairs; conditional-start fallback permits using probationary inspectors (subject to counterpart veto).

**Approval Authorities:** Bilateral vetting coordinator maintains the roster; bilateral conduct committee approves or vetoes counterpart inspectors; co-chairs certify roster fill-rate status by Month 5 (2027-03-08).

### 29. Ledger System Operational Test Report and Monthly Integrity-Verification Results

**ID:** 0ddadbc5-f9fa-4f05-aa87-73ce3c03c7aa

**Description:** Technical report issued after the Month 4 (2027-02-08) ledger stress test, documenting: system architecture, synchronization latency measurements, divergence-detection latency (target <2 hours), recovery times from simulated outages (target <6 hours), cryptographic-signature validation results, offline-backup recovery success, and any gaps requiring remediation. Monthly operational reports (Months 6–10 = 2027-04-08 to 2027-08-08) summarize: ledger sync latency, divergence incidents, forensic-panel findings, backup integrity checks, and zero records lost. Document type: technical operational report and quality assurance; audience: co-chairs, bilateral security teams, ledger operations; confirms ledger reliability before and during Phase One.

**Responsible Role Type:** Ledger Operations Lead and System Architect

**Primary Template:** IT System Operational Test Report and Certification

**Steps:**

- By Month 4 (2027-02-08), conduct a full ledger stress test: simulate an 8-hour network outage between national ledger copies; simulate a single-ledger system crash; simulate temporary unavailability of cryptographic keys. Document recovery time, ledger integrity upon recovery (hash validation), and records reconstructed from backup.
- Measure synchronization latency under normal operations (target <60 minutes); latency during high-load conditions (e.g., 50 simultaneous event entries per minute); and divergence-detection time (target <2 hours).
- Validate cryptographic signing: confirm that entries cannot be inserted or modified unilaterally by either country; only split-key authorization allows new entries.
- Produce a comprehensive stress-test report documenting all test scenarios, results, and any remediation items required before Phase One.
- Starting Month 6 (2027-04-08), produce monthly operational reports (by 15th of each month) summarizing: total new entries recorded, synchronization-latency distribution (mean, max, 95th percentile), divergence incidents (count and resolution time), forensic-panel findings issued, backup integrity checks (cryptographic hash validation), and zero operational failures.

**Approval Authorities:** Ledger operations lead prepares reports; bilateral security teams and co-chairs review stress-test results by Month 4 (2027-02-08) and certify operational readiness; monthly reports reviewed by co-chairs for any operational anomalies.

### 30. Monthly Vendor Refusal and Unverifiable-Equipment Log

**ID:** ae3deedb-8f25-4dca-a544-09715770c24c

**Description:** Operational log (updated continuously, summarized monthly by 15th) recording every vendor-refusal escalation, day-by-day progression through the day-0 to day-10 (or day-15 extended) ladder, examiner assignment, examination outcome (successful verification, unverifiable), and equipment unverifiable count by site. Includes: vendor name, equipment class, refusal date/reason, examiner assigned, examination date, result (verified/unverifiable), and final disposition. Monthly summary: total vendor refusals during month, average resolution time, examiner utilization, and running unverifiable count by site. Document type: operational/compliance log; audience: co-chairs, bilateral vendor-refusal coordinator, operations teams; tracks vendor-refusal trend and unverifiable-equipment accumulation.

**Responsible Role Type:** Bilateral Vendor-Refusal Coordinator and Equipment-Disposition Manager

**Primary Template:** Operational Incident and Resolution Log

**Steps:**

- By Month 6 (2027-04-08), establish a vendor-refusal escalation log as a shared database accessible to all site teams, bilateral coordinators, and the ledger system. Columns: refusal ID, date, vendor name, equipment class, reason for refusal, examiner assigned, day-0–10 timeline, outcome (verified/unverifiable), and notes.
- Designate a bilateral vendor-refusal coordinator responsible for tracking all escalations and ensuring day-10 deadlines are met; escalate any item approaching day 10 without resolution.
- Enter refusals into the ledger immediately upon reporting; track progress daily.
- By the 15th of each month, produce a summary report: count of refusals by vendor, average resolution time, examiner utilization (exams performed per examiner per month), unverifiable count by site, and trend analysis (is unverifiable count increasing, stable, or declining?).
- Flag sites with >5% unverifiable equipment by mid-Phase One (Month 8 = 2027-06-08); escalate to co-chairs with recommendation to accelerate threshold-decision timeline if trend continues.

**Approval Authorities:** Bilateral vendor-refusal coordinator maintains log; co-chairs monitor monthly summary and authorize corrective actions (e.g., additional examiner deployment, vendor penalty invocation).

### 31. Monthly Forensic-Panel Findings and Ledger-Divergence Resolution Summary

**ID:** df873bd4-91bd-477b-b535-8db957cc081a

**Description:** Monthly report (by 15th) summarizing all forensic-panel investigations completed during the month: divergence incidents (count, type, resolution time), panel findings issued, evidence-weighting rule applied per finding, deadlock escalations (if any), co-chair decisions (if panel deadlocked), and any incidents unresolved at month-end (with aging metrics). Includes: each divergence incident summary (date, description, layers of evidence evaluated, finding, time to resolution), and any lessons learned about divergence patterns or procedure gaps. Document type: forensic operations and quality-assurance report; audience: co-chairs, forensic panel, ledger operations, bilateral technical teams; tracks divergence trends and forensic-panel effectiveness.

**Responsible Role Type:** Forensic Panel Lead and Divergence-Resolution Coordinator

**Primary Template:** Incident Resolution and Root-Cause Analysis Report

**Steps:**

- By Month 6 (2027-04-08), designate a forensic panel coordinator responsible for tracking all divergence investigations and maintaining a monthly summary template.
- Record each divergence investigation in the forensic-panel log: date discovered, description (what diverged: timestamp, equipment ID, event type?), date escalated to forensic panel, panel members who reviewed, evidence layers evaluated (attestation, physical inspection, records, third-party logs), finding issued (if consensus reached), and resolution time (hours from discovery to finding).
- If panel deadlocked (members split on identity verdict), record: date deadlock escalated to co-chairs, co-chair discussion date, final decision (which evidence source accepted as authoritative), and justification.
- By the 15th of each month, compile a summary report: count of divergences investigated, count resolved within 48 hours, count requiring co-chair escalation, average resolution time, and any unresolved divergences aging >7 days (escalate these as impaired-confidence or suspension triggers immediately).
- Include a trend section: are divergences decreasing over time (improving ledger sync) or increasing (indicating systematic issues with synchronization, time-keeping, or event recording)? Recommend procedure changes if trends are negative.

**Approval Authorities:** Forensic panel lead prepares report; co-chairs review monthly and authorize any procedure changes to reduce divergence frequency.

### 32. Phase One Exercise Execution and Detection-Performance Log

**ID:** e0e99bac-340e-452c-add1-5f3370916839

**Description:** Operational log (updated in real time during exercises, summarized monthly) recording each blind-challenge exercise execution: date, exercise scenario (event type, equipment class, expected inspector response), site, execution outcome (detection success, detection failure, false positive, equipment unverifiable), inspector performance (detection latency, evidence layers recorded, forensic-panel involvement if identity disputed), and any operational incidents (zone violations, exercise postponement, production disruption). Monthly summary: count of exercises executed, detection rate by event type and site, false-positive and false-negative counts, operational incidents, and progress toward coverage targets (7 event types per site). Document type: exercise operational log and performance tracking; audience: independent testing unit, co-chairs, bilateral technical teams; tracks blind-challenge effectiveness and Phase One progress toward thresholds.

**Responsible Role Type:** Independent Testing Unit Director and Exercise-Operations Coordinator

**Primary Template:** Test Execution and Results Log (ISO/IEC Testing Standard)

**Steps:**

- By Month 5.5 (2027-03-23), establish an exercise log database shared between the independent testing unit, site operations, and co-chairs. Columns: exercise ID, date, event type (unreported arrival, substitution, record falsification, vendor refusal, delayed access, disputed identity, reluctant operator), equipment involved, site, sealed-schedule envelope (A or B), execution outcome (detected/not detected/unverifiable/FP), detection latency (hours from event to ledger entry), inspector names (if identifiable), and incident notes.
- During Phase One (Months 6–9 = 2027-04-08 to 2027-07-08), log each exercise in real time upon completion; no post-hoc changes to results (audit trail to prevent reinterpretation).
- Calculate detection metrics: detection = (true positives) / (true positives + false negatives); false-positive rate = (false positives) / (total negative events, estimated from background event rate); unverifiable = count of exercises where equipment could not be verified.
- By the 15th of each month during Phase One, produce an interim summary: exercises executed during the month, detection rate by event type (e.g., 'unreported arrivals: 12 tested, 11 detected = 92%'), false-positive incidents (if any), unverifiable-equipment events, and cumulative progress toward the calibrated thresholds.
- Track progress toward event-type coverage targets (goal: all 7 event types exercised at least once per site by Month 9 = 2027-07-08); flag any event type not yet tested by Month 8 (2027-06-08).

**Approval Authorities:** Independent testing unit director maintains log; co-chairs monitor monthly summary and adjust exercise schedule if detection is trending above/below thresholds.

### 33. Monthly Zone-Boundary Compliance and Inspector-Conduct Incident Report

**ID:** 3e88c9b4-d051-41de-a308-2c47c541aeef

**Description:** Monthly report (by 20th) summarizing inspector-conduct incidents, zone-boundary violations, access-log audits, and disciplinary actions taken. Incidents include: allegations of zone-boundary crossing (Tier 1–3), unauthorized information collection, espionage concerns, cooperation failures, and disciplinary outcomes. Report includes: count of incidents by tier, average investigation time, outcome by category (warning/retraining, removal, referral for criminal investigation), any unresolved incidents, and appeals or reversals. Access-log audit summary: number of badge-swipe discrepancies identified, average discrepancy magnitude, investigations completed, and any patterns suggesting systematic access-control gaps. Document type: conduct oversight and compliance report; audience: co-chairs, bilateral conduct committee, site security, counterintelligence; tracks inspector trustworthiness and zone-control effectiveness.

**Responsible Role Type:** Bilateral Conduct Committee Co-Chair and Access-Log Audit Specialist

**Primary Template:** Personnel Conduct and Compliance Report

**Steps:**

- By Month 6 (2027-04-08), establish an incident-tracking database for zone violations and conduct issues. Record: date of allegation, description, inspector name (confidential, anonymized in reports), site, incident category (zone crossing, unauthorized access, suspected espionage, cooperation failure, other), investigation start date, findings, disciplinary recommendation, and outcome.
- Establish an access-log audit workflow: monthly (within 10 days of month-end), independent auditors from each country review inspector badge-swipe logs and compare against claimed activities for any discrepancies >15 minutes. Document: number of audits completed, discrepancies found (count, average duration, explanations verified or unexplained), and investigations initiated.
- By the 20th of each month, compile a report summarizing: incident counts by category and tier (Tier 1/2/3), average investigation time, disciplinary outcomes, access-log audit results (discrepancy counts, investigation outcomes), any incidents trending (increasing vs. stable), and any patterns suggesting systemic issues (e.g., zone design flaw if boundary crossings are frequent at one location).
- Include any reversals or appeals of disciplinary actions (e.g., Tier 2 removal appeal upheld); document outcome and any changes to procedures resulting from the appeal.

**Approval Authorities:** Bilateral conduct committee co-chair prepares report; both co-chairs review and authorize corrective actions (e.g., zone redesign, inspector retraining, personnel changes).

## Documents to Find

### 1. US Congressional Authorization and Ratification Precedents (New START, IAEA, Chemical Weapons Convention)

**ID:** ff059db5-2e5d-478f-b507-6ba11dfd9a24

**Description:** Enacted US Congressional resolutions, treaties, and implementing legislation from comparable bilateral or international verification programs (New START Strategic Arms Reduction Treaty, US obligations under IAEA safeguards, Chemical Weapons Convention ratification). Source material type: legislative text and procedural records; purpose: informing US domestic authority decomposition, identifying legislative committees and timelines, understanding inspector immunity and access authority language. Intended audience: bilateral legal team, US State Department, US Congress co-chair staff.

**Recency Requirement:** Current enacted law; New START ratified 2010, still in effect; CWC ratified 1997; IAEA safeguards agreements executed by country (ongoing). Identify most recent Congressional action amending or extending authority (e.g., New START extension 2021, CWC amendments 2019+).

**Responsible Role Type:** Bilateral Legal Counsel and US Legislative Counsel

**Access Difficulty:** Easy. US Congress.gov is a public website; legislative text, committee reports, and floor records are publicly available. State Department materials are public or available via FOIA request (10–20 business days). CRS reports are available to Congress members or via their offices; can be obtained through Freedom of Information Act request.

**Steps:**

- Access US Congress.gov; search for New START Act (Public Law 111-129, 2010), IAEA protocols/agreements, and Chemical Weapons Convention Implementation Act (Public Law 105-277, 1998).
- Identify the legislative committees (US Senate Foreign Relations Committee, House Armed Services Committee) that handled ratification; review committee reports and floor debates for statutory language on inspector access, immunity, and evidence handling.
- Request the State Department's Arms Control, Verification, and Compliance Bureau for copies of bilateral agreements with IAEA and OPCW on inspection scope, inspector immunity, and evidence preservation.
- Consult the Congressional Research Service for legislative procedure guides and typical timelines for treaty ratification and implementing legislation (typically 4–8 weeks for ratification, 4–12 weeks for implementing bills).

### 2. China State Council Directive and Ministerial Governance Structure (Comparable Programs)

**ID:** e13c34ae-f828-453f-a706-f5808d8f4622

**Description:** Examples of State Council administrative directives or notices (guiding documents) delegating authority to ministries to compel enterprise participation in bilateral programs or international verification. Source material type: official Chinese government documents; purpose: understanding China's administrative process for delegation, identifying approving authorities (MIIT, NDRC, State Council), and realistic enactment timelines. Intended audience: bilateral legal team, Chinese co-chair staff, Chinese Ministry of Industry & Information Technology.

**Recency Requirement:** Current or recent (2015+) State Council directives related to international verification, technology regulation, or export control. IAEA safeguards agreements with China (current). Any bilateral verification arrangements with Russia, EU, or IAEA (current implementations).

**Responsible Role Type:** Chinese Legal Counsel and Ministry Liaison

**Access Difficulty:** Medium. Official State Council directives and MOFA materials are not systematically published online; access requires direct government liaison. IAEA agreements may be available via IAEA (iaea.org) or China's MOFA website. NDRC directives are sometimes published on ndrc.gov.cn. Bilateral legal teams with prior government relationships can request these materials via formal diplomatic note.

**Steps:**

- Request the Chinese Ministry of Foreign Affairs (MOFA) for precedents of bilateral verification agreements with other governments (e.g., IAEA agreements, Russia bilateral protocols) and the State Council directives authorizing Chinese participation.
- Contact the Ministry of Industry & Information Technology (MIIT) for any existing directives or regulations on technology verification, equipment tracking, or enterprise cooperation with government programs.
- Query the National Development and Reform Commission (NDRC) for economic coordination directives that compel enterprise participation (precedents for authorizing operator participation in interstate programs).
- Consult Chinese legal counsel with experience in State Council administrative processes; estimate typical timeline for a directive (2–4 weeks drafting, 1–2 weeks interagency coordination, 1–2 weeks State Council approval process = 4–8 weeks total).

### 3. Counterintelligence Personnel Security Clearance Processing Timelines and Standards (US and China)

**ID:** 50d5de66-55cd-40a8-ac34-a55ee69a2fc1

**Description:** Published standards and estimated timelines for counterintelligence vetting of government and contractor personnel, specific to US and Chinese processes. Source material type: government procedure manuals, clearance timelines, expedited-review options; purpose: validating the 14–16 week vetting target for 120–150 candidate inspectors per country, identifying bottleneck agencies (US DoD CI, FBI, Chinese Ministry of State Security), and fallback acceleration options. Intended audience: bilateral vetting coordinator, US counterintelligence liaisons, Chinese security-service liaisons.

**Recency Requirement:** Current (2024–2026) clearance timelines and procedures. US: DoD 5220.22-M, Office of Personnel Management (OPM) clearance processing guides. China: not publicly documented; estimate from IAEA inspector-vetting experience and comparable bilateral programs (New START).

**Responsible Role Type:** Bilateral Vetting Coordinator and Counterintelligence Process Specialist

**Access Difficulty:** Medium. US OPM and DCSA guidance is public or accessible via FOIA request (2–4 week turnaround). Prior bilateral-program timelines may be in public Congressional testimonies or negotiated agreements. China's security-vetting timelines are not publicly available; requires direct diplomatic request to Chinese co-chair office or Ministry liaison.

**Steps:**

- Contact US Office of Personnel Management (OPM) directly for current clearance-processing timelines for Secret and Top Secret/SCI level personnel (typical US timeline: 6–12 months for TS/SCI, accelerated pathways 3–4 months for priority requests).
- Request the US Defense Counterintelligence and Security Agency (DCSA) for guidance on expedited contractor-personnel vetting (may be available through 5–10 week expedited reviews if priority is confirmed).
- Consult prior bilateral programs (New START inspection teams, IAEA safeguards inspectors) for actual vetting timelines experienced; research publications and Congressional records on inspector deployment timelines.
- For China: request diplomatic liaison to Chinese Ministry of State Security through the Chinese co-chair office; inquire about typical timelines for security vetting of government-appointed personnel (estimated 4–8 weeks based on comparable IAEA experience).
- Identify fallback acceleration options: surge vetting capacity (hiring additional security investigators), parallel vetting (multiple agencies working simultaneously), and conditional approval (provisional approval pending final background checks).

### 4. New START and OPCW Inspection Regime Procedural Manuals and Lessons Learned

**ID:** 7e8e8059-8922-4ec1-a5f8-1e44f86ad032

**Description:** Published and classified operational procedures from the New START on-site inspection regime (suspended 2020–2023) and the Organisation for the Prohibition of Chemical Weapons (OPCW) industry-verification program. Source material type: treaty operational procedures, inspection protocols, inspector-conduct rules, challenge-inspection procedures, and post-program evaluations. Purpose: informing the Consortium's inspection zone design, shift-coverage models, maintenance scheduling, exit-disposition procedures, and inspector conduct oversight. Intended audience: bilateral operations planners, inspection-protocol designers, program management.

**Recency Requirement:** Most recent (2020–2023) published New START operational procedures and OPCW Verification Manual (current). For lessons learned, seek post-mortem evaluations or Congressional testimonies (2020–2023 on New START suspension, 2015–2024 on OPCW efficiency).

**Responsible Role Type:** Operations Planning Lead and Verification-Regime Design Specialist

**Access Difficulty:** Medium–Hard. New START procedures have operational-security restrictions; declassified summaries are available via State Department press releases and Congressional briefings, but detailed procedures require FOIA request (2–4 months) or secret-level clearance access. OPCW Verification Manual is public. Congressional testimonies and think-tank reports on lessons learned are freely available. Interviews with retired inspectors require cold outreach but are often willing (no formal access barrier).

**Steps:**

- Contact the US State Department's Bureau of Arms Control, Deterrence and Stability (ACDS) for New START operational procedures (many are unclassified or available via FOIA).
- Request the Defense Threat Reduction Agency (DTRA) for New START inspection-team feedback and operational reports (6–12 month FOIA turnaround).
- Access the OPCW website (opcw.org) for published Verification Manual, technical procedures, and managed-access guidelines (public documents, free download).
- Consult Congressional Research Service reports on New START implementation and OPCW operations (available via Congress.gov or CRS website).
- Interview retired or active New START and OPCW inspectors via the Arms Control Association (armscontrol.org) or think tanks (CSIS, Center for Strategic and International Studies; Center for New American Security) for operational insights.

### 5. IAEA Safeguards Bilateral Agreements and Layered-Evidence Protocols

**ID:** 3c1048cf-a497-406a-b278-ee3fa78d44c7

**Description:** Bilateral safeguards agreements between the IAEA and participating states (including US and China) specifying inspection rights, equipment-identity verification using layered evidence, containment and surveillance procedures, and dispute-resolution mechanisms. Source material type: bilateral international agreements and technical procedures; purpose: informing the evidence-weighting hierarchy (attestation, physical inspection, records, third-party logs), equipment-identity confidence measures, and forensic-panel decision procedures. Intended audience: bilateral technical team, forensic-panel designers, evidence-weighting specialists.

**Recency Requirement:** Current (2020+) IAEA Safeguards Agreements and IAEA Safeguards Implementation Reports (annual). Bilateral agreements with US and China negotiated in prior years but reviewed annually.

**Responsible Role Type:** Bilateral Technical Lead and Evidence-Weighting Specialist

**Access Difficulty:** Easy–Medium. IAEA Safeguards Agreements and Implementation Reports (unclassified portions) are published on iaea.org. IAEA technical procedures and papers are available via IAEA Publications Catalogue. Classified full reports require bilateral diplomatic request (2–4 weeks) or direct IAEA liaison (same clearance as the requesting governments).

**Steps:**

- Visit the IAEA website (iaea.org) to access the Safeguards Agreements database; retrieve agreements between IAEA and China, IAEA and US (unclassified summaries).
- Request the IAEA Department of Safeguards for technical procedures on equipment-identity verification, layered evidence, and sample cross-checking (publicly available or via IAEA liaison channels).
- Access the IAEA Safeguards Implementation Reports (annual, unclassified summary, classified full report); request classified version via bilateral legal channels.
- Contact the IAEA Office of Information for academic publications on layered-evidence methodology and safeguards design (IAEA publishes technical papers on Detection Methods).
- Interview IAEA safeguards specialists via the IAEA's public affairs office for guidance on evidence-weighting rules and forensic methodology (no classification barrier; staff are often available for consultation).

### 6. Cryptographic Trust Roots and Hardware-Security-Module Standards (NIST, RSA Laboratories)

**ID:** dbc17a6c-5567-4919-b9d8-5c967b2f95c0

**Description:** Published standards for split-custody cryptographic key generation, split-key ceremonies, hardware-security modules, and cryptographic validation. Source material type: technical standards and best-practice guides; purpose: validating the ledger's split-key design, key-ceremony procedures, and offline backup encryption. Intended audience: cryptography architects, ledger-design specialists, bilateral security teams.

**Recency Requirement:** Current (2022+) NIST Special Publications (SP 800-57: Key Management; SP 800-153: Guidelines for Securing Wireless Local Area Networks; SP 800-152: Guidelines for Hardware-Rooted Cryptography). ISO/IEC standards (27035, 20000, 27001) on cryptographic practices (current editions, 2020–2024).

**Responsible Role Type:** Cryptographic Systems Architect

**Access Difficulty:** Easy. NIST standards are free downloads from csrc.nist.gov. Academic papers are freely available or available via institutional access. ISO standards require purchase (typically USD 100–200 per document) or access through government standards bodies. NSA guidance requires official diplomatic request (2–4 weeks) or security-clearance access.

**Steps:**

- Access NIST Computer Security Resource Center (csrc.nist.gov) to download current publications on key management and cryptographic standards (free, public PDF).
- Consult ISO/IEC standards via the International Organization for Standardization (iso.org) or through bilateral government standards bodies (US: ANSI; China: SAC); standards are typically paid access but can be obtained via bilateral procurement.
- Request the NSA Information Assurance Directorate (now part of CISA) for guidance on split-key ceremonies and classified-information handling (available via official request through bilateral security channels).
- Consult academic publications and conference papers (Cryptography Research, USENIX Security Symposium) on Byzantine-fault-tolerant ledgers and split-key implementations (publicly available via academia.edu, researchgate.net, or university repositories).

### 7. Frontier Computing Equipment Manufacturer Specifications and Equipment-Roadmap Data

**ID:** 2d2b4388-1c20-4c2e-982b-5b7fff42c278

**Description:** Technical specifications and equipment roadmaps from major manufacturers of frontier computing equipment (NVIDIA, AMD, Intel, TPU/Google, custom ASICs). Source material type: manufacturer data sheets, product specifications, performance metrics; purpose: defining the covered-equipment schedule, classifying equipment as frontier-relevant (top 5% by performance metric), and forecasting equipment obsolescence during the 30+ month project lifecycle. Intended audience: bilateral technical lead, covered-equipment-schedule custodian, independent testing unit.

**Recency Requirement:** Current (2026) manufacturer specifications and roadmap data; any public 2025–2027 announcements of new product lines or performance improvements.

**Responsible Role Type:** Equipment-Schedule Custodian and Technical Specification Lead

**Access Difficulty:** Easy. Manufacturer specifications and public roadmap data are freely available on official websites. Industry reports require subscription (USD 500–5,000 per report) or access through institutional subscriptions (universities, think tanks, government libraries may have access).

**Steps:**

- Visit manufacturers' official websites: NVIDIA.com (GPU specifications), AMD.com (GPU/EPYC specifications), Intel.com (CPU/GPU specifications), Google.com (TPU technical documentation).
- Consult published product data sheets and performance benchmarks (TensorFlow Performance Benchmarks, MLPerf, standard GPU benchmarks like SPECrate).
- Query industry databases (top500.org for supercomputer rankings, which track high-performance accelerators; IDC, Gartner reports on data-center equipment trends).
- Interview equipment specialists at participating datacenters to understand current inventory and equipment-refresh cycles (timelines for new equipment arrivals, typical lifecycle of frontier equipment = 18–36 months before obsolescence).
- Consult industry research reports (Gartner, IDC, Mercury Research) on AI accelerator market trends and performance forecasts for 2026–2028 (available via subscription or academic institution access).

### 8. Independent Equipment-Testing Laboratories and Accreditation Standards

**ID:** d3167042-2359-400f-b901-caa583003c92

**Description:** Directory of independent equipment-testing laboratories in each country capable of equipment-identity verification without manufacturer cooperation (accredited labs, clean-room facilities, cryptographic validation labs). Source material type: laboratory accreditation databases, contact information, service offerings, cost estimates; purpose: pre-qualifying the 3–5 examiner labs per country for the vendor-refusal fallback ladder. Intended audience: bilateral procurement team, vendor-refusal escalation coordinator.

**Recency Requirement:** Current (2026) lab accreditation status and service offerings; ISO 17025 accreditation (for testing lab credibility) as of 2024+.

**Responsible Role Type:** Bilateral Procurement Lead and Independent-Lab Accreditation Specialist

**Access Difficulty:** Easy. ILAC, NVLAP, and CNAS accreditation databases are publicly accessible online. Lab websites and contact information are freely available. Quotes require direct contact (email/phone) but labs typically respond within 2–3 business days.

**Steps:**

- Query ISO/IEC accreditation databases (ILAC, International Laboratory Accreditation Cooperation ilac.org) to identify ISO 17025-accredited testing laboratories in each country with electronics/cryptography expertise.
- Contact national accreditation bodies: US (NIST's National Voluntary Laboratory Accreditation Program, NVLAP); China (China National Accreditation Service for Conformity Assessment, CNAS).
- Search industry directories (electronicstesting.org, testhouse.org, lab-finder databases) for independent equipment-testing and cryptographic-validation labs.
- Request quotes from 5–10 candidate labs per country specifying the scope of work (equipment-identity verification, cryptographic attestation validation, physical inspection procedures, turnaround time, cost per exam).
- Check lab websites and brochures for ISO 17025 certificates, equipment capabilities (spectroscopy, teardown capability, cryptographic-attestation validation expertise), and prior client references.

### 9. US and Chinese Export-Control and Technology-Transfer Regulations (Relevant to Equipment Verification)

**ID:** 9d2dffe9-8b97-47b4-b432-1f05c84eba3a

**Description:** US export-control laws (EAR, ITAR) and Chinese export-control and technology-transfer regulations relevant to frontier computing equipment, inspection scope, and evidence handling (what equipment is subject to export control, what restrictions apply to evidence sharing between governments). Source material type: regulatory text and guidance; purpose: ensuring the bilateral instrument and verification procedures comply with export-control rules and do not violate technology-transfer restrictions. Intended audience: bilateral legal counsel, compliance officers.

**Recency Requirement:** Current (2024+) export-control regulations. US: Bureau of Industry and Security (BIS) Export Administration Regulations (EAR), State Department International Traffic in Arms Regulations (ITAR), and any 2023–2026 updates or clarifications on AI-accelerator export controls. China: Regulations on Technology Export, Measures for Import and Export of Technology (current).

**Responsible Role Type:** Bilateral Legal Counsel and Export-Control Compliance Officer

**Access Difficulty:** Easy–Medium. US export-control regulations are publicly available on bis.doc.gov and state.gov. Chinese regulations are available on English-language government websites or via MOFCOM liaison. CRS reports are accessible via Congress.gov. Export-control compliance opinions from government attorneys require official request (2–4 weeks).

**Steps:**

- Access the US Bureau of Industry and Security (bis.doc.gov) for current EAR text, Commerce Control Lists (CCLs) for computing equipment, and export-authorization procedures.
- Consult the US State Department's DDTC (Directorate of Defense Trade Controls) for ITAR guidance on defense-related equipment and the implications for bilateral verification of military-adjacent technology.
- Query the Congressional Research Service for recent reports on AI-accelerator export controls to China (CRS reports 2023–2026 likely cover this topic).
- Access China's Ministry of Commerce (MOFCOM) website for technology-export regulations and the Catalogue of Technologies Prohibited or Restricted from Export.
- Request both governments' legal teams for opinions on how the bilateral verification mechanism complies with or is exempt from their respective export-control laws.

### 10. Bilateral US–China Technology and Security Cooperation Precedents (2010–2025)

**ID:** 61241520-4c2f-4cfd-b6b6-5ddf30e78cdc

**Description:** Historical examples of bilateral US–China technical agreements, joint research programs, or verification arrangements in nuclear, cyber, or trade domains that provide precedent for the Consortium's governance structure, double-key authority, and inspection procedures. Source material type: bilateral treaty texts, agreements, joint statements; purpose: understanding what bilateral mechanisms have succeeded or failed historically, how double-key governance has been implemented in prior arrangements, and what political barriers may exist. Intended audience: bilateral legal counsel, program management, political advisors.

**Recency Requirement:** Agreements and precedents from 2010–2025; focus on arrangements that remain active or have recent evaluations (2020+).

**Responsible Role Type:** Bilateral Historian and Political-Risk Advisor

**Access Difficulty:** Easy–Medium. State Department treaty database and CRS reports are public. CFR and CSIS analyses are free online. Congressional testimonies are public record. Historical context and lessons-learned analysis require interviews or archival research (medium effort, but primarily accessible through public outlets).

**Steps:**

- Access the US State Department's treaty database (state.gov/treaties) for bilateral agreements with China; filter for verification or technology-related arrangements.
- Consult the Council on Foreign Relations (cfr.org) and Center for Strategic and International Studies (csis.org) for analyses of bilateral US–China agreements and their success/failure factors.
- Query the Congressional Research Service for reports on bilateral US–China verification or technology agreements (available via Congress.gov).
- Request the US State Department's China Desk for a summary of bilateral arrangements addressing verification, equipment tracking, or dual-use technology (internal document, available via diplomatic channels).
- Interview academic specialists in US–China relations and technology diplomacy (universities, think tanks) for historical context and lessons learned (accessible via public contact information).

### 11. Hardware Supply-Chain Integrity Standards and Attestation Technologies (Industry Standards)

**ID:** c9273440-acd2-4074-8d77-a76119927266

**Description:** Published industry and government standards for hardware supply-chain integrity, cryptographic device attestation, trusted-execution environments, and equipment-authenticity verification (e.g., NIST hardware-rooting standards, Trusted Computing Group TCG specifications, UEFI/firmware-attestation standards, DICE architecture). Source material type: technical standards and industry best practices; purpose: informing the evidence-weighting hierarchy's cryptographic-attestation layer and the covered-equipment schedule's attestation-hook availability. Intended audience: bilateral technical team, equipment-schedule custodian, forensic-panel designer.

**Recency Requirement:** Current (2023+) standards. NIST SP 800-155 (BIOS Integrity Measurement), TCG PC Client Platform TPM Profile, UEFI specifications, and any 2024–2026 updates.

**Responsible Role Type:** Equipment-Schedule Custodian and Attestation-Technology Specialist

**Access Difficulty:** Easy. NIST standards, TCG specifications, and UEFI documents are freely available. Academic papers are freely available or accessible via institutional subscriptions. Manufacturer white papers and technical advisories are freely available or require registration on corporate websites.

**Steps:**

- Access NIST Computer Security Resource Center (csrc.nist.gov) for publications on hardware roots of trust and firmware attestation (free downloads).
- Visit the Trusted Computing Group website (trustedcomputinggroup.org) for TPM specifications and platform-architecture guides (free, public documents).
- Consult UEFI Forum (uefi.org) for BIOS/firmware specifications relevant to equipment authenticity (freely available specifications).
- Query academic publications on hardware attestation and supply-chain integrity (available via IEEE Xplore, ACM Digital Library, or arxiv.org).
- Request NIST or security-company specialists (Cisco, Microsoft, Intel) for technical guidance on attestation-hook availability in frontier computing equipment (manufacturers may provide white papers or technical advisories).

### 12. Contingency Cost Modeling and Gate-Delay Holding-Cost Precedents (Comparable Programs)

**ID:** 205cf179-fd24-4fce-83df-53c4bb66c04f

**Description:** Comparative cost data from prior bilateral programs or international verification regimes regarding holding costs during entry-condition delays, costs of fallback personnel deployment (surge staffing), site-replacement costs, and vendor-fallback examiner costs. Source material type: program financial reports, Congressional appropriations testimony, cost-benefit analyses; purpose: validating the USD 50–100M/month holding-cost estimate and USD 3.6–11.2M examiner-overrun estimate, and identifying any costs not yet budgeted. Intended audience: bilateral budget director, fiscal-accountability officer.

**Recency Requirement:** Cost data from 2015+ programs (New START inspections, OPCW-managed industry access, IAEA on-site inspections); any recent Congressional testimonies on program costs (2020–2026).

**Responsible Role Type:** Bilateral Budget Director and Cost-Estimation Specialist

**Access Difficulty:** Easy–Medium. Congressional appropriations data is public (Congress.gov). OPCW budget reports are public. GAO reports are public. CRS reports are accessible via Congress.gov or CRS website. Interviews require outreach to government officials or think-tank researchers (medium effort, often willing to discuss lessons learned).

**Steps:**

- Request the Congressional Research Service for comparative cost analyses of verification programs (New START, OPCW, IAEA) and their budget history (available via Congress.gov or CRS website).
- Access Congressional appropriations hearings and testimonies (2015–2025) from the State Department and DoD on verification-program funding and cost growth (available on Congress.gov).
- Consult the OPCW's annual budgets and cost reports (available on opcw.org) for managed-access verification costs and lessons learned on cost overruns.
- Request the US Government Accountability Office (GAO) for any audits or reports on verification-program cost performance (available on gao.gov).
- Interview program managers from prior bilateral programs (retired or active staff via think tanks or government offices) for lessons learned on cost containment and contingency-reserve adequacy.

### 13. Global Frontier Computing Equipment Performance and Obsolescence Data (Gartner, IDC, Mercury Research)

**ID:** 42f73990-e40a-41f1-ae31-743458a5c71f

**Description:** Industry analyst reports and market surveys tracking the performance, deployment rates, and estimated product lifecycles of frontier computing equipment (GPUs, TPUs, custom ASICs, accelerator interconnects) globally and in the US and Chinese markets separately. Source material type: industry market research; purpose: forecasting equipment obsolescence during the project lifecycle and validating the 'top 5% by performance' definition of frontier-relevant equipment. Intended audience: bilateral technical lead, covered-equipment-schedule custodian.

**Recency Requirement:** Most recent available (2024–2026). Any reports analyzing AI-accelerator market trends, product lifecycle forecasts, or geographic performance gaps between US and China deployments.

**Responsible Role Type:** Equipment-Schedule Custodian and Market-Analysis Specialist

**Access Difficulty:** Medium. Gartner and IDC reports require subscriptions (USD 5,000–50,000 per year) or access through government/institutional accounts. Public analyst reports from cloud providers are free. Industry publications are free online.

**Steps:**

- Access Gartner Research (gartner.com) and request reports on 'Data Center Infrastructure Software' or 'AI Infrastructure and Platforms' (require subscription or institutional access).
- Contact IDC (idc.com) for market forecasts on 'High-Performance Computing' and 'AI Accelerator Market' (subscription or corporate-access required).
- Review Mercury Research (mercresearch.com) for GPU market analysis and lifecycle data (subscription).
- Consult public analyst reports from AWS, Google Cloud, Microsoft Azure on their AI-accelerator strategies and performance benchmarks (freely available on corporate websites).
- Query industry publications (AnandTech, TechPowerUp, Serve The Home) for independent equipment reviews and performance rankings (freely available online).

### 14. Cost of Bilateral Government Inspection Programs and Verification Overhead (Comparative Historical Data)

**ID:** 1c1e8dcc-6c2e-497e-be3a-29b110d86d30

**Description:** Historical cost data from prior bilateral US–China or comparable international verification programs, broken down by personnel costs, travel, secure facilities, equipment, contingency reserves, and cost overruns. Source material type: government financial reports, Congressional appropriations testimony; purpose: validating cost estimates for inspector staffing (USD 750M envelope), secure facilities (USD 750M), and contingency reserve adequacy (USD 500M reserve vs. USD 515M worst-case exposure). Intended audience: bilateral budget director, fiscal-accountability officer.

**Recency Requirement:** Cost data from 2015+ programs; any recent Congressional testimonies (2022–2026) on verification-program budgets and cost performance.

**Responsible Role Type:** Bilateral Budget Director and Cost-Estimation Specialist

**Access Difficulty:** Easy–Medium. Congressional appropriations data is public (Congress.gov). GAO reports are public. CRS reports are accessible. Government agency cost data requires FOIA request (2–4 weeks) or diplomatic request (2–4 weeks). Interviews require outreach (medium effort).

**Steps:**

- Request the Congressional Research Service for historical cost analyses of bilateral verification programs (e.g., New START inspections pre-2020 annual costs, OPCW managed-access program costs).
- Access Congressional Appropriations Committees' mark-ups and justifications for State Department and DoD budgets (2015–2026) for verification-program funding (available on Congress.gov).
- Query the US Government Accountability Office (gao.gov) for any audits of verification-program cost performance or cost-overrun analyses.
- Contact the US State Department's Arms Control Verification and Compliance Bureau or the DTRA for internal cost-tracking reports on prior programs (available via FOIA or diplomatic request).
- Interview program managers from New START or OPCW programs (retired or active) for actual vs. planned cost comparisons and lessons learned on contingency reserve sizing.

### 15. Bilateral US–China Trade and Technology Negotiations (2020–2026): Public Records and Congressional Testimonies

**ID:** b46e2610-27c1-4f21-80ed-7ba0dc3efa37

**Description:** Public statements, Congressional testimonies, and official records from US–China technology and trade negotiations (2020–2026), including any discussions or proposals for bilateral verification mechanisms, equipment tracking, or technology-access agreements. Source material type: Congressional records, news archives, official statements; purpose: understanding the political context and any prior US–China discussions relevant to the Consortium proposal. Intended audience: program management, political advisors.

**Recency Requirement:** Public records and statements from 2020–2026; focus on any mentions of verification mechanisms, bilateral technology agreements, or computing-equipment oversight.

**Responsible Role Type:** Political-Risk Advisor and Bilateral-Context Analyst

**Access Difficulty:** Easy. Congressional records are public (Congress.gov). White House statements are public (whitehouse.gov archives). News archives are publicly available (require free registration for some outlets). USCC reports are publicly available on uscc.gov. Think-tank publications are freely available on institutional websites.

**Steps:**

- Search Congress.gov for Congressional testimonies and hearing transcripts (2020–2026) featuring State Department, DoD, or Commerce Department officials discussing US–China technology policy or verification proposals.
- Access the White House website for official statements and press releases on US–China technology negotiations (2020–2026).
- Search news archives (Reuters, AP, Bloomberg, WSJ) for public reporting on bilateral trade and technology negotiations; filter by date range 2020–2026.
- Consult the US–China Economic and Security Review Commission (USCC, uscc.gov) for annual reports and testimonies on bilateral relations and technology issues (2020–2026).
- Query think-tank publications (CFR, CSIS, Hudson Institute, etc.) for expert commentary on bilateral verification proposals or technology agreements.