
## Documents to Create

### 1. Project Charter and Mission Definition

**ID:** a62b791a-88f9-42a0-a906-9b3cad884a67

**Description:** High-level charter formalizing The Consortium's scope, governance structure (equal co-chairs, double-key authorization, no casting vote), Phase One objectives (90-day declared-equipment change verification at 2–4 matched datacenter pairs), Go/Modify/Stop decision criteria, budget envelope (USD 5.0B), entry conditions and critical success factors. Intended for co-chairs, national leadership and legislative oversight. Establishes legal authority and political commitment.

**Responsible Role Type:** Project Director / Executive Sponsor

**Primary Template:** PMI Project Charter Template

**Secondary Template:** Arms Control Verification Program Charter (IAEA/OPCW precedent)

**Steps:**

- Define mission scope: declared-equipment change verification only (no workload, topology, hidden-facility detection).
- Specify governance: equal co-chairs, double-key authorization for all major decisions, deadlock procedures (auto-suspension day 14, impaired-confidence days 21–28), no casting vote.
- Lock entry conditions: bilateral instrument, appropriations, site selection, inspector approval, vendor participation, covered-equipment schedule (each with milestone date).
- Define Phase One: 90-day operational window (Months 6–9 = 2027-04-08 to 2027-07-08), verdict by Month 9.5 (2027-07-23).
- Specify budget: USD 5.0B total (USD 2.5B each country), seven fixed envelopes, 100% envelope-mapping audit, contingency USD 500M with draw triggers (30%, 50%, 75%).
- State Go/Modify/Stop criteria: detection ≥70% planned / ≥50% unplanned, false positives ≤10%, unverifiable ≤5%, parity ≥85%, no discrepancy >21 days, <5 open material cases, no hard Stop triggers.
- Identify critical success factors: entry-gate completion on time, exercise credibility, adjudication capacity, parity maintenance, ledger integrity.
- Require joint co-chair signature by Month 1 (2026-11-08).

**Approval Authorities:** Both national co-chairs (joint approval required); domestic legislative appropriations bodies (for funding authorization).

### 2. Bilateral Instrument and Governance Framework

**ID:** 03b2a80e-db73-4895-9b18-bed7520a5dac

**Description:** Formal international bilateral agreement establishing the Consortium's legal foundation, governance procedures, deadlock resolution with automatic suspension triggers, inspector privileges and immunity, evidence handling and confidentiality tiers, operator compensation terms, neutral-facility status, and termination provisions. Classified. Binding on both governments. Core of the double-key authorization structure.

**Responsible Role Type:** Legal Counsel / International Law Specialist

**Primary Template:** Bilateral Arms-Control Treaty (New START, JCPOA precedent)

**Secondary Template:** IAEA Safeguards Agreement text

**Steps:**

- Draft executive-summary preamble: mutual recognition of equal standing, commitment to reciprocal transparency, no casting vote, binding dispute procedures.
- Article 1: Mission scope, declared-equipment definition, verified change types (arrival, installation, maintenance, decommissioning, transfer).
- Article 2: Governance (co-chair roles, double-key procedures for budget releases, protocol changes, findings adjudication, suspension triggers).
- Article 3: Entry conditions (instrument signature, appropriation, domestic access authority, site selection with parity audit, inspector approval, vendor participation, schedule adoption) with milestone dates.
- Article 4: Deadlock and automatic-suspension procedures (clock definition, day 14 partial suspension of disputed function, day 21–28 impaired-confidence, emergency summit at day 35, no co-chair waivers without ledger annotation).
- Article 5: Budget envelopes, funding tranches with synchronized deposit requirement and 14-day escalation / 30-day Stop trigger for delays.
- Article 6: Evidence weighting rule, confidential versioning, no single decisive source, rotating combinations.
- Article 7: Verdict thresholds (detection, false-positive, unverifiable, parity rates) as confidence-interval bands, mechanical scoring rule, no amendment after first exercise, final-verdict report signed by both co-chairs.
- Article 8: Inspector privileges, immunity, security vetting, compartmentalization, cooling-off periods, no personal-device communications on-site.
- Article 9: Operator compensation from home government's USD 2.5B contribution; vendor-refusal fallback ladder (5 rungs); equipment unresolved at entry classified unverifiable or excluded.
- Article 10: Neutral facility status, immunity from seizure, dual co-chair control, no unilateral access restrictions.
- Article 11: Key custody (dual-share generation, joint ceremonies, lost-key recovery procedures, ledger signing requirements).
- Article 12: Evidence disclosure tiers, filtered packages, raw-evidence escort access under dispute, independent filter auditor certification.
- Article 13: Confidentiality, classification handling, post-Phase-One ledger archival (7-year minimum), access procedures.
- Article 14: Termination clause (allows either party to withdraw with 180-day notice after entry certification; early withdrawal triggers Stop).
- Obtain legal review from both sides' offices of legal counsel; resolve divergent interpretations. Require joint signature by Month 1 (2026-11-08).

**Approval Authorities:** Both national co-chairs and their legal advisors; foreign ministries or equivalent (for treaty authority); domestic legislative bodies (constitutional ratification if required).

### 3. Covered-Equipment Schedule (Technology-Neutral Version)

**ID:** dd37f6b4-860f-49d0-910a-69d14acf7791

**Description:** Confidential, versioned technical specification defining 'frontier-relevant computing equipment' subject to verification. Uses performance metrics and functional classes (e.g., 'dense matrix-multiply accelerator, FP32 >100 TFLOPS') rather than product names, to remain neutral across hardware generations. Locked before Phase One clock (Month 5.5 = 2027-03-23); frozen for entire 90-day window; amendments only pre-clock by double-key approval. Audit trail shows every version and amendment with timestamp, proposing party, rationale, effective date. Classified.

**Responsible Role Type:** Schedule Versioning and Technology-Neutrality Architect

**Primary Template:** Configuration-Management / Bill-of-Materials template

**Secondary Template:** IAEA Safeguards Accountancy schedule structure

**Steps:**

- Define technology-neutral classification taxonomy: processor family (by function: training accelerator, inference engine, control-plane), performance bands (FP32 peak TFLOPS range, memory bandwidth range, form factor range, power envelope range), not specific products.
- List seven processor classes (e.g., class 1: >500 TFLOPS, class 2: 100–500 TFLOPS, etc.) with examples of representative hardware but not brand-specific requirements.
- Specify supply-chain provenance fields: OEM, maintenance provider identity, logistics partner, to detect substitution without naming vendors.
- Include serialization and attestation requirements: physical serial numbers, manufacturing date codes, markings, vendor attestation records required for identity verification.
- Create a version-control template (amendment log): timestamp, proposing party, technical rationale, both-sides approval dates, effective date, items affected, linkage to any Phase-One results requiring re-classification.
- Draft amendment procedures: proposal with technical justification by Month 4 (2027-02-08); review by Month 4.5 (2027-02-23); lock by Month 5.5 (2027-03-23) if consensus, no amendment if deadlock (freeze version for Phase One).
- Survey Tier-1 vendors (Month 3–4 = 2027-01-08 to 2027-02-08) on hardware-release cycles: are new generations released >3 months apart (allowing mid-test amendments) or is the schedule stable for 9 months (freeze is feasible)?
- Publish initial provisional schedule by Month 4 (2027-02-08) for technical-panel review and double-key approval by Month 5.5 (2027-03-23).
- Lock the Phase-One version in the bilateral instrument (no amendments Months 6–9 = 2027-04-08 to 2027-07-08). Maintain change log in the ledger.

**Approval Authorities:** Both accountable-specialist teams (one per country); both co-chairs (double-key approval for any amendment).

### 4. Entry-Condition Roadmap and Task-Force Charter

**ID:** 48e4ad33-6791-4f10-8e36-2c4cbc11a0b3

**Description:** Detailed project plan for completing all seven entry conditions (bilateral instrument, appropriations, domestic access authority, site selection with parity audit, inspector approval, vendor commitments, covered-equipment schedule adoption) by Month 5.5 (2027-03-23). Includes binding weekly milestone deadlines, parallel-track activation (site nomination, vendor outreach, inspector recruitment all starting Month −2 = 2026-08-08, not sequentially), contingency reserves (USD 50–100M compression reserve), escalation authority with 5-day re-scoping power for any gate slip >2 weeks, and weekly status reporting to both co-chairs.

**Responsible Role Type:** Project Manager / Program Coordinator

**Primary Template:** PMI PMBOK Project-Execution Plan

**Secondary Template:** Critical-Path Scheduling with dependency mapping

**Steps:**

- List all seven entry gates with baseline completion dates and 2-week tolerance buffer.
- Map dependencies (e.g., domestic authority gates site selection) and identify which can run in parallel (site nomination, vendor outreach, inspector vetting all begin Month −2 independently).
- Assign owner and contact for each gate (instrument signature → foreign ministry, site selection → bilateral facility-selection task force, inspectors → recruiting coordinator, etc.).
- Define weekly checkpoint (every Monday, 09:00 CET) with traffic-light status (green = on track, yellow = slip approaching, red = slip >1 week) and escalation trigger (red status triggers emergency co-chair summit within 5 days).
- Specify re-scoping authority: if any gate slips >2 weeks, an independent external authority (neutral third-country official, pre-approved) has power to convene a co-chair summit with 5-day decision deadline on either timeline extension (compressing Phase One by equivalent days) or scope reduction (2 pairs instead of 3, or 60-day test instead of 90).
- Allocate the USD 50–100M compression reserve from the contingency envelope to cover accelerated negotiation costs (extra legal staff, expedited vetting, 24/7 task-force surge).
- Publish a master roadmap at Month 0 (2026-10-08) showing bilateral-instrument signature Month 0.5 (2026-10-23), domestic authority and first tranche Month 1 (2026-11-08), site nominations Month 1 (2026-11-08), vendor written commitments Month 1.5 (2026-11-23), inspector approval Month 2 (2026-12-08), vendor-participation registry and provisional schedule Month 3–4 (2027-01-08 to 2027-02-08), entry-gate certification Month 5.5 (2027-03-23).
- Establish monthly review meetings (both co-chairs, task-force leads, external escalation authority) to assess cascading risks (if site selection slips, does vendor outreach still meet Month 1.5 = 2026-11-23 deadline?) and authorize corrective action.
- Require the task force to produce a final entry-certification memo (Month 5.5 = 2027-03-23) confirming all seven gates are met, signed by both co-chairs, before Phase One clock starts.

**Approval Authorities:** Both national co-chairs; external escalation authority (neutral third-country official); task-force leads (reporting to co-chairs).

### 5. Theory of Change and Public-Value Case

**ID:** 34b57c08-04e2-4da7-8c62-989ebacb9b61

**Description:** Strategic narrative establishing why The Consortium matters to each government and the international community. Articulates the theory of change: if credible, reciprocal verification of declared equipment changes can be demonstrated between distrustful great powers, then bilateral confidence in frontier-computing transparency may enable future arms-control or risk-reduction mechanisms. Identifies outcomes (credible Go/Modify/Stop decision, proven reciprocal-access parity, demonstrated adjudication credibility) and success factors. Intended for legislatures, media and public audiences (unclassified summary). Frames the mission as a public good (reducing security uncertainty) not as a commercial venture.

**Responsible Role Type:** Strategic Communications Lead / Policy Advisor

**Primary Template:** DFID / World Bank Theory of Change framework

**Secondary Template:** Public-value case (UK Cabinet Office)

**Steps:**

- Define the problem statement: frontier computing is a national-security concern for both countries; without transparency mechanisms, arms-control options are limited; existing precedents (IAEA, OPCW, START) do not cover hardware change verification.
- State the theory: if a narrow, bounded, reciprocal-access verification pilot succeeds in demonstrating credible detection and parity, both governments gain confidence in the verification model and may authorize Phase Two or future continuity mechanisms.
- Identify assumptions (not validated): both governments sustain political commitment; operators cooperate; exercises yield statistically defensible detection rates despite thin sample size; adjudication capacity matches demand; no major counterintelligence breach undermines confidence.
- Define success outcomes: (1) Phase One completes with Go verdict, signaling verification feasibility; (2) adjudication procedures and deadlock resolution work without political breakdown; (3) both governments publicly affirm reciprocal-access parity and detect credibility; (4) Phase One provides a template for future bilateral or multilateral verification mechanisms.
- Identify key result areas: entry-gate completion on time, exercise credibility (blind-design independence, realism), parity measurement (symmetric access, exchange timelines), verdict credibility (pre-registered thresholds, mechanical scoring, published rationale).
- Acknowledge risks: thin statistics (±12% confidence intervals make Modify verdicts ambiguous), political withdrawal pressure, operator friction from exercises, confidentiality disputes over filtered evidence.
- Frame the public-value case: national security (reduced frontier-computing uncertainty), reciprocal transparency as a trust-building mechanism, proof-of-concept for arms-control innovation.
- Develop an unclassified summary for legislative and media briefing (Month 4 = 2027-02-08), highlighting mission, timeline, budget, and success criteria without operational detail.

**Approval Authorities:** Both co-chairs; national security advisors; legislatures (for public-facing versions).

### 6. Layered Evidence-Weighting Rule and Calibration Protocol

**ID:** 11f38878-1da7-4c82-b479-e9ffd9ae414b

**Description:** Specification of the confidential rotating evidence-weighting model that combines attestation, physical inspection, customs records, identifiers, maintenance logs, infrastructure changes and witnessed movement into an equipment-identity confidence rating. Locked in double-key-approved escrow by Month 1.5 (2026-11-23). Validated against 100–200 historical equipment-change events per site by Month 2 (2026-12-08) (benign cohort); validated against 20–30 adversarial synthetic scenarios by Month 5 (2027-03-08) (gaming scenarios); frozen before Phase One clock. No single evidence source is decisive. Classified.

**Responsible Role Type:** Evidence-Rule Architect / Technical Specialist

**Primary Template:** Technical specification with decision-tree or scoring-matrix format

**Secondary Template:** Bayesian or rule-based evidence-fusion methodology

**Steps:**

- Define the seven evidence categories: (1) vendor attestation (credibility score based on vendor history, escrow records); (2) physical inspection by inspector (serial number confirmation, physical-marking verification); (3) customs and shipment records (arrival dates, declared characteristics, LOCOhist matching); (4) equipment identifiers (firmware versions, manufacturing date codes, performance-test baselines); (5) maintenance logs (service events, personnel involved, parts replaced); (6) infrastructure changes (network configuration, electrical allocation, cooling systems); (7) witnessed movement (inspection video, timestamp logs, dual-escort documentation).
- Specify the combination rule: no single category is decisive (if only attestation is present, confidence max 60%; if only maintenance logs, max 70%); identity confidence increases when categories corroborate (e.g., physical inspection + customs + attestation = 85%); identity confidence decreases if categories contradict (e.g., firmware version mismatch between attestation and physical test = confidence capped at 50%).
- Define confidence bands: 0–40% = unverifiable (equipment cannot be confidently identified; triggers fallback ladder or exclusion); 40–60% = provisionally verified pending further evidence; 60–85% = verified with moderate confidence; 85–100% = verified with high confidence (equipment identity confirmed).
- Specify that the rotating aspect: the weighting of each category is set by accountable specialists from both sides; weights are not disclosed to operators or vendors (to prevent gaming); weights are rotated (updated monthly) to prevent fixed patterns from emerging; any weight change requires double-key approval and is logged in the ledger with rationale.
- Draft the pilot-validation protocol: apply the locked rule to 100–200 historical equipment-change events per participating site (Month 2 = 2026-12-08 completion target), measuring false-positive rate (equipment incorrectly classed as unverifiable) and false-negative rate (unverifiable equipment classed as verified) against known ground truth from operator records. Target: false positives ≤13% (10% target ±3 points), false negatives ≤5%.
- If historical validation deviates >±5 points from target, adjust category weights and re-validate on a second 100–200 event cohort before Phase One.
- Draft the adversarial-scenario protocol: before Phase One exercises begin, apply the rule to 20–30 synthetically constructed scenarios (forged attestations, delayed-access tactics, colluding vendor and operator) and confirm false-positive rate remains within ±3 points of calibration. Target: ≥85% detection of seeded adversarial cases.
- Create a versioned rule-change log (timestamp, adjustment rationale, evidentiary trigger, both-sides approval) to maintain audit trail. Publish version history in the final ledger so each finding's classification is traceable to the rule version active at the time.
- Lock the rule before Month 6 (2027-04-08) Phase One clock (no amendments during Months 6–9 = 2027-04-08 to 2027-07-08; rule-adjustment disagreements handled by adjudication surge, not rule change).

**Approval Authorities:** Both accountable-specialist teams (evidence-rule designers); both co-chairs (double-key approval of the locked rule and any pre-Phase-One amendments).

### 7. Verdict Thresholds and Mechanical Scoring Framework

**ID:** 976cf6ed-ce77-43e6-9416-aa6d8e076c8d

**Description:** Pre-registered numerical criteria for converting Phase One detection rates, false-positive rates, and other KPIs into Go, Modify, or Stop verdicts. Stated as explicit confidence-interval bands (e.g., Go if lower bound of 90% CL ≥75% detection) rather than point estimates, with a mechanical scoring rule that removes post-hoc bargaining (e.g., 'if interval straddles threshold, default to Modify'). Locked in a joint bilateral memorandum by both co-chairs by Month 2.5 (2026-12-23) before any Phase One exercise. Classified (with unclassified summary for legislatures).

**Responsible Role Type:** Statistician / Verdict-Framework Designer

**Primary Template:** Statistical decision-rule specification (binomial confidence-interval construction)

**Secondary Template:** Go/No-Go decision-threshold framework (engineering standard)

**Steps:**

- Specify confidence level: recommend 90% CL for Go/Modify boundary (recognizes uncertainty), 95% CL for Stop boundary (higher bar for halting).
- Define detection-rate thresholds as confidence-interval bands: Go (planned-event class): if lower bound of 90% CL ≥75%, verdict is Go. Modify (planned-event class): if interval straddles 60% or upper bound ≤82%, verdict is Modify. Stop (planned-event class): if upper bound of 95% CL <55%, verdict is Stop. Apply same structure to unplanned-event class (proposed Go ≥60%, Modify 40–60%, Stop <40%).
- Define false-positive-rate threshold: Modify if FP rate ≤15%; Stop if FP rate >15%.
- Define unverifiable-equipment threshold: Stop if >10% at a single site or >5% overall (proposed); Modify if 5–10%.
- Define reciprocal-access parity (definition TBD, propose inspector-hour parity ≥90%, exercise count parity ≥5 per type per site, data-access time ≤3 days avg, agreement rate ≥80% on challenge outcomes): Go requires parity ≥85%; Modify if 70–85%; Stop if <70%.
- Define discrepancy-age threshold: Go requires no discrepancy open >21 days at conclusion (all cases ≤21 days); Modify if ≤28 days; Stop if any discrepancy >28 days unresolved.
- Specify the overall verdict logic: Go requires ≥4 of 5 criteria met (80%) AND no hard Stop trigger AND intervals not straddling thresholds. Modify: 3 of 5 criteria met OR 4 of 5 but with interval ambiguity (straddles threshold). Stop: <3 of 5 criteria OR any hard Stop trigger (asymmetric access, shielding, ledger unresolved, withheld funding, >10% unverifiable).
- Specify the mechanical scoring rule: 'Results are scored by the Exercise Authority against pre-registered intervals. If the confidence interval straddles a threshold boundary, the verdict defaults to Modify. No co-chair negotiation of the interval or threshold is permitted after Phase One begins.'
- State that all thresholds are marked 'provisional, validated against pilot data'; allowable adjustment before Phase One if pilot data shows >20% deviation from assumption (e.g., if unreported-arrival detection in pilot is 50% instead of assumed 70%, Go threshold may shift from 75% to 70%), but thresholds are locked before Month 6 (2027-04-08) and not amended during Phase One.
- Draft the joint bilateral memorandum (300–500 words) incorporating thresholds, intervals, mechanical rule and no-amendment language. Require both co-chairs to sign by Month 2.5 (2026-12-23).
- Publish an unclassified summary (2–3 pages) showing thresholds and mechanical scoring rule so legislatures can audit the verdict logic before Phase One begins.

**Approval Authorities:** Both co-chairs (joint signature required); independent statistician (certification that interval methodology is sound); both adjudication panels (confirmation that thresholds are operationally defensible).

### 8. Risk Register and Mitigation Strategy

**ID:** 3d526b42-cea6-4d40-8e96-28356a0eed11

**Description:** Comprehensive risk inventory covering entry-gate delays (8–12 week compression risk), evidence-rule miscalibration (false-positive overload), thin statistics (±12–32% confidence intervals), asymmetric access or operator shielding, ledger divergence, staffing shortfalls, vendor refusal cascades, counterintelligence breaches, and political withdrawal. For each risk: probability, impact, mitigation action, owner, trigger threshold and response timeline. Updated monthly. Classified summary for co-chairs; unclassified summary for legislatures.

**Responsible Role Type:** Risk Manager / Program Risk Officer

**Primary Template:** PMI Risk-Management framework (PMBOK)

**Secondary Template:** ISO 31000 risk-assessment methodology

**Steps:**

- List all 19 identified risks from the expert review (entry-gate sequencing, evidence-rule validation, thin statistics, adjudication overload, shift coverage, neutral-facility siting, counterintelligence, vendor ladder recovery, etc.).
- For each risk, specify: (1) probability (high/medium/low); (2) impact (critical/major/moderate); (3) baseline mitigation (from expert review); (4) owner (which role or unit); (5) trigger threshold (what metric indicates the risk is materializing); (6) response (what action is taken if threshold is crossed); (7) timeline for response.
- Map dependencies: which risks cascade into others (e.g., entry-gate slip → compressed Phase One → thin statistics → ambiguous verdict).
- Identify early-warning indicators: entry-gate milestone tracking (weekly status), evidence-rule pilot results (Month 2 = 2026-12-08), adjudication caseload by age (weekly dashboard), personnel recruitment progress (monthly), facility construction status (monthly), vendor-participation registry (Month 3 = 2027-01-08).
- Define contingency reserves: USD 50–100M from the USD 500M contingency allocated to entry-condition acceleration; estimated additional USD 1.5–2M for adjudication surge capacity; estimated USD 5–10M for neutral-facility delays.
- Establish escalation authority: risks rated 'critical' (probability ≥50% AND impact ≥major) are escalated to co-chairs within 48 hours of trigger. Risks rated 'high' (probability ≥30% OR impact major) escalated within 5 days.
- Specify decision trees for major risks: if entry-gate slip >2 weeks, external escalation authority convenes summit within 5 days with decision to compress Phase One or reduce scope; if evidence rule miscalibration >5 points detected, halt exercises and re-validate before resuming; if adjudication backlog exceeds 30 cases, activate surge unit and convene co-chairs to address root cause.
- Publish a monthly risk dashboard (red/yellow/green status for each risk, updated trigger values, current mitigation status) to co-chairs and independent risk officer.
- Include contingency-burn tracking: set alerts at 30%, 50%, 75% of the USD 500M contingency consumed; trigger mandatory review and scope-reduction planning if >50% is drawn before Month 6 (2027-04-08).

**Approval Authorities:** Program Risk Officer (reports to co-chairs); co-chairs (authorize contingency draws and mitigation actions); external auditor (validates risk tracking and trigger logic).

### 9. Blind-Challenge Exercise Authority Charter and Scenario Design Framework

**ID:** 1ad7e871-42cc-4157-83b5-7df08dab5c5e

**Description:** Establishes the independent Exercise Authority (8 mixed-nationality core staff, funded from USD 500M testing envelope) with exclusive authority to design, schedule, execute and score all 54 blind-challenge exercises covering seven event types (unreported arrival, substitution, inaccurate records, delayed access, disputed identity, vendor refusal, reluctant operator). Specifies that each country's red team may nominate challenge types but the Exercise Authority alone decides execution timing and scoring. Exercises run only in staging, spare-inventory, maintenance or expansion areas (zero production disruption). Pilot exercise (all 7 types, non-production site) at Month 5 (2027-03-08). Phase One exercises (3–4 per month per site, Months 6–9 = 2027-04-08 to 2027-07-08) targeted at 6–8 replicates per type. Classified.

**Responsible Role Type:** Independent Exercise Authority Director

**Primary Template:** Verification-exercise design protocol (IAEA or OPCW precedent)

**Secondary Template:** Red-team challenge framework (adversarial-testing standard)

**Steps:**

- Define the Exercise Authority's independence: reports to neither co-chair; findings published to both co-chairs simultaneously; no co-chair input on scenario selection or scoring until after execution.
- Specify staffing: 8 core mixed-nationality staff (e.g., 4 per country or rotation), with sub-roles: (1) scenario designers (2–3), (2) logistics/staging coordinator (1), (3) video and chain-of-custody officer (1), (4) scorers/adjudication (2–3).
- Define the seven event-type scenarios: (1) unreported arrival: inject declared equipment into a staging area without operator notification; inspect and inspector detect arrival time and serial-number accuracy; (2) substituted equipment: place a functionally equivalent but non-declared piece of hardware in spare inventory; test whether physical inspection and identifiers detect the substitution; (3) inaccurate records: introduce deliberate discrepancies between customs declaration and maintenance logs; test whether record-cross-check identifies the gap; (4) delayed access: deny inspector access to a maintenance area for a specified period; test whether delayed-access findings are classified correctly in the evidence rule; (5) disputed identity: place equipment with partially matching serial numbers or firmware versions; test confidence-scoring under identity ambiguity; (6) vendor refusal: have a vendor claim inability to provide attestation for a piece of equipment; test fallback-ladder execution; (7) reluctant operator: have an operator claim operational-criticality of an area and limit inspector time; test whether limitations are recorded and categorized correctly.
- Draft scenario-specification template for each event type: equipment identifiers, expected inspector actions, success criteria (e.g., 'unreported-arrival detection within 4 hours of injection'), witness assignments, evidence documentation, post-exercise remediation steps.
- Specify the pilot-exercise protocol (Month 5 = 2027-03-08): conduct one instance of each of the seven event types at a non-production test datacenter, with full mirrored observation, evidence collection, filtering and ledger closure. Measure actual timelines, operator friction, evidence-collection fidelity and inspector behavior. Adjust Phase One scenario design based on pilot results.
- Specify the Phase-One exercise load: 3–4 exercises per month per site (2–4 sites depending on entry-condition outcome, proposed 3 sites = 6 sites total) × 3 months (Months 6–9 = 2027-04-08 to 2027-07-08) = 45–60 total exercises; goal ≥6 per event type (54 at 3 sites, 48 at 2 pairs = 4 sites).
- Lock the exercise scenarios in pre-registered form by Month 5.5 (2027-03-23): document equipment, scenario description, success criterion, witness list, evidence-collection protocol, expected completion time. Do not disclose scenario timing to site inspectors until exercise begins.
- Specify scoring procedures: independent video recording (uncut, chain-of-custody), witness statements (dual-signed), cryptographic attestation of exercise start/end times, detection-outcome determination (did inspectors detect the injected condition within the expected timeframe?), false-positive and false-negative tallying.
- Require that the Exercise Authority produce a post-exercise briefing (within 2 days of completion) showing: execution timeline, detection outcome, anomalies observed, evidence quality, lessons learned. Publish detection outcome (detected / not detected) to both co-chairs and the ledger; detailed briefing remains confidential to protect exercise realism.

**Approval Authorities:** Both co-chairs (approve Exercise Authority charter and funding); Exercise Authority Director (autonomous authority over scenario design and execution, reports findings to co-chairs).

### 10. Discrepancy Adjudication and Deadlock-Resolution Procedures

**ID:** 2ade0972-a73e-40e3-bc63-c6a6d126925d

**Description:** Specifies the full adjudication pipeline when inspectors disagree on a finding or co-chairs deadlock on evidence interpretation. Adjudication Panel: 6 technical specialists (3 per country) review conflicting evidence within 10 days, rule on which evidence category is most probative, and classify discrepancies as material (affects Go/Modify/Stop) or procedural. Deadlock procedure: if Panel recommendation is non-binding and co-chairs disagree, case is flagged for automatic partial suspension at day 14 (disputed function paused, unrelated sites continue). Age triggers: impaired-confidence flag at day 21 (identity disputes) and day 28 (exit dispositions). Emergency summit if suspension passes 35 days. Independent timekeeper tracks clock. Weekly dashboard shows age distribution and projected clearance date per case. Classified.

**Responsible Role Type:** Adjudication-Panel Chair / Deadlock-Resolution Manager

**Primary Template:** Dispute-resolution procedure specification

**Secondary Template:** IAEA Board of Governors adjudication protocol

**Steps:**

- Define the Adjudication Panel composition: 3 technical specialists per country (totaling 6), appointed by Month 5 (2027-03-08), with expertise in equipment identity, customs procedures and evidence synthesis. Panel operates independently of the co-chairs but reports to them.
- Define discrepancy types: (1) equipment-identity dispute (conflicting serial numbers, firmware versions, physical markings); (2) maintenance-record discrepancy (incomplete logs, delayed access preventing verification); (3) exit-disposition conflict (uncertainty about whether equipment was permanently disabled, transferred or released beyond boundary); (4) customs-record mismatch (arrival date or characteristics disputed); (5) ledger divergence (national copies show different event counts or timestamps).
- Specify the adjudication timeline: case opened when inspectors or co-chairs flag a discrepancy (timestamp in ledger); Panel convened by day 10; Panel interviews inspectors and site operators (within 3 days); Panel reviews conflicting evidence and applies the Layered Evidence-Weighting Rule to score confidence under each interpretation; Panel produces a written recommendation (non-binding) by day 15 identifying which evidence is most probative and whether the discrepancy is material or procedural; co-chairs have 3 days (day 18) to accept or override the Panel's recommendation (any override must be justified in writing and logged in ledger).
- Specify automatic escalations: if case remains unresolved (co-chairs disagree with Panel or with each other) at day 14, automatic partial suspension is triggered: the disputed function (e.g., intake verification if equipment identity cannot be confirmed) is paused, unrelated functions at other sites continue; suspension is logged in the ledger with co-chair notification; if either co-chair can offer a tie-breaking resolution by day 14 (before automatic suspension), suspension is stayed; if no resolution by day 14, suspension takes effect automatically.
- Specify impaired-confidence flags: if a discrepancy remains open at day 21 (identity/evidence disputes) or day 28 (exit/disposition disputes), automatic 'impaired-confidence' status is assigned to the equipment or site; this flag is published in the ledger and alerts co-chairs that the case is aging beyond acceptable thresholds; impairing-confidence status is equivalent to a presumption that further verification is required before the site can be cleared for Go verdict.
- Specify emergency-summit trigger: if any function remains partially suspended for >35 days (cumulative), an emergency co-chair summit is convened within 5 days with authority to decide: (1) extend suspension and accept the loss of verification for that function; (2) invoke the fallback (e.g., accept independent-examiner testimony in place of direct inspection); (3) declare the site failed and trigger a Stop decision for that site.
- Appoint an independent timekeeper (one officer per country, reporting to both co-chairs) who tracks case ages, suspension durations, and produces a mandatory weekly dashboard (every Monday, 09:00 CET) showing: count of open discrepancies by age bucket (0–7 days, 8–14 days, 15–21 days, 22+ days), count in automatic partial suspension (14+ days), count in impaired-confidence status (21+ days identity, 28+ days exit), projected clearance date per case. Dashboard is distributed to co-chairs and the independent risk officer; any discrepancy >20 days is highlighted for co-chair immediate attention.
- Specify adjudication staffing and surge capacity: baseline 5 adjudicators per country (10 total), target 15 cases/month; surge capacity 8–12 additional (4–6 per country) available on 48-hour call if caseload exceeds 25/month. Surge costs estimated USD 1.5–2M (within the USD 750M personnel envelope).
- Specify that all adjudication proceedings (Panel recommendations, co-chair decisions, suspension logs) are recorded in the ledger and published to both sides with necessary redactions for confidentiality; final audit trail supports the verdict credibility at Phase One conclusion.

**Approval Authorities:** Both co-chairs (approve Panel members and adjudication charter); Adjudication Panel (autonomous authority over evidence interpretation and materiality classification); independent timekeeper (confirms suspension and impaired-confidence triggers).

### 11. Inspector Deployment, Training and Compartmentalization Protocol

**ID:** 248c9c3e-f0e4-47f3-99f9-75204cbb0bb7

**Description:** Specifies recruitment, vetting, training and on-site operations for 300+ full-time inspectors (approximately 180 per country) working 24/7 shifts across 2–4 matched datacenter pairs. Includes: recruitment timeline (Month −3 to Month 0 = 2026-10-08 to 2026-10-08), security vetting and polygraph baseline (Month 2 = 2026-12-08), bilateral training academy curriculum (Months −1 to 5 = 2026-09-08 to 2027-03-08), shift schedules (4 months on-site, 2 months off-site, staggered rotation), compartmentalization by role and site (no inspector works >2 consecutive sites), debriefs and cooling-off periods (14 days minimum between reassignments), no personal devices on-site (secured phone only, monitored, 5-minute call limit), quarterly re-vetting by Counterintelligence Oversight Board, and retention bonuses (2–3% estimated USD 15–22.5M within the USD 750M personnel envelope). Classified.

**Responsible Role Type:** Inspector Recruitment and Deployment Manager

**Primary Template:** Personnel-management and security-clearance protocol

**Secondary Template:** Bilateral inspection-force training curriculum (IAEA or OPCW model)

**Steps:**

- Specify recruitment targets: 180–200 per country + 20% surge buffer (36–40 per country) + 45–60 leave-cover pool = total ~300 per country by Month 4 (2027-02-08). Break down by role: equipment-identity specialists (30% of corps), customs/logistics experts (20%), IT/network specialists (15%), maintenance-procedure observers (20%), general inspectors (15%).
- Detail recruitment process: job posting Month −3 (2026-07-08), application period Months −3 to −2 (2026-07-08 to 2026-08-08), first-round screening Month −2 (2026-08-08), second-round interviews Month −1 (2026-09-08), pre-employment vetting Month 0–1 (2026-10-08 to 2026-11-08), conditional offers Month 1 (2026-11-08), security-clearance submission Month 1 (2026-11-08), clearance completion target Month 2 (2026-12-08), onboarding Month 2–3 (2026-12-08 to 2027-01-08).
- Specify vetting procedures: baseline polygraph or equivalent by Month 2 (2026-12-08) for all 300+ inspectors, conducted by Counterintelligence Oversight Board (3 officers per country). Quarterly re-vetting on rotating schedule (every 3rd Friday starting Month 3 = 2027-01-08). Breach protocols: if vetting raises concerns, 48-hour investigation, 72-hour recommendation to co-chairs, 7-day decision on inspector clearance or recall.
- Detail training curriculum: 12-day bilateral academy course (Months −1 to 5 = 2026-09-08 to 2027-03-08) covering: (1) evidence collection and chain-of-custody (4 days); (2) sealed observation-report protocols (3 days); (3) equipment-identity verification procedures (3 days); (4) live-exercise execution (2 days). Train three cohorts (first Months −1 to 0, second Months 0–1 = 2026-10-08 to 2026-11-08, final Months 1–2 = 2026-11-08 to 2026-12-08) so 80% are certified by Month 2.5 (2026-12-23) and 100% ready for deployment by Month 5.5 (2027-03-23).
- Specify shift schedule and no-single-person-failure rule: 3 shifts per day (06:00–14:00, 14:00–22:00, 22:00–06:00 CET or site-local), minimum 4–6 inspectors per shift (2 per country × 2–3 per country), 3 sites × 2–4 sites depending on scope = 36–72 on-site at any time. Rotate cohorts on 4-month on-site, 2-month off-site schedule staggered so at least 80% of each shift's strength is always present. No single-person critical function (every role has backup).
- Specify compartmentalization and information firewall: inspectors assigned to specific sites (each works only 1 site for ≥4 months); roles separated by function (identity verification team separate from logistics team); post-rotation debriefs conducted by CI Oversight Board (4–6 hour sessions, anomaly-focused); cooling-off period of ≥14 days enforced before reassignment to any other role or site (logged by independent timekeeper); no personal phones on-site, monitored encrypted phone only, 5-minute call limit per shift, all calls logged.
- Specify training refreshers and morale: quarterly 2-day reorientation refresher for on-site inspectors (covering protocol updates, incident reviews, performance feedback); annual leave staggered across cohorts to maintain coverage; retention bonuses of 2–3% (estimated USD 15–22.5M) paid at end of Phase One for inspectors completing 9-month tenure.
- Specify performance metrics: shift-fill rate (target ≥95% of planned staffing present), personnel incident rate (breaches, protocol violations, injured inspectors, sick absences), training certification completion rate (target ≥95% certified by deployment), morale surveys (quarterly), attrition rate (target <10% during Phase One).
- Require monthly reporting to co-chairs on staffing status, certification progress, vetting results, compartmentalization compliance, and incident summary (redacted detail, unclassified count).

**Approval Authorities:** Both national co-chairs (approve staffing levels and training curriculum); Counterintelligence Oversight Board (approve vetting procedures and breach adjudication); Inspector Recruitment and Deployment Manager (operational authority over hiring, training and scheduling).

### 12. Replicated Ledger, Key-Custody and Cryptographic-Attestation Architecture

**ID:** f3416189-b745-49c3-bddb-f4749891dcac

**Description:** Technical specification of the tamper-evident replicated national ledgers (one per country) that record all Phase One events (equipment arrivals, installations, maintenance, departures, exercises, disputes, findings) with cryptographic timestamps and dual-nation signing. Specifies: local event recording (≤5 minutes latency), counterpart signed-digest synchronization (≥hourly), divergence detection (automated mismatch alert within 4 hours), reconciliation procedures (target 72 hours, hard limit 7 days), dual-share key generation (joint ceremony at neutral facility), key rotation (every 90 days, proposed), key recovery (if lost, 8–24 hour estimated recovery time, joint procedure), ledger archival (7-year minimum post-Phase-One). Classified.

**Responsible Role Type:** Replicated Ledger and Key-Custody Architect

**Primary Template:** Distributed ledger / blockchain technical specification

**Secondary Template:** CTBTO International Data Centre / IAEA digital-signature architecture

**Steps:**

- Define the ledger schema: event fields (timestamp UTC, event type, site ID, equipment identifiers, inspector names, witness signatures, evidence links, confidence score, discrepancy flags). Each event immutable once recorded (hash-chain validation).
- Specify local recording at each site: every inspection result, exercise injection/outcome, maintenance activity, equipment departure is recorded locally on hardened hardware (tamper-sealed device, airgapped from production network when possible) with cryptographic timestamp (within ±5 seconds accuracy). Inspector and site witness both sign the record. Local copy forwarded to the national ledger-hosting center within 1 hour.
- Specify synchronization: the national ledger-hosting center in each country transmits a signed digest (cryptographic hash of all recorded events for that day) to the counterpart every 1 hour. If a digest exchange is overdue by >30 minutes, an automated alert is sent to both co-chairs and the independent timekeeper; if overdue >4 hours, co-chairs are notified and reconciliation procedures begin.
- Specify divergence detection: if a transmitted digest does not match the counterpart's copy of the same day's events (indicating that one country recorded an event the other does not have), automated divergence detection triggers. The ledger system flags the discrepancy and prevents either country from certifying the ledger as complete until the divergence is resolved.
- Specify divergence reconciliation: both countries' ledger operators compare raw event logs for the diverged time window (typically 1–4 hours) and identify the missing or differing event. Possible causes: network delay (event in flight), data-entry error (typo, duplicate), clock drift (timestamp out of order), or evidence of tampering (event added without proper witness signature). Reconciliation team produces a joint statement (signed by both ledger operators and their supervisors) identifying the root cause and correcting the ledger (adding missing event, removing duplicate, or flagging the event as disputed). Target reconciliation time: 72 hours; hard limit: 7 days (after 7 days unresolved, the divergence is escalated to co-chairs and treated as a hard Stop condition: ledger integrity compromised).
- Specify key-custody architecture: dual-share keys generated in joint ceremonies at the neutral facility. Each country's key-custody officer (1 principal + 1 deputy per country) holds one non-reconstructable share. Both shares required to: (1) sign ledger events; (2) validate attestations from vendors or operators. If either share is lost or contested, key-recovery ceremony is invoked (estimated 8–24 hours, both countries present, new keys generated, old keys revoked and logged in ledger as an event).
- Specify key ceremonies: first ceremony Month 4 (2027-02-08); subsequent rotation ceremonies every 90 days (proposed). Key recovery rehearsal Month 5 (2027-03-08) using a simulated key loss (ledger temporarily blocked, both countries invoke recovery, ceremony executed under supervision, new keys validated, ledger updated). Document procedure and recovery timeline so both sides have confidence in the 8–24 hour recovery estimate.
- Specify ledger archival: upon Phase One conclusion, both national ledgers are encrypted and stored for 7-year minimum. Primary copy held by neutral facility; secondary copies held by each country's national archives or equivalent. Access restricted to: both co-chairs (indefinite), independent researchers after 50-year declassification (TBD), judicial or legislative bodies with co-chair written authorization.
- Specify that the ledger is immutable once archived: no retroactive amendments except through an explicit, dated amendment-record entry (e.g., 'Event X reclassified from discrepancy to non-material on Date Y by co-chair decision Z', with signatures and justification). Amendment records are appended to the ledger, not replacing original entries, so full audit trail is preserved.
- Specify operational monitoring: weekly dashboard of ledger health (synchronization latency, divergence incidents per week, resolution time, key-rotation timeliness, recovery exercise outcomes) reported to co-chairs and independent risk officer.

**Approval Authorities:** Both co-chairs (approve ledger architecture and key-custody procedures); independent cryptographic auditor (certifies that ledger design meets tamper-evidence standards); ledger-hosting facility operators (operational authority over local recording and synchronization).

### 13. Vendor-Refusal Fallback Ladder and Equipment-Unverifiability Classification

**ID:** d51cfc81-4501-4fb3-8d8a-65807d9ca021

**Description:** Specification of five-rung escalation procedure when a critical vendor (equipment manufacturer, maintenance provider, attestation source) declines participation or evidence provision. Rungs: (1) vendor-supervised testing (equipment tested under vendor observation, results certified by vendor); (2) filtered evidence (sensitive specs withheld, event-relevant detail only); (3) accredited independent examiners (third-party technicians certified by both governments examine equipment without vendor veto); (4) clean-room procedures (sealed examination in a restricted facility with chain-of-custody witness); (5) cryptographic attestation validation (vendor-supplied cryptographic proof of equipment identity, validated by independent auditors). Each rung consumes 8–12 weeks (estimated). Equipment unresolved at entry (Month 5.5 = 2027-03-23) is classified unverifiable or excluded from the covered-equipment schedule. Vendor-participation registry published Month 3 (2027-01-08) as entry-condition gate. Classified.

**Responsible Role Type:** Vendor Liaison Officer / Fallback-Ladder Coordinator

**Primary Template:** Supply-chain verification and vendor-cooperation procedure

**Secondary Template:** OPCW-style vendor-managed-access framework

**Steps:**

- Define vendor categories: Tier-1 (critical for covered equipment, refusal blocks site participation; examples: NVIDIA, AMD, Intel, Cerebras, custom-accelerator manufacturers), Tier-2 (maintenance providers, logistics partners; refusal complicates but does not block), Tier-3 (attestation sources, consultants; refusal handled case-by-case).
- Specify the fallback ladder: Rung 1 (vendor-supervised testing): equipment shipped to a secure facility designated by both countries, tested under vendor supervision (vendor employee present), results certified by vendor and counter-certified by an independent observer. Timeframe: 4–6 weeks (equipment transport, setup, testing, certification). Identity confidence: 70% (vendor supervision ensures authentic equipment but vendor incentive exists to misrepresent).
- Rung 2 (filtered evidence): equipment examined by bi-national inspector team, sensitive specifications (e.g., exact power consumption, network routing, cache design) withheld, only event-relevant data (serial number, physical markings, performance benchmarks) documented. Certified by both countries' attestation officers. Timeframe: 2–3 weeks (on-site inspection only, no vendor travel). Identity confidence: 60% (direct observation but limited detail increases unverifiable-equipment risk).
- Rung 3 (accredited independent examiners): equipment examined by a qualified third-country technician (e.g., a certified hardware engineer from a neutral country, pre-cleared and bonded by both governments). Examiner produces a report certifying equipment identity and condition without vendor veto or amendment. Timeframe: 6–8 weeks (examiner identification, pre-clearance, examination, report certification by both sides). Identity confidence: 80% (independent expertise high but examiner relies on vendor specifications for confirmation).
- Rung 4 (clean-room procedures): equipment placed in a sealed examination environment with restricted access, documented chain-of-custody, video recording of all handling. Dual-nation team performs physical examination (serial number verification, date-code confirmation, firmware check, functional test) under witness protocol. Result certified by both countries. Timeframe: 8–12 weeks (facility reservation, access procedures, examination, video processing, dual certification). Identity confidence: 85% (most rigorous procedure but high cost/time).
- Rung 5 (cryptographic attestation validation): vendor provides cryptographic proof (digital signature, hash commitment, hardware attestation key) of equipment identity and ownership history. Independent auditors from both countries validate the signature against known vendor keys and certify authenticity. Timeframe: 4–6 weeks (signature validation, auditor cross-check, bilateral certification). Identity confidence: 50% (relies entirely on vendor's willingness to provide accurate attestation; if vendor has refusal incentive, attestation credibility is low).
- Specify the escalation logic: if vendor refuses Rung 1, offer Rung 2 (faster, cheaper); if vendor refuses Rung 2, offer Rung 3 (independent perspective); if vendor refuses Rung 3, offer Rung 4 (procedural rigor); if vendor refuses Rung 4, offer Rung 5 (last option); if vendor refuses all five rungs, equipment is classified unverifiable and excluded from Phase One or marked as high-risk (unverifiable label).
- Specify timing: vendor refusals must be documented by Month 3 (2027-01-08) to allow time for fallback procedures to complete before the Month 6 (2027-04-08) Phase One clock. If a vendor refusal is received after Month 3 (2027-01-08), only Rungs 1–2 (fastest, 2–6 weeks) can complete before Month 5.5 (2027-03-23) entry certification; Rungs 3–5 (6–12 weeks) extend into Phase One, delaying equipment verification until mid-Phase-One.
- Specify equipment-unverifiability classification: if a critical Tier-1 vendor refuses and fallback is incomplete by entry, the affected equipment is either (1) excluded from the covered-equipment schedule (reduces verification scope but avoids operational delays), or (2) included with a 'conditional' label (verified only after fallback completes, data treated as provisional). Conditional classification is flagged as a reduction in Go-criteria attainment (increases the chance of Modify or Stop verdict).
- Specify that pre-staging of one accredited independent-examiner team per country (5–8 specialists, bonded by government) occurs by Month 1 (2026-11-08) from the USD 500M testing envelope, so Rung 3 can be activated immediately when a vendor refuses.
- Publish the vendor-participation registry (Tier-1 vendors committed, Tier-1 vendors refusing, fallback rung assigned, timeline for fallback completion) by Month 3 (2027-01-08) as an entry-condition gate; entry is not certified until all Tier-1 vendor positions are resolved (committed or fallback assigned).

**Approval Authorities:** Both co-chairs (approve fallback procedures and equipment-unverifiability classification); Vendor Liaison Officer (authority to escalate fallback rungs and assign unverifiability status).

### 14. Counterintelligence Oversight, Inspector Firewall and Security-Vetting Protocol

**ID:** 2c6a4056-44dd-4ae9-ae28-6579c424821e

**Description:** Operational procedures for detecting and adjudicating suspected intelligence-collection activity by or against deployed inspectors. Establishes a Bilateral Counterintelligence Oversight Board (3 senior CI officers per country, monthly classified meetings), baseline polygraph/security vetting for all 300+ inspectors by Month 2 (2026-12-08), quarterly re-vetting, breach investigation and adjudication (48-hour investigation, 72-hour recommendation, 7-day decision to clear, remediate or recall), compartmentalization rules (inspectors separated by site and role, minimum 14-day cooling-off before reassignment), sealed on-site communication (no personal phones, monitored encrypted phone only, 5-minute call limit), and post-rotation debriefs. Monthly unclassified breach-count summaries published to legislatures. Classified.

**Responsible Role Type:** Counterintelligence Director / Security Vetting Coordinator

**Primary Template:** Counterintelligence-investigation and breach-response procedure

**Secondary Template:** Personnel security vetting protocol (US National Security Council or equivalent).

**Steps:**

- Establish the Bilateral Counterintelligence Oversight Board: 3 senior CI officers per country (total 6), appointed by Month 0 (2026-10-08), reporting jointly to both co-chairs. Board meets monthly (every 2nd Tuesday, 14:00 CET via secure video) to review breaches, adjudicate suspected incidents, and validate compartmentalization compliance.
- Specify baseline vetting: all 300+ deployed inspectors undergo baseline polygraph or equivalent (or psych interview if polygraph unavailable) by Month 2 (2026-12-08), conducted at the neutral facility or in-country under CI Oversight Board supervision. Results held confidentially by the Board; failure or inconclusive result triggers additional investigation before deployment clearance.
- Specify quarterly re-vetting: rolling polygraph schedule on every 3rd Friday of each month starting Month 3 (2027-01-08), so all inspectors are re-vetted at least once every 90 days. Focus on changes in financial status, foreign contact, or unusual behavior reported by supervisors or peer inspectors.
- Specify breach investigation fast-track: if a breach is suspected (e.g., inspector caught photographing restricted area, offering to share technical detail, missing from shift), investigation initiates within 24 hours: (1) initial report to Board; (2) 48-hour investigation (interview inspector, supervisors, witnesses, retrieve logs); (3) 72-hour recommendation (Board advises clearance, remediation, or recall); (4) 7-day co-chair decision (authorize continued deployment, temporary suspension, or permanent recall). If investigation is inconclusive, inspector is stood down pending further review (no public disclosure).
- Specify compartmentalization rules: each inspector assigned to one site for ≥4 months; roles segregated by function (equipment-identity team separate from logistics team); no inspector works >2 consecutive sites in a career (rotation to a 3rd site only after 6+ months off-site); post-rotation debriefs conducted by CI Oversight Board officer (4–6 hour session focusing on unusual access requests, suspicious contacts, observations of other inspectors' behavior). Findings logged confidentially; if anomalies are detected, follow-up investigation is triggered but does not automatically result in breach determination.
- Specify cooling-off periods: minimum 14 days must elapse between the end of an inspector's assignment at Site A and the start of assignment at Site B (logged by independent timekeeper, exceptions only for surge approved by both co-chairs jointly). Cooling-off periods allow time for debriefing, compartmentalization to decay, and CI monitoring to detect any intelligence-collection attempts based on knowledge gained at the first site.
- Specify on-site communication security: no personal phones in the datacenter; all inspectors carry a monitored encrypted phone issued and controlled by the CI Oversight Board; phone allowance: 5 minutes per shift, outgoing calls logged (caller, date, time, duration, destination), incoming calls screened by duty officer (CI staff) before connecting; no SMS or data; personal email or internet access forbidden. Violations recorded as security incidents and investigated.
- Specify monitoring and incentives: publish unclassified monthly count of: breaches suspected, breaches sustained (confirmed after investigation), false positives (investigations cleared the inspector), enforcement actions taken (recalls, remediation assignments). Publish these metrics to both legislatures so oversight bodies see CI discipline in action. Incentivize inspector compliance through positive incentives (retention bonuses for clean vetting record, priority for leave, career advancement) in addition to security enforcement.
- Specify that CI findings (breach recommendations, suspensions, re-vetting results) are held confidentially by the Board; they do not enter the public ledger unless they result in formal sanctions (recall, suspension) which are recorded as Phase One incidents (logged event: 'Inspector X stood down due to vetting failure, dates Y–Z'). This confidentiality respects inspector privacy while maintaining transparency about operational impacts.

**Approval Authorities:** Both co-chairs (approve CI Board charter and vetting procedures); CI Oversight Board (autonomous authority over investigations and breach adjudication); both national CI agencies (operational support and vetting administration).

### 15. Neutral Facility Operations Charter and Physical-Security Specifications

**ID:** 1590ad29-1be5-460b-8934-f9a041825ed9

**Description:** Operational and security specifications for the joint neutral secure facility (Geneva or Singapore, site OPEN; decide by Month 1 = 2026-11-08) hosting the replicated national ledgers, key-custody ceremonies, secure reading rooms for raw-evidence escrow, co-chair boardroom, and secure communications infrastructure. Requires: 1,000+ sq m, ISO 27001 certification, IAEA-equivalent physical security, dual-nationality staff (no single-person critical functions), 24/7 staffed operations, monthly operations review by co-chairs, incident reporting within 4 hours, and joint control (no unilateral shutdown or access restriction). Operational budget estimated USD 15–25M (within the USD 750M secure-facilities envelope). Host-country memorandum of understanding signed by Month 1.5 (2026-11-23). Facility operational by Month 3 (2027-01-08). Classified.

**Responsible Role Type:** Neutral Facility Director / Operations Manager

**Primary Template:** Secure-facility operations and security procedures (IAEA precedent)

**Secondary Template:** Bilateral neutral-territory agreement (UN or international precedent).

**Steps:**

- Conduct a site-selection process (Months 0–1 = 2026-10-08 to 2026-11-08): identify 3–4 candidate cities (Geneva, Vienna, Singapore, other neutral location); evaluate host-country security framework, facility costs, staff availability, and political neutrality. Convene a Joint Facility Task Force (US and Chinese technical and diplomatic leads) to prepare an RFP and negotiate with host countries. Lock a primary and secondary facility candidate by Month 1 (2026-11-08), sign MOU with host country by Month 1.5 (2026-11-23).
- Specify physical-security requirements: perimeter security (CCTV, access gates, guards), restricted areas (key-custody room, ledger-hosting center, reading rooms) with biometric or dual-key card access, SCIF (sensitive compartmented information facility) equivalent rating for classified material handling, redundant power (UPS, generator), network isolation (air-gapped from public internet for ledger systems, monitored controlled network for co-chair communications), backup communications (satellite or redundant fiber links).
- Specify organizational structure: Facility Director (third-country national or co-appointed neutral figure), Deputy Directors (one from each country or neutral), Operations Manager, IT/Security Chief, CI Liaison (one per country), Finance Officer, Administrative Staff. Total estimated 15–20 full-time staff. No single person can unilaterally control access or operations; all critical functions require dual sign-off.
- Specify the key-custody chamber: isolated, air-gapped room (except for controlled ceremony entry), CCTV recording (24/7, archived), dual-locked door (one key per country), interior workspace for key-generation ceremony (with cryptographic hardware modules), post-ceremony key storage (in vaults or hardware modules sealed by both countries). Access log: every entry and duration logged, dual-witnessed.
- Specify the ledger-hosting center: climate-controlled server room (redundant cooling, fire suppression), replicated hardware for both countries' ledger copies (one set of servers per country, or mirrored servers with dual-key access controls), hourly digest-exchange infrastructure (monitored network link), backup power, automated malware scanning and intrusion detection, monthly security audits by independent third-party.
- Specify the secure reading room: space for two bilateral teams to review raw evidence (no copying equipment on-site, only reading terminals, dual escort required, session video recorded). Design: small room (~200 sq m), evidence held in sealed cabinets, inspectors and CI officers alternate escort duties, observer logs time and content viewed (redacted detail, unclassified count). Post-session: video archived, no records leave the facility.
- Specify the co-chair boardroom: secure classified meeting space, approved for sensitive discussions about deadlock, suspensions, and verdicts. Video conference capability for remote co-chair attendance (encrypted, dual-authenticated). No recording (information is highly sensitive); instead, a bilateral note-taker summarizes decisions and circulates for sign-off within 24 hours.
- Specify the operations procedures: 24/7 staffing (two shifts minimum), incident-reporting protocol (any security issue reported within 4 hours to both co-chairs and CI Oversight Board), monthly operations reviews (co-chairs meet, review incident logs, staffing status, budget burn, and facility maintenance). Annual security audit by independent third-party firm certified in IAEA or equivalent standards.
- Specify the host-country agreement (MOU): facility is neutral territory (neither country has unilateral authority over operations or access); both countries have equal standing in access decisions; host country provides physical security only (guards, perimeter); both countries staff internal security (CI, access controls); facility is immune from seizure or unilateral closure (either country can request mediation if the other abuses access, but cannot unilaterally shut down operations); 7-year minimum operational commitment (extends 2 years beyond Phase One for ledger archival and dispute resolution).
- Specify the budget: estimated lease/operations USD 3–5M per year (USD 6–10M for 2-year Phase One and transition); hardening/security infrastructure USD 2–4M one-time; staffing USD 5–8M per year (15–20 FTE at local salary scales); communications and IT USD 1–2M per year; contingency 20% (USD 2–4M). Total estimate USD 20–30M across the 2-year horizon, mapped to the USD 750M secure-facilities envelope.

**Approval Authorities:** Both co-chairs (approve facility site, MOU with host country, operational charter); Facility Director (operational authority, reports to co-chairs); co-chair deputies (day-to-day oversight, monthly operations reviews).

### 16. Communication and Stakeholder Engagement Plan

**ID:** 15eda329-06dc-47cb-9a1d-c8aa205a0afa

**Description:** Strategy for engaging legislative oversight bodies, the public, and media with transparent but classified-sensitive briefings on Consortium progress, budget, risks, and eventual verdict. Monthly unclassified dashboards to legislatures (KPIs on personnel deployment, entry-condition completion, exercise completion rate, adjudication metrics, contingency burn, incident counts). Annual public summary reports (declassified framing of mission, timeline, budget, success criteria). Coordination of joint US–China public statements emphasizing reciprocity and parity (no unilateral claims of advantage). Media protocol (no details on exercises, evidence, or findings until Phase One concludes and verdict is public). Designed to build public confidence in the mechanism while protecting operational security.

**Responsible Role Type:** Communications Specialist / Public Affairs Lead

**Primary Template:** Government communication and media-relations strategy

**Secondary Template:** Bilateral joint-statement protocol (arms-control precedent).

**Steps:**

- Identify stakeholder audiences: national legislatures (primary, monthly briefings required), executive branch (cabinet-level, co-chair-level, daily situational updates), media and public (annual declassified summary, no operational detail until verdict), academic and think-tank communities (post-Phase-One publication of methodology and results, classified detail subject to co-chair approval).
- Design legislative briefing: monthly unclassified slides (5–10 pages) summarizing: (1) schedule progress (entry-condition completion status, training completion rate, site selection status); (2) budget status (envelope burn, contingency draw rate, forecast for full program cost); (3) staffing and operations (inspector deployment count, shift coverage status, incident count, breach-investigation outcomes—count only, no names); (4) risk dashboard (red/yellow/green status for top 5 risks, mitigation status, escalation triggers); (5) outlook (next month milestones, anticipated decisions). Slide deck approved by both co-chairs before circulation; no classified detail or exercise results included.
- Design public annual summary: 3–5 page unclassified report (e.g., December year-end) covering: (1) mission statement (verify declared equipment changes at US–China datacenter pairs); (2) timeline (entry conditions complete, Phase One complete, verdict issued); (3) budget transparency (total spent of USD 5.0B cap, envelope breakdown, contingency usage); (4) success criteria (detection thresholds, parity requirements, verdict definition); (5) key milestone achievements (e.g., 'entry gate certified on schedule'; 'all 6 sites recruited and staff trained'; 'exercises completed without production disruption'). Results section published only at Phase One conclusion, showing detection rates, false-positive rate, Go/Modify/Stop verdict and brief rationale (not detailed findings).
- Coordinate joint US–China public statements: both governments issue simultaneous statements at key milestones (entry-gate certification, Phase One commencement, Phase One conclusion, verdict release). Statements emphasize: (1) mutual commitment to reciprocal verification; (2) parity of inspector access and exchange procedures; (3) pre-registered success criteria (shared by both sides); (4) transparent audit and accountability (independent observers, public metrics). Statements avoid claims of unilateral advantage ('X country detected more than Y' language is forbidden; instead, 'both sides achieved detection rates consistent with Go/Modify/Stop thresholds').
- Establish media protocol: no attribution of exercise details, methodology, or findings to either government until Phase One concludes; joint communications office issues only high-level status updates ('exercise program on schedule'; 'no production disruption incidents'). After Phase One verdict is issued, co-chairs jointly publish the full methodology, threshold results, and Go/Modify/Stop decision (unclassified summary); classified operational detail remains protected (exercise locations, specific scenarios, inspector identities redacted).
- Plan post-Phase-One publication: prepare manuscripts for peer review in recognized security studies or arms-control journals, covering: (1) verification-methodology innovation (double-key governance, deadlock procedures, automatic suspension); (2) statistical findings (detection rates, confidence intervals, threshold calibration); (3) lessons learned (what worked, what failed, recommendations for Phase Two or future mechanisms). Publication subject to mutual bilateral approval; redactions applied for operational security.
- Design legislator and media briefing schedule: formal briefings to legislatures (both houses/chambers if required) every quarter (Months 3, 6, 9 = 2027-01-08, 2027-04-08, 2027-07-08); media backgrounder at Phase One completion (Month 9 = 2027-07-08, under embargo until verdict release); public press conference at verdict release (Month 9.5 = 2027-07-23).

**Approval Authorities:** Both co-chairs (approve all public statements, briefing slides, and publication releases); communication leads (operational authority over message development and release timing).

### 17. Monitoring and Evaluation Framework

**ID:** e44bbaf2-53bf-438d-a1a1-2c5c833d974e

**Description:** KPI metrics, data-collection procedures, and reporting cadence for tracking Phase One progress against success criteria. Primary KPIs: detection rate (target ≥70% planned, ≥50% unplanned) by event type with confidence intervals; false-positive rate (target ≤10%); unverifiable-equipment share (target ≤5%); reciprocal-access parity (target ≥85%, definition TBD); discrepancy age (target <21 days max at conclusion). Secondary KPIs: exercise timely completion (target 6 per site per month), personnel deployment (target 80% on-site by Month 6 = 2027-04-08), adjudication caseload (target 15/month baseline), contingency burn (target <30% by Month 6 = 2027-04-08). Weekly dashboard reporting to co-chairs and risk officer. Monthly independent auditor validation (100% envelope-mapping sample, 10% financial sample). Classified.

**Responsible Role Type:** Monitoring and Evaluation Manager / KPI Tracker

**Primary Template:** Logical framework (log frame) KPI specification

**Secondary Template:** World Bank Results-Based Monitoring framework

**Steps:**

- Define the five primary Go criteria as KPIs with numeric targets and measurement methods: (1) detection rate = (number of exercises in which inspectors detected the injected condition within time window) / (total exercises of that type). Measured by Exercise Authority scoring, reported per event type and as pooled average. Target ≥70% planned class, ≥50% unplanned class, with ±12% confidence interval (95% CL) estimated. (2) False-positive rate = (number of discrepancies opened against equipment that later proven compliant) / (total discrepancies opened). Measured by Adjudication Panel post-closure review. Target ≤10% with ±3 point tolerance. (3) Unverifiable-equipment share = (equipment classified unverifiable at conclusion) / (total declared equipment at entry). Measured by schedule comparison and fallback-ladder completion status. Target ≤5% overall, ≤10% per site. (4) Reciprocal-access parity = (defined per operational parity metrics proposed by Month 4 = 2027-02-08; proposed measures: inspector-hour parity ≥90%, exercise-count parity ≥5 per type, data-access latency ≤3 days avg, challenge-outcome agreement ≥80%). Measured weekly during Phase One. Target ≥85% composite score. (5) Discrepancy age = (max age of any open discrepancy at Phase One conclusion). Target <21 days, Modify if ≤28 days, Stop if >28 days.
- Define secondary KPIs for operational health: exercise timely completion (count of exercises completed on schedule / count scheduled, target ≥95%), personnel deployment (count of inspectors on-site on planned date / planned headcount, target ≥80% by Month 6 = 2027-04-08), adjudication caseload (average new discrepancies per month, baseline 15/month, flag if exceeds 25/month for surge activation), contingency burn (cumulative draws from USD 500M contingency / cumulative expected draw, flag if >30% by Month 6 = 2027-04-08 indicating cost overruns or scope growth).
- Specify data-collection procedures: Exercise Authority submits detection-outcome form (within 48 hours of each exercise completion) to the KPI tracker, showing exercise type, expected outcome, actual outcome, confidence level, anomalies. Adjudication Panel submits monthly caseload report (new cases, closed cases, age distribution, false-positive post-reviews). Personnel Manager submits monthly deployment roster (on-site count vs. planned by shift and site). Finance Officer submits monthly envelope-burn report (actual vs. planned per envelope, contingency draw rate, forecast for final cost).
- Specify reporting cadence: KPI dashboard updated weekly (every Thursday, 15:00 CET), distributed to co-chairs and risk officer. Monthly summary (first Friday of month) aggregating all KPIs into a single slide pack (traffic-light status: green = on track, yellow = approaching threshold, red = threshold exceeded). Quarterly detailed report (Months 3, 6, 9 = 2027-01-08, 2027-04-08, 2027-07-08) with trend analysis and risk assessment. Annual public summary (declassified version) published at year-end for legislature and media.
- Specify escalation rules: if any KPI turns red (threshold exceeded) or yellow (approaching), the responsible unit (Exercise Authority, Adjudication, Personnel, Finance) briefs the risk officer within 24 hours and proposes mitigation. If a red KPI is unresolved within 5 days, it is escalated to co-chairs with a recommended decision (continue operations, activate contingency, or invoke Stop). If multiple KPIs are red simultaneously (e.g., detection rate low + adjudication backlog high + discrepancy age >21 days), emergency summit is convened within 5 days.
- Specify independent validation: monthly independent auditor review (budget auditor validates 100% envelope mapping for accuracy; statistical auditor validates detection-rate calculations and confidence intervals; personnel auditor validates inspector vetting records and incident logs). Auditors submit findings to co-chairs within 5 days of month close; any discrepancies or exceptions flagged for co-chair review.
- Specify that KPI targets are provisional and locked in the bilateral instrument; any threshold change requires double-key co-chair approval (amendments forbidden during Phase One, only before Month 6 = 2027-04-08 clock).

**Approval Authorities:** Both co-chairs (approve KPI targets and reporting cadence); independent auditors (validate data quality and calculation methods); Monitoring and Evaluation Manager (operational authority over dashboard updates and escalation decisions).

### 18. Open Publication and Intellectual-Property Licensing Plan

**ID:** 8c7445f0-ba81-4396-87eb-017086b896e9

**Description:** Strategy for sharing Phase One results, lessons learned, and methodology with the international arms-control and verification communities post-conclusion. Specifies which outputs are publishable (methodology papers, statistical findings, procedural lessons, public-verdict summary) and which remain classified (operational detail on exercises, inspector identities, site-specific vulnerabilities, intelligence-derived findings). Plans for peer-reviewed publication in security studies journals, bilateral coordination of manuscript release, and licensing frameworks (e.g., creative commons for non-classified materials) to enable other governments to adapt the Consortium model for other verification regimes. Open-access repositories designated (e.g., arXiv, SSRN, or bilateral document repository) for post-verdict availability.

**Responsible Role Type:** Knowledge-Management and Publications Lead

**Primary Template:** Government publication and IP licensing policy

**Secondary Template:** Open-access and creative-commons licensing framework

**Steps:**

- Identify publishable outputs: (1) methodology papers describing the double-key governance, deadlock procedures, automatic-suspension triggers, and their applicability to other bilateral verification scenarios; (2) statistical results (detection rates per event type, confidence intervals, false-positive rates) analyzed for what they reveal about verification feasibility; (3) lessons-learned report covering what worked operationally (shift scheduling, evidence filtering, adjudication capacity), what failed, and recommendations for Phase Two or future mechanisms; (4) public-verdict summary (the Go/Modify/Stop decision, threshold rationale, and strategic implications).
- Identify classified-sensitive outputs: operational detail on specific exercises (scenarios, injection methods, detection techniques—could inform future adversaries on how to evade), inspector identity and personnel records, detailed site vulnerabilities or security configurations, classified findings linked to specific governments or operators, intelligence-derived information from counterintelligence operations.
- Develop a publication timeline: scholarly manuscript drafting begins at Month 10 (2027-08-08, after Phase One conclusion and verdict release), targeting peer review and publication 12–18 months post-Phase-One (2028–2029 timeframe). Bilateral coordination required: both co-chairs' approval of manuscript before submission; redactions applied for classified content; joint acknowledgment in published papers.
- Specify licensing frameworks: methodology and lessons-learned papers published under creative-commons BY license (attribute both governments as authors, permit derivative works and reuse without royalty). Statistical data published in supplementary materials under CC-BY-SA (share-alike: reusers must credit original and maintain same license). Bilateral agreement permits other governments to cite methodology and adapt procedures for their own verification regimes (e.g., if a third country wants to implement bilateral monitoring with a neighbor, they can reference the Consortium framework as a procedural template).
- Designate open-access repositories: arXiv (physics / international relations category) for rapid dissemination; SSRN (social science research network) for working papers; bilateral secure repository (internal, for classified materials with time-locked release schedule, e.g., declassification after 25 years). Institutional repositories: each co-chair's national archives or think tank (e.g., US: think tank or national laboratory archive; China: government research institute).
- Establish a publications committee (both sides, 3–4 scholars and policy advisors per country) by Month 9.5 (2027-07-23) to review drafts for security appropriateness, strategic alignment, and narrative balance. Committee operates until 12 months post-verdict (Month 21 = 2028-07-08) to manage the publication pipeline.
- Plan for non-specialist public communication: develop a 'Consortium Results Brief' (2–3 pages, unclassified, graphics-rich, no jargon) explaining the verification concept, the Go/Modify/Stop decision, and why the outcome matters to international security. Distribute to legislatures, media, universities, and public libraries.

**Approval Authorities:** Both co-chairs (approve all publications before release); publications committee (manuscripts reviewed for security and accuracy); independent copy-editors and peer reviewers (for external credibility).

### 19. Appropriations and Funding Agreement Structure / Template

**ID:** e5ebc2f5-cdf2-4681-859b-e640426b4b1f

**Description:** Template bilateral appropriation agreement specifying how each government allocates USD 2.5 billion to the Consortium, maps expenses to the seven envelopes, establishes synchronized tranche release dates (25% Month 2 = 2026-12-08, 25% Month 3 = 2027-01-08, 30% Month 5.5 = 2027-03-23, 20% Month 9.2 = 2027-07-14), and defines tranche-withheld triggers (Stop conditions after 14 days escalation, 30 days hard Stop). Includes contingency-burn rules (30%, 50%, 75% draw triggers) and supplemental-appropriation veto points (envelope >120% of plan). Links funding releases to verifiable entry-condition and phase milestones to create accountability and prevent one country from withholding funds as a negotiation tactic.

**Responsible Role Type:** Finance Officer / Budget Authority

**Primary Template:** Bilateral funding agreement template

**Secondary Template:** International organization appropriation framework (World Bank, IAEA precedent)

**Steps:**

- Define the seven envelopes with per-country allocation (625M, 500M, 375M, 375M, 250M, 125M, 250M per country = 2500M per country).
- Specify that the first tranche (25% = 625M per country) is released upon signature of the bilateral instrument and enactment of domestic appropriations (Months 1–2 = 2026-11-08 to 2026-12-08).
- Specify that tranches 2 and 3 (25% and 30%) are released upon verified completion of entry-condition milestones (matched-pair approval, entry-gate certification by Month 5.5 = 2027-03-23).
- Specify that the final tranche (20%) is released upon publication of the Go/Modify/Stop verdict by Month 9.5 (2027-07-23), with no condition that the verdict must be Go (funding released regardless of outcome, so verdict is not biased by funding leverage).
- Establish synchronized-deposit requirement: both countries must deposit their tranches within 7 days of the milestone date; any delay >7 days triggers co-chair escalation; delay >14 days triggers tranche-withhold investigation; delay >30 days unresolved is a Stop condition (program halted pending funding resolution).
- Embed contingency-draw triggers: draw >30% of contingency (USD 150M total, 75M per country) triggers mandatory co-chair briefing and risk assessment; >50% triggers scope-reduction planning; >75% triggers joint budget review with external auditor.
- Specify that envelope overruns (actual spend >110% of plan) require co-chair review; >120% requires supplemental appropriation (new decision by both governments, may not be approved, creates veto risk).
- Require monthly independent audit: envelope-mapping sampled 100%, financial reconciliation (invoice matching, amount verification), contingency-burn reporting.

**Approval Authorities:** Both co-chairs (joint approval of funding structure and tranche milestones); both finance ministries or equivalent (appropriations authority); independent auditors (monthly verification of envelope mapping and spend reconciliation).

### 20. High-Level Schedule / Timeline (Gantt-Style Milestone Map)

**ID:** cc28f0d3-0a63-4046-abf2-8872cfcc7fcb

**Description:** Visual project schedule (Gantt chart or equivalent) showing all entry conditions (Months 0–5 = 2026-10-08 to 2027-03-08), pre-clock calibration (evidence rule validation, pilot exercise, threshold lock, Months 4.5–5.5 = 2027-02-23 to 2027-03-23), Phase One clock (Months 6–9 = 2027-04-08 to 2027-07-08), verdict scoring and publication (Month 9.2–9.5 = 2027-07-14 to 2027-07-23). Shows dependencies (e.g., instrument signature gates appropriation, which gates site selection). Identifies critical-path items and buffer time. Includes trigger points for escalation (gate slips >2 weeks). Updated monthly and reviewed by co-chairs.

**Responsible Role Type:** Project Manager / Scheduler

**Primary Template:** PMI PMBOK Gantt-chart template

**Secondary Template:** Critical-path-method scheduling

**Steps:**

- Map all entry conditions sequentially: instrument signature (Month 0.5 = 2026-10-23), domestic authority and first tranche (Month 1 = 2026-11-08), site nominations (Month 1 = 2026-11-08, parallel with instrument), vendor commitments (Month 1.5 = 2026-11-23), inspector approval (Month 2 = 2026-12-08), entry-gate certification (Month 5.5 = 2027-03-23).
- Identify dependencies (instrument signature is prerequisite for appropriation release; appropriation gates site-prep funding; site approval gates inspector deployment).
- Show parallel workstreams (e.g., site selection, vendor outreach, inspector recruitment all run in parallel starting Month −2 = 2026-08-08, reducing serial-dependency delays).
- Mark milestone dates with 2-week tolerance windows and escalation triggers (e.g., if gate slips >2 weeks, emergency summit convenes).
- Show pre-Phase-One calibration window (Months 4.5–5.5 = 2027-02-23 to 2027-03-23): evidence-rule validation, pilot exercise, threshold lock, all with completion dates.
- Show Phase One 90-day window (Months 6–9 = 2027-04-08 to 2027-07-08) and verdict timeline (Month 9.2–9.5 = 2027-07-14 to 2027-07-23).
- Identify critical path (the sequence of dependent tasks with least float) to highlight which task delays most directly compress the Phase One window.
- Update monthly and circulate to co-chairs; flag any gate approaching a slip threshold (yellow status if <1 week buffer remaining, red status if slip is imminent).

**Approval Authorities:** Project Manager (schedule updates); both co-chairs (major milestone changes); external escalation authority (if gates slip >2 weeks, authority may recommend schedule compression or scope reduction).

### 21. Change Management and Schedule-Amendment Procedure

**ID:** 0de13d6a-d92b-4dfd-93f6-082ad9c867a0

**Description:** Formal process for requesting, evaluating and approving changes to the bilateral instrument, entry-condition timeline, evidence-weighting rule, verdict thresholds, or operational procedures during Phase One. Specifies that entry-condition timeline changes and threshold changes are forbidden after Phase One clock begins (Month 6 = 2027-04-08) without invoking a Stop decision. Changes to evidence rule or verdict thresholds during Months 6–9 (2027-04-08 to 2027-07-08) (Phase One) require double-key approval AND rationale (linked to evidentiary findings) AND ledger annotation (so both sides can audit what was changed and why). Prevents ad-hoc scope creep and protects the integrity of the locked rules and thresholds.

**Responsible Role Type:** Change-Management Officer / Program Controller

**Primary Template:** PMI change-control and configuration-management procedure

**Secondary Template:** Bilateral treaty-amendment protocol

**Steps:**

- Specify that all changes during entry conditions (Months 0–5 = 2026-10-08 to 2027-03-08) require double-key co-chair approval; changes are documented in bilateral amendment memos (changes to instrument via formal amendment, changes to timelines via bilateral agreement, changes to rule/threshold via versioned rule-change log).
- Specify that no changes to verdict thresholds, detection-success criteria, or Go/Modify/Stop decision logic are permitted after the bilateral-instrument lock (Month 2 = 2026-12-08); thresholds are final and non-negotiable during Phase One.
- Specify that no changes to the evidence-weighting rule are permitted during Phase One (Months 6–9 = 2027-04-08 to 2027-07-08); if rule miscalibration is discovered (e.g., false-positive rate exceeds 15% instead of target 10%), the response is adjudication-surge activation or discrepancy-age tracking, NOT rule amendment.
- Specify that changes to operational procedures (exercise design, ledger procedures, inspector scheduling) during Phase One require co-chair approval AND documented rationale (why the change is necessary); change is logged in the ledger as an event so the audit trail shows that the procedure was modified.
- Specify that changes to entry-condition timeline (i.e., slipping a gate past its scheduled completion date) may be permitted only via the external escalation authority's decision (summit convened, decision within 5 days), resulting in either timeline extension (compressing Phase One by equivalent days) or scope reduction (fewer sites, shorter test).
- Create a change-request template: requester, description of change, rationale, impact assessment (does it affect Phase One timeline or verdict defensibility?), proposed implementation date, approval checklist (both co-chairs' sign-off, risk-officer review).
- Require that all changes are logged in a version-control ledger so both sides have visibility into what was changed, when, and why.

**Approval Authorities:** Both co-chairs (approve all changes); risk officer (assess impact on Phase One defensibility); Program Controller (administers change log and version control).

### 22. Post-Phase-One Funding Decision and Modify-Rework Scope (OPEN Item)

**ID:** 5ebb1196-fccf-42aa-9956-995c71f555ec

**Description:** Framework for deciding, by Month 8 (2027-06-08), whether a Modify verdict will trigger rework (additional exercises, extended testing window, rule refinement) or whether Modify is a final outcome that closes Phase One without continuation. Specifies that Modify means 'correctable weaknesses remain; Go cannot be claimed; Stop is not triggered'; rework would address the weaknesses identified in the verdict and lead to a revised Go/Modify decision or Phase Two mandate. Locks the funding and scope implications before the Month 9 (2027-07-08) verdict is issued, so the verdict itself is not seen as contingent on funding or political will for continuation.

**Responsible Role Type:** Program Director / Strategic Planning Lead

**Primary Template:** Gate-decision and continuation-authorization framework

**Secondary Template:** Bilateral phase-transition protocol

**Steps:**

- Specify that co-chairs must jointly decide by Month 8 (2027-06-08)—before the Phase One verdict is known—whether a Modify outcome triggers: (A) rework and Phase 2 (additional exercises, extended window, rule refinement; requires new appropriations authorization), (B) rework within Phase One budget (scope reduction elsewhere to free funds for extended testing; requires co-chair trade-off decision), or (C) Modify is a terminal outcome (Phase One concludes, results published, no Phase Two).
- Define rework scope if authorized: additional exercises (estimated 20–30 more exercises to narrow confidence intervals from ±12–32% to ±8–15%), extended test window (60–90 additional days), or rule refinement (revisit evidence-weighting assumptions based on Phase One data and adjust thresholds).
- Specify that the decision must be published unclassified (both governments announce the continuation plan before Phase One concludes) so legislatures and public understand that a Modify outcome does not mean the program was inconclusive or failed to reach closure.
- Lock any continuation funding and domestic legal authorization by Month 8 (2027-06-08) so rework can proceed immediately if a Modify verdict is issued at Month 9 (2027-07-08), without requiring a new appropriations decision that could slip the timeline.
- If Modify is terminal (no rework), specify the Phase-Two alternative: define the conditions under which Phase Two would be initiated (e.g., 'Phase Two authorized only if bilateral agreement is reached on the frontier-computing threat assessment and a new mandate is developed'; funding and timeline for Phase Two are OPEN pending that negotiation).

**Approval Authorities:** Both co-chairs (joint decision on post-Phase-One funding and Modify-rework scope); both legislatures or appropriations bodies (if new funding is required for rework or Phase Two).

## Documents to Find

### 1. US and Chinese Frontier Computing Hardware Specifications and Performance Metrics

**ID:** 860f7251-c556-46c9-a473-b1b2214246d1

**Description:** Technical specifications for frontier-computing equipment (GPUs, TPUs, custom accelerators, high-performance CPUs) deployed in US and Chinese datacenters, including peak TFLOPS, memory bandwidth, form factor, power envelope, and performance-test benchmarks. Used to establish the technology-neutral classification taxonomy (e.g., 'matrix-accelerator class 2: 100–500 TFLOPS FP32') for the covered-equipment schedule. Sourced from vendor datasheets, manufacturing specifications, and government procurement records (declassified or compartmentalized).

**Recency Requirement:** Current generation hardware (2024–2026 release dates); specifications valid for 12+ months to remain relevant through Phase One.

**Responsible Role Type:** Hardware Attestation Specialist / Technical Data Analyst

**Access Difficulty:** Medium—vendor datasheets are public; government procurement records may be classified or restricted; declassification of intelligence assessments may require 2–4 week review cycle. Mitigation: work with Vendor Liaison and classified-document-handling specialists to assemble the necessary specifications by Month 4 (2027-02-08).

**Steps:**

- Request vendor datasheets from Tier-1 manufacturers (NVIDIA, AMD, Intel, Cerebras, etc.) via Vendor Liaison Office.
- Access government procurement specifications from the participating datacenters' technical teams (equipment procurement records, performance-test results, maintenance logs).
- Review published benchmarking data from independent testing organizations (e.g., MLPerf, SPEC, industry publications).
- Consult defense/intelligence technical-assessment reports (if declassified; request declassification if necessary) on frontier-computing capabilities.

### 2. Historical Equipment-Change Records and Maintenance Logs from Participating Datacenters

**ID:** 6cce6d1c-8868-4148-9dc3-f065e487d5f7

**Description:** Past records of equipment arrivals, installations, maintenance events, and departures from the 2–4 matched datacenters (6–8 facilities total) for the past 12–24 months preceding Phase One. Includes equipment serial numbers, arrival/departure dates, customs records, maintenance personnel names, work performed, and parts replaced. Used to validate the evidence-weighting rule (pilot historical cohort of 100–200 events per site by Month 2 = 2026-12-08) and to serve as ground truth for false-positive and false-negative rate calibration. Declassified or compartmentalized within government.

**Recency Requirement:** Past 12–24 months preceding Phase One (roughly 2025–2026 data); historical data sufficient for calibration; must be complete and audited for accuracy.

**Responsible Role Type:** Evidence-Rule Architect / Data Analyst

**Access Difficulty:** Hard—datacenters are commercially sensitive operations; records involve proprietary equipment, customer data, and security information. Mitigation: establish data-sharing agreements with datacenters at the bilateral government level; agree on redaction rules (customer names, IP details removed; serial numbers and maintenance facts retained). Request data immediately after entry conditions are met (Month 5 = 2027-03-08) with deadline for delivery by Month 5.5 (2027-03-23).

**Steps:**

- Request from participating datacenters' operations teams; data may be held in multiple systems (asset-management software, maintenance ticketing, customs-clearance records).
- Coordinate through the Vendor Liaison Office to aggregate records from multiple vendors and site operators.
- Conduct data-quality review: verify timestamps, match serial numbers across customs and maintenance records, identify gaps or inconsistencies.
- Secure classified handling and compartmentalization: records contain sensitive facility information; restrict access to bilateral core team and evidence-rule architects.

### 3. US and Chinese National Laws and Regulations on Equipment Import/Export, Customs Procedures, and Datacenters Security

**ID:** f0c33d83-6b4e-4b61-bf38-e745ed9a21b1

**Description:** Relevant legal texts governing equipment arrival/departure from participating datacenters: import/export regulations, customs procedures, export-control classifications (if applicable to frontier computing), datacenters' domestic access authority (government authority to compel operator participation in inspections), and sanctions or IP-protection rules. Used to establish the domestic access-authority entry condition and to understand the legal basis for inspector access and operator cooperation. Sourced from national legislative assemblies, customs agencies, and commerce ministries.

**Recency Requirement:** Current laws in effect for 2026–2027 (i.e., binding at the time of Phase One execution); any pending legislative changes must be mapped (e.g., if new export controls are expected, they are flagged for impact on the covered-equipment schedule).

**Responsible Role Type:** Legal Counsel / International Trade Specialist

**Access Difficulty:** Easy—national laws are publicly available through legislative websites, government agency publications, and legal databases. Declassified trade agreements are publicly listed. Mitigation: assign legal counsel to compile and annotate the relevant statutes by Month 1 (2026-11-08).

**Steps:**

- US laws: search Congress.gov for current Export Administration Regulations (EAR), International Traffic in Arms Regulations (ITAR), customs statutes (19 USC), and any datacenters-specific security regulations.
- Chinese regulations: request text of relevant laws from the Ministry of Commerce, General Administration of Customs, and any sector-specific regulations (e.g., telecommunications infrastructure security law).
- International context: review WTO schedules, bilateral trade agreements, and sanctions regimes that might affect equipment movements.

### 4. Existing US and Chinese Data Center and Frontier Computing Operational Procedures (Baseline Benchmarks)

**ID:** fe620345-b023-40d7-8240-f94749db4e07

**Description:** Standard operating procedures, maintenance schedules, equipment-installation protocols, and security procedures from participating or comparable datacenters, used to understand realistic timelines and logistics for equipment arrivals, maintenance, and departures. Informs the design of blind-challenge exercises (e.g., unreported-arrival injection must match realistic datacenter intake procedures; maintenance-substitution test must align with actual scheduled maintenance frequency). Sourced from datacenters' internal documentation or publicly available case studies (e.g., hyperscale operator white papers).

**Recency Requirement:** Current practices (2024–2026); procedures may evolve, so baseline is established by Month 2 (2026-12-08) and refreshed if material changes occur before exercises begin (Month 6 = 2027-04-08).

**Responsible Role Type:** Facility-Operations Specialist / Exercise-Scenario Designer

**Access Difficulty:** Medium—operational procedures are proprietary; some may be classified for security reasons. Mitigation: negotiate confidential sharing agreements with datacenters as part of operator-participation agreements; redact sensitive security details; retain only the information needed to design realistic exercises.

**Steps:**

- Request from participating datacenters' operations and maintenance teams (bilateral government coordination).
- Access published benchmarking or case studies from hyperscale operators (Google, Microsoft, Amazon, Alibaba white papers on datacenter operations).
- Consult with industry-standard groups (e.g., OpenCompute Project for hardware specifications and operational procedures).
- Interview site operators during the Dry Run exercise (Month 4.5–5 = 2027-02-23 to 2027-03-08) to validate that planned exercises align with real operational windows and constraints.

### 5. IAEA Safeguards Verification Procedures and Case Studies (Bilateral Inspection Precedent)

**ID:** 6fe0ab3f-bd62-4c38-b461-9957b2dbb402

**Description:** Detailed descriptions of how the IAEA conducts declared-item inspections, manages access denied scenarios, designs and executes challenge exercises, operates replicated ledgers for accountancy, adjudicates discrepancies, and maintains inspector compartmentalization. Provides procedural templates and lessons learned for adaptation to frontier computing. Sourced from IAEA official documents, safeguards training materials, and published case studies.

**Recency Requirement:** Current IAEA procedures (2020–2026); historical case studies (e.g., JCPOA monitoring, past inspection challenges) for lesson-learned context.

**Responsible Role Type:** Bilateral Verification-Protocol Designer

**Access Difficulty:** Medium–Easy—IAEA publishes substantial material; some safeguards detail is classified for security reasons. Mitigation: request official briefings from IAEA safeguards office (Month 0 = 2026-10-08); identify unclassified case studies and procedural frameworks that can be adapted; coordinate with IAEA on any requests for classified operational detail.

**Steps:**

- Request from IAEA Department of Safeguards via official channels (bilateral government request or through the IAEA public information office).
- Access published IAEA Safeguards Glossary and technical reports on safeguards concepts (accessible on iaea.org).
- Review IAEA Board of Governors reports and implementation reports (publicly available, though some sections may be classified).
- Interview former IAEA inspectors or safeguards specialists (contact via professional networks, IAEA alumni associations, or think tanks).

### 6. OPCW Chemical Weapons Convention Industry Verification and Managed-Access Procedures

**ID:** 7163a9f4-52a7-4dcb-9dfb-d71fdc274bcb

**Description:** OPCW protocols for conducting inspections at commercial and state facilities, managing proprietary-information protection through managed access (restricted areas, redacted evidence), administering vendor and owner cooperation agreements, and adjudicating access-denial disputes. Relevant for understanding how to balance verification credibility with IP/security protection. Sourced from OPCW verification documents and implementation reports.

**Recency Requirement:** Current OPCW procedures (2020–2026); historical precedent for managed-access disputes.

**Responsible Role Type:** Inspector Information Firewall Doctrine Designer / Managed-Access Specialist

**Access Difficulty:** Easy–Medium—OPCW publishes verification framework; some operational detail may be classified. Mitigation: bilateral government request to OPCW for briefing and documentation sharing; expect 2–4 week turnaround for classified materials.

**Steps:**

- Request from OPCW Verification Division (via official government channel or OPCW public information office).
- Access OPCW annual reports and Verification Annex guidance (publicly available on opcw.org).
- Consult published academic papers or think-tank analyses of OPCW industry verification (e.g., Stimson Center, Carnegie Endowment, James Martin Center for Nonproliferation Studies).

### 7. US–Russia START and New START Bilateral Verification and Dispute-Resolution Precedent

**ID:** 01080cd8-c569-4978-aa88-31f428d0477d

**Description:** Detailed records of how START I and New START managed on-site inspections, operated the Joint Compliance and Inspection Commission (bilateral dispute resolution without a casting vote), handled deadlocks, administered inspector rotations, and maintained ledgers and accountancy. Provides lessons on how bilateral equal-footing verification can function and where it has broken down (e.g., suspension of inspections, unresolved compliance disputes). Sourced from US State Department archives, declassified documents, and secondary literature.

**Recency Requirement:** START I historical records (1990–2009) and New START records (2011–2026); most recent data more relevant for current diplomatic context.

**Responsible Role Type:** Bilateral Verification-Protocol Designer / Deadlock-Resolution Specialist

**Access Difficulty:** Medium—some documents are classified; declassified material is in archives; may require 4–8 week FOIA process. Mitigation: initiate request at Month 0 (2026-10-08) for critical documents (Joint Commission procedures, deadlock case studies); supplement with published analysis if classified documents are delayed.

**Steps:**

- Request from US State Department Bureau of Arms Control, Deterrence and Stability (requires official government channel).
- Access declassified documents through the National Archives or the State Department FOIA reading room.
- Consult published accounts: Arms Control Association fact sheets, SIPRI arms-control yearbook chapters, think-tank reports from Stimson Center, Carnegie Endowment, and Council on Foreign Relations.

### 8. Independent Statistician Review: Confidence-Interval Methodology and Sample-Size Validation

**ID:** 60e8eca0-7566-458e-ad79-2af3d27b82db

**Description:** External statistical analysis confirming that the proposed pooled detection-rate estimate (±12% at 95% CL) and per-type estimate (±32% at 95% CL) are realistic for n≈54 exercises with p (probability of detection) ≈0.70. Validates that the thresholds (Go ≥70%, Modify 55–75%, Stop <55%) are statistically defensible or ambiguous given the confidence intervals. May recommend adjustments to sample size (e.g., if intervals are too wide, recommend 90-day test instead of 60-day, or recommend Modify as default outcome when intervals straddle). Sourced from academic statisticians or government statistical agencies (e.g., US NIST, UK ONS equivalent, or university departments).

**Recency Requirement:** Analysis completed by Month 5 (2027-03-08) to inform final threshold lock before Phase One clock (Month 6 = 2027-04-08).

**Responsible Role Type:** Statistician / Quantitative Analyst

**Access Difficulty:** Easy–Medium—independent statisticians are available for hire or consultation; turn-around time typically 4–8 weeks for a technical review. Mitigation: commission the analysis at Month 3 (2027-01-08) to allow 2-month completion window before threshold lock.

**Steps:**

- Identify independent statisticians with experience in binomial inference and confidence-interval construction; candidates from universities, government statistical offices, or international organizations.
- Commission an analysis to validate the confidence-interval assumptions and threshold defensibility; provide them with the proposed sample-size plan, detection-rate assumptions, and decision rule.
- Request a written review (2–3 page technical memo) summarizing whether the thresholds are defensible, whether confidence intervals will be wide enough to create ambiguity, and recommendations for threshold adjustment or sample-size augmentation if necessary.

### 9. Facility Design and Hardening Standards: ISO 27001, IAEA-Equivalent Physical Security, SCIF-Equivalent Classification Handling

**ID:** b53a11f2-7a5c-4e82-98cb-de70f7c1bfe6

**Description:** International standards and government specifications for secure-facility design, applied to the neutral facility and national ledger-hosting centers. ISO 27001 for information security, IAEA or equivalent standards for physical security (perimeter, access controls, redundancy), SCIF (sensitive compartmented information facility) standards from US government or equivalent for classified information handling. Used to design the neutral facility and to evaluate site-readiness by Month 3 (2027-01-08). Sourced from international standardization bodies, government security agencies, and facility-design consultants.

**Recency Requirement:** Current standards (2023–2026); ISO 27001:2022 edition and later; US or international facility-design standards current at the time of facility construction (Month 2–3 = 2026-12-08 to 2027-01-08).

**Responsible Role Type:** Neutral Facility Director / Security-Design Architect

**Access Difficulty:** Easy–Medium—standards are published or available from government sources; some classified detail may require security clearance to access fully. Mitigation: assign facility-design team early (Month 0 = 2026-10-08) to acquire standards and design documents; engage with host-country facility providers (Geneva or Singapore) for preliminary site assessment by Month 0.5 (2026-10-23).

**Steps:**

- ISO 27001 standard from the International Organization for Standardization (ISO) official website or authorized distributor.
- IAEA facility security standards from IAEA Department of Safeguards publications or via official bilateral request.
- US SCIF standards from the Defense Counterintelligence and Security Agency (DCSA) or equivalent in other countries.
- Consult with facility-security design firms that specialize in classified government facilities (e.g., architecture firms with security clearances and relevant experience).

### 10. Recent US Government Policies and Statements on Frontier Computing, Export Control, and China Competition

**ID:** e5b091d4-b3ee-4dc0-9743-5ab2a2efd95c

**Description:** Current US government policy positions (executive orders, State Department guidance, National Security Strategy documents, congressional testimonies, Commerce Department export-control notices) on frontier computing as a national-security concern, export-control policies affecting semiconductors and advanced chips, and strategic-competition framing. Used to understand US domestic political context and constraints on the Consortium (e.g., if export-control policy forbids certain types of technology sharing with China, that affects the extent to which US can share evidence in the Consortium). Sourced from White House, State Department, Commerce Department, and congressional record.

**Recency Requirement:** Most recent (2024–2026) policy guidance; any pending policy changes anticipated by Month 1 (2026-11-08) relevant to Phase One scope.

**Responsible Role Type:** Policy Advisor / US Government Liaison

**Access Difficulty:** Easy—official government policy statements are public; some classified strategic guidance may not be published. Mitigation: work with US government liaison to request classified briefings on policy constraints by Month 0 (2026-10-08).

**Steps:**

- Search whitehouse.gov for National Security Strategy, executive orders on semiconductor security, technology competition frameworks.
- Check state.gov for official policy statements and congressional testimonies on China and frontier computing.
- Review commerce.gov for export-control regulations, commodity control lists, and recent amendments affecting semiconductors.
- Consult congressional testimony and reports (congress.gov) from committees overseeing national security, technology, and foreign relations.

### 11. Recent Chinese Government Policies and Statements on Frontier Computing, Technology Development, and US Relations

**ID:** c4517c42-d06b-49c5-a3f0-94407267a51c

**Description:** Current Chinese government policies (government pronouncements, industrial planning documents, regulatory guidance) on frontier computing and advanced-technology development goals, positions on US export controls and technology competition, and diplomatic stance on international cooperation mechanisms. Used to understand Chinese domestic political context and strategic interests in the Consortium. Sourced from state-council statements, ministry announcements, and official policy documents (available through official channels or international translators).

**Recency Requirement:** Most recent (2024–2026) policy guidance; any anticipated changes by Month 1 (2026-11-08).

**Responsible Role Type:** Policy Advisor / Chinese Government Liaison

**Access Difficulty:** Medium–Hard—official Chinese policy documents may be in Chinese language and not always translated; diplomatic liaison required to access official guidance. Mitigation: work with bilateral government liaison to request briefings and document sharing by Month 0 (2026-10-08).

**Steps:**

- Request briefings from Chinese government liaison on national development plans (e.g., Made in China 2025, any successor frameworks) as they relate to frontier computing.
- Access translated government documents through official diplomatic channels or professional translation services.
- Consult international media analysis and think-tank translations of official announcements (e.g., Carnegie Tsinghua, Brookings Institution China-focused publications).

### 12. Third-Country and International Organization Perspectives on US–China Verification and Arms-Control Precedent

**ID:** a045d2c4-043c-4782-9530-686057ce771d

**Description:** Positions and analyses from neutral third countries (e.g., Switzerland, Singapore, IAEA, OPCW) on bilateral US–China verification mechanisms, lessons from past bilateral negotiations, and feasibility of reciprocal verification in adversarial contexts. Used to inform risk assessment and to identify potential concerns from international observers about the Consortium model. Sourced from think tanks, IAEA/OPCW publications, and diplomatic channels.

**Recency Requirement:** Recent analyses (2020–2026) on US–China verification and arms-control feasibility; historical precedent for lessons learned.

**Responsible Role Type:** Strategic Communications Lead / International Relations Specialist

**Access Difficulty:** Easy—most analyses are publicly available through think-tank websites and international organizations; diplomatic briefings require official channels but are available. Mitigation: begin outreach to international organizations and think tanks at Month 0 (2026-10-08).

**Steps:**

- Request briefings from IAEA and OPCW on their perspectives on bilateral verification models.
- Consult neutral-country diplomatic advisors (Switzerland, Singapore) for perspectives on feasibility and risks.
- Review think-tank publications (Stimson Center, Carnegie Endowment, SIPRI, Stockholm International Peace Research Institute, Council on Foreign Relations) on US–China arms-control and verification topics.