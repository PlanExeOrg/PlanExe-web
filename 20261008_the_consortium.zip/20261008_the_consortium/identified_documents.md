
## Documents to Create

### 1. Bilateral Entry-Gate Steering Committee Charter and Operating Procedures

**ID:** bbb56647-045c-49d6-a1a7-bd7384dfca05

**Description:** Defines the bilateral steering committee's authority, membership, decision scope, escalation rules and weekly reporting cadence for tracking all seven entry conditions (instrument, appropriations, access authority, site selection, inspector approval, operator/vendor participation, schedule). Primary audience: co-chairs, national leadership offices. Includes decision authorities (co-chair level vs. principal level), condition-tracking dashboard specification and 48-hour escalation procedures for any slipped deadline.

**Responsible Role Type:** Bilateral Co-Chair and Governance Lead

**Primary Template:** Bilateral Steering Committee Charter Template

**Secondary Template:** Project Governance Operating Procedures Template

**Steps:**

- Define steering committee membership: one principal representative per country plus leads from inspectorate, ledger architecture and legal implementation.
- Specify decision scope: entry-condition tracking, weekly status reporting, escalation triggers (condition >2 weeks behind schedule), and principal notification procedure.
- Map each of the seven entry conditions to a responsible party, hard deadline and verification criteria (e.g., 'instrument signed by Month 7 (2027-05-12) 17:00 UTC').
- Design escalation procedure: any condition trending to miss its deadline triggers a 48-hour principal review and binary decision (accelerate, defer, or stop).
- Establish steering committee meeting cadence (proposed: weekly, fixed day/time), recording and documentation in the tamper-evident ledger.
- Lock the charter in the bilateral instrument before signature at Month 7 (2027-05-12).

**Approval Authorities:** Bilateral Co-Chairs and Principal-Level Leadership (National Deputy Secretaries or Equivalent)

### 2. Bilateral Instrument (Executive Agreement or Treaty)

**ID:** 9fb345d5-ec6e-4c38-a791-b748b459cbd0

**Description:** Binding legal agreement between the US and China establishing Consortium governance, double-key authorization, deadlock escalation procedures (5/8/13-day timers), enumerated automatic-suspension triggers, CHALLENGE-tag partition rule, reciprocal access parity definitions, covered-equipment schedule framework, ledger synchronization doctrine, and operational protocols. Includes confidentiality covenants, domestic compulsion authority assertions, personnel-clearance reciprocity and dispute-resolution procedures. Primary audience: both national governments, bilateral co-chairs, inspectors, operators. Classified minimum; unclassified executive summary for political messaging.

**Responsible Role Type:** Legal Implementation and Bilateral Instrument Lead

**Primary Template:** Bilateral Executive Agreement Template (State Department Model)

**Secondary Template:** Treaty Protocol on Verification Activities (IAEA/OPCW Precedent)

**Steps:**

- Establish bilateral legal working group by Month 0.5 (2026-10-27) with weekly drafting coordination.
- Negotiate core governance provisions: co-chair structure, double-key authorization, budget tranches, escalation timers.
- Draft deadlock escalation clause with explicit 5-day (co-chair consensus), 8-day (referee panel), 13-day (principal review) timers; specify status-quo default (heightened inspection) if unresolved.
- Enumerate objective automatic-suspension triggers with thresholds: unverifiable >3%, divergence >5%, denial variance >15%, discrepancy age >15 days; document that auto-suspension is reversible only with double-key and corrective-action documentation.
- Define CHALLENGE-tag partition: every injected scenario marked before injection; tagged events excluded from suspension; misclassification escalates within 2 hours with auto-reinstatement.
- Include covered-equipment schedule framework (role-based, version-controlled, double-key update procedure); ledger synchronization doctrine (hourly checkpoints, 1-hour synchronization, 4-hour divergence detection, 24-hour reconciliation closure).
- Incorporate domestic access-authority assertion: each signatory affirms legal authority to compel operator and vendor participation without exemption for state enterprises or national-security contractors.
- Address confidentiality, compartmentation rules, personnel-clearance reciprocity and incident reporting (facility breaches, CI concerns logged within 1 hour).
- Lock instrument signature deadline at Month 7 (2027-05-12); include contingency language for phased access authority or scope reduction if full instrument negotiation slips.
- Obtain principal-level legal review and approval before bilateral signature; publish an unclassified executive summary within 48 hours of signature.

**Approval Authorities:** Both National Co-Chairs, Principal-Level Leadership (Deputy Secretaries or Foreign Ministers), National Legislatures (if treaty; Executive Authorization if executive agreement)

### 3. Vendor-Participation Census and Binding Status Report

**ID:** 174daab2-40a3-42eb-8d4b-d613b6f97169

**Description:** Inventory of all equipment suppliers at each of the 4 participating sites, classified by vendor-binding status (A: binding signed and attestation keys validated; B: binding signed but keys pending; C: no binding or refused). Includes vendor-criticality assessment (% of declared equipment per vendor), legal-compulsion feasibility per jurisdiction, key-custody verification procedures, and escalation path for refusing vendors. Primary audience: bilateral co-chairs, legal team, clean-room operations lead, principals. Used to compute unverifiable-equipment forecast and validate the 3% material threshold.

**Responsible Role Type:** Vendor Binding and Equipment Identity Verification Lead

**Primary Template:** Supply-Chain Risk Assessment Template

**Secondary Template:** Vendor Qualification and Audit Matrix

**Steps:**

- By Month 1 (2026-11-12), request that each site operator declare at least 95% of its supplier list by equipment count, with contact information for each vendor's verification and legal representative.
- Classify each vendor by binding status: A (binding signed + attestation keys validated by bilateral cryptography team), B (binding signed + key validation pending), C (no binding or refusal).
- Compute unverifiable-equipment count by vendor and per site (sum of all Tier C equipment); flag any vendor representing >5% of declared equipment at a site for principal-level escalation.
- Assess legal-compulsion feasibility per jurisdiction: identify any vendor in the US that is a private entity (compellable) vs. state enterprise in China (verify legal authority); document any anticipated litigation.
- By Month 2 (2026-12-12), escalate all Tier C equipment (>5% of site total or representing a critical vendor) to principals for decision: accept unverifiable count, activate clean-room examination fallback, or reduce declared equipment list.
- Document disposition of each vendor: binding execution date, attestation-key fingerprint, clean-room examination results (if applicable), or refusal reason and date.
- By Month 8 (2027-06-12), publish final vendor-status summary with unverifiable-equipment count per site and validation that all Tier A and B vendors are on-track for Phase One start.

**Approval Authorities:** Bilateral Co-Chairs, Vendor Binding Task Lead, and Principals (for Tier C escalation decisions)

### 4. Deadlock and Suspension Mechanics Operating Procedure

**ID:** 3047ed52-4588-468f-92ea-a028d1598e3e

**Description:** Detailed step-by-step procedure for escalating contested site findings through the 5/8/13-day deadlock ladder, activating the Bilateral Technical Referee Panel, enforcing escalation timers, and executing automatic-suspension triggers. Includes adjudication authority at each tier (co-chairs, referees, principals), required inputs and outputs (e.g., dual-signed fact statements), ledger recording and audit trails. Primary audience: operational co-chairs, referees, principals, dispute-resolution officer. Locked in the bilateral instrument.

**Responsible Role Type:** Bilateral Dispute Resolution and Deadlock-Escalation Manager

**Primary Template:** Bilateral Dispute Resolution Standard Operating Procedure

**Secondary Template:** Escalation Timer and Decision-Authority Framework

**Steps:**

- Define deadlock trigger: bilateral consensus not achieved on a site finding within 5 calendar days of initial co-chair notification.
- Specify Tier 1 (Days 1–5): co-chairs attempt consensus; any finding still contested at end of Day 5 auto-escalates to Tier 2.
- Tier 2 (Days 5–8): Bilateral Technical Referee Panel (2 experts per side, pre-cleared by Month 8, 2027-06-12) receives full case file within 24 hours; referees conduct independent fact-finding and issue a dual-signed advisory statement within 3 days (by end of Day 8).
- Tier 3 (Days 8–13): Principal-level review receives referee statement and both governments' rebuttals; principals must issue a joint decision within 5 calendar days (by Day 13).
- Default rule if unresolved by Day 13: status quo defaults to heightened inspection (increased access requests, daily evidence audits, additional witnesses) pending further escalation to top political level.
- Enumerate objective automatic-suspension triggers that bypass deadlock procedure: unverifiable >3% for 5 consecutive days auto-suspends without co-chair discretion; divergence >5%, denial >15%, age >15 days also auto-suspend within 24 hours of threshold breach.
- Define challenge-event misclassification as fast-track escalation: if a CHALLENGE-tagged event is flagged as operational and triggers auto-suspension, principals are notified within 2 hours and site operations auto-reinstate within 2 hours pending adjudication.
- Establish adjudication docket maintenance: dispute manager logs every contested finding, tracks aging discrepancies, publishes weekly aging list in KPI dashboard, and highlights any >10-day or >15-day aging for principal visibility.
- Include procedure for reversing an auto-suspension: suspension is lifted only upon bilateral co-chair counter-signature of a corrective-action plan and a finding-closure or re-adjudication decision.
- Lock this procedure in the bilateral instrument with explicit language that neither co-chair can unilaterally waive escalation timers or suspension triggers.

**Approval Authorities:** Bilateral Co-Chairs and Principals (for each escalation tier decision)

### 5. Challenge-Exercise Misclassification Protocol and Escalation Procedure

**ID:** 2dcbab2a-b8c1-4e00-8720-dac6a00ec4f5

**Description:** Operational procedure for detecting, reporting and resolving cases where a challenge-exercise event (marked CHALLENGE before injection) is flagged as operational by the intake protocol or automated systems, triggering an incorrect automatic suspension. Includes real-time duty-officer alert routing, 2-hour principal-escalation window, automatic site reinstatement, and ledger recording of misclassification resolution. Primary audience: operational duty officers, co-chairs, principals, inspectors. Tested via dry-run drill by Month 8.75 (2027-07-05).

**Responsible Role Type:** Bilateral Dispute Resolution and Deadlock-Escalation Manager, Incident Command Center Lead

**Primary Template:** Incident Response and Escalation Procedure Template

**Secondary Template:** Crisis Management and Emergency Decision-Authority Protocol

**Steps:**

- Define misclassification event: a challenge-exercise scenario tagged CHALLENGE in the sealed ledger is incorrectly flagged as operational (unverifiable equipment, unresolved discrepancy, access denial, etc.) by inspectors or the automated suspension-trigger system.
- Establish automated detection: the ledger ingestion system must validate every non-CHALLENGE event against the challenge-exercise catalog sealed hash; if an event matches a CHALLENGE scenario but lacks the CHALLENGE tag, auto-flag and log to 'partition-audit' ledger.
- Specify duty-officer alert routing: upon auto-flag, the Incident Command Center (staffed 24/7 by one senior officer per country) is notified within 15 minutes with event detail, CHALLENGE-tag status, and preliminary assessment.
- Define duty-officer decision window: officers jointly review the flagged event within 30 minutes and decide: (1) mark as reconciled (tag was present but system error), (2) escalate to co-chairs for 2-hour consensus, or (3) immediately escalate to principals if consensus unlikely.
- Specify principal escalation within 1 hour of misclassification flag: both co-chairs and designated adjudication referees receive full case file (event record, CHALLENGE-tag proof, inspector statements, automated flags).
- Define principal decision options: (A) confirm misclassification, reverse suspension, mark site as reinstatement-pending; (B) confirm genuine operational issue despite CHALLENGE tag (tag was malformed or scenario was executed outside exercise protocol), proceed with suspension; (C) convene immediate bilateral review.
- Establish automatic reinstatement procedure: if principals or duty officers decide misclassification, the ledger records a 'MISCLASSIFICATION_RESOLUTION' entry with decision text, signatures, timestamp and effective reinstatement date.
- Specify KPI dashboard backfill: the misclassified event is excluded from all threshold calculations (unverifiable count, discrepancy age, divergence, etc.) retroactively; metrics are recalculated as if the event did not occur.
- Include penalty for excessive false positives: if >3 misclassifications occur at any single site during Phase One, automatic escalation to impaired-confidence review, and potential suspension of challenge-exercise operations at that site pending bilateral review.
- Mandate inspector training by Month 8.5 (2027-06-27): all inspectors receive a 1-hour mandatory briefing on CHALLENGE-tag recognition, the escalation workflow, the 2-hour decision window and the non-suspension rule; document signed acknowledgment in each file.
- Schedule a full misclassification drill by Month 8.75 (2027-07-05) simulating a CHALLENGE event flagged as operational; measure end-to-end time from auto-flag to duty-officer notification to co-chair decision; validate <2-hour completion.

**Approval Authorities:** Bilateral Incident Command Center (for initial detection and duty-officer decision), Bilateral Co-Chairs (for consensus escalation), and Principals (for decision within 1 hour of flag)

### 6. Equipment Identity Verification and Attestation-Validation Protocol

**ID:** 38f18bb8-a7db-4417-a9d2-a30cdd929baf

**Description:** Detailed procedure for intake-protocol identity verification, including the three-tier evidence ladder (attestation + customs/maintenance + physical inspection; no single layer decisive), conflict-resolution rule (>=2 independent layers must agree within ±2 hours for 95% confidence), accredited-examiner validation process for vendor attestation keys, and fallback pathways (clean-room examination, supervised testing, unverifiable escalation). Primary audience: intake inspectors, accredited examiners, bilateral attestation-validation specialists. Tied to the Equipment Identity Trust Anchor strategic decision.

**Responsible Role Type:** Vendor Binding and Equipment Identity Verification Lead, Cryptographic Hardware Attestation Engineer

**Primary Template:** Equipment Identity Verification and Chain-of-Custody Procedure Template

**Secondary Template:** Cryptographic Attestation Validation and Key-Escrow Protocol

**Steps:**

- Specify the three-tier evidence hierarchy: (Tier 1) vendor-issued cryptographic attestation independently validated by accredited examiners from both countries; (Tier 2) customs records, shipment tracking, maintenance logs and witnessed movement; (Tier 3) physical inspection (serial numbers, equipment identifiers, tamper seals), facility records and inventory counts.
- Define the 'no single layer decisive' rule: attestation alone, customs records alone, or physical inspection alone cannot establish identity confidence >90%; at least two tiers must independently and affirmatively agree within ±2 hours.
- Document accredited-examiner process: each country designates >=2 examiners per site (by Month 8, 2027-06-12) with cryptographic-key validation training; examiners independently verify vendor signatures on attestation chains using pre-distributed bilateral public keys; mismatch flags require bilateral referee adjudication within 2 days.
- Specify attestation-key custody verification: each critical vendor (>5% of declared equipment) must participate in a bilateral key-derivation ceremony or deposit a key fingerprint with both governments' cryptographic specialists by Month 7 (2027-05-12); keys are stored in Hardware Security Modules (HSMs) under shared custody (one half-key per country) where feasible.
- Define conflict-resolution rule: if attestation and physical inspection disagree on identity (e.g., firmware version mismatched between attested claim and actual device), the unit escalates to the Bilateral Technical Referee Panel for dual-signed adjudication within 2 business days; unresolved conflicts default to unverifiable status.
- Document fallback evidence layers for vendor refusal or attestation-key unavailability: Tier 2 (customs + maintenance + physical) is sufficient for identity confirmation if both tiers are independently available and agree within ±2 hours; Tier 3 (physical + facility records) can establish identity if Tier 1 and Tier 2 are unavailable.
- Specify clean-room examination fallback: if vendor refuses attestation validation, the unit enters supervised independent examination at an accredited clean-room center; examiners conduct non-destructive forensic analysis (firmware extraction, hash computation, physical-mark verification) and issue a sealed report confirming or denying identity match.
- Define unverifiable escalation: any unit failing identity confirmation across >=2 tiers is classified unverifiable; unverifiable status is logged in the tamper-evident ledger with reason code (attestation unavailable, customs records absent, physical marks tampered, etc.); cumulative unverifiable count per site is reported weekly in the KPI dashboard.
- Establish identity-confidence scoring: assign a confidence percentage to each intake decision (100% = >=2 tiers agree; 80-90% = tiers mostly agree with minor timestamp/label discrepancies; <80% = conflicting tiers, escalate to referees); target: >=95% of intake decisions reach >=95% confidence; <95% is a leading indicator for filter-adequacy or corroboration-layer issues.
- Lock this protocol in the bilateral instrument by Month 7 (2027-05-12); validate accuracy and bi-country agreement in the filter-adequacy pre-test at Month 8.5 (2027-06-27).

**Approval Authorities:** Bilateral Co-Chairs and Accredited Examiner Task Lead (for each examiner certification and key-validation ceremony)

### 7. Inspection Zone Geometry and Evidence Filtering Design Specification

**ID:** f24ea99b-4483-4a40-9ceb-8a513a2437bd

**Description:** Physical and logical design of bounded inspection zones at each of the 4 participating sites (staging, spare-inventory, maintenance, expansion areas only; production halls and model-weight data areas strictly off-limits), including zone boundaries, access-control specifications, pre-validated instruments allowed, and the operator-controlled redaction-gateway filtering rules. Specifies minimum evidence schema (serial number, firmware hash, attestation digest, maintenance timestamp, physical identifiers, tamper-seal state; cluster membership and power state redactable only by bilateral agreement) and audit trail for filter decisions. Primary audience: facility operators, inspectors, zone-security personnel. Operationally validated in filter-adequacy pre-test by Month 8.5 (2027-06-27).

**Responsible Role Type:** Filtered Evidence and Redaction-Gateway Architect

**Primary Template:** Physical Security and Facility Access-Control Specification

**Secondary Template:** Data Redaction and Filtering Rule Specification Template

**Steps:**

- Define zone boundaries: staging (500–1000 sq m estimated), spare-inventory (300–500 sq m estimated), maintenance (200–300 sq m estimated), equipment-expansion (200–300 sq m estimated); mark all boundaries with paint lines and electronic-access control points.
- Install physical access controls: biometric card readers (+ iris recognition at entry) for zone access; no manual keys; event logging (name, date, time, purpose) of every entry/exit in the tamper-evident ledger within 30 minutes.
- Specify allowed instruments: pre-validated and host-country-approved only; examples: serial-number readers (air-gapped), firmware-extraction devices (isolated, no internet), cryptographic-attestation validation tokens (pre-loaded with bilateral public keys), photographic equipment (film-based preferred, or secured-digital with restricted export).
- Prohibit: recording devices not pre-approved, connected IT systems (laptops, tablets, smartphones) except air-gapped assessment terminals, external storage media, or copying of sensitive materials beyond the approved redaction gateway.
- Define the redaction gateway: operator-staffed, host-country-personnel-operated (counterpart does not operate the host's gateway); gateway converts raw records and telemetry into schema-limited evidence packets before export; all filter decisions logged in the tamper-evident ledger with timestamp, field name, reason code and authorizing engineer.
- Specify minimum evidence schema (non-redactable): equipment serial/unique identifier, firmware version or cryptographic hash, attestation digest, maintenance-event timestamp and type, physical identifiers with tamper-seal state, cluster membership only if necessary for identity verification.
- Define redactable fields (bilateral agreement required for each): power-consumption telemetry, cluster topology details, workload-specific parameters, source-code paths, model-weight or quantization data.
- Lock all redaction rules in a bilateral-signed filter-rule document by Month 7 (2027-05-12); require both countries' sensitive-asset experts to co-sign; document that any field stripping without explicit bilateral written agreement automatically escalates equipment to unverifiable status.
- Establish auditing procedure: counterpart's engineers review and validate all redaction rules (but not the raw input data or the gateway's internal operations) by Month 7.5 (2027-05-27); any rule that appears to strip non-redactable fields triggers bilateral legal review within 48 hours.
- Embed full-time host-country operator liaisons at each site by Month 1 (2026-11-12); liaisons audit inspector zone compliance daily, monitor all redaction-gateway operations, and alert co-chairs to any boundary violations within 2 hours.
- Include zone-violation penalties in the bilateral instrument: minor violation (inspector >1 step beyond marked line, resolved within 1 hour) = formal warning; major violation (deliberate entry to production hall or model-weight area) = immediate removal from site and investigation; repeat violations = personnel rotation or site closure.
- Validate zone geometry and redaction-gateway adequacy in the filter-adequacy blind pre-test at Month 8.5 (2027-06-27): inject test substitutions with edge-case fields near redaction boundaries and measure detection rate with proposed filters applied; require >=85% detection before scored exercises begin.

**Approval Authorities:** Bilateral Co-Chairs (zone geometry approval), both Countries' Sensitive-Asset Experts (filter-rule co-signature), and Operators (facility safety certification)

### 8. Ledger Synchronization and Divergence Doctrine

**ID:** 46a85f1d-f4e9-480d-9419-9c167d95c6df

**Description:** Technical specification for the replicated tamper-evident ledger system maintaining independently verifiable copies at each country's hardened secure facility. Covers checkpoint format (proposed: hourly signed hash-chain with bilateral timestamp, nonce, event count, digital signatures), transport protocol (dedicated IPsec/TLS tunnels, no shared internet), synchronization latency KPI (<=1 hour proposed), divergence-detection window (<=4 hours proposed), reconciliation procedure (<=24 hours closure), and neutral-party digest-escrow role. Includes cryptographic key-exchange ceremony, facility security requirements, incident-logging protocols and forensic-analysis procedures. Primary audience: ledger architects, cryptographic specialists, IT security teams, neutral custodian.

**Responsible Role Type:** Secure Ledger and Tamper-Evidence Systems Architect

**Primary Template:** Replicated Ledger and Distributed-Consensus Protocol Specification

**Secondary Template:** Cryptographic Checkpoint and Non-Repudiation Audit-Trail Standard

**Steps:**

- Specify ledger copy architecture: two independently maintained ledger nodes, one per country, each with full read/write authority over its own entries; no third-party cloud or shared infrastructure.
- Define checkpoint format: hourly digital record containing (event count, local timestamp, bilateral timestamp, bilateral nonce, hash of all events since last checkpoint, bilateral signatures from both countries' ledger architects).
- Specify synchronization transport: dedicated IPsec tunnel with Perfect Forward Secrecy; mutual TLS authentication (each ledger node has a pre-distributed certificate); no shared internet routing; dedicated lines if available, or segregated VPN if not.
- Lock synchronization latency KPI: checkpoint exchange within 1 hour of local recording; any checkpoint >1 hour behind triggers co-chair alert within 15 minutes and automated reconciliation procedure within 4 hours.
- Define divergence detection: materiality threshold (proposed: >5 events disputed per site per week or >5% of all events conflicting); divergence detected within 4 hours triggers automated reconciliation log entry and bilateral notification.
- Specify reconciliation procedure: upon divergence detection, ledger architects from both countries exchange detailed event logs for the diverged period within 6 hours; compare timestamps, signatures and event content; identify root cause (network latency, processing delay, or tampering); resolve mismatches within 24 hours.
- Document resolution outcomes: if divergence is due to network latency (younger ledger copy is just behind), synchronize and re-checkpoint within 24 hours; if due to processing error (logic bug), roll back to last agreed checkpoint and re-process; if due to suspected tampering, escalate to co-chairs and forensic audit.
- Establish neutral-party digest escrow: contract with an internationally accredited custodian (not a government entity) to hold hourly signed digests of both national ledger copies; costs estimated USD 20–30M within USD 1.25B ledger envelope; escrow entries are made hourly and locked (no modification or deletion); either government can demand a forensic audit of escrow copies post-Phase-One to prove non-tampering.
- Include facility security requirements: each ledger node facility is a SCIF-equivalent hardened datacenter with biometric access control, Faraday cage for cryptographic HSM, continuous intrusion detection (network and host-based), UPS and 72+ hour backup power, climate control, 24/7 armed host-country security.
- Specify incident-logging protocol: all divergence, synchronization latency, facility incidents or security alerts are logged in the tamper-evident ledger within 1 hour of discovery with full context (alert timestamp, root cause, remediation, restart time).
- Define forensic-analysis authority: post-Phase-One, either government may request a forensic audit of the ledger divergence log and digest escrow to reconstruct any tampering incidents; neutral custodian provides signed audit trails and expert analysis.
- Lock this doctrine in the bilateral instrument by Month 7 (2027-05-12); conduct cryptographic key-exchange ceremony between ledger architects by Month 8 (2027-06-12); validate checkpoint exchange and divergence detection in operational dry-run at Month 8.5 (2027-06-27).

**Approval Authorities:** Bilateral Ledger Architecture Task Lead and Cryptographic Specialists (technical design), Bilateral Co-Chairs (operational KPI approval and neutral-custodian selection)

### 9. Counterintelligence Vetting Protocol and Insider-Threat Red-Team Operations Specification

**ID:** 6ec45284-0b4d-4783-a9cb-f1d5bee845fe

**Description:** Comprehensive personnel-security vetting procedure for all ~350–500 cleared inspectors and technical staff, including background investigation (criminal, financial, foreign contacts), polygraph examination, reciprocal intelligence-service clearance verification, and compartmentation audit. Specifies 6-month site-tenure limits with 2-month breaks between assignments, compartmentation rules (no cross-site knowledge, event-type segregation), and insider-threat red-team operational procedures (social engineering, financial-compromise attempts, unauthorized-access testing). Primary audience: CI specialists, personnel-security officers, polygraph examiners, inspectors, human resources. Operationalized by Month 8 (2027-06-12); insider-threat red-cell operations run Months 0–12 (2026-10-12 to 2027-10-12).

**Responsible Role Type:** Counterintelligence and Personnel Security Unit Lead

**Primary Template:** Personnel Security Vetting and Clearance Reciprocity Protocol

**Secondary Template:** Insider-Threat Red-Team Operations and Testing Procedures

**Steps:**

- Specify background-investigation components: employment history (>=5 years), criminal history (US national and international searches), financial history (credit reports, debt verification), foreign contacts and travel (visa records, foreign-policy travel lists), family connections (parents, siblings, spouse foreign birth or employment), and current allegiances (club memberships, political affiliations, religious organizations).
- Define polygraph protocols: standard counter-intelligence polygraph (US GSS-PDD, or Chinese equivalent); administered by accredited examiners trained in bilateral protocols; focus questions: recent contact with foreign intelligence services, unauthorized access to classified information, unreported financial compensation or gifts, unauthorized foreign travel.
- Specify reciprocal-clearance verification: US State Department and Intelligence Community clearances must be verified by Chinese security authorities (e.g., Ministry of State Security liaison); Chinese-cleared personnel must be verified by US intelligence community; reciprocal-clearance verification is conducted by liaison teams in Months 0–2 (2026-10-12 to 2026-12-12) and is an entry-gate condition.
- Document compartmentation rules: each inspector is assigned to a single site (either US or China, not rotating between countries); within site, inspectors are compartmented by event type (e.g., intake team has no knowledge of exit dispositions; exit team has no knowledge of maintenance-event details); no inspector holds cross-site, cross-event or cross-country knowledge.
- Specify compartmentation audit: quarterly (Months 3, 6, 9 = 2027-01-12, 2027-04-12, 2027-07-12) compartmentation audits measure whether inspectors have accessed information outside their assigned scope; any cross-compartment access is logged and investigated within 48 hours.
- Lock tenure limits: no inspector assigned to the same site for >6 consecutive months; mandatory 2-month break before reassignment to any site; no counterpart-country reassignment within 12 months of previous deployment.
- Define insider-threat red-cell operations: 2 senior red-cell operatives per country (funded from testing envelope, USD 500M) conduct simulated compromise attempts (social engineering via gift or financial offer, unauthorized-access testing via fake phishing, relationship-capture scenarios via attractive intelligence officer interactions); all red-cell activities are coordinated with CI leadership and authorized by bilateral co-chairs; no real-harm attempts.
- Document red-team reporting: all attempted-compromise incidents are logged in the tamper-evident ledger within 48 hours with: target name, compromise vector, response by inspector, outcome (compromised, rejected, inconclusive), and CI assessment of vulnerability.
- Include investigation procedures: if an inspector is approached or shows signs of compromise, immediate removal from site, notification to bilateral co-chairs within 2 hours, investigation by host-country CI plus bilateral liaison within 5 days, and determination whether to prosecute or terminate employment.
- Specify consequences for compromise or unauthorized access: confirmed compromise results in immediate arrest and prosecution; verified unauthorized cross-compartment access results in removal from inspectorate and referral for prosecution or administrative separation; unconfirmed allegations are investigated before any action is taken.
- Establish continuous vetting: during Phase One, quarterly CI reviews ensure compartmentation compliance and no new foreign-contact or financial-compromise indicators emerge; flagged personnel are re-polygraphed and cleared before continuing operations.
- Lock this protocol in the bilateral instrument by Month 7 (2027-05-12); complete background investigations and polygraph by Month 2 (2026-12-12); deploy red-team operations by Month 2 (2026-12-12) and maintain ongoing activities through Month 12 (2027-10-12).

**Approval Authorities:** Counterintelligence Unit Lead (design), Bilateral Co-Chairs (authorization of red-team operations), and Principals (for investigation and prosecution decisions)

### 10. Challenge-Exercise Design and Independent Testing Plan

**ID:** 1417806b-8bbd-448a-b79e-0f0620b66dd5

**Description:** Comprehensive plan for blind challenge exercises testing detection of unreported arrival, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal, and reluctant operators across 7 event types. Specifies independent-tester authorship and injection procedure, sealed hash-committed scenario catalog (published in advance, scenarios encrypted until injection), blind scoring by each country's independent team, sealed-score comparison, and false-positive containment. Includes filter-adequacy pre-test (Month 8.5 = 2027-06-27, >=10 injections, target 9 of 10 detected, halt if <85%), preliminary calibration exercises (Months 9.5–10.5 = 2027-07-27 to 2027-08-27, unscored), and scored exercises (Months 10.5–11.5 = 2027-08-27 to 2027-09-27). Validates detection rates, evidence-filtering adequacy, reciprocal access and inspector presence effectiveness. Primary audience: challenge-exercise design panel, independent testers, bilateral co-chairs, adjudication referees.

**Responsible Role Type:** Challenge Exercise Design and Independent Testing Lead

**Primary Template:** Blind Exercise Design and Scoring Protocol Template

**Secondary Template:** Independent Testing and Validation Procedures

**Steps:**

- Establish independent Challenge Exercise Design Panel by Month 1 (2026-11-12): 2 technical experts + 1 CI officer per country, pre-cleared by both governments' security services, funded from USD 500M testing envelope.
- Specify independent tester role: each country's red-team personnel design and inject blind scenarios at the counterpart's sites without advance notice to operating inspectors; injection occurs in staging, spare-inventory, maintenance and expansion areas only; zero disruption to active compute or customer-data areas.
- Design 7 event types with 10+ injections each (70+ total): (1) unreported arrival: add 5-10 undeclared units to spare-inventory overnight; (2) substituted equipment: replace a declared unit with a similar unit under different serial/firmware; (3) inaccurate records: falsify maintenance logs or customs records for a known unit; (4) delayed access: simulate an access-denial scenario during scheduled inspection; (5) disputed identity: submit a unit with conflicting attestation and physical marks; (6) vendor refusal: withhold cryptographic attestation keys for a unit; (7) reluctant operator: require extensive justification before granting access to a zone.
- Define sealed scenario commitment: each country's exercise panel designs scenarios, computes cryptographic hash digest, and publishes the digest in the ledger by Month 1.5 (2026-11-27) without revealing scenario details; scenarios are encrypted and stored offline until injection time.
- Specify injection procedure: at injection time (unannounced), the injecting team logs the scenario UUID, timestamp, and bilateral digital signature into the ledger; the CHALLENGE tag is applied simultaneously; operating inspectors and systems are blind to the injection.
- Document blind-scoring process: each country's independent observers (separate from operating inspectors) score the detection outcome for each injected scenario against jointly agreed criteria (e.g., 'substituted equipment is detected if the intake inspector flags identity-confidence <90% and escalates to unverifiable status'); scoring is done independently and sealed (no communication between national teams until after scores are compared).
- Define sealed-score comparison: by Month 11.75 (2027-10-05), both countries' sealed scores are opened simultaneously in the presence of bilateral observers; scores are compared for divergence; if national-team scoring diverges >10% on any event type, technical referees issue a dual-signed fact statement reconciling the scores.
- Specify false-positive containment: any challenge event that is misclassified as operational (e.g., a CHALLENGE substitution is not detected and is classified as unverifiable, triggering a site suspension) is escalated to co-chairs within 2 hours; automatic site reinstatement pending principal adjudication; documented as MISCLASSIFICATION_RESOLUTION in the ledger.
- Include filter-adequacy pre-test by Month 8.5 (2027-06-27): inject at least 10 substitution scenarios in staging and spare-inventory areas with full redaction-gateway filtering applied; measure detection rate (target >=90%, minimum 85%); if <85%, halt all scored exercises and renegotiate filters with operators.
- Specify preliminary (unscored) calibration exercises Months 9.5–10.5 (2027-07-27 to 2027-08-27): run a subset of scenarios (10–15 injections) to validate exercise procedures, measure staff familiarity and baseline detection performance, and fine-tune scoring criteria; results are not used for Go/Modify/Stop verdict, but inform threshold-calibration decisions.
- Lock all exercise procedures in the bilateral instrument by Month 7 (2027-05-12); publish exercise schedule (dates, general descriptions, but not scenario details) by Month 2 (2026-12-12) to allow operators to prepare secure facilities and evidence-handling procedures.
- Include post-exercise audit: by Month 12 (2027-10-12), publish a redacted exercise summary report listing: number of injections per event type, detection rates, false positives and negatives, and major findings; document any systemic weaknesses in detection capability.

**Approval Authorities:** Challenge Exercise Design Panel (exercise design), Bilateral Co-Chairs (injection authorization), and Technical Referees (sealed-score divergence reconciliation)

### 11. Verdict Evidence Sufficiency and Threshold Calibration Protocol

**ID:** ef642475-7387-4c43-a162-7b4d2b8331dd

**Description:** Specification for defining, pre-registering, validating and calibrating Go/Modify/Stop thresholds. Covers threshold documentation (95% identity confidence, 3% unverifiable equipment, 90% blind detection, 10% parity variance, 1-hour ledger synchronization), validation methods (pre-test results, early blind exercises, historical precedent), marking of provisional figures, calibration procedures (threshold review after Month 8.5 = 2027-06-27 pre-test and again after preliminary exercises Months 9.5–10.5 = 2027-07-27 to 2027-08-27), threshold freeze before scored exercises, and scoring-divergence analysis at verdict time. Includes decision rule: if national teams' detection-rate scores diverge >10% on any event type, technical referees resolve divergence before verdict is finalized. Ensures Go/Modify/Stop verdict is evidence-based, not political. Primary audience: Bilateral Co-Chairs, Threshold Calibration Review Panel, Technical Referees, Adjudication Unit.

**Responsible Role Type:** Independent Auditor and Evidence Sufficiency Validator

**Primary Template:** Threshold Definition and Calibration Methodology

**Secondary Template:** Evidence-Sufficiency Validation and Go/Modify/Stop Decision Framework

**Steps:**

- Enumerate all Go/Modify/Stop thresholds in a single document by Month 1 (2026-11-12): identity confidence >95% (provisional); unverifiable equipment <=3% per site (provisional); blind detection >=90% per event type, 7 types x 10+ injections (provisional); false-positive rate <=2% per event type (proposed); false-negative rate <=10% (proposed); parity variance <=10% (proposed); ledger synchronization <=1 hour (proposed); divergence detection <=4 hours (proposed); divergence reconciliation <=24 hours (proposed).
- For each threshold, document the validation method: figures supported by empirical pre-test data (e.g., filter-adequacy pre-test at Month 8.5 = 2027-06-27), figures based on historical precedent (e.g., New START detection rates), and figures that are assumptions pending empirical validation (mark as 'provisional').
- Specify calibration checkpoints: (1) Month 8.5 (2027-06-27) filter-adequacy pre-test results inform identity-confidence and detection-rate assumptions; (2) Months 9.5–10.5 (2027-07-27 to 2027-08-27) preliminary (unscored) exercises generate early detection-rate and false-positive data for calibration review; (3) Month 10.5 (2027-08-27) Threshold Calibration Review Panel issues a calibration report with any recommended threshold adjustments, locked before scored exercises begin.
- Establish Calibration Review Panel by Month 7 (2027-05-12): 2 senior technical experts per country, pre-cleared, funded from testing envelope; panel reviews all available empirical data by Month 10 (2027-08-12) and recommends threshold adjustments or confirms original provisional figures.
- Define calibration report contents: for each threshold, report the empirical data source, actual observed value (if available), confidence interval, recommended threshold adjustment (if any) and justification, and sign-off by both countries' experts.
- Specify threshold-freeze procedure: all thresholds must be locked (no further changes) by Month 10.5 (2027-08-27), before scored exercises begin; any recommended adjustments from calibration must be jointly approved by bilateral co-chairs by that date.
- Include scoring-divergence rule: at verdict time (Month 12.25 = 2027-10-20), if one country's blind-exercise scores show detection rate >=90% and the other's show <90% for any event type, divergence >10% triggers technical-referee adjudication; referees issue a dual-signed fact statement reconciling the scores within 5 days; Go decision cannot be finalized until scoring divergence is resolved or documented as unresolved.
- Specify provisional-figure labeling in the final verdict report: every threshold marked (provisional, calibrated based on X data, validated through Month 11.5 = 2027-09-27 exercises) or (evidence-based, supported by Y empirical observations); explicitly state residual uncertainty (e.g., 'Go decision is based on 90% detection assumption, which was validated by 70 injections showing 63 correct detections = 90% observed; confidence interval ±5% at 95% confidence'; or 'Unverifiable threshold 3% is provisional, not empirically calibrated').
- Lock this protocol in the bilateral instrument by Month 7 (2027-05-12); conduct calibration review by Month 10.5 (2027-08-27) and publish calibration report in the ledger and KPI dashboard.

**Approval Authorities:** Threshold Calibration Review Panel (empirical review and recommendations), Bilateral Co-Chairs (threshold approval and freeze authorization)

### 12. Independent Budget Audit and Fiscal Accountability Plan

**ID:** 63ff9b71-a966-49a3-abeb-7fc4e9e1efea

**Description:** Specification for independent auditor role (not a government employee, internationally accredited, jointly appointed), tranche-release procedures, monthly burn-rate reporting by budget envelope, spending-parity monitoring (±10% divergence threshold, 20% impaired-confidence trigger), contingency-draw governance (USD 10M bilateral approval, USD 375M=75% escalation to principals), and currency-conversion rule documentation. Includes monthly KPI dashboard sections for cumulative disbursement, envelope burn rates, divergence alerts and contingency status. Primary audience: bilateral co-chairs, national budget authorities, independent auditor, principals.

**Responsible Role Type:** Independent Budget Auditor and Fiscal Accountability Officer

**Primary Template:** Independent Fiscal Audit and Tranche-Release Certification Template

**Secondary Template:** Budget Parity and Contingency-Monitoring Framework

**Steps:**

- Procure an independent, internationally accredited auditor (not a government employee, no conflicts of interest) by Month 2 (2026-12-12); costs estimated USD 5–10M from the USD 250M legal/audit envelope; auditor will certify each quarterly tranche release by demonstrating spending parity and envelope compliance.
- Establish CNY-to-USD fixed-conversion rule by Month 7 (2027-05-12): both governments lock a single exchange rate for the entire Phase One period (no floating-rate hedging); document the rate in the bilateral instrument and in tranche-release accounting.
- Specify tranche-release schedule: 4 equal quarterly tranches of USD 625M per country (USD 1.25B combined) released at Months 7, 10, 13, 16 (2027-05-12, 2027-08-12, 2027-11-12, 2028-02-12); tranches 3–4 release only if verdict is not Stop and both co-chairs double-key authorize continued spending.
- Define tranche-release criteria: cumulative-disbursement parity within ±10% of pro-rata share; no single envelope overspent by >15%; contingency drawn <75% (USD 375M); unresolved audit exceptions <5 items.
- Document monthly burn-rate reporting: by the 5th business day of each month, auditor issues a detailed report by envelope (ledger, site prep, personnel, facilities, testing, legal/audit, contingency) with: itemized receipts, cumulative totals per country, pro-rata share calculations, and parity-variance percentage.
- Specify spending-divergence escalation: >15% monthly divergence requires explanation from both co-chairs within 5 days; 20% divergence triggers impaired-confidence review by technical referees; >20% persistent divergence holds tranche release pending bilateral principal review.
- Define contingency-draw governance: draws above USD 10M require bilateral co-chair approval; draws approaching USD 375M (75% of contingency) trigger automatic escalation to principals for decision on supplementary appropriation or scope reduction; any contingency draw is documented in the ledger with reason code and bilateral sign-off.
- Include CNY-accounting reconciliation: auditor reviews monthly spending reports from both countries in local currency; converts Chinese CNY amounts to USD using the locked rate; documents conversion methodology and any rounding adjustments; audits for compliance with USD envelope caps.
- Specify contingency-draw restrictions: USD 50M gate-readiness sub-account (part of USD 500M contingency) is held in escrow, accessible only upon simultaneous certification of all 7 entry conditions; all other contingency draws require documented justification (cost overrun for specific item, e.g., vendor-refusal litigation, personnel surge) and bilateral authorization.
- Establish tranche-release procedure: auditor certifies spending parity and envelope compliance; both co-chairs counter-sign the certification; funds are transferred into bilateral holding account within 3 business days; funds are then drawn by operators and vendors as needed per approval of each government.
- Include currency risk management: note that 90-day Phase One exposure to USD/CNY fluctuation is minimal (likely <3% variance); no external hedging instruments are used; all transactions use the locked bilateral rate documented in the instrument.
- Lock auditor appointment and CNY-conversion rate in the bilateral instrument by Month 7 (2027-05-12); begin monthly audits starting Month 7 (2027-05-12) for tranche 1 release; produce KPI dashboard sections for monthly and cumulative spending by Month 8 (2027-06-12).

**Approval Authorities:** Independent Auditor (spending parity certification), Bilateral Co-Chairs (tranche-release authorization), and Principals (for divergence >20% or supplementary-appropriation decisions)

### 13. Operator-Consent Status Monitoring and Incident-Escalation Procedure

**ID:** 18e4037c-90b6-441f-94c0-d0838c058edf

**Description:** Operational procedures for tracking operator willingness to participate, documenting consent status (full/degraded/withdrawn), escalating consent violations, and managing operator access or withdrawal. Includes quarterly operator-confidence surveys, formal consent-withdrawal procedures (written notice required, escalation to principals within 24 hours), operator-liaison audits of zone-boundary compliance and evidence handling, and trigger-escalation rules (boundary violation, evidence leak, counterpart interference). Primary audience: operator liaisons, bilateral co-chairs, operators, principals.

**Responsible Role Type:** Operator Liaison and Site-Consent Monitor

**Primary Template:** Stakeholder-Consent and Compliance-Monitoring Procedure

**Secondary Template:** Incident Escalation and Remediation Workflow

**Steps:**

- Establish operator liaisons (one full-time host-country representative per site embedded in inspectorate) by Month 1 (2026-11-12); liaisons report to both operators and bilateral co-chairs; liaisons have read-only access to operational ledger entries and inspection reports (no authority to modify).
- Specify operator-consent tracking: consent status is formally established at Phase One start (Month 9 = 2027-07-12) via operator written authorization; status is reviewed monthly by bilateral co-chairs and published in KPI dashboard as 'Operator Consent Status: [site name] [full/degraded/withdrawn]'.
- Define consent-withdrawal procedure: consent is withdrawn only upon formal written notice from operator's authorized representative (designated in advance) to both co-chairs, stating grounds with specific incidents or dates; verbal complaints or single-incident objections do not constitute withdrawal but trigger degraded-consent review.
- Specify degraded-consent triggers: <=1 formal boundary violation cleared within 48 hours; operator complaint about zone access procedures resolved within 5 days; temporary impediment to access due to equipment maintenance or security incident resolved within 10 days.
- Document consent-withdrawal consequences: automatic site suspension within 24 hours upon receipt of written withdrawal; escalation to principals within 4 hours requesting emergency diplomatic resolution; data from that site collected after withdrawal is not used in final verdict (or marked as conditional pending remediation).
- Establish operator-liaison audit log: daily audit (liaison signs off on zone-boundary compliance, evidence-handler discipline, no counterpart interference, operator facilities secure); weekly summary report to co-chairs and operator; quarterly detailed audit to principals.
- Specify incident-escalation protocol: any boundary violation logged within 1 hour by liaison with photos and witness statements; access incidents (unauthorized entry, equipment removal, record tampering) logged within 30 minutes and escalated to co-chairs and operator simultaneously; alleged counterpart interference (espionage attempt, evidence theft) logged within 2 hours and escalated to CI unit and principals.
- Include operator-confidence measurement: quarterly survey (Months 3, 6, 9, 12 = 2027-01-12, 2027-04-12, 2027-07-12, 2027-10-12) of operator's satisfaction with inspectors' zone compliance, data protection, evidence handling and absence of leakage; results published in KPI dashboard; any confidence score <70% triggers co-chair remediation meeting within 1 week.
- Define remediation actions: evidence-handling training (if operators report concern about inspector evidence discipline), liaison rotation (if specific liaison is perceived as biased), or scope reduction (if operator requests smaller inspection area to reduce risk exposure).
- Lock operator-consent framework in the bilateral instrument by Month 7 (2027-05-12); embed liaisons at sites by Month 1 (2026-11-12) and operationalize consent-monitoring by Month 9 (2027-07-12) at Phase One start.

**Approval Authorities:** Operator Liaisons (daily audits), Bilateral Co-Chairs (monthly consent reviews and degraded-consent decisions), and Principals (for consent-withdrawal emergency resolution)

### 14. Reciprocal-Access Parity Accounting Method and Trip-Point Triggers

**ID:** 9f8a448a-477e-4a77-b057-fa543728ed53

**Description:** Specification for measuring and recording reciprocal access parity, normalizing across non-identical sites, establishing reason-coded access denials and delays, setting trip-point thresholds for impaired-confidence review, and reconciliation procedures. Includes definition of equivalence yardstick (matched events vs. outcome-based parity), normalization factors (access per unit of declared equipment), unit-of-comparison specification, reason-code taxonomy for denials, and reconciliation procedures (5-day co-chair review, 10-day escalation if unresolved). Primary audience: parity-accounting officers, bilateral co-chairs, operational inspectors.

**Responsible Role Type:** Reciprocal-Access Parity Accountant

**Primary Template:** Parity Accounting and Equivalence-Measurement Framework

**Secondary Template:** Trip-Point Trigger and Impaired-Confidence Review Procedure

**Steps:**

- Define parity unit of comparison: matched events (inspector hours, staging-area accesses, equipment inspections, evidence requests) rather than raw time or access counts; measure parity as (access granted US side / access granted China side) normalized by site size and declared equipment count.
- Specify normalization factors: parity = (US inspection hours per unit declared US site / China inspection hours per unit at declared China site); tolerance band ±10% divergence before trip point is triggered; divergence measured monthly and reported in the standing parity ledger.
- Document reason-coded access denials: every denial of an inspection request, evidence export or evidence sample is logged in the ledger with: requestor identity, request description, denial reason code (operator-imposed safety, equipment-maintenance window, unverifiable-equipment status, unresolved identity dispute, counterpart allegation of boundary violation), timestamp, duration, and operational impact.
- Establish reason-code taxonomy: (A) safety/operational (equipment maintenance, active workload protection, facility incident), (B) procedural (incomplete request documentation, missing bilateral witness), (C) substantive (disputed equipment identity, unverifiable status, unresolved discrepancy), (D) investigation-related (security incident under review, counterpart allegation pending), (E) unexcused (unexplained, unjustified).
- Specify denial-response timelines: reason code must be provided within 24 hours of denial; if reason code is type E (unexcused) or inadequate explanation is given, escalate to bilateral operations directors within 48 hours; unresolved denials older than 5 days become aging-discrepancy entries in KPI dashboard.
- Define parity trip points (automatic escalation triggers): >15% parity variance for 2 consecutive weeks or >5 unexplained (reason code E) denials per site per week; either trigger activates an impaired-confidence review by bilateral technical referees within 5 days.
- Specify impaired-confidence review procedure: referees examine detailed parity ledger, reason codes, and context for each denial/delay; issue dual-signed fact statement within 3 days identifying whether asymmetry is justified (operational or temporary) or systematic (obstruction); co-chairs use referee recommendation to decide on enhanced inspection at affected site or escalation to principals.
- Include reconciliation procedures: parity accounting is reconciled monthly (Months 9–12 = 2027-07-12 to 2027-10-12); reconciliation log is published in KPI dashboard showing: total accesses granted/denied per country, cumulative parity ratio, reason-code distribution, aging-discrepancy count, and any trip-point breaches.
- Lock this methodology in the bilateral instrument by Month 7 (2027-05-12); establish standing parity-accounting officer positions (one per country) by Month 1 (2026-11-12); begin parity tracking from Phase One Day 1 (Month 9 = 2027-07-12).

**Approval Authorities:** Bilateral Parity-Accounting Officers (monthly reconciliation), Technical Referees (impaired-confidence fact statements), and Bilateral Co-Chairs (trip-point escalation decisions)

### 15. Opening Inventory Baseline and Starting-State Seal Procedure

**ID:** 887a94f6-315c-4a52-8d29-fafaecdc360d

**Description:** Specification for establishing and sealing the opening inventory at each site during Phase One Days 1–5 (Months 9–9.25 = 2027-07-12 to 2027-07-27), defining what baseline methodology will be used (full census of covered equipment, progressive baselining, or operator self-declaration), how the count is jointly verified and sealed in the ledger, and explicit disclosure of whether the baseline is verified or unverified. Includes witness procedures, document chain of custody, ledger entry format, and disclaimer language for all Phase One reports stating baseline status. Primary audience: intake inspectors, bilateral co-chairs, final-report auditors.

**Responsible Role Type:** Equipment Identity Verification Lead and Opening-Inventory Coordinator

**Primary Template:** Inventory Baseline Verification and Seal Procedure

**Secondary Template:** Data-Integrity and Chain-of-Custody Protocol

**Steps:**

- Decide baseline methodology by Month 8 (2027-06-12): choose one of three options—(A) full opening census via joint count of covered-equipment categories within declared zones at each site, Days 1–5 of Phase One; (B) operator self-declaration without count, with explicit disclaimer that starting population is unverified; (C) progressive baselining (verify items only when maintenance events touch them), with explicit disclaimer that early arrivals cannot be distinguished from pre-existing items. No hybrid approach; decision is binding for entire Phase One.
- If methodology A (full census): allocate 10+ additional inspectors per site for Days 1–5 to conduct the count; count covers all covered-equipment categories within declared zones; count results are jointly recorded in the ledger with witness attestations from both countries; any equipment not present is documented as a finding; sealed count becomes the zero-point reference for all later change-detection logic.
- If methodology B (self-declaration): operator provides a list of declared equipment at each site; no independent count is conducted; list is recorded in the ledger as 'Operator Self-Declared Equipment List' with explicit stamp 'UNVERIFIED—no independent count performed'; all subsequent Phase One reports state: 'The starting population of declared equipment is unverified; early discrepancies between expected and observed cannot distinguish pre-existing equipment from arrivals.'
- If methodology C (progressive): no opening count; items are verified only when they are first touched by a maintenance event or movement; baselining log records each verified item with its verification date; explicit disclaimer: 'Baseline is progressive; prior to [date], population is unverified; early-arrival detection depends on maintenance events occurring.'
- Specify ledger entry format for baseline seal: recording includes date, time (UTC), baseline methodology, total covered-equipment count (if methodology A) or 'progressive' (if C) or 'declared' (if B), list of equipment identifiers or operator self-declaration reference, digital signatures of both countries' intake leads, and any non-agreement or caveats.
- Include attestation procedure: baseline seal requires bilateral witness signatures (one inspector per country) and verification that no equipment has been modified, removed or added between baseline-seal time and Phase One Day 6; any discrepancy between baseline and Day 6 inventory is logged as a Finding and escalated to co-chairs within 24 hours.
- Document disclosure in all reports: every Phase One monthly report and the final verdict report must include explicit baseline-status statement: 'Starting population [verified via joint count / unverified per operator declaration / progressively verified]; see Baseline Seal Ledger Entry [reference] for details.' Failure to include baseline disclaimer is a compliance violation.
- Establish baseline-related KPI: share of declared zones with a sealed baseline count (metric only applies if methodology A is used); baseline-related discrepancies per site (discrepancies found between baseline and later observations); time required for baseline seal (target: 5 days for full census, 1 day for self-declaration); report these monthly.
- Lock baseline-methodology decision in the bilateral instrument by Month 7 (2027-05-12); conduct baseline seal on Phase One Days 1–5 (Months 9–9.25 = 2027-07-12 to 2027-07-27); baseline ledger entry is recorded by Day 5 and cannot be modified.

**Approval Authorities:** Bilateral Co-Chairs (baseline-methodology selection by Month 8 = 2027-06-12), Intake-Protocol Leads (baseline seal execution on Days 1–5), and Adjudication Unit (any baseline-related discrepancy escalation)

### 16. Covered-Equipment Schedule Abstraction Ladder and Versioning Protocol

**ID:** 42ab1c6e-c386-4025-8a79-228eaf1a73f7

**Description:** Specification for the confidential, versioned technical schedule defining frontier-relevant covered equipment by functional role (not manufacturer, product or performance unit) so the schedule resists hardware-generation obsolescence. Includes role-based functional categories (e.g., 'any device performing tensor-accelerated parallel computation exceeding 1 exaflops per second in aggregate cluster configuration'), tier-migration procedures (core, watch, exempt categories with quarterly review points), double-key update procedures, and split-escrow threshold custody (if classification sensitivity justifies sealing thresholds from one side). Primary audience: bilateral specialist groups, intake inspectors, schedule-maintenance officers. Locked by Month 7 (2027-05-12).

**Responsible Role Type:** Covered-Equipment Schedule Specialist and Specialist Task Lead

**Primary Template:** Functional Classification and Schedule-Versioning Framework

**Secondary Template:** Technology-Neutral Equipment Definition Standard

**Steps:**

- Define covered equipment by functional role (not by manufacturer or product name): e.g., 'Device Group A: Any semiconductor or processor performing parallel-tensor acceleration or floating-point computation at aggregate >100 trillion operations per second in a cluster configuration; includes but is not limited to GPUs, TPUs, custom accelerators, and NPUs with firmware-accessible acceleration registers.'
- Establish tier structure: (Core) devices universally recognized as frontier-relevant (GPUs, TPUs with latest architectures); (Watch) emerging or specialized devices under evaluation; (Exempt) legacy or commercial-off-the-shelf devices <3 years old or obsolete architectures.
- Specify tier-migration procedure: quarterly review points (Months 3, 6, 9, 12 = 2027-01-12, 2027-04-12, 2027-07-12, 2027-10-12) where bilateral specialist groups assess whether any Watch-tier devices should promote to Core or demote to Exempt based on technology advances; each migration is recorded in the ledger with a versioned schedule update.
- Document schedule-update control: every update to covered-equipment definitions requires bilateral specialist-group consensus and double-key co-chair authorization; published schedule versions are tagged with timestamp, versioning number and digital signature of both countries; inspectors always use the current published version.
- Include boundary-case resolution procedure: if equipment under intake does not clearly fit the functional definitions (e.g., a device falls between two tiers), both countries' specialists convene within 2 days; issue joint classification recommendation within 1 day; if specialists cannot agree within 2 days, equipment defaults to Core (more-conservative-cover classification); dispute is logged in the ledger for post-Phase-One review.
- Specify split-escrow threshold custody (optional, if classification sensitivity justifies): exact performance-threshold numbers (e.g., 'exceeding 100 trillion operations per second') can be held in split-escrow between both countries' specialist groups so inspectors verify equipment against threshold results without seeing the underlying number; both specialist groups must independently compute the threshold and supply matching results within ±5% variance before the equipment can be classified.
- Establish schedule-change latency: any proposed schedule update can take effect only after bilateral approval and 7-day publication notice to all operators; operators must update their equipment-declaration forms within 14 days using the new schedule version; Phase One equipment counts are recalculated using the current schedule version as of each monthly report.
- Include conformance audit: monthly (Months 9–12 = 2027-07-12 to 2027-10-12), verify that all declared equipment at each site is consistently classified under the current schedule version; flag any equipment that was reclassified between reporting periods; document reason for reclassification (tier migration, equipment replacement, schedule update) in the ledger.
- Lock provisional schedule in the bilateral instrument by Month 7 (2027-05-12); establish bilateral Specialist Maintenance Task by Month 1 (2026-11-12) to operationalize quarterly reviews; begin schedule-versioning from Phase One Month 9 (2027-07-12) baseline.

**Approval Authorities:** Bilateral Specialist Group (boundary-case and tier-migration decisions), Bilateral Co-Chairs (schedule-update authorization), and Principals (for disputes unresolved by specialists within 2 days)

### 17. Exit Protocol Disposition Evidence Ladder and Closure Procedures

**ID:** 17ee1587-5097-4848-a48d-1020737dfca7

**Description:** Specification for assigning one of five exit dispositions (witnessed destruction, verified permanent disablement, transfer to another participating site, documented release beyond monitored system, unresolved) to each declared unit when it departs a site. Defines evidentiary requirements per disposition (witnessed destruction requires 2 inspectors + residual sampling; permanent disablement requires 2 inspectors + state verification; etc.), pre-declaration requirement (≥5 days notice of intended disposition path), penalty for vague declarations, witness-capacity surge-planning, and ledger entry format marking the boundary of Consortium knowledge. Primary audience: exit-protocol inspectors, bilateral co-chairs, operators.

**Responsible Role Type:** Exit-Protocol Lead and Departure-Disposition Coordinator

**Primary Template:** Exit Procedure and Disposition-Closure Standard

**Secondary Template:** Evidence-Sufficiency and Knowledge-Boundary Specification

**Steps:**

- Define five dispositions and evidentiary requirements: (1) Witnessed Destruction—unit is destroyed at a licensed facility; 2 mirrored inspectors attend; residual materials (if applicable) are sampled; disposal documentation is collected; ledger entry records facility, date, witnesses, and outcome. (2) Verified Permanent Disablement—unit is permanently rendered non-functional (e.g., processors extracted, firmware wiped, encryption keys destroyed); 2 inspectors verify disablement state; non-destructive forensic examination (if feasible); state certification by facility; ledger entry records location, date, witnesses, disablement method and certification. (3) Transfer—unit is moved to another participating site in the Consortium; transfer is logged in originating site's exit record and receiving site's intake record; sealed transport container with inspector seal; transfer custody documented in ledger. (4) Documented Release—unit is released beyond the monitored system (e.g., to external customer, reseller, or recycling facility); inspector certifies that release is outside Consortium scope; sealed handover is recorded with release destination, date and final inspector attestation; no further Consortium tracking occurs. (5) Unresolved—unit status is unknown or contested; remains under monitoring or escalated for referee adjudication.
- Specify pre-declaration requirement: any operator intending to remove a covered unit must declare its intended disposition path ≥5 days in advance; declaration must specify facility, date range, expected witnesses and any special handling; declaration is recorded in the ledger and co-chairs must confirm feasibility within 2 days.
- Include penalty for vague declarations: if operator declares 'undetermined' or 'to be decided' disposition, unit remains in place and monitored until disposition is clarified; if disposition remains undeclared >15 days after intended removal date, unit automatically escalates to unresolved status and is reported as an aging finding.
- Establish witness-capacity surge planning: at each site, estimate maximum monthly departures (based on operator maintenance and decommissioning schedules) and reserve mirrored-witness teams accordingly (proposed: 4–6 mirrored witness-teams per site to cover ~20–30 departures per month); if departures exceed capacity, establish waiting queue with priority-order rules (safety-critical units first, then oldest-in-service units).
- Define ledger entry format for closed dispositions: recording includes unit identifier, original intake date, disposition type, date of closure action, mirrored-witness names and certifications, facility/location, photographs or forensic results (if applicable), operator authorization signature, and exact text: 'Consortium observation of this unit ends at [date/time]; Consortium states no knowledge of unit status or location beyond this point.' Ledger entry is permanently sealed and cannot be modified.
- Include explicit knowledge-boundary language: post-disposition closure, neither government may make any tracking claim about the unit (e.g., no claim that the unit was later resold, diverted, or covertly recovered); any claim of knowledge beyond the sealed ledger entry is explicitly out of scope for the Consortium verification regime.
- Specify unresolved-disposition penalties: units with unresolved status after 10 days are flagged in the KPI dashboard as aging; >3 unresolved dispositions at any site triggers co-chair investigation and potential operator-consent review; all unresolved dispositions are documented in the final Phase One verdict report and considered a weakness in the closure procedures.
- Establish monthly disposition-closure summary: by the 5th business day of each month, report total arrivals, removals and dispositions per site and per country; track percentage of units with closed disposition (target: >95% by Month 12 = 2027-10-12); report residual unresolved units by age, reason and planned resolution date.
- Lock this protocol in the bilateral instrument by Month 7 (2027-05-12); operationalize exit procedures on Phase One Day 6 (Month 9.25 = 2027-07-20); begin tracking dispositions and reporting in KPI dashboard from Month 9.5 (2027-07-27).

**Approval Authorities:** Bilateral Co-Chairs (pre-declaration approval and surge-capacity decisions), Exit-Protocol Lead (witness coordination), and Adjudication Unit (unresolved-disposition escalation)

### 18. Matched Site Equivalence Certification and Parity-Baseline Defensibility Report

**ID:** 738f3fbf-8459-463f-89ba-74d427d2757a

**Description:** Specification for selecting and certifying four matched declared datacenters (2 US, 2 China) that have comparable staging, spare-inventory, maintenance and expansion areas for reciprocal-access parity measurement. Includes functional-matching criteria (verification activity equivalence rather than compute scale), site-survey documentation, defensibility analysis against bilateral challenge, and publication of pairing rationale before entry gate. Ensures parity accounting has a stable, defensible baseline. Primary audience: bilateral co-chairs, site-selection task, principals.

**Responsible Role Type:** Matched Site Equivalence Task Lead

**Primary Template:** Site-Selection and Equivalence-Assessment Framework

**Secondary Template:** Parity-Baseline Certification Report

**Steps:**

- Define 'matched' site selection: sites are paired by verification-function equivalence (staging area sizes, customs-access latency, operator types, logistics infrastructure density) rather than by compute scale or workload; functional matching allows parity to measure inspection activity rather than capacity.
- Conduct bilateral site survey by Month 1 (2026-11-12): each country's representatives visit prospective sites, document staging area configuration, measurement of floor space for each functional zone (staging 500–1000 sq m, spare-inventory 300–500 sq m, maintenance 200–300 sq m, expansion 200–300 sq m), customs and logistics access distance, operator type (commercial vs. state-owned) and equipment criticality.
- Specify normalization factors: parity is measured as 'inspection hours per unit of declared equipment' or 'access events per covered device'; normalization corrects for site-size differences so asymmetric staging areas do not invalidate parity assessment.
- Establish site-pairing defensibility: publish a joint Site Equivalence Certification report by Month 1.5 (2026-11-27) for each matched pair, documenting: functional-matching criteria, survey results, normalization factors, and bilateral agreement that pairing is defensible to both national authorities; report is signed by both co-chairs.
- Include bilateral challenge period: report is published 7 days before final gate certification (Month 8 = 2027-06-12); either government may formally challenge a pairing within 5 days if it believes equivalence is inadequate; challenges are escalated to principals for resolution within 3 days of challenge receipt.
- Specify site-selection outer limit: final four sites must be certified and locked by Month 8 (2027-06-12); no site changes after that date without bilateral co-chair authorization and principal approval; late site-selection disputes delay Phase One entry gate.
- Document in bilateral instrument: bilateral instrument (signed Month 7 = 2027-05-12) includes Annex specifying the four selected sites by name and location; any substitution requires bilateral amendment before Phase One starts.
- Lock Matched Site Equivalence Certification by Month 8 (2027-06-12); publish unclassified summary of site pairings in KPI dashboard.

**Approval Authorities:** Site-Selection Task Lead (survey and equivalence analysis), Bilateral Co-Chairs (pairing certification and challenge resolution), and Principals (for formal pairing challenges)

### 19. Staffing Model Validation and Personnel Surge-Capacity Plan

**ID:** 5490b933-f62f-44af-9245-da241d4282be

**Description:** Detailed staffing model for ~350–500 cleared full-time inspectors and technical staff, including: shift rotations for 24/7 presence at 4 sites (3 posts × min 2 people = 6 per shift per site); leave buffers (15% proposed); standing surge reserve (10% proposed) plus cross-site floaters (20–30% proposed); tenure limits (6 months max per site with 2-month breaks); compartmentation by site and event type; no single-person critical functions. Includes hiring timeline, background-vetting schedule, training curriculum and dry-run validation results. Primary audience: bilateral co-chairs, personnel units, contingency planners. Validates staffing assumptions against the entry-gate timeline and operational readiness by Month 8 (2027-06-12).

**Responsible Role Type:** Mirrored National Inspectorate Units Lead and Personnel Planning Specialist

**Primary Template:** Staffing Plan and Surge-Capacity Analysis Template

**Secondary Template:** Personnel Rotation and Leave-Management Procedure

**Steps:**

- Model the staffing requirement: 4 sites × 3 shifts × 3 posts per shift × 2 people per post = 72 front-line inspectors; add supervisors, quality-assurance specialists, analysts, logistics coordinators = ~120–150 operational staff per country = 240–300 total.
- Apply leave buffer: 15% of 300 = 45 staff on leave at any time; standing staffing requirement = 300 + 45 = 345.
- Calculate surge reserve: 10% standing surge (35 staff) + 20–30% surge floaters (70–100 staff) = 105–135 surge capacity.
- Total recruitment target: 345 + 105 = 450 staff per country (estimate) or ~900 combined, split 50/50.
- Specify tenure limits and rotation rules: no inspector >6 months at same site; 2-month break before reassignment; no cross-country reassignment within 12 months; compartmentation ensures no inspector holds cross-site or cross-event knowledge.
- Establish hiring timeline: recruitment by Month 0.5 (2026-10-27), vetting and clearance completion by Month 2 (2026-12-12), training and dry-run by Month 8 (2027-06-12), operational deployment Month 9 (2027-07-12).
- Define training curriculum: orientation (4 days, equipment identification, zone boundaries, evidence handling), identity-verification procedures (5 days, attestation validation, corroboration layering), compartmentation and security protocols (3 days, CI vetting, need-to-know rules), exercises and drills (ongoing), and specialized training for supervisors and analysts.
- Specify no single-person critical functions: every shift and post has backup personnel within the same site; no roles filled by a single individual; cross-training for all critical functions.
- Document staffing dry-run results (Month 8 = 2027-06-12): simulate 72-hour shift rotation with 25% of target staff, measure leave and surge handling, validate tenure and compartmentation enforcement, document shortfalls and recommended adjustments.
- Include contingency staffing escalation: if deployment falls below 80% of target (i.e., <360 of 450 staff), automatically activate contingency protocols: curtail inspection scope to 3 instead of 4 sites, reduce challenge-exercise frequency, or extend Phase One timeline with bilateral approval.
- Lock staffing model in bilateral instrument by Month 7 (2027-05-12); publish staffing KPI in the KPI dashboard (Months 9–12 = 2027-07-12 to 2027-10-12) tracking: target staffing deployed, actual deployed, shortfall percentage, leave utilization, and surge-activation events.

**Approval Authorities:** Personnel Planning Lead (staffing model development), Bilateral Co-Chairs (staffing target approval), and Principals (for contingency-activation decisions if deployment falls below 80%)

### 20. Filter-Adequacy Blind Pre-Test Specification and Execution Plan

**ID:** 11366718-9c0a-4768-a7d4-64c3c752a810

**Description:** Comprehensive specification for conducting the filter-adequacy blind pre-test by Month 8.5 (2027-06-27) with ≥10 injected equipment-substitution scenarios in staging and spare-inventory areas under operator-controlled redaction-gateway filtering. Includes: scenario design (wrong serial, firmware rollback, physical-mark tampering, attestation forgery), injection procedures (no inspector knowledge), blind-detection measurement by operating inspectors, scoring against jointly agreed criteria, and halt-if-<85%-detection rule. Documents the test's role as a prerequisite for Phase One entry certification. Primary audience: independent testers, intake inspectors, bilateral co-chairs.

**Responsible Role Type:** Challenge Exercise Design and Independent Testing Lead, Filtered Evidence and Redaction-Gateway Architect

**Primary Template:** Blind Exercise and Scenario-Injection Test Plan

**Secondary Template:** Detection-Rate Measurement and Halt-Criteria Procedure

**Steps:**

- Design 10+ equipment-substitution test scenarios spanning multiple detection-difficulty levels: (1) obvious substitution (different serial number, completely different device); (2) subtle substitution (same model, different firmware version, serial number off by 1 digit); (3) cryptographic-only discrepancy (physical marks match, attestation digest doesn't); (4) physical-only discrepancy (serial and marks match, but physical weight/dimensions don't match); (5) attestation-forgery scenario (forged cryptographic signature on a real device).
- Schedule injection window by Month 8 (2027-06-12) involving staging and spare-inventory areas at both US and China representative sites; coordinate with operators to ensure injection areas are controlled and free from legitimate activity.
- Specify blind-injection procedure: independent testers (not operating inspectors) inject substitutions overnight or during maintenance windows; injectors do not inform operating inspectors of injection; all injected scenarios are marked CHALLENGE in the ledger.
- Define detection measurement: operating inspectors conduct routine intake or maintenance inspections of the staging/spare-inventory area; measure whether inspectors flag identity-confidence issues, escalate to unverifiable, or miss the substitution.
- Specify scoring criteria: 'detection' = inspector flags ≥2 evidence layers in disagreement or escalates to unverifiable within 1 hour of inspecting the unit; 'non-detection' = inspector clears the unit without identity escalation within 1 hour.
- Document redaction-gateway filtering applied: all raw records, sensor outputs and telemetry pass through the operator-controlled gateway before inspectors see them; measure impact of filtering on detection performance.
- Set detection-rate target: ≥9 of 10 detected (90% baseline); ≥8.5 of 10 = acceptable (85% minimum threshold); <8.5 of 10 = HALT all scoring exercises and renegotiate filters.
- Include halt-and-renegotiation procedure: if pre-test detection is <85%, both countries' sensitive-asset teams must jointly review which evidence fields are being filtered and whether redaction rules are stripping identity-critical information (serial, firmware hash, attestation digest); renegotiate filter rules and re-test within 2 weeks.
- Publish pre-test results in the KPI dashboard and ledger by Month 8.5 (2027-06-27); include detailed results by scenario type, evidence-layer performance, filter impact, and any shortfalls identified.
- Gate entry certification on pre-test results: Phase One entry certification cannot be finalized at Month 9 (2027-07-12) unless pre-test detection rate is ≥85%; if <85%, entry gate is deferred until renegotiation and re-test complete.

**Approval Authorities:** Challenge Exercise Design Panel and Independent Testers (pre-test design and execution), Bilateral Co-Chairs (halt decision and filter renegotiation authorization), and Principals (for entry-gate deferral if halt condition triggered)

### 21. Incident Command Center (ICC) Staffing, Duty-Officer Procedures and Escalation Protocols

**ID:** b5449e83-24f4-4965-95b2-5bd3b5def864

**Description:** Specification for establishing and operating a 24/7 bilateral Incident Command Center staffed by one senior duty officer per country, responsible for real-time anomaly alerts (including CHALLENGE-event misclassifications), escalation routing to co-chairs and principals, 2-hour misclassification decision windows, and automatic site-reinstatement procedures. Includes duty-officer training, shift rotations, communication protocols (secure phones, encrypted email), escalation decision trees, and escalation-incident logging. Primary audience: ICC personnel, bilateral co-chairs, principals.

**Responsible Role Type:** Bilateral Dispute Resolution and Deadlock-Escalation Manager

**Primary Template:** Crisis Incident Command Center Charter and Operating Procedures

**Secondary Template:** Emergency Escalation and Decision-Authority Protocol

**Steps:**

- Establish ICC facility: secure office (SCIF equivalent, ~200 sq m estimated) with: (1) Duty-officer workstations (one per country); (2) Secure phones (government landlines, encrypted satellites if needed); (3) Video-teleconference capability (SCIF-compatible encryption); (4) Red-phone or equivalent to co-chairs and principals; (5) Hardened server for real-time ledger-event logging; (6) 24/7 armed security and access control.
- Specify duty-officer personnel: senior officer per country (colonel/general officer equivalent, national-security background, decision authority); two shifts covering all time zones; no gaps in coverage during Phase One Months 9–12 (2027-07-12 to 2027-10-12).
- Define duty-officer authorities: (1) Alert escalation authority: recognize alerts from ledger-ingestion systems, inspect teams or automated monitors; (2) Initial assessment: determine whether alert requires co-chair notification within 15 minutes or principals within 1 hour; (3) Decision authority: joint duty officers (both countries) can jointly decide to escalate or mark as reconciled for alerts <2 hours old; (4) Principal escalation: if escalation unresolved within 1 hour, auto-escalate to co-chairs and principals without waiting for consensus.
- Establish alert-routing procedure: all suspension-trigger fires (unverifiable >3%, divergence >5%, denial >15%, discrepancy age >15 days) automatically notify ICC within 15 minutes; ICC assesses severity and alerts co-chairs immediately; all alerts are logged in the ICC incident log within 30 minutes.
- Define CHALLENGE-misclassification procedure: automated ledger system flags any CHALLENGE event appearing in non-CHALLENGE operational records; ICC notified within 15 minutes; duty officers jointly review within 30 minutes; decision: (1) mark as system error/tag corruption (if reconciliation data available), or (2) escalate to co-chairs within 2 hours.
- Specify co-chair notification format: email with event summary, ICC assessment, recommended action and escalation options; co-chairs have 30 minutes to acknowledge; if no response, auto-escalate to principals.
- Include decision-logging procedure: all ICC decisions (alert routing, CHALLENGE assessment, co-chair notification, remediation) are logged in the tamper-evident ledger with: timestamp, incident summary, decision rationale, personnel involved and outcome.
- Establish duty-officer training: 2-week orientation covering alert types, decision trees, escalation procedures, ledger-system interfaces, secure-communication protocols, and decision-authority limits; annual refresher training.
- Specify ICC shift rotation: 12-hour shifts with 48-hour breaks; no duty officer >14 consecutive days on duty; cross-training ensures both countries' personnel can fill either position.
- Define contingency ICC backup: secondary ICC facility at remote location with same capabilities; automatic failover if primary facility is compromised.
- Lock ICC charter in bilateral instrument by Month 7 (2027-05-12); staff and train ICC personnel by Month 8 (2027-06-12); operational by Phase One start (Month 9 = 2027-07-12).

**Approval Authorities:** Bilateral Co-Chairs (ICC charter and duty-officer training approval), Principals (for escalation decisions requiring principal-level authority)

### 22. Monthly KPI Dashboard Specification and Reporting Procedure

**ID:** 7d488a0d-1652-4cd3-9591-153a69a71517

**Description:** Specification for the monthly Key Performance Indicator dashboard published in the tamper-evident ledger and accessible to bilateral co-chairs, tracking: blind-challenge detection rates by event type, false positives and negatives, equipment-identity confidence, ledger synchronization and divergence, reciprocal-access parity, unresolved discrepancy age, unverifiable-equipment count per site, operator-consent status, IP/cybersecurity incidents, production-disruption incidents, funding timeliness, and contingency burn rate. Includes dashboard structure, data sources, threshold colors (green/yellow/red), alert logic, and monthly publication schedule. Primary audience: bilateral co-chairs, principals, auditors.

**Responsible Role Type:** Independent Auditor and Evidence Sufficiency Validator

**Primary Template:** Performance Metrics Dashboard and KPI Definition Framework

**Secondary Template:** Real-Time Monitoring and Alert Trigger Specification

**Steps:**

- Define KPI categories and specific metrics: (1) Detection Performance: detection rate (%) by event type, false-positive count, false-negative count, cumulative detection rate; (2) Equipment Identity: identity-confidence distribution, unverifiable count per site, identity-conflict escalations, referees adjudications; (3) Ledger Health: synchronization latency (hours), divergence-detection latency (hours), reconciliation closure time (hours), divergence incidents per week; (4) Parity: access variance (%), unexplained denials per site per week, aging-denial count, parity-trip-point breaches; (5) Discrepancies: unresolved-discrepancy count, aging discrepancy age (days), auto-suspension triggers, impaired-confidence reviews; (6) Unverifiable: unverifiable count per site (%), cumulative unverifiable, vendor-refusal escalations; (7) Operator Consent: consent status (full/degraded/withdrawn), boundary violations, evidence-handling incidents; (8) Security: IP/cybersecurity incidents, counterintelligence alerts, insider-threat red-team results, compartmentation violations; (9) Production Impact: disruption-incident count, duration (minutes), affected systems; (10) Fiscal: cumulative disbursement per envelope per country, parity variance (%), contingency burn rate (%), tranche-release status.
- Establish data sources: ledger-ingestion system (auto-populated for ledger metrics), intake/exit inspector reports (identity, unverifiable), exercise-design team (detection rates, blind-test results), parity-accounting officer (access events, denials), ICC incident log (discrepancies, suspensions), CI unit (security incidents), operator liaisons (consent status, disruptions), independent auditor (financial burn).
- Specify threshold colors and alert logic: Green (metric within safe bounds, no action); Yellow (metric approaching trip point, co-chair review recommended within 5 days); Red (metric at or exceeding trip point, auto-escalation to co-chairs and principals, action required immediately). Example: unverifiable equipment Green <2%, Yellow 2-3%, Red ≥3% (auto-suspension trigger).
- Define monthly publication schedule: data reported by 5th business day of following month; dashboard published in the ledger by 7th business day of following month; both co-chairs acknowledge receipt by 10th business day; any Yellow or Red items require documented remediation plan by 15th business day.
- Include provisional-figure labeling: every KPI marked with source (validation method), confidence interval (if applicable), and provenance (empirical from Month X.Y pre-test, calibrated against early exercises, assumed per bilateral agreement, TBD/unvalidated); changes to any threshold documented with approval date and authorization.
- Establish dashboard access control: bilateral co-chairs have read-only access to full dashboard; principals have read-only access; independent auditor and technical specialists have read-only access per their role; no external access; all dashboard accesses logged.
- Include drill and validation procedures: monthly (or quarterly) dry-run of dashboard reporting procedures to ensure data accuracy, system reliability and audit-trail integrity; document drill results and remediate any gaps.
- Lock dashboard specification and publication procedures in bilateral instrument by Month 7 (2027-05-12); deploy dashboard system and staff by Month 9 (2027-07-12); publish first dashboard Month 9.25 (2027-07-20) covering Phase One Days 1-7; continue monthly publication through Month 12.25 (2027-10-20) (verdict date) and beyond if Phase Two is authorized.

**Approval Authorities:** Independent Auditor (dashboard data accuracy), Bilateral Co-Chairs (monthly dashboard review and remediation decisions), and Principals (for Red-tier metric escalation and contingency-draw authorization)

### 23. Bilateral Legal Working Group Charter and Instrument-Negotiation Roadmap

**ID:** 34b202d4-fe95-45e5-b43c-fd70ef95fb12

**Description:** Charter for the bilateral legal working group (established by Month 0.5 = 2026-10-27) coordinating instrument negotiation, domestic-access-authority enactment, vendor-binding legal terms, export-control compliance and dispute-resolution procedures. Includes: negotiation milestones (instrument skeleton Month -2 = 2026-12-15, draft completion Month 6 = 2027-04-12, signature Month 7 = 2027-05-12), decision authority (who negotiates, who approves), escalation procedures (legal bottlenecks escalated to principals within 1 week), and contingency tracks (phased implementation, scope reduction). Primary audience: national legal teams, bilateral co-chairs, principals.

**Responsible Role Type:** Legal Implementation and Bilateral Instrument Lead

**Primary Template:** Bilateral Working Group Charter and Negotiation Roadmap

**Secondary Template:** Legal-Instrument Negotiation and Approval Authority Framework

**Steps:**

- Establish bilateral legal working group by Month 0.5 (2026-10-27): 2–3 legal specialists per country with authority to negotiate and make binding commitments on behalf of their governments; chief legal representative per country (national-security lawyer with signing authority).
- Define negotiation scope: (1) Governance (co-chair structure, double-key authorization, double-key conditions—all decisions or budget/suspension only); (2) Deadlock procedures (5/8/13-day escalation timers, referee procedures, principal involvement); (3) Suspension triggers (automatic vs. discretionary, CHALLENGE-tag partition); (4) Reciprocal access (parity definition, trip-point triggers, denial reason codes); (5) Entry conditions and gate procedures; (6) Confidentiality and compartmentation; (7) Personnel clearance reciprocity; (8) Dispute resolution and arbitration; (9) Domestic compulsion authority assertions; (10) Vendor binding and refusal procedures.
- Specify negotiation schedule: Month 0–1 (2026-10-12 to 2026-11-12) (skeleton agreement on core principles), Month 1–3 (2026-11-12 to 2027-01-12) (detailed provisions draft), Month 3–5 (2027-01-12 to 2027-03-12) (bilateral review and revision), Month 5–6 (2027-03-12 to 2027-04-12) (legal vetting and polish), Month 6 (2027-04-12) (final bilateral agreement), Month 6.5 (2027-04-27) (internal approvals), Month 7 (2027-05-12) (signature).
- Establish decision authority: chief legal representative per country signs bilateral consent to disputed language; any provision unable to reach bilateral consensus within 2 weeks escalates to principals; principals have 5 days to decide or both legal teams move to contingency track (phased implementation or scope reduction).
- Define escalation triggers for legal bottlenecks: (1) legal-authority gaps (no compulsion power over vendors) flagged immediately with 2–4 month litigation estimate → escalate to principals within 1 week; (2) export-control conflicts (inspection procedures violate EAR/ITAR) flagged and escalate within 1 week; (3) irreconcilable legal differences (one country requires amendment, other refuses) escalate to principals within 2 weeks.
- Specify contingency tracks: (A) Phased implementation (sign skeletal agreement Month 7 = 2027-05-12 with core governance and entry conditions; negotiate detailed procedures in Annexes during Phase One if needed). (B) Scope reduction (if legal barriers prevent full instrumentation, negotiate reduced scope that avoids legal conflicts). (C) Supplementary legislation (if domestic compulsion authority is missing, secure legislative amendment in parallel track; delay Phase One until authority is enacted).
- Include domestic-authority workstream: each country's legal team responsible for securing domestic compulsion authority over operators and vendors; deadlines: US by Month 5.5 (2027-03-27) (legislative process requires 2–3 months if bills are pre-filed; no new bills required if existing New START authority suffices; confirm by Month 3 = 2027-01-12); China by Month 5 (2027-03-12) (faster, single decision authority; confirm by Month 2 = 2026-12-12).
- Document legal bottleneck tracking: maintain a weekly legal-risk log listing: outstanding legal issues, resolution status, responsible parties, escalation date if unresolved >1 week, and mitigation actions; log is shared with co-chairs weekly.
- Establish document-management procedures: all negotiation drafts, bilateral exchanges, legal opinions, and correspondence are logged in a secure repository (not in tamper-evident ledger until final instrument, to preserve attorney-client privilege); final instrument is published in ledger upon signature.
- Lock legal working group charter in bilateral steering-committee operating procedures by Month 0.5 (2026-10-27); convene first bilateral legal meeting by Month 0.75 (2026-11-04); confirm instrument-signature timeline commitment from both co-chairs and principals by Month 1 (2026-11-12).

**Approval Authorities:** Chief Legal Representative per Country (legal-working-group decisions), Bilateral Co-Chairs (escalation authorization), and Principals (for legal bottleneck resolution and contingency-track decisions)

## Documents to Find

### 1. Existing US and Chinese Bilateral Treaty and Instrument Precedent Library

**ID:** 2a7dcbc6-60d9-4e30-aac3-2b755ca2162d

**Description:** Collection of executed bilateral arms-control treaties, executive agreements and MOUs (New START, INF, Open Skies, Biological Weapons Convention protocols, etc.) establishing governance precedents for double-key authorization, deadlock procedures, on-site inspections, reciprocal access, and dispute resolution. Source material for drafting the Consortium bilateral instrument. Intended audience: legal implementation team, bilateral negotiators. Context: understand existing diplomatic language and institutional designs that have proven durable or failed.

**Recency Requirement:** Published within last 15 years; focus on instruments currently in force or recently amended (2011–2026); historical treaties also useful for cautionary lessons.

**Responsible Role Type:** Legal Implementation and Bilateral Instrument Lead

**Access Difficulty:** Medium: Most unclassified treaty texts are publicly available on government websites; classified versions or internal negotiating histories require official request and clearance access.

**Steps:**

- Contact the US State Department Legal Advisor's Office (Legal.Advisors@state.gov or via the treaty-databases website); request copies of New START Treaty text (2010), INF Treaty text (1987, as amended), and the Open Skies Treaty (1992).
- Search the US Government Publishing Office (govinfo.gov) for 'Treaty Documents' and 'Senate Treaty Ratification Documents'; filter by arms-control and verification categories.
- Contact the Chinese Ministry of Foreign Affairs Legal Affairs Department; request copies of bilateral arms-control agreements and verification protocols published in the Chinese Official Gazette.
- Access the UN Treaty Collection (treaties.un.org) and search for US–China bilateral instruments and verification protocols.
- Request redacted copies (if classified) from the Defense Threat Reduction Agency's Historical Inspection Division, which maintains a library of Cold War-era on-site-inspection protocols.

### 2. New START Treaty Bilateral Consultative Commission (BCC) Procedural Records and Dispute-Resolution Case Studies

**ID:** 5d10489a-a613-4362-9edb-1553b68486cf

**Description:** Records of BCC meetings, deadlock resolution procedures, escalation decisions and outcomes from the New START regime (2011–2020, and resumption attempts 2021–present), documenting how bilateral governance has handled disputes over inspection access, data discrepancies, and allegations of treaty non-compliance without a casting vote. Source material for designing the Consortium's Deadlock and Suspension Mechanics lever. Intended audience: deadlock-escalation designers, bilateral co-chairs. Context: understand what escalation timers and procedures have proven workable (or unworkable) in practice.

**Recency Requirement:** Documents from 2011 through 2026 preferred; focus on 2018–2020 period (heightened tensions and inspection access disputes); post-2022 resumption attempts also relevant.

**Responsible Role Type:** Bilateral Dispute Resolution and Deadlock-Escalation Manager

**Access Difficulty:** Medium to Hard: Unclassified summaries are publicly available; full meeting records and classified dispute-resolution details require official government request, FOIA process, or clearance-level access.

**Steps:**

- Contact the State Department Bureau of Arms Control, Deterrence and Stability; request (via Freedom of Information Act if necessary) unclassified summaries of BCC meeting outcomes, agendas and dispute-resolution decisions.
- Search the Congressional Research Service (crs.gov) for reports on 'New START Treaty Implementation' or 'US–Russia Verification Challenges'; these reports often discuss BCC procedures.
- Contact the Defense Threat Reduction Agency's Policy Division for interviews or briefings with former BCC delegation members or inspection coordinators.
- Consult the Arms Control Association (armscontrol.org) for published case studies on treaty compliance disputes and verification challenges.
- Request redacted case histories from the State Department's Treaty Interpretation and Dispute Resolution team.

### 3. IAEA Safeguards Implementation Techniques and Managed-Access Protocols

**ID:** 8bb51bf8-4cbb-4234-ae60-986fbdce84fb

**Description:** IAEA procedural documents and technical standards on equipment identity verification (unique identifiers, seals, tamper-indicating devices), managed access (protecting sensitive information while allowing verification), tamper-detection instrument specifications, and inspector training curricula. Source material for designing the Consortium's Equipment Identity Trust Anchor, evidence-filtering, and inspector-presence procedures. Intended audience: identity-verification specialists, managed-access architects, inspector-training coordinators. Context: IAEA has 50+ years of operational verification experience with layered evidence, tamper seals, and managed access, providing tested procedures adaptable to the Consortium.

**Recency Requirement:** Latest available versions; IAEA Safeguards Glossary and Technical Equipment handbook (updated 2024 or latest published version); IAEA Annual Safeguards Implementation Reports (2020–2026).

**Responsible Role Type:** Filtered Evidence and Redaction-Gateway Architect

**Access Difficulty:** Easy: IAEA publishes most safeguards techniques and equipment standards on its public website; some detailed operational manuals require official request or are available only to IAEA member-state representatives.

**Steps:**

- Visit the IAEA website (iaea.org) and access the Safeguards division's publicly available documents; download the Safeguards Techniques and Equipment handbook and Safeguards Glossary.
- Request copies of the Additional Protocol model text (INFCIRC/540) from the IAEA Safeguards Division.
- Contact the IAEA Department of Safeguards via the Vienna office; request expert briefings on managed-access design, seal-design standards and tamper-detection validation procedures.
- Search the IAEA's document collection for published inspection-procedure manuals and equipment-specification standards (many are unclassified).
- Consult the ESARDA (European Safeguards Research and Development Association) website for practitioner papers on managed access and unique-identification systems.

### 4. Chemical Weapons Convention (OPCW) On-Site Inspection Procedures and Challenge-Inspection Protocols

**ID:** 84a32317-2897-4dc3-b450-128e329e8521

**Description:** OPCW procedural manuals and technical specifications for on-site inspections at declared facilities, challenge inspections, managed-access procedures protecting sensitive commercial information, mock-challenge-inspection exercise designs, and inspector training standards. Source material for designing the Consortium's Challenge Exercise Design and Scoring lever, managed-access rules, and exit-disposition procedures. Intended audience: challenge-exercise designers, managed-access specialists, exit-protocol coordinators. Context: OPCW has operationally conducted destruction verification and challenge inspections since 1997, with tested procedures for handling operator reluctance and balancing transparency against confidentiality.

**Recency Requirement:** Current OPCW Verification Annex text (updated 2024 or latest available); OPCW Technical Secretariat annual inspection reports (2020–2026); published mock-challenge-exercise results (if available).

**Responsible Role Type:** Challenge Exercise Design and Independent Testing Lead

**Access Difficulty:** Medium: OPCW publishes most procedural manuals and technical standards publicly; detailed operational scenarios or classified facility information requires official request or OPCW member-state status.

**Steps:**

- Visit the OPCW website (opcw.org) and access the Verification and Inspections division pages; download the Chemical Weapons Convention Verification Annex text and On-Site Inspection Procedures manuals.
- Contact the OPCW Inspectorate Division via The Hague office; request technical briefings on managed-access design, challenge-inspection logistics, and destruction-verification procedures.
- Search the OPCW document repository for published reports on mock-challenge-inspection exercises (e.g., IFE [Integrated Field Exercise] reports if available unclassified).
- Request copies of the OPCW's Designated Laboratories Proficiency Test results and examination protocols from the Technical Secretariat.
- Consult the OPCW's Training and Capacity-Building Division for inspector training materials on managed access and challenge-inspection procedures.

### 5. Comprehensive Nuclear-Test-Ban Treaty Organization (CTBTO) Integrated Field Exercise (IFE) Design and On-Site Inspection Protocols

**ID:** 302a21f6-7366-44d0-bbf6-2be8ce642db8

**Description:** CTBTO technical specifications for designing and executing large-scale blind field exercises simulating on-site inspections, including scenario injection, independent observer monitoring, detection-rate scoring, and logistics coordination across multiple sites. Source material for designing filter-adequacy pre-tests and blind-challenge-exercise procedures. Intended audience: exercise designers, independent testers. Context: CTBTO has conducted multiple Integrated Field Exercises (IFE08 in Kazakhstan, IFE14 in Jordan) that tested equipment, procedures and personnel under realistic conditions; exercise design methodology is transferable to the Consortium.

**Recency Requirement:** CTBTO Integrated Field Exercise reports (IFE08, IFE14 and later, if published); CTBTO On-Site Inspection (OSI) Team handbook (latest version); CTBTO Training and Capacity-Building materials (2015–2026).

**Responsible Role Type:** Challenge Exercise Design and Independent Testing Lead

**Access Difficulty:** Medium: CTBTO publishes unclassified Integrated Field Exercise reports and OSI procedures on its website; detailed scenario designs and observer protocols may require official request or access as an authorized participant.

**Steps:**

- Visit the CTBTO website (ctbto.org) and access the On-Site Inspection pages; download Integrated Field Exercise reports and OSI Team handbook.
- Contact the CTBTO On-Site Inspection Division via Vienna; request expert briefings on blind-exercise design, scenario injection, observation protocols and detection-rate measurement.
- Search the CTBTO's document repository for published lessons-learned reports from past IFE exercises.
- Consult the CTBTO's Training Centre for OSI training materials and exercise-design guidelines.
- Request copies of any IFE scenario design documents, observer checklists or detection-rate scoring sheets that are unclassified.

### 6. Cryptographic Attestation and Hardware Supply-Chain Security Standards (TPM, Secure Enclave, Vendor Key Custody)

**ID:** f460dce0-3ebf-4856-a3c6-8b18cca808ab

**Description:** Technical standards and best-practices documentation on cryptographic hardware attestation (Trusted Platform Modules, secure enclaves, secure elements), firmware attestation chains, attestation key custody and validation protocols, attestation-forgery risks and mitigation, and vendor certification standards (e.g., Common Criteria, FIPS 140-2/140-3). Source material for the Equipment Identity Trust Anchor lever and accredited-examiner validation procedures. Intended audience: cryptographic hardware engineers, accredited examiners, identity-verification specialists. Context: understand the technical foundation for attestation validation, key-compromise risks and realistic error rates.

**Recency Requirement:** Latest available standards (2023–2026): Trusted Computing Group TPM 2.0 specifications, FIPS 140-3 modules approved post-2020, Common Criteria Protection Profiles for cryptographic devices (latest versions), NIST standards on hardware security (SP 800-155, SP 800-193 or later if published).

**Responsible Role Type:** Cryptographic Hardware Attestation and Supply-Chain Security Engineer

**Access Difficulty:** Easy to Medium: Standards and many security-policy documents are publicly available on government and standards-body websites; vendor-specific key-custody procedures may require direct vendor contact or are proprietary.

**Steps:**

- Download TPM 2.0 specifications from the Trusted Computing Group (trustedcomputinggroup.org); access the latest TPM specifications and architectural documents.
- Search the NIST Cryptographic Module Validation Program (CMVP) website for FIPS 140-3 approved modules and their validation certificates; review security policy documents for each module.
- Access NIST standards and guidelines via csrc.nist.gov, specifically NIST SP 800-155 (Guidelines for Hardware Security Module Firmware), SP 800-193 (if published) or equivalent.
- Search the Common Criteria Recognition Arrangement (ccra.acm.org) for certified Protection Profiles (PPs) for cryptographic modules and secure-element devices; download published PPs and Evaluation Assurance Levels (EALs).
- Consult academic and industry sources (IEEE, ACM, Usenix security conferences) for published research on attestation-forgery attacks, firmware-rollback vulnerabilities, and key-custody best practices.
- Contact industry cryptographic vendors (Intel Security Engines, ARM TrustZone, Qualcomm Secure Processing Unit teams) for vendor-specific attestation documentation and key-custody protocols.

### 7. US Domestic Access Authority and Legal Compulsion Precedents (Private Vendors, Export Control, State Enterprises)

**ID:** dc63f9cc-62eb-4225-8275-c9bb0c0438c9

**Description:** Legal opinions, statutes and case law documenting US authority to compel private vendors and equipment manufacturers to participate in verification inspections, potential conflicts with export-control regulations (EAR, ITAR), intellectual-property protections, and any exemptions for state-owned enterprises or contractors with classified government work. Source material for the bilateral legal working group to assess whether domestic access authority exists or requires new legislation. Intended audience: legal implementation team, bilateral counsel. Context: identify legal gaps or bottlenecks that could delay or prevent vendor binding.

**Recency Requirement:** Current statutes and precedents (2010–2026): Export Administration Regulations (EAR), International Traffic in Arms Regulations (ITAR) as currently enforced, relevant federal case law on inspection authorities, Treasury Department rulings on Chinese state-enterprise participation.

**Responsible Role Type:** Legal Implementation and Bilateral Instrument Lead

**Access Difficulty:** Medium: Unclassified statutes and public case law are freely available; legal opinions from OLC or Department of State may be available through FOIA request or official channels, potentially with redactions.

**Steps:**

- Contact the US Office of Legal Counsel (OLC) in the Department of Justice; request a legal opinion on authority to compel private-vendor participation in bilateral equipment verification inspections.
- Access the Bureau of Industry and Security (BIS) export-control guidance on EAR and ITAR exemptions for government-authorized verification activities.
- Search the US Code (title 22, title 50) for verification-authority precedents (e.g., New START inspection authorities, Open Skies Treaty implementation).
- Contact the Export-Import Bank and the Foreign Direct Investment Committee (CFIUS) for guidance on restrictions that might apply to equipment verification at US facilities.
- Consult the Congressional Research Service (crs.gov) for reports on US verification authorities and legal implementation of arms-control treaties.
- Review relevant case law via Google Scholar (scholar.google.com) for judicial opinions on inspection authorities and vendor-compulsion limits.

### 8. Chinese Domestic Access Authority, Vendor-Compulsion Mechanisms, and State-Enterprise Legal Status

**ID:** 5a3be795-bcc8-45b6-b1f3-30fdb27d83c9

**Description:** Chinese legal framework governing verification-authority delegation, vendor-compulsion mechanisms for private and state-owned enterprises, export restrictions on equipment inspection or telemetry export, and potential conflicts with internal Chinese security or industrial-policy regulations. Source material for the bilateral legal working group to assess parallel-authority constraints in China. Intended audience: legal implementation team, Chinese counterpart negotiators. Context: understand Chinese legal and institutional constraints that could limit vendor binding or complicating reciprocal access.

**Recency Requirement:** Current Chinese laws and regulations (2015–2026): Foreign Trade Law of the People's Republic of China, Regulations on Export Control of Goods and Technologies (relevant to dual-use equipment), National Security Law (2015 version and amendments), guidance on state-owned enterprise compliance with bilateral obligations.

**Responsible Role Type:** Legal Implementation and Bilateral Instrument Lead

**Access Difficulty:** Hard: Most detailed Chinese legal guidance and internal directives are not publicly available in English; official diplomatic channels or specialized Chinese-law expertise are required; translations may be available through academic or government partnerships.

**Steps:**

- Contact the Chinese Ministry of Foreign Affairs, Department of Arms Control and Disarmament, for guidance on verification-authority delegation and vendor participation.
- Access the Chinese Ministry of Commerce (MOFCOM) for regulations on export controls and equipment-verification procedures.
- Consult the Chinese Academy of Sciences or relevant Chinese research institutions for translations or summaries of current Chinese legal frameworks on verification authority.
- Request information through official bilateral diplomatic channels (e.g., US–China Joint Commission meetings) on Chinese legal authorities and any anticipated legislative changes.
- Access Chinese-language legal databases (if available through university or government partnerships) for current statutes and regulatory guidance.
- Consult published analyses by law firms or think tanks specializing in Chinese law (e.g., Covington & Burling, Zhong Lun) for expert summaries of applicable legal frameworks.

### 9. US and Chinese Export-Control Regulations and Dual-Use Equipment Classifications

**ID:** 25eff27e-d8e7-4c83-8900-603f5f714f79

**Description:** Current export-control regulations (US EAR, ITAR; Chinese export controls on sensitive equipment) and classifications for dual-use items (semiconductors, computing equipment, cryptographic devices) that may be affected by or constrain bilateral equipment-verification procedures. Determines which equipment can be inspected, what telemetry or forensic data can be exported from China to the US, and what evidence-filtering rules are necessary to comply with export restrictions. Intended audience: legal implementation team, evidence-filtering architects, operators. Context: verify that inspection and evidence-export procedures do not inadvertently violate export controls or create legal liability for participants.

**Recency Requirement:** Current regulations (2024–2026): US Bureau of Industry and Security (BIS) Commerce Control List (CCL), current Deemed Exports guidance, Chinese dual-use export controls as currently enforced, CFIUS rules on information-sharing with foreign governments.

**Responsible Role Type:** Filtered Evidence and Redaction-Gateway Architect, Legal Implementation and Bilateral Instrument Lead

**Access Difficulty:** Medium: US regulations are publicly available on government websites; Chinese regulations may require translation and expert interpretation; specific applicability to bilateral-verification scenarios may require legal counsel from specialized export-control lawyers.

**Steps:**

- Access the BIS Commerce Control List (CCL) via bis.doc.gov; search for export-control classifications relevant to semiconductors, processors, accelerators and computing equipment (Category 3, Item A, for example).
- Review the current State Department ITAR Regulation and International Trafficking in Arms Regulations documentation via pmddtc.state.gov.
- Access the CFIUS operating manual and guidance on what information can be shared with foreign governments in verification contexts via treasury.gov.
- Contact the BIS Export Administration Enforcement team for guidance on deemed-exports implications of bilateral equipment verification.
- Access the Chinese Ministry of Commerce (MOFCOM) export-control guidance and dual-use export regulations (available through official channels or specialized legal sources).
- Consult published analyses by export-control law specialists or industry associations (e.g., National Foreign Trade Council, American Chamber of Commerce in China) for practical guidance on equipment-verification implications of export controls.

### 10. Historical and Current Equipment-Substitution Detection Case Studies and Forensic Analysis Precedents

**ID:** 83eae7d6-c474-401f-9f76-4ca69a49f7ba

**Description:** Case studies of equipment diversion, substitution, or tampering incidents (from arms-control verification contexts, international inspections, supply-chain security literature) documenting what evidence methods successfully detected substitution (physical marks, cryptographic attestation, serial-number verification, firmware analysis) and what evidence layers failed or were circumvented. Source material for designing the Equipment Identity Trust Anchor layer, filter-adequacy pre-test scenarios, and bottleneck analysis. Intended audience: identity-verification specialists, exercise designers, forensic analysts. Context: learn from real-world substitution attempts and detection successes/failures.

**Recency Requirement:** Published case studies and forensic analyses from 2000 onward; focus on post-2010 cases involving semiconductor supply chains, hardware authentication and verification-inspection contexts.

**Responsible Role Type:** Vendor Binding and Equipment Identity Verification Lead

**Access Difficulty:** Medium: Published academic papers and industry reports are publicly available; declassified case studies require FOIA request or official clearance access; current classified incident analyses are not publicly available.

**Steps:**

- Search academic databases (IEEE Xplore, ACM Digital Library, Usenix security conference proceedings) for published research on hardware supply-chain attacks, firmware tampering and authentication-bypass techniques.
- Consult industry reports and whitepapers from security firms (e.g., Black Hat conference presentations, security-vendor whitepapers) on equipment-substitution and tampering-detection methods.
- Request declassified case studies from the Defense Counterintelligence and Security Agency (DCSA) or equivalent US intelligence agencies (if available via FOIA or official channels) on historical equipment-diversion incidents.
- Contact international verification organizations (IAEA, OPCW, CTBTO) for unclassified case studies or lessons-learned documents on substitution-detection successes in their inspection contexts.
- Search the Congressional Record and Government Accountability Office (GAO) reports for documented cases of supply-chain tampering or equipment substitution affecting US military or government systems.
- Consult with private-sector supply-chain security experts and academic researchers in hardware security (e.g., MIT Media Lab, UC San Diego Jacobs School of Engineering) for ongoing research on detection methods and attack vectors.

### 11. Cryptographic Ledger and Distributed-Consensus Specifications and Protocols

**ID:** 96c3c85b-8358-4405-9e88-49552adb49b1

**Description:** Technical specifications for replicated tamper-evident ledgers, hash-chain-based audit trails, Byzantine fault-tolerant consensus protocols, cryptographic checkpoint formats, key-exchange ceremonies and non-repudiation mechanisms. Source material for designing the Ledger Synchronization and Divergence Doctrine. Intended audience: ledger architects, cryptographic specialists. Context: understand available distributed-ledger technologies and cryptographic primitives suitable for bilateral evidence systems.

**Recency Requirement:** Current technical standards and research (2015–2026): NIST recommendations on cryptographic hash functions and digital signatures, academic research on Byzantine fault tolerance (Practical BFT, PBFT variants), ledger-synchronization protocols, audit-trail standards.

**Responsible Role Type:** Secure Ledger and Tamper-Evidence Systems Architect

**Access Difficulty:** Easy to Medium: NIST standards and academic papers are publicly available; specialized consulting or deep technical briefings may require engagement of cryptographic specialists.

**Steps:**

- Access NIST cryptographic standards via csrc.nist.gov; download NIST FIPS 180-4 (Secure Hash Standard) and FIPS 186-5 (Digital Signature Standard).
- Search academic databases (IEEE Xplore, ACM Digital Library, Arxiv) for published research on Byzantine fault-tolerant consensus protocols, replicated state machines and audit-trail architectures.
- Consult industry blockchain and distributed-ledger technology whitepapers and technical documentation (though note that Consortium ledger is NOT a blockchain; it is a bilateral cryptographic checkpoint system).
- Request technical guidance from NIST Computer Security Division on recommended key-exchange and signature protocols for bilateral government systems.
- Consult with cryptographic security firms or academic cryptography research groups for recommendations on checkpoint formats and divergence-detection algorithms.

### 12. Bilateral-Tranche-Release and Matched-Spending-Parity Precedents (Other Bilateral Programs)

**ID:** d82a96a5-bbce-4b25-b30e-d1ad3c48acd6

**Description:** Documentation of how other bilateral government-to-government programs (NATO joint procurement, US–EU research collaborations, bilateral development funds) manage tranche releases, spending parity and currency-conversion rules to prevent asymmetric spending drift or funding weaponization. Source material for designing the budget-parity monitoring and tranche-release procedures. Intended audience: independent budget auditor, bilateral co-chairs, national finance authorities. Context: understand what spending-parity governance mechanisms have proven effective or problematic in practice.

**Recency Requirement:** Recent bilateral program documentation (2015–2026): NATO common-budget procedures, US–EU research funding mechanisms, World Bank co-financing guidelines, examples from current bilateral government programs.

**Responsible Role Type:** Independent Budget Auditor and Fiscal Accountability Officer

**Access Difficulty:** Medium: Some program documentation is publicly available through government transparency initiatives; detailed budget procedures may require official request or consultation with program finance officers.

**Steps:**

- Contact the NATO Resource Policy and Planning Division for documentation on common-budget contribution procedures and parity mechanisms.
- Access the US State Department's Bureau of Administration for guidance on bilateral-program budget management and currency-conversion protocols.
- Search the World Bank's operational guidelines for co-financing and matched-contribution procedures used in bilateral development programs.
- Consult with international organizations' budget and finance divisions (e.g., UN system, OECD) for best-practices documentation on spending-parity monitoring.
- Request redacted program documentation from US bilateral programs (e.g., bilateral research, development aid programs) via FOIA if necessary.

### 13. US Intelligence Community and Chinese Counterpart Intelligence Organizational Charts and Liaison Protocols

**ID:** 7cd1cc68-32e8-40df-af3e-70be3bb5176c

**Description:** Organizational structures and communication channels for US intelligence and counterintelligence services (CIA, DIA, NSA, FBI Counterintelligence Division) and Chinese equivalent organizations (MSS, etc.), including established protocols for bilateral intelligence-liaison relationships, clearance reciprocity procedures, and classified-information-sharing mechanisms. Source material for designing bilateral counterintelligence vetting and clearance-reciprocity procedures. Intended audience: CI unit leads, vetting coordinators, liaison officers. Context: understand existing CI liaison channels and reciprocal-clearance frameworks that can be adapted for Consortium personnel vetting.

**Recency Requirement:** Current organizational information (2022–2026); focus on recent bilateral CI arrangements and clearance-reciprocity developments if available; historical precedents also useful for understanding established protocols.

**Responsible Role Type:** Counterintelligence and Personnel Security Unit Lead

**Access Difficulty:** Hard: Most detailed CI liaison protocols, organizational charts and bilateral arrangements are classified; unclassified information available through official government channels or classified access only; request requires security clearance and official authorization.

**Steps:**

- Contact the Defense Counterintelligence and Security Agency (DCSA) National Industrial Security Program Operations Center (NISPOC) for guidance on bilateral clearance reciprocity and CI protocols.
- Access the CIA's Office of Congressional Affairs for unclassified information on bilateral liaison relationships and intelligence-sharing mechanisms.
- Consult the FBI Counterintelligence Division for information on existing FBI–Chinese counterpart liaison relationships (contact via FBI.gov public affairs).
- Request information through official diplomatic channels (US–China Strategic and Economic Dialogue or equivalent bilateral mechanisms) on CI-liaison protocols.
- Search the Congressional Record for testimony or reports on US–China intelligence-liaison arrangements and clearance-reciprocity discussions.
- Contact the National Security Council's Interagency Policy Committee (IPC) for guidance on bilateral CI cooperation frameworks.

### 14. Current US and Chinese Datacenters and Equipment-Supplier Landscape (Locations, Operators, Equipment Mix)

**ID:** 00e932b9-8258-4ddf-8712-e09fdeb502d5

**Description:** Catalog of major datacenters in Northern Virginia (Loudoun/Prince William) and Beijing–Hebei/Shanghai regions, including operator identities, equipment vendors and suppliers, installed-equipment counts by category, facility sizes and security classifications. Source material for site selection and vendor-census planning. Intended audience: site-selection task, vendor-binding coordinators. Context: identify candidate sites for entry-gate selection and understand regional equipment-supplier distribution affecting vendor-binding logistics.

**Recency Requirement:** Current datacenters (2024–2026); focus on known commercial and state-operated facilities in target regions; historical facility listings also useful for understanding facility evolution.

**Responsible Role Type:** Matched Site Equivalence Task Lead

**Access Difficulty:** Easy to Medium: US datacenters are documented in public real-estate records and SEC filings; Chinese datacenter information is partially available through public sources and industry reports; detailed facility specifications may require direct operator contact or government intelligence sources.

**Steps:**

- Access industry reports from datacenters market-research firms (e.g., Cushman & Wakefield, JLL, Equinix annual reports) on US and China datacenter markets.
- Search public records and property databases for datacenters in Northern Virginia (Loudoun County assessor office, real-estate databases).
- Access SEC filings and investor presentations from major US datacenters operators (Equinix, Digital Realty, etc.) for facility locations and equipment information.
- Contact the Northern Virginia Chamber of Commerce and industry associations for datacenters-facility listings.
- Search Chinese public sources (government development-authority websites, industry publications in English or with translation) for Beijing–Hebei and Shanghai datacenters.
- Consult US trade-policy and export-control databases (Commerce Department Bureau of Industry and Security) for listings of Chinese datacenters with US equipment or technology.

### 15. International Accreditation Standards for Equipment Examination and Testing Laboratories (ISO 17025, Common Criteria EAL Levels)

**ID:** 7249a80a-db9c-42b2-8251-c2cb97784e84

**Description:** International standards for laboratory accreditation (ISO/IEC 17025 for testing and calibration labs) and Common Criteria Evaluation Assurance Levels (EAL 1–7) for security-relevant IT products, specifying what qualifications and processes are required for bilateral-accredited clean-room examination centers. Source material for designing clean-room facility specifications and examiner-qualification procedures. Intended audience: clean-room architects, examiner-training leads, accreditation task. Context: understand what accreditation standards must be met for examination results to be credible and defensible.

**Recency Requirement:** Current standards (2023–2026): ISO/IEC 17025:2017 and any recent amendments, Common Criteria Part 1–3 (latest version, updated through 2024 or latest available), NIST standards for laboratory accreditation if published.

**Responsible Role Type:** Vendor Binding and Equipment Identity Verification Lead

**Access Difficulty:** Medium: ISO standards require purchase or institutional access; Common Criteria specifications are publicly available; NIST guidelines are free; accreditation consulting may require paid engagement.

**Steps:**

- Access the International Organization for Standardization (ISO) website (iso.org) and purchase or access the current ISO/IEC 17025 standard.
- Access the Common Criteria Recognition Arrangement (CCRA) website (ccra.acm.org) for current CC specifications and EAL documentation.
- Contact the American Association for Laboratory Accreditation (A2LA) for guidance on ISO 17025 compliance and laboratory-accreditation requirements.
- Search NIST standards and guidelines via csrc.nist.gov for laboratory-accreditation recommendations (if published).
- Consult international accreditation bodies (e.g., International Laboratory Accreditation Cooperation – ILAC) for accreditation requirements and mutual-recognition frameworks.
- Contact technical-accreditation firms or consulting organizations specializing in laboratory accreditation for practical guidance on compliance procedures.

### 16. Historical Equipment-Substitution and Supply-Chain Tampering Incidents and Investigation Reports

**ID:** c5f62b29-6532-4ec7-b22a-f82f578047aa

**Description:** Declassified or published investigation reports, case studies and forensic analyses documenting historical equipment-substitution, supply-chain tampering or counterfeiting incidents (e.g., Chinese counterfeit electronics in US military supply chains, firmware-compromise incidents, attestation-forgery attempts), including: what substitution methods were used, what evidence enabled detection (or failed to detect), what forensic analysis methods proved decisive, and what detection-rate challenges existed. Source material for validating the equipment-identity-verification protocol and designing filter-adequacy test scenarios. Intended audience: identity-verification specialists, exercise designers, forensic analysis leads. Context: learn from real-world incidents to inform detection procedures.

**Recency Requirement:** Published case studies from 2010 onward; focus on post-2015 incidents involving firmware, cryptographic compromise or semiconductor supply-chain tampering; historical Cold War-era substitution attempts also instructive.

**Responsible Role Type:** Vendor Binding and Equipment Identity Verification Lead

**Access Difficulty:** Medium to Hard: Some GAO reports and FBI summaries are publicly available; declassified investigation reports require government FOIA request or official clearance; detailed forensic analyses may remain classified.

**Steps:**

- Contact the Defense Counterintelligence and Security Agency (DCSA) for declassified case studies on equipment-substitution incidents affecting US defense systems.
- Search the Government Accountability Office (GAO) website (gao.gov) for reports on counterfeit electronics and supply-chain security failures.
- Consult the US Immigration and Customs Enforcement (ICE) website for case summaries on seized counterfeit electronics and investigation techniques.
- Access the US Federal Bureau of Investigation (FBI) public-affairs publications for declassified case studies on intellectual-property theft and supply-chain attacks.
- Search academic databases (IEEE Xplore, ACM Digital Library) for published research on hardware authentication, counterfeit-detection techniques and supply-chain-security case studies.
- Request information from major IT security firms (Mandiant, CrowdStrike, etc.) through published threat reports and conference presentations on hardware-compromise incidents.
- Consult published accounts in trade publications and news archives on notable supply-chain tampering or counterfeit incidents (e.g., New York Times coverage of Chinese counterfeit-electronics operations).