# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Bilateral Verification and Arms Control Treaty Specialist

**Knowledge**: Arms control verification regimes, New START implementation, IAEA safeguards protocols, bilateral confidence-building mechanisms, deadlock resolution in trust-free environments

**Why**: The plan's core innovation is deadlock mechanics, double-key governance and automatic-suspension triggers designed to prevent one party from obstruction. This expert validates that the escalation timers (5/8/13 days), enumerated suspension triggers and CHALLENGE-tag partition match precedents from New START, IAEA and OPCW, and identifies whether the status-quo escalation can credibly prevent indefinite stalling when a government shields an operator.

**What**: Review the Deadlock and Suspension Mechanics lever, the 15-day unresolved-discrepancy threshold, and the automatic-suspension trigger list (unverifiable >3%, divergence >5%, parity variance >15%, denial-rate >15%, age >15 days) against historical patterns of verification breakdowns; flag any threshold that precedent suggests is gamed routinely.

**Skills**: Treaty drafting and implementation, escalation-procedure design, precedent analysis, political-obstruction pattern recognition, confidence-building institutional design

**Search**: bilateral arms control verification specialist, New START deadlock resolution, IAEA safeguards escalation procedures, trust-free verification mechanisms

## 1.1 Primary Actions

- Establish a bilateral entry-gate steering committee with weekly condition tracking by Month 0.5 (2026-10-27), lock binding instrument-signature deadline at Month 7 (2027-05-12), and define principal go/no-go checkpoint at Month 7.5 (2027-05-27) with explicit escalation timers (48-hour review) for any slipped condition. Pre-position USD 50M gate-readiness sub-account from contingency to fund entry work without sunk-cost accumulation if gate certification fails.
- Complete vendor-participation census by Month 1 (2026-11-12) and establish ≥2 bilateral-accredited clean-room examination centers by Month 2.5 (2026-12-27), funded from USD 500M testing envelope. Document three-tier evidence ladder (attestation; customs + maintenance + physical; supervised examination) by Month 1.5 (2026-11-27) and classify all declared equipment by vendor binding-status by Month 2 (2026-12-12). Escalate Tier C equipment (no binding or vendor refusing) to unverifiable status and trigger bilateral principal resolution within 5 days.
- Embed Deadlock and Suspension Mechanics in the signed bilateral instrument by Month 7 (2027-05-12) with fixed escalation timers (Tier 1: Days 1–5; Tier 2: Days 5–8; Tier 3: Days 8–13), enumerated automatic-suspension triggers (unverifiable >3%, divergence >5%, denial variance >15%, discrepancies >10 days), and explicit CHALLENGE-tag partition excluding exercise events from suspension triggers absent principal adjudication. Rehearse misclassification escalation procedure within 2 hours at Month 8 (2027-06-12).

## 1.2 Secondary Actions

- Lock minimum evidence schema (serial number, firmware hash, attestation digest, maintenance timestamp, physical identifiers, cluster membership and power state redactability by bilateral agreement) by Month 1.5 (2026-11-27) and run filter-adequacy blind pre-test at Month 8.5 (2027-06-27) with ≥10 injected substitutions; halt scored exercises if detection rate falls below 85%.
- Establish bilateral Counterintelligence Unit by Month 0.5 (2026-10-27) with ≥4 senior specialists per country; implement comprehensive CI vetting by Month 2 (2026-12-12) including background investigation, financial vetting, polygraph and reciprocal intelligence-service clearance for all 350–500 staff. Impose 6-month site tenure limits with 2-month breaks and fund insider-threat red team (2 per country) to attempt targeted compromise of inspectors and evidence handlers.
- Implement hardened ledger infrastructure by Month 2 (2026-12-12) in dedicated geographically diverse SCIF-equivalent facilities ≥300 km apart; establish cryptographic key-exchange protocol with bilateral ceremony by Month 1.5 (2026-11-27); deploy hourly signed hash-chain checkpoints over dedicated IPsec/TLS tunnels; establish neutral-party digest escrow (USD 20–30M estimate) by Month 2.5 (2026-12-27) to allow forensic proof of non-tampering.
- Complete staffing dry-run at Month 8 (2027-06-12) validating 24/7 shift coverage, leave buffers (15%), surge reserve (10%), cross-site floater pool (20–30%) and single-function redundancy rules. Validate that no post-entry staffing shortfall below 80% of target will force operational curtailment or violate the no-single-person-critical-function rule.
- Publish non-negotiable minimum evidence schema by Month 1.5 (2026-11-27) listing non-redactable fields (serial number, firmware version, attestation digest, maintenance timestamp, physical markers); document that any filter rule stripping a non-redactable field automatically escalates equipment to unverifiable status. Run preliminary filter-adequacy exercises in staging areas by Month 8.5 (2027-06-27) before any scored exercises begin.

## 1.3 Follow Up Consultation

Next consultation should address: (1) Principal-level commitment to the entry-gate steering committee and binding instrument-signature deadline (Month 7, 2027-05-12) with named co-chair leads and escalation authority; (2) Vendor binding strategy and clean-room site selection/approval process, including legal authority to compel private vendor participation in each country; (3) Detailed Deadlock and Suspension Mechanics language for the bilateral instrument, including objective trigger thresholds and CHALLENGE-tag partition procedures; (4) Counterintelligence vetting scope and timeline for the ~350–500 estimated staff, including reciprocal intelligence-service clearance process and any conflicts with contractor or temporary-staff models; (5) Ledger security architecture, including facility specifications, cryptographic key custody and the neutral-custodian escrow service procurement; (6) Staffing model validation via dry-run results and leave/surge contingency planning.

## 1.4.A Issue - Entry-gate certification timeline is critically underspecified and risks catastrophic delay

The plan states entry conditions must be certified by Month 9 (2027-07-12) but contains no binding instrument language, no escalation procedure for individual-condition slip, and no defined consequence if any one condition delays past Month 8 (2027-06-12). The bilateral instrument itself—the most time-consuming entry condition—is treated as a starting assumption rather than a tracked deliverable with a hard signature deadline and principal-level go/no-go checkpoint. If instrument negotiation slips beyond Month 7 (2027-05-12), the entire 90-day Phase One clock compresses or fails.

### 1.4.B Tags

- critical-path-opacity
- no-binding-deadlines
- cascade-failure-risk

### 1.4.C Mitigation

Immediately establish a bilateral entry-gate steering committee with weekly condition tracking by Month 0.5 (2026-10-27). Lock a binding instrument-signature deadline at Month 7 (2027-05-12) with documented escalation: any condition not certified by Month 8 (2027-06-12) triggers automatic principal-level go/no-go review within 48 hours. Pre-position a USD 50M gate-readiness sub-account from contingency, accessible only upon joint certification of all conditions, to fund entry work without sunk-cost accumulation if any condition fails.

### 1.4.D Consequence

Without binding deadlines and escalation procedure, instrument negotiation can drift 2–4 months past Month 7 (2027-05-12), compressing Phase One to 30–60 days or forcing cancellation. Sunk costs of USD 100–200M (estimate) for preliminary work would accumulate against the spending envelopes, not contingency, leaving insufficient funds for Phase One operational work. A delayed or failed entry gate is the highest-probability failure mode.

### 1.4.E Root Cause

The plan treats entry certification as a precondition rather than a managed deliverable. There is no fixed signature deadline for the instrument, no named lead for each condition, no escalation trigger for individual slips, and no separation of gate-readiness funding from operational funds. This reflects a governance assumption that entry conditions will self-organize; they will not under bilateral distrust.

## 1.5.A Issue - Vendor-binding and attestation-concentration risk is documented but not mitigated by Month 2 (2026-12-12)

The plan anchors equipment identity on vendor-issued cryptographic attestation validated by accredited examiners, creating a concentration risk. Documents acknowledge 10–40% of equipment may become unverifiable if attestation fails or vendors refuse binding. However, the plan contains no timeline for vendor census, binding execution, or key-custody validation before Phase One starts. The fallback ladder (vendor-supervised testing, filtered evidence, clean rooms) is mentioned but not funded within a specific envelope or staffed by a named unit.

### 1.5.B Tags

- attestation-single-point-failure
- vendor-refusal-mitigation-missing
- unverifiable-equipment-risk

### 1.5.C Mitigation

Complete vendor-participation census by Month 1 (2026-11-12): each site operator must declare ≥95% of supplier list by equipment count. Establish ≥2 bilateral-accredited clean-room examination centers (one per country) by Month 2.5 (2026-12-27), funded from the USD 500M testing envelope. Document a three-tier evidence ladder by Month 1.5 (2026-11-27): Tier 1 (attestation); Tier 2 (customs + maintenance logs + physical inspection); Tier 3 (supervised examination or witnessed destruction). Classify all declared equipment by vendor binding-status by Month 2 (2026-12-12) and escalate Tier C equipment (no binding or vendor refusing) to unverifiable status.

### 1.5.D Consequence

If vendor binding is not complete by Month 8 (2027-06-12), Phase One enters with unknown unverifiable-equipment counts, violating the 3% threshold rule. Vendors discovered to be refusing cooperation mid-Phase-One cannot be recovered by clean rooms already built or by evidence layers documented after the clock starts. A 15–30% unverifiable-equipment discovery post-entry forces site failure and an automatic Stop condition.

### 1.5.E Root Cause

Vendor binding is treated as an entry condition rather than a pre-Phase-One capability-build. The plan lists vendor participation as a gate but does not assign ownership, timeline or contingency funding to vendor census, binding negotiation, key validation or clean-room construction. This reflects assumption that vendor cooperation is cheaper and simpler than it actually is; supply-chain coordination typically requires 4–6 months and escalation to principals.

## 1.6.A Issue - Deadlock and suspension mechanics lack objective trigger definitions and risk weaponization of contested findings

The plan states that deadlock escalates to technical referees (Days 5–8) and principals (Days 8–13), but the decision document does not define what constitutes a material disputed finding, which findings may suspend a site automatically versus which require co-chair agreement, or how manufactured incidents are partitioned from operational findings. Without enumerated objective triggers (e.g., unverifiable >3%, divergence >5%), one government can stall by labeling every inconclusive finding a disagreement, aging it past 13 days, and forcing a Stop condition through inaction rather than evidence.

### 1.6.B Tags

- deadlock-weaponization-risk
- no-auto-suspension-criteria
- obstruction-loophole

### 1.6.C Mitigation

Embed Deadlock and Suspension Mechanics in the signed bilateral instrument by Month 7 (2027-05-12) with mandatory fixed escalation timers (Tier 1: Days 1–5 co-chairs; Tier 2: Days 5–8 technical referees; Tier 3: Days 8–13 principals) and enumerated automatic-suspension triggers: unverifiable >3% for 5 days; divergence >5%; denial variance >15%; discrepancies >10 days old. Explicitly partition challenge-exercise events from operational triggers via CHALLENGE tags in the ledger, excluding exercise events from suspension triggers absent principal adjudication.

### 1.6.D Consequence

Without objective triggers and partition rules, a government can delay contested findings by 13+ days, aging them past the escalation window and forcing a Stop condition via inaction. Alternatively, a single misclassified challenge-exercise event (estimated 2–3 false positives per Phase One if partition is weak) can trigger automatic suspension, destroying operational progress and eroding regime credibility. Either path converts the deadlock procedure into a weapon.

### 1.6.E Root Cause

The plan adopts the principle that deadlock must not permit unilateral override, but it does not define objective triggers that convert principle into procedure. Without enumerated criteria, the referees' task becomes subjective judgment about materiality, and age-based escalation alone cannot distinguish genuine obstruction from legitimate technical disagreement. This reflects assumption that consensus on triggers is easier to reach than it is; triggers should be frozen in the instrument before Phase One starts.

---

# 2 Expert: Cryptographic Hardware Attestation and Supply-Chain Security Engineer

**Knowledge**: Vendor-issued cryptographic attestation, TPM and secure-enclaves attestation chains, key custody and compromise risk, attestation forgery and firmware rollback attacks, accredited examiner validation protocols

**Why**: The plan anchors equipment identity primarily on vendor-issued cryptographic attestation validated by accredited examiners, treating physical inspection as a corroborating layer. This creates a single-source-failure risk if attestation keys are compromised or vendors collude. This expert assesses whether the layering (attestation + customs + physical + maintenance logs) is sufficient to detect a determined substitute when a vendor's attestation infrastructure is already under state control.

**What**: Analyze the Equipment Identity Trust Anchor lever's assumption that accredited independent examiners can reliably validate vendor attestation without access to vendor key custody and certificate chains; quantify false-negative and false-positive risk for attestation validation under the proposed two-layer agreement rule.

**Skills**: Cryptographic key-compromise forensics, firmware-attestation attack surface analysis, supply-chain risk modeling, accredited-examiner protocols, vendor-compromise scenarios

**Search**: TPM attestation verification engineer, hardware supply chain security, cryptographic attestation validation, vendor key custody risk

## 2.1 Primary Actions

- Launch bilateral-instrument negotiation and establish weekly entry-condition steering committee by Month 0.5 (2026-10-27); lock binding instrument-signature deadline at Month 7 (2027-05-12) with principal go/no-go escalation at Month 7.5 (2027-05-27) if any of the seven conditions slips; pre-position USD 50M gate-readiness sub-account from contingency by Month 0.5 (2026-10-27).
- Complete vendor-participation census and binding certification by Month 2 (2026-12-12); classify equipment into three tiers (binding+keys, binding+pending, refusal); escalate Tier-C equipment to unverifiable status immediately; stand up >=2 clean-room examination centers by Month 3 (2027-01-12) with joint protocols approved by Month 2.5 (2026-12-27).
- Run filter-adequacy blind pre-tests by Month 3 (2027-01-12) with >=10 injected substitutions per event type; measure blind-detection rate against 90% target; halt Phase One and renegotiate filters if detection falls below 85%; document all corroboration and filter decisions in the tamper-evident ledger.
- Embed Deadlock and Suspension Mechanics in the bilateral instrument signed by Month 7 (2027-05-12) with binding language defining automatic triggers, false-positive escalation (2-hour notification, automatic reinstatement) and CHALLENGE-tag partition as a technical control; test the partition in a pre-Phase-One rehearsal by Month 8 (2027-06-12) and mark results in the KPI dashboard.
- Establish bilateral Counterintelligence Unit by Month 0.5 (2026-10-27); implement comprehensive CI vetting protocol for all 350–500 cleared staff by Month 2 (2026-12-12); institute 6-month site tenure limits with 2-month breaks and compartmentation by event type; fund and operationalize an insider-threat red cell by Month 1 (2026-11-12).

## 2.2 Secondary Actions

- Establish independent Challenge Exercise Design Panel by Month 1 (2026-11-12); design blind scenarios for all 7 event types and publish cryptographic commitment (signed hash digest) to sealed scenario catalog by Month 1.5 (2026-11-27); update exercise schedule in KPI dashboard by Month 2 (2026-12-12).
- Design Inspection Zone Geometry and Evidence Filtering boundaries by Month 1.5 (2026-11-27) through joint operator-inspector meetings; establish operator-controlled redaction gateway by Month 2 (2026-12-12); log all filter decisions in ledger with reason codes; embed host-country operator liaisons in inspection teams by Month 1 (2026-11-12) and track operator-consent status in quarterly KPI reports.
- Establish hardened secure facilities for national ledger nodes by Month 2 (2026-12-12) in geographically diverse locations >=300 km apart; implement dedicated authenticated IPsec/TLS transport with bilateral key-derivation ceremony by Month 1.5 (2026-11-27); define Ledger Synchronization doctrine with hourly signed checkpoints, divergence detection within 4 hours and formal reconciliation within 24 hours by Month 2 (2026-12-12).
- Establish neutral-party digest escrow (trusted custodian) by Month 2 (2026-12-12) to hold signed digests of both national ledger copies updated hourly; cost estimated USD 15–20M (estimate) from legal/audit envelope; require joint forensic analysis with custodian observer present.
- Conduct staffing dry-run at Month 2 (2026-12-12) validating 24/7 shift coverage for 4 sites, leave buffers (15%), surge capacity (10% standing plus 20–30% floaters) and tenure-rotation schedules; identify staffing shortfalls and adjust recruitment by Month 3 (2027-01-12); document staffing model in the bilateral instrument by Month 7 (2027-05-12).
- Define Covered-Equipment Schedule Abstraction Ladder by Month 1.5 (2026-11-27) with role-based categories that resist obsolescence; implement versioned, double-key update procedure; establish split-escrow threshold custody between national specialist groups if needed; lock provisional schedule in bilateral instrument by Month 7 (2027-05-12).
- Design Opening Inventory Baseline and Starting-State Seal procedure by Month 1.5 (2026-11-27); declare whether baseline will be full census, progressive or operator-self-declared; if full census, allocate 5 days (Days 1–5 of Phase One) for sealing with joint counts at both countries; document baseline methodology in bilateral instrument.
- Define Reciprocal Access Parity Accounting Method by Month 2 (2026-12-12) specifying unit of comparison (matched events vs. outcomes), tolerance bands (±10% proposed), reason-coded denials and delay-response procedures; establish standing parity ledger with automatic trip points for impaired-confidence review (>15% variance for 2 consecutive weeks); publish parity thresholds in bilateral instrument.
- Design Departure Disposition Evidence Ladder by Month 1.5 (2026-11-27) specifying proof tier for each of 5 exit dispositions (witnessed destruction, verified disablement, transfer, documented release, unresolved); require pre-declaration of intended disposition >=5 days before removal; establish penalty for unresolved dispositions (automatic escalation after 10 days).
- Establish Verdict Evidence Sufficiency and Threshold Calibration by Month 2 (2026-12-12); pre-register all Go/Modify/Stop thresholds with documented validation method before Phase One starts; mark provisional figures clearly (e.g., 95% identity confidence, 3% unverifiable, 90% detection); calibrate thresholds against early blind exercises and freeze before scored exercises begin; document all thresholds in bilateral instrument.

## 2.3 Follow Up Consultation

Next meeting should confirm: (1) bilateral steering-committee charter and first-meeting date (within 1 week); (2) principal go/no-go escalation procedure at Month 7.5 (2027-05-27) and contingency-draw governance; (3) vendor census methodology and Tier-C escalation authority; (4) clean-room site selection, joint-protocol review calendar and examination-cost estimates; (5) filter-adequacy pre-test design, blind-substitution scenarios and detection-rate target validation; (6) CHALLENGE-tag technical specification and false-positive escalation rehearsal schedule; (7) Counterintelligence Unit charter, CI vetting protocol timeline and red-team scope; (8) ledger facilities, key-derivation ceremony schedule and neutral-custodian procurement. Highest priority: confirm instrument-signature deadline Month 7 (2027-05-12) and principal escalation authority at Month 7.5 (2027-05-27).

## 2.4.A Issue - Entry-gate scheduling has no buffer and will slip past the Phase One clock start

The plan targets Month 9 (2027-07-12) Phase One start but gate certification outer limit is Month 12 (2027-10-12). Seven mandatory entry conditions (instrument, appropriations, access authority, site selection, inspector approval, operator/vendor participation, schedule) typically require 6–12 months each. Compressed timelines to Month 7–9 (2027-05-12 to 2027-07-12) are aggressive without buffer. If instrument signature slips to Month 8 (2027-06-12) or Month 9 (2027-07-12), vendor binding cannot complete by Month 8 (2027-06-12), and Phase One start moves into Months 10–12 (2027-08-12 to 2027-10-12), consuming the operational window before verdict becomes due Month 12.25 (2027-10-20). Current plan shows no recovery margin.

### 2.4.B Tags

- entry-gate-stall
- critical-path-compression
- schedule-slip-risk

### 2.4.C Mitigation

Establish a weekly bilateral steering committee tracking all eight conditions by Month 0.5 (2026-10-27). Lock binding signature deadline at Month 7 (2027-05-12) with principal go/no-go escalation if any condition slips beyond Month 7.5 (2027-05-27). Pre-position USD 50M gate-readiness sub-account in contingency (from USD 500M) by Month 0.5 (2026-10-27) accessible only if all conditions certify by Month 9 (2027-07-12). If any condition remains uncertified by Month 9 (2027-07-12), trigger automatic 30-day principal review and Phase One delay announcement. This establishes visible, escalatable checkpoints and protects contingency from sunk-cost burn on a failed gate.

### 2.4.D Consequence

Without buffer and escalation, slippage in one condition (e.g., access-authority legislation) stalls the entire program silently. Sunk costs (staffing recruitment, facility prep, vendor negotiation) accumulate against a shrinking operational window. Phase One may start in Month 11–12 (2027-09-12 to 2027-10-12) or not at all, making the 90-day test and verdict impossible. The program loses credibility with both governments and wastes USD 100–200M (estimate) on preparation work that cannot be completed. Political backing erodes as momentum stalls.

### 2.4.E Root Cause

The plan designates entry conditions as 'mandatory' but does not create escalation triggers, recovery gates or visible checkpoints. Instrument negotiation alone typically takes 4–6 months in bilateral contexts; starting at Month 0 (2026-10-12) to finish by Month 7 (2027-05-12) assumes no rework, legal dispute or legislative delay. Appropriations in Congress and China's budget cycles also have fixed calendars that may not align. The plan assumes these can be compressed without cost or delay recovery; that is unrealistic.

## 2.5.A Issue - Attestation-anchored identity creates vendor-key concentration risk; unverifiable-equipment percentage is projected 10–40% without proven fallbacks

The Pioneer's Gambit anchors equipment identity on vendor-issued cryptographic attestation validated by accredited examiners. This scales well for many units but concentrates trust in vendor key custody, firmware integrity and examiner independence. If a vendor's keys are compromised, firmware is rolled back, or attestation is forged, a large batch of units becomes unverifiable. The plan cites 10–40% unverifiable as an estimate but provides no validation that corroborating layers (customs, physical inspection, maintenance records) will suffice. Clean-room centers and three-tier evidence ladders are proposed but not stood up before Phase One starts. Filter-adequacy testing happens at Month 8.5 (2027-06-27), only 2 weeks before the Phase One clock; if 85% detection threshold is not met, scored exercises halt and Phase One is delayed.

### 2.5.B Tags

- attestation-concentration
- vendor-key-compromise
- unverifiable-equipment-risk
- filter-adequacy-untested

### 2.5.C Mitigation

Complete vendor-participation census and binding by Month 2 (2026-12-12). Classify all declared equipment by vendor into three tiers: (A) binding signed, keys validated; (B) binding signed, keys pending validation; (C) no binding or vendor refusing. Automatically escalate Tier C equipment to unverifiable and demand bilateral principal resolution within 5 days. Stand up >=2 clean-room examination centers by Month 3 (2027-01-12) with joint protocols approved by Month 2.5 (2026-12-27). Run filter-adequacy blind pre-tests by Month 3 (2027-01-12) with >=10 injected substitutions (wrong serial, firmware rollback, attestation forgery, seal tampering); measure blind-detection rate against 90% target. If detection falls below 85%, halt Phase One and renegotiate filters or evidence schema before proceeding. Document all corroboration agreements in the ledger.

### 2.5.D Consequence

If vendor keys are compromised or attestation is forged mid-test, a large batch of equipment identity becomes disputed without recourse. Corroborating layers may be unavailable (customs records incomplete, physical seals not checked, maintenance logs withheld by vendor). The site fails the unverifiable-equipment threshold (>=3% triggers automatic suspension), and Phase One halts with no clear path to resolution. Either government can blame the other for weak corroboration, deadlock persists, and the verdict becomes impossible. The Go decision becomes unsustainable if unverifiable equipment was large but was not detected until escalation.

### 2.5.E Root Cause

The plan assumes vendor key validation and clean-room examination centers can be staged between gate certification and Phase One start, compressed into Months 7–9 (2027-05-12 to 2027-07-12). Vendor binding typically requires 2–4 months of negotiation and legal review. Key validation ceremonies require cryptographers from both countries to jointly generate and verify secrets, taking 1–2 weeks per vendor. Clean-room construction takes 3–6 months. The plan has no buffer for vendor refusal, legal challenge or key-derivation delays. Filter-adequacy testing at Month 8.5 (2027-06-27) is too late to redesign evidence schema if thresholds are not met, so Phase One risk escalation is unavoidable.

## 2.6.A Issue - Deadlock escalation and automatic-suspension triggers lack sufficient partition and reconciliation safeguards; false-positive cascade risk is uncontained

The plan defines enumerated automatic-suspension triggers (unverifiable >3%, ledger divergence >5%, access denial >15%, discrepancy age >15 days) with escalation timers (5/8/13 days) and a CHALLENGE-tag partition. However, the partition is not enforced by system controls—it depends on human actors correctly tagging scenarios before injection and recognizing tags during operational triage. If a challenge-exercise event is misclassified as operational (estimated 2–3 false positives per Phase One if partition is weak), it can trigger automatic suspension automatically. The misclassification escalation rule (notify principals within 2 hours, automatic reinstatement) has no binding language in the bilateral instrument; either co-chair can dispute the reinstatement, returning to deadlock. False-positive cascade can consume 3–7 days of operational work and erode regime credibility with minimal recovery path.

### 2.6.B Tags

- deadlock-escalation-weakness
- false-positive-cascade
- challenge-partition-enforcement
- suspension-trigger-ambiguity

### 2.6.C Mitigation

Embed Deadlock and Suspension Mechanics with binding language in the bilateral instrument signed at Month 7 (2027-05-12): specify that enumerated automatic-suspension triggers are objective and require no co-chair discretion; define false-positive cascade containment: if a CHALLENGE-tagged event is misclassified and incorrectly triggers suspension, principals are notified within 2 hours (not following 5-day deadlock timers), and site operations are automatically reinstated pending principal adjudication without waiting for double-key authorization. Document the CHALLENGE partition as a technical control: all injected scenarios are tagged in the ledger before injection using cryptographic commitment (signed hash digest published in advance); any system flagging a tagged event as operational must immediately notify co-chairs with the tag as proof. Test the partition in a pre-Phase-One rehearsal at Month 8 (2027-06-12): simulate a misclassified CHALLENGE event, measure time-to-escalation and verify automatic reinstatement works within 2 hours without deadlock. Mark this test result in the KPI dashboard.

### 2.6.D Consequence

If false-positive cascade is not contained, a single mistagged exercise event can suspend a site for 5–15 days while escalation proceeds. Both governments dispute the misclassification, site operators lose confidence, and the regime's ability to distinguish test from operation becomes credibility-toxic. Phase One may not recover operational tempo before the 90-day window closes, forcing an early Modify or Stop verdict despite the site being operationally sound. Alternatively, if CHALLENGE-tag partition is ignored, legitimate exercise events trigger real operational responses (suspension, filter renegotiation), contaminating the exercise data and making blind-exercise scoring meaningless.

### 2.6.E Root Cause

The plan documents CHALLENGE tagging as a procedural requirement but does not embed it in the bilateral instrument with binding language or enforce it with technical controls (e.g., ledger system rules that block operational triggering of tagged events). The false-positive escalation rule (notify principals, reinstate) is stated in procedural documents but lacks authority language, so either co-chair can dispute reinstatement and re-enter deadlock. The pre-test rehearsal is mentioned but not specified as a mandatory gate, so the partition's effectiveness is not validated before operational scoring begins. This leaves the partition dependent on human attention during fast-moving operational triage, where misclassification and disputes are likely.

---

# 3 Expert: Secure Ledger and Tamper-Evidence Systems Architect

**Knowledge**: Replicated ledger consistency and divergence detection, cryptographic checksums and hash-chain integrity, offline and online synchronization protocols, evidence-preservation and non-repudiation design, ledger-node hardening and key-escrow systems

**Why**: The plan relies on a replicated tamper-evident bilateral ledger as the foundation for detecting modifications and proving the integrity of all site findings. The Ledger Synchronization and Divergence Doctrine lever specifies hourly checkpoint exchanges, a 4-hour divergence-detection window and a neutral digest custodian. This expert validates whether the proposed transport (dedicated IPsec tunnels, signed hash-chain checkpoints, offline courier fallback) can actually achieve the 1-hour synchronization KPI and whether the divergence-detection threshold (>5% disputed events) is meaningful given latency and partition risk.

**What**: Assess the ledger architecture's ability to detect tampering within the 4-hour detection window against network-partition, replay-attack and key-compromise scenarios; validate the neutral-custodian digest-escrow design and estimate the undetected-tampering risk under each transport mode (online, offline courier, hybrid).

**Skills**: Distributed ledger consistency protocols, cryptographic checkpoint design, Byzantine-resilience modeling, offline synchronization algorithms, non-repudiation and evidence-preservation

**Search**: distributed ledger Byzantine fault tolerance, tamper-evident log architecture, cryptographic checkpoint synchronization, ledger divergence detection protocol

## 3.1 Primary Actions

- Lock the bilateral instrument signature deadline at Month 7 (2027-05-12) and the principal go/no-go checkpoint at Month 7.5 (2027-05-27) in the instrument language itself before signature. Document that any entry condition slipping beyond its assigned sub-deadline triggers automatic bilateral escalation within 48 hours with a public written decision to proceed or defer the entire Phase One gate.
- Establish a bilateral steering committee by Month 0.5 (2026-10-27) that tracks all seven entry conditions weekly and publishes a consolidated status report accessible to both co-chairs every Friday. Require that the committee raise any condition trending past its deadline to principal level immediately.
- Define and document an explicit equipment-identity-conflict rule in the bilateral instrument by Month 7 (2027-05-12): 'If cryptographic attestation and physical inspection disagree on equipment identity, the unit is escalated to the referee panel for dual-signed adjudication. No single evidence layer is decisive. At least two independent layers must affirmatively agree for identity confidence to exceed 90%.' Specify the exact process and timeline for referee adjudication (target: 2 business days).
- Conduct a filter-adequacy blind pre-test by Month 8.5 (2027-06-27) injecting at least 10 substitutions where cryptographic attestation is unaltered but physical marks or serial numbers are forged. Measure detection rate with attestation-only evidence stripped. If detection falls below 85%, halt all scored exercises and require bilateral renegotiation of the redaction-gateway rules before resuming.
- Embed CHALLENGE-event partition rules in the bilateral instrument by Month 7 (2027-05-12) with mandatory language: 'Every challenge-exercise event is marked CHALLENGE in the ledger before injection. No CHALLENGE event may trigger suspension, impaired-confidence review, or KPI violation. Misclassification of a CHALLENGE event as operational requires notification to both co-chairs within 30 minutes and automatic site reinstatement within 2 hours pending principal adjudication. A third CHALLENGE misclassification per site escalates to principals immediately.' Publish a separate CHALLENGE-tag operations manual by Month 9 (2027-07-12).

## 3.2 Secondary Actions

- Pre-position the USD 50M gate-readiness escrow as a separate bilateral account in the first tranche release (Month 7, 2027-05-12), with the rule that it is accessible only upon simultaneous certification of all seven entry conditions. Document that 50% of escrow draws require joint authorization, and any draw approaching the limit triggers principal notification.
- Develop a bilateral entry-condition certification checklist by Month 6 (2027-04-12) that maps each of the seven conditions to a specific deliverable, a responsible party, and a hard deadline with no flexibility. Publish the checklist in both English and Mandarin and reference it in weekly steering-committee reports.
- Commission an independent entry-condition audit by Month 8 (2027-06-12) to verify that all seven conditions are substantively met (not merely signed or announced). Require the auditor to flag any condition that is incomplete, ambiguous or at risk of challenge by the other party, with immediate escalation to principals if audit finds material gaps.
- Design and conduct a staffing dry-run at Month 8 (2027-06-12) involving at least 25% of the estimated 350-500 cleared personnel, simulating a full 72-hour shift rotation covering all four sites and all major operational functions (intake, monitoring, exit, evidence handling, ledger synchronization). Use the dry-run to validate staffing assumptions, identify surge-capacity shortfalls and test compartmentation and tenure limits.
- Establish a bilateral filter-rule audit trail by Month 8.5 (2027-06-27): document every field redaction, reason code, authorizing engineer and timestamp in a ledger accessible to both countries' sensitive-asset experts. Conduct a final bilateral review of all redaction rules by Month 9 (2027-07-12) before operational equipment processing begins. Mark any rule that has changed since bilateral agreement as a protocol change requiring double-key authorization.
- Schedule quarterly compartmentation audits (Months 3, 6, 9 = 2027-01-12, 2027-04-12, 2027-07-12) to verify that inspectors are complying with tenure limits, site segregation and knowledge compartments. Log any compartmentation violation in the ledger and escalate to the CI unit within 24 hours.
- Develop a misclassification-response playbook by Month 9 (2027-07-12) that specifies the exact actions to take if a CHALLENGE event is flagged as operational: notified parties, required timeline, automatic reinstatement procedure, notification to operators, and escalation to principals. Rehearse the playbook with inspectors and system operators at Month 9 (2027-07-12) to ensure 30-minute notification can be reliably achieved.

## 3.3 Follow Up Consultation

At Month 6 (2027-04-12), reassess entry-condition progress against the Month 7 (2027-05-12) deadlines. If any condition shows risk of slippage, initiate principal-level negotiation immediately. Verify that the bilateral steering committee is functioning, that weekly reports are being produced and that escalation procedures are clear. Review the filter-adequacy pre-test plan (Month 8.5 = 2027-06-27) to confirm that sufficient test equipment and forensic resources are allocated. Confirm that the bilaterally agreed CHALLENGE-partition rules are locked in the instrument and that system operators understand them. Discuss fallback plans if attestation validation is delayed (clean-room centers), if vendor binding stalls, or if identity confidence remains below 90% after pre-testing.

## 3.4.A Issue - Entry-Gate Certification Timeline is Catastrophically Underspecified and Drives Critical-Path Failure Risk

The plan states entry conditions must be certified by Month 9 (2027-07-12) but provides no binding instrument deadlines, no escalation procedures, and no mechanism to force simultaneous certification of all seven conditions. The pre-assessment document identifies a USD 50M gate-readiness escrow but does not lock it into the bilateral instrument language or define how it activates. Without a signed deadline at Month 7 (2027-05-12) and explicit principal-level go/no-go at Month 7.5 (2027-05-27), a single slow condition (e.g., domestic access authority or vendor binding) will stall the entire gate, consuming months and burning the contingency on preparatory costs that cannot recover if entry fails.

### 3.4.B Tags

- entry_gate_stall
- critical_path_risk
- governance_ambiguity
- sunk_cost_burn

### 3.4.C Mitigation

Embed mandatory instrument-signature deadline (Month 7, 2027-05-12) and principal go/no-go checkpoint (Month 7.5, 2027-05-27) in the bilateral instrument itself before signature. Define that any single condition slipping beyond its sub-deadline triggers automatic principal-level escalation within 48 hours, with a public written decision to proceed or defer. Lock the USD 50M gate-readiness escrow as a separate bilateral account released only upon simultaneous certification of all seven conditions. Require weekly entry-condition tracking by a bilateral steering committee starting Month 0 (2026-10-12).

### 3.4.D Consequence

Without locked deadlines and escalation procedures, conditions drift past Month 9 (2027-07-12), Phase One never starts on schedule, and sunk-cost burn on preparatory activities (facility hardening, inspector vetting, vendor engagement) accelerates toward the USD 100-200M threshold at which political pressure to cancel or indefinitely defer becomes irresistible. A deferred Phase One dissolves the inspectorate before any empirical testing occurs, failing the primary mission.

### 3.4.E Root Cause

The plan treats entry certification as a selection-time assumption rather than a critical-path gate that must be hardened through locked deadlines, escalation rules and bilateral escrow. No single party can force simultaneous action, so without pre-committed timers and financial triggers, delay becomes the rational default for any party seeking more preparation time or favorable political conditions.

## 3.5.A Issue - Attestation-Anchored Identity Concentrates Trust in Vendor Keys and Firmware; Corroborating Layers Are Weaker Than Assumed

The strategic path anchors equipment identity primarily on vendor-issued cryptographic attestation validated by accredited examiners. If a vendor's keys are compromised, if firmware is forged, or if a vendor refuses key-custody validation, a large share of equipment (estimated 10-40% per site) becomes unverifiable. The plan assumes physical inspection, customs records and maintenance logs provide corroborating layers, but these sources are under the operator's control and can be doctored to match a substituted unit. The corroboration layers are weaker than the plan states, and the plan provides no explicit rule for adjudicating when attestation and physical evidence conflict.

### 3.5.B Tags

- attestation_concentration
- single_source_failure
- weak_corroboration
- evidence_hierarchy_undefined

### 3.5.C Mitigation

Document an explicit evidence-conflict rule: if attestation and physical inspection disagree on identity, the unit goes to referees rather than auto-unverifiable status. Require that at least two independent layers must affirmatively agree (not merely be compatible) for identity confidence to exceed 90%. Pre-test filter adequacy at Month 8.5 (2027-06-27) with at least 10 substitutions where attestation is unaltered but physical marks or serial numbers are forged; measure detection rate with attestation alone stripped. If detection falls below 85%, halt scored exercises and redesign the layering.

### 3.5.D Consequence

If attestation is the decisive layer and it is compromised or unavailable, identity confidence collapses below the 95% threshold and equipment is automatically classified unverifiable. At an estimated 10-40% unverifiable per site, the 3% material threshold is likely exceeded, sites fail Phase One, and the Go verdict is impossible. A government or vendor could trigger this failure by withholding key validation.

### 3.5.E Root Cause

The plan anchors identity on the most scalable but least-controllable source (vendor keys) and treats corroboration as secondary reassurance rather than equal evidence. The plan does not define what happens when corroboration and attestation conflict, creating ambiguity that either government can exploit to argue identity is unverifiable.

## 3.6.A Issue - Challenge-Exercise Partition and False-Positive Cascade Risk Are Underspecified; Misclassification Can Invalidate the Entire Empirical Basis

The plan requires that challenge-exercise events be tagged 'CHALLENGE' before injection and excluded from automatic-suspension triggers. However, the plan provides no rule for detecting misclassification (if an inspector or system flags a CHALLENGE event as operational without recognizing the tag), no timeline for escalation (the 2-hour target in pre-assessment is not in the main plan), and no contingency for false-positive cascade (if three misclassified exercises trigger three auto-suspensions in rapid succession). The plan also does not specify whether unscored calibration exercises (Months 9.5-10.5 = 2027-07-27 to 2027-08-27) are tagged CHALLENGE or whether they could accidentally trigger suspension.

### 3.6.B Tags

- false_positive_cascade
- partition_failure
- misclassification_risk
- exercise_credibility

### 3.6.C Mitigation

Publish mandatory language in the bilateral instrument: 'Every challenge-exercise event must be marked CHALLENGE in the ledger before injection. No CHALLENGE event may trigger suspension, impaired-confidence review, or KPI violation. If a CHALLENGE event is flagged as operational, both co-chairs must be notified within 30 minutes (not 2 hours). Misclassified CHALLENGE events are automatically excluded from suspension logic, and any site suspended on a misclassified event is automatically reinstated within 2 hours pending principal adjudication.' Explicitly partition unscored calibration exercises (Months 9.5-10.5 = 2027-07-27 to 2027-08-27) and scored exercises (Months 10.5-11.5 = 2027-08-27 to 2027-09-27) with separate CHALLENGE sublabels. Define contingency cap: no more than 2 CHALLENGE-event misclassifications per site per Phase One; third misclassification escalates to principals immediately and may trigger verdic

### 3.6.D Consequence

A single misclassified challenge exercise can trigger automatic site suspension (e.g., if an injected substitution is not detected and the system flags it as a real discrepancy, suspension follows in 5 days). If this happens during the scored-exercise window (Months 10.5-11.5 = 2027-08-27 to 2027-09-27), 3-7 days of operational data are lost, the empirical basis for the Go/Modify/Stop verdict is weakened, and the regime's credibility is damaged. Two to three cascade failures in rapid succession could force an early Stop or Modify verdict despite adequate underlying detection performance.

### 3.6.E Root Cause

The plan treats the CHALLENGE tag as a binary partition (tagged = safe, untagged = operational) without mechanisms to detect partition failure or contain false-positive cascade. The plan does not specify who enforces the partition rule or what happens if enforcement is delayed or missed.

---

# 4 Expert: Counterintelligence and Insider-Threat Risk Assessor

**Knowledge**: Espionage targeting of resident inspectors, compartmentation design under persistent adversary, insider-threat red-cell operations, personnel-security vetting standards, clearance reciprocity across national systems, collection-channel risk analysis

**Why**: The plan stations resident mirrored inspectors at each counterpart's site with access to equipment identifiers, maintenance records and facility layouts—all high-value intelligence. The Counterintelligence and Compartmentation Posture lever and the pre-assessment feedback specify CI vetting (polygraph, financial, reciprocal clearance), 6-month tenure limits, compartmentation by site and event type, and an insider-threat red cell. This expert validates whether these controls actually reduce penetration risk to tolerable levels and whether the proposed compartmentation creates operational blindness that prevents detection of a substitution.

**What**: Model the espionage risk to resident inspectors and evidence handlers under the proposed compartmentation, tenure, vetting and red-team testing; identify any leverage point (financial, family, relationship-based) that the present controls do not address; calculate estimated penetration probability and recommend any additional countermeasures.

**Skills**: Insider-threat modeling and red-cell design, personnel-security vetting standards, compartmentation-versus-effectiveness trade-off analysis, espionage targeting pattern analysis, CI polygraph and clearance reciprocity protocols

**Search**: counterintelligence insider threat red team design, compartmented security clearance reciprocity, espionage targeting resident inspectors, personnel vetting polygraph protocols

## 4.1 Primary Actions

- Establish a bilateral entry-condition steering committee by Month 0.5 (2026-10-27) with weekly reporting to both co-chairs, locked deadlines for each of 7 conditions, and a principal go/no-go checkpoint at Month 7.5 (2027-05-27) with documented escalation if any condition misses its deadline.
- Complete a comprehensive vendor-participation census by Month 1 (2026-11-12), classify all vendors by binding status (Tier A/B/C) and equipment count by Month 2 (2026-12-12), and establish bilateral clean-room examination centers with operational readiness by Month 2.5 (2026-12-27), not Month 9 (2027-07-12).
- Lock the Deadlock and Suspension Mechanics in the signed bilateral instrument by Month 7 (2027-05-12) with enumerated automatic-suspension triggers, explicit CHALLENGE-tag partition language, false-positive containment procedures, manufactured-trigger discrimination rules (48-hour denial reason codes), and misclassification escalation timers (2-hour principal escalation, automatic reinstatement).
- Run readiness rehearsals by the proposed dates: staffing dry-run at Month 8 (2027-06-12), filter-adequacy blind pre-test at Month 8.5 (2027-06-27) with >=10 substitutions and halt-if-<85%-detection rule, and misclassification drill by Month 9 (2027-07-12) before scored exercises begin.
- Designate a single Adjudication Unit (>=2 senior arbiters per country, no part-time or temporary staff) by Month 7 (2027-05-12), task it with maintaining the ledger false-positive log and misclassification escalation log, and require monthly KPI reports showing false-positive counts, escalation closure times and audit findings.

## 4.2 Secondary Actions

- Publish a scrubbed readiness dashboard (condition status, vendor census counts, facility security certifications, staffing progress, contingency burn rate) by Month 0.5 (2026-10-27), updated weekly and accessible to both co-chairs as a single source of truth for entry-gate and operational readiness.
- Document a vendor-refusal fallback matrix by Month 2 (2026-12-12): for each vendor tier and equipment criticality, specify the evidence ladder (attestation→customs→inspection→clean-room→unverifiable), expected cycle times, and bilateral sign-off gates; use this to populate the vendor-participation census with a disposition for every supplier.
- Pre-position the USD 50M gate-readiness sub-account from the contingency envelope by Month 0.5 (2026-10-27), with double-key authorization for draws and automatic replenishment from the contingency only if a condition slip forces acceleration or recovery spending; tie every draw to a documented condition slip and bilateral principal decision.
- Commission an independent legal review of domestic access authority and vendor-compulsion mechanisms by Month 0 (2026-10-12), with monthly checkpoint reports to principals on litigation risk, timeline and mitigation; if any jurisdiction signals >4-month litigation risk by Month 2 (2026-12-12), escalate to principals for decision on alternative sites or additional appropriations.
- Establish a CI vetting protocol and insider-threat red cell by Month 1 (2026-11-12), with comprehensive polygraph, financial and foreign-contact review for all 300–500 cleared staff by Month 8 (2027-06-12); maintain compartmentation audit logs and implement quarterly rotation and tenure limits documented in the ledger.
- Conduct a bilateral dispute-simulation exercise by Month 8.5 (2027-06-27): inject a contested equipment identity, an access denial, a ledger divergence and a vendor refusal simultaneously in a non-operational site, run them through the full escalation ladder and deadlock procedures, measure timelines and identify procedural gaps before Phase One.

## 4.3 Follow Up Consultation

Next review should focus on: (1) Entry-condition tracking: confirm the weekly steering committee is established and the Month 7.5 (2027-05-27) principal checkpoint is locked with escalation language in the bilateral instrument draft. (2) Vendor readiness: present the census results (vendor count, Tier A/B/C distribution, unverifiable forecast) and the clean-room examination protocols with bilateral approval dates. (3) Deadlock and false-positive containment: walk through the escalation drill results, confirm CHALLENGE-tag partition is embedded in the instrument, and present the misclassification escalation log from the dress rehearsal. (4) KPI dashboard design: finalize the false-positive reporting format, confidence-rating decay rules, and audit-finding escalation thresholds. (5) Contingency burn: review the gate-readiness sub-account draw plan and confirm that condition-slip costs are tracked separately from operational contingency. Timeline for next review: Month 1 (2026-11-12), after entry-gate steering committee first report and vendor census completion.

## 4.4.A Issue - Entry-Gate Timing and Certification Risk Critically Underestimated

The plan targets Month 9 (2027-07-12) Phase One start with entry conditions certified at Month 9 (2027-07-12), but the canonical facts state a principal go/no-go checkpoint only at Month 7.5 (2027-05-27) with an outer limit of Month 12 (2027-10-12). This creates a 5-month gap between the checkpoint and the proposed clock start, yet the plan provides no recovery path if any condition slips past Month 8 (2027-06-12). Instrument negotiation, domestic access authority and vendor binding typically consume 6–12 months (estimate); a single slip cascades, consuming contingency and political momentum before testing begins.

### 4.4.B Tags

- entry-gate-stall
- critical-path-underestimation
- contingency-burn
- checkpoint-to-start-gap

### 4.4.C Mitigation

Establish a weekly entry-condition tracker by Month 0.5 (2026-10-27), reporting to both co-chairs each Friday. Lock binding signature deadlines: instrument Month 7 (2027-05-12), vendor binding Month 7.5 (2027-05-27), site selection and inspector approval Month 8 (2027-06-12). If any condition misses its deadline, convene principals within 48 hours to choose: defer Phase One start by 2 weeks per slipped condition, activate the USD 50M gate-readiness sub-account to accelerate resolution, or go/no-go. Document every decision in the ledger. Publish a public readiness dashboard (scrubbed of classification) tracking condition status against these hard dates.

### 4.4.D Consequence

Without firm entry-gate deadlines and recovery paths, slippage will accumulate silently until Month 9 (2027-07-12) arrives with incomplete conditions, forcing either a start with half-ready systems (identity, filters, ledger unvalidated) or abrupt cancellation after sunk-cost burn of USD 100–200M (estimate). Either outcome erodes bilateral confidence and invites political blame-shifting.

### 4.4.E Root Cause

The plan assumes entry conditions will be ready by Month 9 (2027-07-12) without specifying intermediate milestones, deadlines or recovery triggers. Instrument negotiation is treated as a black box, and the gap between the Month 7.5 (2027-05-27) checkpoint and Month 9 (2027-07-12) clock start is left unmanaged. This is typical of plans that focus on Phase One execution while treating preconditions as exogenous.

## 4.5.A Issue - Attestation Concentration and Vendor Refusal Create Material Unverifiable-Equipment Risk with Insufficient Fallback

The Equipment Identity Trust Anchor decision anchors identity primarily on vendor-issued cryptographic attestation, validated by accredited examiners. However, no plan specifies: (a) which vendors hold attestation keys, (b) how key custody is verified, (c) attestation failure rates under realistic attack or negligence, or (d) how long examination cycles take. Vendor refusal or key compromise could render 10–40% of equipment unverifiable (estimate), exceeding the 3% threshold for site failure. The clean-room fallback is budgeted at USD 30–50M (estimate) and targeted for Month 9 (2027-07-12), but operational procedures, staffing and bilateral agreement on examination protocols are not locked until Month 12 (2027-10-12). This leaves the refusal ladder untested for 3 months.

### 4.5.B Tags

- attestation-concentration
- vendor-refusal-risk
- unverifiable-threshold-breach
- fallback-untested
- key-custody-opaque

### 4.5.C Mitigation

By Month 1 (2026-11-12), conduct a vendor-participation census at each site: identify all suppliers of covered equipment, classify by equipment count and criticality, flag any vendor representing >2% of declared units. By Month 2 (2026-12-12), lock vendor binding status: Tier A (keys validated and binding signed), Tier B (binding signed, keys pending validation), Tier C (no binding or refusal). By Month 2.5 (2026-12-27), establish operational clean-room examination protocols, staff them with bilateral personnel, and run a dry-run with 10 test units to measure cycle time and evidence quality. Equipment in Tier C at Month 3 (2027-01-12) is automatically flagged as unverifiable unless a bilateral variance allows it. Document every vendor status in the ledger and publish aggregated counts (not identifiers) in the KPI dashboard monthly.

### 4.5.D Consequence

If attestation keys are compromised or vendors refuse cooperation and the clean-room fallback is not operational until Month 10 (2027-08-12) or later, the unverifiable count could exceed 3% by Month 9.5 (2027-07-27), triggering automatic site suspension under the enumerated suspension triggers. This forces either a painful renegotiation during Phase One (consuming 3–7 days and eroding confidence) or acceptance that the site cannot proceed to a Go verdict.

### 4.5.E Root Cause

The plan commits to an attestation-primary identity anchor without pre-validating its resilience or testing the refusal fallback. Vendor binding and clean-room readiness are sequenced too late (Month 9 = 2027-07-12) relative to Phase One start, leaving no time to recover if the fallback is inadequate. This reflects a bias toward front-loading evidence design over operational readiness for failure modes.

## 4.6.A Issue - Deadlock Escalation Timers and Suspension Triggers Create Cascading False-Positive and Manufactured-Incident Risk Without Adequate Containment

The plan defines a 5/8/13-day escalation ladder (Deadlock Mechanics decision) and enumerated automatic-suspension triggers (unverifiable >3%, ledger divergence >5%, access denial >15%, aging >10 days). However, the CHALLENGE-tag partition rule (every injected exercise event tagged before injection, tagged events cannot trigger suspension) creates a single-point-of-failure risk: if an exercise injection is misclassified or a tagger fails, a test scenario becomes an operational trigger, cascading into automatic suspension and forcing a 2-hour principal escalation. No contingency is specified for false-positive recovery (reinstatement time, impact on KPI, reputation damage). Additionally, a determined adversary can manufacture operational triggers (slow down access, delay vendor response, seede a divergence) to force false impaired-confidence reviews, consuming 5–7 days and eroding operational trust.

### 4.6.B Tags

- false-positive-cascade
- suspension-trigger-gaming
- challenge-partition-fragility
- principal-escalation-overload
- manufactured-incident-exposure

### 4.6.C Mitigation

Lock the CHALLENGE-tag rule and false-positive containment in the bilateral instrument by Month 7.5 (2027-05-27) with explicit language: 'Any event tagged CHALLENGE before injection cannot trigger automatic suspension; misclassification escalates to principals within 2 hours; automatic reinstatement pending adjudication; false-positive incidents logged in the KPI dashboard with a 1-point confidence reduction.' By Month 8.5 (2027-06-27), run a misclassification drill where testers deliberately corrupt a CHALLENGE tag and verify that the escalation and reinstatement procedures complete within 2 hours. Define a threshold for false-positive tolerance: if more than 2 false positives occur in any 2-week window, suspend all exercises and convene an adjudication review. For manufactured triggers (vendor delay, access denial), establish a 48-hour escalation timer: if the denial reason code and justification are not provided within 24 hours, automatically escalate to principals; if unresolved within 48 hours, trigger impaired-confidence review (not automatic suspension). Document every escalation, drill and false positive in the ledger.

### 4.6.D Consequence

Without explicit false-positive containment and manufactured-trigger boundaries, a single exercise misclassification or adversarial delay can trigger automatic suspension, forcing reinstatement negotiations that consume operational days and erode bilateral confidence in the regime. Repeated false positives (estimated 2–3 per Phase One if partition is weak) will generate audit findings and a Modify or Stop verdict even if underlying detection and access parity are credible.

### 4.6.E Root Cause

The plan defines suspension triggers and exercise tagging but does not specify how false positives are contained or how manufactured triggers (vendor delay, access denial) are distinguished from credible escalations. This reflects insufficient war-gaming of adversarial scenarios and insufficient distinction between objective triggers and subjective judgment calls that require escalation.

---

# 5 Expert: Supply-Chain Attestation and Vendor Risk Manager

**Knowledge**: Vendor binding mechanisms, supply-chain attestation logistics, clean-room examination protocols, vendor refusal escalation, equipment-traceability systems, manufacturer key-custody standards, customs and shipping verification, vendor risk stratification

**Why**: The plan anchors identity on vendor attestation validated by accredited examiners, yet 10-40% of equipment may become unverifiable if vendors refuse or attestation keys are compromised. The Vendor and Operator Binding Mechanism lever assumes clean-room fallback centers and a three-tier evidence ladder, but lacks concrete operational detail on how refusing vendors are classified, when they escalate to unverifiable, and how supply-chain disruption is managed if critical vendors withdraw. This expert operationalizes the vendor binding and fallback pathways to prevent Phase One stalling on vendor-refusal deadlock.

**What**: Model the vendor-refusal cascade for each equipment category; classify vendors by binding status (signed, unsigned, refusing) and their criticality to site operations; quantify unverifiable risk under each fallback tier (supervised testing, clean room, attestation re-validation) by Month 10 (2027-08-12); specify the principal escalation trigger and decision rule for when a refusing vendor's equipment is declared unverifiable.

**Skills**: Supply-chain risk stratification, vendor qualification and auditing, attestation-key custody verification, customs and logistics coordination, equipment-traceability forensics, clean-room test protocol design, vendor-refusal mitigation triage

**Search**: vendor supply chain risk management, attestation key custody verification, equipment traceability logistics, clean room examination protocols

## 5.1 Primary Actions

- Establish bilateral steering committee by Month 0.5 (2026-10-27) tracking all 7 entry conditions weekly; lock binding instrument-signature deadline Month 7 (2027-05-12) with principal 48-hour escalation on any slip; pre-position USD 50M gate-readiness sub-account (Month 0 = 2026-10-12) accessible only upon simultaneous certification of all conditions by Month 9 (2027-07-12).
- Complete vendor-participation census by Month 1.5 (2026-11-27); operationalize clean-room examination centers (one per country) by Month 2.5 (2026-12-27) with bilateral protocols locked Month 2 (2026-12-12); classify all declared equipment by vendor-binding status by Month 2 (2026-12-12) and auto-escalate refusing/unbound equipment to unverifiable; fund clean-room construction from USD 500M testing envelope.
- Conduct filter-adequacy blind pre-test by Month 0.5 (2026-10-27) with ≥10 injected substitutions; measure detection rate against 85% minimum threshold; halt Phase One entry certification if <85% and renegotiate filters before Month 9 (2027-07-12); document non-redactable evidence schema by Month 1.5 (2026-11-27).
- Embed Deadlock and Suspension Mechanics in the signed bilateral instrument by Month 7 (2027-05-12) with locked 5/8/13-day escalation timers, enumerated objective auto-suspension triggers (unverifiable >3%, divergence >5%, denial variance >15%, discrepancy age >10 days), and explicit CHALLENGE-tag partition excluding injected scenarios from operational triggers.
- Establish bilateral Counterintelligence Unit by Month 0.5 (2026-10-27) (4+ senior CI specialists per country); complete CI vetting of all 350–500 cleared inspectors, technical and support staff by Month 2 (2026-12-12); implement 6-month tenure limits with 2-month breaks between assignments; fund insider-threat red cell (2 per country) from USD 750M security envelope and operationalize by Month 2 (2026-12-12).
- Establish hardened ledger nodes in dedicated SCIF-equivalent facilities by Month 2 (2026-12-12); implement hourly signed hash-chain checkpoints over dedicated IPsec with mutual TLS by Month 2.5 (2026-12-27); establish neutral-party digest escrow by Month 2.5 (2026-12-27) (estimated USD 20–30M from legal/audit envelope); conduct quarterly unannounced facility-security reviews.
- Define Inspection Zone Geometry and Evidence Filtering Design boundaries by Month 1.5 (2026-11-27) through joint operator-inspector meetings; install access-controlled zone markers by Month 2.5 (2026-12-27); establish operator-controlled redaction gateway by Month 2 (2026-12-12) with counterpart rule audit; embed full-time host-country operator liaisons by Month 1 (2026-11-12); publish operator-consent status in KPI dashboard (full/degraded/withdrawn) by Month 2.5 (2026-12-27).
- Establish independent Challenge Exercise Design Panel by Month 1 (2026-11-12) (2 technical experts + 1 CI officer per country); commit blind scenarios to sealed hash-committed catalog by Month 1.5 (2026-11-27); mark all injected CHALLENGE events with mandatory tag and scenario exclusions before injection; design preliminary (unscored) filter-adequacy and presence-detection exercises for Month 0.5 (2026-10-27).
- Lock Verdict Evidence Sufficiency thresholds by Month 2 (2026-12-12) and mark all unvalidated figures (90% detection, 95% identity confidence, 3% unverifiable, 10% parity variance) as provisional or TBD with explicit validation method; calibrate thresholds against preliminary blind exercises (Month 0.5 = 2026-10-27) before freezing.

## 5.2 Secondary Actions

- Conduct staffing dry-run at Month 1 (2026-11-12) validating leave, surge reserve (10% standing, 20–30% surge capacity), tenure limits and cross-site floater coverage; document assumptions about cleared-staff recruitment, bilingual capability and backfill timelines; identify staffing shortfall risk >Month 2 (2026-12-12) and escalate.
- Establish neutral bilateral digest custodian (internationally accredited security audit firm, not government entity) by Month 2 (2026-12-12), funded USD 20–30M from legal/audit envelope; implement escrow of signed ledger-copy digests updated hourly; require joint access and non-repudiation audit trails.
- Define Matched Site Equivalence Basis by Month 0.5 (2026-10-27) (functional matching by verification activity, not compute scale) to support reciprocal-access parity accounting; document site-pairing defensibility for bilateral principals; finalize US locations (Northern Virginia corridor: Loudoun/Prince William) and China locations (Beijing-Hebei or Shanghai) by Month 1 (2026-11-12).
- Design Covered-Equipment Schedule Abstraction Ladder by Month 1 (2026-11-12) to survive hardware generations without manufacturer anchoring; define role-based functional categories and tier-migration review cadence; establish specialist-held split-escrow threshold definitions by Month 2 (2026-12-12) if classification sensitivity justifies sealing.
- Develop Opening Inventory Baseline and Starting-State Seal procedure by Month 1.5 (2026-11-27): decide between full opening census, progressive baseline or thin unverified baseline, trading operator exposure against change-detection credibility; seal opening count jointly within Days 1–5 of Phase One (Months 9–9.25 = 2027-07-12 to 2027-07-27).
- Document Departure Disposition Evidence Ladder by Month 1.5 (2026-11-27): define proof tier for each of 5 exit dispositions (witnessed destruction, verified disablement, transfer, documented release, unresolved); set penalty for vague declarations; require pre-declaration ≥5 days ahead; reserve mirrored-witness capacity for surge periods.
- Establish paired technical referee panels (2 per side) by Month 1 (2026-11-12) for Deadlock and Suspension Mechanics Tier 2 escalation (Days 5–8); document dual-signed advisory fact-statement procedure; train on compartmentation and classified-handling protocols by Month 2.5 (2026-12-27).
- Publish preliminary KPI dashboard template by Month 1 (2026-11-12) covering blind-challenge detection by event type, false negatives/positives, equipment-identity confidence, event-recording latency, ledger divergence and reconciliation time, reciprocal-access parity, unresolved discrepancy age, unverifiable equipment, vendor-refusal outcomes, IP/cybersecurity incidents, production disruption, funding timeliness and audit exceptions; mark all thresholds (estimate) or (proposed threshold); specify validation methods for each.
- Consult with IAEA, OPCW and New START technical experts by Month 0.5 (2026-10-27) on precedent for equipment-identity chains, tamper-evident seals, managed access and mock-challenge exercise design; incorporate lessons learned into intake protocol and exercise procedures.

## 5.3 Follow Up Consultation

Next consultation will address (1) Reciprocal Access Parity Accounting: define the unit of comparison (matched events, detection outcomes or reason-coded access log), establish trip-point thresholds and reconciliation procedures that trigger impaired-confidence review, and test parity measurement across non-identical sites. (2) Ledger Divergence Doctrine: specify checkpoint format, transport authentication, mismatch response and reconciliation timelines; validate that hourly signed checkpoints and neutral escrow prevent tampering and reduce divergence-detection latency to ≤4 hours. (3) False-positive cascade containment and challenge-partition enforcement: rehearse misclassification escalation scenarios (2-hour principal response, automatic reinstatement, audit logging), confirm CHALLENGE-tag marking discipline across all injectors and systems, and validate that exercise events cannot cascade into automatic suspension. (4) Principal-level escalation procedures and decision-making authority: clarify which specific decision thresholds and discrepancies route to principals (e.g., vendor refusal >5 days unresolved, unverifiable >3%, deadlock >13 days, contingency >USD 10M, funding variance >20%), document principal-response timelines and consequences for non-response, and confirm bilateral enforcement mechanisms absent casting vote. (5) Validation roadmap for all provisional thresholds: 90% blind detection, 95% identity confidence, 3% unverifiable, 10% parity variance, 85% filter adequacy, 5-day deadlock, 3% ledger divergence. For each, specify empirical test design, exercise data that will inform calibration, timeline for validation and contingency if actual performance falls short.

## 5.4.A Issue - Entry-gate stall risk dominates Phase One timeline and threatens program viability

The plan correctly identifies entry conditions as mandatory pre-Phase-One gates, yet the project timeline treats them as parallel work. Seven conditions (instrument, appropriations, access authority, site selection, inspector approval, operator/vendor participation, schedule) typically require 6–12 months to align bilaterally. Current outer limit Month 12 (2027-10-12) offers no cushion. If instrument signature slips to Month 10 or 11 (2027-08-12, 2027-09-12), principal go/no-go checkpoint Month 7.5 (2027-05-27) becomes fiction. Sunk costs during gate work (estimated USD 100–200M) are unbudgeted contingency drains. No fallback path exists if a single condition fails.

### 5.4.B Tags

- entry-gate-delay
- critical-path-exposure
- unbudgeted-sunk-cost
- bilateral-alignment-risk

### 5.4.C Mitigation

Immediately establish a bilateral steering committee (by Month 0.5 = 2026-10-27) with weekly condition-tracking dashboard and binding signature deadline Month 7 (2027-05-12), backed by principal-level 48-hour escalation if any slips. Pre-position a USD 50M gate-readiness sub-account (separate from USD 450M free contingency) accessible only upon simultaneous certification of all seven conditions by Month 9 (2027-07-12). Document a fallback path: if instrument signature is delayed past Month 9 (2027-07-12), certify conditions in tranches with matched USD 625M tranche releases, accepting partial commitment risk rather than full program delay.

### 5.4.D Consequence

Without locked entry-gate timelines and escalation, instrument delay cascades to site selection, vendor binding and inspector vetting, compressing Phase One preparation from 3 months to weeks. Staffing becomes chaotic, ledger nodes untested, filters unvalidated and exercises impossible. Program misses the Phase One window or launches operationally unprepared, yielding unreliable Go/Modify/Stop verdict that either government later contests. Political momentum collapses and bilateral cooperation frame erodes.

### 5.4.E Root Cause

Empty

## 5.5.A Issue - Attestation-key concentration and vendor refusal create uncontrolled path to material unverifiable equipment

Identity is anchored on vendor-issued cryptographic attestation, yet key custody, firmware supply chain and vendor willingness to participate are unvetted pre-Phase-One. Refusal-ladder documentation (vendor-supervised testing, clean-room examination, etc.) is design guidance only; clean-room centers do not exist, bilateral examination protocols are unwritten, and accredited independent examiners are unqualified. Estimated 10–40% equipment unverifiable without vendor attestation keys. Plan states unverifiable >3% triggers site failure, yet the path to avoiding 3% is contingent on vendors cooperating with untested fallback mechanisms by Month 10 (2027-08-12). No contingency for attestation forgery or key compromise.

### 5.5.B Tags

- vendor-concentration
- attestation-key-risk
- untested-fallback
- unverifiable-equipment-trajectory

### 5.5.C Mitigation

Complete vendor-participation census by Month 1.5 (2026-11-27): each operator declares ≥95% of supplier list; any vendor >2% of declared equipment refusing participation escalates to principal resolution within 5 days. Operationalize clean-room examination centers (one per country) by Month 2.5 (2026-12-27), funded from USD 500M testing envelope, with bilateral examination protocols locked by Month 2 (2026-12-12). Document three-tier evidence ladder (attestation primary, customs+maintenance secondary, supervised examination tertiary) by Month 1.5 (2026-11-27); require ≥2 independent layers in agreement, no single layer decisive. Classify all declared equipment by vendor-binding status (signed+validated / signed+pending / refusing) by Month 2 (2026-12-12); auto-escalate Tier C (refusing/unbound) equipment to unverifiable status.

### 5.5.D Consequence

Without pre-Phase-One vendor binding and clean-room readiness, vendors will refuse cooperation mid-Phase-One, leaving their equipment unverifiable. Unverifiable counts will exceed 3% threshold during the 90-day window, triggering automatic site suspension. Site failure will force Modify or Stop verdict, and investigating whether suspension was justified will consume 7–10 days, compressing operational time. Political dispute over whether vendor refusal was legitimate or manufactured obstruction will erode bilateral confidence in the regime's impartiality.

### 5.5.E Root Cause

Empty

## 5.6.A Issue - Evidence-filtering design untested until Month 8.5 (2027-06-27) pre-test; filter inadequacy discovered mid-Phase-One is unrecoverable

Operator-controlled redaction gateway (Decision 5) converts raw records and telemetry into schema-limited evidence before release. The plan specifies non-redactable fields (serial number, firmware version, attestation digest, maintenance timestamp, physical identifiers, tamper-seal state) but gives operators discretion to redact cluster membership and power-consumption context. Filter adequacy is untested until the blind pre-test at Month 8.5 (2027-06-27), only 2 weeks before Phase One start (Month 9 = 2027-07-12). If detection rate falls below 85% on pre-test injected substitutions, the plan halts scored exercises and renegotiates filters—but Phase One is already locked by then (entry conditions certified Month 9 = 2027-07-12). Renegotiation compresses into Days 1–5 (opening-inventory seal), yielding no time for re-test. Proceeding with filters known inadequate risks 70–85% detection during scored exercises, failing the Go threshold and forcing Modify.

### 5.6.B Tags

- filter-untested
- inadequate-detection-risk
- compressed-remediation
- evidence-sufficiency-cliff

### 5.6.C Mitigation

Conduct filter-adequacy blind pre-test by Month 0.5 (2026-10-27), 8 weeks before Phase One: inject ≥10 test substitutions (wrong serial, firmware rollback, physical tampering, attestation forgery) into spare-inventory without inspector knowledge; apply proposed redaction rules; measure detection rate (target 9 of 10 = 90%, minimum 85%). If <85%, halt Phase One entry-gate certification and renegotiate filters before Month 9 (2027-07-12). Document minimum evidence schema (non-redactable fields binding) by Month 1.5 (2026-11-27); any filter rule stripping non-redactable fields auto-escalates equipment to unverifiable status. Run supplemental filter edge-case exercises by Month 2 (2026-12-12) where distinguishing fields (firmware version, serial-number suffix, attestation digest) are near redaction boundaries.

### 5.6.D Consequence

If filter-adequacy testing is deferred to Month 8.5 (2027-06-27) and discovers <85% detection, renegotiation must occur during Phase One opening days, leaving no margin for correction. Scored exercises proceed with filters known inadequate, yielding 70–80% detection and missing the Go threshold. Modify verdict triggers, requiring Phase Two negotiation that may never occur if either government views the regime as fundamentally flawed. Alternatively, proceeding without renegotiation yields Go verdict with low-confidence justification, which the counterpart later contests as having known flawed detection.

### 5.6.E Root Cause

Empty

---

# 6 Expert: Filtered Evidence and Redaction-Gateway Architect

**Knowledge**: Data redaction and filtering systems, schema design for evidence retention, information-leakage risk analysis, operator-controlled gateway design, bilateral audit of filtering rules, field-sensitivity classification, evidence adequacy testing, filter-bypass and tampering detection

**Why**: The plan uses operator-run redaction gateways to protect workloads, topology and source code, yet aggressive filtering risks stripping the very fields inspectors need to detect substituted equipment. The gateway architecture, filter rules and audit mechanism are not fully specified. The Inspection Zone Geometry and Evidence Filtering Design lever proposes the host operator runs the gateway while the counterpart audits rules but not inputs. This expert designs the gateway to prove that filtered evidence still carries enough detail to detect substitution, and validates filter adequacy through the Month 8.5 (2027-06-27) blind pre-test before scored exercises begin.

**What**: Design the minimum evidence schema's redaction rules to balance IP protection against detection capability; specify which fields are non-redactable (serial, firmware, attestation, timestamps, seal state) and which can be redacted only by bilateral agreement; architect the bilateral audit mechanism so the counterpart's engineers validate rules without seeing raw telemetry; define the filter-adequacy test: measure detection rates on at least 10 injected substitutions (target 9 of 10 detected, halt if <85%) before Month 10.5 (2027-08-27).

**Skills**: Data-classification and redaction-rule design, gateway architecture and logging, information-leakage forensics, bilateral filter-rule audit protocols, evidence-schema adequacy testing, field-dependency analysis for detection, tampering-resistant logging

**Search**: data redaction gateway architecture, filter adequacy testing, bilateral information sharing architecture, evidence schema design

## 6.1 Primary Actions

- By 2026-10-19 at 09:00, establish a bilateral steering committee with one principal representative per country, holding weekly meetings to track progress on all seven entry conditions (signed instrument, appropriations, access authority, site selection, inspector approval, operator participation, vendor participation, provisional schedule). Document entry-condition status, blockers, and timeline in writing by 2026-10-26 at 17:00.
- By 2026-11-15 at 17:00, complete a fully drafted bilateral instrument (Month 1 = 2026-11-12) containing explicit deadlock escalation language (5/8/13-day timers), enumerated auto-suspension triggers with objective thresholds, CHALLENGE-tag partition rule, false-positive containment procedure (auto-reinstate within 2 hours), and double-key authorization for budget and protocol changes. Lock binding signature deadline at 2026-12-15 at 17:00 (Month 2.5 = 2026-12-27).
- By 2026-12-01 at 17:00 (Month 2 = 2026-12-12), conduct vendor-participation census: each site operator must declare at least 95% of its supplier list by equipment count; any vendor representing >2% of declared equipment refusing participation must be flagged for principal escalation within 5 days. Classify all equipment by vendor-binding status (A: binding signed and keys validated; B: binding signed but keys pending; C: no binding or refused). Escalate all Tier C equipment to unverifiable and demand principal resolution.
- By 2026-11-30 at 17:00 (Month 1.5 = 2026-11-27), jointly define and publish the minimum evidence schema (serial/ID, firmware version, attestation digest, maintenance-event timestamp, physical identifiers with tamper-seal, cluster membership redactable, power state redactable). Explicitly mark non-redactable fields; specify that any field stripping without bilateral agreement automatically escalates equipment to unverifiable status. Require both countries' sensitive-asset experts to co-sign.
- By 2026-10-27 at 12:00 (Month 0.5 = 2026-10-27), run filter-adequacy blind pre-test in staging or spare-inventory areas: inject at least 10 test substitutions (wrong serial, firmware rollback, physical tampering, attestation forgery) without inspector knowledge; apply proposed redaction rules; measure blind-detection rate. Target ≥90%; halt all operator contracts if <85%. Document all filter decisions in the ledger with audit trail.
- By 2026-10-26 at 12:00, pre-position USD 50M escrow account from contingency envelope, accessible only upon simultaneous bilateral certification of all seven entry conditions at a single gate. Establish principal go/no-go decision procedure: any condition will not certify by Month 9 (2027-07-12) → principal decision within 48 hours to defer, accept risk, or stop.
- By 2026-12-20 at 17:00 (Month 2.5 = 2026-12-27), establish at least two bilateral-accredited clean-room examination centers (one US, one China), funded from USD 500M testing envelope, where refusing vendors may submit units for supervised independent testing. Jointly approve examination protocols by 2026-12-01 at 17:00. Define three-tier evidence ladder: (Tier 1) attestation validated by bilateral examiners; (Tier 2) customs + maintenance + physical inspection; (Tier 3) supervised examination or witnessed destruction; require ≥2 tiers in agreement for identity confirmation.

## 6.2 Secondary Actions

- By 2026-12-10 at 17:00 (Month 2 = 2026-12-12), establish dedicated, hardened secure facilities for national ledger nodes (SCIF-equivalent, biometric access, intrusion detection, Faraday-cage key storage). Implement ledger synchronization over dedicated authenticated transport (IPsec + mutual TLS, no shared internet). Conduct bilateral cryptographic key-exchange ceremony by 2026-11-30 at 17:00; establish signed hash-chain checkpoints hourly with bilateral timestamp and nonce.
- By 2026-11-01 at 09:00, establish bilateral Counterintelligence Unit (4 senior CI specialists per country minimum, funded from USD 750M security envelope) to design personnel security, compartmentation rules and insider-threat red-team operations. Publish unit charter and staffing by 2026-11-15 at 17:00. Implement CI vetting by 2026-12-01 at 17:00: background investigation, financial vetting, polygraph, reciprocal clearance for all inspectors; reject candidates with unexplained foreign contacts within 48 hours of polygraph.
- By 2026-12-15 at 17:00 (Month 2.5 = 2026-12-27), implement tenure limits and rotation policy: no inspector >6 consecutive months at same site; 2-month break between reassignments; no counterpart reassignment >once per 18 months. Compartment inspectors by site and event type; maintain access-scope audit logs; investigate any cross-compartment discovery within 2 hours. Fund bilateral Insider-Threat Red Team (2 per country) by 2026-11-15 at 17:00 to attempt compromise of inspectors through social engineering; document all activities in ledger; escalate credible attempts to principals within 4 hours.
- By 2026-11-30 at 17:00 (Month 1.5 = 2026-11-27), define Inspection Zone Geometry boundaries (staging, spare-inventory, maintenance, expansion only; production and model-weight areas off-limits). Paint and mark all zone boundaries; install electronic access controls (biometric card readers); audit every inspector entry/exit by name, date, time and purpose. Establish operator-controlled redaction gateway (host-side personnel only; counterpart audits rules, not inputs); log every filter decision in ledger with reason code. Require bilateral agreement on all redaction rules by 2026-11-30 at 17:00.
- By 2026-12-01 at 17:00 (Month 2 = 2026-12-12), define Ledger Divergence Doctrine: materiality >5 events disputed per site per week; divergence age >4 hours triggers notification to co-chairs and referees; >5% of events disputed triggers impaired-confidence review by 2027-01-01 at 17:00 (Month 3 = 2027-01-12); >10 days unresolved escalates to principals with potential site suspension. Establish neutral-party digest escrow (trusted custodian holds signed digests of both ledger copies, updated hourly; costs USD 15–20M from legal/audit envelope). Enable post-hoc forensic analysis of ledger divergence.
- By 2026-11-15 at 17:00 (Month 1 = 2026-11-12), establish independent Challenge Exercise Design Panel (2 technical experts + 1 CI officer per country; funded from USD 500M testing envelope) to design blind scenarios for 7 event types (unreported arrival, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal, reluctant operator). Pre-commit scenario catalog to sealed hash digest by 2026-11-30 at 17:00; publish challenge-exercise schedule (not scenarios) by 2026-12-01 at 17:00.
- By 2026-12-15 at 17:00 (Month 2.5 = 2026-12-27), embed operator liaisons in inspectorate: at least one full-time host-country liaison per site embedded in inspection team; liaison attends all field work, monitors zone-boundary compliance, audits evidence handling, alerts immediately to violations. Liaison reports to operator and both co-chairs. Maintain liaison-alert log in tamper-evident ledger. Publish quarterly Operator Consent Status metric in KPI dashboard: full/degraded/withdrawn; if degraded or withdrawn, escalate to principals within 24 hours.
- By 2026-12-01 at 17:00 (Month 2 = 2026-12-12), establish standing Deadlock-Resolution Procedure: Technical Referee Panel (2 per side, pre-cleared, funded from personnel envelope) issues dual-signed advisory fact statement within 3 days of Days 5–8 escalation window. Define unresolved-discrepancy aging: flagged daily in KPI dashboard; >10 days automatic impaired-confidence review; >15 days automatic site suspension pending principal decision.
- By 2026-06-27 at 17:00 (Month 0.5 = 2026-10-27 for future reference: 2026-10-27), run filter-adequacy blind pre-test and presence-detection exercises before any scored challenge exercises begin. Verify that ≥85% detection rate is achievable under proposed filtering; validate that continuous residence or response-window deployment can detect unreported arrivals. Document any gap; halt scored exercises if threshold not met.
- By 2027-05-12 at 17:00 (Month 7 = 2027-05-12), conduct staffing dry-run to validate leave, surge capacity and tenure assumptions: model 24/7 shift coverage for 4 sites with no single-person critical functions, 15% leave buffer, 10% surge reserve, and no personnel assigned >6 consecutive months without 2-month break. Identify shortfalls; request supplementary staffing authorization if needed before Month 9 (2027-07-12) phase-one start.
- Consult with IAEA (managed access, seals, unique identifiers), OPCW (mock challenges, on-site inspection), New START (equipment registration, notification protocols) to extract reusable verification methods and lessons learned. Document expert exchanges and incorporate precedent-practice into design by 2026-11-30 at 17:00. Brief co-chairs on transferable insights by 2026-12-01 at 17:00.

## 6.3 Follow Up Consultation

Next meeting should confirm: (1) bilateral steering committee standing authority and weekly reporting cadence; (2) instrument draft completion schedule and bilateral legal working group staffing; (3) vendor census results by 2026-11-15 and classification of Tier C unverifiable equipment; (4) filter-adequacy pre-test plan (venue, injected scenarios, detection-rate measurement method); (5) clean-room center site selection, security design, and examination-protocol bilateral approval timeline; (6) ledger infrastructure hardening and cryptographic key-ceremony schedule; (7) principal go/no-go decision procedure and escalation triggers if any entry condition will slip past Month 9 (2027-07-12). Discuss fallback options if entry certification stalls (defer Phase One, subset of sites, supplementary appropriation) and how sunk-cost risk is contained. Confirm that strategic decisions on identity anchor, inspector presence, deadlock mechanics, exercises, and filtering are locked in the bilateral instrument before any site selection or operator contracts are signed.

## 6.4.A Issue - Entry-Gate Stall Risk Dominates All Other Planning

The pre-project assessment correctly identifies entry-gate work as the true critical path—seven mandatory conditions must be certified simultaneously before the 90-day clock starts at Month 9 (2027-07-12). Yet the project plan treats entry certification as a single gate event at Month 9 (2027-07-12), with no intermediate milestones, no escalation triggers before Month 7.5 (2027-05-27), and no contingency escape route if any single condition slips. Current setup guarantees sunk cost of USD 100–200M if instrument negotiation alone extends past Month 8 (2027-06-12). The plan has no documented principal go/no-go decision at Month 7.5 (2027-05-27) with binding authority to halt if any condition will miss Month 9 (2027-07-12).

### 6.4.B Tags

- entry-gate-stall-risk
- critical-path-management
- principal-escalation-gap
- contingency-escape-missing

### 6.4.C Mitigation

Immediately establish a bilateral steering committee by 2026-10-19 tracking all seven entry conditions weekly, with binding instrument-signature deadline locked at Month 7 (2027-05-12) and a hard principal go/no-go decision at Month 7.5 (2027-05-27). If any condition will not certify by Month 9 (2027-07-12), principals must decide: defer Phase One by 2–4 months (absorbing cost), proceed without that condition (accepting risk), or stop. Pre-position USD 50M from contingency into an escrow account by 2026-10-26, accessible only upon simultaneous certification of all seven conditions, to fund entry-gate costs and prevent sunk-cost accumulation if gate fails. Document escalation procedure in writing: any condition 30 days behind schedule triggers automatic principal notification and a decision within 48 hours.

### 6.4.D Consequence

Without intermediate milestones and a hard Month 7.5 (2027-05-27) go/no-go, the program will drift into late-October Phase One start or abandoned entry gate, consuming USD 100–200M with no operational test. Principals will lack documented decision moments to stop or defer. Momentum erodes as preparation funding burns without clear next steps.

### 6.4.E Root Cause

The strategic decisions document discusses entry certification as a single gate but does not specify how the eight-condition tracking, escalation timers, or principal decision authority will be organized. The project plan lists entry conditions as dependencies but lacks intermediate milestones or escape procedures. Planning assumes all conditions will certify together without contingency for individual condition slippage.

## 6.5.A Issue - Filter-Adequacy Testing Scheduled Too Late; Identity Confidence Unvalidated Before Scored Exercises

The plan schedules filter-adequacy blind pre-test at Month 8.5 (2027-06-27)—only six weeks before scored exercises start at Month 10.5 (2027-08-27). If the pre-test detects <85% substitution-detection rate under proposed redaction rules, there is no time to renegotiate filters, retest, or redesign the evidence schema before the Phase One clock starts Month 9 (2027-07-12). Current threshold of >95% identity confidence per unit is provisional and untested. If redaction rules strip the very fields needed to detect substitution (firmware version, serial-number suffix, attestation digest), this will be discovered after entry gates are locked and operator contracts are signed.

### 6.5.B Tags

- filter-adequacy-untested
- identity-confidence-unvalidated
- late-discovery-risk
- operator-contract-binding

### 6.5.C Mitigation

Move filter-adequacy blind pre-test to Month 6.5 (2027-04-27), immediately after site selection and staged staging-area setup. Inject at least 10 test substitutions (wrong serial, firmware rollback, physical-mark tampering, attestation forgery) into spare-inventory or maintenance zones without inspector knowledge; apply proposed redaction-gateway rules; measure whether redacted evidence still permits intake inspectors (working blind) to detect 9 of 10 substitutions (90% target). If detection rate falls below 85%, halt all operator-contract signature until filters are renegotiated and pre-test passes. Document filter-decision audit trail in the tamper-evident ledger before any operational equipment is processed. Require bilateral sign-off on the minimum evidence schema (serial, firmware, attestation digest, maintenance timestamp, physical identifiers, cluster membership, power state) by Month 6 (2027-04-12), explicitly marking which fields are non-redactable and what happens if a field is stripped.

### 6.5.D Consequence

If filters are discovered post-Phase-One-start to be inadequate for substitution detection, identity confidence will drop below the 95% threshold, material equipment will be classified unverifiable, and a Go verdict becomes impossible. Operators will have already committed; renegotiating filters triggers heightened-inspection status, delays Phase One completion by weeks, and erodes political credibility. The regime's core detection capability—identity layering—is unproven.

### 6.5.E Root Cause

The Inspection Zone Geometry and Evidence Filtering Design decision assumes redaction adequacy without empirical validation. Pre-test timing at Month 8.5 (2027-06-27) is too late to discover and fix filter flaws before entry gates lock and operators sign contracts. The minimum evidence schema is sketched but not published with explicit non-redactable markings.

## 6.6.A Issue - Deadlock and Suspension Procedures Lack Binding Language and False-Positive Containment

The strategic decisions specify 5/8/13-day escalation timers and enumerated auto-suspension triggers (unverifiable >3%, divergence >5%, access denial >15%, discrepancy age >10 days), yet the bilateral instrument is not drafted with this language locked in. If the instrument is signed without explicit CHALLENGE-tag partition and false-positive cascade procedures, a single misclassified test scenario during exercises can trigger automatic suspension, destroy 3–7 days of operational work, and force a 5-day principal escalation with zero containment. The plan states that challenge-exercise events will be marked 'CHALLENGE' in the ledger but does not bind this to the bilateral instrument or define what happens if the partition is violated.

### 6.6.B Tags

- deadlock-procedure-unsigned
- challenge-tag-partition-unbound
- false-positive-cascade-risk
- instrument-language-missing

### 6.6.C Mitigation

Before any site is selected or operator contract is signed (by Month 7, 2027-05-12), complete a fully drafted bilateral instrument that explicitly includes mandatory deadlock language: 'Deadlock = no consensus within 5 calendar days. Auto-escalates to Technical Referee Panel (Days 5–8) with no discretion to defer. Referees issue dual-signed fact statement within 3 days, or escalates unresolved to Principal Review (Days 8–13). Principals must decide within 5 days or status quo defaults to heightened inspection pending escalation.' Define enumerated automatic-suspension triggers with objective thresholds in the same instrument: unverifiable >3% for 5 consecutive days; ledger divergence >5% of events disputed; access denial >15% variance for 2 weeks; unresolved discrepancy >10 days. Explicitly partition challenge-exercise events: 'Every injected scenario must be marked CHALLENGE in the ledger before injection; CHALLENGE-tagged events cannot trigger suspension or impaired-confidence review without principal-level adjudication; misclassification (treating CHALLENGE as operational) escalates to principals within 2 hours with automatic site reinstatement pending review.' Establish bilateral red-team contingency procedure: if a test scenario is misclassified and incorrectly triggers suspension, auto-reinstate site operations within 2 hours and document as an audit finding (1-point confidence reduction proposed).

### 6.6.D Consequence

Without binding language in the instrument, either government can redefine deadlock or suspension procedures unilaterally or contest them post-hoc. A single false-positive automatic-suspension trigger can halt the test and consume escalation capacity, leaving real discrepancies unresolved. The regime loses governance credibility if procedures are changed mid-test or if challenge-exercise events are later disputed as having triggered suspension improperly.

### 6.6.E Root Cause

Strategic decisions are documented as requirements but not yet drafted into binding bilateral-instrument language. The project plan references the need for fixed timers and suspension triggers but does not specify who drafts the instrument, when it must be done, or how to ensure both governments sign language that constrains their own future actions. False-positive cascade containment is identified as a design principle but not yet operationalized.

---

# 7 Expert: Bilateral Legal and Instrument Implementation Counsel

**Knowledge**: Bilateral treaty drafting and ratification, domestic-access-authority enactment, vendor-compelling mechanisms and private-law implications, export-control and classification harmonization, double-key authorization language, deadlock and escalation clauses, dispute-resolution mechanics, confidentiality and compartmentation covenants, personnel-clearance reciprocity agreements

**Why**: The plan requires a signed bilateral instrument and domestic legal authority in both countries by Month 7 (2027-05-12), but the actual instrument language, domestic-authority scope and legal mechanisms are not drafted. The pre-assessment feedback identifies entry-gate stall and legal litigation as high-probability risks (delay 2-4 months, USD 50-100M estimate). This expert drafts the instrument's core provisions (deadlock timers, suspension triggers, double-key authorization, CHALLENGE-tag partition) and ensures both countries can legally compel vendors and operators without violating export-control or state-enterprise constraints.

**What**: Draft binding language for the bilateral instrument covering: deadlock escalation (5/8/13-day tiers with referee and principal review), enumerated automatic-suspension triggers (unverifiable >3%, divergence >5%, age >15 days), CHALLENGE-tag partition excluding test events from suspension, double-key authorization for budgets and site findings, and clear wording that success covers only monitored changes at declared sites; validate that each country's domestic law permits compelling vendors and operators to participate without exemption for state enterprises or national-security contractors.

**Skills**: Bilateral treaty drafting and ratification, domestic legal authority enactment, vendor-compelling jurisdiction and private-law harmonization, export-control harmonization, double-key governance mechanics, dispute-resolution and escalation clause design, confidentiality and state-secret compartmentation covenants, personnel-clearance reciprocity and classified-information handling agreements

**Search**: bilateral treaty drafting arms control, domestic access authority legal implementation, vendor compelling mechanisms, export control harmonization

## 7.1 Primary Actions

- Establish a bilateral legal steering committee by Month 0.5 (2026-10-27) with weekly instrument-draft review, bind principal-level go/no-go checkpoint at Month 6.5 (2027-04-27), and lock a realistic instrument-closure date of Month 7 (2027-05-12) with documented contingency tracks for scope reduction or phased access authority if full instrument negotiation delays.
- Complete vendor-participation census by Month 1.5 (2026-11-27): every operator declares suppliers representing ≥95% of declared equipment; classify each vendor as binding-signed (A), binding-pending (B), or refusing/no-contact (C); escalate all Tier C equipment to unverifiable status within 5 days; fund three-layer fallback evidence ladder (attestation + customs + physical; customs + maintenance + physical; independent examination) by Month 2.5 (2026-12-27).
- Operationalize CHALLENGE-tag partition with dual-key cryptographic commitments by Month 7 (2027-05-12): every injected scenario signed by both countries' exercise panel, validated by all suspension-trigger rules before exemption applies, misclassified events escalate to co-chairs within 2 hours; conduct misclassification drill at Month 8.75 (2027-07-05) and require <5% false-positive rate before scored exercises begin.
- Demote attestation from primary to required-but-not-decisive identity layer by Month 7 (2027-05-12): require ≥3 independent layers (attestation, customs+maintenance, physical) to agree within ±2 hours; establish vendor key-escrow program (shared half-keys) for critical vendors (>5% equipment) by Month 3 (2027-01-12); conduct attestation dry-runs at all sites Month 8 (2027-06-12) and measure vendor participation; if participation <90%, trigger clean-room examination fallback.
- Publish a detailed CHALLENGE-event exclusion rule in the bilateral instrument by Month 7 (2027-05-12) stating: 'No event marked CHALLENGE in the sealed ledger may trigger suspension, impaired-confidence review or KPI violation. Misclassification requires principal-level adjudication and automatic site reinstatement pending decision. All false-positive incidents are recorded as audit findings and subject to follow-up validation.'
- Lock deadlock escalation timers and enumerated auto-suspension triggers in the signed bilateral instrument by Month 7 (2027-05-12) with explicit language: 5-day deadlock → referee panel → 3-day fact statement → principal review within 5 days; status-quo heightened inspection if unresolved; >10-day aging → automatic site suspension absent written principal decision; document that suspension is reversible only with double-key authorization and documented corrective action.

## 7.2 Secondary Actions

- Schedule a comprehensive staffing dry-run at Month 8 (2027-06-12) covering 24/7 shift rotation, leave coverage, surge-capacity deployment and cross-site floater utilization for all 4 sites; validate that no single-person critical functions exist and document shortfall remediation before Phase One clock start.
- Conduct filter-adequacy blind pre-test at Month 8.5 (2027-06-27) with ≥10 injected substitutions (wrong serial, firmware rollback, physical tampering, attestation forgery) in staging and spare-inventory areas; require ≥9-of-10 detection (90% threshold) before scored exercises begin; if detection <85%, halt scored exercises and renegotiate filters with operators.
- Establish bilateral Counterintelligence Unit by Month 1 (2026-11-12) with ≥4 senior CI specialists per country; fund insider-threat red-team operations by Month 2 (2026-12-12) targeting inspectors and evidence handlers; require 6-month site-tenure limits with 2-month breaks and strict compartmentation (no cross-site knowledge) in writing by Month 3 (2027-01-12).
- Complete vendor-binding certification by Month 8 (2027-06-12): document which vendors have signed verification terms, validated cryptographic keys, or are escalated to clean-room examination; publish unverifiable-equipment count per vendor per site by Month 8.5 (2027-06-27) and escalate any site exceeding 3% threshold to principal-level review.
- Establish ≥2 bilateral-accredited clean-room examination centers (one US, one China) by Month 9 (2027-07-12), funded from the USD 500M testing envelope; develop joint examination protocols by Month 8 (2027-06-12) and validate that protocols preserve vendor confidentiality while producing credible identity evidence.
- Pre-position USD 50M gate-readiness sub-account by Month 1 (2026-11-12) (USD 25M per country) accessible only upon joint entry-condition certification; document funding-drawdown triggers for entry-gate work and prevent sunk-cost burn if any single condition slips past Month 12 (2027-10-12).
- Publish a detailed minimum evidence schema by Month 6 (2027-04-12) specifying non-redactable fields (serial, firmware hash, attestation, maintenance timestamp, physical markers) and conditions under which redaction escalates equipment to unverifiable status; require bilateral agreement on all redaction rules by Month 7 (2027-05-12) before any equipment enters intake.
- Define a formal false-positive containment procedure by Month 7 (2027-05-12): if a CHALLENGE event is misclassified as operational and triggers suspension, co-chairs must escalate to principals within 2 hours; automatic site reinstatement pending decision; every false positive records as an audit finding and reduces site confidence rating by 1 point; >3 false positives at any site during Phase One = impaired-confidence review.

## 7.3 Follow Up Consultation

Next consultation focus: (1) Validate that the bilateral legal steering committee is established and instrument negotiation is on track for Month 6.5 (2027-04-27) checkpoint; (2) Review vendor-classification results and confirm fallback evidence layers are funded and documented; (3) Confirm CHALLENGE-tag cryptographic-commitment protocol is drafted and ready for bilateral instrument; (4) Confirm clean-room centers have operational protocols approved and examination capacity is funded. Review risk register monthly: entry-gate slip, vendor refusal escalation, attestation-key compromise, and false-positive cascade remain the top four failure pathways. Escalate any slippage >2 weeks on instrument, vendor binding or CI vetting to principals immediately.

## 7.4.A Issue - Entry-gate timeline is unachievable and will stall Phase One before operations begin

The plan locks instrument signature at Month -2 (2026-12-15), but bilateral treaty negotiation typically requires 6–12 months (benchmarked from New START, Open Skies). Domestic legal authority enactment, site selection and vendor binding cannot be certified simultaneously at Month 9 (2027-07-12) if instrument signature slips past 2026-12-15. Current plan treats entry conditions as rigid gates, yet provides no contingency for the critical-path item (instrument) or staged gate procedure. Risk: Phase One clock is frozen indefinitely, appropriations accumulate sunk cost, and political momentum evaporates.

### 7.4.B Tags

- entry_gate_schedule_optimism
- bilateral_instrument_critical_path
- contingency_planning_absent

### 7.4.C Mitigation

Establish a bilateral legal steering committee by Month 0.5 (2026-10-27) with weekly instrument-draft exchange and escalation to principals if any negotiating point stalls >2 weeks. Lock a non-negotiable 'must-close-by' date at Month 6 (2027-04-12), not Month -2, and fund contingent parallel legal tracks (e.g., narrower instrument scope, phased access authority) by Month 2 (2026-12-12). Accept staged entry certification: instrument and appropriations by Month 6 (2027-04-12), sites and vendors by Month 8 (2027-06-12), single final gate at Month 9 (2027-07-12). Pre-position USD 50M gate-readiness account to absorb entry delays without sunk-cost burn.

### 7.4.D Consequence

Without timeline realism and staged gates, the entire program stalls before operational testing begins. Appropriated funds accumulate without disbursement, political backing erodes, and the 90-day clock is never started. Phase One verdict is indefinitely delayed, rendering the USD 5B investment and bilateral commitment unachievable within the assumed timeframe.

### 7.4.E Root Cause

Empty

## 7.5.A Issue - Attestation-primary identity anchor concentrates trust in vendor keys and creates 10–40% unverifiable-equipment exposure

The chosen 'Pioneer's Gambit' strategy anchors equipment identity primarily on vendor-issued cryptographic attestation, with physical inspection as a secondary corroborating layer. This is operationally attractive (scales across many units) but creates two failure modes: (1) firmware compromise or key exposure at a single vendor wipes identity for all that vendor's equipment; (2) vendor refusal to validate keys or participate escalates equipment to unverifiable status. Plan estimates 10–40% unverifiable equipment per site under this anchor. The pre-test at Month 8.5 (2027-06-27) may catch filter-adequacy failures, but cannot validate attestation integrity or vendor cooperation assumptions before scoring exercises begin.

### 7.5.B Tags

- attestation_concentration_risk
- vendor_key_custody_unverified
- unverifiable_equipment_tolerance_exceeded

### 7.5.C Mitigation

Demote attestation to a required-but-not-decisive layer by Month 7 (2027-05-12): require at least three independent layers (attestation, customs + maintenance logs, physical inspection) to agree within ±2 hours before intake confidence reaches 95%. Establish a vendor-classification task force by Month 1 (2026-11-12) to segregate critical vendors (>5% of site equipment) from replaceable vendors; offer critical vendors either bilateral key-escrow (shared custody with both governments holding one half-key) or third-party certification (independent accredited lab validates keys quarterly). Conduct attestation dry-runs at all sites by Month 8 (2027-06-12) to measure actual vendor participation rates and key-validation latency; if participation <90% or latency >4 hours, trigger clean-room examination fallback. Document a fallback evidence ladder: Tier 1 = three-layer agreement; Tier 2 = customs + maintenance + physical (no attestation); Tier 3 = independent examination or witnessed destruction.

### 7.5.D Consequence

If attestation keys are compromised or vendors refuse validation, 10–40% of equipment becomes unverifiable without fallback evidence, failing the site outright under the ≤3% unverifiable threshold. Phase One collapses for that site; if unverifiable equipment appears at >1 site, automatic suspension and Stop verdict. Credibility of the entire Go decision is undermined because identity confidence cannot be established.

### 7.5.E Root Cause

Empty

## 7.6.A Issue - Challenge-exercise partition and false-positive cascade containment are underspecified; misclassification risk is not quantified or tested before Month 10 (2027-08-12)

The plan requires all injected scenarios to be tagged 'CHALLENGE' before insertion and excluded from automatic-suspension triggers, but does not specify how the tagging is enforced, who verifies compliance, or what happens if a CHALLENGE event is misclassified as operational. The consequence is severe: one undetected misclassification could trigger automatic suspension (e.g., unverifiable >3% threshold tripped by a planted substitution), consuming 3–7 days of operational work and eroding regime credibility. The pre-test at Month 8.5 (2027-06-27) tests filter adequacy but not CHALLENGE-partition enforcement. No false-positive cascade drill is scheduled, and no quantified limit on acceptable false positives (proposed threshold: TBD) is set.

### 7.6.B Tags

- challenge_event_partition_enforcement_weak
- false_positive_cascade_risk_unquantified
- misclassification_escalation_timing_untested

### 7.6.C Mitigation

By Month 7 (2027-05-12), operationalize CHALLENGE tagging with cryptographic commitments: every injected scenario is assigned a UUID, signed with a dual-key by both countries' exercise-design panel, and published in a sealed ledger entry 1 hour before injection. Each inspection system and suspension-trigger rule must validate the dual signature before applying the CHALLENGE exemption; any CHALLENGE tag without valid dual signature or present in the sealed ledger >1 hour before injection triggers immediate escalation to co-chairs. Schedule a misclassification drill at Month 8.75 (2027-07-05): inject 5 known-false challenges in staging areas, measure detection and misdeclaration rates, and require <5% false positives (proposed threshold) before scored exercises begin. Log every false-positive incident in the KPI dashboard with 1-point confidence penalty per site; >3 false positives at any site during Phase One escalates to impaired-confidence review.

### 7.6.D Consequence

Without strong partition enforcement and pre-tested escalation, a single misclassified CHALLENGE event triggers automatic suspension, consuming 3–7 operational days and requiring principal-level adjudication to reinstate. Multiple misclassifications cascade into impaired-confidence status and undermine the empirical basis for the Go verdict. Regime credibility is damaged; sites may be permanently suspended, and Phase One conclusion is contested.

### 7.6.E Root Cause

Empty

---

# 8 Expert: Independent Auditor and Evidence Sufficiency Validator

**Knowledge**: Fiscal accountability and tranche-release audit, evidence-threshold validation and threshold-calibration methodology, detection-rate estimation and calibration against blind exercises, provisional-versus-validated-figure tracking, audit-trail design for Go/Modify/Stop verdict defense, forensic ledger analysis, discrepancy reconstruction and root-cause analysis, fiscal timeliness and contingency-draw monitoring, independent scoresheet design and scoring divergence analysis

**Why**: The plan's Go/Modify/Stop verdict depends on evidence thresholds (90% blind detection, >95% identity confidence, <=3% unverifiable, <=10% parity variance, synchronization <=1 hour) that are all marked provisional with no documented validation method as of Month 9 (2027-07-12). The Verdict Evidence Sufficiency and Threshold Calibration lever requires pre-registered thresholds, but calibration against blind exercises creates a conflict: lock thresholds before data exists, or validate them during the test risking post-hoc goalpost movement. This expert designs the threshold-validation methodology, scoresheet design and the audit trail that proves the Go/Modify/Stop verdict is evidence-based, not political.

**What**: Define the threshold-validation protocol: identify which figures (e.g., 90% detection rate, 1-hour sync) require empirical grounding from the Month 8.5 (2027-06-27) pre-test and which can be pre-registered based on precedent; design sealed scoresheets for blind exercises so each country scores independently, then compare for divergence; specify the rule: if scoring divergence >5%, escalate to technical referees before verdict; document every threshold change or provisional-to-validated transition in the ledger; audit contingency draws, tranche timeliness and cumulative-disbursement parity against the +/-10% and 20% divergence thresholds.

**Skills**: Fiscal audit and tranche-release controls, evidence-threshold calibration and validation methodology, blind-exercise design and independent scoring, detection-rate estimation and confidence intervals, provisional-figure labeling and validation tracking, forensic ledger analysis and divergence root-cause investigation, scoring-divergence analysis and reconciliation, audit-trail design for political defensibility

**Search**: independent auditor threshold validation, evidence sufficiency methodology, blind exercise scoring protocol, fiscal accountability audit framework

## 8.1 Primary Actions

- Lock the Phase One clock-start gate at Month 9 (2027-07-12) 17:00 UTC in the bilateral instrument. Specify that any uncertified entry condition triggers automatic 48-hour principal escalation with a binary decision: proceed with available conditions or cancel Phase One. Publish the decision by 17:00 UTC the same day. Freeze the 90-day window to Months 9–12 (2027-07-12 to 2027-10-12) with no extension without principal double-key reauthorization.
- Complete vendor binding and attestation-key validation by Month 7 (2027-05-12), not Month 8 (2027-06-12). Run a vendor census by Month 6 (2027-04-12), validate cryptographic keys for all critical vendors by Month 6.5 (2027-04-27), and calibrate the 3% unverifiable threshold against validated baseline data. Escalate vendors representing >5% of equipment and unable to validate attestation to principals by Month 7 (2027-05-12) for decision on threshold adjustment or alternate binding.
- Define and publish the Challenge-Exercise Misclassification Protocol by Month 8 (2027-06-12), specifying: automated CHALLENGE-tag detection in the ledger, real-time dual duty-officer alert and 30-minute joint decision, principal escalation within 1 hour (not 2 hours), site reinstatement with MISCLASSIFICATION_RESOLUTION ledger entry, and mandatory 1-hour inspector training. Conduct a full misclassification drill at Month 8.75 (2027-07-05) measuring flag-to-notification latency.
- Establish a bilateral Incident Command Center (ICC) operational by Month 7 (2027-05-12) with a duty-officer roster covering all time zones. ICC is responsible for: real-time anomaly alerts (including CHALLENGE misclassifications), escalation routing to principals, 2-hour misclassification escalation response time, and reinstatement decision recording in the ledger. ICC is jointly staffed with at least one senior officer per country, on-call 24/7.
- Pre-position clean-room examination centers by Month 6.5 (2027-04-27) for any vendors unable to validate cryptographic attestation. Test at least 10 units per non-binding vendor in Month 7 (2027-05-12) to establish fallback detection capability under supervised examination. Document results in the ledger with vendor-binding status per equipment tier.

## 8.2 Secondary Actions

- Conduct a staffing dry-run at Month 8 (2027-06-12) stress-testing leave, surge and tenure assumptions, with particular attention to duty-officer rotation and ICC availability across time-zone boundaries; document any shortfalls and activate contingency staffing plan.
- Run the filter-adequacy blind pre-test at Month 8.5 (2027-06-27) with at least 15 substitution scenarios (increased from 10) including edge cases near redaction boundaries; target >90% detection (increased from 85%) to validate that operator-run redaction gateways retain sufficient evidence for identity confirmation.
- Conduct a bilateral legal and domestic-authority validation by Month 7 (2027-05-12) confirming that compulsion authority over private vendors is enforceable in each country; if litigation or statutory amendment is required, escalate to principals with a 2–4 month (estimate) delay estimate and revised entry-gate timeline.
- Establish a Threshold Calibration Review Panel by Month 7 (2027-05-12) tasked to validate all provisional thresholds (95% identity confidence, 3% unverifiable, 90% detection, 10% parity variance, 1-hour ledger sync) against early baseline data collected during Months 6–8 (2027-04-12 to 2027-06-12). Panel must publish a calibration report by Month 8.75 (2027-07-05) with any recommended adjustments and supporting evidence, locked before scored exercises begin.
- Design and publish exit-disposition rules by Month 7 (2027-05-12) specifying evidence requirements for each of the 5 Exit Protocol dispositions (witnessed destruction, permanent disablement, transfer, documented release, unresolved), including witness counts, sampling procedures, pre-declaration requirements and the exact wording that marks the boundary of Consortium knowledge.

## 8.3 Follow Up Consultation

At the next consultation (Month 6, 2027-04-12), review vendor-binding status and attestation-key validation results; confirm clean-room centers are operationally ready; validate legal compulsion authority for private vendors; and review the Threshold Calibration Panel's preliminary findings. Discuss any vendors still unable to bind and escalation options (refusal ladder, unverifiable classification). Confirm ICC staffing roster and duty-officer training schedule. Review any changes to site locations or operator participation that affect the Phase One setup. Lock the Challenge-Exercise Misclassification Protocol and confirm the Month 8.75 (2027-07-05) misclassification drill schedule.

## 8.4.A Issue - Entry-Gate Timing Is Dangerously Ambiguous and Threatens Phase One Clock Validity

The pre-project assessment correctly flagged entry-gate stall as a high-probability failure pathway (6–12 months typical, estimate), yet the project plan provides no binding escalation rule tied to certification delay. The principal go/no-go at Month 7.5 (2027-05-27) is noted but lacks teeth: no automatic resource hold, no tranche freeze, no published deadline beyond which Phase One is formally cancelled. If Month 9 (2027-07-12) slips to Month 11 (2027-09-12), the 90-day window compresses from 2027-07-12–2027-10-12 to 2027-09-12–2027-12-12, overlapping the winter holiday cycle and staff leave, which will reduce presence and presence-detection credibility.

### 8.4.B Tags

- entry_gate_ambiguity
- clock_validity_risk
- no_escalation_teeth
- compressed_exercise_window
- political_delay_exposure

### 8.4.C Mitigation

Lock a single, non-negotiable certification deadline of Month 9 (2027-07-12) at 09:00 UTC in the bilateral instrument signed by Month 7 (2027-05-12). Define the consequence explicitly: any condition uncertified by Month 9 (2027-07-12) at 17:00 UTC triggers automatic 48-hour principal escalation with a binary decision: proceed with available conditions and document omissions in the ledger, or formally cancel Phase One and return unspent tranche 1 funds. Publish the decision by Month 9 (2027-07-12) at 17:00 UTC. Freeze the 90-day Phase One window to Months 9–12 (2027-07-12 to 2027-10-12) with no extension except by principal double-key re-authorization within 7 days of Month 12 (2027-10-12). Mark any slipped condition in the KPI dashboard as an audit finding.

### 8.4.D Consequence

Without a locked gate, the program can drift into Month 11 (2027-09-12) or later, compressing the operational window below statistical significance for blind-challenge detection (proposed: 70 injections across 7 event types requires stable staffing and ~7 weeks minimum). A late start also bunches Phase One into winter holiday periods, reducing inspector availability and parity credibility. Worst case: no Phase One occurs, USD 100–200M (estimate) entry-cost burn is absorbed, and the program ends before testing begins.

### 8.4.E Root Cause

The plan treats entry conditions as procedural prerequisites rather than as hard-gate decisions with binding closure. The Month 12 (2027-10-12) 'outer limit' was intended as a planning buffer but is being read as ambiguity. No single decision-maker or escalation rule was named to break ties on borderline conditions (e.g., one vendor partially bound, one site inspector approval pending). The pre-project assessment flagged this but the plan did not incorporate the recommended locked deadline and principal escalation rule.

## 8.5.A Issue - Unverifiable-Equipment Threshold at 3% Is Unvalidated and Vulnerable to Exploitation Via Vendor Refusal

The pre-project assessment recommended vendor binding by Month 2.5 (2026-12-27) with a three-tier evidence ladder and explicit escalation to unverifiable status. However, the project plan defers vendor binding to Month 8 (2027-06-12), only 1 month before Phase One clock start. This timing leaves no recovery path if vendors refuse or attestation keys fail validation during the pre-test at Month 8.5 (2027-06-27): if 3% of equipment is unverifiable at that point, the site is already in automatic suspension, and there is no time to activate clean-room centers or re-bind vendors. The plan also does not address whether the 3% is measured by unit count (e.g., 3 of 100 devices) or by criticality; neither does it define which government is responsible for equipment that fails identity during intake—a source of disputes.

### 8.5.B Tags

- unvalidated_threshold
- vendor_refusal_concentration
- attestation_key_risk
- timing_cascade_failure
- unverifiable_classification_ambiguity
- no_recovery_path

### 8.5.C Mitigation

Complete vendor binding and attestation-key validation by Month 7 (2027-05-12), 2 months before Phase One, not Month 8 (2027-06-12). Run a full vendor census by Month 6 (2027-04-12): each vendor must confirm participation, supply cryptographic key fingerprints, and schedule independent validation testing. For any vendor refusing or unable to validate keys, activate pre-positioned clean-room examination centers by Month 6.5 (2027-04-27) and conduct supervised testing of a random sample (>=10 units per vendor) to establish a baseline detection capability under fallback evidence. Document results in the ledger with attestation-key validation status per vendor. Calibrate the 3% unverifiable threshold against this validated baseline: if vendors representing >5% of declared equipment cannot validate attestation, re-negotiate the threshold jointly or escalate to principals by Month 7 (2027-05-12). Define unverifiable classification rule: any equipment failing intake identity procedures is classified unverifiable; unverifiable items discovered post-intake remain unverifiable and count toward the cumulative threshold. Exclude unverifiable units from the opening inventory baseline so their absence is traceable in the ledger.

### 8.5.D Consequence

If vendor binding slips or attestation keys fail validation in Month 8 or 8.5 (2027-06-27), 10–40% of equipment could be unverifiable at Phase One clock start, triggering automatic site suspension under the 3% rule. The site fails outright, and the program loses credibility after USD 2–3 billion (estimate) in preparation costs. Alternatively, sites might start Phase One with unverifiable-equipment counts unknown, so disputes over which equipment is unverifiable arise mid-operation and cause deadlock cascades. Without a validated threshold and clear classification rule, the 3% becomes a political target rather than a technical fact.

### 8.5.E Root Cause

The plan inherited the 3% unverifiable threshold from the pre-project assessment without validating it against actual vendor participation rates or attestation-key custody. Vendor binding was deferred to Month 8 (2027-06-12) to save near-term costs, but this leaves only 1 month for recovery if vendors refuse. The plan also did not specify how unverifiable equipment discovered after intake is counted toward the threshold, which creates ambiguity for late-game disputes.

## 8.6.A Issue - Challenge-Exercise Partition and False-Positive Escalation Rule Are Defined But Not Operationalized; Misclassification Risk Remains Medium-High

The pre-project assessment estimated 2–3 false-positive incident risks per Phase One if partition is weak. The plan acknowledges this and calls for CHALLENGE tagging and partition, but does not specify the operational detection, escalation and reinstatement workflow. For example: if the intake protocol flags a CHALLENGE substitution as 'unverifiable equipment,' does the system automatically notify co-chairs or only log it? Does an automated suspension trigger occur, or is escalation manual? If the exercise-design panel discovers mid-test that a CHALLENGE event was misclassified by inspectors as operational, how is the correction applied retroactively to the KPI dashboard and ledger? The plan also does not address the training, audit and sign-off procedures to ensure inspectors and systems recognize CHALLENGE tags reliably.

### 8.6.B Tags

- partition_not_operationalized
- misclassification_detection_undefined
- 2_hour_escalation_not_proceduralized
- no_automated_tagging_control
- audit_trail_for_reinstatement_missing
- inspector_training_gap

### 8.6.C Mitigation

Define a Challenge-Exercise Misclassification Protocol by Month 8 (2027-06-12) with the following components: (1) Automated detection: the ledger ingestion system must verify every non-CHALLENGE event against the challenge-exercise catalog and halt acceptance if an injected scenario is recorded without the CHALLENGE tag; log all tag-match attempts in a separate 'partition-audit' log. (2) Real-time alert: if an automated flag occurs, a joint duty officer (one from each country) must be notified within 15 minutes with the flagged event, CHALLENGE-tag status, and reason code; the duty officers jointly decide within 30 minutes whether to escalate to principals or mark as reconciled. (3) Principal escalation: if escalation occurs, both co-chairs and their designated adjudication referees are notified within 1 hour (not 2 hours, to allow for time-zone delay) with the full event record, CHALLENGE-tag evidence, and a preliminary assessment. (4) Reinstatement procedure: once principals decide to reinstate a suspended site, the ledger records a 'MISCLASSIFICATION_RESOLUTION' entry with the decision text, signatures and effective-date timestamp; the KPI dashboard is updated to exclude the misclassified event from all thresholds and backfills metrics as if the event did not occur. (5) Inspector training: conduct a 1-hour mandatory training for all inspectors at Month 8.5 (2027-06-27) covering CHALLENGE-tag recognition, the escalation workflow, and the non-suspension rule, with a signed acknowledgment in each inspector's file. Conduct a final dry-run misclassification drill at Month 8.75 (2027-07-05) simulating a misclassified event and measuring the time from flag to co-chair notification.

### 8.6.D Consequence

Without operationalization, a CHALLENGE event that is genuinely flagged as anomalous by inspectors or automated systems will trigger a suspension that then requires a 2-hour emergency escalation across time zones, during which the site is offline and operations are halted. If the escalation procedure is informal or absent, co-chairs may not respond within 2 hours, and the site suspension persists, destroying operational credibility. Alternatively, inspectors may learn to ignore CHALLENGE tags or to suppress legitimate anomaly alerts to avoid false-positive cascades, eroding detection capability. A misclassification incident that is not quickly resolved also becomes an aging discrepancy, which triggers another automatic suspension under the 10-day aging rule, compounding the failure.

### 8.6.E Root Cause

The plan treats CHALLENGE partition as a labeling rule rather than as an operational workflow. The pre-project assessment correctly identified false-positive cascade risk and called for 'explicit CHALLENGE-event partitioning' and procedures, but the project plan incorporated only the policy ('tagged events cannot trigger suspension') without the operational procedures (who detects, how detection is automated, how escalation is triggered, how reinstatement is recorded). No procedure document, training plan or dry-run drill is scheduled.