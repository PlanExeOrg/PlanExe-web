# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Bilateral Governance and Deadlock-Resolution Specialist

**Knowledge**: US-China diplomatic negotiation, bilateral instrument drafting, double-key authority design, deadlock escalation procedures, neutral referee panel governance

**Why**: The plan's survival depends entirely on double-key governance without a casting vote and defined deadlock procedures (7-day escalation to neutral referee). The specialist would review whether the proposed deadlock definition, referee-panel composition, and automatic-suspension triggers are diplomatically defensible and whether the current 7/14-day clock windows are realistic for contested equipment-identity disputes.

**What**: Assess whether the deadlock definition (7 days) and automatic-suspension trigger (14 days) are consistent with similar bilateral verification regimes (New START, OPCW), whether neutral-referee membership is achievable without creating new trust problems, and whether double-key release of contingency (fast lane USD 50M) is administratively feasible within 5 business days.

**Skills**: Bilateral instrument negotiation, international-agreement drafting, dispute-resolution design, precedent analysis (arms control, export control), political-risk assessment

**Search**: bilateral verification mechanism deadlock resolution, US-China diplomatic agreement, double-key governance protocol, arms control escalation procedures

## 1.1 Primary Actions

- By Month 0.5 (2026-10-23 17:00), complete bilateral negotiations to pre-bind top 8–12 critical vendors per site to equipment-identity cooperation agreements (attestation, records, escort, penalties) and pre-qualify 3–5 independent examiner labs per country and 2 clean-room facilities per geography with signed agreements and confirmed cost and capacity. Publish the day-10 vendor-refusal ladder in writing.
- By Month 1 (2026-11-08 17:00), recruit, vet and pre-authorize a joint forensic-identity panel (3–5 per country, equal membership, no casting vote) with authority to resolve contested equipment-identity disputes within 48 hours using a bilateral instrument-codified evidence-weighting hierarchy (attestation if both match > physical + chain of custody > maintenance records > third-party logs). Implement shift-boundary cross-signing at every 8-hour handover (08:00, 16:00, 24:00 UTC).
- By Month 1 (2026-11-08 17:00), establish an explicit conditional-start fallback in the bilateral instrument permitting Phase One clock to begin at each site independently if one country's entry conditions delay >4 weeks, removing unilateral timing veto. Obtain both governments' signed acceptance. Assign named domestic-authority leads in each country and establish weekly bilateral entry-conditions steering committee starting Month 0 (2026-10-08 09:00).
- By Month 0.5 (2026-10-23 17:00), decompose every domestic legal act required in each country (e.g., US Congressional ratification, China State Council directive) and map through approval process. Identify critical-path item and single-item delays. Establish escalation protocol: if any authority slips >4 weeks, escalate to co-chairs within 2 working days with written fallback proposal.
- By Month 4 (2027-02-08 17:00), confirm that all inspector counterintelligence vetting is on track to meet the 100% critical-post and 80% roster-fill targets for Month 5 (2027-03-08). If vetting is at risk of delay, activate surge vetting resources and escalate to treasuries for expedited clearance.
- By Month 5.5 (2027-03-23 17:00), execute pre-test calibration on non-covered equipment (100–150 units per site, 50–100 events per site) and lock all Go/Modify/Stop decision thresholds by double-key co-chair signature, with documented justification and validation method. Mark all thresholds as 'validated' in the ledger.
- By Month 6 (2027-04-08 17:00), certify all seven entry conditions (instrument, appropriations, authority, sites, inspectors, vendor agreements, equipment schedule) independently by both sides with zero unresolved items older than 4 weeks. Issue joint certification in writing, signed by co-chairs, before the 90-day Phase One clock starts.

## 1.2 Secondary Actions

- By Month 0 (2026-10-08 16:00), identify the top 8–12 vendors at each proposed participating site by equipment dependency tier. Prepare ranked list with attestation-hook availability and maintenance-access risk per vendor. Brief both co-chairs on pre-binding strategy and timeline.
- By Month 1 (2026-11-08), design and lock the evidence-weighting corroboration rule in the bilateral instrument with worked example (e.g., 'if attestation diverges but physical inspection matches, accept physical inspection'). Obtain co-chair signature.
- By Month 2 (2026-12-08), schedule the bilateral key ceremony for split-custody cryptographic root generation. Select a mutually trusted secure facility and arrange video recording, witness signatures and tamper-evident seals. Confirm availability of both countries' cryptographic specialists and security teams.
- By Month 2.5 (2026-12-23 17:00), conduct a full ledger-system resilience test simulating 8-hour network outage, system crash and key unavailability. Verify recovery from backup within 6 hours and cryptographic validation success. Document recovery time and correct any procedural gaps by Month 3 (2027-01-08).
- By Month 0.5 (2026-10-23 17:00), conduct a bilateral pre-clock site-boundary survey with both countries' security teams, operators and inspectors present. Physically mark zone perimeter with painted lines, permanent signage and photographic documentation. Produce signed photographic record approved by both co-chairs.
- By Month 1.5 (2026-11-23 17:00), implement zone access-control gates at all entry points with proximity-card readers and video logging to both national ledgers in real time. Install redaction-compliant video in bounded zones. Confirm with operators that non-zone areas have no camera access.
- By Month 2 (2026-12-08), draft the three-tier zone-violation escalation protocol (Tier 1: warning + re-training; Tier 2: formal notice + removal review; Tier 3: immediate removal) and integrate into the bilateral instrument. Require every inspector to sign a zone-conduct acknowledgment before Month 3 (2027-01-08).
- By Month 3 (2027-01-08), confirm in writing whether calibration exercise data (Months 4–5 = 2027-02-08 to 2027-03-08) on non-covered equipment may be reused in the final Go/Modify/Stop decision. If yes, formally integrate calibration results into evidence base and mark 'validated'; if no, discard and note in final-decision rationale.
- By Month 3.5 (2027-01-23 17:00), confirm domestic access authority enacted in both countries. Publish a summary of the authority's enforcement mechanism (e.g., US statute, China directive) and the penalties for operator/vendor non-participation. File with both co-chairs.
- By Month 4.5 (2027-02-23 17:00), brief independent testing unit leadership on blind-exercise design, sealed double-key scheduling, and event-type coverage (at most 2 sessions per site per month, all in staging/spare/maintenance/expansion areas, zero interruption of active computation). Confirm that the testing unit has capacity and security clearance to manage sealed schedules.
- By Month 5 (2027-03-08 17:00), publish a final roster of approved inspectors per site and country, with total headcount, critical-post fill rate and surge-pool size. Brief co-chairs on any staffing gaps and contingency backfill plan.
- By Month 5.5 (2027-03-23 17:00), hold a bilateral pre-Phase-One readiness review with both co-chairs, all primary-unit leads, and ledger and forensic-panel representatives. Walk through each entry condition, ledger operational status, exercise schedule, and decision-threshold lock-in. Document readiness gaps and corrective actions. Clear all gaps or escalate co-chairs for exception.
- Throughout Months 0–6 (2026-10-08 to 2027-04-08), maintain a bilateral entry-conditions dashboard updated weekly, showing status of each domestic legal act, site-selection vote, appropriation tranche, inspector vetting, vendor agreements and equipment schedule. Highlight any item >2 weeks behind baseline. Escalate critical-path delays to co-chairs within 48 hours.

## 1.3 Follow Up Consultation

Next consultation should address: (1) Bilateral instrument drafting status and which articles codify the conditional-start fallback, forensic-panel hierarchy and vendor-refusal ladder; (2) domestic authority enactment timeline decomposed by country, with named leads and escalation procedures; (3) vendor pre-binding negotiation progress—which Tier-1 vendors are on track and which face refusal risk; (4) inspector vetting progress and counterintelligence agency capacity to meet Month 5 (2027-03-08) deadline; (5) ledger operational status and key-ceremony scheduling; (6) contingency governance and whether USD 15M exposure gap requires additional appropriation or scope trade-off; (7) how calibration data will be integrated or excluded from final-decision evidence base; (8) whether any site-selection candidate is at risk of withdrawal and fallback-site substitution contingency. Bring updated entry-conditions dashboard and draft bilateral instrument articles to next meeting.

## 1.4.A Issue - Entry Conditions Timeline Is Compressed and Lacks Fallback Authority

The plan maps seven entry conditions to Months 2–6 (2026-12-08 to 2027-04-08). However, the domestic authority enactment (Month 3.5 = 2027-01-23) is the critical path, and no decomposition by country or fallback exists if one government's legislation slips >4 weeks. A 4-week slip defers Phase One by 3 months and costs USD 150–300M in holding expenses, consuming one-third of contingency. The gate also gives the slower government an unilateral timing veto, contradicting the reciprocity principle.

### 1.4.B Tags

- domestic-authority-risk
- unilateral-timing-veto
- contingency-exposure
- compressed-timeline

### 1.4.C Mitigation

Immediately decompose every domestic legal act by country and approval body (e.g., US Congressional ratification, State Department authorization, China State Council directive) by Month 0.5 (2026-10-23 17:00). Establish a bilateral entry-conditions steering committee with weekly reviews from Month 0 (2026-10-08 09:00). Identify each country's critical-path item and assign a named domestic-authority lead. Pre-draft a conditional-start fallback into the bilateral instrument permitting the clock to begin at each site once that site's entry conditions are met, removing the slower-country veto. Obtain both governments' signed acceptance by Month 1 (2026-11-08 17:00). If any authority slips >4 weeks, escalate to co-chairs within 2 working days with written fallback proposal.

### 1.4.D Consequence

Without fallback authority, a slip in one government's legislation (e.g., parliamentary recess, committee delay) can defer Phase One indefinitely, holding USD 50–100M per month. A 3-month slip to Month 9 (2027-07-08) exhausts contingency and compresses pre-test calibration, forcing locked thresholds on unvalidated data. This increases the risk of a Modify outcome driven by mis-set yardsticks rather than mechanism performance. A further delay past the Month 9 (2027-07-08) backstop triggers an extend-or-stop decision that may be forced rather than principled.

### 1.4.E Root Cause

The plan treats all seven entry conditions as simultaneous prerequisites, reflecting the strict gate principle. However, no mechanism exists to isolate one country's administrative delay from the timeline or to permit bounded conditional start. The bilateral instrument itself may not yet authorize per-site entry phasing.

## 1.5.A Issue - Vendor Refusal Cascade and Unverifiable Equipment Threshold Risk

The plan allocates USD 0.5B for independent testing, red teams and fallback examiners across all four sites and 90 days. However, vendor-refusal escalation paths (request → escalation → examiner notified → exam → day-10 report) assume pre-qualified examiners and clean-room facilities are operational. If critical vendors are not pre-bound by Month 0.5 (2026-10-23 17:00) and examiners not pre-qualified and contracted by Month 4 (2027-02-08), material equipment will be classified unverifiable by Months 3–4 (2027-01-08 to 2027-02-08). At hard sites (those with complex third-party access), unverifiable equipment may exceed the 5% Go threshold, failing the site.

### 1.5.B Tags

- vendor-dependency
- unverifiable-equipment
- fallback-pool-delay
- hard-site-risk
- contingency-overrun

### 1.5.C Mitigation

By Month 0.5 (2026-10-23 17:00), complete bilateral negotiations to pre-bind the top 8–12 critical vendors at each site to equipment-identity cooperation agreements, including attestation disclosure, maintenance records, escort rules and liquidated-damage penalties (USD 500k–2M per refusal). By Month 1 (2026-11-08 17:00), pre-qualify a pool of 3–5 independent examiner labs per country and 2 clean-room facilities per geography, with signed access and confidentiality agreements and confirmed cost per exam (USD 20–50k target) and capacity (5+ parallel exams per week). Codify vendor-refusal ladder (day 0–10) in the bilateral instrument. If 80% of Tier-1 vendors are not pre-bound by Month 1 (2026-11-08 17:00), allocate additional contingency USD 5–10M per site to late-engaged examiners.

### 1.5.D Consequence

If vendors are not pre-bound and examiners not pre-qualified before Phase One starts, a critical manufacturer's refusal triggers day-1 escalation that cannot be resolved within the day-10 ladder due to examiner unavailability. Material equipment is then classified unverifiable. At a hard site with high third-party throughput, unverifiable counts may reach 8–12%, exceeding the 5% Stop threshold and failing the site. This cascades to a Stop decision, making the entire mechanism appear to fail when the root cause is vendor refusal and examiner delay, not the verification design.

### 1.5.E Root Cause

The plan assumes independent examiners and clean-room fallbacks are pre-positioned, but the entry-conditions timeline does not explicitly schedule examiner pre-qualification. Vendor pre-binding is mentioned conceptually but has no firm bilateral negotiation deadline or status tracking.

## 1.6.A Issue - Ledger Divergence Forensics and Automatic Suspension Clock Risk

The plan specifies that ledger divergence is detected within 2 hours, with target resolution of technical faults within 4 hours. However, no joint forensic-identity panel is pre-authorized before Phase One, and no hierarchy for resolving contested identity disputes is codified in the bilateral instrument. When divergence occurs (e.g., national ledgers disagree on whether an equipment identifier was confirmed), the current escalation is unclear: does automatic suspension fire at 7 days unresolved divergence, or does the co-chair escalation clock apply? If suspension fires automatically on divergence older than 7 days, a legitimate 48-hour forensic investigation followed by slow co-chair sign-off can trigger suspension for a technical fault, not a real concealment.

### 1.6.B Tags

- ledger-divergence-deadlock
- forensic-authority-gap
- automatic-suspension-risk
- false-positive-suspension
- stop-condition-ambiguity

### 1.6.C Mitigation

By Month 0.5 (2026-10-23 17:00), recruit and pre-vet a joint forensic-identity panel with 3–5 senior technical specialists per country, each holding counterintelligence clearance. By Month 1 (2026-11-08 17:00), codify a divergence-resolution hierarchy in the bilateral instrument: Equipment identity is confirmed if cryptographic attestation AND physical inspection agree, OR if attestation unavailable, physical inspection PLUS 2 independent records agree. When national ledgers diverge, the panel applies this hierarchy by layer, in order of independence. Issue binding findings within 48 hours; if no consensus, co-chairs decide within 24 hours. Document all resolutions in the ledger. Implement shift-boundary cross-signing at every 8-hour handover (08:00, 16:00, 24:00 UTC), with mirrored inspectors jointly certifying no undisclosed divergence. Any divergence discovered during cross-signing escalates within 2 hours.

### 1.6.D Consequence

Without pre-authorized forensic authority and clear divergence hierarchy, a technical ledger fault (e.g., clock skew causing 30-minute timestamp mismatch between national copies) becomes an ambiguous dispute about whether suspension applies. The 7-day automatic-suspension clock ticks while both sides negotiate procedure, creating pressure to suspend preemptively. A suspension for a technical fault, not a real concealment, triggers impaired-confidence status or Stop, making the mechanism appear to fail when the root cause is divergence procedure, not evidence quality.

### 1.6.E Root Cause

The plan specifies divergence detection and escalation clocks but does not pre-authorize the forensic panel or codify the evidence hierarchy in the bilateral instrument before the clock starts. Automatic suspension is triggered at 7 days, but the path from technical fault to forensic resolution to suspension/clearance is not pre-established.

---

# 2 Expert: Cryptographic Ledger and Key-Ceremony Security Architect

**Knowledge**: Split-custody cryptographic key ceremony design, tamper-evident distributed ledgers, offline backup protocols, ledger-divergence detection and forensics, cryptographic root-key generation and custody

**Why**: Unresolved ledger divergence is an explicit Stop condition, and the plan requires a replicated tamper-evident ledger with split-key custody and offline ceremonies. The specialist would verify that the proposed 2-hour divergence-detection window, 48-hour forensic-panel resolution and shift-handover cross-signing are technically feasible, that the key-ceremony facility and backup protocols prevent unilateral key compromise, and that cryptographic signing cannot be spoofed.

**What**: Design the key-ceremony facility and procedures (air-gapped, physical separation, backup protocols) so that neither government alone can mint or revoke attestation, validate the 60-minute sync-latency target and 2-hour divergence-detection bound against actual network and system-recovery time-constants, and specify the cryptographic hash-check cycle (proposed 4-hour cycle) and automated alert thresholds.

**Skills**: Split-key cryptography, threshold-signature schemes, hardware security modules, key escrow and recovery protocols, distributed-system consistency and Byzantine-fault tolerance, cryptographic-ceremony protocol design

**Search**: split custody key ceremony cryptography, distributed ledger divergence detection, tamper-evident digital evidence custody, offline backup encryption protocols

## 2.1 Primary Actions

- By Month 0.5 (2026-10-23 17:00), complete bilateral negotiations to pre-bind the top 8–12 critical vendors at each proposed participating site to equipment-identity cooperation agreements, and pre-qualify independent examiners and clean-room facilities as fallback evidence routes. Without vendor pre-binding and examiner pre-qualification locked in before the clock starts, material equipment will be classified unverifiable by Month 3–4 (2027-01-08 to 2027-02-08), failing sites under thresholds and forcing a Stop outcome.
- By Month 1 (2026-11-08 17:00), recruit, vet and pre-authorize a joint forensic-identity panel (3–5 specialists per country, equal membership, no casting vote) with explicit authority to resolve contested equipment-identity disputes within 48 hours using a pre-agreed evidence-weighting hierarchy. Codify the dispute-resolution procedure in the bilateral instrument before the clock starts. Without pre-authorized forensic authority, ledger-divergence clocks will expire and trigger cascading automatic suspensions on technical sync faults, making the mechanism appear to fail when it is functioning.
- By Month 1 (2026-11-08 17:00), establish an explicit conditional-start fallback in the bilateral instrument permitting Phase One to begin at each site independently if one country's entry conditions delay >4 weeks beyond the Month 6 (2027-04-08) baseline. Without a conditional-start fallback, either government's domestic legislative delay will indefinitely defer the entire 90-day test, consuming the USD 500M contingency on holding costs and eroding reciprocal confidence before testing begins.

## 2.2 Secondary Actions

- Starting Month 0 (2026-10-08 09:00), establish a bilateral entry-conditions steering committee with equal co-chairs meeting weekly. Each co-chair appoints a single domestic-authority lead. Map all required legislative and executive acts through their approval processes; if any item slips >4 weeks, escalate to co-chairs within 2 working days with written mitigation. This removes the timing veto risk.
- By Month 1 (2026-11-08 17:00), confirm in the bilateral instrument whether calibration-exercise data (Months 4–5 = 2027-02-08 to 2027-03-08) may be reused in the final Go/Modify/Stop decision. If yes, formally integrate calibration results into the evidence base. If no, discard calibration data and acknowledge this in the final-decision rationale. This clarifies whether threshold validation is complete before the formal 90-day window or must rely on provisional figures.
- By Month 0.5 (2026-10-23 17:00), initiate counterintelligence vetting of all candidate inspectors (14–16 weeks before clock start). Identify 120–150 candidates per country (full roster ~100 plus surge buffer). Coordinate with counterintelligence agencies for expedited review; target clearance completion 4 weeks before clock start (by Month 5 = 2027-03-08). Inspector approval is the critical-path bottleneck; start vetting immediately or slip the clock.
- By Month 4 (2027-02-08), design and test the ledger system with shift-boundary cross-signing, automated divergence detection (<2 hours), forensic-panel dispatch routing, and failover procedures on non-covered equipment. Document divergence resolution hierarchy with worked examples. This de-risks the forensic-panel authority and confirms the ledger can handle disputes within clock timers.
- By Month 1.5 (2026-11-23 17:00), confirm which 4 participating sites are selected, conduct bilateral boundary surveys with security and operator teams, physically mark inspection zones with permanent signage and photography, and produce signed boundary documentation. Narrow, marked zones with auditable operator redaction are the core control limiting IP exposure and consent-withdrawal risk.
- By Month 5.5 (2027-03-23 17:00), lock all Go/Modify/Stop decision thresholds via double-key co-chair signature, each with documented justification and calibration or exercise evidence. Mark provisional figures as validated and all later changes as recorded protocol amendments. This prevents thresholds from being re-interpreted after the fact or tuned to reach a predetermined outcome.
- Raise the contingency-exposure gap (about USD 15M estimate) at the Month 3 (2027-01-08) appropriations review. If gate slip, site replacement and vendor-examiner overruns coincide, the contingency is overdrawn by approximately 15M. Secure approval for a small supplementary tranche or tighten scope to eliminate the shortfall before Month 4 (2027-02-08).
- By Month 2 (2026-12-08), the independent testing unit and both technical leads draft the flagship intake-to-exit scenario for one covered equipment class. Rehearse it in calibration (Months 4–5 = 2027-02-08 to 2027-03-08). Stage it as the lead demonstration in Phase One. A visible, end-to-end verified-intake scenario gives leadership a compelling use-case for why the mechanism matters.

## 2.3 Follow Up Consultation

"At Month 1.5 (2026-11-23), review: (1) status of vendor pre-binding agreements (target 80% Tier 1 vendors signed) and examiner pre-qualification (3–5 labs per country, capacity confirmed); (2) forensic-panel vetting completion and evidence-hierarchy codification in the instrument; (3) conditional-start fallback and domestic-authority tracking results (any items >4 weeks late?); (4) inspector vetting progress (target 80% roster submitted for clearance by Month 2 = 2026-12-08); (5) ledger design, boundary survey completion, and threshold-calibration timeline. Address any slip >2 weeks immediately. At Month 3 (2027-01-08), confirm entry-condition certification timeline and schedule site-by-site entry reviews. At Month 5.5 (2027-03-23), lock thresholds and conduct pre-test stress scenarios. At Month 6 (2027-04-08), certify all entry conditions and begin Phase One with full roster and forensic authority in place."


## 2.4.A Issue - Ledger Divergence Has No Pre-Authorized Forensic Authority; Clocks Will Expire and Trigger Cascading Automatic Suspensions

The plan specifies that ledger divergence is detected within 2 hours and must be resolved within bounded clock timers (72 hours for impaired-confidence status, 7 days for automatic suspension). However, no joint forensic-identity panel with pre-authorized decision authority exists, and no bilateral dispute-resolution procedure is locked in the instrument before the clock starts. When divergence occurs—and it will, due to synchronization latency, time-zone recording differences, or deliberate attack—the co-chairs will face a contested identity claim with no pre-agreed mechanism to resolve it within 48 hours. Each side will defend its ledger copy. The clock will expire. Automatic suspension will fire. The mechanism will appear to fail, even though the underlying detection capability is sound.

### 2.4.B Tags

- ledger-divergence-deadlock
- missing-forensic-authority
- automatic-suspension-risk
- bilateral-dispute-procedure

### 2.4.C Mitigation

Establish a pre-authorized joint forensic-identity panel (3–5 senior specialists per country, equal membership, no casting vote) before the clock starts (by Month 1 = 2026-11-08). Codify a dispute-resolution hierarchy in the bilateral instrument: (1) cryptographic attestation, if both ledgers match; (2) physical inspection and chain-of-custody records, if available; (3) independent examiner arbitration, if previous layers diverge; (4) co-chair escalation within 24 hours if consensus fails at step 3. The panel issues findings within 48 hours; if consensus is not reached, co-chairs decide within 24 hours. Implement shift-boundary cross-signing: at each daily shift handover, mirrored inspectors from each country jointly certify they have reviewed the prior shift's entries and found no undisclosed divergences. Configure automated divergence detection to alert within 2 hours and route to the duty forensic-panel member. Document every divergence and its resolution in both ledgers with signatures. Run failover tests of the forensic panel on non-covered equipment by Month 4 (2027-02-08). Consult: bilateral legal counsel, forensic-IT specialists, ledger architects. Read: IAEA/Euratom safeguards forensics procedures. Provide: cryptographic attestation specifications, sample divergence scenarios, ledger sync-latency measurements.

### 2.4.D Consequence

Unresolved ledger divergence will accumulate. At 7 days, automatic suspension of the affected site or event class fires, triggering impaired-confidence status or Stop conditions. If this occurs on a technical sync fault (not concealment), the mechanism is perceived to have failed, eroding reciprocal confidence. A cascading chain of suspensions could render both national ledgers inoperative within the 90-day window, forcing a Stop outcome based on ledger failure rather than detection capability. Political cost: either government can weaponize divergence disputes to halt the test.

### 2.4.E Root Cause

The plan assumes disputes over equipment identity will be resolved through 'co-chair authority' and double-key signing, but it does not pre-authorize a joint technical panel with explicit decision authority, a forensic hierarchy, or a time-bounded resolution process that sits outside the political veto loop. The bilateral instrument does not codify which evidence layers resolve disputes or who can invoke them. Without pre-authorized forensic authority, every divergence becomes a diplomatic negotiation, and escalation clocks expire before consensus is reached.

## 2.5.A Issue - Vendor Refusal Escalation Paths and Independent-Examiner Pre-Qualification Are Not Confirmed; Material Equipment Will Be Classified Unverifiable and Sites Will Fail

The plan outlines a vendor-refusal ladder (day-10 deadline, fallback examiners, clean-room procedures) but does not confirm whether the top 8–12 critical vendors at each site will sign binding cooperation agreements by Month 0.5 (2026-10-23), whether independent examiners exist in sufficient numbers and have been pre-qualified by Month 4 (2027-02-08), or whether clean-room facilities have capacity. Without these commitments in place before the clock starts, vendors will refuse cooperation when called upon, and no fallback examiner will be available or scheduled. Equipment will be classified unverifiable within the day-10 window. At 4 participating sites, if even 6–8% of covered equipment fails identity verification (above the 5% Stop threshold), a site fails the Go decision. The test will be stopped, not because the detection mechanism is weak, but because the evidence supply chain is broken.

### 2.5.B Tags

- vendor-refusal-cascade
- unverifiable-equipment-threshold
- missing-examiner-pool
- supply-chain-risk

### 2.5.C Mitigation

Identify the top 8–12 manufacturers, maintenance providers and logistics vendors at each proposed participating site by Month 0 (2026-10-08). Rank them by dependency (Tier 1: must have vendor cooperation or site fails; Tier 2: fallback available). Conduct bilateral negotiations with every Tier 1 vendor to sign pre-Phase-One cooperation agreements by Month 0.5 (2026-10-23 17:00), binding each vendor to: (a) equipment-identity attestation disclosure within 2 business days of request; (b) maintenance-record preservation and evidence escrow for 90 days post-departure; (c) inspector escort and site access during Phase One; (d) penalty clauses (contract termination, liquidated damages USD 500k–2M per material refusal). Target 80% signature rate on Tier 1 vendors before Month 1 (2026-11-08). Pre-qualify a pool of 3–5 independent examiners per country and 2 clean-room facilities per geography by Month 1 (2026-11-08 17:00). Require each to sign access, confidentiality and capacity-booking agreements (minimum 5 parallel exams per week per facility). Confirm cost per examination (USD 20–50k) and reserve capacity slots for at least 20–30 priority exams per site within the 90-day window. Consult: bilateral procurement teams, vendor legal counsel, independent laboratory accreditation bodies. Read: vendor-dispute resolution case studies from nuclear safeguards. Provide: vendor contact matrix, cooperation-agreement template, examiner pre-qualification checklist, cost-per-exam estimates.

### 2.5.D Consequence

Vendor refusals will accumulate at 4 sites in parallel. Without pre-bound vendor cooperation agreements, refusals will cluster around vendors that control attestation keys or maintenance access—exactly the vendors most likely to be leveraged by either government or withheld for competitive or political reasons. A single major vendor refusal (e.g., a manufacturer controlling 10–15% of covered equipment at a hard site) will push unverifiable counts above the 5% threshold, failing that site. Across 2 sites, the project loses half its evidence base. Political consequence: either government could engineer vendor refusal as a backdoor Stop mechanism. Economic consequence: late-engaged fallback examiners cost USD 30–50k per exam versus the budgeted USD 20–30k; a cascade of 50–100 unplanned exams could overrun the contingency by USD 1–3M per site.

### 2.5.E Root Cause

The plan assumes vendor cooperation and independent examiner availability without confirming their willingness or scheduling capacity before the clock starts. Vendor cooperation is treated as an 'if needed' escalation, not a pre-gated entry condition. No bilateral negotiations with vendors are scheduled before Month 0 (2026-10-08). No examiner pre-qualification or capacity-booking agreements exist. If a vendor refuses cooperation, the operator must request an independent examiner on short notice, but if no examiner is available (or if the vendor withholds technical specifications), the equipment cannot be verified and is marked unverifiable by default.

## 2.6.A Issue - Domestic Authority Enactment Has No Decomposed Milestones or Fallback; One Government's Legislative Delay Will Indefinitely Defer the Phase One Clock or Compress Pre-Test Calibration

The plan lists 'domestic access authority enacted (Month 3.5 = 2027-01-23)' as a mandatory entry condition, but it does not decompose which specific legislative or executive acts each government must pass, does not name the approving bodies or committee review windows, and does not establish a fallback if one country's authority lags beyond Month 6 (2027-04-08). If the US Congress passes the bilateral instrument ratification and domestic access act on schedule in Month 2 (2026-12-08) but China's State Council process slips to Month 5 (2027-03-08) due to competing legislative priorities or summer recess, the strict entry gate will not be satisfied, the Phase One clock will not start on schedule, and no conditional fallback exists to begin testing at individual sites. The entire test is held up by whichever government moves slower. Holding cost is USD 50–100M per month per the estimates.

### 2.6.B Tags

- domestic-authority-lag
- unilateral-veto-risk
- missing-conditional-start
- entry-condition-bottleneck

### 2.6.C Mitigation

Identify and document every specific domestic legislative and executive act required in each country by Month 0 (2026-10-08 16:00). Examples: US: Congressional ratification of bilateral instrument, domestic access authority granting operators legal obligation to participate, inspector immunity acts; China: State Council delegation directive, ministry enforcement authority, domestic access and confidentiality rules. Establish a bilateral entry-conditions steering committee with both co-chairs meeting weekly starting Month 0 (2026-10-08 09:00), with documented meeting notes and signed action-item assignments. Each co-chair appoints a single domestic-authority lead accountable for their country's legislative timeline. Map each required act through its approval process (parliament session dates, committee windows, interagency review, counterintelligence vetting) and identify the critical path. If any act is delayed >4 weeks beyond baseline target, automatically trigger co-chair escalation within 2 working days with a written fallback proposal. Pre-draft a conditional-start fallback option into the bilateral instrument by Month 0.5 (2026-10-23 17:00): Phase One clock may begin at each site independently once that site's entry conditions are met, with joint certification required for the final Go/Modify/Stop decision. Obtain both governments' signed acceptance of this fallback before Month 1 (2026-11-08). Consult: bilateral legal counsel, parliamentary or legislative experts in each country, appropriations officers. Read: New START ratification timeline case study. Provide: decomposed legislative act checklist, approval-process flowchart, critical-path Gantt chart with decision gates and escalation rules.

### 2.6.D Consequence

Domestic legislative or administrative delays will defer the Phase One clock beyond the Month 6 (2027-04-08) baseline. A 3-month slip (to Month 9 = 2027-07-08, the backstop decision window) costs USD 150–300M in holding costs and compresses the calibration window, forcing thresholds to be locked on unvalidated provisional data, which increases the risk of a Modify outcome reflecting the yardstick rather than the mechanism. A 4–6 month slip into Month 12 (2027-10-08) or beyond erodes political will, invites geopolitical reinterpretation of the instrument, and risks that one government withdraws or uses delay as a negotiating lever for unrelated demands. Political consequence: the slower government holds the entire project hostage; the faster government perceives bad faith; reciprocal confidence is damaged before the test even starts.

### 2.6.E Root Cause

The plan treats 'domestic access authority' as a single monolithic entry condition but does not decompose it into the specific legislative and executive acts each country must pass, the approval bodies (e.g., US Congress, China State Council), the likely approval timelines, or the dependencies between them. No bilateral steering committee exists to track progress or escalate delays. No conditional-start fallback exists in the instrument; the design assumes all countries synchronize perfectly. If one government's authority slips by 4+ weeks, the entry gate cannot be certified, the clock does not start, and no mechanism exists to begin testing at sites whose conditions are already met.

---

# 3 Expert: Vendor-Refusal and Supply-Chain Evidence Fallback Strategist

**Knowledge**: Vendor cooperation agreements and penalty clauses, independent equipment-identity examination protocols, clean-room procedures, validated cryptographic attestation methods, equipment-traceability standards

**Why**: Vendor refusal cascades are modeled to leave >10% of equipment unverifiable, a site failure. The plan proposes a day-10 escalation ladder (vendor request, examiner, report) with fallback to clean-room and attestation, but pre-qualification of examiners and clean-room facilities is deferred to Month 4 (2027-02-08), creating risk that no fallback exists when Phase One starts. The specialist would validate the ladder timeline, confirm examiner and clean-room capacity, and specify cost and penalty-clause language.

**What**: By Month 0.5 (2026-10-23), identify and document the top 8-12 critical vendors per site, map their attestation-hook availability and maintenance-access dependencies, draft penalty-clause language (liquidated damages, contract termination, market access loss), and confirm at least 3-5 examiner labs and 2 clean-room facilities per geography with cost estimates and scheduling capacity before Month 4 (2027-02-08).

**Skills**: Vendor contract negotiation, penalty-clause drafting, equipment-identity attestation standards, independent-laboratory accreditation, supply-chain forensics, cost estimation for fallback pathways

**Search**: vendor cooperation penalties contract language, equipment identity verification without vendor access, clean room examination procedures, independent equipment authentication

## 3.1 Primary Actions

- Complete bilateral negotiations to pre-bind top 8–12 critical vendors to equipment-identity cooperation agreements with penalty clauses (USD 500k–2M per material refusal) by Month 0.5 (2026-10-23 17:00). Obtain countersignatures from at least 80% of Tier 1 vendors before Month 1 (2026-11-08).
- Pre-qualify 3–5 independent examiner labs per country and 2 accredited clean-room facilities per geography, with signed access and confidentiality agreements confirming cost (USD 20k–50k per exam) and capacity (5+ parallel exams/week) by Month 1 (2026-11-08 17:00). Register agreements in both national ledgers.
- Recruit and pre-vet a joint forensic-identity panel (3–5 specialists per country, 6–10 total) with full counterintelligence clearance from both governments by Month 0.5 (2026-10-23 17:00). Embed the panel's mandate, corroboration hierarchy and decision-authority in the bilateral instrument by Month 1 (2026-11-08 17:00).
- Implement shift-boundary cross-signing of ledger entries at every shift handover (08:00, 16:00, 24:00 UTC) by mirrored inspectors, with divergence detected within 2 hours, forensic-panel investigation within 24 hours and findings within 48 hours. Configure automated divergence alerts and escalation by Month 1 (2026-11-08).
- Decompose domestic-authority enactment (each country's specific legislative or executive acts) through its approval process by Month 0 (2026-10-08 16:00). Establish a bilateral entry-conditions steering committee with both co-chairs meeting weekly, each appointing a single domestic-authority lead accountable for timeline. Escalate any item >4 weeks late within 2 working days.
- Pre-draft a conditional-start fallback into the bilateral instrument by Month 0.5 (2026-10-23 17:00), permitting Phase One clock to begin at each site once that site's entry conditions are met, with joint certification required for the final Go/Modify/Stop decision. Obtain both governments' signed acceptance by Month 1 (2026-11-08).
- Test the joint forensic panel, ledger divergence detection, and shift-boundary cross-signing procedures on non-covered equipment by Month 4 (2027-02-08) to confirm the 2-hour detection, 48-hour resolution and automatic-suspension triggers function as designed.

## 3.2 Secondary Actions

- By Month 0 (2026-10-08 09:00), establish a bilateral budget working group to identify the contingency exposure gap (estimated USD 15M shortfall if gate slip, site replacement and examiner overruns coincide) and request co-chairs to approve a contingency review and reallocation at Month 3 (2027-01-08).
- By Month 0.5 (2026-10-23 17:00), map all entry-condition milestones (instrument signature, site selection, appropriations, authority enactment, vendor/operator binding, inspector approval, certification) to a weekly tracking dashboard; flag any item with >2-week slip as yellow and >4-week slip as red with automatic escalation.
- By Month 1 (2026-11-08), finalize the bilateral instrument to include: conditional-start fallback language; forensic-panel mandate and corroboration hierarchy; vendor-refusal day-10 ladder; ledger divergence detection and resolution clocks; three-tier zone-infraction escalation protocol; and definitions of deadlock, impaired confidence and automatic suspension. Obtain both co-chairs' signatures.
- By Month 1 (2026-11-08), confirm the split of the USD 1.0B site-preparation envelope between physical site preparation and operator compensation by country, and allocate the USD 250M per-site budget across staging areas, inspection zones, marked boundaries, access controls and redaction infrastructure.
- Initiate counterintelligence vetting of all candidate inspectors (at least 120–150 per country, 20–30% surge buffer) by Month 0.5 (2026-10-23) to meet the 14–16 week vetting window before Phase One clock (Month 6 = 2027-04-08). Request expedited review with commitment to complete clearance 4 weeks before clock start.
- By Month 1 (2026-11-08 17:00), conduct bilateral pre-clock site-boundary surveys at each proposed participating site with security teams, operators and inspectors present. Physically mark zone perimeters with painted lines and signage; produce photographic documentation; obtain signed bilateral approval of the marked boundary.
- By Month 1 (2026-11-08), design and codify the three-tier zone-infraction escalation protocol in the bilateral instrument: Tier 1 (warning + re-training within 48 hours), Tier 2 (formal notice, conduct-committee review, removal within 5 working days), Tier 3 (immediate removal + legal action). Publish the protocol; require every inspector to sign a zone-conduct acknowledgment before clock start.

## 3.3 Follow Up Consultation

At Month 1 (2026-11-08) follow-up, review: (1) vendor pre-binding completion rate (target 80% of Tier 1 vendors countersigned); (2) independent-examiner and clean-room pre-qualification status (target 3–5 labs per country, 2 per geography, agreements signed); (3) forensic-panel recruitment and vetting status (target 6–10 members, clearances granted); (4) domestic-authority status by country (completed acts, pending approvals, critical-path item); (5) bilateral instrument signature and conditional-start fallback acceptance; (6) inspector counterintelligence vetting start and projected completion date; (7) contingency shortfall review outcome and reallocation decision. If any item is incomplete or off track, escalate immediately to co-chairs with a fallback proposal. Confirm ledger operational test completion and shift-boundary cross-signing procedure validation by Month 4 (2027-02-08). At Month 5.5 (2027-03-23), confirm all Go/Modify/Stop thresholds are double-key locked with documented justification.

## 3.4.A Issue - Domestic Authority Enactment Timeline Is Undefined and Unilateral-Veto Risk Is Unmitigated

The plan lists 'domestic access authority enacted (Month 3.5 = 2027-01-23)' as an entry condition but does not decompose the specific legislative or executive acts required in each country, their approval bodies, or realistic enactment timelines. No fallback exists if one government's authority lags >4 weeks. This hands the slower government an effective timing veto: if China's State Council directive or US Congressional ratification slips past Month 6 (2027-04-08), the clock cannot start. At USD 50–100M/month holding cost, a 3-month slip burns USD 150–300M of contingency without addressing the root cause.

### 3.4.B Tags

- entry-condition-delay
- timing-veto
- unilateral-leverage
- cost-overrun
- critical-path-undefined

### 3.4.C Mitigation

By Month 0.5 (2026-10-23 17:00), map each country's required domestic acts (e.g., US Congressional ratification, China State Council directive) through its approval process with specific committee dates and counterintelligence vetoes. Identify the critical-path item. Establish a bilateral entry-conditions steering committee with both co-chairs meeting weekly, each appointing a single domestic-authority lead accountable for timeline. If any authority is >4 weeks late, trigger political escalation within 2 working days. By Month 1 (2026-11-08), embed a conditional-start fallback in the bilateral instrument permitting the clock to begin at each site once that site's entry conditions are met, with joint certification required only for the final Go/Modify/Stop decision. Obtain both governments' signed acceptance of this fallback before Month 1 (2026-11-08).

### 3.4.D Consequence

Without mitigation, if one country's domestic authority does not clear by Month 6 (2027-04-08), the Phase One clock cannot start. The backstop (Month 9 = 2027-07-08 extend-or-stop decision) forces a choice between geopolitical escalation or program deferral, burning USD 150–300M in holding costs and damaging reciprocal confidence. A conditional-start fallback removes the timing veto and permits parallel entry-condition completion.

### 3.4.E Root Cause

The plan treats entry conditions as a monolithic gate but does not decompose domestic-authority timelines or design a procedural fallback for unequal national decision speeds. The strict gate assumption (all conditions simultaneously certified) is a strategic choice, but without escalation procedures and a conditional-start fallback in writing, it becomes a vulnerability rather than a design principle.

## 3.5.A Issue - Vendor Refusal Escalation Path and Independent-Examiner Pre-Qualification Are Not Confirmed; Unverifiable Equipment Will Accumulate

The plan lists vendor-refusal response paths (vendor-supervised testing, filtered evidence, accredited examiners, clean-room procedures, validated attestation) but does not require top vendors to be pre-bound before the clock starts or independent examiners to be pre-qualified by Month 0.5 (2026-10-23). If a critical vendor refuses cooperation and examiners are not pre-credentialed, the day-10 refusal ladder cannot fire. Material equipment will be classified unverifiable by Month 3–4 (2027-01-08 to 2027-02-08), failing the 5% unverifiable threshold and causing a site to fail. Pre-binding is the only way to prevent cascades.

### 3.5.B Tags

- vendor-cooperation-undefined
- independent-examiner-pool-missing
- unverifiable-equipment-accumulation
- threshold-failure
- site-failure-risk

### 3.5.C Mitigation

By Month 0.5 (2026-10-23 17:00), identify the top 8–12 critical vendors (by equipment class, dependency ranking) at each proposed participating site. Conduct bilateral negotiations with every Tier 1 vendor (must-have cooperation) to sign a pre-Phase-One binding agreement by Month 0.5 (2026-10-23 17:00), with penalty clauses (USD 500k–2M per material refusal, loss of future market access). Obtain countersignatures for at least 80% of Tier 1 vendors before Month 1 (2026-11-08). Pre-qualify 3–5 independent examiners per country and 2 clean-room facilities per geography by Month 1 (2026-11-08 17:00). Lock the day-10 refusal ladder in writing (request, escalation, examiner notification, exam, report) and confirm cost per exam (target USD 20k–50k) and weekly capacity (minimum 5 parallel exams per facility). Register these agreements and certifications in both national ledgers before the clock starts.

### 3.5.D Consequence

If vendor pre-binding and examiner pre-qualification are deferred or incomplete by Month 2 (2026-12-08), a single vendor refusal during Phase One will cascade: no pre-qualified examiner can be engaged; alternative routes (clean-room, validated attestation) will lack pre-approval; equipment will remain unverifiable beyond the day-10 deadline. By Month 3–4 (2027-01-08 to 2027-02-08), 5–10% of material equipment at one site will be classified unverifiable, exceeding the 5% Go threshold and triggering automatic site failure (Stop).

### 3.5.E Root Cause

The plan describes vendor-refusal routes as options but does not require pre-binding, pre-qualification or cost commitment in advance. Vendor-refusal escalation is a known, high-probability scenario (frontier equipment relies on specialized vendors), so it must be de-risked before the clock, not improvised during Phase One.

## 3.6.A Issue - Ledger Divergence Forensic Authority and Deadlock Resolution Are Not Pre-Authorized; Automatic Suspension Clocks Will Expire and Trigger Spurious Stop Outcomes

The plan specifies that ledger divergence must be detected within 2 hours and resolved within a 72-hour impaired-confidence clock (Tier 2), with automatic suspension at 7 days (proposed). However, the joint forensic panel that is supposed to resolve contested equipment-identity disputes is not yet recruited, empowered or pre-authorized. The forensic-panel mandate, corroboration hierarchy and decision-authority are not embedded in the bilateral instrument. If a divergence occurs (e.g., national ledgers disagree on an equipment identity claim) and no forensic panel exists or is not empowered to decide, the clock expires and the site is automatically suspended, appearing to fail a working mechanism rather than reflecting a real identity failure.

### 3.6.B Tags

- forensic-panel-missing
- deadlock-authority-undefined
- automatic-suspension-premature
- spurious-stop-outcome
- ledger-reconciliation-stalled

### 3.6.C Mitigation

By Month 0.5 (2026-10-23 17:00), recruit and pre-vet a joint forensic-identity panel of 3–5 senior specialists per country (total 6–10 members), with full counterintelligence clearance from both governments. Embed the panel's mandate, corroboration hierarchy and decision-authority in the bilateral instrument by Month 1 (2026-11-08 17:00): panel issues findings within 48 hours; if consensus fails, co-chairs decide within 24 hours. Define the corroboration hierarchy in writing (e.g., 'attestation if both ledgers match > physical inspection + chain of custody > maintenance records > third-party logs'). Implement shift-boundary cross-signing: at every shift handover (08:00, 16:00, 24:00 UTC), mirrored inspectors jointly sign a ledger entry certifying no undisclosed divergences. Any divergence discovered is immediately recorded and escalated. Configure the ledger system to detect divergence within 2 hours and auto-alert; forensic panel investigates within 24 hours, issues finding within 48 hours. Lock these procedures in writing and test them on non-covered equipment by Month 4 (2027-02-08).

### 3.6.D Consequence

If forensic-panel authority is not pre-authorized and embedded in the bilateral instrument before the clock starts, the first contested equipment-identity divergence will stall. Impaired-confidence and automatic-suspension clocks will expire without resolution, triggering automatic site suspension that appears to be a mechanism failure (Stop) when it is actually a governance gap. This undermines credibility of the entire verification mechanism and damages reciprocal confidence.

### 3.6.E Root Cause

The plan describes ledger divergence handling as a protocol (detect, sync, resolve) but does not pre-authorize the governance body (forensic panel) that must resolve contested items. Divergence is an expected, high-probability scenario in any distributed system, so the decision-making authority and corroboration hierarchy must be locked before the clock, not improvised when a divergence occurs.

---

# 4 Expert: Counterintelligence Vetting and Inspector Conduct-Oversight Director

**Knowledge**: Bilateral personnel-vetting protocols, access-control and continuous-audit systems, inspector conduct rules and discipline escalation, rotation schedules to prevent espionage capture, information-barrier procedures

**Why**: Inspector counterintelligence approval is the critical-path entry condition (14-16 weeks, potentially 20+ if deprioritized) and determines whether at least 80% of the 434-FTE roster is approved by Month 5 (2027-03-08). The specialist would assess whether the proposed vetting timeline is realistic, whether the conduct-oversight protocol (three-tier infraction, joint conduct committee, monthly audits, quarterly rotation) is sufficiently tight to prevent espionage while maintaining inspector independence, and whether the access-log audit cycle (monthly within 10 days) can detect unauthorized zone access before it becomes a Stop incident.

**What**: Map the vetting timeline to each country's counterintelligence approval cycles and security-clearance backlogs, confirm that 434-FTE vetting can complete in 14-16 weeks with 20-30% surge buffer, design the quarterly rotation schedule to prevent site-specific familiarity without creating coverage gaps, and establish the monthly access-log audit procedure with thresholds for immediate investigation of out-of-scope zone access.

**Skills**: Counterintelligence personnel vetting, access-control system design and audit, inspector rotation and conflict-of-interest prevention, continuous access-log analysis, conduct-investigation protocols, security-clearance reciprocal recognition

**Search**: bilateral inspector vetting protocol, counterintelligence access control audit, personnel rotation espionage prevention, conduct investigation procedures for verification inspectors

## 4.1 Primary Actions

- By Month 0.5 (2026-10-23 17:00), establish a bilateral entry-conditions steering committee with weekly co-chair meetings, decompose every domestic legislative or executive act required in each country, identify the critical-path item per country, and obtain signed domestic-authority leads from each government. Escalate any item delayed >4 weeks within 2 working days to co-chairs with a written fallback proposal. Document all decisions in the project ledger.
- By Month 0.5 (2026-10-23 17:00), complete bilateral negotiations to pre-bind the top 8–12 critical vendors (manufacturers, maintenance, logistics) at each participating site to cooperation agreements, including attestation disclosure within 2 business days, maintenance-record preservation, inspector access, and penalty clauses (USD 0.5–2.0M per material refusal). Obtain countersignatures for ≥80% of Tier 1 vendors.
- By Month 1 (2026-11-08 17:00), recruit, vet and pre-authorize a joint forensic-identity panel (3–5 specialists per country, total 6–10), codify a divergence-resolution hierarchy in the bilateral instrument (e.g., attestation > physical inspection > records > third-party logs), and configure the ledger system for automatic divergence detection within 120 minutes with panel findings within 48 hours. Implement shift-handover cross-signing of ledger entries by mirrored inspectors at every 8-hour boundary (08:00, 16:00, 24:00 UTC).
- By Month 1 (2026-11-08 17:00), pre-qualify a pool of 3–5 independent examiners per country and 2 clean-room facilities per geography (≥8 facilities total) with signed access/confidentiality agreements, confirmed cost per exam (USD 20,000–50,000), and minimum 5 parallel exams per week per facility. Lock the vendor-refusal escalation protocol (Day 0–10 ladder with unverifiable classification at Day 10) in the bilateral instrument by Month 2.5 (2026-12-23 17:00).
- By Month 1 (2026-11-08 17:00), codify a conditional-start fallback in the bilateral instrument permitting Phase One to begin at each site independently once that site's entry conditions are met, while the final Go/Modify/Stop decision requires all matched sites to complete 90 days. Obtain signed co-chair acceptance of this fallback before Month 1.5 (2026-11-23 17:00).
- By Month 1.5 (2026-11-23 17:00), conduct a bilateral site-boundary survey with both countries' security teams and operators; physically mark the zone perimeter with painted lines, signage, and photographic documentation; produce a signed photo record approved by both co-chairs. Implement access-control gates with real-time logging to both ledgers at every zone entry point.
- By Month 2 (2026-12-08 17:00), initiate a contingency-funding review meeting both treasuries to address the USD 15M shortfall (estimated) between the USD 515M worst-case contingency exposure and the USD 500M reserve. Propose fast-lane contingency release rules (up to USD 50M on joint signature within 5 business days) and decide whether to request supplemental appropriation, reallocate from other envelopes, or accept reduced surge margin.
- By Month 2.5 (2026-12-23 17:00), commission the independent testing unit to design a calibration-exercise scenario suite (≥50–100 events per site) covering unreported arrivals, substitutions, record falsification, vendor refusal and reluctant-operator scenarios, all using blind methodology (sealed double-key schedule, minimal advance notice). Confirm 100–150 non-covered equipment units per site reserved for calibration use.
- By Month 3 (2027-01-08 17:00), establish an explicit operational ledger-forensics workflow: any divergence detected within 120 minutes triggers notification to the forensic panel within 15 minutes; panel investigation concludes within 48 hours; if no consensus, co-chairs decide within 24 hours; outcome recorded in both ledgers; unresolved divergence >7 days triggers automatic suspension or impaired-confidence status per the bilateral instrument.

## 4.2 Secondary Actions

- By Month 0.5 (2026-10-23 17:00), initiate counterintelligence vetting of 120–150 candidate inspectors per country (14–16 weeks, or 20+ if deprioritised); vetting must complete 4 weeks before Phase One clock start (target Month 5 = 2027-03-08). Nominate domestic-authority leads for each country's vetting agency to ensure expedited review and escalation of delays.
- By Month 1 (2026-11-08 17:00), establish a joint bilateral Inspector Conduct Committee with equal national co-chairs, empowered to approve or veto inspectors within 5 working days, investigate misconduct within 48 hours, and recommend action within 72 hours. Codify conduct rules in the bilateral instrument with photographic zone-boundary appendix and three-tier infraction protocol (Tier 1: warning + retraining; Tier 2: removal within 5 working days; Tier 3: immediate removal).
- By Month 1 (2026-11-08 17:00), implement continuous access-log audit infrastructure: every inspector wears a badged access card logging zone entry/exit to both national ledgers in real time. Monthly audits (independent auditor per country, within 10 days of month-end) compare claimed activities against actual zone times; any unexplained access triggers investigation within 24 hours.
- By Month 1.5 (2026-11-23 17:00), design a ledger-system resilience test (simulate 8-hour network outage, single-ledger crash, cryptographic-key unavailability) to verify that both ledgers recover from backup within 6 hours, cryptographic validation succeeds upon recovery, and no records are lost or corrupted. Document recovery time, integrity-check results and correct any gaps by Month 2 (2026-12-08 17:00).
- By Month 1.5 (2026-11-23 17:00), conduct a bilateral key ceremony in a mutually agreed secure facility to generate and distribute split-key material for ledger entry signing. Document the ceremony with video, witness signatures and tamper-evident seals on all key-storage hardware. Both governments retain encrypted offline backups in separate vaults with 30-day recovery time.
- By Month 2 (2026-12-08 17:00), schedule a flagship intake-to-exit demonstration scenario (one high-consequence equipment class verified from arrival through disposal) for rehearsal in calibration (Months 4–5 = 2027-02-08 to 2027-03-08) and staging in Phase One. Coordinate between the independent testing unit and both technical leads; confirm identity-confirmation method and disposition without IP exposure.
- By Month 2.5 (2026-12-23 17:00), design a daily automated divergence-detection and alert workflow: both national ledgers run cryptographic hash comparison every 4 hours; divergence alert within 120 minutes; forensic-panel notification within 15 minutes; investigation finding within 48 hours; escalation to co-chairs if panel consensus fails within 48 hours.
- By Month 3 (2027-01-08 17:00), finalize the provisional Go/Modify/Stop thresholds (detection ≥90% unreported arrivals / 85% substitutions / 80% record falsification, false positives <5%, parity ±20%, unverifiable <5% per site, zero unresolved divergence >7 days) with documented justifications and validation methods agreed by both co-chairs. Mark all thresholds as 'provisional, validated in calibration' in the bilateral instrument.
- By Month 3.5 (2027-01-23 17:00), confirm that domestic access authority is enacted in both countries and independently certified by each government. Escalate any gaps to co-chairs immediately; if gaps remain unresolved after 2 weeks, invoke the conditional-start fallback and document the delay in the project ledger.
- By Month 4 (2027-02-08 17:00), execute a full ledger-system stress test on non-covered equipment at each participating site, simulating unreported arrival, substitution, record falsification, delayed access, disputed identity, vendor refusal and reluctant-operator scenarios. Document detection results by scenario type, false-positive rate, unverifiable-equipment count, and reconciliation time. Provide raw results to the independent testing unit for threshold calibration.
- By Month 5 (2027-03-08 17:00), confirm that all planned inspectors (target ≥80% of roster, 100% of critical posts) are counterintelligence-approved and have signed zone-conduct acknowledgments. Any vacant posts must be filled from a pre-approved bench within 2 weeks or escalate to co-chairs for authorization of temporary staffing or reduced coverage.
- By Month 5.5 (2027-03-23 17:00), execute calibration exercises (≥50–100 scenarios per site across 7 event types) on non-covered equipment, scoring results using the pre-agreed corroboration rule. Document detection rates by event type, false-positive rate, unverifiable count, and confidence intervals. By Month 5.5 (2027-03-23 17:00), double-key lock all Go/Modify/Stop thresholds and justifications; mark as 'validated' in the ledger; permit no changes except through recorded protocol-change procedures.
- By Month 5.5 (2027-03-23 17:00), obtain signed bilateral co-chair certification that all 7 entry conditions (instrument, appropriations, domestic authority, sites, inspectors, operator/vendor agreements, equipment schedule) are fully satisfied. If any condition is incomplete, escalate within 2 working days and document the gap; conditional-start fallback applies if gaps persist beyond Month 6 (2027-04-08).
- By Month 6 (2027-04-08 17:00), obtain double-key co-chair certification that Phase One clock is starting; record the official start date and time in both national ledgers with cryptographic signatures. Confirm that all 434 FTE (217 per country) are on duty or on-call for surge; all systems (ledger, attestation, zone access-control, evidence redaction) are operational; and the independent testing unit is standing by with the sealed exercise schedule.

## 4.3 Follow Up Consultation

Next meeting: Month 0.25 (2026-10-16 09:00). Agenda: (1) Status of bilateral entry-conditions steering committee and domestic-authority decomposition per country, with named leads and escalation protocol. (2) Progress on vendor pre-binding negotiations: number of Tier 1 vendors contacted, tentative cooperation-agreement language, and counterpart concerns. (3) Inspector vetting status: number of candidates submitted per country, expedited-review requests filed with counterintelligence agencies, and any anticipated delays beyond Month 5 (2027-03-08). (4) Forensic-panel recruitment: identified candidates per country, vetting status, and proposed decision hierarchy draft. (5) Examiner pre-qualification: candidate labs identified, cost estimates confirmed, and capacity commitments obtained. (6) Contingency-funding exposure: preliminary analysis of whether the USD 15M shortfall requires supplemental appropriation or envelope reallocation. (7) Conditional-start fallback draft language for bilateral instrument. Items 1–3 and 5–7 must reach 80% completion by Month 1 (2026-11-08) or the Phase One start will slip and contingency holding costs will accrue.

## 4.4.A Issue - Domestic Authority Enactment Timeline Is Not Decomposed; Unilateral Veto Risk Over Phase One Clock Start

The project plan lists 'domestic access authority enacted Month 3.5 (2027-01-23)' as an entry condition, but provides no country-specific decomposition of required legislative acts, approval bodies, or realistic enactment timelines. No fallback exists if one government's authority process delays >4 weeks. This hands the slower government an effective timing veto: if China's State Council directive or US Congressional ratification lags, the entire Phase One clock start slips, accumulating USD 50–100M/month in holding costs and compressing pre-test calibration. The project plan acknowledges the risk but does not mitigate it.

### 4.4.B Tags

- entry-condition-timing-veto
- domestic-authority-decomposition-missing
- unilateral-delay-risk
- holding-cost-exposure

### 4.4.C Mitigation

Execute immediately: (1) By Month 0.5 (2026-10-23 17:00), identify every domestic legislative or executive act required in each country and map it through approval bodies and timelines (e.g., US: Senate Foreign Relations Committee ratification, Congressional appropriation; China: State Council directive + Ministry of Industry designation). (2) Establish a bilateral entry-conditions steering committee with both co-chairs meeting weekly starting Month 0 (2026-10-08), with signed action-item assignments and a named domestic-authority lead per country accountable for timelines. (3) Codify a conditional-start fallback in the bilateral instrument by Month 1 (2026-11-08 17:00), permitting the clock to begin at each site independently if that site's entry conditions are met, while the final Go/Modify/Stop decision requires all matched sites to complete 90 days. (4) Define escalation: if any authority is delayed >4 weeks beyond baseline, political escalation to co-chairs within 2 working days with a written fallback proposal.

### 4.4.D Consequence

Without decomposition and escalation, a single country's domestic process lag (common in legislative review) defers the entire Phase One start indefinitely or forces compressed calibration and premature threshold locking on unvalidated provisional data. The Month 9 (2027-07-08) backstop only requires a co-chair extend-or-stop decision, which could itself deadlock. Holding costs accumulate USD 50–100M/month. The project appears to fail before the test even starts, damaging credibility and potentially triggering Stop at the gate.

### 4.4.E Root Cause

The project plan treats entry conditions as binary (met or not) without addressing the staggered, asynchronous nature of bilateral domestic processes. No mechanism exists to isolate one country's delay from the other's readiness. The conditional-start fallback is mentioned in the strategic decisions but not locked into the bilateral instrument or the entry-gate certification process. There is no owner or timeline for decomposing domestic acts or managing the weekly steering.

## 4.5.A Issue - Ledger Divergence Forensic Authority Is Not Pre-Authorized; Disputes Will Trigger Automatic Suspension Cascades

The project plan defines automatic suspension at 7 days of unresolved ledger divergence and Tier 2/3 clock expiry, but does not pre-authorize a joint forensic-identity panel or specify its decision-making authority. Without pre-agreed identity-corroboration hierarchy and a panel empowered to issue binding findings within 48 hours, divergence clocks will expire and trigger automatic suspension. This creates a feedback loop: a technical sync fault (e.g., one ledger's timestamp off by 5 minutes) becomes a Tier 2 or Tier 3 escalation, the panel is never constituted before the deadline, automatic suspension fires, and the mechanism appears to fail when it is functioning. The Go/Modify/Stop decision could turn on administrative gaps rather than detection performance.

### 4.5.B Tags

- ledger-divergence-no-authority
- automatic-suspension-cascade-risk
- forensic-panel-missing
- identity-corroboration-hierarchy-undefined

### 4.5.C Mitigation

Execute immediately: (1) By Month 0.5 (2026-10-23 17:00), recruit and pre-vet a joint forensic-identity panel of 3–5 senior technical specialists per country (total 6–10 members), each holding counterintelligence clearance and approved by the counterpart. (2) By Month 1 (2026-11-08 17:00), codify a divergence-resolution hierarchy in the bilateral instrument: if ledgers disagree on equipment identity or event timing, the panel evaluates evidence by layer in decreasing order of independence (e.g., cryptographic attestation if both ledgers match > physical inspection + chain of custody > maintenance records > third-party logs). Equipment identity is confirmed only if the highest-ranked available layer agrees across both ledgers. (3) Implement shift-handover cross-signing: at every 8-hour shift boundary (08:00, 16:00, 24:00 UTC minimum), mirrored inspectors jointly certify prior-shift events and flag undisclosed divergences within 2 hours. (4) Configure ledger system for automatic divergence detection within 120 minutes; escalate to panel within 15 minutes; target panel finding within 48 hours.

### 4.5.D Consequence

Without pre-authorization and hierarchy, the forensic panel cannot issue timely identity findings. Divergence clocks expire, automatic suspension fires, and the project is suspended on technical grounds rather than detection failure. Co-chairs may blame each other for not preventing the cascade. The final decision becomes uninterpretable: does Stop reflect the mechanism's real performance or a procedural gridlock? Reciprocal trust collapses, and Phase Two extension is rejected.

### 4.5.E Root Cause

The project plan defines the escalation clock (48-hour panel finding) but does not pre-authorize the panel, define its membership, or lock its decision hierarchy before the clock starts. No one owns forensic-panel recruitment or hierarchy codification. The shift-handover cross-signing is mentioned as Ledger Divergence Handling (Decision 7) but is not operationalized in the project schedule or assigned to a team. Automatic suspension is treated as a stop-gap rather than a last resort, and no rehearsal of divergence scenarios occurs before Phase One.

## 4.6.A Issue - Vendor Refusal Escalation Paths and Independent-Examiner Pre-Qualification Are Not Confirmed; Material Equipment Will Be Unverifiable by Month 3–4 (2027-01-08 to 2027-02-08)

The project plan specifies a vendor-refusal ladder (request → escalation → examiner notified → exam → report by day 10) and requires independent-examiner pre-qualification by Month 4 (2027-02-08). However, no bilateral negotiations have been conducted to pre-bind Tier 1 vendors (critical manufacturers, maintenance providers), and no examiner pool has been identified, contracted or confirmed available at scale. If top 8–12 vendors per site refuse attestation disclosure or maintenance records and no examiners are pre-qualified, material equipment will be classified unverifiable starting Month 3–4 (2027-01-08 onwards). The project plan permits unverifiable equipment <5% per site as a Go threshold, but cascading refusals will exceed 10%, triggering Stop at each site. The contingency worst case already exposes USD 515M against a USD 500M reserve; late examiner engagement adds USD 3.6–11.2M in overruns (estimate).

### 4.6.B Tags

- vendor-pre-binding-missing
- examiner-pool-not-qualified
- unverifiable-equipment-threshold-at-risk
- contingency-shortfall-usd-15m

### 4.6.C Mitigation

Execute immediately: (1) By Month 0.5 (2026-10-23 17:00), complete bilateral negotiations to pre-bind the top 8–12 manufacturers and logistics vendors at each participating site to cooperation agreements, binding each vendor to: equipment-identity attestation within 2 business days; maintenance-record preservation and evidence escrow 90 days post-departure; inspector escort and site access during Phase One; penalty clauses (USD 500,000–2,000,000 per material refusal, loss of future market access). Obtain countersignatures for at least 80% of Tier 1 vendors. (2) By Month 1 (2026-11-08 17:00), pre-qualify a pool of 3–5 independent examiners per country and 2 accredited clean-room facilities per geography (target: 4 geography regions = 8 facilities total) capable of equipment-identity verification without vendor cooperation. Require signed access and confidentiality agreements. Confirm cost per examination (target USD 20,000–50,000) and minimum 5 parallel examinations per week per facility. (3) Lock vendor-refusal escalation protocol in the bilateral instrument before clock start (by Month 2.5 = 2026-12-23 17:00): Day 0–1 operator escalates to co-chairs if vendor declines; Day 2 bilateral team notifies examiner; Day 5 exam complete; Day 10 report due. If no evidence by Day 10, equipment marked unverifiable with vendor-refusal reason logged.

### 4.6.D Consequence

Without pre-bound vendors and pre-qualified examiners, material equipment becomes unverifiable at multiple sites starting Month 3–4 (2027-01-08 to 2027-02-08). Unverifiable percentages exceed the <5% Go threshold, triggering Stop verdicts at otherwise-functioning sites. Contingency depletes by USD 11M+ in late-engagement examiner costs, with no surge margin remaining (estimated shortfall USD 15M). Co-chairs blame each other for failing to secure vendor cooperation. The project is stopped not by detection failure but by vendor refusal cascades, damaging the bilateral relationship and the mechanism's credibility.

### 4.6.E Root Cause

Vendor pre-binding is treated as an operator/legal task (assigned to 'operators and bilateral legal units' in the SWOT) but has no owner, bilateral negotiation lead, or deadline before Month 4 (2027-02-08). Examiner pre-qualification is mentioned as required but is not resourced or assigned. The risk is acknowledged in the contingency worst case but no mitigation action is listed in the project plan's primary or secondary actions. Month 0.5 (2026-10-23) and Month 1 (2026-11-08) deadlines are proposed in the SWOT but not integrated into the project schedule or budget tracking.

---

# 5 Expert: Domestic Legislative and Appropriations Authority Specialist

**Knowledge**: US Congressional authorization and appropriations law, China State Council delegation and budget procedure, bilateral instrument ratification, inspector immunity statutes, export-control and technology-transfer authorization, domestic access-authority enactment timelines

**Why**: Domestic-authority enactment is the critical-path entry condition (targeted Month 3.5 = 2027-01-23) and the SWOT analysis identifies delays as a major threat (USD 50-100M per month holding cost, potential 3-month slip to Month 9 = 2027-07-08 backstop). The specialist would decompose each required legal act by country, map approval cycles, and validate whether the Month 3.5 (2027-01-23) target is realistic or whether a fallback conditional-start provision is essential.

**What**: By Month 0 (2026-10-08), document every specific US and Chinese legislative or executive act needed: US Congressional authorization of the bilateral instrument, inspector immunity, domestic access authority to compel operator participation, export-control and technology-transfer waivers; China State Council directive and enforcement delegation to a named ministry with operator-participation authority. Identify the critical-path bottleneck in each country and flag any item likely to slip >4 weeks past baseline.

**Skills**: Legislative drafting and procedural law, Congressional and parliamentary procedure, budget authorization and appropriations cycles, ratification and treaty implementation, counterintelligence clearance coordination, export-control and sanctions law, domestic-authority delegation and enforcement mechanisms

**Search**: US Congressional authorization appropriations procedure, China State Council administrative delegation, bilateral treaty ratification domestic implementation, inspector immunity statutes

## 5.1 Primary Actions

- By Month 0 (2026-10-08 16:00), decompose every required domestic legislative or executive act per country into specific bills, approving bodies, and realistic enactment windows. Establish a bilateral entry-conditions steering committee with weekly co-chair meetings and named domestic-authority leads accountable for each government's timeline. Map each authority through its approval process and identify the single-item critical path. If any authority slips >4 weeks, trigger political escalation within 2 working days.
- By Month 0.5 (2026-10-23 17:00), pre-draft a conditional-start fallback into the bilateral instrument permitting Phase One to begin at each site once that site's entry conditions are met, rather than requiring all conditions simultaneously. Obtain both governments' signed acceptance of this fallback by Month 1 (2026-11-08). This removes the timing veto and keeps the strict gate meaningful without indefinite delay.
- By Month 0.5 (2026-10-23 17:00), identify the top 8-12 vendors per proposed participating site and conduct bilateral negotiations to pre-bind every Tier-1 vendor (critical to site success) to a cooperation agreement including attestation disclosure, record preservation, and penalty clauses (USD 500k-2M per material refusal). Obtain countersigned agreements for at least 80% of Tier-1 vendors by Month 1 (2026-11-08).
- By Month 1 (2026-11-08 17:00), pre-qualify at least 3-5 independent examiners per country and 2 accredited clean-room facilities per geography capable of equipment-identity verification without vendor cooperation. Require each to sign confidentiality and scope agreements and confirm cost per exam (USD 20-50k target) and parallel-exam capacity (minimum 5 per week per facility). Publish the examiner pool membership and day-10 vendor-refusal ladder before the clock starts (by Month 3 = 2027-01-08).
- By Month 0.5 (2026-10-23 17:00), recruit and pre-vet a joint forensic-identity panel of 3-5 senior technical specialists per country (total 6-10 members). Each must hold counterintelligence clearance and be approved by the counterpart. By Month 1 (2026-11-08 17:00), codify a divergence-resolution hierarchy in the bilateral instrument (e.g., 'attestation if both ledgers match > physical inspection + chain of custody > maintenance records > third-party logs'). Require the forensic panel to issue identity findings within 48 hours; if consensus fails, co-chairs decide within 24 hours.
- By Month 1 (2026-11-08 17:00), implement shift-boundary cross-signing by mirrored inspectors at every shift handover (minimum 3 daily: 08:00, 16:00, 24:00 UTC). Each cross-signing must certify that prior-shift events have been reviewed and no undisclosed divergences found. Any divergence discovered is recorded immediately with both signatures and escalated within 2 hours. Configure the ledger system for automatic divergence detection and alert within 120 minutes of any discrepancy in event timing, identity or sequence numbers.

## 5.2 Secondary Actions

- By Month 0.5 (2026-10-23 17:00), establish a vendor-refusal escalation protocol locked in writing before the clock starts: Day 0 operator requests vendor cooperation; Day 1 operator escalates to co-chairs if vendor declines; Day 2 bilateral team notifies pre-qualified independent examiner; Day 5 examiner completes on-site inspection; Day 10 report submitted. If no evidence is produced by Day 10, equipment is marked unverifiable and logged in the ledger with vendor-refusal details.
- By Month 1 (2026-11-08 12:00), initiate counterintelligence vetting of all candidate inspectors (at least 120-150 per country) with explicit request for expedited review and clearance completion 4 weeks before Phase One clock start (by Month 5 = 2027-03-08). Establish a joint bilateral Inspector Conduct Committee with equal co-chairs empowered to approve/veto inspectors, investigate misconduct within 48 hours, and recommend removal within 72 hours.
- By Month 1.5 (2026-11-23 17:00), conduct a bilateral pre-clock site-boundary survey with both countries' security teams, operators and inspectors present. Physically mark the zone perimeter with painted lines, permanent signage and photographic documentation. Document the marked boundary in a signed photographic record approved by both co-chairs. Install access-control gates at zone entry points with proximity-card readers logging every entry/exit to both national ledgers in real time.
- By Month 1.5 (2026-11-23 17:00), reserve at least 100-150 units of non-covered equipment per participating site (surplus, refurbished or decommissioned, not in active use) for pre-clock calibration. Commission the independent testing unit to design a calibration scenario suite including unreported arrivals, substitutions, record falsification, vendor refusals and reluctant-operator events (50-100 events per site). Execute calibration Months 1-2 (2026-11-08 to 2026-12-08).5 (2026-11-08 to 2026-12-23) and lock all Go/Modify/Stop thresholds via double-key co-chair signature by Month 3 (2027-01-08 17:00).
- By Month 0.5 (2026-10-23 17:00), design the ledger system with mandatory components: two independent air-gapped national copies, secure communications link with <60-minute sync target, redundant backup paths, and split-key cryptographic signing so no single country can unilaterally insert records. Conduct a bilateral key ceremony by Month 1.5 (2026-11-23 09:00) to generate and distribute split keys. Conduct a ledger resilience test (simulating outage, crash, key unavailability) by Month 0.5 (2026-10-23 17:00); complete corrections by Month 1 (2026-11-08).
- By Month 3 (2027-01-08 17:00), codify zone-boundary rules and violation escalation in the bilateral instrument with reference to the marked physical boundary. Define a three-tier infraction protocol: Tier 1 (minor, first offense) = written warning + re-training within 48 hours; Tier 2 (moderate, repeated) = formal notice, joint review, proposed removal within 5 working days; Tier 3 (material espionage risk) = immediate removal without co-chair review. Require every inspector to sign a zone-conduct acknowledgment before Phase One clock starts.
- By Month 1 (2026-11-08), review the preliminary contingency-exposure estimate (USD 515M worst case, exceeding the USD 500M reserve by ~USD 15M). Escalate to both treasuries at the Month 3 (2027-01-08) appropriations review with options: increase contingency pool, front-load examiner pre-qualification to reduce cost uncertainty, or implement a fast-lane spending authority up to USD 50M on joint signature within 5 business days.

## 5.3 Follow Up Consultation

Next consultation should cover: (1) Confirmation that both governments have named their domestic-authority leads and scheduled the first entry-conditions steering-committee meeting (Month 0 = 2026-10-08, Week 1). (2) Status of bilateral negotiations with Tier-1 vendors (Month 0.5 target = October 23) and examiner pre-qualification outreach (law firms, lab directors contacted, initial responses). (3) Forensic-panel recruitment progress and draft divergence-resolution hierarchy (in writing for bilateral instrument review). (4) Ledger design finalization, key-ceremony logistics and date confirmation. (5) Inspector counterintelligence vetting initiation and any clearance-processing bottlenecks or prioritization gaps. (6) Confirmation that the conditional-start fallback has been pre-drafted into the bilateral instrument and circulated for comment. (7) Reconciliation of the contingency-exposure gap (USD 15M shortfall estimate) and any treasuries' guidance on fast-lane or reserve augmentation.

## 5.4.A Issue - Domestic Authority Enactment Timeline Lacks Decomposition and Fallback Authority

The plan treats 'domestic access authority enacted (Month 3.5 = 2027-01-23)' as a single milestone, but does not decompose it into country-specific legislative or executive acts, approval bodies, or realistic enactment windows. Without this decomposition, either government's legislative delay becomes a unilateral veto over the Phase One clock start. The Month 9 (2027-07-08) backstop only forces an extend-or-stop decision; it does not prevent indefinite delay. No fallback authority—such as executive order, emergency delegation, or conditional-start trigger—is pre-authorized. If US ratification slips 8 weeks but China completes on time, the project either stalls or the strict gate is violated.

### 5.4.B Tags

- domestic_authority_decomposition_missing
- unilateral_veto_risk
- no_fallback_authority
- gate_delay_exposure

### 5.4.C Mitigation

By Month 0 (2026-10-08 16:00), identify every required domestic act per country (e.g., US Senate ratification, appropriations bill, inspector-immunity statute; China State Council directive). Map each through its approval process and committee calendar. By Month 0.5 (2026-10-23 17:00), establish a bilateral entry-conditions steering committee with weekly co-chair meetings and named domestic-authority leads. Pre-draft a conditional-start fallback into the bilateral instrument permitting Phase One to begin at each site once that site's entry conditions are met, not requiring all conditions simultaneously. Obtain both governments' signed acceptance by Month 1 (2026-11-08). This removes the timing veto and keeps the gate meaningful without stalling the clock.

### 5.4.D Consequence

Without decomposition and fallback authority, a 4-8 week legislative slip in one country could defer Phase One from Month 6 (2027-04-08) to Month 9 (2027-07-08) or force the extend-or-stop decision to extend without clarity. Holding cost is USD 50-100M per month (estimate), so a 3-month slip = USD 150-300M against contingency, leaving <USD 200M for vendor refusals, examiner overruns and exercise incidents. The strict gate loses its protection against setup failures being logged as verification failures if it is repeatedly extended without resolution.

### 5.4.E Root Cause

The plan's section 'Entry Conditions Milestones' lists authority enactment as a single Month 3.5 (2027-01-23) date without country-level detail or fallback logic. The project-plan dependencies say 'domestic access authority enacted (Month 3.5 = 2027-01-23)' without specifying which acts, approving bodies, or real timelines. The SWOT Analysis mentions 'Domestic legislative or administrative delays' as a threat but proposes only a weekly review, not decomposition or fallback. The canonical facts include 'entry_conditions_milestones' but do not break out authority enactment by country or mechanism.

## 5.5.A Issue - Ledger Divergence Forensic Authority and Reconciliation Procedures Not Pre-Authorized

The plan specifies that ledger divergence is detected within 2 hours and unresolved divergence >7 days triggers automatic suspension, but it does not pre-authorize a joint forensic-identity panel, define their evidence-weighting hierarchy, or specify how co-chairs resolve a forensic deadlock. The canonical facts mention 'ledger_identity_forensics: Joint forensic panel (3-5 specialists per country…)' as a decision, but the bilateral instrument, staffing, authority delegation, and reconciliation procedures are not confirmed. Without this pre-authorization, a disputed equipment-identity entry or divergence in event timing could expire under the 7-day clock with no authorized decision-maker empowered to resolve it, triggering automatic suspension of a site or event class even when the mechanism is functioning correctly.

### 5.5.B Tags

- forensic_panel_not_pre_authorized
- reconciliation_hierarchy_undefined
- divergence_clock_deadlock_risk
- automatic_suspension_without_remedy

### 5.5.C Mitigation

By Month 0.5 (2026-10-23 17:00), recruit and pre-vet a joint forensic-identity panel of 3-5 senior technical specialists per country (total 6-10 members). Each must hold counterintelligence clearance and be approved by the counterpart. By Month 1 (2026-11-08 17:00), codify a divergence-resolution hierarchy in the bilateral instrument using a pre-agreed corroboration ladder (e.g., 'if attestation diverges but physical inspection matches, accept physical inspection; if physical differs, request independent examiner arbitration'). Require the forensic panel to issue findings within 48 hours; if consensus fails, co-chairs decide within 24 hours. Implement shift-boundary cross-signing by mirrored inspectors at handover (3 times daily minimum) so divergences are detected and escalated within hours, not days.

### 5.5.D Consequence

Without pre-authorized forensic authority and a locked hierarchy, a contested equipment-identity entry or a sync discrepancy lasting >7 days will trigger automatic suspension of the affected site or event class without a legitimate decision-maker empowered to resolve it. The suspension will appear to fail the mechanism even when divergence is a technical fault, not concealment. This turns administrative procedure into a spurious Stop condition, undermining the Go/Modify/Stop verdict and wasting USD 50-100M/month in held cost if the mechanism is then extended to resolve the frozen decision.

### 5.5.E Root Cause

The plan's 'Ledger Divergence Handling' decision (Decision 7) proposes three strategic choices but does not select one. The canonical facts include 'ledger_identity_forensics' and 'deadlock_definition,' which sketch a forensic panel and a neutral referee, but the bilateral instrument, vetting, authority delegation, and 48-hour procedures are not confirmed as pre-authorized before Month 0 (2026-10-08). The project-plan dependencies list 'ledger operational and stress-tested (Month 4 = 2027-02-08)' but do not require forensic-panel recruitment or authority delegation before the clock starts.

## 5.6.A Issue - Vendor Refusal Escalation Paths and Independent-Examiner Pre-Qualification Not Confirmed

The plan specifies a vendor-refusal ladder (day-0 request through day-10 report, then clean-room or validated attestation, then unverifiable) and a fallback pool of '3-5 independent examiner labs per country and 2 clean-room facilities per geography,' with agreements signed by Month 4 (2027-02-08). However, the actual pool membership, examiner pre-qualification status, cost per examination, and readiness to begin work by Month 3 or 4 (2027-01-08, 2027-02-08) are not confirmed. If critical vendors refuse and independent examiners are not pre-qualified and contracted, equipment will be classified unverifiable at day 10, accumulating within the first 30 days of Phase One. Unverifiable equipment >5% per site triggers a Stop condition, and >10% fails the site outright. The plan carries no evidence that examiners capable of equipment-identity verification without vendor cooperation exist, are willing to work under Consortium rules, or have capacity for 20-40 exams per site in 90 days.

### 5.6.B Tags

- vendor_fallback_pool_unconfirmed
- examiner_pre_qualification_not_validated
- unverifiable_equipment_cascade_risk
- stop_condition_exposure

### 5.6.C Mitigation

By Month 0 (2026-10-08 16:00), identify the top 8-12 vendors per proposed site (manufacturers, maintenance providers, logistics firms) and rank by dependency. By Month 0.5 (2026-10-23 17:00), conduct bilateral negotiations to pre-bind every Tier-1 vendor (failure means site fails) to a cooperation agreement including attestation disclosure, record preservation, and penalty clauses (USD 500k-2M per material refusal). Obtain countersigned agreements for at least 80% of Tier-1 vendors by Month 1 (2026-11-08). By Month 1 (2026-11-08 17:00), pre-qualify at least 3-5 independent examiners per country and 2 accredited clean-room facilities per geography. Require each to sign confidentiality and scope agreements and confirm cost per exam (USD 20-50k target) and capacity (minimum 5 parallel exams per week per facility). Publish the day-10 refusal ladder and examiner pool membership before the clock starts.

### 5.6.D Consequence

If pre-qualification is not completed by Month 1 (2026-11-08), Tier-1 vendor refusals in Months 3-4 (2027-01-08 to 2027-02-08) will have no examiner fallback ready. Equipment will accumulate unverifiable status. By Month 6 (2027-04-08), if even one site has >5% unverifiable equipment, that site cannot certify entry and the clock is delayed. If >10% is unverifiable, the site fails Phase One. This triggers Stop or extends the gate indefinitely. Examiner overruns (e.g., 40 exams at USD 50-100k each = USD 2M-4M per site, versus a USD 0.6-1.2M budget) consume contingency; worst-case contingency exposure rises from USD 515M to USD 525M-530M (estimate), exceeding the USD 500M reserve by USD 25M-30M.

### 5.6.E Root Cause

The canonical facts include 'vendor_fallback_pool: Pre-bind top 8-12 vendors per site; pool of 3-5 independent examiner labs per country and 2 clean-room facilities per geography, agreements signed by Month 4 (2027-02-08),' but this is after Phase One entry conditions are certified (Month 6 = 2027-04-08) and too late if Tier-1 refusals occur in Months 3-4 (2027-01-08 to 2027-02-08). The project plan lists 'Operator and vendor binding agreements in place (Month 4 = 2027-02-08)' as a dependency, but does not confirm that examiners are pre-qualified or that the fallback pool is operational before the gate is certified. The SWOT Threats section mentions 'Vendor refusal cascades leaving over 10% of equipment unverifiable at a site,' but the plan does not confirm that pre-mitigation (pre-binding, pre-qualification) will be complete by the gate deadline.

---

# 6 Expert: Frontier AI Equipment Classification and Schedule Governance Specialist

**Knowledge**: Frontier computing equipment architecture and evolution (GPUs, TPUs, custom accelerators, interconnects), manufacturer-neutral classification criteria, product-roadmap forecasting, covered-equipment schedule maintenance and amendment procedures, trade-secret protection in equipment documentation

**Why**: The covered-equipment schedule is deliberately manufacturer-neutral, versioned, and confidential, yet frozen from clock start to final decision (a decision that conflicts with hardware evolution over 90+ months). The specialist would assess whether a frozen schedule is defensible given the 30+ month project window (Month 0 = 2026-10-08 through Month 10 = 2027-08-08), identify which equipment classes are at risk of becoming obsolete mid-test, and propose amendment procedures that avoid threshold-gaming disputes while accommodating real hardware evolution.

**What**: By Month 0 (2026-10-08), draft a functional-risk-based schedule taxonomy (compute density FLOPS-per-watt, interconnect bandwidth, memory bandwidth, security attestation capability) that is manufacturer- and product-neutral, identify which equipment classes are present at candidate sites, forecast which classes will become obsolete during the 30+ month lifecycle, and propose amendment windows (e.g., Month 3 = 2027-01-08 before clock, Month 7 mid-test, Month 10 = 2027-08-08 post-decision) with double-key approval and change-log recording.

**Skills**: Semiconductor and accelerator architecture, equipment-roadmap forecasting, functional-specification development, manufacturer-neutral classification, trade-secret compartmentalization, versioning and change-control procedures, equipment-obsolescence risk assessment

**Search**: frontier AI accelerator equipment classification, GPU TPU architecture specifications, manufacturer neutral equipment taxonomy, equipment roadmap forecasting technology evolution

## 6.1 Primary Actions

- By Month 0 (2026-10-08 16:00): Establish a bilateral entry-conditions steering committee with equal national co-chairs, weekly meeting schedule, and documented action-item tracking. Each co-chair appoints a single domestic-authority lead; together, decompose all required legislative and executive acts per country (ratification, domestic access authority, inspector approvals, equipment schedule adoption) into specific bills, directives, committee schedules, and approval timelines. Identify the single-item critical path and any authority that is delayed >4 weeks beyond baseline; escalation rules: notify co-chairs within 2 working days with a written fallback proposal.
- By Month 0.5 (2026-10-23 17:00): Pre-draft a conditional-start fallback into the bilateral instrument, explicitly permitting Phase One clock to begin at each site once that site's entry conditions are met (rather than requiring all conditions simultaneously), with joint co-chair certification of the final Go/Modify/Stop decision. Obtain both governments' signed acceptance of this fallback before Month 1 (2026-11-08 17:00). Simultaneously, identify and rank (Tier 1, Tier 2, Tier 3) the top 8–12 critical vendors per participating site by dependency on attestation keys, maintenance access, and supply-chain custody.
- By Month 1 (2026-11-08 17:00): Conduct bilateral negotiations with every Tier 1 vendor and sign pre-Phase-One cooperation agreements binding each vendor to attestation disclosure within 2 business days, maintenance-record preservation for 90 days, inspector escort, and liquidated-damage penalties (USD 500k–2M per material refusal). Achieve signings for at least 80% of Tier 1 vendors. In parallel, pre-qualify and contract a pool of at least 3–5 independent examiners per country and at least 2 accredited clean-room facilities per geography, with documented cost per exam (target USD 20–50k) and parallel-exam capacity (minimum 5 per week per facility). Lock the vendor-refusal escalation protocol (day-10 ladder) in the bilateral instrument with documented owner and timeline.
- By Month 1 (2026-11-08 17:00): Recruit, pre-vet, and obtain mutual government approval for a joint forensic-identity panel of 3–5 specialists per country (6–10 total) with counterintelligence clearance. Codify a divergence-resolution hierarchy in the bilateral instrument: apply a pre-agreed evidence-weighting rule for contested equipment identity (e.g., 'cryptographic attestation if both ledgers match > physical inspection + chain of custody > maintenance records'). Define the forensic panel's authority: binding or co-chair-delegated findings within 48 hours; if no consensus, co-chairs decide within 24 hours. Specify shift-boundary cross-signing procedures at 08:00, 16:00, and 24:00 UTC daily, with both inspectors signing ledger entries certifying no undisclosed divergences in the prior shift.
- By Month 1.5 (2026-11-23 17:00): Conduct pre-clock site-boundary survey at each participating site with both countries' security teams, operators, and inspectors present. Physically mark the inspection zone perimeter with painted lines, permanent signage, and photographic documentation, encompassing staging, spare-inventory, maintenance, and expansion areas only. Produce a signed photographic record of the boundary, approved by both co-chairs. Implement access-control gates with proximity-card readers logging all entries to both national ledgers in real time. Install video recording in zones showing only equipment movement, identifiers, and seal status (not live-computation, workloads, or infrastructure).
- By Month 2 (2026-12-08 17:00): Codify all zone-boundary rules and violation escalation in the bilateral instrument, including the three-tier infraction protocol (Tier 1 = first offense warning + re-training within 48 hours; Tier 2 = formal notice + conduct-committee review + proposed removal within 5 days; Tier 3 = immediate removal for espionage/CI risk). Establish a zone-violation hot-line: alleged boundary infractions reported within 2 hours, acknowledged within 15 minutes, investigated within 24 hours, findings within 72 hours, disciplinary decision within 5 working days. Define monthly random-date boundary audits verifying access logs, video integrity, seals, and redaction procedures. Require every inspector to sign a pre-Phase-One zone-conduct acknowledgment on or before Month 3 (2027-01-08 16:00), certifying understanding of the boundary, prohibition on unauthorized photography, and the three-tier escalation protocol.
- By Month 4 (2027-02-08 17:00): Operationalize the ledger system: two independent national copies running on air-gapped infrastructure, connected by secure dedicated communications link (target sync latency <60 minutes), with redundant backup paths (satellite, courier). Implement offline cryptographic root-key custody: each government holds one half of a split master key; split-key signing on every entry. Conduct a bilateral key ceremony in person in a mutually agreed secure facility, with video recording, witness signatures, and tamper-evident seals on key-storage hardware. Configure automatic divergence detection and alert within 2 hours of any discrepancy in timing, identity, or sequence. Stress-test the entire ledger system on non-covered equipment, simulating network outages lasting 8 hours, system crashes, and key unavailability; verify recovery within 6 hours, integrity validation upon recovery, and zero record loss. Document recovery times and integrity-check results; correct any gaps by Month 1 (2026-11-08).

## 6.2 Secondary Actions

- By Month 0.5 (2026-10-23 17:00): Initiate counterintelligence vetting of all candidate inspectors (target 120–150 per country) with expedited-review request and explicit commitment that clearance must complete 4 weeks before Phase One clock start (by Month 5 = 2027-03-08). Establish a joint bilateral Inspector Conduct Committee with equal national co-chairs empowered to approve/veto inspectors, investigate misconduct within 48 hours, recommend action within 72 hours, and maintain monthly conduct reviews. Implement continuous access-log audit: every inspector wears a badge with swipe logs recorded on both national ledgers in real time; monthly review within 10 days of month-end by independent auditors from each country, comparing access logs against claimed activities. Require quarterly site rotation to remove familiarity and establish a shared-bench inspector pool of 20–30% surge/replacement buffer.
- By Month 1 (2026-11-08 17:00): Design the calibration exercise scenario suite on non-covered equipment (100–150 units per site, Months 4–5 = 2027-02-08 to 2027-03-08). Include at least 50–100 events per site covering: ≥10 unreported-arrival scenarios, ≥10 substitution scenarios (including internal modification), ≥10 record-falsification scenarios, ≥5 vendor-refusal scenarios, ≥5 reluctant-operator scenarios. All scenarios must use blind-exercise methodology (sealed double-key schedule, minimal advance notice). Execute calibration Months 4–5 (2027-02-08 to 2027-03-08); score using the fixed pre-agreed corroboration rule. By Month 2.5 (2026-12-23 17:00), document detection rates by event type (target: unreported arrivals ≥90%, substitutions ≥85%, record falsification ≥80%), false-positive rate (<5%), unverifiable-equipment count (<5%), and any threshold adjustments. Lock all Go/Modify/Stop thresholds and justifications via double-key co-chair signature by Month 3 (2027-01-08 17:00); mark all thresholds as 'validated' in the ledger.
- By Month 2 (2026-12-08 17:00): Commission the independent testing unit to design a full Phase One exercise schedule (sealed double-key, at most 2 sessions per site per month, all 7 event types covered, staging/spare/maintenance/expansion areas only, zero interruption of active computation). Finalize the flagship intake-to-exit demonstration scenario (one high-consequence equipment class with clean public-to-leadership demonstration potential); rehearse in calibration and stage as lead demonstration in Phase One. Define maintenance and third-party access scheduling: advance-notice requirement for all access, inspector presence at start/end of maintenance windows, sealed work areas during intervening periods, rapid-response emergency lane (>3 emergencies per month triggers review; >50% ruled non-emergency triggers escalation). Lock maintenance and emergency rules in the bilateral instrument.
- By Month 2.5 (2026-12-23 17:00): Complete all mandatory entry-condition reviews and certifications: instrument ratified, sites selected and ratified, appropriations secured, covered-equipment schedule adopted and frozen, domestic access authority enacted, operator and vendor binding agreements signed, inspectors approved (at least 80% roster + 100% critical posts), ledger operational and stress-tested, all thresholds locked. Identify and document any outstanding item older than 4 weeks; escalate to co-chairs with written fallback proposal. If any condition cannot be met by Month 6 (2027-04-08), invoke the Month 9 (2027-07-08) extend-or-stop backstop decision.
- By Month 3 (2027-01-08 17:00): Conduct independent audit of funding timeliness and spending against envelopes for both governments. Review contingency exposure (estimated USD 515M worst-case vs. USD 500M reserve, shortfall about USD 15M); raise gap at the appropriations review and propose mitigation (surge reduction, timeline extension, or additional contingency allocation). Establish quarterly milestone-based tranche reporting and monthly fiscal-accountability reports to treasuries.
- By Month 4 (2027-02-08 17:00): Complete the pre-qualification of all independent examiners and clean-room facilities; hold a joint bilateral test to verify that each facility can execute a full equipment-identity examination (cryptographic attestation, physical inspection, measurement, documentation) within the day-10 vendor-refusal ladder timeline. Document cost, staffing, and schedule availability. Establish a standing vendor-refusal escalation team at each site (operator, bilateral legal representative, examiner coordinator) empowered to notify pre-qualified examiners and track ladder timelines. Configure the ledger to automatically log every vendor-refusal event, escalation step, and disposition (unverifiable, examiner report, clean-room result).
- By Month 5 (2027-03-08 17:00): Verify that at least 80% of the planned inspector roster is approved and assigned to sites, and 100% of critical posts (shift lead, ledger operator, forensic panel member, zone auditor) are filled by counterintelligence-cleared, bilaterally approved personnel. Conduct final site-readiness reviews at each participating location: confirm zone boundaries are marked and access control operational, ledger copies are running and synchronized, forensic panel members are in place and trained, independent testing unit is staffed, and calibration exercise infrastructure is ready. Identify and resolve any outstanding gaps; escalate unresolved items to co-chairs with timeline and risk assessment.
- By Month 5.5 (2027-03-23 17:00): Lock all Go/Modify/Stop thresholds and their justifications via double-key co-chair signature. Mark all thresholds as 'calibrated and validated' in the ledger, with specific reference to calibration evidence (detection rates, false positives, unverifiable counts). Obtain co-chair agreement on which KPI failures are non-negotiable Stop conditions (e.g., unverifiable equipment >10% at a site, asymmetric access, evidence divergence unresolved, funding withheld, detection <70%). Document the decision rule as a written rubric with examples.
- By Month 6 (2027-04-08 09:00): Hold the formal Phase One entry-condition certification ceremony with both co-chairs, attestations from each government authority (legislative/executive signoff on domestic access, budget office confirmation of appropriations, counterintelligence agency confirmation of inspector approval, technical team confirmation of ledger and exercise readiness). Issue a joint certification that all 7 mandatory entry conditions are fully satisfied. Set the official Phase One clock start to Month 6 (2027-04-08 16:00 UTC). Brief all participating site teams on the clock start, exercise schedule, and final decision timeline (Month 10 = 2027-08-08).

## 6.3 Follow Up Consultation

At Month 1.5 (2026-11-23), review progress on the three critical actions: (1) Have domestic-authority timelines been decomposed per country, and is the conditional-start fallback signed? (2) Are Tier 1 vendors pre-bound (≥80%), examiners pre-qualified, and the vendor-refusal ladder locked? (3) Is the forensic panel recruited and pre-authorized, with shift-boundary cross-signing and divergence-resolution hierarchy codified? Escalate any item not on track to co-chairs with written fallback. Discuss flagship demonstration scenario design and calibration-exercise schedule confirmation. Review contingency exposure (USD 15M shortfall estimate) and options to close the gap. If any of the three critical actions is incomplete or significantly delayed by Month 1.5 (2026-11-23), recommend reassessment of bilateral commitment and possible deferral of Phase One clock start.

## 6.4.A Issue - Domestic Authority Enactment Is the Critical-Path Bottleneck; Decomposition and Escalation Authority Are Missing

The plan treats domestic access authority as a single Month 3.5 (2027-01-23) milestone without decomposing it by country into specific legislative or executive acts, approval bodies, and realistic timelines. If one government's authority lags beyond 4 weeks, the plan has no fallback except to delay the entire 90-day Phase One clock or compress pre-test calibration. This hands whichever government is slower a unilateral timing veto and risks cascading delays into the entry-condition gate. The pre-project assessment identifies this as existential but does not provide the specific acts, timelines or conditional-start mechanism needed to break the deadlock.

### 6.4.B Tags

- critical-path
- domestic-authority
- timing-veto
- gate-delay-cost
- no-fallback

### 6.4.C Mitigation

By Month 0 (2026-10-08 16:00), each country names a single domestic-authority lead and jointly decomposes the required legislative or executive acts (e.g., US Congressional ratification, China State Council directive) with approval timelines and committee schedules. Establish a weekly bilateral entry-conditions steering committee with documented action items and escalation rules: if any authority is delayed >4 weeks beyond baseline (e.g., Month 2 = 2026-12-08 → Month 3 = 2027-01-08), trigger political escalation within 2 working days to co-chairs. Pre-draft a conditional-start fallback into the bilateral instrument by Month 0.5 (2026-10-23 17:00), permitting Phase One clock to begin at each site once that site's entry conditions are met, with joint final-decision authority. Both governments sign the fallback by Month 1 (2026-11-08).

### 6.4.D Consequence

Without decomposition and escalation authority, a single government's domestic-authority delay (e.g., legislative delay of 8–12 weeks) defers the entire Phase One clock from Month 6 (2027-04-08) to Month 8–10 (2027-06-08 to 2027-08-08). This consumes USD 150–300M in holding costs (3 months × USD 50–100M per month), forces compressed pre-test calibration (Months 4–5 = 2027-02-08 to 2027-03-08 shrink to weeks), and locks thresholds on unvalidated provisional data. Alternatively, co-chairs may be forced to abandon Phase One entirely, declaring the program non-viable.

### 6.4.E Root Cause

The plan's original documents do not specify which domestic acts are required, in which approval sequence, or with what contingency if one government lags. The entry-conditions gate logic assumes simultaneous readiness across both countries without a fallback for asynchronous entry. Political commitment to proceed despite one government's slowness is not pre-authorized.

## 6.5.A Issue - Vendor Refusal Escalation Paths and Independent-Examiner Pre-Qualification Are Stated But Not Operationalized; Material Equipment Will Be Classified Unverifiable Without Early Action

The plan identifies vendor refusal as a key risk and lists a 10-day escalation ladder (vendor request, day 1 operator escalation, day 2 examiner notified, day 5 exam, day 10 report), but the bilateral negotiations to pre-bind critical vendors and the pre-qualification of independent examiners and clean-room facilities are not assigned to specific owners, have no documented completion milestones, and have not commenced. Without vendor pre-binding signed by Month 0.5 (2026-10-23) and examiner pre-qualification complete by Month 1 (2026-11-08), critical equipment will face refusal-induced delays at Month 2–3 (2026-12-08 to 2027-01-08) onward, and by Month 3–4 (2027-01-08 to 2027-02-08) material equipment will be classified unverifiable under the threshold, failing the site.

### 6.5.B Tags

- vendor-cooperation
- examiner-qualification
- unverifiable-equipment
- site-failure-threshold
- no-owner-assigned

### 6.5.C Mitigation

By Month 0 (2026-10-08 16:00), identify the top 8–12 manufacturers and logistics vendors per site and rank them by dependency (Tier 1: must have cooperation or site fails). Assign to operators and bilateral legal unit the task of negotiating and signing pre-Phase-One cooperation agreements with every Tier 1 vendor by Month 0.5 (2026-10-23 17:00), binding each vendor to attestation disclosure, maintenance-record preservation, inspector escort, and penalty clauses (USD 500k–2M per material refusal). By Month 1 (2026-11-08), pre-qualify a pool of 3–5 independent examiners per country and 2 clean-room facilities per geography, with signed agreements, cost confirmation (target USD 20–50k per exam) and capacity confirmation (5 parallel exams per week per facility). Lock the vendor-refusal escalation protocol in the bilateral instrument with documented owner and timeline.

### 6.5.D Consequence

If Tier 1 vendors are not pre-bound by Month 1 (2026-11-08) and examiners are not pre-qualified, refusals will occur ad hoc starting Month 2–3 (2026-12-08 to 2027-01-08). Each refusal triggers a 10-day ladder; if examiners are not available or vendors demand custom fees (USD 50–100k per exam vs. budgeted USD 20–30k), material equipment (>5% per site) will be unverifiable by Month 3–4 (2027-01-08 to 2027-02-08). Unverifiable equipment >5% per site is a Stop condition; the site will fail entry certification unless the count drops before Month 6 (2027-04-08). Without pre-qualification, fallback examiners may take 4–8 weeks to stand up, missing the 90-day Phase One window entirely.

### 6.5.E Root Cause

The plan lists vendor fallback routes but does not assign operational ownership (operators? bilateral legal? an independent procurement unit?) or lock completion dates. Vendor negotiation and examiner pre-qualification are assumed to happen in parallel with other entry-condition work, but no dedicated workstream exists and no owner is accountable for the result. Bilateral instrument negotiations have not begun.

## 6.6.A Issue - Ledger Divergence Forensic Authority and Resolution Procedures Are Not Pre-Authorized; Unresolved Divergence Will Trigger Automatic Suspension, Making the Mechanism Appear to Fail When It Is Functioning

The plan defines ledger divergence as an automatic impaired-confidence trigger at 72 hours and automatic suspension at 7 days, but the joint forensic-identity panel that is supposed to resolve contested divergences within 48 hours is not pre-authorized, no pre-agreed evidence-weighting hierarchy is codified, and no shift-boundary cross-signing protocol exists. Without these, divergence clocks will expire and trigger automatic suspension cascades that freeze the mechanism and appear to fail it, even if the underlying changes were correctly recorded. The co-chairs have no pre-committed procedure to recover from divergence or suspend the automatic escalation, so a technical fault (sync delay, network outage) can escalate to automatic suspension within days.

### 6.6.B Tags

- ledger-divergence
- forensic-panel
- automatic-suspension
- no-pre-authorization
- recovery-unavailable

### 6.6.C Mitigation

By Month 0.5 (2026-10-23 17:00), recruit and pre-vet a joint forensic-identity panel of 3–5 specialists per country (6–10 total) with counterintelligence clearance and mutual approval. Codify a divergence-resolution hierarchy in the bilateral instrument by Month 1 (2026-11-08 17:00): if two national ledgers disagree on equipment identity or event timing, the panel applies a pre-agreed evidence-weighting rule (e.g., 'cryptographic attestation if both agree > physical inspection + chain of custody > maintenance records'). Implement shift-boundary cross-signing at every handover (3× daily minimum): mirrored inspectors from each country sign ledger entries at 08:00, 16:00, and 24:00 UTC, certifying that prior-shift events have no undisclosed divergences. Configure ledger for automatic divergence detection and alert within 2 hours; forensic panel investigates within 48 hours and issues binding or co-chair-delegated findings. Test the entire procedure on non-covered equipment by Month 4 (2027-02-08).

### 6.6.D Consequence

Without pre-authorized forensic procedures, any ledger divergence (sync delay >1 hour, timestamp mismatch, cryptographic validation failure) triggers escalation clocks that expire in 72 hours (impaired confidence) to 7 days (automatic suspension). If the forensic panel does not exist or has no pre-committed authority, the co-chairs cannot issue a finding before expiry, and the mechanism enters automatic suspension—freezing the site or event class. This appears to fail the mechanism even if the divergence is a technical fault or a trivial timestamp skew. In a 90-day test with tight margins, automatic suspensions triggered by technical faults could dominate the KPI dashboard and force a Modify or Stop verdict that reflects the administrative process, not the mechanism's detection capability.

### 6.6.E Root Cause

The plan identifies ledger divergence as a key risk and defines automatic escalation clocks, but it does not pre-authorize the forensic panel, lock the resolution hierarchy, or establish shift-boundary cross-signing procedures before the clock starts. The bilateral instrument does not yet include these procedures; they are planned for negotiation during or after entry-condition work, but no owner is assigned and no deadline is set. Automatic suspension is a powerful deterrent against concealment, but without a pre-authorized recovery procedure, it becomes a cascade that can freeze a functioning mechanism.

---

# 7 Expert: Independent Testing Unit Design and Exercise-Credibility Auditor

**Knowledge**: Blind-exercise design and scenario generation, random-draw and sealed-schedule mechanics, detection-performance measurement and false-positive/negative analysis, exercise-execution safeguards against bias or collusion, auditable challenge-result recording and archiving, comparison of US-vs-China exercise fairness

**Why**: The Go/Modify/Stop decision rests entirely on blind-challenge detection results (90% unreported arrivals, 85% substitutions, 80% record falsification—all provisional, TBD). The plan caps exercises at 2 sessions per site per month in non-production areas, yet both governments must find the results credible and symmetric. The specialist would validate that the independent testing unit structure, sealed-schedule mechanism, and fairness-comparison procedures prevent either side from claiming the exercises were biased, rigged or unrepresentative.

**What**: By Month 1 (2026-11-08), design the independent testing unit charter (governance, staffing, reporting), define the sealed double-key schedule mechanism (how events are drawn, stored, revealed), specify the 7 event-type scenario templates (unreported arrival, substitution, record falsification, delayed access, disputed identity, vendor refusal, reluctant operator), establish the cross-country fairness-comparison protocol (comparing US scenarios against China scenarios on difficulty, artifact visibility, operator-knowledge assumptions), and lock the detection-success metrics (e.g., detection = change recorded in ledger within 48 hours).

**Skills**: Experimental-design methodology and random-draw procedures, blind-trial protocols and double-key ceremony mechanics, detection-performance measurement, statistical false-negative and false-positive analysis, adversarial-scenario design, auditable result archiving and chain-of-custody, fairness comparison and statistical parity analysis

**Search**: blind exercise experimental design sealed schedule randomization, detection performance measurement false positive negative, verification exercise scenario fairness comparison bilateral

## 7.1 Primary Actions

- By Month 0.5 (2026-10-23 17:00), initiate all three critical-execution actions simultaneously: (1) Brief both countries' counterintelligence services to start vetting 120–150 candidate inspectors per country immediately (target: 14 weeks completion by Month 4.5 = 2027-02-23), with a surge bench of 20–30% additional replacements. (2) Launch bilateral negotiations with the top 8–12 vendors per site to finalize cooperation agreements and pre-qualify 3–5 independent examiner labs and 2 clean-room facilities per geography by Month 4 (2027-02-08). (3) Commission the legal teams to draft a 'Forensic Panel Charter' specifying composition, decision authority, evidence hierarchy, deadlock escalation, and enforcement, with signature by both co-chairs by Month 1 (2026-11-08).
- By Month 1 (2026-11-08 17:00), obtain bilateral co-chair signature on three documents: (a) the Forensic Panel Charter codifying the 48-hour identity-dispute resolution process, evidence corroboration hierarchy, and deadlock path; (b) a conditional-start fallback clause in the bilateral instrument permitting Phase One to begin at each site independently if either country's entry conditions are not complete by Month 5 (2027-03-08), with interim 'probationary' rosters of 80% approved inspectors pending vetting completion; (c) a vendor-refusal escalation ladder locked in writing with penalties (liquidated damages, market-access loss) for vendor non-cooperation. Without these three signatures, the three critical-path risks remain unmanaged.
- By Month 3 (2027-01-08 17:00), conduct a bilateral Go/No-Go gate review: confirm that inspector vetting is on track for 80% completion by Month 4.5 (2027-02-23), that at least 80% of Tier 1 vendors have signed cooperation agreements, and that examiner and clean-room pre-qualification agreements are signed. If any milestone is not met, invoke the conditional-start fallback or defer Phase One by 4 weeks (push clock start to Month 7 = 2027-05-08). Simultaneously, reserve a contingency of USD 2–4M per site (USD 8–16M total) for late-engaged examiners within the USD 500M contingency envelope, and obtain double-key approval of this reserve.
- By Month 4 (2027-02-08 17:00), finalize and operationally test the ledger system and forensic panel: (a) both national ledgers must be operational and stress-tested on non-covered equipment; (b) all forensic-panel members must be appointed, vetted, and pre-authorized; (c) at least one full mock divergence scenario must be executed, with the panel issuing a finding within 48 hours and co-chairs validating the decision path; (d) the vendor-refusal ladder must be documented and acknowledged by both sides as enforceable.
- By Month 5.5 (2027-03-23 17:00), lock all Go/Modify/Stop thresholds via double-key co-chair signature: detection (≥90% unreported arrivals, ≥85% substitutions, ≥80% record falsification, <5% false positives), parity (within 20%), unresolved discrepancies (<10% of events), unverifiable equipment (<5% per site), ledger divergence (zero unresolved >7 days). Every threshold must include documented justification and the validation method (e.g., 'calibration exercise, Months 4–5 = 2027-02-08 to 2027-03-08'). Mark all values not externally validated as 'provisional, validated in calibration' and document the calibration results in the ledger.

## 7.2 Secondary Actions

- By Month 0 (2026-10-08 16:00), establish a bilateral entry-conditions steering committee with both co-chairs meeting weekly, with documented meeting notes and signed action-item assignments. Each co-chair must appoint a single domestic-authority lead accountable for legislative timelines. Map each required domestic act through its approval process and identify the critical path; if any item is delayed >4 weeks, escalate within 2 working days.
- By Month 1 (2026-11-08 17:00), commission the independent testing unit to design a flagship 'verified intake-to-exit chain' demonstration using one high-consequence equipment class, executed once per site in Phase One (Months 6–9 = 2027-04-08 to 2027-07-08). This demonstration must show identity verified by 2+ independent layers and disposition assigned without IP exposure. Rehearse in calibration (Months 4–5 = 2027-02-08 to 2027-03-08) to validate end-to-end feasibility.
- By Month 1.5 (2026-11-23 17:00), conduct a bilateral pre-clock site-boundary survey at each participating datacenter with both countries' security teams, inspectors, and operators present. Physically mark zones with painted lines, signage, and photos. Produce a signed photographic record of the exact boundary separating inspection zones (staging, spare, maintenance, expansion) from off-limits live-computation areas. Both co-chairs must approve the marked boundaries.
- By Month 2 (2026-12-08 17:00), establish a joint bilateral Inspector Conduct Committee with equal national co-chairs, empowered to approve/veto counterpart inspectors within 5 working days, investigate misconduct within 48 hours, and recommend removal within 72 hours. Implement continuous access-log audit: every inspector wears a proximity badge; monthly, an independent auditor from each country reviews zone entry/exit logs comparing claimed activities against actual presence times. Document all investigations in the ledger with redacted summaries.
- By Month 3 (2027-01-08 17:00), reserve a contingency sub-envelope of USD 2–4M per site (USD 8–16M total) for late-engaged independent examiners or clean-room capacity overruns. Obtain double-key co-chair approval of this sub-envelope. If vendor pre-qualification is >80% complete, release the sub-envelope to contingency; if not, freeze it for examiner use only. Maintain transparency: document the contingency reserve and usage in the bilateral budget monthly.
- By Month 4 (2027-02-08 17:00), operationally test the shift-handover cross-signing process for the ledger: mirrored inspectors (one from each country) must jointly sign a ledger entry at every shift handover (3 per 24-hour day minimum: 08:00, 16:00, 24:00 UTC), certifying that they reviewed the prior shift's events and found no undisclosed divergences. Any divergence discovered during cross-signing must be escalated within 2 hours. Document the first month of cross-signing to ensure the process is feasible and both sides understand the escalation path.
- By Month 4.5 (2027-02-23 17:00), finalize the covered-equipment schedule (provisional, manufacturer-neutral, confidential, versioned) and both co-chairs must sign a 'Schedule Lock Certificate' stating that the schedule is complete and will not be amended until after the Go/Modify/Stop decision (Month 10 = 2027-08-08), except through a documented protocol-change process. Any amendment requests during Phase One must be logged, denied, and recorded in the ledger.
- By Month 5 (2027-03-08 17:00), confirm that at least 80% of the planned inspector roster is vetted and approved, and 100% of critical posts (shift supervisors, zone gatekeepers, ledger custodians) are filled. Any vacancy must be filled from a pre-approved surge bench within 5 working days; if the bench is exhausted, escalate to co-chairs for a decision on reduced-shift coverage or conditional-start delay.
- During Months 4–5 (2027-02-08 to 2027-03-08), execute a calibration exercise on 100–150 non-covered equipment units per site (50–100 events per site), covering unreported arrivals, substitutions, record falsification, vendor refusal, and reluctant-operator scenarios. Score detection rates by event type and false-positive rate. By Month 5.5 (2027-03-23 17:00), document calibration results and validate all provisional Go/Modify/Stop thresholds, or recalibrate thresholds if evidence shows mis-setting. Lock all thresholds via double-key signature by Month 5.5 (2027-03-23 17:00).
- By Month 5.5 (2027-03-23 17:00), finalize all 7 entry-condition certifications (signed instrument, appropriations, domestic access authority, site selection, inspector approval, operator/vendor agreements, equipment schedule) with both co-chairs' joint signatures. If any condition remains unresolved, invoke the conditional-start fallback or defer Phase One to Month 7 (2027-05-08).

## 7.3 Follow Up Consultation

At the Month 1 (2026-11-08) follow-up, the client must confirm: (1) Both forensic-panel charters are signed and panel members are appointed and pre-vetted by counterintelligence. (2) The conditional-start fallback and vendor-refusal ladder are codified in the bilateral instrument with both co-chairs' signatures. (3) Inspector vetting is demonstrably on track for 80% completion by Month 4.5 (2027-02-23); if not, a fallback acceleration plan is active (e.g., parallel vetting across both security agencies). (4) Vendor pre-qualification negotiations are substantively advanced; at least preliminary agreements are in draft with Tier 1 vendors. (5) Calibration exercise scenarios are designed and ready for execution in Months 4–5 (2027-02-08 to 2027-03-08). A second follow-up at Month 3 (2027-01-08) must validate the Go/No-Go gate: thresholds are locked, contingency sub-envelopes are reserved, and a decision is made to proceed to Phase One by Month 6 (2027-04-08) or defer.

## 7.4.A Issue - Entry-Gate Critical-Path Bottleneck: Inspector Vetting Timeline Creates Unilateral Timing Veto

Inspector counterintelligence vetting requires 14–16 weeks (20+ if deprioritized), with no documented acceleration path or surge capacity. Since all inspectors must be approved before the Phase One clock starts (Month 6 = 2027-04-08), any delay in either country's security-clearance process blocks certification of Entry Condition 6 ('all inspectors approved') and defers the 90-day test indefinitely. The plan documents this as the critical-path item but offers no fallback: no conditional start, no reduced roster, no pre-emergency vetting of surge staff. This gives whichever government controls the slower vetting process an effective veto over timing, contrary to the double-key governance principle.

### 7.4.B Tags

- entry-gate-critical-path
- inspector-vetting-delay
- unilateral-timing-veto
- no-fallback-escalation
- reciprocity-imbalance

### 7.4.C Mitigation

Immediately (by Month 0.5 = 2026-10-23 17:00) commission each country's counterintelligence service to vet at least 120–150 candidate inspectors per country in parallel, starting vetting at Month 0.5 (2026-10-23) (not Month 0.5 = 2026-10-23 + lead time). Request expedited 14-week completion by Month 4 (2027-02-08). Establish a surge bench of 20–30% additional pre-vetted replacements by Month 4 (2027-02-08). If either country's vetting falls >4 weeks behind baseline (i.e., not complete by Month 4.5 = 2027-02-23), trigger a bilateral escalation: co-chairs may authorize a conditional partial start at that site using an interim 'probationary' roster of 80% approved plus 20% provisional (subject to counterpart veto within 5 days), allowing the 90-day clock to begin on time while final vetted rosters catch up. Document this fallback in the bilateral instrument by Month 1 (2026-11-08).

### 7.4.D Consequence

Without mitigation, a single country's security agency can defer the 90-day test by 3–6 months, accumulating USD 150–300M in holding costs (per canonical facts). This inverts reciprocity: the mechanism fails not because either government distrusts the design, but because one bureaucracy controls the timeline. Phase One becomes a hostage to domestic process, not a test of bilateral verification. The project faces either indefinite delay or a forced choice to waive full vetting and accept reduced credibility.

### 7.4.E Root Cause

The plan treats inspector vetting as a hard constraint (all inspectors must be approved before clock start) without a backstop or conditional-start option. This mirrors the strict gate principle, but it conflates procedural security (vetting credibility) with timing governance. A true reciprocity design would either make vetting time-bounded with a fallback, or permit a conditional start with heightened monitoring of interim rosters. The plan's tone is cautious and audit-heavy, but it has no mechanism to absorb unilateral delay in one country's security process.

## 7.5.A Issue - Ledger Divergence Forensics Authority Not Pre-Authorized: Automatic Suspension Clocks Turn Technical Faults into Stop Triggers

The plan requires a joint forensic panel (3–5 per country) to resolve contested equipment-identity disputes within 48 hours and defines automatic suspension if divergence is unresolved at 7 days. However, the bilateral instrument does not pre-authorize the forensic panel's composition, decision rules, or enforcement authority. If divergence occurs (e.g., national ledgers disagree on equipment serial number or event timestamp), the plan states the panel 'investigates within 48 hours,' but it does not specify: who appoints panel members, whose national law governs their authority, what happens if the two co-chairs' appointees deadlock (no casting vote), or which national court enforces a forensic finding. Without pre-authorization, the first divergence will consume weeks in procedural arguments over the panel's legitimacy, the 7-day suspension clock will expire, and automatic suspension fires—not because the mechanism failed, but because the forensic authority was never established.

### 7.5.B Tags

- ledger-divergence-forensics
- pre-authorization-gap
- automatic-suspension-cliff
- deadlock-escalation-undefined
- technical-fault-misclassified-as-stop

### 7.5.C Mitigation

By Month 0.5 (2026-10-23 17:00), the bilateral legal unit must draft and both co-chairs must sign a 'Forensic Panel Charter' specifying: (a) composition: 3–5 senior cryptography, supply-chain and equipment-identity specialists per country, appointed by each government before Month 2 (2026-12-08), with counterpart approval within 5 working days (veto right); (b) decision authority: panel operates under both countries' joint mandate, not subject to either country's national law alone; findings are binding on the bilateral mechanism and recorded in both national ledgers; (c) evidence hierarchy: pre-agreed corroboration rule (e.g., 'attestation if both ledgers match > physical inspection + chain of custody > maintenance records > third-party logs'); panel applies rules sequentially and issues findings with written justification within 48 hours; (d) deadlock path: if panel members split (e.g., 3–2 on identity), co-chairs decide within 24 hours; if co-chairs deadlock, neutral referee panel gives non-binding opinion within 5 days, then co-chairs re-vote within 24 hours; (e) enforcement: suspension is automatic only if forensic findings are not issued within 48 hours or co-chair decision not within 24 hours (procedural failure), not for substantive disagreement. Codify this charter in the bilateral instrument by Month 1 (2026-11-08).

### 7.5.D Consequence

Without pre-authorization, the first contested equipment identity or ledger divergence will trigger a procedural cascade: the forensic panel cannot act (authority undefined), the 7-day suspension clock expires, automatic suspension fires, and the mechanism appears to have failed to both governments. In reality, it was never operational. The Go/Modify/Stop decision becomes infected with procedural failure, and rebuilding trust becomes exponentially harder. A single technical divergence (e.g., timestamp drift of 5 minutes between national clocks) will be misclassified as a Stop-level failure, terminating the test before substantive performance is measured.

### 7.5.E Root Cause

The plan specifies forensic-panel functions (48-hour turnaround, corroboration rules) but assumes bilateral authority exists to appoint and enforce them. In a low-trust, no-legal-symmetry design, authority must be pre-established or it does not exist. The plan's gate-before-clock logic is sound—entry conditions must be certified—but forensic authority is not treated as an entry condition. It should be: Entry Condition 7 should be 'forensic panel charter signed by both co-chairs and panel members appointed and approved.' Without it, the mechanism is missing a critical 48-hour decision authority that the entire escalation logic depends on.

## 7.6.A Issue - Vendor Refusal Cascades and Unverifiable-Equipment Threshold: Pre-Qualification and Ladder Deadlines Not Locked

The plan requires a vendor-refusal escalation ladder (day 0–10) and pre-qualified independent examiners and clean-room facilities as fallbacks, but it does not lock the completion date for pre-qualification. The plan states 'pre-bind top 8–12 vendors per site; 3–5 examiner labs per country and 2 clean-room facilities per geography, agreements signed by Month 4 (2027-02-08)' as a mitigation action. However, if negotiations with vendors or examiner labs slip beyond Month 4 (2027-02-08), the 90-day Phase One test (Months 6–9 = 2027-04-08 to 2027-07-08) will encounter vendor refusals with no agreed fallback in place. Equipment will be classified unverifiable by the ladder (day 10), and if unverifiable equipment exceeds the Go threshold of <5% per site, the site fails—not because the mechanism is broken, but because vendor pre-qualification was incomplete. The plan estimates USD 3.6–11.2M contingency overrun for late-engaged examiners, but contingency worst case is already USD 15M over budget.

### 7.6.B Tags

- vendor-refusal-ladder
- pre-qualification-deadline-not-locked
- unverifiable-equipment-threshold-exposure
- contingency-shortfall
- cascading-site-failure-risk

### 7.6.C Mitigation

By Month 0.5 (2026-10-23 17:00), bilateral negotiations with the top 8–12 vendors per site must be initiated, with a target to finalize cooperation agreements by Month 4 (2027-02-08). Make this an explicit Go/No-Go gate: at Month 4 (2027-02-08) review, if <80% of Tier 1 vendors are pre-bound and examiner/clean-room agreements are not signed, do not start Phase One; instead, extend calibration by 4 weeks and defer the clock start to Month 7 (2027-05-08). Alternatively, if vendor negotiations slip, reserve a contingency of USD 2–4M per site (USD 8–16M total) within the USD 500M contingency envelope for late-engaged examiners at USD 50–100k per exam. Lock this reserve by double-key decision at Month 3 (2027-01-08). Define the vendor-refusal ladder thresholds in the bilateral instrument (by Month 1 = 2026-11-08) with explicit penalties for vendors who refuse: loss of future market access, contract termination, liquidated damages of USD 500k–2M per material refusal. Document each vendor-refusal case in the ledger with the name, refusal date, and escalation outcome. If unverifiable equipment reaches 5% at a site (threshold boundary), escalate to co-chairs for a double-key decision on whether the threshold should be adjusted or the site should fail.

### 7.6.D Consequence

If vendor pre-qualification is incomplete by Phase One start, the first vendor refusal will trigger the day-10 ladder, and the equipment will be marked unverifiable. If this happens to multiple items or at a site with few real events, unverifiable equipment will accumulate and exceed the 5% threshold by Month 7–8 (2027-05-08 to 2027-06-08), forcing a Stop or Modify verdict. The mechanism will not have failed; pre-qualification will have. Contingency is already USD 15M over budget, so there is no margin to absorb late-examiner costs. A single site's vendor-refusal cascade can fail Phase One, even if detection and parity performance are strong.

### 7.6.E Root Cause

The plan correctly identifies vendor refusal as a material risk and proposes a ladder and fallback pool, but it treats pre-qualification as a mitigation action (something to do by Month 4 = 2027-02-08) rather than as an entry condition (something that must be complete before the clock starts). The strategic decisions do not lock a pre-qualification deadline before the gate is certified. The contingency exposure is already tight; adding unbudgeted examiner costs has no slack. A more defensible design would either (a) pre-bind 100% of Tier 1 vendors by Month 2 (2026-12-08), not Month 4 (2027-02-08), or (b) include vendor pre-qualification as Entry Condition 8 (after the current 7), making the gate incomplete until all vendor agreements are signed.

---

# 8 Expert: Fiscal Accountability and Contingency-Exposure Risk Manager

**Knowledge**: USD 5.0B appropriations governance and USD 2.5B per-country budgets, 7-envelope allocation and burn-rate tracking, contingency-release mechanics (double-key approval, fast-lane USD 50M), gate-delay holding-cost modeling (USD 50-100M per month), fallback cost scenarios (vendor examiners, site replacement, attestation-root alternatives), contingency-shortfall exposure and mitigation

**Why**: The contingency-exposure analysis identifies a worst-case shortfall of about USD 15M (estimated gate slip USD 300M + site replacement USD 200M + examiner overrun USD 11M, total USD 511M, versus USD 500M contingency), leaving negative surge margin and no buffer for concurrent fallbacks. The specialist would validate the cost estimates, propose a contingency-allocation strategy (e.g., ring-fence gate-delay costs to prevent site-replacement or examiner overrun from consuming the entire reserve), and recommend a funding-timeliness governance structure that detects late tranches within days rather than weeks.

**What**: By Month 0.5 (2026-10-23), decompose the contingency worst-case scenario into its components (gate-delay USD 50-100M per month x 3 months = USD 150-300M; site replacement USD 50-200M; examiner overrun USD 3.6-11.2M; exercise incident USD 4M; total USD 207.6-515M); validate cost bases against comparable bilateral programs (New START overhead, OPCW managed-access costs, IAEA in-situ inspection); propose a contingency sub-allocation (e.g., USD 200M for gate delay, USD 150M for site replacement, USD 100M for vendor fallbacks, USD 50M for surge/exercise incidents); design a funding-timeliness escalation (late tranche flagged within 5 working days, co-chairs notified within 10 days, cure period 30 days, withheld-funding Stop trigger at 75 days total).

**Skills**: Government appropriations and budget-execution procedures, cost estimation and contingency modeling, probability-weighted risk scenarios, funding-timeliness governance and payment-processing, double-key financial authorization, burn-rate tracking and variance analysis, escalation and Stop-trigger criteria

**Search**: government program contingency reserve allocation risk, budget variance tracking escalation procedures, appropriation payment timeliness governance, dual-signature financial authorization

## 8.1 Primary Actions

- Decompose domestic authority enactment into specific legislative or executive acts per country; establish a bilateral entry-conditions steering committee with weekly signed reviews and named domestic-authority leads; identify the critical path and tie-item delays to political escalation within 2 working days. Pre-draft a conditional-start fallback into the bilateral instrument by Month 0.5 (2026-10-23 17:00) and obtain both governments' signed acceptance by Month 1 (2026-11-08).
- Recruit and vet a joint forensic-identity panel (3–5 per country) by Month 0.5 (2026-10-23 17:00); codify in the bilateral instrument a pre-agreed evidence-weighting hierarchy and the panel's 48-hour investigation and decision authority. Mandate shift-boundary cross-signing by mirrored inspectors at 08:00, 16:00, and 24:00 UTC daily; configure ledger for automatic divergence detection and forensic escalation within 48 hours.
- Identify top 8–12 Tier 1 vendors at each site and conduct bilateral negotiations to pre-bind them by Month 0.5 (2026-10-23 17:00); target 80% vendor cooperation agreements by Month 1 (2026-11-08). Pre-qualify 3–5 independent examiner labs per country and 2 clean-room facilities per geography; sign access and confidentiality agreements and confirm schedule capacity by Month 1 (2026-11-08). Lock the day-10 vendor-refusal escalation ladder in writing before clock start.

## 8.2 Secondary Actions

- Design and lock the pre-test calibration-exercise scenario suite (50–100 events per site, covering all 7 event types and blind-challenge methodology) by Month 1 (2026-11-08 12:00); execute calibration Months 4–5 (2027-02-08 to 2027-03-08) on 100–150 reserved non-covered units per site. Document detection and false-positive results; validate all Go/Modify/Stop thresholds; lock thresholds via double-key co-chair signature by Month 3 (2027-01-08 17:00) and mark all as 'validated.'
- Initiate counterintelligence vetting of all candidate inspectors (120–150 per country) by Month 0.5 (2026-10-23 17:00), targeting completion 14–16 weeks before Phase One clock (Month 5 = 2027-03-08). Establish a joint bilateral Inspector Conduct Committee; implement continuous access-log audit and monthly boundary-zone compliance reviews. Require every inspector to sign a zone-conduct acknowledgment before clock start (Month 6 = 2027-04-08) with escalating Tier 1/2/3 violation protocols.
- Implement ledger cryptographic integrity: design two independent air-gapped national ledger copies with secure synchronization link and offline backup paths; conduct a bilateral key ceremony by Month 1.5 (2026-11-23 09:00) to generate and distribute split-key material; stress-test the ledger system on non-covered equipment by Month 4 (2027-02-08) with simultaneous outage, corruption, and key-unavailability scenarios. Conduct monthly ledger-integrity verification and reconciliation within 7 days of any divergence.
- Conduct bilateral pre-clock site-boundary survey by Month 1.5 (2026-11-23 17:00); physically mark zone perimeters with painted lines and signage; install access-control gates with real-time logging to both national ledgers and video recording of aggregate equipment movement only. Implement the three-tier zone-violation escalation protocol and mandatory monthly zone-boundary re-briefing for all inspectors.
- Raise the contingency-exposure gap (about USD 15M estimate) at the Month 3 (2027-01-08) appropriations review; work with both treasuries and the budget working group to either secure an additional USD 15–25M or reallocate within existing envelopes (e.g., defer non-critical testing, reduce staffing surge, or compress site-preparation scope).

## 8.3 Follow Up Consultation

At Month 1 (2026-11-08 17:00), review completion of the three primary actions and the bilateral instrument conditional-start language. Confirm vendor pre-binding and examiner pre-qualification status; reconcile any gaps in attestation-hook availability or vendor leverage. Assess counterintelligence-vetting progress; adjust timeline if >20% behind baseline. Validate that the forensic panel is operational and the ledger stress-test completed without critical failures. At Month 3 (2027-01-08), certify domesticauthority enactment status per country; reconcile appropriations timeliness; confirm calibration-exercise design is locked and blind-exercise methodology approved. Discuss the killer-application flagship scenario and whether Phase One's real-event load will support a visible, high-value demonstration. Final review at Month 5.5 (2027-03-23): lock all thresholds, confirm all entry-gate items are 100% certified, and issue the bilateral go-ahead for clock start at Month 6 (2027-04-08).

## 8.4.A Issue - Domestic Authority Enactment Timeline Lacks Decomposition and Fallback

The plan lists 'domestic access authority enacted (Month 3.5 = 2027-01-23)' as a mandatory entry condition, but does not decompose the specific legislative or executive acts required in each country, their approval timelines, or the critical path. If either government's authority enactment slips >4 weeks (e.g., from Month 3.5 = 2027-01-23 to Month 4.5 = 2027-02-23), the Phase One clock start is deferred 4–8 weeks, accumulating USD 50–100M holding cost and cascading into compressed pre-test calibration. No explicit fallback exists: the plan states 'no partial-start exceptions,' giving the slower government an effective timing veto. The entry-conditions steering committee is implied but not formally chartered.

### 8.4.B Tags

- entry-gate-veto-risk
- domestic-authority-decomposition-missing
- fallback-timing-undefined
- holding-cost-unbudgeted
- steering-committee-not-chartered

### 8.4.C Mitigation

By Month 0 (2026-10-08 16:00), both co-chairs must table a written decomposition of every domestic legal act required (e.g., US Congressional resolution, China State Council directive), each act's approval body and committee review timeline, and the single-item critical path. Establish a bilateral entry-conditions steering committee with weekly signed reviews and named domestic-authority leads per country. If any authority item slips >4 weeks from baseline, trigger political escalation within 2 working days. Pre-draft a conditional-start fallback into the bilateral instrument by Month 0.5 (2026-10-23 17:00) permitting Phase One clock at each site once conditions are met, final decision after all sites complete 90 days. Obtain both governments' signed acceptance by Month 1 (2026-11-08).

### 8.4.D Consequence

Without decomposition and fallback, a legislative delay in either country defers Phase One indefinitely, accumulating USD 150–300M holding cost (3 months x USD 50–100M) that exceeds contingency headroom. Compressed pre-test calibration or skipped calibration forces decision-thresholds to lock on unvalidated provisional data, risking a Modify outcome that reflects the yardstick, not the mechanism's real performance. Deadlock over timing damages reciprocal confidence before Phase One begins.

### 8.4.E Root Cause

The plan treats domestic authority as a binary entry condition without identifying which government is the critical path or what happens if one side is slow. The entry-conditions gate is specified as 'strict' with 'no partial-start exceptions,' but no fallback plan exists for the timing-veto risk it creates. Appropriations governance is mentioned as 'funding timeliness' (45-day + 30-day cure = 75-day threshold) but domestic authority enactment is not similarly bounded.

## 8.5.A Issue - Ledger Divergence Forensic Authority Not Pre-Authorized; Divergence Clocks Expire Unchecked

The plan specifies that unresolved ledger divergence >7 days triggers automatic suspension (an explicit Stop condition), and that a joint forensic panel will investigate disputed entries within 48 hours. However, the plan does not pre-authorize the panel's membership, decision-making authority, or evidence-weighting hierarchy before Phase One. If two national ledgers disagree on equipment identity or event timing and the forensic panel is not empowered in writing by both governments and the bilateral instrument, disputes devolve into co-chair negotiation, which can exceed the 48-hour investigation window and cause the divergence clock to expire, triggering automatic suspension of a functioning mechanism. Additionally, shift-boundary cross-signing is mentioned as a procedure but not mandated operationally or budgeted.

### 8.5.B Tags

- forensic-panel-pre-authorization-missing
- divergence-escalation-hierarchy-undefined
- shift-cross-signing-not-operationalized
- automatic-suspension-hair-trigger
- ledger-credibility-risk

### 8.5.C Mitigation

By Month 0.5 (2026-10-23 17:00), recruit and vet a joint forensic-identity panel (3–5 senior specialists per country, vetted by both governments). Codify in the bilateral instrument a pre-agreed evidence-weighting hierarchy: (a) cryptographic attestation if both ledgers match; (b) physical inspection + chain of custody if attestation unavailable; (c) maintenance records if inspection unavailable; (d) third-party logs as lowest rank. Panel issues binding or co-chair-delegated findings within 48 hours; if no consensus, co-chairs decide within 24 hours. Mandate shift-boundary cross-signing: mirrored inspectors jointly sign at 08:00, 16:00, 24:00 UTC daily, certifying no undisclosed divergence. Configure ledger for automatic divergence detection and alert within 2 hours; forensic investigation within 48 hours; resolution within 7 days or escalate to co-chairs for stop/suspend decision.

### 8.5.D Consequence

Without pre-authorized forensic authority, unresolved ledger divergence can trigger automatic suspension of a site or event class even if the underlying equipment identity is sound and both inspectors agree on facts. This converts a technical or communication lag into a spurious Stop trigger that terminates Phase One not due to access asymmetry or real concealment but due to procedural breakdown. Loss of bilateral confidence; credibility damage to the mechanism; accusations that one side 'weaponized' the divergence clock to veto an inconvenient finding.

### 8.5.E Root Cause

Empty

## 8.6.A Issue - Vendor Refusal Escalation Path Not Confirmed; Critical Equipment Becomes Unverifiable Before Month 3 (2027-01-08)

The plan specifies a day-10 vendor-refusal ladder and designates vendor-supervised testing, filtered evidence, accredited independent examiners, and clean-room procedures as fallback routes. However, the plan does not confirm that critical vendors are pre-bound, independent examiners are pre-qualified, or clean-room facilities are contractually available by Phase One clock start. If a critical vendor (e.g., the only supplier of custom attestation hardware) refuses access at Month 3 (2027-01-08) or Month 4 (2027-02-08) during equipment intake, and no pre-qualified examiner or clean-room is available, material equipment is classified unverifiable and logged. Accumulation of unverifiable equipment across 2 sites can exceed the 5% threshold (proposed), failing one or both sites under the Stop rule. No contingency allocation is earmarked for late-engaged examiners; examiner costs overrun by USD 3.6–11.2M (estimate) versus the USD 1.5–4.0M allocated, consuming contingency headroom.

### 8.6.B Tags

- vendor-pre-binding-not-confirmed
- examiner-pre-qualification-missing
- clean-room-capacity-not-reserved
- vendor-refusal-cascade-risk
- contingency-overrun-examiner-costs

### 8.6.C Mitigation

By Month 0.5 (2026-10-23 17:00), identify the top 8–12 Tier 1 vendors at each proposed site (manufacturers, attestation-key holders, maintenance providers, logistics). Conduct bilateral negotiations to sign pre-Phase-One cooperation agreements binding each vendor to equipment-identity attestation, evidence preservation, escort, and maintenance-record access; include penalty clauses (USD 500k–2M per material refusal). Obtain countersigned agreements for at least 80% of Tier 1 vendors by Month 1 (2026-11-08). Pre-qualify 3–5 independent examiner labs per country and 2 accredited clean-room facilities per geography by Month 1 (2026-11-08); sign access and confidentiality agreements. Confirm cost per examination (USD 20–50k) and schedule capacity (5 parallel exams/week minimum per facility). Lock the day-10 escalation ladder in writing before clock start; document that equipment unverifiable at day 10 (one extension to day 15) triggers the unverifiable-equipment KPI and contributes to site-level Go/Modify/Stop determination.

### 8.6.D Consequence

If vendors are not pre-bound and examiners not pre-qualified, vendor refusals accumulate from Month 3 (2027-01-08) onward, leaving material equipment unverifiable. By Month 4–6 (2027-02-08 to 2027-04-08), one or both sites may exceed the 5% unverifiable-equipment threshold (proposed), triggering a Stop decision before Phase One meaningfully begins. Alternatively, the program pivots to expensive late-engaged examiners, overrunning contingency by USD 3.6–11.2M (estimate) and leaving no surge margin. Loss of bilateral confidence if the mechanism appears unable to overcome vendor refusal; asymmetric burden if one country's vendors are more cooperative than the other's, creating apparent reciprocity failure.

### 8.6.E Root Cause

Empty