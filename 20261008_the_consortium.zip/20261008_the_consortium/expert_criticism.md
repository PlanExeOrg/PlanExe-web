# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Bilateral Verification Protocol Designer

**Knowledge**: Arms-control verification, managed access regimes, IAEA/OPCW precedent, dual-key governance, evidence standards, sealed inspection protocols

**Why**: The plan's core technical innovation—layered evidence weighting, inspector information firewalls, and ledger synchronization bounds—directly parallels IAEA safeguards and START/OSIA monitoring. This expert validates whether the rotating-rule anti-gaming strategy and partial-suspension mechanics are operationally sound and whether precedents from nuclear, chemical and conventional arms control transfer credibly to frontier computing.

**What**: Review the five critical decision levers (evidence weighting, deadlock mechanics, blind exercises, verdict calibration, inspector firewall) against IAEA access-denial, OPCW contested-facility and START commission precedent; assess whether the confidential rotating rule resists gaming without triggering false-positive overload seen in earlier regimes; validate the partial-suspension and impaired-confidence age thresholds (14, 21, 28 days) as realistic against historical deadlock durations.

**Skills**: Protocol design, precedent analysis, access-denial risk modeling, evidence-chain forensics, comparative governance structures, dual-authorization deadlock mechanics

**Search**: IAEA safeguards verification protocol, OPCW managed access, START inspection commission, bilateral arms-control verification, sealed facility inspection

## 1.1 Primary Actions

- Establish Entry-Condition Task Force with binding weekly milestones and parallel-track activation (site nomination, vendor outreach, vetting) starting Month -2; reserve USD 50–100M from contingency for compressed negotiation; appoint external escalation authority with scope-reduction power (2 pairs, 60 days) if any gate slips >2 weeks; lock all entry-gate deadlines (instrument Month 0.5 = 2026-10-23, authority Month 1 = 2026-11-08, sites Month 1 = 2026-11-08, vendors Month 1 = 2026-11-08, inspectors Month 2 = 2026-12-08, schedule Month 3 = 2027-01-08) and certify entry by Month 5.5 (2027-03-23).
- Lock confidential evidence-weighting rule in bilateral escrow by Month 1.5 (2026-11-23) and validate it at Month 2 (2026-12-08) against 100–200 historical equipment-change events per site; compare false-positive output to 10% target within ±3 points; if deviation exceeds ±5 points, adjust and re-validate on a second cohort before Phase One; document rule-version history and link each finding to its active rule version in the final ledger.
- Pre-register verdict thresholds and mechanical scoring logic in a joint bilateral memorandum locked by both co-chairs by Month 2.5 (2026-12-23), before the first Phase One exercise; use confidence-interval bands (Go ≥75% at 90% CL with lower bound ≥62%, Modify 55–75%, Stop <55%); lock scoring rule that defaults to Modify when intervals straddle thresholds; publish thresholds, logic and confidence limits before any Phase One exercises; publish final verdict (rates, intervals, logic, rationale) within 5 days of Phase One conclusion (by Month 9.5 = 2027-07-23) so renegotiation risk is eliminated and both legislatures see objective outcome.

## 1.2 Secondary Actions

- Deploy 300+ inspectors (150–200 per country) using staggered-rotation cohorts (4 months on-site, 2 months off-site) with 20% surge buffer (30–40 per country) and 30% leave coverage; freeze roster by Month 1 (2026-11-08) and complete security clearances by Month 2 (2026-12-08); conduct bilateral training academy Months -1 to 2 (evidence collection, sealed observation, identity verification, exercises) with 80% certified by Month 2.5 (2026-12-23); fund retention bonuses (2–3% of USD 750M personnel envelope, approximately USD 15–22.5M) for 12-month tenure through Phase One conclusion.
- Establish Bilateral Counterintelligence Oversight Board (3 officers per country) by Month 0 (2026-10-08); require all 300+ inspectors to undergo baseline polygraph vetting by Month 2 (2026-12-08) and quarterly re-vetting on rotating schedule; implement secure on-site communication only (no personal phones, monitored channels, 5-minute call limit) for all foreign-stationed inspectors; establish 7-day breach-adjudication protocol (48-hour investigation, 72-hour recommendation, 7-day decision); publish monthly unclassified breach-case count and adjudication outcomes so legislatures see counterintelligence discipline.
- Pre-validate inspector information firewall by Month 0.5 (2026-10-23): convene joint filter-design workshop with inspectors, operators, legal advisors and security engineers to specify evidence filters (preserve event-relevant data, redact network topology, security architecture, customer names, source code); appoint independent filter auditor from neutral third country by Month 0 (2026-10-08) to validate filter compliance by Month 1.5 (2026-11-23); conduct monthly spot-check audits (5–10% sample of filtered packages); implement formal challenge procedure for disputed filters (raw-evidence escort access under dual supervision if counterpart disputes filtering).
- Pre-stage vendor-refusal fallback teams and lock ladder procedures by Month 2 (2026-12-08): conduct vendor outreach and written-commitment requests by Month 1 (2026-11-08) (participate directly or accept fallback testing without veto); document refusals by Month 1.5 (2026-11-23); pre-stage one accredited independent-examiner team per country (5–8 specialists) by Month 1 (2026-11-08) from the USD 500M testing envelope; lock the five-rung fallback ladder (vendor-supervised, filtered evidence, independent examiners, clean-room, validated attestation) with credit toward equipment-identity confidence (rung 1: 70%, 2: 60%, 3: 80%, 4: 85%, 5: 50%); exclude or mark unverifiable any equipment unresolved at entry; publish vendor-participation registry as entry-condition gate by Month 4 (2027-02-08).
- Institute automatic deadlock and suspension procedures as entry-condition items (double-key signed in the bilateral instrument by Month 1 = 2026-11-08): automatic partial suspension at 14 days of unresolved co-chair deadlock (pause only disputed function, leave unrelated sites running); automatic impaired-confidence flag at 21 days (identity disputes) and 28 days (exit dispositions); appoint independent timekeeper (1 per country at neutral facility) reporting weekly with dashboard of open discrepancies by age, suspension count and projected recovery time; escalate to emergency summit if suspension passes 35 days total, with 5-day decision on extend, resume or invoke Stop trigger.
- Pre-register blind-challenge exercise design and scoring authority by Month 2 (2026-12-08): appoint independent Exercise Authority (8 mixed-nationality staff, funded from USD 500M testing envelope) or use cross-designed red-team model (each country's red team designs challenges for counterpart inspectorate, independent referee scores); specify that exercises run only in staging, spare-inventory, maintenance or expansion areas (never interrupt active computation); plan 54 total exercises at 3 sites (6 per type, minimum 6 per event type, pooled n≈54); conduct pilot exercise at Month 5 (2027-03-08) (all 7 event types, non-production datacenter) to calibrate thresholds before Phase One clock starts.
- Establish synchronized tranche structure with 14-day escalation and 30-day Stop trigger: deposit 25% (USD 625M per country) on instrument signature and appropriation (Month 2 = 2026-12-08); 25% on matched-pair approval (Month 3 = 2027-01-08); 30% on entry-gate certification (Month 5.5 = 2027-03-23); 20% on Go/Modify verdict (Month 9.2–9.5); any tranche delay >14 days triggers emergency co-chair escalation; delay >30 days or unequal deposits unresolved is a Stop trigger (withheld funding); do not tie final tranche to verdict outcome, only to verdict publication, so scoring is not biased by funding leverage.
- Validate adjudication surge capacity and age-trigger machinery: confirm that 15 cases/month is achievable with planned staffing (5 adjudication specialists per country, estimate); budget for surge capacity to handle 25–30 cases/month if evidence-rule miscalibration inflates discrepancies; establish mechanical escalation at 21-day (identity) and 28-day (exit) age thresholds that trigger impaired-confidence flag automatically (no co-chair negotiation required); test deadlock procedures in Month 5 (2027-03-08) rehearsal exercise alongside key-custody ceremony and rule validation so suspension triggers are verified operational before Phase One.
- Finalize post-Phase-One funding decision and Modify rework scope by Month 8 (2027-06-08): co-chairs must jointly decide whether a Modify verdict triggers rework (additional exercises, rule adjustment, extended window) or whether Modify means a defined-scope conclusion (Phase One ends, no Phase Two funded, report published as-is); publish this decision before the Month 9.5 (2027-07-23) final verdict so the Go/Modify/Stop outcome is not read as provisional or subject to renegotiation; if rework is funded, lock additional funding, timeline and scope by Month 8 (2027-06-08), not deferred to post-verdict negotiation.

## 1.3 Follow Up Consultation

At the next consultation (recommend Month 0.5 = 2026-10-23), confirm that the Entry-Condition Task Force has launched parallel site-nomination and vendor-outreach tracks, published the compressed-negotiation roadmap with weekly milestones, and activated external escalation authority. Review the draft evidence-weighting rule (in escrow status) and the historical-validation dataset (100–200 events per site) to ensure pilot credibility. Confirm threshold bands and mechanical scoring logic are embedded in the bilateral instrument before Month 1 (2026-11-08). Assess inspector recruitment pace and vetting-capacity constraints to validate Month 2 (2026-12-08) clearance freeze. Address neutral-facility site selection (Geneva or Singapore decision) and host-country permit timeline. Discuss post-Phase-One funding decision (Modify rework yes/no) to close the OPEN item before Month 8 (2027-06-08). Confirm CI Oversight Board is operational and filter-design workshop is scheduled. Lock the vendor-refusal fallback ladder procedure and pre-stage examiner teams.

## 1.4.A Issue - Entry-Gate Timeline Is Sequentially Fragile and Lacks Binding Acceleration Authority

The canonical entry-gate timeline (Months 0–5 = 2026-10-08 to 2027-03-08) lists seven mandatory conditions in a loosely sequenced order. The plan names a 2-week slip tolerance, but no binding weekly milestones, external escalation authority with scope-reduction power, or parallel-track acceleration structure exist. If instrument signature slips to Month 1.5 (2026-11-23) instead of Month 1 (2026-11-08), subsequent gates compress into Months 2–5 (2026-12-08 to 2027-03-08), squeezing the critical pre-clock calibration window (historical validation, pilot exercise, rule lock, threshold pre-registration). An 8-week total slip (realistic given bilateral negotiation pace) compresses Phase One from 90 to 50 days, widening statistical intervals from ±12% pooled to ±18–22%, making the Go/Modify/Stop verdict indefensible. The SWOT Threats section names this but the plan does not operationalize the mitigation: no task-force charter, no parallel site-selection and vendor-outreach kickoff before Month 0 (2026-10-08), and no compressed-negotiation budget carved from contingency.

### 1.4.B Tags

- entry-gate-sequencing
- timeline-slack
- statistical-power-at-risk
- contingency-planning-absent

### 1.4.C Mitigation

Establish a dedicated Entry-Condition Task Force (both co-chairs' offices) at Month 0 (2026-10-08) with weekly dashboard and binding milestone deadlines: instrument signed by Month 0.5 (2026-10-23) (not Month 1 = 2026-11-08), domestic authority by Month 1 (2026-11-08), matched pairs nominated by Month 1 (2026-11-08), inspectors approved by Month 2 (2026-12-08), vendor registry published by Month 1 (2026-11-08), schedule locked by Month 3 (2027-01-08). Launch site-candidate and vendor-outreach tracks in parallel starting Month -2 (before instrument signature), not sequentially after. Reserve USD 50–100M from contingency explicitly for compressed negotiation and expedited vetting. Appoint external escalation authority (neutral senior figure or panel) with power to invoke emergency co-chair summit if any gate slips >2 weeks and 5-day decision authority on scope reduction (2 pairs instead of 3, 60-day test instead of 90) rather than timeline extension.

### 1.4.D Consequence

Without binding acceleration authority and parallel-track activation, Phase One window erodes to 40–60 days, statistical confidence for Go/Modify/Stop becomes indefensible (±20%+ per event type), and the verdict is read as negotiated rather than technical. Vendors discover refusals late, equipment unresolved at entry balloons unverifiable counts to 10–20% per site, and one government may claim the test was rigged by compressed timelines. Stop trigger for thin data becomes unavoidable.

### 1.4.E Root Cause

The plan names the 2-week tolerance and risk but does not instantiate governance machinery (task force, escalation authority, parallel tracks, compressed-negotiation budget) to enforce it. Planning assumes sequential gates will move at predictable pace; bilateral instrument negotiation historically runs 12–24 months, not 6 weeks. The mitigation exists conceptually in the pre-project assessment but is not operationalized in the canonical timeline or governance structure.

## 1.5.A Issue - Evidence-Weighting Rule Is Locked Without Pre-Validation; Miscalibration Risks Adjudication Paralysis

The plan mandates a confidential, rotating evidence-weighting rule (Layered Evidence Weighting Model, choice 2) that accountable specialists set and rotate to prevent gaming. The rule is placed in escrow by Month 4.5 (2027-02-23) and used immediately in Phase One exercises starting Month 6 (2027-04-08). However, the plan validates the rule only against historical, benign equipment-change records (100–200 per site) and does not test it against adversarial scenarios (substitution, doctored timestamps, missing maintenance logs, vendor refusal escalations). If the rule systematically undercredits filtered evidence or overweights contradictions, false-positive rates could reach 20–30% vs. the 10% target, generating 50–100+ discrepancies in 90 days vs. the planned 15/month adjudication capacity. The resulting backlog of unresolved cases (30–50 by Month 9 = 2027-07-08) would trigger impaired-confidence flags and partial suspensions, consuming the latter half of Phase One in disputes rather than detection. No adjustment path exists mid-test; the rule is frozen until the final decision.

### 1.5.B Tags

- evidence-rule-unvalidated
- adversarial-scenario-gap
- adjudication-overload-risk
- false-positive-miscalibration

### 1.5.C Mitigation

Lock the confidential evidence rule in double-key-approved escrow by Month 1.5 (2026-11-23), three months before Phase One. Conduct a mandatory pilot-validation exercise at Month 2 (2026-12-08) at a non-production test datacenter, applying the locked rule to 100–200 historical equipment-change events per site (4–6 weeks of archival data) and comparing output (false positives, false negatives, unverifiable counts) against ground truth from maintenance logs and customs records. If pilot false-positive rate deviates >5 percentage points from the 10% target (i.e., outside 7–13% band), halt Phase One exercises, adjust the rule jointly, and re-validate on a second 100–200 event cohort before proceeding. Document every rule amendment with timestamp, decision rationale and evidentiary basis; publish rule-version history in the final ledger so each finding is traceable to the rule version active when it was classified.

### 1.5.D Consequence

Without pre-validation, miscalibrated evidence weighting floods adjudication with false positives (50–100 cases vs. 15/month capacity) by Month 7 (2027-05-08). Unresolved discrepancies age past 21 days, triggering automatic impaired-confidence flags and partial suspensions that consume the remaining test window. By Month 9, 30–50% of findings are unresolved, the Go/Modify/Stop verdict becomes indeterminate (cannot claim 70% detection if disputes mask the real signal), and one government claims the other side used the rule to suppress unfavorable findings. Phase One credibility collapses and the Stop trigger for 'evidence systems diverge without resolution' is invoked.

### 1.5.E Root Cause

The plan assumes the confidential rule can be locked by Month 4.5 (2027-02-23) and used immediately, without intermediate validation against adversarial behavior. Historical-records validation catches benign miscalibration but not gaming or systematic bias under pressure. The plan names the pre-clock calibration window but treats historical validation as sufficient, neglecting the gap between historical data (no incentive to hide or substitute) and Phase One operations (where both sides actively test verification credibility and vendors resist discovery).

## 1.6.A Issue - Verdict Thresholds Are Pre-Registered But Statistical Confidence Intervals Are So Wide That Boundaries Become Ambiguous and Prone to Political Renegotiation

The plan proposes detection thresholds of ≥70% for planned events and ≥50% for unplanned events as Go criteria, with Modify at 55–75% and Stop <55%. However, the canonical-facts statistical limits are ±12% pooled (n≈54, 95% confidence), ±22% for planned class (n≈16), and ±25% for unplanned class (n≈15). A detected 65% planned-event rate carries a 95% confidence interval of [43%, 87%], which straddles the Modify band (55–75%) entirely. The interval overlaps Go (≥70%), Modify (55–75%) and Stop (<55%) boundaries, making the verdict mechanically ambiguous. The plan states 'default to Modify when intervals straddle thresholds,' but this rule is not locked in advance and is named only in the secondary-actions section of the pre-project assessment. Neither co-chair has committed to accepting Modify as a real outcome (funding for rework is OPEN), so ambiguous intervals create pressure to renegotiate thresholds post-hoc. A detection rate of 68% with interval [46%, 90%] becomes a negotiation point rather than an objective result.

### 1.6.B Tags

- threshold-ambiguity-from-wide-intervals
- statistical-power-insufficient
- post-hoc-renegotiation-risk
- verdict-credibility-at-risk

### 1.6.C Mitigation

Pre-register verdict thresholds in a joint bilateral memorandum locked by both co-chairs by Month 2.5 (2026-12-23, 14:00), before the first Phase One exercise (Month 3 = 2027-01-08). Frame thresholds as explicit confidence-interval bands, not point estimates: Go: ≥75% detection at 90% confidence (lower bound ≥62%); Modify: 55–75%; Stop: <55% (upper bound ≤48%). Apply same structure to unplanned-event thresholds (Go ≥60%, Modify 40–60%, Stop <40%) and false-positive rate (Modify if ≤15%, Stop if >15%). Mark all thresholds 'provisional, validated against pilot data.' Use a mechanical scoring rule: if lower confidence bound exceeds Go threshold, verdict is Go; if upper bound falls below Stop threshold, verdict is Stop; otherwise Modify (default when intervals straddle). Publish thresholds, mechanical scoring logic and confidence-interval bands before any Phase One exercises so results are objective, not negotiated. Publish final verdict (detection rates, intervals, thresholds, scoring logic, rationale) within 5 days of Phase One conclusion (by Month 9.5 = 2027-07-23) so both legislatures see objective outcome and renegotiation risk is eliminated.

### 1.6.D Consequence

Without locked thresholds and mechanical scoring, a Phase One result of 65–72% detection becomes a political argument rather than a technical finding. Each co-chair's legislature reads the wide confidence interval (e.g., [46%, 87%]) and claims ambiguity justifies either Go (upper bound near 70%) or Stop (lower bound near 46%). Renegotiation over thresholds consumes the Month 9.5 (2027-07-23) decision window, final verdict slips to Month 10–12 (2027-08-08 to 2027-10-08), bilateral trust erodes, and one government claims the other manipulated thresholds after seeing results. The Go/Modify/Stop decision loses credibility and legitimacy, defeating the entire purpose of Phase One as a 'credible, reciprocal proof-of-concept.' The plan's final success criterion—'exercises demonstrate reciprocal access and credible detection'—cannot be met if the verdict itself is contested.

### 1.6.E Root Cause

The plan understands that thin 90-day data creates wide intervals (±12–32% per type) but does not lock the threshold-and-scoring rule before Phase One starts. Pre-project assessment names the issue and proposes mechanical scoring and confidence bands, but this is treated as secondary guidance rather than a mandatory entry condition. Neither the canonical facts nor the project plan explicitly states that thresholds are locked and non-negotiable before Month 6 (2027-04-08); instead, the plan allows 'adjustments after pilot data,' which invites post-hoc bargaining when actual results are known. The governance structure (double-key co-chairs with no casting vote) cannot resolve ambiguous thresholds, so mechanical rules become essential but are not yet binding.

---

# 2 Expert: Frontier AI Hardware Attestation Specialist

**Knowledge**: GPU/TPU procurement chains, advanced chip authentication, vendor cooperation and refusal patterns, equipment substitution forensics, cryptographic attestation schemes, supply-chain vulnerability

**Why**: The plan's vendor-refusal fallback ladder (vendor-supervised testing, filtered evidence, independent examiners, clean-room, cryptographic attestation) and the evidence-weighting model depend on knowing which frontier hardware can be authentically attested and which vendors historically cooperate or obstruct. This expert grounds the fallback rungs in realistic hardware and vendor behaviour, evaluates whether the ladder's estimated 8–12 weeks per rung will finish before entry gates, and identifies which equipment classes (GPU cluster vs. custom inference vs. large-model training accelerators) face the highest attestation risk.

**What**: Audit the vendor-refusal fallback ladder against actual Tier-1 vendor (NVIDIA, AMD, Intel, Cerebras, Graphcore, etc.) participation history, export-control constraints, and refusal-pattern precedent; assess which frontier-equipment classes are likely unverifiable under the ladder and whether they should be excluded at entry or designated as hard Stop triggers; validate whether cryptographic attestation (rung 5) can substitute for direct inspection in adversarial contexts.

**Skills**: Supply-chain authentication, vendor relationship management, GPU/accelerator architecture, export-control and sanctions law, cryptographic attestation, substitution-detection forensics, chip-marking and serialization standards

**Search**: GPU supply chain authentication, semiconductor attestation, vendor export control, frontier AI hardware procurement, equipment substitution detection

## 2.1 Primary Actions

- Establish an Entry-Condition Task Force by Month 0 (2026-10-08, 14:00) reporting weekly to both co-chairs, with binding milestones: bilateral-instrument signature Month 0.5 (2026-10-23), domestic authority and appropriation Month 1 (2026-11-08), site nominations Month 1 (2026-11-08), vendor commitments Month 1.5 (2026-11-23), inspector approval Month 2 (2026-12-08), schedule adoption Month 3 (2027-01-08). Activate site and vendor tracks in parallel from Month -2 (2026-08-08). Reserve USD 50–100M explicit compression contingency. Empower external escalation authority to invoke scope reduction (2 pairs, 60 days) if any gate slips >2 weeks.
- Lock and escrow the confidential evidence-weighting rule by Month 1.5 (2026-11-23) in a bilateral memorandum. Validate it by Month 2 (2026-12-08) against 100–200 historical equipment-change events per site. Require pilot false-positive rate 7–13% (±3% of 10% target); if deviation exceeds ±5%, adjust rule and re-validate on a second cohort before Phase One operational exercises. Prohibit rule amendments during Months 6–9 (2027-04-08 to 2027-07-08) (operational window); trigger adjudication surge instead. Maintain versioned rule-change log with every amendment timestamped and double-key-approved.
- Pre-register verdict thresholds with explicit 90% confidence-interval bands by Month 2.5 (2026-12-23, 14:00), before any Phase One exercise: Go planned ≥75% (lower bound ≥62%), Modify 55–75% (upper bound ≤82%), Stop <55% (upper bound ≤48%). Apply mechanical scoring rule: lower bound exceeds Go → Go; upper bound below Stop → Stop; otherwise Modify. Publish unclassified verdict (rates, intervals, thresholds, mechanical rule, rationale) within 5 days of Phase One conclusion.
- Establish a Bilateral Counterintelligence Oversight Board (3 officers per side, joint reporting, monthly classified meetings) by Month 0 (2026-10-08) to detect and adjudicate suspected inspector breaches. Require baseline polygraph vetting of all 300+ inspectors by Month 2 (2026-12-08) and quarterly re-vetting starting Month 3 (2027-01-08). Implement secure on-site communication only (monitored encrypted phone, no personal devices). Enforce 7-day breach-adjudication protocol (48-hour investigation, 72-hour recommendation, 7-day decision). Publish unclassified breach-case counts monthly.
- Pre-stage one accredited independent-examiner team per country (5–8 specialists, frontier-computing qualified, bonded by home government) by Month 1 (2026-11-08), funded from the USD 500M testing envelope. Conduct vendor outreach by Month 1 (2026-11-08) documenting written commitment or refusal from each Tier-1 vendor. Lock the vendor-refusal fallback ladder (five rungs, 8–12 weeks each, 70–85% identity confidence per rung) as a double-key-approved procedure by Month 2 (2026-12-08). Exclude or classify as unverifiable any equipment unresolved at entry (Month 5.5 = 2027-03-23).

## 2.2 Secondary Actions

- Appoint an independent third-country filter auditor by Month 0.5 (2026-10-23) to validate evidence-filtering rules and conduct monthly spot-check audits (5–10% of filtered packages, comparing redacted to raw, confirming event-relevant data preserved). Establish a dispute procedure: if counterpart suspects hidden evidence, invoke 'raw-evidence escort access' (24-hour notice, dual escort, session logged as ledger event). Budget 2–3 days per package for filtering and certification.
- Recruit and vet 300+ inspectors (150–200 per country plus 20% surge buffer, 30% leave coverage) starting Month -3 (2026-07-08); freeze roster by Month 1 (2026-11-08); complete security clearances by Month 2 (2026-12-08). Establish joint training academy by Month -1 (2026-09-08) with 12-day curriculum per cohort (evidence collection, sealed observation, identity verification, exercises). Train three cohorts Months -1 to 2.5 (2026-09-08 to 2026-12-23); certify 80% by Month 2.5 (2026-12-23). Structure shifts: 4 months on-site, 2 months off-site, staggered across cohorts; minimum 6 inspectors per shift (2 countries × 3 each) × 3 shifts × 2–4 sites.
- Establish an independent mixed-nationality Exercise Authority (8 core staff, funded from USD 500M testing envelope) by Month 3 (2027-01-08). Have each country's red team design challenges for the other's inspectorate by Month 4 (2027-02-08), with an independent referee scoring results. Run a pilot multi-type exercise (all 7 event classes) at a non-production site by Month 5 (2027-03-08) to validate exercise procedures and rule calibration before Phase One clock.
- Appoint an independent timekeeper (1 per country, at neutral facility) by Month 0.5 (2026-10-23) to track deadlock age and suspension triggers. Report weekly dashboard (every Monday, 09:00 CET): open-discrepancy counts by age bucket, partial suspensions (14+ days), impaired-confidence status (21+ days identity, 28+ days exit). Implement automatic ledger annotation when thresholds trigger (timestamp, function paused, reason, recovery timeline). Publish unclassified suspension and duration counts weekly.
- Convene a joint filter-design workshop by Month 0.5 (2026-10-23) to specify evidence filters (what is redacted: network topology, security architecture, customer names, model weights, source code; what is preserved: timestamps, serial numbers, arrival/departure, maintenance, physical locations). Lock filter specification by Month 1.5 (2026-11-23). Implement formal challenge procedure and conduct independent monthly spot-check audits of filtered packages.
- Lock deadlock, impaired-confidence and automatic-suspension thresholds into the bilateral instrument by Month 1 (2026-11-08): partial suspension at day 14, impaired-confidence at day 21 (identity) and day 28 (exit), emergency summit if suspension passes 35 days. Design a de-escalation protocol: if both co-chairs agree to resume before full resolution, resume with notation that finding remains open (no dismissal). Make these thresholds non-negotiable entry conditions.
- Establish a joint terminology board and controlled glossary by Month 1.5 (2026-11-23). Use coded language-neutral schema for evidence entries to minimize translation disputes. Require independent bilingual back-translation of all findings before double-key sign-off; reject findings whose back-translations materially differ. Set translation turnaround targets (current: TBD; recommend 2–3 days for standard entries, 5 days for disputed findings).
- Synchronize the four tranches (25% at Month 2 = 2026-12-08, 25% at Month 3 = 2027-01-08, 30% at Month 5.5 = 2027-03-23, 20% at Month 9.2 = 2027-07-14) and audit envelope mapping 100%. Establish that tranche delay >14 days triggers co-chair escalation; delay >30 days or unequal deposits unresolved is a Stop trigger (withheld funding). Do not tie the final tranche to a Go/Modify outcome, only to verdict publication. Settle post-Phase-One funding by Month 8 (2027-06-08).

## 2.3 Follow Up Consultation

Next meeting should cover: (1) Formal task-force charter and weekly reporting protocol to keep entry gates on schedule; (2) approval of the draft evidence rule and escrow procedures by Month 1.5 (2026-11-23), with pilot-validation results review by Month 2 (2026-12-08); (3) finalized confidence-band thresholds and mechanical scoring rule by Month 2.5 (2026-12-23), locked before any exercises; (4) counterintelligence oversight-board charter and breach-adjudication protocol; (5) vendor-participation registry status and first-rung fallback timeline; (6) site-selection parity audit results and matched-pair confirmation by Month 3 (2027-01-08); (7) training academy curriculum and inspector certification plan; (8) neutral facility location and host-country permits. Prepare for re-scoping decision (2 pairs, 60 days) if any gate slips >2 weeks.

## 2.4.A Issue - Entry-Condition Gates Lack Binding Acceleration Mechanisms and Risk Catastrophic Timeline Compression

The entry-condition roadmap (Months 0–5 = 2026-10-08 to 2027-03-08) lists seven mandatory gates but provides no binding weekly milestones, parallel-track activation dates, or escalation authority with emergency re-scoping power. Sequential processing of instrument signature → domestic authority → site selection → inspector approval → vendor commitments → schedule adoption risks 4–8 week slippage, compressing Phase One from 90 days to 45–60 days and widening statistical confidence intervals from defensible ±10–15% to indefensible ±20–25%. The plan names a task force and summit trigger (gate slip >2 weeks) but does not bind the task force to weekly reporting, does not empower the summit to decide scope reduction (fewer sites, shorter test), and does not reserve the USD 50–100M compression budget explicitly in the contingency envelope.

### 2.4.B Tags

- entry-gate-sequencing
- timeline-compression-risk
- statistical-power-loss
- missing-acceleration-authority
- contingency-reserve-undefined

### 2.4.C Mitigation

Establish an Entry-Condition Task Force by Month 0 (2026-10-08, 14:00) with binding weekly milestone report-outs (every Monday, 09:00 CET). Publish a master roadmap showing bilateral-instrument signature by Month 0.5 (2026-10-23), domestic-authority enactment and first-tranche appropriation by Month 1 (2026-11-08), site nominations by Month 1 (2026-11-08), vendor written commitments by Month 1.5 (2026-11-23), inspector approval by Month 2 (2026-12-08), and schedule adoption by Month 3 (2027-01-08). Activate site-candidate identification and vendor outreach in parallel starting Month -2, not sequentially after instrument signature. Empower an external escalation authority (named joint summit with 5-day decision window) to invoke mandatory scope reduction (2 pairs instead of 3, or 60-day instead of 90-day test) rather than timeline extension if any gate slips >2 weeks. Reserve USD 50–100M explicitly from the contingency envelope (separate from the free contingency) for compressed negotiation costs.

### 2.4.D Consequence

Without binding acceleration, entry-condition processing stalls into Month 6 (2027-04-08) or later, compressing Phase One to 45–60 days. Thin-data confidence intervals widen from ±10–15% to ±20–25%, making a 70% detection rate defensible as Go, Modify, or Stop and inviting post-hoc political renegotiation of the verdict. Statistical power loss also reduces the credibility of 'no hard Stop trigger' findings. Phase One becomes a non-credible proof-of-concept, undermining the Consortium's political legitimacy and forcing a costly re-run or abandonment.

### 2.4.E Root Cause

The plan treats entry conditions as a formal prerequisite checklist without operationalizing the acceleration levers (parallel tracks, weekly milestones, re-scoping authority) or the financial reserve needed to compress timelines. The assumption that gates will be met on time lacks accountability mechanisms or contingency pathways. This reflects a planning pattern of stating constraints without designing the operational governance to enforce them under political pressure.

## 2.5.A Issue - Evidence-Weighting Rule Locked Without Pre-Validation, Creating Adjudication Paralysis Risk and Threshold-Ambiguity Scenarios

The plan specifies that the confidential, rotating evidence-weighting rule (chosen strategic decision: rotating rule set by accountable specialists, weights validated against blind-exercise outcomes) is locked by Month 4.5 (2027-02-23) but validated only against historical records, not adversarial scenarios or synthetic cases mimicking operator gaming. If the locked rule miscalibrates false-positive rates to 20–30% versus the 10% target, Phase One will generate 50+ discrepancies per month instead of the planned 15, overloading the adjudication unit and leaving 30–50% of findings unresolved at conclusion. The plan also does not specify how miscalibration is detected mid-Phase-One or whether rule adjustments mid-test are permitted (which would compromise comparability of exercise results across versions).

### 2.5.B Tags

- rule-validation-gap
- false-positive-rate-risk
- adjudication-capacity-overload
- mid-test-recalibration-ambiguity
- adversarial-scenario-untested

### 2.5.C Mitigation

Lock the confidential evidence rule in escrow (double-key-approved memorandum, both co-chairs sign simultaneously) by Month 1.5 (2026-11-23). Conduct a mandatory pilot-validation exercise by Month 2 (2026-12-08) at a non-production test datacenter, applying the locked rule to at least 100–200 historical equipment-change events per site (4–6 weeks of historical maintenance and customs records). Compute false-positive rate, false-negative rate, and unverifiable-equipment count against known ground truth. Compare pilot output to within ±3% of threshold (if target is ≤10%, pilot must produce 7–13%). If deviation exceeds ±5%, halt Phase One exercises, adjust rule, and re-validate using a second 100–200 event cohort before proceeding. Maintain a versioned rule-change log with every amendment timestamped, double-key-approved, and linked to evidentiary outputs triggering the change. Prohibit rule amendments during Months 6–9 (2027-04-08 to 2027-07-08) (Phase One operational window); any perceived miscalibration triggers adjudication surge funding, not rule changes.

### 2.5.D Consequence

A locked but miscalibrated rule produces 50+ discrepancies per month, overwhelming the adjudication unit sized for 15 cases. By Month 8 (2027-06-08), 100–150 unresolved discrepancies accumulate, triggering the 'no discrepancy older than 21 days' failure and automatic Modify or Stop verdict regardless of actual detection performance. The exercise data become unreliable because too many findings are open and contested. Phase One conclusions lose credibility and both governments dispute the verdict as procedurally compromised rather than evidentially sound.

### 2.5.E Root Cause

The plan assumes the evidence rule can be locked on specialist consensus and validated against benign historical data, but does not account for adversarial behavior by operators trying to game the rule's thresholds, or for the discovery mid-test that a rule miscalibration will overflow the adjudication pipeline. The validation pathway is incomplete: historical records alone do not capture gaming patterns that emerge when operators know the rule and try to stay just inside or outside its boundaries. This reflects a gap between design-phase confidence and operational-phase realism.

## 2.6.A Issue - Verdict Thresholds Pre-Registered as Point Estimates Without Explicit Confidence Bands, Enabling Post-Hoc Reinterpretation and Political Bargaining Over Go/Modify/Stop

The plan specifies that verdict thresholds (70% detection for planned events, 50% for unplanned, ≤10% false positives) are locked before Phase One exercises, but does not specify confidence intervals around these point estimates. With ±12% pooled confidence (95% CL) and ±32% per-type intervals (estimate), a detected-event rate of 70% carries a 90% confidence interval of approximately 58–82%. This means a 70% observed rate is indistinguishable from 55% or 75%, making Go, Modify, and Stop all defensible. The plan states thresholds should be 'marked provisional or TBD,' but does not provide explicit numerical confidence bands or a pre-registered mechanical scoring rule. The verdict logic (4 of 5 criteria met = Go, 3 of 5 = Modify, <2 = Stop) is stated but the scoring of criteria when intervals are ambiguous is left to co-chair judgment, reintroducing the political bargaining the plan aims to prevent.

### 2.6.B Tags

- threshold-ambiguity
- missing-confidence-bands
- mechanical-scoring-undefined
- post-hoc-bargaining-risk
- interval-straddling-unresolved

### 2.6.C Mitigation

Pre-register verdict thresholds in a joint bilateral memorandum locked by both co-chairs by Month 2.5 (2026-12-23, 14:00), before any Phase One exercise, using explicit confidence-interval bands rather than point estimates: Go threshold for planned-event detection ≥75% at 90% confidence (lower bound ≥62%); Modify 55–75% (upper bound ≤82%); Stop <55% (upper bound ≤48%); apply same structure to unplanned-event thresholds (Go ≥60%, Modify 40–60%, Stop <40%) and false-positive rate (Modify if ≤15%, Stop if >15%). State all thresholds 'provisional, validated against pilot data.' Score final Phase One results using a pre-registered mechanical rule: if the lower bound of the 90% confidence interval exceeds the Go threshold, verdict is Go (no co-chair discretion); if the upper bound falls below the Stop threshold, verdict is Stop; otherwise Modify (default when intervals straddle a threshold). Publish unclassified final verdict (detection rates, 90% confidence intervals, thresholds, mechanical scoring logic, verdict rationale) within 5 days of Phase One conclusion (by Month 9.5 = 2027-07-23, 14:00) so both legislatures see the objective outcome and the transparent scoring rule.

### 2.6.D Consequence

Without explicit confidence bands and a mechanical scoring rule, either co-chair can argue that observed results fall within their preferred interpretation. A 70% detection rate becomes a contested political outcome: the US co-chair argues it meets the 70% Go threshold, while the Chinese co-chair argues the wide intervals mean Modify is more honest. The verdict itself becomes an arms-control negotiation rather than a technical judgment. This delegitimizes Phase One as an experiment and invites legislative rejection of the outcome in at least one country, undermining the Consortium's credibility for any Phase Two.

### 2.6.E Root Cause

The plan emphasizes that thresholds must be provisional and marked TBD, but does not operationalize this through explicit confidence bands or mechanical scoring logic. It assumes that stating 'provisional' and locking thresholds before exercises will prevent bargaining, but thresholds stated as point estimates (70%, 50%) invite reinterpretation once data arrive with large uncertainty ranges. The gap reflects insufficient attention to the statistical power of a 90-day, 54-exercise test: the confidence intervals are wide enough that nearly any observed result is ambiguous, so the verdict rule must be mechanical and pre-locked to avoid this ambiguity becoming a political opening.

---

# 3 Expert: Counterintelligence and Information-Barrier Operations Lead

**Knowledge**: CI tradecraft, inspector vetting and compartmentalization, IP protection in sensitive facility access, firewall design, breach investigation, CI board governance, secure communications protocols

**Why**: The plan's success depends on inspectors compartmentalized by site and role, with filtered evidence, sealed observation-report models, and post-assignment debriefs and cooling-off periods. The Counterintelligence Oversight Board (3 officers per side, monthly classified meetings, quarterly re-vetting, 7-day breach adjudication) is a critical governance gate that must be operationally credible to both governments. This expert validates whether the inspector compartmentalization, evidence filtering, and CI Board design will actually contain IP leaks and detect breaches without paralyzing the program.

**What**: Design the CI vetting protocol for 360 inspectors (baseline polygraph or equivalent by Month 2 = 2026-12-08, quarterly re-vetting, compartmentalization rules); specify which classified detail each inspector role may see (equipment serial numbers yes, network topology no, customer names no, maintenance logs yes); establish the breach-investigation fast-track (48-hour investigation, 72-hour recommendation, 7-day decision) with decision trees for inspector recall, remediation or suspension; draft the monthly unclassified breach-count summary that legislatures can see without exposing operational details.

**Skills**: Personnel security vetting, compartmentalization design, evidence filtering and certification, breach investigation and adjudication, CI board governance, secure communications, polygraph program management

**Search**: Counterintelligence vetting inspectors, compartmentalization protocol, information barrier design, breach investigation fast-track, CI board governance

## 3.1 Primary Actions

- Establish a dedicated Entry-Condition Task Force (both co-chairs' offices) by Month 0 (2026-10-08, 14:00) with binding weekly milestone deadlines. Launch parallel tracks for site nomination, vendor outreach and inspector vetting starting Month -2 (2026-08-08), not sequentially after instrument signature. Appoint an external escalation authority (neutral third-country official) empowered to invoke emergency co-chair summit within 48 hours if any gate slips >2 weeks, with 5-day binding decision on scope reduction (fewer sites, shorter test) versus timeline extension.
- Lock the confidential evidence-weighting rule in escrow by Month 1.5 (2026-11-23), double-key approved. Conduct mandatory pilot validation by Month 2 (2026-12-08) on 100–200 historical equipment-change events per site AND 20–30 adversarial synthetic substitution cases per site. Require false-positive rate (actual minus target) within ±3 percentage points and false-negative rate <20% on synthetic cases. If deviation exceeds ±5 percentage points, adjust and re-validate on a second cohort by Month 2.5 (2026-12-23) before proceeding to Phase One.
- Pre-register verdict thresholds and mechanical scoring rule in a joint bilateral memorandum signed by both co-chairs by Month 2.5 (2026-12-23), at least 3.5 weeks before Phase One clock. Specify Go/Modify/Stop as confidence-interval bands, not point estimates. Specify mechanical rule: 'If interval straddles threshold, verdict defaults to Modify; no co-chair negotiation permitted after Phase One begins.' Publish the unclassified final verdict within 5 days of Month 9 (2027-07-08) so legislatures see objective outcome.
- Reserve USD 50–100 million from the USD 500M contingency explicitly for compressed entry-condition negotiation, expedited vetting, and 24/7 task-force surge. Authorize the Entry-Condition Task Force to draw from the compression reserve without requesting co-chair approval for each draw (summary reporting only). If any gate slips >2 weeks despite acceleration, the external escalation authority invokes the decision to reduce scope (e.g., 2 pairs instead of 3, 60-day test instead of 90) rather than extend timeline.
- Conduct bilateral Counterintelligence Oversight Board inaugural meeting by Month 0 (2026-10-08, 16:00) with 3 senior CI officers per country. Require all 300+ deployed inspectors to undergo baseline polygraph/security vetting by Month 2 (2026-12-08, 09:00) and quarterly re-vetting thereafter. Implement secure on-site communication (no personal phones, single monitored channel per inspector per shift) and publish unclassified monthly count of adjudication cases (breaches suspected, sustained, false positives) so political leadership sees breach-management discipline.

## 3.2 Secondary Actions

- Pre-stage one accredited independent-examiner team per country (5–8 specialists each) by Month 1 (2026-11-08, 16:00), funded from the USD 500M testing envelope, to activate the vendor-refusal fallback ladder immediately if a vendor declines direct participation. Document vendor positions (participation, refusal, or fallback demand) by Month 3 (2027-01-08) and publish a vendor-participation registry as an entry-condition gate. Lock the fallback ladder (five rungs, 8–12 weeks each) as a double-key-approved procedure by Month 2 (2026-12-08, 09:00).
- Appoint an independent filter auditor (qualified IT/security specialist from a neutral third country, pre-approved by both co-chairs by Month 0 = 2026-10-08) to validate evidence filters by Month 1.5 (2026-11-23, 10:00). Conduct monthly spot-check audits (5–10% sample of filtered packages) and maintain formal challenge procedure: if counterpart disputes filtering, initiate raw-evidence escort access under dual escort, recorded as a ledger event. Document filter-certification results monthly (count of packages filtered, challenged, re-filtered, audit findings and latency).
- Recruit and vet 300+ full-time inspectors (150–200 per country plus 30–40 per-country surge) beginning Month -3 (2026-07-08), targeting 80% roster freeze by Month 1 (2026-11-08, 14:00) and full security-clearance completion by Month 2 (2026-12-08, 09:00). Establish joint training academy by Month -1 (2026-09-08, 10:00) with bilateral curriculum (evidence collection 4 days, sealed observation 3 days, identity verification 3 days, live exercises 2 days). Train first cohort Months -1 to 0, second cohort Months 0–1 (2026-10-08 to 2026-11-08), final cohorts Months 1–2 (2026-11-08 to 2026-12-08), so 80% certified-ready by Month 2.5 (2026-12-23, 17:00).
- Appoint an independent timekeeper (one per country, reporting to both co-chairs) by Month 0 (2026-10-08, 16:00) to track elapsed time from discrepancy opening to closure. Publish mandatory weekly dashboard (every Monday, 09:00 CET) showing discrepancy count by age bucket (0–7 days, 8–14 days, 15–21 days, 22+ days), count in automatic partial suspension (14+ days), count in impaired-confidence (21+ days identity, 28+ days exit), and projected recovery timeline. Publish unclassified monthly count of suspensions and average suspension duration to legislatures.
- Select and secure the neutral facility (Geneva or Singapore) by Month 1 (2026-11-08, 09:00), at least 1,000 sq m, operationally ready by Month 3 (2027-01-08). Fund from the USD 750M secure-facilities envelope. Conduct first joint key-custody ceremony (dual-share generation) at the neutral facility by Month 4 (2027-02-08); rehearse key recovery by Month 5 (2027-03-08). Establish secure reading room for counterpart evidence review and joint ledger-synchronization infrastructure (hourly digest exchange, automated mismatch alerts).
- Lock the Covered-Equipment Schedule as a confidential, versioned, technology-neutral document by Month 3 (2027-01-08), double-key approved by both co-chairs. Freeze it for the entire Phase One window (Months 6–9 = 2027-04-08 to 2027-07-08); permit amendments only before Month 5.5 (2027-03-23) or at final decision (effective for later events only). Maintain a versioned change log with every amendment timestamped and linked to the technical rationale. Publish rule-version history in final ledger so audit trail shows which version classified each finding.

## 3.3 Follow Up Consultation

At the next consultation (recommend Month 1 = 2026-11-08), review: (1) Entry-Condition Task Force milestone completion and parallel-track acceleration status (site nominations, vendor outreach, vetting pipelines). (2) Evidence-rule draft and pilot-validation protocol (historical dataset sourced, synthetic adversarial cases designed, validation laboratory ready). (3) Neutral facility site selected and operational readiness timeline confirmed. (4) Bilateral CI Oversight Board inaugural meeting outcomes and inspector recruitment/vetting pipeline status. (5) Verdict-threshold bilateral memorandum draft for co-chair signature and legal review. (6) Adjudication surge-capacity plan if false-positive rate in pilot exceeds ±5% of target. Discuss any early signals of gate-slip risk and pre-authorize scope-reduction triggers.

## 3.4.A Issue - Entry-Condition Gates Lack Binding Acceleration Mechanism and Parallel-Track Enforcement

Current plan states 'Any gate slipping over 2 weeks: emergency co-chair summit within 5 days; entry gate not certified by Month 9 (2027-07-08): formal Stop/re-scope decision.' But no binding mechanism forces a decision in 5 days, and 're-scope' is undefined. Co-chairs can use the summit to negotiate another 3–4 weeks. The compression reserve (USD 50–100M) is allocated but not explicitly authorized for parallel-track acceleration (expedited vetting, duplicate negotiation teams, 24/7 task-force staffing). Sites, vendors and inspectors are proposed but not pre-nominated; recruitment and vetting timelines assume sequential gates.

### 3.4.B Tags

- entry-gate-sequencing
- timeline-compression-risk
- no-escalation-authority
- statistical-confidence-degradation
- contingency-underutilized

### 3.4.C Mitigation

Establish a dedicated Entry-Condition Task Force (both co-chairs' offices) with binding weekly milestone deadlines by Month 0 (2026-10-08, 14:00). Publish a master roadmap showing bilateral-instrument signature Month 0.5 (2026-10-23), domestic authority Month 1 (2026-11-08), site nominations and vendor outreach in parallel starting Month -2 (2026-08-08), inspector approval Month 2 (2026-12-08), schedule adoption Month 3 (2027-01-08). Launch parallel tracks immediately (do not wait for instrument signature). Reserve USD 50–100M from contingency explicitly for compressed negotiation, expedited vetting, and 24/7 task-force surge. Appoint an external escalation authority (neutral third-country official, pre-approved by both co-chairs) empowered to invoke emergency co-chair summit within 48 hours if any gate slips >2 weeks, with 5-day binding decision: extend timeline (and compress Phase One by equivalent days) or reduce scope (fewer sites, shorter test window). Publish weekly milestone status every Monday, 09:00 CET, to both legislatures.

### 3.4.D Consequence

Without acceleration enforcement: (1) Nominal 90-day test compresses to 45–60 days, reducing exercises from 54 to ~32–36 (below minimum 6 per event type at 3 pairs). (2) Confidence intervals widen from ±12% to ±15–20% pooled, making Go/Modify/Stop thresholds ambiguous (e.g., 70% detection rate defensible as any outcome). (3) Statistical claim of credible detection becomes indefensible, and the verdict is politically vulnerable (either side can argue miscalibration). (4) Contingency (USD 500M) exhausted by delay costs (USD 100–500M for 8–12 week slip), leaving no buffer for mid-Phase-One surprises. (5) Vendor-refusal ladder cannot complete (five rungs × 8–12 weeks); equipment left unverifiable or excluded, undermining coverage. (6) Phase One becomes a brittle, rushed proof-of-concept that neither side credits as rigorous.

### 3.4.E Root Cause

Plan acknowledges gate-slip risk but treats it as a governance problem (summit, negotiation) rather than an operational one (acceleration, parallel tracks, scope flexibility). Compression reserve is notional; no mechanism allocates it proactively. Task force is mentioned but not mandated with binding authority. External escalation is absent—co-chairs negotiate without real consequences for delay. Plan assumes goodwill compliance with sequential timeline, which is unrealistic under mutual distrust.

## 3.5.A Issue - Confidential Evidence-Weighting Rule Locked Without Pre-Validation; Miscalibration Risk Overwhelming

Plan states 'evidence rule validated on 100–200 historical events per site' and 'pilot false positives within 7–13% (10% target ±3 points).' But no adversarial test is planned before Phase One. Historical equipment-change logs do not include deliberate substitutions, operator misdirection or vendor refusal scenarios. If the rule overweights certain evidence categories (e.g., customs records) that an operator can forge or delay, false positives spike mid-test, and the rule cannot be adjusted (schedule frozen, double-key gate on amendments). Even if miscalibration is detected at Month 6 (2027-04-08), fixing it requires ~4 weeks and double-key approval, consuming 45% of Phase One.

### 3.5.B Tags

- rule-validation-gap
- adversarial-testing-absent
- false-positive-overload-risk
- adjudication-capacity-mismatch
- locked-rule-no-mid-test-correction

### 3.5.C Mitigation

Conduct mandatory pre-Phase-One validation of the confidential evidence rule using both historical records and synthetic adversarial cases. (1) Lock the draft rule in escrow by Month 1.5 (2026-11-23), double-key approved by both co-chairs' accountable specialists, published in a sealed bilateral memo. (2) Pilot-validate it on 100–200 historical equipment-change events per site by Month 2 (2026-12-08), comparing false-positive rate (actual minus target) to within ±3 percentage points (e.g., if target is 10%, actual must land 7–13%). (3) Add adversarial synthetic cases: generate 20–30 equipment-substitution scenarios (e.g., swapped serial numbers, forged customs records, delayed maintenance logs) per site, apply the rule, and confirm it detects >80% of seeded substitutions (false-negative rate <20%). (4) If historical pilot deviates >5 percentage points from target or adversarial false-negative rate exceeds 20%, adjust the rule and re-validate on a second cohort of 100–200 historical events by Month 2.5 (2026-12-23) before locking. (5) Maintain a versioned rule-change log with every amendment timestamped, double-key approved, and linked to the validation output that triggered the change. Publish rule-version history in the final ledger so audit trail shows which version classified each finding.

### 3.5.D Consequence

Without pre-validation and adversarial testing: (1) Rule miscalibration (false-positive rate 20–30% vs. 10% target) surfaces at Month 6–7 (2027-04-08 to 2027-05-08), when 100+ discrepancies have been recorded. (2) Adjudication backlog swells from 15/month (planned capacity) to 30–50/month, exceeding the 5-person unit by 6–10×. (3) >50% of discrepancies remain open at Phase One conclusion (Month 9 = 2027-07-08), a hard Stop trigger (plan: 'no discrepancy older than 21 days at conclusion'). (4) Rule amendment requires double-key approval and schedule version management; fixing mid-test consumes 3–4 weeks and may invalidate earlier findings. (5) Verdict is non-credible: high false-positive count looks like either party is gaming the rule or the rule is broken. Phase One fails on adjudication-load alone, independent of detection rates. (6) Contingency (USD 500M) consumed by surge staffing (additional adjudication and appeals staff), leaving no buffer for other surprises.

### 3.5.E Root Cause

Empty

## 3.6.A Issue - Verdict Thresholds Marked Provisional but Not Pre-Registered; Post-Hoc Bargaining Risk Undermines Credibility

Plan states 'Set provisional thresholds before the first exercise, mark each as provisional or TBD, and lock them only after a mirrored panel validates them against pilot data.' But no lockdown date, bilateral signature or publication of locked thresholds is mandated. The KPI dashboard mentions thresholds but does not show the pre-registered values or the mechanical scoring rule. If thresholds are provisionally set at Month 2 (2026-12-08) and 'locked' at Month 5.5 (2027-03-23), they are still not jointly signed and published before the Phase One clock (Month 6 = 2027-04-08). A government can argue later that its understanding of 'provisional' was different.

### 3.6.B Tags

- threshold-preregistration-absent
- mechanical-scoring-undefined
- post-hoc-renegotiation-risk
- interval-ambiguity-exploited
- verdict-credibility-threatened

### 3.6.C Mitigation

Pre-register verdict thresholds and mechanical scoring rule in a joint bilateral memorandum, signed by both co-chairs, and locked (no further amendment) by Month 2.5 (2026-12-23), at least 3.5 weeks before the Phase One clock (Month 6 = 2027-04-08). (1) Specify thresholds as confidence-interval bands, not point estimates: Go if lower bound of detection interval exceeds 70% at 90% CL; Modify if upper bound of interval exceeds 55% and lower bound is below 75%; Stop if upper bound falls below 55% at 90% CL. (2) Use the same structure for false-positive rate (Modify if ≤15%; Stop if >15%) and unverifiable-equipment rate (Stop if >10% at a site or >5% overall). (3) Publish mechanical scoring logic in the memorandum: 'Results are scored by the Exercise Authority using pre-registered intervals. If the confidence interval straddles a threshold boundary, the verdict defaults to Modify. No co-chair negotiation of the interval or threshold is permitted after Phase One begins.' (4) Mark all thresholds 'provisional, validated against pilot data from Month 2 (2026-12-08) pilot exercises'; document the adjustment logic: if pilot detection deviates >20% from assumption, thresholds may shift by up to ±3–5 percentage points, but no adjustment is allowed after the bilateral memorandum is signed. (5) Publish the unclassified final verdict (detection rates, intervals, thresholds, mechanical logic, verdict rationale) within 5 days of Phase One conclusion (by Month 9.5 = 2027-07-23) so both legislatures see objective outcome.

### 3.6.D Consequence

Without pre-registration and mechanical scoring: (1) When detection lands in an ambiguous zone (e.g., 65% ±12%), each government interprets the interval to favor its preferred outcome (US argues 'lower bound 53% supports Modify'; China argues 'central estimate 65% supports Go'). (2) Co-chairs enter post-Phase-One negotiation over methodology rather than results, consuming weeks and delegitimizing the decision. (3) Either government can cite 'provisional threshold' language to demand a re-vote or a second 90-day test. (4) Political factors override technical scoring, and the verdict becomes indistinguishable from a negotiated outcome without evidentiary basis. (5) Phase One is framed as inconclusive or rigged, damaging bilateral confidence in the mechanism itself. (6) Any subsequent phase or continuation is politically vulnerable; legislatures question whether objectives were met or simply negotiated.

### 3.6.E Root Cause

Empty

---

# 4 Expert: Provisional Thresholds Statistician and Uncertainty Quantifier

**Knowledge**: Small-sample inference, binomial confidence intervals, statistical power analysis, threshold ambiguity under thin data, provisional-then-validated threshold design, Go/No-Go decision theory under uncertainty

**Why**: The plan's Go/Modify/Stop verdict rests on detection thresholds (70% planned, 50% unplanned, ±32% per-type intervals at 95% CL from about 8 exercises per type) that are explicitly 'provisional, validated against pilot data.' The statistical intervals are so wide that a 60–80% outcome is defensible as Go, Modify, or Stop depending on weighting. This expert bridges the gap between the plan's honest provisional-threshold requirement and the need for a credible, non-negotiable verdict by designing a pre-registered confidence-interval band structure (Go ≥75% at 90% CL, Modify 55–75%, Stop <55%) and a mechanical scoring rule that defaults to Modify when intervals straddle a threshold, removing post-hoc bargaining leverage.

**What**: Validate the proposed detection thresholds (70%, 50%, TBD) and confidence-interval bands (Go ≥75% at 90% CL) against the thin sample size (n≈8 per event type, n≈16 planned class, n≈15 unplanned class); confirm that the ±32% per-type and ±12% pooled intervals match the 54-exercise design; design a mechanical scoring rule with decision trees (e.g., if lower confidence-interval bound exceeds Go threshold, verdict is Go with no co-chair negotiation; if upper bound falls below Stop threshold, verdict is Stop; otherwise default Modify); model false-positive and false-negative error rates under each threshold choice and show trade-offs; recommend whether historical pilot data from Month 5 (2027-03-08) can narrow the intervals or should be held separate as validation.

**Skills**: Binomial and Bayesian inference, confidence-interval construction, power analysis, sequential testing under small n, decision thresholds under ambiguity, threshold-calibration methodology, Monte Carlo simulation

**Search**: Binomial confidence intervals small sample, Go/No-Go decision thresholds, provisional validation threshold design, detection rate uncertainty quantification

## 4.1 Primary Actions

- Lock the detection-threshold confidence-interval methodology and decision rule (including confidence level, interval type, and which bound governs each verdict category) in a joint bilateral memorandum by Month 2.5 (2026-12-23, 14:00), before any Phase One exercise. Publish the rule unclassified so legislatures can audit the scoring logic.
- Conduct a bifurcated evidence-rule validation by Month 2.5 (2026-12-23, 14:00): (1) historical benign cohort (100-200 records per site, completed by Month 2 = 2026-12-08); (2) adversarial synthetic cohort (40-60 gaming scenarios per site, completed by Month 2.5 = 2026-12-23). Require false-positive rates ≤13% on benign cases and detection of ≥85% of synthetic adversarial cases. If adversarial cohort shows >15% missed cases, adjust the rule and re-validate both cohorts before proceeding to Phase One.
- Define operationally measurable parity metrics by Month 4 (2027-02-08) and lock them in the bilateral instrument: inspector-hour parity ≥90%, exercise parity ≥5 per type per site, data-access parity ≤3 days average, challenge-outcome agreement ≥80%. Report parity weekly during Phase One; if any metric falls below 80%, convene co-chairs within 5 days to address asymmetry or jointly flag result as impaired parity.
- Allocate USD 2-3M from the testing envelope (500M) for adversarial synthetic-case design and red-team validation of the evidence rule. Establish a Rule Validation Task Force (2-3 statisticians, 2-3 red-team members, 1-2 subject-matter experts per country) by Month 1 (2026-11-08, 09:00).
- Establish an independent confidence-interval auditor (qualified statistician, neutral third country, pre-approved by both co-chairs) by Month 2 (2026-12-08, 09:00) to certify that pilot data analysis follows the locked methodology and that final Phase One scoring applies the pre-registered rule without post-hoc adjustment.

## 4.2 Secondary Actions

- Commission a small pre-Phase-One pilot exercise (all 7 event types, non-production site, Month 5 = 2027-03-08) and apply both the benign-validation and confidence-interval rules mechanically to the pilot results. Document any ambiguities or interval-straddling outcomes and use them to clarify the decision rule before the Month 6 (2027-04-08) Phase One clock.
- Design the red-team challenge library (cross-designed by each country's red team for the other's inspectorate) using the locked evidence rule as a reference. Explicitly code which evidence layers each synthetic scenario exploits (e.g., 'scenario 3: misidentified serial vs. matching maintenance records = contradiction scoring test'). Publish a sanitized challenge-design rubric unclassified so both sides can assess representativeness.
- Establish a Threshold Sensitivity Analysis Report (due by Month 5 = 2027-03-08) showing: if detection lands at 60%, 65%, 70%, 75%, what verdict does the locked confidence-interval rule yield under plausible interval widths (±12% pooled, ±25% per type)? Publish this sensitivity matrix unclassified so co-chairs see exactly where ambiguity remains and can jointly decide whether to narrow intervals through extended Phase One, more exercises, or accept the provisional boundaries.
- Create a Verdict-Contingency Playbook (due by Month 5 = 2027-03-08) outlining co-chair actions if the final verdict lands in an ambiguous zone (e.g., Modify becomes the mechanical outcome but one co-chair argues the evidence supports Go). Pre-agree whether such cases trigger a re-decision meeting, independent re-scoring, or automatic default to Modify.
- Assign a dedicated Parity Measurement Officer (1 per country, both reporting to co-chairs) by Month 3 (2027-01-08, 09:00) to track and publish the four parity metrics weekly during Phase One and escalate asymmetries to co-chairs within 24 hours of discovery.
- Develop a fallback adjudication surge plan (estimated 20-30 cases per month if false-positive rate reaches 20%) within the USD 750M personnel envelope by Month 3 (2027-01-08, 14:00), including surge staffing, temporary overtime authorization, and escalation triggers. Budget approximately USD 1.5-2M for adjudication surge capacity above the planned 15 cases per month.

## 4.3 Follow Up Consultation

"In the next consultation (Month 1 = 2026-11-08), discuss: (1) Which confidence-level pairing (90% for Go/Modify, 95% for Stop) is politically acceptable to both co-chairs, and does the asymmetric confidence choice signal mistrust? (2) How many synthetic adversarial scenarios constitute 'adequate validation'—40 per site, 100, or 200? (3) If parity metrics reveal asymmetry mid-Phase-One (e.g., one side's red team has more access to staging areas), does that trigger suspension or re-calibration of thresholds? (4) Should the pilot exercise (Month 5 = 2027-03-08) results be used to adjust thresholds before Phase One, or locked before the pilot? (5) What is the mechanism for breaking a tie if both co-chairs dispute the confidence-interval auditor's scoring? Recommend consulting a bilateral statistical advisory panel (3-4 independent statisticians from neutral countries) by Month 3 (2027-01-08) to pre-vet the methodology so co-chairs do not re-litigate confidence intervals during Phase One operations."


## 4.4.A Issue - Detection Thresholds Rest on Thin Statistics Without Pre-Specification of Confidence-Interval Methodology

The plan proposes Go at ≥70% planned-event detection and ≥50% unplanned-event detection. With 54 total exercises (n≈16-17 per class), the 95% confidence intervals span roughly ±22-25%, making the intervals [48%, 92%] and [25%, 75%] respectively—wide enough that a 65% observed rate is defensible as Go, Modify, or Stop depending on interval interpretation. The plan marks thresholds 'provisional, validated against pilot data,' but does not specify: (1) the confidence level (90%? 95%?), (2) whether to use exact binomial, normal approximation, or Clopper-Pearson bounds, (3) how to handle unequal sample sizes across event types (some n≈8, others n≈16), (4) whether lower or upper confidence bound governs the decision, or (5) what 'validated against pilot data' means mechanically.

### 4.4.B Tags

- thin-statistics
- threshold-ambiguity
- pre-registration-incomplete
- interval-methodology-unspecified
- verdict-vulnerability

### 4.4.C Mitigation

By Month 2.5 (2026-12-23, 14:00)—before any Phase One exercise—both co-chairs must jointly select and lock: (1) a single confidence level (recommend 90% CL for Go/Modify boundary, 95% for Stop boundary, matching asymmetric decision costs); (2) an interval methodology (recommend exact binomial for n<100, Clopper-Pearson for unequal coverage); (3) a decision rule (recommend: Go if lower confidence bound ≥threshold; Modify if interval straddles; Stop if upper bound <threshold). Publish the locked rule as an unclassified annex to the bilateral instrument. Before Month 5.5 (2027-03-23), apply the same rule to pilot data and document any threshold shifts; any shift >3 percentage points must be jointly approved by both co-chairs in writing. Lock all thresholds before the Month 6 (2027-04-08) clock.

### 4.4.D Consequence

Without locked methodology, the final verdict is vulnerable to re-interpretation. A detection rate of 62% with interval [45%, 77%] can be scored as Go (lower bound 45% is below 50%) or Stop (upper bound 77% is below 70%) depending on whether the rule uses lower/upper/midpoint. Co-chairs will dispute the scoring rule itself, not the evidence. This delegitimizes the verdict, triggers renegotiation, and risks a non-decision or forced political compromise that neither side views as credible, undermining Phase One's mission to demonstrate reciprocal-access credibility.

### 4.4.E Root Cause

The plan correctly identifies that Phase One will yield ~±12% pooled and ±22-32% per-type precision (estimate). However, it defers the decision rule for mapping observed detection rates and their intervals into Go/Modify/Stop until after exercises are complete, trading transparency for post-hoc flexibility. Without a pre-locked methodology for constructing intervals, stating which bound drives the decision, and specifying how pilot data reshapes thresholds, the final verdict invites political renegotiation of the scoring rule itself, not merely dispute over what the data shows.

## 4.5.A Issue - Evidence-Weighting Rule Is Locked Without Adversarial Validation; Pilot Cohort Uses Only Benign Historical Records

The plan states the confidential rotating evidence-weighting rule will be 'validated against 100-200 historical equipment-change records per participating site by Month 2 (2026-12-08, 16:00)' and adjusted if false-positive output deviates >5% from target. However, 'historical records' are routine maintenance logs, vendor reports and customs sheets from normal operations—not adversarial, contested or deceptive cases. An operator who intends to hide an equipment swap or false-flag a record will behave differently than routine logs show. The rule may work well against benign noise (record-keeping errors, timing mismatches) and score 8-12% false positives, yet collapse against adversarial gaming, pushing the true false-positive rate under Phase One conditions to 20-30% or higher, overwhelming the 15 cases/month adjudication capacity.

### 4.5.B Tags

- validation-incomplete
- adversarial-gap
- benign-vs-contested
- rule-miscalibration-risk
- adjudication-overload

### 4.5.C Mitigation

Bifurcate the validation into two phases: (1) Historical benign cohort (100-200 events per site, Month 2 = 2026-12-08): apply the rule, check false positives <13%, false negatives <5%; (2) Adversarial synthetic cohort (40-60 realistic deceptive scenarios per site, Month 2.5 = 2026-12-23): craft cases mimicking operator gaming (misidentified serial numbers, swapped equipment with matching headers, backdated maintenance records) and verify the rule flags them. If benign cohort passes but >15% of synthetic scenarios are missed or misclassified, adjust the rule weights and re-validate both cohorts before Phase One. Allocate USD 2-3M from testing envelope for synthetic-case design and red-team validation. Document the rule version that passes both cohorts as the locked Phase One version, immutable for the 90-day window.

### 4.5.D Consequence

If the rule is miscalibrated against adversarial inputs, false-positive volume during Phase One operations will exceed 15 cases per month, choking the adjudication pipeline. Discrepancies age (proposed 21-day impaired-confidence trigger becomes routine), partial suspension (day 14) will be invoked repeatedly, and co-chairs will spend weeks disputing whether a discrepancy is a real finding or a false positive caused by the rule itself. This erodes the 'credible detection' requirement for Go and can force a Modify or Stop verdict not because verification failed but because adjudication infrastructure collapsed under evidence-rule miscalibration.

### 4.5.E Root Cause

The plan conflates validation on historical ground truth (known outcomes from operator records) with validation against adversarial behavior (deceptive or gaming inputs). Historical records provide a useful floor—the rule must not fail on routine cases—but they do not stress-test whether the rule detects deliberate contradictions, plausible false identities or record tampering. The gap between 'validated on benign data' and 'performs under adversarial conditions' is precisely where a rule designed for one regime fails when deployed for another. No contingency budget or adjudication surge plan addresses the risk that false-positive volume could triple.

## 4.6.A Issue - Parity Metrics Are Undefined; 'Reciprocal-Access Parity ≥85%' Cannot Be Measured or Operationalized

The plan states one of the five Go criteria is 'reciprocal-access parity at least 85% (definition TBD)' and lists it as a SWOT question: 'Definition and measurement method of reciprocal-access parity.' By Month 0 (2026-10-08), this is not yet defined, leaving the most politically sensitive criterion unquantified. Parity could mean: equal detection rates by event type, equal exercise count, equal inspector hours at each site, equal data-access time, equal ability to challenge findings, or balanced access to staging and maintenance areas. No definition will satisfy both co-chairs—a metric that shows asymmetry becomes leverage for renegotiating Phase One duration, verdict thresholds, or site selection. Conversely, a metric too loose (e.g., 'both sides say parity was achieved') triggers disputes over whether it was actually measured.

### 4.6.B Tags

- parity-undefined
- operationalization-missing
- political-leverage
- go-criterion-ambiguous
- measurement-gap

### 4.6.C Mitigation

By Month 4 (2027-02-08), define parity operationally through measurable, symmetric indicators: (1) Inspector-hour parity: total inspector hours (on-site + staged exercises) per site per month, target ≥90% balance (site A vs. B in each pair), tranche withheld if >10% disparity; (2) Exercise parity: number of exercises per event type per site per pair, target ≥5 per site per type, with one country's red team designing challenges at the other country's site (swap sites for each challenge type); (3) Data-access parity: average time from event record to counterpart evidence release (filtered package or raw-evidence escort), target ≤3 days, measured weekly; (4) Challenge-outcome parity: fraction of findings challenged by counterpart, fraction sustained after re-review, target ≥80% agreement rate. Lock all four metrics in the bilateral instrument by Month 5 (2027-03-08). During Phase One (Months 6-9 = 2027-04-08 to 2027-07-08), report parity dashboard weekly: if any indicator falls below 80%, co-chairs convene within 5 days to address asymmetry or jointly agree to flag the result as impaired parity (equivalent to a Modify outcome even if detection thresholds are met). Parity ≥85% on all four metrics is the Go gate for parity.

### 4.6.D Consequence

Without defined parity metrics, the Go decision becomes a political judgment: whichever side feels disadvantaged by the detection results will claim parity was not achieved and demand a Modify verdict or re-test. A detection rate of 72% (above the 70% threshold) will be accepted as Go if that side designed the exercises, but the same rate will be challenged as non-representative if the other side controlled the test sites. This politicizes the most credible outcome and leaves Phase One's verdict contested regardless of the technical evidence.

### 4.6.E Root Cause

The plan correctly prioritizes parity as a prerequisite for credible results, but it treats parity as a property of sites (matched-pair selection) rather than as a measurable outcome of operations (achieved parity during Phase One). Matched-pair selection (pre-clock) can confirm functional equivalence of staging areas and access windows; operational parity (during Phase One) requires continuous measurement of inspector time, exercise count, challenge outcomes and resolution timelines at each site. Without pre-specified metrics and measurement rules, parity becomes a post-hoc judgment call, inviting both sides to claim asymmetry when results are unfavorable.

---

# 5 Expert: Neutral Facility Operations and Logistics Director

**Knowledge**: Secure facility design and operations, joint custody and key management, neutral-territory agreements, dual-occupancy protocols, neutral-facility precedent from IAEA, OPCW and UN mechanisms

**Why**: The plan requires a joint neutral secure facility (Geneva or Singapore; site OPEN, decide by Month 1 = 2026-11-08) operational by Month 3 (2027-01-08) to host the replicated ledger, dual-share key ceremonies, reading rooms for filtered evidence, and secure communications. This facility is a critical chokepoint: dual-share key ceremonies can block the ledger 8-24 hours if custody procedures fail, and the facility itself must operate under equal co-chair control with no unilateral shutdown risk. This expert designs the physical, governance and operational architecture to meet those constraints and validates whether the secure-facilities envelope (USD 750M) and the Month 3 (2027-01-08) timeline are realistic.

**What**: Design the joint neutral facility layout (1,000+ sq m) with segregated zones for key custody (dual-share ceremony room with escape routes and fail-safe power), ledger hosting (replicated hardware, continuous backup), reading room (dual escort access, no copying, session logging), secure communications (air-gapped from public internet, monitored by both sides), and support spaces (staff offices, break areas, secure parking). Specify the host-country agreement (site selection, access rights, immunity, dispute resolution); draft the operating charter (equal co-chair approval for any access policy change, incident reporting within 4 hours, monthly operations review); validate the key-ceremony procedures (generation, split, storage, rotation, recovery) against the estimated 8-24 hour recovery window; size the operations staff (estimated 15-20 full-time, mixed nationality, no single-person functions); and estimate facility costs (lease, hardening, communications, staffing) against the secure-facilities envelope.

**Skills**: Secure-facility design and hardening, dual-custody protocols, key-management ceremonies, neutral-territory law and agreements, joint operational governance, incident response and continuity planning, facility cost estimation

**Search**: IAEA neutral facility operations, OPCW secure facility design, dual-key custody procedures, secure communications infrastructure, facility cost benchmarks

## 5.1 Primary Actions

- Establish a Joint Facility Task Force (by Month 0.25 = 2026-10-16, 14:00) with US and Chinese technical and diplomatic leads to complete a bilateral RFP for neutral-facility operators and host countries by Month 0.5 (2026-10-23, 17:00); lock a primary and secondary facility candidate by Month 1 (2026-11-08) and sign a Memorandum of Understanding with the host country by Month 1.5 (2026-11-23, 09:00); require ISO 27001 and IAEA-equivalent physical-security certification by Month 2.5 (2026-12-23, 09:00) and pass a joint hardening audit by Month 3 (2027-01-08, 17:00); schedule the first key ceremony for Month 4 (2027-02-08, 10:00) with explicit recovery-rehearsal milestone at Month 5 (2027-03-08, 14:00).
- Convene an Adjudication Capacity Task Force (Month 0 = 2026-10-08, 16:00) to model caseload under baseline (15/month), miscalibration (50/month) and cascade (40+ open, multiple-site suspensions) scenarios; specify required staffing (minimum 8–12 adjudicators per country, surge to 20+); establish decision turnaround targets (7 days routine, 3 days for aged cases >21 days); pre-stage 3–5 surge adjudicators per country by Month 5 (2027-03-08) funded from the 750M personnel or 500M testing envelope; establish a secondary deadlock advisory panel (2 senior officers per country + neutral chair, if negotiable) to issue recommendations on evidence-rule disputes within 5 days of case opening (day 10) and reduce aged-case load before automatic impaired-confidence triggers.
- Complete the Inspector Firewall Operations Manual by Month 2 (2026-12-08, 10:00) specifying debriefing protocol (4–6 hour session per inspector, CI Oversight Board conducted, anomaly-focused), cooling-off rule (14-day minimum between reassignments, logged, exceptions for surge), and shift-scheduling compliance (no inspector >2 consecutive sites, 4-week minimum tenure, 30% leave buffer); recruit and contract an independent filter auditor (forensic-IT specialist from neutral third country, pre-approved by both co-chairs by Month 1 = 2026-11-08) with fixed fee and performance targets (1-day turnaround routine, 24-hour raw-evidence escort for disputes, monthly report); allocate 2–3 person-months from the 750M personnel envelope; establish a fast-track filter-dispute procedure (48-hour technical review with escort access, escalation to co-chairs only if unresolved, not entry into formal adjudication queue).
- Lock the confidential evidence-weighting rule in a sealed bilateral memorandum (double-key approved) by Month 1.5 (2026-11-23, 10:00) and conduct mandatory historical-data validation at Month 2 (2026-12-08, 08:00) on 100–200 equipment-change events per participating site against known ground truth; compute false-positive rates (target ≤10%, tolerance ±3%), false-negative rates (target ≤5%), and unverifiable-equipment counts; if miscalibration exceeds ±5 percentage points, halt exercises, adjust the rule and re-validate using a second cohort before Month 5.5 (2027-03-23) entry-gate certification; maintain versioned rule-change log with every amendment timestamped, double-key approved and linked to evidentiary trigger.
- Pre-register verdict thresholds with explicit confidence-interval bands by Month 2.5 (2026-12-23, 14:00) locked before the first Phase One exercise (Month 6 = 2027-04-08): Go threshold planned-event detection ≥75% (90% CL, lower bound ≥62%), Modify 55–75%, Stop <55%; unplanned detection Go ≥60%, Modify 40–60%, Stop <40%; false-positive rate Modify if ≤15%, Stop if >15%; apply mechanical scoring (lower-bound exceeds Go = Go, upper-bound below Stop = Stop, straddles threshold = Modify default); mark all thresholds 'provisional, validated against pilot data'; document adjustment logic (pilot results at Month 5 = 2027-03-08 may shift thresholds ±3–5 points if deviation >20%, but lock before Phase One and no amendments during); publish unclassified verdict and mechanical scoring within 5 days of Month 9 (2027-07-08) conclusion.

## 5.2 Secondary Actions

- Establish a Bilateral Counterintelligence Oversight Board (by Month 0 = 2026-10-08, 16:00) with 3 senior counterintelligence officers per country, monthly classified meetings (every 2nd Tuesday, 14:00 CET via secure video at neutral facility), and authority to investigate and adjudicate suspected inspector breaches within a 7-day protocol (48-hour investigation, 72-hour recommendation, 7-day decision); require all 300+ deployed inspectors to undergo baseline polygraph or equivalent by Month 2 (2026-12-08, 09:00) and quarterly re-vetting on rotating schedule (every 3rd Friday of each month starting Month 3 = 2027-01-08); publish unclassified monthly metrics (count of breaches suspected, sustained, false positives) to legislatures.
- Establish an Entry-Condition Task Force with binding weekly milestone deadlines by Month 0 (2026-10-08, 14:00) and publish a master roadmap showing bilateral-instrument signature by Month 1 (2026-11-08), domestic-authority enactment and appropriations by Month 2 (2026-12-08), site nominations by Month 1 (2026-11-08), inspector approval by Month 3 (2027-01-08), vendor written commitments by Month 1 (2026-11-08), and schedule adoption by Month 3 (2027-01-08); launch site-candidate identification (4–6 per country) and vendor outreach in parallel starting Month -2 (2026-08-08), not sequentially; reserve USD 50–100 million from contingency explicitly for compressed-negotiation costs; establish an external escalation authority with right to invoke emergency co-chair summit if any gate slips >2 weeks, with 5-day decision deadline on scope reduction (fewer pairs, 60-day test) rather than timeline extension.
- Appoint an independent timekeeper (dedicated staff at neutral facility, one per country, reporting jointly to co-chairs) by Month 1 (2026-11-08, 10:00) to track elapsed time from discrepancy opening to closure and publish mandatory weekly dashboards (every Monday, 09:00 CET) showing: open-discrepancy count by age bucket (0–7, 8–14, 15–21, 22+ days), items in automatic partial suspension (14+ days), items in impaired-confidence status (21+ days identity, 28+ days exit), and projected recovery time; implement automatic ledger annotation every time a partial suspension or impaired-confidence is triggered (timestamp, function, reason, co-chair justifications, estimated resolution date); publish unclassified monthly summary (count of suspensions, average duration) so legislatures see governance discipline.
- Establish a Vendor Liaison Office (by Month 0 = 2026-10-08, 16:00) to conduct vendor outreach and secure written commitments by Month 1 (2026-11-08, 14:00) offering each Tier-1 vendor a choice: (1) direct participation or (2) fallback testing without veto; document commitments/refusals by Month 1.5 (2026-11-23, 09:00) and publish a vendor-participation registry as an entry-condition gate; pre-stage 1 accredited independent-examiner team per country (5–8 specialists per country, bonded by government) by Month 1 (2026-11-08, 16:00) from the USD 500M testing envelope; lock the vendor-refusal fallback ladder as a double-key-approved procedure by Month 2 (2026-12-08, 09:00) specifying turnaround, credit toward identity-confidence and unverifiable classification if the full ladder cannot complete before entry.
- Recruit and vet 300+ full-time inspectors (150–200 per country plus 20% surge buffer = 30–40 per country on standby) starting Month -3 (2026-07-08) with freeze by Month 1 (2026-11-08, 14:00) and security clearances/polygraph completion by Month 2 (2026-12-08, 09:00); establish a joint US-China bilateral training academy (Month -1 = 2026-09-08, 10:00) with curriculum covering evidence collection (4 days), sealed observation-report protocols (3 days), equipment-identity verification (3 days), live-exercise procedures (2 days); train first cohort Months -1 to 0, second Months 0–1 (2026-10-08 to 2026-11-08), final Months 1–2 (2026-11-08 to 2026-12-08), ensuring 80% certified by Month 2.5 (2026-12-23, 17:00); structure shifts as 4 months on-site/2 months off-site staggered across cohorts, minimum 6 inspectors per shift (3 per country × 3 shifts × 2–4 sites), no single-person critical functions, max 12 consecutive hours, max 48 hours per week; fund retention bonuses (2–3% of 750M ≈ USD 11–17M for 9 months).
- Conduct a joint filter-design workshop (by Month 0.5 = 2026-10-23, 09:00) with both sides' inspectors, operators, legal advisors and security engineers to specify evidence filters (redact network IP, topology, architecture, customer names, weights, code; preserve timestamps, serials, arrival/departure, maintenance, location); appoint an independent filter auditor (qualified security specialist, neutral third country, pre-approved by Month 0 = 2026-10-08) to validate filter compliance by Month 1.5 (2026-11-23, 10:00) and conduct monthly 5–10% spot-check audits; document monthly (packages filtered, challenged, re-filtered, findings, latency); implement a formal challenge procedure with raw-evidence escort access (24-hour notice, dual escort, session logged) and re-filtering if dispute sustained.
- Establish a Ledger Synchronization Operations Manual by Month 2 (2026-12-08, 09:00) specifying: local event recording (≤5 minutes latency), counterpart signed-digest exchange (≥hourly), alert on >30-minute overdue exchange, 4-hour escalation if mismatch detected, 72-hour reconciliation target (7-day hard limit); conduct a key-recovery rehearsal at Month 5 (2027-03-08, 14:00) with a simulated dual-share loss (ledger blocked, both co-chairs invoke recovery procedure, ceremony repeated under supervision, ledger validation repeats, estimated 8–24 hour recovery time documented); establish hourly digest-exchange monitoring dashboard (weekly report of exchange latencies, mismatch counts, reconciliation times, ledger-divergence incidents); lock all synchronization thresholds as entry-gate items by Month 1 (2026-11-08, 09:00).

## 5.3 Follow Up Consultation


At the next consultation, address: (1) Neutral-facility procurement status—RFP timeline, host-country candidates and hardening-specification agreement by Month 0.5 (2026-10-23); (2) Adjudication and secondary-panel staffing model—whether the secondary deadlock panel requires explicit bilateral treaty language or can operate under operational agreement; (3) Filter-auditor procurement—whether a neutral third country is available and willing to provide a dedicated on-site or remote-access auditor at 1-day turnaround; (4) Evidence-rule validation dataset—whether participating sites' historical records (equipment manifests, maintenance logs, customs declarations) can be assembled by Month 1.5 (2026-11-23) for the Month 2 (2026-12-08) pilot, and whether ground truth (e.g., physical inspection of the same equipment) can be established; (5) Post-Phase-One funding route—whether Modify-directed rework or Phase Two is pre-authorized or requires a new appropriations decision, and how that decision is separated from the Go/Modify/Stop verdict to avoid bias.


## 5.4.A Issue - Neutral Facility Site Selection and Dual-Custody Key Ceremony Architecture Remain Unresolved; Delays Risk Cascading Entry-Gate Compression

The plan designates a neutral facility (Geneva or Singapore) as operational by Month 3 (2027-01-08) but site selection is marked OPEN and no host-country agreement exists. Key ceremonies (dual-share generation, rotation, recovery) cannot occur until the facility is operational and hardened. This single-point chokepoint delays the Root-of-Trust Key Custody Architecture, blocks ledger validation and directly blocks Phase One startup. A 4-week site-selection slip cascades: ceremonies slip to Month 4 (2027-02-08), first key validation fails to meet the Month 5 (2027-03-08) rehearsal deadline, and entry certification (Month 5.5 = 2027-03-23) fails. This compresses Phase One from 90 days to 45–60 days and renders statistical confidence undefendable (±32% per type vs. ±12% pooled target).

### 5.4.B Tags

- facility-siting-delay
- chokepoint-geometry
- entry-gate-compression
- key-ceremony-blocking
- cascade-risk

### 5.4.C Mitigation

Immediately establish a Joint Facility Task Force (by Month 0 = 2026-10-08, 14:00) with technical and diplomatic leads to complete a bilateral Request for Proposals (RFP) for neutral-facility operators and host countries by Month 0.5 (2026-10-23). Lock a primary and secondary facility candidate by Month 1 (2026-11-08) and a signed host-country Memorandum of Understanding by Month 1.5 (2026-11-23). Require the facility to achieve ISO 27001 and IAEA-equivalent physical-security standards by Month 2.5 (2026-12-23) and to pass a joint hardening audit by Month 3 (2027-01-08). Schedule the first key ceremony for Month 4 (2027-02-08) with 2-week buffer before Month 5 (2027-03-08) rehearsal. If the primary site slips >2 weeks, invoke the secondary within 48 hours or trigger emergency scope reduction (2 pairs, 60-day test).

### 5.4.D Consequence

Without pre-approved neutral facility and locked key-ceremony schedule, the Phase One window compresses from 90 to 45–60 days, rendering the 54-exercise load infeasible. Statistical confidence per event type drops from ±32% (already wide) to ±45%+, making any verdict intellectually indefensible to either legislature. The Go/Modify/Stop decision becomes ambiguous at ±50% detection, inviting political renegotiation and delegitimizing the Consortium in public assessment. Ledger divergence cannot be resolved without operational keys, blocking evidence acceptance and forcing a Stop decision by default at Month 6 (2027-04-08).

### 5.4.E Root Cause

Facility site selection was not accelerated in parallel with other entry-condition gates (instrument, appropriations, site pairs, vendors). It is treated as a Month 1 (2026-11-08) decision but no bilateral nomination process, host-country pre-approval, or design standard for hardening-level and floor-plan layout has been established. The plan assumes a turnkey facility; real neutral-facility siting (IAEA precedent: 12–18 months from concept to occupancy) takes longer than the plan allows. No contingency pathway exists if the primary site is rejected.

## 5.5.A Issue - Adjudication Capacity and Deadlock-Resolution Procedures Severely Underestimated; 15-Case/Month Baseline Is Undefendable Against Evidence-Rule Miscalibration

The plan allocates 5 full-time adjudication staff per country (10 total) and targets 15 discrepancies per month. However, if the confidential evidence-weighting rule is miscalibrated by even ±5 percentage points during the Month 5 (2027-03-08) historical validation, false-positive rates rise from the 10% target to 15–20%. At a participation scale of 6 datacenters with 54 exercises and continuous monitoring, this yields 50–80 discrepancies per month (not 15), overwhelming the 10-person adjudication unit and directly blocking the 21-day impaired-confidence trigger in the deadlock procedures. Cases age beyond 21 days (identity) and 28 days (exit) automatically, triggering partial suspension cascades. This creates the exact governance failure the plan aims to prevent: stalling under equal co-chairs with no casting vote.

### 5.5.B Tags

- adjudication-underestimate
- evidence-rule-risk
- false-positive-cascade
- deadlock-blocking
- staffing-capacity-gap

### 5.5.C Mitigation

Establish a standalone Adjudication Capacity Task Force (Month 0 = 2026-10-08) to model caseload under three scenarios: baseline (10% false positives, 15 cases/month), miscalibration (20% false positives, 50 cases/month), and cascade (40+ open cases at multiple ages, multiple suspension triggers active). For each scenario, specify required staff (propose 8–12 adjudicators per country minimum, surge to 20+), decision turnaround targets (7 days for routine, 3 days for aged >21 days), and escalation triggers (cases age >14 days = co-chair briefing, >21 days = panel convened, >28 days = automatic impaired-confidence flag and partial suspension with ledger annotation). Pre-stage 3–5 surge adjudicators per country by Month 5 (2027-03-08), funded from the 750M secure-facilities or 500M testing envelope. Establish a secondary deadlock panel (2 senior technical officers per country + 1 neutral chair, if negotiable) to advise on evidence-rule disputes at day 10 (before partial suspension at day 14) and reduce aged-case load.

### 5.5.D Consequence

If adjudication capacity remains at 10 staff and the evidence rule miscalibrates, discrepancies pile up and age past the automatic-suspension thresholds (21 and 28 days). Partial suspensions cascade across multiple sites and functions (intake paused at Site A identity dispute, exits paused at Site B disposition dispute, intake paused again at Site C maintenance-record conflict), paralyzing unrelated functions and violating the plan's goal of keeping unrelated verification running. The co-chairs lose control: neither can unilaterally lift a suspension (double-key rule), both have incentive to hold suspension until the other concedes a point. Phase One outcome becomes an adjudication backlog snapshot, not a credible verdict. Go/Modify/Stop decision is delayed weeks beyond the Month 9 (2027-07-08) deadline and is seen as political compromise, not technical assessment.

### 5.5.E Root Cause

Adjudication staffing (5 per country) was sized assuming the evidence rule works perfectly and the 10% false-positive target holds. No contingency staffing is allocated for rule miscalibration, surge scenarios or mid-test rule adjustment. The plan validates the rule on historical records by Month 5.5 (2027-03-23) but does not include adversarial test cases (operators deliberately obscuring equipment changes, vendors providing partial attestations). The monthly capacity target of 15 cases is stated without a supporting caseload model or backlog-aging analysis. If cases accumulate and age past thresholds, the automatic impaired-confidence triggers backfire: instead of resolving deadlock, they paralyze the system with a cascade of partial suspensions affecting different functions at different sites.

## 5.6.A Issue - Inspector Compartmentalization and Information Firewall Doctrine Lack Operational Detail and Certification Procedure; Evidence-Filtering Certification Adds 2–3 Days Per Package and Risks Filter Disputes Becoming Hard Stops

The Inspector Information Firewall doctrine specifies compartmentalization by role and site with post-assignment debriefs and cooling-off periods, but operational protocols are missing: no definition of 'compartmentalization,' no debriefing template or time budget (estimated 4–8 hours per rotation × ~180 inspectors = 360–720 person-hours per month), and no specification of what triggers a 'cooling-off period' (48 hours? 2 weeks?) or how that interacts with 24/7 shift scheduling. The plan also specifies that filtered evidence must be certified by an independent third-country auditor (2–3 days per package) before reaching the counterpart inspectorate. If a filter dispute arises (counterpart claims sensitive evidence was redacted), the dispute becomes a formal discrepancy, enters the deadlock procedure and ages toward automatic impaired-confidence status. With 54 exercises, assume 20–30 evidence packages per month; at 2–3 days certification latency, certification queues build to 40–60 days and block counterpart evidence access entirely, creating the asymmetric-access trigger for a hard Stop.

### 5.6.B Tags

- firewall-operational-gap
- filtering-latency-risk
- filter-dispute-blocking
- evidence-access-asymmetry
- certification-chokepoint

### 5.6.C Mitigation

Establish an Inspector Firewall Operations Manual by Month 2 (2026-12-08) specifying: (1) debriefing protocol (template, 4–6 hour session per inspector upon departure or reassignment, conducted by CI Oversight Board representative, focusing on unusual access requests or data-handling anomalies); (2) cooling-off period rule (14 days minimum between reassignment, logged by the independent timekeeper, with exceptions only for surge demand approved by both co-chairs jointly); (3) shift-scheduling compliance (no inspector assigned to >2 consecutive sites, no reassignment before 4-week minimum on-site tenure, 30% leave buffer enforced). Recruit and contract the independent filter auditor (propose a forensic-IT specialist or data-security officer from a neutral third country, pre-approved by both co-chairs) by Month 1 (2026-11-08) with a fixed fee and performance-target contract specifying: max 1-day turnaround for routine packages, 24-hour 'raw-evidence escort access' procedure for disputed filters (both sides inspect source, dispute resolved or escalated within 48 hours), and monthly certification report (count of packages, disputes, re-filtering required). Allocate 2–3 person-months from the 750M personnel envelope for the auditor's time. Establish a filter-dispute fast-track: contested filters do NOT enter the formal adjudication queue; instead, both sides' CI officers and the filter auditor convene a 48-hour technical review with escort access; if unresolved, escalate to the co-chairs with a recommendation, not a formal discrepancy.

### 5.6.D Consequence

Without operational firewall detail and debriefing procedures, inspector knowledge leakage risk is uncontrolled: inspectors rotate off-site carrying memories of network topology, security-architecture changes, maintenance-access patterns and production-area layouts. A single debriefed inspector could be the intelligence target for either government's own counterintelligence service. Loss of a debriefed inspector to a foreign service (defection, recruitment) becomes a Phase One stop event. Without a fast-track filter-dispute procedure, filter disputes accumulate in the adjudication queue (assume 5–10% of packages contested = 1–3 per month), age past 21 days, and trigger impaired-confidence status, blocking counterpart evidence access entirely and creating the 'access asymmetric' hard Stop. Phase One halts due to evidence paralysis, not verification failure.

### 5.6.E Root Cause

The firewall doctrine is stated abstractly ('compartmentalize by role and site') without operational procedures, timelines or staffing allocation. The debriefing process is mentioned but not budgeted; the independent filter-auditor role is specified but no auditor procurement timeline, fee estimate or performance target (e.g., max 2-day turnaround) exists. The plan treats filter disputes as potential discrepancies that enter the adjudication system, but provides no parallel fast-track procedure for disputed filters (e.g., 24-hour 'raw-evidence escort access' where both sides inspect the filter's source material to resolve the dispute without a formal adjudication delay). Without a fast-track, a single contested filter can block evidence access to the counterpart and trigger the hard Stop condition (access asymmetric) by default.

---

# 6 Expert: Bilateral Legal Implementation and Instrument Specialist

**Knowledge**: International bilateral agreements, arms-control treaty language, double-key authorization clauses, deadlock and dispute-resolution procedures, domestic access-authority legislation, export-control and sanctions coordination, enforcement and termination clauses

**Why**: The plan's entire governance rests on a bilateral instrument signed by both governments (Month 1 = 2026-11-08 entry gate), which must embed: double-key procedures with no casting vote, defined deadlock and automatic-suspension triggers (days 14, 21, 28), hard Stop conditions (asymmetric access, shielding, ledger divergence, withheld funding), confidentiality and evidence-handling rules, inspector status and immunity, operator compensation, neutral-facility status, and the exit clauses. The instrument must also coordinate domestic access authority in each country (Month 2 = 2026-12-08), which means enacting legislation or executive authority to compel operator and vendor participation and to authorize custody and evidence handling. This expert drafts the instrument, coordinates domestic legislation, and validates whether the legal structure can survive political stress and unilateral withdrawal pressure.

**What**: Draft a model bilateral instrument (estimated 80-120 pages, classified) embedding: (1) mission and scope (declared-equipment change verification only); (2) governance (co-chairs, double-key procedures, no casting vote, deadlock definition at day 14, automatic partial suspension, impaired-confidence at days 21/28, emergency summit at day 35); (3) entry conditions (instrument signature, appropriations, site selection, inspector approval, vendor commitments, schedule adoption); (4) the seven budget envelopes and envelope-mapping audit; (5) Phase One procedures (intake, ledger, exercises, adjudication); (6) the hard Stop triggers and exit procedures; (7) neutral-facility status and immunity; (8) inspector privileges, immunity and security vetting; (9) operator compensation and vendor-participation terms; (10) confidentiality, evidence handling and disclosure tiers; (11) termination and transition clauses. Coordinate with each country's executive and legislative branches to identify which instrument clauses need enabling domestic legislation (access authority, export-control waiver, customs procedures, operator compensation) and draft model language. Identify the highest-risk legal conflicts (unilateral withdrawal, asymmetric domestic authority, sanctions drift) and propose reservation or clarification language.

**Skills**: Treaty drafting and negotiation, bilateral legal frameworks, domestic legislation coordination, double-key and consensus-based governance clauses, dispute-resolution and termination law, export-control and sanctions law, inspector immunity and status law

**Search**: Bilateral arms-control treaty language, double-key authorization clauses, IAEA bilateral agreements, managed-access legal frameworks, inspector immunity statutes

## 6.1 Primary Actions

- Commission a joint bilateral-law drafting team (3 attorneys per side, experienced in arms-control instruments) by Month 0 (2026-10-08) to produce a specimen bilateral-instrument clause locking the deadlock-and-suspension procedure (defining clock start/stop, timekeeper certification, automatic partial-suspension triggers at days 14/21/28, waiver documentation and the no-waiver register). Lock this language into the bilateral instrument by Month 1 (2026-11-08). Include explicit definitions of what stops the clock (procedural exception) and what restarts it (co-chair agreement to a signed waiver in the ledger), so neither side can unilaterally extend deadlines.
- Conduct an adversarial-scenario validation of the confidential evidence-weighting rule by Month 4.5 (2027-02-23), after historical validation is complete. Develop 20–30 synthetic scenarios (access delays, record gaps, vendor refusal, substitution attempts) drawn from IAEA, OPCW and START precedent, apply the locked rule to each scenario, and score the rule's output against a reference-panel judgment. If the rule misscores >10% of scenarios, adjust weights and re-validate on a second historical cohort before Phase One. Document findings in a classified bilateral annex that both co-chairs sign, so both sides certify the rule resists gaming.
- Draft and lock a specimen bilateral-instrument clause (by Month 1 = 2026-11-08) that incorporates verdict thresholds (Go ≥75%, Modify 55–75%, Stop <55%, or updated post-pilot figures) as binding, non-amendable procedural law. Include mechanical scoring rules (confidence-interval bands, default-to-Modify logic) and forbid threshold amendment after any results are known. Require the Exercise Authority to report confidence intervals for each detection rate and require both co-chairs to sign a 'final verdict report' that applies the mechanical rule, so the verdict is an application of pre-agreed law. Publish the unclassified thresholds and mechanical rule before the first Phase One exercise.
- Establish a joint bilateral-law steering committee (co-chaired by the two national legal advisors, meeting monthly starting Month 0 = 2026-10-08) to oversee drafting of all procedural clauses (deadlock, suspension, evidence-rule lockdown, threshold enforcement, key-custody recovery, filter-certification protocols, disclosure-tier definitions). This committee must sign off on each clause, test for internal consistency (e.g., deadlock clock definition vs. partial-suspension trigger), and verify the clause maps to the bilateral instrument article structure by Month 2 (2026-12-08).
- By Month 0.5 (2026-10-23), identify and brief both co-chairs on three JCPOA/New START precedents where threshold or confidence-interval disputes caused stalling or unilateral withdrawal, and frame the legal-instrument strategy as preventing these precedents from repeating. Secure co-chair commitment to locking all thresholds and procedures into the bilateral instrument by Month 2 (2026-12-08), not leaving them as planning documents.

## 6.2 Secondary Actions

- Appoint an independent instrument-compliance auditor (external to both governments, with previous arms-control audit experience, approved by both co-chairs by Month 0 = 2026-10-08) to review each drafted bilateral-instrument clause for internal consistency, legal enforceability, and alignment with the plan's governance architecture. Have this auditor produce a 'compliance certification' (TBD) for each clause before it is finalized, documenting gaps or risks. This role is distinct from the filter auditor and adds an estimated USD 50–75k but provides early detection of legal loopholes.
- Commission a 'deadlock-procedure stress test' (Month 3 = 2027-01-08, 2-day tabletop exercise with legal and senior technical staff from both sides, simulating a disputed discrepancy at day 12, day 16, day 25 and day 35) to walk through the clock-start/stop definitions, timekeeper certification, partial-suspension triggers and waiver documentation. This exercise identifies interpretive gaps before Phase One and allows both sides to agree on the procedural clarifications needed.
- By Month 2 (2026-12-08), obtain written commitment from both co-chairs that verdict thresholds will not be renegotiated after any Phase One exercise results are known, and that both will sign the final verdict report applying the mechanical scoring rule, regardless of the outcome. Make this commitment part of the bilateral instrument's final-decision section, so it is legally enforceable.
- Develop a 'rule-amendment moratorium' document (by Month 5 = 2027-03-08) that forbids any change to the evidence-weighting rule, verdict thresholds, or deadlock procedures after the first Phase One exercise begins (Month 6 = 2027-04-08). Publish this in the bilateral instrument's Phase-One procedures section, so any amendment attempt during the 90-day window is an explicit violation of the instrument.
- Establish a monthly 'instrument-compliance dashboard' (starting Month 1 = 2026-11-08, reported by the bilateral legal steering committee to the co-chairs) tracking: (1) completion status of each required clause (deadlock, suspension, evidence-rule lockdown, threshold enforcement, key custody, filter certification); (2) internal-consistency findings from the compliance auditor; (3) stress-test results and remaining ambiguities; (4) co-chair sign-off status. This dashboard makes legal implementation a measurable gating item, not an afterthought.
- By Month 4 (2027-02-08), publish an unclassified summary of the bilateral instrument's key procedural sections (deadlock clock, partial suspension, verdict thresholds and mechanical scoring, double-key authorization, confidentiality boundaries) so both legislatures can read the legal framework in advance of Phase One and raise concerns before the clock starts.

## 6.3 Follow Up Consultation

"In Month 1 (2026-11-08), review the draft bilateral-instrument clauses (deadlock, suspension, thresholds, evidence-rule procedures) for legal enforceability and consistency. Confirm that both co-chairs have formally committed to locking thresholds into law and applying the mechanical scoring rule, and that no escape hatches (procedural exceptions, good-faith-negotiation delays, urgent-national-interest waivers) remain in the language. Discuss whether a third-country arbitration clause is needed if either side disputes instrument interpretation during Phase One, and whether both governments will accept binding interpretation (or only advisory panels). Clarify the legal standing of the independent timekeeper: does the timekeeper's clock certification have legal force (binding on both co-chairs), or is it advisory (either side can contest the timestamp)? By Month 3 (2027-01-08), validate the adversarial-scenario testing plan against IAEA and OPCW precedent so the synthetic scenarios are realistic and credible to both sides."

## 6.4.A Issue - Bilateral Instrument Language Does Not Lock the Double-Key Deadlock Procedure, Creating Interpretive Escape Hatches

The plan specifies automatic partial suspension at day 14 and impaired-confidence flags at days 21–28, yet no specimen language is provided showing how these thresholds are embedded into the bilateral instrument itself. Without locked procedural language, each co-chair can later argue that 'procedural dispute' delays reset the clock, that 'good-faith negotiation' suspends the age counter, or that 'urgent national interest' justifies exception. The START and JCPOA precedents show that deadlock procedures without ironclad instrument text are treated as advisory only. The plan risks having an 'automatic' suspension that either side can unilaterally defer.

### 6.4.B Tags

- bilateral-instrument-language
- deadlock-procedure-ambiguity
- double-key-escape-hatch
- enforcement-precedent-gap

### 6.4.C Mitigation

By Month 0.5 (2026-10-23), commission a joint bilateral-law team (3 attorneys per side, ideally with IAEA or OSCE experience) to draft and circulate a specimen instrument clause (500–800 words) that operationalizes the deadlock sequence: defines what stops the clock and what restarts it, specifies who certifies clock timestamps (the independent timekeeper, with dual-nation audit), and states consequences (partial suspension is automatic unless both co-chairs sign a written waiver in the ledger within 24 hours). Lock this language into the bilateral instrument by Month 1 (2026-11-08). Include a 'no-waiver register' so any postponed suspension is logged and visible.

### 6.4.D Consequence

Without locked instrument language, adjudication during Phase One will become a tool for stalling: one side delays until sufficient time has passed to reframe a deadline, argues procedural exceptions, and forces the other to invoke suspension unilaterally (appearing aggressive). Alternatively, both sides avoid invoking suspension to keep operations running, allowing discrepancies to age past 21 days and undermining the credibility of the 'automatic' rule. The final verdict becomes a negotiation over which discrepancies 'count' rather than an application of pre-agreed law, delegitimizing the Go/Modify/Stop decision to domestic and international observers.

### 6.4.E Root Cause

The plan describes the deadlock architecture but does not provide a specimen bilateral-instrument clause that locks the procedure beyond ambiguous renegotiation. No statutory or treaty precedent is cited for enforcing age-triggered suspension without a casting vote. The plan assumes both sides will honor procedural discipline in the abstract but does not pre-draft the legal language that makes non-compliance visible or costly.

## 6.5.A Issue - Confidential Evidence-Weighting Rule Lacks Pre-Phase-One Adversarial Validation, Creating Risk of Miscalibration and Adjudication Paralysis

The plan specifies that a 'confidential, rotating combination rule set by accountable specialists' will weight attestation, physical inspection, customs records, identifiers, maintenance logs, infrastructure changes and witnessed movement into an equipment-identity confidence rating. The plan requires validation against 100–200 historical equipment-change records per site by Month 2 (2026-12-08) (proposed threshold), comparing false-positive and false-negative rates against known ground truth. However, this validation uses benign historical records from cooperative operators—not adversarial scenarios where an operator deliberately delays access, substitutes equipment, or provides misleading records to test the rule's robustness. A rule calibrated only on cooperative historical data will fail to detect gaming and may trigger false positives on ordinary delays, overwhelming the 15-case-per-month adjudication capacity.

### 6.5.B Tags

- evidence-rule-validation-gap
- adversarial-testing-absent
- miscalibration-risk
- adjudication-overload

### 6.5.C Mitigation

By Month 4.5 (2027-02-23), after historical validation is complete, conduct an adversarial-scenario workshop (2 days, both sides' evidence-rule specialists, independent exercise-authority staff) to generate 20–30 synthetic scenarios (realistic cases from IAEA, OPCW and START experience involving access delays, record gaps, vendor refusal and substitution attempts). Apply the locked rule to these scenarios, score the confidence outputs and compare to a reference panel's judgment ('this scenario should score 60–70% confidence, not 40%'). If the rule misscores >3 scenarios (more than 10% error rate), adjust the rule weights and re-validate on historical data before Phase One. Document the adversarial-testing results in a classified annex so both sides can verify the rule resists gaming. This adds an estimated 3–4 weeks and USD 150–200k to the calendar but catches miscalibration before the clock starts.

### 6.5.D Consequence

If the rule is miscalibrated on benign data only, Phase One will produce 20–30% false positives (vs. 10% target), generating 30–50 discrepancies per month (vs. 15 planned). The adjudication unit will be paralyzed, discrepancies will age past 21 days, impaired-confidence suspensions will multiply, and both sides will blame each other's filtering or evidence-hiding for the apparent gaming. The final verdict becomes untrustworthy because the high false-positive rate will be attributed to either overly strict rule weights (making one side appear compliant) or overly loose weights (making the other appear non-compliant), inviting a contested Stop or renegotiated Modify outcome.

### 6.5.E Root Cause

The plan treats historical-record validation as sufficient to calibrate the rule. However, historical records reflect normal operations (cooperative access, complete documentation, no deliberate obfuscation). An operator or vendor seeking to shield equipment will not behave cooperatively; they will use delays, record gaps, maintenance claims and access denials to push the rule's thresholds. The validation cohort must include adversarial synthetic scenarios (e.g., a maintenance event with delayed access and missing vendor signature, or substituted equipment with a partial attestation) to test whether the rule correctly scores these as lower-confidence cases or incorrectly flags them as discrepancies.

## 6.6.A Issue - Verdict Thresholds Are Pre-Registered But Confidence-Interval Bands Are Not Locked Into Bilateral Instrument, Enabling Post-Hoc Renegotiation of Go/Modify/Stop Decision

The plan proposes pre-registering verdict thresholds (Go ≥75% detection, Modify 55–75%, Stop <55%, proposed thresholds) by Month 2.5 (2026-12-23) 'before the first Phase One exercise.' However, the plan does not specify whether these thresholds are locked into the bilateral instrument (making them legally binding and non-negotiable) or published only as a planning document (making them advisory and subject to reinterpretation). With only 54 exercises and ±12% pooled confidence intervals at 95%, many outcomes will land inside the Modify band (e.g., 65% ±15% at 95% CL spans 50–80%, overlapping Go and Stop). If thresholds are not legally binding, the final verdict becomes a negotiation over confidence-interval interpretation: one side argues the true rate is likely 75% (Go), the other argues 65% (Modify), and the decision devolves into political bargaining rather than pre-registered rules.

### 6.6.B Tags

- verdict-threshold-ambiguity
- post-hoc-renegotiation-risk
- confidence-interval-interpretation
- bilateral-instrument-lockdown-gap

### 6.6.C Mitigation

By Month 1 (2026-11-08), the bilateral legal team must draft a specimen instrument clause (300–500 words) that: (1) incorporates the verdict thresholds by numeric reference (Go ≥75%, Modify 55–75%, Stop <55%) as binding procedural rules, not advisory figures; (2) requires the Exercise Authority to report confidence intervals (±percentage points at 95% CL) for each detection rate; (3) specifies a mechanical rule ('if lower confidence bound exceeds Go threshold, verdict is Go; if upper bound falls below Stop threshold, verdict is Stop; otherwise Modify'); (4) forbids co-chair amendment of thresholds after any exercise results are known; (5) requires both co-chairs to initial a 'final verdict report' that applies the mechanical rule, so the verdict is an application of pre-agreed law, not a negotiated outcome. This language must be locked into the bilateral instrument by Month 2 (2026-12-08) and published (unclassified) before the first Phase One exercise so both legislatures see the scoring rule in advance.

### 6.6.D Consequence

If thresholds are advisory only or locked in planning documents (not the bilateral instrument), the final verdict will be contested. If results land at 65% detection with ±15% intervals, one co-chair will read this as 'within Modify band' and the other as 'consistent with Go.' Absent mechanical scoring rules, both interpretations are defensible, and the decision defaults to politics: the country with more leverage at that moment can push for Go (claiming a success to justify future funding) or Stop (claiming verification is inadequate to justify continued operations). Either way, the final verdict loses credibility as an objective, pre-agreed outcome and becomes a perceived capitulation by one side. This delegitimizes Phase One to both legislatures and undermines any future phase or new mechanism.

### 6.6.E Root Cause

The plan separates the technical threshold-setting from the legal enforcement mechanism. Thresholds are described as 'pre-registered' in planning documents, but the bilateral instrument is not cited as incorporating them by reference or making them non-amendable. In arms-control precedent (JCPOA, New START), threshold and confidence-interval disputes have repeatedly led to stalling or unilateral withdrawal because the legal force of a 'provisional' threshold is ambiguous. The plan needs explicit instrument language that locks thresholds into law and specifies the mechanical scoring procedure (confidence-interval overlap rules, default-to-Modify decision rule) so the verdict is generated by algorithm, not co-chair judgment.

---

# 7 Expert: Schedule Versioning and Technology-Neutrality Architect

**Knowledge**: Frontier computing hardware architecture and evolution, equipment classification and performance metrics, technology-neutral specification language, version control and configuration management, schedule amendment procedures, scope-creep and inflation resistance

**Why**: The plan calls for a confidential, versioned, technology-neutral covered-equipment schedule (frozen for Phase One, amendments by double-key approval only before Month 5.5 = 2027-03-23, no further changes during Months 6-9 = 2027-04-08 to 2027-07-08). This schedule defines what equipment is 'frontier-relevant' and thus subject to verification, and it must resist three pressures: vendors or operators claiming new hardware is not covered; one side claiming the other is hiding new equipment outside the schedule; and schedule drift toward a product-specific list (e.g., 'H100', 'TPU v5') that becomes obsolete as hardware evolves. This expert designs the technology-neutral classification scheme (e.g., 'dense matrix-multiply accelerator, peak FP32 >100 TFLOPS per unit, form factor <2U'), manages versioning with audit trail (who proposed each amendment, when, why, double-key approval dates), and validates whether the schedule can remain stable during Phase One or whether mid-test amendments will force decision disputes or exercise non-comparability.

**What**: Design the technology-neutral classification taxonomy for frontier-computing equipment covering: (1) processor family (matrix-accelerator, inference engine, training cluster, control-plane processor) by function, not product; (2) performance thresholds (FP32 peak TFLOPS, memory bandwidth, form factor, power envelope) defined as ranges, not specific values, so new hardware generations fall into existing tiers; (3) supply-chain provenance (original equipment manufacturer, maintenance provider, logistics partner) so transfers and maintenance changes are detectable without naming specific vendors; (4) substitution signatures (serial numbers, manufacturing date codes, physical markings, attestation records) that distinguish identity from performance. Create a version-control log template (amendment timestamp, proposing party, technical rationale, double-key approval, effective date, items affected, linkage to any exercise results that may be re-classified). Draft amendment procedures: propose amendment with technical justification by Month 4 (2027-02-08); both sides' technical teams review by Month 4.5 (2027-02-23); if consensus, lock version by Month 5.5 (2027-03-23); if deadlock, no amendment (freeze existing version for Phase One). Validate whether the schedule can remain stable by surveying Tier-1 vendors and manufacturers (do new hardware releases occur >3 months apart, requiring mid-test amendments, or is the schedule stable for a 9-month horizon).

**Skills**: Frontier computing hardware specifications, technology-neutral language design, configuration-management systems, version-control audit trail design, vendor and equipment-evolution forecasting, classification-scheme design

**Search**: GPU TPU hardware specifications technology-neutral taxonomy, equipment classification performance metrics, configuration-management version control, frontier computing procurement standards

## 7.1 Primary Actions

- Establish an Entry-Condition Task Force (both co-chairs' offices) by Month 0 (2026-10-08, 14:00) with binding weekly milestone deadlines and a published master roadmap. Launch site nomination, vendor outreach and inspector vetting in parallel at Month −2, funded by USD 50–100M compression reserve (estimate). Appoint an external escalation authority empowered to convene a co-chair emergency summit within 5 days if any gate slips >2 weeks, with authority to decide scope reduction (2 pairs, 60-day test) rather than timeline extension. Certify entry gate completion by Month 5.5 (2027-03-23, 16:00); any gate not complete by Month 9 (2027-07-08) triggers automatic Stop/re-scope decision.
- Lock the confidential evidence-weighting rule in double-key-approved escrow by Month 1.5 (2026-11-23, 10:00). Conduct historical validation on 100–200 benign equipment-change events per site by Month 2 (2026-12-08, 08:00), measuring false-positive and false-negative rates against known ground truth. If pilot false-positive rate deviates >±5 points from 10% target (outside 5–15% range), adjust the rule and re-validate on a second cohort. Add adversarial-case validation (20–30 synthetic scenarios) before Phase One exercises begin; confirm false-positive rate remains ±3 points of calibration. Lock the rule before Month 6 (2027-04-08) Phase One clock starts.
- Pre-register verdict thresholds as explicit confidence-interval bands in a double-key-approved bilateral memorandum locked by Month 2.5 (2026-12-23, 14:00), before the first Phase One exercise. Define Go (lower bound 90% CL ≥75%), Modify (straddles 60% or falls 50–80%), Stop (upper bound <55%). Adopt a mechanical scoring rule: lower bound exceeds Go threshold = Go verdict (no negotiation); upper bound below Stop = Stop; otherwise Modify. Publish confidence intervals and mechanical logic before any exercises; lock thresholds before Month 6 (2027-04-08) clock. Publish final verdict with intervals and mechanical justification within 5 days of Phase One conclusion (by Month 9.2 = 2027-07-14).
- Appoint a 3-person Bilateral Counterintelligence Oversight Board per country (reporting jointly to co-chairs) by Month 0 (2026-10-08, 16:00), with mandatory monthly classified meetings. Require all 180-per-country deployed inspectors to undergo baseline security vetting by Month 2 (2026-12-08, 09:00) and quarterly re-vetting on rotating schedule. Implement 7-day breach-adjudication protocol (48-hour investigation, 72-hour recommendation, 7-day decision). Enforce compartmentalization: inspectors separated by role and site, with post-assignment debriefs and monitored cooling-off before reassignment. Publish unclassified monthly breach-count metrics (suspected, sustained, false positives) so legislatures see governance discipline.
- Validate the inspector information firewall by Month 5 (2027-03-08, 16:00) using an independent third-country filter auditor (pre-approved by both co-chairs by Month 0 = 2026-10-08). Conduct a joint filter-design workshop by Month 0.5 (2026-10-23, 09:00) specifying which data are redacted, hashed or blinded (removing workload, topology, security architecture, customer names, source code) while preserving event-relevant detail (timestamps, serial numbers, arrival/departure records, maintenance logs). Appoint the filter auditor to validate compliance by Month 1.5 (2026-11-23, 10:00) and conduct monthly spot-check audits (random 5–10% sample). Implement a formal challenge procedure: disputed filters trigger raw-evidence escort access (24-hour advance notice, dual escort, session recorded). Document monthly: packages filtered, challenged, re-filtered, auditor findings and latency (2–3 days per package estimated).

## 7.2 Secondary Actions

- Deploy 300+ inspectors (180 per country) using staggered 4-month on-site / 2-month off-site rotation cohorts. Begin recruitment at Month −3 (2026-07-08) targeting 150–200 per country plus 30–40 surge buffer and 45–60 leave coverage. Freeze roster by Month 1 (2026-11-08, 14:00); complete security clearances and polygraph by Month 2 (2026-12-08, 09:00). Establish joint bilateral training academy by Month −1 (2026-09-08, 10:00) with 12-day curriculum (evidence collection, sealed observation, identity verification, exercises); train first cohort Months −1 to 0, second Months 0–1 (2026-10-08 to 2026-11-08), final Months 1–2 (2026-11-08 to 2026-12-08). Target 80% certified by Month 2.5 (2026-12-23, 17:00). Staff minimum 6 per shift (2 countries × 3 inspectors) × 3 shifts × 2–4 sites, no single-person critical functions, max 12 consecutive hours or 48 hours per week. Fund retention bonuses at 2–3% (USD 15–22.5M estimate) within the USD 750M personnel envelope.
- Conduct vendor outreach and written-commitment requests by Month 1 (2026-11-08, 14:00), offering each Tier-1 vendor direct participation or fallback testing (no veto over results). Document written commitment or refusal by Month 1.5 (2026-11-23, 09:00); publish vendor-participation registry by Month 3 (2027-01-08) as an entry-condition gate. Pre-stage one accredited independent-examiner team per country (5–8 specialists, cleared, bonded) by Month 1 (2026-11-08, 16:00) from the USD 500M testing envelope, so fallback procedures activate immediately if vendor refuses. Lock the vendor-refusal fallback ladder (5 rungs: vendor-supervised testing, filtered evidence, independent examiners, clean-room, cryptographic attestation) as a double-key procedure by Month 2 (2026-12-08, 09:00). Credit each rung toward identity confidence (1=70%, 2=60%, 3=80%, 4=85%, 5=50%); classify equipment as unverifiable if the ladder cannot finish before entry, and exclude from Phase One.
- Establish deadlock-resolution age triggers and automatic partial-suspension procedures as entry-condition items (double-key signed, embedded in bilateral instrument) by Month 1 (2026-11-08, 09:00): automatic partial suspension at 14 days of co-chair deadlock (pause disputed function only, unrelated sites continue); automatic impaired-confidence flag at 21 days (identity disputes) and 28 days (exit dispositions). Appoint an independent timekeeper (one per country, reporting jointly) by Month 0.5 (2026-10-23, 10:00) to track elapsed time from discrepancy opening to closure. Mandate weekly dashboard reporting (every Monday, 09:00 CET): count of open discrepancies by age bucket (0–7, 8–14, 15–21, 22+ days), count in automatic partial suspension (14+ days), count in impaired-confidence (21+/28+ days), projected recovery timeline per case. Implement automatic ledger annotation when suspension or impaired-confidence is triggered; publish weekly unclassified summary (count of suspensions, average duration) so legislatures see governance discipline.
- Pre-register and validate the technical covered-equipment schedule as a frozen, confidential, technology-neutral document by Month 5.5 (2027-03-23, 14:00). Appoint a standing mirrored technical panel (accountable specialists from both sides) to draft the schedule by Month 1.5 (2026-11-23, 10:00), with a controlled glossary and coded classification logic (performance band, form factor, application class, not specific manufacturer or model). Lock the provisional schedule by double-key approval by Month 5.5 (2027-03-23, 16:00), before Phase One clock (Month 6 = 2027-04-08). Freeze the schedule for the entire Phase One window (Months 6–9 = 2027-04-08 to 2027-07-08); no amendments allowed during operations, effective only after Phase One conclusion. Maintain a versioned change log with every amendment timestamped, double-key approved and linked to evidentiary output that triggered change; publish version history in final ledger so audit trail shows which version classified each finding.
- Establish a joint neutral secure facility (Geneva or Singapore; site decision by Month 1 = 2026-11-08) by Month 3 (2027-01-08, 09:00), at least 1,000 sq m, with key-custody ceremonies, ledger hosting, reading rooms for raw-evidence escrow and counterintelligence operations. Host the independent Exercise Authority (8 core mixed-nationality staff, funded from USD 500M testing envelope) at the neutral facility by Month 3 (2027-01-08). Establish key-custody ceremonies with both countries' specialists generating dual-share keys requiring both shares for any ledger signing or attestation validation; first ceremony Month 4 (2027-02-08). Rehearse key recovery procedures by Month 5 (2027-03-08, 14:00) to confirm lost-key recovery time is <24 hours.
- Conduct a full pilot exercise at a non-production test datacenter by Month 5 (2027-03-08, 10:00) covering all seven event types (unreported arrival, substitution, inaccurate records, delayed access, disputed identity, vendor refusal, reluctant operator) with live detection scoring. Ensure zero production disruption; run exercises only in staging, spare-inventory, maintenance or expansion areas. Score blind-exercise results against the pre-registered thresholds and evidence-weighting rule; adjust calibration if needed before Phase One operational exercises begin (Month 6 = 2027-04-08). Publish pilot results (detection rates per type, false-positive rate, false-negative rate, confidence intervals, rule adjustments) in a bilateral memorandum by Month 5.5 (2027-03-23, 14:00) so both co-chairs can finalize verdict thresholds before operations.

## 7.3 Follow Up Consultation

Next consultation should address: (1) Operator compliance incentives and shielding detection—the plan lists 'government shields an operator' as a Stop trigger but does not operationalize how to distinguish shielding from legitimate access delays or confidentiality concerns; recommend pre-agreed operator statements-of-cooperation and a formal access-denial reporting protocol. (2) Parity measurement and asymmetry detection—'reciprocal-access parity at least 85%' is listed as a scored criterion but the definition and measurement method are TBD; recommend a quantitative parity audit (inspector hours on-site per pair, detection-opportunity symmetry, filter-dispute rate per side) finalized by Month 4 (2027-02-08). (3) Phase One to Phase Two funding transition and Modify rework scope—post-Phase One funding is OPEN; recommend locking the Modify rework budget and decision path by Month 8 (2027-06-08) so the final verdict is not perceived as funding leverage. (4) Vendor ladder recovery—the five-rung vendor refusal sequence cannot complete before entry (40–60 weeks estimate); recommend a 'conditional participation' tier allowing vendors to engage fallback testing during Phase One rather than blocking equipment pre-clock, or reducing the ladder to three rungs with aggressive timelines.

## 7.4.A Issue - Entry-Condition Timeline Lacks Binding Enforcement and Parallel-Track Acceleration

The entry-gate roadmap (Months 0–5 = 2026-10-08 to 2027-03-08) lists seven sequential milestones but does not specify which are critical-path blockers, which can overlap, or how to recover from slippage. The plan assumes instrument-signature gates domestic-authority enactment, which gates site selection, which gates vendor outreach. Each slip (estimated 2–4 weeks per gate) compresses Phase One from 90 to 45–60 days, widening statistical uncertainty from ±12% to ±20% at 95% CL. No external escalation authority or scope-reduction trigger exists. Parallel tracks (site nomination, vendor outreach, inspector vetting) starting at Month −2 would recover weeks, but are not mandated.

### 7.4.B Tags

- entry-condition-sequencing
- schedule-compression-risk
- no-escalation-mechanism
- statistical-power-degradation

### 7.4.C Mitigation

Establish an Entry-Condition Task Force by Month 0 (2026-10-08) with binding weekly milestones and a published master roadmap showing instrument signature by Month 0.5 (2026-10-23), domestic authority by Month 1 (2026-11-08), and site/vendor/inspector approval by Month 4 (2027-02-08). Launch site nomination, vendor outreach and inspector vetting in parallel at Month −2 (funded from compression reserve USD 50–100M estimate). Appoint an external escalation authority with power to convene a co-chair summit within 5 days of any gate slipping >2 weeks, with a decision to reduce scope (2 pairs, 60-day test) rather than extend the timeline. Certify entry gate completion by Month 5.5 (2027-03-23); any gate not complete by Month 9 (2027-07-08) triggers a Stop/re-scope decision.

### 7.4.D Consequence

Unmitigated: sequential processing adds 8–12 weeks of risk, exhausting USD 100–500M of contingency (20–100% of the free contingency USD 400–450M estimate), compressing Phase One to 45–60 days. Statistical intervals widen from ±12% to ±20%, making Go/Modify/Stop verdicts ambiguous and contestable. Phase One is delegitimized or cancelled.

### 7.4.E Root Cause

The plan lists entry conditions but does not operationalize dependency sequencing, parallel-path acceleration, or external enforcement. Deadlock and suspension procedures apply only to Phase One operations, not to the entry gate itself, creating a governance vacuum before the 90-day clock starts.

## 7.5.A Issue - Confidential Evidence-Weighting Rule Is Locked Without Pre-Validation Against Adversarial Cases

The plan specifies a confidential rotating evidence-weighting rule (Layered Evidence Weighting Model, choice 2) to resist gaming, with weights validated only against historical benign equipment-change records. Validation on 100–200 historical events per site is planned but does not test the rule against adversarial scenarios: substituted equipment with forged attestations, delayed inspector access to hide changes, or operators colluding with vendors. If pilot false-positive rate reaches 20–30% instead of 10% target (±5 points), adjudication caseload climbs from 15 to 30–45 per month, overwhelming the planned capacity and stalling 30–50% of discrepancies unresolved at Phase One conclusion.

### 7.5.B Tags

- evidence-rule-miscalibration
- no-adversarial-validation
- adjudication-overload-risk
- unresolved-finding-backlog

### 7.5.C Mitigation

Lock the confidential evidence rule in double-key-approved escrow by Month 1.5 (2026-11-23, 10:00). Conduct historical-validation testing at a non-production test datacenter by Month 2 (2026-12-08, 08:00) on 100–200 benign events per site, measuring false-positive and false-negative rates against known ground truth. If pilot false-positive rate deviates >±5 points from 10% target (i.e., result outside 5–15% range), adjust the rule and re-validate on a second 100–200 event cohort. Add a second-phase adversarial-case validation: before Phase One exercises begin, run the rule against 20–30 synthetically constructed scenarios (forged attestations, delayed access, colluding operators) and confirm false-positive rate remains within ±3 points of calibration. Lock the rule before the Month 6 (2027-04-08) Phase One clock.

### 7.5.D Consequence

Unmitigated: miscalibrated evidence rule generates 20–30% false positives, producing 30–50 disputed findings per month. The planned adjudication capacity of 15 cases per month is exhausted by Month 1 (2026-11-08) of Phase One (Month 7 = 2027-05-08). By Phase One conclusion (Month 9 = 2027-07-08), 40–80 unresolved discrepancies accumulate, triggering automatic impaired-confidence status and partial suspension of the disputed functions. Ledger credibility collapses and verdict becomes indefensible.

### 7.5.E Root Cause

Empty

## 7.6.A Issue - Verdict Thresholds Are Pre-Registered But Statistical Confidence Intervals Are Too Wide to Disambiguate Go/Modify/Stop

The plan pre-registers Go (≥70% detection), Modify (55–75%), and Stop (<55%) thresholds for planned-event detection. With an estimated ±12% pooled confidence interval (±22% per planned-event class at 95% CL), a 70% outcome is defensible as Go (confidence band 48–92%), Modify (depending on weighting), or even Stop (under stricter interpretation). No explicit rule exists to resolve cases where the confidence interval straddles a threshold (e.g., 60% ±25% spans both Modify and Stop). The Verdict Threshold Calibration Method (choice 1) marks thresholds provisional and locked only after pilot validation, but pilot validation on 1–2 exercises per type provides even weaker confidence (±32% per-type estimate), not stronger. Political renegotiation of the verdict is therefore likely, delegitimizing the Go/Modify/Stop decision.

### 7.6.B Tags

- threshold-ambiguity
- wide-confidence-intervals
- no-tie-breaking-rule
- verdict-contestability

### 7.6.C Mitigation

Pre-register verdict thresholds as explicit confidence-interval bands (not point estimates) in a double-key-approved bilateral memorandum locked by Month 2.5 (2026-12-23, 14:00), before the first Phase One exercise. Use bands: Go (lower bound of 90% CL ≥75% detection), Modify (upper and lower bounds straddle 60% or fall within 50–80%), Stop (upper bound of 90% CL <55%). Define a mechanical scoring rule: if the lower bound exceeds the Go threshold, outcome is Go (no negotiation); if the upper bound falls below the Stop threshold, outcome is Stop; otherwise default to Modify. Publish the confidence interval for every rate and the mechanical scoring logic so both sides can verify the verdict before it is announced. Lock thresholds before Month 6 (2027-04-08) Phase One clock; publish final verdict with intervals and mechanical justification within 5 days of Phase One conclusion.

### 7.6.D Consequence

Unmitigated: ambiguous thresholds invite post-hoc renegotiation of the verdict. A 70% ±20% result can be read as Go, Modify, or Stop depending on which government's preferred interpretation prevails. Political pressure on scorers to adjust intervals or thresholds corrupts the objective decision-making design. Either government can delegitimize the verdict and withdraw, invalidating Phase One entirely.

### 7.6.E Root Cause

Empty

---

# 8 Expert: Exercise Realism and Production-Disruption Risk Assessor

**Knowledge**: Live-exercise execution in operational datacenters, production-continuity risks and mitigation, exercise scenario design and realism, unreported-arrival and substitution-detection fidelity, operator and vendor friction from exercises, exercise-related operational incidents and recovery

**Why**: The plan calls for 54 exercises (6 sites x 3 per month x 3 months = 54, or fallback 48 at 2 pairs) covering seven event types (unreported arrival, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal, reluctant operator), with zero production disruption tolerated, all in staging, spare-inventory, maintenance or expansion areas without interrupting active computational work. However, exercises in real datacenters carry inherent risk: a staging area that is supposed to be non-critical becomes critical mid-exercise if a production emergency occurs; an exercise-triggered alert could cascade into a security incident; an operator's reluctance to grant access might mask a real incident or might reflect legitimate operational constraints. This expert evaluates whether the 54-exercise load (about 6 per site per month) is operationally realistic, designs scenarios that are adversarially credible without crossing into sabotage, and validates the disruption risk and mitigation.

**What**: Work with the Exercise Authority to design realistic scenarios for each of the seven event types that can be executed in staging and spare areas without touching active production: (1) unreported arrival—can staging areas reliably serve as a stand-in for active-area loading? What is the likelihood a test arrival triggers a production-area alert? (2) Substituted equipment—can spare-inventory equipment be credibly swapped while inspectors monitor? (3) Inaccurate records—how are realistic inconsistencies introduced without exposing the test scenario to production staff? (4) Delayed access—how long can an inspector be denied access without the operator claiming emergency overrides? (5) Disputed identity—what equipment-identity disputes are credible without requiring examiners to second-guess legitimate maintenance? (6) Vendor refusal—can vendor-refusal scenarios be run with real vendors or only with role players? (7) Reluctant operator—what triggers reluctance that is realistic but not actual shielding? Survey 3-5 major datacenters (hyperscale, government-run, private colocation) about: exercise-execution experience, incidents related to live-exercise testing, typical staging-area throughput and criticality, production-area access-denial scenarios, operator and vendor appetite for exercises, estimated friction cost (staff overtime, delayed maintenance, operational planning). Estimate whether 6 exercises per site per month is sustainable or should be reduced to 3-4 per month (requiring a 180-day test instead of 90, or fallback to 2 pairs and 48 exercises). Flag scenarios that would require production-area access or that carry >10% incident risk.

**Skills**: Datacenter operations and continuity management, exercise scenario design and adversarial realism, operational-risk assessment, exercise execution metrics and incident response, vendor and operator friction modeling

**Search**: Live exercise operational datacenter, production-disruption risk assessment, exercise scenario realism testing, operator exercise participation challenges

## 8.1 Primary Actions

- Convene an Exercise Dry Run Steering Committee (both co-chairs' offices, Exercise Authority, one participating site ops lead from each country) by Month 0.5 (2026-10-23, 14:00). Scope and schedule two live exercise pilots (unreported arrival, substitution) at a real staging area (Month 4.5–5 = 2027-02-23 to 2027-03-08), measure operator friction and actual timelines, and produce a revised exercise load (reduce from 6 per type to 4–5 if timelines require 10+ days per exercise). Lock operator participation agreements with written commitments signed by Month 5.5 (2027-03-23).
- Revalidate the confidential evidence rule immediately: place the draft rule in escrow by Month 1.5 (2026-11-23, 10:00) and conduct adversarial pilot testing by Month 5 (2027-03-08) on 20–30 deliberately miscalibrated equipment scenarios (not just historical records). If false-positive rate exceeds 12%, adjust the rule and re-test before Phase One. Publish a calibration-confidence memo signed by both evidence-rule owners documenting validation dataset and residual uncertainty by Month 5.5 (2027-03-23).
- Recompute and lock shift coverage model by Month 1 (2026-11-08, 09:00): choose between Continuous 3-shift (requires ~300 per country; 'Aspirational'), Two-shift 16-hour (requires ~180 per country; 'Achievable'), or Event-triggered (requires ~120 + surge; 'High-risk for unreported arrivals'). If choice requires headcount above 150 per country, trigger scope-reduction planning (reduce to 2 pairs, 4 sites) and adjust inspector envelope accordingly. Publish shift schedule by Month 3 (2027-01-08) so red teams cannot time exercises to low-coverage windows.
- Resize adjudication staffing by Month 1 (2026-11-08): increase from 5 to 12–15 specialists per country (24–30 total), and fund a dedicated surge unit of 8–12 (4–6 per country) available on 48-hour call. Total adjudication cost estimate ~USD 2–3M additional (within the 750M personnel envelope). Recompute deadlock timeline: convene advisory panel by day 7, publish opinion by day 12, co-chair decision by day 14, automatic partial suspension at day 14 with public ledger logging.
- Lock all three primary vulnerabilities (exercise timing, evidence-rule validation, shift coverage, adjudication sizing) in the bilateral instrument by Month 2 (2026-12-08, 09:00) as binding double-key commitments, with monthly progress reporting to the co-chairs. Any deviation from agreed timelines or staffing by Month 5.5 (2027-03-23) triggers an emergency summit, with authority to Stop and re-scope if corrective action is infeasible.

## 8.2 Secondary Actions

- Appoint an independent Exercise Safety Monitor (third-country operations expert, cleared by both co-chairs) by Month 3 (2027-01-08, 09:00) with authority to halt any Phase One exercise if production disruption risk exceeds acceptable thresholds. The monitor observes Dry Run exercises and attends briefing on every Phase One exercise; halt decisions are logged in the ledger and published in unclassified weekly reports so legislatures see governance discipline.
- Establish a weekly adjudication dashboard (every Thursday, 15:00 CET via secure video) showing: discrepancies open by age bucket (0–7 days, 8–14, 15–21, 22+ days), count in automatic partial suspension, count in impaired-confidence status, projected clearance date per case. Escalate any case reaching day 12 unresolved to the co-chairs' offices so they can proactively decide rather than react at day 14 automatic suspension.
- Document operator participation agreements in writing by Month 3 (2027-01-08, 16:00) covering: notification windows for exercise scenarios (e.g., 48 hours for scheduled, 0 for unreported-arrival injection), roles during exercises (operator isolation protocols, equipment access), post-exercise remediation (equipment return, production verification), and dispute resolution (if an operator believes an exercise caused disruption, joint investigation within 5 days). Publish a redacted version of the agreements as part of the entry-gate certification so legislatures see operator buy-in.
- Pre-stage one Exercise Authority observer at each of the three sites by Month 4 (2027-02-08, 09:00) to attend the Dry Run exercises (Month 4.5–5) and validate that observed timelines match plan assumptions. Brief the Exercise Authority by Month 5.5 (2027-03-23) on any gaps so exercises can be redesigned or the site selection can be re-evaluated.
- Conduct a bilateral counterintelligence assessment of each participating site by Month 4 (2027-02-08, 16:00) to evaluate inspector exposure risk (proximity to sensitive areas, sight lines to restricted infrastructure, potential for accidental IP exposure during unreported-arrival or substitution exercises). Recommend mitigations (additional sealing, observer protocols, evidence-collection limits) and incorporate them into the Dry Run scenarios.
- Commission an independent statistical review by a third-country statistician (or team from an academic institution pre-approved by both sides) by Month 5 (2027-03-08, 09:00) to validate the confidence-interval calculations. The plan states '±12% pooled, ±32% per type' but does not document the n and p assumptions; an independent review confirms or revises those figures and flags any assumption changes that would shift thresholds (e.g., if exercises run at 3 per month instead of 6, intervals widen). Final statistical memo locked by Month 5.5 (2027-03-23).

## 8.3 Follow Up Consultation


The next consultation should address: (1) Operator and vendor resistance to blind exercises—what contractual terms, compensation, or legal protections will secure their participation, and which vendors have publicly signaled refusal? (2) Neutral facility readiness—has Geneva or Singapore confirmed availability, security clearance, and operational readiness by Month 3 (2027-01-08)? (3) Key-custody ceremonies—are HSM (hardware security module) and dual-key procedures tested and rehearsed before Month 4 (2027-02-08)? (4) Ledger divergence recovery—if a ledger divergence occurs at day 5 of Phase One (worst case for time pressure), can it be reconciled within 72 hours, or will the deadlock procedure stall the site? (5) Post-Phase-One funding—if the verdict is Modify, does the program have authority and funds to execute rework, or is Phase One a dead-end? Clarify these by Month 3 (2027-01-08).


## 8.4.A Issue - Exercise Execution Design Does Not Match Production Reality or Operator Tolerance

The plan specifies 54 exercises in 90 days (6 per event type minimum) without detailing staging-area setup, equipment-swap logistics, or unreported-arrival injection mechanics. Three critical gaps: (1) Staging areas are designated but not tested for isolation from active infrastructure—swapping frontier hardware in a live datacenter without production touch is operationally novel and untested. (2) Unreported-arrival injection requires injecting equipment past operator awareness; the plan does not clarify whether vendors and operators will permit blind injections into their facilities, and operator friction from exercises is listed as a risk but not mitigated. (3) Six exercises per type in a 90-day window, under full mirrored shifts and with filtering/certification latency (2-3 days per package), leaves only 5-7 days per exercise for setup, execution, evidence collection and teardown—realistic timelines are 10-14 days per exercise (test, remediate, repeat). The plan will either compress exercises into shallow scenarios or face production disruption if each is realistic.

### 8.4.B Tags

- exercise-execution-mismatch
- staging-area-untested
- operator-friction-unmitigated
- unreported-arrival-injection-logistics
- timeline-compression
- production-disruption-risk

### 8.4.C Mitigation

Conduct a three-site Exercise Dry Run (Month 4.5 = 2027-02-23 to Month 5 = 2027-03-08) at one declared site from each country and one neutral non-production facility. For each site, execute two of the seven event types (unreported arrival, substitution) in staging areas under real hardware, full filtering and mirrored observation. Measure actual timelines: setup duration, swap execution, evidence collection, filtering latency, ledger closure. Document operator friction points and agree on notification protocols (e.g., 48-hour operator notice for exercise window, 0 notice for unreported-arrival injection). Revise exercise load (reduce to 4-5 per type if timelines exceed 10 days) and lock operator participation agreements with written commitments signed by Month 5.5 (2027-03-23). Appoint an independent Exercise Safety Monitor (third-country operations expert) who has authority to halt any exercise if production risk is judged unacceptable; logged decisions feed into the final audit.

### 8.4.D Consequence

Risk of operational failure during Phase One: (1) Exercises execute at low fidelity (simulations rather than real hardware swaps), so detection data are misleading and the final verdict is non-credible. (2) Operator resistance causes exercises to be moved or cancelled, reducing sample size below the 6-per-type minimum and widening confidence intervals from ±12% to ±18% (pooled), making Go/Modify/Stop boundaries ambiguous. (3) Production disruption during an exercise (equipment misplaced, network isolation incomplete, active workload interrupted) forces a site offline for 8-24 hours, which the plan explicitly forbids and triggers operator complaints that feed into a shielding allegation or tranche withheld.

### 8.4.E Root Cause

Exercise design was written at strategic level without engagement with datacenter operations, maintenance planning or equipment logistics. The plan assumes exercises can be injected, measured and remediated in 5-7 days per event without specifying the operational machinery—operator notification windows, equipment-staging validation, swap logistics, physical teardown and ledger-closure timelines. Staging-area isolation has not been tested at any participating site, and the injections assume operator willingness to host blind unreported-arrival tests, which is not documented.

## 8.5.A Issue - Adjudication Capacity Underestimated by 2-4x; Deadlock Procedures Will Stall Under Evidence Volume

The plan allocates 15 discrepancies per month adjudication capacity (one 5-person adjudication unit per country = 10 specialists total for 360-person program, 2.8% of staffing). Reality check: (1) If the confidential evidence rule is miscalibrated (false-positive rates 15-20% vs. 10% target), the plan admits miscalibration would 'overflow adjudication.' At a 15% false-positive rate, 54 exercises generate ~8 exercises × 15% = 1.2 false positives per month, plus 2-3 legitimate discrepancies per month (ambiguous equipment identity, incomplete disposal records, ledger divergence) = 3.2 cases per month baseline. If the rule is off by 5 points (false positives 15% instead of 10%), adjudication load rises to ~5 cases per month. (2) The deadlock procedure allocates 10 days for convening and 5 days for an advisory panel, then 3 days for co-chair decision (day 18); automatic partial suspension at day 14 while the advisory panel is still deliberating. At 3-4 cases per month, at least one will hit day 14 while awaiting the panel opinion, triggering a partial suspension that must be logged and may trigger media attention. (3) No surge adjudication unit is funded; the plan allocates only 5 positions per country for adjudication as part of the 36-person specialist unit. If load hits 30-40 cases in a month (possible if exercises cluster and rule miscalibration surfaces), the 5 specialists are overwhelmed and cases age rapidly, hitting impaired-confidence (day 21) and forcing automatic site suspension.

### 8.5.B Tags

- adjudication-capacity-underestimated
- deadlock-stall-risk
- false-positive-overflow
- surge-capacity-underfunded
- evidence-rule-miscalibration-risk
- partial-suspension-cascades

### 8.5.C Mitigation

Resize adjudication immediately: add 8-10 specialists per country (total 16-20, up from 10) and fund a dedicated surge unit of 4-6 per country (total 8-12) available on 48-hour call. Validate the evidence rule on adversarial test cases (not just historical records) by Month 5 (2027-03-08): apply the draft rule to 20-30 deliberately miscalibrated equipment scenarios (records that conflict, omitted serial numbers, altered maintenance logs) and measure false-positive and false-negative rates against known ground truth. If pilot miscalibration shows false positives above 12%, adjust the rule before Phase One and re-test. Lock the rule by Month 5.5 (2027-03-23) with a 'calibration confidence memo' signed by both evidence-rule owners documenting the validation dataset and any residual uncertainty. Restructure deadlock timeline: convene the advisory panel by day 7 (not day 10), publish the panel's opinion by day 12, allow co-chairs 2 days (day 14) to decide; if no decision by day 14, automatic partial suspension is triggered, but the opinion and suspension are published as a joint ledger event so legislatures see the technical recommendation. Add a weekly adjudication dashboard (every Thursday) showing age-bucket counts and projected case clearance date per site.

### 8.5.D Consequence

Phase One stalls 4-6 weeks into the 90-day window as adjudication cases age and automatic partial suspensions trigger. At day 21, identity disputes force impaired-confidence flags; at day 28, disposal-record disputes trigger the same. If multiple sites hit impaired-confidence simultaneously (possible if a rule miscalibration affects all sites uniformly), the program enters automatic partial suspension across 2-3 sites, and the co-chairs must decide whether to Stop or invoke an emergency summit. The partial-suspension trigger (day 14 unresolved) is designed to be non-negotiable, so each co-chair sees the suspension as the other side delaying resolution, feeding into deadlock and mutual blame. The final verdict is delayed or becomes a Stop by default because the program runs out of calendar time before adjudication clears.

### 8.5.E Root Cause

Adjudication headcount (5 per country) was derived from a 15-discrepancies-per-month assumption without validation on historical datasets or realistic miscalibration scenarios. The plan acknowledges false-positive overflow ('adjudication overload') in the Weaknesses section but does not resize staffing or add surge capacity. The deadlock timeline (days 10-18) was designed for a 2-3 case monthly steady state, not for the clustering that will occur when exercises run in parallel weeks and evidence filters certifications bottleneck (2-3 days per package × 54 exercises = 54 people-days of filter-certification work compressed into 6 weeks before Phase One, creating a backlog).

## 8.6.A Issue - Inspector Shift Coverage Will Not Support 24/7 Unreported-Arrival Detection; Blind-Challenge Execution Becomes Predictable

The staffing model allocates 99 inspection-corps per country (54 positions × 1.4 for 7-day coverage = 76, plus 30% leave cover = 99). This arithmetic is correct only if every inspector works 12 consecutive hours or splits two 8-hour shifts, but the plan forbids both ('no inspector working >12 consecutive hours or >48 hours per week'). Reality: 54 positions at 3 sites × 3 shifts × 6 field staff per position × 40-hour-per-week work rule = 54 / (40 / (8 × 3 shifts)) = 54 × 3 shifts / 40 hours = 4.05 shifts per position per week. With 6 field staff per shift and 3 shifts, staff coverage = (6 × 3 × 40 hours) / 54 positions = 720 / 54 = 13.3 hours per position average per week—far short of the 40-hour-per-week work rule. The actual headcount needed is 54 × (40 hours / 13.3 hours) ≈ 162 per country, not 99. Gap: 63 per country (126 total), or 35% of the inspection corps. Consequence: either shifts are undermanned (fewer than 6 per shift) or inspectors work >48 hours per week, violating the plan constraint. Specifically for unreported-arrival exercises (which test the detection of equipment introduced without operator declaration), the detection rate depends entirely on shift staffing at the moment of arrival. If shifts are undermanned or rotated predictably, exercises can be timed to arrive during low-coverage windows, and the blind-challenge intent is lost.

### 8.6.B Tags

- shift-coverage-arithmetic-error
- understaffing-risk
- unreported-arrival-detection-vulnerable
- work-hour-violation
- exercise-timing-gaming
- blind-challenge-credibility

### 8.6.C Mitigation

Recompute staffing for the stated coverage model (Mirrored Shift Coverage Architecture, choice 1: 'minimum paired presence in staging and spare-inventory areas at all times'). Define 'minimum paired presence' explicitly: e.g., 4 inspectors (2 per country) continuously present in staging + 2 in spare/expansion areas, rotating every 8 hours. At 3 sites, 2 shifts minimum (day/night, 16 hours unbroken coverage) is operationally sustainable; 3-shift 24/7 continuous is above budget. Choose: (A) Continuous 3-shift coverage (requires ~300 inspectors per country, not 99; 'Aspirational'); (B) Two-shift 16-hour coverage (6:00–22:00) with on-call night response (requires ~180 per country); or (C) Event-triggered coverage (deploy inspectors within 4 hours of a reported activity; requires ~120 per country + surge pool, but misses unreported arrivals). Lock the choice by Month 1 (2026-11-08) based on entry-gate cost analysis. Revalidate exercise timing: if choice (B) or (C), every unreported-arrival and disputed-identity exercise must occur during core coverage hours (6:00–22:00 for choice B) or within 4 hours of an activity report (choice C). Document the shift schedule publicly so red teams cannot game it. If coverage cannot be delivered without exceeding USD 750M personnel envelope, reduce site count from 3 to 2 pairs (4 sites total, allowing ~225 per country, enough for choice B at 4 sites).

### 8.6.D Consequence

Unreported-arrival exercises will be gamed or will fail to detect adversarial arrivals that occur during shift boundaries or low-presence windows. If five exercises test unreported arrival (n=5) and two are timed to low-coverage moments, the observed detection rate is 3/5 = 60%, which falls into the Modify band (55-75%), not the Go band (≥75%). Across all seven event types, the inadequate shift coverage for unreported arrivals and disputed-identity resolution (both require continuous or high-frequency presence) lowers the pooled detection rate and pushes the verdict toward Modify or Stop. The exercising agency (red teams) will know the shift schedules and time injections accordingly, and inspectors will know that they are expected to detect such arrivals yet lack the staffing, creating morale and credibility issues. If exercises show low unreported-arrival detection (say 40-50%) and the co-chairs ask why, the honest answer is understaffing, which becomes a Stop trigger ('material equipment remains unverifiable' due to detection failure).

### 8.6.E Root Cause

Staffing math was done at the envelope level (number of people) without validating the coverage formula (hours of presence per shift per site). The plan states 'minimum paired presence in staging and spare-inventory areas at all times' (Mirrored Shift Coverage Architecture, choice 1), which implies continuous presence, but the headcount allocation assumes 7-day coverage (1.4 multiplier), not continuous. Continuous coverage would require 54 × 3 shifts × (168 hours / week / 40 hours per week) ≈ 54 × 3 × 4.2 = 680 person-positions, not 99 or even 162. The plan chose not to provide continuous presence, yet exercises assume inspectors can detect unreported arrivals at any time, which is contradictory.