
## Audit - Corruption Risks

- Bribery of government officials to expedite or secure film permits and location access.
- Kickbacks from vendors (e.g., equipment rental, catering) in exchange for contracts.
- Conflicts of interest involving crew members or consultants with undisclosed financial ties to suppliers.
- Nepotism in hiring local crew, potentially compromising quality or inflating costs.
- Misuse of inside information regarding filming locations or schedules for personal gain (e.g., insider trading, extortion).

## Audit - Misallocation Risks

- Inflated invoices from local vendors due to lack of oversight.
- Double-billing for equipment rentals or location fees.
- Unnecessary or extravagant expenses for travel and accommodation of above-the-line talent.
- Inefficient allocation of post-production budget, leading to compromised quality or missed deadlines.
- Misreporting of progress to secure further funding or meet contractual obligations.

## Audit - Procedures

- Conduct quarterly internal audits of all financial transactions, focusing on vendor payments and expense reports.
- Implement a robust contract review process with pre-approval thresholds for all vendor agreements exceeding HK$500,000.
- Perform regular compliance checks to ensure adherence to Hong Kong film censorship regulations and labor laws.
- Conduct a post-project external audit to assess overall financial performance and identify areas for improvement.
- Establish a whistleblower mechanism for reporting suspected fraud or corruption, with clear procedures for investigation and resolution.

## Audit - Transparency Measures

- Publish a project budget dashboard accessible to key stakeholders, tracking actual expenses against planned allocations.
- Document and publish minutes of key production meetings, including decisions related to budget, casting, and location selection.
- Establish a clear and documented selection criteria for all major vendors and contractors.
- Implement a policy of open bidding for all major contracts, ensuring fair competition and transparency.
- Create a publicly accessible website or online platform providing updates on project progress and key milestones.