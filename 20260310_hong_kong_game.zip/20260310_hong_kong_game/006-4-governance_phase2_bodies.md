### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance for the project, ensuring alignment with overall business objectives and managing high-level risks, given the project's significant budget and potential impact.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic direction and guidance to the Project Management Office.
- Review and approve major project deliverables and milestones.
- Monitor project progress and performance against key performance indicators (KPIs).
- Identify, assess, and mitigate strategic risks.
- Resolve escalated issues and conflicts.
- Approve budget changes exceeding HK$5,000,000.
- Approve changes to the core creative vision of the film.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chairperson.
- Establish meeting schedule and communication protocols.
- Define escalation paths and decision-making processes.
- Review and approve the project charter.

**Membership:**

- Executive Producer
- Lead Producer
- Head of Production
- Head of Finance
- Independent Film Industry Advisor (External)

**Decision Rights:** Strategic decisions related to project scope, budget, timeline, and key deliverables. Approval of budget changes exceeding HK$5,000,000. Approval of changes to the core creative vision of the film.

**Decision Mechanism:** Decisions are made by majority vote. In the event of a tie, the Chairperson has the deciding vote. Dissenting opinions are documented in the meeting minutes.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical issues.

**Typical Agenda Items:**

- Review of project progress and performance against KPIs.
- Discussion and approval of major project deliverables and milestones.
- Review and mitigation of strategic risks.
- Resolution of escalated issues and conflicts.
- Budget review and approval of changes.
- Review of key strategic decisions (e.g., casting, distribution).

**Escalation Path:** Unresolved issues are escalated to the CEO or equivalent senior executive.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day project execution, ensuring adherence to budget, timeline, and quality standards.  Essential for a complex, location-driven production with numerous stakeholders.

**Responsibilities:**

- Develop and maintain project plans, schedules, and budgets.
- Manage project resources and track expenses.
- Monitor project progress and identify potential issues.
- Coordinate communication between project stakeholders.
- Implement risk management plans.
- Ensure compliance with regulatory requirements.
- Manage vendor contracts and performance.
- Prepare and present project status reports to the Project Steering Committee.
- Make operational decisions within budget thresholds (under HK$5,000,000).

**Initial Setup Actions:**

- Establish project management processes and tools.
- Develop project communication plan.
- Define roles and responsibilities for project team members.
- Set up project tracking and reporting systems.
- Establish a risk register.

**Membership:**

- Project Manager
- Line Producer
- Production Accountant
- Location Manager
- Post-Production Supervisor

**Decision Rights:** Operational decisions related to project execution, resource allocation, and risk management within defined budget thresholds (under HK$5,000,000).

**Decision Mechanism:** Decisions are made by the Project Manager in consultation with the relevant team members. Disagreements are escalated to the Lead Producer.

**Meeting Cadence:** Weekly, with daily stand-up meetings for the core project team.

**Typical Agenda Items:**

- Review of project progress against schedule.
- Discussion of potential issues and risks.
- Review of budget and expenses.
- Coordination of tasks and activities.
- Update on regulatory compliance.
- Vendor performance review.

**Escalation Path:** Issues exceeding the PMO's authority or budget are escalated to the Project Steering Committee.
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides expert advice on technical aspects of the film production, including cinematography, sound design, VFX, and post-production, ensuring high technical quality and efficient use of resources.

**Responsibilities:**

- Advise on technical aspects of film production, including cinematography, sound design, VFX, and post-production.
- Review and approve technical specifications and standards.
- Evaluate and recommend technical solutions and equipment.
- Provide guidance on troubleshooting technical issues.
- Ensure technical quality and consistency throughout the production process.
- Assess the feasibility of complex visual effects or stunts.
- Review and approve the final film master.

**Initial Setup Actions:**

- Identify and recruit technical experts.
- Define scope of advisory services.
- Establish communication protocols.
- Review project technical requirements.

**Membership:**

- Director of Photography
- Sound Designer
- VFX Supervisor
- Post-Production Supervisor
- Independent Film Technology Consultant (External)

**Decision Rights:** Advisory role on technical aspects of film production. Approval of technical specifications and standards.

**Decision Mechanism:** Decisions are made by consensus. In the event of disagreement, the Director of Photography has the final say on cinematography, the Sound Designer on sound, and the VFX Supervisor on visual effects.

**Meeting Cadence:** Bi-weekly during pre-production and production, monthly during post-production, with ad-hoc meetings as needed.

**Typical Agenda Items:**

- Review of technical specifications and standards.
- Discussion of technical challenges and solutions.
- Evaluation of technical equipment and software.
- Review of VFX and sound design progress.
- Assessment of technical quality and consistency.
- Review of the final film master.

**Escalation Path:** Technical issues that cannot be resolved by the Technical Advisory Group are escalated to the Project Steering Committee.
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures compliance with ethical standards, legal regulations (including GDPR), and Hong Kong film censorship guidelines, mitigating risks related to corruption, data privacy, and freedom of expression.

**Responsibilities:**

- Oversee compliance with ethical standards, legal regulations, and Hong Kong film censorship guidelines.
- Develop and implement policies and procedures to prevent corruption, bribery, and conflicts of interest.
- Ensure compliance with data privacy regulations (GDPR) and other relevant laws.
- Review and approve the script to ensure compliance with censorship guidelines.
- Investigate and resolve ethical complaints and compliance violations.
- Provide training to cast and crew on ethical standards and compliance requirements.
- Monitor vendor contracts and payments to prevent fraud and corruption.
- Ensure a safe and respectful working environment for all cast and crew.

**Initial Setup Actions:**

- Develop a code of ethics and compliance policies.
- Appoint a compliance officer.
- Establish reporting mechanisms for ethical concerns and compliance violations.
- Conduct a risk assessment to identify potential ethical and compliance risks.

**Membership:**

- Compliance Officer
- Legal Counsel
- HR Representative
- Independent Ethics Advisor (External)
- Local Cultural Advisor

**Decision Rights:** Oversight of ethical and compliance matters. Approval of policies and procedures related to ethics and compliance. Authority to investigate and resolve ethical complaints and compliance violations.

**Decision Mechanism:** Decisions are made by majority vote. The Compliance Officer has the authority to halt production if there is a serious ethical or compliance violation.

**Meeting Cadence:** Quarterly, with ad-hoc meetings as needed for urgent issues.

**Typical Agenda Items:**

- Review of ethical complaints and compliance violations.
- Discussion of potential ethical and compliance risks.
- Review of policies and procedures related to ethics and compliance.
- Update on legal and regulatory changes.
- Review of vendor contracts and payments.
- Training on ethical standards and compliance requirements.

**Escalation Path:** Serious ethical or compliance violations are escalated to the CEO or equivalent senior executive and potentially to external regulatory bodies.
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Manages relationships with key stakeholders, including local residents, businesses, and government agencies, ensuring smooth production and minimizing potential disruptions or negative impacts on the community.

**Responsibilities:**

- Identify and engage with key stakeholders, including local residents, businesses, and government agencies.
- Develop and implement a stakeholder engagement plan.
- Communicate project updates and address stakeholder concerns.
- Negotiate agreements with stakeholders regarding filming locations and access.
- Obtain necessary permits and approvals from government agencies.
- Manage community relations and address any negative impacts of the production.
- Ensure compliance with local regulations and cultural sensitivities.
- Mediate disputes between the production team and stakeholders.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop a stakeholder engagement plan.
- Establish communication channels with stakeholders.
- Conduct initial meetings with stakeholders.

**Membership:**

- Location Manager
- Community Liaison Officer
- Public Relations Representative
- Legal Counsel
- Representative from the Hong Kong Film Services Office (Ex-Officio)

**Decision Rights:** Management of stakeholder relationships. Negotiation of agreements with stakeholders. Obtaining necessary permits and approvals.

**Decision Mechanism:** Decisions are made by consensus. In the event of disagreement, the Location Manager has the final say on location-related issues, and the Community Liaison Officer has the final say on community relations issues.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for specific issues.

**Typical Agenda Items:**

- Review of stakeholder engagement activities.
- Discussion of stakeholder concerns and issues.
- Update on permit applications and approvals.
- Review of community relations activities.
- Negotiation of agreements with stakeholders.
- Mediation of disputes.

**Escalation Path:** Stakeholder issues that cannot be resolved by the Stakeholder Engagement Group are escalated to the Project Steering Committee.