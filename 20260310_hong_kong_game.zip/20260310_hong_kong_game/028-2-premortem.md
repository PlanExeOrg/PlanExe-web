A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The Hong Kong Film Development Fund will provide the anticipated level of financial incentives. | Submit a detailed project proposal to the HKFDF outlining the film's budget, scope, and potential benefits to the local film industry. | Receive official notification from the HKFDF that the project's funding application has been rejected or approved at a significantly reduced level (e.g., less than 75% of the requested amount). |
| A2 | Key filming locations in Hong Kong will remain consistently accessible and free from unforeseen disruptions throughout the production schedule. | Conduct thorough site surveys of all identified key filming locations, consulting with local authorities and property owners to assess potential risks (e.g., planned construction, permit restrictions, public demonstrations). | Receive official notification of permit denials or significant restrictions for more than 25% of the identified key filming locations, or identify credible threats of disruption (e.g., planned protests) that would prevent filming at those locations. |
| A3 | The target international audience will embrace a remake of 'The Game' set in Hong Kong, with its unique cultural and political context. | Conduct targeted market research surveys and focus group sessions in key international markets (e.g., North America, Europe, Asia) to gauge audience interest in a Hong Kong-set thriller remake and their familiarity with the original film. | Receive survey results indicating that less than 40% of the target audience expresses interest in seeing a Hong Kong-set thriller remake, or that a significant portion of the audience is unfamiliar with the original film's premise. |
| A4 | The lead actor, once cast, will remain committed to the project and available throughout the entire production and post-production timeline. | Include a robust 'key person' clause in the lead actor's contract that outlines specific performance obligations, consequences for breach, and mechanisms for dispute resolution. | The lead actor expresses intent to withdraw from the project due to scheduling conflicts, creative differences, or personal reasons, despite the existence of a legally binding contract. |
| A5 | The selected director will maintain a consistent creative vision throughout the production process, aligning with the project's overall goals and budget. | Establish a detailed director's agreement that clearly defines the scope of creative control, decision-making processes, and mechanisms for resolving creative disputes with the producers. | The director proposes significant deviations from the agreed-upon creative vision that would substantially increase the budget, alter the film's core themes, or compromise its commercial viability. |
| A6 | The film's score and soundtrack can be licensed and cleared for international distribution at a reasonable cost, without significant restrictions or delays. | Conduct a preliminary music rights clearance assessment, identifying potential copyright holders and obtaining estimated licensing fees for key musical pieces intended for use in the film. | The estimated licensing fees for key musical pieces exceed 15% of the total music budget, or copyright holders impose restrictions that would prevent the film's distribution in key international markets. |
| A7 | The Hong Kong-based film crew will possess the necessary skills and experience to execute the film's technical requirements to the required international standards. | Conduct thorough skills assessments and technical evaluations of key crew members (e.g., cinematographers, VFX artists, sound engineers) based on their past work and performance on pre-production tasks. | The skills assessments reveal significant gaps in the crew's expertise, requiring extensive training or the hiring of expensive international specialists to meet the film's technical demands. |
| A8 | The film's themes and narrative will resonate positively with film festival selection committees, leading to acceptance and premiere at a prestigious international film festival. | Submit a detailed synopsis, treatment, and sample scenes to a panel of experienced film festival consultants for feedback on the film's potential for festival acceptance and awards. | The film festival consultants provide negative feedback, indicating that the film's themes are not timely or relevant, or that its narrative structure is unlikely to appeal to festival audiences. |
| A9 | The political climate in Hong Kong will remain stable enough to allow for uninterrupted film production, without significant restrictions on freedom of expression or assembly. | Consult with political risk analysts and local experts to assess the current political climate in Hong Kong and identify potential risks to film production, including censorship, protests, and government interference. | The political risk assessment indicates a high probability of significant disruptions to film production due to increased political instability, censorship, or government interference. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Incentive Inferno | Process/Financial | A1 | Producer | CRITICAL (20/25) |
| FM2 | The Gridlock Gamble | Technical/Logistical | A2 | Permitting Lead | HIGH (12/25) |
| FM3 | The Cultural Chasm | Market/Human | A3 | Marketing Lead | CRITICAL (15/25) |
| FM4 | The Vanishing Virtuoso | Process/Financial | A4 | Producer | HIGH (10/25) |
| FM5 | The Director's Detour | Technical/Logistical | A5 | Creative Producer | HIGH (12/25) |
| FM6 | The Sonic Snare | Market/Human | A6 | Music Supervisor | HIGH (12/25) |
| FM7 | The Expertise Exodus | Technical/Logistical | A7 | Head of Production | HIGH (12/25) |
| FM8 | The Festival Freeze-Out | Market/Human | A8 | Publicity Lead | CRITICAL (15/25) |
| FM9 | The Political Peril | Process/Financial | A9 | Production Manager | HIGH (10/25) |


### Failure Modes

#### FM1 - The Incentive Inferno

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Producer
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's financial model heavily relies on securing a substantial portion of its funding from the Hong Kong Film Development Fund (HKFDF). If the HKFDF rejects the funding application, or approves it at a significantly reduced level, the project faces a critical funding gap. This gap could lead to several cascading effects: budget cuts impacting production quality, delays in securing key talent and locations, and ultimately, the project's cancellation. The lack of HKFDF funding also reduces the project's attractiveness to other potential investors, creating a negative feedback loop.

##### Early Warning Signs
- Delays in receiving feedback from the HKFDF on the funding application.
- Rumors of changes in the HKFDF's funding priorities or eligibility criteria.
- Increased competition for HKFDF funding due to a surge in film production in Hong Kong.

##### Tripwires
- HKFDF funding approved at <= 50% of the requested amount.
- Alternative funding sources secured cover <= 25% of the HKFDF shortfall.
- Projected ROI drops below 8% due to funding shortfall.

##### Response Playbook
- Contain: Immediately implement a hiring freeze and halt all non-essential spending.
- Assess: Conduct a thorough review of the budget to identify potential cost-cutting measures and alternative funding sources.
- Respond: Explore co-production opportunities with international partners, seek bridge financing, or significantly scale down the project's scope.


**STOP RULE:** Inability to secure alternative funding sources to cover at least 75% of the HKFDF shortfall within 60 days of the funding rejection.

---

#### FM2 - The Gridlock Gamble

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Permitting Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The film's visual identity is intrinsically linked to specific, iconic locations in Hong Kong. If access to these locations is denied or severely restricted due to unforeseen circumstances (e.g., permit denials, construction delays, political unrest), the production faces significant logistical and creative challenges. This could necessitate costly location scouting for alternatives, script revisions to accommodate new settings, and ultimately, a compromise in the film's intended visual impact. The inability to film in key locations also disrupts the carefully planned production schedule, leading to delays and increased costs.

##### Early Warning Signs
- Delays in receiving location permits from the Hong Kong Film Services Office.
- Unexpected construction or renovation projects commencing at key filming locations.
- Increased political tensions or public demonstrations near identified filming locations.

##### Tripwires
- Permit denials or significant restrictions for >= 30% of identified key filming locations.
- Alternative filming locations identified are >= 20% more expensive than original locations.
- Rescheduling due to location unavailability exceeds 14 days.

##### Response Playbook
- Contain: Immediately halt all pre-production activities related to the inaccessible locations.
- Assess: Conduct a rapid assessment of alternative locations and script revisions to mitigate the impact of location unavailability.
- Respond: Negotiate with location owners and authorities to resolve permit issues, explore alternative filming techniques (e.g., CGI) to recreate inaccessible locations, or significantly revise the script to accommodate new settings.


**STOP RULE:** Inability to secure access to at least 60% of the originally planned key filming locations within 90 days of the start of principal photography.

---

#### FM3 - The Cultural Chasm

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Marketing Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project assumes that an international audience will embrace a remake of 'The Game' set in Hong Kong, with its unique cultural and political context. However, if the target audience is unfamiliar with Hong Kong culture, or if they perceive the film's themes as irrelevant or inaccessible, the project faces a significant market risk. This could result in low box office turnout, negative reviews, and a failure to secure distribution deals in key international markets. The film's cultural elements, intended to enhance its appeal, could instead alienate a significant portion of the target audience, leading to commercial failure.

##### Early Warning Signs
- Low engagement rates with marketing materials featuring Hong Kong cultural elements.
- Negative feedback from test screenings regarding the film's setting and themes.
- Lack of interest from international distributors in acquiring the film for their territories.

##### Tripwires
- Pre-sales in key international markets are <= 50% of projected figures.
- Audience scores from test screenings are <= 60% positive.
- Social media sentiment analysis indicates >= 30% negative reactions to the Hong Kong setting.

##### Response Playbook
- Contain: Immediately halt all marketing campaigns that emphasize Hong Kong cultural elements.
- Assess: Conduct additional market research to identify the specific reasons for audience disinterest and explore alternative marketing strategies.
- Respond: Re-edit the film to minimize cultural references, re-focus marketing efforts on universal themes, or significantly scale down the project's scope to target a niche audience.


**STOP RULE:** Inability to secure distribution deals in at least three major international markets (e.g., North America, Europe, Asia) within 6 months of completing principal photography.

---

#### FM4 - The Vanishing Virtuoso

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Producer
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The entire project hinges on the lead actor's consistent presence and commitment. If the lead actor unexpectedly withdraws due to scheduling conflicts, creative disagreements, or personal reasons, the production grinds to a halt. Recasting necessitates costly auditions, schedule adjustments, and potential script revisions to accommodate the new actor's style. The delay inflates production costs, jeopardizes distribution deals, and erodes investor confidence. The film's marketability plummets as the original star power vanishes.

##### Early Warning Signs
- The lead actor expresses dissatisfaction with the script or director's vision.
- The lead actor's agent requests frequent schedule changes or additional compensation.
- Rumors circulate about the lead actor's involvement in other competing projects.

##### Tripwires
- Lead actor requests >= 3 unscheduled days off within a 30-day period.
- Negotiations for additional compensation exceed 10% of the original contract value.
- Public statements from the lead actor expressing doubts about the project's direction.

##### Response Playbook
- Contain: Immediately engage the lead actor and their representatives in open communication to address concerns and find mutually agreeable solutions.
- Assess: Evaluate the feasibility of accommodating the lead actor's requests without compromising the project's budget or timeline.
- Respond: If accommodation is impossible, activate the 'key person' clause in the contract, explore legal options, and begin discreetly scouting for potential replacements.


**STOP RULE:** The lead actor formally withdraws from the project and refuses to honor the terms of the contract, and a suitable replacement cannot be secured within 60 days.

---

#### FM5 - The Director's Detour

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Creative Producer
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The director's consistent creative vision is paramount to the film's coherence and artistic merit. If the director deviates significantly from the agreed-upon vision, proposing drastic script alterations, budget-busting special effects, or thematic shifts, the project veers off course. This leads to creative clashes with producers, production delays, and a compromised final product. The film loses its focus, alienating both the creative team and the target audience.

##### Early Warning Signs
- The director proposes script revisions that fundamentally alter the film's core themes or plot points.
- The director's requests for additional special effects or elaborate set pieces exceed the allocated budget.
- The director expresses a desire to significantly change the film's target audience or marketing strategy.

##### Tripwires
- Director proposes script changes requiring >= 20% budget increase.
- Director's requested VFX additions exceed 15% of the VFX budget.
- Director publicly contradicts agreed-upon marketing strategy.

##### Response Playbook
- Contain: Immediately convene a meeting with the director, producers, and key creative team members to discuss the proposed changes and their potential impact.
- Assess: Evaluate the feasibility of incorporating the director's vision while staying within budget and maintaining the film's core themes.
- Respond: If the director's vision is incompatible with the project's goals, attempt to negotiate a compromise or, as a last resort, invoke the director's agreement and seek a replacement.


**STOP RULE:** The director refuses to compromise on their vision, and their proposed changes would increase the budget by more than 25% or fundamentally alter the film's core themes, and a suitable replacement cannot be secured within 90 days.

---

#### FM6 - The Sonic Snare

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Music Supervisor
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The film's soundtrack, intended to enhance its atmosphere and emotional impact, becomes a legal minefield. If key musical pieces cannot be licensed or cleared for international distribution due to exorbitant fees or copyright restrictions, the film's market reach is severely limited. Replacing the music necessitates costly re-scoring, potentially compromising the film's artistic integrity. The lack of a compelling soundtrack diminishes audience engagement and reduces the film's overall appeal.

##### Early Warning Signs
- Initial inquiries to music rights holders reveal unexpectedly high licensing fees.
- Copyright holders impose restrictions that would prevent the film's distribution in key international markets.
- The composer expresses difficulty in creating original music that matches the desired tone and atmosphere.

##### Tripwires
- Licensing fees for key musical pieces exceed 20% of the total music budget.
- Copyright holders refuse to grant distribution rights in >= 2 major international territories.
- Replacement music scores receive negative feedback from test audiences.

##### Response Playbook
- Contain: Immediately halt all further negotiations with the problematic rights holders.
- Assess: Conduct a thorough review of alternative musical pieces that are either royalty-free or available at a reasonable cost.
- Respond: Commission original music that captures the desired tone and atmosphere, or significantly revise the film's scenes to minimize reliance on copyrighted music.


**STOP RULE:** The cost of securing music rights exceeds 30% of the music budget, or the film cannot be distributed in at least two major international territories due to music rights restrictions.

---

#### FM7 - The Expertise Exodus

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Head of Production
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The film's technical execution relies heavily on the skills and experience of the Hong Kong-based film crew. If the crew lacks the necessary expertise in areas like visual effects, sound design, or cinematography, the film's quality suffers. This necessitates costly training programs or the hiring of international specialists, blowing the budget and delaying the production schedule. The film's visual and auditory impact is compromised, leading to negative reviews and reduced audience engagement.

##### Early Warning Signs
- Key crew members struggle to meet deadlines or produce work that meets the director's expectations.
- The production team identifies significant gaps in the crew's technical knowledge or experience.
- The cost of training programs or hiring international specialists exceeds the allocated budget.

##### Tripwires
- Skills assessments reveal >= 3 key crew members lack required expertise.
- Training costs exceed 10% of the crew budget.
- Hiring international specialists increases labor costs by >= 15%.

##### Response Playbook
- Contain: Immediately halt all production activities that rely on the deficient skills.
- Assess: Conduct a thorough evaluation of the crew's capabilities and identify specific training needs.
- Respond: Implement intensive training programs, hire experienced mentors, or, as a last resort, replace underperforming crew members with qualified professionals.


**STOP RULE:** The cost of addressing the crew's skill deficiencies exceeds 20% of the total production budget, or the film's technical quality is deemed unacceptable by the director and producers.

---

#### FM8 - The Festival Freeze-Out

- **Archetype**: Market/Human
- **Root Cause**: Assumption A8
- **Owner**: Publicity Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The film's marketing strategy hinges on securing a premiere at a prestigious international film festival to generate buzz and critical acclaim. If the film is rejected by major festivals due to uninspired themes, poor execution, or lack of originality, its marketability plummets. The film struggles to attract distributors, and its box office potential is severely limited. The lack of festival recognition undermines the film's credibility and reduces audience interest.

##### Early Warning Signs
- The film receives negative feedback from film festival consultants.
- The film is rejected by several target film festivals.
- The film fails to generate positive buzz or media attention during the submission process.

##### Tripwires
- Rejection from >= 3 target film festivals (Toronto, Venice, Busan).
- Film festival consultant feedback scores <= 50% positive.
- Lack of media coverage or social media buzz surrounding festival submissions.

##### Response Playbook
- Contain: Immediately halt all marketing efforts that rely on film festival recognition.
- Assess: Conduct a thorough review of the film's themes, narrative structure, and overall quality to identify potential weaknesses.
- Respond: Re-edit the film to address festival concerns, re-focus marketing efforts on alternative selling points, or significantly scale down the project's scope to target a niche audience.


**STOP RULE:** The film is rejected by all target film festivals, and alternative marketing strategies are deemed unlikely to generate sufficient audience interest.

---

#### FM9 - The Political Peril

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Production Manager
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The film's production is disrupted by unforeseen political instability in Hong Kong. Increased censorship, protests, or government interference lead to permit revocations, location closures, and safety concerns for the cast and crew. Production grinds to a halt, resulting in significant delays and cost overruns. The film's content is censored, compromising its artistic integrity and limiting its market reach. The project faces potential cancellation due to escalating risks and financial losses.

##### Early Warning Signs
- Increased political tensions or public demonstrations near filming locations.
- Government authorities impose new restrictions on film production or freedom of expression.
- The production team receives credible threats of violence or disruption.

##### Tripwires
- Filming permits are revoked for >= 2 key locations due to political reasons.
- The production team receives credible threats of violence or disruption.
- The Hong Kong government imposes new censorship restrictions that significantly alter the film's content.

##### Response Playbook
- Contain: Immediately suspend all production activities and evacuate the cast and crew to a safe location.
- Assess: Conduct a thorough risk assessment to determine the severity of the political situation and its potential impact on the project.
- Respond: Relocate production to an alternative location outside of Hong Kong, significantly revise the script to minimize political sensitivities, or, as a last resort, cancel the project.


**STOP RULE:** The political situation in Hong Kong renders continued film production unsafe or impossible, and alternative production locations are deemed unsuitable or unavailable.
