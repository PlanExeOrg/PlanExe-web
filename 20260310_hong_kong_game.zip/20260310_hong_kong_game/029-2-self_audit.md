Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 14 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 5 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project is a remake of a thriller set in Hong Kong, and while it involves technology, it does not require any impossible physics.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (remake) + market (global) + tech/process (hybrid distribution) + policy (Hong Kong setting) without independent evidence at comparable scale. There is no credible precedent for this specific system combination.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Project Lead / Deliverable: Validation Report / Date: 90 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks definitions with business-level mechanisms-of-action, owners, and measurable outcomes for key strategic concepts like "Architectural Deconstruction", "Reality Distortion Techniques", and "Cultural Integration Depth".

**Mitigation**: Project Lead: Create one-pagers for each strategic concept, defining inputs→process→customer value, owners, measurable outcomes, value hypotheses, success metrics, and decision hooks. Due Date: 30 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because while the plan identifies several risks (regulatory, security, financial), it doesn't explicitly analyze cascades or provide a register with owners/controls for all hazard classes. The risk register is present, but cascade analysis is not.

**Mitigation**: Risk Manager: Expand the risk register to include second-order risks and map potential risk cascades. Add owners, controls, and a dated review cadence. Due: 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions obtaining permits but lacks a comprehensive matrix detailing required permits, lead times, and dependencies. Without this, timeline realism cannot be assessed.

**Mitigation**: Production Manager: Create a permit/approval matrix detailing all required permits, typical lead times in Hong Kong, and dependencies. Due: 30 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions securing financing but lacks specifics on sources, draw schedule, and covenants. There is no dated financing plan listing sources/status, draw schedule, and covenants. Runway length is undefined.

**Mitigation**: CFO: Develop a dated financing plan listing funding sources and their status (e.g., LOI, term sheet, closed), draw schedule, covenants, and runway length. Due: 60 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of HK$470 million (approximately US$60 million) lacks substantiation via benchmarks or vendor quotes normalized by area. The plan mentions filming locations but omits cost per m²/ft².

**Mitigation**: CFO: Benchmark costs (≥3) for similar film productions in Hong Kong, normalize per area (m²/ft²), obtain vendor quotes, and adjust the budget or de-scope. Due: 60 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions a target theatrical gross (HK$940 million–HK$1.7 billion) but lacks a range, confidence interval, or alternative scenarios. There is no sensitivity analysis or best/worst/base-case scenario analysis for this critical projection.

**Mitigation**: CFO: Conduct a sensitivity analysis and create best/worst/base-case scenarios for the target theatrical gross, including key assumptions and drivers. Due: 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for build-critical components. There are no technical specs, interface definitions, test plans, or integration maps. "The plan mentions filming locations but omits cost per m²/ft²."

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components. Due: 90 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes several critical claims without providing verifiable evidence. For example, it states, "The Hong Kong Film Development Fund provides financial incentives for film productions" but lacks a link to the fund's website or documentation.

**Mitigation**: Project Manager: Compile an evidence pack containing verifiable artifacts (documents, links, IDs) for all critical legal, contract, and operational claims. Due: 30 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "Define Project Deliverables and Acceptance Criteria" but lacks specific, verifiable qualities for the final film. The abstract deliverable is 'the film'.

**Mitigation**: Project Lead: Define SMART criteria for the completed film, including a KPI for audience rating (e.g., 4.0/5.0 on IMDb) by EOM.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes the 'Lead Actor Profile' decision, which adds significant cost without demonstrably supporting the project's primary goals of marketability and budget management.

**Mitigation**: Project Team: Conduct a Benefit Case Review for the lead actor choice, justifying its inclusion with a KPI, owner, and estimated cost, or move to the backlog within 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies the need for a Director but lacks a detailed rationale for this role. The plan mentions the *type* of director needed but doesn't include a role dedicated to the Director as a team member.

**Mitigation**: HR: Add a 'Director' role to the team composition, specifying contract type, activities, background, and resource needs within 30 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan acknowledges regulatory and permitting challenges but lacks a regulatory matrix mapping authorities, artifacts, lead times, and predecessors. "Apply for all necessary filming permits and licenses."

**Mitigation**: Production Manager: Develop a regulatory matrix detailing authorities, required artifacts, lead times, predecessors, and NO-GO criteria. Due: 60 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because sustainability concerns exist but can be addressed with planning. The plan lacks a detailed operational sustainability plan, including funding/resource strategy, maintenance schedule, succession planning, technology roadmap, or adaptation mechanisms.

**Mitigation**: Project Lead: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms. Due: 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because while the plan mentions engaging local counsel and building relationships, it lacks a fatal-flaw screen with authorities. There is no evidence of written confirmation from authorities regarding zoning, occupancy, fire load, etc.

**Mitigation**: Legal Team: Conduct a fatal-flaw screen with Hong Kong authorities regarding zoning, occupancy, fire load, etc., and seek written confirmation where feasible within 60 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions hiring security and coordinating with police, but lacks evidence of SLAs with vendors or tested failover plans. There is no evidence of secondary suppliers or paths.

**Mitigation**: Production Manager: Secure SLAs with key vendors, add a secondary supplier/path for critical dependencies, and test failover procedures by EOM.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Finance Department is incentivized by budget adherence, while the Creative Team is incentivized by artistic vision, creating a conflict over experimental spending. The plan does not address this conflict.

**Mitigation**: Project Lead: Create a shared OKR that aligns Finance and Creative on a measurable outcome (e.g., audience engagement) to balance budget and artistic goals by EOM.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Lead: Add a monthly review with KPI dashboard, owners, and a lightweight change board with thresholds for re-planning/stopping. Due: 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies several high risks (IP rights, remake differentiation, political landscape) but lacks a cross-impact analysis or bow-tie diagram to show how these risks interact. For example, failure to secure IP rights would halt the project.

**Mitigation**: Risk Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Due: 60 days.