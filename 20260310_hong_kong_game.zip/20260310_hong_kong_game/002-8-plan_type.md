This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** This plan *unequivocally requires* physical locations, actors, film crew, and equipment in Hong Kong. The entire premise revolves around filming in a specific physical environment. The plan also requires physical distribution of the film.