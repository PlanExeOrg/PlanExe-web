This plan involves money.

## Currencies

- **HKD:** Local currency for Hong Kong production expenses, crew, location fees, and local talent.
- **USD:** Used for budgeting, reporting, international talent, and potential international distribution deals.

**Primary currency:** USD

**Currency strategy:** While HKD will be used for local transactions, USD is recommended for budgeting and reporting to mitigate risks from currency fluctuations. Given the significant budget, USD is the primary currency.