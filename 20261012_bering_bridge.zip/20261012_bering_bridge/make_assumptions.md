
## Question 1 - What total CAPEX envelope, contingency level, and committed funding sources are available for the gated tunnel-first phase, and how much capital is released at each gate?

**Assumptions:** Assumption: Phase-1 tunnel-first CAPEX is $80-120 billion USD (estimate from risk file; detailed model pending), with a 12-15% contingency pool (proposed) and USD as primary currency. Governments contribute land, rights-of-way and guarantees; a third-country consortium supplies debt and equity. Early capital is limited to surveys and design (estimated $50-150 million before ratification).

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluates affordability and bankability of staged funding.
Details: Gating caps stranded cost at roughly $50-150 million (estimate) before treaty ratification. Overrun exposure is 10-30% of baseline ($10-30 billion, estimate). Mitigation: parametric cost model by Month 3, 12-15% contingency, utility take-or-pay pre-sales for 30-50% of revenue (proposed). Opportunity: fiber and power leases give early cash flow. Key risk: no lender is yet engaged; heads of terms targeted by Month 9 (2027-07-12).

## Question 2 - What are the critical-path milestones and decision gates, and how does the 2026-2041 window absorb treaty, licensing, survey and financial-close lead times?

**Assumptions:** Assumption: Months 0-12 (2026-10-12 to 2027-10-12) cover baseline surveys, Indigenous agreements and financing roadmap; gates fall at Months 6, 12, 18 and 24 (2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12). Design freeze occurs near Month 18 (2028-04-12) after 12-18 months of monitoring. Construction starts only after ratification, licensing and financial close, likely beyond Month 24 (2028-10-12). Full road-and-span phase extends past Month 180 (2041-10-12).

**Assessments:** Title: Schedule Feasibility Assessment
Description: Tests whether the timeline is realistic given gating dependencies.
Details: Ratification slip of 12-36 months (estimate) is the dominant schedule risk. Observational design needs at least one full ice season, so Month 18 (2028-04-12) is the earliest credible freeze. Tunnel element fabrication and tow rely on short open-water windows; one lost season delays by about 12 months. Mitigation: parallel domestic permitting, pilot element trial at Months 9-12 (2027-07-12 to 2027-10-12), schedule float of 6-12 months. Treat the 2041 date as a target for phase 1, not for the full hybrid.

## Question 3 - What core team, specialist contractors, vessels and workforce are needed, and where will they be sourced given sanctions and Arctic remoteness?

**Assumptions:** Assumption: A core team of 100-150 specialists (proposed) on multi-year contracts, an owner's engineer integrator, at least two fabrication yards, and 4-6 ice-class tow vessels (proposed). Labor is drawn from Alaska, Chukotka and third countries, with an Arctic labor premium of 30-50% (proposed). Fabrication occurs in Pacific yards in non-sanctioned jurisdictions.

**Assessments:** Title: Resource Adequacy Assessment
Description: Assesses availability of skilled labor, yards and fleet.
Details: Few yards have Arctic immersed-tube experience; dual-sourcing reduces single-point failure. Turnover of 30-50% annually (estimate) cuts productivity 20-40%. Mitigation: apprenticeships with regional schools, high-standard camps, SOPs and e-learning, multi-year vessel charters. Visa bottlenecks could cost $10-30 million per month (estimate); negotiate binational work-permit protocol by Month 12 (2027-10-12). Opportunity: local hire builds social licence.

## Question 4 - Which legal vehicle, treaty or concession instruments, and permit pathways (NEPA, Russian EIA, sanctions licensing) will govern ownership, liability and disputes at the maritime boundary?

**Assumptions:** Assumption: A neutral special-purpose entity chartered in a third country or under an international regime holds ownership; both governments hold contractual rights. A framework agreement, not a full treaty, is sought first. OFAC and export-control guidance is sought by Month 6 (2027-04-12). Permits are tiered: framework permits Months 6-9 (2027-04-12 to 2027-07-12), detailed marine permits Months 12-18 (2027-10-12 to 2028-04-12). A neutral arbiter resolves operational deadlocks.

**Assessments:** Title: Governance and Regulatory Assessment
Description: Evaluates legal viability and approval pathways.
Details: A neutral entity reduces ratification veto risk but leaves a permanent seam for liability, customs and closure authority; define command and toll rules up front. Sanctions licensing is the gating uncertainty; unlicensed structures are unbankable. Permitting delay of 18-24 months (estimate) is plausible. Mitigation: early regulator engagement, export-control counsel, force-majeure and supplier-substitution clauses, paid pause and exit at each gate.

## Question 5 - Which design load cases, safety standards and emergency doctrine apply to ice, seismic, permafrost, tunnel fire and winter closure, and who has command authority in an incident?

**Assumptions:** Assumption: Observational design with probabilistic return periods (50, 100 and 500 years, proposed), sacrificial ice deflectors, and 10-20% foundation reserve capacity (proposed). Staffed rescue stations at both shores, cross-passages every 500-1000 m (proposed), and pre-agreed closure triggers (proposed thresholds). A binational incident command centre operates under a single safety code.

**Assessments:** Title: Safety and Risk Assessment
Description: Evaluates technical and life-safety exposure.
Details: Highest risks: ice loads exceeding historic records, seismic-permafrost interaction, tunnel fire with delayed rescue. Over-design could add $5-15 billion (estimate); under-design risks repairs of $50-200 million per incident (estimate). Mitigation: 12-18 month monitoring, pier prototypes, independent design review, quarterly joint drills, structural-health monitoring. Gate foundation commitment on data adequacy; do not freeze design by calendar alone.

## Question 6 - What environmental baselines, marine mammal limits, carbon targets and climate-adaptation measures will be applied, and how will compliance be monitored?

**Assumptions:** Assumption: Baseline marine mammal, fisheries and ground-temperature surveys run Months 0-12 (2026-10-12 to 2027-10-12) with Indigenous co-leads. Low-noise methods (vibratory, bubble curtains) and real-time acoustic monitoring with shutdown zones apply. Design assumes 2-4 °C warming over the design life (proposed). Shore facilities sit 2-3 m above current high tide (proposed). A carbon accounting baseline is set before procurement.

**Assessments:** Title: Environmental Impact Assessment
Description: Evaluates ecological, permitting and climate exposure.
Details: Strait is a migration corridor for bowhead, beluga and walrus; stop-work orders of 3-6 months (estimate) are plausible. Dynamic monitoring flexes windows but creates unpredictable idle time contractors will price. Mitigation: fixed core calendar plus monitored adjustments, exclusion zones, subsistence protection fund. Permafrost thaw of 0.5-2.0 m (estimate) drives thermosyphons and adjustable bearings. Prefabrication reduces Arctic footprint but adds tow emissions.

## Question 7 - Which Indigenous communities, agencies, investors and research bodies must be engaged, with what consent authority, and in what sequence before permitting milestones?

**Assumptions:** Assumption: Stakeholder mapping completes by Month 1 (2026-11-12); a Beringia Indigenous Council forms by Months 3-6 (2027-01-12 to 2027-04-12) with binding advisory authority over alignment, work windows and mitigation. Consent agreements are signed by Month 12 (2027-10-12). A benefit fund of 1-2% of revenue or $10-30 million per year (proposed) is created. US DOT, Russian Ministry of Transport, lenders and research institutions join advisory bodies.

**Assessments:** Title: Stakeholder Engagement Assessment
Description: Evaluates legitimacy and litigation exposure.
Details: Unresolved consent could cause 6-18 month injunctions and $5-15 million legal cost (estimate). Differing US and Russian rights frameworks require dual-documented agreements. Mitigation: funded community legal and technical advisors, Indigenous-led baselines, local hire targets, observers on all marine works. Binding veto authority over work windows creates unpriceable schedule risk; define scope of consent clearly. Opportunity: visible legitimacy milestone for both governments.

## Question 8 - What operating model, border and customs process, toll and utility systems, and maintenance regime will run the link, and what availability is targeted?

**Assumptions:** Assumption: Phase 1 carries rail and utilities (fiber, power) in segregated galleries, excluding pressurized hydrocarbon pipelines. Customs and immigration are processed at shore plazas with sealed-transit freight. An operations authority runs 24/7 with automated monitoring, drones and ROVs. An O&M reserve of 12-15% of revenue (proposed) and indexed tolls support long-term upkeep.

**Assessments:** Title: Operational Systems Assessment
Description: Evaluates operability, throughput and lifecycle cost.
Details: Arctic O&M may reach 15-25% of revenue (estimate) versus 5-10% for temperate bridges. Shore-based inspection avoids a mid-strait border facility but requires sealed-transit trust between governments. Mitigation: automation, structural-health monitoring, early O&M model by Month 12 (2027-10-12), indexed tolls, staffing pipeline. Traffic shortfall of 20-50% (estimate) is covered by debt sized to 70% of conservative-case revenue and take-or-pay contracts.