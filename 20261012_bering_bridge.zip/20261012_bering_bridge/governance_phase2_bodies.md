### 1. Project Steering Committee

**Rationale for Inclusion:** This binational, 85 km Arctic megaproject with USD 115 billion funding, 15-year horizon, geopolitical risk and cross-jurisdictional delivery requires executive-level strategic oversight. The Steering Committee provides high-level direction on political gating, financing, treaty negotiation, Indigenous engagement and strategic risk management—decisions exceeding operational authority and requiring sovereign-level coordination. Monthly meetings ensure alignment across the neutral SPV owner, both governments and lead lenders during critical phases (Months 0–24 = 2026-10-12 to 2028-10-12).

**Responsibilities:**

- Approve gate-clearance criteria and decisions at Months 6, 12, 18, 24 (2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12)
- Oversee treaty negotiation, framework agreement and sanctions-licensing pathway; coordinate US and Russian government engagement
- Approve financing structure, lender terms and debt covenants; monitor debt service coverage and financial performance
- Monitor strategic risks (political tension, sanctions escalation, ratification slip) and authorize mitigation or exit provisions
- Review and approve Indigenous consent agreements, benefit-fund allocation and cultural-impact mitigation programs
- Endorse design envelope (ice load, seismic, permafrost assumptions) and approve design-freeze gates based on data adequacy
- Authorize capital deployment and contingency releases; escalate cost overruns >5% for repricing or gate deferral

**Initial Setup Actions:**

- Charter the neutral third-country SPV and establish bylaws specifying voting, decision authority and reporting (Month 0 = 2026-10-12)
- Negotiate and execute Steering Committee charter with explicit authority matrix, meeting cadence, quorum and escalation protocols (Months 0–3 = 2026-10-12 to 2027-01-12)
- Identify and appoint chair (proposed: neutral party, not aligned with either government) and define vice-chair roles for US, Russian and lender representation
- Establish gate-clearance checklist and pass/fail criteria for each of the four gates (Months 0–3 = 2026-10-12 to 2027-01-12)
- Define escalation path to diplomatic or arbitration channels if Steering Committee decisions deadlock (Months 0–3 = 2026-10-12 to 2027-01-12)
- Schedule and publish gate-review calendar (Months 6, 12, 18, 24 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12) and define gate-decision timeline (typically 2–4 weeks for review and 1 week for final decision)

**Membership:**

- Chair: Neutral independent (e.g., retired senior infrastructure executive or diplomat)
- SPV shareholder representative(s): nominee from neutral entity's board
- US government representative: US Department of Transportation or equivalent senior official
- Russian government representative: Russian Ministry of Transport or equivalent senior official
- Lead lender representative(s): 2–3 heads of arranging development banks or infrastructure investors (rotating quarterly or fixed term)
- Independent technical advisor (observing, non-voting): nominated by lender consortium or bridge engineering society to flag technical risks

**Decision Rights:** Steering Committee approves all gate-clearance decisions (Months 6, 12, 18, 24 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12) on criteria documented in the gate-clearance checklist. It approves financing terms, debt covenants and capital deployment authority. It endorses strategic decisions on design envelope, Indigenous benefit agreements and political gating strategy. Decisions requiring two-government consensus (treaty, framework agreement, sanctions licensing pathway) are escalated to diplomatic channels if Steering Committee deadlocks after two meetings on the same issue.

**Decision Mechanism:** Consensus preferred. If consensus fails on a gate-clearance decision or strategic choice, a simple majority vote (>50% of voting members) decides, with the abstention rule: abstention counts as absent, not as dissent. Tie-breaker: if voting members split 2–2 (US + Russia vs. lenders + neutral), the neutral chair casts a tie-breaking vote in favor of most recent motion unless reversing an earlier gate-clearance decision (which requires majority re-vote to overturn). Two-government consensus required for decisions affecting treaty or concession terms; if either government votes no, escalate to diplomatic channels within 2 weeks for resolution or exit.

**Meeting Cadence:** Monthly during Months 0–24 (2026-10-12 to 2028-10-12) (critical phases: pre-gate planning and gate-clearance reviews). Bi-monthly during Months 25–60 (2028-11-12 to 2031-10-12) (construction mobilization phase). Quarterly during Months 60–180 (2031-10-12 to 2041-10-12) (operations and Phase 2 planning). Emergency meetings may be called within 48 hours if a force-majeure or covenant-breach event occurs.

**Typical Agenda Items:**

- Gate-readiness status and clearance-criteria checklist (all meetings; formal vote at gate months)
- Financing update: lender engagement status, term negotiations, debt service coverage, covenant compliance
- Political and regulatory status: treaty/framework progress, OFAC/export-control licensing, permit milestones, Indigenous consent
- Strategic risks: geopolitical developments, sanctions escalation, Indigenous disputes, cost trends and schedule variance
- Design envelope review: ice/seismic/permafrost monitoring data summary, design-freeze adequacy assessment
- Contingency and budget status: cost overruns, change-order log, contingency remaining, repricing triggers

**Escalation Path:** Steering Committee deadlock on gate-clearance decisions (two inconclusive meetings) or strategic choices requiring two-government consensus escalate to a Neutral Arbitration Panel (appointed Month 3 = 2027-01-12, comprising one arbiter each from US and Russia + one neutral international arbiter, with binding authority under a dispute-resolution clause). If arbitration deadlock on ratification or treaty matters, issue escalates to senior diplomatic channels (US State Department, Russian Foreign Ministry) with 2-week resolution window; if unresolved, triggers a paid pause and exit gate (Months 6, 12, 18, 24 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12 decision window).
### 2. Operations and Execution Council

**Rationale for Inclusion:** Operational and technical delivery—design, permitting, surveys, procurement, Indigenous engagement and construction planning—requires day-to-day coordination distinct from strategic oversight. The Operations and Execution Council manages design freeze, cost and schedule performance, interface control, contractor management and risk mitigation actions below Steering Committee thresholds. It operates under the Steering Committee's strategic authority and reports monthly on performance, alerts and escalations. Ensures consistency across design, logistics, safety and Indigenous consultation during the critical Months 0–30 (2026-10-12 to 2029-04-12) pre-construction phase and into delivery.

**Responsibilities:**

- Manage design development and design-freeze gate criteria; oversee ice-monitoring, seismic surveys and permafrost investigations supporting design adequacy (Months 0–18 = 2026-10-12 to 2028-04-12)
- Own cost and schedule baseline: manage Cost Basis Document, parametric estimates, contractor bids and change-control process; flag variance >5% for repricing
- Coordinate environmental and marine-mammal baseline surveys with Indigenous observers; track permit progress (framework Months 6–9 = 2027-04-12 to 2027-07-12, detailed Months 12–18 = 2027-10-12 to 2028-04-12)
- Manage interface-control documents between span, tunnel and island systems; chair monthly Interface Control Board (Months 6–60 = 2027-04-12 to 2031-10-12)
- Oversee Arctic construction logistics planning: fabrication yards, tow-vessel procurement, pilot element trial (Months 9–12 = 2027-07-12 to 2027-10-12) and seasonal-window analysis
- Coordinate Indigenous stakeholder engagement: support Beringia Council formation, fund baseline studies and document consent agreements (Months 0–12 = 2026-10-12 to 2027-10-12)
- Manage technical risk: ice-load and seismic-design contingencies, observational-design protocols, data-adequacy gates and design-refinement schedules

**Initial Setup Actions:**

- Appoint Owner's Engineer Integrator and Core Engineering Team (100–150 specialists, proposed) by Month 0 (2026-10-12); establish governance roles and approval matrices
- Develop and publish detailed project execution plan, including design schedule, permitting roadmap, Indigenous-engagement milestones and cost/schedule baseline (Months 0–3 = 2026-10-12 to 2027-01-12)
- Commission parametric cost model from Arctic-construction specialists (Month 3 = 2027-01-12); establish Cost Basis Document and publish for contractor feedback by Month 6 (2027-04-12)
- Establish Interface Control Board charter and monthly meeting cadence; define interface-control document approval process and design-change authority (Months 3–6 = 2027-01-12 to 2027-04-12)
- Launch ice, seismic and permafrost monitoring instrumentation and geotechnical drilling (Month 0 = 2026-10-12); establish data-collection and analysis protocols with independent verification by Month 3 (2027-01-12)
- Coordinate Indigenous stakeholder mapping (Month 1 = 2026-11-12) and fund community legal/technical advisors; establish Beringia Council formation schedule (Months 3–6 = 2027-01-12 to 2027-04-12)

**Membership:**

- Owner's Engineer/Integrator: senior engineer with Arctic and megaproject experience (full-time lead, voting)
- Cost Engineer: manages parametric estimates, change control and budget tracking (full-time, voting)
- Design Lead (Bridge and Tunnel): senior structural and immersed-tunnel engineer (full-time, voting)
- Environmental and Permitting Lead: coordinates EIS/EIA, marine-mammal baseline and regulatory compliance (full-time, voting)
- Indigenous Stakeholder Lead: funds and coordinates Beringia Council, benefit programs and consent agreements (full-time, voting)
- Construction Logistics Lead: Arctic fabrication yards, tow-vessel procurement and supply-chain risk (full-time, voting)
- Finance and Commercial Manager: debt covenants, take-or-pay contracts, revenue forecasting and lender reporting (part-time, voting)
- Representatives from US and Russian government agencies (observing, non-voting input)

**Decision Rights:** Operations Council approves design refinements and parametric-cost updates that do not exceed pre-approved contingency thresholds (decisions within 5% cost variance require internal approval; >5% variance escalates to Steering Committee). It approves change orders up to USD 10 million (proposed threshold); changes >USD 10 million or schedule slip >2 months escalate to Steering Committee. It approves interface-control documents and contractor procurement recommendations up to pre-qualified baseline; deviation from baseline suppliers requires Steering Committee approval (sanctions or export-control impact). Design-freeze decisions are made by Operations Council if ice/seismic data confidence is within +/-15% (proposed threshold); if confidence is wider, design freeze is deferred and escalated to Steering Committee for gate postponement decision.

**Decision Mechanism:** Consensus among voting members preferred. If consensus fails, a simple majority (>50%) decides. Specific decision subjects have tie-breakers: (1) Design-freeze adequacy: Owner's Engineer Integrator casts tie-breaking vote if tied. (2) Cost or schedule variance: Finance Manager's reforecast is the tie-breaker. (3) Interface conflicts: neutral external arbiter (appointed Month 6 = 2027-04-12, an experienced megaproject integrator) mediates and decides within 2 weeks if Operations Council cannot resolve. Design-freeze deferred if Owner's Engineer Integrator votes no on data adequacy (veto on safety/engineering grounds).

**Meeting Cadence:** Weekly during Months 0–24 (2026-10-12 to 2028-10-12) (critical pre-construction and gate-clearance phase). Bi-weekly during Months 25–60 (2028-11-12 to 2031-10-12) (construction mobilization and early delivery). Monthly during Months 60–180 (2031-10-12 to 2041-10-12) (construction and operations phase). Ad-hoc meetings on cost >5% variance, schedule slip >2 months or safety/permitting alerts.

**Typical Agenda Items:**

- Cost and schedule performance: variance analysis, change-order log, contingency status, bid evaluations and repricing triggers
- Design development: ice/seismic/permafrost monitoring-data summary, design-refinement progress, design-freeze readiness assessment
- Permitting and environmental: baseline survey progress, regulatory feedback, permit application status, marine-mammal monitoring and incident log
- Interface-control and contractor coordination: ICB decision log, unresolved interface conflicts, supplier pre-qualification and long-lead procurement status
- Indigenous engagement: Beringia Council formation progress, consent-agreement negotiations, baseline-study co-authoring and benefit-fund design
- Arctic logistics: fabrication-yard pre-qualification, tow-vessel procurement, pilot-element trial schedule and supply-chain risk alerts

**Escalation Path:** Operations Council deadlock on design-freeze decisions or interface conflicts escalates to the neutral external arbiter (independent megaproject engineer with binding authority, appointed Month 6 = 2027-04-12) for decision within 2 weeks. Cost or schedule variance >5% or change orders >USD 10 million escalate to Steering Committee within 1 week. Permitting or Indigenous-consent delays >3 months escalate to Steering Committee for policy review or gate deferral. Safety or technical-adequacy concerns raised by Owner's Engineer Integrator trigger immediate escalation to Steering Committee and an external independent design review (Months 12–15 = 2027-10-12 to 2028-01-12) within 2 weeks.
### 3. Technical Advisory Group

**Rationale for Inclusion:** This Arctic megaproject faces unprecedented technical unknowns: ice-floe loads, seismic-permafrost interaction, immersed-tube tunnel innovation in Arctic conditions, and observational design dependent on 12–18 months of sparse monitoring data. The Technical Advisory Group provides independent specialized input on load assumptions, design adequacy and safety margins—separating expert assessment from operational delivery and political pressure. Members include world-class ice mechanics, seismic engineers, tunnel specialists and Arctic construction experts from research institutions and peer projects, meeting quarterly during design phases (Months 0–18 = 2026-10-12 to 2028-04-12) and semi-annually during construction.

**Responsibilities:**

- Review and validate ice-monitoring data, ice-load models and design assumptions at Months 9, 15, 21 (2027-07-12, 2028-01-12, 2028-07-12); certify data quality and confidence levels for design-freeze gates
- Conduct independent design review of suspension-bridge towers, cables and immersed-tunnel elements (Months 12–15 = 2027-10-12 to 2028-01-12); identify safety, constructability and long-term durability risks
- Assess seismic hazard analysis, ground-response modeling and permafrost-thaw scenarios; recommend design contingencies and monitoring protocols (Months 6–12 = 2027-04-12 to 2027-10-12)
- Review Arctic construction methods (vibratory vs. impact piling, bubble-curtain acoustics, thermal-stabilization techniques); advise on technical feasibility and compliance with marine-mammal limits
- Validate pilot-element trial results and immersed-tube-tunnel installation procedures (Months 9–12 = 2027-07-12 to 2027-10-12); recommend design or process refinements before full-scale production
- Provide objective assessment of design-envelope trade-offs (deterministic vs. observational, conservative vs. performance-based); advise Steering Committee on safety margin and cost-risk balance

**Initial Setup Actions:**

- Recruit Technical Advisory Group chair: world-class ice or tunnel engineer (e.g., National Academy member with Arctic megaproject experience) by Month 0 (2026-10-12)
- Identify and invite 8–12 specialists (propose: 2–3 ice mechanics experts, 2 seismic/permafrost engineers, 2 immersed-tunnel designers, 2 Arctic construction specialists, 1–2 independent engineering-review firms) by Month 1 (2026-11-12)
- Execute engagement agreements and define confidentiality, conflict-of-interest vetting and fee structure by Month 3 (2027-01-12)
- Schedule quarterly review meetings (Months 3, 6, 9, 12, 15, 18 = 2027-01-12, 2027-04-12, 2027-07-12, 2027-10-12, 2028-01-12, 2028-04-12) and specify deliverables for each (interim letters, formal reports, gate-readiness certifications)
- Establish data-flow protocols: Operations Council provides raw monitoring data, design models and test results monthly; TAG reviews asynchronously and flags concerns at monthly internal calls before formal reviews
- Define escalation criteria: if TAG raises a Major Issue (safety concern, design-adequacy doubt, data-confidence shortfall), require Steering Committee notification within 5 business days

**Membership:**

- Chair: Independent world-class Arctic or tunnel engineer, non-aligned with contractors or government (voting, advisory authority)
- Ice Mechanics Expert(s): 2–3 specialists from universities or national laboratories with Arctic field experience and ice-load modeling expertise (e.g., University of Alaska, Canadian National Research Council)
- Seismic and Permafrost Engineer(s): 2 specialists in seismic hazard analysis, ground-response modeling and permafrost engineering for coastal and Arctic sites
- Immersed-Tunnel Specialist(s): 2 experienced designers or engineers from firms that have built immersed-tube tunnels (e.g., Danish, Dutch or Norwegian tunnel specialists) with deep-water or Arctic adaptation experience
- Arctic Construction Expert(s): 2 engineers with documented experience on Arctic pipeline, platform or infrastructure projects (supply-chain, marine logistics, seasonal-work optimization)
- Independent Design Review Firm (rotating): one external engineering-review organization (propose: HDR, Jacobs, Golder or peer) conducts independent verification at design-critical gates (Months 12–15 = 2027-10-12 to 2028-01-12)

**Decision Rights:** Technical Advisory Group does not make operational decisions; it provides expert advice and independent certification to the Operations Council and Steering Committee. It has authority to certify or withhold certification on: (1) design-freeze data adequacy (ice-load confidence within +/-15%, seismic-hazard confidence documented, permafrost-thaw models validated); (2) pilot-element trial success and readiness for production; (3) design safety margin and compliance with established codes. Withholding certification triggers escalation to Steering Committee for gate deferral or design refinement. TAG advice is non-binding but given significant weight in design-freeze and safety decisions.

**Decision Mechanism:** Consensus of TAG members preferred for certifications and formal opinions. If 2 or more members dissent on a major safety or adequacy issue, the dissent is documented in writing and escalated to Steering Committee regardless of overall TAG consensus. Chair may issue an interim letter of concern to Operations Council within 1 week of identifying a Major Issue (design uncertainty, data delay, safety question); formal letter with TAG consensus follows within 2–3 weeks. Disagreement among TAG members on technical approaches (e.g., deterministic vs. probabilistic design) is documented as professional difference and presented to Steering Committee for policy direction rather than resolved by vote.

**Meeting Cadence:** Quarterly formal meetings (Months 3, 6, 9, 12, 15, 18 = 2027-01-12, 2027-04-12, 2027-07-12, 2027-10-12, 2028-01-12, 2028-04-12) during design and pre-construction phases (Months 0–24 = 2026-10-12 to 2028-10-12). Semi-annual meetings (Months 30, 42, 54, 66 = 2029-04-12, 2030-04-12, 2031-04-12, 2032-04-12) during construction. Monthly conference calls for data-quality checks and interim issue flagging (Months 0–24 = 2026-10-12 to 2028-10-12). Emergency meeting if a Major Issue is raised (within 5 business days).

**Typical Agenda Items:**

- Ice-load monitoring data quality, statistical analysis and load-model calibration; ice-load design assumptions for towers and piers
- Seismic hazard update, ground-response modeling and permafrost-thaw scenario analysis; design-envelope recommendations
- Design-freeze readiness assessment: data confidence, design-adequacy certification and go/no-go recommendation
- Pilot-element trial results and immersed-tube-tunnel installation procedure validation; readiness for full-scale production
- Independent design-review findings (Months 12–15 = 2027-10-12 to 2028-01-12): tower, cable, tunnel and foundation design safety and constructability assessment
- Issue tracking: Major Issues raised, status and resolution by next formal meeting

**Escalation Path:** TAG Major Issue (design uncertainty, safety concern, data-adequacy shortfall) escalates to Operations Council within 5 business days via written interim letter from TAG chair. If Operations Council cannot resolve within 2 weeks, escalate to Steering Committee for decision on design refinement, gate deferral or additional investigation (e.g., extended monitoring, prototype testing). If TAG withholds design-freeze certification due to data gaps or safety concerns, design freeze is automatically deferred and escalates to Steering Committee with recommendation for deferral duration (propose: 3–6 months extended monitoring, or pilot test, or design refinement). TAG consensus on a Major Issue must be documented in the gate-clearance record and disclosed to lenders and regulators.
### 4. Indigenous Stakeholder and Compliance Council

**Rationale for Inclusion:** The project traverses Inupiat, Yupik, Chukchi and Siberian Yupik traditional-use areas in Alaska and Russia, with subsistence harvesting, marine-mammal and fisheries rights. US law (NEPA, Marine Mammal Protection Act) requires Indigenous consultation; Russian protections are weaker but customary law claims exist. Unresolved Indigenous consent can trigger injunctions, 6–18 month litigation delays and costs of USD 5–20 million. The Indigenous Stakeholder and Compliance Council establishes binding advisory authority over alignment, seasonal work windows and mitigation; oversees consent-agreement negotiation; manages benefit-fund design; and coordinates marine-mammal and subsistence-protection programs. Essential for legitimacy, permitting, social license and operational continuity.

**Responsibilities:**

- Chair formation and governance of Beringia Indigenous Council (Months 3–6 = 2027-01-12 to 2027-04-12): represent each identified Indigenous community, with legal standing and funding; establish decision authority and dispute resolution
- Co-author marine-mammal and subsistence-baseline studies with Indigenous community researchers (Months 0–12 = 2026-10-12 to 2027-10-12); document traditional knowledge, harvesting patterns and environmental baselines
- Negotiate and execute formal consent agreements (MOUs, FCIAs) with each community (Months 6–12 = 2027-04-12 to 2027-10-12), specifying scope of binding authority, consent triggers and benefit-sharing
- Design and administer Community Benefit Fund: propose 1–2% of annual revenue or USD 10–30 million/yr; allocate to community-identified projects (training, infrastructure, monitoring, mitigation)
- Establish work-window restrictions and marine-mammal monitoring protocols with binding authority over seasonal access; document stop-work triggers and adaptive-management procedures
- Track Indigenous workforce hiring, training and local-hire targets (propose 20–30%, estimated); report quarterly to Steering Committee on progress and compliance with commitments
- Coordinate subsistence-protection programs: fund alternative harvesting areas, gear, training if traditional areas are impacted; maintain subsistence-impact log and incident-response protocols

**Initial Setup Actions:**

- Conduct Indigenous-stakeholder mapping by Month 1 (2026-11-12): identify all communities with traditional-use rights, regulatory authority or potential impact on alignment (Inupiat and Yupik in Alaska; Chukchi, Yupik and others in Russia)
- Engage each community through established governance structures (tribal councils, traditional-use boards) starting Month 1 (2026-11-12); establish initial consultation protocols and schedule (propose: quarterly meetings through Month 12 = 2027-10-12)
- Fund community legal and technical advisors (propose: USD 500,000–1 million/community through Month 12 = 2027-10-12, then ongoing through operations): enable independent review of consent agreements, EIS/EIA and benefit-fund design
- Co-sponsor baseline studies: secure Indigenous community researchers as co-authors (propose: 30–50% of study team) for marine-mammal surveys, fisheries assessments and traditional-use documentation (Months 0–12 = 2026-10-12 to 2027-10-12)
- Establish Beringia Indigenous Council legally and operationally (Months 3–6 = 2027-01-12 to 2027-04-12): charter with binding advisory authority, legal standing, funding (propose: USD 2–5 million setup + USD 1–2 million/yr operations), and dispute-resolution process
- Develop Community Benefit Fund governance framework: specify fund size (propose 1–2% of revenue or fixed USD 10–30 million/yr), allocation process, governance (joint operator/Council board), eligible projects and reporting (Months 6–9 = 2027-04-12 to 2027-07-12)

**Membership:**

- Council Chair: Neutral independent mediator or Indigenous elder from outside project region (non-voting facilitation role)
- Beringia Indigenous Council Representatives: delegates from each identified Indigenous community (8–12 members, voting); funded and legally empowered to act on behalf of community(ies)
- Project Compliance Lead: project-employed staff managing day-to-day Indigenous engagement, benefit-fund administration and work-window coordination (non-voting, reporting to Council and Operations Council)
- Community Legal and Technical Advisors: one per major community grouping (funded by project, independent of project control), advising communities on consent agreements, impact assessment and benefit programs

**Decision Rights:** Beringia Indigenous Council holds binding advisory authority over: (1) alignment siting and alternative routes (if Indigenous impact varies); (2) seasonal work windows and marine-mammal-protection measures; (3) major design changes affecting traditional-use areas or subsistence access; (4) Community Benefit Fund allocation (Council approves 60%+ of annual fund with project co-approval on financial controls). Council consent (>75% vote threshold) is a gating condition before design freeze (Month 18 = 2028-04-12) and before construction start (Month 24+ = 2028-10-12+). Council cannot veto overall project continuation but can trigger escalation to Steering Committee if alignment, timing or mitigation changes are demanded; Steering Committee arbitrates if cost or schedule impact is material (>USD 100 million, >6 months).

**Decision Mechanism:** Beringia Indigenous Council operates by consensus of member delegations where possible. Votes on consent, work-window restrictions and benefit allocation require >75% affirmative vote (e.g., 8 of 11 members). Tie or deadlock: neutral chair facilitates resolution through mediation; if unresolved within 2 weeks, issue escalates to project Steering Committee and legal counsel in both jurisdictions for interpretation of FPIC (free, prior and informed consent) standards and dispute resolution. Individual community veto on matters uniquely affecting only that community (alignment or harvesting area specific to one group) is recognized; project must negotiate alternative or defer to Steering Committee resolution.

**Meeting Cadence:** Beringia Indigenous Council holds monthly meetings during pre-construction phases (Months 0–24 = 2026-10-12 to 2028-10-12) for consent agreements, baseline studies and benefit-fund design. Quarterly during construction (Months 25–60 = 2028-11-12 to 2031-10-12) for work-window coordination and monitoring. Semi-annual or annual during operations (Months 60–180 = 2031-10-12 to 2041-10-12) for benefit-fund administration and subsistence-impact review. Emergency meetings within 1 week if a stop-work incident or significant impact is reported.

**Typical Agenda Items:**

- Baseline studies co-authoring and traditional-knowledge documentation: schedule, community researcher roles, data sharing
- Consent-agreement negotiation: legal review, scope of binding authority, FPIC validation and final signature
- Seasonal work-window approval: proposed access calendar, marine-mammal monitoring triggers, stop-work protocols and adaptive-management procedures
- Community Benefit Fund design and allocation: fund size confirmation, eligible projects, Council governance and annual reporting
- Indigenous workforce program: hiring targets (20–30%), training partnerships with regional schools, wage and benefits competitiveness
- Subsistence-protection program: alternative harvesting areas, incident log, impact assessments and mitigation updates

**Escalation Path:** Beringia Indigenous Council disputes over consent, work-window or alignment escalate to project Steering Committee and legal counsel (US and Russian) for FPIC interpretation and binding arbitration within 3–4 weeks. If Council withholds consent on material alignment or timing grounds, Steering Committee must either negotiate redesign/rescheduling or escalate to US and Russian governments for sovereign-level diplomatic resolution (political gating). Stop-work incidents or major subsistence impacts reported by Indigenous monitors trigger immediate escalation to Operations Council and Council chair within 24 hours; investigation and response plan within 1 week. Unresolved Indigenous consent dispute at design-freeze gate (Month 18 = 2028-04-12) defers design freeze and extends planning gate by 3–6 months (paid pause); unresolved at construction start (Month 24+ = 2028-10-12+) escalates to Steering Committee for go/no-go decision on project continuation.
### 5. Risk, Compliance and Insurance Committee

**Rationale for Inclusion:** This project faces existential risks across political (treaty ratification, sanctions), financial (USD 100 billion baseline, cost overrun to USD 30 billion, lender default risk), and technical (ice loads, seismic, permafrost) domains. Compliance requirements span two sovereign jurisdictions (US NEPA, Russian EIA), sanctions and export controls (OFAC, EAR/ITAR), Indigenous rights, environmental law and Arctic safety codes. The Risk, Compliance and Insurance Committee integrates risk identification, assessment and mitigation across all domains; ensures regulatory compliance and licensing (OFAC, export control); manages insurance and contingency planning; and monitors leading indicators (cost variance, schedule slip, covenant ratios, permitting delays, geopolitical events) that signal need for escalation or gating decisions. Critical for bankability and lender covenant compliance.

**Responsibilities:**

- Maintain and update comprehensive risk register (Months 0–180 = 2026-10-12 to 2041-10-12): ice load, seismic, permafrost, political gating, sanctions licensing, financing, Indigenous consent, marine-mammal impacts, labor, supply-chain, cost/schedule, governance and O&M risks; assign owners and mitigation actions
- Monitor leading risk indicators: cost variance >5%, schedule slip >2 months, debt service coverage ratio <1.3x, OFAC licensing delays >3 months, permit milestones missed, Indigenous-consent disputes, geopolitical incidents (sanctions escalation, US-Russia tension)
- Manage regulatory compliance: maintain checklist of NEPA/EIA permit requirements, Indigenous-consultation milestones, marine-mammal authorization triggers, export-control vetting; verify timely submission and approval; escalate delays or denials
- Coordinate OFAC and export-control licensing: engage with US Treasury and State Department (Months 3–6 = 2027-01-12 to 2027-04-12); obtain written licensing pathway and pre-approved supplier list by Month 6 (2027-04-12); maintain compliance in procurement and financing
- Procure and manage project insurance: builder's risk, environmental liability, professional indemnity, contractor performance bonds and political-risk insurance (for sanctions and expropriation); ensure coverage aligns with lender requirements and risk profile (Months 6–12 = 2027-04-12 to 2027-10-12 policy negotiation)
- Design contingency-planning protocols for force-majeure events: geopolitical break (government withdrawal), major ice/seismic damage, supply-chain failure, lender default; specify trigger thresholds, activation decision authority and resource mobilization (USD 10–50 million emergency reserves estimated)
- Prepare quarterly risk reporting to Steering Committee and lenders: risk-register summary, risk-indicator trends, emerging issues and recommended mitigation or gating actions

**Initial Setup Actions:**

- Establish Risk, Compliance and Insurance Committee governance and charter by Month 0 (2026-10-12); designate committee chair (senior compliance or risk professional) and define decision authority
- Commission comprehensive risk assessment from an Arctic/megaproject risk consultant (Months 0–3 = 2026-10-12 to 2027-01-12): identify project-specific risks (ice, seismic, permafrost, Arctic logistics, two-jurisdiction permitting, sanctions, Indigenous rights) and rank by likelihood and impact
- Develop risk register (Excel or database) with columns: risk ID, category, description, owner, current mitigation, residual risk, leading indicators, escalation threshold and trigger action (Month 3 = 2027-01-12); populate with 20–30 identified risks from risk assessment and planning documents
- Establish regulatory-compliance checklist: NEPA/EIA requirements, Indigenous-consultation triggers, marine-mammal authorizations, export-control and OFAC licensing steps, Arctic safety-code confirmations; assign each to responsible party and tracking milestone (Months 0–3 = 2026-10-12 to 2027-01-12)
- Engage OFAC and export-control counsel by Month 0 (2026-10-12); request written preliminary guidance on project financing structure and supplier sourcing by Month 3 (2027-01-12) and final licensing pathway by Month 6 (2027-04-12)
- Initiate insurance-broker engagement for builder's risk, environmental liability and political-risk policies (Month 3 = 2027-01-12); draft insurance specifications and coverage requirements by Month 6 (2027-04-12); procure policies by Month 12 (2027-10-12) before construction mobilization

**Membership:**

- Committee Chair: Senior compliance, risk or insurance professional, independent from operational delivery (non-voting facilitation or tie-breaking as needed)
- Risk and Insurance Manager: full-time dedicated role, managing risk register, leading-indicator tracking and insurance procurement and claims management
- Compliance Officer: dedicated to regulatory licensing (OFAC, export control, permits); liaison with US and Russian regulatory agencies; ensures timely compliance filings and authorizations
- Operations Council representative (observing, reporting to Operations Council): provides operations context on cost/schedule variance and emerging execution risks
- Steering Committee representative (observing): reports risk trends and escalation recommendations back to Steering Committee
- Insurance Broker/Advisor: external, specialized in large-project construction and political-risk insurance; advises on coverage adequacy and policy terms (non-voting, external advisor)

**Decision Rights:** Risk Committee identifies and classifies risks; owners and Operations Council decide mitigation actions (budget, schedule, resource allocation). Risk Committee escalates risks exceeding escalation thresholds to Steering Committee within 1 week of threshold breach: (1) cost variance >5% (USD 5 billion) or trend indicating final overrun >10% (USD 10 billion); (2) schedule slip >2 months or ratification delay projected >6 months beyond plan; (3) OFAC licensing pathway uncertain or pre-approved supplier list reduced by >20%; (4) debt service coverage ratio projected to fall <1.3x within 12 months; (5) major geopolitical incident affecting US-Russia relations or sanctions regime. Risk Committee has authority to freeze contingency-reserve release: if contingency drawdown is requested before gate clearance (Month 18 = 2028-04-12), Risk Committee chair may require Steering Committee approval (to prevent excessive contingency spend before design freeze). Insurance policies are approved by Risk Committee with lender sign-off.

**Decision Mechanism:** Risk Committee operates by consensus on risk classification, leading-indicator thresholds and escalation recommendations. If Risk Committee members disagree on severity or mitigation priority, the more conservative (higher-risk) assessment is escalated to Steering Committee. Escalation threshold decisions are made by Risk Committee chair with Steering Committee notification if disagreement arises on threshold level (e.g., if cost variance >5% should trigger escalation or if >7% is acceptable before escalation).

**Meeting Cadence:** Monthly during Months 0–24 (2026-10-12 to 2028-10-12) (pre-construction and gate-clearance phases). Bi-monthly during Months 25–60 (2028-11-12 to 2031-10-12) (construction mobilization). Quarterly during Months 60–180 (2031-10-12 to 2041-10-12) (construction and operations). Weekly monitoring of leading indicators (cost, schedule, covenant ratios, regulatory milestones) with alerts issued within 24 hours if threshold is approached.

**Typical Agenda Items:**

- Risk-register update: new risks identified, mitigation status for existing risks, closed risks and residual-risk trends
- Leading-indicator dashboard review: cost variance, schedule slip, debt service coverage, OFAC licensing progress, permit-approval status, Indigenous-consent milestones, geopolitical incident tracking
- Regulatory compliance status: NEPA/EIA submissions and approvals, export-control vetting, sanctions-licensing confirmation, permit applications and approvals, Indigenous-consultation checklist
- Insurance policies and coverage: builder's risk, environmental liability, professional indemnity, contractor performance bonds, political-risk insurance; claim updates and coverage adequacy assessment
- Escalation recommendations: identification of risks or indicators that have breached thresholds; recommendation for Steering Committee action (design refinement, gate deferral, contingency release, exit)
- Contingency planning: force-majeure scenario testing, resource mobilization plans, exit provisions and paid-pause protocols

**Escalation Path:** Risk Committee escalates to Steering Committee any risk threshold breach (cost >5%, schedule >2 months, DSCR <1.3x, OFAC delay >3 months, geopolitical incident) within 1 week of detection. Escalation package includes: (1) risk description and current status, (2) leading indicator data, (3) impact on project (cost, schedule, financing, permit timeline), (4) recommended mitigation (design change, schedule adjustment, contingency release, gate deferral) and (5) Resource or authorization needed from Steering Committee. If Risk Committee and Operations Council disagree on mitigation adequacy, issue escalates directly to Steering Committee. Major geopolitical incident (e.g., sanctions escalation, significant US-Russia diplomatic break) triggers emergency Steering Committee meeting within 48 hours; Risk Committee chair and Compliance Officer brief on immediate impact and trigger cascade (financing delay, supplier availability, personnel movement, project continuity).