
## Strengths 👍💪🦾
- Staged design: rail-and-utility immersed tunnel on foundations sized for later 2-3 km suspension spans and road lanes keeps the 85 km hybrid end state (user constraint) while limiting Phase 1 exposure.
- Gates at Months 6, 12, 18 and 24 (2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12) with 3-6 month paid pause and exit cap pre-gate spend at USD 150 million (proposed threshold).
- Neutral third-country SPV, framework agreement first and a third-country consortium reduce ratification veto and sanctions exposure.
- Observational design (50/100/500-year return periods, 10-20% foundation reserve, sacrificial ice deflectors) lets ice, seismic and permafrost data inform design freeze.
- Diomede Islands give rock foundations and a shallow central section suited to immersed tube and island foundations.
- Utility revenue (fiber, power) and 30-50% take-or-pay target give early cash flow less dependent on traffic forecasts.
- Comparable binational links (Fehmarnbelt, Oresund, HZMB) offer transferable treaty, financing and immersion lessons.

## Weaknesses 👎😱🪫⚠️
- No lenders engaged; USD 115 billion funding requirement (estimate) is unevidenced and no budget cap or cap-bearer is set.
- Revenue case unproven: no traffic forecast or tariff, yet about USD 8.9 billion/yr conservative revenue is needed to carry USD 69 billion debt (estimate). At USD 100/tonne this implies about 89 million tonnes/yr (estimate).
- Cost estimate is a USD 80-120 billion range without a parametric build-up; contingency of USD 15 billion may be exceeded by up to USD 15 billion (estimate).
- Installation arithmetic fails: about 9 elements per season needed versus 3-8 planned, so Month 180 (2041-10-12) is unachievable at a single spread (estimate).
- Method for the remaining 49-65 km of alignment is undecided (estimate), leaving the end-state link unspecified.
- Month 9-12 (2027-07-12 to 2027-10-12) pilot element trial is aggressive; failure costs about 12 months (estimate).
- Data thin on ice, permafrost and seismic response; design freeze at Month 18 (2028-04-12) depends on one full ice season.

## Opportunities 🌈🌐
- Early confidence-building works (fiber cable, shared geotechnical survey, joint research station) can demonstrate cooperation before major capital is committed.
- Third-country development banks, export-credit agencies and infrastructure funds may back a licensed, ring-fenced structure; written OFAC guidance by Month 6 (2027-04-12) would unlock them.
- Indigenous-led monitoring, benefit fund (1-2% of revenue or USD 10-30 million/yr, proposed) and 20-30% local hire (proposed) can build social licence and a legitimacy milestone for both governments.
- Take-or-pay pre-sales of fiber, power and rail capacity could anchor debt sizing and reduce traffic-forecast dependence.
- Lessons from Fehmarnbelt factory production and HZMB island interfaces can reduce immersion and interface risk; a second spread or yard could close the installation-rate gap.
- Arctic research collaboration and ice-mechanics partnerships with Alaskan, Canadian and Norwegian institutes add credibility and data.

## Threats ☠️🛑🚨☢︎💩☣︎
- Treaty or framework ratification slip of 12-36 months (estimate), or unilateral withdrawal by one government, strands sunk cost.
- Sanctions and export-control tightening may restrict lenders, suppliers and personnel; sourcing premium of 5-10% and financing cost +100-200 bps (estimate).
- Overruns of USD 10-30 billion (estimate) and DSCR falling below 1.2x trigger covenant breach.
- Indigenous consent disputes can cause injunctions of 6-18 months; marine mammal stop-work orders of 3-6 months (estimate).
- One lost open-water season costs about 12 months (estimate); few yards have Arctic immersed-tube experience.
- Ice regime and permafrost thaw may exceed historical records, causing under- or over-design (USD 50-200 million repairs per incident versus USD 5-15 billion over-design, estimate).
- Labor turnover of 30-50% and visa bottlenecks of USD 10-30 million per month (estimate).
- Governance deadlock at the maritime seam over closure, tolls and incident command.

## Recommendations 💡✅
- Month 0-1 (2026-10-12 to 2026-11-12): Sponsor board and finance lead launch lender engagement with 5-10 targets; issue information memorandum Months 3-4 (2027-01-12 to 2027-02-12), hold roundtable Months 4-5 (2027-02-12 to 2027-03-12), sign heads of terms with 2-3 arrangers by Month 9 (2027-07-12).
- Month 0-3 (2026-10-12 to 2027-01-12): Owner's team commissions an Arctic parametric cost model and Cost Basis Document by Month 6 (2027-04-12); set bid-variance trigger at 5% and hold the USD 15 billion contingency outside baseline.
- Month 0-6 (2026-10-12 to 2027-04-12): General counsel retains export-control counsel, charters the neutral SPV by Month 3 (2027-01-12) and obtains written OFAC/export-control guidance and a pre-approved supplier list by Month 6 (2027-04-12).
- Month 0-6 (2026-10-12 to 2027-04-12): Commission an independent traffic and tariff study, and start take-or-pay marketing to fiber, power and rail tenants; test whether any single use-case draws signed commitments before Gate 2.
- Month 0-12 (2026-10-12 to 2027-10-12): Engineering lead starts ice, seismic and permafrost monitoring, runs the pilot element trial in Months 9-12 (2027-07-12 to 2027-10-12), and pre-qualifies two yards; re-plan installation with a second spread or yard.
- Month 1-12 (2026-11-12 to 2027-10-12): Community lead maps Indigenous communities by Month 1 (2026-11-12), forms the Beringia Council by Month 6 (2027-04-12) and signs consent agreements by Month 12 (2027-10-12).
- Month 0-6 (2026-10-12 to 2027-04-12): Steering committee formalizes Gates 1-4 with paid pause and exit and the USD 150 million cap, and decides the remaining alignment method by Gate 3.

## Strategic Objectives 🎯🔭⛳🏅
- By Month 9 (2027-07-12), sign heads of terms with 2-3 lead arrangers covering at least 50% of the USD 69 billion debt target (proposed threshold), and reach financial close by Month 24 (2028-10-12), latest Month 30 (2029-04-12).
- By Month 6 (2027-04-12), issue the Cost Basis Document and parametric model; at Month 12 (2027-10-12), achieve bids within 5% of baseline and keep cumulative pre-gate spend at or below USD 150 million through Month 24 (2028-10-12).
- By Month 18 (2028-04-12), approve design freeze with ice-load confidence within +/-15% using at least one full ice season of data, and hold detailed marine permits.
- By Month 12 (2027-10-12), execute Indigenous consent agreements with all mapped communities and fund the Council with USD 2-5 million, with zero injunctions through Month 30 (2029-04-12).
- By Month 12 (2027-10-12), pre-sell take-or-pay capacity covering at least 30% of target expected revenue (about USD 2.7 billion/yr), and show installation capacity of at least 9 elements per season or a revised Phase 1 completion date.

## Assumptions 🤔🧠🔍
- Phase 1 baseline is USD 100 billion with USD 15 billion contingency; funding requirement USD 115 billion (estimate).
- Governments contribute land, rights-of-way and guarantees, not cash; consortium funds USD 69 billion debt and USD 46 billion equity (estimate).
- A neutral SPV and framework agreement are licensable by OFAC and export-control authorities.
- Debt terms of 30 years at 5.5% (placeholder) give debt service of about USD 4.75 billion/yr (estimate).
- Month 180 (2041-10-12) is a target, not a commitment; Phase 2 completes beyond Month 180 (2041-10-12) and is not costed.
- The program is not run for profit; success is judged on outcomes delivered per unit cost, while fees and tolls are judged on revenue.

## Missing Information 🧩🤷‍♂️🤷‍♀️
- Independent traffic forecast, tariff and shipper demand (which customers would commit, and at what price).
- Detailed parametric cost model and unit rates; cost per tonne or per unit capacity versus alternatives such as sea and air routes.
- Identified lenders, their sanctions policies and written licensing guidance.
- Crossing method and cost for the remaining 49-65 km; Phase 2 cost and funding.
- Ice, seismic, permafrost and marine mammal baseline data; fabrication yard capacity and tow-window evidence.
- Indigenous community positions, legal standing of the Council in both jurisdictions.
- Government appetite for guarantees and the budget cap decision.

## Questions 🙋❓💬📌
- Who would actually pay about USD 8.9 billion/yr, and what evidence from shippers, tenants or governments supports it?
- If sanctions licensing or ratification fails at Gate 4, what is the minimum useful output of the USD 150 million spent, and who bears it?
- Is Phase 1 cost-effective per unit of capacity compared with sea, air or cable-only alternatives?
- How would you close the gap between about 9 elements per season needed and 3-8 achievable, and is the Month 180 (2041-10-12) target worth keeping?
- What decision rights will Indigenous communities hold over work windows and alignment, and can the schedule absorb them?