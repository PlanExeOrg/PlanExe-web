### 1. Project Sponsor and Senior Management formally establish and charter the neutral third-country SPV that will own and govern the crossing. SPV bylaws must specify voting rights, decision authority, reporting structure and Steering Committee composition. Register the SPV in the chosen neutral jurisdiction (Switzerland, Canada or international regime candidate) by Month 3 (2027-01-12).

**Responsible Body/Role:** Project Sponsor (US and Russian government representatives) with Neutral SPV Legal Counsel

**Suggested Timeframe:** Month 0 (2026-10-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- SPV Charter and Bylaws (final, executed)
- SPV Articles of Incorporation filed in host jurisdiction
- Board Composition and Voting Rules documented
- SPV Bank Accounts and Financial Controls established

**Dependencies:**

- Project Sponsor identified and authorized
- Neutral jurisdiction and SPV structure selected
- Legal framework for US-Russia governance agreed in principle

### 2. Project Manager or Designated Formation Lead drafts the Steering Committee Charter, including explicit authority matrix, decision thresholds, meeting cadence, quorum rules and escalation protocols. The Charter must specify gate-clearance criteria, voting procedures, tie-breaking rules and the role of the neutral Steering Committee chair (to be appointed separately). Circulate draft to nominated steering members for review and feedback.

**Responsible Body/Role:** Project Manager / Formation Lead (appointed by Project Sponsor)

**Suggested Timeframe:** Month 0 (2026-10-12) to Month 1.5 (2026-11-27 to 2026-11-27)

**Key Outputs/Deliverables:**

- Draft Steering Committee Charter v0.1
- Authority Matrix and Decision Thresholds documented
- Gate-Clearance Criteria Checklist (Months 6, 12, 18, 24 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12)
- Meeting-Cadence Calendar and Escalation Pathways

**Dependencies:**

- Project Sponsor identified
- SPV Charter under development
- Nominated Steering Committee member list available (US, Russia, lenders, technical advisor)

### 3. Project Sponsor formally appoints the Steering Committee Chair (proposed: neutral independent party, e.g., retired senior infrastructure executive or diplomat). Appointment letter must specify term, decision authority and compensation. Chair must confirm acceptance and sign conflict-of-interest disclosure and confidentiality agreement by Month 1.5 (2026-11-27).

**Responsible Body/Role:** Project Sponsor (US and Russian government representatives, acting jointly)

**Suggested Timeframe:** Month 0.5 (2026-10-27) to Month 1.5 (2026-11-27 to 2026-11-27)

**Key Outputs/Deliverables:**

- Steering Committee Chair Appointment Letter (executed)
- Chair Acceptance and Conflict-of-Interest Disclosure
- Chair Compensation and Term Agreement
- Chair Confidentiality Agreement signed

**Dependencies:**

- Project Sponsor authorized
- Neutral chair candidate identified and vetted
- SPV Charter draft available for reference

### 4. Project Sponsor and Designated Formation Lead circulate the Steering Committee Charter draft to all nominated members (US and Russian government representatives, lead lenders, technical advisor) for review and comment. Collect feedback in a Feedback Summary document. Resolve comments in a redline draft and re-circulate for final approval.

**Responsible Body/Role:** Project Manager / Formation Lead (in coordination with Steering Committee Chair)

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 2 (2026-12-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Steering Committee Charter v0.1 distributed to nominatedmembers
- Feedback Summary (consolidated comments and resolutions)
- Steering Committee Charter v1.0 (redlined, ready for approval)

**Dependencies:**

- Draft Steering Committee Charter v0.1 complete
- Steering Committee Chair appointed
- Nominated member contact list available

### 5. Steering Committee Chair formally confirms and finalizes the Steering Committee Charter v1.0 based on feedback and obtains written approval signatures from all voting members (Project Sponsor representative, US government, Russian government, lead lenders). Publish the finalized Charter and distribute to all parties.

**Responsible Body/Role:** Steering Committee Chair (with Project Manager support)

**Suggested Timeframe:** Month 2 (2026-12-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Steering Committee Charter v1.0 (final, signed by all voting members)
- Steering Committee Charter published and disseminated
- Meeting-Cadence and Gate-Review Calendar confirmed and published

**Dependencies:**

- Steering Committee Charter v1.0 redline complete
- All nominated members confirmed
- Steering Committee Chair in post

### 6. Project Sponsor and Steering Committee Chair jointly formalize the appointment of all Steering Committee voting members (US and Russian government representatives, lead lender representatives, neutral technical advisor). Send formal appointment letters with term, responsibilities and conflict-of-interest requirements. Obtain signed confirmations of acceptance.

**Responsible Body/Role:** Project Sponsor (in coordination with Steering Committee Chair)

**Suggested Timeframe:** Month 2.5 (2026-12-27) to Month 3.5 (2027-01-27 to 2027-02-12)

**Key Outputs/Deliverables:**

- Steering Committee Member Appointment Letters (executed)
- Member Acceptance Confirmations and Conflict-of-Interest Disclosures
- Steering Committee Roster (published with roles and affiliations)

**Dependencies:**

- Steering Committee Chair appointed
- Steering Committee Charter finalized and signed
- Member candidates identified and vetted by Project Sponsor

### 7. Project Sponsor appoints the Operations and Execution Council Chair (proposed: Owner's Engineer/Integrator or senior operations lead). Chair must confirm acceptance, sign conflict-of-interest disclosure and establish initial meeting schedule. Chair drafts the Operations Council Charter specifying decision authority, weekly-meeting cadence, interface-control procedures and escalation to Steering Committee.

**Responsible Body/Role:** Project Sponsor (in coordination with Steering Committee Chair)

**Suggested Timeframe:** Month 0 (2026-10-12) to Month 2 (2026-12-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Operations and Execution Council Chair Appointment Letter (executed)
- Chair Acceptance and Conflict-of-Interest Disclosure
- Draft Operations Council Charter v0.1
- Initial Meeting Schedule and Calendar

**Dependencies:**

- Project Sponsor identified
- Owner's Engineer/Integrator candidate identified
- Steering Committee structure in planning

### 8. Operations and Execution Council Chair drafts the Operations Council Charter, including authority matrix, weekly-meeting cadence, quorum, change-control thresholds (USD 10 million for changes, 5% for cost/schedule variance escalation), interface-control procedures and neutral-arbiter escalation. Circulate to draft to nominated core team members (Owner's Engineer, Cost Engineer, Design Lead, Environmental Lead, Indigenous Lead, Logistics Lead, Finance Manager) for feedback.

**Responsible Body/Role:** Operations and Execution Council Chair (proposed: Owner's Engineer/Integrator)

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 2 (2026-12-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Operations Council Charter v0.1 (draft)
- Authority Matrix and Change-Control Thresholds defined
- Decision Mechanism and Tie-Breaking Rules documented
- Interface-Control Board Charter (draft)

**Dependencies:**

- Operations Council Chair appointed
- Core team roles identified (Owner's Engineer, Cost Engineer, etc.)
- Steering Committee Charter in place (for alignment on thresholds)

### 9. Operations and Execution Council Chair finalizes the Operations Council Charter based on core team feedback. Obtain written approval signatures from all voting members (Cost Engineer, Design Lead, Environmental Lead, Indigenous Lead, Logistics Lead, Finance Manager). Publish the finalized Charter and establish the weekly-meeting routine starting Month 3 (2027-01-12).

**Responsible Body/Role:** Operations and Execution Council Chair

**Suggested Timeframe:** Month 2 (2026-12-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Operations Council Charter v1.0 (final, signed)
- Operations Council Charter published
- Weekly-Meeting Calendar (Months 3-60 = 2027-01-12 to 2031-10-12)
- Interface-Control Board established and meeting schedule published

**Dependencies:**

- Operations Council Chair in post
- Core team roles defined
- Operations Council Charter v0.1 feedback incorporated

### 10. Project Sponsor and Steering Committee Chair jointly recruit and formally appoint the Technical Advisory Group Chair (proposed: world-class Arctic or immersed-tunnel engineer, e.g., National Academy member). Chair must confirm acceptance, sign conflict-of-interest and confidentiality agreements and establish the TAG member recruitment schedule.

**Responsible Body/Role:** Project Sponsor (in coordination with Steering Committee Chair)

**Suggested Timeframe:** Month 0 (2026-10-12) to Month 1 (2026-11-12 to 2026-11-12)

**Key Outputs/Deliverables:**

- Technical Advisory Group Chair Appointment Letter (executed)
- Chair Acceptance and Conflict-of-Interest Disclosure
- TAG Member Recruitment Plan and Timeline
- TAG Charter (draft, pending member confirmation)

**Dependencies:**

- Project Sponsor identified
- TAG Chair candidate (world-class engineer) identified and vetted
- Steering Committee structure in planning

### 11. Technical Advisory Group Chair identifies and recruits 8-12 specialized members (propose: 2-3 ice-mechanics experts, 2 seismic/permafrost engineers, 2 immersed-tunnel designers, 2 Arctic-construction specialists, 1-2 independent engineering-review firms). Send formal engagement letters by Month 1 (2026-11-12). Execute engagement agreements specifying scope, confidentiality, fees and meeting cadence by Month 3 (2027-01-12).

**Responsible Body/Role:** Technical Advisory Group Chair

**Suggested Timeframe:** Month 0.5 (2026-10-27) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- TAG Member List (8-12 confirmed specialists)
- TAG Member Engagement Letters (executed)
- TAG Engagement Agreements (signed, confidentiality in place)
- TAG Member Roster with affiliations and specialties

**Dependencies:**

- TAG Chair appointed
- Funding approved for specialist engagement (external budget)
- TAG member candidate list identified

### 12. Technical Advisory Group Chair drafts the TAG Charter, specifying quarterly-meeting cadence during design phases (Months 3, 6, 9, 12, 15, 18 = 2027-01-12 to 2028-04-12), data-flow protocols from Operations Council, escalation criteria for Major Issues (ice/seismic/permafrost data uncertainties, design-adequacy doubts), certification authority on design freeze and decision mechanism (consensus with dissent documentation). Circulate to TAG members for review and finalization.

**Responsible Body/Role:** Technical Advisory Group Chair

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 2.5 (2026-12-27 to 2027-01-02)

**Key Outputs/Deliverables:**

- TAG Charter v1.0 (draft)
- Quarterly-Meeting Schedule (Months 3-18 = 2027-01-12 to 2028-04-12)
- Data-Flow and Escalation Protocols documented
- TAG Certification Authority and Decision Mechanism defined

**Dependencies:**

- TAG Chair in post
- TAG members recruited and confirmed
- Steering Committee Charter completed (for alignment on escalation)

### 13. Technical Advisory Group Chair finalizes the TAG Charter and obtains written confirmation from all TAG members. Establish monthly data-flow routine from Operations Council (raw monitoring data, design models, test results) to TAG starting Month 3 (2027-01-12). Schedule first formal TAG meeting for Month 3 (2027-01-12) with preliminary ice and seismic data available.

**Responsible Body/Role:** Technical Advisory Group Chair

**Suggested Timeframe:** Month 2 (2026-12-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- TAG Charter v1.0 (final, confirmed by all members)
- Monthly Data-Flow Routine established
- First TAG Meeting scheduled (Month 3 = 2027-01-12)
- TAG Charter published to Steering Committee and Operations Council

**Dependencies:**

- TAG Charter v1.0 draft complete
- All TAG members confirmed
- Operations Council structure and meeting schedule in place

### 14. Project Sponsor and Formation Lead initiate Indigenous-stakeholder mapping by engaging established US and Russian government liaisons (e.g., US Bureau of Indian Affairs, Russian Ministry of Indigenous Affairs if applicable). Conduct stakeholder identification interviews with tribal councils, traditional-use boards and Indigenous community leaders in Alaska (Inupiat, Yupik communities around Wales, Nome) and Russia (Chukchi, Yupik communities around Uelen, Provideniya). Complete mapping document identifying all communities with traditional-use rights, regulatory authority or potential project impact.

**Responsible Body/Role:** Project Manager / Formation Lead (in coordination with Indigenous Engagement Specialist, newly hired or designated)

**Suggested Timeframe:** Month 0 (2026-10-12) to Month 1 (2026-11-12 to 2026-11-12)

**Key Outputs/Deliverables:**

- Indigenous-Stakeholder Mapping Report (8-12 communities identified)
- Contact List for Indigenous Community Leaders and Councils
- Preliminary Community Engagement Timeline and Schedule
- Initial Outreach Letters sent to community councils

**Dependencies:**

- Project Sponsor authorized
- US and Russian government liaisons engaged
- Funding approved for Indigenous-engagement specialist

### 15. Project Manager and Indigenous Engagement Specialist fund and establish community legal and technical advisors (propose: USD 500,000 to 1 million per community grouping through Month 12 = 2027-10-12). Advisors must be independent of project control. Advisors will support community review of EIS/EIA documents, consent agreements and benefit-fund design. Negotiate and execute advisor engagement agreements by Month 3 (2027-01-12).

**Responsible Body/Role:** Project Manager and Indigenous Engagement Specialist (with Project Sponsor approval)

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Community Advisor Recruitment Plan and Budget Allocation
- Community Legal Advisor Engagement Letters (executed)
- Community Technical Advisor Engagement Agreements (signed)
- Advisor Funding Mechanism established (direct payment, independent accounts)

**Dependencies:**

- Indigenous-Stakeholder Mapping complete
- Budget approved for community advisors
- Community councils identified and contacted

### 16. Project Sponsor and Indigenous Engagement Specialist draft the Beringia Indigenous Council Formation Charter, specifying legal standing, binding advisory authority over alignment, work windows and mitigation measures, governance structure (delegates from 8-12 communities), decision-making (>75% consensus threshold), funding mechanism (propose USD 2-5 million setup + USD 1-2 million/yr operations) and dispute-resolution process. Circulate draft to identified community leaders for feedback and refinement.

**Responsible Body/Role:** Indigenous Engagement Specialist (with Project Sponsor and Project Manager oversight)

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 2 (2026-12-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Beringia Indigenous Council Formation Charter v0.1 (draft)
- Community Feedback Summary on Charter scope and authority
- Proposed Council Governance Structure and Decision Rules
- Funding and Support Plan for Council operations

**Dependencies:**

- Indigenous-Stakeholder Mapping complete
- Community Legal Advisors engaged
- Project Sponsor commitment to Indigenous engagement

### 17. Project Sponsor and Indigenous Engagement Specialist formalize the Beringia Indigenous Council Foundation by obtaining written commitment letters from all identified Indigenous communities confirming their participation, delegate representation and acceptance of the Council Charter. Execute the Council Formation Agreement by Month 6 (2027-04-12). Formally establish the Council with an inaugural meeting at Month 6 (2027-04-12).

**Responsible Body/Role:** Project Sponsor (in coordination with Indigenous Engagement Specialist)

**Suggested Timeframe:** Month 3 (2027-01-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Community Participation Commitment Letters (all identified communities signed)
- Beringia Indigenous Council Formation Agreement (executed)
- Council Charter v1.0 (finalized, signed by all communities)
- Council Inaugural Meeting held (Month 6 = 2027-04-12)
- Council Meeting Minutes and member roster published

**Dependencies:**

- Beringia Council Charter v0.1 draft complete
- Community legal advisors in place
- Funding commitment for Council operations secured

### 18. Indigenous Engagement Specialist co-sponsors marine-mammal and subsistence-baseline studies with Indigenous community researchers as co-authors (propose 30-50% of study teams). Studies begin Month 0 (2026-10-12) and run through Month 12 (2027-10-12), documenting traditional knowledge, subsistence harvesting patterns, marine-mammal migration and feeding, and environmental baselines. Ensure Indigenous communities retain data-sharing rights and co-publication authority.

**Responsible Body/Role:** Indigenous Engagement Specialist (in coordination with Environmental and Permitting Lead, Operations Council)

**Suggested Timeframe:** Month 0 (2026-10-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Marine-Mammal Baseline Study (co-authored with Indigenous researchers)
- Subsistence Harvesting Baseline Report (community-validated)
- Traditional-Knowledge Documentation (copyright held by community)
- Study Data-Sharing and Co-Publication Agreement

**Dependencies:**

- Indigenous-Stakeholder Mapping complete
- Community legal and technical advisors in place
- Environmental/permitting team identified (Operations Council)
- Funding for baseline studies approved

### 19. Project Manager (Formation Lead) appoints the Compliance Officer (dedicated regulatory and licensing specialist) and Risk and Insurance Manager by Month 1 (2026-11-12). Both roles report to the Risk, Compliance and Insurance Committee Chair (to be appointed separately). Compliance Officer immediately begins OFAC and export-control engagement, submitting initial written inquiries by Month 1 (2026-11-12) and requesting preliminary guidance on financing structure and supplier sourcing.

**Responsible Body/Role:** Project Sponsor and Project Manager

**Suggested Timeframe:** Month 0.5 (2026-10-27) to Month 1 (2026-11-12 to 2026-11-12)

**Key Outputs/Deliverables:**

- Compliance Officer Job Description and Appointment Letter
- Risk and Insurance Manager Job Description and Appointment Letter
- OFAC Pre-Engagement Letter submitted (Month 1 = 2026-11-12)
- Export-Control Counsel Engagement Letter (signed)

**Dependencies:**

- Project Sponsor authorized
- Funding approved for Compliance Officer and Risk Manager roles
- Export-control counsel identified and pre-qualified

### 20. Project Sponsor and Formation Lead appoint the Risk, Compliance and Insurance Committee Chair (proposed: senior compliance or risk professional, independent from operational delivery). Chair drafts the Risk Committee Charter specifying monthly-meeting cadence during Months 0-24 (2026-10-12 to 2028-10-12), decision authority on risk escalation thresholds (cost >5%, schedule >2 months, DSCR <1.3x, OFAC delay >3 months), insurance-policy oversight and leading-indicator monitoring. Chair establishes monthly risk-monitoring routine.

**Responsible Body/Role:** Project Sponsor (in coordination with Project Manager)

**Suggested Timeframe:** Month 0 (2026-10-12) to Month 2 (2026-12-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Risk Committee Chair Appointment Letter (executed)
- Risk Committee Charter v0.1 (draft, with decision thresholds and escalation criteria)
- Risk-Register Template and Leading-Indicator Dashboard defined
- Monthly Risk-Monitoring Routine established

**Dependencies:**

- Project Sponsor authorized
- Compliance Officer and Risk Manager in post
- Steering Committee Charter in place (for alignment on escalation thresholds)

### 21. Risk Committee Chair circulates the Risk Committee Charter draft to Compliance Officer, Risk and Insurance Manager, and Operations Council representative for feedback. Finalize the Charter and obtain written approval by Month 3 (2027-01-12). Establish the monthly risk-reporting routine (risk-register review, leading-indicator dashboard, escalation recommendations) starting Month 3 (2027-01-12).

**Responsible Body/Role:** Risk, Compliance and Insurance Committee Chair (with Compliance Officer and Risk Manager input)

**Suggested Timeframe:** Month 1.5 (2026-11-27) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Risk Committee Charter v1.0 (final, signed)
- Risk-Register v1.0 populated with 20-30 initial risks (from risk-assessment and planning documents)
- Leading-Indicator Dashboard defined (cost variance, schedule slip, DSCR, permitting delays)
- Monthly Risk-Reporting Template published

**Dependencies:**

- Risk Committee Chair appointed
- Compliance Officer and Risk Manager in post
- Comprehensive risk assessment or risk-file inputs available

### 22. Compliance Officer (with support from Risk and Insurance Manager) conducts formal OFAC and export-control licensing inquiry. Submit detailed project overview, financing structure (third-country consortium), equipment sourcing strategy and personnel-movement plan to US Treasury OFAC and equivalent Russian authorities. Request written preliminary guidance on licensability by Month 3 (2027-01-12) and final licensing pathway with pre-approved supplier list by Month 6 (2027-04-12).

**Responsible Body/Role:** Compliance Officer (dedicated regulatory specialist)

**Suggested Timeframe:** Month 0.5 (2026-10-27) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- OFAC and Export-Control Inquiry Package (submitted Month 1 = 2026-11-12)
- Preliminary OFAC Guidance Letter (received by Month 3 = 2027-01-12, target)
- Written Licensing Pathway (final, by Month 6 = 2027-04-12)
- Pre-Approved Supplier and Contractor List (by Month 6 = 2027-04-12)

**Dependencies:**

- Compliance Officer appointed
- Export-control counsel engaged
- Financing structure and third-country SPV finalized
- Equipment and sourcing strategy defined (Operations Council)

### 23. Risk and Insurance Manager initiates insurance-broker engagement (Month 1 = 2026-11-12), selecting a specialized large-project and political-risk insurance advisor. Broker develops insurance specifications and coverage requirements for builder's risk, environmental liability, professional indemnity, contractor performance bonds and political-risk insurance (sanctions and expropriation coverage) by Month 6 (2027-04-12). Procure final insurance policies by Month 12 (2027-10-12) before construction mobilization.

**Responsible Body/Role:** Risk and Insurance Manager (dedicated role, full-time)

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Insurance-Broker Engagement Letter (executed)
- Insurance Specifications and Coverage Requirements (by Month 6 = 2027-04-12)
- Insurance Policy Quotes and Comparison Analysis (by Month 9 = 2027-07-12)
- Executed Insurance Policies (by Month 12 = 2027-10-12)
- Insurance Certificates of Insurance and proof of coverage

**Dependencies:**

- Risk and Insurance Manager appointed
- Project CAPEX baseline and financing structure finalized
- Lender requirements and insurance mandates understood

### 24. Project Manager and Operations Council Chair formally appoint all core Operations Council voting members (Cost Engineer, Design Lead - Bridge and Tunnel, Environmental and Permitting Lead, Indigenous Stakeholder Lead, Construction Logistics Lead, Finance and Commercial Manager) by Month 1 (2026-11-12). Send formal appointment letters with term, responsibilities and authorities. Obtain signed confirmations of acceptance and conflict-of-interest disclosures.

**Responsible Body/Role:** Project Sponsor and Operations and Execution Council Chair

**Suggested Timeframe:** Month 0.5 (2026-10-27) to Month 2 (2026-12-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Operations Council Member Appointment Letters (executed for all voting members)
- Member Acceptance Confirmations and Conflict-of-Interest Disclosures
- Operations Council Member Roster (published with roles and authorities)
- Weekly-Meeting Schedule (Months 3-60 = 2027-01-12 to 2031-10-12)

**Dependencies:**

- Operations and Execution Council Chair appointed
- Core team roles defined in Operations Council Charter
- Operations Council Charter finalized

### 25. Operations Council Chair establishes the Interface Control Board (ICB) by appointing an ICB Chair (proposed: Owner's Engineer Integrator or independent integrator), defining monthly-meeting cadence starting Month 6 (2027-04-12), and publishing the ICB Charter. ICB will manage interface-control documents between suspension span, immersed-tube tunnel and island systems; resolve interface conflicts through documented decision process; and escalate unresolved conflicts to a neutral external arbiter (to be appointed separately by Month 6 = 2027-04-12).

**Responsible Body/Role:** Operations and Execution Council Chair

**Suggested Timeframe:** Month 2 (2026-12-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Interface Control Board Charter (published)
- ICB Chair Appointment Letter (executed)
- Monthly ICB Meeting Calendar (Months 6-60 = 2027-04-12 to 2031-10-12)
- Interface-Control Document Template and Approval Process defined

**Dependencies:**

- Operations Council Charter finalized
- Owner's Engineer Integrator or ICB Chair candidate identified
- Design team leads identified (bridge and tunnel leads)

### 26. Operations Council Chair appoints a neutral external arbiter (independent megaproject engineer or integrator with binding authority over interface disputes) by Month 2 (2026-12-12). Arbiter must be independent of contractors, governments and operators. Execute arbiter engagement agreement specifying scope (interface conflict resolution within 2-week timeline with binding decision authority), confidentiality and fees. Arbiter attends ICB meetings as needed starting Month 6 (2027-04-12).

**Responsible Body/Role:** Operations and Execution Council Chair (with Project Sponsor oversight)

**Suggested Timeframe:** Month 1.5 (2026-11-27) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Neutral Arbiter Identification and Vetting completed
- Arbiter Engagement Agreement (executed)
- Arbiter Acceptance and Conflict-of-Interest Disclosure
- Arbiter contact and decision-escalation protocols published

**Dependencies:**

- Operations Council established
- Interface Control Board Charter in planning
- Funding approved for arbiter services

### 27. Project Manager (Formation Lead) establishes the Owner's Engineer Integrator function (proposed: senior Arctic megaproject engineer with 100-150 core specialist team). Owner's Engineer is the primary responsible party for design, cost control, interface management and construction oversight, reporting to Operations Council. Publish the Owner's Engineer job description, authority matrix and direct-report structure by Month 1 (2026-11-12). Recruit Owner's Engineer and core team leads by Month 2 (2026-12-12).

**Responsible Body/Role:** Project Sponsor and Project Manager

**Suggested Timeframe:** Month 0.5 (2026-10-27) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Owner's Engineer Job Description and Authority Matrix (published)
- Owner's Engineer Recruitment and Hiring Plan
- Owner's Engineer Offer Letter (by Month 2 = 2026-12-12)
- Core Team Structure (100-150 specialists) and roles defined
- Owner's Engineer Onboarding completed (Month 3 = 2027-01-12)

**Dependencies:**

- Project Sponsor authorized
- Operations Council structure established
- CAPEX budget and staffing budget approved

### 28. Operations Council Chair and Owner's Engineer Integrator develop the Detailed Project Execution Plan, covering design schedule (Months 0-18 = 2026-10-12 to 2028-04-12 for preliminary and critical design reviews), permitting roadmap (framework permits Months 6-9 = 2027-04-12 to 2027-07-12, detailed permits Months 12-18 = 2027-10-12 to 2028-04-12), Indigenous-engagement milestones (Beringia Council formation Months 3-6 = 2027-01-12 to 2027-04-12, consent agreements Month 12 = 2027-10-12), surveys and monitoring (ice, seismic, permafrost Months 0-18 = 2026-10-12 to 2028-04-12), and cost/schedule baseline. Publish by Month 3 (2027-01-12).

**Responsible Body/Role:** Operations and Execution Council Chair and Owner's Engineer Integrator

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Detailed Project Execution Plan v1.0 (published)
- Design Schedule and Milestone Calendar (Months 0-180 = 2026-10-12 to 2041-10-12)
- Permitting Roadmap with agency touchpoints and approval timeline
- Indigenous-Engagement Milestone Schedule (Months 0-12 = 2026-10-12 to 2027-10-12)
- Cost and Schedule Baseline Summary

**Dependencies:**

- Operations Council established
- Owner's Engineer Integrator appointed
- Steering Committee Charter finalized (for gate schedule reference)

### 29. Cost Engineer (appointed as Operations Council voting member) commissions a detailed parametric cost estimate from Arctic-construction specialists (HDR, Jacobs, Golder or equivalent) by Month 3 (2027-01-12). Build-up must include regional labor surveys (target: 30-50% Arctic premium), material cost indices, marine logistics premiums (50-100%), Arctic-specific equipment and supplier rates. Establish Cost Basis Document and publish for contractor feedback by Month 6 (2027-04-12). Conduct sensitivity analysis on key cost drivers (labor escalation, material inflation, exchange rates, contractor premiums).

**Responsible Body/Role:** Cost Engineer (Operations Council voting member)

**Suggested Timeframe:** Month 0.5 (2026-10-27) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Parametric Cost-Estimate Request and Scoping (by Month 2 = 2026-12-12)
- Detailed Cost Build-Up by category (labor, materials, logistics, contingency) - Month 3 = 2027-01-12
- Cost Basis Document v1.0 (published for feedback, Month 6 = 2027-04-12)
- Sensitivity Analysis on key cost drivers
- Contractor feedback summary and cost-estimate refinement

**Dependencies:**

- Cost Engineer appointed
- Arctic-construction cost-modeling consultant identified and selected
- Funding approved for cost-estimate study
- Design scope and deliverables defined

### 30. Operations Council (Cost Engineer lead) establishes a Cost Task Force with representatives from candidate fabrication yards, tow-vessel operators, Arctic labor providers and material suppliers. Task Force meets monthly (Months 3-6 = 2027-01-12 to 2027-04-12) to validate parametric-cost estimates, identify regional rate drivers, confirm labor availability and material lead times, and resolve cost outliers. Task Force input feeds into refined Cost Basis Document v1.0 published by Month 6 (2027-04-12).

**Responsible Body/Role:** Cost Engineer (Operations Council), with support from Logistics Lead and Finance Manager

**Suggested Timeframe:** Month 2 (2026-12-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Cost Task Force Charter and Member List (Month 2 = 2026-12-12)
- Monthly Cost-Review Meeting Minutes (Months 3-6 = 2027-01-12 to 2027-04-12)
- Cost Validation Report (contractor and supplier input consolidated)
- Cost Basis Document v1.0 (final, Month 6 = 2027-04-12)

**Dependencies:**

- Parametric cost estimate commissioned and in progress
- Candidate yards, logistics providers and suppliers identified
- Cost Engineer in post

### 31. Cost Engineer establishes a formal cost-tracking system (Primavera P6, Oracle Cloud or equivalent) and cost-change-control process (Months 3-6 = 2027-01-12 to 2027-04-12). Define cost-change thresholds: Changes ≤USD 10 million approved by Operations Council; >USD 10 million escalate to Steering Committee. Variance >5% triggers reforecasting and repricing review with lender sign-off. Monthly cost tracking and variance reporting begin Month 3 (2027-01-12).

**Responsible Body/Role:** Cost Engineer (Operations Council voting member)

**Suggested Timeframe:** Month 2 (2026-12-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Cost-Tracking System Setup and Database configured
- Cost-Change-Control Process documented and published
- Cost-Variance Report Template (monthly, starting Month 3 = 2027-01-12)
- Cost-Escalation Matrix (thresholds for Operations Council vs. Steering Committee)
- Cost-Variance Monitoring Dashboard (updated monthly)

**Dependencies:**

- Cost Engineer appointed
- Detailed Project Execution Plan and baseline established
- Software licenses and IT infrastructure approved

### 32. Operations Council launches ice-monitoring program: install drifting buoys, shore-based radar and satellite-imagery tracking starting Month 0 (2026-10-12). Install pilot instrumentation (pressure plates, accelerometers) on prototype pier models in the strait (Months 6-12 = 2027-04-12 to 2027-10-12) to capture real-world ice loads. Establish data-collection and analysis protocols with independent verification by Month 3 (2027-01-12). First ice-data summary to Technical Advisory Group by Month 6 (2027-04-12).

**Responsible Body/Role:** Design Lead - Bridge (Operations Council voting member), with support from Environmental Lead and independent monitoring contractor

**Suggested Timeframe:** Month 0 (2026-10-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Ice-Monitoring Program Charter and Instrumentation Plan (Month 0 = 2026-10-12)
- Drifting-Buoy and radar-tracking network deployed (Month 1 = 2026-11-12)
- Pilot Instrumentation installed on prototype piers (Months 6-12 = 2027-04-12 to 2027-10-12)
- Data-Collection and QA/QC Protocols published (Month 3 = 2027-01-12)
- First Ice-Data Summary and load-model calibration (Month 6 = 2027-04-12)

**Dependencies:**

- Operations Council established
- Design Lead - Bridge appointed
- Funding approved for ice-monitoring instrumentation and analysis
- Site survey and baseline established

### 33. Operations Council (with Design Lead - Bridge and Geotechnical specialist input) launches comprehensive geotechnical investigation program. Core drilling at proposed pier locations and island sites (Months 0-6 = 2026-10-12 to 2027-04-12). Laboratory testing of soil samples for shear strength, consolidation and permafrost (Months 3-9 = 2027-01-12 to 2027-07-12). In-situ testing (SPT, CPT, vane shear) at multiple depths (Months 6-12 = 2027-04-12 to 2027-10-12). Establish subsidence and temperature-monitoring network starting Month 6 (2027-04-12), with monthly measurements through Month 24 (2028-10-12).

**Responsible Body/Role:** Design Lead - Bridge / Geotechnical Engineer (Operations Council supporting role)

**Suggested Timeframe:** Month 0 (2026-10-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Geotechnical Investigation Program Charter and drilling/testing schedule (Month 0 = 2026-10-12)
- Core samples collected and logged (Months 0-6 = 2026-10-12 to 2027-04-12)
- Laboratory test results and soil characterization (Months 3-9 = 2027-01-12 to 2027-07-12)
- In-situ test data and soil-profile interpretation (Months 6-12 = 2027-04-12 to 2027-10-12)
- Subsidence and Temperature-Monitoring Network established (Month 6 = 2027-04-12)

**Dependencies:**

- Operations Council established
- Design Lead - Bridge appointed
- Survey and site access rights obtained
- Funding approved for drilling and lab testing

### 34. Design Lead - Bridge (with seismic specialist support) conducts site-specific seismic hazard analysis using latest regional earthquake catalogs and ground-motion prediction models. Analysis complete by Month 6 (2027-04-12). Run coupled seismic-permafrost finite-element analyses (Months 9-12 = 2027-07-12 to 2027-10-12) to model ground response during design-basis earthquake. Summary report and seismic-design recommendations to Technical Advisory Group by Month 12 (2027-10-12).

**Responsible Body/Role:** Design Lead - Bridge (with Seismic Engineer or external specialist support)

**Suggested Timeframe:** Month 3 (2027-01-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Site-Specific Seismic Hazard Analysis Report (Month 6 = 2027-04-12)
- Ground-Motion Prediction Models and design-basis earthquake definition
- Coupled Seismic-Permafrost FE Analysis (Months 9-12 = 2027-07-12 to 2027-10-12)
- Seismic Design Recommendations and loading assumptions (Month 12 = 2027-10-12)

**Dependencies:**

- Design Lead - Bridge appointed
- Seismic engineer or consultant identified
- Geotechnical investigation data available (ice/permafrost characterization)

### 35. Environmental and Permitting Lead (Operations Council voting member) coordinates NEPA/EIA baseline surveys and stakeholder engagement. US NEPA environmental impact statement process initiated Month 0 (2026-10-12); Russian EIA equivalent engaged simultaneously. Baseline surveys (marine mammals, fish, habitats, water quality) run Months 0-12 (2026-10-12 to 2027-10-12) with Indigenous community researchers co-leading (per Indigenous-engagement protocol). Framework permit applications submitted Months 6-9 (2027-04-12 to 2027-07-12); detailed marine permits applied for Months 12-15 (2027-10-12 to 2028-01-12).

**Responsible Body/Role:** Environmental and Permitting Lead (Operations Council voting member)

**Suggested Timeframe:** Month 0 (2026-10-12) to Month 18 (2028-04-12 to 2028-04-12)

**Key Outputs/Deliverables:**

- NEPA and EIA Engagement Letters to US/Russian agencies (Month 0 = 2026-10-12)
- Baseline Marine-Mammal Survey Report (Months 0-12 = 2026-10-12 to 2027-10-12, co-authored with Indigenous researchers)
- Baseline Fisheries and Habitat Assessment (Months 0-12 = 2026-10-12 to 2027-10-12)
- Framework Permit Applications (submitted Months 6-9 = 2027-04-12 to 2027-07-12)
- Detailed Marine-Permit Applications (submitted Months 12-15 = 2027-10-12 to 2028-01-12)
- Permit Approval Timeline Tracker (updated monthly)

**Dependencies:**

- Environmental Lead appointed
- Indigenous-Engagement Specialist and community researchers engaged
- NOAA, US Fish and Wildlife and Russian environmental agencies identified
- Funding approved for baseline surveys

### 36. Operations Council (Finance Manager lead) initiates investor-engagement process by Month 1 (2026-11-12). Identify and pre-qualify 5-10 target lenders and equity investors (development banks, infrastructure funds, export-credit agencies, non-US and non-Russian where possible). Conduct one-on-one meetings with each (Months 1-3 = 2026-11-12 to 2027-01-12) to understand sanctions policies, Arctic-project experience and term expectations. Issue preliminary Information Memorandum (Months 3-4 = 2027-01-12 to 2027-02-12) outlining project, deal structure and financial assumptions.

**Responsible Body/Role:** Finance and Commercial Manager (Operations Council voting member)

**Suggested Timeframe:** Month 0.5 (2026-10-27) to Month 4 (2027-02-12 to 2027-02-12)

**Key Outputs/Deliverables:**

- Target Lender and Investor List (5-10 identified, Month 1 = 2026-11-12)
- One-on-One Meeting Schedule and notes (Months 1-3 = 2026-11-12 to 2027-01-12)
- Preliminary Information Memorandum (Months 3-4 = 2027-01-12 to 2027-02-12)
- Lender Feedback Summary and deal-structure refinement

**Dependencies:**

- Finance Manager appointed
- Project Execution Plan and cost baseline available
- Financing structure (third-country consortium, debt/equity split) finalized

### 37. Finance Manager (Operations Council) hosts an Investor Roundtable (Months 4-5 = 2027-02-12 to 2027-03-12) presenting the project plan, deal structure and financial assumptions to identified lenders and investors. Field questions and assess lender interest in participating in later syndication and term-sheet negotiation. Consolidate lender feedback for deal-structure refinement.

**Responsible Body/Role:** Finance and Commercial Manager (Operations Council voting member)

**Suggested Timeframe:** Month 4 (2027-02-12) to Month 5 (2027-03-12 to 2027-03-12)

**Key Outputs/Deliverables:**

- Investor Roundtable Event (held Months 4-5 = 2027-02-12 to 2027-03-12)
- Presentation Materials (project overview, financials, risk summary)
- Lender Q&A Summary and feedback consolidation
- Refinement recommendations for deal structure and term sheet

**Dependencies:**

- Preliminary Information Memorandum completed
- Cost baseline and revenue assumptions available
- Target lenders and investors confirmed

### 38. Finance Manager (Operations Council) organizes a formal Financing Roadmap Workshop (Month 6 = 2027-04-12) with 2-3 target lead arrangers and the project Steering Committee. Align on financing structure (third-country SPV, debt/equity split, take-or-pay pre-sales, sanctions-licensing pathway), term expectations and gating conditions. Negotiate heads of terms with at least 2-3 lead arrangers (Months 6-9 = 2027-04-12 to 2027-07-12) to demonstrate lender confidence in financing viability.

**Responsible Body/Role:** Finance and Commercial Manager (Operations Council), with Steering Committee participation

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 9 (2027-07-12 to 2027-07-12)

**Key Outputs/Deliverables:**

- Financing Roadmap Workshop (Month 6 = 2027-04-12)
- Heads of Terms negotiation (Months 6-9 = 2027-04-12 to 2027-07-12)
- Heads of Terms (signed with 2-3 lead arrangers by Month 9 = 2027-07-12)
- Financing Structure Summary and path to Financial Close (Month 9 = 2027-07-12)

**Dependencies:**

- Investor Roundtable completed
- Cost basis and preliminary revenue assumptions available
- Sanctions-licensing pathway clarified by Compliance Officer
- Steering Committee established to oversee financing approvals

### 39. Steering Committee formally initiates Gate 1 review process (Month 6 = 2027-04-12). Gate 1 decision criteria include: (1) financing roadmap endorsed by 2+ lead lenders, (2) written OFAC/export-control guidance received, (3) traffic study and Cost Basis Document published, (4) treaty/framework negotiation complete or framework agreement in advanced negotiation. Gate 1 review meeting (Month 6 = 2027-04-12), with gate decision by Month 6.5 (2027-04-27) (proposed 2-4 week review, 1 week decision window). If Gate 1 passes, proceed to detailed design and permitting; if not passed, enter paid-pause protocol (3-6 month pause for remediation).

**Responsible Body/Role:** Steering Committee (chaired by Steering Committee Chair)

**Suggested Timeframe:** Month 5.5 (2027-03-27) to Month 6.5 (2027-04-27 to 2027-05-07)

**Key Outputs/Deliverables:**

- Gate 1 Pass/Fail Criteria Checklist (Month 5.5 = 2027-03-27)
- Gate 1 Review Meeting Agenda and documentation package
- Gate 1 Decision and Minutes (Month 6.5 = 2027-04-27)
- Gate 1 Approval Memo (if pass) or Paid-Pause Trigger (if fail)

**Dependencies:**

- Steering Committee established and operative
- Cost Basis Document and traffic study published
- OFAC guidance letter received
- Financing roadmap workshop and heads-of-terms negotiation complete

### 40. Indigenous Engagement Specialist finalizes Beringia Indigenous Council formation and supports negotiation of formal consent agreements with each identified Indigenous community (Months 6-12 = 2027-04-12 to 2027-10-12). Each community's legal advisor reviews consent-agreement scope and binding authority. Agreements must specify: (1) what decisions require consent, (2) what constitutes informed consent, (3) dispute resolution, (4) benefit-sharing. Secure >75% Council consensus and all community signatures by Month 12 (2027-10-12) (proposed gating condition for design freeze).

**Responsible Body/Role:** Indigenous Engagement Specialist (Operations Council supporting role) and Beringia Indigenous Council

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Beringia Indigenous Council monthly meeting minutes (Months 6-12 = 2027-04-12 to 2027-10-12)
- Formal Consent Agreements with each community (8-12 agreements, executed by Month 12 = 2027-10-12)
- Council consensus letter endorsing project alignment and mitigation measures (Month 12 = 2027-10-12)
- Benefit-Fund governance agreement and annual allocation plan

**Dependencies:**

- Beringia Indigenous Council formed and operative
- Community legal advisors in place
- EIS/EIA and baseline studies available for community review
- Design alignment and seasonal work-window schedule available

### 41. Operations Council (Design Lead - Bridge and Design Lead - Tunnel) initiates preliminary and critical design reviews. Preliminary design phase (Months 6-12 = 2027-04-12 to 2027-10-12) produces draft tower designs, cable analyses, tunnel element cross-sections and foundation layouts, incorporating ice, seismic and permafrost loads per observational-design methodology. Critical design review (Months 12-15 = 2027-10-12 to 2028-01-12) with independent external reviewers (HDR, Jacobs or equivalent) identifies safety risks and design adequacies before design freeze decision.

**Responsible Body/Role:** Design Lead - Bridge and Design Lead - Tunnel (Operations Council voting members)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 15 (2028-01-12 to 2028-01-12)

**Key Outputs/Deliverables:**

- Preliminary Design Report (bridge towers, cables, tunnel sections, Months 6-12 = 2027-04-12 to 2027-10-12)
- Preliminary Design Drawings (30% design-stage drawings)
- Critical Design Review Report (Months 12-15 = 2027-10-12 to 2028-01-12)
- Independent Design-Review Findings (external reviewer, 2-week turnaround after submission)
- Design-Freeze Readiness Assessment (data-confidence evaluation)

**Dependencies:**

- Design Leads appointed
- Ice-monitoring and geotechnical investigation data available
- Seismic hazard analysis complete
- Technical Advisory Group in place for expert input

### 42. Technical Advisory Group conducts formal design-adequacy review and certification (Month 15 = 2028-01-12). TAG assesses preliminary design, ice-load models, seismic-design assumptions and permafrost-thaw models for adequacy. If data confidence is within +/-15% (proposed threshold) and design safety margins are acceptable, TAG issues design-freeze certification. If confidence is wider or safety concerns exist, TAG recommends design-freeze deferral and extended monitoring (3-6 months). TAG findings documented in formal letter to Steering Committee.

**Responsible Body/Role:** Technical Advisory Group (chaired by TAG Chair)

**Suggested Timeframe:** Month 15 (2028-01-12)

**Key Outputs/Deliverables:**

- TAG Design-Adequacy Review Report (Month 15 = 2028-01-12)
- Ice-Load Certification (data quality and confidence level documented)
- Seismic and Permafrost Analysis Certification
- Design-Freeze Certification or Deferral Recommendation Letter
- TAG Consensus Summary (if any member dissents, dissent documented)

**Dependencies:**

- Technical Advisory Group established and operative
- Preliminary design complete
- Ice-monitoring and geotechnical data available (12-15 months of collection)
- Critical design review findings available

### 43. Steering Committee formally initiates Gate 2 review (Month 12 = 2027-10-12). Gate 2 criteria: (1) heads of terms signed with 2-3 lead arrangers, (2) Indigenous consent agreements executed and Beringia Council endorsed, (3) contractor bids within 5% of parametric baseline, (4) binational work-permit protocol agreed, (5) pilot element trial complete and successful. Gate 2 review meeting (Month 12 = 2027-10-12), with decision by Month 12.5 (2027-10-27) (proposed 2-3 week review). Pass/fail determines advance to design freeze or entry into paid-pause remediation.

**Responsible Body/Role:** Steering Committee (chaired by Steering Committee Chair)

**Suggested Timeframe:** Month 11.5 (2027-09-27) to Month 12.5 (2027-10-27 to 2027-11-07)

**Key Outputs/Deliverables:**

- Gate 2 Pass/Fail Criteria Checklist (Month 11.5 = 2027-09-27)
- Gate 2 Review Meeting documentation (heads of terms, consent agreements, bid summaries, pilot-trial results)
- Gate 2 Decision and Minutes (Month 12.5 = 2027-10-27)
- Gate 2 Approval Memo (if pass) or Paid-Pause Trigger (if fail)

**Dependencies:**

- Steering Committee operative
- Heads of terms signed with lead lenders
- Indigenous consent agreements finalized
- Pilot element trial complete (Months 9-12 = 2027-07-12 to 2027-10-12)
- Contractor bids or pre-qualification results available

### 44. Operations Council (Design Lead - Bridge and Design Lead - Tunnel) finalizes design freeze package incorporating TAG certification and independent-design review findings. Design-freeze meeting (Month 18 = 2028-04-12) with Technical Advisory Group, Steering Committee and independent reviewers. Steering Committee formally approves design freeze at Month 18 (2028-04-12) if TAG certification is issued and ice/seismic/permafrost data confidence thresholds are met. If TAG withholds certification due to data gaps, design freeze is deferred 3-6 months (paid pause triggered).

**Responsible Body/Role:** Operations and Execution Council (Design Leads, Owner's Engineer Integrator)

**Suggested Timeframe:** Month 15 (2028-01-12) to Month 18 (2028-04-12 to 2028-04-12)

**Key Outputs/Deliverables:**

- Final Design Package (60% design-stage drawings with all refinements)
- Design-Freeze Justification Memo (data adequacy, safety margins, TAG certification)
- Design-Freeze Meeting (Month 18 = 2028-04-12)
- Steering Committee Design-Freeze Approval Memo (Month 18 = 2028-04-12)
- Design-Frozen Documents package (signed and distributed to all parties)

**Dependencies:**

- Technical Advisory Group design-adequacy review complete
- Independent design review findings incorporated
- Ice-monitoring and geotechnical investigation data available (18 months collection)
- Preliminary design and critical design review complete

### 45. Steering Committee formally initiates Gate 3 review (Month 18 = 2028-04-12). Gate 3 criteria: (1) design freeze approved on data adequacy (ice-load confidence within +/-15%), (2) detailed marine permits issued or approval anticipated, (3) financial close scheduled by Month 24 (2028-10-12), (4) Indigenous consent agreements and Beringia Council governance finalized. Gate 3 review (Month 18 = 2028-04-12), decision by Month 18.5 (2028-04-27). Pass enables advancement to financial close and construction mobilization planning; fail triggers paid pause and extended permitting or design refinement.

**Responsible Body/Role:** Steering Committee (chaired by Steering Committee Chair)

**Suggested Timeframe:** Month 17.5 (2028-03-27) to Month 18.5 (2028-04-27 to 2028-05-07)

**Key Outputs/Deliverables:**

- Gate 3 Pass/Fail Criteria Checklist (Month 17.5 = 2028-03-27)
- Gate 3 Review Meeting documentation (design-freeze approval, permitting status, financial close roadmap)
- Gate 3 Decision and Minutes (Month 18.5 = 2028-04-27)
- Gate 3 Approval Memo or Paid-Pause Trigger

**Dependencies:**

- Steering Committee operative
- Design freeze approved by Operations Council
- Environmental and Permitting Lead confirms permit path
- Finance Manager confirms financial-close roadmap (Month 24 = 2028-10-12 target)

### 46. Finance Manager (Operations Council) drives Financial Close Phase: finalize debt and equity documentation (Months 18-24 = 2028-04-12 to 2028-10-12), obtain all lender and investor board approvals, execute financing agreements and secure all funds in escrow or committed facilities. Financial Close Milestone (Month 24 = 2028-10-12) requires execution of debt and equity agreements, proof of funds or irrevocable commitments from all lenders and equity investors, and release of initial funding tranches for construction mobilization.

**Responsible Body/Role:** Finance and Commercial Manager (Operations Council voting member)

**Suggested Timeframe:** Month 18 (2028-04-12) to Month 24 (2028-10-12 to 2028-10-12)

**Key Outputs/Deliverables:**

- Financing Documentation Package (credit agreements, equity agreements, security documents)
- Lender Board Approvals (obtained for each lead arranger)
- Equity Investor Board Approvals (obtained for each equity fund)
- Financial-Close Certificate (Month 24 = 2028-10-12, executed by lead arrangers and equity sponsors)
- Funding Tranches released to Project Account (proof of funds)

**Dependencies:**

- Heads of Terms signed with lead lenders (Month 9 = 2027-07-12)
- Design freeze approved (Month 18 = 2028-04-12)
- Permits (framework and detailed marine) obtained or approved
- Sanctions licensing confirmed (pre-approved supplier list available)

### 47. Compliance Officer (Risk Committee) confirms final Sanctions and Export-Control compliance (Months 18-24 = 2028-04-12 to 2028-10-12). Obtain written final OFAC and export-control licensing confirmation covering financing entities, equipment suppliers and personnel movement. Finalize Pre-Approved Supplier List by Month 24 (2028-10-12). Compliance Officer maintains ongoing OFAC/export-control monitoring and reporting throughout construction (Months 24-180 = 2028-10-12 to 2041-10-12), with quarterly compliance reviews.

**Responsible Body/Role:** Compliance Officer (Risk Committee, reporting to Risk and Compliance Committee Chair)

**Suggested Timeframe:** Month 18 (2028-04-12) to Month 24 (2028-10-12 to 2028-10-12)

**Key Outputs/Deliverables:**

- Final OFAC Licensing Confirmation Letter (Month 24 = 2028-10-12)
- Final Export-Control Licensing Pathway (EAR, ITAR, Russian controls approval)
- Pre-Approved Supplier and Contractor List (finalized by Month 24 = 2028-10-12)
- Ongoing OFAC Compliance Monitoring Protocol (quarterly reviews, Months 24-180 = 2028-10-12 to 2041-10-12)
- Sanctions Escalation Alerts (if regulatory environment changes)

**Dependencies:**

- Preliminary OFAC guidance received (Month 6 = 2027-04-12)
- Financing entities and suppliers finalized
- Lender OFAC compliance requirements confirmed

### 48. Steering Committee formally initiates Gate 4 review and decision (Month 24 = 2028-10-12). Gate 4 criteria: (1) framework agreement/concessions executed by both US and Russian governments, (2) sanctions licences confirmed in writing, (3) financial close achieved (funding in place), (4) construction mobilization plan approved. Gate 4 review (Month 24 = 2028-10-12), decision within 1 week (Month 24.25 = 2028-10-20). Pass authorizes construction mobilization (earliest Months 24-30 = 2028-10-12 to 2029-04-12). Fail triggers paid-pause exit provision (3-6 months paid pause, then exit if conditions not met by Month 30 = 2029-04-12).

**Responsible Body/Role:** Steering Committee (chaired by Steering Committee Chair)

**Suggested Timeframe:** Month 23.5 (2028-09-27) to Month 24.25 (2028-10-20 to 2028-10-19)

**Key Outputs/Deliverables:**

- Gate 4 Pass/Fail Criteria Checklist (Month 23.5 = 2028-09-27)
- Gate 4 Review Meeting (Month 24 = 2028-10-12, documentation: framework agreement, sanctions confirmation, financial-close certificate, mobilization plan)
- Gate 4 Decision and Minutes (Month 24.25 = 2028-10-20)
- Gate 4 Approval Memo (if pass) or Exit-Provision Trigger (if fail)

**Dependencies:**

- Steering Committee operative
- Framework agreement/concessions negotiated with US and Russian governments
- Financial close achieved (debt and equity executed)
- Sanctions licensing confirmed
- Construction mobilization plan prepared by Operations Council

### 49. Steering Committee Chair formally schedules and convenes the first Steering Committee Kick-Off Meeting (Month 3 = 2027-01-12) once the Charter is finalized and all voting members are appointed and confirmed. At this inaugural meeting: (1) Chair welcomes members and confirms decision authorities, (2) review project overview and governance structure, (3) present Detailed Project Execution Plan and gate schedule, (4) establish monthly-meeting cadence and committee norms, (5) discuss strategic risks and compliance requirements, (6) assign reporting responsibilities to Operations Council and committee members. Distribute meeting minutes and action items within 1 week.

**Responsible Body/Role:** Steering Committee Chair (with Project Manager support)

**Suggested Timeframe:** Month 3 (2027-01-12)

**Key Outputs/Deliverables:**

- Steering Committee Kick-Off Meeting Agenda and materials (Month 3 = 2027-01-12)
- Meeting Minutes and Action Items Log
- Steering Committee Member Handbook (governance, decision process, escalation)
- Monthly-Meeting Calendar (Months 3-24 = 2027-01-12 to 2028-10-12)
- Committee Communication Protocol (email, document sharing, confidentiality)

**Dependencies:**

- Steering Committee Charter finalized and signed
- All voting members appointed and confirmed
- Detailed Project Execution Plan published
- Project Sponsor briefed and expectations set

### 50. Operations and Execution Council Chair formally schedules and convenes the first Operations Council Kick-Off Meeting (Month 3 = 2027-01-12) once the Charter is finalized and all voting members are appointed. At this inaugural meeting: (1) Chair establishes weekly-meeting routine and norms, (2) review project execution plan and Operations Council authorities, (3) present design schedule, permitting roadmap and Indigenous-engagement milestones, (4) assign lead roles for each workstream (design, permitting, cost, Indigenous engagement, logistics), (5) establish reporting to Steering Committee (monthly high-level summaries), (6) discuss operational risks and change-control thresholds. Distribute minutes and action items within 2 business days.

**Responsible Body/Role:** Operations and Execution Council Chair

**Suggested Timeframe:** Month 3 (2027-01-12)

**Key Outputs/Deliverables:**

- Operations Council Kick-Off Meeting Agenda and materials
- Meeting Minutes and Action Items Log
- Operations Council Member Handbook (authorities, change control, escalation, interface management)
- Weekly-Meeting Calendar (Months 3-60 = 2027-01-12 to 2031-10-12)
- Operations Council Communication and Document-Sharing Protocol

**Dependencies:**

- Operations Council Charter finalized and signed
- All voting members appointed and confirmed
- Detailed Project Execution Plan published
- Steering Committee established

### 51. Technical Advisory Group Chair formally schedules and convenes the first TAG Kick-Off Meeting (Month 3 = 2027-01-12) once all TAG members are recruited and confirmed. At this inaugural meeting: (1) Chair welcomes members and clarifies TAG roles (expert advice, design-freeze certification, escalation of Major Issues), (2) review project technical scope and data-collection plans, (3) present ice-monitoring, geotechnical and seismic investigation schedules, (4) establish quarterly-meeting schedule (Months 3, 6, 9, 12, 15, 18 = 2027-01-12 to 2028-04-12), (5) define data-flow protocols from Operations Council (monthly raw data, design models), (6) discuss escalation thresholds for design-adequacy concerns. Minutes and action items distributed within 1 week.

**Responsible Body/Role:** Technical Advisory Group Chair

**Suggested Timeframe:** Month 3 (2027-01-12)

**Key Outputs/Deliverables:**

- TAG Kick-Off Meeting Agenda and materials
- Meeting Minutes and Action Items Log
- TAG Member Handbook (authorities, confidentiality, decision mechanism, escalation)
- Quarterly-Meeting Schedule and deliverables calendar (Months 3-18 = 2027-01-12 to 2028-04-12)
- TAG Data-Flow Protocol from Operations Council (monthly data delivery schedule)

**Dependencies:**

- Technical Advisory Group Charter finalized
- All TAG members recruited and confirmed
- Ice, geotechnical and seismic monitoring programs initiated (Month 0 = 2026-10-12)
- Operations Council established

### 52. Indigenous Engagement Specialist formally schedules and convenes the first Beringia Indigenous Council Meeting (Month 6 = 2027-04-12) after community participation commitments are secured. At this inaugural meeting: (1) Indigenous Council Chair facilitates opening and welcomes all community delegates, (2) Council Charter is reviewed and voted on by all member communities (>75% consensus required), (3) Council governance structure, decision process and dispute-resolution mechanism established, (4) monthly meeting schedule agreed (Months 6-12 = 2027-04-12 to 2027-10-12 during consent-agreement negotiation), (5) benefit-fund governance framework introduced, (6) project alignment and mitigation measures presented for community feedback. Minutes documented in English and Indigenous languages where applicable.

**Responsible Body/Role:** Indigenous Engagement Specialist and Beringia Indigenous Council Chair

**Suggested Timeframe:** Month 6 (2027-04-12)

**Key Outputs/Deliverables:**

- Beringia Indigenous Council Inaugural Meeting Agenda
- Meeting Minutes (in English and community languages)
- Council Charter Voted and Approved (>75% consensus)
- Council Member Roster and delegate contacts
- Monthly-Meeting Schedule (Months 6-12 = 2027-04-12 to 2027-10-12)
- Council Communication Protocol and confidentiality agreement

**Dependencies:**

- Community participation commitment letters obtained
- Beringia Council Formation Charter finalized
- Indigenous community legal advisors engaged
- Benefit-fund governance framework drafted

### 53. Risk, Compliance and Insurance Committee Chair formally schedules and convenes the first Risk Committee Kick-Off Meeting (Month 3 = 2027-01-12) once the Charter is finalized and all committee members are confirmed. At this inaugural meeting: (1) Chair establishes monthly-meeting cadence and risk-review process, (2) present comprehensive risk register (20-30 identified risks) with owners and mitigation actions, (3) define leading-indicator thresholds (cost >5%, schedule >2 months, DSCR <1.3x, OFAC delays >3 months), (4) establish risk-monitoring and escalation protocols to Steering Committee, (5) discuss insurance-procurement roadmap and political-risk insurance strategy, (6) define compliance checklist for NEPA/EIA, Indigenous consultation, export controls and permits. Distribute minutes and risk-register tracking sheet within 1 week.

**Responsible Body/Role:** Risk, Compliance and Insurance Committee Chair

**Suggested Timeframe:** Month 3 (2027-01-12)

**Key Outputs/Deliverables:**

- Risk Committee Kick-Off Meeting Agenda and materials
- Risk Register v1.0 (20-30 risks, owners, mitigations, escalation criteria)
- Leading-Indicator Dashboard (cost, schedule, covenant ratios, permitting tracking)
- Compliance Checklist (NEPA/EIA, Indigenous consultation, export controls, permits)
- Meeting Minutes and action items
- Monthly Risk-Reporting Template and schedule (starting Month 3 = 2027-01-12)

**Dependencies:**

- Risk Committee Charter finalized
- Compliance Officer and Risk Manager appointed
- Risk assessment or risk-file inputs available
- Steering Committee established (for escalation alignment)