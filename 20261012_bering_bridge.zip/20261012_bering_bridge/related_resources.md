## Suggestion 1 - Fehmarnbelt Fixed Link (Femern A/S), Denmark-Germany

Roughly 18 km immersed road-and-rail tunnel under the Baltic Sea between Lolland (Denmark) and Fehmarn (Germany), the world's longest immersed tunnel. Built under a 2008 bilateral state treaty, with Danish state-guaranteed financing repaid by user charges. Tunnel elements are cast at a purpose-built factory at Rødbyhavn and immersed in sequence. Construction started in 2020-2021; opening has been targeted around 2029-2031 after delays.

### Success Metrics

Treaty-based, state-guaranteed financing structure in operation (Femern A/S)
Largest immersed tunnel factory and element immersion programme under way; element counts published by Femern A/S
Opening date has slipped from the original target (approximate; check Femern A/S for the current date)
Cost baseline has been revised upward since approval (approximate; verify in Femern A/S reports)

### Risks and Challenges Faced

Treaty ratification and German planning litigation delayed start: addressed through a long permitting sequence and court rulings before construction.
Cost and schedule growth: addressed through re-baselining and state guarantees, with Femern A/S retaining owner control.
Immersed element factory and seabed prep complexity: addressed by a dedicated on-site factory and dredging contracts split by package.
Environmental objections (marine life): addressed by monitoring and mitigation programmes agreed in the permit.

### Where to Find More Information

https://femern.com (Femern A/S official site)
Danish Ministry of Transport documents on the Fehmarnbelt treaty (search 'Fehmarnbelt treaty 2008')
Femern A/S annual reports

### Actionable Steps

Contact Femern A/S (Copenhagen) via the communications or technical director office listed on femern.com to request a lessons-learned briefing on treaty, financing and immersion.
Approach the tunnel contractor consortium (Femern Link Contractors) via its public contact page for factory and immersion practice.
Search LinkedIn for Femern A/S project, technical and finance directors.

### Rationale for Suggestion

Closest analogue for a treaty-backed, state-guaranteed immersed tunnel with a factory-based element programme and a long permitting path. It informs the legal vehicle, gating, financing and immersion logistics. Not Arctic and not adversarial, so sanctions and ice lessons must come from other sources.
## Suggestion 2 - Hong Kong-Zhuhai-Macao Bridge (HZMB)

About 55 km bridge-tunnel link across the Pearl River Estuary, with a roughly 6.7 km immersed tunnel between two artificial islands. It crosses three jurisdictions with different legal systems, customs and driving rules. Construction ran about 2009-2017 and it opened in October 2018. Delivered by a joint authority with government-funded shares and bank loans.

### Success Metrics

Opened to traffic in October 2018 after about nine years of construction
Immersed tunnel of 33 elements installed between two artificial islands (verify in project papers)
Delays and cost overruns occurred; reported final cost is significantly above the original budget (approximate; verify)
Traffic volumes below early forecasts (reported; verify with HZMB Authority statistics)

### Risks and Challenges Faced

Three-jurisdiction seam (customs, driving side, liability): handled by a joint authority and island border facilities, with traffic-side conversion interchanges.
Soft seabed and last-joint installation difficulty: addressed by trial installations and a redesigned final joint (published in engineering papers).
Traffic forecast shortfall: demand ramp-up slower than planned; a lesson for demand underwriting.
Marine mammal (Chinese white dolphin) impact: addressed through monitoring and construction restrictions.

### Where to Find More Information

HZMB Authority official site (search 'Hong Kong-Zhuhai-Macao Bridge Authority')
Journals such as Tunnelling and Underground Space Technology and Engineering (search 'HZMB immersed tunnel')
Hong Kong Highways Department project pages

### Actionable Steps

Contact the HZMB Authority public enquiries channel for technical-visit or paper requests.
Contact Highways Department, Hong Kong (HZMB Hong Kong Link Road project office) for contract and interface lessons.
Contact the authors of published HZMB immersed-tunnel papers via their institutional email (check journal pages).

### Rationale for Suggestion

Best precedent for artificial islands joining an immersed tunnel and a long bridge across a multi-legal-system seam, with a joint authority. It informs interface control, island design and border handover. Warm-water and non-sanctions setting, so Arctic and financing lessons are weak.
## Suggestion 3 - Øresund Link (Øresundsbron), Denmark-Sweden

About 16 km road-and-rail fixed link made up of a bridge, an artificial island (Peberholm) and an immersed tunnel (Drogden). It opened in July 2000 under a 1991 bilateral treaty. A jointly owned company (Øresundsbron) financed the link with state-guaranteed loans, repaid from road and rail user fees. Both states hold border and customs functions at shore.

### Success Metrics

Opened in 2000; operating continuously as a binational user-pay link
State-guaranteed debt reportedly fully repaid ahead of the original profile (verify in Øresundsbron reports)
Annual traffic and rail ridership published by Øresundsbron
Single binational company model operating over two decades

### Risks and Challenges Faced

Initial traffic below forecast: addressed by ramp-up pricing, commuter products and regional integration (published in reports).
Two legal systems and currencies: addressed by a single treaty and a jointly owned company.
Environmental concerns about flow in the sound: addressed by a zero-effect-on-flow design requirement and monitoring (Peberholm island and bridge-height design).
Border control at shore: handled at plazas, closely matching the shore-plaza assumption.

### Where to Find More Information

https://www.oresundsbron.com (corporate and annual reports)
Öresundsbro Konsortiet and Danish and Swedish transport ministry documents on the 1991 agreement

### Actionable Steps

Contact Øresundsbron's corporate communications or finance unit via the site for the financing and traffic history.
Search LinkedIn for Øresundsbron CEO office, technical and finance directors.

### Rationale for Suggestion

A proven binational, state-guaranteed, user-pay link with a bridge, island and immersed tunnel, and a single operating company. It informs the tolling, joint ownership and shore-plaza border model. Setting is temperate and politically aligned; the sanctions and ice dimension is absent.
## Suggestion 4 - SECONDARY: Ferry-free E39 / Rogfast, Norway

Secondary suggestion. Norwegian Public Roads Administration programme to replace ferries on the E39 coastal route with fjord crossings. It includes Rogfast, an undersea road tunnel of about 27 km under construction, one of the longest and deepest of its kind, and studies of submerged floating tunnels and floating bridges. Cold-climate, offshore marine engineering with ice-free but harsh conditions.

### Success Metrics

Rogfast under construction, with progress reported by the Norwegian Public Roads Administration (Statens vegvesen)
Programme produces published feasibility studies for fjord crossings (verify on the agency site)

### Risks and Challenges Faced

Cost growth and schedule changes on Rogfast: addressed through re-baselining and state funding reviews (verify).
Novel technology risk for floating crossings: addressed through staged pilot and independent review.

### Where to Find More Information

Statens vegvesen (Norwegian Public Roads Administration) E39 and Rogfast project pages
Research from SINTEF and NTNU on Arctic and fjord crossings

### Actionable Steps

Contact the Statens vegvesen E39 project office through its public contact channel.
Approach SINTEF Ocean or NTNU researchers on ice and marine loads via institutional emails.

### Rationale for Suggestion

Relevant for cold-region marine tunnel engineering, observational design and staged technology risk. Secondary because it is single-nation and not ice-drift dominated.

## Summary

Phase 1 is a gated, sanctions-compatible rail-and-utility immersed tunnel on foundations sized for later spans. No direct precedent exists for a drifting-ice, seismic, binational crossing. The closest verified references are: Fehmarnbelt Fixed Link (Denmark-Germany; state-guaranteed financing, immersed tunnel, binational treaty), Hong Kong-Zhuhai-Macao Bridge (bridge-tunnel with artificial islands, three jurisdictions), Øresund Link (binational bridge-tunnel with a user-pay model and artificial island), and, as secondary, Norway's Rogfast / Ferry-free E39 programme (deep submerged and Arctic-adjacent immersed-tube and floating-bridge concepts). Geographic proximity to the Bering Strait is limited: no Arctic binational fixed link exists. Figures below are drawn from public sources and should be checked against the cited primary documents (not verified here).