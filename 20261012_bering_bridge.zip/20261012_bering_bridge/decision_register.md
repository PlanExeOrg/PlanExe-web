**8 open decisions: 5 high and 3 medium severity.** The most urgent decisions are the Phase 1 service and revenue basis, the overrun bearer and the pre-gate spend cap, all needed by about Month 3 (2027-01-12) before lender materials and early commitments. Until then the plan can safely proceed with SPV chartering, baseline surveys, community mapping, sanctions guidance requests and lender outreach, while avoiding charters, procurement and heads of terms.

| # | Decision | Severity | Owner | Decide by | Blocks |
|---|---|---|---|---|---|
| 1 | Phase 1 service definition and revenue basis | 🔴 High | Project Sponsor with Project Steering Committee | Month 3 (2027-01-12), before the information memorandum (Months 3-4 = 2027-01-12 to 2027-02-12) goes to lenders. | Gate 1 (Month 6 = 2027-04-12) lender endorsement and heads of terms at Month 9 (2027-07-12). |
| 2 | Overrun and shortfall bearer | 🔴 High | Project Sponsor and Project Steering Committee | Month 3 (2027-01-12) (written decision; Month 1 = 2026-11-12 charter clause as placeholder). | Heads of terms (Month 9 = 2027-07-12) and Gate 4 financial close (Month 24 = 2028-10-12). |
| 3 | Second spread or rescope | 🔴 High | Project Steering Committee with lead lenders | Month 12 (2027-10-12), the installation-rate decision after the pilot. | Heads of terms completion date and Gate 3 (Month 18 = 2028-04-12). |
| 4 | Pre-gate cap vs early commitments | 🔴 High | Project Sponsor | Month 3 (2027-01-12), before charters and team hiring begin and before the pilot lead times. | Gate 2 pilot trial (Months 9-12 = 2027-07-12 to 2027-10-12) and the spend cap compliance. |
| 5 | Latest close date vs ratification slip | 🔴 High | Project Steering Committee with Project Sponsor | Month 6 (2027-04-12), before Gate 1 and funder commitments. | Gate 4 (Month 24 = 2028-10-12) and paid-pause budget. |
| 6 | Government withdrawal rule | 🟡 Medium | Project Steering Committee with SPV board and counsel | Month 6 (2027-04-12), with framework negotiation completion at Gate 1. | Framework agreement text (Month 6 = 2027-04-12) and Gate 4. |
| 7 | Pilot authorization and permit sequence | 🟡 Medium | Project Steering Committee with SPV counsel | Month 6 (2027-04-12), before pilot fabrication commitments. | Pilot trial (Months 9-12 = 2027-07-12 to 2027-10-12) and Gate 3 permits (Month 18 = 2028-04-12). |
| 8 | Debt drawdown and construction-period financing | 🟡 Medium | Project Sponsor with lead arrangers | Month 9 (2027-07-12), at heads of terms. | Heads of terms (Month 9 = 2027-07-12) and Gate 4 financial close. |

## 1. Phase 1 service definition and revenue basis (🔴 High)

**Decision:** Should Phase 1 be scoped as a through-link (with the 49-65 km remainder funded), a stand-alone tunnel service re-based on its own evidenced revenue, or renamed so it claims no through-link?

**Why it is open:** Executive summary and canonical revenue (USD 8.9 billion/yr, USD 2.4 billion/yr surplus) assume a continuous link; Phase 1 covers only 20-36 km of 85 km and Phase 2 is not costed. Rail capacity criteria of 12-18 Mt/yr give only about USD 1.2-1.8 billion/yr at an illustrative USD 100/tonne.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Add a crossing method and cost for the remaining 49-65 km to Phase 1 scope and funding. | Funding requirement rises above USD 115 billion (estimate); debt, equity and DSCR resized; Month 180 (2041-10-12) less achievable. | alignment_remainder_open_decision, phase2_scope_and_timing, total_funding_requirement, phase1_scope. |
| B. Define a stand-alone Phase 1 service and re-base revenue and debt on the traffic study. | Debt falls (about USD 7.75 billion per USD 1 billion/yr); acceptance criteria derived from the Month 6 (2027-04-12) study; gates stay but sized lower. | required_annual_revenue, debt_amount, take_or_pay_target, acceptance criteria, executive summary. |
| C. Rescope or rename Phase 1 so commissioning does not claim a through-link. | Narrative honest, but strategic and trade-corridor case weakens; revenue still needs re-basing. | Executive summary, lender materials, phase1_scope. |

- **If nobody decides:** Month 6 (2027-04-12) traffic study and Gate 1 lender appetite test an undefined service; Month 9 (2027-07-12) heads of terms are likely missed.
- **Owner:** Project Sponsor with Project Steering Committee
- **Decide by:** Month 3 (2027-01-12), before the information memorandum (Months 3-4 = 2027-01-12 to 2027-02-12) goes to lenders.
- **Blocks:** Gate 1 (Month 6 = 2027-04-12) lender endorsement and heads of terms at Month 9 (2027-07-12).

## 2. Overrun and shortfall bearer (🔴 High)

**Decision:** Who bears cost overruns beyond the USD 15 billion contingency and revenue shortfalls: sponsor equity, government cash or availability payments, scope cut, or lender restructuring?

**Why it is open:** Canonical financing says governments give no cash and no budget cap is set, yet review and premortem rely on availability-payment backstops, subsidy and a USD 5-10 billion escrow. Dates conflict (Month 1 = 2026-11-12 vs Month 3 = 2027-01-12).

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Sponsor/consortium equity top-up commitment. | Equity above USD 46 billion (estimate) must be committed; may deter investors. | budget_cap_open_decision, equity_amount, cost_overrun_exposure. |
| B. Government availability payments or cash backstop. | Reverses the no-cash principle; requires framework agreement terms and may raise sanctions exposure. | financing_responsibility, framework agreement, debt_terms. |
| C. Phased scope cut and lender restructuring, no external backstop. | Overrun above USD 15 billion triggers rescope; lower lender comfort; Gate 4 risk. | budget_cap_open_decision, contingency rules, charter. |

- **If nobody decides:** Overrun beyond contingency stays unfunded and Gate 4 bids test lacks a named bearer.
- **Owner:** Project Sponsor and Project Steering Committee
- **Decide by:** Month 3 (2027-01-12) (written decision; Month 1 = 2026-11-12 charter clause as placeholder).
- **Blocks:** Heads of terms (Month 9 = 2027-07-12) and Gate 4 financial close (Month 24 = 2028-10-12).

## 3. Second spread or rescope (🔴 High)

**Decision:** Is the installation-rate shortfall solved by a funded second spread (USD 10-20 billion, estimate), a 60-70 element rescope, or an accepted later completion date?

**Why it is open:** Month 180 (2041-10-12) needs about 9 elements/season; the risk file supports 3-8. The second spread is outside the USD 115 billion model and no funder is named, while the executive summary claims the model is preserved.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Fund a second spread from added debt/equity. | Funding requirement rises by USD 10-20 billion (estimate); DSCR resized. | total_funding_requirement, debt_amount, delivery_resources. |
| B. Rescope to 60-70 elements and re-date. | Lower capex and earlier date; shorter tunnel, lower capacity and revenue. | phase1_tunnel_elements, phase1_capex_baseline, Month 180 (2041-10-12) target. |
| C. Keep single spread and restate completion later than Month 180 (2041-10-12). | Lender and government agreement needed on new date; more interest and overhead. | program_horizon, tunnel_installation_rate_gap, heads of terms. |

- **If nobody decides:** Month 180 (2041-10-12) stays unachievable and the preserved-model claim is removed; Month 18 (2028-04-12) pivot/cancel trigger applies.
- **Owner:** Project Steering Committee with lead lenders
- **Decide by:** Month 12 (2027-10-12), the installation-rate decision after the pilot.
- **Blocks:** Heads of terms completion date and Gate 3 (Month 18 = 2028-04-12).

## 4. Pre-gate cap vs early commitments (🔴 High)

**Decision:** Should the USD 150 million pre-gate cap be raised to cover pilot, vessel charters, yards and core team, or should those commitments be deferred until after financial close?

**Why it is open:** Canonical cap is USD 150 million through Month 24 (2028-10-12), but plan commits 4-6 ice-class vessels, a pilot at Months 9-12 (2027-07-12 to 2027-10-12) and a 100-150 person team. Four vessels at USD 0.5 million/day (proposed) is about USD 0.73 billion/yr, which exceeds the cap.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Cost the commitments and raise the cap and its funding. | Higher sunk cost at risk if gates fail; pilot stays at Months 9-12 (2027-07-12 to 2027-10-12). | pre_gate_spend_cap, delivery_resources, funding sources. |
| B. Defer charters and team build-up to after close; move pilot. | Cap holds; pilot and installation-rate evidence arrive later; Month 12 (2027-10-12) and Month 18 (2028-04-12) triggers shift. | delivery_resources, gate_2_month_12, premortem FM2/FM9 tripwires. |
| C. Use options and letters of intent only, with a small pilot scope. | Cap likely holds; weaker pilot evidence and binding capacity quotes. | delivery_resources, tunnel_installation_rate_gap evidence. |

- **If nobody decides:** Cap is breached or the pilot and charters silently slip; Gate 2 cannot be met as written.
- **Owner:** Project Sponsor
- **Decide by:** Month 3 (2027-01-12), before charters and team hiring begin and before the pilot lead times.
- **Blocks:** Gate 2 pilot trial (Months 9-12 = 2027-07-12 to 2027-10-12) and the spend cap compliance.

## 5. Latest close date vs ratification slip (🔴 High)

**Decision:** Does the Month 30 (2029-04-12) abandonment rule govern, or are the latest close date and spend cap extended with a funded pause budget to absorb a 12-36 month ratification slip?

**Why it is open:** Canonical exit is Month 30 (2029-04-12) and cap runs to Month 24 (2028-10-12); the schedule narrative plans around a 12-36 month slip that would land at Month 36-60 (2029-10-12 to 2031-10-12).

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Keep Month 30 (2029-04-12) as a hard exit; drop long slip from the schedule narrative. | Sunk cost capped; project ends if ratification is late. | ratification_slip_and_phase1_date, risk register. |
| B. Extend latest close and cap with a funded paid-pause budget. | Preserves option value; higher sunk cost and partner commitment fatigue. | paid_pause_and_exit, financial_close_target, pre_gate_spend_cap. |

- **If nobody decides:** Month 30 (2029-04-12) exit applies and burn in Months 24-30 (2028-10-12 to 2029-04-12) is uncovered by the cap.
- **Owner:** Project Steering Committee with Project Sponsor
- **Decide by:** Month 6 (2027-04-12), before Gate 1 and funder commitments.
- **Blocks:** Gate 4 (Month 24 = 2028-10-12) and paid-pause budget.

## 6. Government withdrawal rule (🟡 Medium)

**Decision:** If one government withdraws, is it a hard stop with asset preservation, or is a continuation arrangement defined and tested with counsel?

**Why it is open:** Plan review provides a unilateral operating agreement if withdrawal occurs by Month 12 (2027-10-12); the premortem says cancel on written withdrawal. Framework needs both governments and the alignment crosses the boundary.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Withdrawal is a hard stop; SPV preserves data and assets. | Simple and consistent with Gate 4; no continuation value. | plan review item 4, premortem FM6, SPV charter. |
| B. Define a continuation arrangement tested with counsel. | Needs legal work on alignment, landfall, licences and lender consent; may not be bankable. | framework agreement, legal_vehicle, gate_4_month_24. |

- **If nobody decides:** Cancel on withdrawal applies and the unilateral contingency is removed.
- **Owner:** Project Steering Committee with SPV board and counsel
- **Decide by:** Month 6 (2027-04-12), with framework negotiation completion at Gate 1.
- **Blocks:** Framework agreement text (Month 6 = 2027-04-12) and Gate 4.

## 7. Pilot authorization and permit sequence (🟡 Medium)

**Decision:** What authorization covers the Months 9-12 (2027-07-12 to 2027-10-12) pilot, and who holds detailed permits before the framework agreement is executed at Month 24 (2028-10-12)?

**Why it is open:** Pilot immersion precedes detailed marine permits (Months 12-18 = 2027-10-12 to 2028-04-12); heads of terms at Month 9 (2027-07-12) need a completion date that pilot data only supports at Month 12 (2027-10-12); SPV legal basis arrives at Month 24 (2028-10-12).

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Cover the pilot under framework permits and SPV standing. | Pilot timing holds; needs permit scope and legal standing agreed by Month 9 (2027-07-12). | permitting_sequence, legal_vehicle. |
| B. Move the pilot to after detailed permits. | Installation-rate data arrives about Month 18 (2028-04-12) or later; the Month 12 (2027-10-12) rate decision slips. | delivery_resources, gate_2_month_12, tunnel_installation_rate_gap. |
| C. Move Gate 3 permit milestone after the framework agreement. | Design freeze and close sequence change; likely later close. | gate_3_month_18, gate_4_month_24. |

- **If nobody decides:** Pilot proceeds without defined authorization or is delayed by about 12 months.
- **Owner:** Project Steering Committee with SPV counsel
- **Decide by:** Month 6 (2027-04-12), before pilot fabrication commitments.
- **Blocks:** Pilot trial (Months 9-12 = 2027-07-12 to 2027-10-12) and Gate 3 permits (Month 18 = 2028-04-12).

## 8. Debt drawdown and construction-period financing (🟡 Medium)

**Decision:** What drawdown profile applies, and are interest during construction and a grace period inside the USD 115 billion?

**Why it is open:** Debt service of about USD 4.75 billion/yr from Month 24 (2028-10-12) with revenue only from Month 180 (2041-10-12) implies about USD 62 billion (recomputed) outside the funding requirement; breach timing statements conflict.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Capitalise interest during construction and add to funding requirement. | Funding requirement rises well above USD 115 billion. | total_funding_requirement, debt_amount. |
| B. Grace period until commissioning with revised tenor. | Total debt cost higher; DSCR test starts at Month 180 (2041-10-12); lenders must accept. | debt_terms_and_service, dscr_sizing, review items 6 and 10. |
| C. Phased drawdown with revenue-first early income. | Lower interest but needs interim revenue not in plan. | financial model, debt_terms_and_service. |

- **If nobody decides:** Financial model carries an unfunded gap and heads of terms lack coherent terms.
- **Owner:** Project Sponsor with lead arrangers
- **Decide by:** Month 9 (2027-07-12), at heads of terms.
- **Blocks:** Heads of terms (Month 9 = 2027-07-12) and Gate 4 financial close.

## Choices made on your behalf

Set when the scenario was selected, not by you. Confirm or change them.

| Lever | Chosen | Strongest alternative | Why it matters | Revisit by |
|---|---|---|---|---|
| Crossing configuration | Rail-and-utility immersed tunnel first, with foundations sized for later suspension spans and road lanes. | Full hybrid with road and rail from first opening (The Pioneer's Span). | Sets capex, bankable scope and whether Phase 1 produces a through-link. | Month 6 (2027-04-12) (Gate 1), after the traffic study. |
| Ice-load and seismic design envelope | Observational design with several seasons of monitoring before design freeze. | Deterministic worst-case envelope with full redundancy. | Drives the Month 18 (2028-04-12) design freeze, foundation reserve and cost. | Month 18 (2028-04-12) (Gate 3). |
| Binational legal vehicle | Neutral third-country SPV with contractual government rights. | Bilateral treaty creating a joint authority. | Determines sanctions compatibility, ratification risk and withdrawal handling. | Month 3 (2027-01-12) (SPV charter). |
| Capital stack and financing | Third-country consortium of funds, development banks and ECAs; governments give no cash. | Sovereign equity and availability payments from both governments. | Sets who bears overruns and whether backstops exist. | Month 6 (2027-04-12) (Gate 1). |
| Political gating sequence | Explicit gates with 3-6 month paid pause and exit provisions. | Fixed program with early contracts, or cooperation-first confidence building. | Caps sunk cost but adds schedule risk and requires a pause budget. | Month 12 (2027-10-12) (Gate 2). |
