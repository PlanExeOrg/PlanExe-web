**Primary domain:** Bridge Engineering

**Secondary domains:** Arctic Engineering, Infrastructure Finance, Immersed Tunnel Engineering

**Rationale:** Bridge Engineering is the sole outcome-role candidate and owns the core deliverable, the 85 km bridge-tunnel crossing. Immersed Tunnel Engineering, Arctic Engineering, Infrastructure Finance and Megaproject Management are subordinate methods or constraints serving that crossing.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Bridge Engineering | 5 | 5 | outcome | Core deliverable is an 85 km suspension-bridge and immersed-tube tunnel crossing. |
| Immersed Tunnel Engineering | 5 | 5 | method | Immersed-tube tunnel segments are a core technical element requiring specialist subsea design and installation. |
| Arctic Engineering | 5 | 4 | constraint | Ice floes, permafrost, and seismic loads dictate foundation and structural design. |
| Geotechnical Engineering | 5 | 4 | method | Permafrost, seismic ground response, and foundation design govern the bridge piers and tunnel trench. |
| International Treaty Law | 5 | 4 | constraint | Binational joint ownership, jurisdiction, and permitting require a treaty-based legal framework across the US and Russia. |
| Infrastructure Finance | 4 | 4 | method | PPP, sovereign funds, and multilateral bank financing underpin the mega-project's viability. |
| Geopolitical Risk Management | 4 | 4 | constraint | Binational US-Russia sanctions, diplomacy and political tension strongly shape feasibility and governance. |
| Environmental Impact Assessment | 4 | 4 | constraint | Marine wildlife, permafrost and dual US-Russian environmental regulatory compliance are mandatory. |
| Megaproject Management | 4 | 3 | method | Phased delivery, logistics, and governance of a multi-decade binational infrastructure program. |