_Consistency: first pass found 2 high / 3 medium / 0 low contradictions. Repair: round 1: 21 edits → 1 high / 2 medium; round 2: 15 edits → 1 high / 3 medium. Published: round 1 (fewest high-severity issues). Shown below: the final check of the repaired documents (1 high / 2 medium / 0 low)._

## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Is there a written OFAC/export-control licensing pathway and pre-approved supplier list that accepts the neutral third-country SPV, with at least 2 lead lenders endorsing the financing roadmap? | Written OFAC/export-control pathway and supplier list by Month 6 (preliminary guidance Month 3); financing roadmap endorsed by 2+ lead lenders; written lender appetite of at least about USD 20 billion (estimate) at Month 6 (premortem tripwire). | OFAC/BIS guidance letter (request Month 2, preliminary Month 3, written pathway Month 6); written lender appetite letters from the 5-10 targets contacted from Month 1; roundtable feedback Months 4-5; government written positions on a framework-first agreement by Month 3. | Gate 1 fails: 3-6 month paid pause, then exit if still unmet. Do not sign heads of terms or commit procurement on an unlicensed structure, which is unbankable. Cost to date stays inside the USD 150 million (proposed threshold) cap. |
| 2 | Do independent traffic evidence and binding take-or-pay pre-sales support the USD 8.9 billion/yr conservative-case revenue needed to carry USD 69 billion of debt at DSCR >= 1.5x, enough to sign heads of terms with 2-3 lead arrangers? | Binding take-or-pay of 30-50% of expected revenue = about USD 2.7-4.5 billion/yr (proposed threshold); heads of terms signed with 2-3 lead arrangers by Month 9; conservative-case DSCR >= 1.5x; USD 1.5 billion/yr of non-binding interest is only an early-warning floor. | Independent traffic study findings and indicative tariff (Month 6); signed capacity contracts and lender term sheets (Month 9); lender model rerun at the revenue actually evidenced. | Heads of terms are not signed: debt capacity is about USD 7.75 billion per USD 1 billion/yr of revenue, so at USD 2 billion/yr about USD 99.5 billion stays unfunded. Rescope Phase 1 to evidenced revenue or enter a 3-6 month paid pause. Stop if no financial close by Month 30. Government availability-payment backstops need an explicit decision because the financing model excludes government cash. |
| 3 | Does the pilot-element trial and yard/vessel capacity evidence support about 9 elements per season at a funded single spread, or has a funded second spread or a 60-70 element rescope been approved? | About 9 elements/season needed for Month 180 (100 elements in about 11 seasons); 3-8 supported by the risk file; a lower measured rate requires a funded second spread (USD 10-20 billion, estimate, funder not yet named) or a 60-70 element rescope with a revised commissioning date agreed by lenders and governments. | Binding capacity quotes from 3-5 yards and a logic-based schedule model (Months 0-6); pilot-element trial results (Months 9-12); installation-rate decision at Month 12. | Month 180 is not achievable and must be restated. Either name the funder of the extra spread, or rescope to 60-70 elements and re-date. Pivot or cancel if the pilot fails twice or no funded spread or approved rescope exists by Month 18. |
| 4 | Have all mapped Indigenous communities signed consent agreements, with counsel opinions confirming the Beringia Council's legal standing in both jurisdictions? | Consent agreements signed by 100% of mapped communities at Month 12 (Gate 2); counsel opinions on Council standing by Month 3; stop floor of agreements covering communities with authority over more than 50% of the alignment by Month 18. | Community mapping (Month 1); Council charter (Months 3-6); signed consent agreements and legal opinions in the US and Russian regimes (Month 12). | Defer design freeze and detailed permitting, run funded mediation, and redesign the Council charter with explicit consent triggers. A holdout risks injunctions of 6-18 months (estimate). Pivot or cancel if the more-than-50% floor is not met by Month 18. |
| 5 | Do ice, seismic and permafrost data support a design freeze within +/-15% confidence, and are detailed marine permits issued, so that foundation commitments can begin? | Ice-load confidence within +/-15% certified by the Data Adequacy Committee at Month 18; detailed marine permits (Months 12-18) issued; 10-20% foundation reserve (proposed) judged sufficient. | 12-18 months of ice, seismic and permafrost monitoring; independent ice-mechanics review (Months 12-15); Data Adequacy Committee certification; NOAA, USFWS and Russian permit decisions by Month 18. | Block foundation and pier commitments and extend monitoring 3-6 months under a paid pause rather than freezing on the calendar. Pivot or cancel if confidence is still outside +/-15% after one more full ice season, beyond Month 30. |
| 6 | Is financial close achieved with the framework agreement executed by both governments, sanctions licences in writing, bids within 5% of the USD 100 billion baseline, and a named bearer for any overrun beyond the USD 15 billion contingency? | Gate 4 at Month 24, latest Month 30 after a paid pause: framework agreement and concessions executed, licences in writing, financial close of about USD 115 billion (USD 69 billion debt, USD 46 billion equity, estimate); bids within 5% of baseline; cumulative pre-gate spend <= USD 150 million (proposed threshold). | Executed framework text; OFAC/BIS licences; signed financing documents; Cost Basis Document and bid comparison (Months 6-12); sponsor decision on overrun ownership (requested by Month 3). | Paid pause of 3-6 months; if still unmet by Month 30, abandon Phase 1 and preserve data and the SPV. If bids exceed baseline by more than 5%, re-baseline or rescope before any mobilization. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: executive summary / project plan
    canonical: alignment_remainder_open_decision = About 49-65 km of the 85 km not covered by 20-36 km of immersed tube; crossing method for that remainder is undecided (estimate)
    observed:  Revenue USD 8.9 billion/yr and USD 2.4 billion/yr surplus assumed from Phase 1 alone
HIGH CF-002  document: self-audit item 11
    canonical: demand_and_tariff_gap = No traffic forecast or tariff in documents; at an illustrative USD 100/tonne, USD 8.9B/yr needs about 89 million tonnes/yr, not evidenced (estimate)
    observed:  Rail capacity 12-18 million tonnes/year
HIGH CF-003  document: executive summary
    canonical: total_funding_requirement = USD 115 billion (baseline 100 + contingency 15) (estimate)
    observed:  Second spread USD 10-20 billion (estimate) added on top; 'preserves ... USD 115 billion funding model'
HIGH CF-004  document: plan review (items 4, 9, 11) and premortem FM1/FM7
    canonical: financing_responsibility = Third-country consortium finances Phase 1 debt and equity; governments give land, rights-of-way and guarantees, no cash (decision)
    observed:  Government availability-payment backstop / subsidy and USD 5-10 billion escrow as recovery paths
HIGH CF-005  document: self-audit items 5/6 and premortem FM6
    canonical: paid_pause_and_exit = Each missed gate: paid pause of 3-6 months; if still unmet, parties may exit; Phase 1 abandoned if Gate 4 is not met by Month 30 (proposed threshold)
    observed:  Ratification slip of 12-36 months planned as float-absorbed schedule risk while pause/exit and cap end by Month 24-30
HIGH CF-006  document: premortem FM2/FM9 and project plan mitigation
    canonical: pre_gate_spend_cap = USD 150 million cumulative cap through Month 24 (expected USD 50-150 million) (proposed threshold)
    observed:  4-6 vessel multiyear charters by Month 9-12 and a 100-150 person core team before Month 24
HIGH CF-007  document: plan review item 3; premortem FM1/FM7
    canonical: take_or_pay_target = 30-50% of expected revenue pre-sold = about USD 2.7-4.5 billion/yr at USD 8.9 billion (proposed threshold)
    observed:  30% tested at Month 12; 20% at Month 18; unfunded gap of USD 20-30 billion at USD 5-6 billion/yr contracted
MEDIUM CF-008  document: plan review items 6 and 10 (and executive summary debt-service line)
    canonical: debt_terms_and_service = 30-year tenor, 5.5% (placeholder) -> annual debt service about USD 4.75 billion/yr (estimate)
    observed:  Debt service from close with revenue from Month 180; breach claimed at 12 months and 5-7 years post-close
MEDIUM CF-009  document: plan review items 5, 6, 13; premortem A2/FM2
    canonical: tunnel_installation_rate_gap = 100 elements in about 11 seasons needs about 9 per season vs 3-4 or 6-8; not achievable by Month 180 at a single spread (estimate)
    observed:  Thresholds of 6+, below 7, <= 6; Month 200-210 at 6-8/season; Month 230+ at 3-4/season; Month 150-160 'if single spread'
MEDIUM CF-010  document: plan review items 5/6/8; executive summary gate sequence
    canonical: gate_3_month_18 = Month 18: design freeze approved on data adequacy, detailed marine permits issued, financial close scheduled (proposed threshold)
    observed:  Completion date embedded at Month 9; permits at Month 18 before framework agreement at Month 24; pilot immersion Months 9-12
MEDIUM CF-011  document: plan review item 4
    canonical: gate_4_month_24 = Framework agreement/concessions executed by both governments, sanctions licences in writing, financial close achieved (proposed threshold)
    observed:  Unilateral operating agreement if one government withdraws
MEDIUM CF-012  document: plan review items 5 and 6
    canonical: gate_2_month_12 = Bids within 5% of parametric baseline (proposed threshold); contractor risk premium 15-25% (estimate)
    observed:  Premium 'embedded in the USD 100 billion baseline'; re-baseline at 10% by Month 12
```

### 1. Phase 1 revenue case depends on a through-link that Phase 1 does not build (🔴 High) — needs a project decision

- **Executive summary (Timeline and Budget; Overall Takeaway); canonical required_annual_revenue:** Phase 1 must earn about USD 8.9 billion/yr to carry USD 69 billion debt, and 'generates USD 2.4 billion/yr surplus post-commissioning' once commissioned at Month 180.
- **Project plan (SMART Specific; Related Goals); canonical alignment_remainder_open_decision, phase2_scope_and_timing:** Phase 1 is 20-36 km of an 85 km crossing; 'Decide crossing method for the remaining 49-65 km of alignment (estimate)' and 'The remaining alignment method is undecided'; Phase 2 is not costed.
- **Why it conflicts:** Rail, fiber and power revenue only exists if a continuous link across the strait exists, yet no document says how the 49-65 km remainder is crossed, funded or timed. The USD 115 billion funding and the revenue model therefore underwrite a service that is not defined.
- **Suggested resolution:** A project decision is needed. Options: (a) bring a crossing method and cost for the remainder into Phase 1 scope and the funding requirement; (b) define a stand-alone Phase 1 service and re-base revenue and debt on what that service earns, evidenced by the traffic study; (c) rescope or rename Phase 1 so its commissioning does not claim a through-link. State the choice in the executive summary and lender materials.

### 2. Proposed Phase 1 rail capacity vs tonnage needed for the revenue case (🔴 High) — needs a project decision

- **Canonical demand_and_tariff_gap; plan review item 1; premortem FM1:** At an illustrative USD 100/tonne all-in tariff, USD 8.9 billion/yr needs about 89 million tonnes/yr.
- **Self-audit item 11 (Mitigation):** Proposed Phase 1 acceptance criteria: 'Rail: capacity 12-18 million tonnes/year', fiber 2-4 Tbps, power 500-1000 MW.
- **Why it conflicts:** Recomputed: 12-18 Mt/yr x USD 100/t = USD 1.2-1.8 billion/yr, about 14-20% of the requirement. Fiber and power are not shown to supply the other roughly USD 7 billion/yr. Either the capacity criteria or the revenue requirement is wrong, and lenders would see both.
- **Suggested resolution:** Derive acceptance criteria from the traffic study and the USD 8.9 billion/yr requirement, or restate the required revenue and debt size to match a 12-18 Mt/yr service. Until then label the self-audit capacities as unconnected to the financing case.

### 3. Second spread (USD 10-20 billion) outside the 'preserved' USD 115 billion funding model (🔴 High) — needs a project decision

- **Executive summary (Overall Takeaway); canonical total_funding_requirement:** 'The plan preserves both the USD 115 billion funding model and the 85 km end-state ambition'; funding requirement is baseline 100 + contingency 15.
- **Executive summary (Risks); plan review item 1 and Review 5; project plan (Resources Required):** Commit 'second spread (USD 10-20 billion estimate)' or rescope by Month 12; 'second fabrication yard and tow-vessel fleet (estimated USD 10-20 billion additional capex)'. The baseline already lists '2+ fabrication yards and 4-6 ice-class tow vessels'.
- **Why it conflicts:** The second spread is in neither the USD 100 billion baseline nor the USD 15 billion contingency, which is already exposed to up to USD 15 billion of uncovered overrun. No funder is named, and debt (USD 69 billion) and DSCR are sized without it. The documents also do not define a 'spread': the baseline already has 2+ yards and 4-6 vessels, so what is added is unclear.
- **Suggested resolution:** A decision is needed on what a spread is economically and who finances it. Options: add it to the funding requirement and resize debt, equity and DSCR; fund it from sponsor equity; or choose the 60-70 element rescope instead. Until decided, remove the claim that the USD 115 billion model is preserved.

### 4. Governments give no cash, yet fallbacks and overruns rely on government money (🔴 High) — needs a project decision

- **Canonical financing_responsibility and budget_cap_open_decision:** Governments give land, rights-of-way and guarantees, no cash; the third-country consortium finances debt and equity. No budget cap or bearer is set.
- **Plan review items 4, 9, 11; premortem FM1 and FM7:** 'consider government availability-payment backstop (convert to subsidy model)'; 'seek availability-payment backstops'; overrun funded by '(b) government subsidy'; 'USD 5-10 billion escrow' for political loss; decision requested 'by Month 3' but to be embedded in the charter 'by Month 1'.
- **Why it conflicts:** Availability payments, subsidies and escrows are cash from governments or sponsors that the financing model excludes. The cover for up to USD 15 billion of uncovered overrun and for revenue shortfall is therefore unfunded. The overrun decision is dated Month 3 and also due earlier, at Month 1.
- **Suggested resolution:** Decide the overrun and shortfall bearer: sponsor equity top-up, government cash or availability payments (which changes the financing responsibility decision), phased scope cut, or lender restructuring. Until then describe backstops as unfunded options. Set one date, Month 3, for the written decision and the Month 1 charter clause only as a placeholder.

### 5. 12-36 month ratification slip vs Month 30 abandonment and Month 24 spend cap (🔴 High) — needs a project decision

- **Self-audit item 5; premortem FM6; canonical ratification_slip_and_phase1_date:** 'Ratification slip of 12-36 months (estimate) is the dominant schedule risk'; the 6-12 month float is planned to absorb delay; construction mobilizes Months 24-30.
- **Canonical paid_pause_and_exit and pre_gate_spend_cap; premortem FM1/FM6 stop rules; self-audit items 2, 5, 6:** Phase 1 is abandoned if Gate 4 is not met by Month 30; the USD 150 million cap runs only 'through Month 24', while paid pauses run to Month 30; 'if ratification slips >12 months beyond Month 24, trigger paid pause and rescope'.
- **Why it conflicts:** A 12-36 month slip after Month 24 lands at Month 36-60, but the stop rule ends the project at Month 30 (a 6-month allowance). The plan cannot both plan around a slip of that length and abandon at Month 30. Burn during Months 24-30 is not covered by the cap.
- **Suggested resolution:** Decide which governs. Either treat a slip beyond Month 30 as an exit trigger and drop it from the schedule-risk narrative, or extend the latest-close date and the spend cap with a funded paid-pause budget. Do not keep both.

### 6. USD 150 million pre-gate cap vs vessel charters, pilot element and core team (🔴 High) — needs a project decision

- **Canonical pre_gate_spend_cap; executive summary; project plan:** Cumulative pre-gate spend capped at USD 150 million through Month 24 (expected USD 50-150 million).
- **Project plan (Resources; Mitigation); plan review item 8; premortem FM2, FM9:** Multiyear charters of 4-6 ice-class tow vessels (USD 0.5-1.5 million/day proposed), pilot element fabricated and towed Months 9-12, 2+ yards, core team of 100-150 specialists; FM2 tripwire 'fewer than 4 vessels chartered at Month 12', FM9 'core team filled < 75% at Month 9'.
- **Why it conflicts:** Recomputed: 4 vessels x USD 0.5 million/day x 365 is about USD 0.73 billion/yr, several times the whole cap before the pilot element, yards, team and surveys. Either these commitments are not placed before Gate 4 or the cap is not USD 150 million. No document costs them.
- **Suggested resolution:** A decision is needed. Options: cost the pilot, charters, yards and team and raise the pre-gate cap (and its funding), or defer charters and team build-up to after financial close and move the pilot and its trigger dates. Remove charter/staffing tripwires inside the cap period if deferred.

### 7. Take-or-pay go/no-go threshold and timing; unfunded-gap arithmetic (🔴 High)

- **Executive summary (Action Orientation); canonical take_or_pay_target; plan review 8:** Pass threshold is 30-50% of expected revenue (USD 2.7-4.5 billion/yr) of binding take-or-pay at heads of terms, Month 9; USD 1.5 billion/yr is an early-warning floor for non-binding interest only.
- **Premortem A7, FM1, FM7; plan review item 3 (Recommended Actions):** Premortem tests signed take-or-pay '< 30% at Month 12' (FM1, FM7), a failure trigger of USD 1.5 billion/yr at Month 9 (A7), and a stop rule of 'below 20% ... at Month 18'; Review 3 says USD 2.7-4.5 billion/yr reduces the gap 'from USD 99.5 billion unfunded to USD 20-30 billion (at USD 5-6 billion/yr contracted)'.
- **Why it conflicts:** The same 30% test is applied at Month 9 and Month 12, with three levels (1.5 billion, 30%, 20%) of differing strength. The Review 3 figure is also off: recomputed at USD 7.75 billion debt per USD 1 billion/yr, USD 2.7-4.5 billion/yr supports about USD 21-35 billion debt, leaving about USD 80-94 billion unfunded, not USD 20-30 billion, and USD 5-6 billion/yr is outside the stated range.
- **Suggested resolution:** Keep the binding 30-50% as the heads-of-terms test at Month 9, align FM1/FM7 tripwires to Month 9 (with Month 12 as the Gate 2 re-check), and label USD 1.5 billion/yr and 20% explicitly as early-warning and last-resort stop levels. Correct Review 3 to the canonical debt-capacity multiple.

### 8. Debt service from close vs revenue from Month 180; no construction-period financing (🟡 Medium) — needs a project decision

- **Executive summary; canonical debt_terms_and_service, financial_close_target:** Annual debt service about USD 4.75 billion/yr on USD 69 billion, 30-year tenor, financial close Month 24; DSCR >= 1.5x.
- **Plan review items 6, 10; premortem FM2:** Revenue starts at commissioning, Month 180; breach 'within 5-7 years of financial close' (review 6) and 'by Month 72 (12 months post-close)' (review 10); 'debt service accrues without revenue' (FM2). No drawdown, interest-during-construction or grace period is given.
- **Why it conflicts:** If debt service is paid from close, Months 24-180 carry about 13 years x USD 4.75 billion = about USD 62 billion (recomputed) before any revenue, outside the USD 115 billion. If it starts at commissioning, the 5-7 year breach claim and the 30-year tenor need restating. Month 72 is 48 months after close, not 12.
- **Suggested resolution:** Decide the drawdown profile and whether interest during construction and a grace period are inside the USD 115 billion, then restate tenor, DSCR test start and breach timing consistently.

### 9. Installation-rate pass thresholds and revised completion dates (🟡 Medium)

- **Executive summary (Overall Takeaway); canonical tunnel_installation_rate_gap:** About 9 elements/season are needed for Month 180; 6-8 per season 'only supports a later date or a 60-70 element rescope'.
- **Plan review items 5, 6, 13; premortem A2, FM2:** Pass levels differ: 'lock 6+ by Month 12' (review 6), 'below 7' (A2), '<= 6' (FM2). 6-8/season 'enabling revised completion by Month 200-210'; 3-4/season gives 'Month 230+'; 'Month 150-160 ... if single spread'.
- **Why it conflicts:** A rate of exactly 6 passes one test and fails two, and none equals the 9 needed. Recomputed from Month 42: 100 elements at 6-8/season take 12.5-16.7 seasons, about Month 192-242, so Month 200-210 holds only near 7-8; 3-4/season takes 25-33 seasons, about Month 340+, not Month 230+. Month 150-160 requires the 60-70 element rescope, not a single spread.
- **Suggested resolution:** Use one test: about 9/season keeps Month 180; below that, state the recomputed completion or choose the rescope or a funded second spread by Month 12. Correct the date ranges and label Month 150-160 as the rescope case.

### 10. Pilot results, heads of terms and permit sequence (🟡 Medium) — needs a project decision

- **Plan review items 5, 6, 8; canonical gate_3_month_18:** Embed the revised Phase 1 completion date in lender heads of terms at Month 9; Gate 3 at Month 18 requires detailed marine permits issued.
- **Executive summary; project plan (Compliance Actions); canonical gate_4_month_24, permitting_sequence:** Pilot-element trial runs Months 9-12 and installation-rate data exist only at Month 12; the pilot is immersed in-water before detailed marine permits (Months 12-18); the framework agreement and sanctions licences are executed only at Month 24 (Gate 4).
- **Why it conflicts:** A completion date cannot be fixed at Month 9 from data that does not exist until Month 12. Permits are expected at Month 18 before the framework agreement and licences that give the SPV its legal basis (Month 24), and the pilot work precedes the detailed marine authorizations.
- **Suggested resolution:** Sign heads of terms at Month 9 with the completion date as a stated range and a re-opener after the pilot. A decision is needed on what authorization covers the pilot and who holds detailed permits before the framework agreement is executed: framework permits and SPV standing, or moving the pilot or Gate 3 permit milestone.

### 11. Government withdrawal: continue unilaterally vs cancel (🟡 Medium) — needs a project decision

- **Plan review item 4 (Showstopper Risk 1, Contingency):** 'If one government withdraws by Month 12, activate a unilateral operating agreement allowing the remaining government and consortium to proceed.'
- **Premortem FM6 stop rule; canonical gate_4_month_24:** 'Cancel if either government withdraws in writing.' The framework agreement must be executed by both governments, and Phase 1 spans the maritime boundary.
- **Why it conflicts:** One document treats withdrawal as a path to continue; the other makes it a stop rule. A one-sided arrangement is also not reconciled with concessions executed by both governments, shore plazas on both coasts and the neutral SPV.
- **Suggested resolution:** A decision is needed. Options: withdrawal is a hard stop and the SPV preserves assets; or a continuation arrangement is defined and tested with counsel (alignment, landfall, licences, lender consent). Until decided, remove the unilateral operating contingency.

### 12. Contractor premium embedded or not; 5% vs 10% re-baseline trigger (🟡 Medium)

- **Executive summary (Feedback); plan review item 3; canonical gate_2_month_12:** The 15-25% contractor premium (USD 15-25 billion) applies 'if applied to the baseline and not embedded in it'; Gate 2 tests bids within 5% of the parametric baseline.
- **Plan review items 5, 6, 7, 12; self-audit item 19:** '15-25% contractor risk-premium cushion embedded in the USD 100 billion baseline'; 're-baseline if cumulative variance exceeds 10% by Month 12'; elsewhere 5% at Month 12.
- **Why it conflicts:** Whether the premium is inside the baseline is stated as fact in one place and left open in another. If it is embedded, the baseline is not a neutral yardstick for the 5% test; if not, bids at +15-25% fail the 5% test by design. The re-baseline trigger is 5% in some documents, 10% in others, and 'rescope above 10%' and 'exit above 15%' in the self-audit.
- **Suggested resolution:** Treat the premium as unresolved until the Cost Basis Document (Month 6) states it. Keep 5% as the Gate 2 bid test; define 10% and 15% only as separately named rescope and exit triggers. Correct Review 5.

## Summary

Most earlier repairs held: the Month 180 target is now labelled unachievable at a single spread, the framework-agreement date is consistent at Month 24, and the Council's authority is partly qualified. What remains are structural gaps rather than typos. Phase 1 revenue is assumed for a link that Phase 1 does not complete, and the second spread, government backstops and overrun bearer sit outside the funding model. Several thresholds and arithmetic points in the review and premortem (take-or-pay timing, installation-rate levels, the cap versus commitments, the Month 30 exit, DSCR sensitivity) need aligning to the canonical values. Lower-order items not listed: O&M reserve basis (12-15% of revenue vs of surplus), Beringia Council timing (Months 3-6 vs Month 12) and a few month/calendar-date mismatches in the review.