# Governance Audit


## Audit - Corruption Risks

- Conflict of interest in vendor selection: contractors or suppliers favoring connected sub-suppliers or consultants in procuring tunnel elements, tow vessels, or fabrication services, circumventing competitive bidding and inflating costs by 5-10%.
- Bribery and approval capture: Indigenous community representatives or government permitting officials accepting payments or benefits from project sponsors in exchange for expedited consent, reduced environmental conditions, or favorable permit interpretations, compromising social license and regulatory validity.
- Nepotism in workforce recruitment and hiring: project management and technical staff filling apprenticeships, maintenance posts and safety-critical positions (divers, rescue personnel) with relatives or associates rather than qualified candidates, degrading safety and operational integrity in extreme Arctic conditions.
- Kickbacks from material suppliers to project procurement officials: international suppliers of Arctic-rated steel, concrete, cables or tunnel liners offering rebates or undisclosed commissions to drive orders toward higher-cost or lower-quality sources, embedding cost overruns and quality risk.
- Information asymmetry and misuse: government representatives, lenders or operator personnel exploiting privileged access to toll revenue forecasts, cost overruns, incident reports or crossing-availability data to trade currencies, adjust tariffs, or time maintenance windows for personal gain.
- Double-dealing and regulatory capture: binational governance officials acting simultaneously as advisors to the SPV and representatives of their home governments, using dual roles to influence toll rates, closure authority or incident-response decisions in ways that benefit financial interests rather than public safety or treaty obligations.

## Audit - Misallocation Risks

- Budget misuse for non-project overhead: soft-cost allocations (consulting, legal, engineering fees, mobilization) inflated to 20-30% of early spending before construction, with insufficient cost-control discipline, consuming the USD 50-150 million pre-gate budget cap without delivering surveys or permits.
- Double-spend on surveys and baseline studies: geotechnical drilling, ice-monitoring instrumentation and marine-mammal baseline work initiated by both US and Russian agencies independently, without coordination, duplicating effort and wasting 10-20% of Month 0-12 (2026-10-12 to 2027-10-12) survey allocations.
- Misallocation of contingency reserves: the 15% (USD 15 billion) contingency pool drawn down for forecast cost-growth or change orders before reserves are truly needed, leaving insufficient buffer for genuine emergencies (ice damage, seismic discovery, supply-chain failure) by Months 30-60 (2029-04-12 to 2031-10-12).
- Unauthorized use of project vehicles and equipment: Arctic logistics assets (icebreakers, tow vessels, camp generators, fuel stockpiles) repurposed for unrelated scientific research, Indigenous community support or government agency operations without formal recharge, eroding project cost and availability.
- Poor record-keeping and progress misreporting: monthly construction progress reports inflating tunnel-element installation counts (claiming 6 per season when actual is 3-4), causing lender disbursement overstatement and masking schedule compression risk until final-phase acceleration becomes impossible.
- Misreporting of revenue and tolling data: operator or toll-collection contractor under-reporting crossing traffic volumes, fuel surcharge collections or fiber lease revenue by 5-15%, with proceeds diverted to undisclosed maintenance or personnel accounts, degrading debt-service visibility and covenant compliance.

## Audit - Procedures

- Quarterly external audit of cost and schedule performance (Months 6, 12, 18, 24, 30 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12, 2029-04-12 onwards): independent review of expenditure against budget by category (design, surveys, fabrication, logistics), schedule variance by phase, and change-order log; flag overruns >5% at each gate for mandatory reforecasting and lender repricing.
- Post-gate compliance certification (Months 6, 12, 18, 24 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12): independent auditor reviews gate-clearance criteria (treaty status, sanctions licensing confirmation, permit status, Indigenous consent, lender heads-of-terms) against documented checklist; certify pass/fail before capital release.
- Annual supply-chain and procurement audit (Months 6, 18, 30, 42 = 2027-04-12, 2028-04-12, 2029-04-12, 2030-04-12 onwards): review supplier pre-qualification documentation, force-majeure and substitution clauses, sanctions-compliance vetting, and actual sourcing patterns; flag single-source dependencies and unlicensed purchases.
- Semi-annual financial-controls audit (Months 12, 24, 36 = 2027-10-12, 2028-10-12, 2029-10-12 onwards): test cost accounting for allocations to correct phase, contingency tracking and release protocols, debt-service reserve adequacy, and toll/revenue collection and reconciliation (if operations phase reached).
- Ad-hoc ice, seismic and permafrost monitoring-data audit (Months 9, 15, 21 = 2027-07-12, 2028-01-12, 2028-07-12): independent glaciologist and geotechnical engineer review raw monitoring data, statistical analysis, and load-model calibration; certify data quality and design assumptions before design-freeze gates.
- Binational governance and contract-administration audit (Months 12, 24, 36 = 2027-10-12, 2028-10-12, 2029-10-12 onwards): independent review of interface-control documents, change-order justifications and approvals across contractors and jurisdictions; identify unresolved disputes and liability-allocation gaps at the maritime seam.

## Audit - Transparency Measures

- Monthly project dashboard (public and lender-access versions): cost and schedule variance by phase, contingency remaining, gate-clearance milestones, permits obtained, Indigenous-agreement status, lender and investor participation status; publish non-sensitive summary on a dedicated project website by Month 6 (2027-04-12) onwards.
- Published quarterly gate-review minutes: Steering Committee and advisory-body meetings (Months 6, 12, 18, 24 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12 onwards) documented and published with >30-day lag, identifying decisions, dissents, gate criteria assessed, and dates for next review; redact commercially sensitive cost details but disclose all go/no-go decisions.
- Documented supplier pre-qualification and sanctions-compliance public summary (Month 6 = 2027-04-12): list approved fabrication yards, tow-vessel operators and key material suppliers with their Arctic experience, sanctions-vetting status and force-majeure terms; update quarterly and publish redacted version.
- Annual Indigenous-benefits and environmental-monitoring report (Months 12, 24, 36 = 2027-10-12, 2028-10-12, 2029-10-12 onwards post-gate-2): document Indigenous workforce hiring, training and wage data; subsistence-protection fund disbursements and projects; environmental baseline findings and incident reports (noise exceedances, wildlife interactions); publish with community co-signature.
- Neutral arbiter incident and dispute-resolution log (Months 24 onwards, construction phase): document all operational incidents (ice damage, seismic events, tunnel fire drills, closure decisions) and disputes escalated to neutral arbiter; publish redacted log quarterly to demonstrate transparent governance and decision authority.
- Whistleblower and grievance mechanism with public disclosure of themes (quarterly, Months 6 onwards): establish anonymous reporting channel for cost overruns, safety lapses, Indigenous-impact concerns or procurement irregularities; publish quarterly summary of allegations received and disposition (investigated/dismissed/remedied) without identifying individuals unless criminal referral is made.

# Internal Governance Bodies

### 1. Project Steering Committee

**Rationale for Inclusion:** This binational, 85 km Arctic megaproject with USD 115 billion funding, 15-year horizon, geopolitical risk and cross-jurisdictional delivery requires executive-level strategic oversight. The Steering Committee provides high-level direction on political gating, financing, treaty negotiation, Indigenous engagement and strategic risk management—decisions exceeding operational authority and requiring sovereign-level coordination. Monthly meetings ensure alignment across the neutral SPV owner, both governments and lead lenders during critical phases (Months 0–24 = 2026-10-12 to 2028-10-12).

**Responsibilities:**

- Approve gate-clearance criteria and decisions at Months 6, 12, 18, 24 (2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12)
- Oversee treaty negotiation, framework agreement and sanctions-licensing pathway; coordinate US and Russian government engagement
- Approve financing structure, lender terms and debt covenants; monitor debt service coverage and financial performance
- Monitor strategic risks (political tension, sanctions escalation, ratification slip) and authorize mitigation or exit provisions
- Review and approve Indigenous consent agreements, benefit-fund allocation and cultural-impact mitigation programs
- Endorse design envelope (ice load, seismic, permafrost assumptions) and approve design-freeze gates based on data adequacy
- Authorize capital deployment and contingency releases; escalate cost overruns >5% for repricing or gate deferral

**Initial Setup Actions:**

- Charter the neutral third-country SPV and establish bylaws specifying voting, decision authority and reporting (Month 0 = 2026-10-12)
- Negotiate and execute Steering Committee charter with explicit authority matrix, meeting cadence, quorum and escalation protocols (Months 0–3 = 2026-10-12 to 2027-01-12)
- Identify and appoint chair (proposed: neutral party, not aligned with either government) and define vice-chair roles for US, Russian and lender representation
- Establish gate-clearance checklist and pass/fail criteria for each of the four gates (Months 0–3 = 2026-10-12 to 2027-01-12)
- Define escalation path to diplomatic or arbitration channels if Steering Committee decisions deadlock (Months 0–3 = 2026-10-12 to 2027-01-12)
- Schedule and publish gate-review calendar (Months 6, 12, 18, 24 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12) and define gate-decision timeline (typically 2–4 weeks for review and 1 week for final decision)

**Membership:**

- Chair: Neutral independent (e.g., retired senior infrastructure executive or diplomat)
- SPV shareholder representative(s): nominee from neutral entity's board
- US government representative: US Department of Transportation or equivalent senior official
- Russian government representative: Russian Ministry of Transport or equivalent senior official
- Lead lender representative(s): 2–3 heads of arranging development banks or infrastructure investors (rotating quarterly or fixed term)
- Independent technical advisor (observing, non-voting): nominated by lender consortium or bridge engineering society to flag technical risks

**Decision Rights:** Steering Committee approves all gate-clearance decisions (Months 6, 12, 18, 24 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12) on criteria documented in the gate-clearance checklist. It approves financing terms, debt covenants and capital deployment authority. It endorses strategic decisions on design envelope, Indigenous benefit agreements and political gating strategy. Decisions requiring two-government consensus (treaty, framework agreement, sanctions licensing pathway) are escalated to diplomatic channels if Steering Committee deadlocks after two meetings on the same issue.

**Decision Mechanism:** Consensus preferred. If consensus fails on a gate-clearance decision or strategic choice, a simple majority vote (>50% of voting members) decides, with the abstention rule: abstention counts as absent, not as dissent. Tie-breaker: if voting members split 2–2 (US + Russia vs. lenders + neutral), the neutral chair casts a tie-breaking vote in favor of most recent motion unless reversing an earlier gate-clearance decision (which requires majority re-vote to overturn). Two-government consensus required for decisions affecting treaty or concession terms; if either government votes no, escalate to diplomatic channels within 2 weeks for resolution or exit.

**Meeting Cadence:** Monthly during Months 0–24 (2026-10-12 to 2028-10-12) (critical phases: pre-gate planning and gate-clearance reviews). Bi-monthly during Months 25–60 (2028-11-12 to 2031-10-12) (construction mobilization phase). Quarterly during Months 60–180 (2031-10-12 to 2041-10-12) (operations and Phase 2 planning). Emergency meetings may be called within 48 hours if a force-majeure or covenant-breach event occurs.

**Typical Agenda Items:**

- Gate-readiness status and clearance-criteria checklist (all meetings; formal vote at gate months)
- Financing update: lender engagement status, term negotiations, debt service coverage, covenant compliance
- Political and regulatory status: treaty/framework progress, OFAC/export-control licensing, permit milestones, Indigenous consent
- Strategic risks: geopolitical developments, sanctions escalation, Indigenous disputes, cost trends and schedule variance
- Design envelope review: ice/seismic/permafrost monitoring data summary, design-freeze adequacy assessment
- Contingency and budget status: cost overruns, change-order log, contingency remaining, repricing triggers

**Escalation Path:** Steering Committee deadlock on gate-clearance decisions (two inconclusive meetings) or strategic choices requiring two-government consensus escalate to a Neutral Arbitration Panel (appointed Month 3 = 2027-01-12, comprising one arbiter each from US and Russia + one neutral international arbiter, with binding authority under a dispute-resolution clause). If arbitration deadlock on ratification or treaty matters, issue escalates to senior diplomatic channels (US State Department, Russian Foreign Ministry) with 2-week resolution window; if unresolved, triggers a paid pause and exit gate (Months 6, 12, 18, 24 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12 decision window).
### 2. Operations and Execution Council

**Rationale for Inclusion:** Operational and technical delivery—design, permitting, surveys, procurement, Indigenous engagement and construction planning—requires day-to-day coordination distinct from strategic oversight. The Operations and Execution Council manages design freeze, cost and schedule performance, interface control, contractor management and risk mitigation actions below Steering Committee thresholds. It operates under the Steering Committee's strategic authority and reports monthly on performance, alerts and escalations. Ensures consistency across design, logistics, safety and Indigenous consultation during the critical Months 0–30 (2026-10-12 to 2029-04-12) pre-construction phase and into delivery.

**Responsibilities:**

- Manage design development and design-freeze gate criteria; oversee ice-monitoring, seismic surveys and permafrost investigations supporting design adequacy (Months 0–18 = 2026-10-12 to 2028-04-12)
- Own cost and schedule baseline: manage Cost Basis Document, parametric estimates, contractor bids and change-control process; flag variance >5% for repricing
- Coordinate environmental and marine-mammal baseline surveys with Indigenous observers; track permit progress (framework Months 6–9 = 2027-04-12 to 2027-07-12, detailed Months 12–18 = 2027-10-12 to 2028-04-12)
- Manage interface-control documents between span, tunnel and island systems; chair monthly Interface Control Board (Months 6–60 = 2027-04-12 to 2031-10-12)
- Oversee Arctic construction logistics planning: fabrication yards, tow-vessel procurement, pilot element trial (Months 9–12 = 2027-07-12 to 2027-10-12) and seasonal-window analysis
- Coordinate Indigenous stakeholder engagement: support Beringia Council formation, fund baseline studies and document consent agreements (Months 0–12 = 2026-10-12 to 2027-10-12)
- Manage technical risk: ice-load and seismic-design contingencies, observational-design protocols, data-adequacy gates and design-refinement schedules

**Initial Setup Actions:**

- Appoint Owner's Engineer Integrator and Core Engineering Team (100–150 specialists, proposed) by Month 0 (2026-10-12); establish governance roles and approval matrices
- Develop and publish detailed project execution plan, including design schedule, permitting roadmap, Indigenous-engagement milestones and cost/schedule baseline (Months 0–3 = 2026-10-12 to 2027-01-12)
- Commission parametric cost model from Arctic-construction specialists (Month 3 = 2027-01-12); establish Cost Basis Document and publish for contractor feedback by Month 6 (2027-04-12)
- Establish Interface Control Board charter and monthly meeting cadence; define interface-control document approval process and design-change authority (Months 3–6 = 2027-01-12 to 2027-04-12)
- Launch ice, seismic and permafrost monitoring instrumentation and geotechnical drilling (Month 0 = 2026-10-12); establish data-collection and analysis protocols with independent verification by Month 3 (2027-01-12)
- Coordinate Indigenous stakeholder mapping (Month 1 = 2026-11-12) and fund community legal/technical advisors; establish Beringia Council formation schedule (Months 3–6 = 2027-01-12 to 2027-04-12)

**Membership:**

- Owner's Engineer/Integrator: senior engineer with Arctic and megaproject experience (full-time lead, voting)
- Cost Engineer: manages parametric estimates, change control and budget tracking (full-time, voting)
- Design Lead (Bridge and Tunnel): senior structural and immersed-tunnel engineer (full-time, voting)
- Environmental and Permitting Lead: coordinates EIS/EIA, marine-mammal baseline and regulatory compliance (full-time, voting)
- Indigenous Stakeholder Lead: funds and coordinates Beringia Council, benefit programs and consent agreements (full-time, voting)
- Construction Logistics Lead: Arctic fabrication yards, tow-vessel procurement and supply-chain risk (full-time, voting)
- Finance and Commercial Manager: debt covenants, take-or-pay contracts, revenue forecasting and lender reporting (part-time, voting)
- Representatives from US and Russian government agencies (observing, non-voting input)

**Decision Rights:** Operations Council approves design refinements and parametric-cost updates that do not exceed pre-approved contingency thresholds (decisions within 5% cost variance require internal approval; >5% variance escalates to Steering Committee). It approves change orders up to USD 10 million (proposed threshold); changes >USD 10 million or schedule slip >2 months escalate to Steering Committee. It approves interface-control documents and contractor procurement recommendations up to pre-qualified baseline; deviation from baseline suppliers requires Steering Committee approval (sanctions or export-control impact). Design-freeze decisions are made by Operations Council if ice/seismic data confidence is within +/-15% (proposed threshold); if confidence is wider, design freeze is deferred and escalated to Steering Committee for gate postponement decision.

**Decision Mechanism:** Consensus among voting members preferred. If consensus fails, a simple majority (>50%) decides. Specific decision subjects have tie-breakers: (1) Design-freeze adequacy: Owner's Engineer Integrator casts tie-breaking vote if tied. (2) Cost or schedule variance: Finance Manager's reforecast is the tie-breaker. (3) Interface conflicts: neutral external arbiter (appointed Month 6 = 2027-04-12, an experienced megaproject integrator) mediates and decides within 2 weeks if Operations Council cannot resolve. Design-freeze deferred if Owner's Engineer Integrator votes no on data adequacy (veto on safety/engineering grounds).

**Meeting Cadence:** Weekly during Months 0–24 (2026-10-12 to 2028-10-12) (critical pre-construction and gate-clearance phase). Bi-weekly during Months 25–60 (2028-11-12 to 2031-10-12) (construction mobilization and early delivery). Monthly during Months 60–180 (2031-10-12 to 2041-10-12) (construction and operations phase). Ad-hoc meetings on cost >5% variance, schedule slip >2 months or safety/permitting alerts.

**Typical Agenda Items:**

- Cost and schedule performance: variance analysis, change-order log, contingency status, bid evaluations and repricing triggers
- Design development: ice/seismic/permafrost monitoring-data summary, design-refinement progress, design-freeze readiness assessment
- Permitting and environmental: baseline survey progress, regulatory feedback, permit application status, marine-mammal monitoring and incident log
- Interface-control and contractor coordination: ICB decision log, unresolved interface conflicts, supplier pre-qualification and long-lead procurement status
- Indigenous engagement: Beringia Council formation progress, consent-agreement negotiations, baseline-study co-authoring and benefit-fund design
- Arctic logistics: fabrication-yard pre-qualification, tow-vessel procurement, pilot-element trial schedule and supply-chain risk alerts

**Escalation Path:** Operations Council deadlock on design-freeze decisions or interface conflicts escalates to the neutral external arbiter (independent megaproject engineer with binding authority, appointed Month 6 = 2027-04-12) for decision within 2 weeks. Cost or schedule variance >5% or change orders >USD 10 million escalate to Steering Committee within 1 week. Permitting or Indigenous-consent delays >3 months escalate to Steering Committee for policy review or gate deferral. Safety or technical-adequacy concerns raised by Owner's Engineer Integrator trigger immediate escalation to Steering Committee and an external independent design review (Months 12–15 = 2027-10-12 to 2028-01-12) within 2 weeks.
### 3. Technical Advisory Group

**Rationale for Inclusion:** This Arctic megaproject faces unprecedented technical unknowns: ice-floe loads, seismic-permafrost interaction, immersed-tube tunnel innovation in Arctic conditions, and observational design dependent on 12–18 months of sparse monitoring data. The Technical Advisory Group provides independent specialized input on load assumptions, design adequacy and safety margins—separating expert assessment from operational delivery and political pressure. Members include world-class ice mechanics, seismic engineers, tunnel specialists and Arctic construction experts from research institutions and peer projects, meeting quarterly during design phases (Months 0–18 = 2026-10-12 to 2028-04-12) and semi-annually during construction.

**Responsibilities:**

- Review and validate ice-monitoring data, ice-load models and design assumptions at Months 9, 15, 21 (2027-07-12, 2028-01-12, 2028-07-12); certify data quality and confidence levels for design-freeze gates
- Conduct independent design review of suspension-bridge towers, cables and immersed-tunnel elements (Months 12–15 = 2027-10-12 to 2028-01-12); identify safety, constructability and long-term durability risks
- Assess seismic hazard analysis, ground-response modeling and permafrost-thaw scenarios; recommend design contingencies and monitoring protocols (Months 6–12 = 2027-04-12 to 2027-10-12)
- Review Arctic construction methods (vibratory vs. impact piling, bubble-curtain acoustics, thermal-stabilization techniques); advise on technical feasibility and compliance with marine-mammal limits
- Validate pilot-element trial results and immersed-tube-tunnel installation procedures (Months 9–12 = 2027-07-12 to 2027-10-12); recommend design or process refinements before full-scale production
- Provide objective assessment of design-envelope trade-offs (deterministic vs. observational, conservative vs. performance-based); advise Steering Committee on safety margin and cost-risk balance

**Initial Setup Actions:**

- Recruit Technical Advisory Group chair: world-class ice or tunnel engineer (e.g., National Academy member with Arctic megaproject experience) by Month 0 (2026-10-12)
- Identify and invite 8–12 specialists (propose: 2–3 ice mechanics experts, 2 seismic/permafrost engineers, 2 immersed-tunnel designers, 2 Arctic construction specialists, 1–2 independent engineering-review firms) by Month 1 (2026-11-12)
- Execute engagement agreements and define confidentiality, conflict-of-interest vetting and fee structure by Month 3 (2027-01-12)
- Schedule quarterly review meetings (Months 3, 6, 9, 12, 15, 18 = 2027-01-12, 2027-04-12, 2027-07-12, 2027-10-12, 2028-01-12, 2028-04-12) and specify deliverables for each (interim letters, formal reports, gate-readiness certifications)
- Establish data-flow protocols: Operations Council provides raw monitoring data, design models and test results monthly; TAG reviews asynchronously and flags concerns at monthly internal calls before formal reviews
- Define escalation criteria: if TAG raises a Major Issue (safety concern, design-adequacy doubt, data-confidence shortfall), require Steering Committee notification within 5 business days

**Membership:**

- Chair: Independent world-class Arctic or tunnel engineer, non-aligned with contractors or government (voting, advisory authority)
- Ice Mechanics Expert(s): 2–3 specialists from universities or national laboratories with Arctic field experience and ice-load modeling expertise (e.g., University of Alaska, Canadian National Research Council)
- Seismic and Permafrost Engineer(s): 2 specialists in seismic hazard analysis, ground-response modeling and permafrost engineering for coastal and Arctic sites
- Immersed-Tunnel Specialist(s): 2 experienced designers or engineers from firms that have built immersed-tube tunnels (e.g., Danish, Dutch or Norwegian tunnel specialists) with deep-water or Arctic adaptation experience
- Arctic Construction Expert(s): 2 engineers with documented experience on Arctic pipeline, platform or infrastructure projects (supply-chain, marine logistics, seasonal-work optimization)
- Independent Design Review Firm (rotating): one external engineering-review organization (propose: HDR, Jacobs, Golder or peer) conducts independent verification at design-critical gates (Months 12–15 = 2027-10-12 to 2028-01-12)

**Decision Rights:** Technical Advisory Group does not make operational decisions; it provides expert advice and independent certification to the Operations Council and Steering Committee. It has authority to certify or withhold certification on: (1) design-freeze data adequacy (ice-load confidence within +/-15%, seismic-hazard confidence documented, permafrost-thaw models validated); (2) pilot-element trial success and readiness for production; (3) design safety margin and compliance with established codes. Withholding certification triggers escalation to Steering Committee for gate deferral or design refinement. TAG advice is non-binding but given significant weight in design-freeze and safety decisions.

**Decision Mechanism:** Consensus of TAG members preferred for certifications and formal opinions. If 2 or more members dissent on a major safety or adequacy issue, the dissent is documented in writing and escalated to Steering Committee regardless of overall TAG consensus. Chair may issue an interim letter of concern to Operations Council within 1 week of identifying a Major Issue (design uncertainty, data delay, safety question); formal letter with TAG consensus follows within 2–3 weeks. Disagreement among TAG members on technical approaches (e.g., deterministic vs. probabilistic design) is documented as professional difference and presented to Steering Committee for policy direction rather than resolved by vote.

**Meeting Cadence:** Quarterly formal meetings (Months 3, 6, 9, 12, 15, 18 = 2027-01-12, 2027-04-12, 2027-07-12, 2027-10-12, 2028-01-12, 2028-04-12) during design and pre-construction phases (Months 0–24 = 2026-10-12 to 2028-10-12). Semi-annual meetings (Months 30, 42, 54, 66 = 2029-04-12, 2030-04-12, 2031-04-12, 2032-04-12) during construction. Monthly conference calls for data-quality checks and interim issue flagging (Months 0–24 = 2026-10-12 to 2028-10-12). Emergency meeting if a Major Issue is raised (within 5 business days).

**Typical Agenda Items:**

- Ice-load monitoring data quality, statistical analysis and load-model calibration; ice-load design assumptions for towers and piers
- Seismic hazard update, ground-response modeling and permafrost-thaw scenario analysis; design-envelope recommendations
- Design-freeze readiness assessment: data confidence, design-adequacy certification and go/no-go recommendation
- Pilot-element trial results and immersed-tube-tunnel installation procedure validation; readiness for full-scale production
- Independent design-review findings (Months 12–15 = 2027-10-12 to 2028-01-12): tower, cable, tunnel and foundation design safety and constructability assessment
- Issue tracking: Major Issues raised, status and resolution by next formal meeting

**Escalation Path:** TAG Major Issue (design uncertainty, safety concern, data-adequacy shortfall) escalates to Operations Council within 5 business days via written interim letter from TAG chair. If Operations Council cannot resolve within 2 weeks, escalate to Steering Committee for decision on design refinement, gate deferral or additional investigation (e.g., extended monitoring, prototype testing). If TAG withholds design-freeze certification due to data gaps or safety concerns, design freeze is automatically deferred and escalates to Steering Committee with recommendation for deferral duration (propose: 3–6 months extended monitoring, or pilot test, or design refinement). TAG consensus on a Major Issue must be documented in the gate-clearance record and disclosed to lenders and regulators.
### 4. Indigenous Stakeholder and Compliance Council

**Rationale for Inclusion:** The project traverses Inupiat, Yupik, Chukchi and Siberian Yupik traditional-use areas in Alaska and Russia, with subsistence harvesting, marine-mammal and fisheries rights. US law (NEPA, Marine Mammal Protection Act) requires Indigenous consultation; Russian protections are weaker but customary law claims exist. Unresolved Indigenous consent can trigger injunctions, 6–18 month litigation delays and costs of USD 5–20 million. The Indigenous Stakeholder and Compliance Council establishes binding advisory authority over alignment, seasonal work windows and mitigation; oversees consent-agreement negotiation; manages benefit-fund design; and coordinates marine-mammal and subsistence-protection programs. Essential for legitimacy, permitting, social license and operational continuity.

**Responsibilities:**

- Chair formation and governance of Beringia Indigenous Council (Months 3–6 = 2027-01-12 to 2027-04-12): represent each identified Indigenous community, with legal standing and funding; establish decision authority and dispute resolution
- Co-author marine-mammal and subsistence-baseline studies with Indigenous community researchers (Months 0–12 = 2026-10-12 to 2027-10-12); document traditional knowledge, harvesting patterns and environmental baselines
- Negotiate and execute formal consent agreements (MOUs, FCIAs) with each community (Months 6–12 = 2027-04-12 to 2027-10-12), specifying scope of binding authority, consent triggers and benefit-sharing
- Design and administer Community Benefit Fund: propose 1–2% of annual revenue or USD 10–30 million/yr; allocate to community-identified projects (training, infrastructure, monitoring, mitigation)
- Establish work-window restrictions and marine-mammal monitoring protocols with binding authority over seasonal access; document stop-work triggers and adaptive-management procedures
- Track Indigenous workforce hiring, training and local-hire targets (propose 20–30%, estimated); report quarterly to Steering Committee on progress and compliance with commitments
- Coordinate subsistence-protection programs: fund alternative harvesting areas, gear, training if traditional areas are impacted; maintain subsistence-impact log and incident-response protocols

**Initial Setup Actions:**

- Conduct Indigenous-stakeholder mapping by Month 1 (2026-11-12): identify all communities with traditional-use rights, regulatory authority or potential impact on alignment (Inupiat and Yupik in Alaska; Chukchi, Yupik and others in Russia)
- Engage each community through established governance structures (tribal councils, traditional-use boards) starting Month 1 (2026-11-12); establish initial consultation protocols and schedule (propose: quarterly meetings through Month 12 = 2027-10-12)
- Fund community legal and technical advisors (propose: USD 500,000–1 million/community through Month 12 = 2027-10-12, then ongoing through operations): enable independent review of consent agreements, EIS/EIA and benefit-fund design
- Co-sponsor baseline studies: secure Indigenous community researchers as co-authors (propose: 30–50% of study team) for marine-mammal surveys, fisheries assessments and traditional-use documentation (Months 0–12 = 2026-10-12 to 2027-10-12)
- Establish Beringia Indigenous Council legally and operationally (Months 3–6 = 2027-01-12 to 2027-04-12): charter with binding advisory authority, legal standing, funding (propose: USD 2–5 million setup + USD 1–2 million/yr operations), and dispute-resolution process
- Develop Community Benefit Fund governance framework: specify fund size (propose 1–2% of revenue or fixed USD 10–30 million/yr), allocation process, governance (joint operator/Council board), eligible projects and reporting (Months 6–9 = 2027-04-12 to 2027-07-12)

**Membership:**

- Council Chair: Neutral independent mediator or Indigenous elder from outside project region (non-voting facilitation role)
- Beringia Indigenous Council Representatives: delegates from each identified Indigenous community (8–12 members, voting); funded and legally empowered to act on behalf of community(ies)
- Project Compliance Lead: project-employed staff managing day-to-day Indigenous engagement, benefit-fund administration and work-window coordination (non-voting, reporting to Council and Operations Council)
- Community Legal and Technical Advisors: one per major community grouping (funded by project, independent of project control), advising communities on consent agreements, impact assessment and benefit programs

**Decision Rights:** Beringia Indigenous Council holds binding advisory authority over: (1) alignment siting and alternative routes (if Indigenous impact varies); (2) seasonal work windows and marine-mammal-protection measures; (3) major design changes affecting traditional-use areas or subsistence access; (4) Community Benefit Fund allocation (Council approves 60%+ of annual fund with project co-approval on financial controls). Council consent (>75% vote threshold) is a gating condition before design freeze (Month 18 = 2028-04-12) and before construction start (Month 24+ = 2028-10-12+). Council cannot veto overall project continuation but can trigger escalation to Steering Committee if alignment, timing or mitigation changes are demanded; Steering Committee arbitrates if cost or schedule impact is material (>USD 100 million, >6 months).

**Decision Mechanism:** Beringia Indigenous Council operates by consensus of member delegations where possible. Votes on consent, work-window restrictions and benefit allocation require >75% affirmative vote (e.g., 8 of 11 members). Tie or deadlock: neutral chair facilitates resolution through mediation; if unresolved within 2 weeks, issue escalates to project Steering Committee and legal counsel in both jurisdictions for interpretation of FPIC (free, prior and informed consent) standards and dispute resolution. Individual community veto on matters uniquely affecting only that community (alignment or harvesting area specific to one group) is recognized; project must negotiate alternative or defer to Steering Committee resolution.

**Meeting Cadence:** Beringia Indigenous Council holds monthly meetings during pre-construction phases (Months 0–24 = 2026-10-12 to 2028-10-12) for consent agreements, baseline studies and benefit-fund design. Quarterly during construction (Months 25–60 = 2028-11-12 to 2031-10-12) for work-window coordination and monitoring. Semi-annual or annual during operations (Months 60–180 = 2031-10-12 to 2041-10-12) for benefit-fund administration and subsistence-impact review. Emergency meetings within 1 week if a stop-work incident or significant impact is reported.

**Typical Agenda Items:**

- Baseline studies co-authoring and traditional-knowledge documentation: schedule, community researcher roles, data sharing
- Consent-agreement negotiation: legal review, scope of binding authority, FPIC validation and final signature
- Seasonal work-window approval: proposed access calendar, marine-mammal monitoring triggers, stop-work protocols and adaptive-management procedures
- Community Benefit Fund design and allocation: fund size confirmation, eligible projects, Council governance and annual reporting
- Indigenous workforce program: hiring targets (20–30%), training partnerships with regional schools, wage and benefits competitiveness
- Subsistence-protection program: alternative harvesting areas, incident log, impact assessments and mitigation updates

**Escalation Path:** Beringia Indigenous Council disputes over consent, work-window or alignment escalate to project Steering Committee and legal counsel (US and Russian) for FPIC interpretation and binding arbitration within 3–4 weeks. If Council withholds consent on material alignment or timing grounds, Steering Committee must either negotiate redesign/rescheduling or escalate to US and Russian governments for sovereign-level diplomatic resolution (political gating). Stop-work incidents or major subsistence impacts reported by Indigenous monitors trigger immediate escalation to Operations Council and Council chair within 24 hours; investigation and response plan within 1 week. Unresolved Indigenous consent dispute at design-freeze gate (Month 18 = 2028-04-12) defers design freeze and extends planning gate by 3–6 months (paid pause); unresolved at construction start (Month 24+ = 2028-10-12+) escalates to Steering Committee for go/no-go decision on project continuation.
### 5. Risk, Compliance and Insurance Committee

**Rationale for Inclusion:** This project faces existential risks across political (treaty ratification, sanctions), financial (USD 100 billion baseline, cost overrun to USD 30 billion, lender default risk), and technical (ice loads, seismic, permafrost) domains. Compliance requirements span two sovereign jurisdictions (US NEPA, Russian EIA), sanctions and export controls (OFAC, EAR/ITAR), Indigenous rights, environmental law and Arctic safety codes. The Risk, Compliance and Insurance Committee integrates risk identification, assessment and mitigation across all domains; ensures regulatory compliance and licensing (OFAC, export control); manages insurance and contingency planning; and monitors leading indicators (cost variance, schedule slip, covenant ratios, permitting delays, geopolitical events) that signal need for escalation or gating decisions. Critical for bankability and lender covenant compliance.

**Responsibilities:**

- Maintain and update comprehensive risk register (Months 0–180 = 2026-10-12 to 2041-10-12): ice load, seismic, permafrost, political gating, sanctions licensing, financing, Indigenous consent, marine-mammal impacts, labor, supply-chain, cost/schedule, governance and O&M risks; assign owners and mitigation actions
- Monitor leading risk indicators: cost variance >5%, schedule slip >2 months, debt service coverage ratio <1.3x, OFAC licensing delays >3 months, permit milestones missed, Indigenous-consent disputes, geopolitical incidents (sanctions escalation, US-Russia tension)
- Manage regulatory compliance: maintain checklist of NEPA/EIA permit requirements, Indigenous-consultation milestones, marine-mammal authorization triggers, export-control vetting; verify timely submission and approval; escalate delays or denials
- Coordinate OFAC and export-control licensing: engage with US Treasury and State Department (Months 3–6 = 2027-01-12 to 2027-04-12); obtain written licensing pathway and pre-approved supplier list by Month 6 (2027-04-12); maintain compliance in procurement and financing
- Procure and manage project insurance: builder's risk, environmental liability, professional indemnity, contractor performance bonds and political-risk insurance (for sanctions and expropriation); ensure coverage aligns with lender requirements and risk profile (Months 6–12 = 2027-04-12 to 2027-10-12 policy negotiation)
- Design contingency-planning protocols for force-majeure events: geopolitical break (government withdrawal), major ice/seismic damage, supply-chain failure, lender default; specify trigger thresholds, activation decision authority and resource mobilization (USD 10–50 million emergency reserves estimated)
- Prepare quarterly risk reporting to Steering Committee and lenders: risk-register summary, risk-indicator trends, emerging issues and recommended mitigation or gating actions

**Initial Setup Actions:**

- Establish Risk, Compliance and Insurance Committee governance and charter by Month 0 (2026-10-12); designate committee chair (senior compliance or risk professional) and define decision authority
- Commission comprehensive risk assessment from an Arctic/megaproject risk consultant (Months 0–3 = 2026-10-12 to 2027-01-12): identify project-specific risks (ice, seismic, permafrost, Arctic logistics, two-jurisdiction permitting, sanctions, Indigenous rights) and rank by likelihood and impact
- Develop risk register (Excel or database) with columns: risk ID, category, description, owner, current mitigation, residual risk, leading indicators, escalation threshold and trigger action (Month 3 = 2027-01-12); populate with 20–30 identified risks from risk assessment and planning documents
- Establish regulatory-compliance checklist: NEPA/EIA requirements, Indigenous-consultation triggers, marine-mammal authorizations, export-control and OFAC licensing steps, Arctic safety-code confirmations; assign each to responsible party and tracking milestone (Months 0–3 = 2026-10-12 to 2027-01-12)
- Engage OFAC and export-control counsel by Month 0 (2026-10-12); request written preliminary guidance on project financing structure and supplier sourcing by Month 3 (2027-01-12) and final licensing pathway by Month 6 (2027-04-12)
- Initiate insurance-broker engagement for builder's risk, environmental liability and political-risk policies (Month 3 = 2027-01-12); draft insurance specifications and coverage requirements by Month 6 (2027-04-12); procure policies by Month 12 (2027-10-12) before construction mobilization

**Membership:**

- Committee Chair: Senior compliance, risk or insurance professional, independent from operational delivery (non-voting facilitation or tie-breaking as needed)
- Risk and Insurance Manager: full-time dedicated role, managing risk register, leading-indicator tracking and insurance procurement and claims management
- Compliance Officer: dedicated to regulatory licensing (OFAC, export control, permits); liaison with US and Russian regulatory agencies; ensures timely compliance filings and authorizations
- Operations Council representative (observing, reporting to Operations Council): provides operations context on cost/schedule variance and emerging execution risks
- Steering Committee representative (observing): reports risk trends and escalation recommendations back to Steering Committee
- Insurance Broker/Advisor: external, specialized in large-project construction and political-risk insurance; advises on coverage adequacy and policy terms (non-voting, external advisor)

**Decision Rights:** Risk Committee identifies and classifies risks; owners and Operations Council decide mitigation actions (budget, schedule, resource allocation). Risk Committee escalates risks exceeding escalation thresholds to Steering Committee within 1 week of threshold breach: (1) cost variance >5% (USD 5 billion) or trend indicating final overrun >10% (USD 10 billion); (2) schedule slip >2 months or ratification delay projected >6 months beyond plan; (3) OFAC licensing pathway uncertain or pre-approved supplier list reduced by >20%; (4) debt service coverage ratio projected to fall <1.3x within 12 months; (5) major geopolitical incident affecting US-Russia relations or sanctions regime. Risk Committee has authority to freeze contingency-reserve release: if contingency drawdown is requested before gate clearance (Month 18 = 2028-04-12), Risk Committee chair may require Steering Committee approval (to prevent excessive contingency spend before design freeze). Insurance policies are approved by Risk Committee with lender sign-off.

**Decision Mechanism:** Risk Committee operates by consensus on risk classification, leading-indicator thresholds and escalation recommendations. If Risk Committee members disagree on severity or mitigation priority, the more conservative (higher-risk) assessment is escalated to Steering Committee. Escalation threshold decisions are made by Risk Committee chair with Steering Committee notification if disagreement arises on threshold level (e.g., if cost variance >5% should trigger escalation or if >7% is acceptable before escalation).

**Meeting Cadence:** Monthly during Months 0–24 (2026-10-12 to 2028-10-12) (pre-construction and gate-clearance phases). Bi-monthly during Months 25–60 (2028-11-12 to 2031-10-12) (construction mobilization). Quarterly during Months 60–180 (2031-10-12 to 2041-10-12) (construction and operations). Weekly monitoring of leading indicators (cost, schedule, covenant ratios, regulatory milestones) with alerts issued within 24 hours if threshold is approached.

**Typical Agenda Items:**

- Risk-register update: new risks identified, mitigation status for existing risks, closed risks and residual-risk trends
- Leading-indicator dashboard review: cost variance, schedule slip, debt service coverage, OFAC licensing progress, permit-approval status, Indigenous-consent milestones, geopolitical incident tracking
- Regulatory compliance status: NEPA/EIA submissions and approvals, export-control vetting, sanctions-licensing confirmation, permit applications and approvals, Indigenous-consultation checklist
- Insurance policies and coverage: builder's risk, environmental liability, professional indemnity, contractor performance bonds, political-risk insurance; claim updates and coverage adequacy assessment
- Escalation recommendations: identification of risks or indicators that have breached thresholds; recommendation for Steering Committee action (design refinement, gate deferral, contingency release, exit)
- Contingency planning: force-majeure scenario testing, resource mobilization plans, exit provisions and paid-pause protocols

**Escalation Path:** Risk Committee escalates to Steering Committee any risk threshold breach (cost >5%, schedule >2 months, DSCR <1.3x, OFAC delay >3 months, geopolitical incident) within 1 week of detection. Escalation package includes: (1) risk description and current status, (2) leading indicator data, (3) impact on project (cost, schedule, financing, permit timeline), (4) recommended mitigation (design change, schedule adjustment, contingency release, gate deferral) and (5) Resource or authorization needed from Steering Committee. If Risk Committee and Operations Council disagree on mitigation adequacy, issue escalates directly to Steering Committee. Major geopolitical incident (e.g., sanctions escalation, significant US-Russia diplomatic break) triggers emergency Steering Committee meeting within 48 hours; Risk Committee chair and Compliance Officer brief on immediate impact and trigger cascade (financing delay, supplier availability, personnel movement, project continuity).

# Governance Implementation Plan

### 1. Project Sponsor and Senior Management formally establish and charter the neutral third-country SPV that will own and govern the crossing. SPV bylaws must specify voting rights, decision authority, reporting structure and Steering Committee composition. Register the SPV in the chosen neutral jurisdiction (Switzerland, Canada or international regime candidate) by Month 3 (2027-01-12).

**Responsible Body/Role:** Project Sponsor (US and Russian government representatives) with Neutral SPV Legal Counsel

**Suggested Timeframe:** Month 0 (2026-10-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- SPV Charter and Bylaws (final, executed)
- SPV Articles of Incorporation filed in host jurisdiction
- Board Composition and Voting Rules documented
- SPV Bank Accounts and Financial Controls established

**Dependencies:**

- Project Sponsor identified and authorized
- Neutral jurisdiction and SPV structure selected
- Legal framework for US-Russia governance agreed in principle

### 2. Project Manager or Designated Formation Lead drafts the Steering Committee Charter, including explicit authority matrix, decision thresholds, meeting cadence, quorum rules and escalation protocols. The Charter must specify gate-clearance criteria, voting procedures, tie-breaking rules and the role of the neutral Steering Committee chair (to be appointed separately). Circulate draft to nominated steering members for review and feedback.

**Responsible Body/Role:** Project Manager / Formation Lead (appointed by Project Sponsor)

**Suggested Timeframe:** Month 0 (2026-10-12) to Month 1.5 (2026-11-27 to 2026-11-27)

**Key Outputs/Deliverables:**

- Draft Steering Committee Charter v0.1
- Authority Matrix and Decision Thresholds documented
- Gate-Clearance Criteria Checklist (Months 6, 12, 18, 24 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12)
- Meeting-Cadence Calendar and Escalation Pathways

**Dependencies:**

- Project Sponsor identified
- SPV Charter under development
- Nominated Steering Committee member list available (US, Russia, lenders, technical advisor)

### 3. Project Sponsor formally appoints the Steering Committee Chair (proposed: neutral independent party, e.g., retired senior infrastructure executive or diplomat). Appointment letter must specify term, decision authority and compensation. Chair must confirm acceptance and sign conflict-of-interest disclosure and confidentiality agreement by Month 1.5 (2026-11-27).

**Responsible Body/Role:** Project Sponsor (US and Russian government representatives, acting jointly)

**Suggested Timeframe:** Month 0.5 (2026-10-27) to Month 1.5 (2026-11-27 to 2026-11-27)

**Key Outputs/Deliverables:**

- Steering Committee Chair Appointment Letter (executed)
- Chair Acceptance and Conflict-of-Interest Disclosure
- Chair Compensation and Term Agreement
- Chair Confidentiality Agreement signed

**Dependencies:**

- Project Sponsor authorized
- Neutral chair candidate identified and vetted
- SPV Charter draft available for reference

### 4. Project Sponsor and Designated Formation Lead circulate the Steering Committee Charter draft to all nominated members (US and Russian government representatives, lead lenders, technical advisor) for review and comment. Collect feedback in a Feedback Summary document. Resolve comments in a redline draft and re-circulate for final approval.

**Responsible Body/Role:** Project Manager / Formation Lead (in coordination with Steering Committee Chair)

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 2 (2026-12-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Steering Committee Charter v0.1 distributed to nominatedmembers
- Feedback Summary (consolidated comments and resolutions)
- Steering Committee Charter v1.0 (redlined, ready for approval)

**Dependencies:**

- Draft Steering Committee Charter v0.1 complete
- Steering Committee Chair appointed
- Nominated member contact list available

### 5. Steering Committee Chair formally confirms and finalizes the Steering Committee Charter v1.0 based on feedback and obtains written approval signatures from all voting members (Project Sponsor representative, US government, Russian government, lead lenders). Publish the finalized Charter and distribute to all parties.

**Responsible Body/Role:** Steering Committee Chair (with Project Manager support)

**Suggested Timeframe:** Month 2 (2026-12-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Steering Committee Charter v1.0 (final, signed by all voting members)
- Steering Committee Charter published and disseminated
- Meeting-Cadence and Gate-Review Calendar confirmed and published

**Dependencies:**

- Steering Committee Charter v1.0 redline complete
- All nominated members confirmed
- Steering Committee Chair in post

### 6. Project Sponsor and Steering Committee Chair jointly formalize the appointment of all Steering Committee voting members (US and Russian government representatives, lead lender representatives, neutral technical advisor). Send formal appointment letters with term, responsibilities and conflict-of-interest requirements. Obtain signed confirmations of acceptance.

**Responsible Body/Role:** Project Sponsor (in coordination with Steering Committee Chair)

**Suggested Timeframe:** Month 2.5 (2026-12-27) to Month 3.5 (2027-01-27 to 2027-02-12)

**Key Outputs/Deliverables:**

- Steering Committee Member Appointment Letters (executed)
- Member Acceptance Confirmations and Conflict-of-Interest Disclosures
- Steering Committee Roster (published with roles and affiliations)

**Dependencies:**

- Steering Committee Chair appointed
- Steering Committee Charter finalized and signed
- Member candidates identified and vetted by Project Sponsor

### 7. Project Sponsor appoints the Operations and Execution Council Chair (proposed: Owner's Engineer/Integrator or senior operations lead). Chair must confirm acceptance, sign conflict-of-interest disclosure and establish initial meeting schedule. Chair drafts the Operations Council Charter specifying decision authority, weekly-meeting cadence, interface-control procedures and escalation to Steering Committee.

**Responsible Body/Role:** Project Sponsor (in coordination with Steering Committee Chair)

**Suggested Timeframe:** Month 0 (2026-10-12) to Month 2 (2026-12-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Operations and Execution Council Chair Appointment Letter (executed)
- Chair Acceptance and Conflict-of-Interest Disclosure
- Draft Operations Council Charter v0.1
- Initial Meeting Schedule and Calendar

**Dependencies:**

- Project Sponsor identified
- Owner's Engineer/Integrator candidate identified
- Steering Committee structure in planning

### 8. Operations and Execution Council Chair drafts the Operations Council Charter, including authority matrix, weekly-meeting cadence, quorum, change-control thresholds (USD 10 million for changes, 5% for cost/schedule variance escalation), interface-control procedures and neutral-arbiter escalation. Circulate to draft to nominated core team members (Owner's Engineer, Cost Engineer, Design Lead, Environmental Lead, Indigenous Lead, Logistics Lead, Finance Manager) for feedback.

**Responsible Body/Role:** Operations and Execution Council Chair (proposed: Owner's Engineer/Integrator)

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 2 (2026-12-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Operations Council Charter v0.1 (draft)
- Authority Matrix and Change-Control Thresholds defined
- Decision Mechanism and Tie-Breaking Rules documented
- Interface-Control Board Charter (draft)

**Dependencies:**

- Operations Council Chair appointed
- Core team roles identified (Owner's Engineer, Cost Engineer, etc.)
- Steering Committee Charter in place (for alignment on thresholds)

### 9. Operations and Execution Council Chair finalizes the Operations Council Charter based on core team feedback. Obtain written approval signatures from all voting members (Cost Engineer, Design Lead, Environmental Lead, Indigenous Lead, Logistics Lead, Finance Manager). Publish the finalized Charter and establish the weekly-meeting routine starting Month 3 (2027-01-12).

**Responsible Body/Role:** Operations and Execution Council Chair

**Suggested Timeframe:** Month 2 (2026-12-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Operations Council Charter v1.0 (final, signed)
- Operations Council Charter published
- Weekly-Meeting Calendar (Months 3-60 = 2027-01-12 to 2031-10-12)
- Interface-Control Board established and meeting schedule published

**Dependencies:**

- Operations Council Chair in post
- Core team roles defined
- Operations Council Charter v0.1 feedback incorporated

### 10. Project Sponsor and Steering Committee Chair jointly recruit and formally appoint the Technical Advisory Group Chair (proposed: world-class Arctic or immersed-tunnel engineer, e.g., National Academy member). Chair must confirm acceptance, sign conflict-of-interest and confidentiality agreements and establish the TAG member recruitment schedule.

**Responsible Body/Role:** Project Sponsor (in coordination with Steering Committee Chair)

**Suggested Timeframe:** Month 0 (2026-10-12) to Month 1 (2026-11-12 to 2026-11-12)

**Key Outputs/Deliverables:**

- Technical Advisory Group Chair Appointment Letter (executed)
- Chair Acceptance and Conflict-of-Interest Disclosure
- TAG Member Recruitment Plan and Timeline
- TAG Charter (draft, pending member confirmation)

**Dependencies:**

- Project Sponsor identified
- TAG Chair candidate (world-class engineer) identified and vetted
- Steering Committee structure in planning

### 11. Technical Advisory Group Chair identifies and recruits 8-12 specialized members (propose: 2-3 ice-mechanics experts, 2 seismic/permafrost engineers, 2 immersed-tunnel designers, 2 Arctic-construction specialists, 1-2 independent engineering-review firms). Send formal engagement letters by Month 1 (2026-11-12). Execute engagement agreements specifying scope, confidentiality, fees and meeting cadence by Month 3 (2027-01-12).

**Responsible Body/Role:** Technical Advisory Group Chair

**Suggested Timeframe:** Month 0.5 (2026-10-27) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- TAG Member List (8-12 confirmed specialists)
- TAG Member Engagement Letters (executed)
- TAG Engagement Agreements (signed, confidentiality in place)
- TAG Member Roster with affiliations and specialties

**Dependencies:**

- TAG Chair appointed
- Funding approved for specialist engagement (external budget)
- TAG member candidate list identified

### 12. Technical Advisory Group Chair drafts the TAG Charter, specifying quarterly-meeting cadence during design phases (Months 3, 6, 9, 12, 15, 18 = 2027-01-12 to 2028-04-12), data-flow protocols from Operations Council, escalation criteria for Major Issues (ice/seismic/permafrost data uncertainties, design-adequacy doubts), certification authority on design freeze and decision mechanism (consensus with dissent documentation). Circulate to TAG members for review and finalization.

**Responsible Body/Role:** Technical Advisory Group Chair

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 2.5 (2026-12-27 to 2027-01-02)

**Key Outputs/Deliverables:**

- TAG Charter v1.0 (draft)
- Quarterly-Meeting Schedule (Months 3-18 = 2027-01-12 to 2028-04-12)
- Data-Flow and Escalation Protocols documented
- TAG Certification Authority and Decision Mechanism defined

**Dependencies:**

- TAG Chair in post
- TAG members recruited and confirmed
- Steering Committee Charter completed (for alignment on escalation)

### 13. Technical Advisory Group Chair finalizes the TAG Charter and obtains written confirmation from all TAG members. Establish monthly data-flow routine from Operations Council (raw monitoring data, design models, test results) to TAG starting Month 3 (2027-01-12). Schedule first formal TAG meeting for Month 3 (2027-01-12) with preliminary ice and seismic data available.

**Responsible Body/Role:** Technical Advisory Group Chair

**Suggested Timeframe:** Month 2 (2026-12-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- TAG Charter v1.0 (final, confirmed by all members)
- Monthly Data-Flow Routine established
- First TAG Meeting scheduled (Month 3 = 2027-01-12)
- TAG Charter published to Steering Committee and Operations Council

**Dependencies:**

- TAG Charter v1.0 draft complete
- All TAG members confirmed
- Operations Council structure and meeting schedule in place

### 14. Project Sponsor and Formation Lead initiate Indigenous-stakeholder mapping by engaging established US and Russian government liaisons (e.g., US Bureau of Indian Affairs, Russian Ministry of Indigenous Affairs if applicable). Conduct stakeholder identification interviews with tribal councils, traditional-use boards and Indigenous community leaders in Alaska (Inupiat, Yupik communities around Wales, Nome) and Russia (Chukchi, Yupik communities around Uelen, Provideniya). Complete mapping document identifying all communities with traditional-use rights, regulatory authority or potential project impact.

**Responsible Body/Role:** Project Manager / Formation Lead (in coordination with Indigenous Engagement Specialist, newly hired or designated)

**Suggested Timeframe:** Month 0 (2026-10-12) to Month 1 (2026-11-12 to 2026-11-12)

**Key Outputs/Deliverables:**

- Indigenous-Stakeholder Mapping Report (8-12 communities identified)
- Contact List for Indigenous Community Leaders and Councils
- Preliminary Community Engagement Timeline and Schedule
- Initial Outreach Letters sent to community councils

**Dependencies:**

- Project Sponsor authorized
- US and Russian government liaisons engaged
- Funding approved for Indigenous-engagement specialist

### 15. Project Manager and Indigenous Engagement Specialist fund and establish community legal and technical advisors (propose: USD 500,000 to 1 million per community grouping through Month 12 = 2027-10-12). Advisors must be independent of project control. Advisors will support community review of EIS/EIA documents, consent agreements and benefit-fund design. Negotiate and execute advisor engagement agreements by Month 3 (2027-01-12).

**Responsible Body/Role:** Project Manager and Indigenous Engagement Specialist (with Project Sponsor approval)

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Community Advisor Recruitment Plan and Budget Allocation
- Community Legal Advisor Engagement Letters (executed)
- Community Technical Advisor Engagement Agreements (signed)
- Advisor Funding Mechanism established (direct payment, independent accounts)

**Dependencies:**

- Indigenous-Stakeholder Mapping complete
- Budget approved for community advisors
- Community councils identified and contacted

### 16. Project Sponsor and Indigenous Engagement Specialist draft the Beringia Indigenous Council Formation Charter, specifying legal standing, binding advisory authority over alignment, work windows and mitigation measures, governance structure (delegates from 8-12 communities), decision-making (>75% consensus threshold), funding mechanism (propose USD 2-5 million setup + USD 1-2 million/yr operations) and dispute-resolution process. Circulate draft to identified community leaders for feedback and refinement.

**Responsible Body/Role:** Indigenous Engagement Specialist (with Project Sponsor and Project Manager oversight)

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 2 (2026-12-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Beringia Indigenous Council Formation Charter v0.1 (draft)
- Community Feedback Summary on Charter scope and authority
- Proposed Council Governance Structure and Decision Rules
- Funding and Support Plan for Council operations

**Dependencies:**

- Indigenous-Stakeholder Mapping complete
- Community Legal Advisors engaged
- Project Sponsor commitment to Indigenous engagement

### 17. Project Sponsor and Indigenous Engagement Specialist formalize the Beringia Indigenous Council Foundation by obtaining written commitment letters from all identified Indigenous communities confirming their participation, delegate representation and acceptance of the Council Charter. Execute the Council Formation Agreement by Month 6 (2027-04-12). Formally establish the Council with an inaugural meeting at Month 6 (2027-04-12).

**Responsible Body/Role:** Project Sponsor (in coordination with Indigenous Engagement Specialist)

**Suggested Timeframe:** Month 3 (2027-01-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Community Participation Commitment Letters (all identified communities signed)
- Beringia Indigenous Council Formation Agreement (executed)
- Council Charter v1.0 (finalized, signed by all communities)
- Council Inaugural Meeting held (Month 6 = 2027-04-12)
- Council Meeting Minutes and member roster published

**Dependencies:**

- Beringia Council Charter v0.1 draft complete
- Community legal advisors in place
- Funding commitment for Council operations secured

### 18. Indigenous Engagement Specialist co-sponsors marine-mammal and subsistence-baseline studies with Indigenous community researchers as co-authors (propose 30-50% of study teams). Studies begin Month 0 (2026-10-12) and run through Month 12 (2027-10-12), documenting traditional knowledge, subsistence harvesting patterns, marine-mammal migration and feeding, and environmental baselines. Ensure Indigenous communities retain data-sharing rights and co-publication authority.

**Responsible Body/Role:** Indigenous Engagement Specialist (in coordination with Environmental and Permitting Lead, Operations Council)

**Suggested Timeframe:** Month 0 (2026-10-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Marine-Mammal Baseline Study (co-authored with Indigenous researchers)
- Subsistence Harvesting Baseline Report (community-validated)
- Traditional-Knowledge Documentation (copyright held by community)
- Study Data-Sharing and Co-Publication Agreement

**Dependencies:**

- Indigenous-Stakeholder Mapping complete
- Community legal and technical advisors in place
- Environmental/permitting team identified (Operations Council)
- Funding for baseline studies approved

### 19. Project Manager (Formation Lead) appoints the Compliance Officer (dedicated regulatory and licensing specialist) and Risk and Insurance Manager by Month 1 (2026-11-12). Both roles report to the Risk, Compliance and Insurance Committee Chair (to be appointed separately). Compliance Officer immediately begins OFAC and export-control engagement, submitting initial written inquiries by Month 1 (2026-11-12) and requesting preliminary guidance on financing structure and supplier sourcing.

**Responsible Body/Role:** Project Sponsor and Project Manager

**Suggested Timeframe:** Month 0.5 (2026-10-27) to Month 1 (2026-11-12 to 2026-11-12)

**Key Outputs/Deliverables:**

- Compliance Officer Job Description and Appointment Letter
- Risk and Insurance Manager Job Description and Appointment Letter
- OFAC Pre-Engagement Letter submitted (Month 1 = 2026-11-12)
- Export-Control Counsel Engagement Letter (signed)

**Dependencies:**

- Project Sponsor authorized
- Funding approved for Compliance Officer and Risk Manager roles
- Export-control counsel identified and pre-qualified

### 20. Project Sponsor and Formation Lead appoint the Risk, Compliance and Insurance Committee Chair (proposed: senior compliance or risk professional, independent from operational delivery). Chair drafts the Risk Committee Charter specifying monthly-meeting cadence during Months 0-24 (2026-10-12 to 2028-10-12), decision authority on risk escalation thresholds (cost >5%, schedule >2 months, DSCR <1.3x, OFAC delay >3 months), insurance-policy oversight and leading-indicator monitoring. Chair establishes monthly risk-monitoring routine.

**Responsible Body/Role:** Project Sponsor (in coordination with Project Manager)

**Suggested Timeframe:** Month 0 (2026-10-12) to Month 2 (2026-12-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Risk Committee Chair Appointment Letter (executed)
- Risk Committee Charter v0.1 (draft, with decision thresholds and escalation criteria)
- Risk-Register Template and Leading-Indicator Dashboard defined
- Monthly Risk-Monitoring Routine established

**Dependencies:**

- Project Sponsor authorized
- Compliance Officer and Risk Manager in post
- Steering Committee Charter in place (for alignment on escalation thresholds)

### 21. Risk Committee Chair circulates the Risk Committee Charter draft to Compliance Officer, Risk and Insurance Manager, and Operations Council representative for feedback. Finalize the Charter and obtain written approval by Month 3 (2027-01-12). Establish the monthly risk-reporting routine (risk-register review, leading-indicator dashboard, escalation recommendations) starting Month 3 (2027-01-12).

**Responsible Body/Role:** Risk, Compliance and Insurance Committee Chair (with Compliance Officer and Risk Manager input)

**Suggested Timeframe:** Month 1.5 (2026-11-27) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Risk Committee Charter v1.0 (final, signed)
- Risk-Register v1.0 populated with 20-30 initial risks (from risk-assessment and planning documents)
- Leading-Indicator Dashboard defined (cost variance, schedule slip, DSCR, permitting delays)
- Monthly Risk-Reporting Template published

**Dependencies:**

- Risk Committee Chair appointed
- Compliance Officer and Risk Manager in post
- Comprehensive risk assessment or risk-file inputs available

### 22. Compliance Officer (with support from Risk and Insurance Manager) conducts formal OFAC and export-control licensing inquiry. Submit detailed project overview, financing structure (third-country consortium), equipment sourcing strategy and personnel-movement plan to US Treasury OFAC and equivalent Russian authorities. Request written preliminary guidance on licensability by Month 3 (2027-01-12) and final licensing pathway with pre-approved supplier list by Month 6 (2027-04-12).

**Responsible Body/Role:** Compliance Officer (dedicated regulatory specialist)

**Suggested Timeframe:** Month 0.5 (2026-10-27) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- OFAC and Export-Control Inquiry Package (submitted Month 1 = 2026-11-12)
- Preliminary OFAC Guidance Letter (received by Month 3 = 2027-01-12, target)
- Written Licensing Pathway (final, by Month 6 = 2027-04-12)
- Pre-Approved Supplier and Contractor List (by Month 6 = 2027-04-12)

**Dependencies:**

- Compliance Officer appointed
- Export-control counsel engaged
- Financing structure and third-country SPV finalized
- Equipment and sourcing strategy defined (Operations Council)

### 23. Risk and Insurance Manager initiates insurance-broker engagement (Month 1 = 2026-11-12), selecting a specialized large-project and political-risk insurance advisor. Broker develops insurance specifications and coverage requirements for builder's risk, environmental liability, professional indemnity, contractor performance bonds and political-risk insurance (sanctions and expropriation coverage) by Month 6 (2027-04-12). Procure final insurance policies by Month 12 (2027-10-12) before construction mobilization.

**Responsible Body/Role:** Risk and Insurance Manager (dedicated role, full-time)

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Insurance-Broker Engagement Letter (executed)
- Insurance Specifications and Coverage Requirements (by Month 6 = 2027-04-12)
- Insurance Policy Quotes and Comparison Analysis (by Month 9 = 2027-07-12)
- Executed Insurance Policies (by Month 12 = 2027-10-12)
- Insurance Certificates of Insurance and proof of coverage

**Dependencies:**

- Risk and Insurance Manager appointed
- Project CAPEX baseline and financing structure finalized
- Lender requirements and insurance mandates understood

### 24. Project Manager and Operations Council Chair formally appoint all core Operations Council voting members (Cost Engineer, Design Lead - Bridge and Tunnel, Environmental and Permitting Lead, Indigenous Stakeholder Lead, Construction Logistics Lead, Finance and Commercial Manager) by Month 1 (2026-11-12). Send formal appointment letters with term, responsibilities and authorities. Obtain signed confirmations of acceptance and conflict-of-interest disclosures.

**Responsible Body/Role:** Project Sponsor and Operations and Execution Council Chair

**Suggested Timeframe:** Month 0.5 (2026-10-27) to Month 2 (2026-12-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Operations Council Member Appointment Letters (executed for all voting members)
- Member Acceptance Confirmations and Conflict-of-Interest Disclosures
- Operations Council Member Roster (published with roles and authorities)
- Weekly-Meeting Schedule (Months 3-60 = 2027-01-12 to 2031-10-12)

**Dependencies:**

- Operations and Execution Council Chair appointed
- Core team roles defined in Operations Council Charter
- Operations Council Charter finalized

### 25. Operations Council Chair establishes the Interface Control Board (ICB) by appointing an ICB Chair (proposed: Owner's Engineer Integrator or independent integrator), defining monthly-meeting cadence starting Month 6 (2027-04-12), and publishing the ICB Charter. ICB will manage interface-control documents between suspension span, immersed-tube tunnel and island systems; resolve interface conflicts through documented decision process; and escalate unresolved conflicts to a neutral external arbiter (to be appointed separately by Month 6 = 2027-04-12).

**Responsible Body/Role:** Operations and Execution Council Chair

**Suggested Timeframe:** Month 2 (2026-12-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Interface Control Board Charter (published)
- ICB Chair Appointment Letter (executed)
- Monthly ICB Meeting Calendar (Months 6-60 = 2027-04-12 to 2031-10-12)
- Interface-Control Document Template and Approval Process defined

**Dependencies:**

- Operations Council Charter finalized
- Owner's Engineer Integrator or ICB Chair candidate identified
- Design team leads identified (bridge and tunnel leads)

### 26. Operations Council Chair appoints a neutral external arbiter (independent megaproject engineer or integrator with binding authority over interface disputes) by Month 2 (2026-12-12). Arbiter must be independent of contractors, governments and operators. Execute arbiter engagement agreement specifying scope (interface conflict resolution within 2-week timeline with binding decision authority), confidentiality and fees. Arbiter attends ICB meetings as needed starting Month 6 (2027-04-12).

**Responsible Body/Role:** Operations and Execution Council Chair (with Project Sponsor oversight)

**Suggested Timeframe:** Month 1.5 (2026-11-27) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Neutral Arbiter Identification and Vetting completed
- Arbiter Engagement Agreement (executed)
- Arbiter Acceptance and Conflict-of-Interest Disclosure
- Arbiter contact and decision-escalation protocols published

**Dependencies:**

- Operations Council established
- Interface Control Board Charter in planning
- Funding approved for arbiter services

### 27. Project Manager (Formation Lead) establishes the Owner's Engineer Integrator function (proposed: senior Arctic megaproject engineer with 100-150 core specialist team). Owner's Engineer is the primary responsible party for design, cost control, interface management and construction oversight, reporting to Operations Council. Publish the Owner's Engineer job description, authority matrix and direct-report structure by Month 1 (2026-11-12). Recruit Owner's Engineer and core team leads by Month 2 (2026-12-12).

**Responsible Body/Role:** Project Sponsor and Project Manager

**Suggested Timeframe:** Month 0.5 (2026-10-27) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Owner's Engineer Job Description and Authority Matrix (published)
- Owner's Engineer Recruitment and Hiring Plan
- Owner's Engineer Offer Letter (by Month 2 = 2026-12-12)
- Core Team Structure (100-150 specialists) and roles defined
- Owner's Engineer Onboarding completed (Month 3 = 2027-01-12)

**Dependencies:**

- Project Sponsor authorized
- Operations Council structure established
- CAPEX budget and staffing budget approved

### 28. Operations Council Chair and Owner's Engineer Integrator develop the Detailed Project Execution Plan, covering design schedule (Months 0-18 = 2026-10-12 to 2028-04-12 for preliminary and critical design reviews), permitting roadmap (framework permits Months 6-9 = 2027-04-12 to 2027-07-12, detailed permits Months 12-18 = 2027-10-12 to 2028-04-12), Indigenous-engagement milestones (Beringia Council formation Months 3-6 = 2027-01-12 to 2027-04-12, consent agreements Month 12 = 2027-10-12), surveys and monitoring (ice, seismic, permafrost Months 0-18 = 2026-10-12 to 2028-04-12), and cost/schedule baseline. Publish by Month 3 (2027-01-12).

**Responsible Body/Role:** Operations and Execution Council Chair and Owner's Engineer Integrator

**Suggested Timeframe:** Month 1 (2026-11-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Detailed Project Execution Plan v1.0 (published)
- Design Schedule and Milestone Calendar (Months 0-180 = 2026-10-12 to 2041-10-12)
- Permitting Roadmap with agency touchpoints and approval timeline
- Indigenous-Engagement Milestone Schedule (Months 0-12 = 2026-10-12 to 2027-10-12)
- Cost and Schedule Baseline Summary

**Dependencies:**

- Operations Council established
- Owner's Engineer Integrator appointed
- Steering Committee Charter finalized (for gate schedule reference)

### 29. Cost Engineer (appointed as Operations Council voting member) commissions a detailed parametric cost estimate from Arctic-construction specialists (HDR, Jacobs, Golder or equivalent) by Month 3 (2027-01-12). Build-up must include regional labor surveys (target: 30-50% Arctic premium), material cost indices, marine logistics premiums (50-100%), Arctic-specific equipment and supplier rates. Establish Cost Basis Document and publish for contractor feedback by Month 6 (2027-04-12). Conduct sensitivity analysis on key cost drivers (labor escalation, material inflation, exchange rates, contractor premiums).

**Responsible Body/Role:** Cost Engineer (Operations Council voting member)

**Suggested Timeframe:** Month 0.5 (2026-10-27) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Parametric Cost-Estimate Request and Scoping (by Month 2 = 2026-12-12)
- Detailed Cost Build-Up by category (labor, materials, logistics, contingency) - Month 3 = 2027-01-12
- Cost Basis Document v1.0 (published for feedback, Month 6 = 2027-04-12)
- Sensitivity Analysis on key cost drivers
- Contractor feedback summary and cost-estimate refinement

**Dependencies:**

- Cost Engineer appointed
- Arctic-construction cost-modeling consultant identified and selected
- Funding approved for cost-estimate study
- Design scope and deliverables defined

### 30. Operations Council (Cost Engineer lead) establishes a Cost Task Force with representatives from candidate fabrication yards, tow-vessel operators, Arctic labor providers and material suppliers. Task Force meets monthly (Months 3-6 = 2027-01-12 to 2027-04-12) to validate parametric-cost estimates, identify regional rate drivers, confirm labor availability and material lead times, and resolve cost outliers. Task Force input feeds into refined Cost Basis Document v1.0 published by Month 6 (2027-04-12).

**Responsible Body/Role:** Cost Engineer (Operations Council), with support from Logistics Lead and Finance Manager

**Suggested Timeframe:** Month 2 (2026-12-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Cost Task Force Charter and Member List (Month 2 = 2026-12-12)
- Monthly Cost-Review Meeting Minutes (Months 3-6 = 2027-01-12 to 2027-04-12)
- Cost Validation Report (contractor and supplier input consolidated)
- Cost Basis Document v1.0 (final, Month 6 = 2027-04-12)

**Dependencies:**

- Parametric cost estimate commissioned and in progress
- Candidate yards, logistics providers and suppliers identified
- Cost Engineer in post

### 31. Cost Engineer establishes a formal cost-tracking system (Primavera P6, Oracle Cloud or equivalent) and cost-change-control process (Months 3-6 = 2027-01-12 to 2027-04-12). Define cost-change thresholds: Changes ≤USD 10 million approved by Operations Council; >USD 10 million escalate to Steering Committee. Variance >5% triggers reforecasting and repricing review with lender sign-off. Monthly cost tracking and variance reporting begin Month 3 (2027-01-12).

**Responsible Body/Role:** Cost Engineer (Operations Council voting member)

**Suggested Timeframe:** Month 2 (2026-12-12) to Month 3 (2027-01-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Cost-Tracking System Setup and Database configured
- Cost-Change-Control Process documented and published
- Cost-Variance Report Template (monthly, starting Month 3 = 2027-01-12)
- Cost-Escalation Matrix (thresholds for Operations Council vs. Steering Committee)
- Cost-Variance Monitoring Dashboard (updated monthly)

**Dependencies:**

- Cost Engineer appointed
- Detailed Project Execution Plan and baseline established
- Software licenses and IT infrastructure approved

### 32. Operations Council launches ice-monitoring program: install drifting buoys, shore-based radar and satellite-imagery tracking starting Month 0 (2026-10-12). Install pilot instrumentation (pressure plates, accelerometers) on prototype pier models in the strait (Months 6-12 = 2027-04-12 to 2027-10-12) to capture real-world ice loads. Establish data-collection and analysis protocols with independent verification by Month 3 (2027-01-12). First ice-data summary to Technical Advisory Group by Month 6 (2027-04-12).

**Responsible Body/Role:** Design Lead - Bridge (Operations Council voting member), with support from Environmental Lead and independent monitoring contractor

**Suggested Timeframe:** Month 0 (2026-10-12) to Month 6 (2027-04-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Ice-Monitoring Program Charter and Instrumentation Plan (Month 0 = 2026-10-12)
- Drifting-Buoy and radar-tracking network deployed (Month 1 = 2026-11-12)
- Pilot Instrumentation installed on prototype piers (Months 6-12 = 2027-04-12 to 2027-10-12)
- Data-Collection and QA/QC Protocols published (Month 3 = 2027-01-12)
- First Ice-Data Summary and load-model calibration (Month 6 = 2027-04-12)

**Dependencies:**

- Operations Council established
- Design Lead - Bridge appointed
- Funding approved for ice-monitoring instrumentation and analysis
- Site survey and baseline established

### 33. Operations Council (with Design Lead - Bridge and Geotechnical specialist input) launches comprehensive geotechnical investigation program. Core drilling at proposed pier locations and island sites (Months 0-6 = 2026-10-12 to 2027-04-12). Laboratory testing of soil samples for shear strength, consolidation and permafrost (Months 3-9 = 2027-01-12 to 2027-07-12). In-situ testing (SPT, CPT, vane shear) at multiple depths (Months 6-12 = 2027-04-12 to 2027-10-12). Establish subsidence and temperature-monitoring network starting Month 6 (2027-04-12), with monthly measurements through Month 24 (2028-10-12).

**Responsible Body/Role:** Design Lead - Bridge / Geotechnical Engineer (Operations Council supporting role)

**Suggested Timeframe:** Month 0 (2026-10-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Geotechnical Investigation Program Charter and drilling/testing schedule (Month 0 = 2026-10-12)
- Core samples collected and logged (Months 0-6 = 2026-10-12 to 2027-04-12)
- Laboratory test results and soil characterization (Months 3-9 = 2027-01-12 to 2027-07-12)
- In-situ test data and soil-profile interpretation (Months 6-12 = 2027-04-12 to 2027-10-12)
- Subsidence and Temperature-Monitoring Network established (Month 6 = 2027-04-12)

**Dependencies:**

- Operations Council established
- Design Lead - Bridge appointed
- Survey and site access rights obtained
- Funding approved for drilling and lab testing

### 34. Design Lead - Bridge (with seismic specialist support) conducts site-specific seismic hazard analysis using latest regional earthquake catalogs and ground-motion prediction models. Analysis complete by Month 6 (2027-04-12). Run coupled seismic-permafrost finite-element analyses (Months 9-12 = 2027-07-12 to 2027-10-12) to model ground response during design-basis earthquake. Summary report and seismic-design recommendations to Technical Advisory Group by Month 12 (2027-10-12).

**Responsible Body/Role:** Design Lead - Bridge (with Seismic Engineer or external specialist support)

**Suggested Timeframe:** Month 3 (2027-01-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Site-Specific Seismic Hazard Analysis Report (Month 6 = 2027-04-12)
- Ground-Motion Prediction Models and design-basis earthquake definition
- Coupled Seismic-Permafrost FE Analysis (Months 9-12 = 2027-07-12 to 2027-10-12)
- Seismic Design Recommendations and loading assumptions (Month 12 = 2027-10-12)

**Dependencies:**

- Design Lead - Bridge appointed
- Seismic engineer or consultant identified
- Geotechnical investigation data available (ice/permafrost characterization)

### 35. Environmental and Permitting Lead (Operations Council voting member) coordinates NEPA/EIA baseline surveys and stakeholder engagement. US NEPA environmental impact statement process initiated Month 0 (2026-10-12); Russian EIA equivalent engaged simultaneously. Baseline surveys (marine mammals, fish, habitats, water quality) run Months 0-12 (2026-10-12 to 2027-10-12) with Indigenous community researchers co-leading (per Indigenous-engagement protocol). Framework permit applications submitted Months 6-9 (2027-04-12 to 2027-07-12); detailed marine permits applied for Months 12-15 (2027-10-12 to 2028-01-12).

**Responsible Body/Role:** Environmental and Permitting Lead (Operations Council voting member)

**Suggested Timeframe:** Month 0 (2026-10-12) to Month 18 (2028-04-12 to 2028-04-12)

**Key Outputs/Deliverables:**

- NEPA and EIA Engagement Letters to US/Russian agencies (Month 0 = 2026-10-12)
- Baseline Marine-Mammal Survey Report (Months 0-12 = 2026-10-12 to 2027-10-12, co-authored with Indigenous researchers)
- Baseline Fisheries and Habitat Assessment (Months 0-12 = 2026-10-12 to 2027-10-12)
- Framework Permit Applications (submitted Months 6-9 = 2027-04-12 to 2027-07-12)
- Detailed Marine-Permit Applications (submitted Months 12-15 = 2027-10-12 to 2028-01-12)
- Permit Approval Timeline Tracker (updated monthly)

**Dependencies:**

- Environmental Lead appointed
- Indigenous-Engagement Specialist and community researchers engaged
- NOAA, US Fish and Wildlife and Russian environmental agencies identified
- Funding approved for baseline surveys

### 36. Operations Council (Finance Manager lead) initiates investor-engagement process by Month 1 (2026-11-12). Identify and pre-qualify 5-10 target lenders and equity investors (development banks, infrastructure funds, export-credit agencies, non-US and non-Russian where possible). Conduct one-on-one meetings with each (Months 1-3 = 2026-11-12 to 2027-01-12) to understand sanctions policies, Arctic-project experience and term expectations. Issue preliminary Information Memorandum (Months 3-4 = 2027-01-12 to 2027-02-12) outlining project, deal structure and financial assumptions.

**Responsible Body/Role:** Finance and Commercial Manager (Operations Council voting member)

**Suggested Timeframe:** Month 0.5 (2026-10-27) to Month 4 (2027-02-12 to 2027-02-12)

**Key Outputs/Deliverables:**

- Target Lender and Investor List (5-10 identified, Month 1 = 2026-11-12)
- One-on-One Meeting Schedule and notes (Months 1-3 = 2026-11-12 to 2027-01-12)
- Preliminary Information Memorandum (Months 3-4 = 2027-01-12 to 2027-02-12)
- Lender Feedback Summary and deal-structure refinement

**Dependencies:**

- Finance Manager appointed
- Project Execution Plan and cost baseline available
- Financing structure (third-country consortium, debt/equity split) finalized

### 37. Finance Manager (Operations Council) hosts an Investor Roundtable (Months 4-5 = 2027-02-12 to 2027-03-12) presenting the project plan, deal structure and financial assumptions to identified lenders and investors. Field questions and assess lender interest in participating in later syndication and term-sheet negotiation. Consolidate lender feedback for deal-structure refinement.

**Responsible Body/Role:** Finance and Commercial Manager (Operations Council voting member)

**Suggested Timeframe:** Month 4 (2027-02-12) to Month 5 (2027-03-12 to 2027-03-12)

**Key Outputs/Deliverables:**

- Investor Roundtable Event (held Months 4-5 = 2027-02-12 to 2027-03-12)
- Presentation Materials (project overview, financials, risk summary)
- Lender Q&A Summary and feedback consolidation
- Refinement recommendations for deal structure and term sheet

**Dependencies:**

- Preliminary Information Memorandum completed
- Cost baseline and revenue assumptions available
- Target lenders and investors confirmed

### 38. Finance Manager (Operations Council) organizes a formal Financing Roadmap Workshop (Month 6 = 2027-04-12) with 2-3 target lead arrangers and the project Steering Committee. Align on financing structure (third-country SPV, debt/equity split, take-or-pay pre-sales, sanctions-licensing pathway), term expectations and gating conditions. Negotiate heads of terms with at least 2-3 lead arrangers (Months 6-9 = 2027-04-12 to 2027-07-12) to demonstrate lender confidence in financing viability.

**Responsible Body/Role:** Finance and Commercial Manager (Operations Council), with Steering Committee participation

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 9 (2027-07-12 to 2027-07-12)

**Key Outputs/Deliverables:**

- Financing Roadmap Workshop (Month 6 = 2027-04-12)
- Heads of Terms negotiation (Months 6-9 = 2027-04-12 to 2027-07-12)
- Heads of Terms (signed with 2-3 lead arrangers by Month 9 = 2027-07-12)
- Financing Structure Summary and path to Financial Close (Month 9 = 2027-07-12)

**Dependencies:**

- Investor Roundtable completed
- Cost basis and preliminary revenue assumptions available
- Sanctions-licensing pathway clarified by Compliance Officer
- Steering Committee established to oversee financing approvals

### 39. Steering Committee formally initiates Gate 1 review process (Month 6 = 2027-04-12). Gate 1 decision criteria include: (1) financing roadmap endorsed by 2+ lead lenders, (2) written OFAC/export-control guidance received, (3) traffic study and Cost Basis Document published, (4) treaty/framework negotiation complete or framework agreement in advanced negotiation. Gate 1 review meeting (Month 6 = 2027-04-12), with gate decision by Month 6.5 (2027-04-27) (proposed 2-4 week review, 1 week decision window). If Gate 1 passes, proceed to detailed design and permitting; if not passed, enter paid-pause protocol (3-6 month pause for remediation).

**Responsible Body/Role:** Steering Committee (chaired by Steering Committee Chair)

**Suggested Timeframe:** Month 5.5 (2027-03-27) to Month 6.5 (2027-04-27 to 2027-05-07)

**Key Outputs/Deliverables:**

- Gate 1 Pass/Fail Criteria Checklist (Month 5.5 = 2027-03-27)
- Gate 1 Review Meeting Agenda and documentation package
- Gate 1 Decision and Minutes (Month 6.5 = 2027-04-27)
- Gate 1 Approval Memo (if pass) or Paid-Pause Trigger (if fail)

**Dependencies:**

- Steering Committee established and operative
- Cost Basis Document and traffic study published
- OFAC guidance letter received
- Financing roadmap workshop and heads-of-terms negotiation complete

### 40. Indigenous Engagement Specialist finalizes Beringia Indigenous Council formation and supports negotiation of formal consent agreements with each identified Indigenous community (Months 6-12 = 2027-04-12 to 2027-10-12). Each community's legal advisor reviews consent-agreement scope and binding authority. Agreements must specify: (1) what decisions require consent, (2) what constitutes informed consent, (3) dispute resolution, (4) benefit-sharing. Secure >75% Council consensus and all community signatures by Month 12 (2027-10-12) (proposed gating condition for design freeze).

**Responsible Body/Role:** Indigenous Engagement Specialist (Operations Council supporting role) and Beringia Indigenous Council

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 12 (2027-10-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Beringia Indigenous Council monthly meeting minutes (Months 6-12 = 2027-04-12 to 2027-10-12)
- Formal Consent Agreements with each community (8-12 agreements, executed by Month 12 = 2027-10-12)
- Council consensus letter endorsing project alignment and mitigation measures (Month 12 = 2027-10-12)
- Benefit-Fund governance agreement and annual allocation plan

**Dependencies:**

- Beringia Indigenous Council formed and operative
- Community legal advisors in place
- EIS/EIA and baseline studies available for community review
- Design alignment and seasonal work-window schedule available

### 41. Operations Council (Design Lead - Bridge and Design Lead - Tunnel) initiates preliminary and critical design reviews. Preliminary design phase (Months 6-12 = 2027-04-12 to 2027-10-12) produces draft tower designs, cable analyses, tunnel element cross-sections and foundation layouts, incorporating ice, seismic and permafrost loads per observational-design methodology. Critical design review (Months 12-15 = 2027-10-12 to 2028-01-12) with independent external reviewers (HDR, Jacobs or equivalent) identifies safety risks and design adequacies before design freeze decision.

**Responsible Body/Role:** Design Lead - Bridge and Design Lead - Tunnel (Operations Council voting members)

**Suggested Timeframe:** Month 6 (2027-04-12) to Month 15 (2028-01-12 to 2028-01-12)

**Key Outputs/Deliverables:**

- Preliminary Design Report (bridge towers, cables, tunnel sections, Months 6-12 = 2027-04-12 to 2027-10-12)
- Preliminary Design Drawings (30% design-stage drawings)
- Critical Design Review Report (Months 12-15 = 2027-10-12 to 2028-01-12)
- Independent Design-Review Findings (external reviewer, 2-week turnaround after submission)
- Design-Freeze Readiness Assessment (data-confidence evaluation)

**Dependencies:**

- Design Leads appointed
- Ice-monitoring and geotechnical investigation data available
- Seismic hazard analysis complete
- Technical Advisory Group in place for expert input

### 42. Technical Advisory Group conducts formal design-adequacy review and certification (Month 15 = 2028-01-12). TAG assesses preliminary design, ice-load models, seismic-design assumptions and permafrost-thaw models for adequacy. If data confidence is within +/-15% (proposed threshold) and design safety margins are acceptable, TAG issues design-freeze certification. If confidence is wider or safety concerns exist, TAG recommends design-freeze deferral and extended monitoring (3-6 months). TAG findings documented in formal letter to Steering Committee.

**Responsible Body/Role:** Technical Advisory Group (chaired by TAG Chair)

**Suggested Timeframe:** Month 15 (2028-01-12)

**Key Outputs/Deliverables:**

- TAG Design-Adequacy Review Report (Month 15 = 2028-01-12)
- Ice-Load Certification (data quality and confidence level documented)
- Seismic and Permafrost Analysis Certification
- Design-Freeze Certification or Deferral Recommendation Letter
- TAG Consensus Summary (if any member dissents, dissent documented)

**Dependencies:**

- Technical Advisory Group established and operative
- Preliminary design complete
- Ice-monitoring and geotechnical data available (12-15 months of collection)
- Critical design review findings available

### 43. Steering Committee formally initiates Gate 2 review (Month 12 = 2027-10-12). Gate 2 criteria: (1) heads of terms signed with 2-3 lead arrangers, (2) Indigenous consent agreements executed and Beringia Council endorsed, (3) contractor bids within 5% of parametric baseline, (4) binational work-permit protocol agreed, (5) pilot element trial complete and successful. Gate 2 review meeting (Month 12 = 2027-10-12), with decision by Month 12.5 (2027-10-27) (proposed 2-3 week review). Pass/fail determines advance to design freeze or entry into paid-pause remediation.

**Responsible Body/Role:** Steering Committee (chaired by Steering Committee Chair)

**Suggested Timeframe:** Month 11.5 (2027-09-27) to Month 12.5 (2027-10-27 to 2027-11-07)

**Key Outputs/Deliverables:**

- Gate 2 Pass/Fail Criteria Checklist (Month 11.5 = 2027-09-27)
- Gate 2 Review Meeting documentation (heads of terms, consent agreements, bid summaries, pilot-trial results)
- Gate 2 Decision and Minutes (Month 12.5 = 2027-10-27)
- Gate 2 Approval Memo (if pass) or Paid-Pause Trigger (if fail)

**Dependencies:**

- Steering Committee operative
- Heads of terms signed with lead lenders
- Indigenous consent agreements finalized
- Pilot element trial complete (Months 9-12 = 2027-07-12 to 2027-10-12)
- Contractor bids or pre-qualification results available

### 44. Operations Council (Design Lead - Bridge and Design Lead - Tunnel) finalizes design freeze package incorporating TAG certification and independent-design review findings. Design-freeze meeting (Month 18 = 2028-04-12) with Technical Advisory Group, Steering Committee and independent reviewers. Steering Committee formally approves design freeze at Month 18 (2028-04-12) if TAG certification is issued and ice/seismic/permafrost data confidence thresholds are met. If TAG withholds certification due to data gaps, design freeze is deferred 3-6 months (paid pause triggered).

**Responsible Body/Role:** Operations and Execution Council (Design Leads, Owner's Engineer Integrator)

**Suggested Timeframe:** Month 15 (2028-01-12) to Month 18 (2028-04-12 to 2028-04-12)

**Key Outputs/Deliverables:**

- Final Design Package (60% design-stage drawings with all refinements)
- Design-Freeze Justification Memo (data adequacy, safety margins, TAG certification)
- Design-Freeze Meeting (Month 18 = 2028-04-12)
- Steering Committee Design-Freeze Approval Memo (Month 18 = 2028-04-12)
- Design-Frozen Documents package (signed and distributed to all parties)

**Dependencies:**

- Technical Advisory Group design-adequacy review complete
- Independent design review findings incorporated
- Ice-monitoring and geotechnical investigation data available (18 months collection)
- Preliminary design and critical design review complete

### 45. Steering Committee formally initiates Gate 3 review (Month 18 = 2028-04-12). Gate 3 criteria: (1) design freeze approved on data adequacy (ice-load confidence within +/-15%), (2) detailed marine permits issued or approval anticipated, (3) financial close scheduled by Month 24 (2028-10-12), (4) Indigenous consent agreements and Beringia Council governance finalized. Gate 3 review (Month 18 = 2028-04-12), decision by Month 18.5 (2028-04-27). Pass enables advancement to financial close and construction mobilization planning; fail triggers paid pause and extended permitting or design refinement.

**Responsible Body/Role:** Steering Committee (chaired by Steering Committee Chair)

**Suggested Timeframe:** Month 17.5 (2028-03-27) to Month 18.5 (2028-04-27 to 2028-05-07)

**Key Outputs/Deliverables:**

- Gate 3 Pass/Fail Criteria Checklist (Month 17.5 = 2028-03-27)
- Gate 3 Review Meeting documentation (design-freeze approval, permitting status, financial close roadmap)
- Gate 3 Decision and Minutes (Month 18.5 = 2028-04-27)
- Gate 3 Approval Memo or Paid-Pause Trigger

**Dependencies:**

- Steering Committee operative
- Design freeze approved by Operations Council
- Environmental and Permitting Lead confirms permit path
- Finance Manager confirms financial-close roadmap (Month 24 = 2028-10-12 target)

### 46. Finance Manager (Operations Council) drives Financial Close Phase: finalize debt and equity documentation (Months 18-24 = 2028-04-12 to 2028-10-12), obtain all lender and investor board approvals, execute financing agreements and secure all funds in escrow or committed facilities. Financial Close Milestone (Month 24 = 2028-10-12) requires execution of debt and equity agreements, proof of funds or irrevocable commitments from all lenders and equity investors, and release of initial funding tranches for construction mobilization.

**Responsible Body/Role:** Finance and Commercial Manager (Operations Council voting member)

**Suggested Timeframe:** Month 18 (2028-04-12) to Month 24 (2028-10-12 to 2028-10-12)

**Key Outputs/Deliverables:**

- Financing Documentation Package (credit agreements, equity agreements, security documents)
- Lender Board Approvals (obtained for each lead arranger)
- Equity Investor Board Approvals (obtained for each equity fund)
- Financial-Close Certificate (Month 24 = 2028-10-12, executed by lead arrangers and equity sponsors)
- Funding Tranches released to Project Account (proof of funds)

**Dependencies:**

- Heads of Terms signed with lead lenders (Month 9 = 2027-07-12)
- Design freeze approved (Month 18 = 2028-04-12)
- Permits (framework and detailed marine) obtained or approved
- Sanctions licensing confirmed (pre-approved supplier list available)

### 47. Compliance Officer (Risk Committee) confirms final Sanctions and Export-Control compliance (Months 18-24 = 2028-04-12 to 2028-10-12). Obtain written final OFAC and export-control licensing confirmation covering financing entities, equipment suppliers and personnel movement. Finalize Pre-Approved Supplier List by Month 24 (2028-10-12). Compliance Officer maintains ongoing OFAC/export-control monitoring and reporting throughout construction (Months 24-180 = 2028-10-12 to 2041-10-12), with quarterly compliance reviews.

**Responsible Body/Role:** Compliance Officer (Risk Committee, reporting to Risk and Compliance Committee Chair)

**Suggested Timeframe:** Month 18 (2028-04-12) to Month 24 (2028-10-12 to 2028-10-12)

**Key Outputs/Deliverables:**

- Final OFAC Licensing Confirmation Letter (Month 24 = 2028-10-12)
- Final Export-Control Licensing Pathway (EAR, ITAR, Russian controls approval)
- Pre-Approved Supplier and Contractor List (finalized by Month 24 = 2028-10-12)
- Ongoing OFAC Compliance Monitoring Protocol (quarterly reviews, Months 24-180 = 2028-10-12 to 2041-10-12)
- Sanctions Escalation Alerts (if regulatory environment changes)

**Dependencies:**

- Preliminary OFAC guidance received (Month 6 = 2027-04-12)
- Financing entities and suppliers finalized
- Lender OFAC compliance requirements confirmed

### 48. Steering Committee formally initiates Gate 4 review and decision (Month 24 = 2028-10-12). Gate 4 criteria: (1) framework agreement/concessions executed by both US and Russian governments, (2) sanctions licences confirmed in writing, (3) financial close achieved (funding in place), (4) construction mobilization plan approved. Gate 4 review (Month 24 = 2028-10-12), decision within 1 week (Month 24.25 = 2028-10-20). Pass authorizes construction mobilization (earliest Months 24-30 = 2028-10-12 to 2029-04-12). Fail triggers paid-pause exit provision (3-6 months paid pause, then exit if conditions not met by Month 30 = 2029-04-12).

**Responsible Body/Role:** Steering Committee (chaired by Steering Committee Chair)

**Suggested Timeframe:** Month 23.5 (2028-09-27) to Month 24.25 (2028-10-20 to 2028-10-19)

**Key Outputs/Deliverables:**

- Gate 4 Pass/Fail Criteria Checklist (Month 23.5 = 2028-09-27)
- Gate 4 Review Meeting (Month 24 = 2028-10-12, documentation: framework agreement, sanctions confirmation, financial-close certificate, mobilization plan)
- Gate 4 Decision and Minutes (Month 24.25 = 2028-10-20)
- Gate 4 Approval Memo (if pass) or Exit-Provision Trigger (if fail)

**Dependencies:**

- Steering Committee operative
- Framework agreement/concessions negotiated with US and Russian governments
- Financial close achieved (debt and equity executed)
- Sanctions licensing confirmed
- Construction mobilization plan prepared by Operations Council

### 49. Steering Committee Chair formally schedules and convenes the first Steering Committee Kick-Off Meeting (Month 3 = 2027-01-12) once the Charter is finalized and all voting members are appointed and confirmed. At this inaugural meeting: (1) Chair welcomes members and confirms decision authorities, (2) review project overview and governance structure, (3) present Detailed Project Execution Plan and gate schedule, (4) establish monthly-meeting cadence and committee norms, (5) discuss strategic risks and compliance requirements, (6) assign reporting responsibilities to Operations Council and committee members. Distribute meeting minutes and action items within 1 week.

**Responsible Body/Role:** Steering Committee Chair (with Project Manager support)

**Suggested Timeframe:** Month 3 (2027-01-12)

**Key Outputs/Deliverables:**

- Steering Committee Kick-Off Meeting Agenda and materials (Month 3 = 2027-01-12)
- Meeting Minutes and Action Items Log
- Steering Committee Member Handbook (governance, decision process, escalation)
- Monthly-Meeting Calendar (Months 3-24 = 2027-01-12 to 2028-10-12)
- Committee Communication Protocol (email, document sharing, confidentiality)

**Dependencies:**

- Steering Committee Charter finalized and signed
- All voting members appointed and confirmed
- Detailed Project Execution Plan published
- Project Sponsor briefed and expectations set

### 50. Operations and Execution Council Chair formally schedules and convenes the first Operations Council Kick-Off Meeting (Month 3 = 2027-01-12) once the Charter is finalized and all voting members are appointed. At this inaugural meeting: (1) Chair establishes weekly-meeting routine and norms, (2) review project execution plan and Operations Council authorities, (3) present design schedule, permitting roadmap and Indigenous-engagement milestones, (4) assign lead roles for each workstream (design, permitting, cost, Indigenous engagement, logistics), (5) establish reporting to Steering Committee (monthly high-level summaries), (6) discuss operational risks and change-control thresholds. Distribute minutes and action items within 2 business days.

**Responsible Body/Role:** Operations and Execution Council Chair

**Suggested Timeframe:** Month 3 (2027-01-12)

**Key Outputs/Deliverables:**

- Operations Council Kick-Off Meeting Agenda and materials
- Meeting Minutes and Action Items Log
- Operations Council Member Handbook (authorities, change control, escalation, interface management)
- Weekly-Meeting Calendar (Months 3-60 = 2027-01-12 to 2031-10-12)
- Operations Council Communication and Document-Sharing Protocol

**Dependencies:**

- Operations Council Charter finalized and signed
- All voting members appointed and confirmed
- Detailed Project Execution Plan published
- Steering Committee established

### 51. Technical Advisory Group Chair formally schedules and convenes the first TAG Kick-Off Meeting (Month 3 = 2027-01-12) once all TAG members are recruited and confirmed. At this inaugural meeting: (1) Chair welcomes members and clarifies TAG roles (expert advice, design-freeze certification, escalation of Major Issues), (2) review project technical scope and data-collection plans, (3) present ice-monitoring, geotechnical and seismic investigation schedules, (4) establish quarterly-meeting schedule (Months 3, 6, 9, 12, 15, 18 = 2027-01-12 to 2028-04-12), (5) define data-flow protocols from Operations Council (monthly raw data, design models), (6) discuss escalation thresholds for design-adequacy concerns. Minutes and action items distributed within 1 week.

**Responsible Body/Role:** Technical Advisory Group Chair

**Suggested Timeframe:** Month 3 (2027-01-12)

**Key Outputs/Deliverables:**

- TAG Kick-Off Meeting Agenda and materials
- Meeting Minutes and Action Items Log
- TAG Member Handbook (authorities, confidentiality, decision mechanism, escalation)
- Quarterly-Meeting Schedule and deliverables calendar (Months 3-18 = 2027-01-12 to 2028-04-12)
- TAG Data-Flow Protocol from Operations Council (monthly data delivery schedule)

**Dependencies:**

- Technical Advisory Group Charter finalized
- All TAG members recruited and confirmed
- Ice, geotechnical and seismic monitoring programs initiated (Month 0 = 2026-10-12)
- Operations Council established

### 52. Indigenous Engagement Specialist formally schedules and convenes the first Beringia Indigenous Council Meeting (Month 6 = 2027-04-12) after community participation commitments are secured. At this inaugural meeting: (1) Indigenous Council Chair facilitates opening and welcomes all community delegates, (2) Council Charter is reviewed and voted on by all member communities (>75% consensus required), (3) Council governance structure, decision process and dispute-resolution mechanism established, (4) monthly meeting schedule agreed (Months 6-12 = 2027-04-12 to 2027-10-12 during consent-agreement negotiation), (5) benefit-fund governance framework introduced, (6) project alignment and mitigation measures presented for community feedback. Minutes documented in English and Indigenous languages where applicable.

**Responsible Body/Role:** Indigenous Engagement Specialist and Beringia Indigenous Council Chair

**Suggested Timeframe:** Month 6 (2027-04-12)

**Key Outputs/Deliverables:**

- Beringia Indigenous Council Inaugural Meeting Agenda
- Meeting Minutes (in English and community languages)
- Council Charter Voted and Approved (>75% consensus)
- Council Member Roster and delegate contacts
- Monthly-Meeting Schedule (Months 6-12 = 2027-04-12 to 2027-10-12)
- Council Communication Protocol and confidentiality agreement

**Dependencies:**

- Community participation commitment letters obtained
- Beringia Council Formation Charter finalized
- Indigenous community legal advisors engaged
- Benefit-fund governance framework drafted

### 53. Risk, Compliance and Insurance Committee Chair formally schedules and convenes the first Risk Committee Kick-Off Meeting (Month 3 = 2027-01-12) once the Charter is finalized and all committee members are confirmed. At this inaugural meeting: (1) Chair establishes monthly-meeting cadence and risk-review process, (2) present comprehensive risk register (20-30 identified risks) with owners and mitigation actions, (3) define leading-indicator thresholds (cost >5%, schedule >2 months, DSCR <1.3x, OFAC delays >3 months), (4) establish risk-monitoring and escalation protocols to Steering Committee, (5) discuss insurance-procurement roadmap and political-risk insurance strategy, (6) define compliance checklist for NEPA/EIA, Indigenous consultation, export controls and permits. Distribute minutes and risk-register tracking sheet within 1 week.

**Responsible Body/Role:** Risk, Compliance and Insurance Committee Chair

**Suggested Timeframe:** Month 3 (2027-01-12)

**Key Outputs/Deliverables:**

- Risk Committee Kick-Off Meeting Agenda and materials
- Risk Register v1.0 (20-30 risks, owners, mitigations, escalation criteria)
- Leading-Indicator Dashboard (cost, schedule, covenant ratios, permitting tracking)
- Compliance Checklist (NEPA/EIA, Indigenous consultation, export controls, permits)
- Meeting Minutes and action items
- Monthly Risk-Reporting Template and schedule (starting Month 3 = 2027-01-12)

**Dependencies:**

- Risk Committee Charter finalized
- Compliance Officer and Risk Manager appointed
- Risk assessment or risk-file inputs available
- Steering Committee established (for escalation alignment)

# Decision Escalation Matrix

**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of cost variance >5% (USD 5 billion or trend indicating >10% final overrun); Finance Manager submits variance report with root-cause analysis and mitigation options; Committee votes on contingency release, design refinement, schedule adjustment or project restructuring within 2-week review window.
Rationale: Cost overruns of 10–30% (USD 10–30 billion) are plausible if Arctic logistics, foundation unknowns or contractor risk premiums exceed baseline. At 20% overrun, debt service coverage falls below 1.2x covenant threshold, triggering default risk. PMO-level cost management cannot absorb overruns of this magnitude or authorize covenant breach. Escalation allows strategic trade-off decisions (schedule slip, scope reduction, contingency draw) that only sponsor-level authority can make.
Negative Consequences: Unescalated cost overrun beyond available contingency (USD 15 billion) leaves USD 10–15 billion unfunded, forcing mid-construction financing restructuring or project abandonment. Debt covenant breach triggers lender default provisions, asset seizure, and operational control transfer to lenders. Equity investor losses of USD 15–46 billion. Reputational damage and loss of binational political support.

**Critical Risk Materialization: Geopolitical Break or Sanctions Escalation**
Escalation Level: Project Steering Committee and Diplomatic Channels (US State Department, Russian Foreign Ministry)
Approval Process: Risk Committee flags geopolitical incident (sanctions escalation, major US–Russia diplomatic break affecting project) within 24 hours; Emergency Steering Committee meeting convened within 48 hours. Steering Committee assesses impact on financing (lender withdrawal, licensing revocation), equipment sourcing (export-control tightening, supplier list reduction), and personnel movement (visa bans). If impact is existential (lenders withdraw, key suppliers become unavailable, personnel cannot cross border), Steering Committee escalates to diplomatic channels for government-level negotiation on sanctions carve-outs or project exemption. Decision on project continuation, funded pause, or exit made within 1–2 weeks.
Rationale: Sanctions, export controls and US–Russia political tension are binary kill-switch risks outside project operational control. A single major geopolitical event (sanctions escalation on Russia, visa ban on Russian nationals, financing lender facing compliance restrictions) can strangle financing or supply chains within days. PMO cannot negotiate with governments or lenders on exemptions or policy. Sponsor-level escalation to diplomatic channels is required to explore sanctioned carve-outs, alternative financing or personnel arrangements.
Negative Consequences: Unescalated geopolitical shock leaves project with no financing (lenders withdraw within 30–60 days of sanctions escalation), no suppliers (export licenses revoked), and no personnel (visa bans prevent cross-border work). Construction halts, equipment and crews stranded on site, estimated loss of USD 100–500 million. Potential loss of strategic geopolitical relationship between governments. Long-term erosion of public and investor confidence in binational mega-projects.

**PMO Deadlock on Critical Operational Decision**
Escalation Level: Project Steering Committee and Neutral Arbiter
Approval Process: Operations Council unable to reach consensus on interface conflict, design-freeze adequacy or contractor dispute after 2 meetings (2-week window). Issue escalated to neutral external arbiter (independent megaproject engineer with binding decision authority, appointed Month 6 = 2027-04-12) for resolution within 2 weeks. Arbiter reviews both sides, issues written decision on technical merits. If arbiter decision conflicts with lender or government priority, Steering Committee may override arbiter decision by majority vote, but must document rationale. Design-freeze deadlock or major interface conflict unresolved by arbiter within 2 weeks escalates to Steering Committee for strategic direction (e.g., design refinement, schedule deferral, scope reduction).
Rationale: Decisions such as design-freeze adequacy (ice-load data confidence, seismic assumptions), interface conflicts (tower foundation settlement affecting tunnel approach), or contractor risk allocation (who bears Arctic logistics uncertainty) require technical expertise and impartial assessment. PMO members may have conflicting incentives (cost vs. schedule, lender risk appetite vs. design conservatism). Deadlock over design freeze can delay financial close and construction start by 3–6 months. Neutral arbiter breaks deadlock on technical grounds; Steering Committee escalates only if arbiter decision conflicts with strategy or lender requirements.
Negative Consequences: Unresolved operational deadlock causes schedule slip of 1–3 months per incident, compounding across design and construction phases (total slip of 6–18 months by end of Phase 1). Design freeze delayed beyond Month 18 (2028-04-12) pushes construction start past optimal open-water seasons, reducing seasonal work windows and extending critical-path activities. Interface conflicts unresolved during design phase cause expensive rework or site disputes during construction (cost USD 50–200 million per incident). Contractor claims and litigation if responsibility for deadlock resolution is ambiguous.

**Proposed Major Scope Change or Alignment Deviation**
Escalation Level: Project Steering Committee and Beringia Indigenous Council
Approval Process: Operations Council receives request for scope change (e.g., shift tunnel alignment to avoid sensitive marine-mammal habitat, add road lanes to Phase 1, exclude pressurized pipelines). If change cost impact >USD 100 million or schedule slip >6 months, or if change affects Indigenous traditional-use area, escalate to Steering Committee for policy review. Steering Committee reviews cost/schedule/technical impact and consults with Beringia Indigenous Council if alignment or seasonal work-window changes are proposed. Indigenous Council holds binding advisory authority over alignment and work-window modifications; Council consent (>75% vote) is required before design or permitting changes advance. If Indigenous Council withholds consent on alignment grounds, Steering Committee must either negotiate design alternative or escalate to governments for diplomatic resolution.
Rationale: Major scope changes (alignment shift, Phase 1 road addition, utility corridor expansion) redraw the project's cost, schedule and environmental footprint, affecting financing assumptions, permit conditions and Indigenous subsistence rights. Changes of USD 100+ million or >6 months exceed PMO change-control authority and require strategic trade-off decisions (delay Phase 1, request more contingency, redesign approach). Indigenous consent authority over alignment and work windows is a binational commitment and legal requirement; unilateral PMO decisions risk injunctions and permitting delays. Scope changes must be escalated to allow sponsor-level negotiation with governments and Indigenous communities.
Negative Consequences: Unescalated scope change implemented without Indigenous consultation triggers injunctions and litigation (3–12 month delays, USD 5–20 million legal costs). Design or permitting changes made without Steering Committee knowledge cause surprise cost overruns or schedule slips that exceed contingency (unbudgeted cost of USD 5–50 million per incident). Changed alignment discovered late in construction requires rework, foundation redesign or tunnel re-routes (cost USD 50–200 million, schedule slip 6–18 months). Loss of Indigenous support and social license, complicating operations and future phases.

**Reported Ethical Violation, Fraud, or Sanctions Compliance Breach**
Escalation Level: Risk, Compliance and Insurance Committee and Project Sponsor
Approval Process: Compliance Officer or project staff reports suspected violation (fraud in contractor billing, bribery or corruption in vendor selection, sanctions breach such as undisclosed Russian entity ownership in supplier, environmental impact misrepresentation). Risk Committee Chair immediately notifies Project Sponsor and initiates fact-finding (within 24–72 hours). Committee determines if violation is minor (operational correctable issue) or major (legal/regulatory exposure). Minor violations (e.g., procurement documentation error) are corrected by Operations Council with Compliance Officer oversight. Major violations (potential fraud, sanctions breach, environmental non-compliance) trigger formal investigation by external independent counsel, suspension of affected contractors or suppliers, and reporting to regulatory authorities (OFAC, FBI, EPA equivalent) as legally required. Investigation findings and remediation plan escalated to Steering Committee and Project Sponsor for decision on project continuation, remedial action or escalation to law enforcement.
Rationale: Ethical violations and sanctions breaches expose the project to criminal liability, asset seizure, financing lender default (lender policy violation), loss of banking relationships, and operational shutdown. A contractor-fraud scheme unchecked can inflate costs by 10–20%, or a sanctions-compliance breach can trigger OFAC penalties and financing cancellation. PMO cannot make decisions on regulatory reporting, investigation scope or disciplinary action affecting contractors—these require independent assessment and sponsor/government authorization. Delays in escalation allow evidence destruction or exposure to expand, worsening legal and reputational damage.
Negative Consequences: Unreported or mishandled ethical violation exposes project to criminal prosecution, OFAC fines (up to 20% of transaction value, potentially USD 5–15 billion), financing lender default and asset freeze, loss of project insurance coverage. Sanctioned individual or entity may have already transferred USD millions fraudulently. Regulatory investigation and potential project shutdown lasting 6–18 months. Reputational damage to US and Russian governments and investor confidence in binational projects. Inability to obtain future financing or insurance.

**Design-Freeze Gate Data Inadequacy or Technical Advisory Group Certification Withheld**
Escalation Level: Project Steering Committee and Technical Advisory Group
Approval Process: Technical Advisory Group (at Month 18 = 2028-04-12 design-freeze review) assesses ice-load monitoring data, seismic analysis and permafrost models for confidence level. If data confidence is within +/−15% and design safety margins are acceptable, TAG issues design-freeze certification. If confidence is wider (±20% or greater) or safety concerns exist, TAG withholds certification and recommends design-freeze deferral. Operations Council escalates TAG recommendation to Steering Committee with impact analysis: deferral of 3–6 months delays financial close and construction start; continued design freeze on uncertain data risks post-construction repairs (USD 50–200 million cost per incident). Steering Committee decides on design-freeze deferral or conditional approval with enhanced monitoring/contingency.
Rationale: Design freeze on ice, seismic and permafrost loads that exceed data confidence thresholds locks in structural assumptions that may be wrong, leaving high post-construction liability. The observational design approach depends on 12–18 months of monitoring to reduce uncertainty before irreversible foundation commitment. If monitoring is delayed, incomplete or inconclusive, design freeze is premature. TAG certification authority prevents premature freeze; PMO alone cannot assess technical adequacy or data quality. Steering Committee escalation allows strategic decision on schedule trade-off (accept delay for better data) vs. cost/risk trade-off (accept design risk for faster schedule).
Negative Consequences: Design freeze under-confident in ice or seismic loads causes pier or tower damage after construction (cost USD 50–200 million repair, 1–3 month closure per incident). Over-confident design freeze based on sparse data risks discovery of errors too late to retrofit economically. Deferral of design freeze beyond Month 21 (2028-07-12) compresses construction schedule and reduces open-water seasons, pushing Phase 1 commissioning past Month 180 (2041-10-12). Financing covenant breach if construction delays extend final cost or debt service coverage below 1.2x threshold.

# Monitoring Progress

### 1. Tracking Key Performance Indicators (KPIs) Against Project Baseline and Lender Covenants
**Monitoring Tools/Platforms:**

  - Project Management Software Dashboard (Primavera P6 or Oracle Cloud)
  - Monthly KPI Tracking Spreadsheet
  - Lender Covenant Compliance Report
  - Cost and Schedule Variance Dashboard

**Frequency:** Weekly during Months 0-24 (2026-10-12 to 2028-10-12); bi-weekly during Months 25-60 (2028-11-12 to 2031-10-12); monthly during Months 60-180 (2031-10-12 to 2041-10-12)

**Responsible Role:** Cost Engineer and Finance Manager (Operations and Execution Council) reporting to Steering Committee

**Adaptation Process:** Monthly variance review by Operations Council: if cost variance exceeds 5% or schedule slip exceeds 2 months, Finance Manager initiates reforecasting and repricing analysis. Cost changes >USD 10 million or schedule slip >6 months escalate to Steering Committee for decision on contingency release, scope reduction, or schedule adjustment. Debt service coverage ratio (DSCR) monitored against 1.2x covenant breach threshold; DSCR projected <1.3x triggers Steering Committee review of revenue assumptions, toll increases or cost mitigation. Variance trends (3+ consecutive months exceeding thresholds) trigger immediate escalation and corrective-action planning.

**Adaptation Trigger:** Cost variance >5% (USD 5 billion), schedule slip >2 months, DSCR projected <1.3x within 12 months, or trend of 3+ months exceeding thresholds. Covenant breach trigger at DSCR <1.2x or debt-to-equity ratio exceeding agreed ratio. Trigger thresholds are decision gates; reforecasting occurs at each gate (Months 6, 12, 18, 24 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12) and adjusted if project risk profile changes.

### 2. Regular Risk Register Review and Leading-Indicator Monitoring for Political, Financial and Technical Risk Clusters
**Monitoring Tools/Platforms:**

  - Comprehensive Risk Register (Excel or dedicated risk database)
  - Risk Dashboard with Leading Indicators (cost, schedule, DSCR, permitting milestones, Indigenous consent)
  - Monthly Risk Status Report to Steering Committee
  - Geopolitical and Sanctions Escalation Alert Log

**Frequency:** Weekly risk-indicator monitoring (cost variance, schedule slip, covenant ratios, permitting delays) with automated alerts. Monthly Risk Committee meetings and formal risk-register updates (Months 0-24 = 2026-10-12 to 2028-10-12). Bi-monthly during construction (Months 25-60 = 2028-11-12 to 2031-10-12). Quarterly during operations (Months 60-180 = 2031-10-12 to 2041-10-12). Emergency risk escalation within 24 hours if geopolitical incident or major risk materializes.

**Responsible Role:** Risk, Compliance and Insurance Committee Chair and Compliance Officer, supported by Steering Committee representation

**Adaptation Process:** Risk Committee identifies emerging risks or threshold breaches and proposes mitigation: (1) operational mitigation (design refinement, schedule adjustment, cost control) managed by Operations Council; (2) political/sanctions mitigation escalated to Steering Committee for government/lender engagement; (3) force-majeure events or existential risks (sanctions escalation, financing withdrawal, geopolitical break) trigger emergency Steering Committee meeting within 48 hours and escalation to diplomatic channels if required. Mitigation ownership assigned, target completion date set, and residual risk re-assessed at each risk-committee meeting. Closed risks removed from register; new risks added as identified.

**Adaptation Trigger:** Risk threshold breach: cost variance >5%, schedule slip >2 months, DSCR <1.3x, OFAC/export-control licensing delayed >3 months, permit milestone missed >1 month, Indigenous-consent dispute unresolved >6 weeks, geopolitical incident (sanctions escalation, major US-Russia diplomatic break, visa bans), major supplier failure or lender withdrawal. Each risk category has escalation criteria documented in risk register; Risk Committee escalates to Steering Committee within 1 week of threshold breach. Emergency escalation within 24 hours if risk impact is existential (financing loss, project abandonment trigger).

### 3. Political Gating and Confidence-Building Sequence: Tracking Treaty Ratification, Sanctions Licensing and Financial Close Against Explicit Decision Gates
**Monitoring Tools/Platforms:**

  - Gate-Readiness Checklist (Months 6, 12, 18, 24 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12)
  - Treaty and Framework Agreement Negotiation Timeline Tracker
  - OFAC and Export-Control Licensing Pathway Document (updated monthly)
  - Financing Roadmap and Heads-of-Terms Status Dashboard
  - Government Engagement Log (diplomatic meetings, regulatory submissions, approvals)

**Frequency:** Continuous monitoring of gate-readiness criteria. Monthly Steering Committee reviews (Months 0-24 = 2026-10-12 to 2028-10-12). Formal gate-clearance decision meetings at Months 6, 12, 18, 24 (2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12) with 2-4 week review window and 1-week decision window. Emergency escalation if gate-readiness indicator falls below 50% at midpoint between gate months.

**Responsible Role:** Steering Committee Chair, with support from Project Manager (treaty/framework tracking), Compliance Officer (sanctions/export-control pathway), Finance Manager (financing-close status) and Operations Council leadership

**Adaptation Process:** Gate-readiness tracked against explicit pass/fail criteria documented in gate-clearance checklists. If criteria are on track (>80% confidence), gate proceeds as scheduled. If criteria are at risk (50-80% confidence), remediation actions are assigned to responsible parties (e.g., accelerate treaty negotiation, submit OFAC licensing request, secure lender term-sheet commitment) with target completion before gate review. If criteria fall below 50% confidence or dependency fails (e.g., lender withdraws, treaty ratification blocked), Steering Committee triggers Paid Pause Protocol: 3-6 month funded pause (pre-gate spending limited to remediation), with exit provisions if gate criteria remain unmet by pause deadline (Month 30 = 2029-04-12 for Gate 4). Gate decisions (pass/defer/exit) are formally documented and communicated to all parties.

**Adaptation Trigger:** Gate-readiness indicator below 50% at midpoint between gate reviews, or explicit gate-readiness criterion failing (e.g., lender heads-of-terms not signed by Month 9 = 2027-07-12 target for Gate 2, or OFAC licensing pathway not received by Month 6 = 2027-04-12 target). Treaty negotiation slip >3 months beyond original schedule, sanctions-licensing uncertainty unresolved >6 weeks, financing roadmap without commitment from 2+ lead lenders >2 weeks after Months 6-9 (2027-04-12 to 2027-07-12) target. Any gate criterion flagged as fail at gate-review meeting triggers immediate Paid Pause and escalation per gate protocol. Emergency escalation within 48 hours if geopolitical event makes gate criteria unachievable (e.g., sanctions escalation prevents OFAC licensing, US-Russia diplomatic break stalls treaty negotiation).

### 4. Ice-Load, Seismic and Permafrost Observational Design Monitoring: Tracking Data Collection and Design-Freeze Gate Adequacy
**Monitoring Tools/Platforms:**

  - Ice-Monitoring Network Dashboard (drifting buoys, radar, satellite imagery, live data feeds)
  - Geotechnical Investigation Database (core logs, lab results, in-situ test data)
  - Seismic Hazard Analysis and Ground-Response Modeling Reports
  - Data-Confidence Scoring Matrix (ice, seismic, permafrost; target: within +/-15% by Month 18 = 2028-04-12)
  - Technical Advisory Group Monthly Data Summary and Quarterly Certification Reports

**Frequency:** Continuous ice-monitoring data collection (buoys, radar) starting Month 0 (2026-10-12). Weekly ice-data quality checks and summary (Months 6-18 = 2027-04-12 to 2028-04-12). Monthly geotechnical lab results review (Months 3-12 = 2027-01-12 to 2027-10-12). Quarterly Technical Advisory Group formal reviews (Months 3, 6, 9, 12, 15, 18 = 2027-01-12 to 2028-04-12). Design-freeze readiness assessment at Month 15 (2028-01-12); formal data-adequacy gate at Month 18 (2028-04-12).

**Responsible Role:** Design Lead - Bridge (ice and seismic lead), Owner's Engineer Integrator (geotechnical lead), and Technical Advisory Group (independent certification of data adequacy)

**Adaptation Process:** Monthly design-refinement incorporating newly available monitoring data: ice-load models updated as seasonal data accumulate; seismic and permafrost assumptions refined based on lab and in-situ testing. If data trends confirm design assumptions within expected ranges (confidence bands tightening toward +/-15% target), design proceeds on schedule toward freeze at Month 18 (2028-04-12). If data reveal higher loads or ground instability than assumed (e.g., ice floes larger or more frequent than historical baseline, permafrost thaw faster than models), design load cases are increased iteratively and foundation designs strengthened, extending design refinement into Months 18+ as needed. If data collection is delayed or inconclusive by Month 15 (2028-01-12), Technical Advisory Group recommends design-freeze deferral (3-6 month paid pause) to allow extended monitoring, triggering Steering Committee decision on schedule trade-off vs. design-uncertainty risk.

**Adaptation Trigger:** Data confidence falling below target (+/-15% threshold) at Month 15 (2028-01-12) leads to design-freeze deferral recommendation by TAG. Ice-load data showing 20%+ higher peak pressures than historical baseline, permafrost thaw rates 50%+ faster than models, or seismic ground-response uncertainties >20% trigger design-envelope review and potential specification tightening (cost increase of USD 5-15 billion estimated). Monitoring data collection 6+ weeks behind schedule at any point in Months 0-18 (2026-10-12 to 2028-04-12) escalates to Operations Council for expedited catch-up or alternative data-collection methods. TAG certification withheld if data-confidence thresholds are not met by Month 18 (2028-04-12); design freeze deferred and Steering Committee triggered for gate decision (delay or accept risk).

### 5. Indigenous Consent and Benefit-Sharing Tracking: Monitoring Beringia Indigenous Council Formation, Consent Agreements and Work-Window Compliance
**Monitoring Tools/Platforms:**

  - Beringia Indigenous Council Membership and Governance Document
  - Signed Consent Agreements with each Indigenous community (8-12 agreements)
  - Community Benefit Fund Allocation and Expenditure Tracker
  - Baseline Studies Co-Authoring Progress Log (marine mammals, subsistence harvesting, traditional knowledge)
  - Indigenous Workforce and Local-Hire Tracking Sheet (target: 20-30%)
  - Marine-Mammal Monitoring and Subsistence-Impact Incident Log

**Frequency:** Weekly tracking of Indigenous-engagement milestones during Months 0-12 (2026-10-12 to 2027-10-12) consent-agreement negotiation. Monthly Beringia Indigenous Council meetings and status updates (Months 6-12 = 2027-04-12 to 2027-10-12 and beyond). Quarterly Indigenous-stakeholder compliance reviews (Months 12, 24, 36 = 2027-10-12, 2028-10-12, 2029-10-12 onwards). Real-time monitoring of work-window compliance and subsistence impacts during construction (Months 30-180 = 2029-04-12 to 2041-10-12).

**Responsible Role:** Indigenous Stakeholder and Compliance Council (chaired by neutral Indigenous mediator) and Indigenous Engagement Specialist (Operations Council supporting role)

**Adaptation Process:** Consent-agreement negotiation tracked against Month 12 (2027-10-12) gate deadline. If any community withholds consent by Month 12 (2027-10-12), Indigenous Council escalates alignment or work-window dispute to Steering Committee for negotiation or design alternative (e.g., shift alignment to reduce impact, modify seasonal work windows). Benefit-Fund allocations reviewed quarterly with Indigenous Council co-governance; if fund balance or spending trajectory deviates from agreed annual allocation, corrective disbursements or schedule adjustments are made. Baseline studies co-authored with Indigenous researchers; publication and data-sharing disputes resolved through Community Advisory process. During construction, Indigenous-led marine-mammal monitoring triggers real-time work stoppages if protected species enter shutdown zones; stop-work incidents logged and subsistence-impact assessments conducted within 1 week. Unresolved Indigenous disputes or consent withdrawals >6 weeks trigger escalation to Steering Committee and potential design or permitting reconsideration.

**Adaptation Trigger:** Beringia Indigenous Council not formed by Month 6 (2027-04-12) escalates to Steering Committee for engagement intensification. Consent agreements not signed by >1 community by Month 12 (2027-10-12) triggers gate-readiness downgrade and potential Gate 2 deferral. Baseline studies delayed >2 months behind schedule activates accelerated co-authoring or alternative data sources. Benefit-Fund annual disbursement >USD 2 million behind schedule escalates to Finance Manager for corrective payment. Indigenous-led stop-work incidents unresolved >1 week trigger escalation to joint Operations Council and Beringia Council emergency meeting. Consent withdrawal or alignment dispute by any Indigenous community escalates to Steering Committee for government-level diplomatic resolution within 2 weeks.

### 6. Environmental Permitting and Marine-Mammal Protection Monitoring: Tracking Permit Milestones, Baseline Survey Progress and Compliance with Seasonal Work-Window Restrictions
**Monitoring Tools/Platforms:**

  - NEPA/EIA Permit Submission and Approval Timeline Tracker
  - Marine-Mammal Baseline Survey Progress Log (co-authored with Indigenous researchers)
  - Seasonal Work-Window Approval Calendar (with marine-mammal exclusion zones and acoustic shutdown triggers)
  - Real-Time Acoustic Monitoring Dashboard (passive listening stations, automated species detection)
  - Subsistence-Impact Assessment Reports (quarterly, co-authored with Indigenous monitors)
  - Stop-Work Incident Log (species sightings, acoustic measurements, closure triggers activated)

**Frequency:** Continuous environmental baseline surveys (Months 0-12 = 2026-10-12 to 2027-10-12). Monthly permit-approval status reviews (Months 0-18 = 2026-10-12 to 2028-04-12). Real-time acoustic monitoring and species-detection alerts during construction (Months 30-180 = 2029-04-12 to 2041-10-12). Quarterly subsistence-impact assessments (Months 12, 24, 36 onwards = 2027-10-12 onwards).

**Responsible Role:** Environmental and Permitting Lead (Operations Council) and Marine-Mammal Monitoring Coordinator (Indigenous co-leads)

**Adaptation Process:** Baseline surveys progress tracked against completion targets (marine-mammal surveys, fisheries assessments, water-quality baselines by Month 12 = 2027-10-12). If survey data arrival is delayed, preliminary permitting proceeds on interim data (framework permits at Months 6-9 = 2027-04-12 to 2027-07-12) with condition to update permits based on final surveys. Permit applications submitted at scheduled gates (framework Months 6-9 = 2027-04-12 to 2027-07-12, detailed marine Months 12-18 = 2027-10-12 to 2028-04-12) with regulator feedback incorporated iteratively. Seasonal work-window approvals updated annually based on latest migration and spawning data; acoustic-monitoring results trigger real-time work adjustments (if bowhead whales detected, impact piling halts automatically per pre-agreed threshold). Stop-work incidents and acoustic exceedances logged daily; monthly incident summaries trigger protocol review if patterns emerge (e.g., repeated species presence in previously excluded zones, indicating changed migration). Subsistence-impact reports compiled quarterly; significant impacts (harvest decline >10%, access restriction) trigger mitigation-program expansion (alternative harvesting areas, compensation).

**Adaptation Trigger:** Baseline survey >2 months behind schedule at Month 9 (2027-07-12) escalates to Environmental Lead for accelerated data collection. Permit application milestones missed (framework permits not submitted by Month 9 = 2027-07-12, detailed permits not submitted by Month 18 = 2028-04-12) triggers regulator engagement for expedited review or alternative permitting pathway. Regulator stop-work order (unscheduled closure due to unanticipated impact) lasts >3 days, requiring incident investigation and work-procedure modification within 1 week. Acoustic exceedances or species sightings in shutdown zones trigger immediate work cessation and 24-hour investigation. Subsistence-impact assessment showing harvest decline >10% or access restriction affecting >1 community escalates to Indigenous Council and Steering Committee for mitigation-program adjustment (cost and schedule implications).

### 7. Sanctions Licensing and Export-Control Compliance Monitoring: Tracking OFAC Approval, Pre-Approved Supplier List and Procurement Authorization Against Regulatory Milestones
**Monitoring Tools/Platforms:**

  - OFAC and Export-Control Licensing Pathway Document (updated monthly)
  - Pre-Approved Supplier and Contractor List (updated quarterly, with sanctions vetting status)
  - Procurement Authorization Checklist (each item requires compliance officer sign-off before order)
  - Export-Control Counsel Legal Opinion File (on specific transactions, if needed)
  - Sanctions Compliance Monitoring Dashboard (financing entities, equipment suppliers, key personnel)

**Frequency:** Monthly OFAC and export-control compliance status reviews (Months 0-24 = 2026-10-12 to 2028-10-12, then quarterly). Real-time procurement-authorization tracking: each order >USD 1 million requires Compliance Officer sign-off against pre-approved supplier list before purchase order release. Quarterly compliance audits of active contracts and vendor payments (Months 12-180 = 2027-10-12 to 2041-10-12). Emergency escalation within 24 hours if new sanctions are imposed on project-related entity or country.

**Responsible Role:** Compliance Officer (Risk Committee) and Risk and Insurance Committee Chair

**Adaptation Process:** OFAC and export-control guidance sought by Month 3 (2027-01-12); written licensing pathway and pre-approved supplier list obtained by Month 6 (2027-04-12). Pre-approved supplier list maintained and updated quarterly as new vendors are proposed or regulatory restrictions change. Each procurement action checked against current list; if supplier is not pre-approved, Compliance Officer either: (1) adds vendor to approved list if sanctions/export-control vetting clears, or (2) sources from alternative approved supplier without project delay. Financing entities (lenders, equity investors) continuously monitored for sanctions exposure; if sanctions-affected lender faces restrictions, Finance Manager identifies alternative lender within 2-week window. Personnel movement (binational team members crossing border) requires visa and work-permit authorization pre-cleared with project Compliance Officer; delays trigger escalation to Steering Committee for diplomatic intervention or remote-work arrangements.

**Adaptation Trigger:** OFAC guidance not received by Month 3 (2027-01-12) escalates to Project Sponsor for direct OFAC engagement. Pre-approved supplier list reduced by >20% due to new sanctions (e.g., supplier's parent company sanctioned) triggers emergency Compliance Officer alert and Finance/Logistics managers identify and onboard alternative suppliers within 2 weeks. Export-control license request rejected or delayed >6 weeks escalates to Steering Committee for policy decision (substitute supplier, design change, or funding/timeline impact). New sanctions imposed on any project financing entity, key contractor, or critical supplier triggers emergency Risk Committee meeting within 24 hours; if impact is existential (financing lender becomes unavailable, critical supplier blacklisted), escalate to Steering Committee and diplomatic channels for exemption request or project restructuring. Personnel visa/work-permit authorization delayed >2 weeks triggers escalation to Project Sponsor for diplomatic resolution or remote-work protocol activation.

# Governance Extra

## Governance Validation Checks

1. Completeness: All six core governance components are generated (audit/E&C framework, internal bodies, implementation plan, decision-escalation matrix, monitoring/progress framework, and risk register). No critical component is missing. The five internal governance bodies (Steering Committee, Operations Council, Technical Advisory Group, Indigenous Stakeholder Council, Risk/Compliance Committee) are specified with charters, membership, decision authorities and meeting cadences. Implementation plan covers 22 sequential steps from Month 0 (2026-10-12) through Month 24 (2028-10-12) (financial close), with step-by-step responsible parties, deliverables and dependencies.
2. Internal Consistency: Governance bodies align with decision gates (Months 6, 12, 18, 24 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12) and gates feed into consistent escalation criteria across all committees. The Steering Committee chair and neutral arbiter roles are consistently defined; decision thresholds (cost >5%, DSCR <1.3x, OFAC delay >3 months) appear in Risk Committee and financial-monitoring protocols and cascade correctly to appropriate escalation level. Indigenous Stakeholder Council's >75% consensus threshold for work-window approval is integrated into Environmental permitting milestones. The staged gating (paid pause and exit provisions) is explicitly linked to gate-readiness criteria in the implementation plan. No contradictions detected between bodies' scopes or between stages.
3. Critical Gap 1—Commercial and Financial Underwriting Lacks Verification: The debt-sizing model assumes USD 8.9 billion/yr conservative-case revenue from an 85 km crossing with no documented traffic forecast, tariff study, or comparable precedent. At an illustrative USD 100/tonne tariff, this requires about 89 million tonnes/yr; Bering Strait current traffic is negligible. Take-or-pay pre-sales (30–50% of revenue, proposed) target USD 2.7–4.5 billion/yr but no letters of intent from freight forwarders, energy companies or carriers are mentioned. Lenders typically require a traffic study and contracted revenue before heads of terms. Gap: Finance Manager is tasked with 'independent traffic study' in the governance implementation (step for Months 3–4 = 2027-01-12 to 2027-02-12), but no timeline for completion or lender sign-off appears before Gate 1 (Month 6 = 2027-04-12). If traffic study is not complete and contracted capacity not pre-sold by Month 6 (2027-04-12), Gate 1 pass is at risk; remedy is not specified.
4. Critical Gap 2—Cost Estimate Build-Up and Contractor Risk Pricing Not Finalized: Phase 1 CAPEX baseline is USD 100 billion (midpoint of USD 80–120 billion range, estimate). However, detailed parametric cost model from Arctic specialists is tasked to Commission by Month 3 (2027-01-12) but not due until Month 6 (2027-04-12) (Gate 1). Cost Task Force validation occurs Months 3–6 (2027-01-12 to 2027-04-12), refining Cost Basis Document by Month 6 (2027-04-12). Arctic labor premiums (30–50%), marine logistics (50–100%) and contractor risk premiums (15–25%) are stated as proposed/estimated but contractor bids are not mentioned until they are compared to parametric baseline at Gate 2 (Month 12 = 2027-10-12). Gap: between Gate 1 and Gate 2, there is no intermediate check that parametric cost remains realistic or that early bids are in line with plan. If Arctic-specialist cost model at Month 6 (2027-04-12) shows baseline should be USD 120 billion (not USD 100 billion), there is no documented protocol for Steering Committee repricing decision. Cost variance re-forecasting is assigned to Cost Engineer every month, but escalation of major baseline shifts (>10%) is not explicit between gates.
5. Critical Gap 3—Sanctions Licensing and Financing Entity Sanctions Vetting Not Sequenced with Financial Close: OFAC preliminary guidance is due Month 3 (2027-01-12), final licensing pathway and pre-approved supplier list Month 6 (2027-04-12) (proposed). However, financing roadmap (heads of terms negotiation) also occurs Months 6–9 (2027-04-12 to 2027-07-12), with financial close targeted Month 24 (2028-10-12). If OFAC guidance at Month 6 (2027-04-12) reveals that a critical supplier or a key lender's parent company is sanctioned, requiring substitute sourcing (5–10% cost premium, estimate) or alternative lender (100–200 bps higher cost, estimate), there is no scheduled Steering Committee repricing gate between Month 6 (2027-04-12) (Gate 1) and Gate 2 (Month 12 = 2027-10-12) to address financing-cost or supply-chain-cost escalation. Compliance Officer is tasked with maintaining OFAC monitoring, but the scenario where OFAC-driven cost impacts trigger contingency draws is not explicitly escalated to Risk Committee until monthly risk monitoring (no gate-aligned trigger). Gap: if Phase 1 CAPEX is USD 100 billion and sanctions sourcing premium is 5–10%, baseline increases by USD 5–10 billion; lender repricing of 100–200 bps (0.5–1% of USD 69 billion debt) adds USD 350–700 million annual cost. These are material; escalation criteria and gate-deferral implications are not documented.
6. Critical Gap 4—Operations Council Change-Control Threshold (USD 10 Million) Is Misaligned with Steering Committee Visibility: Operations Council approves cost changes ≤USD 10 million; escalates >USD 10 million to Steering Committee. However, Steering Committee cost-escalation threshold is >5% variance (USD 5 billion target overrun). This creates a zone (USD 10 million to USD 5 billion) where individual changes fall below both thresholds yet cumulatively could trigger variance. Gap: No protocol for Operations Council to flag cumulative change-order trend to Steering Committee before variance reaches 5%. Risk Committee monitors variance monthly and escalates >5%, but monthly reporting lags real-time accumulation. Recommendation: add a secondary escalation criteria such as 'cumulative monthly change orders exceeding USD 100 million' or 'three consecutive months with changes >USD 5 million each' to trigger Steering Committee proactive repricing review between scheduled gates.
7. Critical Gap 5—Indigenous Consent Authority Boundary Over Alignment vs. Operations Is Ambiguous: Beringia Indigenous Council holds 'binding advisory authority' over alignment, seasonal work windows and mitigation. However, 'binding' is not defined: does it mean full veto power (Council can block alignment, permitting stalls indefinitely), or does it mean Steering Committee must negotiate redesign and Council rejection triggers diplomatic escalation only? If Council withholds consent on alignment grounds, the Implementation Plan states 'Steering Committee must negotiate alternative or escalate to diplomatic resolution,' implying veto is not absolute but negotiable. Gap: this creates interpretive risk—Communities and/or regulators may believe Council has absolute veto, while Steering Committee assumes negotiability. If Council withholds consent late (Month 10–11 = 2027-08-12 to 2027-09-12, weeks before Month 12 = 2027-10-12 gate), negotiations cannot complete in time; gate is deferred. Recommendation: formalize 'binding advisory' as requiring >75% Council vote to trigger escalation, with explicit language that Steering Committee escalation to governments is the dispute-resolution mechanism (not indefinite stalling). Also clarify that 'alignment change' triggering consent is defined narrowly (route shift >1 km, seasonal window shift >2 weeks) to prevent frivolous re-negotiation.

## Tough Questions

1. What is the probability-weighted forecast for total Phase 1 CAPEX (baseline USD 100 billion + contingency USD 15 billion + Arctic-sourcing premium USD 5–10 billion + contractor risk premium USD 15–25 billion = USD 135–150 billion range estimate) and who bears cost overruns exceeding the USD 115 billion funding envelope—equity investors, debt holders, or the project (with payment deferrals)? How will this be disclosed to lenders before financial close?
2. Has an independent third-party traffic and demand study been commissioned yet, and will it be completed and lender-approved before Gate 1 (Month 6 = 2027-04-12)? What is the downside revenue scenario (e.g., recession, sanctions-driven trade collapse) and how does DSCR perform under that scenario? At what traffic volume does DSCR fall below 1.2x covenant breach threshold?
3. What is the current status of treaty or framework-agreement negotiations with US and Russian governments (as of project start, Month 0 = 2026-10-12)? Is a neutral third-country legal framework and SPV charter achievable by Month 3 (2027-01-12), or is this a 12+ month negotiation that puts Gate 1 (Month 6 = 2027-04-12) at risk?
4. Show documented evidence (letters of intent, term sheets, or signed capacity agreements) that 30–50% of Phase 1 revenue will be pre-sold via take-or-pay contracts (fiber, power, rail freight) before financial close (Month 24 = 2028-10-12). If this pre-sales target is not on track, what is the fallback financing structure and debt-sizing adjustment?
5. What specific contingency protocols exist if a design-freeze gate (Month 18 = 2028-04-12) is missed due to inconclusive ice-load or permafrost-thaw monitoring data, or if Technical Advisory Group withholds certification due to data-confidence gaps? Is a 3–6 month paid pause automatic, or does Steering Committee have discretion to force design freeze on uncertain data to meet schedule? If forced, who bears the post-construction repair risk (estimated USD 50–200 million per incident)?
6. If sanctions on Russia escalate between Gate 1 (Month 6 = 2027-04-12) and financial close (Month 24 = 2028-10-12) and OFAC revokes or tightens export licenses, requiring 5–10% sourcing-cost premiums or substitution of lenders, who approves the cost increase—Steering Committee unilaterally, or does the project require renegotiation with equity and debt holders? Is there a financing-repricing gate between Month 6 (2027-04-12) and Month 24 (2028-10-12), or does the project absorb sanctions-driven cost escalation as a risk?

## Summary

The Bering Strait Phase 1 project implements a multi-layered binational governance structure designed to manage extreme technical uncertainty, geopolitical risk and financial exposure across a 180-month (2026–2041) program. Five internal governance bodies (Steering Committee, Operations Council, Technical Advisory Group, Indigenous Stakeholder Council, Risk/Compliance Committee) operate through explicit decision gates (Months 6, 12, 18, 24 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12) with paid-pause and exit provisions to cap pre-construction sunk cost at USD 150 million. The framework prioritizes observational design (ice/seismic/permafrost monitoring through Month 18 = 2028-04-12), Indigenous consent authority, sanctions-compatible third-country financing, and staged capital deployment. Phase 1 targets 20–36 km of rail-and-utility tunnel on oversized island foundations; Phase 2 (suspension spans and road) defers beyond Month 180 (2041-10-12). Viability depends on resolution of three existential risks before financial close: treaty ratification, OFAC/export-control licensing clarity, and design-freeze data adequacy. Escalation pathways and neutral arbiters address binational governance seams. The framework is logically coherent but several operational and commercial assumptions lack external verification, creating latent risk in financing and schedule forecasts.