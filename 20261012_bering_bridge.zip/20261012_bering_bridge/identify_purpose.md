**Purpose:** business

**Purpose Detailed:** Strategic plan to design, finance, build and operate a binational mega-infrastructure link across the Bering Strait. It covers technical concept, feasibility, cost and funding (PPP, sovereign funds, multilateral banks), phased timeline, risk register, governance, environmental and social impact, stakeholder engagement, and the economic and strategic benefits (trade corridor, energy transport, telecom fiber, Arctic research, national security). It is a large-scale infrastructure and geopolitical project run under a binational public-private structure.

**Topic:** Permanent Alaska-Russia Bering Strait crossing: an 85 km hybrid suspension-bridge and immersed-tube tunnel link