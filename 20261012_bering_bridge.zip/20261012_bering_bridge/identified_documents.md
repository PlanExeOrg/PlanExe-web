
## Documents to Create

### 1. Project Charter and Gating Framework

**ID:** 7a20a0a0-eb3f-432f-a813-7e13f7925eda

**Description:** Foundational governance document establishing the Phase 1 gated program structure (Gates 1–4 at Months 6, 12, 18, 24 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12), paid-pause and exit provisions, decision authorities, steering-committee composition, and sponsor sign-off on the USD 150 million pre-gate spend cap. Defines Phase 1 scope (rail-and-utility immersed tunnel on island foundations), end-state vision (85 km hybrid crossing), and milestones tied to treaty ratification, sanctions licensing, Indigenous consent and financial close. Intended audience: sponsors, lenders, steering committee, regulators.

**Responsible Role Type:** Project Director / Executive Sponsor Lead

**Primary Template:** PMI Project Charter Template

**Secondary Template:** Megaproject Gating Framework (binational infrastructure precedent: Fehmarnbelt, Öresund)

**Steps:**

- Convene steering committee (US and Russian government representatives, lead sponsors, lenders, Indigenous Council leadership) by Month 0 (2026-10-12).
- Define Gate 1–4 criteria and decision milestones explicitly (financing roadmap, cost validation, design freeze, financial close).
- Establish paid-pause and exit protocols: if a gate is unmet by its date, enter 3–6 month paid pause; if still unmet, parties may exit with no further obligation.
- Lock the USD 150 million pre-gate cumulative spend cap and identify the budget cap-bearer (estimated sponsor or lender requirement).
- Document approval thresholds (e.g., steering-committee unanimous or majority) and escalation paths for unresolved conflicts.
- Distribute draft charter for sponsor and lender review by Month 1 (2026-11-12); finalize by Month 3 (2027-01-12).

**Approval Authorities:** US Secretary of Transportation (or equivalent cabinet-level authority), Russian Ministry of Transport, lead sponsors, lead arrangers

### 2. Parametric Cost Estimate and Cost Basis Document

**ID:** 09827955-adc9-4daa-a5e7-eba4e5324ff6

**Description:** Detailed build-up of the USD 100 billion Phase 1 baseline disaggregated by labor (skilled trades, engineers, support staff at +30–50% Arctic premium, estimate), materials (steel $/tonne, concrete $/m³, Arctic-specialized components), marine logistics (ice-class vessel charter USD 500k–1.5M/day, estimate), and regional indices (Alaska, Chukotka). Establishes unit rates, productivity assumptions (propose 60–70% of temperate baseline for Arctic piling, estimate), contingency allocation (12–15% outside baseline), and cost-variance gates (reforecast if bids exceed baseline by >5% at Month 12 = 2027-10-12, estimate). Intended audience: lenders, contractors, sponsors, Cost Task Force.

**Responsible Role Type:** Cost Estimating & Financial Controls Engineer

**Primary Template:** Parametric Cost Estimate (Arctic megaproject precedent: Fehmarnbelt)

**Secondary Template:** Contractor Cost-Tracking and Earned-Value Management System (EVMS)

**Steps:**

- Engage Arctic construction specialists (HDR, Jacobs, Golder, Hatch) by Month 0 (2026-10-12); commission parametric model by Month 3 (2027-01-12).
- Build unit-cost tables for labor (day-rates by trade, location, crew size), materials (market indices + Arctic freight adders), and logistics (vessel availability, tow seasons, fuel).
- Validate assumptions with regional labor surveys (Alaska Department of Labor, Russian statistics) and Arctic project benchmarks (Fehmarnbelt, Hong Kong–Zhuhai–Macau Bridge, North Slope oil field).
- Establish a Cost Task Force (Months 3–6 = 2027-01-12 to 2027-04-12) with 2–3 candidate lead contractors and suppliers; review unit rates and resolve outliers.
- Publish the Cost Basis Document by Month 6 (2027-04-12) with line-item build-up, assumptions, escalation indices and sensitivity analysis (downside: labor +40%, material +8%; upside: labor +50%, material +12%, estimate).
- Assign an Owner's Cost Engineer (Month 6 = 2027-04-12 onward) to track bids monthly; implement formal change-control gate at 5% variance (reforecast and repricing if bids exceed baseline by >5% at Month 12 = 2027-10-12).

**Approval Authorities:** Cost Engineer, Project Director, Lead Lender Financial Officer

### 3. Financing Roadmap and Lender Engagement Plan

**ID:** da20904d-296e-49a4-a53e-b2efae93dbd6

**Description:** Strategy document identifying 5–10 target development banks, export-credit agencies, and infrastructure funds; outlines engagement sequence (one-on-one meetings Months 1–3 = 2026-11-12 to 2027-01-12, preliminary information memorandum Months 3–4 = 2027-01-12 to 2027-02-12, investor roundtable Months 4–5 = 2027-02-12 to 2027-03-12, heads-of-terms signature by Month 9 = 2027-07-12, financial close by Month 24 = 2028-10-12). Specifies debt amount (USD 69 billion, estimate), tenor (30 years, estimate), interest-rate and DSCR assumptions (5.5% placeholder, DSCR ≥1.5x sizing / <1.2x covenant breach, proposed thresholds), and conditions precedent (OFAC licensing, treaty ratification, environmental permits). Intended audience: sponsors, finance committee, identified lenders.

**Responsible Role Type:** Arctic Megaproject Financing Strategist / Finance Lead

**Primary Template:** Infrastructure Financing Roadmap (World Bank, IFC precedent)

**Secondary Template:** Term-Sheet Framework (standard debt syndication template)

**Steps:**

- Identify Finance Lead and mandated arranger by Month 0 (2026-10-12); jointly develop target-lender list (5–10) by Month 1 (2026-11-12).
- Schedule one-on-one meetings with each lender (Months 1–3 = 2026-11-12 to 2027-01-12) to gauge appetite and outline deal structure.
- Prepare preliminary Information Memorandum (Months 3–4 = 2027-01-12 to 2027-02-12) with project description, Phase 1 scope, timeline, governance (neutral SPV), financing structure (third-country consortium), risk summary and preliminary financial model.
- Host investor roundtable (Months 4–5 = 2027-02-12 to 2027-03-12) to present the deal and gather feedback; adjust structure based on lender feedback.
- Negotiate non-binding letters of interest (LOI) from 4–6 lenders by Month 6 (2027-04-12) confirming appetite and outlining term-sheet expectations.
- Prepare draft heads-of-terms (Months 6–9 = 2027-04-12 to 2027-07-12) specifying debt amount, tenor, interest rate, covenants (DSCR, mandatory prepayment triggers), conditions precedent and syndication timeline; target signature from 2–3 lead arrangers by Month 9 (2027-07-12).

**Approval Authorities:** Finance Lead, Project Director, Sponsor Board, Lead Arranger(s)

### 4. Sanctions and Export-Control Compliance Memorandum and Pre-Approved Supplier List

**ID:** 47645207-221f-47cd-a380-5d107e35fc83

**Description:** Legal analysis of OFAC, US export-control (EAR/ITAR) and Russian sanctions/export-control regimes as applied to the neutral SPV structure, third-country financing consortium, equipment procurement, and personnel movement. Includes written preliminary OFAC guidance (target Month 3 = 2027-01-12) and definitive licensing pathway (target Month 6 = 2027-04-12) covering (a) approved financing-vehicle jurisdictions and lender nationalities, (b) approved supplier countries for all long-lead items (cable, steel, tunnel elements, electrical systems), (c) equipment classifications and licenses required per draw, (d) work-visa and personnel-movement protocols. Includes pre-approved supplier list with primary, secondary and tertiary sources for every critical item to preserve substitution flexibility. Intended audience: sponsors, lenders, Finance Lead, procurement team.

**Responsible Role Type:** Sanctions & Export-Control Counsel / Financing Lawyer

**Primary Template:** Export-Control Risk Assessment and Licensing Guidance (US State Department, Commerce Department precedent)

**Secondary Template:** Sanctions-Compliant Supplier Pre-Qualification Matrix

**Steps:**

- Retain export-control counsel (Miller & Chevalier, Akin Gump equivalent) by Month 0 (2026-10-12).
- Conduct preliminary OFAC, BIS and Russian export-control assessment (Months 0–2 = 2026-10-12 to 2026-12-12) covering neutral-entity jurisdictional options, lender-eligibility criteria and equipment classifications.
- Submit detailed licensing request to OFAC and BIS by Month 2 (2026-12-12) describing (a) SPV charter and ownership structure (actual jurisdiction), (b) financing-consortium lender nationalities and US nexus (if any), (c) equipment supply-chain countries of origin, (d) personnel movement (visa categories, work permits). Request written guidance on approved scenarios.
- Obtain preliminary OFAC guidance letter (Months 2–3 = 2026-12-12 to 2027-01-12); finalize written licensing pathway and pre-approved supplier list by Month 6 (2027-04-12).
- Establish a 'Sanctions Compliance Tracker' documenting licensing status for every major financing draw, equipment order and personnel deployment; update quarterly and flag any changes to OFAC or BIS guidance.
- Include sanctions-compliance conditions in all financing term sheets (Month 9 = 2027-07-12 heads of terms) and procurement contracts, specifying that licenses must be obtained before drawdown and that cost of delays or denials is shared per defined formula.

**Approval Authorities:** Export-Control Counsel, Finance Lead, Project Director, OFAC (US Treasury), Russian Ministry of Trade and Industry

### 5. Independent Traffic Forecast and Revenue Underwriting Study

**ID:** e18b42b8-b505-4c0c-b36a-9f9044ab0cc8

**Description:** Third-party demand analysis by recognized Arctic/maritime transport economist (Delft Hydraulics, Ocean Wise, Arctic Council observer) modeling freight volumes (containerized, break-bulk, project cargo, LNG) by competing routes (Bering Strait crossing, northern sea route, Suez, air freight); passenger and rail demand; fiber-bandwidth and power-interconnection lease rates; downside, base and upside scenarios over 30 years with sensitivity to tariff (USD 50–125 per tonne, all-in), geopolitical risk and alternative routes. Specifies conservative-case revenue (proposed: 70% of baseline forecast), lender DSCR implications (DSCR vs. traffic/tariff sensitivity), and shipper and tenant pre-sales requirements (target 30–50% of expected revenue, estimated USD 2.7–4.5 billion/yr by Month 12 = 2027-10-12). Intended audience: lenders, sponsors, finance committee, shipper/tenant prospects.

**Responsible Role Type:** Traffic Demand and Revenue Underwriting Analyst

**Primary Template:** Transport Demand Forecasting Study (IBI Group, AECOM, Steer precedent)

**Secondary Template:** Infrastructure Revenue Modeling (toll, lease, take-or-pay contract precedents)

**Steps:**

- Commission study by Month 0 (2026-10-12) from Arctic shipping/logistics specialist; issue RFP and select consultant by Month 1 (2026-11-12).
- Conduct shipper and operator interviews (Months 1–3 = 2026-11-12 to 2027-01-12) with 10–15 freight forwarders, energy majors, telecom carriers and utilities to gauge demand and willingness-to-pay.
- Model freight-route economics: Asia–Europe via Bering Strait vs. northern sea route vs. Suez (time, fuel, insurance, passage fees); quantify cost savings at various tariff levels.
- Model rail demand from Russian Arctic ports to North American markets; estimate volumes and revenue sensitivity.
- Model telecom-fiber and power-interconnection lease rates based on regional and global benchmarks.
- Develop downside (30% below base), base and upside (20% above base) traffic scenarios with 30-year projection; identify demand-ramp assumptions (e.g., years to reach full capacity).
- Conduct sensitivity analysis on tariff (±25%), geopolitical risk (sanctions tightening, trade restriction), alternative-route competitiveness.
- Publish preliminary findings by Month 6 (2027-04-12); finalize report with lender and shipper feedback by Month 12 (2027-10-12).

**Approval Authorities:** Project Director, Finance Lead, Lender Traffic-Risk Officer

### 6. Beringia Indigenous Council Charter and Free, Prior and Informed Consent (FPIC) Framework

**ID:** 5b2aaeb5-2e60-4b6d-ba43-4047aa9aea5d

**Description:** Binational governance instrument establishing the Beringia Indigenous Council (members from all mapped communities: estimated 8–12 across Alaska and Russia) with explicit Free, Prior and Informed Consent (FPIC) authority over alignment options, seasonal work windows, marine-mammal mitigation measures and emergency response. Reconciles US trust-responsibility doctrine and Russian Indigenous-rights law into a single cross-border legal standing. Specifies Council decision authority (unanimous, supermajority or rotating veto by topic), dispute-resolution mechanism (neutral arbitration), and annual governance review. Outlines benefit-sharing structure (1–2% of annual operating revenue or fixed USD 10–30 million/yr, proposed threshold), Indigenous workforce targets (20–30%, proposed threshold), and observer participation on all marine works and monitoring programs. Accompanied by separate FPIC agreements with each participating community documenting informed consent for alignment, seasonal work and benefit-sharing terms. Intended audience: Indigenous communities, government agencies, project team, lenders, regulators.

**Responsible Role Type:** Indigenous Engagement & Community Relations Director

**Primary Template:** Binational Indigenous Governance Charter (Porcupine Caribou Herd management committee, Inuit Tapiriit Kanatami precedent)

**Secondary Template:** Free, Prior and Informed Consent (FPIC) Framework (UNDRIP, ILO Convention 169 guidance)

**Steps:**

- Commission Binational Indigenous Consultation Legal Framework memorandum by Month 0 (2026-10-12) specifying how US and Russian Indigenous-rights doctrines are reconciled; deliver by Month 3 (2027-01-12).
- Conduct community stakeholder mapping by Month 1 (2026-11-12); identify all communities with subsistence-harvesting, traditional-use or regulatory authority over alignment (estimated 8–12 primary communities).
- Draft Beringia Indigenous Council Charter (Months 1–3 = 2026-11-12 to 2027-01-12) with governance structure, decision authority, meeting protocols, independent secretariat role and funding commitment.
- Circulate charter for comment to all mapped communities (Months 2–3 = 2026-12-12 to 2027-01-12); negotiate revisions based on feedback.
- Execute signed Memorandum of Understanding (MOU) establishing the Council with legal standing in both US and Russian jurisdictions (Months 3–6 = 2027-01-12 to 2027-04-12); seek government (US State Department, Russian Ministry of Foreign Affairs) recognition if required by law.
- Develop template FPIC agreements specifying: (a) decisions requiring full consent versus advisory input, (b) informed-consent definition (baseline studies, independent legal review, impact disclosure), (c) benefit-sharing amount and allocation, (d) local-hiring targets and Indigenous-observer roles, (e) dispute-resolution (escalation to neutral mediator, binding arbitration if necessary).
- Negotiate and execute FPIC agreements with each participating community (Months 6–12 = 2027-04-12 to 2027-10-12); obtain signatures by Month 12 (2027-10-12) as Gate 2 deliverable.
- Fund the Council secretariat with USD 2–5 million (not USD 2–5 million previously proposed; increase to USD 3–5 million per expert feedback) for independent legal counsel, technical advisors and annual operations (Months 6–180 = 2027-04-12 to 2041-10-12).

**Approval Authorities:** Beringia Indigenous Council (supermajority or consensus, as defined in MOU), US Secretary of Interior (if NAGPRA-level authority required), Russian Federation regional authorities (Sakha Republic, Chukotka Autonomous Okrug)

### 7. Ice-Load and Seismic Design Envelope with Observational Design Protocol

**ID:** 08c5646a-05e0-4fc0-a038-8a51a719495a

**Description:** Technical specification defining design load cases and return periods (50/100/500-year proposed thresholds) for ice-floe impacts, ice ridging, seismic ground response and permafrost thaw over a 100-year design life. Based on 12–18 months of monitoring data (drifting buoys, shore-based radar, pilot instrumentation on prototype piers deployed Months 0–12 = 2026-10-12 to 2027-10-12). Establishes observational design approach with confidence thresholds (propose ±15% estimated) and adaptive-management triggers: if data quality is inadequate at Month 18 (2028-04-12), extend observational period by 3–6 months rather than proceeding with uncertain loads. Specifies design margins (10–20% foundation reserve, proposed threshold), sacrificial ice-deflection structures upstream of piers, and redundancy philosophy (e.g., cable-suspension bridges designed for partial cable failure). Includes climate-change impact modeling (2–4°C warming over design life, proposed threshold) and permafrost-thaw subsidence rates (0.05–0.2 m per decade, estimated for sensitive locations). Intended audience: Owner's Engineer, bridge and tunnel designers, independent design reviewer, lenders, regulators.

**Responsible Role Type:** Lead Structural Engineer (Bridge & Spans) / Immersed Tunnel Systems Engineer

**Primary Template:** Arctic Infrastructure Design Standard (API RP 2A, DNV-GL Arctic Certification Rules)

**Secondary Template:** Observational Design Protocol (Peck Method precedent)

**Steps:**

- Launch ice-monitoring campaign by Month 0 (2026-10-12): deploy 4–6 drifting buoys, establish shore-based radar stations at Wales and Uelen (Months 0–6 = 2026-10-12 to 2027-04-12), and install passive acoustic telemetry to track ice-floe velocity, thickness and frequency.
- Install pilot instrumentation (pressure plates, accelerometers) on prototype pier models deployed near Little Diomede (Months 6–12 = 2027-04-12 to 2027-10-12) to measure real-world ice-impact transients.
- Conduct seismic-hazard analysis using latest regional earthquake catalogs and ground-motion prediction models (Months 0–6 = 2026-10-12 to 2027-04-12); establish design-basis earthquake return periods and site-specific amplification factors.
- Commission geotechnical investigation (core drilling, laboratory testing for shear strength and permafrost characteristics) at proposed foundation locations (Months 0–6 = 2026-10-12 to 2027-04-12).
- Run coupled ice-mechanics and permafrost finite-element analyses iteratively as monitoring data arrive (Months 6–18 = 2027-04-12 to 2028-04-12).
- Establish a Data Adequacy Committee with independent ice-mechanics, seismic and permafrost experts; convene by Month 6 (2027-04-12) to review data quality and design confidence.
- Draft preliminary design and design envelope (Months 0–6 = 2026-10-12 to 2027-04-12); refine iteratively as monitoring data arrive (Months 6–18 = 2027-04-12 to 2028-04-12).
- Lock design-freeze gate at Month 18 (2028-04-12) contingent on written Data Adequacy Committee confirmation that ice-load and seismic-return-period loads are quantified within ±15% confidence (proposed threshold); if not, extend observational period by 3–6 months and reschedule design freeze to Month 24–30 (2028-10-12 to 2029-04-12) with corresponding paid pause.

**Approval Authorities:** Owner's Engineer, Independent Design Reviewer, Project Director, Lender Chief Technical Officer

### 8. Binational Legal Vehicle and Concession / Framework Agreement

**ID:** c2f0dfc7-aa4f-441d-b315-eed1eadbaf14

**Description:** Charter or bilateral instrument establishing the neutral third-country special-purpose entity (SPV) that holds ownership and operating rights to Phase 1 (and optionally Phase 2 and beyond). Defines SPV jurisdiction (Swiss, Canadian or international legal regime candidate), governance (board composition, shareholder rights), and relationship to both US and Russian governments (contractual rights holders: concession, rights-of-way, land contributions, guarantees; not equity shareholders). Specifies operational authority: toll-setting, traffic restrictions, closure authority (independent closure rights for each government in defined emergency scenarios; joint authority for routine operations), incident command and liability allocation at the maritime seam. Includes dispute-resolution mechanism (binding arbitration under UNCITRAL rules with neutral mediator for deadlocks). Executed as a bilateral framework agreement or paired concessions (one per jurisdiction) with a cross-border cooperation MOU. Intended audience: both governments, lead sponsors, lenders, neutral SPV board.

**Responsible Role Type:** Binational Treaty and Sovereign-Risk Counsel

**Primary Template:** Binational Infrastructure Treaty (Great Lakes Navigation Agreement, Seaway precedent)

**Secondary Template:** Public-Private Partnership Concession Agreement (World Bank PPI Database precedent)

**Steps:**

- Commission Binational Legal Framework analysis by Month 0 (2026-10-12) assessing neutral-entity jurisdictional options (Switzerland, Canada, international/supranational); deliver by Month 2 (2026-12-12).
- Charter the neutral SPV in selected jurisdiction by Month 3 (2027-01-12); confirm OFAC and export-control eligibility with written guidance by Month 6 (2027-04-12).
- Draft bilateral framework agreement or concession-pair template (Months 0–3 = 2026-10-12 to 2027-01-12); include operational-authority matrix, toll-setting rules, closure triggers and incident-command protocols.
- Circulate draft to US and Russian government negotiators; negotiate revisions (Months 3–9 = 2027-01-12 to 2027-07-12).
- Execute signed framework agreement with both governments (target Month 24 = 2028-10-12, Gate 4); treat as a condition of financial close.
- Include dispute-resolution and arbitration rules: propose UNCITRAL Arbitration Rules, neutral mediator selection (e.g., Swiss judge, international arbitrator), and 30-day decision timeline for operational disputes.

**Approval Authorities:** US Secretary of State, Russian Ministry of Foreign Affairs, Neutral SPV Board, Project Director

### 9. Marine Mammal and Fisheries Protection Operating Envelope and Monitoring Plan

**ID:** 1ef15c39-c08f-4d29-a048-5f6f45dd59a6

**Description:** Technical and regulatory document specifying acoustic thresholds, seasonal exclusion zones, foundation-method selection (vibratory/drilled piling preferred over impact piling, estimated cost delta USD 0.5–2 billion for Phase 1, estimate), and real-time observer-stop-work protocols to protect beluga, bowhead, gray whales, walrus, seals and fisheries during construction. Based on 12-month marine-mammal baseline survey (passive acoustic monitoring, photo-ID, haul-out surveys) conducted Months 0–12 (2026-10-12 to 2027-10-12). Specifies seasonal closures (proposed: no impact piling May 20–June 15 bowhead migration, no dredging May–July fish spawning, estimate). Establishes Marine Mammal Monitoring and Adaptive Management Committee with Indigenous observers, contractor representatives and regulators; meets monthly during construction. Proposes co-management of monitoring by Indigenous communities with independent funding (estimated USD 1–2 million/yr, estimate) and decision authority over seasonal work windows within pre-agreed thresholds. Intended audience: NOAA Fisheries, US Fish and Wildlife Service, Russian Federal Agency for Fisheries, Indigenous Council, contractors, regulators.

**Responsible Role Type:** Arctic Environmental Compliance and Marine Mammal Permitting Lead

**Primary Template:** Marine Mammal Protection Act (MMPA) Incidental Take Authorization (ITA) and Mitigation Plan

**Secondary Template:** Indigenous Co-Management Protocol (Arctic Council guidance)

**Steps:**

- Establish Marine Mammal Permitting Task Force by Month 1 (2026-11-12) with NOAA Fisheries, USFWS, Russian Federal Agency for Fisheries, Indigenous observers.
- Commission acoustic-impact modeling study (Months 0–6 = 2026-10-12 to 2027-04-12) quantifying Phase 1 construction noise (immersed-tube jacking, dredging, element placement) and species-specific shutdown thresholds.
- Launch 12-month baseline marine-mammal survey (Months 0–12 = 2026-10-12 to 2027-10-12): passive acoustic monitoring at 5–8 buoy stations, shore-based photo-identification, walrus haul-out surveys.
- Finalize foundation method (impact piling vs. vibratory vs. drilled) by Month 15 (2028-01-12) after pilot testing; confirm cost delta and incorporate into design freeze and financing baseline.
- Draft Construction Acoustic Mitigation Plan (Months 3–6 = 2027-01-12 to 2027-04-12) with fixed seasonal exclusions and observer-triggered stop-work authority limited to pre-specified conditions; finalize by Month 12 (2027-10-12).
- File preliminary MMPA Incidental Take Authorization application (US) and Russian aquatic-mammal-impact assessment (Months 9–12 = 2027-07-12 to 2027-10-12).
- Obtain final ITA issuance before design freeze (Month 18 = 2028-04-12); incorporate acoustic thresholds, seasonal exclusions and observer-authority protocols into construction contracts.
- Establish Joint Monitoring and Adaptive Management Committee with Indigenous observers, contractors and regulators; meet monthly during construction (Months 30–180 = 2029-04-12 to 2041-10-12).

**Approval Authorities:** NOAA Fisheries (MMPA authority), US Fish and Wildlife Service, Russian Federal Agency for Fisheries, Beringia Indigenous Council

### 10. Immersed-Tube Tunnel Fabrication and Installation Schedule

**ID:** c2e2616d-1b85-4a25-941c-1881a12c8f54

**Description:** Detailed Gantt-based schedule modeling tunnel-element fabrication (80–120 elements × 250–300 m, estimated 100 @ 275 m = 27.5 km, estimate), yard ramp-up, tow-window constraints (June–September open-water season, estimated 4-month window), and installation rates (baseline 3–4 elements per season from risk register; planned 6–8 per season; target 9 per season needed to meet Month 180 = 2041-10-12, estimate). Specifies two fabrication yards with staggered production to saturate tow window. Models pilot-element trial (Months 9–12 = 2027-07-12 to 2027-10-12) as a decision gate: if successful, proceeds to full-scale production; if failure, triggers 12-month redesign and recovery. Includes second-spread contingency (dual tow-vessel fleets, estimated cost USD 5–10 billion) as an option if baseline productivity <7 elements/season. Identifies schedule float (6–12 months proposed threshold) and lost-season risk (one lost open-water season = 12 months delay, estimate). Intended audience: Arctic logistics director, contractors, fabrication yards, lenders, Project Director.

**Responsible Role Type:** Arctic Construction Logistics & Supply-Chain Director

**Primary Template:** Critical-Path Method (CPM) Schedule (Primavera P6, MS Project)

**Secondary Template:** Marine-Works Logistics Plan (Arctic vessel scheduling, tow-route planning)

**Steps:**

- Commission detailed logic-based schedule from marine-works specialist (Horizon Offshore, Crowley, Jan De Nul) by Month 0 (2026-10-12); deliver by Month 6 (2027-04-12).
- Model fabrication-yard ramp-up (8–12 months to full production, estimate), element design freeze, pre-fabrication lead times (24–36 months, estimate) and production rates (3–4 per yard per year, baseline estimate).
- Model tow-window availability: June–September (4 months); deduct 35–40% for ice, fog, storm (net 2.4–2.6 months access, estimate); specify element tow time and weather delays.
- Model installation: element positioning, de-ballasting, joint work (1.5–2 days per element, estimate); specify seasonal shutdown and vessel redeployment to southern yards for maintenance.
- Calculate installation rates (expected 4–6 elements per season, 44–66 in 11 seasons, estimate); identify shortfall vs. 100 elements needed (34–56 element gap, estimate).
- Model pilot-element trial (Months 9–12 = 2027-07-12 to 2027-10-12) as a go/no-go gate with 3-month contingency buffer; if pilot fails, extend by one season and redesign element.
- Model second-spread option (dual fabrication yards, dual tow fleets, staggered deployment Months 30 and 42 = 2029-04-12 and 2030-04-12, estimate) with cost (USD 5–10 billion estimate) and schedule delta (shortens Phase 1 by 12–18 months, estimate).
- Model reduced Phase 1 scope (50–70 elements = 15–20 km tunnel, estimate) with later completion (Month 150–160 = 2040-01-12 to 2040-08-12, estimate).
- Present pilot-element trial results and revised schedule at Gate 2 (Month 12 = 2027-10-12); finalize Phase 1 scope and installation plan by Gate 3 (Month 18 = 2028-04-12).

**Approval Authorities:** Arctic Construction Logistics Director, Project Director, Lender Scheduling Officer

### 11. Lender Financing Term Sheet and Debt Covenants Document

**ID:** 9e8ddfc7-b8d3-48ef-8e89-6ddfe201dc29

**Description:** Binding heads of terms and proposed debt covenants specifying: debt amount (USD 69 billion, estimate), tenor (30 years, estimate), interest rate (TBD post-due-diligence, placeholder 5.5%, estimate), conditions precedent (treaty ratification, sanctions licensing, environmental permits, Indigenous consent), mandatory prepayment triggers, and financial covenants (minimum DSCR ≥1.5x for debt sizing, covenant-breach trigger at DSCR <1.2x, proposed thresholds). Specifies revenue-assurance mechanisms (traffic insurance, take-or-pay contracts, government availability-payment backstop, as applicable). Includes force-majeure and early-termination provisions if sanctions escalate, treaty ratification fails by Month 30 (2029-04-12), or design freeze is not achieved by Month 24 (2028-10-12). Specifies financial-close conditions and closing date (target Month 24 = 2028-10-12, latest Month 30 = 2029-04-12). Intended audience: lead arrangers, lender syndicate, project sponsors, Finance Lead.

**Responsible Role Type:** Arctic Megaproject Financing Strategist / Finance Lead

**Primary Template:** Term Sheet (investment-grade infrastructure project precedent)

**Secondary Template:** Debt Covenant Framework (World Bank IBRD, IFC loan agreements)

**Steps:**

- Prepare draft term sheet by Month 6 (2027-04-12) based on financing roadmap, cost basis document, traffic study and risk assessment.
- Specify debt conditions precedent: (a) treaty ratification or framework agreement signed by both governments, (b) written OFAC/export-control licensing confirmation for financing vehicle and approved suppliers, (c) environmental permits (framework, detailed marine, MMPA ITA issued), (d) Indigenous consent agreements signed, (e) design freeze approved.
- Define financial covenants: DSCR ≥1.5x for debt sizing; covenant breach at DSCR <1.2x; mandatory prepayment if DSCR falls to 1.0x; lender right to foreclose or force restructuring.
- Include revenue-assurance mechanisms: traffic insurance (if available), take-or-pay pre-sales (minimum 30% of expected revenue, estimated USD 2.7–4.5 billion/yr), availability-payment backstop (if government co-guarantees).
- Specify force-majeure and exit provisions: project can be abandoned if treaty ratification fails by Month 30 (2029-04-12), sanctions escalate beyond defined thresholds, or design freeze is not achieved by Month 24 (2028-10-12).
- Include syndication schedule: lead arrangers to syndicate to broader lender pool within 90 days of heads-of-terms signature (Month 9 = 2027-07-12).
- Negotiate heads-of-terms with 2–3 lead arrangers by Month 9 (2027-07-12); circulate final term sheet to broader syndicate (Months 12–18 = 2027-10-12 to 2028-04-12); target full syndication and financial close by Month 24 (2028-10-12).

**Approval Authorities:** Lead Arrangers, Lender Credit Committee, Finance Lead, Project Director, Sponsor Board

### 12. Environmental Impact Assessment (EIS/EIA) Scope and Baseline Surveys Plan

**ID:** 56cbc9e3-b86b-4376-aea6-462936ef52da

**Description:** Detailed outline of US National Environmental Policy Act (NEPA) environmental impact statement and Russian environmental impact assessment (EIA) scope covering: ice-floe and seismic structural impacts; permafrost thaw and subsidence; marine-mammal behavior and acoustic impacts; fisheries effects; Indigenous subsistence use; cumulative climate-change impacts over 100-year design life; and traffic-related air and noise emissions. Specifies baseline survey schedule: ice-load monitoring (Months 0–18 = 2026-10-12 to 2028-04-12), marine-mammal surveys (Months 0–12 = 2026-10-12 to 2027-10-12), geotechnical drilling and permafrost characterization (Months 0–12 = 2026-10-12 to 2027-10-12), seismic and ground-response studies (Months 0–12 = 2026-10-12 to 2027-10-12). Plans tiered permitting: framework permits (Months 6–9 = 2027-04-12 to 2027-07-12) based on preliminary EIS/EIA, detailed permits (Months 12–18 = 2027-10-12 to 2028-04-12) based on final design. Intended audience: regulators (NOAA, USFWS, EPA regional, Russian environmental agencies), project team, Indigenous Council.

**Responsible Role Type:** Arctic Environmental Compliance and Marine Mammal Permitting Lead

**Primary Template:** NEPA Environmental Impact Statement Scope (CEQ guidance)

**Secondary Template:** Russian EIA Scope (Russian Federation EIA Regulations)

**Steps:**

- Conduct joint NEPA/EIA scoping with NOAA, USFWS, EPA, Russian environmental agencies and Indigenous observers by Month 3 (2027-01-12); document scoping conclusions by Month 6 (2027-04-12).
- Define EIS/EIA content: (a) Project Description (Phase 1 scope, Phase 2 options), (b) Affected Environment (ice regime, seismic history, permafrost, marine mammal populations, fisheries, Indigenous use), (c) Environmental Consequences (ice-load impacts on structures, permafrost thaw, marine-mammal disturbance, subsistence effects, cumulative climate change), (d) Mitigation Measures (acoustic controls, seasonal restrictions, ice-deflection structures, subsistence-protection programs), (e) Alternatives (no action, bridge-only, island-chain, staged tunnel).
- Establish baseline-survey schedule aligned with design timeline: ice monitoring and seismic data needed by Month 18 (2028-04-12) for design freeze.
- Identify regulatory permits required: MMPA ITA (NOAA), Endangered Species Act Section 7 consultation (USFWS), Clean Water Act Sections 401/404 (EPA/states), Russian environmental permits (Federal Agency for Fisheries, regional authorities).
- Plan tiered permitting: framework-level EIS/EIA public comment and agency sign-off (Months 6–9 = 2027-04-12 to 2027-07-12); detailed EIS/EIA following design freeze (Months 18–24 = 2028-04-12 to 2028-10-12); final permitting (Months 24–30 = 2028-10-12 to 2029-04-12).
- Establish Regulatory Coordination Committee with monthly meetings (Months 6–30 = 2027-04-12 to 2029-04-12) to maintain regulator engagement and address emerging issues early.

**Approval Authorities:** NOAA Fisheries, US Fish and Wildlife Service, EPA, Russian Federal Agency for Fisheries, respective regional authorities

### 13. Phase 1 Pilot Element Trial Specification and Execution Plan

**ID:** ebb61484-b0ed-4f5d-bf90-7f909c94782e

**Description:** Engineering specification for one full-scale immersed-tube tunnel segment (250–300 m, estimated) covering design finalization (ice-impact reinforcement, joint details, buoyancy specifications), fabrication yard selection (winner from pre-qualification, Month 3–6 = 2027-01-12 to 2027-04-12), fabrication timeline (4–5 months, estimate), tow-route planning and weather-window booking (June–September, estimated 4-month window), real-time monitoring instrumentation (GPS, accelerometers, strain gauges, structural telemetry), installation procedures (positioning, ballast control, de-watering, joint work, final surveys), and go/no-go decision criteria (fabrication: within ±5% cost and ±3 months schedule; tow: structural performance within predicted models, weather downtime <20% of window; installation: <5% tolerance, water-tight at first attempt). Failure of pilot triggers 3–6 month design/method review and redesign before full-scale production commitment. Intended audience: fabrication yards, tow contractors, installation contractors, Owner's Engineer, Independent Design Reviewer.

**Responsible Role Type:** Immersed Tunnel Systems Engineer & Installation Authority

**Primary Template:** Full-Scale Prototype Testing Protocol (engineering standards precedent)

**Secondary Template:** Marine-Immersion Procedure Manual (Fehmarnbelt Link precedent)

**Steps:**

- Pre-qualify candidate yards by Month 3 (2027-01-12); select primary yard for pilot by Month 6 (2027-04-12).
- Finalize pilot-element design (Months 6–9 = 2027-04-12 to 2027-07-12) incorporating preliminary ice-load data from Months 0–6 (2026-10-12 to 2027-04-12) monitoring.
- Establish fabrication schedule with yard (target Month 6–11 = 2027-04-12 to 2027-09-12 production cycle, estimate).
- Plan tow operations: vessel booking (June–September, estimated window), tow-route hazard analysis, emergency sheltering (Nome, Provideniya, estimate), weather contingency (propose 3-week delay buffer).
- Specify monitoring instrumentation: GPS (sub-meter accuracy), accelerometers (pitch, roll, heave), strain gauges on critical joints, thermal sensors (permafrost near elements), real-time telemetry to shore center.
- Develop installation procedures: element positioning (dynamic positioning system), ballast-control sequence, de-watering protocol, joint preparation, grouting, final surveys and sign-off.
- Define go/no-go criteria: fabrication (within ±5% cost and ±3 months schedule); tow (structural performance within ±10% of FEA prediction, weather downtime <20%); installation (alignment within ±5 cm, water-tightness achieved at first attempt); commissioning sign-off by Independent Design Reviewer and yard quality team.
- If pilot fails on any criterion, trigger Root Cause Analysis (2–3 weeks, estimate), design modification, and decision whether to: (a) extend pilot by one season with redesign, or (b) activate fallback method (shift from immersed tunnel to island/causeway for affected alignment section, cost and schedule impact to be quantified).

**Approval Authorities:** Immersed Tunnel Systems Engineer, Independent Design Reviewer, Fabrication Yard Quality Manager, Tow Contractor, Installation Contractor

### 14. Detailed Cost-Control and Change-Management Protocol

**ID:** 5a9ea225-4730-4cca-8b1d-d9a0a0c00d92

**Description:** Governance document establishing formal cost-tracking, change-order authorization and contingency-management procedures. Defines Owner's Cost Engineer role and authority (monthly variance tracking, reforecasting at variance >5%, escalation to Project Director and lender if >10%, propose thresholds); cost-variance gates (reforecast and reprice if bids exceed parametric baseline by >5% at Month 12 = 2027-10-12); contingency-pool authority (12–15% of baseline = USD 15 billion, held outside baseline, separate drawdown approval for each change); change-order process (documented impact analysis, 2-week approval cycle, board sign-off if >USD 50 million, estimate). Specifies monthly cost-tracking reports to steering committee and lenders; quarterly reforecasting with DSCR impact analysis. Intended audience: Owner's Cost Engineer, Project Director, steering committee, lenders, contractors.

**Responsible Role Type:** Cost Estimating & Financial Controls Engineer

**Primary Template:** Project Cost Management Plan (PMI PMBOK)

**Secondary Template:** Earned-Value Management System (EVMS) Protocol (US Department of Defense precedent)

**Steps:**

- Establish Owner's Cost Engineer position (Month 6 = 2027-04-12); assign individual with 10+ years Arctic or megaproject experience.
- Define monthly cost-tracking metrics: actual spend vs. baseline by work-breakdown-structure (WBS) category; cumulative variance (target within ±5% by Month 12 = 2027-10-12, ±7% by Month 24 = 2028-10-12, propose thresholds).
- Establish reforecasting schedule: monthly updates (Months 6–24 = 2027-04-12 to 2028-10-12); quarterly steering-committee reports with DSCR impact analysis.
- Define cost-variance gates: if cumulative variance exceeds ±5% by Month 12 (2027-10-12), trigger immediate design review and scope/schedule trade-off analysis; if variance is >±10%, escalate to steering committee and lenders for repricing or alternative-funding decision.
- Establish contingency-pool management: contingency (USD 15 billion) held in separate account; drawdowns authorized only for documented, board-approved cost changes or unforeseen conditions; monthly tracking of contingency balance and cumulative drawdowns.
- Define change-order process: cost-change request triggers documented impact analysis (budget, schedule, technical risk); changes <USD 10 million approved by Project Director and Cost Engineer (2-week cycle); changes >USD 10 million require steering-committee or lender approval; changes >USD 50 million require formal repricing and term-sheet amendment (propose thresholds).
- Publish monthly cost-status report (actual vs. planned, variance, forecast at completion, contingency balance, key drivers of variance) to steering committee and lenders starting Month 12 (2027-10-12).

**Approval Authorities:** Cost Engineer, Project Director, Steering Committee (for >USD 10 million changes), Lender Financial Officer (for covenant-material changes)

### 15. Binational Operations and Incident-Command Plan

**ID:** fdff0671-f58c-49d3-a93a-af4e3bf32bd2

**Description:** Technical and governance specification for Phase 1 and Phase 2 operational model: toll collection (plaza design, payment systems, seasonal closures), customs and immigration (sealed-transit protocol, processing time targets <30 minutes per vehicle, estimate), emergency response (rescue stations at both shores, cross-passages every 500–1000 m, estimate, ventilation system sizing for tunnel fire), incident command (binational incident-command center, closure-authority protocol, both governments hold independent closure rights for defined emergencies, propose thresholds: major structural damage, tunnel fire, seismic event, ice-floe strike), and winter operations (convoy-only protocol, speed restrictions, de-icing capability). Establishes Joint Operations Committee (representatives from both governments, operator, Indigenous observer, safety regulator) meeting monthly starting Month 24 (2028-10-12) (construction start). Specifies quarterly joint emergency drills (Months 24–180 = 2028-10-12 to 2041-10-12). Intended audience: governments, operators, regulators, lenders.

**Responsible Role Type:** Binational Treaty and Sovereign-Risk Counsel, Emergency Response Director

**Primary Template:** Cross-Border Infrastructure Operations Manual (Great Lakes precedent)

**Secondary Template:** Incident-Command System (US NIMS standard)

**Steps:**

- Draft toll-plaza and customs-processing design (Months 6–12 = 2027-04-12 to 2027-10-12) specifying: facility footprint (estimate 5–10 hectares per shore), toll booths (propose 8–12 lanes, staffed 24/7), sealed-freight-transit protocol (RFID sealing, X-ray inspection, pre-clearance), passenger immigration processing (estimate 30-minute throughput per vehicle, propose target), and security barriers (vehicle gates, emergency closures).
- Develop emergency-response protocol (Months 6–18 = 2027-04-12 to 2028-04-12): rescue-station location (both shores, possibly mid-strait island if feasible), personnel staffing (24-hour emergency responders, medical capability, fire suppression), de-icing equipment, tunnel-fire suppression system design (ventilation system sizing for worst-case fire load, cross-passages as refuge areas every 500–1000 m).
- Draft closure-authority and incident-command procedures: specify trigger events (major bridge damage, tunnel fire, seismic event, ice-strike causing structural failure); each government retains independent closure authority for security-related threats within its jurisdiction; joint authority for infrastructure damage within shared facilities; closure decision timeline (propose <1 hour for detection and decision).
- Establish Joint Operations Committee structure; convene first meeting by Month 30 (2029-04-12) (pre-commissioning).
- Schedule quarterly emergency drills (Months 24–180 = 2028-10-12 to 2041-10-12 starting in Year 2 of construction, estimate) practicing tunnel-fire evacuation, bridge-damage response and multi-jurisdictional coordination.
- Document all procedures in a comprehensive Operations Manual (target Month 18–24 = 2028-04-12 to 2028-10-12) covering routine traffic management, seasonal winter protocols, emergency response and operator checklist.

**Approval Authorities:** Binational Operations Committee, US Department of Homeland Security, Russian Federal Security Service (border and customs authority), Project Operator

### 16. Phase 1 Completion and Commissioning Criteria Document

**ID:** 8b1418a1-3285-449b-9230-cab8a2b087b1

**Description:** Formal definition of Phase 1 completion and commissioning milestones, success metrics and sign-off authority. Specifies tunnel-element acceptance (80–120 elements immersed, approximately 20–36 km of tunnel operational, estimate); rail-track installation and testing (full rail line operational between Alaska and Russia landfalls); utility-gallery acceptance (fiber, power systems tested and ready for lease); safety certification (fire, life-safety, emergency egress tested and approved by both governments); traffic ramps (tolling system operational, customs processing functional, emergency response teams trained and on station); and revenue draw-down (initial operations revenue flowing to debt service account). Establishes Phase 1 as either (a) a self-contained asset viable on its own (rail-and-utility crossing, generates independent revenue), or (b) a foundational phase requiring Phase 2 for full trade-corridor viability (clarifies which interpretation guides revenue underwriting). Sets target completion date as Month 180 (2041-10-12) (estimate based on user constraint; if installation rate validates at <7 elements/season, reset to Month 200+ = 2043+, estimate). Intended audience: Project Director, Independent Commissioning Authority, governments, lenders, operators.

**Responsible Role Type:** Project Director / Executive Sponsor Lead, Independent Commissioning Authority

**Primary Template:** Major Project Commissioning and Handover Protocol

**Secondary Template:** Phased Acceptance and Provisional-Operation Certificate (megaproject precedent)

**Steps:**

- Define Phase 1 scope explicitly: confirm 80–120 tunnel elements installed, 20–36 km of rail-and-utility tunnel operational, or reduced scope (50–70 elements = 15–20 km, estimate) if installation-rate closure mandates Phase 1 rescope by Gate 3 (Month 18 = 2028-04-12).
- Establish tunnel-element acceptance criteria: structural integrity per design (stress levels <nominal under service load), water-tight joint performance (no seepage >0.1 L/min per joint, estimate), utility-gallery functionality (fiber, power systems operational per tenant specifications).
- Specify rail-line acceptance: track geometry per specification (±10 mm lateral, ±20 mm vertical over 100 m, propose thresholds), rail-car performance testing (loaded and unloaded runs, brake testing, acoustic limits), signaling and switching systems operational.
- Define utility-gallery acceptance: fiber-optic cable spliced and tested (transmission loss <0.1 dB per connection, estimate), power-interconnection cable energized and synced with regional grids, service levels confirmed (uptime 99.5%, estimate).
- Establish safety-certification criteria: tunnel fire-safety system acceptance (full-scale fire test if code permits; ventilation system verification), emergency-egress route testing (cross-passage accessibility, fresh-air supply), structural-health monitoring system calibrated and reporting baseline readings.
- Define commissioning sign-off authority: Commissioning Authority (independent engineer, approved by both governments and lenders) conducts final inspection (Months 150–180 = 2040-01-12 to 2041-10-12, estimate based on Phase 1 completion date); issues Provisional-Operation Certificate and Substantial-Completion Certificate upon acceptance.
- Establish Phase 1 revenue-draw-down schedule: tolling and utility-lease payments directed to debt-service reserve account starting upon Provisional-Operation Certificate; revenue applied to annual debt service (USD 4.75 billion/yr, estimate) and O&M reserve (USD 1.8 billion/yr, estimate) per lender instructions.
- Clarify Phase 1 commercial viability: publish brief economic assessment confirming whether Phase 1 is a self-contained asset (rail-and-utility crossing generating USD 2–4 billion/yr revenue, estimate) or foundational only (depends on Phase 2 suspension spans and road lanes for full trade-corridor viability); guides Phase 2 funding and timing decisions.

**Approval Authorities:** Independent Commissioning Authority, US Department of Transportation, Russian Ministry of Transport, Lead Lenders, Project Operator

### 17. Arctic Fabrication Yard Pre-Qualification and Framework Agreement Portfolio

**ID:** 243f894d-6c4c-4c77-8a45-b55a5a1ef9b3

**Description:** Technical and commercial evaluation of 2–3 candidate immersed-tube tunnel-fabrication yards (Pacific Northwest, South Korea, Japan, northern Europe) against project-specific criteria: documented Arctic immersion experience (Fehmarnbelt, Hong Kong-Zhuhai-Macau Bridge or equivalent), capacity for 5–6 elements per year (250–300 m each), Arctic-rated materials availability (cold-temperature steel, low-permeability concrete admixtures, epoxy-coated rebar), quality-assurance systems, labor availability (Arctic premium wages budgeted, turnover assumptions modeled), tow-vessel arrangements (ice-class support estimated), and fixed/capped unit-cost terms. Includes non-binding Requests for Qualifications (RFQ), technical site visits, and binding framework agreements signed by Month 6 (2027-04-12) committing to production schedule aligned to tow windows, Arctic materials standards, force-majeure substitution provisions and change-order dispute resolution. Intended audience: Project Director, Arctic Construction Logistics Director, fabrication-yard candidates, lenders.

**Responsible Role Type:** Arctic Construction Logistics & Supply-Chain Director, Immersed Tunnel Systems Engineer & Installation Authority

**Primary Template:** Procurement Specification and Request for Qualifications (RFQ) Template

**Secondary Template:** Equipment Supply Framework Agreement (Arctic construction precedent)

**Steps:**

- Issue detailed RFQ to 4–6 candidate yards by Month 0 (2026-10-12), requesting: documented Arctic or heavy marine experience, production capacity (elements/year), quality-assurance certifications, labor agreements, Arctic materials procurement relationships, tow-vessel arrangements, willingness to enter framework agreement with fixed unit costs and penalties for schedule slip.
- Conduct technical site visits (Months 1–3 = 2026-11-12 to 2027-01-12) to top 3 candidate yards; assess fabrication floor layout, crane capacity, concrete-mix capabilities, welding and joint-preparation quality control.
- Request binding cost proposals from top 2 candidates (Months 2–3 = 2026-12-12 to 2027-01-12) for unit cost per tunnel element (250–300 m), including Arctic material premiums, labor, quality assurance and tow preparation.
- Negotiate framework agreements with primary and backup yards (Months 3–6 = 2027-01-12 to 2027-04-12) specifying: fixed unit cost ± escalation cap (propose 3–5% annual, estimate), production schedule aligned to tow windows (June–September annually starting 2029, estimated), Arctic materials standards (steel certification, concrete testing, joint specifications), quality-assurance protocols (NDT inspection, final acceptance criteria), force-majeure and substitution provisions (allow secondary-yard sourcing if primary yard fails to deliver), and change-order dispute resolution (limited to documented design changes approved by Owner's Engineer).
- Sign binding framework agreements with both yards by Month 6 (2027-04-12); establish quarterly coordination meetings to track design progress and production planning.

**Approval Authorities:** Arctic Construction Logistics Director, Immersed Tunnel Systems Engineer, Project Director, Lender Procurement Officer

### 18. Detailed Schedule and Critical-Path Analysis (Months 0–180 = 2026-10-12 to 2041-10-12)

**ID:** 14a97608-e83a-4ef0-bc51-588fec4e77e3

**Description:** Comprehensive Gantt schedule (Microsoft Project, Primavera P6 or equivalent) modeling all work streams: financing (lender engagement, term-sheet negotiation, financial close), permitting (baseline surveys, EIS/EIA, framework permits, detailed marine permits, MMPA ITA), treaty negotiation (framework agreement, government ratification), design (preliminary, iterative refinement, design freeze), construction (pilot element trial, fabrication ramp-up, tow and installation, commissioning), and Indigenous engagement (community mapping, Council formation, consent agreements). Establishes critical-path dependencies, schedule float (6–12 months proposed threshold), and decision gates (Months 6, 12, 18, 24 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12) with predecessor conditions. Models installation-rate scenarios: single-spread baseline (3–8 elements/season, Phase 1 completion Month 200+ = 2043+), second-spread acceleration (9+ elements/season, Phase 1 completion Month 150–180 = 2040-01-12 to 2041-10-12). Includes schedule-risk analysis (Monte Carlo simulation) quantifying probability of commissioning by Month 180 (2041-10-12) versus likely push-out. Intended audience: Project Director, Steering Committee, lenders, contractors.

**Responsible Role Type:** Program Controls and Schedule Risk Management Officer

**Primary Template:** Critical-Path Method (CPM) Schedule (Primavera P6, MS Project standard)

**Secondary Template:** Schedule-Risk Analysis (Monte Carlo simulation)

**Steps:**

- Establish Work Breakdown Structure (WBS) covering all project phases: strategic planning, financing, permitting, design, construction, operations.
- Map activity sequences and dependencies: finance gate (Month 9 = 2027-07-12) gates design-freeze (Month 18 = 2028-04-12); design freeze gates construction start (Month 24–30 = 2028-10-12 to 2029-04-12); permitting gates construction (framework permits Month 6–9 = 2027-04-12 to 2027-07-12, detailed permits Month 12–18 = 2027-10-12 to 2028-04-12).
- Model financing stream: lender engagement (Months 1–3 = 2026-11-12 to 2027-01-12), information memorandum (Months 3–4 = 2027-01-12 to 2027-02-12), roundtable (Months 4–5 = 2027-02-12 to 2027-03-12), heads of terms (Months 6–9 = 2027-04-12 to 2027-07-12), syndication (Months 9–24 = 2027-07-12 to 2028-10-12), financial close (Month 24 = 2028-10-12).
- Model permitting stream: baseline surveys (Months 0–12 = 2026-10-12 to 2027-10-12), EIS/EIA scoping (Months 3–6 = 2027-01-12 to 2027-04-12), framework EIS/EIA public comment (Months 6–9 = 2027-04-12 to 2027-07-12), framework permits issued (Month 9 = 2027-07-12), detailed EIS/EIA following design freeze (Months 18–24 = 2028-04-12 to 2028-10-12), detailed marine permits (Month 24 = 2028-10-12).
- Model design stream: preliminary design (Months 0–12 = 2026-10-12 to 2027-10-12), design reviews and iteration (Months 6–18 = 2027-04-12 to 2028-04-12), design freeze approval (Month 18 = 2028-04-12) contingent on ice-load data adequacy.
- Model construction stream: pilot-element trial (Months 9–12 = 2027-07-12 to 2027-10-12, decision gate 3 months buffer if redesign needed), fabrication ramp-up (Months 18–30 = 2028-04-12 to 2029-04-12, two yards phased start), tow seasons (June–September annually, Months 30–180 = 2029-04-12 to 2041-10-12), installation (3–8 per season baseline, Months 42–180 = 2030-04-12 to 2041-10-12 estimated), commissioning (Month 180 = 2041-10-12 target, or Month 200+ = 2043+ if single-spread productivity realized).
- Calculate critical-path duration: finance close (Month 24 = 2028-10-12) + design finalization (Month 24–30 = 2028-10-12 to 2029-04-12 after financial close) + construction (Months 30–180 = 2029-04-12 to 2041-10-12) = approximately 180 months (achievable only if single-spread installation produces 9 elements/season, which is optimistic, estimate).
- Identify schedule float: 6–12 months available for financing or permitting delays before impacting construction start; one lost open-water season (12 months) consumes all float unless second spread is accelerated.
- Run Monte Carlo simulation (1,000 iterations) with probabilistic durations on long-lead activities (fabrication yard ramp-up, tow-window weather delays, permit issuance delays); quantify probability of Phase 1 commissioning by Month 180 (2041-10-12) (likely <30%, estimate, if based on single-spread productivity of 6–8 elements/season).
- Present critical-path baseline and schedule-risk summary at Gate 1 (Month 6 = 2027-04-12); update schedule with pilot-element trial results at Gate 2 (Month 12 = 2027-10-12); finalize Phase 1 completion date at Gate 3 (Month 18 = 2028-04-12) after decision on second spread or scope reduction.

**Approval Authorities:** Program Controls and Schedule Risk Management Officer, Project Director, Steering Committee

### 19. Pre-Approved Supplier and Long-Lead Equipment Procurement List

**ID:** 8304e45f-02fd-4517-a0a2-536821564406

**Description:** Comprehensive list of all Phase 1 long-lead equipment (lead time >12 months): cable (main suspension cables, power-interconnection cables, telecom fiber), structural steel (tower segments, span connectors), tunnel elements and liners, tunnel-fire suppression and ventilation systems, electrical and control systems, toll-collection infrastructure, and emergency-response equipment. For each category, identifies: primary suppliers (pre-qualified by Month 6 = 2027-04-12), secondary and tertiary backup sources (different countries, if possible, to avoid single-source sanctions exposure), unit costs (validated by Cost Task Force), lead times (design-to-delivery, months estimate), export-control classifications (ECCN, if US-origin), and sanctions-compliance status (confirmed by export-control counsel). Specifies procurement timeline: letters of intent (Month 6 = 2027-04-12) to reserve queue position, supply contracts (Months 9–12 = 2027-07-12 to 2027-10-12) with fixed prices and escalation caps, long-lead-material buffer stocking (Months 18–24 = 2028-04-12 to 2028-10-12, propose 10–15% excess for critical items like cable and structural steel to insure against supplier failure mid-project). Intended audience: Finance Lead, Procurement Team, Sanctions Counsel, Cost Engineer, Lenders.

**Responsible Role Type:** Arctic Construction Logistics & Supply-Chain Director, Sanctions & Export-Control Counsel / Financing Lawyer

**Primary Template:** Procurement Schedule and Supplier Pre-Qualification Matrix

**Secondary Template:** Export-Control and Sanctions Compliance Supplier Vetting Checklist

**Steps:**

- Identify all Phase 1 long-lead items (>12 months typical lead time) by work package: cables, structural steel, tunnel systems, fire/life-safety, electrical, tolling, emergency equipment.
- For each item, research and contact 3–4 potential suppliers; request qualifications, lead times, current pricing and Arctic experience (Months 0–3 = 2026-10-12 to 2027-01-12).
- Pre-qualify primary, secondary and tertiary suppliers (Months 3–6 = 2027-01-12 to 2027-04-12); confirm export-control classifications and sanctions compliance (US-origin vs. third-country, subject to EAR/ITAR or not).
- Issue letters of intent (LOI) to primary suppliers (Month 6 = 2027-04-12) to reserve queue position, lock design-change terms and initiate engineering samples/prototypes if required.
- Negotiate supply contracts (Months 6–12 = 2027-04-12 to 2027-10-12) specifying: unit cost, escalation cap (propose 3–5% annual, estimate), delivery schedule aligned to construction sequence (Months 24–60 = 2028-10-12 to 2031-10-12, estimate fabrication and procurement window), quality standards (testing/certification per design), force-majeure substitution provisions (allow secondary-supplier sourcing if primary cannot deliver within agreed timeline, with cost delta <15%, estimate), and liquidated damages for delivery delays (propose 0.5% per month up to 5% of contract value, estimate).
- Establish strategic buffer-stocking plan (Months 18–24 = 2028-04-12 to 2028-10-12): procure and stockpile 10–15% excess of critical long-lead items (cable, structural steel, tunnel concrete additives) to protect against mid-project supplier failure; store in secure facilities at or near project site (Nome, Provideniya, estimate).
- Maintain sanctions-compliance tracking (monthly, Months 6–60 = 2027-04-12 to 2031-10-12): monitor supplier financial health, geopolitical exposure (sanctions listings, trade-policy changes), and capacity utilization; escalate to Project Director and Sanctions Counsel if any supplier faces sanctions or export-control restrictions.
- Publish pre-approved supplier list to lenders at financial close (Month 24 = 2028-10-12) as evidence of supply-chain de-risking and compliance.

**Approval Authorities:** Arctic Construction Logistics Director, Sanctions Counsel, Cost Engineer, Project Director, Lender Procurement Officer

### 20. Risk Register and Mitigation Action Plan (Living Document)

**ID:** ccc82cbd-069d-4f8a-9c44-b05290365160

**Description:** Comprehensive identification and management of all project risks across political, financial, technical and operational domains. Identifies 20+ risk events (treaty ratification slip 12–36 months, capital cost overrun USD 10–30 billion, ice-load data inadequacy, installation-rate gap between 9 needed and 3–8 planned per season, sanctions escalation, financing withdrawal, Indigenous consent disputes, marine-mammal stop-work orders 3–6 months, labor turnover 30–50%, etc.). For each risk, specifies: event description, probability (Low/Medium/High), impact (Cost $M, Schedule months, Reputation), inherent risk rating (pre-mitigation), mitigation actions (who, when, deliverables), residual risk rating (post-mitigation), and owner accountability. Establishes trigger thresholds and escalation protocols: if cost variance exceeds 5% at Month 12 (2027-10-12), trigger rebaselining review; if ice-load data are inconclusive at Month 18 (2028-04-12), extend observational period rather than force design freeze; if lenders do not commit heads of terms by Month 9 (2027-07-12), invoke Gate 2 paid pause. Reviewed quarterly by Steering Committee; updated monthly by Project Director and Risk Owner. Intended audience: Steering Committee, Project Director, Risk Owners, Lenders.

**Responsible Role Type:** Project Director / Executive Sponsor Lead, Program Controls and Schedule Risk Management Officer

**Primary Template:** Risk Register and Risk Management Plan (PMI PMBOK, ISO 31000)

**Secondary Template:** Risk Heat Map and Mitigation Action Tracking

**Steps:**

- Establish Risk Register template with columns: Risk ID, Category (Political/Financial/Technical/Operational), Event Description, Probability (Low/Medium/High), Impact ($M, Schedule months, Reputational), Inherent Risk (Probability × Impact), Mitigation Actions, Mitigation Owner, Completion Date, Residual Risk, Status.
- Conduct risk identification workshop (Month 1 = 2026-11-12) with Project Director, Owner's Engineer, Finance Lead, Indigenous Relations Lead, Arctic Logistics Lead, Sanctions Counsel and representatives from sponsors and lenders; brainstorm all foreseeable risks across project phases.
- Document all identified risks (estimated 25–30 events) including: treaty ratification (probability Medium/High, 12–36 month slip impact), financing gap (probability Medium/High, USD 20–30 billion uncovered), ice-load design uncertainty (probability Medium, USD 50–200 million post-construction repair), installation-rate gap (probability High, 20–36 month delay if single-spread), sanctions escalation (probability Medium, +100–200 bps financing cost), Indigenous consent disputes (probability Medium, 6–18 month injunction), marine-mammal stop-work (probability Medium, 3–6 months per incident), labor turnover (probability High, 20–40% productivity loss), geopolitical withdrawal (probability Medium, stranded capital USD 50–150 million), permitting delays (probability Medium, 12–24 months).
- Develop mitigation strategies for each risk: political risks mitigated by gating structure with paid pause and exit provisions; financial risks by early lender commitment and revenue pre-sales; technical risks by observational design and pilot trials; operational risks by Indigenous benefit-sharing and marine-mammal monitoring programs.
- Assign risk owners (specific named individuals accountable for monitoring and mitigation action execution); establish review cadence (monthly by risk owner, quarterly by steering committee).
- Create Risk Heat Map (Probability × Impact matrix) to visualize high-priority risks and trigger thresholds for escalation.
- Integrate risk monitoring into steering-committee meetings (monthly); require status updates on all High-risk and Medium-risk items; escalate any risk that has moved toward higher probability or impact.
- Update Risk Register quarterly with new risks, changes to probability/impact assessments, completion status of mitigation actions, and lessons learned.

**Approval Authorities:** Project Director, Steering Committee, Risk Review Board (if separate from Steering Committee)

### 21. Phase 2 Preliminary Scope and Feasibility Assessment (Suspension Spans and Road Lanes, 49–65 km)

**ID:** 03c01173-b7d3-45f0-ab61-a8facfa58f91

**Description:** High-level definition of Phase 2 scope (suspension-bridge spans of 2–3 km each, carrying road lanes for vehicle and truck traffic, covering the remaining ~49–65 km of alignment not occupied by Phase 1 immersed tunnel, estimated). Includes preliminary design concept (main-span geometry, tower heights, cable arrangements, deck width, ice and seismic load assumptions), estimated CAPEX (range USD 40–80 billion, estimate, pending Phase 1 cost baseline validation), estimated timeline (design Months 120–150 = 2036-04-12 to 2039-04-12, construction Months 150–240 = 2039-04-12 to 2046-10-12, estimate), and gating criteria for Phase 2 advancement (Phase 1 commissioning achieved, Phase 1 traffic >80% of forecast for 12 months, Phase 1 debt service covered at >1.3x DSCR, Phase 2 funding committed). Notes the critical decision: whether Phase 2 is a self-contained road-and-span upgrade to Phase 1 (full 85 km end-state crossing), or whether Phase 2 scope is reduced and Phase 1 is a standalone asset. Intended audience: sponsors, lenders, governments (for long-term planning), steering committee.

**Responsible Role Type:** Project Director / Executive Sponsor Lead, Lead Structural Engineer (Bridge & Spans)

**Primary Template:** Feasibility Study and Preliminary Scope Definition (World Bank, ARUP precedent)

**Secondary Template:** Phased Development and Option Strategy (real-options analysis)

**Steps:**

- Define Phase 2 alignment and end-state crossing geometry: 49–65 km of suspension-bridge spans (2–3 km each = 3–4 main spans estimate) connecting Phase 1 tunnel portal to both shore landfalls (Wales and Uelen).
- Develop preliminary main-span design: tower heights, cable arrangements, deck width and road lanes (propose 3–4 lanes for vehicles, 1–2 lanes for rail, plus emergency shoulder, estimate), ice-shedding devices, seismic damping systems (similar specifications as Phase 1 bridge consultation).
- Estimate Phase 2 CAPEX: main-span and approach-span construction, approach roads and rail on both coasts (Months 120–150 = 2036-04-12 to 2039-04-12), preliminary cost range USD 40–80 billion (pending Phase 1 unit-rate validation and inflation adjustment).
- Identify Phase 2 revenue case: combined Phase 1 + Phase 2 toll revenue (road and rail on full 85 km, versus Phase 1 rail-only revenue); traffic demand model to be updated post-Phase-1-commissioning with actual usage data.
- Establish Phase 2 gating criteria: (a) Phase 1 commissioned, (b) Phase 1 traffic >80% of forecast for 12 consecutive months (evidence of demand), (c) Phase 1 debt service covered at DSCR >1.3x (evidence of financial viability), (d) Phase 2 financing committed (either by original lender consortium, government, or new investors). If any criterion is not met, Phase 2 is deferred or rescoped.
- Develop a 'Real Options' analysis: value the flexibility to defer Phase 2, rescope Phase 2 (fewer lanes, reduced span capacity) or abandon the full 85 km crossing plan. Quantify the cost of waiting (higher inflation, delayed trade-corridor benefits) versus benefit of deferral (preserved capital, demand validation through Phase 1 operation).
- Publish Phase 2 Preliminary Scope Document by Month 12 (2027-10-12) for sponsor and lender review; update annually post-Phase-1-commissioning with actual Phase 1 data and revised Phase 2 cost/demand forecasts.

**Approval Authorities:** Project Director, Sponsor Board, Lead Lenders (for long-term planning alignment)

## Documents to Find

### 1. Current Bering Strait Ice-Regime Data and Historical Records

**ID:** 8ebbf4d9-8bad-442c-8499-8ce0ddc2a70d

**Description:** Satellite imagery (NOAA, NSIDC archives), ice-buoy drift records, and historical ice-thickness and pressure-ridge surveys from government agencies (NOAA, USCG, Russian Arctic and Antarctic Research Institute). Raw source material documenting multi-decadal ice-floe velocity, maximum ridge depth (keel), floe-impact pressures and seasonal timing. Required to calibrate observational design load cases (50/100/500-year return periods) and validate ice-mechanics models for pier design. Type: scientific datasets and government survey reports. Intended use: design envelope validation, 12–18 month observational-design monitoring baseline.

**Recency Requirement:** Most recent available year (preferably 2015–2026 for recent satellite data); historical time series back to 1980s acceptable for regime characterization and climate-shift analysis.

**Responsible Role Type:** Lead Structural Engineer (Bridge & Spans) / Immersed Tunnel Systems Engineer, Arctic Environmental Compliance Lead

**Access Difficulty:** Easy to Medium. Satellite data (NOAA, NASA) are publicly available; historical buoy data and USCG records require formal request to government agencies (2–4 weeks typical); Russian AARI data may require Russian-language contact and diplomatic coordination (4–8 weeks estimate).

**Steps:**

- Contact NOAA Polar Oceans Program (Boulder, CO) for satellite ice-extent and thickness archives (SeaIce.gsfc.nasa.gov).
- Request USCG and Russian Federal Service for Hydrometeorology historical ice-buoy deployment data.
- Contact Russian Arctic and Antarctic Research Institute (AARI, St. Petersburg) for ice-ridge and pressure-field surveys.
- Search NSIDC (nsidc.org) for processed ice-drift and sea-ice-concentration datasets.
- Engage regional Arctic research centers (Geophysical Institute, University of Alaska Fairbanks; Arctic Council Secretariat) for any unpublished regional compilations.

### 2. Regional Seismic Hazard and Earthquake Catalogs for Bering Strait and Aleutian Subduction Zone

**ID:** 02842232-a773-49a6-b5be-1406b4db8067

**Description:** Official earthquake catalogs, focal-mechanism solutions and ground-motion prediction models (USGS, Russian Academy of Sciences) for the Aleutian subduction zone and Arctic spreading centers within 200+ km of the Bering Strait alignment. Raw source material documenting historical seismic events (magnitude, frequency, depth), fault geometry, and regional ground-motion attenuation relations. Required to establish design-basis earthquake return periods (50/100/500-year, estimate) and site-specific seismic hazard for pier foundation and tunnel design. Type: government seismic databases, peer-reviewed hazard studies.

**Recency Requirement:** Most recent USGS Seismic Hazard Models (updated ~2018–2021); historical catalogs acceptable back to 1900s for magnitude-frequency relations; latest ground-motion prediction equations from peer review literature (2015+).

**Responsible Role Type:** Lead Structural Engineer (Bridge & Spans) / Immersed Tunnel Systems Engineer

**Access Difficulty:** Easy (USGS public databases, peer-reviewed literature); Russian Academy data and localized hazard studies require agency request (2–4 weeks).

**Steps:**

- Download USGS Seismic Hazard Map products (earthquake.usgs.gov) for Alaska and US Exclusive Economic Zone.
- Contact USGS Alaska Science Center (Anchorage) for custom seismic-hazard study and local-expert input.
- Request Russian Academy of Sciences Geophysical Institute (Moscow) for Aleutian and Russian Arctic seismic catalogs and focal mechanisms.
- Access peer-reviewed literature (GEM Hazard Model, 2018+ ground-motion equations) via university library or USGS open-access repositories.
- Engage regional seismic-monitoring networks (Alaska Earthquake Center, Kasatochi Observatory if active) for recent focal-mechanism data.

### 3. Arctic Permafrost Distribution and Thaw-Rate Data for Alaska and Chukotka

**ID:** 17b222ea-83df-487f-99e6-597da4e357f4

**Description:** Geological survey maps, permafrost-temperature monitoring networks, and thaw-subsidence measurements from USGS, NSIDC and Russian Permafrost Institute. Raw source material documenting permafrost distribution (sporadic, discontinuous, continuous zones), soil-ice content, active-layer thickness and thaw rates (meters per decade) under current and warming scenarios (2–4°C, estimate). Required to design foundations that tolerate predicted subsidence (0.5–2.0 m over 100-year life, estimate) and select stabilization methods (thermosyphons, cooling systems). Type: geological maps, monitoring network data, temperature time series.

**Recency Requirement:** Most recent permafrost surveys (USGS ~2020–2023); temperature-monitoring networks operational year-round; historical time series back to 1980s acceptable for thaw-trend analysis; IPCC climate projections (2021) for 21st-century scenarios.

**Responsible Role Type:** Lead Structural Engineer (Bridge & Spans) / Immersed Tunnel Systems Engineer, Geotechnical Engineer

**Access Difficulty:** Easy to Medium. USGS and NSIDC data are public; Russian Permafrost Institute requires formal agency request and possible translation (4–8 weeks); climate projections accessible via CMIP5/CMIP6 archives.

**Steps:**

- Contact USGS Alaska Science Center for permafrost-distribution maps and subsidence monitoring (CRREL database).
- Access NSIDC Permafrost Active Layer (PAL) and Global Terrestrial Network for Permafrost (GTN-P) archives (nsidc.org).
- Request Russian Permafrost Institute (Moscow State University) for Chukotka permafrost surveys and thaw-rate data.
- Contact University of Alaska Fairbanks Geophysical Institute for permafrost-monitoring network data (Barrow, Prudhoe Bay, other Arctic stations).
- Engage IPCC-participating climate modeling centers for regional Arctic permafrost projections under RCP 4.5 and 8.5 scenarios.

### 4. Marine-Mammal Population and Migration Data for Bering Strait Cetaceans, Pinnipeds and Walrus

**ID:** 4d07a79f-9682-4540-8eef-152f396d6053

**Description:** Government and research datasets documenting beluga, bowhead and gray whale populations, migration timing, acoustic behavior, haul-out sites for walrus and seals in the Bering Strait and adjacent waters. Source material from NOAA Fisheries, USFWS, Russian Federal Agency for Fisheries and academic research institutions (Alaska Fisheries Science Center, Marine Mammal Laboratory, universities). Raw data: population censuses, satellite-tag locations, acoustic recordings, haul-out surveys, catch records. Required to establish baseline marine-mammal distributions, migration corridors and acoustic thresholds for construction-impact modeling and regulatory incidental-take authorization (ITA) scope. Type: survey reports, population estimates, acoustic databases, satellite-tag tracks.

**Recency Requirement:** Most recent population surveys (bowhead, beluga, gray whales ~2015–2025); acoustic recordings from prior field seasons (2010+); satellite-tag data concurrent with observation period (2020+); historical catch/population records back to 1990s for trend analysis.

**Responsible Role Type:** Arctic Environmental Compliance and Marine Mammal Permitting Lead, Indigenous Engagement & Community Relations Director

**Access Difficulty:** Easy (NOAA, USFWS, AFSC publish population reports and datasets publicly); Russian data requires agency request and possible translation (4–8 weeks); academic publications available via university library or preprint servers.

**Steps:**

- Contact NOAA Fisheries Alaska Regional Office (Juneau) for beluga, bowhead and gray whale population surveys and status reports.
- Request USFWS Marine Mammals Management (Anchorage) for walrus and seal population data and haul-out site surveys.
- Access NOAA Alaska Fisheries Science Center databases (AFSC/REFM) for marine-mammal acoustic recordings and bioacoustic analyses.
- Contact Russian Federal Agency for Fisheries (Moscow) for beluga and walrus population data and catch records from Chukotka region.
- Engage academic institutions (University of Washington School of Aquatic and Fishery Sciences, Alaska Fisheries Science Center, Scripps Institute) for published population models and acoustic-behavior studies.
- Search NOAA Fisheries Open Data portal (data.noaa.gov) for marine-mammal satellite-tag datasets and real-time tracking (if available).
- Contact Indigenous knowledge-holders and subsistence hunters (Inupiat, Yupik communities) for traditional-knowledge input on whale migration timing and population observations.

### 5. Current Arctic Labor Rates and Productivity Benchmarks for Construction and Marine Operations

**ID:** acae6f19-68a9-4aff-b66f-e4c3e0c33a7d

**Description:** Regional wage surveys, labor-productivity indices and cost benchmarks from Alaska and Russian Arctic construction sectors. Source material from Alaska Department of Labor, Russian Federal State Statistics Service (Rosstat), trade union agreements, and Arctic megaproject cost-actualization reports. Data on day-rates for skilled trades (welders, divers, equipment operators), labor turnover rates (30–50%, estimate), productivity relative to temperate-zone baselines (60–70%, estimate), and Arctic premiums (30–50%, estimate). Required to validate unit-labor-cost assumptions in the parametric cost model and inform cost-control baselines. Type: wage surveys, productivity studies, project-cost reports (if public).

**Recency Requirement:** Most recent wage surveys (Alaska Dept of Labor ~2024–2025; Russian Rosstat ~2023–2025); productivity benchmarks from recent Arctic projects (North Slope oil, Fehmarnbelt ancillary labor data, ~2015–2022); historical labor-cost escalation indices (2010+).

**Responsible Role Type:** Cost Estimating & Financial Controls Engineer, Arctic Construction Logistics & Supply-Chain Director

**Access Difficulty:** Easy (Alaska Dept of Labor publishes wage surveys; trade union contracts are public); Russian wage data and Arctic-project reports may require agency request or proprietary negotiation (2–6 weeks); academic labor-productivity studies available via university library.

**Steps:**

- Contact Alaska Department of Labor and Workforce Development for regional wage surveys (Anchorage, Nome, Fairbanks wage bulletins).
- Request Alaska CTC (Construction Training Center) and trade unions (Operating Engineers Local 302, UA Local 357) for union day-rate schedules and productivity agreements.
- Contact Russian Federal State Statistics Service (Rosstat) for wages in Chukotka and Russian Far East energy sectors.
- Engage Fehmarnbelt Link project (if public records available) or similar Arctic megaproject for labor-cost actualization and productivity reports.
- Search Arctic industry publications (Oil & Gas Journal, Arctic Bulletin, industry council reports) for labor-cost benchmarks and case studies.
- Contact regional contractors (Aecon, Boskalis, Dredging International) for proprietary labor-cost estimates and productivity data (if willing to share).

### 6. Marine Logistics Costs and Ice-Class Vessel Availability Data

**ID:** 1abf9283-5a34-42f1-838f-945ceb510b9b

**Description:** Current charter rates for ice-class tow vessels, icebreaker assistance, heavy-lift barges and support vessels in Arctic waters. Source material from marine-transportation databases, vessel brokerage firms, Arctic shipping industry reports and recent megaproject contracts (if public). Data on daily charter rates (proposed baseline USD 500k–1.5M/day for ice-class prime mover, estimate), seasonal availability windows, weather-delay assumptions (35–40% of open-water season lost to ice/fog/storm, estimate), and fuel costs (premium Arctic fuel, 50–100% uplift, estimate). Required to validate marine-logistics cost assumptions and tow-window productivity baseline. Type: brokerage market data, contract summaries, industry cost reports.

**Recency Requirement:** Most recent vessel charter rates (2023–2026 market data preferred); Arctic shipping season availability documented for last 3–5 years (2020–2025); fuel-cost benchmarks from recent Arctic operations (2020+).

**Responsible Role Type:** Arctic Construction Logistics & Supply-Chain Director, Cost Estimating & Financial Controls Engineer

**Access Difficulty:** Medium. Current vessel charter rates are proprietary and require direct brokerage inquiry (1–2 weeks); Arctic Council reports are public; megaproject contracts typically confidential but executive summaries may be published (4–8 weeks to negotiate disclosure).

**Steps:**

- Contact marine-brokerage firms with Arctic expertise (Braemar ACM, Fearnleys, Arctic shipping brokers) for current ice-class vessel charter rates.
- Request quotes from major Arctic tow/heavy-lift contractors (Horizon Offshore, Boskalis, Cal Dive, Seaspan) for multi-year charter frameworks and rates.
- Access Arctic Council Secretariat and Arctic Shipping Best Practices Information Forum (ASBPIF) reports on Arctic maritime operations and cost benchmarks.
- Search published megaproject reports (Fehmarnbelt, Gotthard Base Tunnel ancillary marine operations, if available) for vessel-cost actualization.
- Contact regional shipping industry associations (Alaska Shipper & Vessel Association, Russian Far East Shipping Council) for cost indices and market intelligence.
- Monitor DNV GL and ClassNK Arctic ship classification rules and cost-impact analyses (publicly available).

### 7. Existing US and Russian Laws and Policies on Binational Infrastructure, Cross-Border Permitting and Dispute Resolution

**ID:** b6b3d08f-20f1-401b-b31b-a01514b43b50

**Description:** US legislation (International Bridges Act, binational agreement frameworks), Russian Federation laws on cross-border infrastructure and international agreements, and bilateral precedents (US-Canada Great Lakes navigation, Seaway, US-Mexico Rio Grande management). Source material for legal architecture of neutral SPV, treaty ratification pathway, and dispute-resolution mechanisms. Type: legislative texts, bilateral treaties, executive agreements.

**Recency Requirement:** Current statutes and regulations (2020+); historical precedents (1975+) for treaty structures and ratification timelines.

**Responsible Role Type:** Binational Treaty and Sovereign-Risk Counsel

**Access Difficulty:** Easy (US statutes and many treaties published on congress.gov, state.gov, UN Treaty Series); Russian laws accessible via Russian Federation Justice Ministry website or Russian law repositories (if in Russian language); binational precedent agreements often public but require multi-agency coordination to request.

**Steps:**

- US Congress Legislative Library: search 'International Bridges Act' and related statutes (congress.gov).
- US State Department Office of Treaty Affairs: request precedent binational-infrastructure agreements (US-Canada, US-Mexico, US-Japan).
- Russian Federation Ministry of Foreign Affairs and Duma Legislative Assembly: request laws on cross-border projects and international agreements.
- Consult published binational-treaty collections (UNCTAD, UN Treaty Series, bilateral repositories) for precedent language and ratification processes.
- Engage law firms with Arctic/binational experience (Baker McKenzie, White & Case, Dentons) for private research on treaty precedents (may be proprietary).

### 8. Federal and State Environmental Laws and Regulations Applicable to Bering Strait Infrastructure (US NEPA, ESA, MMPA, CWA; Russian EIA, Environmental Protection Laws)

**ID:** 60b719e8-dd7f-430b-b96e-afd8998894af

**Description:** US National Environmental Policy Act (NEPA) regulations, Marine Mammal Protection Act (MMPA), Endangered Species Act (ESA), Clean Water Act (CWA) and applicable state (Alaska, Coastal Zone Management Act) laws. Russian Federation environmental laws, Federal Service for Environmental, Technological and Nuclear Supervision (Rostekhnadzor) regulations, and Chukotka regional statutes. Source material specifying environmental assessment requirements (EIS scope, mitigation measures), marine-mammal incidental-take authorization (ITA) process, endangered-species consultation, and coastal-permit pathways. Type: federal and state statutes, agency regulations, guidance documents.

**Recency Requirement:** Current statute and regulation text (2020+); agency guidance documents and policy memoranda (latest available).

**Responsible Role Type:** Arctic Environmental Compliance and Marine Mammal Permitting Lead

**Access Difficulty:** Easy (US statutes and federal regulations published on congress.gov, eCFR and agency websites); Russian laws accessible via Russian Federation Justice Ministry website (may be in Russian; professional translation recommended); agency guidance accessible by direct agency request or FOIA/Russian equivalent (1–2 weeks).

**Steps:**

- Access US Code (Title 42 for NEPA, Title 16 for ESA/MMPA/CWA) via Congress.gov or eCFR (electronic Code of Federal Regulations).
- Contact NOAA, USFWS and EPA regional offices for agency guidance on permit requirements and ITA processes.
- Access Russian Federation State Duma laws and Rostekhnadzor regulations via Russian Federation Justice Ministry (if available in English translation, request from embassy).
- Contact US State Department and Russian Federation Ministry of Natural Resources for bilateral environmental coordination guidance.
- Engage environmental law firms (Arnold & Porter, Covington & Burling, Stoel Rives) for synthesized guidance on binational compliance (may require retainer).

### 9. OFAC Sanctions Lists, Export-Control Regulations (EAR, ITAR) and Russian Equivalent Export-Control Policies

**ID:** 7fa4f896-73f8-4742-9450-985a742dcd20

**Description:** US Treasury OFAC Specially Designated Nationals (SDN) list and Sectoral Sanctions Identification (SSI) list; US Commerce Department Bureau of Industry and Security (BIS) Export Control Classification Numbers (ECCN) and Commodity Control List (CCL); Russian Federal Service for Military-Technical Cooperation (FSMTC) and Foreign Ministry export-control lists. Source material specifying sanctioned entities, sanctioned countries and sectors, and export-controlled equipment classifications (steel, electronics, dual-use materials relevant to Arctic construction). Type: government enforcement lists, regulatory guidance.

**Recency Requirement:** Current OFAC SDN/SSI lists (updated continuously, accessible real-time); BIS CCL and ECCN database (updated regularly); Russian lists (current as of latest available).

**Responsible Role Type:** Sanctions & Export-Control Counsel / Financing Lawyer

**Access Difficulty:** Easy (OFAC and BIS lists are public and real-time accessible online); EAR/ITAR regulations published on eCFR; Russian lists require agency contact or diplomatic coordination (2–4 weeks); licensed counsel maintains real-time sanctions databases (subscription-based).

**Steps:**

- Access OFAC SDN list and SSI list via Treasury.gov (real-time database, daily updates).
- Search BIS Denied Persons List, Unverified List and Entity List (bis.doc.gov, updated regularly).
- Access BIS CCL and ECCN lookup tools (bxsearch.doc.gov) for equipment-classification queries.
- Consult ITAR and EAR regulations via eCFR or State Department DDTC website (Title 22 CFR Parts 120–130 for ITAR, Title 15 CFR Parts 730–799 for EAR).
- Contact Russian Federation Ministry of Foreign Affairs or FSMTC for Russian export-control lists and guidance (may require diplomatic request).
- Engage export-control counsel (Miller & Chevalier, Akin Gump, CBSA-Customs Law) for real-time database subscriptions and sanctions-watch services (proprietary).

### 10. Commercial Arctic Immersed-Tube Tunnel and Bridge Precedent Cost and Schedule Data

**ID:** b8478fb8-f787-41cd-8a9f-14901892bccc

**Description:** Published or publicly available cost and schedule data from comparable immersed-tube tunnel projects (Fehmarnbelt Link, Hong Kong-Zhuhai-Macau Bridge, Øresund Link, Caspian crossing feasibility studies) and Arctic bridge megaprojects (large pipeline projects, ice-capable marine structures). Source material documenting actual CAPEX per km, labor and logistics costs, schedule productivity (elements per season for immersed-tube work, bridge spans per season), Arctic premiums and cost-escalation trends. Type: megaproject reports, published cost papers, feasibility studies (if public), engineering journals.

**Recency Requirement:** Fehmarnbelt (2015–2025 cost updates), HZMB (2015–2018 cost reports), Øresund (historical 1995–2000 baseline, adjusted for inflation). Arctic projects: North Slope oil field, Trans-Alaska pipeline, contemporary LNG and mining operations (2015–2025).

**Responsible Role Type:** Cost Estimating & Financial Controls Engineer, Arctic Construction Logistics & Supply-Chain Director

**Access Difficulty:** Medium. Fehmarnbelt and HZMB publish annual reports (Easy); Øresund historical data available in published academic papers (Easy); proprietary cost data from contractors requires confidentiality agreements (2–4 weeks negotiation); unpublished feasibility studies may be held by governments or archived in libraries (Hard, 4–12 weeks).

**Steps:**

- Contact Femern A/S (Fehmarnbelt Link) Communications or Finance office via femern.com for project cost reports and lessons-learned briefings.
- Request HZMB Authority (Hong Kong-Zhuhai-Macau Bridge) technical publications and annual reports via official website.
- Engage Oresundsbron A/S for historical cost and schedule data (oresundsbron.com).
- Search Arctic industry journals (Arctic, Arctic Anthropology, Oil & Gas Journal) for case-study cost data and productivity benchmarks.
- Contact university Arctic engineering programs (University of Alaska Fairbanks, technical universities in Canada and Scandinavia) for published research on Arctic construction costs.
- Engage major Arctic contractors (Aecon, Damen, Boskalis, Horizon Offshore) for proprietary experience data (if willing to share under confidentiality agreement).

### 11. Alaska and Russian Arctic Regional Economic and Infrastructure Development Plans and Policies

**ID:** bddd36de-0710-4f0b-a62d-ff5fb897a95c

**Description:** State of Alaska strategic infrastructure plans, Russian Federation Arctic Strategy documents, Chukotka development initiatives, and regional trade forecasts. Source material defining government priorities for transportation, energy and telecom corridors, existing and planned port, rail and road infrastructure at landfalls (Wales, Uelen, Provideniya, Nome), and government funding mechanisms for cross-border projects. Type: government policy documents, development plans, regional strategic analyses.

**Recency Requirement:** Current strategic plans (Alaska 2020+, Russian Federation Arctic Strategy 2025+, Chukotka 2020+); infrastructure master plans and investment roadmaps (latest available).

**Responsible Role Type:** Project Director, Finance Lead, Arctic Megaproject Financing Strategist

**Access Difficulty:** Easy (government documents published on official websites; Arctic Council reports publicly available); Russian-language documents may require translation (professional translation recommended, 1–2 weeks).

**Steps:**

- Alaska Department of Commerce, Community and Economic Development: strategic plans and infrastructure master plans (alaska.gov).
- Russian Federation Government website and Ministry of Development of the Russian Far East & Arctic: Arctic Strategy and regional development programs (gov.ru).
- Chukotka Autonomous Okrug Administration: regional development plans and transport/infrastructure priorities (chukotka.gov.ru, if available in English).
- Arctic Council Secretariat: Arctic Regional Integrated Monitoring Assessment Programme (AMAP) reports on infrastructure and development (arctic-council.org).
- Regional economic development organizations (Alaska Native corporations, Far Eastern Development Corporation, Russian Arctic Council participants) for strategic priorities and investment readiness.

### 12. Indigenous Communities and Traditional-Use Areas: Alaska and Chukotka Stakeholder Registry and Legal Standing

**ID:** c9314bc5-2acc-4e97-86e1-bab828088a27

**Description:** Official registry of Indigenous communities with subsistence-harvesting and traditional-use rights in Alaska (Inupiat, Yupik, etc.) and Russia (Chukchi, Siberian Yupik, etc.) across the Bering Strait alignment and near-shore areas. Source material specifying: tribal enrollment, geographic territories, documented subsistence harvesting areas, traditional knowledge repositories and existing co-management agreements (e.g., Porcupine Caribou Herd management, Bering Strait beluga management committees). Type: government agency records, tribal government documents, community surveys.

**Recency Requirement:** Current tribal enrollment and governance lists (2023–2025); documentation of subsistence areas and harvest statistics (2015+); existing co-management agreement frameworks (if established, current versions).

**Responsible Role Type:** Indigenous Engagement & Community Relations Director, Binational Treaty and Sovereign-Risk Counsel

**Access Difficulty:** Medium. Alaska Native registries are relatively accessible (BIA, AFN, state websites); Russian Indigenous community registries and subsistence-rights documentation may require agency request or diplomatic coordination (4–8 weeks); direct tribal council contact is essential and may be informal/relationship-based rather than documentary (ongoing engagement).

**Steps:**

- Alaska Native Heritage Center and Alaska Federation of Natives: comprehensive Alaska Native community registry and contact information (alaskanative.org).
- US Bureau of Indian Affairs (BIA) Alaska Region: official tribal status and governance information (bia.gov/regional-offices/alaska).
- State of Alaska Department of Commerce: tribal and Indigenous organization contacts (alaska.gov).
- Russian Federation Ministry of Natural Resources: Indigenous peoples' registries and subsistence-rights documentation (if available in English or via translation).
- Bering Strait Beluga Whale Committee and other existing co-management bodies: documentation of Indigenous participation frameworks (precedent for Council structure).
- Engage tribal councils directly: contact Inupiat Circumpolar Council (ICC), Yup'ik communities (Toksook Bay, Chevak, etc.), Chukchi and Siberian Yupik organizations for stakeholder mapping and engagement preferences.

### 13. Regional Construction Labor Market Data: Alaska and Chukotka Wage Surveys, Skill Availability and Apprenticeship Programs

**ID:** 08de4dec-a0cd-4013-b347-2dc5eee7f012

**Description:** Labor-market datasets and surveys documenting wages for skilled trades (welders, divers, equipment operators, crane operators, concrete specialists) in Alaska (Nome, Fairbanks, Anchorage regions) and Russian Arctic (Chukotka, Sakha Republic). Includes apprenticeship and vocational-training program information (Alaska CTC, trade unions, Russian technical colleges) for Arctic construction specialization. Source material for validating labor-cost assumptions (30–50% Arctic premium, estimate) and identifying labor-training partnerships. Type: wage surveys, trade union contracts, regional labor-force statistics, vocational-program curricula.

**Recency Requirement:** Most recent wage surveys (2024–2025); labor-force participation statistics (2023–2025); apprenticeship-program rosters and curriculum (current 2025–2026).

**Responsible Role Type:** Cost Estimating & Financial Controls Engineer, Arctic Construction Logistics & Supply-Chain Director

**Access Difficulty:** Easy (Alaska Dept of Labor and trade union contracts public); Russian data requires agency request or translation (2–4 weeks); apprenticeship program information available through direct contact with training providers.

**Steps:**

- Alaska Department of Labor and Workforce Development: wage surveys by region and occupation (labor.alaska.gov).
- Alaska CTC (Construction Training Center): apprenticeship programs, training costs and completion rates.
- Alaska trade unions (Operating Engineers Local 302, UA Local 357, IBEW Local 3): union day-rate schedules and fringe benefits (negotiated annually).
- Russian Federal State Statistics Service (Rosstat): regional wage data for Chukotka and Sakha (via Russian Federation official statistics portal).
- Russian Arctic technical colleges and vocational institutes: Arctic construction apprenticeship programs (contact via regional education ministries).
- Regional development corporations: Far Eastern Development Corporation, Alaska Native corporations (job training and labor-supply forecasts).

### 14. Comparable Immersed-Tube Tunnel Element Fabrication and Installation Productivity Benchmarks

**ID:** bf7e9191-3662-42e4-b944-f84e162ed901

**Description:** Case-study data from Fehmarnbelt Link, Hong Kong-Zhuhai-Macau Bridge and other recent immersed-tube tunnel projects documenting: fabrication cycle time per element (months, design-to-delivery), element weight and dimensions, quality-assurance and testing timelines, tow-vessel characteristics and tow time, weather-delay history (percentage of season lost), installation rate per open-water season (elements completed, time per element), installation downtime due to equipment failure or permitting, and cost per tunnel element (actual CAPEX vs. baseline estimate). Source material for validating Phase 1 installation-rate assumption (baseline 3–8 per season, estimate) and identifying realistic productivity. Type: megaproject case studies, published technical papers, contractors' project reports (if public).

**Recency Requirement:** Recent projects (Fehmarnbelt 2020–2025 data if available; HZMB 2015–2018; pre-2010 projects acceptable for historical productivity trends).

**Responsible Role Type:** Arctic Construction Logistics & Supply-Chain Director, Immersed Tunnel Systems Engineer & Installation Authority, Cost Estimating & Financial Controls Engineer

**Access Difficulty:** Medium. Published case studies and peer-reviewed papers accessible (Easy); Fehmarnbelt public reports available (Easy); proprietary contractor data requires confidentiality agreements (2–4 weeks negotiation); Russian immersed-tube precedent data limited (Arctic tunnel construction is novel in Russia).

**Steps:**

- Contact Femern A/S (Fehmarnbelt) project office via public website or Danish engineering firms for published project reports and lessons learned.
- Request HZMB Authority (Hong Kong-Zhuhai-Macau Bridge) technical reports and annual progress summaries.
- Search engineering journals (Tunnelling and Underground Space Technology, Journal of Bridge Engineering) for peer-reviewed case studies of immersed-tube fabrication and installation.
- Engage major immersed-tube contractors (Dredging International, Jan De Nul, Boskalis, Cal Dive) for project references and historical-productivity data (may be proprietary; confidentiality agreement required).
- Contact university civil-engineering programs with marine-construction focus (UC Berkeley, University of Washington, Delft University, DTU) for published research on Arctic and marine tunnel productivity.

### 15. Fiber-Optic Submarine Cable Leasing and Telecom Interconnection Tariffs and Market Demand

**ID:** fcdf0377-a8fc-4889-8c87-621f45280a81

**Description:** Market data on lease rates for transpacific and Arctic telecom-fiber capacity, power-interconnection cable rates and typical long-term contracts (take-or-pay frameworks). Source material documenting: fiber-lease rates ($/Tbps/year, typical 10-year contracts), minimum-capacity commitments, connection-point requirements, and shipper demand from major telecom operators, cloud-service providers and data-center networks operating in the Arctic region. Type: industry rate cards, published market analyses, shipper-demand surveys (if available).

**Recency Requirement:** Most recent telecom tariff schedules (2023–2025); fiber-lease contracts from recent submarine-cable systems (if public disclosure available, 2015+).

**Responsible Role Type:** Finance Lead, Traffic Demand and Revenue Underwriting Analyst

**Access Difficulty:** Medium. Published market analyses available (Easy to Medium); telecom-operator demand surveys require direct inquiry (1–2 weeks); proprietary rate cards often confidential (requires confidentiality agreement, 2–4 weeks); SEC filings accessible online (Easy).

**Steps:**

- Contact major subsea-cable consortia and operators (Telegeography, TeleGeography, Global Gateway, Dunant, Firmina, etc.) for public rate cards and demand forecasts.
- Search industry publications (Telegeography Intelligence, TDC Intelligence, Submarine Cable Map) for Arctic telecom-fiber market analysis.
- Contact regional telecom operators and cloud providers (Alaska Communications, Viasat, Amazon Web Services, Google Cloud) for interest in Bering Strait fiber lease (non-binding inquiry).
- Engage telecommunications-consulting firms (Analysys Mason, IDC, IDATE DigiWorld) for market sizing and demand forecasts (may require consulting contract).
- Access published submarine-cable contracts (if any disclosed in SEC filings or industry publications) for rate-structure precedents.