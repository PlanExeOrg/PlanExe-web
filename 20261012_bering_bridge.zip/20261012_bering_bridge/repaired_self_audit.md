Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 16 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 3 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is a comprehensive infrastructure megaproject plan rooted in conventional civil engineering (immersed-tube tunnels, suspension bridges, Arctic geotechnical design) and multinational financing. All load-bearing mechanisms are physical — materials, construction methods, hydrodynamics, foundation bearing, environmental forces, and institutional arrangements — and do not require violating any named law of physics or invoking non-physical causation. The acknowledged demand-and-tariff gap is an empirical and business-model risk, not a physics violation.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan combines four novel elements at an unprecedented scale with no independent precedent: (1) an 85 km binational immersed-tube tunnel plus suspension bridge in a drifting-ice, seismic, permafrost environment with no Arctic precedent at this scale; (2) a neutral third-country SPV governing structure across two sovereign jurisdictions with no comparable cross-border Arctic precedent; (3) sanctions-compatible financing of USD 115 billion (estimate) to a US-Russia project under export-control constraints, untested at this capital scale; (4) a staged gated approach with paid-pause and exit provisions dependent on treaty ratification, OFAC licensing, Indigenous FPIC consent, and ice/seismic data adequacy—all non-technical conditions outside project control. The plan acknowledges "no direct precedent at this scale in a drifting-ice, seismic, permafrost environment." Failure in any of the four domains (technical, financial, political, regulatory) is likely unless validation gates explicitly confirm each assumption. Credible precedent exists for individual elements (immersed tubes: Fehmarnbelt, HZMB; binational governance: Øresund Link; Arctic construction: oil platforms) but not for the integrated system under current geopolitical and sanctions constraints.

**Mitigation**: Establish four parallel validation tracks through Month 18 (2028-04-12) with binding NO-GO gates: (1) Technical/Engineering: Complete 12–18 months of ice-regime, seismic and permafrost monitoring; pilot-element trial (Months 9–12 = 2027-07-12 to 2027-10-12); lock design freeze only if confidence intervals are within ±15% and Data Adequacy Committee certifies; (2) Financial/Market: Commission independent traffic study and secure USD 2.7–4.5 billion/yr (30–50% of required revenue) in binding take-or-pay pre-sales by Month 9 (2027-07-12); obtain lender heads of terms by Month 9 (2027-07-12) confirming debt terms and sanctions-compliance pathway; (3) Legal/Compliance: Obtain written OFAC preliminary licensing guidance by Month 3 (2027-01-12) and final approved-supplier list by Month 6 (2027-04-12); execute framework agreement with both governments by Month 24 (2028-10-12); (4) Indigenous/Social: Form Beringia Indigenous Council by Month 6 (2027-04-12) with binding advisory authority; execute FPIC consent agreements with all mapped communities by Month 12 (2027-10-12), with communities holding authority over >50% of alignment as the Month 18 (2028-04-12) stop floor. Define two global NO-GO gates: (a) empirical/engineering validity (design-freeze certification at Month 18 = 2028-04-12); (b) legal/compliance clearance (framework agreement signed and sanctions licenses confirmed by Month 24 = 2028-10-12). Failure in any critical track triggers paid-pause and exit; abandonment if any gate is unmet by Month 30 (2029-04-12).


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical strategic frameworks—particularly the tunnel installation-rate gap, revenue underwriting case, and sanctions-licensing pathway—lack defined business-level mechanism-of-action (inputs→process→customer value), measurable owners, and validated success metrics. The plan names strategic concepts (Crossing Configuration, Political Gating, Indigenous Consent, Capital Stack, Traffic Demand Underwriting) but does not ground them in executable decision trees with owner accountability and success gates. For example: Traffic Demand Underwriting assumes USD 8.9B/yr revenue with no independent traffic study, tariff analysis, or shipper pre-sales documented. Political Gating proposes explicit gates but provides no written decision criteria or escalation authority assigned to sponsors. Tunnel installation rate states 9 elements/season needed versus 3–8 achievable but defers the second-spread or scope-cut decision until Month 12 (2027-10-12), post-heads-of-terms (Month 9 = 2027-07-12), creating a blind spot when lenders commit. These strategic blindnesses directly gate financial close (Month 24 = 2028-10-12) and Phase 1 commissioning (Month 180 = 2041-10-12).

**Mitigation**: By Month 6 (2027-04-12), assign named owners with explicit accountability to produce one-pagers for the five critical strategic decisions (Political Gating, Capital Stack, Crossing Configuration, Indigenous Consent, Traffic Demand Underwriting) specifying: inputs (e.g., lender appetite, treaty status, shipper letters of interest), process (e.g., decision gate criteria, escalation path), customer value (e.g., debt capacity, commissioning date, social license), success metric (e.g., lender heads of terms signed, consent agreements executed, take-or-pay contracts covering 30% of revenue), and decision hooks (gate triggers and NO-GO thresholds). Gate 1 deliverable (Month 6 = 2027-04-12): one-pagers for all five decisions with measured inputs and owner sign-off.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because second-order risks (legal, safety, financial, reputational cascades) lack explicit mapping of cause-effect chains with named owners and control triggers. The plan identifies 22 individual risks in assumptions.md and documents three critical clusters (Political Gating, Capital Cost, Technical Data Unknowns) but does not systematize how triggering one risk cascades into others or who owns monitoring and response. For example: permit delay (legal) → Indigenous injunction (legal/social) → construction halt (schedule) → lost open-water season (technical) → Phase 1 slip past Month 180 (2041-10-12) (financial) → DSCR breach below 1.2x (financial) → covenant default and restructuring (financial/reputational). The 22 risks reference impact ranges and likelihood but lack explicit cascade mapping, decision owners by risk category, or quantified trigger thresholds for escalation. No formal risk register with ownership, control, review cadence and escalation authority is produced as a gate deliverable.

**Mitigation**: By Month 6 (2027-04-12), Risk Lead: develop a formal risk register mapping all 22 risks into four cascading clusters (Political, Financial, Technical, Regulatory/Social) with cause-effect chains (e.g., ratification slip → financing delay → construction mobilization slip → lost seasons → commissioning delay). Assign a named owner, control action, review cadence (monthly/quarterly), and escalation trigger to each risk. Include explicit risk-interaction matrix (which risks amplify others) and single-point-failure triggers (e.g., single lender withdrawal, single-yard closure). Deliver register with owner sign-off at Gate 1.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because (a) treaty/framework ratification typically takes 12–36 months post-signature but plan allocates only Months 24–30 (2028-10-12 to 2029-04-12)—a 12–36 month slip exceeds the 6–12 month buffer, violating the >20% threshold; (b) NEPA/EIA environmental permitting compressed from baseline 18–24 months to Months 12–18 (2027-10-12 to 2028-04-12)—no expedited-authority or parallel-process precedent cited; (c) design-freeze gate at Month 18 (2028-04-12) is contingent on ice-load data adequacy (±15% confidence, proposed) from 12–18 months of monitoring, but one season is statistically insufficient for 100-year loads, creating an undefined defer-extension risk that cascades to fabrication, tow, and installation schedules.

**Mitigation**: Project Manager & Schedule Lead: Rebuild the critical path by Month 3 (2027-01-12) with documented permit lead times from NOAA, USFWS, Russian environmental agencies and legal counsel, incorporating realistic ratification timelines (12–36 months post-signature, proposed); establish a dated-predecessor network for design freeze (gated on Data Adequacy Committee sign-off, not calendar); set NO-GO thresholds: if ratification slips >12 months beyond Month 24 (2028-10-12) or any permit is not on track by Month 15 (2028-01-12), trigger paid pause and rescope. Within 90 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan specifies a USD 115 billion funding requirement (USD 69 billion debt + USD 46 billion equity, estimate) with no signed debt or equity commitments, no validated revenue case (USD 8.9 billion/yr conservative-case revenue is unsubstantiated at an illustrative USD 100/tonne toll implying ~89 million tonnes/yr), and financing gates defined only as proposed thresholds, not as binding covenants. The plan targets lender heads-of-terms by Month 9 (2027-07-12) and financial close by Month 24 (2028-10-12), but no funding source has been approached by Month 0 (2026-10-12). Debt service coverage ratio thresholds (≥1.5x sizing; <1.2x default) are proposed but not confirmed by any lender. Without signed commitments, validated demand, and committed lender covenants by Gate 1 (Month 6 = 2027-04-12), the entire financing structure remains speculative and carries binary risk: withdrawal of any anchor lender or OFAC denial of sanctions-compatible financing would leave USD 99.5 billion (estimate) unfunded.

**Mitigation**: Finance Lead: Launch formal lender engagement immediately (Month 0 = 2026-10-12), identifying 5–10 target institutions; deliver Information Memorandum and schedule investor roundtable by Month 5 (2027-03-12); secure binding heads-of-terms from 2–3 lead arrangers by Month 9 (2027-07-12) specifying debt amount, tenor, DSCR covenants, and default triggers. Simultaneously, commission independent traffic study and execute take-or-pay pre-sales targeting USD 2.7–4.5 billion/yr by Month 9 (2027-07-12). Make financial close (Month 24 = 2028-10-12) a hard gate with exit provisions; if not achieved by Month 30 (2029-04-12), activate paid pause or abandon.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the USD 100 billion Phase 1 baseline lacks parametric validation by labor category, material unit rates, and Arctic cost premiums. Arctic labor (+30–50%), marine logistics (+50–100%), and contractor risk premiums (15–25%) are proposed but not reflected in binding quotes or unit costs. No Cost Basis Document or Cost Task Force sign-off exists. Overruns of 10–30% (USD 10–30 billion, estimate) exceed the 15% contingency (USD 15 billion), leaving USD 0–15 billion uncovered. Contractor bids will embed 15–25% risk premiums absent a credible baseline. Lenders cannot size debt (USD 69 billion, estimate) on circular assumptions. Per-area benchmarks (USD 3.7–6.0 billion/km for Arctic immersed-tube) suggest baseline may underestimate Arctic uplift or contingency may be inadequate.

**Mitigation**: Cost Engineer: Commission parametric cost model by Month 3 (2027-01-12) from Arctic specialists (HDR, Jacobs, Golder, Hatch); publish Cost Basis Document with line-item labor/material/logistics breakdown and 2–3 contractor sign-offs by Month 6 (2027-04-12). Establish 5% bid-variance gate at Month 12 (2027-10-12); enforce monthly cost tracking and re-forecasting through financial close (Month 24 = 2028-10-12). Within 6 months.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections—Phase 1 tunnel elements (100 planned at 275 m = 27.5 km), Phase 1 commissioning date (Month 180 = 2041-10-12), installation rate (9 elements per season needed), and required annual revenue (USD 8.9 billion)—as single-point estimates without documented range, downside cases, or sensitivity analysis. The tunnel installation-rate projection (9 per season) conflicts with the risk register's own estimate of 3–8 achievable, yet is not resolved in the plan baseline. Required revenue of USD 8.9 billion/yr is reverse-engineered from debt-service requirements, not derived from an independent traffic forecast, leaving demand sensitivity unmeasured. Phase 1 commissioning at Month 180 (2041-10-12) assumes optimistic schedule float absorption and single-spread installation productivity without modeling downside (ratification slip 12–36 months, lost seasons 12 months each, design-freeze delay 3–6 months). Absence of formal sensitivity analysis, downside DSCR cases, or best/worst/base scenarios prevents stakeholders from assessing likelihood of overruns or delays exceeding the 6–12 month float and pushing past the user target.

**Mitigation**: Finance Lead & Cost Engineer: By Month 6 (2027-04-12), deliver a formal sensitivity analysis quantifying Phase 1 commissioning date, DSCR, and debt capacity under three scenarios—conservative (ratification slip 24 months, installation rate 4 elements/season, revenue USD 3 billion/yr), base (ratification slip 12 months, 6 elements/season, revenue USD 5 billion/yr), optimistic (ratification slip 0 months, 9 elements/season, revenue USD 8.9 billion/yr)—with trigger thresholds for scope rebaselining at each gate.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because build-critical components (tunnel elements, piers, cross-passages, fire/life-safety systems, bridge-tunnel interfaces, utility galleries, foundations) lack detailed technical specifications, binding interface contracts, acceptance-test procedures, and validated non-functional requirements before financial close (Month 24 = 2028-10-12). Design envelope is gated on ice/seismic data adequacy at Month 18 (2028-04-12), leaving all detailed specs provisional until that date. Interface-control board governance is conceptual; no binding interface-control documents exist. Acceptance tests are outlined operationally but lack drafted procedures and acceptance criteria. Integration plan exists as work-breakdown structure but lacks detailed hand-off protocols, sequence logic for parallel installation streams, and conflict-resolution procedures across bridge, tunnel, and island contractors operating under two legal systems.

**Mitigation**: Owner's Engineer: Draft preliminary technical specifications for all build-critical components (tunnel cross-section, pier geometry, cross-passage layout, ventilation capacity, utility-gallery segregation, bearing design), preliminary interface-control documents (loads, tolerances, acceptance criteria for bridge-tunnel-island connections), acceptance-test procedures with pass/fail criteria, and detailed integration plan with contractor hand-off protocols and dispute resolution by Month 12 (2027-10-12); finalize all artifacts as financial-close prerequisite by Month 24 (2028-10-12).


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because nine critical legal, financial and operational claims lack verifiable artifacts as of Month 0 (2026-10-12): (1) lender debt commitment (USD 69 billion) — no LOI or heads-of-terms; (2) revenue case (USD 8.9 billion/yr) — no independent traffic study or shipper take-or-pay contracts; (3) sanctions-compliant financing — no written OFAC guidance or pre-approved supplier list; (4) framework agreement — no bilateral text or government signature; (5) Indigenous Beringia Council — no charter or signed MOUs from communities; (6) design-envelope validation — no ice-monitoring data or Data Adequacy Committee certification; (7) cost-basis document — no parametric model or Cost Task Force sign-offs; (8) pilot-element trial success — not yet executed; (9) work-permit protocol — no signed bilateral agreement. Per rubric, absence of verifiable artifacts for critical legal/contract/operational claims is HIGH risk. The plan postpones all evidence acquisition to gates spanning Months 1–24 (2026-11-12 to 2028-10-12), creating binary risk: if any artifact is not delivered on schedule, the gate fails and financial close (Month 24 = 2028-10-12) is in jeopardy.

**Mitigation**: Finance Lead and Owner's Engineer: Establish a Critical Evidence Acquisition Plan by Month 1 (2026-11-12) mapping all nine artifacts to specific gate deliverables with named owners, concrete success criteria (e.g., "lender LOI from 2–3 arrangers signed," "traffic study issued," "OFAC letter received"), and escalation if each is not delivered on time. Conduct monthly evidence-status reviews (Months 1–24 = 2026-11-12 to 2028-10-12) tracking progress toward each artifact; flag any 4-week slip as a schedule/gate risk and escalate within 5 business days. Within 30 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because Phase 1 "rail-and-utility immersed tunnel" lacks specific, verifiable acceptance criteria. The plan specifies 20–36 km length, 80–120 tunnel elements, fiber-optic and power galleries, but does not define: (1) minimum rail-service level (tonnage capacity, speed, frequency); (2) fiber-bandwidth throughput (Tbps, redundancy); (3) power-interconnection capacity (MW, voltage, availability); (4) structural acceptance tolerances (settlement limits, joint performance, ice-load responses post-commissioning); (5) operational readiness (safety certification, regulator sign-off criteria); (6) revenue-earning threshold (minimum tariff acceptance, shipper sign-off). Without quantified acceptance criteria and a single KPI per service line (rail tonnage/year, fiber availability %, power uptime %), lenders cannot assess phase-completion success and release tranches. Current deliverable definition is architectural, not operational or financial."

**Mitigation**: Owner's Engineer & Finance Lead: By Month 12 (2027-10-12), define SMART acceptance criteria for Phase 1 "rail-and-utility tunnel" covering: (1) Rail: capacity 12–18 million tonnes/year, speed 60+ km/h, service availability 95%+ per lender covenant; (2) Fiber: 2–4 Tbps through-put, 99.9% monthly availability, at least two geographically diverse landing points; (3) Power: 500–1000 MW interconnection capacity, 99.5% monthly availability, emergency-load override; (4) Tunnel structural: foundation settlement <0.2 m over first 5 years, zero ice-damage incidents exceeding annual contingency budget, emergency-egress response time <15 min any point; (5) Financial readiness: toll collection operable, at least three named shipper customers with signed take-or-pay contracts, regulatory certification from USCG and Russian authorities. Lock criteria before detailed design freeze at Month 18 (2028-04-12)."


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because two Phase 1 components—the observational design approach (12-18 months of ice/seismic monitoring before design freeze) and the segregated utility galleries (fiber-optic and power interconnection in dedicated conduits within the immersed tunnel)—add material cost and schedule complexity (estimated 5-10% capex uplift for monitoring infrastructure and utility-gallery safety systems) without demonstrably supporting the two primary Phase 1 objectives: (1) deliver operational rail capacity, and (2) demonstrate binational cooperation within a gated capital-exposure framework. The observational design defers design freeze from Month 12 (2027-10-12) to Month 18 (2028-04-12), consuming 6 months of the 6-12 month schedule float. The segregated utility galleries add approximately USD 500 million to USD 2 billion in structural/mechanical cost, yet fiber-optic and power services are not contractually pre-sold (only a USD 2.7-4.5 billion/yr target is proposed, not binding). If take-or-pay pre-sales for utilities do not materialize by Month 9 (2027-07-12), utility-gallery cost becomes stranded, as the tunnel cannot generate the revenue to justify the infrastructure cost. Neither monitoring nor utility galleries is a binding requirement of the framework agreement or a stated lender condition; both are internal project choices that inflate Phase 1 cost without contractual revenue backing.

**Mitigation**: Finance Lead and Owner's Engineer: Conduct a Benefit Case Review by Month 9 (2027-07-12) for observational design and utility galleries, producing a one-page case per feature specifying: (1) KPI (e.g., design-confidence level +/-15%, utility revenue USD X/yr), (2) owner (e.g., Data Adequacy Committee, Utility Tenants Task Force), (3) estimated cost (monitoring USD Y, galleries USD Z). If either case cannot defend the cost against Phase 1 primary objectives, defer feature to Phase 2 or project backlog by Gate 2 decision (Month 12 = 2027-10-12).


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Binational Arctic Immersed-Tube Tunnel Systems Engineer & Installation Authority is mission-critical and exceptionally rare. This role owns pilot-element trial success (gate condition; failure costs ~12 months), tunnel-element installation-rate validation (3–8 per season vs. 9 needed; triggers rescope decision at Month 12 = 2027-10-12), and design-freeze certification (Month 18 = 2028-04-12). Globally, only ~5 individuals hold the integrated skill set: immersed-tube element design, Arctic marine operations (ice-class handling, tow dynamics), fabrication-yard leadership, and seismic/ice-load integration. Fehmarnbelt (Denmark) and HZMB (Hong Kong) projects employ the handful of qualified candidates; recruitment is high-cost and faces long lead time. Without this role, pilot trial cannot validate installation feasibility before financial close (Month 24 = 2028-10-12), and Phase 1 commissioning credibility collapses.

**Mitigation**: Infrastructure Talent Manager: conduct global talent-market validation for the Binational Arctic Immersed-Tube Tunnel Systems Engineer & Installation Authority role by Month 3 (2027-01-12). Deliverable: written report naming at least 3 qualified candidates with confirmed availability or binding pre-engagement offers. If fewer than 2 candidates secured by Month 3 (2027-01-12), escalate to Project Director for go/no-go decision on pilot-element trial feasibility by Month 6 (2027-04-12).


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because legal and regulatory feasibility is mapped (NEPA, Russian EIA, MMPA, tribal consultation, framework agreements are named regimes), but three critical prerequisites are unmapped and unvalidated as of Month 0 (2026-10-12): (1) OFAC licensing guidance for the neutral-SPV structure (requested Month 2 = 2026-12-12, expected Month 3 = 2027-01-12, not yet obtained); (2) framework agreement draft text and government preliminary positions (no draft in hand; signature targeted Month 24 = 2028-10-12; ratification uncertain, 12–36 months estimated post-signature); (3) binational Indigenous-Council legal charter and cross-border enforceability (charter not drafted; formation Months 3–6 = 2027-01-12 to 2027-04-12; enforceability unvalidated). Each absence is a potential showstopper: OFAC denial breaks financing; framework-agreement ratification failure strands sunk costs and breaches debt covenants; Indigenous-Council enforceability gaps invite litigation (6–18 months, estimate). Permitting pathway is compressed (Months 6–18 = 2027-04-12 to 2028-04-12) without expedited-authority justification, and marine-mammal permits are gated on design freeze, creating circular dependency with ice/seismic data collection.

**Mitigation**: By Month 6 (2027-04-12), Binational Project Director and specialized counsel must deliver: (1) written OFAC preliminary licensing guidance (request by Month 2 = 2026-12-12); (2) draft framework agreement with government preliminary positions; (3) Beringia Indigenous Council Charter and MOUs from mapped communities with cross-border legal enforceability confirmed; (4) NEPA/EIA scoping memorandum and framework-permit application roadmap; (5) preliminary marine-mammal baseline report and acoustic model. Gate 2 (Month 12 = 2027-10-12) requires FPIC agreements, final framework draft, and preliminary marine permits on track. Gate 4 (Month 24 = 2028-10-12) requires executed framework agreement and final permits. Assign Regulatory Lead with monthly tracking; NO-GO thresholds for OFAC denial, ratification failure, or consent gaps.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan defers operational sustainability to post-Month 180 (2041-10-12) with no credible long-term O&M funding model, revenue hedge against Arctic cost escalation, or technology-refresh strategy over the century-scale design life. Specifically: (1) O&M cost model is sketched (12–15% of annual revenue, ~USD 1.1–1.3 billion/yr estimate) but lacks line-item build-up by category (labor, equipment, permafrost-maintenance cycles); Arctic labor and equipment costs escalate 5–10% annually (estimate), outpacing 2–4% toll-revenue growth if tariffs are indexed to inflation. (2) No dedicated O&M reserve fund governance exists; proposal to allocate 12–15% of surplus to O&M reserve is indicative, not binding in lender covenants. (3) Permafrost thaw and climate-driven settlement (0.5–2.0 m over 100 years, proposed estimate) necessitate major renewal cycles (pier underpinning, bearing replacement, tunnel lining) at ~50-year intervals, costing USD 100–500 million (estimate) per cycle; no funding mechanism or capital-reserve schedule is committed. (4) Technology obsolescence risk is unaddressed: fire/life-safety systems, SCADA controls, and structural-health monitoring will require replacement Months 60–120 (2031-10-12 to 2036-10-12); succession plan for core operations staff (100–150 specialists proposed for construction) is absent. Without explicit O&M reserve covenants, climate-adaptation budgeting, and technology-refresh mechanisms locked in lender term sheets by Month 24 (2028-10-12), operational sustainability is contingent on sustained high toll revenue and benign permafrost behavior—both at material risk.

**Mitigation**: Finance Lead & Owner's Engineer: Finalize a binding Operational Sustainability Plan (OSP) by Month 12 (2027-10-12) for lender review, specifying: (1) O&M cost baseline by category (labor 40–50%, equipment 25–30%, emergency response 10–15%, utilities/lease 10–15%) escalating 5–10% annually; (2) O&M reserve fund architecture: ring-fenced account funded with 12–15% of annual toll and utility revenue starting Month 180 (2041-10-12) operations; target reserve balance USD 500 million–USD 1 billion by Month 120 (2036-10-12) for major renewal cycles; (3) climate-adaptation budget: allocate 0.5–1% of annual operating revenue to permafrost monitoring, thermosyphon/bearing-pad maintenance and 50-year pier-underpinning reserve; (4) technology-refresh roadmap: plan fire/SCADA/SHM replacement Months 60–120 (2031-10-12 to 2036-10-12) at estimated cost USD 100–200 million (estimate); (5) personnel succession plan: establish apprenticeships and cross-training for 100–150 core operations staff, with annual hire targets starting Month 180 (2041-10-12); (6) indexed toll mechanism: tie annual toll adjustments to a published Arctic O&M cost index, ensuring DSCR ≥1.2x survives 5–10% cost escalation. Embed OSP commitments as binding covenants in lender heads-of-terms (Month 9 = 2027-07-12) and financing agreements (Month 24 = 2028-10-12).


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because Phase 1 success depends on three non-waivable hard constraints spanning two sovereignties, all of which are documented as uncertain or partially unresolved at Month 0 (2026-10-12): (1) OFAC sanctions-licensing pathway for neutral SPV and equipment procurement (preliminary guidance requested Month 2 = 2026-12-12, not yet confirmed; written pathways required by Month 6 = 2027-04-12); (2) marine-mammal protection hard limits (incidental-take authorization from NOAA/USFWS and Russian equivalents, gated on 12-month baseline data, with acoustic shutdown zones and seasonal closures that compress an already short open-water season); (3) permafrost and structural-limit constraints tied to 100-year design life under 2–4 °C warming, requiring observational ice/seismic data adequacy confirmation by Month 18 (2028-04-12) before pier-foundation commitment. None of these can be waived. If OFAC denies the SPV structure, financing collapses (binary risk). If marine-mammal data trigger stricter acoustic limits than the proposed 10 km shutdown zone, installation season shrinks from 2.4–2.6 net months to <2 months (estimate), pushing Phase 1 past Month 200 (2043-06-12). If design-freeze data remain inconclusive at Month 18 (2028-04-12), either design freezes under uncertainty (liability risk: USD 50–200 million repairs if loads exceed design) or observational period extends, consuming all 6–12 month float and cascading Phase 1 commissioning. All three gating uncertainties are unresolved as of Month 0 (2026-10-12), leaving Phase 1 feasibility dependent on favorable regulatory outcomes outside project control.

**Mitigation**: Project Director: establish a Constraints Validation Task Force by Month 1 (2026-11-12) comprising OFAC counsel, marine-mammal regulatory specialists (NOAA, USFWS, Russian Federal Agency for Fisheries), and Arctic geotechnical engineers. Task Force must deliver: (1) by Month 3 (2027-01-12), written preliminary positions from each authority on licensability, permit scope and data sufficiency; (2) by Month 6 (2027-04-12), binding written OFAC guidance and pre-approved supplier list, preliminary ITA framework and baseline-data adequacy assessment; (3) fatal-flaw screen identifying any non-waivable constraint that cannot be satisfied by design or mitigation, with explicit NO-GO thresholds (e.g., "ITA issuance not on track by Month 12 = 2027-10-12 triggers paid pause at Gate 2"). Schedule two fallback designs: Alternative A (vibratory/drilled foundations instead of impact piling, +USD 2–5 billion cost estimate) if acoustic limits tighten; Alternative B (Phase 1 scope reduction to 60–70 tunnel elements, pushing commissioning to Month 150–160 = 2040-01-12 to 2040-08-12 estimate) if installation-season compression exceeds 20% (estimate). Within 30 days, identify and document the single non-waivable constraint that, if unmet by Month 24 (2028-10-12), forces project abandonment or major rescope, and assign a named owner to track it monthly through financial close.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan stages capital deployment through explicit gates (Months 6, 12, 18, 24 = 2027-04-12 to 2028-10-12) with paid-pause and exit provisions, reducing pre-gate sunk cost to USD 150 million and enabling cascade-risk absorption if single-point dependencies fail. However, material gaps in tested resilience remain: (1) no secondary tow-vessel fallback if primary ice-class fleet is lost (loss = ~12-month delay estimate in a 4-month season); (2) no contingency path if OFAC denies neutral-SPV licensing (Month 6 = 2027-04-12 gate, binary kill-switch risk); (3) no secondary regulatory pathway if US or Russian permit authority tightens marine-mammal or environmental limits; (4) no backup lender syndication if lead arrangers withdraw at Month 9 (2027-07-12) heads-of-terms gate. Gating preserves optionality and caps pre-construction exposure, but single-point-failure dependencies at Gates 1–4 lack concrete secondary paths. One lost open-water season (ice-season failure, vessel breakdown, permitting delay) cascades to ~12-month installation slip, pushing Phase 1 commissioning past the Month 180 (2041-10-12) target.

**Mitigation**: Infrastructure Resilience Lead: By Month 6 (2027-04-12), establish a Vendor Resilience Plan documenting: (1) secondary tow-vessel availability (identify 2–3 backup ice-class vessels on standby, negotiate frame rates and 2-week mobilization terms); (2) backup lender syndication (identify 2–3 secondary arrangers with USD 10–20 billion commitments as fallback if primary lead arrangers withdraw); (3) OFAC contingency (develop alternative SPV jurisdiction and financing vehicle if neutral-entity licensing is denied); (4) dual-source fabrication and installation (confirm 2+ yards with 5+ elements/yr capacity on parallel contracts); (5) regulatory fallback (pre-draft alternative design scenarios if marine-mammal or environmental permits tighten). Test each fallback by Month 18 (2028-04-12) through binding letters of intent from secondary vendors and formal gate contingency protocols.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because Finance and Engineering hold materially conflicting incentives over design-freeze timing, observational data confidence, and procurement urgency. Finance prioritizes lender head-of-terms signature (Month 9 = 2027-07-12) and financial close (Month 24 = 2028-10-12) to minimize carry cost; Engineering demands ice/seismic data adequacy (±15% confidence) and pilot-element trial validation before design lock and major expenditure. This conflict is unstated in the plan: no shared OKR bridges the two incentive systems. The plan implicitly favors Finance timing (design freeze Month 18 = 2028-04-12, financial close Month 24 = 2028-10-12) but leaves Engineering's data-adequacy gate undefined (triggers 3–6 month defer if data are inconclusive, per Risk 3 pre-mortem). One lost open-water season (ice-season failure, delayed monitoring, pilot redesign) cascades into 12-month installation slip, breaching Phase 1 commissioning schedule and DSCR covenant compliance. This gap is material: no joint Finance-Engineering KPI exists that both parties are accountable for achieving; success remains bifurcated (Finance: DSCR and close date; Engineering: design confidence and pilot success) rather than unified.

**Mitigation**: Finance Lead and Owner's Engineer: Co-author and jointly commit to a single, measurable OKR by Month 6 (2027-04-12) that aligns Finance and Engineering incentives on Phase 1 gating. OKR: "Achieve design freeze with validated cost, schedule, and risk margin such that Phase 1 commissioning target (Month 180 = 2041-10-12) remains achievable at >70% probability with DSCR ≥1.5x under conservative case revenue (USD 2–3 billion/yr downside), and debt service is covered by contracted (take-or-pay) plus forecasted (traffic) revenue in a 70:30 ratio." Assign joint ownership: Finance Lead owns DSCR certification and revenue certainty; Owner's Engineer owns design-freeze data adequacy and cost validation. Measure success at each gate: Gate 1 (Month 6 = 2027-04-12): preliminary cost-basis document sign-off by Cost Task Force; preliminary lender appetite (≥USD 20 billion debt interest); preliminary traffic study. Gate 2 (Month 12 = 2027-10-12): binding heads of terms; signed take-or-pay contracts (≥30% revenue, USD 2.7 billion/yr); pilot element trial complete; bids within 5% of baseline. Gate 3 (Month 18 = 2028-04-12): design-freeze certification (ice-load confidence ±15%); revised Phase 1 commissioning date (Month 150–210 = 2040-01-12 to 2044-04-12 range, confirmed); financial-close readiness. Governance: monthly joint Finance-Engineering steering review (Months 1–24 = 2026-11-12 to 2028-10-12) tracking both DSCR and design-confidence KPIs; NO-GO thresholds: if DSCR projects <1.2x or design-freeze data remain inconclusive at Month 18 (2028-04-12), joint decision to extend paid pause (Months 18–24 = 2028-04-12 to 2028-10-12) or rescope Phase 1. This OKR converts the latent conflict into explicit accountability and ensures neither Finance nor Engineering can optimize alone at the other's cost.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan establishes gate milestones (Months 6, 12, 18, 24 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12) with tied decisions and monthly steering-committee reviews, plus cost tracking and DSCR covenant targets. However, critical feedback-loop infrastructure is missing or underspecified: no formal KPI dashboard with automated alerts, no operationalized change-control board with decision authority and escalation timelines, no mid-construction (Months 30–180 = 2029-04-12 to 2041-10-12) monitoring and course-correction triggers, and no post-commissioning (O&M reserve, toll indexation) feedback mechanisms tied to measurable thresholds. The plan states "monthly reforecasting" and "quarterly sanctions monitoring" but does not define which metrics trigger escalation, who owns each metric, or what STOP/RE-PLAN thresholds apply. Vague monthly reviews are insufficient for a 180-month program; without automated dashboards and formalized change-control authority, cost and schedule variance will accumulate undetected until gate deadlines.

**Mitigation**: Project Controls Lead: Design and implement by Month 6 (2027-04-12) a formal Feedback and Control System comprising: (a) KPI Dashboard (monthly earned-value cost/schedule variance, DSCR projection, installation rate, risk-register heat map, permit-milestone tracking) with automated escalation if variance exceeds ±5%; (b) Change-Control Board (Owner, Finance Lead, Cost Engineer, representatives from top three contractors) meeting bi-weekly with 2-week decision turnaround and binding authority up to USD 50 million; (c) Escalation Thresholds (reforecast if cumulative cost >5%, rescope if >10%, exit decision if >15% or DSCR falls below 1.3x); (d) Post-commissioning review cadence (quarterly O&M cost variance, annual toll-indexation adjustment review, 5-year climate-adaptation audit). Embed dashboards and change-control authority in lender covenants at financial close.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies 22 discrete risks across political, financial, technical, and regulatory domains but does not map their interdependencies, common-mode failures, or cascading impact chains. The plan flags three critical risk clusters (political gating, capital cost, technical data unknowns) but does not model how simultaneous or sequential breaches trigger multi-domain failure. For example: ratification slip of 12–36 months (estimate) plus design-freeze delay of 3–6 months plus one lost open-water season (12 months each estimate) combine to push Phase 1 commissioning from Month 180 (2041-10-12) to Month 210+ (2044-04-12+, estimate), consuming all schedule float and breaching DSCR covenant (<1.2x trigger). A second example: sanctions-licensing restriction (Month 6–18 = 2027-04-12 to 2028-04-12) cascades into equipment sourcing delay (6–12 months estimate), missing tow windows, reduced installation rate (3–4 elements/season vs. 9 needed), and Phase 1 slip. The plan's risk register treats each risk in isolation; no bow-tie, fault-tree, or cross-impact matrix surfaces these coupling chains.

**Mitigation**: Risk Lead: Develop a formal Risk Interaction and Cascade Map by Month 6 (2027-04-12) using bow-tie or fault-tree analysis identifying: (1) common-mode-failure clusters (political withdrawal triggers financing withdrawal and Indigenous opposition simultaneously); (2) three-node cascades (e.g., ratification slip → financing delay → lost tow season → Phase 1 slip); (3) single-point-of-failure dependencies (e.g., one lender withdrawal, OFAC denial, pilot-element failure). Map combined DSCR and commissioning impact; define NO-GO thresholds (e.g., combined slip >24 months triggers Phase 1 rescope). Assign ownership and quarterly review cadence.