## 1. Lender Engagement, Financing Structure and Debt Capacity Validation

Lender commitment is binary and outside project control once financing structure and revenue assumptions are locked. Without heads-of-terms by Month 9 (2027-07-12) and financial close by Month 24 (2028-10-12), construction cannot mobilize and sunk costs of USD 50–150 million (estimate) are stranded. Sanctions licensing is the critical path item: OFAC denial or restriction of key suppliers/lenders in Month 12–18 (2027-10-12 to 2028-04-12) cascades into 6–12 month delays or project suspension. Independent traffic study and shipper pre-sales (30–50% take-or-pay target) anchor debt sizing; lenders will not commit without credible demand proof.

### Data to Collect

- Binding heads-of-terms or term sheets from 2–3 lead arrangers (debt amount, tenor, pricing, covenants, conditions precedent)
- Written OFAC preliminary licensing guidance confirming sanctions-compliant financing vehicle structure and approved lender nationalities
- Independent traffic and tariff study with shipper demand quantification and take-or-pay pre-sales commitments (target 30–50% revenue, USD 2.7–4.5 billion/yr)
- Preliminary lender letters of interest or term-sheet outlines from 4–6 target institutions confirming appetite and term expectations
- Financing-risk stress cases: downside revenue scenarios (20%, 40%, 60% shortfall) and corresponding DSCR and debt-capacity implications

### Simulation Steps

- Use a financial-modeling platform (Excel, Anaplan, Hyperion) to build a DCF model with conservative, base and upside revenue scenarios; stress DSCR against tariff elasticity (±15–25% price sensitivity) and traffic volume downside (–20%, –40%, –60%); publish downside DSCR curves for lender review
- Deploy a debt-sizing calculator linking conservative-case revenue to maximum sustainable debt under DSCR ≥1.5x covenant; model what revenue shortfall triggers covenant breach (DSCR <1.2x) and required corrective actions (toll increase, scope reduction, equity injection)
- Run a lender-capacity survey using industry contacts or databases (Project Finance Magazine, Dealogic, Bloomberg): identify development banks, export-credit agencies and infrastructure funds with Arctic or sanctions-exposure experience; model their stated lending appetite for megaprojects (typical USD 1–5 billion per institution); aggregate to confirm USD 69 billion debt capacity is achievable with 3–5 lead arrangers
- Compile a Financing Structure Scorecard (sanctions exposure, debt tenor, covenant structure, pricing) comparing neutral-SPV ownership models (Swiss, Canadian, supranational) against direct ownership; use it to validate which structure OFAC is likely to approve

### Expert Validation Steps

- Engage a mandated arranger or financial advisor (e.g., SMBC, IJ Global, Moodys Analytics) to conduct one-on-one pre-engagement meetings with 8–12 target lenders (Month 1–2 = 2026-11-12 to 2026-12-12) and gather preliminary non-binding feedback on appetite, pricing expectations and conditions precedent
- Retain OFAC-licensed export-control counsel (Month 0 = 2026-10-12) to conduct preliminary licensing assessment; submit formal OFAC and BIS licensing request (Month 2–3 = 2026-12-12 to 2027-01-12); obtain written preliminary guidance (Month 6 = 2027-04-12) confirming licensable financing-vehicle structures
- Commission independent traffic and demand study from Arctic shipping specialist (DNV GL, Stena advisors, Arctic Council observer) (Month 0–3 = 2026-10-12 to 2027-01-12); peer-review findings with shipper industry body (Arctic Council, Inuit Tapiriit Kanatami trade committee, Russian Arctic Commission) by Month 6 (2027-04-12)
- Host formal investor roundtable (Month 4–5 = 2027-02-12 to 2027-03-12) with 8–12 target lenders presenting preliminary IM, cost basis, revenue case and term-sheet outline; solicit written feedback on lender appetite, pricing and term preferences; synthesize feedback into revised deal structure by Month 6 (2027-04-12)

### Responsible Parties

- Finance Lead / CFO (project sponsor appointed Month 0 = 2026-10-12)
- Mandated arranger / financial advisor (SMBC, IJ Global, equivalent)
- Export-control counsel (specialized law firm with OFAC relationships)
- Traffic and demand consultant (Arctic shipping specialist)
- Lender representatives (8–12 target institutions)

### Assumptions

- **High:** Lender appetite for a USD 69 billion Arctic megaproject exists; 3–5 lead arrangers collectively have capacity to fund debt tranche within 24 months (2026–2028).
- **High:** OFAC will provide written preliminary licensing guidance by Month 6 (2027-04-12) confirming that a neutral third-country SPV with US and Russian government contractual rights is licensable for financing and equipment sourcing.
- **High:** Independent traffic study will show demand for Phase 1 (rail-and-utility tunnel) of at least USD 2 billion/yr revenue, anchoring debt capacity at USD 20–30 billion (estimate) from traffic alone; take-or-pay pre-sales will add USD 2.7–4.5 billion/yr to reach USD 8.9 billion/yr target.
- **Medium:** Conservative-case DSCR of 1.5x is acceptable to lenders; if actual revenue falls 20–40% below conservative case, DSCR remains ≥1.2x (default trigger), preserving covenant compliance.
- **High:** No single lender entity will be excluded by sanctions or export controls from participating in the financing; if one lender withdraws, 3–5 backup arrangers are available to replace them without material pricing or term changes.

### SMART Validation Objective

By Month 9 (2027-07-12), obtain binding heads of terms from 2–3 lead arrangers specifying debt amount (USD 69 billion ±10%, estimate), tenor (30 years ±2), pricing (5.5% placeholder +/– lender risk premium), and DSCR covenant (≥1.5x, default <1.2x); confirm written OFAC licensing pathway; and execute take-or-pay pre-sales totaling ≥USD 1.5 billion/yr (17% of USD 8.9 billion target). If any of these are not achieved by Month 9 (2027-07-12), trigger Gate 2 (Month 12 = 2027-10-12) paid-pause review.

### Notes

- Financing close is the single largest gating risk; lender withdrawal or sanctions denial (Month 12–18 = 2027-10-12 to 2028-04-12) cascades into 6–12 month program delay and USD 50–150 million stranded cost.
- Revenue underwriting failure (traffic <USD 2 billion/yr) reduces debt capacity by 50–75%; requires scope reduction or government availability-payment backstop, both politically contentious.
- Sanctions licensing uncertainty is unresolvable until OFAC provides written guidance; preliminary licensing request must be submitted by Month 2 (2026-12-12) to meet Month 6 (2027-04-12) Gate 1 deadline.
- Traffic study timeline is aggressive (Month 0–6 = 2026-10-12 to 2027-04-12); shipper engagement must start Month 1 (2026-11-12) to achieve pre-sales commitments by Month 9 (2027-07-12).
- No lender has been identified or pre-engaged; immediate action (Month 0 = 2026-10-12) to appoint Finance Lead and mandated arranger is critical path item.


## 2. Arctic Parametric Cost Estimate Validation and Unit-Rate Confirmation

Cost estimate of USD 80–120 billion (planning midpoint USD 100 billion) is unvalidated and will inflate via contractor risk premiums (15–25%, estimate) if unit rates are not proven. Lenders will not issue heads-of-terms without a credible Cost Basis Document; contractors will embed conservative risk premiums (USD 10–30 billion estimate) if baseline is opaque. Monthly cost reforecasting starting Month 6 (2027-04-12) enables early warning of cost trends that exceed lender comfort or trigger covenant risk; establishing a 5% bid-variance gate at Month 12 (2027-10-12) preserves owner authority to reprove or rescope before financial close.

### Data to Collect

- Detailed parametric cost model disaggregated by labor (trades, engineers, support staff at Arctic regional rates +30–50% premium), materials (steel $/tonne, concrete $/m³, specialty Arctic components), marine logistics (ice-class vessel charter USD 500k–1.5M/day, tow operations, fuel, insurance), and site facilities
- Regional cost indices and productivity assumptions (Arctic labor productivity 60–70% of temperate baseline for piling/foundation; 80–90% for steel/tunnel work)
- Cost Task Force validation: contractor and supplier sign-off on unit rates and escalation caps
- Cost Basis Document published for lender and bid-process review with explicit assumptions and sensitivity analysis
- Monthly cost reforecasting and variance tracking (starting Month 6 = 2027-04-12) with 5% bid-variance gate triggering re-baselining

### Simulation Steps

- Build a parametric cost spreadsheet (Excel or dedicated tool) with cost line-items covering labor (hourly rates by trade, benefits, overhead 30–50% regional premium), materials (pricing from 3+ suppliers per material type), marine logistics (vessel rates from recent Arctic tenders; daily costs × days × vessels), site facilities (camp, port infrastructure) and regional indices (Alaska/Chukotka cost adjustment). Model cost sensitivities: if labor rates go +10%, materials +5%, logistics +15% (estimated ranges), what is total cost increase? Create a downside (high-cost) case and upside (low-cost) case.
- Benchmark parametric unit rates against comparable Arctic projects (Fehmarnbelt immersed-tube fabrication and installation, Hong Kong-Zhuhai-Macau Bridge tunneling, Northern Sea Route infrastructure, Alaska oil/gas megaprojects); extract $/element, $/tonne steel, $/m³ concrete for immersed-tube construction and scale to Bering Strait context.
- Run a productivity-assumption test: model piling and foundation work at 60–70% of temperate baseline (weather delays, permafrost treatment, ice management); model tunnel-element fabrication at 80–90% baseline (Arctic material sourcing lead times, labor experience curve); validate against historical Arctic marine-construction performance data.
- Create a contingency-allocation matrix: separate 12–15% contingency (USD 15 billion) from baseline (USD 100 billion); allocate contingency by risk category (ice loads 3%, seismic 2%, permafrost 2%, labor turnover 2%, schedule slip 2%, regulatory/permitting 2%, other 2%) to identify where contingency is most exposed and trigger early warning if a category begins to consume reserves.

### Expert Validation Steps

- Engage Arctic construction specialists (HDR, Jacobs, Golder, Hatch, equivalent) to develop parametric cost model (Months 0–3 = 2026-10-12 to 2027-01-12); deliver draft Cost Basis Document by Month 3 (2027-01-12) for Cost Task Force review.
- Convene a Cost Task Force (Month 3–6 = 2027-01-12 to 2027-04-12) with 2–3 candidate lead contractors (major Arctic/offshore firms), 2–3 material suppliers (steel mills, concrete yards, tunnel-liner fabricators), and 1–2 marine-logistics providers (ice-class vessel operators, tow contractors); have Cost Task Force review unit rates, challenge productivity assumptions, and sign-off on Cost Basis Document by Month 6 (2027-04-12).
- Submit Cost Basis Document to independent cost auditor (e.g., independent cost engineer or specialist firm unrelated to project team) for peer review (Month 6 = 2027-04-12); resolve any discrepancies or outliers with documented justification.
- Brief lenders on Cost Basis Document findings (Month 6 = 2027-04-12) and confirm it is acceptable as the parametric baseline for bid comparisons and contractor pricing; obtain lender written confirmation that cost estimate is credible enough to proceed to heads-of-terms negotiation.
- Retain Owner's Cost Engineer (starting Month 6 = 2027-04-12) to conduct monthly cost tracking, gather actual bid prices, compare to parametric baseline by cost category, and produce monthly variance reports with escalation flags if cumulative overrun >5% (Month 12 = 2027-10-12 gate) or >10% (Month 24 = 2028-10-12 gate).

### Responsible Parties

- Cost Lead / Finance (project sponsor)
- Arctic construction specialists (HDR, Jacobs, Golder, Hatch, equivalent)
- Cost Task Force members (lead contractors, suppliers, logistics providers)
- Independent cost auditor (peer review)
- Owner's Cost Engineer (Month 6+ ongoing)

### Assumptions

- **High:** Parametric cost model built from validated Arctic construction data (labor rates, material indices, productivity baselines) will be within ±15% of actual contractor bids when solicited at Month 12–18 (2027-10-12 to 2028-04-12).
- **Medium:** Regional labor cost premiums for Alaska and Chukotka are 30–50% above southern US/Russian baseline; marine-logistics premiums are 50–100%; these premiums can be validated against current regional wage surveys and recent ice-class vessel rates.
- **Medium:** Arctic construction productivity (60–70% of temperate baseline for piling/foundation, 80–90% for tunnel work) reflects historical performance from comparable projects (Fehmarnbelt, HZMB, Arctic LNG, trans-Alaska pipeline); productivity will not degrade further due to labor turnover, permafrost surprises or ice-condition changes.
- **High:** Contingency pool (USD 15 billion = 15% of baseline) is sufficient to cover 5–10% bid overruns across the project; overruns beyond 10% trigger scope reduction or schedule extension, not contingency depletion.
- **Medium:** 2–3 candidate lead contractors will participate in Cost Task Force validation and will accept Cost Basis Document as a reference for their own bid preparation; if contractors reject unit rates as unrealistic, Cost Basis Document must be revised or contractor risk premiums will inflate bids by 15–25%.

### SMART Validation Objective

By Month 6 (2027-04-12), publish a Cost Basis Document with line-item build-up of USD 100 billion baseline disaggregated by labor (+30–50% regional premium), materials (steel, concrete, specialty items at ±5% accuracy to current-year supplier quotes), marine logistics (vessel charter USD 500k–1.5M/day validated against market), and site facilities; achieve Cost Task Force sign-off confirming unit rates are credible and productivity assumptions align with Arctic precedents (±10% tolerance). By Month 12 (2027-10-12), conduct first cost reforecast against early bids; if bids exceed parametric baseline by >5%, trigger design/scope review and repricing; maintain bid-variance gate at 5% through financial close (Month 24 = 2028-10-12).

### Notes

- Cost credibility is a lender gate at Month 6 (2027-04-12); without Cost Basis Document, lenders will demand 15–25% risk premiums (USD 15–30 billion estimate) on top of baseline or will refuse to commit.
- Parametric model must include Arctic-specific line items: permafrost remediation (thermosyphons, ground freezing, overexcavation), ice-impact design loads (reinforcement costs), specialized fabrication yards (startup costs), Arctic labor availability and turnover (training, rotation premium).
- Cost Task Force validation is critical: if contractors signal skepticism about unit rates, Cost Basis Document loses lender confidence; ensure task force participation is formalized early (Month 3 = 2027-01-12) to allow 3-month validation window (Months 3–6 = 2027-01-12 to 2027-04-12).
- Monthly cost tracking (Month 6+ = 2027-04-12 onwards) requires a dedicated Owner's Cost Engineer with direct reporting to project director and lenders; variance reporting must be transparent and trigger escalation at ±5% gate.
- Contingency management is separate from baseline; do not allow contingency to become a hidden cost buffer; document every contingency draw and obtain steering-committee approval before expenditure.


## 3. Ice-Load, Seismic and Permafrost Design-Envelope Data Validation

Ice-load and seismic-permafrost interaction are site-specific and have high epistemic uncertainty in the Bering Strait (limited historical data, climate-change regime shift). A one-season pilot observation (Month 0–12 = 2026-10-12 to 2027-10-12) is statistically insufficient to define 50-, 100-, 500-year return-period loads; proceeding with design freeze at Month 18 (2028-04-12) without adequate confidence risks USD 50–200 million (estimate) in post-construction repairs if actual loads exceed design or overdesign by USD 5–15 billion if conservative margins are applied without data confidence. Observational design approach (design refinement based on monitoring) preserves optionality: if data are conclusive within ±15% by Month 18 (2028-04-12), freeze design and proceed; if not, extend monitoring and design-freeze by 3–6 months rather than betting on uncertain loads.

### Data to Collect

- 12–18 months of Bering Strait ice-regime monitoring data (drifting buoys, shore-based radar, satellite imagery, pilot instrumentation on prototype pier models) quantifying floe velocity, thickness, ridge-height and impact-pressure distributions
- Seismic return-period analysis (50-, 100-, 500-year earthquake scenarios) with ground-response modeling incorporating permafrost thaw and liquefaction risk; validation against regional seismic catalogs and USGS/Russian earthquake data
- Permafrost baseline survey (core drilling, laboratory testing, in-situ sensors) documenting ground-ice content, thaw rates and bearing-capacity changes over 100-year design life; climate-change warming scenarios (2–4°C) incorporated into settlement models
- Design-freeze confirmation: ice-load confidence within ±15% (proposed threshold), seismic return-period loads validated, permafrost settlement models reconciled with field data; design envelope locked by Month 18 (2028-04-12)
- Foundation design flexibility: 10–20% reserve capacity specified to allow post-monitoring load upgrades without full rework; sacrificial ice-deflection structures and bearing designs specified to accommodate predicted settlements

### Simulation Steps

- Deploy ice-monitoring campaign (Month 0–18 = 2026-10-12 to 2028-04-12): launch 4–6 drifting buoys across the Bering Strait recording floe velocity and ice thickness; establish shore-based radar stations at Wales and Uelen measuring ice-floe position and speed; conduct passive acoustic monitoring to detect floe-impact events; process real-time data to build statistical distributions of floe size, speed and pressure. Parallel simulation: use published Arctic ice-mechanics models (e.g., Cryosat satellite data, historical ice charts 1985–2025, Arctic Council research) to project worst-case floe scenarios (mega-ridges, multi-year ice collisions) and validate against observed data.
- Conduct seismic finite-element analysis (Months 3–15 = 2027-01-12 to 2028-01-12) using site-specific ground-motion parameters (Mw 6–8 earthquake scenarios, spectral accelerations appropriate to Aleutian subduction zone and Arctic rifting); couple seismic loads with permafrost thaw (model liquefaction risk in saturated silts, ground-ice melting reducing bearing capacity); run deterministic analyses at 50-, 100-, 500-year return periods and probabilistic seismic hazard analysis (PSHA); output design-basis accelerations and settlement displacements for pier and foundation design.
- Geotechnical investigation and modeling (Months 0–12 = 2026-10-12 to 2027-10-12): core drilling at 8–12 proposed foundation locations, laboratory testing (shear strength, consolidation, permafrost ice-content, thaw rate), in-situ testing (SPT, CPT, vane shear). Model bearing capacity and settlement under combined ice-load, seismic and permafrost-thaw scenarios using coupled finite-element analysis (FLAC, PLAXIS); generate settlement predictions at each pier location for 0–100 year horizons under 2–4°C warming scenarios.
- Design-envelope simulation: run numerical models of candidate pier and foundation designs (assume 2–3 alternative designs for testing) under combined worst-case ice and seismic loads at various return periods (50-, 100-, 500-year); identify which design envelope (loads and safety factors) is most cost-effective and still meets the ±15% confidence threshold (proposed). Output a design-basis document specifying accepted loads, safety factors, settlement tolerances and adaptive-upgrade criteria.

### Expert Validation Steps

- Engage Arctic ice-mechanics research institutions (University of Alaska Fairbanks geophysical Institute, Canadian ice-research centers, Norwegian Arctic research bodies) by Month 0 (2026-10-12) to validate ice-monitoring methods and co-publish ice-regime baseline by Month 6 (2027-04-12).
- Commission seismic hazard assessment from USGS or equivalent Arctic seismic specialist (Month 0–6 = 2026-10-12 to 2027-04-12); obtain final site-specific ground-motion parameters and design-basis earthquake scenario by Month 6 (2027-04-12).
- Retain independent geotechnical engineer or foundation specialist (e.g., Golder, Jacobs, BGC Engineering) to review drilling results and permafrost models (Month 12 = 2027-10-12); peer-review settlement and bearing-capacity predictions; confirm that 10–20% design flexibility is adequate to accommodate data-driven adjustments without major redesign.
- Establish a Data Adequacy Committee (Owner's Engineer, independent design reviewer, ice-mechanics expert, geotechnical specialist, foundation engineer) to convene at Month 18 (2028-04-12) and certify whether 12–18 months of monitoring data support a design-freeze decision: confirm ice-load confidence ±15%, seismic return-period loads validated, permafrost settlements quantified within ±0.2 m tolerance. If data are inconclusive at Month 18 (2028-04-12), recommend design-freeze extension by 3–6 months and expanded monitoring (one additional ice season, expanded borehole program).
- Design-freeze review (Month 18 = 2028-04-12): present finalized design envelope (loads, safety factors, settlement models, adaptive-upgrade triggers) to lenders, regulators (USCG, Russian classification society) and government stakeholders; obtain written sign-off confirming design is acceptable and meets permit requirements before proceeding to detailed design and financial close.

### Responsible Parties

- Owner's Engineer (design integration and data adequacy committee chair)
- Arctic ice-mechanics researchers (University of Alaska, Canadian/Norwegian research institutes)
- Seismic specialist (USGS or regional equivalent)
- Independent geotechnical engineer (peer review)
- Foundation specialist (design validation)
- Data Adequacy Committee (Month 18 = 2028-04-12 certification)

### Assumptions

- **High:** 12–18 months of ice-regime monitoring (4–6 buoys, shore radar, pilot pier instrumentation) will capture worst-case floe-impact scenarios and quantify return-period load envelopes to ±15% confidence for 50-, 100-, 500-year events.
- **Medium:** Historical Bering Strait ice data (satellite imagery 1985–2025, Arctic Council databases) plus pilot-season observations will be adequate to calibrate numerical ice-mechanics models; one additional ice season (if needed) will refine models to ±10% accuracy.
- **Medium:** Seismic return-period analysis using regional earthquake catalogs and PSHA methods (USGS guidelines) will yield design-basis ground motions that, when coupled with permafrost thaw modeling, give foundation designs acceptable to lenders and regulators without additional conservatism beyond standard safety factors.
- **Medium:** Permafrost thaw rates under 2–4°C warming scenarios (per IPCC models) can be modeled reliably using site-specific ground-temperature data, ice-content measurements and thermal-conductivity inputs; settlement predictions will be within ±0.2 m over 100-year design life.
- **Medium:** 10–20% design flexibility (foundation reserve capacity, adjustable bearing pads, thermosyphon upgrading) is sufficient to accommodate post-construction load changes or settlement rate increases without major retrofits; additional design margins beyond this reserve will trigger redesign and cost overrun gates.

### SMART Validation Objective

By Month 12 (2027-10-12), complete first-season ice monitoring (4–6 months of buoy, radar and pilot instrumentation data); by Month 18 (2028-04-12), conduct Data Adequacy Committee review confirming ice-load confidence within ±15% (50-, 100-, 500-year return periods quantified), seismic return-period analysis completed and validated by USGS, and permafrost settlement models reconciled with field-boring data (tolerance ±0.2 m). If data adequacy is certified, lock design freeze and proceed to detailed design and financial close. If data remain inconclusive at Month 18 (2028-04-12), recommend design-freeze extension by 3–6 months and one additional ice-season monitoring; trigger paid pause (Month 18–24 = 2028-04-12 to 2028-10-12) to absorb monitoring extension without cascading into construction schedule.

### Notes

- Ice-regime monitoring must start Month 0 (2026-10-12) to capture the 2026–2027 winter season (Oct 2026–May 2027) and 2027 spring/summer (Jun–Sep 2027); one season of data is minimum; two seasons (Oct 2026–Sep 2027) is preferred for return-period quantification.
- Pilot instrumentation on prototype pier models (proposed Month 6–12 = 2027-04-12 to 2027-10-12 deployment near Little Diomede in shallow water) is critical for validating ice-impact load predictions; recommend placing 2–3 instrumented test piles at different depths/orientations to capture variability.
- Permafrost baseline drilling is time-sensitive: optimal drilling season is May–October (thawed surface); plan drilling campaign for Months 3–9 (2027-01-12 to 2027-07-12) to ensure samples are representative and lab testing is complete by Month 12 (2027-10-12).
- Seismic hazard analysis should include magnitude-frequency and rupture-distance uncertainties; output should be a hazard-disaggregation diagram showing which earthquake scenarios dominate the design loads (e.g., frequent small earthquakes vs. rare large earthquakes) to inform design trade-offs.
- Design-envelope finalization (Month 18 = 2028-04-12) must include written certification from Data Adequacy Committee, independent design reviewer and applicable regulators (USCG, Russian classification society) confirming that design loads and safety factors are acceptable; without this, design freeze is not credible and lenders will not commit to heads of terms.


## 4. Indigenous Consent Framework and Beringia Indigenous Council Establishment with Binding Authority

Indigenous consent is a legal gate in both US (trust responsibility, NEPA consultation, treaty rights) and Russian (indigenous peoples' rights statutes) jurisdictions; unresolved claims can trigger 6–18 month injunctions and USD 5–20 million litigation costs (estimate). A Beringia Indigenous Council with binding decision authority over work windows and alignment changes reduces downstream injunction risk and builds social license for operations. Benefit-sharing (1–2% revenue or USD 10–30 million/yr) and Indigenous workforce participation (20–30% of Phase 1) are non-negotiable expectations and improve legitimacy with regulators and lenders. FPIC agreements signed by all mapped communities by Month 12 (2027-10-12) are an explicit Gate 2 deliverable; without them, design freeze (Month 18 = 2028-04-12) cannot proceed.

### Data to Collect

- Mapping of all Indigenous communities with subsistence-harvesting rights or regulatory authority over the 85 km alignment and 50+ km approaches (estimated 8–12 primary communities across Alaska and Russia)
- Beringia Indigenous Council legal charter and Memorandum of Understanding specifying binding decision authority (which decisions require full consent vs. advisory), dispute-resolution mechanism and enforcement in both US and Russian legal regimes
- Free, Prior and Informed Consent (FPIC) framework agreements with each mapped community defining informed-consent criteria, benefit-sharing mechanisms (1–2% annual revenue or USD 10–30 million/yr), Indigenous workforce targets (20–30% of Phase 1 labor) and observer participation on marine works
- Baseline environmental and social documentation: Indigenous land-use mapping, traditional-harvesting data, subsistence-species impact assessments, benefit-fund governance and management protocols
- Written consent agreements from all 8–12 mapped communities authorizing design freeze and construction start; designate as explicit Gate 2 (Month 12 = 2027-10-12) deliverable

### Simulation Steps

- Use ArcGIS or equivalent mapping tool to spatially represent Indigenous communities, subsistence-harvest zones (traditional hunting, fishing, gathering areas), migration corridors for whales/walrus and marine-protected areas; overlay project alignment and identify which communities have traditional-use claims overlapping with project footprint. Engage with Arctic Council Permanent Participants (Inuit Tapiriit Kanatami, Inuit Circumpolar Council, etc.) and Russian Indigenous organizations (Association of Indigenous Peoples of the North, Siberia and Far East) to validate community mapping by Month 3 (2027-01-12).
- Draft a Binational Indigenous Consultation Legal Framework memorandum (Months 1–2 = 2026-11-12 to 2026-12-12) reconciling US trust-responsibility doctrine (Section 106 of National Historic Preservation Act, Indian Religious Freedom Act, tribal consultation standards) with Russian indigenous-rights statutes (Law on Indigenous Peoples of the Russian Federation, regional autonomy provisions). Circulate for comment to US tribal leaders, Russian Indigenous leaders and relevant legal experts by Month 3 (2027-01-12); finalize framework by Month 6 (2027-04-12).
- Model benefit-fund governance using precedent binational mechanisms (Great Lakes Basin Binational Toxics Strategy co-management model, Porcupine Caribou Herd International Management Board, or Inuit Tapiriit Kanatami joint-governance examples); draft governance charter and bylaws for Beringia Indigenous Council specifying: membership (representatives from each mapped community), decision-making procedures (consensus-based, supermajority, or rotating veto), dispute-resolution (neutral mediator, external arbitration), and benefit-fund administration (independent audits, transparency).
- Prototype a consent-agreement template in both English and Russian covering: project description and impacts (alignment, work windows, marine-mammal effects), informed-consent definition (what information is provided, in what languages, over what timeframe), decision authority (which project changes trigger need for new consent), benefit-sharing (revenue share, local-hire targets, observer roles, co-management programs), dispute resolution (negotiation → mediation → arbitration pathway), and compliance monitoring (annual reporting, joint oversight). Circulate template to 2–3 representative communities for iterative feedback by Month 3–4 (2027-01-12 to 2027-02-12); finalize by Month 6 (2027-04-12).

### Expert Validation Steps

- Retain a binational Indigenous-rights and consultation specialist (e.g., law firm with expertise in US tribal consultation and Russian indigenous law, or Arctic Council observer organizations) by Month 0 (2026-10-12) to co-develop the Binational Indigenous Consultation Legal Framework by Month 6 (2027-04-12).
- Fund independent Indigenous legal advisors (USD 1–3 million allocation over Months 0–12 = 2026-10-12 to 2027-10-12) to represent the interests of Indigenous communities in negotiations; ensure advisors have standing in both US and Russian legal systems and can review agreements for enforceability and fairness.
- Engage each mapped community through its established governance structure (tribal council, regional Native corporation, elders' advisory board) starting Month 1 (2026-11-12); conduct in-person consultation meetings in each community (Wales, Uelen, and regional centers) explaining the project, soliciting feedback on impacts and benefit-sharing preferences, and discussing consent protocols. Document attendance, comments and community preferences in a consultation record (Month 1–6 = 2026-11-12 to 2027-04-12).
- Formally establish the Beringia Indigenous Council (Months 3–6 = 2027-01-12 to 2027-04-12) with signed Memoranda of Understanding from all participating communities and governments; ensure Council has legal standing in both US and Russian jurisdictions (may require treaty or bilateral governmental agreement); fund secretariat with USD 2–5 million annual allocation (proposed threshold) and hire an Indigenous Executive Director or co-chairs.
- Negotiate and execute FPIC agreements with each community (Months 6–12 = 2027-04-12 to 2027-10-12) under the Council's oversight; ensure agreements are documented in both English and Russian and signed by tribal/community leaders and Council representatives; provide each community free legal review before signature.

### Responsible Parties

- Community Relations Lead / Indigenous Engagement Director (project sponsor)
- Binational Indigenous-rights counsel (framework development)
- Independent Indigenous legal advisors (community representation)
- Beringia Indigenous Council (negotiation and governance)
- Each mapped Indigenous community (consent signatory)

### Assumptions

- **High:** All 8–12 mapped Indigenous communities will participate in the Beringia Indigenous Council formation and FPIC negotiation; if any community refuses to participate, alternative consent pathway (direct government-to-community agreement) will be negotiated in parallel to ensure no community is excluded from decision-making.
- **High:** A Beringia Indigenous Council with binding advisory authority (or full veto power over specific decisions) can be established under a cross-border legal instrument (treaty, bilateral agreement, or supranational governance charter) that is enforceable in both US and Russian jurisdictions without requiring full US Senate or Russian Duma ratification.
- **Medium:** Indigenous communities will accept a benefit-sharing formula of 1–2% of annual operating revenue (estimated USD 10–30 million/yr at full operation) or fixed annual payment as adequate compensation for project impacts and lost subsistence use; if communities demand higher percentages (5–10%), project must negotiate alternative benefit mechanisms (local hiring, joint ventures, technology transfer) or accept higher operating costs.
- **Medium:** FPIC agreements reached with communities by Month 12 (2027-10-12) will remain binding and enforceable through construction and operations (Months 24–180 = 2028-10-12 to 2041-10-12) even if geopolitical or economic conditions change; communities will not rescind consent mid-project unless major scope changes occur (aligned, work windows) that trigger renegotiation clauses.
- **Medium:** Indigenous observers and co-management participation in marine mammal monitoring (proposed in Decision 11) will be funded through the Beringia Indigenous Council (USD 1–3 million/yr estimated for monitoring, capacity-building, co-management) and will be implemented as a formal operating procedure that does not create unmanageable stop-work authority for contractors.

### SMART Validation Objective

By Month 6 (2027-04-12), establish the Beringia Indigenous Council with signed Memorandum of Understanding from all 8–12 mapped communities, confirmed legal standing in both US and Russian jurisdictions, and USD 2–5 million annual funding. By Month 12 (2027-10-12), execute Free, Prior and Informed Consent agreements with all participating communities specifying binding consent authority, benefit-sharing mechanisms, Indigenous workforce targets and observer participation; obtain written Council certification that all consent requirements have been met and communities authorize proceeding to design freeze. If any community withholds consent at Month 12 (2027-10-12), trigger paid pause (Months 12–18 = 2027-10-12 to 2028-04-12) for additional negotiation; if consent remains unachieved by Month 18 (2028-04-12), design freeze is deferred and project gates slip by 6–12 months.

### Notes

- Indigenous-rights law in both jurisdictions is evolving toward Free, Prior and Informed Consent (FPIC) as a binding standard, not merely advisory consultation; expect communities to assert veto authority over alignment changes, work-window restrictions and emergency protocols; design the Council governance to accommodate this without creating paralyzing deadlock.
- Benefit-sharing and local-hire commitments are expected baseline outcomes; lenders will view community buy-in as a credit positive and will encourage benefit funds as part of the permitting and financing package. Budget USD 1–3 million/yr for benefit-fund administration and USD 10–30 million/yr for payments (part of operating costs, not contingency).
- Consent-agreement language must be accessible to Indigenous communities (plain language, not legal jargon); provide funded interpretation and independent legal review for all communities to ensure understanding and informed signature.
- Timeline for Indigenous engagement is aggressive: Months 1–12 (2026-11-12 to 2027-10-12) covers mapping, Council formation, and consent negotiation; any delay in community engagement in Month 1 (2026-11-12) cascades into Month 12 (2027-10-12) Gate 2 risk if consent agreements are not finalized.
- Designate a named Indigenous Engagement Director (dedicated FTE starting Month 0 = 2026-10-12) with authority to commit resources and negotiate directly with communities; consultant-only models historically underweight Indigenous consultation and trigger downstream litigation.


## 5. Immersed-Tube Tunnel Element Fabrication Capacity, Pilot-Element Trial and Installation-Rate Validation

Tunnel-element fabrication and installation are novel in Arctic conditions; no proven precedent exists for continuous production of 100+ elements and sustained 9 elements/season installation in ice. Single-yard and single-vessel dependencies create catastrophic schedule risk: yard failure or one lost season cascades into 12+ month delays. Pilot-element trial (Months 9–12 = 2027-07-12 to 2027-10-12) is the critical technical gate: if pilot fails (design defect, tow damage, installation misalignment), full-scale production is at risk and must be redesigned. Installation-rate gap (9 needed vs. 3–8 achievable) is unresolved in the plan; validating realistic capacity by Month 6 (2027-04-12) and locking Phase 1 completion date by Month 18 (2028-04-12) preserves credibility with lenders and prevents late-stage surprises.

### Data to Collect

- Pre-qualified 2–3 fabrication yards with documented Arctic or heavy-marine immersed-tube experience; framework agreements specifying production capacity (5–8 elements/yr per yard, estimated), unit costs (capped escalation), lead times and quality assurance
- Pilot-element trial results (Months 9–12 = 2027-07-12 to 2027-10-12): full-scale tunnel segment (250–300 m) design, fabrication, tow and installation monitoring documenting real-world performance, cost and schedule vs. baseline
- Detailed installation schedule modeling open-water season constraints (June–September tow window, 4-month nominal), element-preparation and immersion rates, seasonal overlap and recovery actions (second spread, acceleration incentives, contingency buffers); installation rate baseline (3–8 elements/season documented performance; target 9 elements/season, identified as gap)
- Revised Phase 1 completion date contingent on demonstrated installation capacity: if single-spread productivity <7 elements/season, confirm second-spread plan (cost USD 10–20 billion estimate, schedule +12 months for mobilization, or Phase 1 scope reduction to 60–70 elements with extended timeline beyond Month 180 = 2041-10-12)
- Marine-logistics risk register: tow-vessel availability, weather downtime, ice-season duration variability, element damage risk and recovery procedures; contingency schedule float for lost seasons (propose 12+ months)

### Simulation Steps

- Develop a detailed logic-based Gantt schedule (Months 0–3 = 2026-10-12 to 2027-01-12) using Primavera P6 or equivalent covering: fabrication-yard ramp-up (8–12 months to full production), design-to-fabrication lead times (18–24 months for first element, 8–12 months for subsequent), tow preparation (2–4 weeks per element), tow transit time (4–8 weeks depending on weather routing), immersion setup and execution (2–3 days positioning, 1–2 days dewatering). Model seasonal tow-window constraints: June–September = 4-month open-water window; reduce by 35–40% for weather delays, ice intrusions and regulatory stop-work = 2.4–2.6 months net productive tow. Model parallel mobilization: Element N being immersed while Element N+1 is in tow and Element N+2 is being fabricated. Output: installation rate (elements per season) and cumulative timeline for 100 elements at 1-spread vs. 2-spread operation.
- Conduct a fabrication-yard feasibility assessment by Month 3 (2027-01-12): identify 3–5 candidate yards globally (Pacific Northwest, South Korea, Japan, northern Europe) with immersed-tube experience (Fehmarnbelt, HZMB, Caspian projects); request capacity and cost quotes for a 10-element contract at capped unit cost. Assess: production floor space (propose 50,000+ m² for concurrent element production), launching/docking facilities (propose heavy-lift capacity ≥5,000 tonnes), workforce availability (propose 200–500 construction workers), quality-assurance and test protocols. Build a yard-selection scorecard assessing cost, capacity, Arctic materials experience, and sanctions/export-control eligibility.
- Model pilot-element trial (Months 9–12 = 2027-07-12 to 2027-10-12) with real instrumentation: deploy GPS (position accuracy ±10 cm), accelerometers (capture wave and tow-vessel motion), strain gauges on element structure (validate design assumptions), and structural-health sensors (underwater acoustic telemetry). Document tow performance (sea state, tow-vessel fuel consumption, cable tension, time-to-site) and immersion procedure (ballast sequence, diver operations, positioning accuracy, joint installation). Use pilot outcomes to refine element design and yard/contractor processes before full-scale production commitment.
- Stress-test installation schedule against single-loss scenarios: if one tow vessel breaks down (12-month repair, estimated), how does that affect installation timeline? If one open-water season is lost to ice (one-in-five-year probability, estimated), what is cumulative delay? If pilot-element trial fails (redesign, 6-month delay), what is impact? Output: schedule float allocation, contingency reserve, and identification of critical-path items where delays are unrecoverable (e.g., first element must be delivered by Month 36 = 2029-10-12 or Phase 1 completion slips beyond Month 180 = 2041-10-12).

### Expert Validation Steps

- Engage Arctic offshore specialists (Boskalis, Jan De Nul, Dredging International, equivalent) by Month 0 (2026-10-12) to conduct fabrication-yard pre-qualification survey and deliver detailed installation schedule by Month 6 (2027-04-12).
- Convene a Fabrication and Logistics Task Force (Months 3–6 = 2027-01-12 to 2027-04-12) with Owner's Engineer, candidate yards (2–3), tow contractors (2+), and Arctic specialists to validate element design feasibility in candidate yards, confirm cost and production-rate quotes, and finalize framework agreements by Month 6 (2027-04-12).
- Commission a marine-construction risk assessment from a specialized firm (e.g., horizon Offshore, Cal Dive, equivalent) quantifying weather downtime, tow-vessel utilization, element-damage probability and recovery costs; identify single-point-of-failure risks (e.g., only one yard capable of producing elements, limited tow-vessel availability) and mitigation (backup yards, spare vessels, insurance coverage).
- Pilot-element trial oversight (Months 9–12 = 2027-07-12 to 2027-10-12): establish an Independent Review Board (yard engineer, owner's engineer, classification society, Arctic specialist) to witness fabrication, tow and installation; document all anomalies, corrective actions and lessons learned; issue pilot trial report with go/no-go recommendation by Month 12 (2027-10-12).
- Design-review gate at Month 15 (2028-01-12): present finalized installation schedule and yard framework agreements to lenders and governments; confirm that installation productivity (estimated 3–8 elements/season baseline, identified gap, requires mitigation) will be addressed by second-spread option, scope reduction, or extended Phase 1 timeline; obtain written lender and government acceptance of revised Phase 1 completion date before final design freeze at Month 18 (2028-04-12).

### Responsible Parties

- Owner's Engineer (design integration and pilot-trial oversight)
- Arctic offshore construction specialists (fabrication and logistics planning)
- Fabrication-yard task force members (yard selection, contracting)
- Marine-construction risk specialist (schedule and logistics risk quantification)
- Tow-contractor and vessel operators (capacity and availability confirmation)
- Independent Review Board (pilot-trial oversight and certification)

### Assumptions

- **High:** At least 2–3 immersed-tube fabrication yards globally have capacity and willingness to produce 10–50+ elements at the Bering Strait design scale (250–300 m length, 40–50 m width, 30–35 m depth, concrete or steel construction) within budget and schedule constraints.
- **High:** Pilot-element trial (Months 9–12 = 2027-07-12 to 2027-10-12) will achieve technical success (design validated, fabrication feasible, tow stable, installation procedures proven) with <5% cost overrun and <3-month schedule slip vs. baseline, allowing full-scale production to proceed without major redesign.
- **Medium:** Arctic open-water season (June–September, 4-month nominal window) will support 2.4–2.6 months of net productive tow and immersion after weather delays (35–40% downtime from ice, storms, fog). Second-order loss (one full season every 5–10 years) is captured in schedule contingency (propose 12+ months float) rather than as baseline assumption.
- **High:** Single-spread installation at 6–8 elements/season will not achieve the 100-element Phase 1 count within the Month 180 (2041-10-12) target; a second spread (dual yards, parallel production and tow) or Phase 1 scope reduction (60–70 elements, extended timeline to Month 210+ = 2043-09-12+) will be necessary and will be committed by Month 12 (2027-10-12).
- **Medium:** Framework agreements with 2+ fabrication yards will include force-majeure and substitution provisions allowing yard failure recovery without project termination; secondary-yard activation fees and contingency tow-vessel availability will be pre-negotiated and funded within capex contingency (USD 500 million–USD 1 billion estimated for logistics redundancy).

### SMART Validation Objective

By Month 6 (2027-04-12), execute framework agreements with 2 primary immersed-tube fabrication yards specifying production schedules (5–8 elements/yr per yard, capped unit costs), Arctic material standards and quality-assurance protocols. By Month 12 (2027-10-12), complete pilot-element trial with go/no-go recommendation from Independent Review Board (design validated, fabrication feasible, installation procedures proven). By Month 18 (2028-04-12), finalize revised Phase 1 timeline: confirm either (a) second-spread mobilization plan with cost and schedule (dual yards, parallel production, reduced installation time), or (b) Phase 1 scope reduction to 60–70 elements with commissioning date extended to Month 210+ (2043-09-12+, beyond the Month 180 = 2041-10-12 user target). Obtain lender and government written acceptance of the chosen path as a condition of financial close.

### Notes

- Fabrication-yard selection must account for sanctions and export-control compliance; yards in non-sanctioned jurisdictions (Canada, northern Europe, Japan, South Korea) are preferred to avoid US/Russian licensing delays; yards with prior Arctic experience (Fehmarnbelt in Denmark, HZMB yards in China, Caspian projects) have institutional knowledge relevant to the Bering Strait design.
- Pilot-element trial cost is estimated at USD 50–80 million (within pre-gate spend cap of USD 150 million through Month 24 = 2028-10-12); if pilot fails and redesign is required, cost escalates to USD 100–150 million and timeline extends to Month 15–18 (2028-01-12 to 2028-04-12), consuming design-freeze margin.
- Installation-rate gap (9 needed vs. 3–8 achievable) is the critical schedule risk; decision between second-spread investment and scope reduction must be made by Gate 2 (Month 12 = 2027-10-12) to allow lenders to size debt against revised Phase 1 revenue and extend timeline accordingly. Any delay in this decision pushes uncertainty to Gate 3 (Month 18 = 2028-04-12) or financial close (Month 24 = 2028-10-12), both unacceptable for financing closure.
- Marine-logistics risk register must quantify: tow-vessel availability (propose 85–90% utilization target vs. 95–100% assumed in optimistic plans), weather downtime (propose 35–40% of open-water window, industry standard for Arctic), and single-loss recovery (12-month vessel repair, 6-month element redesign post-failure). Schedule float of 12+ months (propose allocation) is necessary to absorb one lost season without breaching Month 180 (2041-10-12) target.
- Framework agreements with yards must include innovation and learning-curve provisions: unit cost reductions of 10–15% (estimated) are typical in the second through fifth elements of a new design as fabrication becomes optimized; captured reductions offset 10–15% contractor risk premiums and improve financing economics.


## 6. Sanctions Licensing, Export-Control Compliance and Third-Country Financing-Vehicle Validation

Sanctions and export-control compliance are binary gating risks: OFAC can deny licensing or restrict critical suppliers at any point (Month 3–180 = 2027-01-12 to 2041-10-12), cascading into equipment procurement delays (6–12 months, estimate) or financing withdrawal. A neutral third-country SPV is proposed to ring-fence sponsors from direct sanctions exposure, but OFAC approval is not guaranteed; preliminary licensing guidance by Month 6 (2027-04-12) is essential before heads-of-terms (Month 9 = 2027-07-12) are signed. Pre-approved supplier list (Month 6 = 2027-04-12) with secondary sourcing options preserves flexibility if primary suppliers face sanctions mid-project. Quarterly sanctions monitoring (Month 6–60 = 2027-04-12 to 2031-10-12) enables early warning and contingency activation (backup suppliers, design substitutions) before critical path is breached.

### Data to Collect

- Written preliminary and final OFAC licensing guidance (Months 3–6 = 2027-01-12 to 2027-04-12) confirming that neutral third-country SPV ownership with US and Russian government contractual stakeholders qualifies for financing and equipment sourcing
- Pre-approved supplier list for all long-lead items (steel mills, cable manufacturers, tunnel-element yards, electrical vendors) with explicit verification that each supplier source (country of origin, US export-control classification) is compatible with current OFAC, EAR and Russian sanctions regimes
- Neutral special-purpose entity (SPV) charter (Swiss, Canadian or international legal regime) drafted and approved by OFAC by Month 3 (2027-01-12); formal incorporation and registration by Month 6 (2027-04-12)
- Financing term-sheet with sanctions-compliance conditions specified (OFAC licensing must be obtained before each debt draw; if licenses are revoked, force-majeure and debt-reduction provisions apply)
- Quarterly sanctions monitoring and escalation protocol (starting Month 6 = 2027-04-12): track US, Russian, EU and Canadian sanctions developments; flag supplier or financing-partner sanctions risk to steering committee with 2-week contingency mitigation window

### Simulation Steps

- Conduct a sanctions-exposure assessment by categorizing all major project components (bridge towers, cable, tunnel elements, electrical systems, control software) by export-control classification (ITAR-controlled, EAR-controlled, dual-use, civilian-only); map candidate suppliers and yards against OFAC Specially Designated Nationals (SDN) list, EU sanctions lists, and Russian blacklists. For each component, identify sanctions-compliant sourcing options (non-US, non-Russian suppliers if available; or suppliers with existing export licenses for Arctic use). Document sourcing geography and licensing assumptions in a Sanctions Risk Scorecard.
- Model financing-vehicle structures using a legal-structure comparison tool or memo: Option A (neutral Swiss SPV with non-US/non-Russian equity and debt) vs. Option B (Canadian corporation with multilateral development-bank funding) vs. Option C (supranational entity chartered under international law). For each option, assess OFAC approval likelihood, lender acceptance, and operating complexity; output a recommendation on which structure is most likely to achieve licensing by Month 6 (2027-04-12).
- Build a supplier-substitution matrix: for each critical item (cable, steel, tunnel liners, electrical systems), identify primary and secondary sourcing countries and suppliers; assess export-control compliance for each; calculate cost delta if primary supplier faces sanctions and secondary must be used (estimate 5–15% cost premium, estimate). Scenario-test: if US imposes new sanctions on Russian steel (hypothetical), what project components are affected, which suppliers can substitute, and what is cost impact? If OFAC denies license for certain electronics, which subsystems can be redesigned or sourced differently?

### Expert Validation Steps

- Retain OFAC-licensed export-control counsel by Month 0 (2026-10-12); conduct preliminary sanctions and export-control assessment (Months 0–2 = 2026-10-12 to 2026-12-12); submit formal licensing request to OFAC and BIS (Months 2–3 = 2026-12-12 to 2027-01-12) describing financing structure, ownership, equipment procurement and personnel movement.
- Engage with OFAC Sanctions Licensing Division (designated OFAC contact) by Month 2 (2026-12-12); request written preliminary guidance on licensable financing-vehicle structures, approved lender nationalities and approved-supplier-list criteria. Goal: obtain written preliminary guidance letter by Month 6 (2027-04-12) that identifies which financing structures OFAC is prepared to license and which supplier geographies are approved for procurement.
- Coordinate with Russian export-control authorities (Federal Customs Service, Ministry of Foreign Affairs, Ministry of Trade and Industry, or equivalent) by Month 2 (2026-12-12) through project counsel and Russian government liaisons; request guidance on what project equipment and financing sources are acceptable under Russian law and bilateral export-control agreements.
- Establish a Sanctions Compliance Working Group (starting Month 3 = 2027-01-12) with export-control counsel, project finance lead and procurement lead; meet monthly (Months 3–60 = 2027-01-12 to 2031-10-12) to review sanctions developments, update pre-approved supplier list quarterly, and escalate any supplier/lender sanctions risk to steering committee with contingency mitigation options (backup suppliers, financing restructuring).
- Obtain lender written confirmation (as part of heads-of-terms, Month 9 = 2027-07-12) that financing structure and sanctions-compliance conditions are acceptable; specify that debt draws are contingent on OFAC licenses being current and that force-majeure provisions apply if licenses are revoked mid-project.

### Responsible Parties

- Export-control counsel (OFAC-licensed law firm or consultant)
- Finance Lead / CFO (financing-vehicle charter and lender coordination)
- Procurement Lead (supplier pre-qualification and sanctions monitoring)
- Russian government liaison (export-control coordination with Russian authorities)
- Sanctions Compliance Working Group (ongoing monitoring and escalation)
- OFAC Sanctions Licensing Division (written guidance and licensing decisions)

### Assumptions

- **High:** OFAC will issue written preliminary licensing guidance by Month 6 (2027-04-12) confirming that a neutral third-country SPV with US and Russian government contractual rights (not equity ownership) qualifies for financing and equipment sourcing under existing sanctions authorities.
- **High:** At least 2–3 major US and Russian lenders will accept project financing under sanctions-compliant structure; if OFAC licensing is restrictive or unavailable, project can substitute non-US, non-Russian lenders (development banks, export-credit agencies) without material pricing or term changes.
- **Medium:** Pre-approved supplier list (Month 6 = 2027-04-12) covering all long-lead items will include secondary and tertiary suppliers in different countries; if primary supplier faces sanctions mid-project, project can substitute secondary supplier within 8–12 weeks without >10% cost premium (estimated).
- **High:** US and Russian bilateral sanctions regimes will not tighten materially beyond current levels (Month 0 = 2026-10-12 baseline) during the program horizon (Months 0–180 = 2026-10-12 to 2041-10-12); if sanctions do escalate (hypothetical new restrictions on financing or equipment), project will have 2-week notice and contingency mitigation options (forced-majeure clause, financing restructuring, scope reduction).
- **Medium:** All lenders committing debt (heads of terms, Month 9 = 2027-07-12 and beyond) will accept force-majeure and debt-reduction provisions if OFAC licenses are revoked mid-project; financing structure will not require US government guarantee or US-entity participation that could expose lenders to retroactive sanctions liability.

### SMART Validation Objective

By Month 6 (2027-04-12), obtain written OFAC preliminary licensing guidance letter confirming that proposed neutral SPV structure is licensable for financing and equipment procurement; establish pre-approved supplier list covering all long-lead items with secondary/tertiary sources in non-sanctioned jurisdictions; and complete neutral-country SPV charter for incorporation. By Month 9 (2027-07-12), incorporate SPV and obtain lender written confirmation that financing structure satisfies sanctions-compliance requirements; include OFAC-licensing conditions in heads-of-terms. By Month 24 (2028-10-12), obtain final OFAC licenses for debt facilities and major equipment suppliers before financial close. Maintain quarterly sanctions monitoring (Month 6–60 = 2027-04-12 to 2031-10-12) with escalation protocol if supplier/lender sanctions risk emerges.

### Notes

- OFAC licensing pathways are unpredictable and dependent on changing geopolitical conditions; preliminary guidance (Month 6 = 2027-04-12) is not a binding commitment. Project must be structured so that if OFAC denies or delays licensing beyond Month 18 (2028-04-12), design and procurement can pivot to non-sanctioned suppliers without major cost or schedule impact.
- Russian export controls are less transparent than US sanctions; early coordination with Russian government (Month 2–3 = 2026-12-12 to 2027-01-12) through diplomatic channels is advisable to understand Russian approval requirements and timelines.
- Pre-approved supplier list must be maintained dynamically (quarterly updates, Month 6–60 = 2027-04-12 to 2031-10-12): as sanctions develop or suppliers face restrictions, list must be refreshed and contingency suppliers activated.
- Sanctions-compliance costs are estimated at 5–10% procurement premium (estimate) for sourcing from non-sanctioned suppliers or managing licensing delays. These costs should be embedded in the parametric cost model (Item 2) or allocated from contingency pool (USD 1–2 billion, estimate).
- Force-majeure and debt-reduction provisions in financing agreements are critical: if OFAC revokes a license for a critical supplier mid-construction, lenders must accept delayed completion and reduced early revenue; project cannot be abandoned because of licensing changes outside sponsor control.

## Summary

This six-item data-collection plan prioritizes the five to seven most critical validation areas for Phase 1 (rail-and-utility immersed-tunnel) of the Alaska-Russia Bering Strait crossing, gated at Months 6, 12, 18 and 24 (2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12). Item 1 (Lender Engagement & Financing) is foundational: without heads-of-terms by Month 9 (2027-07-12) and financial close by Month 24 (2028-10-12), sunk costs of USD 50–150 million (estimate) are stranded. Item 2 (Cost Validation) must deliver a parametric Cost Basis Document by Month 6 (2027-04-12) to prevent contractor risk premiums from inflating USD 100 billion baseline by USD 10–30 billion (estimate). Item 3 (Design Envelope Data) gates design freeze on ice-load, seismic and permafrost confidence ±15% by Month 18 (2028-04-12); one lost ice-season (12-month delay estimate) or inconclusive data extends observational period rather than freezing uncertain design. Item 4 (Indigenous Consent) establishes Beringia Indigenous Council with binding decision authority by Month 6 (2027-04-12) and executes FPIC agreements by Month 12 (2027-10-12); unresolved claims trigger 6–18 month injunctions (estimate). Item 5 (Tunnel Installation Capacity) resolves the gap between 9 elements/season required and 3–8 achievable by committing to a second spread (USD 10–20 billion cost estimate) or rescoping Phase 1 by Month 12 (2027-10-12); without resolution, Phase 1 commissioning slips past Month 180 (2041-10-12) target. Item 6 (Sanctions Licensing) obtains written OFAC guidance by Month 6 (2027-04-12) confirming licensable financing vehicle; sanctions denial or supplier restrictions cascade into 6–12 month delays. Each validation area includes simulation steps (financial modeling, parametric cost spreadsheets, schedule simulations, GIS mapping, ice-impact models) and expert-validation steps (lender engagement, Arctic specialists, export-control counsel, Indigenous rights experts, marine-construction engineers) with explicit SMART objectives, responsibles, assumptions (with sensitivity scores) and actionable notes. Most critical next steps: (1) Appoint Finance Lead and launch lender engagement by Month 0–1 (2026-10-12 to 2026-11-12); (2) Retain export-control counsel and submit OFAC licensing request by Month 0–2 (2026-10-12 to 2026-12-12); (3) Commission parametric cost model and independent traffic study by Month 0–3 (2026-10-12 to 2027-01-12); (4) Map Indigenous communities and establish Beringia Council by Month 1–6 (2026-11-12 to 2027-04-12); (5) Pre-qualify fabrication yards and plan pilot-element trial by Month 3–6 (2027-01-12 to 2027-04-12). Gate 1 (Month 6 = 2027-04-12) is the critical decision point: if lender LOIs, cost basis document, OFAC guidance, Indigenous Council and traffic study are not delivered by then, trigger immediate repricing and risk reassessment; if any are missing, enter paid pause or exit per gating protocol.