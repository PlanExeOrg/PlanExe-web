### 1. Tracking Key Performance Indicators (KPIs) Against Project Baseline and Lender Covenants
**Monitoring Tools/Platforms:**

  - Project Management Software Dashboard (Primavera P6 or Oracle Cloud)
  - Monthly KPI Tracking Spreadsheet
  - Lender Covenant Compliance Report
  - Cost and Schedule Variance Dashboard

**Frequency:** Weekly during Months 0-24 (2026-10-12 to 2028-10-12); bi-weekly during Months 25-60 (2028-11-12 to 2031-10-12); monthly during Months 60-180 (2031-10-12 to 2041-10-12)

**Responsible Role:** Cost Engineer and Finance Manager (Operations and Execution Council) reporting to Steering Committee

**Adaptation Process:** Monthly variance review by Operations Council: if cost variance exceeds 5% or schedule slip exceeds 2 months, Finance Manager initiates reforecasting and repricing analysis. Cost changes >USD 10 million or schedule slip >6 months escalate to Steering Committee for decision on contingency release, scope reduction, or schedule adjustment. Debt service coverage ratio (DSCR) monitored against 1.2x covenant breach threshold; DSCR projected <1.3x triggers Steering Committee review of revenue assumptions, toll increases or cost mitigation. Variance trends (3+ consecutive months exceeding thresholds) trigger immediate escalation and corrective-action planning.

**Adaptation Trigger:** Cost variance >5% (USD 5 billion), schedule slip >2 months, DSCR projected <1.3x within 12 months, or trend of 3+ months exceeding thresholds. Covenant breach trigger at DSCR <1.2x or debt-to-equity ratio exceeding agreed ratio. Trigger thresholds are decision gates; reforecasting occurs at each gate (Months 6, 12, 18, 24 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12) and adjusted if project risk profile changes.

### 2. Regular Risk Register Review and Leading-Indicator Monitoring for Political, Financial and Technical Risk Clusters
**Monitoring Tools/Platforms:**

  - Comprehensive Risk Register (Excel or dedicated risk database)
  - Risk Dashboard with Leading Indicators (cost, schedule, DSCR, permitting milestones, Indigenous consent)
  - Monthly Risk Status Report to Steering Committee
  - Geopolitical and Sanctions Escalation Alert Log

**Frequency:** Weekly risk-indicator monitoring (cost variance, schedule slip, covenant ratios, permitting delays) with automated alerts. Monthly Risk Committee meetings and formal risk-register updates (Months 0-24 = 2026-10-12 to 2028-10-12). Bi-monthly during construction (Months 25-60 = 2028-11-12 to 2031-10-12). Quarterly during operations (Months 60-180 = 2031-10-12 to 2041-10-12). Emergency risk escalation within 24 hours if geopolitical incident or major risk materializes.

**Responsible Role:** Risk, Compliance and Insurance Committee Chair and Compliance Officer, supported by Steering Committee representation

**Adaptation Process:** Risk Committee identifies emerging risks or threshold breaches and proposes mitigation: (1) operational mitigation (design refinement, schedule adjustment, cost control) managed by Operations Council; (2) political/sanctions mitigation escalated to Steering Committee for government/lender engagement; (3) force-majeure events or existential risks (sanctions escalation, financing withdrawal, geopolitical break) trigger emergency Steering Committee meeting within 48 hours and escalation to diplomatic channels if required. Mitigation ownership assigned, target completion date set, and residual risk re-assessed at each risk-committee meeting. Closed risks removed from register; new risks added as identified.

**Adaptation Trigger:** Risk threshold breach: cost variance >5%, schedule slip >2 months, DSCR <1.3x, OFAC/export-control licensing delayed >3 months, permit milestone missed >1 month, Indigenous-consent dispute unresolved >6 weeks, geopolitical incident (sanctions escalation, major US-Russia diplomatic break, visa bans), major supplier failure or lender withdrawal. Each risk category has escalation criteria documented in risk register; Risk Committee escalates to Steering Committee within 1 week of threshold breach. Emergency escalation within 24 hours if risk impact is existential (financing loss, project abandonment trigger).

### 3. Political Gating and Confidence-Building Sequence: Tracking Treaty Ratification, Sanctions Licensing and Financial Close Against Explicit Decision Gates
**Monitoring Tools/Platforms:**

  - Gate-Readiness Checklist (Months 6, 12, 18, 24 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12)
  - Treaty and Framework Agreement Negotiation Timeline Tracker
  - OFAC and Export-Control Licensing Pathway Document (updated monthly)
  - Financing Roadmap and Heads-of-Terms Status Dashboard
  - Government Engagement Log (diplomatic meetings, regulatory submissions, approvals)

**Frequency:** Continuous monitoring of gate-readiness criteria. Monthly Steering Committee reviews (Months 0-24 = 2026-10-12 to 2028-10-12). Formal gate-clearance decision meetings at Months 6, 12, 18, 24 (2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12) with 2-4 week review window and 1-week decision window. Emergency escalation if gate-readiness indicator falls below 50% at midpoint between gate months.

**Responsible Role:** Steering Committee Chair, with support from Project Manager (treaty/framework tracking), Compliance Officer (sanctions/export-control pathway), Finance Manager (financing-close status) and Operations Council leadership

**Adaptation Process:** Gate-readiness tracked against explicit pass/fail criteria documented in gate-clearance checklists. If criteria are on track (>80% confidence), gate proceeds as scheduled. If criteria are at risk (50-80% confidence), remediation actions are assigned to responsible parties (e.g., accelerate treaty negotiation, submit OFAC licensing request, secure lender term-sheet commitment) with target completion before gate review. If criteria fall below 50% confidence or dependency fails (e.g., lender withdraws, treaty ratification blocked), Steering Committee triggers Paid Pause Protocol: 3-6 month funded pause (pre-gate spending limited to remediation), with exit provisions if gate criteria remain unmet by pause deadline (Month 30 = 2029-04-12 for Gate 4). Gate decisions (pass/defer/exit) are formally documented and communicated to all parties.

**Adaptation Trigger:** Gate-readiness indicator below 50% at midpoint between gate reviews, or explicit gate-readiness criterion failing (e.g., lender heads-of-terms not signed by Month 9 = 2027-07-12 target for Gate 2, or OFAC licensing pathway not received by Month 6 = 2027-04-12 target). Treaty negotiation slip >3 months beyond original schedule, sanctions-licensing uncertainty unresolved >6 weeks, financing roadmap without commitment from 2+ lead lenders >2 weeks after Months 6-9 (2027-04-12 to 2027-07-12) target. Any gate criterion flagged as fail at gate-review meeting triggers immediate Paid Pause and escalation per gate protocol. Emergency escalation within 48 hours if geopolitical event makes gate criteria unachievable (e.g., sanctions escalation prevents OFAC licensing, US-Russia diplomatic break stalls treaty negotiation).

### 4. Ice-Load, Seismic and Permafrost Observational Design Monitoring: Tracking Data Collection and Design-Freeze Gate Adequacy
**Monitoring Tools/Platforms:**

  - Ice-Monitoring Network Dashboard (drifting buoys, radar, satellite imagery, live data feeds)
  - Geotechnical Investigation Database (core logs, lab results, in-situ test data)
  - Seismic Hazard Analysis and Ground-Response Modeling Reports
  - Data-Confidence Scoring Matrix (ice, seismic, permafrost; target: within +/-15% by Month 18 = 2028-04-12)
  - Technical Advisory Group Monthly Data Summary and Quarterly Certification Reports

**Frequency:** Continuous ice-monitoring data collection (buoys, radar) starting Month 0 (2026-10-12). Weekly ice-data quality checks and summary (Months 6-18 = 2027-04-12 to 2028-04-12). Monthly geotechnical lab results review (Months 3-12 = 2027-01-12 to 2027-10-12). Quarterly Technical Advisory Group formal reviews (Months 3, 6, 9, 12, 15, 18 = 2027-01-12 to 2028-04-12). Design-freeze readiness assessment at Month 15 (2028-01-12); formal data-adequacy gate at Month 18 (2028-04-12).

**Responsible Role:** Design Lead - Bridge (ice and seismic lead), Owner's Engineer Integrator (geotechnical lead), and Technical Advisory Group (independent certification of data adequacy)

**Adaptation Process:** Monthly design-refinement incorporating newly available monitoring data: ice-load models updated as seasonal data accumulate; seismic and permafrost assumptions refined based on lab and in-situ testing. If data trends confirm design assumptions within expected ranges (confidence bands tightening toward +/-15% target), design proceeds on schedule toward freeze at Month 18 (2028-04-12). If data reveal higher loads or ground instability than assumed (e.g., ice floes larger or more frequent than historical baseline, permafrost thaw faster than models), design load cases are increased iteratively and foundation designs strengthened, extending design refinement into Months 18+ as needed. If data collection is delayed or inconclusive by Month 15 (2028-01-12), Technical Advisory Group recommends design-freeze deferral (3-6 month paid pause) to allow extended monitoring, triggering Steering Committee decision on schedule trade-off vs. design-uncertainty risk.

**Adaptation Trigger:** Data confidence falling below target (+/-15% threshold) at Month 15 (2028-01-12) leads to design-freeze deferral recommendation by TAG. Ice-load data showing 20%+ higher peak pressures than historical baseline, permafrost thaw rates 50%+ faster than models, or seismic ground-response uncertainties >20% trigger design-envelope review and potential specification tightening (cost increase of USD 5-15 billion estimated). Monitoring data collection 6+ weeks behind schedule at any point in Months 0-18 (2026-10-12 to 2028-04-12) escalates to Operations Council for expedited catch-up or alternative data-collection methods. TAG certification withheld if data-confidence thresholds are not met by Month 18 (2028-04-12); design freeze deferred and Steering Committee triggered for gate decision (delay or accept risk).

### 5. Indigenous Consent and Benefit-Sharing Tracking: Monitoring Beringia Indigenous Council Formation, Consent Agreements and Work-Window Compliance
**Monitoring Tools/Platforms:**

  - Beringia Indigenous Council Membership and Governance Document
  - Signed Consent Agreements with each Indigenous community (8-12 agreements)
  - Community Benefit Fund Allocation and Expenditure Tracker
  - Baseline Studies Co-Authoring Progress Log (marine mammals, subsistence harvesting, traditional knowledge)
  - Indigenous Workforce and Local-Hire Tracking Sheet (target: 20-30%)
  - Marine-Mammal Monitoring and Subsistence-Impact Incident Log

**Frequency:** Weekly tracking of Indigenous-engagement milestones during Months 0-12 (2026-10-12 to 2027-10-12) consent-agreement negotiation. Monthly Beringia Indigenous Council meetings and status updates (Months 6-12 = 2027-04-12 to 2027-10-12 and beyond). Quarterly Indigenous-stakeholder compliance reviews (Months 12, 24, 36 = 2027-10-12, 2028-10-12, 2029-10-12 onwards). Real-time monitoring of work-window compliance and subsistence impacts during construction (Months 30-180 = 2029-04-12 to 2041-10-12).

**Responsible Role:** Indigenous Stakeholder and Compliance Council (chaired by neutral Indigenous mediator) and Indigenous Engagement Specialist (Operations Council supporting role)

**Adaptation Process:** Consent-agreement negotiation tracked against Month 12 (2027-10-12) gate deadline. If any community withholds consent by Month 12 (2027-10-12), Indigenous Council escalates alignment or work-window dispute to Steering Committee for negotiation or design alternative (e.g., shift alignment to reduce impact, modify seasonal work windows). Benefit-Fund allocations reviewed quarterly with Indigenous Council co-governance; if fund balance or spending trajectory deviates from agreed annual allocation, corrective disbursements or schedule adjustments are made. Baseline studies co-authored with Indigenous researchers; publication and data-sharing disputes resolved through Community Advisory process. During construction, Indigenous-led marine-mammal monitoring triggers real-time work stoppages if protected species enter shutdown zones; stop-work incidents logged and subsistence-impact assessments conducted within 1 week. Unresolved Indigenous disputes or consent withdrawals >6 weeks trigger escalation to Steering Committee and potential design or permitting reconsideration.

**Adaptation Trigger:** Beringia Indigenous Council not formed by Month 6 (2027-04-12) escalates to Steering Committee for engagement intensification. Consent agreements not signed by >1 community by Month 12 (2027-10-12) triggers gate-readiness downgrade and potential Gate 2 deferral. Baseline studies delayed >2 months behind schedule activates accelerated co-authoring or alternative data sources. Benefit-Fund annual disbursement >USD 2 million behind schedule escalates to Finance Manager for corrective payment. Indigenous-led stop-work incidents unresolved >1 week trigger escalation to joint Operations Council and Beringia Council emergency meeting. Consent withdrawal or alignment dispute by any Indigenous community escalates to Steering Committee for government-level diplomatic resolution within 2 weeks.

### 6. Environmental Permitting and Marine-Mammal Protection Monitoring: Tracking Permit Milestones, Baseline Survey Progress and Compliance with Seasonal Work-Window Restrictions
**Monitoring Tools/Platforms:**

  - NEPA/EIA Permit Submission and Approval Timeline Tracker
  - Marine-Mammal Baseline Survey Progress Log (co-authored with Indigenous researchers)
  - Seasonal Work-Window Approval Calendar (with marine-mammal exclusion zones and acoustic shutdown triggers)
  - Real-Time Acoustic Monitoring Dashboard (passive listening stations, automated species detection)
  - Subsistence-Impact Assessment Reports (quarterly, co-authored with Indigenous monitors)
  - Stop-Work Incident Log (species sightings, acoustic measurements, closure triggers activated)

**Frequency:** Continuous environmental baseline surveys (Months 0-12 = 2026-10-12 to 2027-10-12). Monthly permit-approval status reviews (Months 0-18 = 2026-10-12 to 2028-04-12). Real-time acoustic monitoring and species-detection alerts during construction (Months 30-180 = 2029-04-12 to 2041-10-12). Quarterly subsistence-impact assessments (Months 12, 24, 36 onwards = 2027-10-12 onwards).

**Responsible Role:** Environmental and Permitting Lead (Operations Council) and Marine-Mammal Monitoring Coordinator (Indigenous co-leads)

**Adaptation Process:** Baseline surveys progress tracked against completion targets (marine-mammal surveys, fisheries assessments, water-quality baselines by Month 12 = 2027-10-12). If survey data arrival is delayed, preliminary permitting proceeds on interim data (framework permits at Months 6-9 = 2027-04-12 to 2027-07-12) with condition to update permits based on final surveys. Permit applications submitted at scheduled gates (framework Months 6-9 = 2027-04-12 to 2027-07-12, detailed marine Months 12-18 = 2027-10-12 to 2028-04-12) with regulator feedback incorporated iteratively. Seasonal work-window approvals updated annually based on latest migration and spawning data; acoustic-monitoring results trigger real-time work adjustments (if bowhead whales detected, impact piling halts automatically per pre-agreed threshold). Stop-work incidents and acoustic exceedances logged daily; monthly incident summaries trigger protocol review if patterns emerge (e.g., repeated species presence in previously excluded zones, indicating changed migration). Subsistence-impact reports compiled quarterly; significant impacts (harvest decline >10%, access restriction) trigger mitigation-program expansion (alternative harvesting areas, compensation).

**Adaptation Trigger:** Baseline survey >2 months behind schedule at Month 9 (2027-07-12) escalates to Environmental Lead for accelerated data collection. Permit application milestones missed (framework permits not submitted by Month 9 = 2027-07-12, detailed permits not submitted by Month 18 = 2028-04-12) triggers regulator engagement for expedited review or alternative permitting pathway. Regulator stop-work order (unscheduled closure due to unanticipated impact) lasts >3 days, requiring incident investigation and work-procedure modification within 1 week. Acoustic exceedances or species sightings in shutdown zones trigger immediate work cessation and 24-hour investigation. Subsistence-impact assessment showing harvest decline >10% or access restriction affecting >1 community escalates to Indigenous Council and Steering Committee for mitigation-program adjustment (cost and schedule implications).

### 7. Sanctions Licensing and Export-Control Compliance Monitoring: Tracking OFAC Approval, Pre-Approved Supplier List and Procurement Authorization Against Regulatory Milestones
**Monitoring Tools/Platforms:**

  - OFAC and Export-Control Licensing Pathway Document (updated monthly)
  - Pre-Approved Supplier and Contractor List (updated quarterly, with sanctions vetting status)
  - Procurement Authorization Checklist (each item requires compliance officer sign-off before order)
  - Export-Control Counsel Legal Opinion File (on specific transactions, if needed)
  - Sanctions Compliance Monitoring Dashboard (financing entities, equipment suppliers, key personnel)

**Frequency:** Monthly OFAC and export-control compliance status reviews (Months 0-24 = 2026-10-12 to 2028-10-12, then quarterly). Real-time procurement-authorization tracking: each order >USD 1 million requires Compliance Officer sign-off against pre-approved supplier list before purchase order release. Quarterly compliance audits of active contracts and vendor payments (Months 12-180 = 2027-10-12 to 2041-10-12). Emergency escalation within 24 hours if new sanctions are imposed on project-related entity or country.

**Responsible Role:** Compliance Officer (Risk Committee) and Risk and Insurance Committee Chair

**Adaptation Process:** OFAC and export-control guidance sought by Month 3 (2027-01-12); written licensing pathway and pre-approved supplier list obtained by Month 6 (2027-04-12). Pre-approved supplier list maintained and updated quarterly as new vendors are proposed or regulatory restrictions change. Each procurement action checked against current list; if supplier is not pre-approved, Compliance Officer either: (1) adds vendor to approved list if sanctions/export-control vetting clears, or (2) sources from alternative approved supplier without project delay. Financing entities (lenders, equity investors) continuously monitored for sanctions exposure; if sanctions-affected lender faces restrictions, Finance Manager identifies alternative lender within 2-week window. Personnel movement (binational team members crossing border) requires visa and work-permit authorization pre-cleared with project Compliance Officer; delays trigger escalation to Steering Committee for diplomatic intervention or remote-work arrangements.

**Adaptation Trigger:** OFAC guidance not received by Month 3 (2027-01-12) escalates to Project Sponsor for direct OFAC engagement. Pre-approved supplier list reduced by >20% due to new sanctions (e.g., supplier's parent company sanctioned) triggers emergency Compliance Officer alert and Finance/Logistics managers identify and onboard alternative suppliers within 2 weeks. Export-control license request rejected or delayed >6 weeks escalates to Steering Committee for policy decision (substitute supplier, design change, or funding/timeline impact). New sanctions imposed on any project financing entity, key contractor, or critical supplier triggers emergency Risk Committee meeting within 24 hours; if impact is existential (financing lender becomes unavailable, critical supplier blacklisted), escalate to Steering Committee and diplomatic channels for exemption request or project restructuring. Personnel visa/work-permit authorization delayed >2 weeks triggers escalation to Project Sponsor for diplomatic resolution or remote-work protocol activation.