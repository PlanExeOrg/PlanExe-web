## Primary Decisions
The vital few decisions that have the most impact.


The Critical levers address the project's core tensions: capital exposure versus schedule certainty (configuration, capital stack), political optionality versus committed delivery (gating, legal vehicle), and safety margin versus cost (design envelope). High levers cover execution and bankability trade-offs: risk allocation, logistics, Indigenous consent, and revenue underwriting. Missing dimensions: explicit surveys and data acquisition for design freeze, and supply-chain and export-control sourcing of materials.

### Decision 1: Crossing Configuration: Bridge, Tunnel, or Staged Hybrid
**Lever ID:** `afddd3d9-08ea-4f16-bda5-c7c8c5237cf3`

**The Core Decision:** Selects the structural architecture of the 85 km link and the traffic modes it carries from opening day. It is the anchor decision that sizes the supply chain, number of specialist contractors and interface count. Success metrics: schedule certainty, capital at risk before first revenue, share of alignment shielded from ice strike, and the ability to add capacity in later phases without rebuilding foundations.

**Why It Matters:** Fixes how much of the 85 km alignment is suspension span versus immersed tube, and whether road, rail, or both are carried. The strait is shallow (roughly 30-50 m average depth), which favors immersed-tube and island-supported solutions, but the mix sets exposure to drifting ice, seismic loading and cost. A heavier tunnel share reduces ice-strike risk but concentrates ventilation, fire-safety and dewatering complexity underwater.

**Strategic Choices:**

1. Build the full hybrid as specified, pairing long suspension spans with immersed-tube sections and carrying both road and rail from first opening, accepting maximum capital exposure up front.
2. Build a rail-and-utility immersed tunnel first across the shallow central section, with island foundations sized so suspension spans and road lanes can be added in a later phase.
3. Replace the long suspension spans with a chain of artificial islands joined by short tunnel and causeway segments, using the islands as ice-defense, maintenance and ventilation stations.

**Trade-Off / Risk:** The hybrid looks balanced on paper, but two very different structure types double the specialist supply chains and interface risks, so a simpler single-mode crossing may beat it on schedule certainty even if it carries less.

**Strategic Connections:**

**Synergy:** Amplifies Arctic Construction Logistics and Island Strategy, since island-based or staged options define the yard, island and vessel needs, and enables Energy and Fiber Co-Location Corridor by fixing where utility bores and cable ducts sit.

**Conflict:** Trades off against Capital Stack and Sanctions-Compatible Financing, because the full hybrid maximizes upfront capital exposure. Also constrains Ice-Load and Seismic Design Envelope, since structure mix changes which load cases govern and how conservative design can be.

**Justification:** *Critical*, Anchor decision that sizes supply chain, interfaces and capital at risk. It feeds logistics, utility corridor and design envelope, and trades off directly against financing. Staging the structure controls the core schedule-certainty versus capacity and capital-exposure tension of the whole program.

### Decision 2: Ice-Load and Seismic Design Envelope
**Lever ID:** `e3bfabbf-4c1a-4034-ad18-fb93abb7cca8`

**The Core Decision:** Defines the load cases, return periods and redundancy philosophy that govern pier geometry, tunnel element weight, foundation depth and permafrost treatment. Its scope includes how climate-driven shifts in ice regime are handled over a century-scale design life. Success metrics: demonstrable life-safety margin, repairability after rare events, cost per pier, and acceptance by lenders, insurers and both national regulators.

**Why It Matters:** Sets the return period and load cases that drive pier geometry, tunnel element weight and foundation depth. Ice-floe impact, ice ridging and permafrost thaw interact with seismic ground response, so a conservative envelope raises materials and marine-works cost across every pier. A lean envelope lowers capex but leaves little margin if climate-driven ice behavior departs from the historic record.

**Strategic Choices:**

1. Adopt a deterministic, extreme-event envelope with full redundancy, sizing every pier and tunnel element for the worst credible simultaneous ice and seismic combination.
2. Adopt a performance-based envelope with sacrificial ice-deflection structures upstream of piers, accepting repairable damage in rare events while protecting life-safety and traffic continuity.
3. Adopt an observational design approach, instrumenting the alignment for several seasons before freezing the design, and reserving foundation capacity that can be upgraded as ice and ground data accumulate.

**Trade-Off / Risk:** A more conservative envelope buys safety but may price the project out of financing, while an observational approach delays design freeze and only works if monitoring data genuinely arrive before foundations are committed.

**Strategic Connections:**

**Synergy:** Enables Emergency Response and Winter Closure Doctrine by defining which damage states are tolerated and when closure triggers apply, and supports Marine Mammal and Fisheries Protection Operating Envelope where sacrificial ice-deflection structures double as exclusion zones.

**Conflict:** Conflicts with Capital Stack and Sanctions-Compatible Financing and Contracting Method and Construction Risk Allocation: conservative envelopes inflate cost and strain lenders, while observational approaches delay design freeze and complicate fixed-price risk transfer.

**Justification:** *Critical*, Sets the safety-versus-cost tradeoff driving every pier, tunnel element and foundation. It conflicts with financing and contract risk transfer, and enables the emergency doctrine and wildlife exclusion zones. Lender, insurer and regulator acceptance hinges on it.

### Decision 3: Binational Legal Vehicle and Sovereignty Seam
**Lever ID:** `0422f13a-ff57-40a4-bbed-ac3ceeed0902`

**The Core Decision:** Chooses the legal personality, ownership and regulatory regime that govern the structure across the maritime boundary. It decides whether one rulebook or two applies to safety, liability, tolling and dispute resolution, and how resilient the project is to political change. Success metrics: ratification feasibility, clarity of liability at the seam, bankability for lenders, and speed to a legally operable entity.

**Why It Matters:** Determines who owns, regulates and polices the structure where it crosses the maritime boundary and the two national jurisdictions. A treaty-based joint authority offers one rulebook but needs ratification in both capitals; separate national concessions are faster to set up but leave a handover seam for customs, security, liability and emergency response.

**Strategic Choices:**

1. Negotiate a bilateral treaty creating a single joint ownership and operating authority with its own legal personality, a unified safety code and a treaty-protected dispute-resolution body.
2. Grant two parallel national concessions that meet at the boundary, with interoperable technical standards and a mutual handover protocol, avoiding any shared sovereignty over the structure.
3. Place ownership in a neutral special-purpose entity chartered under a third-country or international legal regime, with US and Russian governments holding contractual rather than sovereign rights.

**Trade-Off / Risk:** A single treaty gives clean governance but hands each legislature a veto over a project that must survive shifting politics, whereas parallel concessions are easier to pass yet embed a permanent seam where failures will be argued.

**Strategic Connections:**

**Synergy:** Enables Mid-Strait Border, Customs and Security Posture by supplying the legal authority for customs and policing arrangements, and strengthens Traffic Demand Underwriting and Revenue Certainty by giving a single, enforceable toll and concession framework.

**Conflict:** Constrains Political Gating and Confidence-Building Sequence, since treaty ratification becomes a gate that may stall the schedule, and complicates Capital Stack and Sanctions-Compatible Financing, because ownership structure determines which entities and lenders face sanctions exposure.

**Justification:** *Critical*, Foundational governance hub: defines ownership, liability and rulebook at the boundary. It enables border posture and a single toll framework, while gating the schedule through ratification and shaping sanctions exposure for lenders. Without it nothing else is bankable.

### Decision 4: Capital Stack and Sanctions-Compatible Financing
**Lever ID:** `dea94a14-ca94-4f6e-ace3-0b795bdf6354`

**The Core Decision:** Determines who supplies debt and equity, in what sequence, and under which sanctions licenses and export-control regimes. It shapes security packages, guarantees and the availability or toll payments lenders require. Success metrics: percentage of capex with licensed and ring-fenced commitments, financing cost, resilience to a single government withdrawing, and time from decision to financial close.

**Why It Matters:** Decides who funds construction and on what terms, given that US and Russian financial institutions and sovereign funds operate under sanctions and export-control constraints that may require licensing. Reliance on one government's fund concentrates political leverage; broader lender pools lengthen negotiation and complicate security packages. The choice also shapes the tolling and freight revenue guarantees lenders will demand.

**Strategic Choices:**

1. Lead with sovereign-fund equity from both governments, backed by long-term availability payments, and use multilateral banks only for tranches that can be licensed and ring-fenced.
2. Assemble a third-country investor consortium of infrastructure funds, development banks and export-credit agencies, with both governments contributing land, rights-of-way and guarantees rather than cash.
3. Finance in revenue-first segments, using telecom fiber, pipeline and cable leases to fund early works so each later construction phase is paid by proven cash flow.

**Trade-Off / Risk:** Sanctions licensing is the gating uncertainty, and a financing structure that quietly assumes it will be resolved turns a funding plan into a political bet; revenue-first staging reduces that bet but slows the main crossing.

**Strategic Connections:**

**Synergy:** Amplifies Energy and Fiber Co-Location Corridor, because early pipeline, cable and fiber leases generate cash flow that funds later phases, and reinforces Traffic Demand Underwriting and Revenue Certainty by tying lender protections to contracted revenue.

**Conflict:** Trades off against Political Gating and Confidence-Building Sequence and Crossing Configuration: revenue-first staging slows the main crossing, while lenders seeking firm commitments resist gates and the full hybrid's large upfront capital need.

**Justification:** *Critical*, Highly connected hub: sanctions licensing is the gating uncertainty. It trades off against configuration, gating and contracting, and draws synergy from utility revenue and demand underwriting. It determines whether the project reaches financial close and survives one government withdrawing.

### Decision 5: Political Gating and Confidence-Building Sequence
**Lever ID:** `7fd2828c-fb90-4517-ad59-bb14f7576381`

**The Core Decision:** Sets how irreversible capital is released against diplomatic, legal, financial and technical conditions across the 2026-2041 program. It frames the project as infrastructure or as a diplomatic instrument and fixes the cost of stopping. Success metrics: sunk cost at each gate, gate clearance time, preserved optionality, and contractor and lender willingness to engage despite conditional commitments.

**Why It Matters:** Controls whether the 2026-2041 schedule commits large irreversible capital early or releases it through gates tied to diplomatic, legal and financial conditions. Early gates keep exit costs low and let design and surveys proceed, but they stretch the timeline and may deter contractors and lenders seeking firm commitments. The sequence also signals whether this is an infrastructure project or a diplomatic instrument.

**Strategic Choices:**

1. Commit to a fixed 15-year program with full design, procurement and construction contracts signed early, using schedule certainty to attract contractors and lock in prices.
2. Stage the program through explicit decision gates covering treaty ratification, sanctions licensing, financing close and survey results, with paid pause and exit provisions at each gate.
3. Open with non-structural confidence-building work, such as a joint Arctic research station, shared geotechnical survey and a fiber cable, so cooperation is demonstrated before any bridge capital is committed.

**Trade-Off / Risk:** Gating protects capital but may never clear if the first gate depends on diplomatic conditions outside the project's control, while a fixed program looks decisive until a political break strands sunk costs on both shores.

**Strategic Connections:**

**Synergy:** Amplifies Indigenous Consent and Benefit-Sharing Architecture by allowing consent and baseline studies to precede construction, and enables Energy and Fiber Co-Location Corridor as a non-structural early step that demonstrates cooperation before bridge capital.

**Conflict:** Conflicts with Contracting Method and Construction Risk Allocation, since gates and paid-pause provisions raise price premiums and weaken fixed-price terms, and with Capital Stack and Sanctions-Compatible Financing when lenders need firm, early commitments.

**Justification:** *Critical*, Controls the central tension between committing irreversible capital early and preserving optionality under geopolitical risk. It conflicts with contracting and financing certainty, and enables Indigenous consent and early utility steps. It defines sunk cost, timeline and whether the project proceeds at all.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Arctic Construction Logistics and Island Strategy
**Lever ID:** `60eba1c3-0591-48ba-b229-bb0b09989037`

**The Core Decision:** Sets the production geography, ice-class fleet and seasonal work calendar on which every marine activity depends. Scope covers yard and camp siting, ports, tow routes and use of landfast ice for island foundations. Success metrics: share of planned placements completed per open-water window, tow-window reliability, schedule float preserved after a lost season, and delivered cost per element against baseline.

**Why It Matters:** Defines where tunnel elements, steel and concrete are made and how they reach a site with short open-water seasons, little existing port or road infrastructure on either shore and heavy ice. In-region fabrication cuts transport risk but requires building yards and camps in remote areas; remote yards ease site conditions but add long tow and weather-window risk.

**Strategic Choices:**

1. Build large fabrication yards, ports and worker camps on both coasts, producing tunnel elements and prefabricated spans locally and sustaining year-round work with icebreaker support.
2. Fabricate tunnel elements and bridge segments in existing Pacific shipyards and tow them to site during the open-water window, minimizing permanent infrastructure on the Arctic coasts.
3. Use winter ice as a working platform, staging heavy equipment and island foundations from landfast ice and reserving open-water months for marine placement and tunnel immersion.

**Trade-Off / Risk:** Remote prefabrication reduces camp and yard burden but depends on narrow tow windows and ice-class fleets, so a single lost season could idle the whole marine spread and push the schedule back a year.

**Strategic Connections:**

**Synergy:** Gives Contracting Method and Construction Risk Allocation a concrete logistics baseline that bidders can price, and informs Crossing Configuration: Bridge, Tunnel, or Staged Hybrid by showing which element mix fits the realistic short marine season.

**Conflict:** Competes with Marine Mammal and Fisheries Protection Operating Envelope, because noise limits and vessel-traffic restrictions squeeze the same short open-water season, and strains Indigenous Consent and Benefit-Sharing Architecture where yards and camps touch subsistence areas.

**Justification:** *High*, Governs production geography and the short open-water season on which every marine activity depends. It gives bidders a priceable baseline and competes with wildlife limits and Indigenous subsistence areas. Strong execution lever, but largely derived from the configuration decision.

### Decision 7: Indigenous Consent and Benefit-Sharing Architecture
**Lever ID:** `add4e032-39fc-46f3-b4ee-344fa94609ac`

**The Core Decision:** Defines the legal and economic standing of Indigenous communities on both shores, from consultation to shared ownership to binding consent. It must reconcile differing US and Russian rights frameworks into a workable arrangement. Success metrics: agreements executed before permitting milestones, Indigenous participation in monitoring and local hire, community benefit disbursed, and permitting completed without litigation or injunction.

**Why It Matters:** Sets whether Indigenous communities on both sides of the strait are consulted, compensated or hold real decision rights over the alignment, marine impacts and subsistence use. Stronger rights can slow permitting but reduce litigation and legitimacy risk later. The two countries have different legal frameworks for Indigenous rights, so a single approach must be reconciled with each.

**Strategic Choices:**

1. Meet statutory consultation requirements in each jurisdiction through public hearings and impact-benefit agreements, keeping decision authority with the project owner and regulators.
2. Offer community equity stakes and revenue shares, and fund Indigenous-led marine mammal monitoring and subsistence-protection programs as a condition of construction seasons.
3. Establish a binding cross-border Beringia Indigenous council with free, prior and informed consent authority over alignment changes, seasonal work windows and operating restrictions.

**Trade-Off / Risk:** A binding consent council builds legitimacy but gives a body spanning two legal systems effective veto power over the schedule, while minimal consultation is quicker until opposition surfaces during permitting or litigation.

**Strategic Connections:**

**Synergy:** Amplifies Marine Mammal and Fisheries Protection Operating Envelope, since Indigenous-led monitoring brings traditional knowledge and credibility, and supports Political Gating and Confidence-Building Sequence by supplying a visible legitimacy milestone for both governments.

**Conflict:** Constrains Arctic Construction Logistics and Island Strategy and Contracting Method and Construction Risk Allocation: consent authority over work windows or alignment changes creates schedule uncertainty that contractors cannot price and that tightens an already narrow construction season.

**Justification:** *High*, Controls legitimacy and permitting risk across two legal systems. It amplifies wildlife protection and gives gating a visible milestone, but consent authority over work windows creates schedule uncertainty that constrains logistics and contracting. Major litigation and social-licence lever.

### Decision 8: Energy and Fiber Co-Location Corridor
**Lever ID:** `842185e9-1da4-4be5-99c5-eee51d0eb5a6`

**The Core Decision:** Chooses which pipelines, power cables and fiber share the crossing, which fixes the non-toll revenue base and the tunnel's safety classification. Scope includes gallery segregation, leak detection, isolation, landing rights and tenant selection. Success metrics: share of revenue from utilities, contracted capacity before final investment decision, safety certification achieved, and demonstrable compliance with applicable sanctions regimes.

**Why It Matters:** Deciding which pipelines, power cables and telecom fiber share the crossing determines the energy-transport and telecom revenue streams and the tunnel's safety classification. Co-locating hydrocarbon or hydrogen lines with passenger traffic imposes separation, explosion-venting and emergency-egress requirements. Utilities add a second customer class but tie the crossing's security to energy politics and sanctions regimes.

**Strategic Choices:**

1. Limit utilities to telecom fiber and electric interconnection cables carried in dedicated service galleries, excluding pressurized hydrocarbon or hydrogen pipelines from the crossing entirely.
2. Include a segregated pipeline gallery within the immersed-tube tunnel for natural gas or hydrogen, with independent leak detection and isolation from the traffic bores.
3. Lease an empty utility conduit and landing rights to third-party subsea cable and energy operators as a open-access corridor, letting demand rather than the project define the utility mix.

**Trade-Off / Risk:** Energy co-location promises a revenue stream beyond tolls, but pipeline safety separation inflates tunnel scope, and any energy flow routed through a US-Russia link inherits sanctions exposure the project cannot hedge.

**Strategic Connections:**

**Synergy:** Strengthens Traffic Demand Underwriting and Revenue Certainty by adding a utility customer class with long-term leases, and supports Capital Stack and Sanctions-Compatible Financing by offering lenders a revenue source less tied to traffic forecasts.

**Conflict:** Complicates Emergency Response and Winter Closure Doctrine because hydrocarbon or hydrogen galleries add fire and explosion scenarios, and inflates tunnel scope under Crossing Configuration: Bridge, Tunnel, or Staged Hybrid, raising cost and interface complexity.

**Justification:** *Medium*, Adds a non-toll revenue class and early cash flow that supports financing and demand underwriting. However, hydrocarbon galleries inflate scope and safety complexity and add sanctions exposure. Valuable optimization of revenue and safety classification, not a foundational pillar.

### Decision 9: Mid-Strait Border, Customs and Security Posture
**Lever ID:** `e2716175-fcf0-4821-8192-37a6ead5d27a`

**The Core Decision:** Decides where immigration, customs and security inspection occur on a structure that contains an international boundary, and who may close it. Though often treated as operational detail, it governs plaza footprint, gating hardware and throughput. Success metrics: freight clearance time, closure protocols both governments accept, plaza land take, and sign-off from defense and border agencies.

**Why It Matters:** A fixed link places an international boundary inside the structure, so the plan must decide where immigration, customs and security inspection occur and who may close the crossing. A strong inspection and closure regime reassures national security agencies on both sides but throttles throughput and weakens the trade-corridor case. A light-touch regime attracts traffic but may be unacceptable to defense establishments.

**Strategic Choices:**

1. Locate full customs and immigration processing at plazas on each shore with sealed-transit freight lanes across the crossing, so no inspection takes place inside the structure itself.
2. Establish a binational joint border facility on an artificial island at the midpoint where both states inspect in a single shared process, minimizing duplicate checks.
3. Restrict the crossing to pre-cleared, scheduled and electronically sealed freight and credentialed passengers, with physical barriers and closure gates the two states can each operate independently.

**Trade-Off / Risk:** Border design is often deferred as an operational detail, yet it drives plaza footprint, tunnel gating and throughput, and the closure authority each government demands may undercut the reliability that freight shippers need.

**Strategic Connections:**

**Synergy:** Reinforces Political Gating and Confidence-Building Sequence by giving security agencies a credible inspection and closure regime to approve at each stage, and underpins Traffic Demand Underwriting and Revenue Certainty through predictable, bankable processing times.

**Conflict:** Trades off against Traffic Demand Underwriting and Revenue Certainty, since stringent inspection and independent closure rights throttle throughput, and complicates Emergency Response and Winter Closure Doctrine where gates and barriers impede evacuation and cross-border responder access.

**Justification:** *Medium*, Drives throughput, plaza footprint and closure authority, trading security assurance against freight revenue. It links to gating and demand, but is largely an operational design choice that follows from the legal vehicle and is settled later in the program.

### Decision 10: Contracting Method and Construction Risk Allocation
**Lever ID:** `9f88b363-8732-4070-b255-8662c0949e7d`

**The Core Decision:** Packages design, procurement and construction to decide who carries ice, seismic, ground and geopolitical risk, and how early contractors shape design. Scope covers contract form, liability caps, independent engineering and interface management across two legal systems. Success metrics: bidder depth, contingency retained by the owner, change-order and claim levels, and cost and schedule variance against the baseline.

**Why It Matters:** How design, procurement and construction are packaged sets who carries ice, seismic, ground and geopolitical risk, and how early contractors can influence the design. A single design-build contractor simplifies accountability but few firms can bear unlimited Arctic risk. Splitting packages by tunnel, bridge and islands spreads risk but multiplies interfaces across two legal systems and currencies.

**Strategic Choices:**

1. Award a single binational design-build contract to a consortium with a capped liability and an independent engineer, trading price certainty for a premium and a narrow bidder pool.
2. Run an alliance-style contract in which owner, designers and contractors share cost overruns and savings under open-book accounting from the earliest design stage.
3. Procure separate packages for islands, tunnel elements and bridge spans through staged competitions, with an owner-retained integrator managing interfaces and holding the geopolitical and ice-condition risk.

**Trade-Off / Risk:** Contract structure decides who absorbs the risks nobody can price, but no bidder will accept unlimited ice, seismic and sanctions risk, so the residual falls back on the sponsors regardless of the model chosen.

**Strategic Connections:**

**Synergy:** Works with Ice-Load and Seismic Design Envelope, because early contractor involvement tests buildability of design criteria, and with Arctic Construction Logistics and Island Strategy, which supplies the logistics assumptions bidders must price.

**Conflict:** Pulls against Capital Stack and Sanctions-Compatible Financing, since lenders want fixed-price certainty while alliance or split packages leave overruns open, and burdens Binational Legal Vehicle and Sovereignty Seam with multiple interfaces across jurisdictions and currencies.

**Justification:** *High*, Decides who absorbs ice, seismic and geopolitical risk, pulling against lender fixed-price demands and gating provisions. It connects design envelope, logistics, wildlife limits and legal seam. Important risk-transfer trade-off, though residual risk falls back on sponsors regardless.

### Decision 11: Marine Mammal and Fisheries Protection Operating Envelope
**Lever ID:** `9ab49f42-bc3c-4e0a-a4bc-ce1f85eb3c1b`

**The Core Decision:** Translates wildlife and subsistence protection into enforceable permit conditions: noise thresholds, shutdown zones, vessel speed and routing rules, and seasonal restrictions on piling, dredging and trench work. Success is measured by work days actually achieved against plan, zero regulator stop orders, documented disturbance of whales, walrus and seals, and continuity of community subsistence harvests as reported by Indigenous partners.

**Why It Matters:** Sets the seasonal, acoustic and vessel-traffic limits under which piling, dredging and tunnel trench work may proceed. Tight limits protect migrating whales, walrus, seals and subsistence fisheries and strengthen the social licence. They also shorten the usable work windows in an already short Arctic season, which pushes schedule and cost upward.

**Strategic Choices:**

1. Adopt a fixed seasonal exclusion calendar that halts impact piling and dredging during peak migration periods, and plan the construction schedule around the remaining windows.
2. Deploy real-time passive acoustic monitoring with Indigenous observers and vessel-mounted marine mammal observers, and authorize work dynamically against live animal presence rather than a fixed calendar.
3. Replace impact piling with vibratory, drilled or prefabricated foundation methods and use bubble curtains throughout, accepting higher unit cost to keep nearly continuous work windows.

**Trade-Off / Risk:** Dynamic monitoring sounds flexible, but it hands stop-work authority to field data and observers, which can produce unpredictable idle time that fixed-price contractors will price in as a heavy risk premium.

**Strategic Connections:**

**Synergy:** Strengthens Indigenous Consent and Benefit-Sharing Architecture, since Indigenous observers and co-management give the limits legitimacy. Also informs Arctic Construction Logistics and Island Strategy by fixing which foundation methods and work windows the island schedule can assume.

**Conflict:** Directly strains Contracting Method and Construction Risk Allocation, because observer-triggered stop-work authority creates idle time contractors price as risk premium. It also shortens the already limited season that Arctic Construction Logistics and Island Strategy depends on.

**Justification:** *Medium*, Sets permit-driven work windows and stop-work authority that squeeze the short season and raise contractor premiums. Strong links to Indigenous consent and logistics, but largely a constraint on execution rather than a strategic driver of the project's direction.

### Decision 12: Traffic Demand Underwriting and Revenue Certainty
**Lever ID:** `fbb05080-1b9f-4b0b-8cb6-46eeb7666c0a`

**The Core Decision:** Chooses the revenue basis on which debt is sized and lenders are asked to commit: user tolls, contracted capacity, or government availability payments. Because no comparable crossing exists, and demand also depends on road and rail feeders at both approaches, the choice largely determines bankability. Key metrics are downside-case debt service coverage, the share of revenue contractually committed, and lender acceptance of the traffic studies.

**Why It Matters:** Fixes which traffic and revenue assumptions the financing is built upon: tolls, freight, pipeline and fiber access fees, or availability-style payments. Conservative underwriting makes the project bankable but may show that user revenue alone cannot cover cost. Aggressive assumptions improve headline returns but expose lenders to demand shortfalls in a market with no operating precedent.

**Strategic Choices:**

1. Underwrite on user-pay tolls and freight charges only, using independent traffic studies with conservative downside cases, and size debt strictly to that revenue stream.
2. Replace volume-based revenue with a binational availability payment from both governments, so that the operator is paid for keeping the link open and safe regardless of traffic.
3. Pre-sell long-term capacity rights in advance to freight forwarders, energy shippers and data carriers through take-or-pay contracts, and use the contracted capacity as the anchor for debt sizing.

**Trade-Off / Risk:** Availability payments give lenders certainty, but they convert a commercial project into a long-term sovereign liability, and take-or-pay contracts only hold if counterparties remain solvent and permitted to trade across the link.

**Strategic Connections:**

**Synergy:** Amplifies Capital Stack and Sanctions-Compatible Financing, since contracted or availability-backed revenue lets lenders size debt with confidence. Pairs with Energy and Fiber Co-Location Corridor, which adds pipeline and fiber access fees as non-traffic revenue.

**Conflict:** Depends on Political Gating and Confidence-Building Sequence, because availability payments and take-or-pay deals require sovereign commitments that gating may delay. Restrictive Mid-Strait Border, Customs and Security Posture could also throttle freight volumes the revenue case assumes.

**Justification:** *High*, Determines bankability in a market with no precedent: tolls versus availability payments versus take-or-pay. It amplifies the capital stack and pairs with utility revenue, but depends on gating and border posture. Controls the commercial-versus-sovereign-liability tension.

### Decision 13: Emergency Response and Winter Closure Doctrine
**Lever ID:** `d1ba1a71-0a12-4a77-b8c6-b1221e5ef37c`

**The Core Decision:** Sets the operating safety regime for a link where help is hundreds of kilometers from major centers: tunnel fire and ventilation systems, rescue stations, de-icing, and objective closure triggers for storms and ice. It must also settle who commands an incident across the national seam. Metrics are response time to any point on the crossing, annual closure hours, availability percentage, and incident outcomes.

**Why It Matters:** Establishes how the crossing is kept safe and operable once open: fire and life-safety systems in the tunnel, rescue capability, de-icing, and rules for closing during storms and ice events. A strict doctrine protects lives and assets but reduces availability and revenue-earning hours. A lean doctrine raises uptime but depends on response resources that are hundreds of kilometers from major population centers.

**Strategic Choices:**

1. Maintain permanently staffed rescue and maintenance stations at both shores and at mid-strait, with dedicated fire, medical and recovery vehicles and a binational incident command center.
2. Operate under conservative weather and ice closure thresholds with convoy-only winter traffic, and accept lower availability in exchange for a smaller emergency footprint.
3. Rely on autonomous inspection drones, smart sensors and remotely operated recovery systems to detect and respond to incidents, with human crews on stand-by only at the shore terminals.

**Trade-Off / Risk:** Remote autonomy reduces staffing in a harsh setting, but if an incident occurs deep in the tunnel or on the span, the response time of shore-based crews becomes the binding safety constraint.

**Strategic Connections:**

**Synergy:** Builds on Crossing Configuration: Bridge, Tunnel, or Staged Hybrid, since the span and tunnel mix determines the life-safety systems required. Mid-strait stations can also host the posts required by Mid-Strait Border, Customs and Security Posture, sharing cost and staffing.

**Conflict:** Conservative closure rules reduce revenue-earning hours and undercut Traffic Demand Underwriting and Revenue Certainty. Permanently staffed mid-strait stations raise operating cost and complicate Binational Legal Vehicle and Sovereignty Seam, which must allocate command and liability.

**Justification:** *Low*, Operational safety regime that largely follows from configuration and design envelope choices. It affects availability and revenue at the margin and is needed for certification, but is decided later and is downstream of the structural and legal levers.
