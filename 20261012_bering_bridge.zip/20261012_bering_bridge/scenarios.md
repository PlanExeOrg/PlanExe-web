# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** Extremely high. A permanent 85 km binational crossing of the Bering Strait combining suspension spans and immersed-tube tunnel, with road, rail, energy and fiber corridors. Programme runs roughly Months 0-180 (2026-2041 horizon), spans two sovereign jurisdictions and requires artificial islands, heavy marine works and a century-scale design life. Geopolitical and economic transformation is the stated purpose.

**Risk and Novelty:** Very high risk and no direct precedent at this scale in a drifting-ice, seismic, permafrost environment. Exposure is dominated by non-technical risks: US-Russia political tension, sanctions and export controls on financing and equipment, treaty ratification, and Indigenous consent. Technical risk (ice-floe loads, thaw, seismic ground response) is also significant and data are thin. The plan itself includes a risk register and contingency planning, signalling awareness that the schedule is not guaranteed.

**Complexity and Constraints:** Very high complexity. Two structure types double specialist supply chains and interfaces; remote Arctic logistics with a short construction season; two regulatory regimes; PPP, sovereign-fund and multilateral-bank financing that must be sanctions-compatible; binational governance and joint ownership. The stated 2026-2041 window and an 'ASAP' start conflict with the time needed for treaties, licensing, baseline surveys and financial close.

**Domain and Tone:** Business and strategic planning for mega-infrastructure with a geopolitical dimension. Formal, action-oriented, investor- and government-facing tone requiring a comprehensive document with cost tables, a Gantt-style timeline and a risk matrix. Physical-world execution at an Arctic site.

**Holistic Profile:** A moonshot, binational mega-infrastructure programme whose end state is the full hybrid crossing, but whose feasibility hinges on political, sanctions and data uncertainties outside project control. It needs an approach that preserves the full ambition while staging capital, absorbing sanctions and ratification risk, and letting site data inform design before irreversible commitments.

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Gated Foundation
**Strategic Logic:** Build a rail-and-utility tunnel first on foundations sized for later suspension spans and road lanes, and let monitoring data inform the design before foundations are committed. A neutral special-purpose entity and a third-country investor consortium keep the project sanctions-compatible, while explicit decision gates with paid pause and exit provisions cap sunk-cost exposure. This path trades the full crossing's headline capacity for a deliverable first phase and real option value.

**Fit Score:** 8/10

**Why This Path Was Chosen:** Retains the hybrid end state through foundations sized for later suspension spans and road lanes, while gates, a neutral entity, a third-country consortium and observational design directly address sanctions, ratification and ice/seismic data uncertainty; the cost is a longer path to full capacity and some strain on the 2026-2041 window.

**Key Strategic Decisions:**

- **Crossing Configuration: Bridge, Tunnel, or Staged Hybrid:** Build a rail-and-utility immersed tunnel first across the shallow central section, with island foundations sized so suspension spans and road lanes can be added in a later phase.
- **Ice-Load and Seismic Design Envelope:** Adopt an observational design approach, instrumenting the alignment for several seasons before freezing the design, and reserving foundation capacity that can be upgraded as ice and ground data accumulate.
- **Binational Legal Vehicle and Sovereignty Seam:** Place ownership in a neutral special-purpose entity chartered under a third-country or international legal regime, with US and Russian governments holding contractual rather than sovereign rights.
- **Capital Stack and Sanctions-Compatible Financing:** Assemble a third-country investor consortium of infrastructure funds, development banks and export-credit agencies, with both governments contributing land, rights-of-way and guarantees rather than cash.
- **Political Gating and Confidence-Building Sequence:** Stage the program through explicit decision gates covering treaty ratification, sanctions licensing, financing close and survey results, with paid pause and exit provisions at each gate.

**The Decisive Factors:**

- **Ambition preserved, risk staged:** foundations sized for later suspension spans and road lanes keep the plan's 85 km hybrid as the end state while a rail-and-utility tunnel delivers a bankable first phase.
- **Matches the dominant risks:** sanctions, ratification and political tension are the gating uncertainties; explicit gates with paid pause and exit provisions cap sunk cost instead of betting on them.
- **Handles technical unknowns:** observational design lets ice, permafrost and seismic data inform the design freeze before foundations are committed.
- **Financing fit:** a neutral entity and third-country consortium align with the plan's PPP and multilateral-bank model and remain licensable.
- **Why not The Pioneer's Span:** full up-front capital and single-treaty dependence strand costs if either government withdraws.
- **Why not The Cooperation-First Consolidator:** drops the suspension spans and defers the crossing, undermining the plan's strategic-priority and trade-corridor objectives.

---
## Alternative Paths
### The Pioneer's Span
**Strategic Logic:** Commit to the full hybrid crossing under a single treaty authority, funded by sovereign equity and locked in by early contracts, so that schedule certainty and a unified safety code drive the project to completion. The performance-based envelope with sacrificial ice-deflection structures keeps cost and design freeze on a fast track, but the plan is a direct political bet: it depends on treaty ratification and sanctions licensing resolving in the project's favour, with sunk costs stranded if they do not.

**Fit Score:** 4/10

**Assessment of this Path:** Matches the plan's literal specification (full hybrid, joint authority, sovereign funds, fixed 15-year schedule) but is an explicit political bet on ratification and sanctions licensing, with maximum capital exposure and stranded-cost risk that the plan's own risk register flags.

**Key Strategic Decisions:**

- **Crossing Configuration: Bridge, Tunnel, or Staged Hybrid:** Build the full hybrid as specified, pairing long suspension spans with immersed-tube sections and carrying both road and rail from first opening, accepting maximum capital exposure up front.
- **Ice-Load and Seismic Design Envelope:** Adopt a performance-based envelope with sacrificial ice-deflection structures upstream of piers, accepting repairable damage in rare events while protecting life-safety and traffic continuity.
- **Binational Legal Vehicle and Sovereignty Seam:** Negotiate a bilateral treaty creating a single joint ownership and operating authority with its own legal personality, a unified safety code and a treaty-protected dispute-resolution body.
- **Capital Stack and Sanctions-Compatible Financing:** Lead with sovereign-fund equity from both governments, backed by long-term availability payments, and use multilateral banks only for tranches that can be licensed and ring-fenced.
- **Political Gating and Confidence-Building Sequence:** Commit to a fixed 15-year program with full design, procurement and construction contracts signed early, using schedule certainty to attract contractors and lock in prices.

### The Cooperation-First Consolidator
**Strategic Logic:** Prove cooperation before committing bridge capital: open with a joint research station, shared geotechnical survey and fiber cable, and let their lease revenue fund each later construction phase. The crossing itself becomes a chain of islands joined by short tunnel and causeway segments, built under two parallel national concessions and a conservative deterministic envelope that avoids reliance on shared sovereignty, large-scale financing or unproven design assumptions. Cost and political exposure stay lowest, at the price of the slowest and least ambitious crossing.

**Fit Score:** 5/10

**Assessment of this Path:** Lowest political and capital exposure, but drops the suspension spans, defers the main crossing behind confidence-building steps and revenue-funded staging, and so is the slowest and least aligned with the plan's strategic-priority, trade-corridor and 2041 ambition.

**Key Strategic Decisions:**

- **Crossing Configuration: Bridge, Tunnel, or Staged Hybrid:** Replace the long suspension spans with a chain of artificial islands joined by short tunnel and causeway segments, using the islands as ice-defense, maintenance and ventilation stations.
- **Ice-Load and Seismic Design Envelope:** Adopt a deterministic, extreme-event envelope with full redundancy, sizing every pier and tunnel element for the worst credible simultaneous ice and seismic combination.
- **Binational Legal Vehicle and Sovereignty Seam:** Grant two parallel national concessions that meet at the boundary, with interoperable technical standards and a mutual handover protocol, avoiding any shared sovereignty over the structure.
- **Capital Stack and Sanctions-Compatible Financing:** Finance in revenue-first segments, using telecom fiber, pipeline and cable leases to fund early works so each later construction phase is paid by proven cash flow.
- **Political Gating and Confidence-Building Sequence:** Open with non-structural confidence-building work, such as a joint Arctic research station, shared geotechnical survey and a fiber cable, so cooperation is demonstrated before any bridge capital is committed.
