A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Lenders in a third-country consortium will commit USD 69 billion (estimate) of debt on an unevidenced revenue case of about USD 8.9 billion/yr (estimate), with OFAC licensing the neutral SPV structure. | Appoint a Finance Lead and mandated arranger; approach 5-10 target lenders at Month 1 (2026-11-12) for written non-binding appetite on size, tenor and sanctions conditions; submit the OFAC licensing request. | Fewer than 2 lenders give written appetite covering at least USD 20 billion (estimate) by Month 6 (2027-04-12), or OFAC guidance rejects the neutral SPV structure. |
| A2 | Single-spread Arctic installation and fabrication can be closed by a pilot element trial in Months 9-12 (2027-07-12 to 2027-10-12) and a second spread or scope cut, so that tunnel elements are installed at rates supporting the Month 180 (2041-10-12) target. | Commission an independent logic-based schedule model and yard capacity survey in Months 0-3 (2026-10-12 to 2027-01-12) using 3-8 elements per season as the range against the 9 needed; request binding capacity quotes from 3-5 yards. | Modelled or quoted capacity is below 7 elements per season with no funded second spread, or no yard commits 5 or more elements per year at capped unit cost. |
| A3 | Indigenous communities on both shores will sign consent agreements through a Beringia Indigenous Council with binding advisory authority by Month 12 (2027-10-12), without demanding full veto or injunctive action. | Complete community mapping by Month 1 (2026-11-12); hold in-person consultations in Wales and Uelen; circulate a draft Council charter and consent template to 2-3 communities for written feedback. | Any mapped community with traditional-use claims refuses to join the Council, or at least 2 communities demand full veto authority over alignment and work windows in written feedback. |
| A4 | Fixed-price risk premiums and contractor bids will land within 5% of the USD 100 billion baseline (estimate), so the 15% contingency (USD 15 billion) held outside the baseline absorbs overruns without a budget-cap decision. | Commission a parametric cost model by Month 3 (2027-01-12) and request indicative unit-rate quotes from 3 Arctic contractors and 3 yards; compare to the baseline by line item. | Indicative quotes exceed the parametric baseline by more than 5% (proposed threshold), or implied overrun exceeds USD 15 billion with no sponsor willing to name who bears the excess. |
| A5 | Ice, seismic and permafrost data gathered in 12-18 months will support a design freeze within +/-15% confidence at Month 18 (2028-04-12), with the 10-20% foundation reserve (proposed) covering residual uncertainty. | Have an independent ice-mechanics institute and seismic specialist assess, by Month 3 (2027-01-12), whether 12-18 months of monitoring plus historical records can bound 50/100/500-year loads, and what confidence is achievable. | Independent reviewers state that confidence cannot reach +/-15% with less than 2 full ice seasons, or that plausible loads exceed the 10-20% reserve. |
| A6 | The US and Russian governments will each sign a framework agreement and concessions, supply guarantees and rights-of-way, and tolerate sanctions-compatible workarounds through Month 24 (2028-10-12) despite persistent bilateral tension. | Obtain written preliminary positions from the US DOT and Russian Ministry of Transport by Month 3 (2027-01-12) on a framework-first agreement, guarantees and personnel movement; commission counsel opinions on ratification and withdrawal exposure. | Either government declines in writing to commit to guarantees or a framework text by Month 6 (2027-04-12), or counsel finds the framework requires full legislative ratification beyond Month 30 (2029-04-12). |
| A7 | Utility tenants (fiber, power) will sign take-or-pay capacity contracts covering 30-50% of expected revenue (about USD 2.7-4.5 billion/yr, proposed threshold) before heads of terms, despite no traffic study, tariff or named counterparty. | Issue a tenant soundings package to 10-15 fiber, power and rail-freight prospects by Month 3 (2027-01-12) with indicative tariffs, and request written non-binding capacity interest. | Written interest covers less than USD 1.5 billion/yr (proposed threshold) by Month 9 (2027-07-12), or fewer than 3 prospects state a price they would pay. |
| A8 | Marine mammal permits and incidental-take authorizations can be obtained on the proposed no-impact-piling and 10 km acoustic shutdown basis within Months 12-18 (2027-10-12 to 2028-04-12) without redesign or seasonal exclusions that cut the open-water window. | Hold pre-application meetings with NOAA, USFWS and Russian environmental agencies by Month 3 (2027-01-12); commission an acoustic-impact model to test whether vibratory or drilled foundations meet permit thresholds. | Regulators state in writing that baseline data of 12 months are insufficient, or the acoustic model shows thresholds are exceeded with the proposed methods, cutting the usable window below 2.4 months per season (estimate). |
| A9 | A skilled Arctic workforce (core team 100-150 specialists, proposed) can be recruited and retained, and crews can cross the maritime border under a binational work-permit protocol, with turnover held near 30-50% (estimate) and without visa stoppages. | Survey 5-8 Arctic contractors and two regional training institutions by Month 3 (2027-01-12) on available skilled trades; request written positions from both governments' immigration authorities on a work-permit protocol. | Contractors confirm fewer than half the required specialist trades are available at the +30-50% premium (proposed), or either government declines in writing to agree a work-permit protocol by Month 12 (2027-10-12). |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Phantom Revenue Ledger | Process/Financial | A1 | Finance Lead / CFO | CRITICAL (20/25) |
| FM2 | The Season That Never Came | Technical/Logistical | A2 | Arctic Construction Logistics & Supply-Chain Director | CRITICAL (20/25) |
| FM3 | The Council That Said No | Market/Human | A3 | Indigenous Engagement & Community Relations Director | CRITICAL (16/25) |
| FM4 | The Contingency That Vanished | Process/Financial | A4 | Cost Estimating & Financial Controls Engineer | CRITICAL (20/25) |
| FM5 | The Ice That Rewrote the Record | Technical/Logistical | A5 | Owner's Engineer / Integrator & Technical Director | CRITICAL (16/25) |
| FM6 | The Handshake That Withdrew | Market/Human | A6 | Binational Project Director / Executive Sponsor Lead | CRITICAL (20/25) |
| FM7 | The Empty Capacity Auction | Process/Financial | A7 | Finance Lead / CFO | CRITICAL (16/25) |
| FM8 | The Silenced Hammer | Technical/Logistical | A8 | Owner's Engineer / Integrator & Technical Director | HIGH (12/25) |
| FM9 | The Crew That Could Not Cross | Market/Human | A9 | Binational Project Director / Executive Sponsor Lead | HIGH (12/25) |


### Failure Modes

#### FM1 - The Phantom Revenue Ledger

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Finance Lead / CFO
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Debt sized to USD 8.9 billion/yr (estimate) revenue with no traffic study or tariff; about 89 million tonnes/yr implied at USD 100/tonne (estimate).
- Lenders cut debt capacity; at USD 2 billion/yr, about USD 15.5 billion debt, leaving about USD 99.5 billion unfunded (estimate).
- Sanctions licensing uncertainty adds +100-200 bps.
- Pre-gate spend of up to USD 150 million (proposed threshold) is stranded at Gate 4.

##### Early Warning Signs
- Fewer than 4 lenders send written interest after the Months 4-5 (2027-02-12 to 2027-03-12) roundtable
- Independent traffic study not commissioned by Month 1 (2026-11-12)
- Take-or-pay LOIs below USD 1.5 billion/yr (proposed threshold) by Month 9 (2027-07-12)
- OFAC written guidance letter not received by Month 6 (2027-04-12)

##### Tripwires
- Signed or written lender appetite covers <= USD 20 billion (estimate) at Month 6 (2027-04-12)
- Take-or-pay commitments < 30% of expected revenue (about USD 2.7 billion/yr) at Month 12 (2027-10-12)
- Projected conservative-case DSCR < 1.5x in the lender model

##### Response Playbook
- Contain: Freeze new major procurement and hold pre-gate spend at or below the USD 150 million cap until lender feedback is in hand.
- Assess: Rerun debt sizing on the independent traffic study and lender feedback; quantify the funding gap and DSCR at 20%, 40% and 60% revenue shortfalls.
- Respond: Trigger a 3-6 month paid pause; resize Phase 1 scope or seek availability-payment backstops, or exit if no close by Month 30 (2029-04-12).


**STOP RULE:** Cancel or pivot if no financial close is achieved by Month 30 (2029-04-12) or if fewer than 2 lead arrangers hold signed heads of terms by Month 12 (2027-10-12).

---

#### FM2 - The Season That Never Came

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Arctic Construction Logistics & Supply-Chain Director
- **Risk Level:** CRITICAL 20/25 (Likelihood 5/5 × Impact 4/5)

##### Failure Story
- Plan needs about 9 elements/season (estimate); risk file supports 3-8.
- Pilot element in Months 9-12 (2027-07-12 to 2027-10-12) is aggressive; failure costs about 12 months (estimate).
- Few yards have Arctic immersed-tube experience; single-yard or vessel dependency.
- Lost open-water season costs about 12 months; commissioning slips past Month 180 (2041-10-12).
- Debt service accrues without revenue.

##### Early Warning Signs
- Fewer than 2 yards sign framework agreements by Month 6 (2027-04-12)
- Pilot element fabrication start slips past Month 9 (2027-07-12)
- Modelled installation rate below 7 elements per season
- Ice-class tow vessel charters not secured by Month 9 (2027-07-12)

##### Tripwires
- Modelled single-spread rate <= 6 elements per season at Month 6 (2027-04-12)
- Pilot trial delivery slips >= 3 months beyond Month 12 (2027-10-12)
- Fewer than 4 ice-class tow vessels chartered at Month 12 (2027-10-12)

##### Response Playbook
- Contain: Halt full-scale fabrication commitments and lock only the pilot element contract until trial data is validated.
- Assess: Run a Monte Carlo schedule with single-loss scenarios (lost season, vessel failure, pilot redesign) to quantify the slip beyond Month 180 (2041-10-12).
- Respond: Commit a second spread or second yard, or rescope Phase 1 to 60-70 elements and re-baseline commissioning with lender and government sign-off.


**STOP RULE:** Pivot or cancel if the pilot element fails twice, or if no funded second spread or approved rescope exists by Gate 3 at Month 18 (2028-04-12).

---

#### FM3 - The Council That Said No

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Indigenous Engagement & Community Relations Director
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Cross-border council with 'binding advisory' authority is undefined legally in two regimes.
- A community outside the Council files an injunction after heads of terms.
- Injunctions of 6-18 months (estimate) and stop-work orders of 3-6 months.
- Loss of social licence erodes lender confidence and local hire.
- Benefit fund of 1-2% of revenue may be judged inadequate.

##### Early Warning Signs
- Council charter not signed by Month 6 (2027-04-12)
- One or more mapped communities decline to participate
- Written demands for full FPIC veto authority
- Legal opinions on Council standing in US and Russia not delivered by Month 3 (2027-01-12)

##### Tripwires
- Fewer than 100% of mapped communities (8-12 estimate) have signed MOUs at Month 6 (2027-04-12)
- Consent agreements signed < 100% at Month 12 (2027-10-12)
- Any injunction or formal legal notice filed before Month 18 (2028-04-12)

##### Response Playbook
- Contain: Suspend work-window and alignment decisions affecting the objecting community and offer an immediate funded mediation with independent legal counsel.
- Assess: Map which decisions each community claims consent over; obtain legal opinions on enforceability in both jurisdictions and the schedule exposure in months.
- Respond: Redesign the Council charter with explicit consent triggers and dispute resolution, renegotiate benefit terms, and defer design freeze if consent is not secured.


**STOP RULE:** Pivot or cancel if consent agreements covering communities with authority over more than 50% of the alignment are not signed by Month 18 (2028-04-12).

---

#### FM4 - The Contingency That Vanished

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Cost Estimating & Financial Controls Engineer
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Contractors price Arctic labor +30-50%, marine logistics +50-100% and risk premiums of 15-25% (estimate).
- Overrun of 10-30% (USD 10-30 billion, estimate) exceeds the USD 15 billion contingency by up to USD 15 billion.
- No budget cap or cap-bearer is decided; Gate 2 deadlocks.
- DSCR slips toward the 1.2x default trigger (proposed threshold).

##### Early Warning Signs
- Cost Basis Document not signed off by the Cost Task Force at Month 6 (2027-04-12)
- Early bids exceed the parametric baseline by more than 5%
- Contingency draws exceed 10% of the pool before Month 18 (2028-04-12)
- No written sponsor decision on overrun ownership by Month 3 (2027-01-12)

##### Tripwires
- Bids > 5% above parametric baseline at Month 12 (2027-10-12)
- Forecast overrun > USD 15 billion (estimate) at any monthly reforecast
- Cumulative contingency drawn >= 25% before financial close

##### Response Playbook
- Contain: Freeze scope changes and non-critical procurement; route every contingency draw through the change board.
- Assess: Rebuild the cost forecast line by line with independent audit; quantify uncovered exposure and DSCR at +10%, +20% and +30%.
- Respond: Convene sponsors for a binding cap and overrun-allocation decision; rescope Phase 1 or enter a 3-6 month paid pause to reprice.


**STOP RULE:** Cancel or rescope if forecast cost exceeds the USD 115 billion funding requirement (estimate) by more than USD 15 billion with no committed funder by Month 24 (2028-10-12).

---

#### FM5 - The Ice That Rewrote the Record

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Owner's Engineer / Integrator & Technical Director
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Short monitoring record cannot resolve 100- and 500-year ice and seismic loads.
- Climate-driven regime shift invalidates historical baselines.
- Design freeze either slips 3-6 months or locks under-estimated loads.
- Under-design: repairs of USD 50-200 million per incident (estimate); over-design adds USD 5-15 billion (estimate).
- Lenders and regulators withhold sign-off.

##### Early Warning Signs
- Buoy and radar data availability below 80% (proposed threshold) in the first winter
- Ice-load confidence interval wider than +/-15% at Month 12 (2027-10-12)
- Pilot pier instrumentation not deployed by Month 12 (2027-10-12)
- Independent reviewers request additional seasons of data

##### Tripwires
- Confidence interval > +/-15% at Month 15 (2028-01-12)
- Observed single-season peak load > 80% of the proposed 100-year design load (proposed threshold)
- Data Adequacy Committee fails to certify by Month 18 (2028-04-12)

##### Response Playbook
- Contain: Block foundation and pier commitments; keep only reversible design and survey spending.
- Assess: Convene the Data Adequacy Committee with independent reviewers to quantify the confidence gap and cost of one extra season versus over-design.
- Respond: Extend monitoring 3-6 months under a paid pause, or adopt the deterministic envelope and re-baseline cost with lenders.


**STOP RULE:** Pivot or cancel if ice-load confidence is still outside +/-15% after one additional full ice season, beyond Month 30 (2029-04-12).

---

#### FM6 - The Handshake That Withdrew

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Binational Project Director / Executive Sponsor Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Bilateral tension turns a framework agreement into a political liability in one capital.
- Ratification slip of 12-36 months (estimate) exceeds the 6-12 month float.
- Guarantees and rights-of-way are withheld; lenders and tenants lose confidence.
- Public opposition and visa denials disrupt crews and design reviews.
- Pre-gate spend of up to USD 150 million (proposed threshold) is stranded.

##### Early Warning Signs
- No written government position on the framework by Month 3 (2027-01-12)
- Legislative committee hearings or riders opposing the project
- New sanctions designations touching named suppliers or lenders
- Visa or work-permit protocol not agreed by Month 12 (2027-10-12)

##### Tripwires
- Framework text unsigned by either government at Month 6 (2027-04-12)
- Ratification timetable slips >= 6 months (estimate) at Month 18 (2028-04-12)
- Two or more lenders cite political risk in writing to withdraw

##### Response Playbook
- Contain: Pause new commitments to contractors and yards; preserve data, surveys and cash within the spend cap.
- Assess: Obtain counsel opinions on each government's legal position, withdrawal exposure and SPV continuity; rescore lender and tenant appetite.
- Respond: Pursue a non-structural confidence-building track (fiber, research station, survey) or activate exit provisions at the next gate.


**STOP RULE:** Cancel if either government withdraws in writing, or if Gate 4 is not met by Month 30 (2029-04-12).

---

#### FM7 - The Empty Capacity Auction

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Finance Lead / CFO
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Take-or-pay marketing starts without a tariff schedule or traffic study.
- Tenants decline to commit to a crossing with no operating precedent and sanctions exposure.
- Contracted revenue stays far below USD 2.7 billion/yr (proposed threshold).
- Debt capacity is about USD 7.75 billion per USD 1 billion/yr of revenue (estimate), so lenders cut debt sharply.
- Heads of terms stall and pre-gate spend of USD 150 million (proposed threshold) is at risk.

##### Early Warning Signs
- Fewer than 5 tenant prospects hold meetings by Month 3 (2027-01-12)
- No indicative tariff published by Month 6 (2027-04-12)
- Prospects request sovereign guarantees before signing
- Lenders ask for availability payments in term-sheet feedback

##### Tripwires
- Written interest < USD 1.5 billion/yr (proposed threshold) at Month 9 (2027-07-12)
- Signed take-or-pay < 30% of expected revenue at Month 12 (2027-10-12)
- Fewer than 3 prospects with named capacity requests at Month 6 (2027-04-12)

##### Response Playbook
- Contain: Stop incurring new marketing and tenant-specific design costs; hold spend inside the USD 150 million cap (proposed threshold).
- Assess: Re-run debt sizing at the contracted revenue actually evidenced; quantify the gap and DSCR at 20%, 40% and 60% shortfalls.
- Respond: Offer shorter or phased capacity terms, seek government availability-payment backstops, or rescope Phase 1 to evidenced revenue.


**STOP RULE:** Cancel or pivot if signed take-or-pay is below 20% of expected revenue at Month 18 (2028-04-12) with no sovereign backstop agreed.

---

#### FM8 - The Silenced Hammer

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Owner's Engineer / Integrator & Technical Director
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Permit conditions tighten beyond the 10 km shutdown and 15-20 km exclusion zones (proposed).
- Vibratory or drilled foundations fail to meet permit thresholds or durability needs.
- Stop-work orders of 3-6 months (estimate) shrink an already short season.
- A lost open-water season costs about 12 months (estimate).
- Redesign adds cost and widens the installation-rate gap.

##### Early Warning Signs
- Regulators request more than 12 months of baseline data
- Acoustic model exceeds thresholds at any construction scenario
- Preliminary authorization not filed by Month 12 (2027-10-12)
- Observers call repeated stops in pilot element works

##### Tripwires
- Preliminary authorization not on track at Month 12 (2027-10-12)
- Modelled usable window < 2.4 months per season (estimate)
- Stop-work orders >= 3 months during pilot trial

##### Response Playbook
- Contain: Suspend marine works that trigger objections and keep only survey and monitoring activity under approved conditions.
- Assess: Rerun the acoustic model and schedule with regulator-specified thresholds; quantify lost work days and foundation cost delta.
- Respond: Switch foundation method or adopt a fixed seasonal calendar with a negotiated stop-work protocol and re-baseline with lenders.


**STOP RULE:** Pivot or cancel if final incidental-take authorization is not issued by Month 24 (2028-10-12) after one redesign cycle.

---

#### FM9 - The Crew That Could Not Cross

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Binational Project Director / Executive Sponsor Lead
- **Risk Level:** HIGH 12/25 (Likelihood 4/5 × Impact 3/5)

##### Failure Story
- Competing Arctic projects absorb scarce skilled trades and divers.
- Turnover of 30-50% (estimate) cuts productivity 20-40% (estimate).
- Visa and work-permit delays idle crews at an estimated USD 10-30 million per month.
- Core team of 100-150 specialists (proposed) is not assembled before pilot trial.
- Rework and quality defects slip the schedule.

##### Early Warning Signs
- Fewer than 50% of core roles filled by Month 6 (2027-04-12)
- Offer acceptance rate below 60% (proposed threshold)
- Work-permit protocol not drafted by Month 9 (2027-07-12)
- Wage quotes exceed the +50% premium (proposed)

##### Tripwires
- Core team filled < 75% at Month 9 (2027-07-12)
- Work-permit protocol unsigned at Month 12 (2027-10-12)
- Annualized turnover >= 40% (estimate) in any quarter

##### Response Playbook
- Contain: Defer mobilization of non-critical field crews and protect the retained core team with retention incentives.
- Assess: Quantify role-by-role vacancies, wage gaps and visa backlog, with idle-cost exposure per month.
- Respond: Add third-country labor pools and training pipelines, escalate the permit protocol through both governments, and resequence work to available crews.


**STOP RULE:** Pivot if the work-permit protocol is not agreed by Month 18 (2028-04-12) or core roles stay below 75% filled at Gate 3.
