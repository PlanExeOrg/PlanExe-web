This plan involves money.

## Currencies

- **USD:** Primary currency for international financing (sovereign funds, multilateral banks, export-credit agencies), equipment procurement, engineering contracts, and cross-border payments. Essential for sanctions compliance and third-country investor consortium model. Mitigates ruble volatility and export-control exposure.
- **RUB:** Local transactions in Russia for labor, local materials, and Chukotkan operations. Limited role due to sanctions and export-control constraints on Russian financial institutions and equipment sourcing. Useful for documenting local cost baselines.
- **EUR:** Potential participation by European development banks, Canadian yards, and EU export-credit agencies. May be needed for portions of financing and third-country contractor payments, particularly for prefabrication work in Pacific yards.

**Primary currency:** USD

**Currency strategy:** Use USD as the primary currency for all budgeting, financing agreements, and international procurement to ensure compatibility with sanctions licensing and third-country investor consortium requirements. Convert local Russian labor and materials costs to USD equivalents at project-approved monthly rates to manage exchange-rate exposure. Require all debt facilities and availability payments to be denominated in USD. For European development bank participation, establish funding tranches in EUR where licensing permits, but consolidate reporting in USD. Build contingency buffers (propose 8-12%) into baseline estimates to absorb currency volatility over the 180-month program and unanticipated ruble devaluation. Quarterly reforecasting of ruble costs against hedging options. Pre-sell utility revenue (fiber, power, pipeline access) in USD-denominated take-or-pay contracts to lock early cash flow.