This plan implies one or more physical locations.

## Requirements for physical locations

- Alignment across the Bering Strait between Alaska (USA) and Chukotka (Russia), about 85 km (user constraint)
- Shallow central section (Diomede Islands area) suitable for immersed-tube tunnel and artificial islands
- Shore sites for fabrication yards, ports, worker camps and road/rail approaches on both coasts
- Geotechnical stability: permafrost, seismic ground response and ice-load data available
- Access for ice-class vessels and short open-water season logistics
- Proximity to Indigenous communities for consent, monitoring and local hire
- Jurisdictional clarity at the maritime boundary for customs, security and emergency response
- Feasible landing rights for utility corridors (fiber, power, pipelines)
- Existing or developable power, port and airstrip infrastructure for remote construction

## Location 1
Bering Strait, between USA (Alaska) and Russia (Chukotka)

Cape Prince of Wales (Alaska) to Cape Dezhnev area (Chukotka), via the Diomede Islands

Narrowest strait alignment passing Little Diomede (US) and Big Diomede (Russia); exact alignment subject to surveys

**Rationale**: This is the conventional alignment for a fixed crossing. The Diomede Islands offer rock foundations and a natural mid-strait base for the shallow central tunnel section and staged island foundations. Exact route is not confirmed and needs geotechnical survey.

## Location 2
USA, Alaska, Seward Peninsula

Wales / Tin City / Nome region

Coastal sites near Wales and Tin City for the eastern landfall, with Nome port as logistics hub

**Rationale**: Nome has the nearest deep-draft port, airport and regional services in Alaska. Wales and Tin City are close to the alignment, allowing the eastern portal, yards and camps. Indigenous (Inupiat, Yupik) communities are nearby, so consent and benefit-sharing agreements are required.

## Location 3
Russia, Chukotka Autonomous Okrug

Uelen / Lavrentiya / Provideniya region

Coastal landfall near Uelen or Cape Dezhnev, with Provideniya port as logistics base

**Rationale**: Provideniya is an existing port and Uelen is the nearest settlement to the western landfall. These sites host the western portal, fabrication yards and camps. Road and rail approaches would have to be built across remote tundra. Sanctions and export-control licensing affect equipment and financing here.

## Location 4
Pacific shipyards (third-country or US/Asia)

Existing heavy fabrication yards on the North Pacific rim

Candidate yards in the Pacific Northwest, Korea, Japan or Canada, subject to sanctions and licensing review

**Rationale**: Fabricating tunnel elements and spans in established yards and towing them to site during the open-water window minimizes permanent Arctic infrastructure. Yard choice must be compatible with sanctions and export-control regimes.

## Location Summary
The plan is tied to the Bering Strait between Alaska and Chukotka, so the location is fixed. The listed sites cover the central alignment via the Diomede Islands, the Alaskan landfall around Wales and Nome, the Chukotkan landfall around Uelen and Provideniya, and remote Pacific yards for prefabrication. Together they support the staged tunnel-first approach with island foundations, within a short open-water season.