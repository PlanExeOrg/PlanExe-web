# Purpose
# Permanent Alaska-Russia Bering Strait Crossing: 85 km Hybrid Suspension-Bridge and Immersed-Tube Tunnel Link

## Purpose

Strategic plan to design, finance, build and operate a binational mega-infrastructure link across the Bering Strait. Covers technical concept, feasibility, cost and funding (PPP, sovereign funds, multilateral banks), phased timeline, risk register, governance, environmental and social impact, stakeholder engagement, and economic and strategic benefits (trade corridor, energy transport, telecom fiber, Arctic research, national security). Large-scale infrastructure and geopolitical project run under binational public-private structure.

# Domain
# Primary domain: Bridge Engineering

## Secondary domains

- Arctic Engineering
- Infrastructure Finance
- Immersed Tunnel Engineering

## Rationale
Bridge Engineering is the sole outcome-role candidate and owns the core deliverable, the 85 km bridge-tunnel crossing. Immersed Tunnel Engineering, Arctic Engineering, Infrastructure Finance and Megaproject Management are subordinate methods or constraints serving that crossing.

# Disciplines

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Bridge Engineering | 5 | 5 | outcome | Core deliverable is an 85 km suspension-bridge and immersed-tube tunnel crossing. |
| Immersed Tunnel Engineering | 5 | 5 | method | Immersed-tube tunnel segments are a core technical element requiring specialist subsea design and installation. |
| Arctic Engineering | 5 | 4 | constraint | Ice floes, permafrost, and seismic loads dictate foundation and structural design. |
| Geotechnical Engineering | 5 | 4 | method | Permafrost, seismic ground response, and foundation design govern the bridge piers and tunnel trench. |
| International Treaty Law | 5 | 4 | constraint | Binational joint ownership, jurisdiction, and permitting require a treaty-based legal framework across the US and Russia. |
| Infrastructure Finance | 4 | 4 | method | PPP, sovereign funds, and multilateral bank financing underpin the mega-project's viability. |
| Geopolitical Risk Management | 4 | 4 | constraint | Binational US-Russia sanctions, diplomacy and political tension strongly shape feasibility and governance. |
| Environmental Impact Assessment | 4 | 4 | constraint | Marine wildlife, permafrost and dual US-Russian environmental regulatory compliance are mandatory. |
| Megaproject Management | 4 | 3 | method | Phased delivery, logistics, and governance of a multi-decade binational infrastructure program. |

# Plan Type
# Plan Overview

This plan requires one or more physical locations. It cannot be executed digitally.

## Explanation

The plan is to design, finance, construct and operate a permanent 85 km hybrid suspension-bridge and immersed-tube tunnel crossing of the Bering Strait between Alaska and Russia. This requires a real-world construction site in the Bering Strait, including artificial islands, bridge piers, main span erection, and immersed-tube tunnel segment fabrication and installation. Geotechnical surveys and seabed and permafrost testing on site, physical materials procurement (steel, concrete), heavy marine vessels, logistics, and labor in an extreme Arctic environment are essential. Environmental monitoring of marine wildlife, in-person engagement with Indigenous communities, binational government meetings, and eventual physical operations (tolling, freight, maintenance, telecom fiber laying) all have physical elements. Although parts of the work such as the strategic document, financing structure, and governance framework can be drafted digitally, the overall plan is centered on constructing and operating physical infrastructure.

# Physical Locations
# Requirements for physical locations

- Alignment across the Bering Strait between Alaska (USA) and Chukotka (Russia), about 85 km (user constraint)
- Shallow central section (Diomede Islands area) suitable for immersed-tube tunnel and artificial islands
- Shore sites for fabrication yards, ports, worker camps and road/rail approaches on both coasts
- Geotechnical stability: permafrost, seismic ground response and ice-load data available
- Access for ice-class vessels and short open-water season logistics
- Proximity to Indigenous communities for consent, monitoring and local hire
- Jurisdictional clarity at the maritime boundary for customs, security and emergency response
- Feasible landing rights for utility corridors (fiber, power, pipelines)
- Existing or developable power, port and airstrip infrastructure for remote construction

## Location 1: Bering Strait (USA-Russia)

Cape Prince of Wales (Alaska) to Cape Dezhnev area (Chukotka), via the Diomede Islands. Narrowest strait alignment passing Little Diomede (US) and Big Diomede (Russia); exact alignment subject to surveys.

Conventional alignment for a fixed crossing. The Diomede Islands offer rock foundations and a natural mid-strait base for the shallow central tunnel section and staged island foundations. Exact route requires geotechnical survey.

## Location 2: Alaska, Seward Peninsula

Wales / Tin City / Nome region. Coastal sites near Wales and Tin City for the eastern landfall, with Nome port as logistics hub.

Nome has the nearest deep-draft port, airport and regional services in Alaska. Wales and Tin City are close to the alignment for the eastern portal, yards and camps. Indigenous (Inupiat, Yupik) communities require consent and benefit-sharing agreements.

## Location 3: Russia, Chukotka Autonomous Okrug

Uelen / Lavrentiya / Provideniya region. Coastal landfall near Uelen or Cape Dezhnev, with Provideniya port as logistics base.

Provideniya is an existing port and Uelen is the nearest settlement to the western landfall. These sites host the western portal, fabrication yards and camps. Road and rail approaches must be built across remote tundra. Sanctions and export-control licensing affect equipment and financing.

## Location 4: Pacific shipyards (third-country or US/Asia)

Existing heavy fabrication yards on the North Pacific rim. Candidate yards in the Pacific Northwest, Korea, Japan or Canada, subject to sanctions and licensing review.

Fabricating tunnel elements and spans in established yards and towing them to site during the open-water window minimizes permanent Arctic infrastructure. Yard choice must be compatible with sanctions and export-control regimes.

## Location Summary

The plan is tied to the Bering Strait between Alaska and Chukotka. Listed sites cover the central alignment via the Diomede Islands, the Alaskan landfall around Wales and Nome, the Chukotkan landfall around Uelen and Provideniya, and remote Pacific yards for prefabrication. Together they support the staged tunnel-first approach with island foundations within a short open-water season.

# Currency Strategy
# Currencies

- USD: Primary currency for international financing, equipment procurement, engineering contracts, and cross-border payments. Essential for sanctions compliance and third-country investor consortium model.
- RUB: Local transactions in Russia for labor, local materials, and Chukotkan operations. Limited role due to sanctions and export-control constraints.
- EUR: Potential participation by European development banks and export-credit agencies for portions of financing and third-country contractor payments.

## Currency Strategy

- Use USD as primary currency for all budgeting, financing agreements, and international procurement to ensure sanctions licensing compatibility and third-country investor consortium requirements.
- Convert local Russian labor and materials costs to USD equivalents at project-approved monthly rates.
- Require all debt facilities and availability payments denominated in USD.
- For European development bank participation, establish funding tranches in EUR where licensing permits, but consolidate reporting in USD.
- Build contingency buffers (8-12% proposed) into baseline estimates to absorb currency volatility over 180 months and ruble devaluation.
- Conduct quarterly reforecasting of ruble costs against hedging options.
- Pre-sell utility revenue (fiber, power, pipeline access) in USD-denominated take-or-pay contracts to lock early cash flow.


# Identify Risks
# Risk 1 - Regulatory & Permitting

## Treaty ratification dependency

Both US and Russian legislatures must approve a bilateral treaty establishing the joint authority and legal framework. Ratification timelines are unpredictable; political opposition from either side could indefinitely stall the project. Russia faces US sanctions and export-control scrutiny that may trigger legislative conditions or riders delaying approval. Environmental permitting in both jurisdictions requires multi-year baseline surveys and mitigation planning.

- Impact: Delay of Months 24–36 (2028-10-12 to 2029-10-12) or project failure. Sunk costs in design, surveys and mobilization (estimated $50–150 million USD) stranded if ratification fails.
- Likelihood: High
- Severity: High
- Action: Stage permitting and ratification through explicit gates with paid pause and exit provisions. Separate treaty negotiation (Months 0–6 = 2026-10-12 to 2027-04-12) from design freeze; prioritize framework treaties over detailed terms to improve ratification odds. Engage US and Russian legislative committees early; use confidence-building works (fiber cable, research station, geotechnical survey) as visible cooperation milestones. Parallel-path domestic permitting in each jurisdiction to shorten critical path once treaty is signed. Retain a third-country legal vehicle option to reduce sovereignty-seam complexity.

# Risk 2 - Regulatory & Permitting

## Indigenous stakeholder consent and litigation

US and Russian Indigenous communities (Inupiat, Yupik, Chukchi, Siberian Yupik) hold subsistence harvesting rights and may claim FPIC (free, prior and informed consent) authority. US law requires NEPA consultation; Russian law offers weaker protections. Unresolved consent claims can trigger injunctions, delaying or halting construction. Two legal regimes must be reconciled into a single cross-border agreement.

- Impact: Months 6–12 (2027-04-12 to 2027-10-12) delay in design freeze if consent processes are incomplete. Potential construction injunctions (Months 18–30 = 2028-04-12 to 2029-04-12) causing Months 6–18 (2027-04-12 to 2028-04-12) halts. Requirement to redesign alignment, environmental controls or work windows, adding $20–50 million USD. Litigation costs of $5–15 million USD across both jurisdictions.
- Likelihood: High
- Severity: High
- Action: Establish a Beringia Indigenous Council (Months 0–3 = 2026-10-12 to 2027-01-12) with binding advisory authority over alignment, seasonal work windows and marine impacts. Fund Indigenous-led baseline studies of marine mammals, subsistence harvests and traditional use patterns (Months 0–12 = 2026-10-12 to 2027-10-12). Commit to revenue shares, local hiring targets and Indigenous observer participation in all marine works. Negotiate consent agreements as a gating condition before design freeze (Months 6–12 = 2027-04-12 to 2027-10-12). Provide free legal counsel to Indigenous groups and budget for independent co-management monitoring and adaptive mitigation. Document agreements under both US and Russian legal frameworks simultaneously.

# Risk 3 - Regulatory & Permitting

## Environmental permitting delays

Immersed-tube tunnel and dredging/piling work require detailed marine environmental assessments (EIS in US, EIA equivalent in Russia), habitat mitigation plans, marine mammal protection protocols and fisheries impact assessments. Multi-year baseline data collection is needed before permitting can proceed. Regulatory agencies (NOAA, Fish and Wildlife Service in US; relevant Russian agencies) must coordinate across the maritime boundary.

- Impact: Delay of Months 12–24 (2027-10-12 to 2028-10-12) in permitting. Re-design of tunnel sections or marine works to meet permit conditions, adding $10–30 million USD and Months 6–12 (2027-04-12 to 2027-10-12). Potential permit denial if impacts are deemed unacceptable.
- Likelihood: Medium
- Severity: High
- Action: Launch geotechnical and environmental baseline surveys immediately (Month 0 = 2026-10-12), well before permit applications are drafted. Engage NOAA, US Fish and Wildlife and Russian environmental regulators as design partners from Month 0 (2026-10-12) onwards, incorporating feedback iteratively rather than submitting a frozen design for review. Adopt the observational design approach (refined over Months 0–12 = 2026-10-12 to 2027-10-12) so the permit application reflects real conditions. Propose tiered permitting: framework permits (Months 6–9 = 2027-04-12 to 2027-07-12) for site surveying and foundational works; detailed permits for dredging and tunnel (Months 12–18 = 2027-10-12 to 2028-04-12). Budget contingency for permit modifications or conditions, and establish adaptive management protocols to modify marine works in response to monitoring data without requiring permit re-issuance where legally feasible.

# Risk 4 - Political & Geopolitical

## US-Russia political tension and sanctions escalation

The baseline assumes sanctions licensing will be available for financing, equipment and personnel movement. If US-Russia relations deteriorate further, sanctions may tighten (export controls on steel, electronics, dual-use materials; financing restrictions on multilateral banks and development agencies; visa and personnel movement bans). A major geopolitical event could trigger unilateral project termination by one government, stranding the other's capital and personnel on the opposite shore.

- Impact: Financing delays or withdrawal (Months 12–24 = 2027-10-12 to 2028-10-12), causing $50–200 million USD cost and Months 6–18 (2027-04-12 to 2028-04-12) schedule slip. Equipment procurement delays if key suppliers face export controls, adding Months 12–24 (2027-10-12 to 2028-10-12) to long-lead items. Personnel unable to cross the border, disrupting design reviews and site supervision (Months 12–60 = 2027-10-12 to 2031-10-12). Unilateral project termination stranding capital, equipment and crews on site, risking loss of $100–500 million USD depending on construction stage.
- Likelihood: High
- Severity: High
- Action: Assemble financing through a third-country investor consortium and multilateral banks (non-US, non-Russian) to reduce direct sanctions exposure and preserve flexibility if bilateral relations deteriorate. Negotiate sanctions licensing frameworks with OFAC and equivalent Russian authorities before financial close (Months 6–9 = 2027-04-12 to 2027-07-12), locking in approved supplier lists and financing structures. Include explicit force-majeure and early-termination provisions in all contracts, with paid-pause and exit gates at Months 6, 12, 18 and 24 (2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12). Establish binational insurance and contingency funds to cover stranded capital or workforce evacuation. Diversify suppliers across multiple countries and pre-qualify backup vendors for all critical long-lead items. Stage capital deployment on the basis of political confidence milestones, not just technical progress. Designate neutral-party (e.g., Swiss or Canadian) facilities for key design and oversight functions to reduce personnel movement dependency.

# Risk 5 - Financial

## Capital cost overrun and financing risk

Total estimated CAPEX for the staged tunnel-first approach is likely $80–120 billion USD (estimate; detailed cost model required). Actual costs may exceed estimates due to Arctic logistics inflation, ice and seismic unknowns, supply-chain disruptions, and currency volatility (ruble depreciation). Lenders require fixed-price certainty; contractors will demand contingency premiums (15–25%) for ice, permafrost and geopolitical risk that they cannot price. Cost escalations can trigger covenant breaches and loss of lender support. Revenue underperformance (lower toll and freight volumes than forecast) can worsen debt service coverage.

- Impact: Cost overruns of $10–30 billion USD (10–30% of baseline) due to Arctic logistics, foundation unknowns and contractor risk premiums. Financing gap of $5–15 billion USD if lenders withhold tranches on covenant breaches. Debt service coverage ratio falling below 1.2x, triggering default provisions. Project restructuring or partial write-down of equity positions. Schedule delays of Months 12–36 (2027-10-12 to 2029-10-12) to work within reduced cash flow.
- Likelihood: High
- Severity: High
- Action: Conduct a detailed build-up cost estimate with Arctic logistics specialists, ice/seismic engineers and third-country contractors (Months 0–6 = 2026-10-12 to 2027-04-12). Incorporate regional cost indices for Arctic labor (propose 30–50% premium over southern US or Russian rates) and marine logistics (propose 50–100% premium). Establish a separate contingency pool (propose 12–15% of CAPEX) for unknowns and manage it through formal change-control processes. Use an alliance-contract model or open-book accounting for design and early construction phases (Months 6–24 = 2027-04-12 to 2028-10-12) to build transparency and early warning of cost trends. Secure multi-year supply contracts with fixed escalation caps for steel, concrete and fuel. Implement forex hedging for ruble costs; propose quarterly reforecasting of labor and material costs with lender sign-off. Build availability-payment or take-or-pay utility revenue into the financing plan (fiber, power, pipeline access) to reduce debt dependency on traffic-volume forecasts. Stage capital deployment through decision gates (Months 6, 12, 18 = 2027-04-12, 2027-10-12, 2028-04-12) with scheduled re-forecasting and repricing; preserve exit provisions if costs diverge materially from plan.

# Risk 6 - Financial

## Sanctions and export-control financing constraints

Multilateral development banks (World Bank, ADB, EBRD, IFC) may face policy restrictions on financing US-Russia projects, particularly if equipment procurement involves sensitive dual-use materials or if either government is under targeted sanctions. Export-control regimes (ITAR, EAR in US; equivalent Russian controls) restrict sourcing of electronics, composite materials and specialized equipment. Financing structures that rely on US or Russian-domiciled institutions face mandatory compliance reviews that can delay funding releases.

- Impact: Financing delays of Months 6–12 (2027-04-12 to 2027-10-12) due to licensing reviews and compliance sign-offs (Months 12–24 = 2027-10-12 to 2028-10-12). Reduction in available funding by 10–20% if sanctions-sensitive tranches are restricted. Increase in financing costs by 100–200 basis points if alternative lenders demand higher risk premiums. Equipment procurement delays of Months 6–12 (2027-04-12 to 2027-10-12) if suppliers require export licenses; substitute sources may be costlier or lower quality.
- Likelihood: Medium
- Severity: High
- Action: Pre-engage with OFAC (US) and equivalent Russian authorities to obtain sanctions-licensing guidance before financial close (Months 3–6 = 2027-01-12 to 2027-04-12). Structure the financing vehicle as a neutral third-party entity (e.g., Swiss or Canadian SPV) with non-US, non-Russian lenders where possible. Use third-country development banks (EIB, ADB, Canadian banks, Scandinavian development finance) that have clearer sanctions-licensing pathways than multilaterals. Maintain a pre-qualified supplier list for all long-lead items, with explicit sanctions and export-control compliance vetting (Months 6–12 = 2027-04-12 to 2027-10-12). Establish a secondary source list for each critical component (steel, concrete, electronics, tunnel liners) and pre-qualify facilities outside sanctioned jurisdictions. Budget 5–10% cost premium for sanctions-compliant sourcing. Include explicit force-majeure and contract-modification provisions allowing substitution of suppliers or sourcing countries if licenses are revoked or delayed. Engage export-control counsel in contract drafting to ensure licensing-friendly language.

# Risk 7 - Technical

## Ice-floe impact and structural damage risk

Drift ice in the Bering Strait exerts dynamic loads on piers and bridge spans. Ice ridging can produce keel depths of 20–40 m, and seasonal floe pressure creates multi-directional forces. Historical ice-flow behavior is based on limited data; climate change may shift ice regime in ways not captured by historical records. The observational design approach depends on installing monitoring instruments and collecting real-time data before design is frozen, but if data collection is delayed or ambiguous, design decisions may be made on incomplete information, leading to underestimated ice loads and structural inadequacy.

- Impact: Pier damage or partial failure if ice loads exceed design assumptions, requiring costly repairs or temporary closure (Months 1–3 = 2026-11-12 to 2027-01-12 per incident, cost $50–200 million USD). Over-design of piers to accommodate worst-case ice loads, adding $5–15 billion USD to CAPEX. Delays in design freeze if monitoring data are slow to accumulate or inconclusive (Months 3–6 = 2027-01-12 to 2027-04-12 extension of Months 0–12 = 2026-10-12 to 2027-10-12 survey window). Litigation or insurance disputes if damage occurs and causation is attributed to inadequate design.
- Likelihood: High
- Severity: High
- Action: Launch an intensive ice-monitoring program starting Month 0 (2026-10-12), using drifting buoys, shore-based radar and satellite imagery to characterize ice-floe size, thickness, velocity and pressure regimes over Months 0–18 (2026-10-12 to 2028-04-12). Install pilot instrumentation (pressure plates, accelerometers) on prototype pier models in the strait (Months 6–12 = 2027-04-12 to 2027-10-12) to capture real-world ice loads. Parallelize design development with monitoring data collection; draft preliminary designs (Months 0–6 = 2026-10-12 to 2027-04-12) and refine them iteratively (Months 6–12 = 2027-04-12 to 2027-10-12) as monitoring data arrive. Adopt a probabilistic design framework (characteristic events at 50-year, 100-year and 500-year return periods) rather than deterministic worst-case, with design margins tied to data confidence levels. Partner with ice-mechanics research institutions (e.g., universities in Alaska, Canada, Norway) to validate ice models and load assumptions. Include sacrificial ice-deflection structures (ice booms, pile-supported upstream deflectors) that absorb floe impacts and protect the main piers, allowing repair or replacement without damage to the structure. Reserve design contingency to upgrade pier foundations if monitoring data suggest higher loads (propose 10–15% design flexibility in foundation sizing). Establish an adaptive management protocol allowing design refinement through Month 18 (2028-04-12) before pouring permanent foundations.

# Risk 8 - Technical

## Seismic risk and permafrost ground response

The Bering Strait region is moderately seismic; the Aleutian subduction zone and Arctic spreading centers produce earthquakes of magnitude 6–8, with return periods of 50–200 years. Permafrost in shallow soils and on the coasts degrades under climate warming, changing bearing capacity and subsidence rates. Uncertain ground conditions (layer depth, ice content, thaw potential) require extensive drilling and laboratory testing before foundation design can be frozen. Seismic amplification in soft soils and saturation effects during earthquakes interact with permafrost thaw in ways not fully understood in this region.

- Impact: Foundation subsidence of 0.3–1.0 m over the design life if permafrost thaw is underestimated, requiring costly remediation or bridge realignment (cost $5–20 million USD per location, Months 3–12 = 2027-01-12 to 2027-10-12 delay). Seismic ground failure or liquefaction during a large earthquake, causing partial or total loss of a pier or tunnel section (cost $50–500 million USD and Months 12–24 = 2027-10-12 to 2028-10-12 recovery). Over-design of foundations to accommodate worst-case permafrost and seismic scenarios, adding $3–10 billion USD to CAPEX. Delays in design if geotechnical surveys are incomplete (proposed Months 6–12 = 2027-04-12 to 2027-10-12 extension).
- Likelihood: Medium
- Severity: High
- Action: Launch a comprehensive geotechnical investigation program in Month 0 (2026-10-12), including core drilling at proposed pier locations and shallow island sites (Months 0–6 = 2026-10-12 to 2027-04-12), laboratory testing of soil samples for shear strength, consolidation and permafrost characteristics (Months 3–9 = 2027-01-12 to 2027-07-12), and in-situ testing (SPT, CPT, vane shear) at multiple depths (Months 6–12 = 2027-04-12 to 2027-10-12). Establish a long-term subsidence and temperature-monitoring network at prototype pier locations starting Month 6 (2027-04-12), with monthly measurements through Month 24 (2028-10-12) to calibrate thaw models. Conduct site-specific seismic hazard analysis using the latest regional earthquake catalogs and ground-motion prediction models (complete by Month 6 = 2027-04-12). Run coupled seismic-permafrost finite-element analyses to model ground response during a design-basis earthquake (Months 9–12 = 2027-07-12 to 2027-10-12). Adopt dynamic-compaction or soil-stabilization techniques (e.g., cement columns, thermosyphons) to improve bearing capacity and reduce thaw risk, with pilot trials at one pier location (Months 6–12 = 2027-04-12 to 2027-10-12). Design island foundations on a floating or semi-floating principle to accommodate differential subsidence without inducing large moments in the superstructure. Include a 15–20% design contingency in foundation stiffness to allow post-construction upgrading if subsidence monitoring shows thaw is faster than predicted. Establish an observational method protocol with prescribed trigger levels for design review and remedial work (e.g., if subsidence exceeds 0.2 m in the first 2 years, implement additional thermal or mechanical stabilization).

# Risk 9 - Technical

## Immersed-tube tunnel fabrication, tow and installation risk

The immersed-tube tunnel is a novel structure in the Arctic environment; few yards have experience with Arctic-rated tunnel elements. Fabrication of 85 km of tunnel (in segments, typically 200–400 m each) requires specialized yards, heavy lifting capacity and quality assurance for underwater operation. Towing multi-thousand-ton concrete or steel tubes across the North Pacific through storm and ice seasons is technically feasible but carries high risk of weather delays, equipment failure or collision. Installation in a strong current with variable water depth, seabed condition and ice cover requires precise positioning and high-resolution hydrographic data.

- Impact: Tunnel-element fabrication delays of Months 12–24 (2027-10-12 to 2028-10-12) due to yard capacity or quality issues, pushing installation season back (Months 24–36 = 2028-10-12 to 2029-10-12 delay in critical path). Tow-vessel accidents or losses en route, destroying elements and causing Months 6–12 (2027-04-12 to 2027-10-12) schedule slip and $50–200 million USD element replacement cost. Tow-window failures (bad weather) leaving elements at sea through winter, risking ice damage or loss (cost $10–50 million USD per element and Months 3–6 = 2027-01-12 to 2027-04-12 delay). Tunnel-element misalignment or seabed settling during immersion, requiring in-situ repair dives or re-flotation, adding Months 1–3 (2026-11-12 to 2027-01-12) per element and $10–30 million USD cost. Installation productivity lower than planned (e.g., 4 elements per year instead of 6–8), stretching the installation schedule by Years 2–4 (Months 24–48 = 2028-10-12 to 2030-10-12 delay).
- Likelihood: High
- Severity: High
- Action: Conduct a pre-design tunnel-element fabrication feasibility study with candidate yards (Months 0–3 = 2026-10-12 to 2027-01-12) to confirm capacity, past Arctic experience and quality assurance protocols. Select and contract with at least two fabrication yards (preferably on different coasts) to enable parallel production and provide redundancy if one yard is interrupted (Months 3–6 = 2027-01-12 to 2027-04-12). Standardize tunnel-element design (propose 250–300 m length, modular cross-section) to simplify fabrication and allow learning-curve improvements over the first 5–10 elements. Establish a pilot-element trial (Months 9–12 = 2027-07-12 to 2027-10-12): design, fabricate and tow one full-scale element to the site, test installation procedures and instrumentation, and document lessons before full-scale production begins. Secure dedicated ice-class tow vessels (propose 4–6 vessels for redundancy) and negotiate multi-year charter rates to lock in costs and availability (Months 6–9 = 2027-04-12 to 2027-07-12). Establish a tow-route contingency plan allowing sheltering in protected bays (e.g., Nome, Provideniya) if weather forces a seasonal halt; pre-position repair and maintenance crews in those bays. Install real-time GPS, accelerometer and structural-health monitoring on every tube element during tow to detect anomalies (icing, damage, fatigue) before installation. Establish an in-water inspection and repair protocol using remote-operated vehicles (ROVs) before final immersion; budget for unforeseen repairs (propose 5% contingency on installation cost). Sequence tunnel-installation work to align with the clearest open-water windows (Months 6–9 = 2027-04-12 to 2027-07-12 in each construction year) and accept lower installation rates (propose 3–4 elements per year) to ensure safety and quality over schedule acceleration.

# Risk 10 - Technical

## Suspension-bridge main span design and erection risk

The planned suspension-bridge spans of 2–3 km are among the longest in the world, with unprecedented ice and seismic loads. Design of the towers, cables and anchorages requires cutting-edge analysis and testing; erection requires specialized contractor expertise and heavy marine-based lifting equipment. The observational design approach defers design freeze to Months 12–18 (2027-10-12 to 2028-04-12), but if geotechnical or ice-monitoring data are inconclusive, tower foundation design may be locked in without full confidence in load models, and remedial strengthening after construction begins is extremely costly.

- Impact: Design inadequacy if ice or seismic loads are underestimated, requiring in-service strengthening of towers or cables (cost $1–5 billion USD and Years 1–2 disruption). Cable-spinning or strand-raising delays of Months 6–12 (2027-04-12 to 2027-10-12) if contractor capacity is limited or weather forces extended stoppages (Months 36–48 = 2029-10-12 to 2030-10-12 delay in critical path). Tower-base settlement or cracking during or after erection if ground conditions are worse than assumed, requiring costly underpinning and temporary load transfer (cost $100–500 million USD and Months 3–6 = 2027-01-12 to 2027-04-12 delay per tower). Inadequate damping of wind, wave and seismic response leading to vibration issues or fatigue damage (discovered in commissioning or early operation, cost $50–200 million USD and Months 6–12 = 2027-04-12 to 2027-10-12 retrofit).
- Likelihood: Medium
- Severity: High
- Action: Engage world-class cable-suspension bridge specialists (firms with experience on Akashi Kaikyo, Golden Gate or equivalent) as design partners from Month 0 (2026-10-12) onwards. Conduct a detailed cable-dynamics and aerodynamic-stability analysis (Months 3–9 = 2027-01-12 to 2027-07-12) using 1:100 and 1:50 scale models and computational fluid dynamics, with focus on ice-load combinations and seismic response. Establish a tower-foundation design review gate at Month 12 (2027-10-12), contingent on completion of geotechnical surveys and seismic hazard analysis; if data are inconclusive, defer tower-foundation commitments by Months 3–6 (2027-01-12 to 2027-04-12) and extend the observational-monitoring program. Design the main cables with redundancy: assume failure of individual strands and ensure the tower and anchorages remain stable under partial-load conditions. Specify ice-shedding and vibration-damping devices (ice-deflectors, tuned mass dampers, viscous or magnetorheological dampers) in the design to reduce dynamic loads and extend fatigue life. Plan a full-scale prototype test of tower-cable connections, anchorage hardware and damping devices (Months 12–18 = 2027-10-12 to 2028-04-12) before production commitment. Secure a specialized cable-spinning contractor early (Months 6–9 = 2027-04-12 to 2027-07-12) and plan cable-spinning to occur in summer months (Months 6–8 = 2027-04-12 to 2027-06-12) with backup seasons to accommodate weather delays. Pre-fab all major tower components (nodes, welded assemblies) onshore and assemble them at height to reduce field-welding and weather exposure. Include an in-service health-monitoring system (accelerometers, strain gauges, GPS displacement sensors) installed during construction, with real-time data streaming to shore-based monitoring center, enabling early detection of unexpected behavior and adaptive repairs.

# Risk 11 - Operational & Maintenance

## Emergency response and winter operations

The crossing spans 85 km through a remote, harsh Arctic environment with extreme weather and sea ice. Any incident (tunnel fire, bridge collision, major ice-floe damage) requires rapid response, but rescue and recovery bases are hundreds of kilometers away (nearest major centers: Nome, Provideniya). Winter ice and weather can make access to mid-strait difficult or impossible for weeks. Operating a toll-collection and inspection plaza straddling the international boundary adds complexity to emergency command and evacuation.

- Impact: Fatality or mass-casualty event in the tunnel if fire or structural failure occurs and evacuation or rescue is delayed (Months 24–60 = 2028-10-12 to 2031-10-12 operational phase). Loss of a bridge span or tunnel section to ice or seismic damage, closure for Months 6–12 (2027-04-12 to 2027-10-12) and cost $100–500 million USD. Interruption of traffic and revenue for unplanned maintenance or damage assessment (propose Months 5–10 = 2027-03-12 to 2027-08-12 days per incident). Liability claims from users stranded or injured during an incident (cost $10–50 million USD per significant event).
- Likelihood: Medium
- Severity: High
- Action: Establish permanently staffed rescue and maintenance stations at both shores (Months 18–24 = 2028-04-12 to 2028-10-12) with trained emergency responders, medical capability and fire-suppression equipment dedicated to the crossing. Consider a mid-strait station (on an artificial island or rig) staffed seasonally or by rotation (Months 30–36 = 2029-04-12 to 2029-10-12 feasibility assessment) to reduce response time to central tunnel sections. Design the tunnel with multiple cross-passages for emergency evacuation (propose every 500–1000 m), with sealed shelters and fresh-air supply independent of main ventilation. Install a redundant, bi-directional ventilation system capable of clearing smoke from a tunnel fire within 30 minutes; size it for worst-case fire load (Months 12–18 = 2027-10-12 to 2028-04-12 design phase). Establish binational incident-command protocols and joint emergency-response drills (quarterly, starting Month 24 = 2028-10-12) to ensure coordinated response across the maritime boundary. Design the toll-collection and inspection plaza with fail-safe gates (hydraulic locks that activate on power loss) to prevent vehicles from entering the tunnel during an emergency. Install continuous structural-health monitoring (accelerometers, inclinometers, strain gauges) throughout the crossing, with automated alerts if damage thresholds are exceeded, triggering immediate inspection and closure if warranted. Maintain a fleet of ice-breaking and recovery vessels (propose 2–3 dedicated icebreakers and support ships) based at or near site (Months 24–60 = 2028-10-12 to 2031-10-12) for winter operations and emergency response. Establish seasonal weather-based closure triggers (wind speed >80 km/h, visibility <200 m, ice-floe density >7/10 coverage) and closure protocols that both governments have pre-agreed and practiced.

# Risk 12 - Regulatory & Permitting

## Long-lead procurement and supply-chain disruption

Fabrication and delivery of major components (cable, tower steel, tunnel liners, bridge bearings, ventilation fans, electrical and control systems) can require Months 18–36 (2028-04-12 to 2029-10-12) from order to delivery. Global supply-chain disruptions (shipping delays, material shortages, labor disputes, sanctions) have become more frequent; Arctic-specific items (ice-class steel, specialized concrete, cold-weather electronics) have limited suppliers and long lead times. Sanctions on Russian sourcing create further constraints. Any delay in long-lead items can cascade through the construction schedule, delaying critical-path activities by months.

- Impact: Procurement delays of Months 6–12 (2027-04-12 to 2027-10-12) for specialized items, pushing fabrication and delivery back (Months 24–36 = 2028-10-12 to 2029-10-12 impact on construction schedule). Expedited-freight cost premiums of 10–30% if items must be sourced from alternate suppliers or flown to remote sites. Supply-chain alternative sourcing forcing design changes (e.g., if a specified cable manufacturer cannot deliver, design must be modified to use alternate cable, requiring re-analysis and re-certification, cost $5–20 million USD and Months 3–6 = 2027-01-12 to 2027-04-12 delay). Material price escalation of 5–15% due to global market shifts or sanctions-driven sourcing constraints.
- Likelihood: High
- Severity: Medium
- Action: Establish a detailed long-lead-item procurement plan by Month 3 (2027-01-12), identifying every item with a lead time >12 months (cable, towers, tunnel elements, large bearings, electrical equipment, fuel systems). Create a pre-qualified supplier list for all critical items, with primary and secondary sources in different countries (Months 3–6 = 2027-01-12 to 2027-04-12). Issue letters of intent (non-binding) to primary suppliers by Month 6 (2027-04-12) to secure queue position and establish delivery schedules; sign binding supply contracts by Months 9–12 (2027-07-12 to 2027-10-12), with fixed prices and escalation caps. For Arctic-specific items with only 1–2 qualified suppliers, negotiate long-term framework agreements covering multiple projects or future phases (Months 6–12 = 2027-04-12 to 2027-10-12) to secure commitment. Maintain a strategic materials buffer: stockpile 10–15% excess of critical items with long lead times (cable, structural steel) before the start of intensive assembly phases (by Months 18–24 = 2028-04-12 to 2028-10-12), so a mid-project supplier failure does not halt construction. Establish contingency sub-suppliers for high-risk items; engage them in design reviews and conduct prototype tests (Months 12–18 = 2027-10-12 to 2028-04-12) to ensure drop-in compatibility if primary supplier fails. Implement supply-chain risk monitoring: track supplier financial health, geopolitical exposure and capacity utilization monthly, with escalation if risks increase (Months 12–60 = 2027-10-12 to 2031-10-12). Negotiate force-majeure and alternative-source provisions in all supply contracts, allowing design changes and re-sourcing if delivery fails without liability to the project for reasonable substitutes. Pre-position critical consumables (fuel, spare parts, electronics) at the Arctic base camps starting Month 18 (2028-04-12), so operations are not disrupted by seasonal supply-ship delays.

# Risk 13 - Supply Chain & Procurement

## Labor availability and Arctic workforce turnover

Construction and operations of the crossing require skilled workers (welders, divers, engineers, equipment operators) in a remote Arctic environment with extreme weather, isolation and limited amenities. Turnover is typically 30–50% annually on remote Arctic projects, disrupting productivity and quality. Housing, food and transportation must be provided at significant cost. Worker recruitment and visa issuance for binational teams face geopolitical delays if US-Russia relations deteriorate.

- Impact: Labor productivity 20–40% below southern baseline due to turnover, training and weather stoppages, adding Months 6–12 (2027-04-12 to 2027-10-12) to schedule (Months 30–60 = 2029-04-12 to 2031-10-12 impact). Labor cost inflation of 20–30% above regional rates due to remote premium and mobilization overhead (cost $5–15 billion USD over the program). Visa delays or denials preventing workers from crossing the border, causing project idle time (cost $10–30 million USD per month). Quality defects due to inexperienced crews, requiring rework (cost $50–200 million USD and Months 3–6 = 2027-01-12 to 2027-04-12 delay).
- Likelihood: High
- Severity: High
- Action: Develop a detailed workforce plan by Month 6 (2027-04-12) identifying peak labor demand by trade, skill level and nationality, and establishing recruitment and retention strategies. Establish long-term partnerships with regional vocational and technical schools (Months 3–9 = 2027-01-12 to 2027-07-12) in Alaska and Chukotka to train Arctic workers in specialized skills (underwater welding, ice mechanics, remote equipment operation); offer apprenticeships and permanent-hire pathways to improve retention. Secure housing, food and transportation infrastructure at base camps before peak mobilization (Months 12–18 = 2027-10-12 to 2028-04-12): hire established Arctic logistics contractors, establish camp standards and ensure worker amenities exceed baseline (propose single rooms, high-speed internet, recreational facilities) to improve morale and retention. Negotiate binational visa and work-permit agreements (Months 6–12 = 2027-04-12 to 2027-10-12) that streamline processing for project workers and allow multi-year residency for key staff, reducing re-entry delays. Establish a redundant-crew model: develop a core team of 100–150 highly trained specialists (engineers, supervisors, divers, equipment operators) hired on multi-year contracts, with permanent base-camp presence; surround them with rotating semi-skilled labor hired seasonally or on project-phase contracts. Implement safety and quality-incentive programs that reward low injury rates, zero-rework milestones and on-time delivery; tie contractor payments to performance metrics. Document procedures and Standard Operating Procedures comprehensively (Months 12–18 = 2027-10-12 to 2028-04-12) so that high turnover does not require constant re-training; use video training and e-learning platforms for remote delivery. Budget 10–15% of labor cost for training, safety standdowns and quality assurance.

# Risk 14 - Environmental

## Marine mammal and fisheries impact

The Bering Strait is a critical migration corridor and feeding area for bowhead whales, beluga, walrus, seals and commercial fish stocks (pollock, crab). Dredging, piling, tunnel trenching and marine-traffic noise can disrupt migration, feeding and breeding, and alter fish populations. US and Russian marine-protection laws require mitigation, but enforcement and effectiveness are uncertain in the remote environment. Indigenous subsistence harvesting may be impacted, triggering social and legal conflicts.

- Impact: Regulatory shutdown of construction (Months 3–6 = 2027-01-12 to 2027-04-12) if unexpected marine mammal impacts or injury are documented, requiring design or method changes (cost $10–50 million USD). Fines or penalties under US Marine Mammal Protection Act or Russian environmental law (propose $1–10 million USD). Requirement to redesign dredging, piling or tunnel methods to reduce noise or disruption, adding cost ($50–200 million USD) and schedule (Months 6–12 = 2027-04-12 to 2027-10-12). Litigation from Indigenous communities if subsistence harvests are impacted, causing project delays (Months 3–12 = 2027-01-12 to 2027-10-12) and adding legal costs ($5–20 million USD).
- Likelihood: Medium
- Severity: Medium
- Action: Conduct a comprehensive baseline survey of marine mammal populations, migration timing, feeding areas and fish stocks in the strait and approaches (Months 0–12 = 2026-10-12 to 2027-10-12), using passive acoustic monitoring, visual surveys and ecological sampling. Establish binational marine-protection protocols and monitoring programs with Indigenous observers co-leading baseline studies and on-site monitoring (Months 0–12 = 2026-10-12 to 2027-10-12 onwards). Adopt construction methods that minimize underwater noise: use vibratory pile-driving instead of impact piling, bubble curtains to attenuate shock waves, and low-frequency dredging or trenching equipment (Months 12–18 = 2027-10-12 to 2028-04-12 design finalization). Implement a fixed seasonal-work calendar aligned with marine-mammal migration and breeding (propose: no impact piling June–November for whale migration; no dredging May–July for fish spawning; adjust as data arrive). Establish real-time passive acoustic monitoring on site (Months 18–60 = 2028-04-12 to 2031-10-12 construction) with automatic shutdown if belugas, bowhead or other protected species are detected within 10 km. Designate exclusion zones (propose 15–20 km radius from piling sites during sensitive seasons) and enforce them through coordination with US and Russian marine-enforcement agencies. Fund Indigenous subsistence-protection and community-benefit programs: provide alternative fishing areas, gear and training if traditional areas are impacted; commit to hiring and training Indigenous workers for monitoring and construction roles. Prepare an adaptive-management protocol allowing seasonal and methodological adjustments if monitoring shows impacts exceeding predictions (Months 12–60 = 2027-10-12 to 2031-10-12).

# Risk 15 - Environmental

## Climate change and permafrost thaw acceleration

The plan is designed for a century-scale design life, but Arctic permafrost is thawing faster than historical models predicted. Bearing capacity of pile foundations can degrade as ground-ice content decreases, and subsidence may accelerate over the design life. Thaw-induced settlement of 0.5–2.0 m is plausible for some foundation types, creating alignment changes, bridge-deck sag, tunnel-settling and long-term maintenance burdens. Sea-level rise and increased storm surge may also impact shore facilities.

- Impact: Accelerated foundation subsidence (0.5–2.0 m over 50–100 years) requiring costly raising or underpinning of piers and bridges (cost $100–500 million USD in Months 120–180 = 2036-10-12 to 2041-10-12 post-opening). Alignment changes that stress bridge joints and tunnel bores, causing accelerated wear and increased maintenance (cost $10–50 million USD annually, Months 60–180 = 2031-10-12 to 2041-10-12). Coastal-facility flooding or erosion due to sea-level rise and storm surge, requiring relocation or strengthening (cost $100–500 million USD per shore facility, Months 120–180 = 2036-10-12 to 2041-10-12). Long-term revenue impact if repeated maintenance and closures reduce reliability and attractiveness of the crossing.
- Likelihood: Medium
- Severity: Medium
- Action: Design foundations with explicit climate-change scenarios: assume 2–4°C warming over the design life and model permafrost thaw using latest IPCC climate models (Months 6–12 = 2027-04-12 to 2027-10-12). Select foundation types that tolerate differential subsidence: floating foundations, adjustable bearing pads, or semi-floating systems that distribute loads evenly across thawing ground. Design bridge expansion joints and tunnel articulations to accommodate predicted settlements (0.5–1.0 m per 10 km span) without distress. Establish long-term ground-temperature and subsidence monitoring (Months 0–180 = 2026-10-12 to 2041-10-12 operational life) with annual surveys of foundation settlements, permafrost temperatures and ground-ice content; trigger remedial work if subsidence rates exceed 0.05 m/year. Specify thermosyphon or active-cooling systems under critical foundations to maintain permafrost stability and slow thaw (Months 18–30 = 2028-04-12 to 2029-04-12 detail design). Raise shore facilities above projected high-tide and storm-surge levels (propose 2–3 m elevation above current high tide as minimum). Budget for periodic major maintenance and foundation renewal starting Month 90 (2034-04-12) (around 2034-04-12) and plan for a 50-year major refresh or rebuilding phase starting Month 150 (2039-04-12) (around 2039-04-12). Incorporate climate-change impacts into long-term financial forecasting and reserve funds for adaptation (propose 0.5–1% of annual operating revenue).

# Risk 16 - Political & Geopolitical

## Binational governance deadlock and operational disputes

Even with a joint authority in place, the US and Russian governments retain sovereignty over their waters and can issue conflicting orders regarding tolling, traffic restrictions, security protocols or emergency response. Disputes over bridge operations (e.g., closure authority, toll rates, access restrictions) can stall decision-making or require escalation to diplomatic channels, affecting real-time operations. A mid-strait incident requiring binational coordination can be delayed if protocols or authority structures are unclear.

- Impact: Operational delays of hours to days if closure or access decisions are disputed, reducing revenue and user confidence (cost $1–5 million USD per incident and reputational damage). Inability to set toll rates or enforce tariffs uniformly, creating revenue uncertainty (propose 5–10% revenue variance if governance conflicts lead to inconsistent enforcement). Litigation in national courts with conflicting outcomes, stranding the operator in legal limbo and potentially requiring forced restructuring (cost $50–200 million USD and Years 1–2 disruption). Unilateral action by one government (e.g., US closure of the link on security grounds), stranding infrastructure and personnel on the other shore.
- Likelihood: Medium
- Severity: High
- Action: Negotiate detailed operational protocols and decision-making procedures in the treaty or concession agreements (Months 0–6 = 2026-10-12 to 2027-04-12), including: authority hierarchy for toll setting, traffic restrictions, emergency closure, and incident response; dispute-resolution mechanisms (arbitration, expert panels) with binding authority; and escalation paths to diplomatic channels only if operational authority is deadlocked. Establish a binational Operations Committee with permanent representation from both governments, technical staff and the operator, meeting monthly to align policies and address emerging disputes before they become deadlocks (Months 24 onwards, starting Month 18 = 2028-04-12 in planning). Draft detailed incident-response protocols specifying command authority, communication procedures, and decision-making timelines (e.g., closure decisions must be made within 1 hour; disputes escalate to a neutral arbiter for 2-hour resolution if governments disagree). Establish a Neutral Arbiter (propose a retired judge or international arbitrator with authority to rule on operational disputes within a tight timeline) with binding decision authority to break deadlocks without requiring government agreement (Months 6–12 = 2027-04-12 to 2027-10-12 negotiation). Implement a shared operational-control system where both governments and the operator have real-time access to incident data, allowing all parties to see the factual basis for decisions and reducing disputes based on information asymmetry. Publish operational manuals and decision rules in advance so all stakeholders understand the authority structure and decision timelines; conduct joint exercises and drills to practice decisions in advance (Months 12–18 = 2027-10-12 to 2028-04-12 planning phase, then quarterly starting Month 24 = 2028-10-12).

# Risk 17 - Political & Geopolitical

## Revenue underperformance and traffic-demand shortfall

The business plan assumes traffic volumes on the basis of trade forecasts, but actual demand depends on feeder infrastructure (roads, rail, ports) on both sides, economic conditions in Russia and Alaska, sanctions-driven trade restrictions, and the competitiveness of the crossing versus alternative routes. A global recession, energy-price collapse or continued sanctions could reduce freight and tolling revenue by 20–50% versus baseline, threatening debt service coverage and lender confidence.

- Impact: Debt service coverage falling below 1.2x if traffic revenue is 30–50% below plan, triggering covenant breaches and potential default (cost $100–500 million USD in financing restructuring and equity write-downs). Requirement to raise tolls, reducing traffic further and creating a negative spiral (revenue decline of 5–10% per 1% toll increase, Months 60–120 = 2031-10-12 to 2036-10-12 operational phase). Inability to fund scheduled maintenance or capital improvements, leading to deterioration and eventual safety closure (cost $50–200 million USD and loss of operating revenue). Equity investor losses and potential government bailout demands.
- Likelihood: Medium
- Severity: High
- Action: Commission independent traffic and demand studies (Months 0–6 = 2026-10-12 to 2027-04-12) from recognized transport-modeling firms (e.g., Parsons, AECOM, Steer) using conservative baseline scenarios and documented downside cases (recession, sanctions tightening, modal shift to air). Build financing on conservatively underwritten revenue: propose underwriting debt to 70% of conservative-case revenue, not baseline or upside (effective debt service coverage of 1.5–2.0x in the conservative case). Pre-sell capacity and revenue rights to anchor tenants (freight forwarders, pipeline operators, fiber carriers) through long-term take-or-pay contracts (Months 6–12 = 2027-04-12 to 2027-10-12), locking in minimum revenue independent of actual traffic (propose 30–50% of expected revenue from contracts). Include availability-payment or utility-revenue components in the financing structure (Months 12–18 = 2027-10-12 to 2028-04-12) to reduce debt dependency on volatile traffic volumes. Establish a revenue-sharing structure where if traffic exceeds plan, a portion of surplus revenue is retained for maintenance and reserve funds, ensuring long-term viability independent of continued high demand. Conduct quarterly traffic monitoring (Months 60 onwards, post-opening) and update demand forecasts; if traffic trends 10–15% below plan, trigger a strategic review of toll rates, service offerings or feeder-infrastructure investments to stimulate demand. Build a contingency fund (propose 10–15% of annual operating revenue) to weather temporary demand shortfalls and avoid covenant breaches.

# Risk 18 - Project Management & Integration

## Coordination complexity and interface management

The project involves two structural types (suspension bridge and immersed-tube tunnel), multiple interface points, separate national permitting regimes, and multinational contractors and suppliers. Design coordination across span, tunnel and island systems is challenging; any misalignment (e.g., tower foundation settlement affecting approach-bridge alignment, or island subsidence affecting tunnel portal elevation) can require expensive redesign or rework. Binational contract administration across two legal systems and currencies compounds complexity.

- Impact: Interface conflicts or misalignments discovered during construction, requiring design changes and rework (cost $50–200 million USD and Months 3–12 = 2027-01-12 to 2027-10-12 delay). Change orders and claims driven by unclear interface requirements, inflating cost (propose 5–10% overhead for interface-related changes). Contractor disputes over responsibility for interface failures, potentially requiring arbitration (cost $5–20 million USD in legal and time). Delays in decisions or approvals due to differing timelines or interpretations of contracts across two jurisdictions.
- Likelihood: High
- Severity: Medium
- Action: Establish a robust governance structure with clear roles and authorities (Months 0–6 = 2026-10-12 to 2027-04-12): designate a single Owner's Engineer or Integrator with unambiguous authority over interface definition and change control. Create an Interface Control Board (ICB) meeting monthly (Months 6–60 = 2027-04-12 to 2031-10-12) with representatives of the owner, designers, major contractors and both governments, with a formalized process for identifying, tracking and resolving interface issues. Develop detailed interface-control documents for every connection between span, tunnel and island systems (Months 6–18 = 2027-04-12 to 2028-04-12), specifying loads, tolerances, environmental conditions and acceptance criteria; require all contractors to sign off on these documents before design is frozen. Use a single integrated project-management system (e.g., Primavera P6, Oracle Cloud) with real-time visibility of schedule, budget and change orders across all contractors; enforce change-control discipline with documented impact analysis before approval (Months 6–60 = 2027-04-12 to 2031-10-12). Conduct design reviews (preliminary in Months 9–12 = 2027-07-12 to 2027-10-12, critical in Months 12–15 = 2027-10-12 to 2028-01-12) with independent external reviewers from world-class engineering firms to identify interface conflicts early. Require all major long-lead procurement (towers, cables, tunnel elements) to have interface drawings stamped and approved by the ICB before fabrication begins (Months 15–18 = 2028-01-12 to 2028-04-12). Establish a neutral-arbiter mechanism for interface disputes: if contractors or designers disagree on interface responsibility or solution, an independent engineer with binding authority resolves it within 2 weeks, preventing escalation to litigation.

# Risk 19 - Operational & Maintenance

## Long-term O&M cost and staffing sustainability

Once operational (from Month 60 = 2031-10-12 onwards), the crossing requires year-round maintenance of ice-detection and structural-health systems, de-icing equipment, tunnel ventilation and safety systems, emergency response capability, and toll-collection infrastructure. Arctic operations are inherently costly and staff-intensive; continuous staffing in a harsh environment over a multi-decade horizon faces turnover, training and recruitment challenges. O&M costs can escalate 5–10% annually due to inflation, making long-term financial viability uncertain.

- Impact: O&M costs escalating to 15–25% of annual revenue (vs. historical 5–10% baseline for temperate bridges), consuming margin and reducing debt service capacity (Months 60–180 = 2031-10-12 to 2041-10-12 operational phase). Inadequate maintenance deferral due to budget constraints, leading to premature deterioration and eventual safety closure (cost $100–500 million USD in emergency repairs and lost revenue). Staffing shortages at critical facilities (rescue stations, toll plazas) due to turnover, reducing service reliability and safety (cost $5–20 million USD in inefficiency and accidents).
- Likelihood: High
- Severity: Medium
- Action: Develop a detailed O&M cost model by Month 12 (2027-10-12), accounting for Arctic labor premiums (propose 30–50% above southern baseline), specialized equipment (icebreakers, drones, diving support vessels), and consumables. Build a long-term service-level agreement and staffing plan (Months 18–24 = 2028-04-12 to 2028-10-12) with estimated annual costs by category (personnel, equipment, maintenance, emergency response); include 5–10% annual escalation. Establish a dedicated O&M fund, funded from year 1 of operations (propose 12–15% of annual toll and utility revenue) and invested conservatively to earn interest; target a balance of $500 million–$1 billion USD by Month 120 (2036-10-12) (around 2036-10-12) to ensure cash availability for major maintenance and replacement cycles. Automate critical monitoring and detection systems (structural health, ice conditions, air quality) to reduce labor dependency; use remote-operated vehicles, drones and autonomous sensors to replace human presence in harsh conditions (Months 30–36 = 2029-04-12 to 2029-10-12 specification and procurement). Establish partnerships with regional universities and technical schools to train and certify Arctic O&M specialists; create apprenticeship programs and permanent-hire pathways to improve retention (Months 24–36 = 2028-10-12 to 2029-10-12 implementation). Develop a comprehensive O&M manual with detailed procedures, video training and e-learning modules for all systems, so that high staffing turnover does not compromise safety or reliability (Months 18–24 = 2028-04-12 to 2028-10-12 documentation). Conduct annual O&M budget reviews and forecasting updates; escalate costs promptly and consider toll increases or service reductions if O&M costs are trending above plan. Include a contractual mechanism (e.g., indexed toll rates) allowing tolls to rise with documented cost escalation, protecting financial viability without requiring annual approval.

# Risk 20 - Assumptions & Missing Information

## Detailed cost-estimate data and sources not provided

The plan specifies cost components (materials, labor, logistics) and a total CAPEX range ($80–120 billion USD estimate) but does not provide detailed unit costs, productivity rates, or validated cost indices for Arctic construction. Without these, cost forecasting has wide confidence intervals and contractors will price risk heavily.

- Impact: Cost contingencies bid by contractors (propose 15–25% premiums) inflate the funding requirement; if actual costs track the baseline without these premiums, equity returns are better than lenders expect, creating moral-hazard pressure. Conversely, if contingencies are inadequate, cost overruns and financing gaps result (Months 18–36 = 2028-04-12 to 2029-10-12 risk). Budget credibility depends on detailed cost justification; missing cost data undermine confidence in the plan.
- Likelihood: High
- Severity: Medium
- Action: Commission a detailed parametric cost model by Month 3 (2027-01-12) from Arctic-construction specialists (e.g., HDR, Jacobs, Golder), building unit costs from regional labor and material surveys, historical Arctic projects (pipeline, platform, port construction), and inflation indices. Establish a Cost Task Force with contractors and suppliers to validate cost estimates and resolve outliers (Months 3–6 = 2027-01-12 to 2027-04-12). Document all cost assumptions and sources in a Cost Basis Document; publish it for contractor review and feedback (Month 6 = 2027-04-12). Conduct sensitivity analysis on key cost drivers (labor escalation, material inflation, exchange rates, logistics premiums) and publish downside and upside cases (Month 6 = 2027-04-12). Implement a detailed cost-tracking system (Months 6–60 = 2027-04-12 to 2031-10-12) comparing actual costs to baseline by category and geography, with monthly reforecasting and variance analysis. Include a formal Cost Engineer role in the Owner's Team (Months 6 onwards) with authority to investigate and report cost deviations.

# Risk 21 - Assumptions & Missing Information

## Financing structure and lender engagement not confirmed

The plan proposes a third-country investor consortium, multilateral banks and availability payments, but no specific lenders or investors have been identified or engaged. Without pre-commitment from lenders, the financing structure is speculative and faces significant execution risk.

- Impact: Financing close delayed by Months 6–12 (2027-04-12 to 2027-10-12) if identified lenders withdraw or demand higher terms (Months 12–18 = 2027-10-12 to 2028-04-12 risk). Capital-raising costs and complexity increase if a less-ideal financing structure is substituted (e.g., if all-equity funding is required, diluting returns). Conditions placed by lenders on design, contracting or governance that conflict with the project plan (cost Months 3–6 = 2027-01-12 to 2027-04-12 and design changes of $10–50 million USD).
- Likelihood: High
- Severity: Medium
- Action: Launch an investor-engagement process by Month 1 (2026-11-12), identifying and pre-qualifying potential lenders and equity investors (propose 5–10 development banks, infrastructure funds and export-credit agencies). Conduct one-on-one meetings with each (Months 1–3 = 2026-11-12 to 2027-01-12) to understand their sanctions policies, Arctic-project experience and term expectations. Issue a preliminary Information Memorandum (Months 3–4 = 2027-01-12 to 2027-02-12) outlining the project, deal structure and financial assumptions; solicit feedback and refine the structure based on lender input. Host an investor roundtable (Months 4–5 = 2027-02-12 to 2027-03-12) to present the plan, field questions and assess lender interest in participating in later syndication or term sheets. Conduct a formal financing-roadmap workshop (Month 6 = 2027-04-12) with target lenders to align on structure, terms and gating conditions; negotiate heads of terms or a term sheet (Months 6–9 = 2027-04-12 to 2027-07-12) with at least 2–3 lead arrangers to demonstrate confidence in financial close. Include lender representatives in the Steering Committee and Technical Advisory Board so their concerns are addressed early (Months 6 onwards). Establish explicit financing gates in the project schedule (Month 6 = 2027-04-12 for heads of terms, Month 12 = 2027-10-12 for financial close) with paid pause and exit provisions if financing does not materialize, protecting sunk investment and credibility.

# Risk 22 - Assumptions & Missing Information

## Indigenous community engagement and consent authorities not defined

The plan recognizes Indigenous Consent as critical, but does not specify which communities have authority over which decisions, how consent is obtained or validated, or how binding their authority is. Without clarity, Indigenous engagement can become a source of delay or litigation rather than a controlled gate.

- Impact: Permitting delays of Months 6–12 (2027-04-12 to 2027-10-12) if Indigenous consent processes are incomplete or disputed (Months 12–24 = 2027-10-12 to 2028-10-12 risk). Litigation or injunctions if Indigenous groups claim they were inadequately consulted or their consent was not obtained (Months 18–36 = 2028-04-12 to 2029-10-12 potential impact). Community benefit agreements are negotiated late in the project, causing cost surprises and resentment (cost $100–500 million USD in commitments and Months 3–12 = 2027-01-12 to 2027-10-12 delay).
- Likelihood: Medium
- Severity: High
- Action: Conduct a formal Indigenous-stakeholder mapping by Month 1 (2026-11-12), identifying all communities with traditional-use claims, subsistence harvesting rights, or regulatory authority over the alignment (propose: Inupiat, Yupik communities in Alaska; Chukchi, Yupik, other Indigenous groups in Russia). Engage each community through their established governance structures (tribal councils, traditional-use advisory boards) starting Month 1 (2026-11-12); fund capacity-building so communities can hire their own legal and technical advisors (Months 1–6 = 2026-11-12 to 2027-04-12). Establish a Beringia Indigenous Council (Months 3–6 = 2027-01-12 to 2027-04-12 formation) with binding advisory authority over alignment, seasonal work windows and mitigation measures; include representation from each identified community and ensure it has legal standing and funding. Co-author baseline studies with Indigenous community researchers (Months 0–12 = 2026-10-12 to 2027-10-12), documenting traditional knowledge, subsistence patterns and environmental conditions; use these studies to inform environmental and social-impact assessment. Develop formal consent agreements (MOUs or FCIAs) with each community (Months 6–12 = 2027-04-12 to 2027-10-12), specifying: what decisions require consent; what constitutes informed consent; how disputes are resolved; and what benefit-sharing or compensation applies. Include these agreements in the project gating (Month 12 = 2027-10-12 gate requires all consent agreements signed and community boards' final approval). Establish a Community Benefit Fund (propose 1–2% of annual revenue, or fixed annual payment of $10–30 million USD) managed jointly by the operator and Indigenous Council, dedicated to training, infrastructure and mitigation programs identified by communities.

# Risk summary

This 85 km binational Arctic mega-infrastructure project faces existential risks across political, financial and technical domains. The three most critical risks are:

- Political Gating and Sanctions Exposure: treaty ratification, sanctions licensing and US-Russia geopolitical tension create binary kill-switch risks that cost, schedule and financing cannot mitigate.

- Capital Cost and Financing Uncertainty: estimated CAPEX of $80–120 billion USD with wide contingency bands, coupled to sanctions-driven constraints on lender participation and supply-chain costs, creates funding and debt-service risk that could strand the project mid-construction.

- Technical Data Unknowns (Ice, Seismic, Permafrost): the observational design approach depends on Months 12–18 (2027-10-12 to 2028-04-12) monitoring campaigns to inform design freeze, but if data are delayed or ambiguous, design decisions are made under incomplete information, creating post-construction liability and repair costs.

The project is bankable only if these three risk clusters are sequenced through explicit gates with paid pause and exit provisions, with a neutral third-party legal vehicle and a third-country financing consortium that remain sanctions-compatible. The 2026–2041 timeline is aggressive; realistically, Months 0–18 (2026-10-12 to 2028-04-12) should focus on permitting, baseline data and financing, with construction gates at Months 18–24 (2028-04-12 to 2028-10-12) contingent on treaty ratification, sanctions licensing and validated cost/schedule. The staged rail-and-utility tunnel approach (vs. the full hybrid up front) preserves optionality and limits sunk-cost exposure while foundations are sized for later suspension-span and road additions. Strong Indigenous consent and binational governance protocols are essential to operability and social license; underestimating these creates litigation and reputational risk that outweighs near-term schedule savings.

# Make Assumptions
# Question 1 - Total CAPEX envelope, contingency level, and committed funding sources for the gated tunnel-first phase

## Assumptions

- Phase-1 tunnel-first CAPEX is $80-120 billion USD (estimate from risk file; detailed model pending)
- 12-15% contingency pool (proposed)
- USD as primary currency
- Governments contribute land, rights-of-way and guarantees
- Third-country consortium supplies debt and equity
- Early capital limited to surveys and design: $50-150 million before ratification

## Financial Feasibility Assessment

Gating caps stranded cost at roughly $50-150 million (estimate) before treaty ratification. Overrun exposure is 10-30% of baseline ($10-30 billion, estimate).

Mitigation:

- Parametric cost model by Month 3
- 12 (2027-01-12 to 2027-10-12)-15% contingency
- Utility take-or-pay pre-sales for 30-50% of revenue (proposed)
- Fiber and power leases provide early cash flow

Key risk: no lender yet engaged; heads of terms targeted by Month 9 (2027-07-12).

# Question 2 - Critical-path milestones, decision gates, and timeline absorption for treaty, licensing, survey and financial-close lead times

## Assumptions

- Months 0-12 (2026-10-12 to 2027-10-12) cover baseline surveys, Indigenous agreements and financing roadmap
- Gates fall at Months 6, 12, 18 and 24 (2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12)
- Design freeze near Month 18 (2028-04-12) after 12-18 months of monitoring
- Construction starts only after ratification, licensing and financial close, likely beyond Month 24 (2028-10-12)
- Full road-and-span phase extends past Month 180 (2041-10-12)

## Schedule Feasibility Assessment

Ratification slip of 12-36 months (estimate) is the dominant schedule risk. Observational design needs at least one full ice season; Month 18 (2028-04-12) is earliest credible freeze. Tunnel element fabrication and tow rely on short open-water windows; one lost season delays by about 12 months.

Mitigation:

- Parallel domestic permitting
- Pilot element trial at Months 9-12 (2027-07-12 to 2027-10-12)
- Schedule float of 6-12 months
- Treat 2041 date as target for phase 1, not for full hybrid

# Question 3 - Core team, specialist contractors, vessels and workforce sourcing given sanctions and Arctic remoteness

## Assumptions

- Core team of 100-150 specialists (proposed) on multi-year contracts
- Owner's engineer integrator
- At least two fabrication yards
- 4-6 ice-class tow vessels (proposed)
- Labor drawn from Alaska, Chukotka and third countries
- Arctic labor premium of 30-50% (proposed)
- Fabrication in Pacific yards in non-sanctioned jurisdictions

## Resource Adequacy Assessment

Few yards have Arctic immersed-tube experience; dual-sourcing reduces single-point failure. Turnover of 30-50% annually (estimate) cuts productivity 20-40%.

Mitigation:

- Apprenticeships with regional schools
- High-standard camps and SOPs
- E-learning
- Multi-year vessel charters
- Negotiate binational work-permit protocol by Month 12 (2027-10-12)

Risk: visa bottlenecks could cost $10-30 million per month (estimate).

Opportunity: local hire builds social licence.

# Question 4 - Legal vehicle, treaty or concession instruments, permit pathways (NEPA, Russian EIA, sanctions licensing) for ownership, liability and disputes at maritime boundary

## Assumptions

- Neutral special-purpose entity chartered in third country or under international regime holds ownership
- Both governments hold contractual rights
- Framework agreement sought first, not full treaty
- OFAC and export-control guidance sought by Month 6 (2027-04-12)
- Permits tiered: framework permits Months 6-9 (2027-04-12 to 2027-07-12), detailed marine permits Months 12-18 (2027-10-12 to 2028-04-12)
- Neutral arbiter resolves operational deadlocks

## Governance and Regulatory Assessment

Neutral entity reduces ratification veto risk but leaves permanent seam for liability, customs and closure authority; define command and toll rules up front. Sanctions licensing is the gating uncertainty; unlicensed structures are unbankable. Permitting delay of 18-24 months (estimate) is plausible.

Mitigation:

- Early regulator engagement
- Export-control counsel
- Force-majeure and supplier-substitution clauses
- Paid pause and exit at each gate

# Question 5 - Design load cases, safety standards, emergency doctrine for ice, seismic, permafrost, tunnel fire and winter closure

## Assumptions

- Observational design with probabilistic return periods (50, 100 and 500 years, proposed)
- Sacrificial ice deflectors
- 10-20% foundation reserve capacity (proposed)
- Staffed rescue stations at both shores
- Cross-passages every 500-1000 m (proposed)
- Pre-agreed closure triggers (proposed thresholds)
- Binational incident command centre operates under single safety code

## Safety and Risk Assessment

Highest risks: ice loads exceeding historic records, seismic-permafrost interaction, tunnel fire with delayed rescue. Over-design could add $5-15 billion (estimate); under-design risks repairs of $50-200 million per incident (estimate).

Mitigation:

- 12-18 month monitoring
- Pier prototypes
- Independent design review
- Quarterly joint drills
- Structural-health monitoring
- Gate foundation commitment on data adequacy; do not freeze design by calendar alone

# Question 6 - Environmental baselines, marine mammal limits, carbon targets and climate-adaptation measures

## Assumptions

- Baseline marine mammal, fisheries and ground-temperature surveys run Months 0-12 (2026-10-12 to 2027-10-12) with Indigenous co-leads
- Low-noise methods (vibratory, bubble curtains) and real-time acoustic monitoring with shutdown zones
- Design assumes 2-4 °C warming over design life (proposed)
- Shore facilities sit 2-3 m above current high tide (proposed)
- Carbon accounting baseline set before procurement

## Environmental Impact Assessment

Strait is migration corridor for bowhead, beluga and walrus; stop-work orders of 3-6 months (estimate) are plausible. Dynamic monitoring flexes windows but creates unpredictable idle time contractors will price. Permafrost thaw of 0.5-2.0 m (estimate) drives thermosyphons and adjustable bearings.

Mitigation:

- Fixed core calendar plus monitored adjustments
- Exclusion zones
- Subsistence protection fund
- Prefabrication reduces Arctic footprint but adds tow emissions

# Question 7 - Indigenous communities, agencies, investors and research bodies engagement with consent authority and sequence before permitting milestones

## Assumptions

- Stakeholder mapping completes by Month 1 (2026-11-12)
- Beringia Indigenous Council forms by Months 3-6 (2027-01-12 to 2027-04-12) with binding advisory authority over alignment, work windows and mitigation
- Consent agreements signed by Month 12 (2027-10-12)
- Benefit fund of 1-2% of revenue or $10-30 million per year (proposed)
- US DOT, Russian Ministry of Transport, lenders and research institutions join advisory bodies

## Stakeholder Engagement Assessment

Unresolved consent could cause 6-18 month injunctions and $5-15 million legal cost (estimate). Differing US and Russian rights frameworks require dual-documented agreements.

Mitigation:

- Funded community legal and technical advisors
- Indigenous-led baselines
- Local hire targets
- Observers on all marine works
- Define scope of consent clearly to bound schedule risk

Opportunity: visible legitimacy milestone for both governments.

# Question 8 - Operating model, border and customs process, toll and utility systems, maintenance regime and availability targets

## Assumptions

- Phase 1 carries rail and utilities (fiber, power) in segregated galleries
- Excludes pressurized hydrocarbon pipelines
- Customs and immigration processed at shore plazas with sealed-transit freight
- Operations authority runs 24/7 with automated monitoring, drones and ROVs
- O&M reserve of 12-15% of revenue (proposed)
- Indexed tolls support long-term upkeep

## Operational Systems Assessment

Arctic O&M may reach 15-25% of revenue (estimate) versus 5-10% for temperate bridges. Shore-based inspection avoids mid-strait border facility but requires sealed-transit trust between governments. Traffic shortfall of 20-50% (estimate) is covered by debt sized to 70% of conservative-case revenue and take-or-pay contracts.

Mitigation:

- Automation
- Structural-health monitoring
- Early O&M model by Month 12 (2027-10-12)
- Indexed tolls
- Staffing pipeline


# Distill Assumptions
# Bering Strait Link – Phase 1 Plan

## Project Scope

- Rail-and-utility immersed tunnel on foundations sized for later suspension spans and road lanes.
- Phase 1 CAPEX: $80–120 billion (estimate), with 12–15% contingency (proposed).
- Pre-ratification spending limited to surveys and design: $50–150 million (estimate).

## Financing Structure

- Third-country consortium supplies debt and equity; governments contribute land, rights-of-way and guarantees, not cash.
- Debt sized to 70% of conservative-case revenue, backed by take-or-pay pre-sales of 30–50% (proposed).
- Heads of terms with lender targeted by Month 9 (2027-07-12).
- Sanctions licensing is the gating uncertainty; unlicensed structures are unbankable.

## Decision Gates and Schedule

- Gates at Months 6, 12, 18 and 24 (2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12) with paid pause and exit provisions.
- Months 0–12 (2026-10-12 to 2027-10-12): baseline surveys, Indigenous agreements and financing roadmap.
- Design freeze near Month 18 (2028-04-12), after 12–18 months of monitoring, gated on data adequacy.
- Construction starts after ratification, licensing and financial close, likely beyond Month 24 (2028-10-12).
- Ratification slip of 12–36 months (estimate) is the dominant schedule risk.
- Phase 1 targets 2041; full road-and-span phase extends past Month 180 (2041-10-12).

## Governance and Ownership

- Neutral third-country special-purpose entity owns the link; governments hold contractual rights.
- Framework agreement, not a full treaty, sought first.
- OFAC and export-control guidance by Month 6 (2027-04-12).
- Framework permits in Months 6–9 (2027-04-12 to 2027-07-12); detailed marine permits in Months 12–18 (2027-10-12 to 2028-04-12).

## Engineering and Design

- Core team: 100–150 specialists, owner's engineer integrator, two or more yards, and 4–6 ice-class tow vessels (proposed).
- Fabrication in non-sanctioned Pacific yards; one lost open-water season delays approximately 12 months.
- Observational approach using 50/100/500-year return periods, sacrificial ice deflectors and 10–20% foundation reserve (proposed).
- Design assumes 2–4 °C warming and shore facilities 2–3 m above high tide (proposed).

## Labor and Workforce

- Labor from Alaska, Chukotka and third countries, with 30–50% Arctic premium (proposed).
- Binational work-permit protocol negotiated by Month 12 (2027-10-12) to avoid visa bottlenecks.

## Environmental and Safety Measures

- Marine mammal, fisheries and ground-temperature baselines run Months 0–12 (2026-10-12 to 2027-10-12) with Indigenous co-leads.
- Low-noise methods and real-time acoustic monitoring apply; stop-work orders of 3–6 months are plausible (estimate).
- Rescue stations at both shores, cross-passages every 500–1000 m, and one binational incident command under a single safety code.

## Indigenous Engagement

- Beringia Indigenous Council forms by Months 3–6 (2027-01-12 to 2027-04-12); consent agreements signed by Month 12 (2027-10-12).
- Benefit fund of 1–2% of revenue or $10–30 million per year (proposed).

## Operations and Utilities

- Phase 1 excludes pressurized hydrocarbon pipelines; fiber and power run in segregated galleries.
- Customs and immigration processed at shore plazas with sealed-transit freight lanes.
- O&M reserve of 12–15% of revenue (proposed); Arctic O&M may reach 15–25% (estimate).

## Governance and Advisory Bodies

- US DOT, Russian Ministry of Transport, lenders and research institutions join advisory bodies.


# Review Assumptions
# Domain of the expert reviewer
Mega-Infrastructure Project Management and Geopolitical Risk, with emphasis on Arctic binational mega-projects, public-private partnerships, sanctions-compatible financing, and staged capital deployment under extreme technical and political uncertainty

## Domain-specific considerations

- Sanctions, export controls and third-country financing viability under US-Russia political tension
- Staged gating with paid pause and exit provisions to cap sunk-cost exposure before treaty ratification and licensing are confirmed
- Arctic data collection (ice, seismic, permafrost) as prerequisite for design freeze; observational design trade-offs between schedule and design confidence
- Indigenous consent frameworks spanning two legal regimes (US NEPA/tribal law vs. Russian protections) with binding authority and benefit-sharing
- Binational governance seams at the maritime boundary: liability, closure authority, customs and incident command under unified rulebook
- Supply-chain and fabrication-yard redundancy in a sanctions-constrained environment with long lead times and short Arctic construction seasons

# Issue 1 - Missing Explicit Financing Close Gate and Lender Engagement Timeline

## Problem

Plan proposes third-country investor consortium and sanctions-compatible financing but does not identify lenders, investors or milestones for financing close. Without pre-committed lenders and binding term sheet by Month 9–12 (2027-07-12 to 2027-10-12), financial structure remains speculative and carries binary risk: 6–12 month delay if lenders withdraw, or unfavorable terms (higher cost, stricter covenants) that undermine project economics.

## Recommendation

Launch formal investor engagement by Month 1 (2026-11-12) with 5–10 target lenders (development banks, infrastructure funds, export-credit agencies). Conduct one-on-one meetings (Months 1–3 = 2026-11-12 to 2027-01-12) to assess sanctions policies and Arctic experience. Issue preliminary Information Memorandum (Months 3–4 = 2027-01-12 to 2027-02-12) and host investor roundtable (Months 4–5 = 2027-02-12 to 2027-03-12). Negotiate heads of terms with at least two lead arrangers by Month 9 (2027-07-12) and target financial close by Month 12–15 (2027-10-12 to 2028-01-12). Include lender representatives in Steering Committee from Month 6 (2027-04-12) onwards. Make financing close an explicit gate: if not achieved by Month 18 (2028-04-12), trigger paid pause and exit provisions to preserve capital.

## Sensitivity

Financing delay of 6–12 months (impact Months 12–18 = 2027-10-12 to 2028-04-12) slips construction start and increases pre-construction soft costs by $10–30 million (estimate). If terms are unfavorable, debt service coverage falls 0.2–0.5x below plan, adding $50–200 million to capital need or requiring equity dilution. Baseline: heads of terms by Month 9 (2027-07-12), financial close by Month 12–15 (2027-10-12 to 2028-01-12); variance: delay beyond Month 18 (2028-04-12) triggers exit.

# Issue 2 - Unquantified Cost Estimate and Contractor Risk Premiums in Arctic Logistics Environment

## Problem

Total CAPEX estimated at $80–120 billion USD lacks detailed cost justification by labor category, material unit costs, and Arctic logistics premiums. Contractors bidding Arctic work apply risk premiums of 15–25% (estimate) for ice, seismic, permafrost and geopolitical uncertainty. Plan does not specify which cost elements are contingency versus baseline, leaving unclear how much buffer exists before lender covenant breaches.

## Recommendation

Commission parametric cost model by Month 3 (2027-01-12) from Arctic construction specialists (HDR, Jacobs, Golder, similar), building unit costs from regional labor surveys (target: 30–50% Arctic premium for labor; 50–100% for marine logistics), material indices, and 5–10 comparable Arctic projects. Establish Cost Task Force (Months 3–6 = 2027-01-12 to 2027-04-12) with candidate contractors to validate estimates and resolve outliers. Document assumptions in Cost Basis Document and publish for contractor feedback by Month 6 (2027-04-12). Create separate contingency pool (propose 12–15% of baseline) managed through formal change control. Implement Owner's Cost Engineer starting Month 6 (2027-04-12) to track actual costs monthly against baseline and reforecast quarterly.

## Sensitivity

Cost overruns of 10–30% ($8–36 billion, estimate) are plausible if Arctic logistics, foundation unknowns or contractor premiums exceed baseline. At 20% overrun ($16–24 billion), debt service coverage falls from plan (assumed 1.5–2.0x in conservative case) to 1.0–1.2x, triggering covenant breach. Mitigation: conservative baseline cost, validated parametric model, separate contingency pool and early alarm thresholds (reforecast and reprice if costs exceed plan by 5–10% at Month 12 = 2027-10-12). Baseline: $80–120 billion, 12–15% contingency; variance: +10–30% overrun risk if unit costs or productivity assumptions are wrong.

# Issue 3 - Observational Design Approach Defers Design Freeze to Month 18 (2028-04-12), Compressing Construction Window and Increasing Permafrost/Seismic Risk

## Problem

Observational design approach instruments ice, seismic and permafrost conditions for 12–18 months before freezing design and committing pier foundations. This is prudent given data scarcity but defers design freeze to around Month 18 (2028-04-12) and pushes foundation work to Months 18–30 (2028-04-12 to 2029-04-12) at earliest. If monitoring data are delayed, ambiguous or inconclusive, design decisions are locked in without full confidence, creating high risk of under-design (repairs of $50–200 million, estimate) or over-design (CAPEX inflation of $5–15 billion, estimate). Compressed construction window reduces float for fabrication and installation.

## Recommendation

Launch intensive ice and seismic monitoring starting Month 0 (2026-10-12): drifting buoys, shore-based radar, satellite imagery and pressure plates on pilot pier models (Months 6–12 = 2027-04-12 to 2027-10-12). Parallelize preliminary design (Months 0–6 = 2026-10-12 to 2027-04-12) with monitoring; iteratively refine designs (Months 6–18 = 2027-04-12 to 2028-04-12) as data arrive. Partner with ice-mechanics research institutions to validate load models. Establish design-freeze gate at Month 18 (2028-04-12) explicitly contingent on data adequacy, not calendar: if confidence levels are low, extend monitoring by 3–6 months rather than proceeding with uncertain loads. Reserve 10–15% design flexibility in foundation sizing (proposed) to allow post-monitoring upgrades without major rework. Conduct independent external design review (Months 12–15 = 2027-10-12 to 2028-01-12) to flag unknowns early.

## Sensitivity

If design freeze is delayed beyond Month 18 (2028-04-12) due to inconclusive data, each month slips construction critical path by about 1 month; 3–6 month extension (realistic if spring data collection is poor) delays construction start and end-of-construction by 3–6 months. Alternatively, if design freezes at Month 18 (2028-04-12) on incomplete data and ice loads later exceed design assumptions, pier repairs cost $50–200 million per location and cause 1–3 month closures. If over-design contingency is high (worst-case ice and seismic combined), CAPEX inflates 5–15 billion. Baseline: design freeze Month 18 (2028-04-12) on validated data; variance: delay risk 3–6 months if data are late, or post-construction repair risk $50–200 million if data are sparse.

# Review conclusion

Bering Strait crossing is credible but high-risk binational mega-project. Viability hinges on three critical clusters:

- Political gating (treaty ratification, sanctions licensing) is binary and largely outside project control. Explicit gates with paid pause and exit provisions (Months 6, 12, 18, 24 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12) must cap sunk-cost exposure before committing major capital.
- Financing remains speculative; no lenders yet engaged. Heads of terms must be in hand by Month 9 (2027-07-12) and financial close by Month 12–15 (2027-10-12 to 2028-01-12), or project enters default-risk trajectory.
- Technical unknowns (ice loads, seismic-permafrost interaction) require 12–18 months of observational data before design freeze. If data are late or ambiguous, design decisions are made under uncertainty, creating post-construction liability of $50–200 million per incident.

Cost contingency of 12–15% (proposed) is prudent but unvalidated; detailed parametric cost model from Arctic specialists is essential by Month 3 (2027-01-12). Staged rail-and-utility tunnel approach (vs. full hybrid) preserves optionality and full crossing's end-state while limiting upfront capital exposure. Indigenous consent authority and binational governance clarity are non-negotiable for permitting and operations; underestimating creates injunction and litigation risk of 3–18 months and $5–20 million.

## Recommendations

- Launch financing investor engagement by Month 1 (2026-11-12).
- Commission detailed parametric cost model by Month 3 (2027-01-12).
- Make financing close (heads of terms by Month 9 = 2027-07-12, close by Month 12–15 = 2027-10-12 to 2028-01-12) an explicit, non-negotiable gate.
- Establish design-freeze gate at Month 18 (2028-04-12) explicitly contingent on data adequacy, with paid pause and exit if not met.
- Finalize Indigenous consent agreements and Beringia Council by Month 12 (2027-10-12) as a permitting prerequisite.

Treat 2041 date as a target for Phase 1 only; Phase 2 (suspension spans and road) extends beyond 2041.