Persuasive elevator pitch.

# Bridge Two Continents, Unlock the Arctic

## Project Overview

The Alaska-Russia Bering Strait link is an **infrastructure moonshot** of the 21st century: an 85 km crossing combining an immersed rail-and-utility tunnel (Phase 1) on foundations engineered for future suspension spans, and suspension bridge elements plus road lanes (Phase 2) to complete permanent trade, energy and research connectivity between North America and Asia.

Phase 1 targets 20–36 km of operational rail, fiber and power infrastructure across **segregated galleries**, with commissioning targeted at Month 180 (2041-10-12) but not achievable at a single spread, anchoring a staged, gated program that preserves ambition while absorbing geopolitical and technical risk. No crossing of comparable scale, in drifting ice and seismic terrain, exists anywhere.

A **third-country financing consortium** (infrastructure funds, development banks, export-credit agencies), neutral ownership structure and explicit decision gates at Months 6, 12, 18 and 24 (2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12) keep capital commitment proportional to validated conditions. This is not a bet on optimistic assumptions—it is a **disciplined path** to binational infrastructure that transforms Arctic connectivity, Arctic science, and the global supply chain.

## Target Audience

**Primary audiences:**

- Third-country infrastructure investors (sovereign funds, pension funds, development banks, export-credit agencies)
- Multilateral lenders (World Bank, AIIB, EBRD)
- Large-cap engineering consortia seeking flagship Arctic and geopolitical diversification opportunities

**Secondary audiences:**

- US and Russian government officials (transport, energy, defense, security)
- Indigenous communities whose consent and participation are **gatekeeping** conditions

**Tertiary audiences:**

- Global freight forwarders, telecom and energy operators seeking trans-Arctic capacity and long-term contractual revenue

All audiences require clarity on **sanctions compliance**, geopolitical risk mitigation and realistic timelines.

## Risks and Mitigation Strategies

**Treaty ratification and sanctions licensing**

- Risk: 12–36 month slip is plausible.
- Mitigation: Explicit decision gates with paid pause and exit provisions cap sunk cost at USD 150 million (proposed threshold); neutral SPV remains licensable even if one government's political posture shifts.

**Financing gap**

- Risk: USD 8.9 billion/yr (estimate) required revenue is not yet evidenced.
- Mitigation: Independent traffic study and 30–50% take-or-pay pre-sales (fiber, power, rail) anchor debt before construction.

**Installation-rate shortfall**

- Risk: Single-spread model (3–8 elements/season vs 9 needed) makes Month 180 (2041-10-12) target unachievable.
- Mitigation: Pilot-element trial (Months 9–12 = 2027-07-12 to 2027-10-12) validates productivity; Phase 1 scope or second-spread commitment required by Month 12 (2027-10-12).

**Ice and seismic unknowns**

- Risk: Design assumptions may not hold under observed conditions.
- Mitigation: Observational design with 12–18 months of monitoring and 10–20% foundation reserve (estimate) preserve design flexibility; design freeze gates on data adequacy.

**Arctic cost premiums**

- Risk: Labor +30–50%, logistics +50–100% (estimate) exceed baseline assumptions.
- Mitigation: Parametric baseline and contingency budgeting absorb typical variance; bids exceeding baseline by >5% trigger re-evaluation.

## Metrics for Success

**Gate passage:**

- Gate 1 (Month 6 = 2027-04-12): Financing roadmap endorsed by ≥2 lead lenders; written OFAC/export-control pathways; treaty/framework negotiation complete.
- Gate 2 (Month 12 = 2027-10-12): Indigenous consent agreements signed; pilot element trial completed.
- Gate 3 (Month 18 = 2028-04-12): Design frozen within ±15% confidence on ice and seismic loads.
- Gate 4 (Month 24 = 2028-10-12): Framework agreement/concessions executed; financial close achieved.

**Financial metrics:**

- Pre-gate spend below USD 150 million.
- Debt sourced at target cost (5.5% placeholder, +100–200 bps sensitivity band for sanctions).
- DSCR ≥1.5x in conservative case.

**Delivery metrics:**

- Pilot element successfully immersed (Months 9–12 = 2027-07-12 to 2027-10-12).
- Bids within 5% of USD 100 billion baseline.
- Tunnel elements procured and installed on schedule, with about 9 per season needed as the Month-180 (2041-10-12) test; 6–8 per season only supports a later date or a 60–70 element rescope.

**Stakeholder metrics:**

- Indigenous workforce ≥20% (proposed).
- Community benefit fund operational.
- Zero regulator stop orders due to licensing gaps.
- Both governments' concessions executed.

## Stakeholder Benefits

**Investors and lenders:**

- 30-year revenue stream from tolls, fiber leases, power access fees and rail capacity.
- Contracted (take-or-pay) and availability-backed revenue reduce demand risk.
- Flagship Arctic and geopolitical **diversification** in a market with no precedent (first-mover premium).

**US government:**

- Permanent trade and energy corridor to Arctic Asia.
- Strategic connectivity and Arctic presence.
- Indigenous benefit and research **collaboration**.

**Russian government:**

- Energy export corridor.
- Arctic research partnership.
- Domestic connectivity to Far East.
- Indigenous benefit.

**Indigenous communities:**

- 1–2% of revenue (USD 10–30 million/yr, estimate) in benefit fund.
- 20–30% workforce participation (proposed).
- Binding advisory authority via Beringia Council until counsel opinions (Month 3 = 2027-01-12) establish the legal standing and scope of consent.
- Co-management of marine mammal monitoring.

**Freight forwarders, energy and telecom operators:**

- Pre-sell 30–50% of expected capacity (proposed threshold) to anchor debt.
- Secure long-term contractual access at predictable tariffs.
- Diversify trans-Arctic routing.

**Arctic region:**

- Permanent research platform.
- Ice-monitoring and seismic data shared globally.
- Rail access to Russia's Arctic ports.
- Fiber backbone for remote communities.

## Ethical Considerations

**Indigenous rights and benefit:**

- Free, prior and informed **consent** is a gate (Month 12, 2027-10-12).
- Beringia Indigenous Council holds binding advisory authority over seasonal work windows and alignment changes.
- Benefit fund (1–2% revenue, USD 10–30 million/yr, estimate) and 20–30% workforce participation (proposed) are contractual commitments, not discretionary.

**Environmental stewardship:**

- No impact piling; vibratory/drilled foundations only.
- Acoustic shutdown if marine mammals within 10 km.
- Seasonal exclusion zones 15–20 km.
- Indigenous-led monitoring.
- Independent environmental impact statement and baseline surveys from project start.

**Sanctions and supply-chain integrity:**

- Neutral SPV and third-country consortium prevent concentration of sanctions exposure in one jurisdiction.
- Pre-approved supplier list and export-control counsel ensure procurement **compliance**.
- Transparency reporting on supply chains.

**Equitable governance:**

- Single binational safety code and neutral arbiter for operational deadlocks prevent unilateral closures.
- Shared liability and incident command protocols.
- Shore-based customs/immigration avoid sovereign control of the structure itself.

**Transparency:**

- Public disclosure of cost, schedule and risk milestones at each gate.
- Independent engineer oversight.
- Lender due diligence and covenant monitoring.
- Annual stakeholder reporting on Indigenous benefit, environmental performance and safety.

## Collaboration Opportunities

**Engineering consortia:**

- Lead-design partnerships with Fehmarnbelt Fixed Link and Øresund Link operators for immersed-tunnel factory and element-immersion lessons.
- Technology licenses from HZMB (Hong Kong-Zhuhai-Macao Bridge) on artificial-island seabed prep and last-joint installation.

**Research institutions:**

- Joint ice-dynamics, seismic hazard and permafrost-monitoring programmes with US Geological Survey, National Center for Atmospheric Research, Russian Academy of Sciences and SINTEF Ocean.
- Indigenous knowledge **co-production** with Beringia communities.

**Supply chains:**

- Yard partnerships with Pacific Rim shipbuilders (South Korea, Singapore, Japan) for element fabrication.
- Vessel chartering via established Arctic operators (Healy, Polar Star class).
- Procurement consortia for Arctic-grade materials and sanctions-compliant sourcing.

**Tenants and users:**

- Fiber-optic carriers (Telesat, Intelsat, Russian telecom operators).
- Hydropower interconnection operators (BC Hydro, Russian energy).
- Freight forwarders (Maersk, MSC, Russian lines) for take-or-pay pre-sales anchoring debt.

**Governments and regulators:**

- Bilateral working groups on customs, incident command, environmental permitting and Indigenous benefit.
- Technology-transfer agreements with existing Arctic operators (Norway, Finland, Canada).
- Joint Arctic research memoranda.

## Long-term Vision

**The 85 km end state:**
Phase 1 rail-and-utility tunnel (2026–2041) is the anchor; Phase 2 suspension spans (2–3 km each) and road lanes (post-2041) complete the hybrid, enabling full bi-directional heavy-goods and passenger traffic, energy and data transport at scale. Cumulative impact: 200+ million tonnes/yr freight capacity, 5–10 GW energy transfer, petabits/yr fiber capacity, and year-round binational connectivity.

**Arctic transformation:**
The crossing becomes the pivot for trans-Arctic supply chains, Arctic energy development (hydrogen, wind, hydropower export), Arctic research infrastructure (shared ice-monitoring, seismic networks, subsea observatories), and Indigenous economic development across the Bering Strait region.

**Geopolitical:**
Permanent demonstration of binational **cooperation** under adversity; template for future Arctic infrastructure (Baffin Strait, Fram Strait concepts); Arctic Council legitimacy through Native co-governance and benefit-sharing.

**Climate resilience:**
Observational design and adaptive management embed climate-driven ice and permafrost shifts into operations; data shared globally, improving Arctic system science.

**100-year horizon:**
The crossing operates across multiple climate regimes and political cycles; its legal structure (neutral SPV, treaty framework, Indigenous authority) survives individual government transitions. Revenue surplus funds Arctic research endowments, Indigenous trust funds and climate adaptation in the region.

## Call to Action

**Investors and lenders:**

- Engage with the project team for an information memorandum and roundtable (Months 4–5, 2027-02-12 to 2027-03-12) to evaluate the financing roadmap and take-or-pay pre-sales opportunity.
- Submit non-binding interest for heads-of-terms negotiations (target Month 9, 2027-07-12).

**Governments:**

- Complete framework negotiation and provide a written OFAC/sanctions licensing pathway by Month 6 (2027-04-12); execute the framework agreement and issue sanctions licences by Month 24 (2028-10-12).

**Indigenous communities and operators:**

- Register with the Beringia Indigenous Council (forming Months 3–6 = 2027-01-12 to 2027-04-12).
- Join the community benefit fund and consent process by Month 12 (2027-10-12).

**All participants:**

- Monitor Gate milestones at Months 6, 12, 18, 24 (2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12); each gate decision window opens participation and marks de-risking steps.
