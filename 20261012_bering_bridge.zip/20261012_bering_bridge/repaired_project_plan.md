**Goal Statement:** Deliver Phase 1 of the Alaska-Russia Bering Strait link: a rail-and-utility immersed tunnel (rail, fiber, power) on island foundations sized for later suspension spans and road lanes, commissioned by Month 180 (2041-10-12) as a target, within a staged gated program toward the 85 km hybrid end state (user constraint).

## SMART Criteria

- **Specific:** Design, finance, build and operate a Phase 1 rail-and-utility immersed tunnel across the shallow central Bering Strait section, with foundations sized for later 2-3 km suspension spans and road lanes. The remaining alignment method is undecided (estimate).
- **Measurable:** Success is tracked by passage of Gates 1-4 (Months 6, 12, 18, 24 = 2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12), financial close of about USD 115 billion funding (estimate), and commissioning of 80-120 tunnel elements (about 20-36 km, estimate) carrying rail, fiber and power.
- **Achievable:** Staging caps pre-gate spend at USD 150 million (proposed threshold). A neutral SPV and third-country consortium reduce sanctions exposure. Achievability is conditional: installation rates and ratification slip of 12-36 months (estimate) make Month 180 (2041-10-12) unlikely at a single spread.
- **Relevant:** The link supports a binational trade corridor, energy and telecom transport, Arctic research and strategic connectivity, while preserving the full hybrid crossing as the end state.
- **Time-bound:** Program horizon is Months 0-180 (2026-2041). Gates fall at Months 6, 12, 18 and 24 (2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12); construction starts no earlier than Months 24-30 (2028-10-12 to 2029-04-12); Phase 1 commissioning is targeted at Month 180 (2041-10-12), a target not a commitment. Project start ASAP.

## Dependencies

- Neutral SPV chartered (Month 3 = 2027-01-12 target) and treaty/framework negotiation complete (Month 6 = 2027-04-12); framework agreement executed by both governments (Month 24 = 2028-10-12)
- Written OFAC licensing pathway and pre-approved supplier list (Month 6 = 2027-04-12); sanctions and export-control licences obtained in writing (Month 24 = 2028-10-12)
- Financing: lender engagement, heads of terms (Month 9 = 2027-07-12) and financial close (Month 24 = 2028-10-12 target)
- Baseline ice, seismic, permafrost and marine mammal surveys supporting design freeze (Month 18 = 2028-04-12) and permits
- Indigenous consent agreements and Beringia Indigenous Council established (Month 12 = 2027-10-12)

## Resources Required

- Third-country consortium financing: USD 69 billion debt and USD 46 billion equity (estimate)
- Core team of 100-150 specialists and owner's engineer integrator (proposed)
- 2+ fabrication yards and 4-6 ice-class tow vessels (proposed)
- Ice, seismic and permafrost monitoring instrumentation and geotechnical drilling
- Shore yards, ports, camps and logistics hubs at Nome and Provideniya areas

## Related Goals

- Phase 2 suspension spans and road lanes beyond Month 180 (2041-10-12) (not costed)
- Decide crossing method for the remaining 49-65 km of alignment (estimate)
- Trans-strait fiber and power interconnection
- Joint Arctic research and monitoring collaboration
- Binational trade and energy corridor development

## Tags

- Bering Strait
- Immersed tunnel
- Arctic megaproject
- Binational infrastructure
- Sanctions-compatible financing

## Risk Assessment and Mitigation Strategies


### Key Risks

- Treaty ratification and sanctions licensing delays of 12-36 months (estimate) or one-government withdrawal
- Cost overrun of USD 10-30 billion (estimate) exceeding the USD 15 billion contingency by up to USD 15 billion
- Financing not secured: no lenders engaged, no traffic forecast or tariff, USD 8.9 billion/yr conservative revenue need unevidenced (estimate)
- Ice, seismic and permafrost loads exceeding design assumptions or data arriving late
- Tunnel element installation rate (3-8 per season vs about 9 needed) making Month 180 (2041-10-12) unachievable at one spread (estimate)

### Diverse Risks

- Indigenous consent disputes causing injunctions of 6-18 months (estimate)
- Marine mammal stop-work orders of 3-6 months and lost open-water seasons (about 12 months each, estimate)
- Arctic labor turnover of 30-50% and visa bottlenecks (estimate)
- Governance deadlock at the maritime boundary over closure, tolls and incident command
- Arctic O&M costs of 15-25% of revenue and tunnel fire with delayed rescue (estimate)

### Mitigation Plans

- Gates at Months 6, 12, 18, 24 (2027-04-12, 2027-10-12, 2028-04-12, 2028-10-12) with 3-6 month paid pause and exit; pre-gate spend capped at USD 150 million (proposed threshold); neutral SPV and framework agreement first
- Parametric cost model by Month 3 (2027-01-12); 15% contingency outside baseline; RUB buffer of 8-12% inside baseline; reprice if bids exceed baseline by more than 5%
- Lender engagement from Month 1 (2026-11-12), heads of terms by Month 9 (2027-07-12), independent traffic study, 30-50% take-or-pay pre-sales, debt sized to DSCR of 1.5x or more with default trigger below 1.2x (proposed thresholds)
- Observational design with 12-18 months of monitoring, 10-20% foundation reserve, sacrificial ice deflectors, design freeze gated on data adequacy within +/-15%
- Dual-source yards, pilot element trial Months 9-12 (2027-07-12 to 2027-10-12), multiyear vessel charters, Indigenous-led monitoring, binational work-permit protocol, rescue stations and cross-passages every 500-1000 m (proposed)

## Stakeholder Analysis


### Primary Stakeholders

- Neutral SPV owner and sponsor board
- Owner's engineer / integrator and core engineering team
- Third-country lender and investor consortium
- US and Russian governments (contractual rights holders)
- Beringia Indigenous Council and Indigenous communities

### Secondary Stakeholders

- US Department of Transportation and Russian Ministry of Transport
- OFAC, export-control and environmental regulators (NOAA, USFWS, Russian agencies)
- Fabrication yards, tow vessel and material suppliers
- Scientific and ice-mechanics research institutions
- Freight forwarders, fiber and power tenants

### Engagement Strategies

- Steering committee with monthly reporting and gate reviews; lenders and governments join advisory bodies from Month 6 (2027-04-12)
- Funded community advisors, Indigenous observers on marine works, benefit fund of 1-2% of revenue or USD 10-30 million/yr (proposed)
- Early regulator engagement as design partners with iterative feedback and written licensing guidance
- Supplier pre-qualification with force-majeure and substitution clauses; milestone updates
- Investor roundtable Months 4-5 (2027-02-12 to 2027-03-12) and take-or-pay marketing to prospective tenants

## Regulatory and Compliance Requirements


### Permits and Licenses

- US NEPA environmental impact statement and Russian EIA approvals
- Marine Mammal Protection Act authorizations (incidental take) and Russian equivalents
- OFAC licences and US/Russian export-control authorizations
- Marine construction, dredging and coastal permits in both jurisdictions
- Binational framework agreement/concessions and work-permit and visa protocol

### Compliance Standards

- Sanctions and export-control regimes (OFAC, EAR/ITAR, Russian controls)
- Tunnel fire and life-safety codes under a single binational safety code
- Marine mammal noise thresholds and exclusion zones
- Indigenous consultation and FPIC-aligned agreements in both legal regimes
- Arctic seismic and permafrost design standards with 100-year design life

### Regulatory Bodies

- US Treasury OFAC and Department of Commerce BIS
- NOAA and US Fish and Wildlife Service
- US Department of Transportation
- Russian Ministry of Transport and environmental authorities
- Neutral third-country jurisdiction regulator for the SPV

### Compliance Actions

- Retain export-control counsel Month 0 (2026-10-12); written OFAC guidance Months 3-6 (2027-01-12 to 2027-04-12)
- Apply for framework permits Months 6-9 (2027-04-12 to 2027-07-12) and detailed marine permits Months 12-18 (2027-10-12 to 2028-04-12)
- Charter neutral SPV by Month 3 (2027-01-12) and execute framework agreement by Month 24 (2028-10-12)
- Run baseline surveys from Month 0 (2026-10-12) to support EIS/EIA
- Hold quarterly compliance reviews and joint emergency drills from Month 24 (2028-10-12)