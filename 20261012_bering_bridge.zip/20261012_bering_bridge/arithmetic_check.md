31 explicit calculations found in the documents re-computed without an LLM; 1 does not match its stated result.

| Section | Statement | Stated | Computed |
|---|---|---|---|
| Canonical Facts | revenue x (1 - 20% opex) = 7.12 gives USD 8.9B | 7.12 | 0.8 |
