### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] A fixed 85 km bridge-and-tunnel link that needs joint US-Russian ownership, tolling and a funded 15-year build is a plan for a political relationship that does not exist, across a strait with no road or rail network on either side to feed it.**

**Bottom Line:** REJECT: The premise requires cooperation, capital and cargo that do not exist, so there is no project to plan.


#### Reasons for Rejection

- The plan assumes a binational steering committee, joint ownership, a US Department of Transportation counterpart and a Russian Ministry of Transport counterpart, but US-Russia relations are shaped by Ukraine-related sanctions and export controls that bar the very financing, procurement and contracting the plan relies on.
- The financing model (public-private partnership, sovereign funds, multilateral banks) has no lender that can lawfully or reputationally sit beside a Russian state counterparty, so the capital stack has no willing participants.
- A 2026-2041 schedule for an 85 km hybrid suspension-bridge and immersed-tube system through pack ice, seismic faults and permafrost ignores that the 18 km Fehmarnbelt tunnel, in far milder conditions, has already slipped its schedule and cost.
- Revenue from tolling, freight and telecom fiber depends on cargo that has no origin or destination: Chukotka and western Alaska have no connected highway or rail network, and the Bering Strait carries negligible freight because both sides are thinly populated.
- Designating a Russia-Alaska link as a 'geopolitical priority' and a 'national security' asset in the same document contradicts itself, because each government would treat a fixed physical connection to the other as a military vulnerability and not as a benefit.

#### Second-Order Effects

- 0–6 months: Announcing a US-Russia joint infrastructure project 'ASAP' draws sanctions-compliance reviews, congressional objections and allied alarm, and consumes diplomatic bandwidth without producing a single legal counterparty or financed contract.
- 1–3 years: Geotechnical and environmental studies are paid for with money no bank will commit against, Alaska Native and Chukotkan communities are consulted for a project with no funding, and the study results become trophies in unrelated Ukraine-era negotiations.
- 5–10 years: A stalled or half-built binational structure leaves stranded sunk costs, a standing claim on Arctic infrastructure by two adversarial states, and a precedent that peace talks can be bought with pledged megaprojects.

#### Evidence

- Case/Incident — Kremlin envoy Kirill Dmitriev's 'Putin-Trump tunnel' proposal (2025): a Bering Strait rail and cargo link priced at about $8 billion was floated in the context of Ukraine war diplomacy, which shows how closely the idea is tied to political signalling and not to any bankable demand.
- Case/Incident — Fehmarnbelt fixed link, Denmark-Germany (construction ongoing): an 18 km immersed tunnel costing roughly €7.5 billion has faced reported delays to its planned 2029 opening despite benign conditions and two cooperative, EU-aligned states.
- Law/Standard — US Executive Order 14024 (2021): the sanctions framework against Russia's economy blocks dealings with Russian state entities, which makes joint ownership and a Russian counterparty legally toxic for US participants.



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[STRATEGIC] — Concrete Handshake: The plan turns a Kremlin envoy's diplomatic gesture, floated while the Ukraine war continues, into an 85 km bridge-and-tunnel structure on an ice-scoured, seismic seabed that will outlive the political mood that produced it.**

**Bottom Line:** REJECT: A Concrete Handshake is a gesture dressed as infrastructure, and no 85 km structure across a seismic, ice-choked strait should be built to give two governments a photograph. The premise fails before a single pile is driven.


#### Reasons for Rejection

- The Iñupiat, Yupik and Chukchi communities whose hunting depends on the strait's ice and animal migration lanes would have an industrial corridor imposed by two capitals, and meaningful consent cannot be obtained on a coast that Russia treats as a restricted border zone.
- A single structure crossing the maritime boundary would answer to two legal systems, two environmental regimes and a binational committee that no voter on either side elected, while the Russian sponsor is a sovereign fund tied to US sanctions (current status not verified).
- A fixed structure in 30–50 m of water cannot be withdrawn if relations collapse, would become a militarized chokepoint and prime target, and would teach other governments that a summit-season prestige megaproject can be conjured on demand.
- The traffic case is hollow: neither the Seward Peninsula nor Chukotka is connected to its national rail network (not verified), the reported $8 billion tunnel claim sits against a reported $65 billion conventional estimate, and an eightfold gap is salesmanship rather than economics.

#### Second-Order Effects

- **Month 0–12 (2026-10-12 to 2027-10-12) — The Cracks Appear:** Sanctions counsel, Indigenous councils and defense planners on both sides discover the project cannot proceed without political concessions unrelated to transport, and the plan becomes a bargaining chip rather than a build program.
- **Months 12–48 (2027-10-12 to 2030-10-12) — Copycats Arrive:** Other leaders pitch their own symbolic mega-links across contested straits and borders, each priced by optimism and financed by promised partners who never appear.
- **Months 60–96 (2031-10-12 to 2034-10-12) — Norms Degrade:** Study contracts and design retainers become a permanent rent stream for consultants and state-linked funds, while sanctions discipline and Indigenous consultation standards are treated as obstacles to be waived for a good photograph.
- **Months 120+ — The Reckoning:** Unfinished or underused structures sit across a warming, shifting strait as a stranded liability that neither government can write off without admitting the premise was a stunt.

#### Evidence

- Case/Report — The 'Putin-Trump tunnel' was floated by Kremlin investment envoy Kirill Dmitriev (head of the RDIF sovereign fund) soon after a Putin-Trump phone call, with a claimed $8 billion cost and a proposal to use The Boring Company; reported conventional cost was about $65 billion, and Zelenskyy said he was 'not happy with this idea' (reported by RCI/Eye on the Arctic and bne IntelliNews).
- Case/Report — The Bering Strait is at minimum about 82 km wide with average depth of 30–50 m and a maximum of about 90 m; the Diomede Islands, only about 3.9 km apart, also sit on both the US-Russia maritime border and the International Date Line, which makes them a border-security flashpoint rather than a neutral stepping stone.
- Law/Standard — UN Declaration on the Rights of Indigenous Peoples, Arts. 19 and 32 (free, prior and informed consent before projects affecting Indigenous lands and resources are approved).
- Law/Standard — US Executive Order 14024 (2021, Russia-related sanctions authority); applicability to RDIF and to any joint financing vehicle is Unknown — default: caution.



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] An 85 km fixed link jointly owned with a state under layered U.S. sanctions assumes political trust, capital, and legal access that do not exist.**

**Bottom Line:** REJECT: A jointly owned 85 km bridge-tunnel between two adversarial states, resting on financing, legal access and trust that sanctions and geopolitics deny, is a political fantasy that fails at its premise.


#### Reasons for Rejection

- Joint ownership under a binational steering committee asks Washington and Moscow to co-govern a border chokepoint, while the plan also lists 'national security' as an objective, so the asset's stated purpose and its ownership model contradict each other.
- The financing model of sovereign funds, multilateral banks and a public-private partnership presumes lenders willing to deal with sanctioned Russian counterparties, and the tolling and freight revenue has no base because neither Chukotka nor western Alaska has a connected road or rail network to feed an 85 km crossing.
- The 85 km hybrid of suspension spans and immersed tubes must survive moving pack ice, seismicity and permafrost in a strait only 30–50 m deep, at a scale far beyond the roughly 18 km Fehmarnbelt tunnel, the longest immersed-tube tunnel yet built or under construction.
- A 15-year schedule of 2026–2041 with 'project start ASAP' commits to island construction and span erection before any treaty, border-control regime, or US and Russian environmental permitting pathway exists, so the timeline starts from a legal vacuum.
- Indigenous communities, including the Iñupiat of Little Diomede and the peoples of Chukotka, appear as one line in a stakeholder list beside 'international investors', although the strait is their hunting ground and the migration route of whales, walrus and seals that artificial islands and a decade of construction would permanently disrupt.

#### Second-Order Effects

- 0–6 months: Any formal US step toward joint ownership with Russia triggers congressional and allied backlash and sanctions-compliance freezes, so design and survey contracts stall with no lawful counterparty to sign them.
- 1–3 years: Geotechnical and ice studies consume money with no construction permit in sight, and the only willing financiers are Russian state-linked funds, which turns the 'partnership' into a one-sided dependency and a bargaining chip in unrelated negotiations.
- 5–10 years: If physical works have begun, half-built approaches and artificial islands sit stranded in an ice-scoured strait, damaging seabed habitat and mammal migration routes with no legally responsible owner to remove them.

#### Evidence

- Case/Incident — Kremlin envoy Kirill Dmitriev's Bering Strait 'Putin–Trump tunnel' proposal (2025): claimed roughly $8bn for a 100 km link against earlier estimates above $65bn, showing the project is driven by political signalling rather than engineered budgets.
- Case/Incident — Kerch Strait (Crimean) Bridge attacks (2022, 2023): the bridge was damaged by a truck bomb in October 2022 and by naval drone strikes in July 2023, showing a strategic fixed link between rival states becomes a military target.
- Law/Standard — U.S. Executive Order 14024 (2021): created the sanctions authority used to block property and transactions of Russian government-linked entities, directly constraining the financing and joint-ownership structure the plan assumes.



### Premise Attack 4 — Cascade
_Tracks second/third-order effects and copycat propagation._

**The plan treats an 85 km, two-nation Arctic megaproject as an engineering problem when the binding constraints are that no cargo exists to fill it, no road or rail reaches either shore, and its only possible co-owner is a sanctioned state with which the US cannot legally contract. A 15-year schedule starting "ASAP" in a war-sanctions regime is fantasy; the bridge has no customer, no financier, no legal counterparty, and no approach infrastructure.**

**Bottom Line:** Abandon the premise: the crossing is a symbol in search of a market, a financier and a lawful partner, and no schedule, tunnel design, or governance chart can create those. The flaw lies in the goal itself, not the engineering: a 15-year, sanctions-blind, freight-less mega-link between two adversarial states cannot be financed or governed.


#### Reasons for Rejection

- The Bridge-to-Nowhere Paradox: both landings are roadless and railless. Alaska's Seward Peninsula is not connected by road to the Alaska highway system, and Chukotka is not connected to Russia's rail network (widely reported, not verified in this search). The span is the cheapest 85 km of a multi-thousand-km chain that would also need new rail/road, ports and power on both sides, none of it in the plan's cost table.
- The Sanctions Wall Fallacy: the plan assumes a 'binational steering committee' and 'joint ownership' with the Russian Ministry of Transport, sovereign funds and multilateral banks. US and allied sanctions on Russian state entities, banks and sovereign funds make the counterparty legally untouchable for US DOT, the World Bank, EBRD and Western insurers. The sole recent revival, the Dmitriev 'Putin-Trump tunnel' trial balloon of October 2025, was floated as a diplomatic gesture, was met with a public rebuke from Ukraine's president, and produced no financing instrument.
- The Phantom Freight Illusion: the revenue model (tolls, freight, telecom fiber) rests on traffic that does not exist. Russia and the US trade little by land, rail gauges differ (1520 mm vs 1435 mm standard), and Arctic sea routes, subsea cable and air freight already serve the same flows. With ~3-4 million people across both Far-East regions, volume cannot service tens of billions in debt.
- The Cost-Estimate Mirage: an 85 km hybrid suspension-plus-immersed-tube system in sea ice, a seismic zone and permafrost has no built precedent. The recent benchmark, Denmark-Germany's 18 km Fehmarnbelt immersed tunnel in temperate water, has slipped its original 2029 opening and absorbed repeated cost increases of roughly €1.2 bn in total (per press reports). Extrapolating to an Arctic strait with a 4-5 month ice season and a roughly 6-month working window turns any quoted CAPEX into a lower bound.
- The Ice-Season Logistics Trap: no heavy-lift port, cement plant, aggregate quarry, or workforce camp exists within thousands of km of either shore, and the strait is navigable only part of the year. Every tonne of steel, concrete and diesel must be barged in during a short window, so a single slipped season delays the entire critical path by a year, and 15 years of schedule contains only a handful of real working summers.

#### Second-Order Effects

- Months 0-12 (2026-10-12 to 2027-10-12): the 'design and permitting' phase stalls at the first gate; OFAC/BIS licensing, NEPA scoping and Russian state approval cannot proceed in parallel. Consultants and feasibility studies absorb tens of millions (estimate) while producing no binding commitments from any lender.
- Months 12-36: early works (staging islands, camp, port) are the only fundable pieces and are built on the Alaska side alone, creating a stranded asset that serves no function without the Russian half. Alaska Native corporations and Diomede and Chukotka communities are asked to consent to a project whose benefits are theoretical, eroding trust and triggering litigation.
- Months 36-72 (2029-10-12 to 2032-10-12): cost escalation and ice-season slippage force repeated re-baselining, mirroring Fehmarnbelt's pattern at higher scale. Political cycles in Washington and Moscow reverse each other's positions; the project becomes a bargaining chip in sanctions or security negotiations and is cancelled or frozen as a concession.
- Months 72-120 (2032-10-12 to 2036-10-12): a half-built crossing becomes a security liability, since a fixed US-Russia link is a military and smuggling vector that Pentagon and Russian General Staff planners would insist on gating, destroying the 'open trade corridor' economics. Sunk capital is written off, and the Arctic's real needs (ports, energy, communications) are starved of the capital that was diverted.

#### Evidence

- Dmitriev's October 2025 'Putin-Trump tunnel' proposal: the head of Russia's RDIF floated an ~US$8 bn, sub-8-year, Boring Company-built link versus conventional estimates above US$65 bn; it drew a skeptical response, no financing, no treaty, and public opposition from Ukraine's president (rcinet.ca, Kyiv Post, Fox News reports).
- Fehmarnbelt Fixed Link (Denmark-Germany): an 18 km immersed tunnel in temperate waters, with first immersion slipping to 2026 and cost overruns reported near €1.2 bn; its 2029 opening is acknowledged as unrealistic (Femern A/S / Sund & Bælt statements; boote-magazin, tunnelsandtunnelling reports). Even the best-funded, legally unified, user-financed project did not hold schedule.
- Historical Bering Strait schemes: the 1890s-1900s Tsarist-era rail-tunnel proposal (Loicq de Lobel; reportedly approved by Nicholas II in 1905, not verified here) and the Cold War 'Kennedy-Khrushchev World Peace Bridge' concept cited by Dmitriev all died before construction, because the underlying freight and political preconditions never existed.
- Big Diomede and Little Diomede lie roughly 3.8 km apart on either side of the International Date Line and the US-Russia maritime boundary; Little Diomede's community of about 80-100 residents (estimate, not verified) is the closest US population to the crossing and has no road or deep-water port, illustrating how thin the human base is.



### Premise Attack 5 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[STRATEGIC] — The Concrete Détente Fallacy: the plan tries to buy political reconciliation with an 85 km, irreversible, multi-decade structure, chaining a permanent physical asset to the most volatile bilateral relationship on earth and treating a sanctioned counterparty as a stable co-owner.**

**Bottom Line:** REJECT: A permanent 85 km structure whose legitimacy depends on a sanctioned, adversarial co-owner and on a trade corridor that does not exist is a monument to wishful diplomacy, not infrastructure. The gate is closed.


#### Reasons for Rejection

- Rights and dignity: the Yupik, Iñupiat and Chukchi peoples of the strait depend on sea ice, walrus, seal and whale migrations, and a permanent, state-to-state megaproject designed around a diplomatic deal reduces their consent to a stakeholder-engagement line item, with no free and open voice on the Russian side.
- Accountability and oversight: a binational steering committee with no shared court, no common regulator and no enforceable liability regime between two governments under active sanctions leaves nobody answerable when the budget, the schedule or the structure fails.
- Systemic risk and scale: an 85 km hybrid suspension-and-immersed-tube crossing through drifting ice, seismic zones and permafrost has no precedent anywhere, and its landward ends (sparse roads and rail in Chukotka and western Alaska) do not exist, so the link would be a single point of failure for an entire corridor that has not been built.
- Value-proposition rot: the trade, energy and 'scientific collaboration' benefits assume open commerce between the US and Russia that current law forbids, and the claimed cost and speed advantages are political theater; the cited public range runs from roughly $8 billion to $65 billion for the same crossing, a gap that shows nobody actually knows the number.

#### Second-Order Effects

- T+0–6 months — The Cracks Appear: counterparties, banks and contractors are screened against US sanctions, so no multilateral lender or listed contractor will touch the financing, and the 'public-private' structure collapses into a state-sponsor-and-shell-company arrangement.
- T+1–3 years — Copycats Arrive: rival states announce prestige crossings (Arctic corridors, strait tunnels) on the same template of leader-branded diplomacy, and feasibility studies are commissioned to justify a decision already made.
- T+5–10 years — Norms Degrade: Indigenous consultation and environmental review become ceremonial for 'strategic' Arctic infrastructure, and sanctions and export-control regimes are quietly bent to protect sunk costs.
- T+10+ years — The Reckoning: a half-built or politically severed structure sits in the world's most remote seabed, too expensive to finish and too costly to remove, a stranded asset and a standing hostage to every future crisis between Washington and Moscow.

#### Evidence

- Case/Report — Kirill Dmitriev's October 2025 'Putin-Trump tunnel' proposal: the head of Russia's sovereign wealth fund floated a roughly 70-mile Russia–Alaska link at about $65 billion by conventional methods versus a claimed $8 billion using Boring Company technology; Ukrainian President Zelenskiy said he was not happy with it, and reporting noted Chukotka's sparse road and rail network.
- Law/Standard — US Executive Order 14024 (April 2021) and the OFAC Russia sanctions program: blocking authorities over designated Russian entities and sectors make joint ownership, tolling revenue and shared financing with Russian state entities legally toxic for US persons.
- Principle/Analogue — Megaproject management (Bent Flyvbjerg's 'iron law of megaprojects'): megaprojects are routinely over budget, over time and under benefits 'over and over', and the first-of-a-kind, extreme-environment ones fail the worst.
- Case/Report — Physical reality of the strait: minimum width about 82 km, depth 30–50 m, winter ice fields averaging four to five feet with drift ice persisting in midsummer, and the US–Russia border and International Date Line running between the Diomede Islands.