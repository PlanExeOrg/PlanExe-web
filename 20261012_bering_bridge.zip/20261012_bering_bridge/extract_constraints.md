## Positive Constraints

- Draft a comprehensive strategic plan for designing, financing, constructing, and operating a permanent Alaska-Russia bridge across the Bering Strait
- Technical concept: hybrid 85 km suspension-bridge + immersed-tube tunnel system
- Engineer the system for extreme Arctic ice, seismic activity, and permafrost
- Technical concept must cover foundation, materials, and redundancy
- Include Executive Summary with concise mission and why the link is a geopolitical and economic priority
- Include Project Vision & Objectives covering connectivity, trade corridor, energy transport, scientific collaboration, and national security
- Include Feasibility & Site Analysis covering geotechnical, environmental, climate-change impacts, and regulatory pathways in both US and Russian jurisdictions
- Include Cost Estimate & Funding Model with detailed CAPEX (materials, labor, logistics) and OPEX
- Financing structure to cover public-private partnership, sovereign funds, and multilateral banks
- Revenue streams to include tolling, freight, and telecom fiber
- Include Detailed Timeline & Milestones with phased schedule 2026-2041 covering design, permitting, island construction, main span erection, tunnel installation, and commissioning
- Project start ASAP
- Include Risk Register & Mitigation covering ice floe damage, seismic events, political tension, supply-chain disruptions, and indigenous stakeholder concerns
- Propose contingency plans for identified risks
- Include Governance & Management Structure with binational steering committee, technical advisory board, operations authority, and legal framework for joint ownership
- Include Environmental & Social Impact covering mitigation of marine wildlife disturbance, carbon-footprint reduction, and community engagement
- Ensure compliance with US and Russian environmental regulations
- Include Stakeholder & Communication Plan involving Indigenous groups, US Department of Transportation, Russian Ministry of Transport, international investors, and scientific institutions
- Include Economic & Strategic Benefits covering projected trade volume increase, reduced shipping times, energy corridor potential, and enhanced Arctic research collaboration
- Provide the plan in a clear, hierarchical format
- Include a table for cost breakdown
- Include a Gantt-style timeline table
- Include a risk matrix table
- Use concise, action-oriented language throughout
- Refer to points in time as month offsets from project start (e.g., Month 3 = 2027-01-12, Months 48-72 = 2030-10-12 to 2032-10-12), with Month 0 (2026-10-12) = project start
- Mark any figure that is not a user constraint or externally established benchmark as an estimate or proposed value (e.g., '(estimate)', '(proposed threshold)')
- Write in the impersonal voice of a planning document

## Negative Constraints

- Do not present invented numbers as facts
- Do not turn example values from input documents ('e.g. ...') into requirements
- Do not write calendar dates; use month offsets instead
- Do not refer to the author or the writing process (no 'I', 'my knowledge', 'I could not verify', 'I recomputed')
