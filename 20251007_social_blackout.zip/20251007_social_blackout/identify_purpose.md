**Purpose:** business

**Purpose Detailed:** Governmental public policy implementation to restrict minors' access to social media, using inspection teams, penalties, device confiscation, and service suspensions, funded by collected penalties

**Topic:** EU enforcement of under-15 social media blackout via unannounced inspections