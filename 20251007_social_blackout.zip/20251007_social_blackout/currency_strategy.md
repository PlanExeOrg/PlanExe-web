This plan involves money.

## Currencies

- **EUR:** Primary stable currency across EU member states; used for budgeting, inter‑country transfers, salaries, and procurement.
- **PLN:** Local Polish currency needed for vendor payments, payroll, and on‑site expenses in Poland.

**Primary currency:** EUR

**Currency strategy:** EUR will be the main budgeting and reporting currency for the EU‑wide enforcement program. Local transactions in Poland can be settled in PLN, while all other member states use EUR, minimizing exchange‑rate risk and simplifying financial management across the multi‑country operation.