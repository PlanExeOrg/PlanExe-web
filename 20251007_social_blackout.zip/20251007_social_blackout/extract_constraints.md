## Positive Constraints

- Conduct unannounced inspections
- Sweep schools, youth venues, retailers, transit hubs, and random households
- Cross‑check identities during inspections
- Issue spot penalties
- Perform mandatory device confiscation
- Enforce service suspensions
- Enforce EU‑wide under‑15 blackout on all social media and communication platforms
- Fund inspection teams using collected spot penalties
- Start project as soon as possible
