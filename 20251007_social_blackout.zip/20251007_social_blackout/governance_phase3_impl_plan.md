### 1. Project Sponsor (EU Commission President) issues formal mandate to establish the governance framework and appoints a Formation Lead (Senior Project Manager) for the setup phase

**Responsible Body/Role:** Project Sponsor (EU Commission President)

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Governance establishment mandate document
- Formation Lead appointment letter

**Dependencies:**


### 2. Formation Lead drafts the Terms of Reference (ToR) for the EU Enforcement Steering Committee (ESC)

**Responsible Body/Role:** Formation Lead (Senior Project Manager)

**Suggested Timeframe:** Project Week 1‑2

**Key Outputs/Deliverables:**

- Draft ESC ToR v0.1

**Dependencies:**

- Project Sponsor issues formal mandate to establish the governance framework and appoints a Formation Lead (Senior Project Manager) for the setup phase

### 3. Legal Counsel and Data Protection Officer review the draft ESC ToR and provide feedback

**Responsible Body/Role:** Legal Counsel / Head of Data Protection (DPO)

**Suggested Timeframe:** Project Week 2‑3

**Key Outputs/Deliverables:**

- Reviewed ESC ToR with comments

**Dependencies:**

- Formation Lead drafts the Terms of Reference (ToR) for the EU Enforcement Steering Committee (ESC)

### 4. Project Sponsor approves the final ESC ToR after incorporating feedback

**Responsible Body/Role:** Project Sponsor (EU Commission President)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved ESC ToR

**Dependencies:**

- Legal Counsel and Data Protection Officer review the draft ESC ToR and provide feedback

### 5. Project Sponsor formally appoints the ESC Chair (Commission Director for Enforcement) and Vice‑Chair

**Responsible Body/Role:** Project Sponsor (EU Commission President)

**Suggested Timeframe:** Project Week 3‑4

**Key Outputs/Deliverables:**

- Appointment letters for ESC Chair and Vice‑Chair

**Dependencies:**

- Project Sponsor approves the final ESC ToR after incorporating feedback

### 6. ESC Chair, in consultation with the Deputy Director – Legal & Policy, identifies and appoints the remaining ESC members (CFO, Head of DPO, Independent NGO Representative, Independent Procurement Auditor)

**Responsible Body/Role:** ESC Chair (Commission Director for Enforcement)

**Suggested Timeframe:** Project Week 4‑5

**Key Outputs/Deliverables:**

- ESC membership confirmation list
- Signed appointment confirmations

**Dependencies:**

- Project Sponsor formally appoints the ESC Chair (Commission Director for Enforcement) and Vice‑Chair

### 7. First ESC meeting held: adopts meeting calendar, finalises ToR, and records inaugural minutes

**Responsible Body/Role:** ESC (Chair and members)

**Suggested Timeframe:** Project Week 5‑6

**Key Outputs/Deliverables:**

- ESC inaugural meeting minutes
- Final ESC ToR (signed)
- Quarterly meeting schedule

**Dependencies:**

- ESC Chair, in consultation with the Deputy Director – Legal & Policy, identifies and appoints the remaining ESC members

### 8. Formation Lead drafts the Terms of Reference (ToR) for the Enforcement Project Management Office (EPMO)

**Responsible Body/Role:** Formation Lead (Senior Project Manager)

**Suggested Timeframe:** Project Week 5‑6

**Key Outputs/Deliverables:**

- Draft EPMO ToR v0.1

**Dependencies:**

- First ESC meeting held: adopts meeting calendar, finalises ToR, and records inaugural minutes

### 9. ESC reviews the draft EPMO ToR and provides comments

**Responsible Body/Role:** ESC (Chair and members)

**Suggested Timeframe:** Project Week 6‑7

**Key Outputs/Deliverables:**

- Reviewed EPMO ToR with ESC comments

**Dependencies:**

- Formation Lead drafts the Terms of Reference (ToR) for the Enforcement Project Management Office (EPMO)

### 10. ESC formally approves the final EPMO ToR

**Responsible Body/Role:** ESC (Chair and members)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Approved EPMO ToR

**Dependencies:**

- ESC reviews the draft EPMO ToR and provides comments

### 11. ESC appoints the EPMO Director and Deputy Director

**Responsible Body/Role:** ESC (Chair)

**Suggested Timeframe:** Project Week 7‑8

**Key Outputs/Deliverables:**

- Appointment letters for EPMO Director and Deputy Director

**Dependencies:**

- ESC formally approves the final EPMO ToR

### 12. EPMO Director selects and appoints core EPMO members (Head of Logistics & Fleet Management, Chief Inspector, Finance Manager, IT Operations Lead)

**Responsible Body/Role:** EPMO Director

**Suggested Timeframe:** Project Week 8‑9

**Key Outputs/Deliverables:**

- EPMO membership roster
- Signed appointment confirmations

**Dependencies:**

- ESC appoints the EPMO Director and Deputy Director

### 13. EPMO holds its inaugural kick‑off meeting: adopts operational rollout schedule, risk register and and communication protocols

**Responsible Body/Role:** EPMO (Director and members)

**Suggested Timeframe:** Project Week 9‑10

**Key Outputs/Deliverables:**

- EPMO kick‑off meeting minutes
- Approved operational rollout Gantt chart
- Initial operational risk register

**Dependencies:**

- EPMO Director selects and appoints core EPMO members

### 14. Formation Lead drafts the Terms of Reference (ToR) for the Technical Advisory Panel (TAP)

**Responsible Body/Role:** Formation Lead (Senior Project Manager)

**Suggested Timeframe:** Project Week 9‑10

**Key Outputs/Deliverables:**

- Draft TAP ToR v0.1

**Dependencies:**

- EPMO holds its inaugural kick‑off meeting

### 15. ESC reviews the draft TAP ToR and provides feedback

**Responsible Body/Role:** ESC (Chair and members)

**Suggested Timeframe:** Project Week 10‑11

**Key Outputs/Deliverables:**

- Reviewed TAP ToR with ESC comments

**Dependencies:**

- Formation Lead drafts the Terms of Reference (ToR) for the Technical Advisory Panel (TAP)

### 16. ESC formally approves the final TAP ToR

**Responsible Body/Role:** ESC (Chair and members)

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Approved TAP ToR

**Dependencies:**

- ESC reviews the draft TAP ToR and provides feedback

### 17. ESC appoints the TAP Chair (Chief Technology Officer) and selects two external experts (Biometric Security Specialist, AI Ethics Scholar)

**Responsible Body/Role:** ESC (Chair)

**Suggested Timeframe:** Project Week 11‑12

**Key Outputs/Deliverables:**

- Appointment letters for TAP Chair and external experts
- TAP membership list

**Dependencies:**

- ESC formally approves the final TAP ToR

### 18. First TAP technical workshop held: defines biometric scanner specifications, AI scheduling standards, and forensic lab requirements

**Responsible Body/Role:** TAP (Chair and members)

**Suggested Timeframe:** Project Week 12‑13

**Key Outputs/Deliverables:**

- Technical standards and specification document
- TAP workshop minutes

**Dependencies:**

- ESC appoints the TAP Chair and selects two external experts

### 19. ESC drafts the charter for the Ethics, Legal & Human Rights Committee (ELHRC)

**Responsible Body/Role:** ESC (Chair)

**Suggested Timeframe:** Project Week 12‑13

**Key Outputs/Deliverables:**

- Draft ELHRC charter v0.1

**Dependencies:**

- First TAP technical workshop held

### 20. ESC approves the ELHRC charter

**Responsible Body/Role:** ESC (Chair and members)

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Approved ELHRC charter

**Dependencies:**

- ESC drafts the charter for the Ethics, Legal & Human Rights Committee (ELHRC)

### 21. ESC appoints ELHRC Chair (Head of Legal) and members (Human Rights Counsel, Child‑Protection NGO Representative, Ethics Scholar, Compliance Officer)

**Responsible Body/Role:** ESC (Chair)

**Suggested Timeframe:** Project Week 13‑14

**Key Outputs/Deliverables:**

- Appointment letters for ELHRC members
- ELHRC membership roster

**Dependencies:**

- ESC approves the ELHRC charter

### 22. ELHRC inaugural meeting: reviews Penalty Escalation Framework and Device Confiscation Protocol for proportionality and human‑rights compliance

**Responsible Body/Role:** ELHRC (Chair and members)

**Suggested Timeframe:** Project Week 14‑15

**Key Outputs/Deliverables:**

- ELHRC meeting minutes
- Ethical assessment report on escalation framework

**Dependencies:**

- ESC appoints ELHRC Chair and members

### 23. ESC drafts the charter for the Data Protection Oversight Board (DPOB)

**Responsible Body/Role:** ESC (Chair)

**Suggested Timeframe:** Project Week 14‑15

**Key Outputs/Deliverables:**

- Draft DPOB charter v0.1

**Dependencies:**

- ELHRC inaugural meeting

### 24. ESC approves the DPOB charter

**Responsible Body/Role:** ESC (Chair and members)

**Suggested Timeframe:** Project Week 15

**Key Outputs/Deliverables:**

- Approved DPOB charter

**Dependencies:**

- ESC drafts the charter for the Data Protection Oversight Board (DPOB)

### 25. ESC appoints DPOB Chair (Head of Data Protection) and members (CISO, External GDPR Auditor, Academic Data‑Privacy Expert, Legal Counsel)

**Responsible Body/Role:** ESC (Chair)

**Suggested Timeframe:** Project Week 15‑16

**Key Outputs/Deliverables:**

- Appointment letters for DPOB members
- DPOB membership roster

**Dependencies:**

- ESC approves the DPOB charter

### 26. DPOB first meeting: approves the initial Data Protection Impact Assessment (DPIA) and defines audit schedule

**Responsible Body/Role:** DPOB (Chair and members)

**Suggested Timeframe:** Project Week 16‑17

**Key Outputs/Deliverables:**

- DPIA approval certificate
- DPOB meeting minutes
- Quarterly privacy audit plan

**Dependencies:**

- ESC appoints DPOB Chair and members

### 27. ESC drafts the charter for the Community Liaison Council (CLC)

**Responsible Body/Role:** ESC (Chair)

**Suggested Timeframe:** Project Week 16‑17

**Key Outputs/Deliverables:**

- Draft CLC charter v0.1

**Dependencies:**

- DPOB first meeting

### 28. ESC approves the CLC charter

**Responsible Body/Role:** ESC (Chair and members)

**Suggested Timeframe:** Project Week 17

**Key Outputs/Deliverables:**

- Approved CLC charter

**Dependencies:**

- ESC drafts the charter for the Community Liaison Council (CLC)

### 29. ESC appoints CLC Chair (Head of Stakeholder Engagement) and members (School Association Rep, Parent‑Teacher Org Rep, NGO Child‑Protection Advocate, Retail Liaison)

**Responsible Body/Role:** ESC (Chair)

**Suggested Timeframe:** Project Week 17‑18

**Key Outputs/Deliverables:**

- Appointment letters for CLC members
- CLC membership roster

**Dependencies:**

- ESC approves the CLC charter

### 30. CLC inaugural forum: launches multilingual online portal, grievance hotline, and publishes first public‑acceptance survey

**Responsible Body/Role:** CLC (Chair and members)

**Suggested Timeframe:** Project Week 18‑20

**Key Outputs/Deliverables:**

- Forum minutes
- Live portal URL
- Hotline SOP document
- Initial public‑acceptance survey results

**Dependencies:**

- ESC appoints CLC Chair and members