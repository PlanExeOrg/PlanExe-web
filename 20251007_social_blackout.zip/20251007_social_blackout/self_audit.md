Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 16 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 3 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan deals with enforcement logistics and biometric checks, not physics. "Deploy a fleet of vans equipped with biometric scanners" and "The plan aims to achieve 80 % coverage".

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of penalty‑funded inspection teams, biometric verification, and rapid‑response mobile units without independent evidence at comparable scale. "Penalty‑Funded Inspection Teams create a self‑sustaining enforcement workforce by channeling collected fines into salaries, transport, and equipment." "Deploy a fleet of compact vans equipped with portable biometric scanners to conduct surprise inspections at schools and transit stations during high‑traffic periods."

**Mitigation**: Legal & Regulatory Compliance Officer: Draft EU emergency decree, secure ECJ advisory opinion, and run pilot validation tracks for legal, technical, and privacy domains within 60 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan defines levers such as "Penalty‑Funded Inspection Teams" and "Venue Prioritization Strategy" but does not assign owners or provide concise one‑pagers with clear inputs→process→customer value and measurable outcomes.

**Mitigation**: Program Director: Draft one‑pager per strategic lever (owner, mechanism, metrics) and circulate for approval by 31 July 2026.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions key second‑order risks but lacks a detailed register with owners, controls, and explicit cascade mappings. "Regulatory and legal challenges to mandatory biometric checks, device confiscation, and public backlash" and "Funding volatility – a rolling reserve fund covering six months of operating costs (≈ €30 M) and a €15 M EU contingency grant" illustrate partial treatment.

**Mitigation**: Legal & Regulatory Compliance Officer: Develop a full second‑order risk register with owners, controls, and cascade diagrams, and implement quarterly review updates; finalize by 31 July 2026.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a detailed permit/approval matrix and cites "Legal clearance buffer 4 weeks" and "Member‑state approval delays >2 months may push full coverage by up to 6 weeks", indicating approvals exceed allocations.

**Mitigation**: Legal & Regulatory Compliance Officer: Rebuild critical path with detailed permit matrix and dated predecessors, set NO‑GO thresholds, and deliver revised schedule within 30 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan only states "Annual budget €200 million; 60 % (€120 million) from penalties, 40 % (€80 million) EU central funds" and "Reserve fund €30 million (15 % of budget) covers six months low‑violation period" but provides no signed term sheets, detailed draw schedule, or runway calculation of ≥ X months.

**Mitigation**: Finance Director: Draft a dated financing plan listing each source/status, draw schedule, covenants, and a NO‑GO clause for missed financing gates within 30 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan provides only a total €200 million budget and a €30 million reserve ("Annual budget €200 million; 60 % (€120 million) from penalties" and "Reserve fund €30 million (15 % of budget) covers six months low‑violation costs") but no vendor quotes, no cost‑per‑area benchmarks, and no 10‑20% contingency breakdown, leaving cost realism unverified.

**Mitigation**: Finance Director: Obtain three vendor quotes for vans and biometric scanners, calculate cost per square meter of coverage, add 15 % contingency, and revise budget by 31 July 2026.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lists single‑point figures like "Annual budget €200 million; 60 % (€120 million) from penalties" and "80 % venue coverage" without any range or scenario analysis.

**Mitigation**: Finance Directorate: Deliver a sensitivity analysis with best‑, base‑, and worst‑case revenue and coverage scenarios by 30 June 2026.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions deployment of vans and biometric scanners but provides no technical specifications, interface contracts, acceptance tests, integration plan, or non‑functional requirements. "Deploy a fleet of compact vans equipped with portable biometric scanners" and "Implement a secure EU‑hosted data hub" are the only related quotes.

**Mitigation**: Engineering Lead: Draft and approve technical specs, interface contracts, acceptance test suites, integration plan, and non‑functional requirements for all build‑critical components within 30 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan asserts obtaining an ECJ advisory opinion and a signed reserve‑fund agreement but provides no document links or IDs to verify these legal and financial artifacts.

**Mitigation**: Legal & Regulatory Compliance Officer: Draft the EU emergency decree, secure the ECJ advisory opinion, and obtain a signed reserve‑fund agreement, completing all by 31 July 2026.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "Penalty‑Funded Inspection Teams" without concrete acceptance criteria or measurable KPIs beyond vague coverage targets; the deliverable remains abstract.

**Mitigation**: Program Director: Define SMART criteria for Penalty‑Funded Inspection Teams, including KPI for inspection throughput (e.g., ≥200 inspections per day) by 31 July 2026.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Retail Partner Enforcement Pact adds significant cost and complexity (contract negotiations, revenue‑share incentives, and extra inspection logistics) without directly supporting the core objectives of 80% coverage and 60% exposure reduction. "Retail Partner Enforcement Pact secures cooperation from retail chains to grant inspection teams entry rights and temporary device seizure during blackout hours." "By negotiating contracts and offering revenue‑share incentives, the lever expands physical coverage into high‑traffic commercial venues while generating a funding stream from collected penalties."

**Mitigation**: Program Director: Produce a one‑page benefit case for the Retail Partner Enforcement Pact, including KPI, owner, cost estimate, by 31 July 2026.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on a Legal & Regulatory Compliance Officer to draft an emergency decree and obtain an ECJ advisory opinion; Plan says “Draft an emergency decree”.

**Mitigation**: HR Lead: Conduct talent‑market analysis for EU emergency‑law experts, compile shortlist with availability and salary ranges, and deliver report by 30 May 2026.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan only states “Draft an EU emergency decree authorising mandatory biometric checks and device confiscation” and “Obtain a provisional ECJ advisory opinion on proportionality within 30 days,” but no approvals or lead‑time evidence are provided.

**Mitigation**: Legal & Regulatory Compliance Officer: Finalise EU emergency decree, secure ECJ advisory opinion, and obtain national transposition agreements within 45 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on volatile penalty revenue and a modest reserve, creating funding shortfalls; "Penalty‑Funded Inspection Teams create a self‑sustaining enforcement workforce by channeling collected fines into salaries, transport, and equipment" and "Relying on fine revenue creates budget elasticity that may cripple enforcement during low‑violation periods".

**Mitigation**: Finance Director: Develop a rolling reserve fund equal to 25 % of annual operating costs, secure a €15 M EU contingency grant, and add a fixed EU budget line, by 30 June 2026.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan provides no evidence that zoning, occupancy, fire‑load, structural or noise permits are secured; it only cites “Vehicle operation permits for rapid‑response vans” and “Obtain national transposition agreements” without confirming approvals.

**Mitigation**: Legal & Regulatory Compliance Officer: Conduct a fatal‑flaw screen with authorities, secure written zoning, occupancy, fire‑load, structural and noise permits for all sites, and define NO‑GO thresholds; deliver findings within 30 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on a single EU tender for electric/hybrid vans and a single handheld biometric scanner vendor without documented secondary suppliers or tested failover. "Issue EU Tender for Electric/Hybrid Vans" and "Select Handheld Biometric Scanner Vendor".

**Mitigation**: Operations & Logistics Manager: Add secondary supplier contracts for vans and biometric scanners, and conduct failover test by 31 July 2026.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because Finance seeks cost control ('Financial & Funding Analyst: model penalty revenue scenarios') while R&D drives tech innovation ('Technology & Systems Engineer: develop biometric verification platform'), creating tension.

**Mitigation**: Finance Director & Technology Lead: Draft a shared OKR limiting experimental spend to 10% of budget while delivering two biometric enhancements, due 31 Oct 2026.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan only states "Success is measured by inspection throughput, budget variance, and compliance uplift" but does not assign owners, set a review cadence, or define a change‑control process with thresholds; the vague monitoring language leaves a critical feedback loop missing.

**Mitigation**: Program Director: Schedule a monthly KPI review meeting, create a dashboard reporting coverage, response time, and budget variance, and convene a lightweight change board to approve adjustments, to be operational by 30 June 2026.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan’s reliance on fine revenue creates budget elasticity that can trigger legal, privacy, and public‑backlash cascades. "Relying on fine revenue creates budget elasticity".

**Mitigation**: Legal & Regulatory Compliance Officer: Draft interdependency map, bow‑tie analysis, and combined heatmap with owners, dates, and NO‑GO thresholds by 30 June 2026.