**Goal Statement:** Design, pilot and publish Clear English Standard v1.0, a parallel (not replacement) English variant with regularized ordinals, spelling-to-sound guidance, capped morphology changes and homograph disambiguation, within 36 months and $3.5M (user constraint), led by an ESL-first adoption wedge.

## SMART Criteria

- **Specific:** Deliver a public Clear English Standard v1.0 with rule set and rationale, 5,000-word reference dictionary, style guide, pilot curriculum with assessments and open licensing policy, for adult ESL, technical writing and safety-critical glossary use, without mandates or K-12 replacement.
- **Measurable:** Success is a Month 24 (2028-10-13) GO on four pre-registered metrics: ordinal error reduction >=25% (proposed threshold), comprehension speed within 10% of control, pronunciation consistency >=15% above control with a statistically significant difference (scoring kappa target 0.75, floor 0.70 as a separate validity condition), 30-day retention >=70% of post-test and not below control. Also >=3 licensed third-party adopters by Month 36 (2029-10-13) (proposed).
- **Achievable:** Feasible through a gated three-phase plan, light-touch rules (standard spellings kept, prefix ordinals coexisting with legacy forms) and a $3.5M budget with a $0.35M reserve. Limits: scarce psychometric skills, pilot attrition, and unfunded post-Month-36 stewardship.
- **Relevant:** Gives ESL learners and technical writers a consistent, optional standard that reduces high-friction inconsistencies and ambiguity, with evidence-based adoption by publishers and standards bodies rather than mandates.
- **Time-bound:** 36 months from Month 0 (2026-10-13): Phase 1 Months 0-12 (2026-10-13 to 2027-10-13) rules and corpus; Phase 2 Months 12-24 (2027-10-13 to 2028-10-13) pilots with go/no-go at Month 24 (2028-10-13); Phase 3 Months 24-36 (2028-10-13 to 2029-10-13) release and limited adoption, v1.0 by Month 30 (2029-04-13) (proposed).

## Dependencies

- Establish editorial board charter, voting rules and tiebreak arbiter by Month 1 (2026-11-13)
- Hire independent psychometrician and pre-register gate metrics and thresholds by Month 11 (2027-09-13)
- Secure signed pilot partner commitments (ESL programs, technical/safety-training organizations) by Month 3 (2027-01-13)
- Complete 5,000-word lexicon and single-accent audio, with ethics approval and legal counsel in place
- Lock rules at Month 12 (2027-10-13) and secure steward commitment before v1.0 release

## Resources Required

- Core team of 8-10 FTE peak (proposed)
- $3.5M budget: Phase 1 $1.1M, Phase 2 $1.2M, Phase 3 $0.85M, reserve $0.35M
- Audio recording studio capacity and encrypted storage
- Assessment and logging platform with lexicon and pronunciation overlay tooling
- Pilot site access and legal/ethics advisory services

## Related Goals

- Adult ESL learner support
- Clear safety-critical documentation
- Plain-language and controlled-language alignment
- Post-project stewardship of the standard
- Evidence-based language standards

## Tags

- Clear English
- language standard
- ESL
- safety-critical documentation
- pilot study

## Risk Assessment and Mitigation Strategies


### Key Risks

- Educator, publisher and standards-body rejection or pushback reducing adoption and pilot engagement
- Pilot recruitment shortfall or dropout above 30% invalidating gate metrics
- Weak or disputable assessment validity and rater reliability (kappa below 0.70)
- Editorial board deadlock or rule ambiguity delaying the Month 12 (2027-10-13) rules lock
- Safety-critical liability exposure from misreading of Clear English text

### Diverse Risks

- Budget overrun (a $300K overrun is 8.6% of budget, estimate) exceeding the $175K pre-gate reserve cap
- Phase 1 slippage compressing the pilot window, with Phase 2 extension costing up to $300K for 3 months (estimate)
- Fragmentation and unofficial variants after release
- Pilot audio privacy and ethics approval delays
- Unfunded stewardship after Month 36 (2029-10-13) ($150K-$250K per year, estimate)

### Mitigation Plans

- Position as supplementary ESL module; co-design protocols with teachers, engage TESOL/IATEFL and publishers from Months 1-3 (2026-11-13 to 2027-01-13), fund an educator liaison
- Sign enrolment commitments by Month 3 (2027-01-13), over-recruit to >=115 per arm (estimate), use incentives and a cohort manager by Month 6 (2027-04-13)
- Pre-register thresholds by Month 11 (2027-09-13), run validity study and dry run at Month 10 (2027-08-13), retrain raters, and extend Phase 1 by 4 weeks if kappa stays below 0.70
- Publish board charter by Month 1 (2026-11-13), resolve disputes by Month 10 (2027-08-13), use external arbiter, freeze rules during pilots
- Limit pilots to glossary and labeling, retain legal counsel by Month 2 (2026-12-13), disclaim and human-review all materials, use monthly budget tracking and critical-path reviews, certification mark and early steward search

## Stakeholder Analysis


### Primary Stakeholders

- Project lead and program team
- Editorial board and linguistic reviewers
- Psychometrician and assessment team
- Curriculum designers and cohort manager
- Educator liaison

### Secondary Stakeholders

- Adult ESL programs and learners
- Technical and safety-training organizations
- ESL publishers and standards bodies (TESOL, IATEFL, ASD-STE100 maintainers)
- Academic and university partners
- Potential steward organizations and funders

### Engagement Strategies

- Primary team: monthly critical-path and budget reviews, decision logging and prompt escalation of slips over 2 weeks
- Editorial board: charter, first meeting at Month 2 (2026-12-13), published rationale for contested rules
- Pilot partners and teachers: written commitments, co-designed protocols, stipends, quarterly advisory panels, Month 18 (2028-04-13) check-in
- Publishers and standards bodies: non-binding letters of interest by Month 3 (2027-01-13), milestone updates, free light conformance checklist
- Steward candidates: proposal by Month 24 (2028-10-13), commitment sought before v1.0 release

## Regulatory and Compliance Requirements


### Permits and Licenses

- Ethics/IRB approval for pilot research with human participants
- Data-sharing and consent agreements with pilot partner institutions
- Trademark or certification-mark registration for the 'Clear English' name
- Open license for text and dictionary

### Compliance Standards

- GDPR and US state data-protection laws for pilot audio and scores
- Research ethics and informed-consent standards
- Product liability and disclaimer practice for safety-critical materials
- Accessibility and fair-use norms for published curricula

### Regulatory Bodies

- Institutional Review Board or research ethics committee
- Data-protection authorities (ICO, US state regulators)
- Education authorities and accreditation bodies in pilot jurisdictions
- Workplace safety regulators (OSHA, HSE) for safety-critical contexts

### Compliance Actions

- Engage ethics review at Months 1-2 (2026-11-13 to 2026-12-13) and obtain approval by Month 6 (2027-04-13)
- Secure encrypted audio storage by Month 6 (2027-04-13) and audit by Month 8 (2027-06-13)
- Publish privacy policy and consent forms by Month 12 (2027-10-13)
- Retain legal counsel by Month 2 (2026-12-13) and set liability strategy by Month 4 (2027-02-13)
- Decide licensing and certification model by Month 6 (2027-04-13) and publish by Month 12 (2027-10-13)