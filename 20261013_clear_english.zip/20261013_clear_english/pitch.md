Persuasive elevator pitch.

# Clear English Standard: A Parallel English Variant for Adult ESL Learners and Technical Writers

## Project Overview

Imagine a pathway for millions of learners to finally read English with confidence—without replacing the English they know.

**Clear English Standard** is a parallel English variant designed for adult ESL learners and technical writers who lose critical information to spelling irregularities, unpredictable ordinals, and ambiguous words. Over 36 months and $3.5M, this project will deliver a public standard with regularized ordinals, pronunciation guidance, and homograph disambiguation—validated through rigorous pilots at Month 24 (2028-10-13), optionally adopted by ESL publishers and safety-critical sectors, and stewarded for long-term stability.

This is not a replacement. **Clear English sits alongside standard English** as a supplementary module and optional overlay. Learners and organizations choose it. The standard is built on defensible evidence: four pre-registered gate metrics (ordinal error reduction ≥25%, comprehension speed within 10% of control, pronunciation consistency ≥15% above control, 30-day retention ≥70%), independently reviewed assessments, and a 5,000-word reference lexicon validated in real classrooms and technical settings.

Clear English matters because **inconsistency costs learners time and errors cost lives**. A native speaker absorbs "read (present)" vs. "read (past)" through years of exposure; an ESL learner sees contradiction. A technical glossary resolves that gap—saving seconds on every procedure and potentially preventing miscommunication in safety-critical work.

This project is **evidence-gated, not ideologically driven**. If the pilots do not meet the threshold metrics, the project stops before public release and returns unspent funds. If they do, Clear English becomes a certified, openly licensed resource that any publisher or standards body can adopt on transparent terms, without mandates or takeover of K-12 education.

## Target Audience

- **Primary:** Adult ESL program leaders and ESL publishers seeking a proven, evidence-backed curriculum innovation; technical and safety-training organizations evaluating ways to reduce documentation errors.
- **Secondary:** Editorial boards, standards bodies (TESOL, IATEFL, ASD-STE100 maintainers) and academic linguistics researchers interested in language-planning and constructed-variant precedent.
- **Tertiary:** Potential steward organizations and language-policy advocates in non-profit sectors.
- **Not:** K-12 educators, policymakers seeking mandates, or general public audiences.

## Risks and Mitigation Strategies

**Educator and publisher pushback**

Risk: Teachers resist a "non-standard" variant or publishers see it as a competitor.

Mitigation: Position as supplementary, not replacement; co-design protocols with teachers from Month 1 (2026-11-13); engage TESOL/IATEFL early; fund an educator liaison.

**Pilot recruitment shortfall**

Risk: Enrollments fall below 80 completers per arm, invalidating gate metrics.

Mitigation: Sign commitments by Month 3 (2027-01-13); over-recruit to ≥115 per arm; use incentives ($50–$150 stipends) and a dedicated cohort manager by Month 6 (2027-04-13).

**Assessment validity**

Risk: Pronunciation raters disagree (kappa <0.70), making the go/no-go gate disputable.

Mitigation: Pre-register thresholds by Month 11 (2027-09-13); run a validity study by Month 10 (2027-08-13); retrain raters; extend Phase 1 by 4 weeks if needed.

**Safety-critical liability**

Risk: Misreading in operational procedures causing harm.

Mitigation: Limit pilots to glossary and labeling only; retain legal counsel by Month 2 (2026-12-13); disclaim all materials; human-review every entry.

## Metrics for Success

**Gate metrics (Month 24 = 2028-10-13)**

- Ordinal error reduction ≥25% vs. standard-English control
- Comprehension speed ≤10% slower than control
- Pronunciation consistency ≥15% above control with kappa ≥0.70
- 30-day retention ≥70%

**Operational metrics (Phase 1 exit, Month 12 = 2027-10-13)**

- Rules locked; 5,000 entries with usable audio
- Inter-rater kappa ≥0.70
- Ethics approval in hand
- ≥3 ESL and ≥2 technical-training partner commitments

**Adoption metrics (Month 36 = 2029-10-13)**

- ≥3 licensed third-party adopters (at least 1 ESL publisher)
- Steward commitment signed before v1.0 release
- Conformance checklists passed by ≥2 published materials

**Fidelity and risk metrics**

- No rule changes during pilots
- Zero safety incidents in pilot glossaries
- Stranding of <$175K pre-gate reserve before Month 24 (2028-10-13) no-go fallback

## Stakeholder Benefits

**ESL programs and learners**

A defensible, certified supplementary curriculum module with validated gains in ordinal recognition, pronunciation consistency and 30-day retention; optional overlay that does not disrupt standard English teaching.

**Technical and safety-training organizations**

A 500-word safety-critical glossary with mandatory homograph markers in procedures, reducing ambiguity-driven errors without the cost of full controlled-language training.

**ESL publishers**

License-to-use the reference lexicon, style guide and assessment items on permissive terms; gain competitive advantage by offering Clear English modules certified against a public checklist.

**Standards bodies (TESOL, IATEFL)**

A precedent for evidence-gated language innovation; no institutional turf conflict (independent non-profit steward).

**Linguistics and language-policy researchers**

A real-world test case of constructed-variant adoption, governance and fragmentation control.

## Ethical Considerations

**Transparency and evidence**

All pilot data, decision logs and assessment instruments made public (with participant consent); pre-registered metrics and thresholds locked before pilots start to prevent p-hacking and selective reporting.

**Inclusivity and accent bias**

Reference accent chosen by Month 3 (2027-01-13) with documented mapping of other major English varieties; pronunciation consistency score scored on shared phonemic contrasts to avoid privileging one region; additional accents proposed as optional post-v1.0 (not funded in this phase).

**Informed consent and data protection**

Ethics approval by Month 6 (2027-04-13); encrypted audio storage with GDPR compliance; participants compensated fairly ($50–$150 stipends); right to withdraw.

**Liability and safety**

Safety-critical pilots limited to glossary and labeling, no live procedures; legal counsel retained; all materials disclaimed; human review of every homograph marker.

**Equity**

Free, **open-licensed standard** with no paywall; certification mark is non-profit and awards based on a published conformance checklist, not gatekeeping; no mandates or K-12 replacement claims.

## Collaboration Opportunities

**ESL program partnerships**

Co-develop pilot curriculum, recruit and support learner cohorts (Months 12–24 = 2027-10-13 to 2028-10-13); receive published curriculum materials and conformance training.

**Technical-writing and safety-training organizations**

Co-design the 500-word safety-critical glossary; pilot homograph-marking protocols; receive validated glossary with licensing rights.

**ESL publishers**

License reference lexicon, dictionary and style guide; adopt Clear English as a supplementary module; use public conformance checklist for certification.

**Linguistics and applied-language research**

Commission or collaborate on pronunciation-rater calibration, morphology-error analysis and adoption-barrier research; access anonymized pilot data for secondary analysis (after Month 24 = 2028-10-13 gate).

**Standards bodies (ASD-STE100, ICAO, plain-language networks)**

Validate one-way mapping table from existing standards; co-author compatibility guidance; refer members to Clear English resources (no formal liaison funded).

**Post-v1.0 steward organization**

Assume governance, change-control and archive roles; receive $0.35M reserve release post-gate plus pro-rata Phase 3 funding if commitments are met by Month 33 (2029-07-13).

## Long-term Vision

**Institutional sustainability**

Clear English Standard is transferred to a committed, non-profit steward organization by Month 36 (2029-10-13) with a published 10-year governance roadmap, change-control calendar and annual budget ($150K–$250K per year, estimate). The steward enforces the certification mark, approves third-party adopters against a public checklist and coordinates maintenance without centralized control.

**Adoption pathway**

By Month 36 (2029-10-13), ≥3 third-party adopters (at least 1 ESL publisher) integrate Clear English into courseware and glossaries, reaching an estimated 10,000–50,000 learners within 5 years; safety-critical sectors adopt the 500-word glossary in procedure manuals and training, reducing ambiguity-driven errors.

**Evolution and resilience**

v1.0 is frozen for 12 months post-release; v2.0 consolidates pilot feedback and post-launch usage data by Month 42 (2030-04-13). **Fragmentation is controlled** by the certification mark and the requirement that variants beyond 10% of rules adopt a distinct name.

**Knowledge and precedent**

Clear English becomes a documented case study in evidence-gated language planning, governance and constructed-variant adoption, contributing to applied linguistics research and informing future language-standardization initiatives.

## Call to Action

**ESL program leaders and technical-training organizations**

Express interest in pilot partnership by Month 3 (2027-01-13). Sign a Memorandum of Understanding committing to ≥115 learner enrollments and onsite assessment sessions; we provide curriculum, incentives ($50–$150 per participant) and expert facilitation.

**ESL publishers and standards bodies**

Review the draft standard at Month 11 (2027-09-13) during the 30-day public comment window; submit conformance letters of interest by Month 12 (2027-10-13).

**Potential steward organizations**

Contact the project lead to discuss post-v1.0 governance roles and funding partnerships by Month 24 (2028-10-13).