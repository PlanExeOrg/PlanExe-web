## Primary Decisions
The vital few decisions that have the most impact.


The five Critical levers (Ordinal Marker Architecture, Grapheme-to-Phoneme Depth, Adoption Wedge, Outcome Metric Battery, Phase Budget) cover the main tensions: rule ambition versus recognizability and adoption, evidence rigor versus a fixed budget, and breadth versus depth of market entry. High levers refine content and governance. No distinct lever addresses risk and liability management for safety-critical pilots, or educator-outreach and training capacity.

### Decision 1: Ordinal Marker Architecture
**Lever ID:** `1a9e4740-06a2-43cd-9ac0-fb5ab53fb48e`

**The Core Decision:** Sets the single rule that replaces 1st/2nd/3rd, 11th–13th and 21st/31st patterns, and thereby the most visible, testable feature of the standard. Scope covers written form, a fixed spoken reading and machine conversion of legacy forms. Success metrics: ordinal error rate in pilots, native-reader acceptance, reading speed, and ease of automatic conversion in dates, lists and procedures.

**Why It Matters:** Choosing between a numeric form with one invariant marker (A) and fully spelled ordinals with regular endings (B) decides how many learners can use the rule on day one. Numeric forms are shorter and match how ordinals already appear in dates, lists and procedures, but they leave the spoken form unresolved. Spelled forms fix speech and writing together but add new unfamiliar words such as 'oneth' that native readers may reject.

**Strategic Choices:**

1. Adopt numeric ordinals with one invariant suffix on every digit string, so 1, 2, 3, 11, 21 all take the same marker, and publish a fixed spoken reading for that suffix.
2. Adopt numeric ordinals with an invariant prefix marker placed before the digits, avoiding clashes with the legacy 1st/2nd/3rd suffixes and letting software convert both forms mechanically.
3. Adopt fully spelled ordinals with a single regular -th ending, retain digits only in tables and codes, and justify the choice through pilot reading-speed comparisons.

**Trade-Off / Risk:** Option A is cheaper to teach and machine-convert, but it leaves pronunciation open; option B resolves speech yet risks native-reader rejection of forms like 'oneth', so the choice should be tested rather than argued.

**Strategic Connections:**

**Synergy:** Feeds Outcome Metric Battery Design, since ordinal error rate is a go/no-go metric, and strengthens Adoption Wedge and Sequencing by giving safety-critical procedures and numbered steps an immediately usable, low-cost rule.

**Conflict:** Pulls against Grapheme-to-Phoneme Intervention Depth: a spelled-out ordinal form implies respelling, while a numeric marker leaves spoken form to the pronunciation layer. Also strains Reference Accent Anchor when fixing the spoken reading.

**Justification:** *Critical*, Sets the most visible, testable rule of the standard and feeds the ordinal error rate gate metric. Connects to Outcome Metric Battery, Adoption Wedge, G2P Depth and Accent Anchor, and controls the numeric-versus-spelled trade-off between native-reader acceptance and spoken-form resolution.

### Decision 2: Grapheme-to-Phoneme Intervention Depth
**Lever ID:** `f2c8fd84-4f48-425c-87f3-17d8bb34c18b`

**The Core Decision:** Determines whether Clear English changes spelling itself or only layers guidance on top of it, which sets conversion cost, tooling needs and educator acceptance. Scope is the 5,000-word lexicon and its respelling key or overlay. Success metrics: pronunciation consistency score, recognition distance of changed forms, compatibility with search and dictionary tools, and publisher willingness to adopt.

**Why It Matters:** This lever sets how far the standard departs from conventional spelling. Leaving spellings intact and adding a pronunciation layer protects recognizability and publisher buy-in, but learners still face irregular spelling. Respelling words directly fixes the sound mapping but breaks compatibility with existing text, search tools and dictionaries, and raises the risk of fragmentation.

**Strategic Choices:**

1. Keep standard spellings unchanged and add a consistent pronunciation-guidance layer to the 5,000-word lexicon, using one minimal respelling key in dictionaries and teaching materials.
2. Respell only a ranked shortlist of the highest-friction spelling patterns in the core lexicon, keeping every changed form within easy recognition distance of its standard spelling.
3. Render pronunciation as an optional software-generated overlay, such as ruby-style annotations in digital materials, so printed text stays standard while learners see the regularized mapping on demand.

**Trade-Off / Risk:** A guidance layer is the safest route to adoption, but it does not truly fix spelling-to-sound inconsistency; deeper respelling delivers that fix while multiplying conversion costs and the risk that educators reject the variant.

**Strategic Connections:**

**Synergy:** Works with Reference Accent Anchor, which supplies the sound targets the mapping encodes, and with Core Lexicon Selection Basis, which defines which words get guidance first. A light-touch layer also eases Licensing and Name Stewardship.

**Conflict:** Deeper respelling conflicts with Change-Control and Release Cadence, because each respelling change forces reprints and invalidates materials, and with Adoption Wedge and Sequencing, where publishers and educators resist incompatible text.

**Justification:** *Critical*, Controls the core trade-off between fixing spelling-to-sound and preserving compatibility and publisher buy-in. Hub linking Accent Anchor, Core Lexicon, Change-Control, Adoption Wedge, Licensing and Homograph markers; deeper respelling directly raises fragmentation and rejection risk against the adoption priority.

### Decision 3: Adoption Wedge and Sequencing
**Lever ID:** `3a239b73-ec97-45dc-9dbd-d3e4250b89a3`

**The Core Decision:** Chooses which user group meets Clear English first and therefore which evidence, partners and liability exposure the program builds. The choice shapes pilot recruitment, the form of materials and the credibility story for the Phase 2 go/no-go. Success metrics: pilot cohort enrollment, partner commitments, time to first real-world use and absence of stalled approvals.

**Why It Matters:** The first market chosen shapes the evidence, the partners and the risk exposure of the program. Safety-critical documentation offers clear measurable benefits but brings liability concerns and slow organizational approval. ESL publishers move faster and supply learners for pilots, but they may demand full curricula and treat the variant as a competitor to standard English teaching.

**Strategic Choices:**

1. Lead with adult ESL programs and publishers, offering Clear English as a supplementary module that sits alongside standard English curricula rather than replacing them.
2. Lead with a technical glossary for safety-critical documentation, co-developed with one or two industry or standards-body partners and tested in real working procedures.
3. Lead with a free, standalone reference site and browser extension that lets any reader toggle between standard and Clear English forms, building a user base before institutional partnerships.

**Trade-Off / Risk:** Each wedge builds a different evidence base, so choosing one early narrows the others; the risk is that a safety-critical pilot gets stalled by liability review while the ESL track starves for rules.

**Strategic Connections:**

**Synergy:** Sets priorities for Outcome Metric Battery Design and Core Lexicon Selection Basis, because the chosen wedge determines which metrics and which glossary vocabulary are collected first, and supports Licensing and Name Stewardship through early partner agreements.

**Conflict:** Competes with Phase Budget Weighting and Reserve: pursuing one wedge deeply starves the others, and a safety-critical lead raises liability and slow approvals that clash with Change-Control and Release Cadence.

**Justification:** *Critical*, The central hub: determines which partners, evidence, liability exposure and glossary vocabulary the program builds first. Synergies run to metrics, lexicon, licensing and homograph policy; conflicts with budget and change-control. Directly serves the plan's 'optimize for adoption' directive.

### Decision 4: Outcome Metric Battery Design
**Lever ID:** `8066426e-2101-40b0-a31b-2c802373d134`

**The Core Decision:** Defines the instruments, scoring rules and sampling that turn the four gate metrics (comprehension speed, ordinal error rate, pronunciation consistency, 30-day retention) into decision-grade evidence. Scope includes control-group design, inter-rater reliability for pronunciation scoring, and pre-registered pass/fail thresholds fixed before Month 12 (2027-10-13). Success means the Phase 2 go/no-go cannot be disputed as measurement artefact by educators or standards bodies.

**Why It Matters:** This lever decides how comprehension speed, ordinal error rate, pronunciation consistency and 30-day retention are actually measured in the pilots. Instrument choices determine whether the Phase 2 go/no-go decision rests on defensible evidence or on noisy proxies. Richer instruments need more psychometric expertise and more supervised sessions, which draws on pilot budget and learner time.

**Strategic Choices:**

1. Adopt validated off-the-shelf reading, listening and recall instruments and adapt them minimally, accepting less precision on Clear English-specific features in exchange for external credibility.
2. Develop a purpose-built assessment set for each of the four metrics, calibrated against a standard-English control group, and have an independent psychometrician review item validity before the pilots begin.
3. Embed measurement in normal course work through passive digital logging of response times and error patterns, supplemented by a small supervised audio-capture sample for pronunciation scoring.

**Trade-Off / Risk:** Purpose-built instruments fit the four gate metrics but are untested and costly to validate; borrowed instruments are credible yet may miss exactly the ordinal and pronunciation effects the standard is meant to change.

**Strategic Connections:**

**Synergy:** Strengthens Phase Budget Weighting and Reserve, because credible metrics justify staged release of funds. Also amplifies Adoption Wedge and Sequencing by giving partner organizations defensible evidence that Clear English works in their setting.

**Conflict:** Competes with Phase Budget Weighting and Reserve, since purpose-built instruments and psychometric review consume pilot money. Also clashes with Grapheme-to-Phoneme Intervention Depth and Reference Accent Anchor if rules shift mid-pilot, invalidating calibrated items.

**Justification:** *Critical*, Converts the four gate metrics into decision-grade evidence for the Phase 2 go/no-go. Pulls together ordinal, morphology, accent and G2P choices and competes with budget; weak instruments make the gate disputable and undermine partner confidence.

### Decision 5: Phase Budget Weighting and Reserve
**Lever ID:** `093258bc-f4c3-4775-bec5-b125346fcf20`

**The Core Decision:** Allocates the fixed $3.5M across rule specification, pilots and public release, and sets the size and release conditions of any contingency reserve. The split determines how many pilot sites, assessment sessions and print runs are affordable, and whether a no-go at the Phase 2 gate returns funds or strands them. Success means each gate is adequately funded without overspending before evidence exists.

**Why It Matters:** This lever splits the fixed $3.5M across rule specification, pilots and public release, and decides how much is held back as a reserve. Front-loading Phase 1 gives sturdier rules but squeezes pilots, where the evidence for the go/no-go gate is generated. A larger reserve protects against rework after Phase 2 but reduces what can be spent on outreach and curriculum quality.

**Strategic Choices:**

1. Weight spending toward Phase 2 pilots and assessments, keeping Phase 1 lean through a small expert team and a deliberately narrow first rule set that can be piloted quickly.
2. Spread spending roughly evenly across the three phases, with a modest unallocated reserve released by the editorial board only after the go/no-go decision.
3. Hold a large contingent tranche that is released in stages against evidence milestones, so that a no-go outcome at Phase 2 returns unspent funds rather than financing a weak launch.

**Trade-Off / Risk:** Weighting toward pilots strengthens the evidence base, but a thin Phase 1 risks piloting flawed rules; a large staged reserve disciplines spending yet can leave teams under-resourced during the work that must come first.

**Strategic Connections:**

**Synergy:** Enables Outcome Metric Battery Design by funding the supervised sessions and psychometric review the gate depends on. Also supports Adoption Wedge and Sequencing by reserving money for Phase 3 outreach once the evidence is in.

**Conflict:** Constrains Outcome Metric Battery Design and Core Lexicon Selection Basis, since a lean Phase 1 or a large held reserve limits corpus work and instrument validation. Staged release also slows Editorial Board Seat Allocation's capacity to commission early work.

**Justification:** *Critical*, Fixed $3.5M envelope governs every other lever's feasibility: metric validation, multi-accent audio, tooling, outreach and licensing administration all compete for it. Controls the evidence-versus-lean-rules trade-off and whether a no-go returns funds.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Irregular Morphology Retention Threshold
**Lever ID:** `440edab7-8f36-408e-81ab-03bd984e89ac`

**The Core Decision:** Defines the cutoff that decides which irregular verbs and plurals are regularized and which are retained, protecting recognizability while still removing real learning friction. The rule must be publishable, explainable and reproducible by third parties. Success metrics: share of the defined subset changed, misread rate on regularized forms, native-speaker acceptance, and learner retention after 30 days.

**Why It Matters:** The retention rule determines which irregular verbs and plurals are regularized and which are left alone. A frequency-based threshold keeps the most common forms, such as go/went, intact because learners already meet them constantly, and regularizes rarer ones where relearning cost is low. A looser threshold raises regularity but erodes the recognizability constraint and invites native-speaker resistance.

**Strategic Choices:**

1. Retain every irregular form that falls within a high-frequency band of the core lexicon and regularize only lower-frequency irregulars, publishing the cutoff and the resulting list openly.
2. Select forms for regularization using error data from ESL learner corpora, regularizing only those irregulars that learners most often get wrong and that have a low recognition penalty.
3. Accept both regularized and legacy irregular forms during the pilot, then retire whichever form pilot readers resolve more slowly or misread more often before locking v1.0.

**Trade-Off / Risk:** A frequency cutoff protects intelligibility, but the cutoff value itself is arbitrary until pilot data exists, and the plan's own example go/went would probably be retained rather than regularized.

**Strategic Connections:**

**Synergy:** Draws directly on Core Lexicon Selection Basis, whose frequency data defines the high-frequency band, and relies on Outcome Metric Battery Design to supply error and reading-speed data for tuning the cutoff before v1.0 lock.

**Conflict:** Trades off against Change-Control and Release Cadence: accepting dual forms during the pilot means later retiring one, creating churn. Aggressive regularization also strains Editorial Board Seat Allocation when native-speaker members resist.

**Justification:** *High*, Governs the recognizability-versus-regularity trade-off for verbs and plurals, drawing on lexicon frequency and metric data and straining board consensus. Strong interactions, but a bounded rule subset with a likely conservative cutoff limits systemic reach.

### Decision 7: Homograph Disambiguation Policy
**Lever ID:** `79d385f2-41b8-499f-9ae8-c2c2a22cf147`

**The Core Decision:** Specifies when a homograph or homophone pair needs a marker, a rewrite or nothing, and how that obligation is enforced in different document types. Scope is a short, published high-impact pair list such as lead/lead and read/read. Success metrics: misreading rate in safety-critical test passages, authoring burden per page, compliance consistency and list size kept manageable.

**Why It Matters:** This lever decides when a marker, a rewrite, or nothing at all is required for pairs such as lead/lead or read/read. Mandatory markers in safety-critical text reduce misreading risk but add visual clutter and authoring burden. Optional markers are easier to adopt but produce inconsistent practice that undermines the standard's value for safety documents.

**Strategic Choices:**

1. Require a disambiguation marker only in safety-critical and procedural documents for a short, published list of high-impact pairs, and leave it optional elsewhere.
2. Replace markers with controlled-language writing rules that require authors to rephrase sentences so context resolves each homograph, as in simplified technical writing standards.
3. Insert markers automatically through an authoring-tool plugin that flags ambiguous words and proposes the marked form, so authors approve rather than memorize the pair list.

**Trade-Off / Risk:** Tool-assisted marking lowers authoring burden, but it adds software development cost and a dependency on tooling that the $3.5M budget and small team may not sustain beyond the pilot.

**Strategic Connections:**

**Synergy:** Amplifies Controlled-Language Alignment Posture, since rewrite rules and marker rules can share one authoring checklist, and strengthens Adoption Wedge and Sequencing when the safety-critical track needs a concrete, measurable risk reduction.

**Conflict:** Constrains Phase Budget Weighting and Reserve if tool-assisted marking is chosen, since plugin development and maintenance compete with pilot and outreach funds. Mandatory markers also conflict with Grapheme-to-Phoneme Intervention Depth by adding visual clutter.

**Justification:** *High*, Delivers the concrete, measurable risk reduction that makes the safety-critical track credible. Links to controlled-language rules, lexicon, G2P clutter and budget if tooling is chosen; scope is a short pair list, so influence is narrower than the critical levers.

### Decision 8: Reference Accent Anchor
**Lever ID:** `d12e1659-c616-44f6-95e8-5eb35c1e2615`

**The Core Decision:** Chooses which pronunciation model underpins the grapheme-to-phoneme rules, audio recordings, dictionary guidance and pilot scoring. Beyond measurement convenience, it determines which learner populations see the biggest gains and whether adoption is perceived as regional. Success metrics: pronunciation consistency score reliability across raters, share of core-lexicon entries with usable audio by Month 12 (2027-10-13), and no significant accent-based drop in pilot comprehension or retention.

**Why It Matters:** The accent chosen for pronunciation guidance and audio models decides which vowel and consonant contrasts the grapheme-to-phoneme rules treat as fixed and which learners gain the most. A single anchor makes the pronunciation consistency score straightforward to measure, but it can alienate speakers of other major varieties and narrow adoption outside the anchor region.

**Strategic Choices:**

1. Anchor all pronunciation guidance, recordings and pilot scoring to one widely taught reference accent, and document how other accents map onto it.
2. Specify only the phoneme contrasts shared across major English varieties, leave other vowel realizations deliberately unspecified, and score pilot pronunciation consistency on the shared contrasts alone.
3. Record every core-lexicon entry in several regional accents, let publishers and learners select an accent profile, and keep the written form identical across all profiles.

**Trade-Off / Risk:** A single anchor accent keeps measurement clean but quietly privileges one speaker population, while a multi-accent design widens appeal at the cost of recording effort and a muddier pronunciation consistency metric for the go/no-go gate.

**Strategic Connections:**

**Synergy:** Amplifies Grapheme-to-Phoneme Intervention Depth, since a fixed anchor decides which contrasts the mapping must encode. It also strengthens Outcome Metric Battery Design by giving the pronunciation consistency score a clean, auditable reference.

**Conflict:** Trades off against Core Lexicon Selection Basis and Phase Budget Weighting and Reserve: multi-accent recording multiplies per-word audio effort across 5,000 entries, while a single anchor narrows appeal beyond one region.

**Justification:** *Medium*, Supplies the sound targets for G2P rules and a clean pronunciation score, but is largely a supporting input to the G2P depth decision. Main tension is recording effort versus regional appeal, which is an optimization within budget.

### Decision 9: Core Lexicon Selection Basis
**Lever ID:** `533fda13-50d1-49c7-98aa-d1c490efbbd9`

**The Core Decision:** Sets the selection principle for the 5,000-word core lexicon, which is the unit the dictionary, pronunciation guidance and pilot curriculum all operate on. The choice defines first beneficiaries (general ESL learners versus safety-critical readers) and how quickly pilot cohorts perceive value. Success metrics: coverage of running text in pilot glossaries, share of entries needing rule exceptions, and auditability of the list's provenance.

**Why It Matters:** The principle used to pick the 5,000 core words determines whom the dictionary serves first and how quickly pilot cohorts see practical value. A frequency-led list maximizes general coverage, while a domain-led list improves safety-critical usefulness but may omit everyday words learners need to read the surrounding text.

**Strategic Choices:**

1. Build the 5,000-word list from general-English frequency corpora, then add a small reserved block of technical and safety terms to cover pilot glossaries.
2. Seed the list with safety-critical and technical glossary terms first, then fill the remaining slots with the highest-frequency general words needed to read those documents.
3. Derive the list from incident reports, near-miss records and procedure manuals where ambiguous wording caused confusion, then fill gaps from ESL syllabus word lists.

**Trade-Off / Risk:** Frequency lists are defensible and easy to audit but generic; incident-driven selection is persuasive to safety stakeholders yet depends on access to sensitive records that organizations may be unwilling or slow to share.

**Strategic Connections:**

**Synergy:** Enables Homograph Disambiguation Policy and Adoption Wedge and Sequencing: an incident-informed or domain-seeded list surfaces the high-impact ambiguous pairs and gives the safety-critical wedge a concrete, credible vocabulary to start with.

**Conflict:** Conflicts with Controlled-Language Alignment Posture, which may impose an existing controlled vocabulary, and with Irregular Morphology Retention Threshold, since frequency-led lists contain the most entrenched irregular forms that resist regularization.

**Justification:** *High*, Defines the 5,000-word unit on which dictionary, pronunciation guidance and curriculum operate. Enables homograph identification and the safety-critical wedge, and conflicts with morphology retention and controlled-language vocabulary. Important, but largely downstream of the wedge choice.

### Decision 10: Change-Control and Release Cadence
**Lever ID:** `c310f188-a76c-47fb-ab70-544c06a4980f`

**The Core Decision:** Governs how the standard changes after v1.0: freeze periods, errata handling, scheduled revisions or a candidate-and-comment path. It is the mechanism that converts pilot findings into rule fixes without destabilizing printed materials already in circulation. Success metrics: time from change proposal to ruling, number of concurrent live versions, publisher confidence in stability, and the count of unofficial forks.

**Why It Matters:** The rules for amending the standard after v1.0 determine whether publishers and teachers can trust it as stable or see it as a moving target. Frequent revision answers pilot feedback quickly but multiplies version confusion, while a hard freeze protects materials yet locks in any rule errors the pilots expose.

**Strategic Choices:**

1. Freeze v1.0 for a fixed period after publication, accepting only errata, and collect change proposals for a single consolidated v2.0 review.
2. Issue scheduled minor revisions at fixed intervals, each with a published deprecation notice and a conversion table from the previous release.
3. Release v1.0 as a candidate standard with an open public-comment window and a sandbox for registered experimental forks before ratifying the final rule set.

**Trade-Off / Risk:** Stability and responsiveness pull in opposite directions; the board must choose which failure it can better absorb, and an unclear cadence invites the fragmentation the risk register already flags.

**Strategic Connections:**

**Synergy:** Reinforces Licensing and Name Stewardship by giving certification or share-alike terms a defined version baseline to test conformance against. It also supports Editorial Board Seat Allocation with a predictable decision calendar.

**Conflict:** Constrains Outcome Metric Battery Design and Ordinal Marker Architecture: a hard freeze locks in any rule errors the Phase 2 pilots expose, while rapid revisions undermine comparability of pilot data and printed curricula.

**Justification:** *Medium*, Matters for post-v1.0 stability and fragmentation control, reinforcing licensing and board decisions. Operates mostly after the Phase 2 gate, so it is less central to the near-term strategic outcome than rule and evidence choices.

### Decision 11: Licensing and Name Stewardship
**Lever ID:** `e6d5785e-6fe6-4aaa-bc8d-121c6c4eaa77`

**The Core Decision:** Determines the legal and brand terms under which the standard, dictionary and the 'Clear English' name circulate. It balances low-friction uptake by ESL publishers and standards bodies against protection from diluted or non-conforming material using the name. Success metrics: number of third-party adopters licensed, share of labelled materials passing a conformance check, and absence of confusing look-alike variants by Month 36 (2029-10-13).

**Why It Matters:** How the standard, dictionary and the name 'Clear English' are licensed shapes both third-party uptake and the project's ability to prevent diluted or divergent versions. Permissive terms lower adoption friction, but without some name control any publisher can label non-conforming material as Clear English.

**Strategic Choices:**

1. Release all deliverables under a fully permissive open license with no restrictions on the name, relying on the editorial board's reputation to signal the authoritative version.
2. License the text and dictionary openly, but reserve the name as a certification mark awarded to materials that pass a published conformance checklist.
3. Use a share-alike license that requires derivative works to declare which rules they diverge from and to adopt a distinct name once they diverge.

**Trade-Off / Risk:** Open terms and quality control conflict: certification marks protect integrity but add an administrative burden and a gatekeeper image that may deter the ESL publishers and standards bodies whose adoption the project needs.

**Strategic Connections:**

**Synergy:** Amplifies Adoption Wedge and Sequencing by letting early adopters reuse materials with clear terms, and works with Change-Control and Release Cadence, where versioned conformance checklists make name stewardship enforceable.

**Conflict:** Tensions with Controlled-Language Alignment Posture and Editorial Board Seat Allocation: certification gatekeeping can deter standards bodies and publishers, and it demands board capacity and administrative budget that Phase Budget Weighting and Reserve must absorb.

**Justification:** *High*, Controls the open-uptake versus anti-fragmentation trade-off central to third-party adoption by publishers and standards bodies. Connects to wedge, change-control and board capacity, but its impact materializes mainly in Phase 3 after the evidence exists.

### Decision 12: Controlled-Language Alignment Posture
**Lever ID:** `8fb6c1ea-42bc-4ded-8e9d-ae685aa0f1f3`

**The Core Decision:** Defines how Clear English relates to existing controlled languages such as ASD-STE100 Simplified Technical English and plain-language guidance, which technical writers already follow. The choice sets the effort for safety-critical adopters, whether one or two rule sets must be run, and how much design freedom the project retains. Success metrics: share of pilot technical documents passing both rule sets, and writer conversion effort.

**Why It Matters:** This lever sets how Clear English relates to existing controlled languages such as Simplified Technical English and plain-language guidance already used in safety-critical writing. Tight alignment lowers the barrier for technical writers who already follow a controlled vocabulary, but it ties the standard to another body's conventions. A distant posture preserves design freedom but forces safety-critical adopters to run two rule sets.

**Strategic Choices:**

1. Build Clear English as a compatible overlay that reuses the vocabulary and sentence-writing constraints of an existing controlled language, adding only the orthographic and ordinal rules on top.
2. Design Clear English as an independent standard with its own rules, and publish a one-way mapping table so technical writers can translate from existing controlled-language documents.
3. Co-develop the safety-critical glossary jointly with a controlled-language maintainer, so one shared term list is validated under both rule sets and each side can cite the other.

**Trade-Off / Risk:** Alignment speeds acceptance among technical writers, yet it imports another standard's limits and politics, and the claimed compatibility is hard to verify until pilot documents are actually run through both rule sets.

**Strategic Connections:**

**Synergy:** Strengthens Adoption Wedge and Sequencing by giving technical writers a familiar on-ramp, and supports Core Lexicon Selection Basis when a shared safety-critical term list is validated under both rule sets.

**Conflict:** Constrains Homograph Disambiguation Policy and Grapheme-to-Phoneme Intervention Depth, since an overlay inherits another body's vocabulary and conventions, limiting orthographic freedom and requiring coordination with an external maintainer's schedule.

**Justification:** *Medium*, Offers a familiar on-ramp for technical writers and shared glossary validation, but mainly serves the safety-critical wedge and overlaps with homograph and lexicon choices. Useful positioning optimization, with external-maintainer dependence limiting leverage.

### Decision 13: Editorial Board Seat Allocation
**Lever ID:** `cc0df26c-1351-481b-8450-753f7da0225e`

**The Core Decision:** Sets who holds voting and veto authority over rule decisions, and how linguistic review, practitioners and learners are represented. Beyond composition, it fixes decision procedures, term lengths and conflict-of-interest rules that determine perceived legitimacy among educators, publishers and standards bodies. Success shows in rule-decision turnaround, retained seats, and endorsement by named partner institutions rather than linguistic elegance.

**Why It Matters:** This lever determines who sits on the editorial board and linguistic review panel and who holds decision authority over rule changes. A board weighted toward linguists favors internal consistency, while one weighted toward ESL teachers, technical writers and standards-body staff favors usability and adoption. The balance also shapes whether educators treat the standard as their own or as something imposed from outside.

**Strategic Choices:**

1. Seat a linguist-majority board with advisory seats for practitioners, giving rule decisions a rigorous basis while risking the perception that the standard is academic and detached from classrooms.
2. Seat a practitioner-majority board of ESL instructors, technical writers and safety trainers, with linguists holding a formal review-and-veto role limited to rule-conflict and ambiguity findings.
3. Rotate board seats on fixed terms and add a standing learner panel whose pilot feedback must be formally answered in the published rationale for each rule.

**Trade-Off / Risk:** Practitioner weighting aligns with the adoption priority, but without strong linguistic review, rule ambiguity and drift can creep in; rotating seats add legitimacy at the cost of institutional memory and decision speed.

**Strategic Connections:**

**Synergy:** Amplifies Adoption Wedge and Sequencing and Controlled-Language Alignment Posture, since practitioner and standards-body seats open partner channels. Also strengthens Change-Control and Release Cadence by giving revisions a legitimate, accountable decision body.

**Conflict:** Tension with Change-Control and Release Cadence, because rotating or large boards slow decisions and dilute institutional memory. Also trades off against Irregular Morphology Retention Threshold and Homograph Disambiguation Policy, where linguist-weighted consistency pulls against practitioner usability preferences.

**Justification:** *High*, Fixes who holds rule authority and whether educators and standards bodies see the standard as legitimate. Opens partner channels for wedge and controlled-language alignment and sets the usability-versus-consistency balance in morphology and homograph decisions.
