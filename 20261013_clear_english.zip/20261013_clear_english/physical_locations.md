This plan **does not** imply any physical location.

## Requirements for physical locations

- Access to adult ESL learners (community colleges, adult education centers, language schools) for in-person pilot cohorts
- Access to native speakers in technical or safety-critical training settings
- Proximity to universities with applied linguistics and psychometric expertise
- Office or co-working space for editorial board, linguists and curriculum designers
- Quiet room or studio capacity for supervised audio capture of pronunciation
- Good transport links for outreach to publishers and standards organizations
- Moderate cost of living and labor to fit a $3.5M total budget (user constraint)
- English-speaking environment so that reference accent and native-reader testing are practical

## Location 1
United Kingdom

Cambridge / Oxford area, England

University-adjacent offices near Cambridge or Oxford; partner language schools and ESL publishers (e.g., Cambridge, Oxford)

**Rationale**: Dense cluster of ESL publishers, assessment bodies, applied linguists and psychometric expertise. Strong access to adult ESL schools and standards-oriented organizations. Supports the ESL-first wedge and credible pilot measurement. Office costs are higher than in smaller cities.

## Location 2
United States

Washington, D.C. metro area (including Arlington and Northern Virginia)

Co-working or university-affiliated office space near Georgetown University / Center for Applied Linguistics-type organizations; partner adult ESL programs in the metro area

**Rationale**: Large, diverse adult ESL population and many adult education programs. Proximity to standards bodies, federal safety and technical-writing communities and applied linguistics departments. Good air and rail links for outreach. Cost is higher but offset by access to partners and pilot participants.

## Location 3
United States

Austin, Texas or similar mid-cost metro

Co-working space near University of Texas at Austin; adult ESL centers, community colleges and industrial or energy-sector training sites in the region

**Rationale**: Lower cost than coastal hubs, with a large adult ESL population, a university linguistics base and nearby industrial and energy safety-training settings for the technical-glossary cohort. Fits the budget limit while serving both pilot cohorts.

## Location Summary
The plan names no site, but it is physical: in-person pilot cohorts, print curriculum, board meetings, audio capture and outreach all need real sites. Three options are suggested. Cambridge/Oxford offers publisher and assessment expertise. Washington, D.C. offers diverse ESL cohorts plus standards and safety communities. Austin offers lower cost with ESL and industrial training access. Final choice should weigh partner commitments and budget fit.