**Primary domain:** Language Standardization

**Secondary domains:** Applied Linguistics, ESL Pedagogy, Orthography Design

**Rationale:** Language Standardization is the only outcome candidate that owns the project's overall success criterion: a governed, versioned standard variant of English. Lexicography is a component deliverable, Orthography Design and Applied Linguistics are methods, and ESL Pedagogy and Standards Development are adoption or process support.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Language Standardization | 5 | 5 | outcome | Core deliverable is a formal standardized English variant with rules, lexicon, and governance. |
| Orthography Design | 5 | 5 | method | Grapheme-to-phoneme mapping, ordinal notation, and minimal diacritics are the core rule-design mechanism. |
| Applied Linguistics | 5 | 4 | method | Phonology, morphology, and orthography design underpin grapheme-to-phoneme mapping and regularization rules. |
| Controlled Language Authoring | 4 | 5 | market | Safety-critical and technical documentation, comparable to Simplified Technical English, is a target adoption market. |
| ESL Pedagogy | 4 | 4 | market | Adult ESL learners are pilot cohort and primary adoption audience for curriculum. |
| Lexicography | 4 | 4 | outcome | The 5,000-word reference dictionary with pronunciation guidance and mappings is a core deliverable. |
| Standards Development | 4 | 4 | stakeholder | Editorial board governance, versioned standard, licensing, and standards-organization outreach require formal standards practice. |
| Instructional Design | 4 | 4 | method | Print and digital pilot curriculum with assessments must be designed for adult learners. |
| Educational Psychometrics | 4 | 4 | method | Go/no-go depends on valid comprehension, error-rate, and retention measurement from pilots. |