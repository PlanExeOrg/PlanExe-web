A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The $3.5M envelope, with a $175K pre-gate draw cap, absorbs foreseeable Phase 1 and Phase 2 cost shocks (audio, psychometrics, retraining) without cutting pilot scope. | By Month 2 (2026-12-13), obtain firm quotes from 2-3 studios and the psychometrician, build a bottom-up Phase 1 and Phase 2 cost model, and run stacked fallback scenarios (4-week extension plus audio overrun) against the cap. | Stacked plausible scenarios exceed the $175K pre-gate cap, or firm quotes put audio above $20 per entry and psychometrics above $200K (estimate). |
| A2 | Prefix ordinals, the spoken reading and the single-accent overlay can be fixed by Month 10 (2027-08-13) and scored by raters at kappa >=0.70, so the gate hardware (instruments, raters, audio) works as designed. | By Month 3 (2027-01-13), record a 50-100 word proof-of-concept sample with candidate marker readings and have 3-4 pre-screened raters score it blind; compute pairwise kappa. | Pairwise kappa below 0.70 after one retraining round, or fewer than 3 raters reach 0.75 on the screening sample. |
| A3 | Adult ESL learners, educators and publishers will accept a supplementary Clear English module and enrol and complete the pilot at the planned rate (>=115 per arm, <=30% dropout). | By Month 2 (2026-12-13), run the 20-30 learner baseline study at 2-3 sites and interview 5-8 publishers and TESOL/IATEFL contacts about willingness to enrol, co-produce and cite the standard. | Observed dropout above 35% in the baseline study, fewer than 3 ESL programs and 2 technical organizations willing to sign by Month 3 (2027-01-13), or fewer than 3 publishers giving written interest. |
| A4 | A steward organization with $150K-$250K per year (estimate) of committed funding will exist and sign before the Month 30 (2029-04-13) v1.0 release, so the standard is maintained after Month 36 (2029-10-13). | By Month 6 (2027-04-13), send a 2-page stewardship brief to 5-6 candidate organizations (non-profits, university consortia, standards bodies) and request a written response on interest, budget capacity and conditions. | Fewer than 2 candidates give written interest, or none can identify a funding source for $150K-$250K per year (estimate) by Month 12 (2027-10-13). |
| A5 | Safety-critical glossary and labeling pilots can run under legal disclaimers and human review without triggering regulatory approval, insurer refusal or liability exposure that blocks the technical cohort. | By Month 4 (2027-02-13), obtain written advice from retained counsel and at least 2 insurance brokers on pilot coverage, and informal written input from one US and one UK safety or education regulator on the glossary-and-labeling scope. | Counsel or a regulator indicates formal approval is required, or insurers decline pilot coverage or quote premiums above $50K per year (estimate). |
| A6 | A practitioner-leaning board of 7-9 members can resolve contested rules (ordinal reading, morphology cutoff, homograph list) by vote or arbiter by Month 10 (2027-08-13) without eroding legitimacy or forcing mid-pilot changes. | By Month 3 (2027-01-13), run a simulated contested-rule vote with a draft charter and 2-3 external linguists scoring rule clarity, and confirm arbiter availability and conflict-of-interest declarations in writing. | The simulated dispute takes longer than 4 weeks to resolve, average clarity score is below 3.5 of 5 (proposed threshold), or no qualified arbiter agrees by Month 5 (2027-03-13). |
| A7 | The ordinal prefix marker and legacy 1st/2nd/3rd forms can coexist in real documents, and a mechanical converter handles dates, lists and procedures without creating new ambiguity or rework for adopters. | By Month 4 (2027-02-13), run a conversion test on 200-300 real documents (dates, numbered steps, tables) from ESL and technical sources, and have 2 technical writers review converted output for ambiguity. | More than 5% of converted instances (proposed threshold) are ambiguous or misread by reviewers, or reviewers need manual correction on more than 10% of documents (proposed threshold). |
| A8 | ESL publishers and technical-writing organizations see enough practical value in a supplementary, optional Clear English module to license it and use it in courseware, so the >=3 licensed adopter target is reachable. | By Month 3 (2027-01-13), hold structured interviews with 5-8 ESL publishers and 3-4 technical-writing organizations and ask each to state conditions for licensing, expected cost and evidence required. | Fewer than 3 publishers state they would license at a GO outcome, or most name a requirement (mandate, full curriculum, revenue guarantee) outside the plan's no-mandate scope. |
| A9 | Key specialist roles (psychometrician, cohort manager, 2-3 linguists, audio lead) can be hired on time and retained through Month 24 (2028-10-13) within the budgeted salaries. | By Month 1 (2026-11-13), post the psychometrician and cohort manager roles, obtain salary benchmarks and screen at least 5 qualified candidates per role, and confirm availability dates. | Fewer than 3 qualified candidates per role, offers declined at budgeted pay, or the psychometrician start date later than Month 2 (2026-12-13). |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Reserve That Vanished Before the Gate | Process/Financial | A1 | Budget Owner (Program Director) | CRITICAL (16/25) |
| FM2 | The Marker Nobody Could Say | Technical/Logistical | A2 | Lexicon and Audio Lead | CRITICAL (15/25) |
| FM3 | The Standard Nobody Wanted to Join | Market/Human | A3 | Regulatory and Stakeholder Affairs Manager | CRITICAL (20/25) |
| FM4 | The Orphaned Standard | Process/Financial | A4 | Regulatory and Stakeholder Affairs Manager | CRITICAL (16/25) |
| FM5 | The Label That Cried Wolf | Technical/Logistical | A5 | Legal and Liability Counsel Lead (Project Lead oversight) | CRITICAL (15/25) |
| FM6 | The Board That Split the Standard | Market/Human | A6 | Editorial Board Chair | HIGH (12/25) |
| FM7 | The Empty Chair at the Gate | Process/Financial | A9 | Project Lead | HIGH (12/25) |
| FM8 | The Prefix That Broke the Paperwork | Technical/Logistical | A7 | Lead Linguist (Ordinal Workstream) | HIGH (12/25) |
| FM9 | The Free Standard No One Licensed | Market/Human | A8 | Regulatory and Stakeholder Affairs Manager | CRITICAL (16/25) |


### Failure Modes

#### FM1 - The Reserve That Vanished Before the Gate

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Budget Owner (Program Director)
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Audio per-entry cost exceeds $20 and kappa retraining forces a 4-week Phase 1 extension (about $85K, estimate).
- Psychometric redesign and recruitment incentives draw the remainder of the $175K pre-gate cap.
- A 3-month Phase 2 extension ($300K, estimate) then leaves a $35K shortfall.
- Pilot scope is cut and the Month 24 (2028-10-13) gate is under-evidenced.

##### Early Warning Signs
- Monthly burn exceeds baseline by more than 10% for 2 consecutive months
- Studio quotes above $20 per entry
- Psychometrician quote above $200K

##### Tripwires
- Cumulative Phase 1 spend >=10% over baseline at any month-end
- Pre-gate reserve draws >=$90K before Month 12 (2027-10-13)
- Audio cost per entry >$20

##### Response Playbook
- Contain: Freeze discretionary spend and non-gate hires; require board approval for any draw above $25K.
- Assess: Rebuild the 6-month forecast with stacked fallback scenarios within 5 business days and quantify remaining headroom under the $175K cap.
- Respond: Switch audio to synthetic baseline plus human verification of the highest-friction subset, and cut Phase 2 non-gate extras before reducing arms or sessions.


**STOP RULE:** If forecast cumulative pre-gate draws exceed $175K before Month 12 (2027-10-13) with no funded plan to keep >=80 completers per arm, halt Phase 2 launch and return to the board for descoping or cancellation.

---

#### FM2 - The Marker Nobody Could Say

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Lexicon and Audio Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Ordinal marker spoken form and accent anchor slip past Month 8 (2027-06-13), so rater training starts late.
- Raters cannot agree on how learners should produce the marker; kappa stays below 0.70 after retraining.
- Audio production backlog and storage or consent issues shrink the scorable sample.
- Pronunciation consistency becomes uninterpretable, leaving the gate disputable or forcing a Phase 1 extension.

##### Early Warning Signs
- Marker spoken form unresolved at Month 8 (2027-06-13)
- Screening kappa under 0.75 for most candidate raters
- Studio delivery lags schedule by more than 2 weeks

##### Tripwires
- Pairwise kappa <0.70 on the 100-200 word calibration sample
- Ordinal spoken form not locked by Month 10 (2027-08-13)
- Fewer than 3 raters reach kappa >=0.75 at pre-screening by Month 4 (2027-02-13)

##### Response Playbook
- Contain: Halt full 5,000-word production and freeze the marker reading and accent anchor in writing.
- Assess: Break down kappa by rater pair and phoneme type, and test whether the rubric or the anchor is the cause within 2 weeks.
- Respond: Retrain on the revised rubric and retest; if still below 0.70, adopt synthetic baseline plus human verification or take the 4-week extension to the board.


**STOP RULE:** If kappa remains below 0.70 after the retest and a 4-week extension, pronunciation consistency is dropped as a primary gate metric by board decision or the project pivots; no Phase 2 launch on unreliable scoring.

---

#### FM3 - The Standard Nobody Wanted to Join

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Regulatory and Stakeholder Affairs Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Educators and TESOL/IATEFL voices frame Clear English as a non-standard variant.
- Partners sign non-binding or soft commitments, then reduce enrolment in the 9-month lag before Phase 2.
- Voluntary adult dropout runs above the planned 30%, leaving fewer than 80 completers per arm.
- Publishers withhold interest, so Phase 3 reaches fewer than 3 adopters.

##### Early Warning Signs
- Partners delay signature past Month 3 (2027-01-13)
- Baseline dropout above 35%
- Public criticism from a teacher body

##### Tripwires
- Fewer than 3 ESL programs and 2 technical organizations signed by Month 3 (2027-01-13)
- Enrolment <70% of 460 by Month 10 (2027-08-13)
- Cumulative dropout >25% by Month 15 (2028-01-13)

##### Response Playbook
- Contain: Activate standby recruitment sites and contingency incentives, and pause new public claims until partner positions are confirmed.
- Assess: Interview each at-risk partner and a sample of dropouts within 2 weeks to separate capacity, motivation and rule-burden causes.
- Respond: Reframe messaging as optional supplementary, add co-design seats for teacher bodies, and rebalance arms or extend enrolment with a board-approved power check.


**STOP RULE:** If signed enrolment guarantees cover fewer than 320 expected completers by Month 6 (2027-04-13) despite standby sites, cancel Phase 2 or pivot the wedge before further spend.

---

#### FM4 - The Orphaned Standard

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Regulatory and Stakeholder Affairs Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Steward search starts at Month 12 (2027-10-13) and finds no funded home for $150K-$250K per year (estimate).
- Project revenue is $0, so no internal fallback exists.
- v1.0 release by Month 30 (2029-04-13) is conditional on a steward commitment, so release slips or ships unmaintained.
- Errata and change requests go unanswered; adopters withdraw and the >=3 adopter target is missed.

##### Early Warning Signs
- No written steward interest by Month 12 (2027-10-13)
- Candidates ask for funding the project cannot provide
- Phase 2 extension compresses negotiation time

##### Tripwires
- Fewer than 2 written letters of interest by Month 24 (2028-10-13)
- No signed steward MOU by Month 30 (2029-04-13)
- Stewardship funding commitments cover <50% of $150K per year (estimate) at Month 33 (2029-07-13)

##### Response Playbook
- Contain: Suspend public v1.0 release scheduling and adopter announcements until a steward position is confirmed.
- Assess: Rank all candidates by funding capacity, mission fit and conditions within 3 weeks, and cost a reduced maintenance scope.
- Respond: Negotiate a scaled stewardship model (annual review only) or a consortium of funders, and release v1.0 only with a signed commitment.


**STOP RULE:** If no signed steward commitment exists by Month 33 (2029-07-13), v1.0 public release is cancelled and the project closes with archived materials.

---

#### FM5 - The Label That Cried Wolf

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Legal and Liability Counsel Lead (Project Lead oversight)
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Counsel or regulators require formal review of safety-related pilot materials, taking 4-8 months (estimate).
- Insurers refuse pilot cover or price it above $50K per year (estimate).
- A pilot partner uses a glossary or label in a live setting despite disclaimers, and a marker or homograph is misread.
- The technical cohort is suspended and the evidence base narrows to the ESL cohort.

##### Early Warning Signs
- Counsel flags approval requirements
- Broker quotes decline or exceed budget
- Partner requests live-procedure use

##### Tripwires
- Liability strategy not complete by Month 4 (2027-02-13)
- Insurance premium >$50K per year (estimate)
- Any reported near-miss or misreading incident >=1 in a pilot

##### Response Playbook
- Contain: Suspend all technical-cohort materials at the affected site and notify counsel and the insurer within 24 hours.
- Assess: Review the incident log and the partner agreement, and establish within 2 weeks whether scope limits were breached.
- Respond: Restrict the safety track to non-life-critical glossaries, re-paper partner agreements, and move deeper safety work after the Month 24 (2028-10-13) gate.


**STOP RULE:** If insurance cannot be secured and counsel advises uninsured exposure, safety-critical pilots are cancelled and the project proceeds ESL-only.

---

#### FM6 - The Board That Split the Standard

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Editorial Board Chair
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Linguists and practitioners clash over the ordinal reading, morphology cutoff and homograph list.
- Arbiter rulings are contested publicly; the comment window surfaces teacher and publisher objections.
- Rules slip past Month 12 (2027-10-13) or change after pre-registration, invalidating assessments.
- The standard looks divided, and TESOL/IATEFL voices withdraw support.

##### Early Warning Signs
- Votes split 4-3 or closer on multiple rules
- Board member resignations
- Public comments criticize rule coherence

##### Tripwires
- Any rule dispute unresolved >4 weeks
- Arbiter not agreed by Month 5 (2027-03-13)
- Rules not locked by Month 12 (2027-10-13)

##### Response Playbook
- Contain: Freeze the contested rule in its current published form and stop all pilot-material edits touching it.
- Assess: Document majority and minority positions and run an independent clarity review within 2 weeks.
- Respond: Refer to the arbiter, publish the ruling with rationale, and delay Phase 2 start only with board approval and a power check.


**STOP RULE:** If core rules are not locked by Month 13 (2027-11-13), Phase 2 does not launch and the board decides on extension or cancellation.

---

#### FM7 - The Empty Chair at the Gate

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Project Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- The psychometrician and cohort manager are scarce roles; searches run past Month 2 (2026-12-13) and Month 6 (2027-04-13).
- Power analysis, pre-analysis plan and recruitment design start late and cascade into the Month 11 (2027-09-13) pre-registration.
- Premium salaries and contractor cover draw on the $175K pre-gate cap.
- Mid-pilot turnover leaves scoring and retention unowned.

##### Early Warning Signs
- Role open for more than 30 days with fewer than 3 qualified candidates
- Offers declined on pay
- Interim contractors used beyond 8 weeks

##### Tripwires
- Psychometrician not signed by Month 2 (2026-12-13)
- Cohort manager not hired by Month 6 (2027-04-13)
- Staffing costs >=10% over baseline for 2 consecutive months

##### Response Playbook
- Contain: Engage an interim assessment firm or contractor on a fixed-deliverable contract to start the power analysis immediately.
- Assess: Re-baseline the critical path and staffing cost within 10 business days and quantify slip against the Month 11 (2027-09-13) pre-registration.
- Respond: Raise offers within a board-approved limit, or outsource instrument design to a measurement firm, and protect the pre-registration date before other scope.


**STOP RULE:** If no qualified psychometrician is contracted by Month 4 (2027-02-13), Phase 2 start is deferred by board vote until pre-registration is credible, or the project is cancelled.

---

#### FM8 - The Prefix That Broke the Paperwork

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Lead Linguist (Ordinal Workstream)
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Prefix ordinals collide with existing codes, table headers, version numbers or software parsers.
- Mixed legacy and prefix forms in one document are misread or flagged as errors.
- The mechanical converter fails on edge cases and needs manual correction.
- Pilot materials and the ordinal error metric become confounded by format artefacts rather than learning.

##### Early Warning Signs
- Converter errors found in pilot-material test conversions
- Reviewers report ambiguity in dates or lists
- Edge-case log growing weekly

##### Tripwires
- More than 5% ambiguous conversions in the Month 4 (2027-02-13) test (proposed threshold)
- Marker symbol and spoken form not fixed by Month 10 (2027-08-13)
- More than 10 unresolved edge-case classes at Month 8 (2027-06-13)

##### Response Playbook
- Contain: Freeze the marker symbol and block further pilot-material production using ordinals until edge cases are classified.
- Assess: Test the 3 worst edge-case classes on 50 real documents each and measure reader error within 2 weeks.
- Respond: Narrow ordinal scope to unambiguous contexts with a published exception list, and re-run the converter validation before rules lock.


**STOP RULE:** If ambiguity stays above 5% (proposed threshold) after one redesign cycle by Month 10 (2027-08-13), the ordinal rule is withdrawn from the v1.0 gate and the board decides a pivot.

---

#### FM9 - The Free Standard No One Licensed

- **Archetype**: Market/Human
- **Root Cause**: Assumption A8
- **Owner**: Regulatory and Stakeholder Affairs Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Publishers read the supplementary, no-mandate positioning as optional and low priority.
- Letters of interest stay non-binding; publishers ask for revenue guarantees or full curricula.
- A positive gate does not translate into signed licences; fewer than 3 adopters by Month 36 (2029-10-13).
- Phase 3 funds are spent on outreach with little uptake.

##### Early Warning Signs
- Publisher interviews lukewarm or conditional
- Letters of interest not renewed after Month 12 (2027-10-13)
- Competing plain-language initiatives announced by larger bodies

##### Tripwires
- Fewer than 3 publisher letters of interest by Month 3 (2027-01-13)
- Fewer than 2 publishers confirm interest at the Month 18 (2028-04-13) check-in
- Fewer than 1 signed licence by Month 30 (2029-04-13)

##### Response Playbook
- Contain: Pause broad Phase 3 outreach spend and keep only conversations with named, interested publishers.
- Assess: Interview every lapsed publisher within 3 weeks to identify the missing value, cost or evidence they require.
- Respond: Reposition around a measured benefit (ordinal accuracy, safety glossary) and offer early-adopter terms, or refocus Phase 3 on 1-2 anchor adopters.


**STOP RULE:** If no publisher or standards body has signed a licence commitment by Month 30 (2029-04-13), Phase 3 outreach spending stops and unspent funds are returned.
