_Consistency: first pass found 3 high / 3 medium / 1 low contradictions. Repair: round 1: 42 edits → 1 high / 4 medium; round 2: 42 edits → 0 high / 3 medium. Published: round 2 (fewest high-severity issues). Shown below: the final check of the repaired documents (0 high / 3 medium / 3 low)._

## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Are signed pilot partner commitments in hand (at least 3 adult ESL programs and 2 technical/safety-training organizations, with enrolment guarantees) and at least 3 publisher letters of interest, with baseline dropout evidence no worse than 35%? | Signed commitments from at least 3 ESL programs and 2 technical organizations by Month 3, plus at least 3 non-binding publisher letters; baseline-study dropout not above 35%; guarantees covering at least 320 expected completers by Month 6. | Signed MOUs and enrolment guarantees at Month 3; publisher letters at Month 3; baseline dropout analysis at Month 3 (run in a form that ethics review permits); guarantee audit at Month 6. | Delay Phase 2 launch and re-recruit from standby sites; if guarantees cover fewer than 320 expected completers by Month 6, cancel Phase 2 or pivot the wedge before further spend (premortem FM3). |
| 2 | Can safety-critical glossary and labeling pilots proceed under counsel and insurer advice without formal regulatory approval and without disproportionate premiums? | Written counsel advice and informal regulator input that no formal approval is required for glossary/labeling scope; insurance cover available at no more than $50K per year (estimate); legal/liability spend within $150K-$200K (estimate). | Counsel retained by Month 2; liability strategy, broker quotes and regulator written input at Month 4 (other documents say Month 6 or 8; align to Month 4). | Cancel or defer the technical/safety cohort and proceed ESL-only. This changes the 4-arm, 320-completer design, so the gate population and validity conditions must be re-registered before Phase 2. Do not run live-procedure pilots. |
| 3 | Can raters score pronunciation consistency reliably on the locked ordinal reading and single accent anchor, and does the ordinal converter stay unambiguous? | Inter-rater kappa at least 0.70 floor (target 0.75) at the Month 10 dry run, with at least 3 raters at 0.75 on pre-screening by Month 4; no more than 5% ambiguous conversions (proposed threshold) in the Month 4 conversion test; marker symbol and spoken form fixed in writing. | Pre-screening Month 4; micro-calibration on 100-200 words Month 6; dry run and kappa check Month 10; converter test on 200-300 real documents Month 4. | Retrain and retest; then 4-week Phase 1 extension (about $85K, estimate) or synthetic baseline plus human verification. If kappa is still below 0.70, the board drops pronunciation consistency as a primary metric or pivots. If ambiguity exceeds 5% after one redesign, withdraw the ordinal rule from the gate. No Phase 2 launch on unreliable scoring. |
| 4 | Is Phase 1 exit met: rules locked, four metrics and thresholds pre-registered with a power analysis confirming 80 completers per arm, 5,000 entries with usable audio, and enrolment forecast to deliver at least 320 completers within the $175K pre-gate draw cap? | Pre-registration on OSF by Month 11 with psychometrician sign-off; rules locked Month 12; lexicon coverage at least 85%; ethics approval in hand; forecast completers at least 320 (enrolment at least 460 at no more than 30% dropout) at the enrolment audit; cumulative pre-gate draws not above $175K. | Power analysis Month 5; validity study Months 10-11; pre-registration Month 11; Phase 1 exit review Month 12; enrolment audit Month 12-13 (one agreed month); earned-value report. | Delay Phase 2 start only by board vote with a power check; activate contingency incentives ($20K-$30K, estimate) or resize enrolment to 123-146 per arm if baseline dropout is 35-45%. If forecast draws exceed $175K with no funded plan for 80 completers per arm, halt Phase 2 and descope or cancel (premortem FM1 stop rule). |
| 5 | Do the Month 24 pilot results show GO: all four pre-registered metrics pass on valid data? | Ordinal error down at least 25%; comprehension no more than 10% slower than control; pronunciation consistency at least 15% above control and statistically significant; 30-day retention at least 70% of post-test and not below control; validity: at least 80 completers per arm, follow-up at least 70%, kappa at least 0.70. | Data lock including 30-day follow-up Month 22; analysis and gate dossier Months 22-24; board decision Month 24. | Valid data with any metric failing is NO-GO: close the project and return up to $1.2M (less draws and wind-down). Invalid or inconclusive data leads to a board-decided 3-6 month extension (about $300K-$600K, estimate), whose funding source must be decided in advance. |
| 6 | Is a written steward commitment signed for post-v1.0 maintenance, as the precondition for the v1.0 release? | Signed MOU with a steward showing a funding source for $150K-$250K per year (estimate); at least 2 written letters of interest by Month 24; funding commitments at least 50% of $150K per year at Month 30. | Candidate brief at Month 12; letters of interest by Month 24; MOU negotiation Months 27-30; signed MOU at Month 30 (Month 33 is only the latest point at which a delayed release can still be triggered). | Do not release v1.0; go to the board for a scaled stewardship model or a funder consortium. If nothing is signed by Month 33, cancel the public release and close with archived materials, unless a funded deferral beyond Month 36 is explicitly decided. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: repaired_review_plan.md (Reviews 1, 2, 4, 5, 10)
    canonical: reserve_draw_rule = Before Month 24: draws capped at $175K for gate-protection only; remaining balance of at least $175K released only after the Month 24 GO
    observed:  Phase 2 extension 'consuming the entire $350K reserve'; Phase 2.5 'funded from Phase 3 reserve'
HIGH CF-002  document: repaired_pitch.md
    canonical: stewardship_funding_gap = Revenue $0; stewardship $150K-$250K per year (estimate) unfunded, $1.5M-$2.5M over 10 years
    observed:  Steward receives $0.35M reserve release plus pro-rata Phase 3 funding
HIGH CF-003  document: repaired_review_plan.md (Reviews 4, 10) and repaired_self_audit.md; repaired_pitch.md
    canonical: pilot_design = 2 cohorts x 2 conditions = 4 arms; 320 completers; liability strategy by Month 4
    observed:  Defer safety cohort to Phase 2.5 after >6 months (or >4 months); regulator written advice at Month 4, 6 or 8
HIGH CF-004  document: repaired_review_plan.md (Reviews 5, 6, 9, 14) and repaired_self_audit.md (item 20)
    canonical: v1_release = v1.0 public release by Month 30, conditional on a written steward commitment; adoption Months 30-36
    observed:  Defer v1.0 to Month 36 or later
MEDIUM CF-005  document: repaired_self_audit.md (item 5); repaired_review_plan.md (Reviews 2, 4)
    canonical: phase2_go_no_go_rule = Invalid/inconclusive data = board-decided extension; valid data with any metric failing = NO-GO
    observed:  'no-go on inconclusive data, stranding $1.2M'; 'Type II error to 50%' at ~60% power
MEDIUM CF-006  document: premortem FM2/FM8; Review 8, 9; canonical_facts ordinal_rule
    canonical: ordinal_rule = Marker symbol and spoken form fixed by Month 10
    observed:  Spoken form 'not finalized until Month 10' while kappa check is also Month 10
MEDIUM CF-007  document: repaired_review_plan.md (Reviews 6, 8, 12); premortem FM3
    canonical: pilot_enrolment_and_dropout = >=115 per arm = 460 total; dropout <=30%; enrolment complete Month 13
    observed:  Audit Month 13 (FM3) / Month 10 dropout check / 70 per arm bound / '30% monthly dropout'
MEDIUM CF-008  document: repaired_review_plan.md (Review 13 #1); repaired_self_audit.md (item 3)
    canonical: rules_freeze_preregistration = Metrics pre-registered Month 11; rules locked Month 12 (Phase 2 start); power analysis draft Month 5
    observed:  'only 4 weeks before pilots begin at Month 13'; power analysis 'not due until Month 11'
LOW CF-009  document: repaired_executive_summary.md; repaired_review_plan.md
    canonical: free_reserve_after_fallbacks = Remaining pre-gate headroom after $85K draw = $90K; $35K is a shortfall on the whole reserve
    observed:  '$35K-$90K headroom'; '2.7-3.5%'; '$125K-$152K'
LOW CF-010  document: repaired_review_plan.md
    canonical: staffing = 1.0 FTE cohort manager by Month 6
    observed:  Cohort manager by Month 4 as mitigation; 6-month 'gap' after a Month 6 hire
```

### 1. Reserve cannot fund the extensions and top-ups charged to it (🔴 High) — needs a project decision

- **canonical reserve_draw_rule; Review 14 #3:** Reserve: pre-gate draws capped at $175K; the remaining balance is released only after the Month 24 GO.
- **Review 2 #2, Review 5 #1, Review 1 #2, Review 4 #1, Review 10 #3:** A 3-6 month Phase 2 extension ($300K-$600K) is 'consuming the entire $350K reserve'; Phase 2.5 safety extension is 'funded from Phase 3 reserve'; 'consuming the entire pre-gate reserve'.
- **Why it conflicts:** An extension follows invalid or inconclusive data, which has no GO, so the post-gate half of the reserve is not releasable. Pre-gate draws are capped at $175K, and even the full $350K is below a 6-month extension ($600K). The same reserve is also claimed for Phase 3 top-up, Phase 2.5 and pre-gate protection, with no ranking.
- **Suggested resolution:** Decide and document one waterfall for the $0.35M: pre-gate gate-protection (cap $175K), extension after inconclusive data, Phase 3 top-up, any Phase 2.5. Options: (a) let the board release a defined part of the post-gate balance for a validated extension without a GO; (b) cap the extension at what the pre-gate cap and Phase 3 underspend can cover; (c) treat an extension as unfunded and require descoping. Replace 'entire reserve' wording with the chosen rule, and correct the $35K-$250K shortfall figures accordingly.

### 2. Steward receives the $0.35M reserve vs stewardship unfunded (🔴 High) — needs a project decision

- **Pitch, Collaboration Opportunities (post-v1.0 steward):** Steward 'receive[s] $0.35M reserve release post-gate plus pro-rata Phase 3 funding if a written commitment is signed by Month 30'.
- **Executive Summary Risk 3; Review 14 #1; canonical stewardship_funding_gap:** Post-Month-36 stewardship ($150K-$250K per year) is unfunded and no steward or funding source exists; Risk 3 'stewardship unfunded'.
- **Why it conflicts:** The pitch states a transfer to the steward as fact, while every other document treats steward funding as an open gap. The same $0.35M is also the pre-gate protection pool, the Phase 3 top-up and the extension source, so it cannot be given away as well.
- **Suggested resolution:** Remove the transfer from the pitch until decided. Decision options: (a) the steward receives nothing from the project budget; (b) a fixed, capped seed from unspent Phase 3 or reserve funds, ranked after pre-gate protection and any extension; (c) steward funding is entirely external. State the choice in the project plan and the pitch.

### 3. Safety-critical cohort deferral vs 4-arm, 320-completer gate and conflicting triggers (🔴 High) — needs a project decision

- **canonical pilot_design, phase2_go_no_go_rule; Pitch Stakeholder Benefits; Executive Summary:** Pilot design is 2 cohorts x 2 conditions = 4 arms; gate validity needs at least 80 completers per arm (320 total); pitch promises validated technical-glossary benefits.
- **Review 4 #1, Review 10 #3, Self-audit 2 and 14, Premortem A5:** If approval takes more than 6 months, defer the safety-critical cohort to a post-Month-24 Phase 2.5 (Review 4); more than 4 months (Review 10, Self-audit 14, Self-audit 2). Written regulator advice is due Month 4 (premortem A5), Month 6 (Review 10), Month 8 (Review 4, Self-audit 14).
- **Why it conflicts:** Removing two arms before Month 24 changes the gate population and the 320-completer validity condition, yet the gate rule and pitch assume four arms. The deferral threshold (4 vs 6 months) and the advice date differ, and the liability strategy at Month 4 would precede advice not due until Month 8.
- **Suggested resolution:** Decide the fallback: ESL-only 2-arm gate with re-registered validity conditions (160 completers) and technical cohort as non-gating, or a deferred cohort. Use one trigger (4 months is the more defensible, since the pilot window is only 12 months) and one date for written advice (Month 4, matching the liability strategy). Qualify the pitch's technical-glossary claims as conditional.

### 4. Steward fallback: cancel v1.0 at Month 33 vs defer to Month 36 or later (🔴 High) — needs a project decision

- **Premortem FM4 stop rule; Review 6 KPI 3 (first clause):** No signed commitment by Month 30: release not triggered; Month 33 is the latest point at which a delayed release can be triggered; if none by then, v1.0 is cancelled and the project closes.
- **Review 5 #3, Review 6 KPI 3, Review 9 #3, Review 14 #1, Self-audit 20:** If no signed MOU by Month 30, 'defer v1.0 release to Month 36 (2029-10-13) or later'; 'delays release to Month 36'; 'defer v1.0 release from Month 30 to Month 36'.
- **Why it conflicts:** Cancellation at Month 33 and deferral to Month 36 or later are different outcomes. A release at or after Month 36 falls outside the funded 36-month program, leaves no time for the at least 3 licensed adopters by Month 36, and no funded team exists to carry it.
- **Suggested resolution:** Choose one rule. If a deferral beyond Month 33 is wanted, decide who funds the team after Month 36 and re-date the adopter target; otherwise adopt the FM4 rule (release by Month 33 or cancel and archive) everywhere. Never state 'Month 36 or later' as a release option unless funded.

### 5. Underpowered/inconclusive pilot treated as NO-GO or 'false-negative gate' (🟡 Medium)

- **canonical phase2_go_no_go_rule; Executive Summary:** Fewer than 80 completers per arm makes data invalid; invalid or inconclusive data leads to a board-decided extension; NO-GO applies only to valid data with a failing metric and returns up to $1.2M.
- **Self-audit 5; Review 2 #1-#2, Review 4 #3, Review 5 #1; Review 2 #1:** 'a false-negative gate (no-go on inconclusive data, stranding $1.2M Phase 2 spend)'; power 'from 80% to ~60% ... raising false-negative gate risk'; 'Type II error ... to 50%' at 60% power; 'credibility worth $1.2M-$1.4M'.
- **Why it conflicts:** Under the canonical rule an underpowered pilot is invalid and leads to an extension, not NO-GO. A NO-GO returns funds rather than stranding them. Phase 2 spend is not 'stranded' by the gate, and funds at risk are $1.2M (Phase 3 + reserve), not $1.2M-$1.4M. At 60% power the Type II error is 40%, not 50%.
- **Suggested resolution:** Reword: sample below 80 per arm = invalid = extension; false-negative language applies only to valid, adequately powered data. Replace '$1.2M-$1.4M' with '$1.2M (Phase 3 $0.85M + reserve $0.35M)'. Make power/Type II pairs consistent (60% power = 40% Type II).

### 6. Baseline recruitment study precedes ethics, consent and partner commitments (🟡 Medium) — needs a project decision

- **Project Plan Compliance Actions and Dependencies; canonical pilot_partner_commitments:** Ethics approval by Month 6; signed partner commitments by Month 3; consent forms and privacy policy by Month 12.
- **Executive Summary Risk 1 and Feedback #2; Review 3 #2; Review 8 #2; Premortem A3:** Baseline study with 20-30 learners and 2 assessment sessions in Months 1-2, to validate the 35-45% dropout assumption and set enrolment targets.
- **Why it conflicts:** A human-subject study with assessments and attrition tracking would start before IRB approval, before consent forms exist and before partners are signed. Two months also cannot observe 30-day follow-up or the up-to-12-month attrition it is meant to validate.
- **Suggested resolution:** Decide the form: (a) obtain an ethics exemption/approval before Months 1-2 and secure consent and partner agreement first; (b) re-scope to a non-participant evidence review (partner historical attrition and literature) in Months 1-3; or (c) move the study after Month 6 and drop the claim that it validates 30-day or 12-month dropout. Update the Month 3 retargeting deadline accordingly.

### 7. Ordinal spoken form locked in the same month as the kappa check that depends on it (🟡 Medium) — needs a project decision

- **canonical ordinal_rule, phase1_extension_fallback; Premortem FM2 and FM8 tripwires; Review 8 #3; Review 9 #1:** Marker symbol and spoken form fixed by Month 10; kappa check and dry run at Month 10; ordinal spoken form 'not finalized until Month 10'.
- **Review 13 #2; Premortem FM2 early warning:** Lock accent and spoken form by Month 8; begin rater training Month 8; confirm kappa by Month 9.5; FM2 early warning 'spoken form unresolved at Month 8'.
- **Why it conflicts:** Raters cannot be calibrated on a reading fixed only in the month of the check. A Month 10 lock leaves no buffer before the 4-week extension fallback, and ordinal audio recorded in Months 6-11 would precede the fixed reading.
- **Suggested resolution:** Adopt Month 8 as the lock date across documents (Month 10 stays the backstop and kappa-check date). Align FM2/FM8 tripwires and Reviews 8 and 9 to Month 8, and have the kappa check follow at least 4-6 weeks after the lock.

### 8. Enrolment audit month, tripwires and dropout units (🟡 Medium)

- **canonical pilot_enrolment_and_dropout; Review 4 #3; Review 13 #3; Self-audit 4 and 20:** Enrol at least 115 per arm (460 total), dropout at most 30%, enrolment complete Month 13; audit shows forecast completers at least 320 (Month 12 in Reviews 4, 13, Self-audits).
- **Premortem FM3; Review 8 #2; Review 6 KPI 1; Review 12 #2:** Audit at Month 13 'one month after enrolment opens' (FM3); 'activate contingency if dropout tracking exceeds 25% by Month 10' (Review 8); flag if completers below 70 per arm at Month 18 (KPI 1); 'at most 30% monthly dropout' (Review 12).
- **Why it conflicts:** The audit month differs (12 vs 13). A Month 10 dropout check precedes any Phase 2 enrolment (starts Month 12). A 70-per-arm warning is below the 80-per-arm validity minimum, so the alarm fires after validity is lost. A 30% monthly dropout is a different quantity from the 30% tolerated total dropout.
- **Suggested resolution:** Use one audit at Month 12 (enrolment opens) with a forecast completers at least 320 test, a follow-up check at Month 13 (enrolment close), and an 80-per-arm warning bound at Month 18. Replace the Month 10 dropout check with the baseline/partner-history evidence. Express the retention KPI as at most 30% cumulative dropout.

### 9. Psychometrics timeline: lead-time arithmetic and what is 'due' when (🟡 Medium)

- **canonical psychometrics_cost, rules_freeze_preregistration; Executive Summary; Self-audit 20:** Power analysis and pre-analysis plan draft by Month 5; pre-registered Month 11; rules locked and Phase 2 starts Month 12; enrolment complete Month 13.
- **Review 13 #1; Self-audit 3; Review 1 #1:** 'pre-registered until Month 11 - only 4 weeks before pilots begin at Month 13'; 'Pre-analysis plan and power analysis are not due until Month 11'; validity study Months 10-11 feeds thresholds registered at Month 11.
- **Why it conflicts:** Month 11 to Month 12 is about 4 weeks and to Month 13 about 8-9, so the lead time and pilot start are mixed. Self-audit 3 says the power analysis is due at Month 11 while its own mitigation and Self-audit 20 say Month 5. A validity study ending in Month 11 cannot inform thresholds registered at the same date without a stated sequence.
- **Suggested resolution:** State: power analysis Month 5; validity study Months 10-11 ends before registration (e.g., results by Month 10.5 or registration at end of Month 11); about 4 weeks to Phase 2 start (Month 12) and about 8-9 weeks to enrolment close (Month 13). Correct Self-audit 3.

### 10. Pre-gate headroom and percentage arithmetic (⚪ Low)

- **canonical free_reserve_after_fallbacks, overrun_exposure (recomputed):** $85K is about 49% of the $175K cap, leaving $90K headroom; $85K + $20K-$30K leaves $60K-$70K; $40K-$50K is 3.6-4.5% of $1.1M; $35K is a shortfall on the whole reserve after $85K + $300K.
- **Executive Summary Feedback #3; Review 11 #2; Review 5 #2:** '$35K-$90K headroom estimate' under the cap; '$40K-$50K overrun (2.7-3.5% of Phase 1)' leaving '$125K-$152K'; '$105K-$115K' 'exhausts contingency'.
- **Why it conflicts:** $35K is not headroom under the cap. $40K-$50K is 3.6-4.5% of $1.1M and leaves $125K-$135K. $105K-$115K leaves $60K-$70K, which is not an exhausted cap.
- **Suggested resolution:** Correct to: headroom $90K after a 4-week extension; $60K-$70K after adding recruitment contingency; 3.6-4.5% of Phase 1; $125K-$135K remaining.

### 11. Cohort manager timing and ownership gap (⚪ Low)

- **canonical staffing; Executive Summary; Project Plan:** 1.0 FTE cohort manager hired by Month 6.
- **Review 4 #3; Review 12 #2; Review 1 #2:** 'hire cohort manager by Month 4 (not Month 6)'; add a 0.5 FTE Recruitment Coordinator by Month 3; 'hires at Month 6, but enrollment begins Month 12 - a 6-month gap during which recruitment design ... unowned'.
- **Why it conflicts:** The Month 4 hire and the extra coordinator are stated as mitigations while the Executive Summary treats Month 4 only as a proposal with cost to be assessed. The 'gap' argument is illogical: a Month 6 hire covers Months 6-12; the unowned period is Months 0-6.
- **Suggested resolution:** Keep Month 6 as the plan value; list a Month 4 hire or interim coordinator as a costed option only. Rewrite the gap as Months 3-6, before the hire.

### 12. Stewardship roadmap horizon: 5-year vs 10-year (⚪ Low)

- **Executive Summary Key Deliverables; Review (Issue 5 recommendation):** A 5-year roadmap is published by Month 36.
- **Pitch, Long-term Vision:** Steward receives 'a published 10-year governance roadmap, change-control calendar and annual budget'.
- **Why it conflicts:** The deliverable's horizon differs between documents. The 10-year figure is the funding-gap horizon, not the planned roadmap.
- **Suggested resolution:** Keep the 5-year roadmap as the Month 36 deliverable and refer to the 10-year funding gap separately.

## Summary

The plan is largely consistent on its core structure: budget split, 4-arm design, gate rule, Month 30 release conditional on a steward commitment, and the 10% morphology/accent/ordinal design choices. Most earlier fixes have held. The remaining problems are concentrated in funding and fallback logic: the $0.35M reserve is claimed by several competing uses, safety-cohort and steward fallbacks are unresolved, and an extension after invalid data has no stated source of funds. Several lower-level timing and arithmetic slips (enrolment audit month, ordinal lock vs kappa check, headroom percentages) are fixable by editing to the canonical values. The user's intelligibility constraint (at least 90% of control accuracy within 2 weeks) is not operationalized as a gate metric in any document.