
## Risk 1 - Regulatory & Standards Adoption
Educational and standards bodies (ESL publishers, national curricula authorities, standards-setting organizations) may reject Clear English as a non-standard variant or threat to unified English instruction, delaying or blocking third-party adoption. Regulatory bodies in jurisdictions requiring alignment with national language standards may refuse to permit use in accredited programs. The standard's legal standing and protection against dilution or divergent forks remain undefined until licensing is finalized.

**Impact:** Rejection by key adopter groups could reduce pilot enrollment and Phase 3 adoption to near zero, effectively ending the initiative despite completion of rule specification. Regulatory delays of 4–8 months could push pilot timeline into Month 28–32 (2029-02-13 to 2029-06-13) and jeopardize the Month 24 (2028-10-13) go/no-go gate. Uncontrolled fragmentation and unofficial variants could emerge within 18–24 months of public release, damaging credibility and undermining adoption claims.

**Likelihood:** High

**Severity:** High

**Action:** Engage national language-curriculum authorities and standards bodies (e.g., Common European Framework, TESOL leadership) in advisory roles from Month 1 (2026-11-13) to gauge regulatory appetite and identify formal approval pathways. Prepare formal submissions to relevant standards bodies by Month 15 (2028-01-13). Establish a licensing and name-stewardship framework by Month 12 (2027-10-13) that reserves the 'Clear English' mark for conforming materials and includes a public conformance checklist. Create a formal dispute-resolution procedure within the editorial board for handling divergent forks.

## Risk 2 - Pilot Recruitment & Participant Retention
Recruiting and retaining sufficient adult ESL and native-speaker cohorts for statistically valid gate metrics (comprehension speed, ordinal error rate, pronunciation consistency, 30-day retention) may prove difficult if partnership institutions lack capacity, funding or learner availability. The plan requires in-person supervised sessions, audio capture and 30-day follow-up, imposing high participant burden. High dropout rates could render pilot data inconclusive at the Month 24 (2028-10-13) go/no-go gate.

**Impact:** Insufficient cohort size (fewer than 50–100 learners per condition) may make the four gate metrics statistically unreliable, forcing either extension of Phase 2 by 3–6 months or a disputed no-go decision. Dropout rates above 30% could reduce effective sample sizes further. A failed or inconclusive gate decision could strand Phase 3 funding ($800K–$1.2M, estimated) and delay market entry to Month 36 (2029-10-13) or beyond. Recruitment delays alone could consume 4–8 weeks of the 12-month Phase 2 window.

**Likelihood:** High

**Severity:** High

**Action:** Secure commitments from at least 3–4 adult ESL programs and 2–3 technical/safety-training organizations by Month 3 (2027-01-13), including written enrollment guarantees and contact-hour or per-learner payment terms. Offer learner incentives (certificates, small stipends, discounted course fees) to reduce dropout. Design assessments to fit existing course schedules to minimize added burden. Hire a dedicated Phase 2 project manager focused on cohort administration and retention by Month 12 (2027-10-13). Build a 10–15% contingency into projected cohort size to absorb attrition.

## Risk 3 - Technical & Assessment Validity
Purpose-built gate metrics (comprehension speed, ordinal error rate, pronunciation consistency, 30-day retention) must be validated and pre-registered before Month 12 (2027-10-13) to ensure credibility for the Phase 2 go/no-go decision. Developing psychometrically sound instruments tailored to Clear English-specific effects requires expert effort and pilot testing that may exceed initial timeline or budget. If instruments are weak or inconsistently applied, the go/no-go decision will be scientifically disputable and lose partner confidence.

**Impact:** Instrument validation failures could delay metrics pre-registration by 2–4 months, compressing the Phase 2 pilot window to 8 months or fewer. Weak or disputed metrics could make the Phase 2 gate non-credible, forcing either a do-over at additional cost ($200K–$300K, estimated) or a gate decision that partners reject, stalling Phase 3 planning. Inconsistent scoring of pronunciation consistency across raters could inflate measurement noise, obscuring true effects and leading to a false-negative go/no-go outcome.

**Likelihood:** Medium

**Severity:** High

**Action:** Hire an independent psychometrician or applied measurement specialist by Month 2 (2026-12-13) and budget $150K–$200K (estimated) for instrument design, validation and inter-rater reliability studies. Pre-register the metric design, pass/fail thresholds and primary analysis plan on an open repository (e.g., OSF) by Month 11 (2027-09-13), 30 days before the Month 12 (2027-10-13) deadline. Conduct a small pilot validity study (N=20–30) in Month 10–11 (2027-08-13 to 2027-09-13) to confirm instruments discriminate between Clear English and standard English conditions before Phase 2 enrollment begins.

## Risk 4 - Rule Ambiguity & Editorial Board Consensus
The morphology retention threshold, homograph disambiguation policy and ordinal marker pronunciation require editorial board consensus before Phase 1 rules can be finalized at Month 12 (2027-10-13). If board members (linguists, practitioners, learners) hold conflicting preferences—e.g., linguists favoring consistency versus teachers favoring recognizability—rule specifications may remain ambiguous, vague or internally contradictory. Unresolved conflicts delay rule publication and weaken the rule set's credibility for pilots.

**Impact:** Unresolved editorial disputes could push rule finalization by 4–12 weeks into Phase 2, compressing the pilot window. Ambiguous or internally inconsistent rules (e.g., unclear morphology exceptions or conflicting ordinal-marker guidance) could force rule clarifications or errata mid-pilot, invalidating earlier assessments and inflating measurement noise. A visibly divided editorial board could undermine educator and publisher confidence in the standard before pilots begin.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish editorial board composition and decision procedures by Month 1 (2026-11-13), including clear voting rules, conflict-of-interest management and a formal 'decision logging' process that documents disagreements and the rationale for each ruling. Conduct a first editorial board meeting by Month 2 (2026-12-13) to surface rule tensions and assign rule-specification workstreams to board subcommittees. Set a hard rule-finalization deadline of Month 11 (2027-09-13), requiring all rule ambiguities to be resolved in writing and published as a draft standard by Month 11 (2027-09-13) for a 30-day public-comment window before finalization.

## Risk 5 - Financial & Budget Overrun
The fixed $3.5M budget must be split across three 12-month phases, including rule specification, 5,000-word core lexicon with pronunciation recordings, reference corpus, purpose-built pilot assessments, print and digital curriculum design, pilot administration and outreach. Any of several line items could overrun: audio recording (multi-accent recordings at scale), psychometric validation (more expensive than estimated), pilot incentives and cohort management (retention costs), or unforeseen operational expenses (office space inflation, staff turnover requiring recruitment costs, technology licensing). A $200K–$500K overrun could force budget cuts mid-project.

**Impact:** A $300K overrun (8.6% of budget) during Phase 1–2 could force either reductions in pilot scope (fewer cohorts, smaller assessment battery), curriculum quality (less refined pilot materials) or postponement of outreach. Cutting Phase 2 pilot scope would undermine the go/no-go gate evidence. Cost overruns discovered in Month 18–24 (2028-04-13 to 2028-10-13) leave limited time to recover and no clear contingency plan. If contingency reserve is depleted before Phase 2 ends, a no-go decision would leave no unspent funds to return.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Implement a detailed Phase-wise budget with monthly tracking and rolling 6-month forecasts beginning Month 1 (2026-11-13). Establish a spending review gate at Month 9 (2027-07-13) to assess Phase 1 expenses against budget and adjust Phase 2 allocations if needed. Allocate a clear contingency reserve of $175K–$250K (5–7% of budget) controlled by the editorial board and released only for pre-approved, evidence-backed needs (e.g., additional psychometric validation if Phase 1 pilot signals a tight gate). Negotiate fixed-rate contracts with curriculum vendors and audio studios by Month 3 (2027-01-13) to lock recording and design costs.

## Risk 6 - Pronunciation Consistency Measurement & Accent Selection
The pronunciation consistency score, a key go/no-go gate metric, depends on a chosen reference accent (e.g., Received Pronunciation, General American) and reliable inter-rater scoring. If raters disagree on whether learner pronunciation matches the reference, the metric becomes noisy and unreliable. Choosing a single reference accent alienates speakers of other major varieties (Australian, Indian, South African English), narrowing adoption perception. Audio capture, storage and scoring infrastructure must be secured and tested before Phase 2 pilots begin.

**Impact:** Poor inter-rater reliability (Cohen's kappa <0.70) on pronunciation scoring would inflate measurement error, obscuring true Clear English effects and risking a false-negative gate outcome, delaying or killing Phase 3. Accent selection disputes (e.g., objections to British or American bias) could trigger criticism from standards bodies or ESL organizations, damaging the standard's perceived neutrality. Audio infrastructure failures (missing recordings, inaudible files, storage loss) could make pronunciations impossible to score, invalidating the metric.

**Likelihood:** Medium

**Severity:** High

**Action:** Anchor the reference accent selection by Month 3 (2027-01-13), with explicit written justification and documentation of how other major accents map to the anchor. Conduct inter-rater training and a calibration study (N=30–50 recordings) in Month 11 (2027-09-13), targeting Cohen's kappa ≥0.75 and publishing the scoring rubric openly. Secure audio storage infrastructure and backup protocols by Month 6 (2027-04-13); conduct a dry-run with a small pilot cohort (N=5–10) in Month 10 (2027-08-13) to test recording, storage and scoring workflows. If inter-rater reliability falls below 0.70 at Month 11 (2027-09-13), extend Phase 1 by 4 weeks to conduct additional rater training rather than proceeding to Phase 2 with weak measurement.

## Risk 7 - Safety-Critical Adoption & Liability
If the project pursues a safety-critical adoption wedge (technical glossaries, procedures, incident reports), it assumes responsibility for the safety and clarity of documents using Clear English. Misreading or ambiguity in safety-critical text (e.g., a procedure or hazard label) caused by Clear English rules or gaps could result in injury, regulatory investigation or litigation. Liability exposure increases if Clear English forms are adopted in real working environments (factories, laboratories, medical settings) during Phase 2 pilots or Phase 3 early adoption. Insurance, legal review and risk-approval processes may be costly and slow.

**Impact:** A serious incident linked to Clear English documentation could result in litigation, regulatory action (e.g., from OSHA, EPA or equivalent bodies), and immediate pause or withdrawal of the standard, ending the initiative. Legal review and liability insurance could cost $100K–$300K (estimated) and delay safety-critical partner engagement by 2–4 months. Regulatory approval or safety-case review for safety-critical use could stretch to 6–12 months, pushing pilot enrollment into Month 30–36 (2029-04-13 to 2029-10-13). Any incident, even if not fatal or injurious, would trigger media scrutiny and credibility loss.

**Likelihood:** Low

**Severity:** High

**Action:** If pursuing the safety-critical adoption wedge, secure legal counsel specializing in product liability and regulatory compliance by Month 2 (2026-12-13) and develop a risk-mitigation and liability-insurance strategy by Month 4 (2027-02-13), with costs capped at $150K–$200K. Conduct a formal safety-case review with partner organizations (e.g., industry standards bodies) before any safety-critical pilot material is used in real working environments. Require all safety-critical pilot documents to carry explicit disclaimers and to be reviewed by qualified human experts (not Clear English alone) before deployment. Establish an incident-reporting protocol and a rapid-response team to address any misreading or clarity issues discovered during pilots. Consider capping safety-critical pilots to non-life-critical procedures or glossaries (e.g., warnings, labeling) rather than core operational procedures until post-Phase-2 evidence is strong.

## Risk 8 - Educator Pushback & Teacher Training
Teachers, curriculum designers and ESL instructors may resist Clear English adoption for multiple reasons: perceived threat to standard English teaching, unfamiliarity with the rules, skepticism about evidence claims, or concern that learners will be confused by a non-standard variant. Without active teacher buy-in and training, pilots will fail. Educator pushback could manifest as low engagement, non-compliance with pilot protocols, or vocal criticism that damages public credibility. Training teacher cohorts on Clear English rules and pedagogy is a significant operational burden not fully budgeted in the plan.

**Impact:** Low educator engagement or non-compliance could reduce pilot quality and statistical power, making gate metrics unreliable or inconclusive. Public criticism from respected teachers or professional organizations (TESOL, IATEFL) could trigger negative media coverage, damaging credibility before the go/no-go gate decision. Inadequate teacher training could lead to rule misapplication in pilot materials, invalidating assessment results. Educator resistance could reduce Phase 3 adoption by 30–50% even if the gate decision is positive.

**Likelihood:** High

**Severity:** Medium

**Action:** Engage ESL teacher professional organizations (TESOL, IATEFL, national equivalents) as advisory partners by Month 2 (2026-12-13) and co-design pilot protocols with practicing teachers to increase buy-in. Develop a comprehensive teacher training program (online and in-person) by Month 10 (2027-08-13) covering Clear English rules, rationale, pilot administration and learner communication. Recruit and hire a dedicated educator-liaison person (0.5–1.0 FTE, estimated $50K–$70K for Phase 2) responsible for teacher engagement, training delivery and feedback loops. Offer continuing education credits or stipends to pilot teachers (estimated $20K–$40K across Phase 2) to incentivize active participation.

## Risk 9 - Fragmentation & Unofficial Variants
Once the Clear English standard is published, third parties may create divergent variants or forks—e.g., a 'Simplified Clear English' for children, a 'Medical Clear English' with specialized terminology, or non-conforming materials labeled as Clear English but not adhering to the official rule set. Licensing and name-stewardship controls are planned but may be weak or unenforceable, especially against offshore publishers or open-source projects. Fragmentation undermines the standard's value for consistent communication and creates confusion for learners and users.

**Impact:** Uncontrolled fragmentation could emerge within 12–24 months of Phase 3 public release, reducing the perceived value of the standard and making adoption claims (e.g., 'Clear English is widely used for safety documentation') false. Certification and dispute-resolution overhead could consume 5–10% of ongoing governance budget ($50K–$100K annually post-Phase 3, not budgeted). Confusion over which variant is 'official' could depress adoption if educators and publishers perceive the standard as unstable or political.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Finalize the Licensing and Name Stewardship decision (Decision 11) by Month 6 (2027-04-13), choosing either a certification-mark approach or a permissive share-alike license with divergence-disclosure requirements. Publish a clear conformance checklist and versioned certification procedure by Month 14 (2027-12-13). Establish a standing 'Standards Stewardship Committee' within the editorial board (3–5 members, 2–4 hours/month) with authority to review third-party claims to the Clear English name and issue guidance or public statements on non-conforming forks. Draft dispute-resolution procedures and consider low-cost arbitration options for contested conformance claims. Set a policy that substantial divergences (more than 10–15% of rule changes) trigger a requirement to adopt a distinct name.

## Risk 10 - Coordination with Existing Controlled Languages
The plan considers alignment with existing controlled-language standards (e.g., ASD-STE100 Simplified Technical English) to ease adoption by technical writers. However, coordinating rule changes, vocabulary lists and pronunciation guidance with another standards body's maintenance schedule is operationally complex and constrains the project's independence. If alignment is chosen (Decision 12), changes to the external standard could force Clear English revisions, and conflicts between the two standards could confuse adopters.

**Impact:** Dependency on an external standards body's revision schedule could delay Clear English v1.0 release by 2–4 months if coordination is required. Unresolved conflicts between Clear English and an external controlled language (e.g., differing ordinal conventions) could make the '100% compatible' alignment claim false, embarrassing both standards. If the external standard is acquired, discontinued or significantly changed, Clear English would need rapid revision, straining the Change-Control and Release Cadence decision.

**Likelihood:** Low

**Severity:** Medium

**Action:** If the Controlled-Language Alignment Posture decision (Decision 12) opts for close coordination, formalize a Memorandum of Understanding with the external standards body by Month 4 (2027-02-13), defining scope, change-request procedures, and escalation paths for conflicts. Establish a standing liaison role (0.25–0.5 FTE) to coordinate vocabulary and rule changes. Conduct a detailed compatibility audit at Month 10 (2027-08-13) to identify and resolve conflicts before v1.0 finalization. Include explicit language in the Clear English license and documentation noting any dependency or alignment with external standards. If full compatibility cannot be demonstrated, clearly label the alignment as partial and specify which rules differ.

## Risk 11 - Core Lexicon Coverage & Adequacy
The 5,000-word core lexicon is designed to cover ESL and safety-critical use, but its selection basis (Decision 9—frequency-led, domain-led, or incident-driven) determines whether it adequately serves pilots and early adopters. If the lexicon omits high-frequency words needed to read pilot materials or technical glossaries, assessments will suffer from confounding (learners struggle with out-of-lexicon words rather than Clear English effects). An incomplete or misaligned lexicon could undermine pilot credibility and adoption appeal.

**Impact:** If the core lexicon covers fewer than 85–90% of running text in pilot materials or technical glossaries, comprehension assessments will be confounded and gate metrics unreliable. Discovering inadequate coverage at Month 18 (2028-04-13) would require expansion of the lexicon, adding 4–8 weeks to Phase 2 and inflating pronunciation-recording costs ($20K–$50K per 500 words, estimated). Missing domain-specific terms (e.g., safety jargon) would reduce the appeal of the technical wedge and damage early-adopter credibility.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Finalize the Core Lexicon Selection Basis decision (Decision 9) by Month 2 (2026-12-13) and conduct a pilot lexicon-coverage audit by Month 8 (2027-06-13), analyzing running text from existing ESL curricula and technical glossaries to confirm 85%+ coverage. If coverage falls short, allocate time and budget (estimated $30K–$50K) for targeted lexicon expansion by Month 10 (2027-08-13). Publish the lexicon and its selection methodology openly by Month 12 (2027-10-13), inviting third-party feedback and challenges. Reserve 5–10% of the core-lexicon slots for domain-specific additions identified during Phase 2 pilots before v1.0 lock.

## Risk 12 - Timeline Compression & Phase Gate Slippage
The plan specifies three fixed 12-month phases with a hard go/no-go gate at Month 24 (2028-10-13). However, multiple dependencies and unknowns could compress the timeline: rule finalization delays, slow institutional partnerships, audio recording backlogs, psychometric validation setbacks, or pilot recruitment lag. If Phase 1 slips by 4–6 weeks, Phase 2 pilots face a compressed window, reducing data quality. If the Month 24 (2028-10-13) go/no-go gate must be postponed due to incomplete pilot data, Phase 3 outreach and adoption are delayed.

**Impact:** A 6-week slip in Phase 1 compresses Phase 2 to 10 months, reducing pilot robustness and possibly making the go/no-go gate decision inconclusive, triggering a 6–12 month extension (Month 30–36 = 2029-04-13 to 2029-10-13) that strands Phase 3 funding and delays market entry. Any gate delay beyond Month 24 (2028-10-13) pushes Phase 3 launch to Month 36 (2029-10-13) or later, reducing the project's ability to capitalize on early momentum. Compressed timelines force trade-offs: fewer cohorts, shorter follow-up periods, or weaker assessment instruments.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish monthly project-status reviews with critical-path analysis and rolling forecasts of key milestones (rule finalization, psychometric validation, cohort recruitment, audio completion) from Month 1 (2026-11-13) onward. Build in explicit 2–4 week buffers at key decision points (Month 6 = 2027-04-13 for design freeze, Month 11 = 2027-09-13 for metrics finalization, Month 18 = 2028-04-13 for pilot midpoint) to catch and correct slippage. Identify high-risk dependencies early (e.g., audio recording capacity, partnership commitment letters) and secure contingency plans or backup vendors by Month 3 (2027-01-13). Create a formal escalation path to the editorial board if any critical path item slips >2 weeks, triggering review of timeline and scope.

## Risk 13 - Data Privacy & Participant Confidentiality
Phase 2 pilots collect sensitive data: learner literacy levels, pronunciation recordings, test scores, demographic information and 30-day follow-up assessments. Audio recordings of pronunciation are biometric data requiring careful consent, storage and retention protocols. Institutional Review Board (IRB) or ethics-board approval may be required in the US and UK, depending on whether the pilot is classified as research. Data breaches, unauthorized use of recordings, or privacy violations could expose the project to legal liability and damage participant trust.

**Impact:** Delays in IRB/ethics approval (2–8 weeks) could compress the Phase 2 pilot window or push recruitment into Month 14–16 (2027-12-13 to 2028-02-13). Privacy violations or data breaches could trigger regulatory investigation (GDPR in UK, state privacy laws in the US) and litigation. Restrictive data-handling requirements (e.g., deletion of audio after transcription, restricted re-use) could limit future analysis and replicability of the go/no-go metrics. Participant concerns about data privacy could reduce cohort recruitment or increase dropout.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Engage an IRB or ethics-review board early (Month 1–2 = 2026-11-13 to 2026-12-13) to clarify whether the pilot qualifies as research requiring formal review and to draft consent forms and data-handling protocols. Budget $10K–$20K (estimated) for ethics consulting and compliance management. Implement secure audio storage (encrypted, access-controlled, backed up) by Month 6 (2027-04-13) and conduct a data-protection audit by Month 8 (2027-06-13). Publish a clear privacy policy and data-retention schedule on the project website by Month 12 (2027-10-13), explicitly stating how long recordings are kept and who may access them. Offer participants the option to have their audio deleted post-analysis if they request it.

## Risk 14 - Reference Accent & Multi-Accent Demand
Choosing a single reference accent (Decision 8) for pronunciation guidance and pilot scoring simplifies measurement but may trigger pressure to add additional accents (British, American, Australian, Indian) to broaden appeal and inclusivity. Multi-accent audio recording (5,000 words × 2–3 accents = 10,000–15,000 audio files) is expensive, complex to manage and complicates the pronunciation consistency score (Which accent is 'correct'?). Scope creep toward multi-accent coverage could inflate audio costs by 2–3× and compress other budget areas.

**Impact:** Pressure to add accents could emerge at Month 9–12 (2027-07-13 to 2027-10-13) during Phase 1, forcing a decision whether to absorb the cost (estimated $50K–$100K additional, straining Phase 1 budget) or decline and risk criticism from standards bodies and ESL organizations concerned about inclusivity. Multi-accent audio infrastructure (storage, playback, rater training) adds complexity and could delay pronunciation-guidance publication by 4–8 weeks. Scope creep here could cascade to other line items: additional accent guidance in the dictionary, revised pronunciation-consistency scoring procedures, extended pilot timelines.

**Likelihood:** Medium

**Severity:** Low

**Action:** Lock the single-accent decision early (Month 2–3 = 2026-12-13 to 2027-01-13) with explicit, published justification and a documented commitment to document how other accents map to the anchor by Month 12 (2027-10-13). Set a policy that accent additions are deferred to post-v1.0 (Phase 3 or beyond) and require a formal scope-change proposal with budget impact analysis. Consider recording a small secondary sample (200–300 high-frequency or safety-critical words) in one additional accent as a 'proof-of-concept' for Phase 3, costing $10K–$15K (estimated), rather than committing to full coverage.

## Risk 15 - Publisher & Curriculum Vendor Capacity
The plan envisions publishers and ESL material vendors adopting or co-producing Clear English curricula in Phase 3. However, their capacity to invest in new materials, their interest in a non-standard variant, and their willingness to delay publication pending the Phase 2 go/no-go decision are all uncertain. Vendors may be slow to commit resources without market proof, or they may demand guarantees of adoption or a minimum revenue threshold that the project cannot offer. If major publishers decline to participate, Phase 3 adoption will be limited to small providers or open-source projects.

**Impact:** Low publisher engagement could reduce Phase 3 curriculum diversity, limiting adoption to niche ESL programs or technical contexts. Delayed vendor commitments could push Phase 3 curriculum launch to Month 36–42 (2029-10-13 to 2030-04-13), missing the window for near-term adoption momentum. Vendor demands for guarantees or revenue sharing could strain the project's governance or budget. Without major publishers, the standard's reach may plateau at 10,000–50,000 learners rather than reaching the 100,000+ needed for credible market presence.

**Likelihood:** High

**Severity:** Medium

**Action:** Engage major ESL publishers (Cambridge, Oxford, Pearson, smaller regional publishers) and material-development vendors as advisory partners by Month 3 (2027-01-13), seeking non-binding letters of interest or commitment to pilot or co-develop curricula. Conduct a Phase 3 publisher-readiness assessment at Month 18 (2028-04-13) to gauge commitment levels and identify gaps. Develop a clear, low-friction licensing pathway (Decision 11) and publish it by Month 12 (2027-10-13) to reduce vendor uncertainty. Offer a '30-day rights' window post-publication (Phase 3 start) where early-adopting publishers can claim specific glossaries or grade levels to incentivize rapid adoption.

## Risk 16 - Measurement Construct Validity & Outcome Definition
The four gate metrics (comprehension speed, ordinal error rate, pronunciation consistency, 30-day retention) assume that improvements in these measures indicate that Clear English is superior and worthy of adoption. However, the construct validity of each metric—i.e., whether it actually measures what it claims (e.g., whether ordinal error rate captures ordinal learning or test-taking noise)—is untested. Confounds could inflate or deflate measured effects: e.g., learners might improve ordinal accuracy due to simple repeated exposure rather than Clear English superiority, or pronunciation consistency could be high for both Clear English and standard English if the accent is close to learners' first language.

**Impact:** Weak construct validity could lead to false-positive or false-negative go/no-go outcomes. A false-positive (gate passes but Clear English provides no real benefit) could launch a standard that fails to deliver on adoption promises, damaging credibility. A false-negative (gate fails but Clear English is actually effective) could kill a viable initiative. Unresolved construct questions at Month 24 (2028-10-13) could force a redo of Phase 2 or a disputed gate decision that stakeholders reject.

**Likelihood:** Medium

**Severity:** High

**Action:** Build construct-validity analysis into the Outcome Metric Battery Design (Decision 4) by Month 5 (2027-03-13). Conduct a detailed literature review and expert panel (applied linguists, psychometricians, ESL researchers) to identify potential confounds and design control conditions that isolate Clear English effects from other learning factors. In Phase 2 pilots, include explicit manipulation checks (e.g., explicit instruction on ordinal rules versus implicit learning) to validate that observed effects are due to Clear English comprehensibility and not other factors. Publish a pre-analysis plan documenting the construct-validity framework and all confound-control measures before Phase 2 begins.

## Risk 17 - Sustainability & Post-Phase-3 Governance
The plan addresses governance during the three-year project (editorial board, linguistic review, pilot administration) but does not specify how the standard will be maintained, updated and governed after Month 36 (2029-10-13) when external project funding ends. Ongoing tasks—responding to adoption feedback, managing change requests, handling disputes over rule interpretation, updating the lexicon with emerging vocabulary—require sustained funding and staffing. Without a clear post-project governance model and funding plan, the standard could atrophy or become poorly maintained, undermining long-term adoption.

**Impact:** Lack of post-project governance could degrade the standard within 12–24 months of Phase 3 completion. Ambiguities and errors discovered after v1.0 publication would go unaddressed, reducing credibility and adoption. Emerging vocabulary and cultural shifts would not be incorporated into the lexicon, making the standard feel outdated by Month 48–60 (2030-10-13 to 2031-10-13). Third-party adopters and educators would face uncertainty about the standard's future, reducing their willingness to invest in long-term adoption.

**Likelihood:** High

**Severity:** Medium

**Action:** Define a post-Phase-3 governance and funding model by Month 24 (2028-10-13), before the go/no-go gate decision. Identify potential sustaining organizations (e.g., language education non-profits, standards bodies, academic consortiums) and approach them for funding commitments (estimated $150K–$250K annually for ongoing maintenance, estimated) by Month 30 (2029-04-13). Establish a permanent Standards Stewardship Committee (Decision 7 touches on this) with clear roles, decision authority and term lengths. Publish a 5-year stewardship plan by Month 36 (2029-10-13), outlining how the standard will be updated, how change requests will be prioritized and how conflicts will be resolved.

## Risk 18 - Market Saturation & Competing Standards
The English-language standardization space is not empty. Existing initiatives—plain-language standards, controlled-technical languages, reformed spelling movements—compete for attention and adoption. New entrants may emerge during the three-year project timeline. If Clear English is perceived as a marginal variant or a late arrival to a crowded field, adoption may stall. Competitor standards or initiatives endorsed by larger organizations (UNESCO, British Council, ILO) could eclipse Clear English before it gains traction.

**Impact:** Competition could reduce Phase 3 adoption by 20–40%, capping learner reach at 20,000–50,000 instead of the 100,000+ needed for significant market presence. Competing standards endorsed by larger bodies could crowd out Clear English in institutional procurement decisions (ESL curricula, safety standards). Phase 3 outreach budget would need to be higher to differentiate Clear English and build awareness, straining the $3.5M envelope.

**Likelihood:** Low

**Severity:** Low

**Action:** Conduct a competitive landscape analysis by Month 3 (2027-01-13), mapping existing plain-language, controlled-language and spelling-reform initiatives and their adoption rates, funding and organizational backing. Identify Clear English's unique value proposition (e.g., 'ordinal standardization for safety-critical procedures' or 'ESL-optimized pronunciation guidance') and emphasize it in all outreach by Month 12 (2027-10-13). Monitor the field for new entrants during Phase 2 and adjust messaging as needed. Build academic partnerships (universities, research centers) that provide credibility and differentiation from commercial or political initiatives.

## Risk 19 - Currency Fluctuation & International Operations
The project operates across multiple currencies (USD primary budget, GBP for UK operations if Location 1 is chosen, EUR for European outreach). Currency fluctuations, particularly if the UK (Location 1) is selected as the operational hub, could inflate costs and compress the budget. A 10–15% depreciation of GBP against USD (as occurred in 2016–2024) could add £50K–£100K in real costs for UK-based office, partnerships and staff without corresponding budget increases.

**Impact:** A 10% GBP depreciation against USD could reduce UK operational budget purchasing power by £50K–£100K (estimated), forcing cuts in pilot scope, personnel, or outreach. Unhedged currency risk could emerge in Months 12–24 (2027-10-13 to 2028-10-13), when most Phase 2 spending occurs, leaving limited time to adjust. Late discovery of currency pressures could trigger budget-cutting decisions that compromise pilot quality or team capacity.

**Likelihood:** Low

**Severity:** Low

**Action:** Implement the currency strategy outlined in the currency_strategy.md file: denominate all budgeting and reporting in USD; if Location 1 (UK) is chosen, lock GBP exchange rates in contracts by Month 3 (2027-01-13) to avoid variance in office and partner costs; allocate a modest 2–3% contingency within UK-based spending to absorb exchange-rate fluctuation. Monitor currency forecasts quarterly and assess impact on budget; if significant headwinds emerge (>5% adverse movement), propose a budget amendment or deferred spending to leadership by Month 15 (2028-01-13).

## Risk 20 - Stakeholder Misalignment on 'Success'
Stakeholders—educators, standards bodies, ESL publishers, learners, safety regulators—may have divergent definitions of what constitutes successful Clear English adoption. Educators may prioritize ease of teaching and learner engagement; regulators may prioritize measurable safety improvements; publishers may prioritize revenue potential; learners may prioritize job prospects or fluency gain. If the project's definition of success (as measured by the four gate metrics) does not align with what stakeholders value, adoption may remain low even if the metrics pass the gate.

**Impact:** Misaligned stakeholder expectations could lead to post-launch disappointment and reduced adoption (20–40% lower than projected). Educators could resist adoption if they perceive the standard as imposing inconvenient rules rather than delivering classroom benefits they care about. Safety regulators could decline to mandate or incentivize Clear English if they don't see measurable, incident-reduction improvements. This misalignment could be discovered at Month 24 (2028-10-13) (go/no-go) or later, stranding Phase 3 planning.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Conduct stakeholder-expectation interviews and focus groups during Month 1–3 (2026-10 to 2027-01), engaging educators, regulators, publishers and learners to understand their success criteria and concerns. Publish a 'Stakeholder Alignment Charter' by Month 6 (2027-04-13) that documents stakeholder input and explains how the project's metrics and approach address key concerns. Build stakeholder advisory panels (separate from the editorial board) for educators, regulators and publishers, meeting quarterly to surface emerging concerns and expectations. At Month 18 (2028-04-13), conduct a mid-phase stakeholder check-in to assess alignment and adjust Phase 2 or Phase 3 strategy if major gaps are identified.

## Risk summary
This three-year, $3.5M language-standardization initiative is ambitious, evidence-gated and operationally complex. The top three critical risks that could jeopardize success are: **(1) Regulatory & Standards Adoption (high likelihood, high severity):** Educational authorities, standards bodies and ESL publishers may reject Clear English as a non-standard threat or fragmentation risk, blocking institutional adoption and reducing the pilot to voluntary, low-engagement cohorts. This risk requires early engagement with regulatory bodies and a credible licensing framework by Month 12 (2027-10-13). **(2) Pilot Recruitment & Retention (high likelihood, high severity):** Recruiting sufficient adult ESL and native-speaker cohorts for statistically defensible gate metrics, and retaining them through 30-day follow-up, is operationally challenging and high-cost. Failure to retain 70%+ of recruited learners invalidates the comprehension speed, ordinal error rate, pronunciation consistency and 30-day retention metrics that trigger the Phase 2 go/no-go decision. This requires early partnership commitments, learner incentives and dedicated cohort management by Month 3 (2027-01-13). **(3) Assessment Validity & Rule Ambiguity (medium–high likelihood, high severity):** Purpose-built gate metrics must be psychometrically sound and pre-registered by Month 12 (2027-10-13) to be credible; editorial board consensus on morphology, homographs and ordinals must be resolved by Month 11 (2027-09-13) to avoid mid-pilot rule changes. Weak or ambiguous metrics could render the Month 24 (2028-10-13) go/no-go gate scientifically disputable, forcing expensive rework or a failed gate. Secondary risks include Phase 1 timeline slip (compressing Phase 2 pilot window), educator pushback (reducing engagement and public credibility), fragmentation and unofficial variants (undermining standard stability post-launch), and safety-critical liability exposure (if that wedge is chosen). The plan's Pragmatic Foundation path—invariant prefix ordinals, optional pronunciation overlay, ESL-first supplementary wedge, purpose-built validated metrics and even budget spread—substantially mitigates these risks by avoiding aggressive rule choices, protecting compatibility with standard English and ESL pedagogy, and building credible evidence before scaling. However, active risk management (stakeholder engagement, timeline discipline, budget controls, governance clarity) is essential from Month 1 (2026-11-13) onward to prevent slippage and maintain stakeholder confidence through the Phase 2 gate.