# Purpose
# Clear English: Language Standardization Program

## Overview

Three-year, gated, $3.5M program to develop a standardized parallel variant of English with regularized ordinals, spelling-to-sound mapping, morphology and homograph disambiguation. Target sectors: education, ESL, technical writing and safety-critical documentation.

## Deliverables

- Public standard
- Reference dictionary
- Style guide
- Pilot curriculum
- Open licensing policy
- Editorial-board governance framework
- Risk register
- Outreach strategy for academic partners, ESL publishers and standards organizations

## Program Structure

Gated phases with go/no-go decision after Phase 2. Phase 1 covers rule specification and reference corpus. Phase 2 includes pilot learning materials and usability testing. Phase 3 involves public standard release with limited-scope adoption.

## Scope and Intent

Standards and public-interest language initiative aimed at wide adoption in education, ESL, technical writing and safety-critical documentation. Not a profit-seeking venture.

# Domain
and

# Plan Type
and

# Physical Locations
# Requirements for physical locations

- Access to adult ESL learners (community colleges, adult education centers, language schools) for in-person pilot cohorts
- Access to native speakers in technical or safety-critical training settings
- Proximity to universities with applied linguistics and psychometric expertise
- Office or co-working space for editorial board, linguists and curriculum designers
- Quiet room or studio capacity for supervised audio capture of pronunciation
- Good transport links for outreach to publishers and standards organizations
- Moderate cost of living and labor to fit a $3.5M total budget (user constraint)
- English-speaking environment so that reference accent and native-reader testing are practical

## Location 1: Cambridge / Oxford area, England

University-adjacent offices near Cambridge or Oxford; partner language schools and ESL publishers (e.g., Cambridge, Oxford). Dense cluster of ESL publishers, assessment bodies, applied linguists and psychometric expertise. Strong access to adult ESL schools and standards-oriented organizations. Supports the ESL-first wedge and credible pilot measurement. Office costs are higher than in smaller cities.

## Location 2: Washington, D.C. metro area (including Arlington and Northern Virginia)

Co-working or university-affiliated office space near Georgetown University / Center for Applied Linguistics-type organizations; partner adult ESL programs in the metro area. Large, diverse adult ESL population and many adult education programs. Proximity to standards bodies, federal safety and technical-writing communities and applied linguistics departments. Good air and rail links for outreach. Cost is higher but offset by access to partners and pilot participants.

## Location 3: Austin, Texas or similar mid-cost metro

Co-working space near University of Texas at Austin; adult ESL centers, community colleges and industrial or energy-sector training sites in the region. Lower cost than coastal hubs, with a large adult ESL population, a university linguistics base and nearby industrial and energy safety-training settings for the technical-glossary cohort. Fits the budget limit while serving both pilot cohorts.

## Location Summary

The plan is physical: in-person pilot cohorts, print curriculum, board meetings, audio capture and outreach all require real sites. Cambridge/Oxford offers publisher and assessment expertise. Washington, D.C. offers diverse ESL cohorts plus standards and safety communities. Austin offers lower cost with ESL and industrial training access. Final choice should weigh partner commitments and budget fit.

# Currency Strategy
# Currencies

- USD: Primary currency for the $3.5M budget constraint. All budget splits across three phases, staff salaries, pilot assessments, print curriculum production and outreach travel will be denominated in USD for consolidated reporting.
- GBP: Relevant for Location 1 (Cambridge/Oxford area, England). Local spending on office space, ESL school partnerships, publisher meetings and assessment administration will occur in GBP.
- EUR: Relevant if outreach expands to European standards bodies, ESL publishers or applied linguistics networks.

## Primary currency

USD

## Currency strategy

All budgeting and financial reporting will be conducted in USD, aligning with the fixed $3.5M constraint. Phase splits and milestone payments will be tracked in USD. For operations in the UK (Location 1 option), GBP exchange rates should be locked at contract signature to avoid variance in office, partner and pilot costs; a 2–3% contingency of UK-based spending is recommended to absorb currency fluctuation. If outreach to European standards bodies or ESL publishers occurs in Phase 3, EUR spending should be pre-approved and capped as a percentage of outreach budget. Fixed-rate agreements with vendors and partners will be prioritized to minimize exchange-rate surprise.

# Identify Risks
# Risk 1 - Regulatory & Standards Adoption

Educational and standards bodies may reject Clear English as a non-standard variant or threat to unified English instruction, delaying or blocking third-party adoption. Regulatory bodies in jurisdictions requiring alignment with national language standards may refuse to permit use in accredited programs. The standard's legal standing and protection against dilution or divergent forks remain undefined until licensing is finalized.

Impact: Rejection by key adopter groups could reduce pilot enrollment and Phase 3 adoption to near zero, effectively ending the initiative despite completion of rule specification. Regulatory delays of 4–8 months could push pilot timeline into Month 28–32 (2029-02-13 to 2029-06-13) and jeopardize the Month 24 (2028-10-13) go/no-go gate. Uncontrolled fragmentation and unofficial variants could emerge within 18–24 months of public release, damaging credibility and undermining adoption claims.

Likelihood: High

Severity: High

Action: Engage national language-curriculum authorities and standards bodies (e.g., Common European Framework, TESOL leadership) in advisory roles from Month 1 (2026-11-13) to gauge regulatory appetite and identify formal approval pathways. Prepare formal submissions to relevant standards bodies by Month 15 (2028-01-13). Establish a licensing and name-stewardship framework by Month 12 (2027-10-13) that reserves the 'Clear English' mark for conforming materials and includes a public conformance checklist. Create a formal dispute-resolution procedure within the editorial board for handling divergent forks.

# Risk 2 - Pilot Recruitment & Participant Retention

Recruiting and retaining sufficient adult ESL and native-speaker cohorts for statistically valid gate metrics (comprehension speed, ordinal error rate, pronunciation consistency, 30-day retention) may prove difficult if partnership institutions lack capacity, funding or learner availability. The plan requires in-person supervised sessions, audio capture and 30-day follow-up, imposing high participant burden. High dropout rates could render pilot data inconclusive at the Month 24 (2028-10-13) go/no-go gate.

Impact: Insufficient cohort size (fewer than 50–100 learners per condition, estimated) may make the four gate metrics statistically unreliable, forcing either extension of Phase 2 by 3–6 months or a disputed no-go decision. Dropout rates above 30% could reduce effective sample sizes further. A failed or inconclusive gate decision could strand Phase 3 funding ($800K–$1.2M, estimated) and delay market entry to Month 36 (2029-10-13) or beyond. Recruitment delays alone could consume 4–8 weeks of the 12-month Phase 2 window.

Likelihood: High

Severity: High

Action: Secure commitments from at least 3–4 adult ESL programs and 2–3 technical/safety-training organizations by Month 3 (2027-01-13), including written enrollment guarantees and contact-hour or per-learner payment terms. Offer learner incentives (certificates, small stipends, discounted course fees) to reduce dropout. Design assessments to fit existing course schedules to minimize added burden. Hire a dedicated Phase 2 project manager focused on cohort administration and retention by Month 12 (2027-10-13). Build a 10–15% contingency into projected cohort size to absorb attrition.

# Risk 3 - Technical & Assessment Validity

Purpose-built gate metrics (comprehension speed, ordinal error rate, pronunciation consistency, 30-day retention) must be validated and pre-registered before Month 12 (2027-10-13) to ensure credibility for the Phase 2 go/no-go decision. Developing psychometrically sound instruments tailored to Clear English-specific effects requires expert effort and pilot testing that may exceed initial timeline or budget. If instruments are weak or inconsistently applied, the go/no-go decision will be scientifically disputable and lose partner confidence.

Impact: Instrument validation failures could delay metrics pre-registration by 2–4 months, compressing the Phase 2 pilot window to 8 months or fewer. Weak or disputed metrics could make the Phase 2 gate non-credible, forcing either a do-over at additional cost ($200K–$300K, estimated) or a gate decision that partners reject, stalling Phase 3 planning. Inconsistent scoring of pronunciation consistency across raters could inflate measurement noise, obscuring true effects and leading to a false-negative go/no-go outcome.

Likelihood: Medium

Severity: High

Action: Hire an independent psychometrician or applied measurement specialist by Month 2 (2026-12-13) and budget $150K–$200K (estimated) for instrument design, validation and inter-rater reliability studies. Pre-register the metric design, pass/fail thresholds and primary analysis plan on an open repository (e.g., OSF) by Month 11, 30 (2027-09-13, 2029-04-13) days before the Month 12 (2027-10-13) deadline. Conduct a small pilot validity study (N=20–30) in Months 10–11 (2027-08-13 to 2027-09-13) to confirm instruments discriminate between Clear English and standard English conditions before Phase 2 enrollment begins.

# Risk 4 - Rule Ambiguity & Editorial Board Consensus

The morphology retention threshold, homograph disambiguation policy and ordinal marker pronunciation require editorial board consensus before Phase 1 rules can be finalized at Month 12 (2027-10-13). If board members (linguists, practitioners, learners) hold conflicting preferences—e.g., linguists favoring consistency versus teachers favoring recognizability—rule specifications may remain ambiguous, vague or internally contradictory. Unresolved conflicts delay rule publication and weaken the rule set's credibility for pilots.

Impact: Unresolved editorial disputes could push rule finalization by 4–12 weeks into Phase 2, compressing the pilot window. Ambiguous or internally inconsistent rules (e.g., unclear morphology exceptions or conflicting ordinal-marker guidance) could force rule clarifications or errata mid-pilot, invalidating earlier assessments and inflating measurement noise. A visibly divided editorial board could undermine educator and publisher confidence in the standard before pilots begin.

Likelihood: Medium

Severity: Medium

Action: Establish editorial board composition and decision procedures by Month 1 (2026-11-13), including clear voting rules, conflict-of-interest management and a formal 'decision logging' process that documents disagreements and the rationale for each ruling. Conduct a first editorial board meeting by Month 2 (2026-12-13) to surface rule tensions and assign rule-specification workstreams to board subcommittees. Set a hard rule-finalization deadline of Month 11 (2027-09-13), requiring all rule ambiguities to be resolved in writing and published as a draft standard by Month 11 (2027-09-13) for a 30-day public-comment window before finalization.

# Risk 5 - Financial & Budget Overrun

The fixed $3.5M budget must be split across three 12-month phases, including rule specification, 5,000-word core lexicon with pronunciation recordings, reference corpus, purpose-built pilot assessments, print and digital curriculum design, pilot administration and outreach. Any of several line items could overrun: audio recording (multi-accent recordings at scale), psychometric validation (more expensive than estimated), pilot incentives and cohort management (retention costs), or unforeseen operational expenses (office space inflation, staff turnover requiring recruitment costs, technology licensing). A $200K–$500K overrun could force budget cuts mid-project.

Impact: A $300K overrun (8.6% of budget, estimated) during Phase 1–2 could force either reductions in pilot scope (fewer cohorts, smaller assessment battery), curriculum quality (less refined pilot materials) or postponement of outreach. Cutting Phase 2 pilot scope would undermine the go/no-go gate evidence. Cost overruns discovered in Month 18–24 (2028-04-13 to 2028-10-13) leave limited time to recover and no clear contingency plan. If contingency reserve is depleted before Phase 2 ends, a no-go decision would leave no unspent funds to return.

Likelihood: Medium

Severity: Medium

Action: Implement a detailed Phase-wise budget with monthly tracking and rolling 6-month forecasts beginning Month 1 (2026-11-13). Establish a spending review gate at Month 9 (2027-07-13) to assess Phase 1 expenses against budget and adjust Phase 2 allocations if needed. Allocate a clear contingency reserve of $175K–$250K (5–7% of budget, estimated) controlled by the editorial board and released only for pre-approved, evidence-backed needs (e.g., additional psychometric validation if Phase 1 pilot signals a tight gate). Negotiate fixed-rate contracts with curriculum vendors and audio studios by Month 3 (2027-01-13) to lock recording and design costs.

# Risk 6 - Pronunciation Consistency Measurement & Accent Selection

The pronunciation consistency score, a key go/no-go gate metric, depends on a chosen reference accent (e.g., Received Pronunciation, General American) and reliable inter-rater scoring. If raters disagree on whether learner pronunciation matches the reference, the metric becomes noisy and unreliable. Choosing a single reference accent alienates speakers of other major varieties (Australian, Indian, South African English), narrowing adoption perception. Audio capture, storage and scoring infrastructure must be secured and tested before Phase 2 pilots begin.

Impact: Poor inter-rater reliability (Cohen's kappa <0.70) on pronunciation scoring would inflate measurement error, obscuring true Clear English effects and risking a false-negative gate outcome, delaying or killing Phase 3. Accent selection disputes (e.g., objections to British or American bias) could trigger criticism from standards bodies or ESL organizations, damaging the standard's perceived neutrality. Audio infrastructure failures (missing recordings, inaudible files, storage loss) could make pronunciations impossible to score, invalidating the metric.

Likelihood: Medium

Severity: High

Action: Anchor the reference accent selection by Month 3 (2027-01-13), with explicit written justification and documentation of how other major accents map to the anchor. Conduct inter-rater training and a calibration study (N=30–50 recordings) in Month 11 (2027-09-13), targeting Cohen's kappa ≥0.75 and publishing the scoring rubric openly. Secure audio storage infrastructure and backup protocols by Month 6 (2027-04-13); conduct a dry-run with a small pilot cohort (N=5–10) in Month 10 (2027-08-13) to test recording, storage and scoring workflows. If inter-rater reliability falls below 0.70 at Month 11 (2027-09-13), extend Phase 1 by 4 weeks to conduct additional rater training rather than proceeding to Phase 2 with weak measurement.

# Risk 7 - Safety-Critical Adoption & Liability

If the project pursues a safety-critical adoption wedge (technical glossaries, procedures, incident reports), it assumes responsibility for the safety and clarity of documents using Clear English. Misreading or ambiguity in safety-critical text (e.g., a procedure or hazard label) caused by Clear English rules or gaps could result in injury, regulatory investigation or litigation. Liability exposure increases if Clear English forms are adopted in real working environments (factories, laboratories, medical settings) during Phase 2 pilots or Phase 3 early adoption. Insurance, legal review and risk-approval processes may be costly and slow.

Impact: A serious incident linked to Clear English documentation could result in litigation, regulatory action (e.g., from OSHA, EPA or equivalent bodies), and immediate pause or withdrawal of the standard, ending the initiative. Legal review and liability insurance could cost $100K–$300K (estimated) and delay safety-critical partner engagement by 2–4 months. Regulatory approval or safety-case review for safety-critical use could stretch to 6–12 months, pushing pilot enrollment into Month 30–36 (2029-04-13 to 2029-10-13). Any incident, even if not fatal or injurious, would trigger media scrutiny and credibility loss.

Likelihood: Low

Severity: High

Action: If pursuing the safety-critical adoption wedge, secure legal counsel specializing in product liability and regulatory compliance by Month 2 (2026-12-13) and develop a risk-mitigation and liability-insurance strategy by Month 4 (2027-02-13), with costs capped at $150K–$200K (estimated). Conduct a formal safety-case review with partner organizations (e.g., industry standards bodies) before any safety-critical pilot material is used in real working environments. Require all safety-critical pilot documents to carry explicit disclaimers and to be reviewed by qualified human experts (not Clear English alone) before deployment. Establish an incident-reporting protocol and a rapid-response team to address any misreading or clarity issues discovered during pilots. Consider capping safety-critical pilots to non-life-critical procedures or glossaries (e.g., warnings, labeling) rather than core operational procedures until post-Phase-2 evidence is strong.

# Risk 8 - Educator Pushback & Teacher Training

Teachers, curriculum designers and ESL instructors may resist Clear English adoption for multiple reasons: perceived threat to standard English teaching, unfamiliarity with the rules, skepticism about evidence claims, or concern that learners will be confused by a non-standard variant. Without active teacher buy-in and training, pilots will fail. Educator pushback could manifest as low engagement, non-compliance with pilot protocols, or vocal criticism that damages public credibility. Training teacher cohorts on Clear English rules and pedagogy is a significant operational burden not fully budgeted in the plan.

Impact: Low educator engagement or non-compliance could reduce pilot quality and statistical power, making gate metrics unreliable or inconclusive. Public criticism from respected teachers or professional organizations (TESOL, IATEFL) could trigger negative media coverage, damaging credibility before the go/no-go gate decision. Inadequate teacher training could lead to rule misapplication in pilot materials, invalidating assessment results. Educator resistance could reduce Phase 3 adoption by 30–50% even if the gate decision is positive.

Likelihood: High

Severity: Medium

Action: Engage ESL teacher professional organizations (TESOL, IATEFL, national equivalents) as advisory partners by Month 2 (2026-12-13) and co-design pilot protocols with practicing teachers to increase buy-in. Develop a comprehensive teacher training program (online and in-person) by Month 10 (2027-08-13) covering Clear English rules, rationale, pilot administration and learner communication. Recruit and hire a dedicated educator-liaison person (0.5–1.0 FTE, estimated $50K–$70K for Phase 2) responsible for teacher engagement, training delivery and feedback loops. Offer continuing education credits or stipends to pilot teachers (estimated $20K–$40K across Phase 2) to incentivize active participation.

# Risk 9 - Fragmentation & Unofficial Variants

Once the Clear English standard is published, third parties may create divergent variants or forks—e.g., a 'Simplified Clear English' for children, a 'Medical Clear English' with specialized terminology, or non-conforming materials labeled as Clear English but not adhering to the official rule set. Licensing and name-stewardship controls are planned but may be weak or unenforceable, especially against offshore publishers or open-source projects. Fragmentation undermines the standard's value for consistent communication and creates confusion for learners and users.

Impact: Uncontrolled fragmentation could emerge within 12–24 months of Phase 3 public release, reducing the perceived value of the standard and making adoption claims (e.g., 'Clear English is widely used for safety documentation') false. Certification and dispute-resolution overhead could consume 5–10% of ongoing governance budget ($50K–$100K annually post-Phase 3, not budgeted). Confusion over which variant is 'official' could depress adoption if educators and publishers perceive the standard as unstable or political.

Likelihood: Medium

Severity: Medium

Action: Finalize the Licensing and Name Stewardship decision by Month 6 (2027-04-13), choosing either a certification-mark approach or a permissive share-alike license with divergence-disclosure requirements. Publish a clear conformance checklist and versioned certification procedure by Month 14 (2027-12-13). Establish a standing 'Standards Stewardship Committee' within the editorial board (3–5 members, 2–4 hours/month) with authority to review third-party claims to the Clear English name and issue guidance or public statements on non-conforming forks. Draft dispute-resolution procedures and consider low-cost arbitration options for contested conformance claims. Set a policy that substantial divergences (more than 10–15% of rule changes) trigger a requirement to adopt a distinct name.

# Risk 10 - Coordination with Existing Controlled Languages

The plan considers alignment with existing controlled-language standards (e.g., ASD-STE100 Simplified Technical English) to ease adoption by technical writers. However, coordinating rule changes, vocabulary lists and pronunciation guidance with another standards body's maintenance schedule is operationally complex and constrains the project's independence. If alignment is chosen, changes to the external standard could force Clear English revisions, and conflicts between the two standards could confuse adopters.

Impact: Dependency on an external standards body's revision schedule could delay Clear English v1.0 release by 2–4 months if coordination is required. Unresolved conflicts between Clear English and an external controlled language (e.g., differing ordinal conventions) could make the '100% compatible' alignment claim false, embarrassing both standards. If the external standard is acquired, discontinued or significantly changed, Clear English would need rapid revision, straining the Change-Control and Release Cadence decision.

Likelihood: Low

Severity: Medium

Action: If the Controlled-Language Alignment Posture decision opts for close coordination, formalize a Memorandum of Understanding with the external standards body by Month 4 (2027-02-13), defining scope, change-request procedures, and escalation paths for conflicts. Establish a standing liaison role (0.25–0.5 FTE) to coordinate vocabulary and rule changes. Conduct a detailed compatibility audit at Month 10 (2027-08-13) to identify and resolve conflicts before v1.0 finalization. Include explicit language in the Clear English license and documentation noting any dependency or alignment with external standards. If full compatibility cannot be demonstrated, clearly label the alignment as partial and specify which rules differ.

# Risk 11 - Core Lexicon Coverage & Adequacy

The 5,000-word core lexicon is designed to cover ESL and safety-critical use, but its selection basis (Decision 9—frequency-led, domain-led, or incident-driven) determines whether it adequately serves pilots and early adopters. If the lexicon omits high-frequency words needed to read pilot materials or technical glossaries, assessments will suffer from confounding (learners struggle with out-of-lexicon words rather than Clear English effects). An incomplete or misaligned lexicon could undermine pilot credibility and adoption appeal.

Impact: If the core lexicon covers fewer than 85–90% of running text in pilot materials or technical glossaries (estimated), comprehension assessments will be confounded and gate metrics unreliable. Discovering inadequate coverage at Month 18 (2028-04-13) would require expansion of the lexicon, adding 4–8 weeks to Phase 2 and inflating pronunciation-recording costs ($20K–$50K per 500 words, estimated). Missing domain-specific terms (e.g., safety jargon) would reduce the appeal of the technical wedge and damage early-adopter credibility.

Likelihood: Medium

Severity: Medium

Action: Finalize the Core Lexicon Selection Basis decision by Month 2 (2026-12-13) and conduct a pilot lexicon-coverage audit by Month 8 (2027-06-13), analyzing running text from existing ESL curricula and technical glossaries to confirm 85%+ coverage. If coverage falls short, allocate time and budget (estimated $30K–$50K) for targeted lexicon expansion by Month 10 (2027-08-13). Publish the lexicon and its selection methodology openly by Month 12 (2027-10-13), inviting third-party feedback and challenges. Reserve 5–10% of the core-lexicon slots for domain-specific additions identified during Phase 2 pilots before v1.0 lock.

# Risk 12 - Timeline Compression & Phase Gate Slippage

The plan specifies three fixed 12-month phases with a hard go/no-go gate at Month 24 (2028-10-13). However, multiple dependencies and unknowns could compress the timeline: rule finalization delays, slow institutional partnerships, audio recording backlogs, psychometric validation setbacks, or pilot recruitment lag. If Phase 1 slips by 4–6 weeks, Phase 2 pilots face a compressed window, reducing data quality. If the Month 24 (2028-10-13) go/no-go gate must be postponed due to incomplete pilot data, Phase 3 outreach and adoption are delayed.

Impact: A 6-week slip in Phase 1 compresses Phase 2 to 10 months, reducing pilot robustness and possibly making the go/no-go gate decision inconclusive, triggering a 6–12 month extension (Month 30–36 = 2029-04-13 to 2029-10-13) that strands Phase 3 funding and delays market entry. Any gate delay beyond Month 24 (2028-10-13) pushes Phase 3 launch to Month 36 (2029-10-13) or later, reducing the project's ability to capitalize on early momentum. Compressed timelines force trade-offs: fewer cohorts, shorter follow-up periods, or weaker assessment instruments.

Likelihood: Medium

Severity: Medium

Action: Establish monthly project-status reviews with critical-path analysis and rolling forecasts of key milestones (rule finalization, psychometric validation, cohort recruitment, audio completion) from Month 1 (2026-11-13) onward. Build in explicit 2–4 week buffers at key decision points (Month 6 = 2027-04-13 for design freeze, Month 11 = 2027-09-13 for metrics finalization, Month 18 = 2028-04-13 for pilot midpoint) to catch and correct slippage. Identify high-risk dependencies early (e.g., audio recording capacity, partnership commitment letters) and secure contingency plans or backup vendors by Month 3 (2027-01-13). Create a formal escalation path to the editorial board if any critical path item slips >2 weeks, triggering review of timeline and scope.

# Risk 13 - Data Privacy & Participant Confidentiality

Phase 2 pilots collect sensitive data: learner literacy levels, pronunciation recordings, test scores, demographic information and 30-day follow-up assessments. Audio recordings of pronunciation are biometric data requiring careful consent, storage and retention protocols. Institutional Review Board (IRB) or ethics-board approval may be required in the US and UK, depending on whether the pilot is classified as research. Data breaches, unauthorized use of recordings, or privacy violations could expose the project to legal liability and damage participant trust.

Impact: Delays in IRB/ethics approval (2–8 weeks) could compress the Phase 2 pilot window or push recruitment into Month 14–16 (2027-12-13 to 2028-02-13). Privacy violations or data breaches could trigger regulatory investigation (GDPR in UK, state privacy laws in the US) and litigation. Restrictive data-handling requirements (e.g., deletion of audio after transcription, restricted re-use) could limit future analysis and replicability of the go/no-go metrics. Participant concerns about data privacy could reduce cohort recruitment or increase dropout.

Likelihood: Medium

Severity: Medium

Action: Engage an IRB or ethics-review board early (Month 1–2 = 2026-11-13 to 2026-12-13) to clarify whether the pilot qualifies as research requiring formal review and to draft consent forms and data-handling protocols. Budget $10K–$20K (estimated) for ethics consulting and compliance management. Implement secure audio storage (encrypted, access-controlled, backed up) by Month 6 (2027-04-13) and conduct a data-protection audit by Month 8 (2027-06-13). Publish a clear privacy policy and data-retention schedule on the project website by Month 12 (2027-10-13), explicitly stating how long recordings are kept and who may access them. Offer participants the option to have their audio deleted post-analysis if they request it.

# Risk 14 - Reference Accent & Multi-Accent Demand

Choosing a single reference accent (Decision 8) for pronunciation guidance and pilot scoring simplifies measurement but may trigger pressure to add additional accents (British, American, Australian, Indian) to broaden appeal and inclusivity. Multi-accent audio recording (5,000 words × 2–3 accents = 10,000–15,000 audio files) is expensive, complex to manage and complicates the pronunciation consistency score (Which accent is 'correct'?). Scope creep toward multi-accent coverage could inflate audio costs by 2–3× and compress other budget areas.

Impact: Pressure to add accents could emerge at Month 9–12 (2027-07-13 to 2027-10-13) during Phase 1, forcing a decision whether to absorb the cost (estimated $50K–$100K additional, straining Phase 1 budget) or decline and risk criticism from standards bodies and ESL organizations concerned about inclusivity. Multi-accent audio infrastructure (storage, playback, rater training) adds complexity and could delay pronunciation-guidance publication by 4–8 weeks. Scope creep here could cascade to other line items: additional accent guidance in the dictionary, revised pronunciation-consistency scoring procedures, extended pilot timelines.

Likelihood: Medium

Severity: Low

Action: Lock the single-accent decision early (Month 2–3 = 2026-12-13 to 2027-01-13) with explicit, published justification and a documented commitment to document how other accents map to the anchor by Month 12 (2027-10-13). Set a policy that accent additions are deferred to post-v1.0 (Phase 3 or beyond) and require a formal scope-change proposal with budget impact analysis. Consider recording a small secondary sample (200–300 high-frequency or safety-critical words) in one additional accent as a 'proof-of-concept' for Phase 3, costing $10K–$15K (estimated), rather than committing to full coverage.

# Risk 15 - Publisher & Curriculum Vendor Capacity

The plan envisions publishers and ESL material vendors adopting or co-producing Clear English curricula in Phase 3. However, their capacity to invest in new materials, their interest in a non-standard variant, and their willingness to delay publication pending the Phase 2 go/no-go decision are all uncertain. Vendors may be slow to commit resources without market proof, or they may demand guarantees of adoption or a minimum revenue threshold that the project cannot offer. If major publishers decline to participate, Phase 3 adoption will be limited to small providers or open-source projects.

Impact: Low publisher engagement could reduce Phase 3 curriculum diversity, limiting adoption to niche ESL programs or technical contexts. Delayed vendor commitments could push Phase 3 curriculum launch to Month 36–42 (2029-10-13 to 2030-04-13), missing the window for near-term adoption momentum. Vendor demands for guarantees or revenue sharing could strain the project's governance or budget. Without major publishers, the standard's reach may plateau at 10,000–50,000 learners rather than reaching the 100,000+ needed for credible market presence.

Likelihood: High

Severity: Medium

Action: Engage major ESL publishers (Cambridge, Oxford, Pearson, smaller regional publishers) and material-development vendors as advisory partners by Month 3 (2027-01-13), seeking non-binding letters of interest or commitment to pilot or co-develop curricula. Conduct a Phase 3 publisher-readiness assessment at Month 18 (2028-04-13) to gauge commitment levels and identify gaps. Develop a clear, low-friction licensing pathway (Decision 11) and publish it by Month 12 (2027-10-13) to reduce vendor uncertainty. Offer a '30-day rights' window post-publication (Phase 3 start) where early-adopting publishers can claim specific glossaries or grade levels to incentivize rapid adoption.

# Risk 16 - Measurement Construct Validity & Outcome Definition

The four gate metrics (comprehension speed, ordinal error rate, pronunciation consistency, 30-day retention) assume that improvements in these measures indicate that Clear English is superior and worthy of adoption. However, the construct validity of each metric—i.e., whether it actually measures what it claims (e.g., whether ordinal error rate captures ordinal learning or test-taking noise)—is untested. Confounds could inflate or deflate measured effects: e.g., learners might improve ordinal accuracy due to simple repeated exposure rather than Clear English superiority, or pronunciation consistency could be high for both Clear English and standard English if the accent is close to learners' first language.

Impact: Weak construct validity could lead to false-positive or false-negative go/no-go outcomes. A false-positive (gate passes but Clear English provides no real benefit) could launch a standard that fails to deliver on adoption promises, damaging credibility. A false-negative (gate fails but Clear English is actually effective) could kill a viable initiative. Unresolved construct questions at Month 24 (2028-10-13) could force a redo of Phase 2 or a disputed gate decision that stakeholders reject.

Likelihood: Medium

Severity: High

Action: Build construct-validity analysis into the Outcome Metric Battery Design decision by Month 5 (2027-03-13). Conduct a detailed literature review and expert panel (applied linguists, psychometricians, ESL researchers) to identify potential confounds and design control conditions that isolate Clear English effects from other learning factors. In Phase 2 pilots, include explicit manipulation checks (e.g., explicit instruction on ordinal rules versus implicit learning) to validate that observed effects are due to Clear English comprehensibility and not other factors. Publish a pre-analysis plan documenting the construct-validity framework and all confound-control measures before Phase 2 begins.

# Risk 17 - Sustainability & Post-Phase-3 Governance

The plan addresses governance during the three-year project (editorial board, linguistic review, pilot administration) but does not specify how the standard will be maintained, updated and governed after Month 36 (2029-10-13) when external project funding ends. Ongoing tasks—responding to adoption feedback, managing change requests, handling disputes over rule interpretation, updating the lexicon with emerging vocabulary—require sustained funding and staffing. Without a clear post-project governance model and funding plan, the standard could atrophy or become poorly maintained, undermining long-term adoption.

Impact: Lack of post-project governance could degrade the standard within 12–24 months of Phase 3 completion. Ambiguities and errors discovered after v1.0 publication would go unaddressed, reducing credibility and adoption. Emerging vocabulary and cultural shifts would not be incorporated into the lexicon, making the standard feel outdated by Month 48–60 (2030-10-13 to 2031-10-13). Third-party adopters and educators would face uncertainty about the standard's future, reducing their willingness to invest in long-term adoption.

Likelihood: High

Severity: Medium

Action: Define a post-Phase-3 governance and funding model by Month 24 (2028-10-13), before the go/no-go gate decision. Identify potential sustaining organizations (e.g., language education non-profits, standards bodies, academic consortiums) and approach them for funding commitments (estimated $150K–$250K annually for ongoing maintenance) by Month 30 (2029-04-13). Establish a permanent Standards Stewardship Committee (referenced in earlier risks) with clear roles, decision authority and term lengths. Publish a 5-year stewardship plan by Month 36 (2029-10-13), outlining how the standard will be updated, how change requests will be prioritized and how conflicts will be resolved.

# Risk 18 - Market Saturation & Competing Standards

The English-language standardization space is not empty. Existing initiatives—plain-language standards, controlled-technical languages, reformed spelling movements—compete for attention and adoption. New entrants may emerge during the three-year project timeline. If Clear English is perceived as a marginal variant or a late arrival to a crowded field, adoption may stall. Competitor standards or initiatives endorsed by larger organizations (UNESCO, British Council, ILO) could eclipse Clear English before it gains traction.

Impact: Competition could reduce Phase 3 adoption by 20–40%, capping learner reach at 20,000–50,000 instead of the 100,000+ needed for significant market presence. Competing standards endorsed by larger bodies could crowd out Clear English in institutional procurement decisions (ESL curricula, safety standards). Phase 3 outreach budget would need to be higher to differentiate Clear English and build awareness, straining the $3.5M envelope.

Likelihood: Low

Severity: Low

Action: Conduct a competitive landscape analysis by Month 3 (2027-01-13), mapping existing plain-language, controlled-language and spelling-reform initiatives and their adoption rates, funding and organizational backing. Identify Clear English's unique value proposition (e.g., 'ordinal standardization for safety-critical procedures' or 'ESL-optimized pronunciation guidance') and emphasize it in all outreach by Month 12 (2027-10-13). Monitor the field for new entrants during Phase 2 and adjust messaging as needed. Build academic partnerships (universities, research centers) that provide credibility and differentiation from commercial or political initiatives.

# Risk 19 - Currency Fluctuation & International Operations

The project operates across multiple currencies (USD primary budget, GBP for UK operations if Location 1 is chosen, EUR for European outreach). Currency fluctuations, particularly if the UK (Location 1) is selected as the operational hub, could inflate costs and compress the budget. A 10–15% depreciation of GBP against USD could add £50K–£100K in real costs for UK-based office, partnerships and staff without corresponding budget increases.

Impact: A 10% GBP depreciation against USD could reduce UK operational budget purchasing power by £50K–£100K (estimated), forcing cuts in pilot scope, personnel, or outreach. Unhedged currency risk could emerge in Months 12–24 (2027-10-13 to 2028-10-13), when most Phase 2 spending occurs, leaving limited time to adjust. Late discovery of currency pressures could trigger budget-cutting decisions that compromise pilot quality or team capacity.

Likelihood: Low

Severity: Low

Action: Denominate all budgeting and reporting in USD. If Location 1 (UK) is chosen, lock GBP exchange rates in contracts by Month 3 (2027-01-13) to avoid variance in office and partner costs. Allocate a modest 2–3% contingency within UK-based spending to absorb exchange-rate fluctuation. Monitor currency forecasts quarterly and assess impact on budget; if significant headwinds emerge (>5% adverse movement), propose a budget amendment or deferred spending to leadership by Month 15 (2028-01-13).

# Risk 20 - Stakeholder Misalignment on 'Success'

Stakeholders—educators, standards bodies, ESL publishers, learners, safety regulators—may have divergent definitions of what constitutes successful Clear English adoption. Educators may prioritize ease of teaching and learner engagement; regulators may prioritize measurable safety improvements; publishers may prioritize revenue potential; learners may prioritize job prospects or fluency gain. If the project's definition of success (as measured by the four gate metrics) does not align with what stakeholders value, adoption may remain low even if the metrics pass the gate.

Impact: Misaligned stakeholder expectations could lead to post-launch disappointment and reduced adoption (20–40% lower than projected). Educators could resist adoption if they perceive the standard as imposing inconvenient rules rather than delivering classroom benefits they care about. Safety regulators could decline to mandate or incentivize Clear English if they don't see measurable, incident-reduction improvements. This misalignment could be discovered at Month 24 (2028-10-13) (go/no-go) or later, stranding Phase 3 planning.

Likelihood: Medium

Severity: Medium

Action: Conduct stakeholder-expectation interviews and focus groups during Month 1–3 (2026-11-13 to 2027-01-13), engaging educators, regulators, publishers and learners to understand their success criteria and concerns. Publish a 'Stakeholder Alignment Charter' by Month 6 (2027-04-13) that documents stakeholder input and explains how the project's metrics and approach address key concerns. Build stakeholder advisory panels (separate from the editorial board) for educators, regulators and publishers, meeting quarterly to surface emerging concerns and expectations. At Month 18 (2028-04-13), conduct a mid-phase stakeholder check-in to assess alignment and adjust Phase 2 or Phase 3 strategy if major gaps are identified.

## Risk summary

This three-year, $3.5M language-standardization initiative is ambitious, evidence-gated and operationally complex. The top three critical risks that could jeopardize success are:

- Regulatory & Standards Adoption (high likelihood, high severity): Educational authorities, standards bodies and ESL publishers may reject Clear English as a non-standard threat or fragmentation risk, blocking institutional adoption and reducing the pilot to voluntary, low-engagement cohorts. This risk requires early engagement with regulatory bodies and a credible licensing framework by Month 12 (2027-10-13).

- Pilot Recruitment & Retention (high likelihood, high severity): Recruiting sufficient adult ESL and native-speaker cohorts for statistically defensible gate metrics, and retaining them through 30-day follow-up, is operationally challenging and high-cost. Failure to retain 70%+ of recruited learners invalidates the comprehension speed, ordinal error rate, pronunciation consistency and 30-day retention metrics that trigger the Phase 2 go/no-go decision. This requires early partnership commitments, learner incentives and dedicated cohort management by Month 3 (2027-01-13).

- Assessment Validity & Rule Ambiguity (medium–high likelihood, high severity): Purpose-built gate metrics must be psychometrically sound and pre-registered by Month 12 (2027-10-13) to be credible; editorial board consensus on morphology, homographs and ordinals must be resolved by Month 11 (2027-09-13) to avoid mid-pilot rule changes. Weak or ambiguous metrics could render the Month 24 (2028-10-13) go/no-go gate scientifically disputable, forcing expensive rework or a failed gate.

Secondary risks include Phase 1 timeline slip (compressing Phase 2 pilot window), educator pushback (reducing engagement and public credibility), fragmentation and unofficial variants (undermining standard stability post-launch), and safety-critical liability exposure (if that wedge is chosen). The plan's Pragmatic Foundation path—invariant prefix ordinals, optional pronunciation overlay, ESL-first supplementary wedge, purpose-built validated metrics and even budget spread—substantially mitigates these risks by avoiding aggressive rule choices, protecting compatibility with standard English and ESL pedagogy, and building credible evidence before scaling. However, active risk management (stakeholder engagement, timeline discipline, budget controls, governance clarity) is essential from Month 1 (2026-11-13) onward to prevent slippage and maintain stakeholder confidence through the Phase 2 gate.

# Make Assumptions
# Budget Allocation and Reserve

## Budget Split

- Phase 1: $1.1M
- Phase 2: $1.2M
- Phase 3: $0.85M
- Reserve: $0.35M (10%, proposed)

Reserve released by editorial board only after Month 24 (2028-10-13) go/no-go decision.

## Financial Feasibility

Largest budget lines are staff, psychometric validation (estimate $150K–$200K), and audio capture and pilot administration. Risk: $300K overrun (estimate, 8.6% of budget) would cut pilot scope. Mitigation: monthly tracking, Month 9 (2027-07-13) spending review, fixed-rate vendor contracts by Month 3 (2027-01-13). Benefit: no-go at Month 24 (2028-10-13) leaves reserve and most Phase 3 funds unspent.

# Timeline and Gated Schedule

## Phase Structure

- Phase 1: Months 0–12 (2026-10-13 to 2027-10-13)
- Phase 2: Months 12–24 (2027-10-13 to 2028-10-13)
- Phase 3: Months 24–36 (2028-10-13 to 2029-10-13)

## Key Milestones

- Month 3 (2027-01-13): Vendor contracts finalized and partner commitments secured
- Month 6 (2027-04-13): Editorial board and buffer; certification terms and checklist decided
- Month 10 (2027-08-13): Dry run of assessment tools
- Month 11 (2027-09-13): Rules draft completed with 30-day comment window; metrics pre-registered
- Month 18 (2028-04-13): Stakeholder alignment check-in
- Month 24 (2028-10-13): Go/no-go decision by editorial board

Buffers of 2–4 weeks (proposed) at Months 6, 11, and 18 (2027-04-13, 2027-09-13, 2028-04-13).

## Timeline Feasibility

Critical path: board decisions, lexicon, audio, instrument validation, recruitment. A 6-week Phase 1 slip compresses pilots to ~10 months. Mitigation: monthly critical-path reviews, escalation for slips over 2 weeks. Opportunity: early pre-registration makes the gate defensible and allows Phase 3 planning to begin before Month 24 (2028-10-13).

# Staffing and Pilot Sample

## Core Team

8–10 FTE (proposed): project lead, 2–3 linguists, psychometrician, curriculum designers, Phase 2 cohort manager, educator liaison, developer.

Hire psychometrician by Month 2 (2026-12-13).

## Pilot Sample

At least 50–100 learners per condition (estimate), with 15% over-recruitment for attrition.

## Resource Feasibility

Psychometric and cohort-management skills are scarce roles. Dropout above 30% weakens statistical power. Mitigation: written enrollment guarantees from 3–4 ESL programs, stipends and certificates, assessments fitted into existing course time. Opportunity: university partners supply raters and graduate assistants cheaply.

# Governance and Licensing

## Editorial Board

Practitioner-leaning board of 7–9 members (proposed) with formal linguist review-and-veto limited to ambiguity and conflict findings.

## Licensing and Name Stewardship

Text and dictionary openly licensed. 'Clear English' name reserved as a certification mark against a public conformance checklist, decided by Month 6 (2027-04-13).

## Governance Feasibility

Practitioner weighting serves adoption; linguist review limits rule ambiguity. Logged decisions and conflict-of-interest rules support legitimacy. Risk: certification may appear gatekeeping; keep checklist light and free. Add ethics review and data-protection compliance (GDPR/US state law) for pilot audio. Post-Month 36 (2029-10-13) stewardship funding not yet secured.

# Safety and Liability

## Safety Controls

Safety-critical pilots limited to glossary and labeling exercises, not live operational procedures, until after Month 24 (2028-10-13). All materials carry disclaimers and reviewed by qualified humans. Legal counsel retained by Month 2 (2026-12-13), with liability costs capped near $150K–$200K (estimate).

## Safety Risk Assessment

Likelihood is low but severity is high. Mitigation: formal safety-case review with partners, incident-reporting protocol, insurance strategy by Month 4 (2027-02-13). Safety exposure is deferred and bounded by the ESL-first wedge approach. Other tracked risks: rule ambiguity, educator pushback, fragmentation.

# Environmental Impact

## Scope

Digital-first materials with limited, on-demand print runs (small pilot batches, proposed) and recycled stock. Travel limited to essential partner and board meetings; virtual meetings as default.

## Environmental Feasibility

Main sources are print runs and travel. Benefit: on-demand pronunciation overlay keeps printed text standard and avoids reprints. Risk: print materials still need the pronunciation key; freeze content before printing. Mitigation: shared co-working space, regional pilot sites, track print volume and travel as simple annual indicators.

# Stakeholder Engagement

## Engagement Timeline

Advisory roles from Months 1–3 (2026-11-13 to 2027-01-13) for ESL teacher bodies (TESOL, IATEFL), 3–4 ESL programs, 2–3 technical training organizations, ESL publishers, and one standards body.

Stakeholder advisory panels meet quarterly. Stakeholder Alignment Charter published by Month 6 (2027-04-13).

## Engagement Feasibility

Educator pushback and publisher capacity are high-likelihood risks. Mitigation: co-design protocols with teachers, educator liaison (0.5–1.0 FTE, estimate), stipends or continuing-education credit, non-binding publisher letters of interest by Month 3 (2027-01-13). Positioning as supplementary, never replacement, reduces resistance. Month 18 (2028-04-13) check-in catches misaligned success definitions before Phase 3.

# Operational Systems

## Required Systems

- Version-controlled rule repository
- Lexicon database with pronunciation overlay generator
- Encrypted audio storage with backups by Month 6 (2027-04-13)
- Assessment and logging platform
- Pre-registered analysis plan

Single anchor accent chosen by Month 3 (2027-01-13). Go/no-go thresholds fixed before pilots.

## Operational Feasibility

Inter-rater reliability target kappa of at least 0.75 (proposed), with extension if below 0.70. Lexicon coverage of at least 85% of pilot text (proposed) to avoid confounds. Risks: audio loss, rule changes mid-pilot invalidating items. Mitigation: backups, rule freeze at Month 11 (2027-09-13), dry run at Month 10 (2027-08-13). Keep tooling lean to fit budget and post-project maintenance.

# Distill Assumptions
# Clear English Program Plan

## Overview

- 36-month program in three gated 12-month phases: rules, pilots, public release.
- Go/no-go decision at Month 24 (2028-10-13) based on four pilot metrics.
- Metrics pre-registered by Month 11 (2027-09-13); rules freeze at Month 11 (2027-09-13).
- Total budget $3.5M (user constraint): Phase 1 $1.1M, Phase 2 $1.2M, Phase 3 $0.85M, reserve $0.35M.
- Editorial board releases reserve only after Month 24 (2028-10-13) go/no-go.

## Core Design

- Clear English is a parallel variant, not a replacement; no mandates or K-12 replacement.
- Ordinals use numeric form with invariant prefix marker, coexisting with legacy forms.
- Pronunciation is optional software overlay; printed text keeps standard spelling.
- Core lexicon is 5,000 words with pronunciation guidance and mapping to standard English.
- Single anchor accent chosen by Month 3 (2027-01-13).

## ESL Strategy and Safety

- ESL-first wedge: adult ESL programs and publishers receive supplementary module.
- Safety-critical pilots limited to glossary and labeling exercises until after Month 24 (2028-10-13).
- Legal counsel retained by Month 2 (2026-12-13); liability costs capped near $150K–$200K (estimate).

## Measurement and Pilots

- Purpose-built assessments calibrated against standard-English control, subject to independent psychometric review before pilots.
- Gate metrics: comprehension speed, ordinal error rate, pronunciation consistency, 30-day retention.
- Pilots need at least 50–100 learners per condition (estimate) with 15% over-recruitment (estimate).
- Dropout above 30% would weaken statistical power; 3–4 ESL programs provide enrollment guarantees (estimate).
- Inter-rater reliability kappa target at least 0.75 (proposed); lexicon covers at least 85% of pilot text (proposed).

## Organization and Governance

- Core team about 8–10 FTE (proposed); psychometrician hired by Month 2 (2026-12-13).
- Practitioner-leaning editorial board of 7–9 members (proposed) with linguist review-and-veto on ambiguity.
- Text and dictionary openly licensed; name is certification mark, decided by Month 6 (2027-04-13).
- Stakeholder advisory roles start Months 1–3 (2026-11-13 to 2027-01-13); Alignment Charter published by Month 6 (2027-04-13).
- Publisher letters of interest and partner commitments secured by Month 3 (2027-01-13).

## Schedule and Risk

- Schedule buffers of 2–4 weeks (proposed) at Months 6, 11, and 18 (2027-04-13, 2027-09-13, 2028-04-13); 6-week Phase 1 slip compresses pilots.
- Pilot audio requires ethics review and GDPR/US state data-protection compliance.
- Post-Month 36 (2029-10-13) stewardship funding not yet secured.
- Key risks: educator pushback, rule ambiguity, fragmentation and liability, tracked with owners.


# Review Assumptions
# Domain of the expert reviewer

Project management and standards development, with specialization in educational language initiatives, evidence-based program design, stakeholder governance, and risk mitigation in multi-phase, fixed-budget public-interest projects.

## Domain-specific considerations

- Gating and go/no-go credibility: The Month 24 (2028-10-13) decision must rest on pre-registered, psychometrically sound metrics defensible to educators, standards bodies and regulators; weak instruments render the gate disputable.
- Stakeholder alignment and adoption bottlenecks: Regulatory approval, educator buy-in and publisher commitment are non-technical risks with high likelihood and high impact; early engagement (Months 1–3 = 2026-11-13 to 2027-01-13) is critical to surface objections.
- Operational complexity and timeline compression: Multiple sequential dependencies (rules → lexicon → audio → instruments → recruitment) create a single critical path; any 4–6 week slip in Phase 1 compresses Phase 2 pilots, weakening evidence.
- Budget realism and contingency reserve: The fixed $3.5M envelope must cover rule ambition, audio production, psychometric validation, pilot administration and outreach; overruns of $200K–$500K (estimate) force scope cuts that undermine gate credibility.
- Data integrity and measurement validity: Purpose-built gate metrics must control for confounds and demonstrate construct validity; instrument failure at Month 18–24 (2028-04-13 to 2028-10-13) triggers expensive rework.
- Post-launch governance and sustainability: The standard's long-term viability depends on unfunded stewardship after Month 36 (2029-10-13); lack of a funding model invites rapid degradation and loss of adopter confidence.

# Issue 1 - Missing Definition of Gate Thresholds and Success Criteria for Four Metrics

## Problem

The plan names four go/no-go metrics (comprehension speed, ordinal error rate, pronunciation consistency, 30-day retention) but does not specify quantitative thresholds (e.g., ordinal error rate must drop by at least 25% from baseline) or sample-size targets. Without pre-registered, numerical pass/fail criteria, the Month 24 (2028-10-13) go/no-go decision becomes subjective and disputable, inviting stakeholders to claim the gate was too lenient or too strict.

## Recommendation

By Month 5 (2027-03-13), the editorial board must commission a psychometrician to draft a pre-analysis plan specifying: (1) quantitative pass/fail thresholds for each metric with explicit justification; (2) minimum sample sizes per condition (e.g., n≥80 per group for 80% statistical power at α=0.05); (3) primary and secondary outcome definitions; (4) intention-to-treat vs. completer-case analysis rules. Register this plan on a public repository (e.g., Open Science Framework) and publish by Month 11, 30 (2027-09-13, 2029-04-13) days before Phase 2 pilots begin. Failure to pre-register triggers an immediate Month 12 (2027-10-13) board decision to delay Phase 2 by 6–12 weeks for instrument finalization.

## Sensitivity

If gate thresholds are too high, a false-negative outcome is likely, potentially killing a viable standard and stranding $1.2M–$1.4M (Phase 2–3 budget estimate). If thresholds are too loose, a false-positive launches a weak standard, damaging long-term credibility and adoption by 30–50%. A 4-week delay in pre-registration compresses the Phase 2 pilot window from 12 to 11 months, reducing cohort retention by an estimated 5–10 percentage points and inflating measurement error by 10–15%.

# Issue 2 - Absent Contingency Plan for Rule Ambiguity or Editorial Board Deadlock

## Problem

The plan assumes the editorial board will finalize rules (ordinal marker design, morphology retention threshold, homograph markers) by Month 11 (2027-09-13). However, it does not specify conflict-resolution procedures if linguists, practitioners and learner representatives disagree. Without a formal tiebreaker mechanism and decision authority, rule disputes could stall the board for weeks, compressing pilots or forcing ambiguous rules into Phase 2, where mid-pilot clarifications invalidate earlier assessments.

## Recommendation

By Month 1 (2026-11-13), publish an explicit Editorial Board Charter (2–3 pages) specifying: (1) voting rules (e.g., simple majority with a linguist-review veto limited to ambiguity findings); (2) escalation path if voting deadlocks (e.g., a neutral arbiter from an external linguistics or standards body casts a tie-breaking vote); (3) conflict-of-interest disclosure; (4) term limits (e.g., 2-year terms with staggered renewal). For any rule requiring a tiebreaker, document both the majority and minority positions in the published rule rationale. Establish a hard deadline of Month 10 (2027-08-13) for all rule disputes to be resolved, allowing a 1-month buffer for drafting and public comment before Month 11 (2027-09-13) finalization.

## Sensitivity

A 4-week board deadlock compresses Phase 2 pilots by 3.3% (4 weeks out of 12 months), reducing effective pilot window and inflating measurement error. A forced, ambiguous rule could trigger 10–20% rule misapplication during pilots, confounding results. Escalation to an external arbiter adds $10K–$20K (estimate) in consulting costs and a 2-week process delay if not pre-negotiated.

# Issue 3 - Underspecified Confound Controls and Construct Validity for Gate Metrics

## Problem

The plan assumes improvements in comprehension speed, ordinal error rate, pronunciation consistency and 30-day retention directly indicate Clear English superiority. However, alternative explanations could inflate or deflate observed effects: (a) repeated exposure to ordinals (even in standard form) might improve accuracy without Clear English; (b) learner motivation to participate in a 'new standard' study might boost performance regardless of rule quality; (c) accent proximity to learners' first language might make pronunciation consistency high for both conditions. The plan does not specify control conditions, manipulation checks or confound analyses.

## Recommendation

By Month 5 (2027-03-13), build a construct-validity section into the Outcome Metric Battery Design: (1) identify plausible alternative explanations for each metric; (2) design explicit control conditions (e.g., standard-English ordinals with explicit rule instruction vs. implicit exposure) to isolate Clear English effects; (3) measure manipulation checks (e.g., ask learners post-test which rule system they learned); (4) analyze potential confounds (e.g., regress ordinal error rates on learner baseline literacy, first-language phonology, study motivation). Publish this framework in the pre-analysis plan (Month 11 = 2027-09-13). If inter-rater reliability or effect-size analyses at Month 18 (2028-04-13) reveal confounds larger than expected, conduct additional validation by Month 21 (2028-07-13) rather than proceeding to Month 24 (2028-10-13) with questionable data.

## Sensitivity

If confounds inflate perceived Clear English effects, a false-positive gate outcome launches a weak standard, reducing Phase 3 adoption by 20–40%. A 1-month delay in construct-validity analysis pushes pre-registration to Month 12 (2027-10-13), eliminating the 30-day public-comment window and risking post-hoc challenges to instrument validity. Failure to measure manipulation checks adds 10–15% measurement error, reducing statistical power to detect true effects by 15–25%.

# Issue 4 - Unaddressed Ecosystem Dependencies: Audio Production Bottlenecks and Multi-Accent Pressure

## Problem

The plan commits to 5,000-word core lexicon with pronunciation guidance, recorded in a single anchor accent by Month 12 (2027-10-13). However, audio production at scale (5,000 entries × multiple takes/ratings = 7,500–10,000 files estimate) is bottlenecked by studio availability, rater training and inter-rater reliability calibration (target kappa ≥0.75 proposed). The plan does not estimate studio costs, scheduling lead times or contingency for technical failures. Additionally, pressure to add accents (British, American, Australian, Indian) deferred as 'post-v1.0' creates scope-creep and coalition risk: if standards bodies demand multi-accent coverage, adding accents at Month 12–15 (2027-10-13 to 2028-01-13) could inflate audio budget by $50K–$100K (estimate), straining Phase 1 contingency.

## Recommendation

By Month 2 (2026-12-13), conduct detailed audio-production scoping: (1) reserve a studio or recording partner with firm capacity guarantees (lead time, file delivery, backup protocols) for Months 6–11 (2027-04-13 to 2027-09-13); (2) estimate all-in cost per entry (speaker fees, editing, inter-rater scoring) and scale to 5,000 words—if cost exceeds $15–20 per entry (estimate), explore technology-assisted annotation (speech synthesis for baseline, human raters calibrate/correct) to reduce cost; (3) design inter-rater training and kappa-calibration process (small sample ~100–200 words by Month 9 = 2027-07-13, then full production Months 9–11 = 2027-07-13 to 2027-09-13); (4) publish a clear, board-approved policy by Month 3 (2027-01-13) that defers accent additions to post-v1.0, with a documented process for considering future requests. Identify a contingency provider (secondary studio) by Month 3 (2027-01-13). If, by Month 9 (2027-07-13), costs exceed budget or rater reliability is below target kappa 0.70, pause full production and conduct a 4-week targeted remediation by Month 10 (2027-08-13); if not resolved, flag to editorial board for a potential timeline extension or scope reduction (e.g., record only 3,000–4,000 highest-impact words).

## Sensitivity

A 4-week studio delay compresses audio production from 6 months to 5, reducing rater training and inter-rater calibration time by 17% and increasing kappa-reliability risk (below-target reliability triggers 3–6 week remediation). Uncontrolled multi-accent scope creep adds $50K–$100K (1.4–2.9% of Phase 1 budget estimate, straining contingency). A failure to achieve target inter-rater kappa (e.g., kappa 0.65 instead of 0.75) inflates measurement noise by 20%, reducing statistical power to detect Clear English effects by 10–15%.

# Issue 5 - Incomplete Post-Project Governance and Stewardship Funding Model

## Problem

The plan extends only to Month 36 (2029-10-13), when external funding and formal project governance end. However, the standard will require ongoing maintenance: responding to adoption feedback, managing version/change requests, updating the lexicon, handling disputes over rule interpretation. Without a clear stewardship funding model and organizational home, the standard could atrophy within 12–24 months (by Month 48–60 = 2030-10-13 to 2031-10-13), as corrections and updates accumulate and no one is funded to address them. Adopter organizations would lose confidence in the standard's stability and long-term credibility, reducing Phase 3 adoption.

## Recommendation

By Month 24 (2028-10-13), before the Phase 2 go/no-go decision, define a formal post-project governance and funding model: (1) identify 2–3 potential permanent steward organizations (e.g., language education non-profits, a university consortium, international standards bodies like ISO or ASTM) and approach them by Month 27 (2029-01-13) with a stewardship proposal (estimated annual budget: $150K–$250K for staff, meetings, dispute resolution and lexicon updates); (2) establish a permanent Standards Stewardship Committee (separate from the Phase 1–3 editorial board) with clear decision authority (3–5 permanent members, annual election of rotating seats) and published decision calendar; (3) publish a 5-year stewardship roadmap by Month 36 (2029-10-13) specifying how and when the standard will be reviewed, how change requests will be prioritized and how conflicts will be resolved. Secure written commitment letters from at least one steward organization by Month 33 (2029-07-13); if no commitment is obtained, flag the go/no-go outcome as contingent on stewardship funding, preventing a full Phase 3 public release until stewardship is secured.

## Sensitivity

Lack of stewardship funding by Month 36 (2029-10-13) could cause the standard to stagnate. By Month 48–60 (2030-10-13 to 2031-10-13), perceived instability could reduce Phase 3 adoption by 30–50%, capping learner reach at 15,000–35,000 instead of 100,000+. A 6-month delay in identifying a steward (discovery at Month 30 = 2029-04-13 instead of Month 24 = 2028-10-13) leaves insufficient time to negotiate and fund stewardship before Phase 3 public release, risking a delayed or conditional go/no-go decision. Annual stewardship costs of $150K–$250K (estimate) over 10 years total $1.5M–$2.5M, dwarfing the one-time $3.5M project budget; failure to secure this funding renders v1.0 undefendable as a public standard.

# Review conclusion

This $3.5M, 36-month language-standardization initiative is ambitious and well-scoped for a public-interest program, but it rests on four critical missing or underspecified assumptions:

- Gate Thresholds: Quantitative pass/fail criteria for the four go/no-go metrics must be pre-registered by Month 11 (2027-09-13) to ensure the Month 24 (2028-10-13) decision is defensible and not disputable. Absent thresholds risk false-positive or false-negative gate outcomes, costing $1.2M–$1.4M (Phase 2–3 budget estimate) or damaging credibility long-term.
- Rule Deadlock Resolution: An explicit Editorial Board Charter with voting rules, tiebreaker mechanisms and conflict-of-interest protocols must be published by Month 1 (2026-11-13) to prevent rules from remaining ambiguous or contradictory during pilots.
- Construct Validity and Confounds: The gate metrics must be analyzed for alternative explanations via explicit control conditions and manipulation checks, documented in the pre-analysis plan by Month 5 (2027-03-13). Weak construct validity inflates or deflates observed effects, invalidating the gate outcome.
- Post-Project Stewardship: A funded, committed organizational home for the standard must be identified and committed to by Month 33 (2029-07-13). Without stewardship, the standard will atrophy post-Phase 3, reducing adoption and long-term credibility.

Secondary risks include audio-production bottlenecks (7,500–10,000 files require careful scheduling and inter-rater training), pilot recruitment and retention (targeting 50–100 learners per condition with ≤30% dropout), and timeline compression (a 4–6 week Phase 1 slip compresses pilots by 33–50%, weakening evidence). The Pragmatic Foundation path—invariant prefix ordinals, optional pronunciation overlay, ESL-first supplementary wedge, purpose-built validated metrics and even budget spread—substantially mitigates rule ambition and native-reader rejection risks. However, active management of gate credibility, rule governance, measurement validity and post-launch stewardship is essential from Month 1 (2026-11-13) onward to ensure the initiative delivers on its adoption and evidence-gating promise.

## Numbers and provenance

Do not present invented numbers as facts. For any figure that is not a user constraint or an externally established benchmark, mark what it is, e.g. "(proposed threshold)" or "(estimate)"; mark user-given figures "(user constraint)" only when that helps. Never turn an example value from the input documents ("e.g. ...") into a requirement.