This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** The plan is a three-year, $3.5M program to design and launch "Clear English", a standardized variant of English. It is not executable purely online with zero benefit from physical presence or resources, so it is classified as physical. The physical requirements are:

- Pilot cohorts: adult ESL learners and native speakers working with a safety-critical or technical glossary. Recruiting, enrolling and running them involves in-person classes, sessions or workshops at real sites (adult education centers, ESL programs, industrial or safety-training settings). Usability testing and comprehension assessments (comprehension speed, pronunciation consistency, 30-day retention) benefit from, and in practice require, in-person administration and supervised audio capture of pronunciation.
- Print curriculum: the pilot curriculum is explicitly "print + digital". Printing, producing, distributing and handing out physical learner materials is a physical activity and resource requirement.
- Team and governance: an editorial board, linguistic reviewers, researchers and curriculum designers need workspaces, equipment, and in-person board meetings and review sessions. Staffing and office or co-working space are real-world resources funded by the budget.
- Outreach: engaging academic partners, ESL publishers and standards organizations involves in-person meetings, conferences and workshops, with associated travel.
- Pronunciation and phonology work: building the grapheme-to-phoneme mapping and pronunciation guidance for 5,000 words benefits from recording and testing with real speakers (studio or field recordings), which is physical.
- Safety-critical documentation adoption: limited-scope adoption in technical or safety-critical settings requires testing documents in real operating environments with real workers.

Although the deliverables (standard, dictionary, style guide, licensing policy) are largely documents, the plan depends on human participants, physical materials, travel and facilities. Under the "if in doubt, physical" rule, the plan is physical.