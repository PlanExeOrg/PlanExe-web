Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 14 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 4 | Material risk with plausible path. |
| ✅ Low | 2 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is a linguistic standardization, curriculum design, and pilot-testing program. Success depends on documented rule systems, human learning measured via objective test performance, institutional adoption decisions, and pedagogical engineering—all of which are physical processes (cognition, information systems, organizational behavior). The plan makes no claims that non-physical mechanisms produce real-world learning outcomes and does not require breaking any named law of physics.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of five elements (prefix ordinal markers, optional pronunciation overlay, supplementary ESL-first wedge, purpose-built validated gate metrics, and non-profit certification-mark governance) without independent evidence at comparable scale. No published precedent demonstrates that this system combination works together; Basic English (1930s) adoption faded; spelling reforms failed; ASD-STE100 and ICAO control languages exist but are distinct models. Effect-size assumptions driving the power analysis are unvalidated. Failure cascades to zero adoptable output—returns $0 and kills the initiative.

**Mitigation**: Run four parallel validation tracks (Market, Legal, Technical, Evidence) with two NO-GO gates: (1) Empirical/engineering validity by Month 10 (2027-08-13)—if inter-rater kappa <0.70 or power analysis reveals underpowering, stop Phase 2; (2) Legal/compliance by Month 8 (2027-06-13)—if regulatory approval exceeds 4 months or insurers decline, defer safety cohort. Publish pre-analysis plan with effect-size justification by Month 11 (2027-09-13) and conduct validity study (N=20–30, Months 10–11 = 2027-08-13 to 2027-09-13) to confirm assumptions before Phase 2 launch. Each track produces one authoritative source or supervised pilot showing results vs. baseline.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan names five critical strategic levers (ordinal architecture, G2P depth, adoption wedge, outcome metrics, budget weighting) with business-level mechanisms and owners, but gate thresholds remain "proposed" without empirically justified numeric values. Pre-analysis plan and power analysis are not due until Month 11 (2027-09-13), only about 4 weeks before Phase 2 starts at Month 12 (2027-10-13). If effect-size assumptions are wrong or thresholds require mid-project adjustment, the Month 24 (2028-10-13) go/no-go decision becomes disputable, reducing stakeholder confidence by 20-30% and Phase 3 adoption by that margin.

**Mitigation**: Psychometrician: deliver draft pre-analysis plan with numeric thresholds and power analysis by Month 5 (2027-03-13); conduct validity study (N=20-30, Months 10-11 = 2027-08-13 to 2027-09-13) to confirm effect-size assumptions; pre-register on Open Science Framework by Month 11 (2027-09-13) with board sign-off and public disclosure. Gate thresholds must be locked and defended before Phase 2 starts at Month 12 (2027-10-13).


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies 20 tracked risks with quantified impacts, but second-order cascade effects—particularly recruitment failure → sample-size loss → false-negative gate → 6-month Phase 2 extension → stewardship negotiation compression → unfunded v1.0 orphaning—lack explicit mitigation sequencing or decision thresholds. The gate metrics (ordinal error ≥25%, pronunciation consistency ≥15% above control and significant, with kappa ≥0.70 as a separate validity condition) depend on adequate sample size and measurement reliability, both jeopardized if recruitment/retention miss targets (high likelihood per baseline assumptions) or rater training fails (medium likelihood). If either failure cascades unchecked, the Phase 2 extension consumes the entire $350K reserve and eliminates funding headroom for stewardship contingency (estimated $150K–$250K/year post-launch). The plan acknowledges these cascades in the premortem but lacks actionable monthly KPI dashboards or automatic escalation triggers (e.g., "if forecast completers are below 320 (or enrolment is below the 460 power-analysis target) at the Month 12-13 = 2027-10-13 to 2027-11-13 audit, activate contingency immediately"). This gap creates a 3-6 month discovery lag before corrective action, reducing effectiveness.

**Mitigation**: Program Lead: Establish by Month 1 (2026-11-13) a living risk dashboard with monthly KPI triggers (enrollment targets, dropout rates, spend variance >10%, recruitment velocity). Define automatic escalation thresholds: if forecast completers are <320 (or enrolment is below the 460 planned) at the audit one month after enrolment opens (Month 12-13 = 2027-10-13 to 2027-11-13), immediately activate contingency incentive draw ($20K–$30K, estimate) and flag Phase 2 extension risk to the board within 5 days. Create a Cascade Mitigation Playbook documenting: (1) recruitment failure → sample-size shortfall → statistical power loss → inconclusive gate → 3–6 month extension ($300K–$600K cost); (2) kappa <0.70 → pronunciation metric failure → 4-week extension ($85K) → reserve cap breached → stewardship funding gap emerges. Update the playbook monthly and present findings to the board at Months 6, 12, 18, 24 (2027-04-13, 2027-10-13, 2028-04-13, 2028-10-13) to enable proactive contingency activation before total reserve is exhausted.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the timeline is compressed and contains critical path dependencies that leave minimal buffer for slippage. The Month 24 (2028-10-13) go/no-go gate depends on three prerequisites that must lock by Month 12 (2027-10-13): (1) pre-analysis plan with numeric thresholds pre-registered by Month 11 (2027-09-13)—requiring power analysis from a psychometrician not yet hired; (2) all pilot partner commitments signed by Month 3 (2027-01-13)—with recruitment baseline not yet conducted; (3) inter-rater kappa ≥0.70 confirmed by Month 10 (2027-08-13)—requiring audio production (Months 6–11 = 2027-04-13 to 2027-09-13) on a critical path with no contingency raters pre-screened. If any single item slips 4–6 weeks (audio delivery delay, psychometrician hire delay, kappa retraining), Phase 2 start compresses by 1–2 months, reducing the 12-month pilot window to 10–11 months, cutting effective assessment time by 8–17% and reducing statistical power to detect ordinal error or pronunciation effects by 10–15%. A 6-week slip cascades to either a false-negative gate (no-go on inconclusive data, stranding $1.2M Phase 2 spend) or a 3–6 month extension ($300K–$600K, consuming the entire $350K reserve). The plan acknowledges this (Risk Register entries 6, 12) but lacks explicit critical-path buffers or escalation triggers (e.g., 'if audio studio delivery is >2 weeks late by Month 8 = 2027-06-13, activate the hybrid synthetic-baseline model immediately'). Monthly earned-value tracking and 2-week slip escalation thresholds are missing from the canonical timeline.

**Mitigation**: Program Lead: Establish by Month 1 (2026-11-13) a detailed critical-path schedule with explicit dependencies and 2-week slip escalation triggers for each gate milestone (psychometrician hired Month 2 = 2026-12-13; power analysis draft Month 5 = 2027-03-13; audio studio contract signed Month 3 = 2027-01-13; rater pre-screening complete Month 4 = 2027-02-13; kappa ≥0.70 confirmed Month 10 = 2027-08-13; pre-analysis plan registered Month 11 = 2027-09-13). If any item slips >2 weeks, escalate to editorial board within 5 days with a recovery plan (e.g., hybrid audio model, extended Phase 1 timeline, scope reduction). Conduct monthly critical-path reviews at Months 3, 6, 9 (2027-01-13, 2027-04-13, 2027-07-13) and publish findings to the board.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because committed funding sources and draw schedules exist (Phase 1 $1.1M, Phase 2 $1.2M, Phase 3 $0.85M + $0.35M reserve, total $3.5M user constraint), but critical dependencies and contingency exposure are substantial. Pre-gate reserve capped at $175K (5% of budget) with stacked fallback scenarios (4-week Phase 1 extension ~$85K + psychometric re-validation + recruitment contingency) potentially exceeding the cap by $125K, leaving only $90K unallocated headroom. Post-Phase-2 stewardship ($150K–$250K annually) is unfunded and no steward organization is committed, creating a $1.5M–$2.5M ten-year gap post-v1.0 release. Pilot recruitment/retention shortfall (ample likelihood given 35–45% typical adult dropout vs. 30% plan assumption) forcing 3–6 month Phase 2 extension ($300K–$600K, estimate) would consume entire reserve and create $35K–$250K shortfall. Runway is defensible only if recruitment succeeds and primary technical risks (kappa ≥0.70, power analysis validated) are resolved by Month 12 (2027-10-13).

**Mitigation**: Finance Officer: By Month 1 (2026-11-13), establish monthly earned-value tracking with variance alerts (>10% overrun triggers board review within 5 days); conduct spending audit at Months 3, 6, 9 (2027-01-13, 2027-04-13, 2027-07-13) and document rolling 6-month forecasts. Identify and pre-commit a steward organization with written funding pledge by Month 30 (2029-04-13) before v1.0 release, locking annual stewardship budget ($150K–$250K, estimate) from external sources (endowment, membership, grant). If the steward commitment is not signed by Month 30 (2029-04-13), defer v1.0 release until stewardship is funded; Month 33 (2029-07-13) is the latest point at which a delayed release can still be triggered.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of $3.5M is not substantiated by vendor quotes or scale-appropriate benchmarks. The plan allocates Phase 1 $1.1M for rule specification, lexicon development, and audio production of 5,000 entries, but provides only rough cost estimates (audio "typically $80K–$120K estimate," psychometrics "$150K–$200K estimate") without firm quotes from professional studios, assessment vendors, or comparable language-standardization projects. The plan acknowledges audio production as cost-critical (Months 6–11 = 2027-04-13 to 2027-09-13 budget bottleneck) but defers cost-per-entry validation to Month 4 (2027-02-13), after rule lock and partner commitments are due. A per-entry cost exceeding $20 (the proposed $100K ÷ 5,000 threshold) would trigger a hybrid pivot to speech synthesis, invalidating assumptions and consuming contingency. No normalized cost-per-word benchmarks are cited against comparable lexicon projects (e.g., corpus-based dictionary development, ESL curriculum production). Contingency reserve is capped at 10% ($0.35M), with pre-gate draws limited to $175K (5% of budget)—inadequate against known failure scenarios (Phase 1 extension $85K + recruitment contingency $20K–$30K + psychometric rework $50K+ totals $155K–$165K, leaving near-zero headroom). The plan lacks a detailed cost-realism validation baseline.

**Mitigation**: Finance Officer and Lexicon Lead: Obtain firm, irrevocable quotes from ≥3 professional audio studios by Month 2 (2026-12-13) specifying per-entry cost, delivery timeline (≤4 weeks), take requirements (2+ takes), and backup/contingency rates. Simultaneously, benchmark 5,000-word lexicon production against ≥3 published ESL dictionary or corpus projects (Cambridge, Oxford, learner corpora) documenting cost per entry, including pronunciation audio. Normalize by per-word cost and validate assumptions against benchmarks. Adjust Phase 1 budget or implement the hybrid synthetic-baseline model by Month 4 (2027-02-13) if per-entry costs exceed $20 (estimate).


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan presents four gate-metric thresholds (ordinal error ≥25%, comprehension ≤10% slower, pronunciation consistency ≥15% above control and significant, retention ≥70% of post-test and not below control) and adoption target (≥3 adopters) as single values without confidence intervals, sensitivity analysis, or published benchmarks. Dropout and learner-reach estimates lack worst-case/best-case scenarios. The plan acknowledges uncertainty in risk registers and fallback timelines but does not formalize effect-size sensitivity (e.g., power curves under 20%, 25%, 30% ordinal reduction) or adoption-rate ranges. Canonical facts confirm gates are "proposed thresholds" pending pre-analysis plan finalization by Month 11 (2027-09-13), so contingency analysis is deferred, not absent.

**Mitigation**: Psychometrician: Deliver sensitivity analysis by Month 9 (2027-07-13) showing statistical power under ordinal-error reduction of 20%, 25%, 30% (vs. ≥25% threshold); model sample-size adequacy under 30%, 35%, 40% dropout scenarios. Regulatory Affairs Lead: Model adoption under 1, 2, 3, ≥5 third-party adopter scenarios and resulting learner reach (5,000–100,000 range). Publish ranges and best/worst/base-case projections in the pre-analysis plan registered by Month 11 (2027-09-13).


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because core build-critical components lack foundational engineering artifacts. The 5,000-word lexicon, inter-rater pronunciation-scoring system, and four pre-registered gate metrics are specified at policy level but lack formal technical specifications. No interface contracts exist between the ordinal-marker system and learner-facing materials, the pronunciation overlay and digital/print delivery platforms, or the assessment instruments and pilot curriculum. Acceptance tests for ordinal-error measurement, pronunciation-consistency scoring (Cohen's kappa calibration), and comprehension-speed instruments are not documented. Integration plan and non-functional requirements (accuracy thresholds, latency, accessibility, availability of audio files) are absent. The pre-analysis plan (Month 11 = 2027-09-13) is foundational but lacks implementation detail: no technical specification for how ordinal markers are encoded, tagged, or parsed in documents; no acceptance criteria for rater-training completion or kappa floor validation before pilots; no integration roadmap linking assessment platforms, learner data collection, and gate-decision automation. This gap directly threatens gate credibility: if inter-rater kappa is discovered below 0.70 at Month 10 (2027-08-13) dry run, no formal acceptance test exists to govern whether retraining or fallback (hybrid synthetic model) is triggered. Critical components (pronunciation overlay, marker conversion) are architectural decisions without technical implementation specs.

**Mitigation**: Psychometrician and Engineering Lead: By Month 5 (2027-03-13), deliver a Technical Specification Document (5-7 pages) covering: (1) ordinal-marker encoding (symbol, notation, data format in digital/print); (2) inter-rater kappa measurement procedure (rater selection, training protocol, blind-scoring workflow, dispute resolution, minimum N for statistical validity); (3) acceptance test suite: kappa ≥0.70 on calibration sample (100-200 words, ≥3 raters), pronunciation-error task floor (lowest quartile ≥50% accuracy), comprehension-speed baseline (control ≥85th percentile fluency). (4) Integration map with owners (assessor, linguist, platform lead) and dates (audio delivery Month 11 = 2027-09-13, integration platform testing Month 10 = 2027-08-13, pilot dry-run Month 10 = 2027-08-13). Within 30 days of each gate deadline (Month 10 = 2027-08-13, Month 24 = 2028-10-13), validate acceptance criteria and document pass/fail evidence.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because nearly all critical claims—pilot partner commitments (>=3 ESL programs, >=2 technical organizations), pre-analysis plan with numeric thresholds and power analysis, ethics approval, inter-rater kappa >=0.70, steward organization commitment—lack verifiable artifacts (signed contracts, registered plans, approval letters, or formal agreements). The plan specifies *when* evidence *should* be obtained (Month 3 = 2027-01-13, Month 11 = 2027-09-13, Month 30 = 2029-04-13) but provides no current documentary proof. Most critically, the Month 24 (2028-10-13) go/no-go gate depends on a pre-analysis plan not yet commissioned; the psychometrician hire (Month 2 = 2026-12-13) is not confirmed. Without evidence of these foundational commitments and contracts in hand before Month 3 (2027-01-13), the plan cannot proceed credibly. Per the rubric, critical control/evidence is missing, creating a likely failure mode.

**Mitigation**: Finance/Program Lead: By Month 1.5 (2026-11-28), obtain signed RFPs from >=3 ESL programs and >=2 technical-training organizations; execute MOUs with enrollment guarantees by Month 3 (2027-01-13). Simultaneously, issue a signed contract with the independent psychometrician specifying power-analysis deliverables by Month 5 (2027-03-13) and pre-analysis plan registration by Month 11 (2027-09-13). Retain legal counsel and ethics-review board contact by Month 2 (2026-12-13). Start the steward search by Month 12 (2027-10-13) and request written letters of interest by Month 24 (2028-10-13).


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because 'Clear English Standard v1.0' final deliverable lacks specific, verifiable acceptance criteria beyond policy intent. 'Public standard,' 'reference dictionary,' and 'compliance' are named but unmeasured: no minimum lexicon coverage KPI, no defined ordinal-error rate improvement target, no documented pronunciation-consistency threshold.

**Mitigation**: Editorial Board: By Month 11 (2027-09-13), define SMART acceptance criteria for v1.0 deliverables with KPIs: (1) Reference Dictionary completeness: 5,000 core entries with pronunciation audio (target >=99% coverage); (2) Ordinal Rule clarity: >=90% native-reader and educator comprehension of ordinal marker notation (target >=4/5 on clarity rubric); (3) Pilot-validated metrics: ordinal error reduced >=25%, pronunciation consistency >=15% above control and significant (kappa >=0.70 as a separate validity condition). Document in published specification.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan explicitly positions Clear English as a parallel (not replacement) English variant offered as an optional, supplementary module alongside standard English curricula. The goal statement says 'without mandates or K-12 replacement,' and Decision 3 (Adoption Wedge and Sequencing) selects 'adult ESL programs and publishers' as the lead market. However, the plan does not identify, isolate, or cost the 'gold-plating' features—non-core rule enhancements, optional multi-accent audio recording, authoring-tool automation, or glossary extensions—that add material scope and budget exposure without being foundational to the 5,000-word lexicon, ordinal marker, G2P overlay, or the gate metrics themselves. Specifically: (1) The pronunciation-consistency gate metric hinges on single-accent audio (proposal approved Decision 8), yet the plan defers multi-accent recording to 'post-v1.0' without pre-committing that the additional cost ($50K–$100K estimate for 2–3 accents) will not creep into Phase 1 or Phase 2 budgets. (2) The homograph-disambiguation policy (Decision 7) proposes optional tool-assisted marking ('an authoring-tool plugin'), but this plugin is not funded in v1.0 and its omission risks governance creep: if early adopters demand it, Phase 3 budget ($0.85M nominal, up to $1.2M with reserve) will be diverted from outreach to engineering. (3) The lexicon-expansion trigger (if coverage audits show <85% by Month 8 = 2027-06-13) can push per-entry recording and rater work beyond the budgeted $80K–$120K, consuming contingency. None of these features (multi-accent, plugin, expanded lexicon) is required to satisfy the core project objectives: deliver a defensible 5,000-word core, ordinal rule, G2P overlay, and pass the four gate metrics by Month 24 (2028-10-13). Gold-plating features risk: (1) compressing the gate timeline (e.g., if multi-accent audio is added, audio production extends beyond Month 11 = 2027-09-13, delaying rater training and kappa confirmation past Month 10 = 2027-08-13, triggering the 4-week Phase 1 extension fallback); (2) consuming the $175K pre-gate draw cap (currently capped at $175K for gate-protection draws; multi-accent and plugin development would consume $50K–$100K+, leaving insufficient headroom for recruitment or psychometric rework); (3) spreading scope across adopters without clarity on whose budget funds the add-on (publisher? project?). The plan does not document a formal gold-plating gate: no month/decision point at which optional features are reviewed against the project objectives and either committed to as in-scope or deferred to Phase 3/post-v1.0.

**Mitigation**: Editorial Board: Establish by Month 3 (2027-01-13) a Scope Control Charter (1–2 pages) that defines 'in-scope' for v1.0 as: the 5,000-word lexicon with single-anchor pronunciation, ordinal prefix rule with fixed spoken form, G2P optional overlay, homograph list (no tool), and four gate metrics. Any feature outside this list (multi-accent audio, authoring plugin, lexicon expansion beyond 5,000 words unless coverage audit forces it, additional morphology changes, enhanced homograph marking) is marked 'proposed' and requires explicit budget approval by the editorial board before Month 10 (2027-08-13). For each gold-plating proposal, the proposer must submit a one-page Benefit Case (KPI, owner, cost, alternative drop) to the board; the board votes on inclusion by Month 11 (2027-09-13), before pre-analysis plan lock. Any gold-plating approved must not exceed a $30K–$50K (estimate) total spend cap pre-gate; overages are deferred to Phase 3.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Psychometrician / Assessment Specialist is the single non-delegable expertise required to design defensible gate metrics, conduct power analysis, and pre-register thresholds by Month 11 (2027-09-13). If this rare role is not hired by Month 2 (2026-12-13) or their power analysis reveals underpowering, the Month 24 (2028-10-13) go/no-go decision becomes scientifically disputable, reducing Phase 3 adoption by 20–50% and stranding up to $300K–$400K of the $1.2M Phase 3 budget. Applied measurement expertise in ESL assessment and pre-analysis plan registration is scarce and difficult to replace or fast-track.

**Mitigation**: Regulatory Affairs Manager: Validate psychometrician availability by issuing an RFP to 5–8 qualified candidates by Month 1 (2026-11-13) and securing a signed contract with the top candidate by Month 2 (2026-12-13), specifying deliverables and a penalty clause if power-analysis draft is not delivered by Month 5 (2027-03-13).


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because legality and required approvals for this language-standardization program are substantially undefined or unclear, creating potential showstopper risks. The plan addresses education, adult ESL, and safety-critical documentation contexts, each subject to distinct regulatory regimes, but the controlling statutes and approval authorities are not mapped. Specifically: (1) **Education and ESL Curricula**: No evidence that US state education departments, Ofqual (UK regulator of education standards), TESOL professional standards body, or CEFR governance bodies have been formally engaged to clarify whether Clear English adoption in accredited programs requires compliance review, registration, or curriculum-alignment approval. The regulatory landscape assessment is deferred to Month 8 (2027-06-13) as an informal advice-gathering exercise, not a formal pre-filing with authorities. (2) **Safety-Critical Documentation**: No formal legal determination exists on whether glossaries and procedure labels using ordinal markers, homograph markers, or pronunciation guidance trigger product-liability review, OSHA (Occupational Safety and Health Administration) or HSE (Health and Safety Executive, UK) oversight, or FDA (if medical device contexts arise) premarket review. The plan states 'glossary and labeling only, no live procedures' as a liability containment strategy, but regulators have not confirmed this scope avoids mandatory approval. (3) **Intellectual Property and Name Stewardship**: The plan reserves 'Clear English' as a potential certification mark but has not registered it with USPTO, UK Intellectual Property Office, or international trademark bodies; no clearance search confirms the name is unencumbered. (4) **Data Protection and Ethics**: IRB/ethics approval is targeted for Month 6 (2027-04-13), but the study protocol is not yet submitted; GDPR and US state data-protection compliance are assumed but not audited. The plan acknowledges regulatory risks in the risk register but provides no evidence of pre-filing conversations, clearance opinions, or risk-mitigation agreements with authorities. Without documented approval pathways and regulator engagement, a 4-8 month approval delay (documented forecast in the risk register) could compress Phase 2 pilots by 33-67%, invalidating gate evidence.

**Mitigation**: Regulatory and Stakeholder Affairs Manager: Establish by Month 2 (2026-12-13) a Regulatory Landscape Map identifying all applicable authorities (US: state education departments, OSHA, FDA if applicable, FTC for consumer claims; UK: Ofqual, HSE, ICO for data protection; International: CEFR steerage, ISO language committees). Conduct pre-filing outreach by Month 4 (2027-02-13) with written inquiries to at least one US and one UK education/safety authority requesting non-binding advisory input on the 'glossary and labeling' scope. Obtain written responses by Month 8 (2027-06-13) documenting whether formal approval is required, timelines, and any conditions. If approval is required and timelines exceed 4 months, defer safety-critical pilots to a post-Month-24 (2028-10-13) Phase 2.5 research track ($150K-$300K, estimate, funded from Phase 3 reserve), protecting the main ESL pilot window. Secure IRB/ethics approval by Month 6 (2027-04-13) and publish a Data Protection and Privacy Policy by Month 12 (2027-10-13).


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because post-Month-36 (2029-10-13) stewardship is unfunded ($150K–$250K annually estimated) with no committed steward organization identified. The plan releases v1.0 by Month 30 (2029-04-13) conditional on "a written steward commitment," but steward search does not begin until Month 12 (2027-10-13), and no non-binding letters of interest are solicited until Month 24 (2028-10-13). Without funded long-term maintenance post-launch, the standard will atrophy within 12–24 months (by Month 48–60 = 2030-10-13 to 2031-10-13): change requests accumulate unanswered, errata go unfixed, adopters withdraw confidence, and Phase 3 adoption collapses from ≥3 target to 1–2, negating $600K–$1M in adoption value.

**Mitigation**: Regulatory Affairs Manager: Identify 2–3 steward candidates (university consortiums, language non-profits, standards bodies) by Month 12 (2027-10-13); approach with formal Stewardship Proposal specifying $150K–$250K annually, governance structure, and 10+ year commitment by Month 24 (2028-10-13); secure signed MOU before v1.0 release at Month 30 (2029-04-13) confirming funding source and maintenance responsibilities.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ✅ Low

**Justification**: Rated LOW because the project is a language-standardization and educational-pilot program, not a physical facility or construction project. No zoning, occupancy-code, fire-load, or structural constraints apply. Operational constraints (regulatory approval for pilot use, ethics clearance, data-protection compliance, liability insurance, partner facility access) are the real hard limits; these are documented in the regulatory landscape assessment and risk register, not zoning law. Standard office and audio-capture space exist in all three candidate hubs at budgeted cost.

**Mitigation**: Hub Selection Lead: Confirm the chosen operational hub (Austin, Cambridge, or D.C. metro) by Month 3 (2027-01-13) and execute a 36-month lease or co-working agreement; verify that space meets audio-capture acoustics, partner accessibility, and board-meeting capacity within 30 days of lease signature.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because external dependencies are substantial and single-point-of-failure risks are inadequately mitigated. The plan depends on: (1) 5,000-word audio production (Months 6–11 = 2027-04-13 to 2027-09-13) from a single primary studio with only a 'backup vendor identified by Month 3 (2027-01-13)'—no firm contract for the backup, no contingency budget if primary studio capacity is exhausted or per-entry cost escalates; (2) inter-rater pronunciation scoring at kappa ≥0.70 (target 0.75 proposed) by Month 10 (2027-08-13), with only 3–4 trained raters and no pre-screened secondary panel if primary raters become unavailable, quit, or fail calibration; (3) ≥3 ESL program and ≥2 technical-organization pilot partners for enrollment by Month 13 (2027-11-13), with written commitments due Month 3 (2027-01-13) but no contingency recruitment sites identified or contacted, and a 9-month gap between commitment and enrollment during which partner circumstances (staffing, budgets, competing initiatives) can change; (4) ethics approval and data-protection clearance by Month 6 (2027-04-13), with IRB submission deferred to Month 2 (2026-12-13) and no contingency regulator or ethics body identified if primary review body escalates or imposes lengthy conditions; (5) steward-organization commitment for $150K–$250K per-year post-v1.0 funding (estimated), with no named steward candidate and search deferred to Month 12 (2027-10-13)—if a steward commitment is not signed by Month 30 (2029-04-13), v1.0 release is conditional (Month 33 = 2029-07-13 is the latest point at which a delayed release can still be triggered) and standard risks orphaning by Month 48–60 (2030-10-13 to 2031-10-13). No failover strategy documents parallel suppliers, rater contingency rosters, backup partner sites, secondary ethics reviewers, or alternative steward pipelines. If any single dependency (studio, rater team, partner site, ethics body, steward) breaks unexpectedly, the critical path (audio completion Month 11 = 2027-09-13, rules lock Month 12 = 2027-10-13, pilot enrolment complete Month 13 = 2027-11-13, gate Month 24 = 2028-10-13) experiences 4–8 week delays that compress subsequent phases and reduce data quality. A 6-week audio-studio delay compresses rater training from 6 weeks to 2 weeks, risking kappa <0.70 and triggering a 4-week Phase 1 extension ($85K estimate) that consumes 48% of the pre-gate $175K draw cap.

**Mitigation**: Regulatory Affairs Manager: By Month 2 (2026-12-13), execute signed backup-vendor agreements with ≥2 secondary audio studios committing to surge capacity (500–1,000 files within 2 weeks if primary vendor fails) at locked per-entry rates; confirm in writing. Simultaneously, recruit a secondary rater panel of 2–3 additional trained raters by Month 4 (2027-02-13) (in addition to the primary 3–4) and maintain currency with quarterly training refreshes. Identify ≥2 fallback pilot sites (ESL programs or technical-training organizations) by Month 3 (2027-01-13) with signed letters of interest (non-binding but confirming willingness to enroll ≥30 learners if a primary partner withdraws). Engage secondary IRB/ethics reviewers and conduct pre-submission consultation by Month 1 (2026-11-13) so alternate review pathways are known if primary review is delayed. Start the steward search by Month 12 (2027-10-13), solicit steward-candidate letters of interest by Month 24 (2028-10-13) and initiate formal proposal discussions with ≥3 candidates (not 2) by Month 18 (2028-04-13) to provide negotiation cushion.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because two key stakeholders have fundamentally misaligned incentives that are not yet publicly documented or negotiated. The Finance Department is likely incentivized by quarterly budget adherence and ROI per dollar spent within fixed fiscal periods; the R&D/Linguistics Team is incentivized by linguistic comprehensiveness and long-term evidence rigor. A tension emerges: Finance pressures for lean Phase 1 rules (faster to pilot) and deferred costly features (pronunciation audio, multi-rater validation); R&D insists on robust rule specification, multi-accent validation, and rigorous pilot instrumentation before releasing the standard. The project acknowledges this in Decision 5 (Phase Budget Weighting and Reserve) and Decision 4 (Outcome Metric Battery Design), naming the trade-off between 'evidence rigor versus a fixed budget.' However, no shared OKR exists that bridges the tension. Without explicit alignment, Finance may demand early gate closure or budget cuts (e.g., single accent, 3,000-word lexicon, off-the-shelf instruments) that weaken R&D's evidence base, triggering disputes at Month 9-12 (2027-07-13 to 2027-10-13) when trade-offs must be finalized for Phase 2. The misalignment directly threatens gate credibility at Month 24 (2028-10-13): if a budget squeeze forces cheaper measurement instruments or thinner rule validation, stakeholders can later claim the go/no-go decision was under-evidenced.

**Mitigation**: Editorial Board (Chair, Finance Lead, R&D Lead): Co-author a one-page Shared OKR by Month 3 (2027-01-13) specifying a joint success metric (e.g., 'Deliver defensible gate metrics validated on >=80 per-arm pilots within the $1.2M Phase 2 budget, with no instrument cost exceeding $200K or rule specification cost exceeding $400K'). Establish monthly Steering Meetings (Months 3-12 = 2027-01-13 to 2027-10-13) with Finance Lead and R&D Lead to jointly review actuals, trade-offs and forward forecast. Lock rule specifications and gate metrics jointly by Month 10 (2027-08-13), ensuring Finance sign-off on instrument costs and R&D sign-off on timeline constraints.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical controls are missing: (1) No unified KPI dashboard with defined review cadence, owners, and escalation thresholds. Monitoring activities ('monthly reviews,' 'quarterly panels') are scattered across documents but lack assigned accountability, formal chartering, or decision authority. (2) No mid-project change-control process specifying who approves scope changes (e.g., multi-accent audio, lexicon expansion), at what cost/schedule thresholds escalation is triggered, or how scope creep is rejected. Decision 10 addresses post-v1.0 versioning, not in-flight control. (3) Vague monitoring language: 'we will monitor trends quarterly' without automatic response protocols or stop rules integrated into active governance. (4) STOP rules exist in the premortem but are contingency plans, not active KPI dashboard feedback triggers. Without a unified, high-cadence feedback loop with owners and escalation authority, cost overruns, recruitment shortfalls, and measurement failures risk discovery only at Months 9-12 (2027-07-13 to 2027-10-13) or later, eliminating corrective action windows.

**Mitigation**: Program Lead: Establish by Month 1 (2026-11-13) a Monthly KPI Dashboard Charter specifying: (1) KPI universe (enrollment trend, dropout rate, spend variance, rater kappa trend, rule-dispute velocity); (2) Review cadence (monthly executive dashboard review, escalation board meeting if any KPI drifts >10% from baseline); (3) Owners (Budget Owner, Cohort Manager, Psychometrician, Board Chair); (4) Change-control gate (Scope Change Request form with cost/schedule impact; approval authority by Editorial Board if cost >$25K or schedule >2 weeks). Implement dashboard in Month 2 (2026-12-13) with automatic weekly updates and monthly board briefings. Integrate STOP rules as auto-triggered escalations (e.g., if cumulative spend >$175K pre-gate, halt Phase 2 launch within 5 days).


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan contains at least three High-severity risks with strong coupling: (1) Pilot Recruitment/Retention shortfall (Likelihood high: 35–45% adult dropout vs. 30% plan assumption) cascades to sample-size loss <80 per arm, invalidating statistical power for all four gate metrics (ordinal error, comprehension speed, pronunciation consistency, retention); (2) Gate-threshold pre-registration delay or weak psychometric validation (Likelihood medium-high: psychometrician not yet hired, power analysis not due until Month 5 = 2027-03-13, pre-registration Month 11 = 2027-09-13) renders the Month 24 (2028-10-13) go/no-go scientifically disputable, triggering stakeholder rejection and 20–30% Phase 3 adoption loss; (3) Unfunded post-v1.0 stewardship ($150K–$250K/year, estimate, no steward commitment planned until Month 30 = 2029-04-13) causes standard atrophy within 12–24 months, reducing Phase 3 adopters from ≥3 target to 1–2, negating $600K–$1M in adoption value. A single common-mode trigger is the Phase 2 extension: if pilot recruitment/retention shortfall forces a 3–6 month Phase 2 extension ($300K–$600K), it consumes the entire $350K reserve and compresses stewardship negotiation from 6–9 months (Months 24–33 = 2028-10-13 to 2029-07-13) to 3 months (Months 30–33 = 2029-04-13 to 2029-07-13), making steward commitment unachievable before v1.0 release (Month 30 = 2029-04-13). Alternatively, if inter-rater kappa <0.70 at Month 10 (2027-08-13) forces a 4-week Phase 1 extension ($85K), it consumes 48% of the pre-gate $175K draw cap, leaving only $90K headroom for recruitment contingency ($20K–$30K) or psychometric rework ($50K+), forcing either a budget shortfall or scope cut (e.g., 4,000-word lexicon instead of 5,000, violating user constraint). The three risks are tightly coupled: underpowered recruitment threatens gate credibility, which threatens stewardship commitment, which threatens post-v1.0 viability; technical measurement failures (kappa, power analysis) threaten gate defensibility, which threatens adopter confidence, which threatens stewardship funding. No single dependency is documented to separately mitigate all three.

**Mitigation**: Risk Integration Owner: establish by Month 1 (2026-11-13) a living Cascade Risk Dashboard mapping the three High risks (Recruitment, Gate Defensibility, Stewardship Funding) with explicit dependencies: (1) Forecast completers <320 (or enrolment below 460) at the Month 12-13 (2027-10-13 to 2027-11-13) audit → automatic trigger for Phase 2 extension by Month 15 (2028-01-13) decision → stewardship negotiation compressed to 3 months (Months 30–33 = 2029-04-13 to 2029-07-13) → contingency: defer v1.0 release from Month 30 (2029-04-13) to Month 36 (2029-10-13) to secure MOU; (2) Kappa <0.70 at Month 10 (2027-08-13) → automatic 4-week Phase 1 extension request ($85K draw) → $90K remaining pre-gate headroom insufficient for both recruitment + psychometric rework → contingency: activate hybrid synthetic-baseline model immediately and reduce Phase 1 extension to 2 weeks; (3) Stewardship commitment not secured by Month 30 (2029-04-13) → v1.0 release conditional on signed MOU or deferred to Month 36 (2029-10-13) → automatic board decision rule within 5 days of Month 30 (2029-04-13). Publish dashboard monthly and escalate if any cascade threshold is crossed.