
## Question 1 - How should the $3.5M (user constraint) be split across the three phases, and what reserve is held back and who releases it?

**Assumptions:** Assumption: Roughly even split: Phase 1 $1.1M, Phase 2 $1.2M, Phase 3 $0.85M (proposed), plus a $0.35M (10%, proposed) reserve released by the editorial board only after the Month 24 (2028-10-13) go/no-go. Even spreads match the Pragmatic Foundation path and keep rule work and pilots funded.

**Assessments:** Title: Financial Feasibility Assessment
Description: Adequacy of the phased budget and reserve.
Details: Largest lines are staff, psychometric validation (estimate $150K-$200K), audio capture and pilot administration. Risk: a $300K overrun (estimate) is 8.6% of budget and would cut pilot scope. Mitigation: monthly tracking, a Month 9 (2027-07-13) spending review, fixed-rate vendor contracts by Month 3 (2027-01-13). Benefit: a no-go at Month 24 (2028-10-13) leaves the reserve and most Phase 3 funds unspent.

## Question 2 - Which fixed milestones and buffers govern the gated schedule, including metric pre-registration and the Month 24 (2028-10-13) go/no-go?

**Assumptions:** Assumption: Phase 1 runs Months 0-12 (2026-10-13 to 2027-10-13), Phase 2 Months 12-24 (2027-10-13 to 2028-10-13), Phase 3 Months 24-36 (2028-10-13 to 2029-10-13). Rules draft by Month 11 (2027-09-13) with a 30-day comment window, metrics pre-registered by Month 11 (2027-09-13), go/no-go at Month 24 (2028-10-13), with 2-4 week buffers (proposed) at Months 6, 11 and 18 (2027-04-13, 2027-09-13, 2028-04-13).

**Assessments:** Title: Timeline Feasibility Assessment
Description: Credibility of the 36-month gated plan.
Details: Critical path: board decisions, lexicon, audio, instrument validation, then recruitment. A 6-week Phase 1 slip compresses pilots to about 10 months. Mitigation: monthly critical-path reviews, escalation for slips over 2 weeks, partner commitments secured by Month 3 (2027-01-13). Opportunity: early pre-registration makes the gate defensible and lets Phase 3 planning begin before Month 24 (2028-10-13).

## Question 3 - What core team and external expertise are needed, and how many pilot learners per condition are required?

**Assumptions:** Assumption: Core team of about 8-10 FTE (proposed): project lead, 2-3 linguists, psychometrician, curriculum designers, Phase 2 cohort manager, educator liaison, developer. Pilot target of at least 50-100 learners per condition (estimate), with 15% over-recruitment for attrition.

**Assessments:** Title: Resource and Staffing Assessment
Description: Capacity to deliver rules, materials and pilots.
Details: Psychometric and cohort-management skills are the scarce roles; hire the psychometrician by Month 2 (2026-12-13). Dropout above 30% would weaken statistical power. Mitigation: written enrollment guarantees from 3-4 ESL programs, stipends and certificates, assessments fitted into existing course time. Opportunity: university partners supply raters and graduate assistants cheaply.

## Question 4 - What governance structure decides rules, and what licensing and name-stewardship terms apply?

**Assumptions:** Assumption: Practitioner-leaning editorial board (7-9 members, proposed) with a formal linguist review-and-veto limited to ambiguity and conflict findings. Text and dictionary openly licensed; the 'Clear English' name reserved as a certification mark against a public conformance checklist, decided by Month 6 (2027-04-13).

**Assessments:** Title: Governance and Regulatory Assessment
Description: Decision authority, legitimacy and anti-fragmentation controls.
Details: Practitioner weighting serves adoption, while linguist review limits rule ambiguity. Logged decisions and conflict-of-interest rules support legitimacy. Risk: certification may look gatekeeping to publishers; keep checklist light and free. Add ethics review and data-protection compliance (GDPR/US state law) for pilot audio. Post-Month 36 (2029-10-13) stewardship funding is not yet secured.

## Question 5 - What safety and liability controls apply to pilots using safety-critical glossaries?

**Assumptions:** Assumption: Safety-critical pilots are limited to glossary and labeling exercises, not live operational procedures, until after Month 24 (2028-10-13). All materials carry disclaimers and are reviewed by qualified humans; legal counsel retained by Month 2 (2026-12-13), with liability costs capped near $150K-$200K (estimate).

**Assessments:** Title: Safety and Risk Assessment
Description: Liability exposure from misreading in safety contexts.
Details: Likelihood is low but severity is high; one incident could end the program. Mitigation: formal safety-case review with partners, incident-reporting protocol, insurance strategy by Month 4 (2027-02-13). Because the ESL-first wedge leads, safety exposure is deferred and bounded. Other risks to track: rule ambiguity, educator pushback, fragmentation, all in the register with owners.

## Question 6 - What environmental impacts arise from print curriculum, travel and in-person sessions, and how will they be limited?

**Assumptions:** Assumption: Impact is small. Digital-first materials with limited, on-demand print runs (small pilot batches, proposed) and recycled stock; travel limited to essential partner and board meetings, with virtual meetings as default.

**Assessments:** Title: Environmental Impact Assessment
Description: Footprint of printing, travel and facilities.
Details: Main sources are print runs, flights for outreach and pilot-site travel. Benefit: the on-demand pronunciation overlay keeps printed text standard and avoids reprints when rules change. Risk: print materials still need the pronunciation key, so freeze content before printing. Mitigation: shared co-working space, regional pilot sites, track print volume and travel as simple annual indicators.

## Question 7 - Which stakeholders must be engaged early and in what roles, and how is their feedback fed into decisions?

**Assumptions:** Assumption: Advisory roles from Month 1-3 (2026-11-13 to 2027-01-13) for ESL teacher bodies (e.g., TESOL, IATEFL), 3-4 ESL programs, 2-3 technical training organizations, ESL publishers and one standards body. Separate stakeholder advisory panels meet quarterly; a Stakeholder Alignment Charter is published by Month 6 (2027-04-13).

**Assessments:** Title: Stakeholder Engagement Assessment
Description: Buy-in from educators, publishers and standards bodies.
Details: Educator pushback and publisher capacity are high-likelihood risks. Mitigation: co-design protocols with teachers, an educator liaison (0.5-1.0 FTE, estimate), stipends or continuing-education credit, non-binding publisher letters of interest by Month 3 (2027-01-13). Positioning as supplementary, never replacement, reduces resistance. A Month 18 (2028-04-13) check-in catches misaligned success definitions before Phase 3.

## Question 8 - What operational systems are needed for rule management, the lexicon, audio capture, assessments and the go/no-go?

**Assumptions:** Assumption: Version-controlled rule repository, lexicon database with pronunciation overlay generator, encrypted audio storage with backups by Month 6 (2027-04-13), an assessment and logging platform, and a pre-registered analysis plan. Single anchor accent chosen by Month 3 (2027-01-13); go/no-go thresholds fixed before pilots (to be set by the board).

**Assessments:** Title: Operational Systems Assessment
Description: Tooling and processes supporting pilots and the gate.
Details: Inter-rater reliability target kappa of at least 0.75 (proposed), with extension if below 0.70. Lexicon coverage of at least 85% of pilot text (proposed) to avoid confounds. Risks: audio loss, rule changes mid-pilot invalidating items; mitigate with backups, rule freeze at Month 11 (2027-09-13) and a dry run at Month 10 (2027-08-13). Keep tooling lean to fit budget and post-project maintenance.