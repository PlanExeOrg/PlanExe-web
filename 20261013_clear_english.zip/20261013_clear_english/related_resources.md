## Suggestion 1 - ASD-STE100 Simplified Technical English (Specification maintained by the ASD STE100 Maintenance Group)

A controlled-language standard for technical documentation, originating from aerospace manuals in the 1980s. It comprises about 60 writing rules and a controlled dictionary of approved words with approved meanings. Maintained by the STE Maintenance Group (STEMG) under ASD (AeroSpace and Defence Industries Association of Europe), with periodic numbered issues. Widely used in aerospace, defence, and increasingly other sectors, with certified training and software checkers offered by third parties.

### Success Metrics

Sustained use across international aerospace and defence manuals over several decades (documented by ASD)
Multiple numbered issues released, showing a working change-control cadence
Ecosystem of third-party checkers and training providers (count not verified)
Mandated by some aerospace customers' documentation contracts (extent not verified)

### Risks and Challenges Faced

Writer resistance to restricted vocabulary: mitigated by an approved-word dictionary with examples and training
Specification drift across versions: mitigated by a standing maintenance group and published issues
Compliance verification: mitigated by software checkers and certified training offerings
Unclear mapping between standard and non-standard text: mitigated by approved-meaning entries and explicit not-allowed alternatives

### Where to Find More Information

https://www.asd-ste100.org (official specification site)
ASD STE100 Issue documentation, available from the official site on request

### Actionable Steps

Contact the ASD-STE100 Maintenance Group via the contact form on the official site to ask how they structure change control and licensing
Ask ASD for the current licensing terms for the specification and for guidance on describing partial compatibility
Approach STE training providers listed on the official site to learn about writer conversion effort

### Rationale for Suggestion

Closest real analogue for the safety-critical glossary track and the one-way mapping table the plan chooses. It shows how a controlled English earns trust among technical writers, how a maintenance group handles versioned releases, and how third-party tool vendors build around an open-but-controlled specification. Geographic proximity is limited (European and US industry), but the sector is the target adopter.
## Suggestion 2 - ICAO Language Proficiency Requirements for aviation English

International Civil Aviation Organization standards (Annex 1, Doc 9835) requiring pilots and air traffic controllers on international routes to demonstrate English language proficiency on a six-level scale, with standardized phraseology (ICAO Doc 4444 and Doc 9432). Adopted after language-related accident analyses, with a phased implementation deadline extended by ICAO from 2008 to 2011.

### Success Metrics

Adoption by ICAO member states with national test providers (extent varies; not verified)
Implementation deadline met only after an extension, showing timeline risk
Creation of an ecosystem of aviation English tests and curricula (count not verified)

### Risks and Challenges Faced

Accent diversity and rater consistency: mitigated by a holistic rating scale with defined descriptors and rater training
Uneven national readiness: mitigated by an extended deadline and guidance manual (Doc 9835)
Test quality disputes: mitigated by published guidelines and ICAO-endorsed test-evaluation efforts
Liability and safety scrutiny: mitigated by tying language to documented incident analysis

### Where to Find More Information

https://www.icao.int (search Doc 9835 Manual on the Implementation of ICAO Language Proficiency Requirements)
ICAO Annex 1 and Doc 4444 via the ICAO store

### Actionable Steps

Contact ICAO's Air Navigation Bureau or Montreal headquarters through the official contact page
Reach out to national civil aviation authorities or aviation English test providers for lessons on rater calibration
Ask aviation English researchers at universities with applied linguistics programs about inter-rater reliability experience

### Rationale for Suggestion

A real, documented case of rolling out a standardized English subset in safety-critical settings. It demonstrates how a rating scale, test providers, and training materials were built across many accents, and how phased deadlines and extensions were handled. Relevant to accent anchoring, liability, and gate metric design, although it was a mandate (which Clear English avoids).
## Suggestion 3 - Basic English (C. K. Ogden, 1930s; later Orthological Institute)

A constructed, limited-vocabulary English of 850 words designed by C. K. Ogden as an international auxiliary and teaching language, promoted in the 1930s-1940s with textbooks, a journal and institutional backing. Interest peaked in the 1940s (including attention from Winston Churchill) and then declined.

### Success Metrics

Widespread attention in the 1930s-1940s, including government interest (documented in histories)
Published textbooks and a dictionary (counts not verified)
Long-term adoption remained limited, informing the plan's modest targets

### Risks and Challenges Faced

Learners needed full English anyway: the plan's supplementary positioning addresses this
Limited vocabulary led to awkward phrasing: mitigated here by a 5,000-word lexicon
Dependence on one founder and institute: mitigated by planned board and steward organization
Waning institutional support: mitigated by early stewardship search

### Where to Find More Information

Ogden, C. K., Basic English: A General Introduction with Rules and Grammar (1930)
Encyclopaedia Britannica entry on Basic English
Archives of the Orthological Institute (location not verified)

### Actionable Steps

Contact university libraries with Ogden collections (for example McMaster University, which holds Ogden papers; not verified) for archival material
Consult applied linguistics historians of language planning for lessons learned
Review academic papers on Basic English adoption via Google Scholar

### Rationale for Suggestion

A real precedent for a parallel, intelligible English subset aimed at learners, which shows both promotion tactics and why adoption faded. Useful as a cautionary and design reference for lexicon size, supplementary positioning and stewardship. It is geographically British and historical, so operational detail is dated.
## Suggestion 4 - Secondary: Simplified Spelling Board (US, 1906) and Shavian alphabet (UK, 1960)

Two real English spelling reform efforts. The Simplified Spelling Board, funded by Andrew Carnegie, proposed respelling about 300 words and gained a presidential endorsement attempt before public and congressional pushback. The Shaw Alphabet competition produced the Shavian alphabet and a published edition of Androcles and the Lion.

### Success Metrics

Limited long-term adoption, supporting the no-respelling choice
Some forms (for example 'catalog', 'program') persisted in American usage (extent not verified)

### Risks and Challenges Faced

Public ridicule and political pushback: avoided here by optional overlay
Fragmentation and lack of enforcement: addressed by certification mark and checklist

### Where to Find More Information

Encyclopaedia Britannica: Spelling reform
Shavian alphabet resources at shavian.info (not verified)

### Actionable Steps

Contact the Simplified Spelling Society (UK) via its website for historical material and a view on adoption barriers

### Rationale for Suggestion

Secondary suggestion. Both show native-reader rejection of respelling, supporting the plan's decision to keep standard spellings and use an overlay. Details are historical and less operational.

## Summary

Clear English is a parallel, ESL-first, evidence-gated standard. The closest real precedents are controlled or simplified language standards and constructed or standardized English variants, plus large-scale ESL pronunciation and assessment projects. Directly matching projects (a parallel English variant with prefix ordinals and a pronunciation overlay) do not exist, so the references below cover separate components: controlled-language governance (ASD-STE100), a limited-vocabulary variant with an adoption history (Basic English), a standardized aviation English with a safety-critical rollout (ICAO English Language Proficiency), and a secondary reference on spelling-reform fragmentation. Figures not verified are labelled as such; contacts are organizations or roles, not named individuals.