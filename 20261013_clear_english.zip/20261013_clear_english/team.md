*Roles Needed & Example People*

# Roles

## 1. Project Lead / Program Director

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Program Lead / Director must own end-to-end delivery across 36 months, manage governance, maintain stakeholder confidence and ensure budget discipline. This is a continuous, core accountability role requiring full control and availability from Month 0 (2026-10-13) onward. No procurement-outside-expertise model applies; the role is integral to project success and requires deep institutional knowledge of decisions, timelines and partner relationships.

**Explanation**:
Owns the end-to-end delivery of the standard across three gated phases, manages the core team, editorial board governance, critical-path tracking, and stakeholder escalation. Ensures budget discipline, timeline adherence, and go/no-go decision readiness. This role is essential from Month 0 (2026-10-13) onward to establish governance, secure partnerships and maintain credibility with educators, standards bodies and regulators.

**Consequences**:
Without a dedicated program lead, governance and decision-making becomes diffuse, critical deadlines slip (e.g., board charter delayed, partner commitments unsigned, psychometric validation postponed), budget tracking lapses, stakeholder communication becomes inconsistent, and the Month 24 (2028-10-13) go/no-go gate collapses under competing priorities and unclear authority. Project risk of failure increases by an estimated 30–50%.

**People Count**:
1

**Typical Activities**:
Sarah owns end-to-end delivery across three phases: establishing the editorial board charter and voting procedures by Month 1 (2026-11-13), securing signed partner commitments by Month 3 (2027-01-13), managing monthly critical-path reviews and escalating any slip over 2 weeks, maintaining the project budget tracker and forecasting Phase 2–3 spending, chairing editorial board meetings and logging contested rule decisions, reporting go/no-go readiness to the board at Month 24 (2028-10-13), and transitioning stewardship governance by Month 30 (2029-04-13). She spends roughly 30% of time on governance and decision authority, 30% on timeline and budget discipline, 25% on stakeholder communication and partner relationship maintenance, and 15% on risk escalation.

**Background Story**:
Sarah Chen, based in Austin, Texas, is a program director with 12 years of experience managing large-scale education and standards initiatives. She holds an MBA from UT Austin and a background in public health program management. Sarah led a successful three-year health literacy curriculum rollout across 15 school districts and has deep relationships with education authorities and non-profit partners. She is fluent in Mandarin and English, with experience managing cross-cultural teams. Sarah joined the Clear English project in October 2026 specifically for its evidence-gated approach and adoption-first philosophy, values aligned with her belief that standards succeed through stakeholder buy-in, not mandate.

**Equipment Needs**:
Laptop and project-management software (Microsoft Project, Asana, or Jira) for critical-path tracking and budget forecasting. Video conferencing platform (Zoom, Teams) with recording capability for distributed editorial board and stakeholder meetings. Document version-control system (GitHub, SharePoint) for decision logging and rule drafts. Secure file storage and backup. High-speed internet connection.

**Facility Needs**:
Office space with meeting rooms suitable for monthly editorial board gatherings and stakeholder calls. Private workspace for sensitive governance documents and budget forecasts. Meeting space capacity for 8–12 people (editorial board + project lead + secretary). Virtual-meeting infrastructure for board members in distributed locations. Proximity to pilot partner institutions and stakeholder organizations beneficial but not mandatory given virtual engagement capability.

## 2. Psychometrician / Assessment Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Psychometrician / Assessment Specialist is essential to design and validate gate metrics, ensure pre-registration by Month 11 (2027-09-13), and lead inter-rater calibration. While assessment is often contractor work, the 14-month engagement (Month 2 = 2026-12-13 to Month 15+ post-gate analysis) and requirement for continuous involvement in validation cycles, pre-analysis plan development and kappa calibration makes a full-time role more cost-effective and ensures continuity. Alternatively, independent_contractor if an established assessment firm is engaged for the full Phase 1–2 scope under a fixed deliverable contract.

**Explanation**:
Designs and validates the four gate metrics (ordinal error rate, comprehension speed, pronunciation consistency, 30-day retention), ensures they are statistically sound and pre-registered by Month 11 (2027-09-13), and leads inter-rater training and kappa calibration. Critical for gate credibility: weak or disputable metrics render the Month 24 (2028-10-13) decision non-defensible and undermine partner confidence.

**Consequences**:
Absent psychometric expertise leads to weak, unmeasurable gate criteria; inter-rater reliability falls below kappa 0.70, inflating measurement noise by 20% and reducing statistical power by 10–15%; the Month 24 (2028-10-13) gate decision becomes scientifically disputable, triggering stakeholder rejection and forcing expensive ($200K–$300K) rework or a failed gate that strands Phase 3 funding ($1.2M–$1.4M).

**People Count**:
1

**Typical Activities**:
Marcus designs and validates four gate metrics: commissioning a validity study (N=20–30) in Months 10–11 (2027-08-13 to 2027-09-13), drafting the pre-analysis plan by Month 5 (2027-03-13) with quantitative thresholds (e.g., ordinal error reduction ≥25%), registering the plan on Open Science Framework by Month 11 (2027-09-13), and leading inter-rater training and kappa calibration for pronunciation consistency (target kappa ≥0.75). He advises the editorial board on construct validity concerns, identifies potential confounds (e.g., repeated exposure to ordinals), and designs control conditions to isolate Clear English effects. He conducts a dry-run validity check at Month 10 (2027-08-13) and retrains raters if kappa falls below 0.70, extending Phase 1 by 4 weeks if necessary.

**Background Story**:
Dr. Marcus Okafor, a psychometrician and educational measurement specialist, holds a PhD in Educational Research Methodology from the University of Michigan and has published 18 peer-reviewed papers on validity and reliability in language assessment. He spent 8 years as an assessment director at a major ESL testing organization and has designed inter-rater training protocols for oral-proficiency exams used by over 100,000 test-takers annually. Marcus brings deep expertise in pre-registration, confound control and measurement validity. He was hired by Month 2 (2026-12-13) specifically because the Clear English go/no-go gate depends entirely on defensible, pre-registered metrics; his reputation in applied measurement lends credibility to the gate decision.

**Equipment Needs**:
Statistical software (R, SPSS, SAS, or equivalent) for designing validity studies, calculating inter-rater reliability (Cohen's kappa), and conducting power analysis. Online survey platform (Qualtrics, REDCap) for collecting assessment data if piloting digitally. Reading-assessment instruments (commercial or custom) compatible with Clear English and standard English conditions. Data-analysis and visualization tools (e.g., ggplot2, Excel). Laptop and secure data storage for participant datasets.

**Facility Needs**:
Office space with private work area for confidential psychometric analysis and instrument validation. Access to a quiet testing environment for the small validity study (N=20–30) at Month 10–11 (2027-08-13 to 2027-09-13); could be a university partner's lab or a rented quiet room. Secure server or encrypted cloud storage for pre-analysis plan and sensitive research data. Video conferencing for consultation with the editorial board and external reviewers.

## 3. Linguistic Specialist / Computational Linguist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Linguistic Specialist / Computational Linguist (min 2, max 3 per canonical facts) requires continuous development of rule specification, lexicon and editorial board guidance Months 0–12 (2026-10-13 to 2027-10-13) and ongoing support through Phase 2. This is a core technical role with no clear exit point until rules are finalized and pilots are analyzed. Multiple linguists create redundancy and depth. Full-time employment ensures consistency and availability, particularly during contested rule decisions where external linguistic review cannot substitute for core team expertise.

**Explanation**:
Develops the rule specification (ordinals, morphology retention, homograph disambiguation, grapheme-to-phoneme mapping) and owns the 5,000-word core lexicon. Chairs or advises the editorial board on linguistic consistency and ambiguity resolution. Essential during Phase 1 to finalize rules by Month 12 (2027-10-13) and ensure they are unambiguous before pilots begin.

**Consequences**:
Insufficient linguistic expertise leads to rule ambiguity, internal contradiction, and inconsistent application; editorial board disputes remain unresolved, delaying rule finalization by 4–12 weeks; mid-pilot rule changes invalidate earlier assessments and inflate measurement error; adopters perceive the standard as linguistically incoherent, reducing Phase 3 adoption by 20–40%.

**People Count**:
min 2, max 3, depending on rule complexity and lexicon scope

**Typical Activities**:
Keiko and James lead three rule-specification workstreams: ordinal-marker design, morphology retention threshold, and homograph disambiguation. They draft rule specifications with written rationale by Month 10 (2027-08-13), chair editorial board subcommittees on contested rules, facilitate consensus between linguists and practitioners, and prepare documentation for the 30-day public comment window (Month 11 = 2027-09-13). Keiko leads morphology and homograph work, compiling a ranked list of irregular forms and high-impact homograph pairs from learner-error corpora. James leads ordinal-marker design, proposing the invariant prefix notation and fixed spoken form. Both contribute to the pre-comment rule document (Month 11 = 2027-09-13) and manage rule finalizations by Month 12 (2027-10-13), freezing the rule set before pilots begin.

**Background Story**:
Dr. Keiko Sato and Dr. James O'Brien are two senior linguists co-leading rule specification. Keiko, trained at Cambridge in English phonology and morphology, spent 10 years at Oxford University Press developing English-learning curricula and has published on regularizing irregular verbs in ESL contexts. James, a computational linguist from MIT, specializes in grapheme-to-phoneme systems and has built speech-synthesis lexicons for three Asian languages. Together they bring complementary expertise: Keiko's pedagogical and morphological depth, James's technical and phonetic precision. Both understand the tension between linguistic consistency and learnability and are committed to evidence-based rule choices over pure elegance.

**Equipment Needs**:
Linguistics reference tools (Oxford English Dictionary, major ESL learner corpora, morphological databases). Corpus-analysis software (AntConc, SketchEngine) for mining irregular verbs and high-frequency words. Text-annotation and markup tools (BRAT, Prodigy) for managing lexicon and rule examples. Pronunciation/phonetics software (Praat) for designing phoneme-based rule specifications. Document collaboration tools (Google Docs, Overleaf) for co-authoring rule specifications with the second linguist. Laptop with large monitor for extended writing and analysis.

**Facility Needs**:
Office space shared with curriculum and development team for close coordination on rule clarity and pedagogical fit. Access to university linguistics library or database subscriptions (e.g., Linguistics and Language Behavior Abstracts, Project MUSE) for research on morphology and phonology. Meeting space for editorial board subcommittee discussions on contentious rules (ordinals, homographs). Ideally proximity to or affiliation with a university linguistics department for access to applied-linguistics expertise and student assistants for corpus work.

## 4. Phase 2 Cohort Manager / Pilot Administrator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Phase 2 Cohort Manager / Pilot Administrator is hired by Month 6 (2027-04-13) and runs continuously through Month 24 (2028-10-13) and 30-day follow-up (Month 22–26 = 2028-08-13 to 2028-12-13). This is a single, continuous role requiring hands-on management of 460 pilot participants, coordination with 5–7 institutional partners, weekly tracking and real-time problem-solving. The role is non-negotiable for achieving the pilot's 70%+ retention rate and defensible sample sizes. Full-time is essential; part-time or contractor models lack the availability to respond to recruitment bottlenecks and participant dropouts.

**Explanation**:
Manages recruitment, enrollment and retention of pilot learners (target 460 across 4 arms, >=80 completers per arm). Coordinates with ESL programs and technical-training partners, tracks attendance, manages incentive payments and 30-day follow-up. Essential from Month 6 (2027-04-13) onward to ensure dropout stays below 30% and minimum sample sizes are achieved for gate credibility.

**Consequences**:
Without dedicated cohort management, enrollment lags, dropout exceeds 30% (potentially reaching 40–50%), effective sample size drops below 80 per arm, statistical power degrades by 15–25%, and the gate metrics become inconclusive or invalid; pilot data is unusable, forcing a 3–6 month Phase 2 extension ($300K–$600K additional) or a false-negative no-go that kills a viable standard.

**People Count**:
1

**Typical Activities**:
Rosa manages all aspects of pilot participant recruitment and retention: coordinating with 5–7 partner institutions (ESL programs and technical-training organizations), tracking enrollment toward a target of 115 per arm (460 total), scheduling four in-person assessment sessions per participant across Months 13–24 (2027-11-13 to 2028-10-13), managing participant incentives ($50–$150 per learner, totaling $23K–$69K), conducting 30-day follow-up contact (no later than 60 days post-test), and responding immediately to any participant who misses a session. She maintains a master spreadsheet of all 460 participants and their progress, sends attendance reminders 2 weeks and 1 day before each session, arranges make-up sessions within ±1 week, and flags at-risk participants to the project lead weekly.

**Background Story**:
Rosa Mendoza, the Phase 2 Cohort Manager, is a former ESL instructor with 7 years of classroom experience and 4 years managing student success programs at a large community college in the San Antonio area. She speaks fluent Spanish and English and has strong relationships with ESL teachers and program coordinators across Texas. Rosa has personal experience with the frustration of irregular English morphology and spelling inconsistencies in her own teaching and sees the Clear English project as an opportunity to test evidence-based solutions. She was hired by Month 6 (2027-04-13) specifically to ensure the 460 pilot participants stay engaged and dropout remains below 30%.

**Equipment Needs**:
Participant-management database (custom or off-the-shelf, e.g., REDCap, Qualtrics) for tracking 460 learners across 4 cohorts, attendance, contact information, incentive status and 30-day follow-up. Email and SMS reminders/scheduling system. Spreadsheet software (Excel, Google Sheets) for master participant list and dropout monitoring. Videoconference platform for virtual assessments if any sessions are conducted remotely. Secure encrypted storage for participant contact and incentive data (GDPR/HIPAA-level security).

**Facility Needs**:
Office space (preferably shared with project lead or nearby) for daily participant coordination and rapid response to recruitment/retention issues. Phone line and internet for outreach calls to at-risk participants. Meeting space or videoconference capability for weekly status check-ins with the project lead. Ideally located in one of the pilot hubs (e.g., Austin, Washington DC, Cambridge area) to enable in-person relationship-building with ESL programs and technical-training partners. Travel budget for quarterly on-site visits to pilot institutions (already budgeted in project travel allocation).

## 5. Curriculum Designer / Materials Developer

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Curriculum Designer / Materials Developer (1–2 per canonical facts) must produce pilot-ready learning materials by Month 13 (2027-11-13) and ensure fidelity throughout Phase 2 pilots. This is a continuous design-and-iteration role, not a discrete deliverable (print a curriculum, hand off). Materials must be revised if rules change, adapted to partner settings, and debugged during pilots. One FTE for core ESL module, potentially one for technical-glossary and safety exercises. Full-time employment ensures pedagogical consistency and rapid response to rule clarifications or pilot findings.

**Explanation**:
Designs pilot learning materials (print and digital), assessments, and the pilot curriculum that embeds the Clear English rules and tests comprehension, ordinal accuracy and pronunciation consistency. Ensures materials are pedagogically sound, free from rule errors, and aligned with pilot protocols. Active during Phases 1–2 to produce pilot-ready curriculum by Month 13 (2027-11-13).

**Consequences**:
Absent curriculum design results in pilot materials that are poorly aligned to rules, contain rule errors or pedagogical gaps, and fail to engage learners; assessment instruments become misaligned to the intended Clear English constructs; pilot fidelity is low, confounding results; assessment data is unreliable for the gate decision, reducing credibility by an estimated 20–30%.

**People Count**:
min 1, max 2, depending on breadth of materials (ESL module, technical glossary, safety-labeling exercises)

**Typical Activities**:
David and Elena jointly design pilot learning materials (print booklet and digital module) by Month 13 (2027-11-13), with David leading ESL-module pedagogy and Elena leading technical-glossary design. They embed Clear English rules into scaffolded exercises: ordinal practice (using prefix-marker forms in dates, lists and procedures), pronunciation guidance (optional overlay accessible on digital, printed key for print), and morphology and homograph examples. They conduct dry runs at pilot sites in Month 10 (2027-08-13), identify rule ambiguities or pedagogical misfits, relay findings to the linguistic team for Month 11 (2027-09-13) clarifications, and revise materials to match the final frozen rules by Month 12 (2027-10-13). They support both ESL and technical pilot cohorts with fidelity checks and learner-engagement monitoring Months 13–24 (2027-11-13 to 2028-10-13).

**Background Story**:
David Liu and Elena Rodriguez are two curriculum designers with complementary expertise. David has 6 years of experience designing print and digital ESL materials for a major textbook publisher and knows how to translate linguistic rules into engaging, scaffold learning activities. Elena, a former safety-compliance trainer in the oil and gas industry, has written technical glossaries and procedure guides and understands how clarity, consistency and minimal ambiguity reduce accident risk. Together they design both the ESL pilot module (for adult learners) and the technical/safety-glossary exercises (for the native-speaker cohort). Both are deeply familiar with the tension between pedagogical appeal and rule fidelity.

**Equipment Needs**:
Learning-management system (LMS) or digital content-creation platform (Canvas, Moodle, or proprietary) for delivering pilot materials and embedded assessments. Authoring tools for print and digital materials (Adobe InDesign or equivalent for layout; Articulate Storyline or similar for digital interactivity). Access to Clear English rule specifications and pronunciation guidance (frozen by Month 12 = 2027-10-13). Proofreading and editing software (Grammarly, Microsoft Editor) adapted for Clear English rule-checking. Laptop with dual monitors for design and assessment integration.

**Facility Needs**:
Office space shared with the linguistic team and project lead for rapid iteration and rule alignment. Access to quiet design space for focused curriculum writing and layout work (Months 6–13 = 2027-04-13 to 2027-11-13 are peak production months). Meeting space for dry-run testing with a small pilot group (N=5–10) at Month 10 (2027-08-13); quiet classroom or training room at a partner ESL program or technical-training site. Ideally co-located or virtual-adjacent to pilot partner institutions to enable hands-on material piloting and fidelity checks Months 13–24 (2027-11-13 to 2028-10-13).

## 6. Educator Liaison / Teacher Engagement Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Educator Liaison / Teacher Engagement Specialist (0.5–1.0 FTE) must engage TESOL, IATEFL and pilot teachers from Month 1 (2026-11-13) through Phase 3 adoption planning. This is a sustained relationship-building and communication role, not event-based consulting. One FTE ensures continuous teacher training delivery, buffer between the project team and educators, and early warning of educator pushback. Part-time or contractor models create discontinuity and miss the relational trust-building essential to mitigating educator resistance.

**Explanation**:
Builds and maintains relationships with ESL professional organizations (TESOL, IATEFL), pilot partner teachers, and educators; communicates the rationale for Clear English and delivers teacher training and support during pilots. Surfaces educator concerns early (Months 1–3 = 2026-11-13 to 2027-01-13) and ensures buy-in and compliance. Essential to mitigate educator pushback and foster adoption readiness.

**Consequences**:
Without educator engagement, teachers view Clear English as imposed from outside; non-compliance in pilots is high, rule application is inconsistent, and engagement and retention suffer; public criticism from respected educators damages credibility before and after the gate; Phase 3 adoption declines by an estimated 30–50% even with a positive gate outcome.

**People Count**:
1 FTE or 0.5 FTE part-time, depending on engagement breadth

**Typical Activities**:
Anna engages ESL professional organizations (TESOL, IATEFL and regional chapters) from Month 1 (2026-11-13) onward, co-designs pilot protocols with practicing teachers to increase buy-in, delivers teacher-training workshops on Clear English rules and pilot administration (starting Month 10 = 2027-08-13), and facilitates quarterly advisory panels where pilot teachers surface concerns and offer feedback. She communicates the project's rationale and pilot findings to educators, mitigates teacher resistance by emphasizing that Clear English is supplementary and optional, and gathers early warning signals of educator skepticism. She manages a small pool of teacher stipends ($20K–$40K across Phase 2) to incentivize active participation and co-design engagement.

**Background Story**:
Professor Anna Kowalski, the Educator Liaison, is a 20-year veteran of ESL teacher training and professional development, currently affiliated with a regional TESOL chapter in the Southwest US. She holds a master's degree in TESOL from the University of Arizona and has trained over 500 ESL teachers in curriculum design and assessment. Anna was skeptical of the Clear English project initially—fearing another top-down standard that teachers would resist—but came to champion it after reviewing the evidence-based pilot design and the plan's commitment to supplementary positioning (not replacement) and educator co-design. She brings credibility and trust with the ESL teacher community.

**Equipment Needs**:
Email and video conferencing (Zoom, Teams) for outreach to teacher professional organizations (TESOL, IATEFL) and pilot teachers. Presentation software (PowerPoint, Keynote) for teacher-training workshops. Learning-management system (LMS) or webinar platform (Zoom, GoToWebinar) for delivering asynchronous and synchronous teacher training. Document library or wiki for publishing rationale, FAQs and training materials. Optionally, a survey tool (Qualtrics, SurveyMonkey) for teacher feedback collection during pilots.

**Facility Needs**:
Office space for maintaining relationships, writing training materials and managing educator communications. Access to video-production or presentation space for recording teacher-training modules (Months 10–12 = 2027-08-13 to 2027-10-13) and during Phase 2 for live workshops. Ability to travel (or host virtually) quarterly advisory-panel meetings with ESL teachers; travel budget for 3–4 in-person conferences or regional teacher meetings annually (already budgeted in project outreach). Co-location with major ESL programs or conference venues beneficial but not mandatory if primary mode is virtual.

## 7. Editorial Board Coordinator / Governance Administrator

**Contract Type**: `part_time_employee`

**Contract Type Justification**: Editorial Board Coordinator / Governance Administrator (0.5 FTE estimated) manages recurring meetings, decision logging and conflict escalation, not a full continuous role. Board meetings occur monthly or bi-monthly, decision documentation is episodic, and tiebreaker arbiter engagement is triggered only on disputes. The role is essential but not full-time; 0.5 FTE (20 hours/week) accommodates meeting administration, documentation and follow-up. Could be hybrid with part-time employment + part-time administrative support from the program lead's office.

**Explanation**:
Manages editorial board meetings, records decisions and rationales, tracks rule disputes and escalation to the tiebreaker arbiter, and publishes decision documentation. Ensures the board charter is enforced (voting rules, conflict-of-interest disclosure, timely decisions). Essential from Month 1 (2026-11-13) to establish governance and keep rule finalization on track.

**Consequences**:
Without governance administration, board meetings lack structure, decisions are poorly documented, conflicts go unresolved, and the tiebreaker arbiter is not engaged; rule finalization delays by 4–12 weeks, compressing Phase 2 by 33–100%; stakeholders perceive the board as disorganized and politically divided, undermining credibility and adoption confidence.

**People Count**:
1

**Typical Activities**:
Michael schedules and facilitates all editorial board meetings (monthly or bi-monthly, Months 1–36 = 2026-11-13 to 2029-10-13), documents all voting outcomes and rationales for contested rules, tracks rule disputes and escalates to the external tiebreak arbiter when consensus fails, publishes decision summaries on the project website, and maintains a master decision log. He prepares board packets 1 week before each meeting, records minutes and action items, follows up on assigned workstreams (ordinal marker, morphology, homographs), and ensures the board charter's voting rules and conflict-of-interest procedures are followed. He publishes the draft standard with rationale by Month 11 (2027-09-13) and manages the public 30-day comment window.

**Background Story**:
Michael Torres is a project coordinator with 8 years of experience managing meeting logistics, decision documentation and governance workflows in a non-profit standards-development setting. He previously worked for a consortium managing international education standards and is expert at translating complex technical decisions into clear, accessible decision records. Michael is detail-oriented, unflappable under deadline pressure, and skilled at surfacing consensus and disagreeing-respectfully documenting minority positions. He was brought on to ensure the editorial board's decision-making is transparent, traceable and defensible to external stakeholders.

**Equipment Needs**:
Meeting-scheduling and minute-taking tools (e.g., Doodle, When2Meet for scheduling; professional note-taking software). Decision-logging and tracking system: a shared spreadsheet or simple wiki/Confluence instance for recording all board votes, rationale and escalations. Version-control repository (GitHub, GitLab) for managing drafts of rule specifications and published standards. Email and calendar management. Laptop for administrative support.

**Facility Needs**:
Shared office space with the project lead and editorial board for close coordination on governance. Access to a secure meeting room for recording sensitive board decisions (e.g., conflicts of interest, tie-breaking outcomes). High-speed internet and video conferencing for distributed board members. Document storage and backup system for maintaining decision archives. Could be co-located with program offices or centralized in the project headquarters location.

## 8. Regulatory and Stakeholder Affairs Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Regulatory and Stakeholder Affairs Manager (0.5–1.0 FTE) must engage multiple regulatory bodies, ESL programs, publishers and steward-organization candidates from Month 1 (2026-11-13) through Phase 3 (Month 36 = 2029-10-13). This role involves relationship continuity, regulatory tracking, written submissions to authorities (months of back-and-forth), and steward negotiations that require trust and institutional memory. A 1.0 FTE in Year 1–2 (Phase 1–2) and 0.5 FTE in Year 3 (Phase 3) balances front-loaded engagement with sustained stewardship search. Full-time (or phased) is essential; a contractor engagement for 'regulatory review' misses the relationship work and tracking continuity.

**Explanation**:
Engages regulatory bodies (education authorities, standards bodies, TESOL, IATEFL), technical-training organizations and ESL publishers from Month 1 (2026-11-13) onward; surfaces regulatory risks and approval pathways; secures written partner commitments and steward-organization engagement post-gate. Essential to prevent adoption blocking and ensure institutional partnerships.

**Consequences**:
Absent stakeholder engagement leads to rejection by key adopter groups (educators, standards bodies, regulators) without warning; regulatory approval delays are discovered late (Month 18–24 = 2028-04-13 to 2028-10-13), compressing pilots or blocking deployment; publisher commitments are weak or nonexistent; Phase 3 adoption is near zero; steward funding remains unsecured at Month 33 (2029-07-13), making the standard indefensible as public by Month 36 (2029-10-13).

**People Count**:
1 (0.5–1.0 FTE), depending on number of jurisdictions and stakeholder relationships

**Typical Activities**:
Patricia identifies regulatory bodies whose approval could enable or block adoption (state education departments, Ofqual in the UK, TESOL, IATEFL and CEFR steerage committees) by Month 1 (2026-11-13) and secures written advisory input from at least one US and one UK standards body by Month 2 (2026-12-13). She documents the regulatory landscape and approval pathways by Month 4 (2027-02-13), prepares formal regulatory submissions (e.g., to state boards) by Month 15 (2028-01-13), manages regulatory timelines and escalates approval delays to the program lead. She cultivates non-binding letters of interest from ESL publishers and technical-training organizations by Month 3 (2027-01-13), monitors competitive or aligned standards initiatives (plain-language guidelines, ASD-STE100 updates) quarterly, and identifies steward-organization candidates and approaches them with a formal proposal by Month 24 (2028-10-13).

**Background Story**:
Dr. Patricia Greenfield, the Regulatory and Stakeholder Affairs Manager, is a former education-policy analyst who spent 10 years at a state department of education and now consults on standards adoption with school districts and ESL organizations. She understands the regulatory landscape for education standards in the US and UK, has relationships with accreditation bodies and standards organizations, and knows how to craft regulatory submissions and navigate approval processes. Patricia joined the Clear English project because she believes evidence-based language standards are desperately needed, yet sees the real risk that regulatory inertia or educator resistance could kill the initiative before it gains traction.

**Equipment Needs**:
Secure database or CRM (Salesforce, HubSpot) for tracking stakeholder relationships, regulatory contacts and partner commitments. Email and telephone for outreach to education authorities, standards bodies and publishers. Document-drafting tools for formal regulatory submissions and partnership proposals. Calendar and scheduling systems for managing regulatory timelines and follow-ups. Secure file storage for sensitive regulatory communications and partnership MOUs.

**Facility Needs**:
Office space with private work area for confidential stakeholder negotiations and regulatory filings. Internet and phone infrastructure for managing international relationships with UK (Ofqual), US (state education departments, TESOL) and international (ISO, CEFR) standards bodies. Meeting space for periodic in-person stakeholder convenings or regional travel to attend standards-body meetings and conferences. Travel budget for engagement with regulatory bodies and steward-organization candidates (Months 1–36 = 2026-11-13 to 2029-10-13), with heavier travel in Months 24–36 (2028-10-13 to 2029-10-13) for stewardship search and Phase 3 partnership building.

## 9. Audio Production & Technical Infrastructure Manager

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Audio Production & Technical Infrastructure Manager (Months 2–11 = 2026-12-13 to 2027-09-13) is a time-bounded, specialist role: secure studio capacity, coordinate 5,000-entry recording, run inter-rater training, and deliver encrypted storage infrastructure. While critical, this is a front-loaded, deliverable-based engagement with a clear exit point at Month 12 (2027-10-13) when audio is complete. The role benefits from external vendor relationships (audio studios, hosting/storage providers) that a contractor brings; internal FTE overhead is not justified for an 10-month, specialist task. Alternatively, a full-time employee if internal IT infrastructure and in-house recording are priorities; trade-off: cost and hiring delay vs. control.

**Explanation**:
Secures audio recording studio capacity, manages pronunciation recording of the 5,000-word lexicon, coordinates inter-rater training and kappa calibration for pronunciation consistency scoring, oversees encrypted audio storage, and ensures backup and data-integrity protocols. Essential Months 2–11 (2026-12-13 to 2027-09-13) to deliver pronunciation guidance and meet the Month 12 (2027-10-13) lexicon freeze.

**Consequences**:
Without audio-production oversight, studio scheduling and delivery slip, inter-rater training is inadequate, recording quality is inconsistent, and files are lost or unplayable; inter-rater kappa falls below 0.70, invalidating pronunciation consistency scoring; pronunciation guidance is unusable, weakening the ordinal and G2P fix; Phase 1 extends 4–8 weeks, compressing Phase 2 pilots and reducing data quality for the gate.

**People Count**:
1

**Typical Activities**:
James secures studio capacity and contracts a recording partner by Month 2 (2026-12-13), with firm capacity guarantees for 5,000 entries and 2+ takes each. He budgets and tracks audio-production costs ($80K–$120K, estimate) and pivots to speech-synthesis baseline plus human verification if per-entry costs exceed $20. He designs inter-rater training materials and conducts calibration sessions with 3–4 raters on a 100–200 word pilot sample (Months 9–10 = 2027-07-13 to 2027-08-13), measuring Cohen's kappa and retraining raters if kappa falls below 0.70. He manages encrypted audio-file storage, backup protocols, and GDPR-compliant access controls by Month 6 (2027-04-13), conducts a data-protection audit by Month 8 (2027-06-13), and delivers all 5,000 entries with passing inter-rater checks by Month 11 (2027-09-13).

**Background Story**:
James Okonkwo is a senior audio engineer and digital-infrastructure specialist with 6 years of experience managing large-scale audio-recording projects for language and speech-research programs. He has set up inter-rater training workflows, managed encrypted storage systems for sensitive audio biometric data, and coordinated international recording sessions across multiple time zones. James was contracted specifically because the 5,000-word pronunciation-guidance recording (Months 6–11 = 2027-04-13 to 2027-09-13) is a technically complex, time-bounded deliverable with high quality and reliability requirements: 10,000+ audio files, inter-rater calibration to kappa ≥0.75, secure backup and GDPR-compliant storage.

**Equipment Needs**:
Professional audio recording and editing software (Audacity, Adobe Audition, or studio-grade equivalent). Secure file-transfer and backup systems (encrypted FTP, rsync, or cloud-based backup, e.g., AWS S3 with encryption). Inter-rater reliability assessment tools (spreadsheet or custom database for tracking rater agreement and kappa calculations). Encrypted storage infrastructure (hardware security modules, encrypted cloud servers, or on-premises secure servers) for hosting 10,000+ audio files with access controls and audit logs. Laptop with high-speed storage and processing for managing large audio datasets.

**Facility Needs**:
Coordination and contract management for professional audio studio or language-recording partner (Months 2–11 = 2026-12-13 to 2027-09-13). Quiet studio or recording facility with professional audio equipment for inter-rater training calibration sessions and dry runs (Months 9–10 = 2027-07-13 to 2027-08-13; could be outsourced to a partner studio). Office space for managing studio contracts, tracking delivery timelines and coordinating inter-rater training. Secure on-premises or cloud-hosted server infrastructure for encrypted audio storage, backup and GDPR-compliant access control (location-agnostic; cloud or dedicated server).

---

# Omissions

## 1. Absence of Quantitative Gate Thresholds and Pre-Registration Plan

The plan names four go/no-go metrics (ordinal error rate, comprehension speed, pronunciation consistency, 30-day retention) but does not specify quantitative pass/fail criteria (e.g., 'ordinal error must drop by ≥25%') or sample-size targets. Without pre-registered thresholds fixed before Month 11 (2027-09-13), the Month 24 (2028-10-13) go/no-go decision becomes subjective and disputable, undermining partner confidence and gate credibility.

**Recommendation**:
By Month 5 (2027-03-13), commission the psychometrician to draft a pre-analysis plan specifying: (1) quantitative thresholds for each metric with explicit justification (e.g., ordinal error reduction ≥25% proposed, comprehension speed ≤10% slower than control proposed, pronunciation consistency kappa ≥0.75 proposed, 30-day retention ≥70% proposed); (2) minimum sample sizes per arm (≥80 completers proposed for 80% statistical power); (3) primary outcomes and intention-to-treat rules. Register this plan on Open Science Framework by Month 11 (2027-09-13) and publish publicly 30 days before Phase 2 begins. If pre-registration is not complete by Month 11 (2027-09-13), delay Phase 2 start and gate decision by 6–12 weeks to ensure thresholds are defensible.

## 2. Missing Construct Validity and Confound-Control Framework for Gate Metrics

The plan does not specify how to control for alternative explanations of measured effects. Repeated exposure to ordinals (even in standard form) might improve accuracy independent of Clear English; learner motivation to participate in a novel standard could inflate performance; accent proximity to learners' first language might make pronunciation scores high in both conditions. Without explicit control conditions and confound analyses, the gate metrics become scientifically disputable.

**Recommendation**:
By Month 5 (2027-03-13), build a construct-validity section into the Outcome Metric Battery Design decision: (1) identify plausible alternative explanations for each metric (e.g., repeated exposure, motivation, accent proximity); (2) design explicit control conditions (e.g., standard-English ordinals with rule instruction vs. implicit exposure) to isolate Clear English effects; (3) measure manipulation checks (ask learners post-test which rule system they learned); (4) pre-register confound-analysis plan (e.g., regress ordinal error on baseline literacy, first-language phonology, study motivation). Publish this framework in the Month 11 (2027-09-13) pre-analysis plan. If effect sizes or inter-rater reliability at Month 18 (2028-04-13) reveal confounds larger than expected, conduct additional validity work by Month 21 (2028-07-13) rather than proceeding to the gate with weak data.

## 3. Unspecified Fallback if Inter-Rater Reliability Falls Below Target Kappa

The plan targets Cohen's kappa ≥0.75 (proposed) for pronunciation-consistency scoring, with a floor of 0.70 (proposed). However, no explicit action plan specifies what happens if rater calibration achieves only kappa 0.65–0.70. A weak inter-rater reliability inflates measurement noise by 20%, reducing statistical power to detect Clear English effects by 10–15%, risking a false-negative gate outcome that kills a viable standard or forces expensive rework.

**Recommendation**:
Include in the Phase 1 schedule (by Month 8 = 2027-06-13): design inter-rater training and calibration protocol; recruit ≥3–4 raters with ESL/phonetics background; conduct training on the anchor accent (chosen by Month 3 = 2027-01-13) on a pilot sample of 100–200 words by Month 9 (2027-07-13); measure Cohen's kappa by Month 10 (2027-08-13) and require kappa ≥0.70 (floor) to proceed to full production. If kappa falls below 0.70 at Month 10 (2027-08-13), halt full production, conduct additional rater retraining and calibration (2–4 weeks, extending to Month 10.5 = 2027-08-28 = ~2027-08-28), and retest kappa by Month 11 (2027-09-13). If kappa remains below 0.70, flag to the editorial board for either a 4-week Phase 1 extension (new deadline Month 15 = 2028-01-13) or scope reduction (record only 3,000–4,000 highest-impact words). This ensures pronunciation-consistency scoring meets measurement-reliability standards before pilots begin.

## 4. Undefined Post-Project Stewardship Funding Model and Governance

The plan extends only to Month 36 (2029-10-13), when external funding and formal project governance end. However, the standard will require ongoing maintenance: responding to adoption feedback, managing version/change requests, updating the lexicon, and handling disputes over rule interpretation. Without a clear stewardship funding model and organizational home identified by Month 33 (2029-07-13), the standard could atrophy within 12–24 months (by Month 48–60 = 2030-10-13 to 2031-10-13). Adopter organizations will lose confidence in stability, reducing Phase 3 adoption by 30–50%.

**Recommendation**:
By Month 24 (2028-10-13) (coinciding with the Phase 2 go/no-go decision), identify ≥2–3 potential permanent steward organizations (language-education non-profits, university consortiums, standards bodies such as ISO or TESOL) and document their capacity and mission alignment. By Month 27 (2029-01-13), approach the top candidates with a formal Stewardship Proposal specifying annual budget ($150K–$250K estimate), key responsibilities (responding to change requests, managing conformance claims, issuing errata, leading full review every 3–5 years) and decision authority. By Month 30 (2029-04-13), negotiate a formal Memorandum of Understanding (MOU) with at least one steward organization committing to assume stewardship for ≥10 years; have it signed and published by Month 33 (2029-07-13). Publish a public 5-year Stewardship Roadmap by Month 36 (2029-10-13) documenting review cycles, change-request prioritization, governance-committee composition and dispute-resolution procedures. If no steward commitment is secured by Month 33 (2029-07-13), flag to the editorial board that v1.0 public release is contingent on stewardship being in place, preventing a launch without long-term maintenance capacity.

## 5. Audio Production Bottleneck and Multi-Accent Scope Creep Risk

The plan commits to 5,000-word core lexicon with single-accent pronunciation guidance by Month 12 (2027-10-13). Audio production at scale (5,000 entries × ≥2 takes estimate = 10,000+ files) is bottlenecked by studio availability, rater training and inter-rater reliability calibration (target kappa ≥0.75 proposed). The plan does not estimate studio costs, scheduling lead times or contingency for technical failures. Additionally, pressure to add accents (British, American, Australian, Indian) could emerge at Month 9–12 (2027-07-13 to 2027-10-13), inflating audio budget by $50K–$100K (estimate) and straining Phase 1 contingency.

**Recommendation**:
By Month 2 (2026-12-13), conduct detailed audio-production scoping: (1) reserve a professional recording studio or language-recording service with firm capacity guarantees for Months 6–11 (2027-04-13 to 2027-09-13); document lead times, file specifications and backup protocols in a signed contract; identify a contingency provider by Month 3 (2027-01-13); (2) estimate all-in cost per entry (speaker fees, editing, inter-rater scoring): if cost exceeds $20 per entry (estimate), pivot to hybrid approach—speech-synthesis baseline for all 5,000 words by Month 7 (2027-05-13), then human rater verification on the highest-friction 1,000–1,500 words by Month 11 (2027-09-13); (3) by Month 3 (2027-01-13), publish a board-approved policy deferring accent additions to post-v1.0, with a documented process for future requests; cap scope-creep risk by specifying that accent additions require a formal scope-change proposal with budget impact. (4) By Month 9 (2027-07-13), assess production progress and kappa-reliability status; if kappa falls below 0.70 (floor proposed) or costs exceed budget, halt and conduct 2–4 weeks targeted remediation by Month 10 (2027-08-13); if not resolved, flag to board for Phase 1 extension or scope reduction (record 3,000–4,000 words only, violating the 5,000-word constraint and requiring board waiver).

## 6. Insufficient Contingency Reserve and Pre-Gate Draw Procedure

The plan allocates a $0.35M reserve (10% of budget), with only $175K (5% of budget) available for pre-gate draws. A $300K overrun (8.6% of budget estimate) would exhaust the pre-gate draw cap by $125K, leaving no further contingency before the Month 24 (2028-10-13) go/no-go decision. If Phase 1 extends 4 weeks (~$85K estimate) and Phase 2 encounters unexpected psychometric validation costs or recruitment delays, the remaining headroom ($90K estimate) is inadequate for typical project contingencies.

**Recommendation**:
Establish a clear pre-gate draw procedure by Month 1 (2026-11-13): (1) cap pre-gate draws at $175K (5% of budget, half the reserve), available only for pre-approved, evidence-backed gate-protection needs (e.g., psychometric re-validation, rater retraining, recruitment incentive increases); (2) require the project lead to request draws with written justification to the editorial board, specifying why the expense protects gate credibility and why it could not be anticipated; (3) maintain a running forecast of spending by Month 9 (2027-07-13) and assess whether Phase 2 can proceed on schedule; if remaining pre-gate headroom falls below $90K (estimate) or cumulative overrun exceeds $100K, convene the editorial board at Month 9 (2027-07-13) to decide whether to extend Phase 1 (costing ~$85K per month estimate), reduce Phase 2 scope (fewer cohorts, shorter follow-up) or release additional reserve funds with a board-documented decision. (4) Implement monthly project-status reviews and rolling 6-month spending forecasts from Month 1 (2026-11-13) onward, with escalation to the program lead if any line item tracks >10% over budget.

---

# Potential Improvements

## 1. Clarify Editorial Board Tiebreaker Mechanism and Timeline

The plan specifies an external tiebreaker arbiter for rule disputes but does not detail how to engage the arbiter, timeline for tiebreaker decisions, cost ceiling or how minority-position documentation will be handled. Vague escalation procedures could delay rule finalization, compressing Phase 2 pilots by 4–12 weeks. A formal, pre-negotiated tiebreaker process with clear decision timelines (e.g., arbiter must rule within 2 weeks) ensures rule disputes do not stall the project.

**Recommendation**:
By Month 3 (2027-01-13), the editorial board must identify and secure a written agreement with an external neutral arbiter (e.g., a senior linguist or standards-development expert from an external institution such as a university or ISO body). Document in the Editorial Board Charter: (1) arbiter's decision authority (e.g., 'arbiter is called if voting deadlocks 4–5 after two discussion rounds'); (2) decision timeline (e.g., 'arbiter must render a written ruling within 2 weeks of referral'); (3) arbiter cost (cap at $10K–$20K estimate per project, or $5K per decision estimate); (4) publication protocol ('both majority and arbiter-preferred positions published in rule rationale'). By Month 5 (2027-03-13), have the arbiter's signed agreement on file and publish a one-page summary on the project website explaining the tiebreaker process. If a rule dispute is referred to the arbiter, the project lead tracks the timeline and escalates if the arbiter's decision takes >2 weeks.

## 2. Establish Clear Partner Enrollment Guarantees and Make-Up Protocols

The plan requires ≥3–4 ESL programs and ≥2–3 technical-training organizations to provide ≥115 learners per arm (460 total estimate) and achieve a dropout rate ≤30% (estimate). However, the team-members document does not specify what happens if a partner fails to meet enrollment targets or if a learner misses a session. Vague make-up and escalation procedures could lead to unplanned sample-size reductions and statistical power loss.

**Recommendation**:
By Month 3 (2027-01-13), finalize written partner Memoranda of Understanding (MOUs) that specify: (1) minimum guaranteed enrollment (e.g., 'Partner A commits to enroll ≥75 ESL learners by Month 13 = 2027-11-13'); (2) assessment schedule (e.g., 'four in-person sessions of 60–90 minutes each across Months 13–24 = 2027-11-13 to 2028-10-13'); (3) make-up session protocol ('any learner missing a scheduled session has the option for a make-up within ±1 week'); (4) escalation ('if enrollment falls >10% short of guarantee by Month 14 = 2027-12-13, partner notifies project lead within 2 days and project lead activates backup recruitment'); (5) incentive and payment terms (e.g., '$75 per learner for completion incentive; partner receives $40 per learner-session to cover costs'). By Month 13 (2027-11-13), the Cohort Manager confirms that enrollment meets targets and begins tracking attendance. Document all make-up sessions and attendance deviations in the master participant log to assess dropout trends early.

## 3. Specify Pronunciation Consistency Scoring Procedure and Rater Independence

The plan designates pronunciation consistency as a gate metric requiring Cohen's kappa ≥0.75 (proposed target) inter-rater reliability. However, it does not detail: (1) how raters will be selected and trained; (2) whether raters must be independent of the project team; (3) how audio files will be presented to raters (randomized, blinded to condition); (4) how disagreements will be resolved. Without these procedural details, pronunciation scoring could be biased or inconsistently applied, inflating kappa or introducing rater drift.

**Recommendation**:
By Month 4 (2027-02-13), the psychometrician and audio-production manager must draft a detailed Pronunciation Scoring Protocol specifying: (1) rater recruitment and training (e.g., 'at least 3–4 raters with ESL teaching or speech-pathology background; independent of Clear English development team; trained on reference-accent anchor by Month 9 = 2027-07-13 using a 100–200 word calibration sample'); (2) scoring procedure ('raters score audio files in randomized order, blinded to condition and learner identity; each file scored by ≥2 independent raters; scoring on a validated scale, e.g., 1–5 rating or binary match/mismatch'); (3) inter-rater reliability check (Cohen's kappa calculated on calibration sample by Month 10 = 2027-08-13; target ≥0.75 proposed, floor 0.70 proposed); (4) disagreement resolution ('if raters disagree, a third independent rater breaks the tie; if tie-breaker also disagrees, entry marked as 'unclear' and excluded from scoring'); (5) rater-training documentation ('all raters sign confidentiality agreements and a statement confirming they received training on the scoring protocol'). Publish this protocol in the pre-analysis plan (Month 11 = 2027-09-13) to ensure scoring is transparent and auditable.

## 4. Define Lexicon Coverage Audit Procedure and Expansion Trigger

The plan specifies that the 5,000-word core lexicon must cover ≥85% of pilot running text (proposed threshold) and commits to a coverage audit by Month 8 (2027-06-13), with fixes by Month 10 (2027-08-13). However, it does not specify: (1) which text corpus will be analyzed (pilot ESL curriculum? technical glossaries? both?); (2) how coverage will be calculated (types vs. tokens?); (3) what constitutes an 'expansion' (adding words to the core 5,000, or creating a secondary 500-word block?); (4) cost and timeline if expansion is needed.

**Recommendation**:
By Month 3 (2027-01-13), specify the lexicon-audit scope: (1) coverage will be calculated on the actual pilot curriculum and technical-glossary documents planned for use in Phase 2, plus running text from at least 2–3 existing ESL textbooks; (2) coverage metric is word type coverage ('how many distinct word forms in pilot text are in the 5,000-word list') calculated on the first 10,000 running words (or entire curriculum if <10,000 words) to approximate early-learning engagement; (3) coverage target ≥85% (proposed); (4) if coverage falls short, the 5,000-word list may be expanded by drawing from a pre-compiled secondary candidate list (e.g., the next 500 highest-frequency words from the same corpus used to build the base 5,000). By Month 8 (2027-06-13), conduct the audit and identify any shortfalls. If expansion is needed, allocate $20K–$50K (estimate) for pronunciation recording of new entries and revise recording timeline: record new entries by Month 11 (2027-09-13) (compressing other work or extending Phase 1 by 1–2 weeks). Document the final lexicon and its coverage in the published v1.0 standard.

## 5. Clarify Data Privacy and Participant Consent Workflow

The plan notes that ethics/IRB approval and GDPR compliance are required by Month 6 (2027-04-13) but does not specify the consent workflow or data-retention schedule. Ambiguity could delay ethics approval or create compliance gaps, jeopardizing pilot recruitment or exposing the project to regulatory investigation.

**Recommendation**:
By Month 2 (2026-12-13), the project lead and regulatory affairs manager must engage an ethics review committee (IRB, research ethics committee) and draft a study protocol specifying: (1) research classification (is the pilot human-subjects research requiring IRB review? Likely yes; confirm with the IRB); (2) informed-consent process (in writing, in multiple languages if ESL learners speak different home languages, using plain language; electronic or paper consent; right to withdraw and data deletion); (3) data types collected and retention schedule ('audio recordings: 3 years post-analysis or until learner requests deletion; test scores and demographics: 5 years for replication studies; consent forms: 3 years minimum for compliance audit'); (4) access controls ('authorized research team members only; all team members sign data-use agreements'); (5) storage and security ('encrypted on-premises or cloud server, GDPR-compliant, with backup and audit logs'). Obtain written ethics approval by Month 6 (2027-04-13). By Month 10 (2027-08-13), publish standard informed-consent forms and a Data Protection and Privacy Policy on the project website, clearly stating how long data is retained and participants' rights. Provide all participants a copy of the consent form and privacy policy at enrollment.

## 6. Document Phase 2 Pilot Timeline and Contingency Windows

The plan specifies Phase 2 occurs Months 12–24 (2027-10-13 to 2028-10-13) with enrollment complete by Month 13 (2027-11-13) and data lock by Month 22 (2028-08-13), leaving only 2 months for analysis and gate-decision dossier preparation (Months 22–24 = 2028-08-13 to 2028-10-13). This timeline is compressed and leaves little room for data-quality issues or analysis surprises. Clarifying the pilot schedule with explicit checkpoints and contingency windows improves timeline discipline and reduces gate-decision risk.

**Recommendation**:
Establish a formal Phase 2 schedule and contingency plan by Month 9 (2027-07-13): (1) Enrollment Phase: all recruitment complete by Month 13 (2027-11-13); 1-week buffer for stragglers (to Month 14 = 2027-12-13); (2) Assessment Phase: four sessions per participant across Months 13–24 (2027-11-13 to 2028-10-13); Session 1 by Month 14 (2027-12-13); Session 2 by Month 17 (2028-03-13); Session 3 by Month 20 (2028-06-13); Session 4 by Month 23 (2028-09-13); (3) 30-day follow-up: completed by Month 22 (2028-08-13) (last session Month 23 = 2028-09-13 + 30 days ~Month 24 = 2028-10-13 or slightly later; data collection extended 1–2 weeks if needed); (4) Data lock and quality check: Month 22 (2028-08-13); (5) Analysis and dossier preparation: Months 22–24 (2028-08-13 to 2028-10-13); gate decision Months 24 (2028-10-13). If data quality issues are identified (e.g., >10 files corrupted, dropout exceeds 35%, inter-rater kappa <0.70 in preliminary checks), flag to the editorial board by Month 21 (2028-07-13) with options: (a) extend Phase 2 by 3–6 months for remediation or additional data collection; (b) proceed with inconclusive data and conditional gate decision; (c) conduct targeted re-assessment on a subset of participants. Document all contingency triggers and board-decision authority in the Phase 2 Project Plan by Month 12 (2027-10-13).

## 7. Specify Licensing Model Decision Criteria and Timeline

The plan states that a Licensing and Name Stewardship decision will be made by Month 6 (2027-04-13), choosing between three options: (a) permissive open license with no name restrictions; (b) name-as-certification-mark with a published conformance checklist; (c) share-alike license requiring divergent works to adopt a distinct name. However, it does not specify which decision criteria (ease of adoption, protection against fragmentation, governance overhead) will weigh most heavily or who decides in case the editorial board is divided.

**Recommendation**:
By Month 3 (2027-01-13), the regulatory affairs manager must commission a legal analysis (estimated $10K–$20K) comparing the three licensing scenarios on: (1) adoption friction (ease for publishers to adopt); (2) fragmentation risk (likelihood of non-conforming variants); (3) governance overhead ($cost and staff time for certification/dispute resolution); (4) perceived fairness/openness (stakeholder perception of gatekeeping). By Month 4 (2027-02-13), present the analysis to the editorial board with a recommendation. Establish a board vote by Month 5 (2027-03-13) with clear voting rules (e.g., simple majority; if tied, program lead + external arbiter decide). The chosen model must be published with explicit rationale by Month 6 (2027-04-13). If the board selects certification mark (option b), publish a free, light conformance checklist by Month 12 (2027-10-13) specifying exactly what materials must do to qualify as Clear English, with a goal of reducing gatekeeping perception and enabling fast approval for most straightforward adaptations.

## 8. Establish Monthly Budget Tracking and Spending Forecast Protocol

The plan mentions budget controls and a Month 9 (2027-07-13) spending review but does not specify: (1) who tracks spending monthly (project lead? dedicated finance person?); (2) what spending forecast tool is used; (3) what variance thresholds trigger escalation (e.g., >10% over budget on a line item?); (4) escalation procedure. Without clear financial discipline, budget overruns can accumulate silently, consuming contingency reserves without board awareness.

**Recommendation**:
By Month 1 (2026-11-13), establish a monthly budget-tracking system: (1) project lead or a part-time finance administrator maintains a detailed spending log in a shared spreadsheet or accounting system, tracking actual spend vs. budget for each major line item (staff, psychometrics, audio production, pilot incentives, travel, etc.) monthly; (2) by the 5th business day of each month, produce a summary dashboard showing year-to-date actuals, forecast-to-completion, and variance (actual spend % of monthly budget allocation); (3) variance threshold: escalate to the editorial board if any line item is >10% over budget or if cumulative overrun exceeds $50K in a single month (estimate); (4) at Month 9 (2027-07-13), conduct a formal Phase 1 spending review: assess whether Phase 1 is on budget; if overrun >$100K, convene the board to decide whether to extend Phase 1, reduce Phase 2 scope or release additional reserve funds; (5) establish rolling 6-month spending forecasts at Months 9 (2027-07-13), 15 (2028-01-13), 21 (2028-07-13) and 27 (2029-01-13) to identify future budget gaps early and allow mid-course corrections. Document all budget decisions and board actions in the decision log maintained by the governance administrator.

## 9. Define Pilot Fidelity Monitoring and Rule-Compliance Checkpoints

The plan specifies that curriculum designers will conduct dry runs and support fidelity checks during pilots (Months 13–24 = 2027-11-13 to 2028-10-13), but does not detail: (1) what 'fidelity' means (consistent rule application? all rules taught? rules taught in the specified order?); (2) how fidelity will be measured (classroom observations? curriculum deliverable reviews? learner quiz on rule accuracy?); (3) how rule violations will be corrected. Poor fidelity could introduce confounds (learners in one site receive incomplete rule instruction), inflating measurement noise and weakening gate evidence.

**Recommendation**:
By Month 12 (2027-10-13), the curriculum design team must document a Fidelity Monitoring Protocol specifying: (1) definition of fidelity: ('Clear English' cohorts are taught all core rules (ordinals, morphology, homographs, pronunciation guidance) in the prescribed order and frequency; control cohorts receive standard-English instruction); (2) fidelity measures: (a) instructor compliance checklist (curriculum designers or an independent observer confirm that each of the 4–6 core rules was taught in the prescribed sessions); (b) learner comprehension check (brief 5–10 minute quiz after each rule unit, scored to confirm learners understood the rule); (c) delivery logs (instructors record which rules were taught each session and any deviations); (3) fidelity monitoring schedule: Month 14 (2027-12-13) initial site visit to all partners; Month 17 (2028-03-13) midpoint fidelity audit (review delivery logs and conduct random classroom observations); Month 23 (2028-09-13) final audit; (4) corrective action: if fidelity is <80% (estimated) at any site by Month 17 (2028-03-13), the curriculum team contacts the instructor, reviews the lesson materials, and provides coaching; if fidelity remains <80% by Month 20 (2028-06-13), flag to the project lead for consideration of excluding that site's data or requiring re-teaching. Document all fidelity findings in the gate-decision dossier (Months 22–24 = 2028-08-13 to 2028-10-13) to contextualize any low ordinal-accuracy or pronunciation-consistency scores.