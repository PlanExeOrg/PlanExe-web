# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Applied Psychometrician & Assessment Design Specialist

**Knowledge**: Educational measurement, validity and reliability analysis, pre-analysis plan design, inter-rater agreement (Cohen's kappa), statistical power analysis, ESL assessment instruments

**Why**: The pre-registration of four gate metrics (ordinal error, comprehension speed, pronunciation consistency, 30-day retention) by Month 11 (2027-09-13) is critical to project credibility. Current thresholds are proposals; expert will lock defensible, empirically justified numeric targets and ensure the Phase 2 go/no-go decision is not disputable. Weak or absent thresholds directly threaten gate validity and Phase 3 adoption (20–50% loss noted in risk register).

**What**: Design and pre-register a quantitative assessment battery: specify minimum sample size per arm (justifying the ≥80 completers proposal), primary and secondary outcomes, intention-to-treat rules, rater reliability targets (kappa ≥0.70 floor), and pass/fail thresholds for each metric. Deliver a pre-analysis plan draft by Month 5 (2027-03-13) for board review and formal registration by Month 11 (2027-09-13).

**Skills**: Instrument validation, experimental design, effect-size estimation, power analysis, inter-rater calibration, preregistration workflow (OSF, similar platforms), ESL assessment literacy

**Search**: psychometrician language testing ESL assessment design, applied measurement specialist educational validity, Cohen's kappa inter-rater reliability training

## 1.1 Primary Actions

- By Month 1 (2026-11-13 at 09:00), hire an independent psychometrician (signed contract, fixed deliverables) and initiate a phased pre-registration workflow: validity study (N=20–30) by Month 5 (2027-03-13), final PAP with empirically grounded thresholds by Month 8 (2027-06-13), pre-registration to OSF by Month 10 (2027-08-13). Do not defer to Month 11 (2027-09-13). Publish thresholds and power justification publicly immediately after pre-registration.
- By Month 2 (2026-12-13 at 10:00), conduct a mini-pilot (N=20–30 ESL and technical learners, 2–3 partner sites, 2 assessment cycles, Months 2–4 = 2026-12-13 to 2027-02-13). Document dropout timing, reasons, incentive sufficiency and assessment burden. Use findings to calibrate retention contingencies and revise enrolment protocols by Month 4 (2027-02-13).
- By Month 3 (2027-01-13 at 10:00), obtain signed Memoranda of Understanding (not letters of intent) from ≥3 ESL programs and ≥2 technical/safety organizations, with explicit clauses: minimum learner guarantees per partner, liquidated damages ($500–$1K per missing learner, estimate) for shortfalls, 30-day notification of recruitment problems, and escalation contacts. Ensure non-repudiability via institutional signatures and board attestation.
- By Month 2 (2026-12-13 at 14:00), define and publish the reference accent anchor specification (2–3 pages): vowel inventory, key consonant contrasts, stress patterns, 20–30 exemplar recordings. Provide to all raters by Month 7 (2027-05-13).
- By Month 4 (2027-02-13 at 10:00), pre-screen 6–8 candidate raters using 50-word calibration samples; select top 3–4 by kappa ≥0.75 on pilot sample. If no raters achieve ≥0.70 by Month 6 (2027-04-13), pivot to hybrid model: synthetic TTS baseline + human verification of 1,500–2,000 highest-friction words only by Month 11 (2027-09-13).
- By Month 6 (2027-04-13 at 09:00), hire the Phase 2 Cohort Manager (1.0 FTE) with explicit retention accountabilities: track attendance, manage incentives, conduct mid-phase (Month 18 = 2028-04-13) check-ins, implement dropout-response protocols (24-hour outreach + one make-up session). Link cohort manager bonus (10–15% of base, estimate) to retention ≥70% by Month 22 (2028-08-13).
- By Month 10 (2027-08-13 at 12:00), measure inter-rater Cohen's kappa on the full micro-pilot sample (200–500 words). If kappa ≥0.70, proceed to full recording. If kappa <0.70, immediately implement hybrid model (synthetic baseline + verification) and flag to editorial board for Phase 1 extension decision by Month 10.5 (2027-08-28).
- By Month 12 (2027-10-13 at 15:00), establish enrolment contingency: if recruitment is tracking below ≥115 per arm by Month 12 (2027-10-13) end, immediately activate a standby cohort of 40–50 learners (cost ~$30K–$50K, estimate) with expedited incentive and partner-payment processing by Month 13 (2027-11-13).
- By Month 24 (2028-10-13 at 14:00), do not issue a go decision unless all four gate metrics meet pre-registered thresholds AND validity conditions hold: ≥80 completers per arm, 30-day follow-up completion ≥70%, inter-rater kappa ≥0.70. Document minority positions and dissenting board votes in the published gate dossier.

## 1.2 Secondary Actions

- By Month 1 (2026-11-13 at 09:00), publish the Editorial Board Charter with explicit voting rules, tiebreak arbiter mechanism (external neutral, costs $10K–$20K, estimate), conflict-of-interest disclosure and term limits. Establish rule-specification workstreams with clear owners for ordinals, morphology, homographs and pronunciation scoring.
- By Month 2 (2026-12-13 at 11:00), retain legal counsel specializing in product liability, data protection and standards governance. Commission a liability risk analysis for safety-critical pilots: scenarios where Clear English misreading could cause harm, regulatory bodies that might investigate, insurance requirements, and disclaimer language (cost $10K–$20K, estimate).
- By Month 2 (2026-12-13 at 09:00), engage an Institutional Review Board or Research Ethics Committee to determine if Phase 2 pilots require formal human-subjects ethical review. Prepare study protocol (learner population, intervention, data collection, retention, storage) and submit for expedited review.
- By Month 3 (2027-01-13 at 15:00), commission a 3-page licensing and name-stewardship analysis (lawyer, IP specialist): compare fully permissive open license, certification-mark model, and share-alike license. Document advantages, enforcement costs and fragmentation risks of each (cost $5K–$10K, estimate).
- By Month 4 (2027-02-13 at 12:00), if pursuing safety-critical pilots, secure product liability insurance covering the standard and pilot materials (coverage ≥$1M–$5M per incident, estimate). If insurance cost exceeds $50K annually (estimate), scale back safety pilots to glossary and labeling only, not live procedures.
- By Month 5 (2027-03-13 at 12:00), secure the external tiebreak arbiter's written agreement, fee schedule and conflict-of-interest attestation. Establish escalation procedures for rule disputes reaching the arbiter by Month 8 (2027-06-13).
- By Month 6 (2027-04-13 at 10:00), publish the chosen Licensing and Name Stewardship Policy (2–3 pages): legal protection mechanism for 'Clear English' mark, public conformance checklist, third-party certification process, dispute resolution and costs (max $5K–$10K per dispute, estimate).
- By Month 6 (2027-04-13 at 13:00), determine whether formal regulatory submissions (to Ofqual, state education departments, safety regulators) are required in pilot jurisdictions. Identify blocking requirements and approval timelines (4–8 months, estimate). Prepare submissions and identify regulatory advisors by Month 12 (2027-10-13).
- By Month 8 (2027-06-13 at 13:00), finalize and publish a Data Protection and Privacy Policy: what data are collected, retention periods, access controls, encryption protocols, learners' deletion rights. Publish plain-language informed-consent forms and data-use agreements by Month 10 (2027-08-13).
- By Month 12 (2027-10-13 at 10:00), establish a standing Standards Stewardship Committee (3–5 board members, 2–4 hours/month estimate) with authority to review third-party conformance claims, issue guidance on non-conforming forks, maintain public registry of certified materials. Publish committee charter and decision criteria.
- By Month 12 (2027-10-13 at 14:00), initiate steward search: identify 2–3 candidate organizations (non-profits, university consortiums, standards bodies) with capacity for $150K–$250K annual stewardship budget (estimate). Prepare 1-page candidate summaries and preliminary approach strategy.
- By Month 18 (2028-04-13 at 10:00), conduct first regulatory check-in with advisory partners (TESOL, standards bodies, education authorities) to flag anticipated Phase 2 pilot design and gather early feedback on approval pathways. Document any concerns or objections in a risk summary.

## 1.3 Follow Up Consultation

At the next consultation, discuss: (1) Psychometrist hiring timeline and pre-analysis plan schedule—confirm whether a validity study by Month 5 (2027-03-13) is feasible with current budget and staffing. (2) Mini-pilot design and site selection—identify specific ESL programs and technical-training organizations to approach for the Month 2–4 (2026-12-13 to 2027-02-13) mini-pilot. (3) Audio production and rater fallbacks—confirm whether hybrid synthetic + verification model is acceptable if human inter-rater kappa is <0.70. (4) Steward candidates and funding models—identify organizations with sufficient financial stability and mission alignment to sustain $150K–$250K annual stewardship post-Month 36 (2029-10-13). (5) Regulatory and standards-body engagement strategy—clarify which jurisdictions require formal approval before pilots can operate and whether research-study framing can bypass some delays.

## 1.4.A Issue - Pre-Registration and Psychometric Validation Are Dangerously Underspecified

The project plan specifies four gate metrics (ordinal error ≥25% reduction, comprehension speed ≤10% slower, pronunciation consistency ≥15% above control, 30-day retention ≥70%) as 'proposed thresholds,' not pre-registered. The psychometrician hire is scheduled for Month 2 (2026-12-13), but the pre-analysis plan (PAP) is not due until Month 9 (2027-07-13), with pre-registration by Month 11 (2027-09-13)—only 30 days before Phase 2 pilots begin. This compressed timeline creates three failures: (1) no pilot validity study (N=20–30) to calibrate thresholds before they are locked; (2) no time to correct instrument ambiguity if the dry run at Month 10 (2027-08-13) exposes flawed items; (3) post-hoc claims by educators and regulators that thresholds were rigged or arbitrary, undermining the gate decision credibility that is the entire epistemic foundation of the project.

### 1.4.B Tags

- psychometrics-timeline-compression
- pre-registration-delay
- validity-study-absent
- gate-credibility-risk
- threshold-not-empirically-justified

### 1.4.C Mitigation

Hire the psychometrician by Month 1 (2026-11-13) (not Month 2 = 2026-12-13) and commission a phased deliverable: (1) By Month 3 (2027-01-13), submit a draft instrument specification, item pool and effect-size justification. (2) By Month 5 (2027-03-13), conduct and complete a small pilot validity study (N=20–30 adult ESL learners and native speakers, 2–3 assessment sessions) to estimate effect sizes and refine items. (3) By Month 8 (2027-06-13), deliver the final pre-analysis plan with numeric thresholds backed by observed effect sizes, not proposals. (4) Pre-register by Month 10 (2027-08-13) (not Month 11 = 2027-09-13), allowing 6 weeks for editorial board review and early third-party comment. If a validity study is not feasible by Month 5 (2027-03-13), defer Phase 2 pilots and extend Phase 1 by 8–12 weeks (cost ~$170K–$255K, estimate) to establish credible baselines.

### 1.4.D Consequence

Without pre-registered, empirically justified thresholds, the Month 24 (2028-10-13) go/no-go decision will be scientifically disputable. Educators and standards bodies will claim the thresholds were set to produce a predetermined outcome, reducing Phase 3 adoption by 20–50% and triggering public criticism. A false-positive gate (passing weak evidence) could launch a flawed standard; a false-negative (rejecting real effects) wastes $1.2M on inconclusive pilots and forfeits 12 months' credibility building.

### 1.4.E Root Cause

The project plan prioritizes timeline compression over epistemic rigor. Hiring the psychometrician 1 month after project start, then compressing the validity study, instrument refinement and pre-registration into 9 months, reflects an assumption that thresholds can be proposals until Month 11 (2027-09-13). This assumption is false: standards bodies, funders and educators demand empirically grounded thresholds locked before evidence collection begins. The root cause is insufficient allocation of Phase 1 time and budget to psychometrics.

## 1.5.A Issue - Pilot Recruitment and Retention Strategy Lacks Contingency Depth and Early Verification

The plan specifies signed commitments from ≥3 ESL programs and ≥2 technical organizations by Month 3 (2027-01-13), with enrolment beginning Month 12 (2027-10-13) (9 months later) and completion by Month 13 (2027-11-13). This 9-month lag creates three risks: (1) signed letters are non-binding or evaporate if institutional circumstances change; (2) no early verification of learner eligibility, willingness or capacity until Month 12 (2027-10-13), when reversal costs are maximal; (3) no pilot recruitment trial run (mini-pilot, N=20–30) to test assessment logistics, dropout drivers and incentive adequacy before full-scale enrolment. The plan budgets for a 30% dropout tolerance but provides no data-driven dropout prediction, contingency learner pools, or escalation triggers (e.g., 'if dropout exceeds 20% by Month 15 = 2028-01-13, recruit an additional cohort of 40–50').

### 1.5.B Tags

- recruitment-timeline-lag
- non-binding-commitments
- no-mini-pilot
- dropout-contingency-absent
- retention-strategy-reactive

### 1.5.C Mitigation

(1) By Month 2 (2026-12-13), recruit and run a mini-pilot (N=20–30 adult learners and native-speaker technical trainees, at 1–2 partner sites) through at least 2 full assessment cycles (Months 2–4 = 2026-12-13 to 2027-02-13). Document actual dropout, reasons for attrition, dropout timing, incentive sufficiency and assessment burden. (2) By Month 4 (2027-02-13), use mini-pilot data to calibrate a dropout-prediction model and revise enrolment and retention protocols. (3) By Month 3 (2027-01-13), obtain signed Memoranda of Understanding (not just letters) with explicit clauses: guaranteed learner supply with liquidated damages ($500–$1K per missing learner, estimate) if recruitment targets are missed; institution's escalation contact and 30-day notification of shortfalls. (4) By Month 6 (2027-04-13), conduct a recruitment triage: identify learners at high dropout risk (e.g., attendance history, work instability) and apply differentiated retention tactics (higher incentives, flexible scheduling, peer cohorts). (5) Establish an escalation trigger: if dropout exceeds 20% by Month 15 (2028-01-13), immediately recruit a standby cohort of 40–50 learners (cost ~$30K–$50K, estimate) to reach the minimum 80 per-arm threshold.

### 1.5.D Consequence

If pilot recruitment falls short or dropout exceeds 30%, effective sample size drops below 80 per condition, reducing statistical power to ~60% (estimate). This inflates the Type II error (false-negative) risk: real Clear English effects are not detected, triggering a false-negative gate outcome and a no-go decision despite potential efficacy. Alternatively, retention shortfalls compress the data-collection window and force rushed, incomplete 30-day follow-up assessments, invalidating the retention metric. Either path wastes Phase 2 budget (~$1.2M) and forces a 6-month extension (cost ~$300K–$600K, estimate) or project termination.

### 1.5.E Root Cause

The recruitment strategy treats pilot partners as static commitments rather than active collaborators with changing capacity. The 9-month lag between signed commitments and actual enrolment reflects an assumption that letters of intent guarantee delivery without ongoing relationship management. The plan lacks early verification (mini-pilot) and contingency learner pools, indicating insufficient budgeting for recruitment risk and retention management. The cohort manager is hired at Month 6 (2027-04-13), after recruitment design should be finalized, creating a downstream, reactive posture.

## 1.6.A Issue - Inter-Rater Reliability and Audio Production Timeline Creates a Critical Single-Point Failure

The plan specifies audio recording of 5,000 lexicon entries (≈10,000 files at 2 takes) during Months 6–11 (2027-04-13 to 2027-09-13), with inter-rater training and calibration during Months 8–10 (2027-06-13 to 2027-08-13). If inter-rater Cohen's kappa falls below 0.70 at Month 10 (2027-08-13), the fallback is '2–4 weeks additional retraining.' This assumes retraining succeeds, but provides no contingency if kappa remains ≤0.70 after retraining. The plan proposes a 4-week Phase 1 extension (~$85K cost, estimate) as the only fallback, but this single extension does not address the core failure modes: (1) selected raters may be unsuitable for pronunciation judgement (accent, ear training, language background); (2) audio quality or speaker training may be poor, inflating noise; (3) the reference accent anchor may not be sufficiently defined for consistent scoring. Without alternative rater sources, pre-screening, or a synthetic-audio fallback, any kappa failure at Month 10 (2027-08-13) blocks full Phase 2 launch.

### 1.6.B Tags

- inter-rater-reliability-single-point-failure
- audio-production-timeline-critical-path
- kappa-floor-0.70-brittle
- accent-anchor-undefined
- rater-prerequisites-not-validated

### 1.6.C Mitigation

(1) By Month 2 (2026-12-13), establish rater pre-screening criteria: phonetics or applied-linguistics background (MA or equivalent), native or native-like proficiency in the reference accent, and prior rater-training experience. Pre-screen at least 6–8 candidate raters by Month 4 (2027-02-13), testing each on a 50-word calibration sample to identify the 3–4 most reliable. (2) By Month 3 (2027-01-13), finalize and document the reference accent anchor in a 2–3 page specification: vowel inventory, key consonant contrasts, stress and intonation patterns, and recordings of example words. Provide raters with this spec and 20–30 anchor exemplars by Month 7 (2027-05-13). (3) By Month 5 (2027-03-13), conduct a micro-pilot recording session (100–200 entries) with the top rater candidates; measure inter-rater kappa on this sample by Month 6 (2027-04-13). If kappa ≥0.75, proceed to full production by Month 7 (2027-05-13). If 0.70–0.74, implement targeted retraining (focused on misaligned phoneme categories) and retest by Month 7.5 (2027-05-28). If <0.70, pivot immediately to a hybrid model: (a) Synthetic speech (TTS) baseline for all 5,000 entries by Month 8.5 (2027-06-28) (cost $15K–$25K, estimate); (b) human rater verification only on the top 1,500–2,000 highest-friction words (irregular, diphthongs, schwa words) by Month 11 (2027-09-13). (4) By Month 9 (2027-07-13), if human recording is still in progress, secure a backup studio and a secondary rater by Month 8 (2027-06-13) to parallelise sessions and reduce single-vendor risk.

### 1.6.D Consequence

If inter-rater kappa falls below 0.70 and retraining fails, the project faces a hard stop at Month 10.5 (2027-08-28). Proceeding to Phase 2 with kappa <0.70 inflates the pronunciation-consistency metric's measurement error by 20–30%, reducing statistical power to detect true Clear English effects by 10–15% (estimate). The gate outcome becomes unreliable: pronunciation consistency could falsely pass (Type I error, false positive) or falsely fail (Type II error), invalidating the go/no-go decision. A 4-week Phase 1 extension addresses timeline slippage but not the underlying validity crisis. Without a pre-planned hybrid (synthetic + verification) fallback, kappa failure forces a 12-week extension (~$170K–$255K cost, estimate) or scope reduction (recording only 3,000 words, violating the 5,000-word user constraint).

### 1.6.E Root Cause

The audio production timeline is on the critical path, compressed into 6 months (Months 6–11 = 2027-04-13 to 2027-09-13) with only a 4-week contingency buffer. The project assumes raters can be trained to kappa ≥0.70 by Month 10 (2027-08-13), but provides no pre-screening, no rater-selection validation and no synthetic-audio fallback plan. The reference accent anchor is not finalized until Month 3 (2027-01-13) (or later), leaving only 3–4 months for raters to internalize the standard before calibration testing. The single-point failure is the absence of a hybrid recording strategy (synthetic baseline + verification subset) that would allow Phase 2 launch even if human rater kappa is delayed or subthreshold.

---

# 2 Expert: ESL Curriculum & Adoption Lead

**Knowledge**: Adult ESL pedagogy and program management, publisher partnerships, TESOL/IATEFL networks, supplementary-module design and integration, learner retention and engagement strategies

**Why**: Pilot recruitment, retention and partner engagement are high-risk; the plan requires ≥115 enrolled per arm by Month 13 (2027-11-13), ≤30% dropout, and signed commitments from ≥3 ESL programs and ≥2 technical-training orgs by Month 3 (2027-01-13). The expert will secure and manage these partnerships, design the supplementary-module positioning to maximize teacher buy-in, and lead the educator liaison function to prevent the 'external imposition' perception flagged in threats.

**What**: By Month 1 (2026-11-13), identify and formally pitch 4–5 ESL programs and 2–3 technical orgs; by Month 3 (2027-01-13), obtain signed letters of understanding guaranteeing cohort size, assessment scheduling and per-learner payment terms. Co-design pilot protocols with teacher advisory panels; hire and direct the 1.0 FTE Cohort Manager (by Month 6 = 2027-04-13); establish quarterly practitioner check-ins to maintain retention and collect early adoption signals.

**Skills**: Program management, stakeholder engagement and negotiation, ESL syllabus design, teacher professional development, retention-focused course design, TESOL/IATEFL credibility and networks

**Search**: ESL curriculum director adult language programs, TESOL practitioner liaison educator engagement, ESL publisher partnerships supplementary materials

## 2.1 Primary Actions

- By Month 2 (2026-12-13): Hire an independent psychometrician with a signed contract specifying deliverables (gate thresholds, power analysis, pre-analysis plan). Allocate $150K–$200K from Phase 1 budget for this role and all psychometric work through Month 24 (2028-10-13).
- By Month 5 (2027-03-13): Deliver a complete pre-analysis plan with numeric pass/fail thresholds for all four gate metrics, minimum sample sizes per condition (at least 80 per arm, justified by power analysis), intention-to-treat rules, and primary/secondary outcomes.
- By Month 11 (2027-09-13): Register the pre-analysis plan on Open Science Framework or Aspredicted.org with full board sign-off in writing. Publish the registered thresholds and analysis plan on the project website immediately for public review. Do not proceed to Phase 2 without this pre-registration.
- By Month 1 (2026-11-13): Draft and publish a 2–3 page Editorial Board Charter specifying voting rules (simple majority for rule decisions, linguist review-and-veto limited to ambiguity/contradiction), escalation path for ties (external arbiter, no tie-breaking cost exceeding $5K per decision), conflict-of-interest disclosure, and term limits (recommend 2-year renewable, max 3 consecutive).
- By Month 1 (2026-11-13): Identify and formally approach at least 4–5 adult ESL programs and 3 technical-training organizations with a one-page partnership proposal specifying enrollment targets (≥50 per partner), assessment schedule (4 in-person/virtual sessions, Months 13–24 = 2027-11-13 to 2028-10-13), and incentives ($50–$150 per learner).
- By Month 3 (2027-01-13): Secure signed letters of understanding or MOUs from ≥3 ESL programs and ≥2 technical-training organizations, with binding enrollment guarantees (≥50 learners per partner, 50% recruited by Month 12 = 2027-10-13, 100% by Month 13 = 2027-11-13). Do not start Phase 2 without these commitments.
- By Month 6 (2027-04-13): Hire a dedicated Phase 2 Cohort Manager (1.0 FTE, $60K–$80K/year) responsible for retention tracking, attendance management, incentive administration, and mid-phase check-ins. Budget $40K–$60K for learner incentives across Phase 2.
- By Month 12 (2027-10-13): Establish a Standing Stewardship Committee (2–3 board members, 4–6 hours/month) tasked with identifying candidate steward organizations, auditing their financial stability and governance, and drafting a Stewardship Proposal.
- By Month 2 (2026-12-13): Retain legal counsel specializing in product liability and regulatory compliance. If pursuing safety-critical pilots, obtain written analysis of liability exposure (scenarios, regulatory bodies, insurance requirements, disclaimer language).
- By Month 2 (2026-12-13): Engage an Institutional Review Board or research ethics committee to determine whether Phase 2 pilots require formal ethical review. Submit a 2–3 page study protocol by Month 4 (2027-02-13) and obtain written approval by Month 6 (2027-04-13).

## 2.2 Secondary Actions

- By Month 2 (2026-12-13): Scope audio production: identify and contract with at least one professional audio studio with firm capacity guarantees (5,000 audio files, 2 takes per entry, 4-week lead time, $80K–$120K budget). If per-entry cost exceeds $20, pivot to a hybrid approach (synthetic baseline for all 5,000 entries by Month 7 = 2027-05-13, plus human verification of the highest-friction 1,000–1,500 words).
- By Month 3 (2027-01-13): Finalize the reference accent (one anchor accent) with written justification, and document how other major English varieties map onto it. Document this mapping publicly by Month 12 (2027-10-13).
- By Month 4 (2027-02-13): Conduct a full cost-per-entry audit for audio production and confirm alignment with Phase 1 budget.
- By Month 6 (2027-04-13): Commission legal analysis of three alternative licensing scenarios (permissive open license, certification mark, share-alike) with advantages, risks, and enforcement costs. The editorial board must vote on the chosen model by Month 6 (2027-04-13).
- By Month 6 (2027-04-13): Obtain ethics approval and publish a comprehensive Data Protection and Privacy Policy specifying data types, retention periods, access rules, encryption protocols, and learners' right to deletion. Publish informed-consent forms and data-use agreements (in multiple languages if needed) by Month 10 (2027-08-13).
- By Month 8 (2027-06-13): Run a lexicon coverage audit: confirm that the 5,000-word core lexicon covers ≥85% of running text in pilot glossaries and training materials. If coverage falls short, expand the lexicon or add domain-specific terms by Month 10 (2027-08-13).
- By Month 8 (2027-06-13): Design and document inter-rater training and calibration protocol: recruit 3–4 raters with ESL or phonetics background, conduct training on the reference accent using a pilot sample (100–200 words) by Month 9 (2027-07-13), and measure Cohen's kappa by Month 10 (2027-08-13). Require kappa ≥0.70 (target 0.75) before proceeding to full production.
- By Month 10 (2027-08-13): Run a dry run of all assessment tools and logging platforms. If inter-rater kappa falls below 0.70, halt full production, conduct 2–4 weeks of additional rater training, and retest kappa by Month 11 (2027-09-13). If kappa remains below 0.70, flag to the board for a 4-week Phase 1 extension or scope reduction (record only 3,000 highest-impact words).
- By Month 10 (2027-08-13): Finalize all rule disputes at the editorial board level. Resolve contentious decisions (ordinal marker, morphology threshold, homograph policy) and appoint the external tiebreak arbiter if needed.
- By Month 11 (2027-09-13): Publish the draft standard for a 30-day public-comment window. All rules must be frozen by Month 12 (2027-10-13); rules cannot change during Phase 2 pilots.
- By Month 18 (2028-04-13): Conduct a mid-pilot check-in with all partner sites. Monitor enrollment progress, dropout rate, and data-quality indicators. If dropout exceeds 30% or enrollment falls below 450 total, escalate to the editorial board and plan retention-focused interventions.
- By Month 24 (2028-10-13): Conduct the Month 24 (2028-10-13) go/no-go decision using the pre-registered metrics and thresholds. Publish the gate decision and supporting data summary within 2 weeks.
- By Month 24 (2028-10-13): If the go/no-go is GO, formally approach the top 2 steward candidates with a Stewardship Proposal. Request a written letter of interest by Month 27 (2029-01-13) and negotiate a signed MOU by Month 30 (2029-04-13).
- By Month 30 (2029-04-13): Publish Clear English Standard v1.0 (rules, dictionary, style guide, licensing policy) only after a signed stewardship MOU is in hand. Do not release v1.0 without a steward commitment.

## 2.3 Follow Up Consultation

At the next meeting, we must address: (1) Power analysis and sample-size justification—what effect sizes do you expect for ordinal error reduction and pronunciation consistency, and do 80 completers per arm provide adequate statistical power? (2) Which ESL programs and technical-training sites have been informally approached, and what is their likelihood of commitment by Month 3 (2027-01-13)? (3) Steward candidates—have you identified any universities, language non-profits, or standards bodies willing to house the standard for $150K–$250K per year? (4) Audio cost and rater availability—what quotes have you obtained from professional studios, and do you have 3–4 qualified raters (ESL or phonetics background) available by Month 8 (2027-06-13)? (5) Regulatory landscape—which education and safety authorities (Ofqual, state education departments, OSHA, HSE) must approve or endorse adoption in your target jurisdictions, and what are their timelines?

## 2.4.A Issue - Gate Metrics Are Still Proposals, Not Pre-Registered. This Is a Critical Credibility Risk.

The plan lists four gate thresholds (ordinal error ≥25% reduction, comprehension ≤10% slower, pronunciation consistency ≥15% above control, 30-day retention ≥70%) as 'proposed' figures. None are pre-registered on an open repository, no power analysis justifies the sample size (80 per arm), and no independent psychometrician has signed a contract specifying deliverables. Without pre-registration by Month 11 (2027-09-13), the Month 24 (2028-10-13) go/no-go decision will be scientifically indefensible. Regulators, standards bodies and publishers will claim the thresholds were set post-hoc to justify a desired outcome.

### 2.4.B Tags

- gate_credibility
- measurement_validity
- stakeholder_confidence
- regulatory_risk

### 2.4.C Mitigation

Execute immediately: (1) By Month 2 (2026-12-13), hire an independent psychometrician (signed contract, $150K–$200K budget). (2) By Month 5 (2027-03-13), deliver a pre-analysis plan with numeric thresholds, sample-size power analysis, and intention-to-treat rules. (3) By Month 11 (2027-09-13), register the complete plan on Open Science Framework or Aspredicted.org, with board sign-off in writing. (4) Publish thresholds on the project website immediately for third-party review. This is non-negotiable for Phase 2 credibility.

### 2.4.D Consequence

A disputed or undefended gate decision will fracture stakeholder confidence: standards bodies may refuse to cite the standard, ESL publishers will hesitate to adopt, and a false-positive outcome (weak evidence supporting a GO) will damage adoption by 20–50% in Phase 3. The project will be perceived as academically dishonest, not rigorous.

### 2.4.E Root Cause

Empty

## 2.5.A Issue - Pilot Partner Commitments Are Not Yet Signed. Recruitment Failure Will Invalidate Phase 2.

The plan calls for 'signed commitments by Month 3 (2027-01-13)' from ≥3 ESL programs and ≥2 technical-training organizations. No evidence is presented that these partners have been approached, that they have provisionally agreed, or that they understand the commitment (≥50 learners per partner, 4 in-person sessions, 30-day follow-up, demographic data collection). If recruitment stalls or dropout exceeds 30%, the effective sample size falls below 80 per arm, invalidating statistical power and forcing a 3–6 month Phase 2 extension ($300K–$600K). No contingency plan specifies how to recover if a partner withdraws.

### 2.5.B Tags

- pilot_recruitment
- partner_engagement
- sample_size_risk
- budget_exposure

### 2.5.C Mitigation

Action required by Month 1 (2026-11-13): (1) Identify and formally approach 4–5 ESL programs and 3 technical-training sites with a one-page partnership proposal specifying cohort size, assessment schedule, incentives ($50–$150 per learner), and partner payment ($30–$50 per session). (2) By Month 3 (2027-01-13), secure signed letters of understanding with binding enrollment guarantees. (3) Hire a dedicated Phase 2 Cohort Manager (1.0 FTE, $60K–$80K/year) by Month 6 (2027-04-13) to manage retention, track attendance, and conduct mid-phase check-ins. (4) Over-recruit to ≥115 per arm (460 total) to buffer for a 30% dropout rate. If recruitment fails by Month 6 (2027-04-13), escalate to the editorial board immediately.

### 2.5.D Consequence

Without signed commitments, Phase 2 begins with no enrolled learners. Recruitment delays compress the pilot window, forcing a 3–6 month Phase 2 extension that consumes the $175K pre-gate reserve and leaves a $35K shortfall. A no-go outcome becomes more likely, returning $1.2M unspent and delaying publication to Month 39 (2030-01-13) or later, breaking the 36-month timeline.

### 2.5.E Root Cause

Empty

## 2.6.A Issue - Post-Project Stewardship Is Unfunded. Version 1.0 Release Depends on a Commitment That Does Not Yet Exist.

The plan specifies that v1.0 must be released by Month 30 (2029-04-13) 'conditional on a written steward commitment.' No steward organization has been approached, no letters of interest have been collected, and no funding source for the $150K–$250K per year stewardship cost has been identified. The plan cannot credibly promise a v1.0 release without a signed commitment in hand. After Month 36 (2029-10-13), the standard will atrophy: corrections will accumulate unanswered, adopter confidence will degrade, and Phase 3 adoption will fall by 30–50% within 24–36 months.

### 2.6.B Tags

- stewardship
- sustainability
- post_project_risk
- adoption_fade

### 2.6.C Mitigation

By Month 12 (2027-10-13), launch a Standing Stewardship Committee (2–3 board members, 4–6 hours/month). By Month 18 (2028-04-13), identify 2–3 candidate steward organizations (language non-profits, university consortiums, ISO committees) and audit their 3+ years of financials, governance, and standards-maintenance experience. By Month 24 (2028-10-13), present a formal Stewardship Proposal to the top 2 candidates specifying annual budget ($150K–$250K), responsibilities (change requests, conformance claims, errata), and decision authority. Request a written letter of interest by Month 27 (2029-01-13) and a signed MOU by Month 30 (2029-04-13). Freeze v1.0 release until the MOU is signed.

### 2.6.D Consequence

Without a funded steward, the standard becomes orphaned post-Month-36. Fragmentation accelerates: unofficial forks emerge, conformance claims go unanswered, and third-party adoption stalls. By Month 60 (2031-10-13), the standard is perceived as abandoned, reducing Phase 3 uptake by 30–50% and eroding the credibility the project invested 3 years to build.

### 2.6.E Root Cause

Empty

---

# 3 Expert: Language Standardization & Governance Expert

**Knowledge**: Language standards bodies (ISO, ICAO, ASD-STE100), editorial board governance and decision-making, change-control and versioning frameworks, standards adoption and third-party conformance

**Why**: The project's editorial board charter, voting rules, tiebreak arbiter and post-v1.0 stewardship model are underspecified and risk deadlock (flagged in weaknesses). This expert will codify governance (Decision 13: Editorial Board Seat Allocation), lock the release cadence and licensing framework (Decision 10 & 11), and secure a permanent steward by Month 24 (2028-10-13)—directly preventing the 'unfunded stewardship after Month 36 (2029-10-13)' threat that could degrade Phase 3 adoption by 30–50% within 24–36 months.

**What**: By Month 1 (2026-11-13), draft and publish a 2–3 page Editorial Board Charter specifying voting rules, tiebreak arbiter selection and cost cap ($5K–$20K estimate), conflict-of-interest rules and term limits. By Month 5 (2027-03-13), retain and brief the external arbiter. By Month 6 (2027-04-13), finalize and publish the Licensing and Name Stewardship Policy (certification-mark approach) and Change-Control & Release Cadence framework. By Month 24 (2028-10-13), identify and secure a written commitment from a steward organization ($150K–$250K annually, 10+ years).

**Skills**: Language standards governance (ISO, ICAO precedent), editorial decision architecture, third-party conformance auditing, intellectual property and certification-mark strategy, post-project stewardship and funding models

**Search**: language standards governance expert ASD-STE100 ISO liaison, editorial board structure decision-making framework, standards stewardship funding sustainability

## 3.1 Primary Actions

- Lock and pre-register all four gate metrics with numeric thresholds, sample-size power analysis, and intention-to-treat decision rules by Month 11 (2027-09-13). Hire the independent psychometrician by Month 2 (2026-12-13) with a signed statement of work requiring a pre-analysis plan draft by Month 9 (2027-07-13) and formal registration on Open Science Framework by Month 11 (2027-09-13). Publish thresholds and rationale on the project website for third-party review and editorial board sign-off by Month 12 (2027-10-13).
- Draft and publish a formal Editorial Board Charter by Month 1 (2026-11-13) specifying voting thresholds, linguist-veto scope, conflict-of-interest rules, and an external tiebreak arbiter with a fee cap ($10K-$20K estimated per decision). Secure the arbiter's written commitment and fee schedule by Month 5 (2027-03-13). Publish a decision log of all disputed rules by Month 10 (2027-08-13) with majority and minority positions. Lock all rules by Month 12 (2027-10-13) and conduct a 30-day public-comment window (Months 11-11.5 = 2027-09-13 to 2027-09-28) with a published response document.
- Hire the Cohort Manager by Month 6 (2027-04-13), but onboard at 0.5 FTE by Month 2 (2026-12-13) to draft partner commitments and retention protocols. Secure signed commitments from at least 3 ESL programs and 2 technical-training organizations by Month 3 (2027-01-13) specifying minimum cohort size (≥50 per partner estimate) and enrollment windows. Confirm audio studio capacity and per-entry cost by Month 4 (2027-02-13); if cost exceeds $20 per entry (estimate), pivot to synthetic baseline plus human verification by Month 7 (2027-05-13). Schedule rater training and inter-rater reliability dry run (kappa ≥0.70 floor, target 0.75) for Month 9 (2027-07-13) with a go/no-go decision by Month 9.5 (2027-07-28); escalate to the board by Month 11 (2027-09-13) if remediation requires a Phase 1 extension.

## 3.2 Secondary Actions

- Establish a Standing Regulatory Affairs workstream (0.5 FTE) by Month 3 (2027-01-13) to identify and engage key regulatory and standards bodies (TESOL, Ofqual, state education departments, ISO language committees) as non-binding advisors. Secure advisory seats and document regulatory risks by Month 4 (2027-02-13). Determine whether formal approval processes are required in jurisdictions where Phase 2 pilots operate by Month 6 (2027-04-13) and prepare regulatory submissions by Month 15 (2028-01-13) with realistic approval timelines (4-8 months estimated). Flag any blocking requirements to the editorial board by Month 12 (2027-10-13).
- Commission a lawyer specializing in intellectual property and language standards by Month 3 (2027-01-13) to draft three alternative licensing and name-stewardship scenarios (fully permissive open license, certification-mark model, share-alike with divergence rules). Have the board vote and publish the chosen Licensing and Name Stewardship Policy by Month 6 (2027-04-13) specifying: legal mechanism for protecting the name, public conformance checklist, third-party certification process, and dispute resolution. Establish a standing Standards Stewardship Committee (3-5 board members, 2-4 hours/month estimated) by Month 12 (2027-10-13) with explicit authority to review conformance claims, maintain a public registry of certified materials, and deter non-conforming forks.
- Engage an Institutional Review Board or Research Ethics Committee by Month 2 (2026-12-13) to determine whether Phase 2 pilots require formal ethical review. Submit a 2-3 page study protocol by Month 4 (2027-02-13) and obtain written approval by Month 6 (2027-04-13). Finalize and publish a comprehensive Data Protection and Privacy Policy on the project website by Month 8 (2027-06-13) specifying data types collected, retention timelines (audio 3 years post-analysis, scores 5 years for archival), access controls, and learner deletion rights. Publish informed-consent forms in plain language and in multiple languages by Month 10 (2027-08-13) to support credible pilot recruitment.
- Search for and identify 2-3 permanent steward organizations by Month 18 (2028-04-13) (candidates: language-education non-profits, university consortiums, established standards bodies). Prepare a Stewardship Proposal by Month 24 (2028-10-13) specifying annual budget ($150K-$250K estimated), key responsibilities, decision authority, and funding sources. Secure a written letter of interest from at least one steward candidate by Month 27 (2029-01-13) and negotiate a formal Memorandum of Understanding (MOU) with 10-year commitment by Month 33 (2029-07-13). Publish a 5-year Stewardship Roadmap by Month 36 (2029-10-13) documenting review schedules, change-request prioritization, committee composition, and conflict resolution.

## 3.3 Follow Up Consultation

At the next consultation (suggest Month 1 = 2026-11-13), present: (1) a signed contract with the independent psychometrician and a draft statement of work for the pre-analysis plan, power analysis, and pre-registration; (2) a published Editorial Board Charter with voting rules, arbiter selection, and conflict-of-interest rules; (3) a 3-4 page Regulatory Landscape Summary identifying key standards bodies and their approval pathways; (4) initial outreach letters to at least 4-5 ESL programs and 2-3 technical-training organizations with a partnership proposal. By Month 3 (2027-01-13), present signed pilot partner commitments and confirmation of the Cohort Manager hire. By Month 6 (2027-04-13), present the finalized Licensing and Name Stewardship Policy, audio studio capacity confirmation with cost audit, ethics-board approval, and data-protection policies. By Month 11 (2027-09-13), present the pre-registered gate metrics on Open Science Framework with independent psychometrician sign-off, final rule set with published rationale, and rater inter-rater reliability dry-run results (target kappa ≥0.70). These milestones directly address the three critical gaps: gate credibility, governance legitimacy, and pilot feasibility.

## 3.4.A Issue - Pre-Registration and Gate Thresholds Remain Proposals, Not Locked Commitments

The gate metrics (ordinal error ≥25% reduction, comprehension within 10%, pronunciation consistency ≥15% above control, 30-day retention ≥70%) are labelled 'proposed thresholds' throughout. They are not yet pre-registered on an open repository, do not have a psychometrician-led power analysis confirming sample-size adequacy (at least 80 per arm), and lack published decision rules for borderline outcomes (e.g., if ordinal error is reduced 24% vs. 25%). This is critical because the Month 24 (2028-10-13) go/no-go decision is the only gate; a weak or disputable threshold invalidates the entire evidence strategy and invites stakeholders to claim the outcome is rigged.

### 3.4.B Tags

- gate-credibility
- pre-registration-gap
- measurement-validity
- standards-governance

### 3.4.C Mitigation

Immediately (Month 0 = 2026-10-13): Draft a statement of work for the independent psychometrician specifying: (1) deliver a pre-analysis plan by Month 9 (2027-07-13) with explicit numeric thresholds, sample-size justification, power calculations (target 80% power, two-sided α=0.05), and intention-to-treat rules; (2) register the plan on Open Science Framework or equivalent by Month 11 (2027-09-13), 30 days before Phase 2 begins; (3) publish thresholds and rationale on the project website by Month 11 (2027-09-13) for third-party review. Secure a signed contract by Month 2 (2026-12-13). Commission a 20-30 participant validity study in Months 10-11 (2027-08-13 to 2027-09-13) to confirm that the proposed thresholds are defensible and that the instruments detect ordinal and pronunciation effects. Escalate to the editorial board for written sign-off of the final thresholds by Month 12 (2027-10-13).

### 3.4.D Consequence

Without pre-registered, defended thresholds, the Month 24 (2028-10-13) go/no-go decision will be scientifically disputable. Educators, standards bodies, and publishers can claim the gate was rigged or that borderline results were manipulated. A false-positive outcome (a GO on weak evidence) launches a standard that fails in Phase 3 adoption; a false-negative (a NO-GO on borderline data) squanders $1.2M in Phase 2 spending and delays steward commitment. Dispute risk alone reduces third-party adoption confidence by 20-50% and invites regulatory challenge. ICAO, ISO, and ASD-STE100 precedent shows that credible standards require pre-registered metrics and independent validation; a weak gate risks relegating Clear English to a minority variant or relegating it to a footnote in education literature.

### 3.4.E Root Cause

The plan names four metrics and proposes numeric values, but the psychometrician role was listed as 'hired by Month 2 (2026-12-13)' without specifying that the pre-analysis plan (PAP) drafting, validity study, and formal pre-registration must occur by Month 11 (2027-09-13). No contract exists yet with the psychometrician, no power analysis has been run, and no open-science registration is scheduled. The strategic decisions document identifies Outcome Metric Battery Design as a critical lever, yet the plan treats thresholds as negotiable rather than as non-negotiable pre-commitments before Phase 2 begins.

## 3.5.A Issue - Editorial Board Governance Structure Lacks Explicit Decision Authority and Dispute Resolution

The plan specifies a 'practitioner-leaning editorial board of 7-9 members with linguist review-and-veto limited to ambiguity/contradiction findings' and names a 'tiebreak arbiter.' However, the charter itself is not drafted, voting procedures are not documented, the arbiter's scope and fee cap ($10K-$20K estimated) are not locked, and no escalation path is published for contested rule decisions. The strategic_decisions document flags Editorial Board Seat Allocation as a high-impact lever affecting the usability-versus-consistency trade-off in morphology and homograph decisions. The plan requires rules to be locked by Month 12 (2027-10-13), but without a formal, published charter with clear decision rules, disputes can stretch into Phase 2, invalidating early pilot comparisons.

### 3.5.B Tags

- governance-ambiguity
- decision-authority
- rule-finalization-risk
- standards-legitimacy

### 3.5.C Mitigation

By Month 1 (2026-11-13 at 09:00): Draft and publish a 2-3 page Editorial Board Charter specifying: (1) voting rule (simple majority, quorum 6 of 9); (2) linguist veto scope (only ambiguity, logical contradiction, or factual error; not subjective preference); (3) veto override path (if linguists veto a rule, present both positions to the board and allow override by 2/3 majority); (4) conflict-of-interest disclosure (members must recuse if they profit from a rule); (5) tiebreak arbiter (externally appointed, e.g., from a university or standards body, with written fee schedule capped at $10K per decision). By Month 5 (2027-03-13): Secure the arbiter's written commitment and fee schedule in advance. By Month 10 (2027-08-13): publish a 1-page decision log of all disputed rules, including majority/minority positions and the rationale for the chosen path. Lock all rules by Month 12 (2027-10-13) and conduct a 30-day public-comment window (Month 11 = 2027-09-13 to Month 11.5 = 2027-09-28 to 2027-09-28) with a published response to comments. This echoes ICAO and ISO precedent, where explicit governance structures and published reasoning builds credibility.

### 3.5.D Consequence

Without a published, formal charter and clear dispute resolution, the board can deadlock indefinitely. Contested decisions (e.g., whether to regularize go/went, or how to mark homophones) can stretch from Month 5 (2027-03-13) to Month 12 (2027-10-13) or later, compressing the Phase 1 exit gate and forcing a 4-12 week extension ($85K-$250K estimated). Mid-pilot rule changes invalidate prior assessments, weakening the go/no-go evidence. Standards bodies, publishers, and educators perceive the process as opaque or rigged, reducing adoption by 20-30%. Past precedent (ASD-STE100 governance debates 2000-2005) shows that weak governance invites external challenges that can paralyze a standard for years. Stronger governance signals institutional legitimacy and third-party confidence.

### 3.5.E Root Cause

The plan names decisions (practitioner-leaning board, linguist veto, tiebreak arbiter) but does not publish governance documents. The charter is mentioned as due by Month 1 (2026-11-13), but no template, voting threshold, conflict-of-interest rules, or arbiter-selection criteria are specified. The SWOT analysis flags 'Editorial board deadlock or rule ambiguity delaying the Month 12 (2027-10-13) rules lock' as a key risk, yet mitigation only says 'publish board charter by Month 1 (2026-11-13)' without operationalizing how disputes are actually resolved. This mirrors past standards failures (e.g., Simplified Spelling Board disputes in the 1960s, which paralyzed rule decisions).

## 3.6.A Issue - Pilot Recruitment, Retention, and Audio Production Are Under-Resourced and Lack Explicit Fallback Plans

The plan targets at least 80 completers per arm (320 total across 4 arms, implying enrollment of ≥115 per arm at a 70% retention rate estimate), with signed partner commitments by Month 3 (2027-01-13). However: (1) no psychometric power analysis yet exists to confirm that 80 per arm is sufficient; (2) the Cohort Manager (1.0 FTE, $60K-$80K/yr) is not hired until Month 6 (2027-04-13), leaving 5 months of recruitment with no dedicated staff; (3) audio production is budgeted $80K-$120K (estimate) with a $20 per-entry cost floor, but if cost exceeds this, the fallback (synthetic baseline plus human verification of highest-friction words) is not funded in Phase 1; (4) inter-rater reliability (kappa ≥0.70 floor, target 0.75) is critical for the pronunciation consistency gate metric, yet rater training and a dry run are scheduled only by Month 10 (2027-08-13), giving a 2-month window to retrain or reduce scope before the rules lock. This concentrates risk in Months 8-12 (2027-06-13 to 2027-10-13).

### 3.6.B Tags

- pilot-feasibility
- resource-sequencing
- measurement-readiness
- risk-concentration

### 3.6.C Mitigation

Immediate actions (Month 0-2 = 2026-10-13 to 2026-12-13): (1) Confirm the psychometric power analysis target (80 per arm) or adjust enrollment targets and Phase 2 budget based on effect-size assumptions (this is the psychometrician's job by Month 5 = 2027-03-13). (2) Hire the Cohort Manager by Month 6 (2027-04-13), but onboard and plan recruitment by Month 2 (2026-12-13) in a 0.5 FTE advisory capacity; have them draft partner commitments, incentive structures, and a retention protocol before Month 3 (2027-01-13). (3) By Month 2 (2026-12-13): Secure studio capacity with firm pricing and delivery timelines; trigger a cost audit by Month 4 (2027-02-13); if per-entry cost exceeds $20 (estimate), pivot immediately to a hybrid approach (synthetic baseline for all 5,000 by Month 7 = 2027-05-13, human verification of highest-friction 1,000-1,500 by Month 11 = 2027-09-13). (4) Schedule a rater training and kappa dry run for Month 9 (2027-07-13) (not Month 10 = 2027-08-13), with a go/no-go decision by Month 9.5 (2027-07-28); if kappa <0.70, conduct intensive retraining for Weeks 1-4 of Month 10 (2027-08-13) with retest by Month 10.5 (2027-08-28). If retest kappa is still <0.70, escalate to the board by Month 11 (2027-09-13 at 09:00) with two options: (a) reduce lexicon scope to 3,000 highest-impact words (violates user constraint, not recommended), or (b) extend Phase 1 by 6 weeks (not 4) to allow rater retraining and a third kappa check, shifting Phase 2 start to Month 13 (2027-11-13) (cost ~$125K estimated). Publish these decision rules and timelines on the project website by Month 1 (2026-11-13) to signal credibility and give partners visibility into fallback scenarios.

### 3.6.D Consequence

Weak pilot recruitment and retention (dropout >30%) reduces effective sample size below 80 per arm, inflating measurement error by 20-30% and reducing statistical power to detect true ordinal and pronunciation effects by 10-20%. An underpowered gate metric is inconclusive and forces either a false-negative (NO-GO on weak evidence, wasting $1.2M) or a false-positive (GO on borderline data, launching a weak standard). Unreliable pronunciation scoring (kappa <0.70) adds 10-15% measurement noise to the pronunciation consistency gate, making it impossible to distinguish true Clear English effects from rater variance. Audio cost overruns or late rater-training discovery compress the Phase 1 rules-lock deadline, forcing either a 6-week extension (cost $125K-$150K estimated) or a scope reduction that violates the 5,000-word user constraint. Past precedent (ICAO aviation-English pilot studies 2010-2015) shows that under-resourced recruitment and late assessment readiness are the top reasons pilots fail to generate defensible evidence; the cost of remediation is typically 2-3 months and $200K-$400K, not the projected 4 weeks and $85K.

### 3.6.E Root Cause

The plan names recruitment targets and a retention goal but does not sequence hiring or budget fallbacks tightly. The Cohort Manager is a critical role for retention, yet is not hired until Month 6 (2027-04-13), after the first 5 months of partner engagement and recruitment logistics should have begun. Audio production cost is volatile (per-entry cost unknown; potential $50K+ overrun), yet is not subject to a go/no-go decision at Month 8 (2027-06-13) with clear fallback triggers. Inter-rater reliability is a gate-metric prerequisite, yet the dry run is scheduled for Month 10 (2027-08-13) with only 2 months to remediate if kappa falls below 0.70 (the floor). This mirrors the risk register's flag: 'Weak or disputable assessment validity and rater reliability (kappa below 0.70)' is a key risk, yet mitigation says only 'extend Phase 1 by 4 weeks if kappa stays below 0.70,' implying a reactive, not proactive, approach.

---

# 4 Expert: Data Protection & Research Ethics Advisor

**Knowledge**: GDPR and US state data-privacy law, Institutional Review Board (IRB) and Research Ethics Committee (REC) processes, informed consent and learner safeguarding, product liability in language/safety-critical contexts

**Why**: Audio recordings of 460 learners, pronunciation scoring, and potential safety-critical pilot materials expose the project to GDPR/privacy breach, ethics-approval delay, and liability litigation if misreading occurs. These must be locked by Month 6 (2027-04-13) to avoid Month 18–24 (2028-04-13 to 2028-10-13) discovery of unresolved exposure. The expert will secure IRB/REC approval, establish encrypted storage and audit protocols, and define safety-critical liability thresholds that keep pilots within 'glossary and labeling' bounds (not live procedures).

**What**: By Month 2 (2026-12-13), engage an IRB/REC and draft a study protocol (learner population, intervention, data types, retention). By Month 4 (2027-02-13), commission a product-liability analysis covering safety-critical misreading scenarios and insurance requirements. By Month 6 (2027-04-13), obtain written ethics approval and secure liability insurance (≥$1M–$5M per incident, estimate). By Month 8 (2027-06-13), finalize Data Protection and Privacy Policy and audit encrypted storage. By Month 10 (2027-08-13), publish plain-language consent forms and data-use agreements in multiple languages.

**Skills**: GDPR compliance, IRB/REC navigation, informed-consent design in plain language, data encryption and audit, product liability assessment, safety-critical documentation standards (IEC 62304, DO-178C or equivalent)

**Search**: GDPR data protection officer language research, IRB ethics committee human-subjects protocol, product liability insurance safety documentation

## 4.1 Primary Actions

- By Month 1 (2026-11-13), draft a plain-language Informed Consent Template (1–2 pages) and a Data Protection & Privacy Policy (2–3 pages) specifying data types collected, retention periods, access controls, encryption standards (AES-256), cloud-vendor DPA requirements, and learners' right to deletion; submit both to the IRB by Month 2 (2026-12-13) for pre-screening feedback, allowing 2-week turnaround and resubmission by Month 3 (2027-01-13) for formal expedited or full review, targeting approval by Month 5 (2027-03-13).
- By Month 1 (2026-11-13), commission a Data Protection Impact Assessment (DPIA) under GDPR Article 35 documenting the lawful processing ground for audio recording (explicit consent + research exemption), data-minimization strategy (calibrate inter-rater reliability on a 200–300 word pilot subset, Month 8–9 = 2027-06-13 to 2027-07-13, before committing to full 5,000-word recording), Right-to-Be-Forgotten Protocol, and risk mitigation (if >5% of learners request deletion during pilots, specify contingency for kappa re-estimation or threshold downgrade). Publish the DPIA by Month 4 (2027-02-13).
- By Month 2 (2026-12-13), engage a lawyer specializing in product liability and regulatory compliance (separate from data-protection counsel) and commission a written Liability & Regulatory Landscape Analysis (3–5 pages) identifying applicable liability frameworks (US tort, UK CPFUTC, ISO/IEC standards), liability scenarios per cohort, estimated exposure, and available insurance. By Month 4 (2027-02-13), publish a Liability Strategy Document specifying the mitigation approach (research exemption + disclaimers + human-review protocol), mandatory incident reporting, and regulatory notification protocol. Secure signed Pilot Partner Agreements by Month 6 (2027-04-13) confirming experimental status and indemnification.
- By Month 2 (2026-12-13), commission a Pre-Negotiation of Data Processing Agreements (DPAs) with at least two potential cloud-storage vendors (AWS, Azure, or equivalent), specifying data location, encryption, sub-processor controls, and annual renewal. Complete DPA signature by Month 3.5 (2027-01-28) to unblock IRB submission.
- By Month 4 (2027-02-13), secure product-liability insurance quotes from at least two brokers specializing in education or standards liability, requesting coverage for pilot activities with limits of $1M–$5M per incident (estimate). If premiums exceed $50K/year (estimate) or if underwriters classify materials as 'uninsurable,' scale back the safety-critical wedge to non-life-critical glossaries only (office supplies, library labels, not pharmaceuticals or operating procedures) and defer operational-procedures pilots to post-Phase-2 evidence collection.
- By Month 5 (2027-03-13), obtain written IRB/REC approval confirming that the consent template, data-protection plan, and audio-recording protocol meet regulatory standards. If full review is mandated (not expedited), negotiate for phased approval allowing recruitment to begin by Month 6 (2027-04-13) under provisional clearance for core data collection.

## 4.2 Secondary Actions

- By Month 1 (2026-11-13), establish a Data Governance Working Group (2–3 FTE, shared with ethics and legal counsel) responsible for: maintaining a Data Registry (inventory of all data types, retention schedules, access controls), conducting quarterly Compliance Audits (GDPR, HIPAA if medical partners join, state privacy laws), and managing learner-deletion requests with a documented Right-to-Be-Forgotten workflow.
- By Month 3 (2027-01-13), draft a Breach Notification Plan specifying: detection procedures (encrypted-storage monitoring, access-log audits), internal escalation (who to notify within 24 hours), regulatory notification (ICO, state AGs, OSHA if applicable), learner notification (within 72 hours if breach is material), and documentation (incident log, containment action, root-cause analysis). Publish the plan on the project website.
- By Month 6 (2027-04-13), conduct a Privacy-by-Design Audit reviewing all assessment tools, storage infrastructure, and learner-contact protocols to confirm that PII (personally identifiable information) is minimized, encrypted at rest and in transit, and that access logs are maintained. Schedule quarterly re-audits through Month 36 (2029-10-13).
- By Month 8 (2027-06-13), implement encrypted audio storage with a backup plan: primary encryption on an on-premises server with split-key custody (project team holds one key, an external escrow service holds the other) or full cloud encryption (AWS KMS or Azure Key Vault) with project team controlling the master key. Document the storage architecture and key-recovery procedures.
- By Month 10 (2027-08-13), conduct a Post-Hoc Liability Review if any pilot incident (near-miss, learner complaint about ambiguity, or operational misuse) occurs; immediately notify the liability insurance broker and legal counsel, document the incident in an Incident Report, and assess whether the event changes the risk profile or requires modification of the Liability Strategy.
- By Month 12 (2027-10-13), publish a Learner Privacy & Liability Compliance Report (2–3 pages) summarizing: IRB/REC approval status and any conditions, GDPR/data-protection audit results, insurance coverage and premium, incident reports (if any), and compliance outlook for Phase 2. Share with pilot partners and the editorial board.
- Throughout Months 13–24 (2027-11-13 to 2028-10-13), maintain active learner-consent management: send annual re-consent requests to all retained data donors (Month 18 = 2028-04-13) if audio is to be retained beyond the original 3-year window, and process Right-to-Be-Forgotten requests within 30 days with documented confirmation sent to the learner.
- By Month 24 (2028-10-13), conduct a final Data Governance Audit prior to the Phase 2 go/no-go decision, confirming that all audio, test scores, and demographic data are securely stored, properly encrypted, and that breach-detection and deletion procedures are operational. Flag any compliance gaps to the editorial board for remediation before Phase 3 release.

## 4.3 Follow Up Consultation

"In the next consultation, we should address: (1) the final IRB/REC approval status and any conditions imposed on audio recording or data retention; (2) the results of the Data Protection Impact Assessment and which data-minimization optimizations are feasible (e.g., can inter-rater reliability be calibrated on a 300-word subset instead of 5,000 words?); (3) confirmation of insurance coverage and liability strategy, including whether the safety-critical wedge will remain operational-procedures-only (non-live) or scale to glossary-only (safest); (4) the cloud-vendor DPA status and whether data residency or sub-processor controls require changes; (5) incident-reporting procedures and whether the pilot partners' signed agreements have been finalized; (6) a draft Learner Privacy Compliance Report for Month 12 (2027-10-13) documenting all regulatory approvals, data-protection measures, and insurance status. If any IRB objections or insurance-availability issues have emerged, we should discuss contingency plans (e.g., switching to synthetic audio, narrowing the safety-critical scope, or extending Phase 1 to allow additional risk assessment)."

## 4.4.A Issue - IRB/REC Approval Timeline Is Dangerously Compressed and May Block Phase 2 Start

The project targets IRB/REC approval by Month 6 (2027-04-13) but requests expedited review by Month 4 (2027-02-13). Expedited review typically handles minimal-risk studies; if the audio-recording component or learner-identification protocols raise concerns about privacy, data sensitivity, or long-term retention, the board may require full review (4–8 weeks instead of 2–3 weeks). Additionally, no consent template, privacy statement, or data-retention schedule is drafted before Month 2 (2026-12-13), yet these are required by most IRBs before submission. A Month 4 (2027-02-13) submission with incomplete consent language will be returned for revision, delaying approval to Month 7–8 (2027-05-13 to 2027-06-13), compressing the Month 13 (2027-11-13) enrolment deadline by 4–6 weeks and forcing either rushed recruitment or scaled-back cohort targets.

### 4.4.B Tags

- IRB_approval_delay
- consent_template_missing
- audio_privacy_risk
- data_retention_policy_undefined
- critical_path_compression

### 4.4.C Mitigation

By Month 1 (2026-11-13), draft a plain-language Informed Consent Template (1–2 pages) specifying: what data will be collected (pronunciation audio, test responses, reading times, name and email), how long each data type is retained (audio 3 years post-analysis then deleted unless learner consents to archival; scores and demographics 5 years for verification), who may access it (core research team with signed data-use agreements; no sharing with third parties without consent), encryption and backup procedures, and the learner's right to withdraw and request deletion at any time. Include translations into the home languages of ESL cohorts if feasible. By Month 1 (2026-11-13), also draft a Data Protection and Privacy Policy (2–3 pages) documenting GDPR/state-law compliance, data-minimization principles, and breach-notification procedures. Submit both to the IRB along with the study protocol by Month 2 (2026-12-13) for a 2-week pre-screening and feedback cycle; revise based on IRB queries by Month 3 (2027-01-13); resubmit for formal review by Month 3.5 (2027-01-28); target approval by Month 5 (2027-03-13). If full review is mandated, negotiate for a phased approval (audio recording and scores first, follow-up contact second) to allow recruitment to begin by Month 6 (2027-04-13) under provisional ethics clearance for core data collection. Engage a data-protection officer or legal counsel specializing in research compliance (separate from the product-liability counsel) by Month 1 (2026-11-13) to guide compliance.

### 4.4.D Consequence

Without accelerated IRB action and complete submission by Month 2 (2026-12-13), approval will slip to Month 7–8 (2027-05-13 to 2027-06-13), shortening the recruitment window to 5–6 months (vs. 8 months planned). This forces over-recruitment pressure on partner organizations, raising dropout risk above the tolerated 30% and reducing effective sample size below the 80-per-arm minimum, invalidating the gate metrics and triggering a Phase 2 extension costing $300K–$600K (estimate). Alternatively, a scaled-back cohort (60–70 per arm) proceeds but loses statistical power, raising Type II error risk (false-negative gate) and requiring higher effect-size thresholds that may be unachievable.

### 4.4.E Root Cause

The plan assumes expedited review will clear by Month 6 (2027-04-13) without accounting for (a) the likelihood that audio recording of pronunciation triggers full review; (b) the absence of a written, detailed consent template and data-use agreement in plain language; (c) the lack of a formal data-retention and deletion schedule specifying which data (audio, scores, demographics) are retained for how long and under what conditions. IRB turnaround depends critically on submission completeness: missing consent templates, data-protection statements, or privacy notices routinely trigger rejection-for-revision cycles adding 3–6 weeks.

## 4.5.A Issue - Audio Recording, Biometric Data and GDPR Compliance Are Underestimated; Learner Privacy Exposure Is Substantial

The project plans to record pronunciation audio from 460 learners (>115 per arm) across 4 sessions, plus demographic data and test scores, retaining audio for 3 years post-analysis. Under GDPR (applicable to UK pilots and EU participants), voice recordings are biometric data requiring explicit lawful-processing grounds (consent, legitimate interest, or legal obligation). The plan documents 'consent' but does not address: (1) scope of consent—are learners consenting only to research use or also to storage in an encrypted archive for 3 years? (2) right to be forgotten—learners can demand audio deletion at any time, but can the psychometric validity study be re-run without re-recording a sample, or does deletion invalidate inter-rater reliability claims? (3) cross-border transfer—if the US-based hub stores encrypted audio on cloud servers (AWS, Azure), GDPR requires data-processing agreements (DPAs) with the cloud vendor, which add 2–4 weeks of legal negotiation. (4) data-minimization principle—can inter-rater reliability be assessed on a 200-word subset instead of 5,000 entries, or is the full-corpus recording non-negotiable? The plan mentions 'encrypted storage by Month 6 (2027-04-13) and audit by Month 8 (2027-06-13)' but does not specify which encryption standard (AES-256?), key-management protocol (who holds the decryption key?), or cloud-vendor DPA status.

### 4.5.B Tags

- GDPR_biometric_data
- consent_scope_ambiguous
- data_minimization_not_optimized
- DPA_missing
- right_to_be_forgotten_unresolved
- encryption_standard_undefined

### 4.5.C Mitigation

By Month 1 (2026-11-13), commission a Data Protection Impact Assessment (DPIA) under GDPR Article 35 (or equivalent UK/US framework) to: (1) document the lawful processing ground for audio recording (proposed: explicit consent + research exemption under Schedule 1, Part 2 (academic research) of the UK DPA 2018, if applicable); (2) map retention periods for each data type (audio 3 years post-analysis, but specify when 'analysis' is complete—at Month 24 = 2028-10-13 gate or Month 30 = 2029-04-13 v1.0 release?); (3) implement data minimization: run an inter-rater calibration on a 200–300 word pilot subset (Months 8–9 = 2027-06-13 to 2027-07-13) to establish kappa, then record only the full 5,000-word corpus if kappa is confirmed >=0.70, or switch to a synthetic baseline if training does not achieve kappa; (4) detail encryption standard (AES-256, FIPS 140-2 validated, or equivalent) and key-management protocol (keys held in split custody, escrow with a third party, or on-premises only); (5) pre-negotiate a Data Processing Agreement with the selected cloud vendor (AWS, Azure, or alternative) by Month 3 (2027-01-13), specifying data location, sub-processor controls, and DPA renewal every 12 months; (6) draft a Right-to-Be-Forgotten Protocol specifying that a learner's request to delete audio is honored within 30 days, but the learner's outcome data (test scores, reading time) may be retained for analysis if anonymized post-deletion; (7) document residual risk: if more than 5% of learners (>23 per arm) request deletion during Months 13–24 (2027-11-13 to 2028-10-13), the inter-rater reliability sample may fall below N=15 per rater, triggering a re-training cycle or Cohen's kappa downgrade (target 0.75 becomes 0.70 floor). By Month 4 (2027-02-13), publish the DPIA and the draft DPA on the project website (redacting cloud-vendor confidential terms) to signal regulatory compliance to the IRB and pilot partners.

### 4.5.D Consequence

Without a DPIA and explicit data-processing grounds documented before Month 2 (2026-12-13), the IRB may classify the project as high-risk, escalating from expedited to full review (adding 4–6 weeks, approval slips to Month 7–8 = 2027-05-13 to 2027-06-13). Additionally, a UK data-protection authority (ICO) or GDPR-compliant institution could challenge the consent scope and retention schedule at any time Months 6–24 (2027-04-13 to 2028-10-13), triggering a compliance investigation and a requirement to delete audio from all participants, invalidating the inter-rater reliability score and forcing the pronunciation consistency metric to revert to a non-audio proxy (e.g., written transcripts), which is weaker and may not meet the gate threshold. In the worst case, a breach notification requirement (if audio is exposed) could trigger regulatory fines of 10–20 million EUR or up to 4% of global revenue (GDPR Article 83) and reputational damage that blocks Phase 3 adoption.

### 4.5.E Root Cause

The plan treats audio recording as a low-risk, standard-research activity and assumes standard consent is sufficient, but does not account for GDPR Article 9 (special categories of personal data, including biometrics) or the UK Data Protection Act 2018 Schedule 1 exemptions for research. The root causes are: (a) no explicit biometric-data processing-ground documented (consent alone is often insufficient; 'legitimate interest' for standards development may be arguable but requires impact assessment); (b) no data-minimization analysis—the plan records 5,000 words × 2 takes × 460 learners = 4.6M audio files without exploring whether inter-rater reliability can be established on a 500–1,000 word pilot sample, not the full corpus; (c) no vendor due-diligence or DPA pre-negotiated with cloud-storage providers; (d) a 'right to be forgotten' request mid-pilot could delete a learner's audio, invalidating that learner's data from the validity study and triggering a re-analysis that may weaken kappa estimates.

## 4.6.A Issue - Safety-Critical Liability Exposure Is Bounded but Not Eliminated; Insurance, Disclaimers and Regulatory Strategy Are Incomplete

The plan scopes safety-critical pilots to 'glossary and labeling exercises, no live operational procedures' and budgets legal/liability spend at $150K–$200K (estimate), but does not document: (1) which jurisdictions' product-liability frameworks apply (OSHA in the US, HSE in the UK, ISO 26262 or IEC 62304 for medical devices, FAA or EASA for aviation)? (2) whether the 'glossary and labeling' scope is sufficient to avoid product-liability claims if a misreading of Clear English ordinals or homophones in a label causes injury (e.g., a pharmaceutical concentration label reading '11th dose' misread as '1st' under the prefix-marker rule, resulting in overdose); (3) what insurance is available, at what cost, and whether it covers 'pilot' or 'research' use or only commercial release; (4) what disclaimers are legally sufficient to limit liability if a pilot partner uses Clear English materials in a live context without explicit authorization? The plan mentions 'retain legal counsel by Month 2 (2026-12-13)' and 'liability strategy by Month 4 (2027-02-13)', but these are not detailed: no specific scenarios, no regulatory-body notification strategy, no insurance specifications, no template disclaimers.

### 4.6.B Tags

- safety_critical_scope_ambiguous
- liability_insurance_unconfirmed
- disclaimer_language_missing
- product_liability_framework_undefined
- regulatory_notification_strategy_absent

### 4.6.C Mitigation

By Month 1 (2026-11-13), engage a lawyer specializing in product liability and regulatory compliance in both the US and UK jurisdictions (not the same counsel as the data-protection advisor, to ensure independent review). Commission a written Liability and Regulatory Landscape Analysis (3–5 pages) addressing: (1) which product-liability regimes apply to safety-critical documentation standards (US Restatement Third of Torts § 2, UK Product Liability Directive 85/374/EEC, industry-specific standards like ISO 26262 for automotive, IEC 62304 for medical devices); (2) whether a research exemption is available (e.g., FDA Good Laboratory Practice exemptions, UK Research Ethics Committee approval providing qualified immunity); (3) liability scenarios for each pilot cohort (e.g., ESL learner misreading of ordinals in a classroom glossary vs. a technical trainer introducing labeled procedures into a factory floor); (4) estimated exposure for a 'worst-case' incident (injury or property damage from misreading) and comparable verdicts or settlements in education or language-standard cases; (5) available insurance products (professional liability, errors & omissions, product liability for 'pilot' or 'developmental' standards) and rough premium estimates ($20K–$50K annually, estimate, vs. the $150K–$200K budget allocated to all legal/liability). By Month 2 (2026-12-13), also commission an Underwriting Proposal from at least two insurance brokers specializing in education or standards liability, requesting a quote for coverage of the pilot activities and conditions (coverage limit $1M–$5M per incident, estimate). By Month 4 (2027-02-13), publish a Liability Strategy Document (2 pages) on the project website specifying: (a) the chosen liability-mitigation approach (e.g., 'research exemption + institutional indemnity, combined with site-specific disclaimers and partner agreements'); (b) a Disclaimer and Consent Template for pilot partners confirming that the standard is developmental and not intended for life-critical use; (c) mandatory Human-Review Protocol specifying that all safety-critical materials must be reviewed by a native speaker and a domain expert (pharmacist, nurse, engineer) before use in any operational context; (d) incident-reporting requirements (pilot partners must report any ambiguity, misreading, or near-miss within 24 hours to the project team); (e) the regulatory notification strategy (e.g., if a serious incident occurs, notify relevant regulators—OSHA, HSE, state medical board—within 10 days as part of the project's own incident-investigation process, not to shift liability but to build transparency). Secure signed Pilot Partner Agreements by Month 6 (2027-04-13) that explicitly state the standard is experimental, that partners may not use it in live operational procedures without explicit written approval, and that partners indemnify the project from claims arising from unauthorized use. If insurance cannot be secured at a cost <$50K/year (estimate), or if the underwriter classifies safety-critical materials as 'uninsurable pilot' due to unknown risks, scale the safety-critical wedge to non-life-critical glossaries (e.g., labeling of office supplies or library materials, not pharmaceuticals or operating procedures) until post-Phase-2 evidence demonstrates that the ordinal and homograph rules are sufficiently reliable.

### 4.6.D Consequence

Without a detailed Liability Strategy and confirmed insurance by Month 4 (2027-02-13), the project risks uninsured exposure: if a pilot partner uses Clear English materials in a live setting and an injury or near-miss occurs, the project team could face product-liability claims (estimated $100K–$1M+ defense costs, settlement or judgment), regulatory investigation (OSHA recordkeeping, HSE prosecution, state board review), and reputational damage that blocks Phase 3 adoption by all technical and safety-critical partners (estimated 30–50% of adoption target). Additionally, if the IRB discovers that liability exposure has not been quantified or mitigated, it may withdraw ethics approval or downgrade the pilot to 'non-operational use only,' narrowing the scope and reducing the credibility of the safety-critical evidence at the Month 24 (2028-10-13) gate. Conversely, over-conservative disclaimers that position the standard as 'not suitable for any operational use' will deter safety-critical partners from participation, eliminating the technical-glossary cohort from pilots and reducing the overall adoption case.

### 4.6.E Root Cause

The plan treats safety-critical liability as a secondary concern ('limit pilots to glossary and labeling') and assigns it a single line item ('legal strategy by Month 4 = 2027-02-13'), without distinguishing between research liability (covered by IRB approval and institutional indemnity) and product liability (exposure to third-party injury claims, regulatory prosecution, and reputational harm). The root causes are: (a) no clarity on what 'glossary and labeling exercises' means operationally—are learners labeling pharmaceutical bottles with Clear English ordinals in a supervised classroom, or are pilot partners introducing labeled materials into actual workplace settings?; (b) no differentiation between US and UK liability frameworks (US relies on product-liability tort law; UK relies on Consumer Protection from Unfair Trading Regulations and Health & Safety at Work etc. Act 1974); (c) no assessment of whether a 'research study' exemption applies if the materials are not released commercially; (d) no insurance-market research to confirm whether liability coverage is available or affordable at $150K–$200K (estimate) for a novel, unproven standard.

---

# 5 Expert: Lexical Semantics & Controlled Vocabulary Specialist

**Knowledge**: Corpus linguistics, frequency analysis, semantic field mapping, controlled-language vocabulary design (ASD-STE100, ISO 1087), ESL core vocabulary selection, word sense disambiguation

**Why**: The 5,000-word core lexicon (4,500 frequency-led + 500 technical/safety block) is the foundation of all downstream work: the dictionary, pronunciation guidance, pilot curriculum, and homograph identification. Current selection basis (frequency-led with incident-driven optional seeding) lacks a formal ranking, gap-analysis, and collision-detection protocol. The expert will audit the lexicon against pilot running text, ensure >=85% coverage by Month 8 (2027-06-13), and surface high-friction homographs and ambiguous near-synonyms that feed Decision 7 (Homograph Disambiguation Policy) and the pronunciation-consistency metric scoring. Weak lexicon coverage or missed ambiguities reduce pilot utility by 15-30% and force Month 10-11 (2027-08-13 to 2027-09-13) rework.

**What**: By Month 4 (2027-02-13), deliver a ranked, justified 5,000-word core list with frequency bands, semantic domains, and provenance (corpus source, incident records, or syllabus). By Month 6 (2027-04-13), conduct a coverage audit against all pilot materials (ESL texts, technical manuals, safety glossaries); flag gaps and high-friction polysemes. By Month 8 (2027-06-13), finalize the list with documented exceptions and expansion justification; deliver a semantic-field map linking related terms (e.g., ordinal markers, safety procedures) to homograph-policy designers.

**Skills**: Corpus analysis and frequency profiling, semantic field and word-sense mapping, vocabulary auditing and gap analysis, controlled-vocabulary design and ISO 1087 standards, homograph and polysemy identification

**Search**: corpus linguist vocabulary selection ESL core lexicon, controlled language terminology ASD-STE100 semantic fields, word frequency analysis polysemy disambiguation

## 5.1 Primary Actions

- Hire an independent psychometrician by Month 2 (2026-12-13) and commission a power analysis, pre-analysis plan with quantitative gate thresholds, and validity study by Month 10 (2027-08-13). Pre-register the complete plan on Open Science Framework by Month 11 (2027-09-13) with board sign-off and public disclosure.
- Immediately (by Month 1 = 2026-11-13) identify and approach ≥4–5 ESL programs and ≥2–3 technical-training organizations with written pilot partnership proposals. Secure signed commitments (letters of understanding) guaranteeing ≥50 learners per partner by Month 3 (2027-01-13). Hire a dedicated Cohort Manager by Month 3 (2027-01-13) (not Month 6 = 2027-04-13) to manage recruitment, retention and incentives.
- Establish an Editorial Board Charter with explicit voting rules, tiebreak arbiter process and conflict-of-interest rules by Month 1 (2026-11-13). Schedule the first board meeting for Month 2 (2026-12-13). Assign clear owners to each rule workstream (ordinal architecture, morphology threshold, homograph policy, accent anchor) and finalize all rules by Month 11 (2027-09-13) with published rationale for any contested decisions.
- Retain legal counsel specializing in product liability and data protection by Month 2 (2026-12-13). Define the safety-critical liability strategy by Month 4 (2027-02-13), limiting pilots to glossary and labeling exercises (no live operational procedures). Obtain IRB/ethics approval by Month 6 (2027-04-13) and finalize a Data Protection Policy and informed-consent forms by Month 12 (2027-10-13).
- Begin steward-organization search by Month 12 (2027-10-13). Identify ≥2–3 candidate stewards (university consortiums, language non-profits, standards bodies) with 3+ years of audited financials. Solicit written letters of interest by Month 24 (2028-10-13) and negotiate a formal MOU committing to ≥10 years of post-v1.0 stewardship funding ($150K–$250K per year). Publish the steward commitment and 5-year stewardship roadmap with v1.0 release (Month 30 = 2029-04-13).

## 5.2 Secondary Actions

- Commission audio recording scope and vendor selection by Month 2 (2026-12-13). Identify a professional audio studio with firm capacity guarantees (5,000 files, 2 takes each, ≤4 weeks lead time from lexicon delivery). Budget $80K–$120K (estimate) and conduct a cost-per-entry audit by Month 4 (2027-02-13). If per-entry cost exceeds $20 (estimate), pivot to hybrid: speech-synthesis baseline by Month 7 (2027-05-13) plus human rater verification on the top 1,000–1,500 highest-friction words by Month 11 (2027-09-13).
- Design and implement inter-rater calibration and kappa measurement by Month 8 (2027-06-13). Recruit ≥3–4 raters with ESL or phonetics background, conduct training on the reference accent by Month 9 (2027-07-13), and measure Cohen's kappa on a 100–200-word pilot sample by Month 10 (2027-08-13). Require kappa ≥0.70 (target 0.75) before proceeding to full production. If kappa <0.70, extend Phase 1 by 4 weeks (approximately $85K) for additional rater training and retest by Month 11 (2027-09-13).
- Establish a regulatory and standards-body advisory track by Month 1 (2026-11-13). Identify key regulators (US: TESOL, state education departments, OSHA; UK: Ofqual, HSE; international: CEFR, ISO language committees). Secure advisory seats with written 2-year commitments and quarterly briefings by Month 2 (2026-12-13). Document regulatory concerns and approval pathways in a risk summary by Month 4 (2027-02-13). Determine whether formal regulatory submissions are required by Month 6 (2027-04-13).
- Draft and finalize the Licensing and Name Stewardship Policy by Month 6 (2027-04-13). Decide between three models: (a) fully permissive open license with no name control; (b) open text/dictionary with 'Clear English' as a certification mark against a free conformance checklist; (c) share-alike license requiring divergent forks to adopt distinct names. Publish the chosen policy, conformance checklist and certification process by Month 12 (2027-10-13). Establish a Standing Standards Stewardship Committee by Month 12 (2027-10-13) to manage third-party claims and divergent variants.
- Conduct a comprehensive competitor and alignment analysis by Month 3 (2027-01-13). Map Clear English against ASD-STE100, plain-language guidance, ICAO aviation English and other controlled-language standards. Determine whether a one-way mapping table, a compatibility label ('partial'), or a formal joint-development MOU with an external standards-body maintainer is warranted. Document findings in a 2–3 page strategic options memo by Month 6 (2027-04-13).
- Establish educator and publisher engagement protocols by Month 1 (2026-11-13). Recruit an Educator Liaison (0.5–1.0 FTE) by Month 3 (2027-01-13) to co-design pilot curricula with teachers, conduct quarterly practitioner advisory panels (Months 12, 18, 24, 30 = 2027-10-13, 2028-04-13, 2028-10-13, 2029-04-13), and ensure native-speaker and pedagogical feedback is integrated into rule refinement. Solicit non-binding letters of interest from ≥3–5 ESL publishers by Month 3 (2027-01-13).

## 5.3 Follow Up Consultation

At the next review (Month 3 = 2027-01-13), confirm: (1) psychometrician hired and power analysis commissioned; (2) signed pilot partner commitments (≥3 ESL programs, ≥2 technical-training organizations); (3) Editorial Board Charter published with tiebreak arbiter named; (4) legal counsel retained and safety-liability strategy finalized; (5) audio vendor identified and cost-per-entry estimate confirmed; (6) IRB/ethics approval pathway clarified; (7) steward-search workstream assigned and first candidate list drafted. Critical dependency: if any of these is missing or delayed, Phase 1 will compress and pilot evidence will degrade. Discuss fallbacks and contingency triggers (e.g., if steward commitment is unlikely by Month 18 = 2028-04-13, consider extending Phase 3 or pivoting to a lighter post-v1.0 governance model).

## 5.4.A Issue - Gate Metrics Are Proposed, Not Pre-Registered; Thresholds Lack Psychometric Justification

All four gate thresholds (ordinal error ≥25% reduction, comprehension ≤10% slower, pronunciation consistency ≥15% above control, 30-day retention ≥70%) are marked 'proposed' and remain unvalidated estimates. No power analysis confirms that ≥80 completers per arm achieves 80% statistical power to detect these effects. The pre-analysis plan is not yet commissioned, and the psychometrician hire is not scheduled until Month 2 (2026-12-13). Without pre-registered, psychometrically justified thresholds by Month 11 (2027-09-13), the Month 24 (2028-10-13) go/no-go gate will be disputable and credibility-damaging.

### 5.4.B Tags

- gate_credibility_risk
- missing_power_analysis
- pre_registration_gap
- psychometric_validation

### 5.4.C Mitigation

Hire the psychometrician by Month 2 (2026-12-13) with explicit deliverables: power analysis confirming sample size by Month 5 (2027-03-13), draft pre-analysis plan with numeric thresholds by Month 9 (2027-07-13), and independent validity review by Month 10 (2027-08-13). Pre-register the complete plan on Open Science Framework by Month 11 (2027-09-13) with board sign-off. Publish thresholds and justification publicly to forestall post-hoc disputes.

### 5.4.D Consequence

Without pre-registration, the Month 24 (2028-10-13) go/no-go becomes scientifically disputable. A false-positive gate (launching a weak standard) reduces Phase 3 adoption credibility by 30–50%. A false-negative gate (rejecting a viable standard) wastes Phase 2 investment. Stakeholders and standards bodies will demand external review, delaying adoption by 6–12 months and eroding partner confidence.

### 5.4.E Root Cause

Plan treats thresholds as illustrative examples rather than pre-locked commitments. Psychometric vendor selection and power-analysis budget are deferred, leaving no time buffer before Month 12 (2027-10-13) when rules lock and pilots must begin.

## 5.5.A Issue - Pilot Recruitment and Retention Strategy Lacks Concrete Partner Commitments and Risk Mitigation

The plan proposes signing pilot partner commitments by Month 3 (2027-01-13) but provides no current list of target ESL programs, safety-training organizations, or publisher letters of interest. No Cohort Manager is hired until Month 6 (2027-04-13), leaving a 3-month gap when recruitment logistics are unmanaged. Dropout tolerance is 30%, but with ≥115 enrollments per arm, a 30% loss leaves only 80–81 completers per arm—the bare minimum for power. No contingency plan names recruitment fallbacks or re-engagement tactics.

### 5.5.B Tags

- pilot_recruitment_gap
- no_partner_list
- cohort_manager_delay
- attrition_risk

### 5.5.C Mitigation

Immediately identify and formally approach ≥4–5 ESL programs and ≥2–3 technical-training organizations (by Month 1 = 2026-11-13) with written pilot proposals. Obtain signed letters of understanding guaranteeing ≥50 learners per partner by Month 3 (2027-01-13). Hire Cohort Manager by Month 3 (2027-01-13) (not Month 6 = 2027-04-13), allocate ≥$50K–$80K for incentives and partner payments, and establish a dropout-response protocol (outreach within 24 hours, one-time make-up sessions).

### 5.5.D Consequence

Failure to recruit ≥460 learners by Month 13 (2027-11-13) or dropout >30% reduces effective sample size below the ≥80-per-arm floor. This invalidates power for all four gate metrics, forcing a 3–6 month Phase 2 extension (≥$300K cost, straining budget) or a false-negative gate outcome that rejects a viable standard.

### 5.5.E Root Cause

Recruitment risk is identified in the SWOT but no concrete partner list or hiring schedule exists. The plan assumes ESL programs and technical-training organizations will commit without pre-existing relationships or co-designed protocols.

## 5.6.A Issue - Post-Month-36 Stewardship Is Unfunded and No Permanent Steward Is Identified; Standard Risks Atrophy

The plan correctly identifies that post-v1.0 stewardship costs $150K–$250K per year (estimate) but does not specify a funding source or named steward organization. The project currently has no revenue stream, no endowment, and no explicit commitment from a non-profit, university, or standards body to assume stewardship. Without a funded steward by Month 36 (2029-10-13), the standard will receive no corrections, no version updates, and no active governance after Phase 3 ends. Publishers and educators will lose confidence in stability within 12–24 months, degrading adoption by 30–50%.

### 5.6.B Tags

- stewardship_funding_gap
- no_named_steward
- long_term_sustainability
- post_project_atrophy

### 5.6.C Mitigation

By Month 12 (2027-10-13), identify ≥2–3 potential steward candidates (university consortium, language non-profit, or standards body with 3+ years of audited financials). By Month 24 (2028-10-13), solicit written letters of interest. By Month 30 (2029-04-13), negotiate a formal MOU committing the steward to ≥10 years of funding ($150K–$250K per year) from endowment, member fees, or organizational budget. Publish the stewardship roadmap and steward identity with v1.0 release (Month 30 = 2029-04-13).

### 5.6.D Consequence

Without a committed, funded steward by Month 30 (2029-04-13), the v1.0 release is incomplete and non-credible. Errata and change requests accumulate unanswered. Publishers withdraw support within 12–24 months (by Month 48–60 = 2030-10-13 to 2031-10-13). Adoption fails to reach the ≥3 third-party adopters target, and the project ends as an academic exercise with negligible real-world impact.

### 5.6.E Root Cause

Plan prioritizes Phase 1–3 delivery but defers long-term sustainability to the end. No steward-search workstream is budgeted or scheduled, and the $0.35M reserve cannot cover post-36-month operational costs. The project risks becoming a 'publish and abandon' exercise.

---

# 6 Expert: Orthography & Phonetics Design Engineer

**Knowledge**: Phonemic transcription, grapheme-to-phoneme rule design, phonetic pedagogy, pronunciation guidance systems, diacritical marking conventions, IPA and practical orthographies

**Why**: Decision 2 (Grapheme-to-Phoneme Intervention Depth) and Decision 8 (Reference Accent Anchor) require a mapping from 5,000 English words to a consistent sound system, with inter-rater reliability (kappa >=0.70, target 0.75) and a fixed spoken reading for the ordinal prefix. The expert will design the pronunciation-guidance overlay (printed key for print, ruby-style for digital), anchor it to one reference accent with documented phonemic inventory, and produce a rater-calibration protocol for scoring the pronunciation-consistency metric. Without expert orthographic and phonetic grounding, the overlay will be ambiguous, raters will diverge, and the pronunciation-consistency gate score will become noisy (kappa <0.70, raising the risk of false-negative or false-positive gate outcomes).

**What**: By Month 3 (2027-01-13), select and justify one reference accent (US, RP, or equivalent); document its phonemic inventory and vowel-quality conventions. By Month 5 (2027-03-13), design a minimal pronunciation-guidance notation (IPA, respelling key, or hybrid) for the 5,000-word lexicon, tested on a pilot sample (100-200 words) for rater learnability. By Month 8 (2027-06-13), produce a rater-training manual and a pronunciation-consistency scoring rubric with worked examples. By Month 10 (2027-08-13), conduct inter-rater calibration (Cohen's kappa on 100-200 words); if kappa <0.70, iterate training and notation by Month 11 (2027-09-13).

**Skills**: Phonemic transcription and IPA, grapheme-to-phoneme algorithm design, phonetic notation and teaching, accent variation mapping, rater-calibration and inter-rater reliability, pronunciation-pedagogy best practice

**Search**: phonetics pronunciation guide orthography design, ESL pronunciation teaching IPA transcription, rater calibration inter-rater reliability phonetic scoring

## 6.1 Primary Actions

- By Month 1 (2026-11-13), establish the Editorial Board Charter with explicit voting rules, a named tiebreak arbiter (or process to select one by Month 5 = 2027-03-13), and workstream assignments for ordinal design, accent selection, morphology threshold, and homograph policy. Publish the charter on the project website immediately.
- By Month 2 (2026-12-13), hire an independent psychometrician (signed contract, deliverables specified) and appoint a workstream lead for the ordinal-marker design (inclusive of the spoken-form specification). Simultaneously, retain legal counsel and engage an Institutional Review Board to initiate ethics approval.
- By Month 2 (2026-12-13), commission a 2–3 page Accent Selection Rationale Document from the accent workstream, documenting candidate accents ranked by learnability, phonological distinctiveness, and ESL learner demand. Finalize the accent by Month 3 (2027-01-13) with a 50–100 word proof-of-concept audio sample.
- By Month 2 (2026-12-13), the ordinal-marker workstream must deliver a 2–3 page Ordinal Spoken-Form Specification documenting candidate spoken forms, learnability evidence, and the chosen form. Finalize and record a proof-of-concept sample by Month 11 (2027-09-13).
- By Month 3 (2027-01-13), the psychometrician and assessment workstream must deliver a 5–8 page Instrument Specification and Feasibility Report proposing ordinal-error task formats, pronunciation-consistency scoring rubric, comprehension-speed text type, and 30-day retention protocol. Initiate a validity study with N=30–50 immediately after.
- By Month 9 (2027-07-13), deliver the complete pre-analysis plan with power calculations, effect-size estimates, and justified sample-size and threshold specifications. By Month 11 (2027-09-13), pre-register all four gate metrics and thresholds on an open repository (Open Science Framework or equivalent) with published power calculations.

## 6.2 Secondary Actions

- By Month 5 (2027-03-13), commission the psychometrician to draft a brief (2–3 page) feasibility assessment of the pronunciation-consistency scoring method: can raters reliably discriminate Clear English pronunciations from standard English within the chosen anchor? If the initial answer is uncertain, budget an additional $20K–$30K (estimate) for a mini-pilot with N=10–15 learner recordings.
- By Month 4 (2027-02-13), scope and cost the audio production in detail: solicit firm quotes from at least 2 professional recording studios for 5,000 entries with 2 takes per entry. If cost-per-entry exceeds $20 (estimate), finalize a hybrid approach: speech-synthesis baseline for all 5,000 entries by Month 7 (2027-05-13), then human-rater verification of the highest-friction 1,000–1,500 words by Month 11 (2027-09-13).
- By Month 6 (2027-04-13), obtain written ethics approval from the IRB or Research Ethics Committee and finalize the informed-consent and data-use forms in plain language. Budget encrypted audio storage and backup by this date.
- By Month 6 (2027-04-13), publish the Licensing and Name Stewardship Policy on the project website and establish a standing Standards Stewardship Committee (3–5 members) with authority to review third-party conformance claims and issue guidance on non-conforming forks.
- By Month 8 (2027-06-13), conduct a dry run of the full assessment pipeline: recruit N=5–10 learners, run them through all four gate metrics, and record any logistical, technical or scoring ambiguities. Use findings to refine the pre-analysis plan before Month 9 (2027-07-13) finalization.

## 6.3 Follow Up Consultation


At the Month 3 (2027-01-13) consultation, review: (1) Accent Selection Rationale: is the chosen accent justified and accepted by the board? Has the proof-of-concept audio been recorded and pilot-tested with 5–10 ESL learners for comprehensibility? (2) Ordinal Spoken-Form Specification: is the chosen form teachable in 1–2 exposures? Have 5–10 learners been able to learn and produce it consistently? (3) Instrument Specification: are the effect-size estimates from the validity study feasible for the ordinal-error and pronunciation tasks, or do they require sample-size increases or threshold adjustments? (4) Pilot Partner Confirmations: are signed commitments in hand from at least 3 ESL programs and 2 technical/safety organizations? If not, what recruitment contingencies are being activated? (5) Psychometrician Contracting: is the pre-analysis plan on track for Month 9 (2027-07-13) delivery and Month 11 (2027-09-13) pre-registration?


## 6.4.A Issue - Anchor Accent Choice Deferred; Pronunciation Consistency Scoring Will Fail Without It

The plan states 'One reference accent chosen and justified by Month 3 (2027-01-13)' but provides no accent selected. Pronunciation consistency kappa >=0.75 (target) cannot be reliably scored without a fixed anchor. If raters are asked to score naturalness or regional fit instead of adherence to a published anchor, inter-rater reliability drops 15–25% (typical). Pilot audio and all rater training depend on this choice. The pre-analysis plan at Month 5 (2027-03-13) cannot specify scoring procedures without it. A deferred accent choice compresses the window between accent lock (Month 3 = 2027-01-13) and rater calibration (Month 9, 2027-07-13), leaving only 6 months to train raters and achieve kappa >=0.70 floor by Month 10 (2027-08-13).

### 6.4.B Tags

- pronunciation-consistency-scoring
- rater-calibration
- reference-anchor-undefined
- measurement-validity

### 6.4.C Mitigation

By Month 1 (2026-11-13), commission a 2–3 page Accent Selection Rationale Document specifying: (a) candidate accents (RP, GenAm, Irish, etc.) ranked by teachability, learner demand in ESL contexts, and distinctiveness of phonemic contrasts; (b) phonological mapping tables showing which vowel mergers or consonant distinctions each accent encodes; (c) rater-population fit (will raters be native speakers of the anchor or trained non-natives?); (d) fallback: if no consensus by Month 3 (2027-01-13), use a 'core-contrast' approach (shared distinctions only, other realizations unspecified). Finalize accent by Month 2 (2026-12-13). Commission a 50–100 word proof-of-concept audio sample in the chosen accent by Month 4 (2027-02-13) and play it at the first board meeting to validate listener acceptance before scaling to 5,000 entries.

### 6.4.D Consequence

Without a locked anchor by Month 3 (2027-01-13), rater training slips to Month 10 (2027-08-13) or later. If inter-rater kappa falls below 0.70 at Month 10 (2027-08-13), the 4-week Phase 1 extension ($85K estimate) is triggered automatically. If the anchor is changed after rater training begins (Month 9, 2027-07-13), all trained raters must retrain, adding 4–6 weeks and $40K–$60K (estimate). Weak accent guidance also invites multiple interpretations of 'naturalness,' fragmenting pronunciation guidance across early adopters and reducing the pronunciation consistency score by 10–20%, potentially failing the Month 24 (2028-10-13) gate.

### 6.4.E Root Cause

The accent anchor (Decision 8: Reference Accent Anchor) was identified as strategically important but its selection was delegated to Month 3 (2027-01-13) without explicit criteria, justification framework, or a fallback if consensus fails. No phonological contrasts (shared vowels vs. distinctiveness) or pedagogical fit (learner populations served by each accent) have been documented. The board charter does not specify who decides accents or how tied votes are broken.

## 6.5.A Issue - Pre-Analysis Plan and Psychometric Instrument Validity Not Defended; Gate Thresholds Are Still Proposals

The plan states 'Develop a purpose-built assessment set for each of the four metrics, calibrated against a standard-English control group, and have an independent psychometrician review item validity before the pilots begin' (Decision 4: Outcome Metric Battery Design). However, no validity study design is specified, no expected effect sizes are documented, and no power analysis justifies the claimed minimum sample size of 80 completers per arm. The gate thresholds (ordinal error >=25% reduction, comprehension no more than 10% slower, pronunciation consistency >=15% above control, 30-day retention >=70%) remain proposals until pre-registered Month 11 (2027-09-13). A validity study is budgeted at $150K–$200K (estimate), with a dry run Month 10 (2027-08-13), leaving only 4 weeks to address validity failures before pre-registration lock. If the validity study reveals low discriminative power for the ordinal-error task or pronunciation task, the thresholds cannot be justified, and the gate dossier at Month 24 (2028-10-13) becomes disputable.

### 6.5.B Tags

- gate-threshold-justification
- psychometric-validity-untested
- effect-size-unknown
- power-analysis-missing
- ordinal-task-design-unspecified

### 6.5.C Mitigation

By Month 3 (2027-01-13), commission the psychometrician to deliver a 5–8 page Instrument Specification and Feasibility Report detailing: (a) ordinal-error measurement: propose 2–3 candidate task formats (e.g., reading-to-matching, ordinal-in-context comprehension, error-spotting in a procedure), justify which is most sensitive to ordinal-marker effects, and cite prior evidence or pilot data if available; (b) pronunciation consistency: specify the anchor-dependent scoring rubric (phonemic accuracy vs. native-like naturalness), define kappa calculation method (pairwise inter-rater agreement vs. multi-rater consensus), and justify the kappa >=0.75 target; (c) comprehension speed: define which text type (narrative, procedural, technical) best isolates spelling-to-sound effects; (d) 30-day retention: specify whether retention is measured by re-test accuracy, self-report, or engagement metrics. By Month 5 (2027-03-13), initiate the validity study with N=30–50 (increased from proposed 20–30 estimate) to estimate effect sizes for ordinal error, pronunciation, and reading speed under the Clear English variant. By Month 9 (2027-07-13), deliver final pre-analysis plan with power calculations and threshold justification; if any threshold falls below the 80% statistical-power bar, flag to the board by Month 10 (2027-08-13) for adjustment or sample-size increase. Pre-register by Month 11 (2027-09-13) with published power calculations so the gate cannot be disputed.

### 6.5.D Consequence

If the validity study is skipped or compressed (Month 10 = 2027-08-13 only), validity problems (e.g., ceiling effects in ordinal accuracy, kappa <0.60 for pronunciation) are discovered at Month 18–20 (2028-04-13 to 2028-06-13) after 6+ weeks of pilot data have been collected. Re-scoring or re-designing assessments compresses analysis, delays the gate dossier by 6–8 weeks, and introduces post-hoc methodological choices that invite stakeholder challenge. A no-go or inconclusive outcome at Month 24 (2028-10-13) triggers a 3-month Phase 2 extension ($300K estimate), consuming 25% of the project reserve. Weak or unpublished thresholds also invite educators and standards bodies to dismiss the gate outcome as arbitrary, reducing Phase 3 adoption by 20–30%.

### 6.5.E Root Cause

The decision to commission purpose-built assessments (rather than adapt off-the-shelf instruments) was driven by the need to measure ordinal and pronunciation effects specific to Clear English. However, no ordinal-error measurement task has been piloted, no item pool for pronunciation consistency has been validated, and no effect-size estimates from comparable interventions have been documented. The pre-analysis plan is due Month 9 (2027-07-13), but the validity study (N=20–30, estimate) must run Months 10–11 (2027-08-13 to 2027-09-13) in parallel, compressing the timeline. If the validity study uncovers that the ordinal marker requires 3–5 exposures to reach 90% accuracy (instead of the assumed 1–2), the effect-size estimate changes, and sample-size calculations must be redone.

## 6.6.A Issue - Ordinal Marker Spoken Form Unspecified; Pilot Learners Will Not Know How to Read It Aloud

Decision 1 (Ordinal Marker Architecture) selects 'numeric ordinals with an invariant prefix marker placed before the digits,' with 'fixed spoken reading published.' However, the spoken form is not specified. What is the spoken form: 'prefix-ONE' (e.g., 'prefix one' for 1), 'clear-one,' a single phoneme /ə/, or a silent marker? How does a learner know whether '○1' (hypothetical example) is read aloud as a word, an abbreviation, or silently skipped? If the spoken form is ambiguous, learners produce inconsistent speech, raters score inconsistently, and the pronunciation consistency score at the Month 24 (2028-10-13) gate inflates measurement noise by 15–30%. Pilot participants cannot be trained on a marker whose spoken reading is not finalized. A marker symbol and spoken form are both part of the ordinal rule, not downstream implementation choices.

### 6.6.B Tags

- ordinal-spoken-form-undefined
- rule-specification-incomplete
- learner-training-impossible
- pronunciation-scoring-ambiguous

### 6.6.C Mitigation

By Month 2 (2026-12-13), the ordinal-marker workstream (workstream owner assigned by Month 2 = 2026-12-13 per the Editorial Board Charter) must deliver a 2–3 page Ordinal Spoken-Form Specification documenting: (a) candidate spoken forms (single morpheme, e.g., 'ord' or /ɔɹd/, vs. a phrase like 'ordinal', vs. silent or letter-spelling); (b) learnability evidence or examples from other constructed orthographies (e.g., how Japanese furigana annotations are read; how acronyms like 'URL' are handled in ESL); (c) pilotability: how will learners be trained in 1–2 exposures to produce it consistently? (d) alternative: if no consensus on a spoken form emerges, defer marker speech to an optional-annotation approach where learners may read the digit aloud (e.g., '1' as 'one') and the marker silent, accepting lower pronunciation consistency but avoiding ambiguity. Finalize the spoken form by Month 10 (2027-08-13) and record a 20–50 word proof-of-concept sample by Month 11 (2027-09-13) to validate rater and learner comprehension before the pilots begin at Month 13 (2027-11-13).

### 6.6.D Consequence

If the ordinal marker's spoken form is not finalized by Month 10 (2027-08-13), rater training is delayed 4–6 weeks, and inter-rater calibration slips to Month 11 (2027-09-13) or beyond, compressing the Phase 1 buffer to zero. If the form is ambiguous during pilots (Months 13–24 = 2027-11-13 to 2028-10-13), learners produce inconsistent pronunciations, kappa for pronunciation scoring drops below 0.70, and the Phase 1 extension is triggered or the pronunciation gate metric is lost. Learners cannot be effectively trained in reading ordinals if they do not know whether the marker produces a word, silence, or a letter-name. This ambiguity is a direct cause of failure to meet the Month 12 (2027-10-13) exit gate (kappa >=0.70 floor) and forces a 4–8 week extension and rework at a cost of $85K–$150K (estimate).

### 6.6.E Root Cause

The ordinal-marker design has been treated as a symbol-and-mechanics choice ('prefix placement,' 'invariant,' 'mechanical conversion') without specifying the phonological commitment. The plan assumes a 'fixed spoken reading for that suffix' (Decision 1) or 'published' reading (canonical facts) but does not specify what that reading is. This is a phonological design gap: deciding that the marker is 'a prefix' does not decide whether it is read, silent, or abbreviated. Without that decision, the first rater-training session at Month 9 (2027-07-13) cannot proceed because raters have no model of what learners should produce.

---

# 7 Expert: Technical Writing & Safety-Critical Documentation Advisor

**Knowledge**: Simplified technical English, safety-critical documentation standards (IEC 62304, DO-178C, ISO/IEC 80601), procedure design, risk-informed writing, industry-specific glossaries (aviation, medical, industrial)

**Why**: The safety-critical adoption wedge (technical glossary and labeling cohort) is the project's highest-value, highest-liability scenario, but governance and content oversight are underspecified. This expert will co-design the technical-glossary content (500-word reserved block of the core lexicon), ensure alignment or documented divergence from ASD-STE100 and plain-language standards (Decision 12: Controlled-Language Alignment Posture), and advise on liability containment (glossary and labeling only, no live procedures before Month 24 = 2028-10-13). The expert will also help interpret the homograph-disambiguation policy (Decision 7) for safety contexts, where a misread 'lead/lead' could cause incident-level harm. Without safety-critical expertise, the glossary will omit domain-critical terms, liability exposure will be unquantified, and adopters will perceive the standard as outside safety governance, blocking the technical wedge's credibility.

**What**: By Month 2 (2026-12-13), audit existing safety-critical documentation standards and glossaries (industrial, medical, aviation) to identify the 500-word technical-safety block and gaps. By Month 5 (2027-03-13), co-design a safety-critical style guide (procedure layout, homograph warnings, disclaimer language) and advise legal counsel on liability thresholds (what document types are safe for pilot use before Month 24 = 2028-10-13). By Month 8 (2027-06-13), deliver a technical-glossary pilot sample (100-200 words, real procedure excerpts) for readability and error-rate testing. By Month 12 (2027-10-13), produce a technical-adoption roadmap post-Phase-2, positioning Clear English as an optional best-practice overlay on existing safety systems, not a replacement.

**Skills**: Safety-critical documentation standards (IEC, DO-178C, ISO), simplified technical writing and ASD-STE100 practice, risk assessment and incident-level harm analysis, procedure design and user-interface language, regulatory compliance (OSHA, HSE, industry-specific authorities)

**Search**: safety-critical documentation technical writing IEC 62304 DO-178C, simplified technical English procedure design, risk management documentation standards aviation medical industrial

## 7.1 Primary Actions

- Hire an independent psychometrician by Month 2 (2026-12-13) with a signed contract specifying: quantitative thresholds for ordinal error (≥25% relative reduction, finalized), comprehension speed (≤10% slower), pronunciation consistency (≥15% above control, Cohen's kappa ≥0.75 target, ≥0.70 floor), and 30-day retention (≥70%). Require a draft pre-analysis plan with power analysis by Month 5 (2027-03-13) and pre-registration on Open Science Framework by Month 11 (2027-09-13), 30 days before Phase 2 start. Publish registered thresholds publicly by Month 11 (2027-09-13) to foreclose post-hoc disputes at the Month 24 (2028-10-13) gate.
- Secure signed pilot partner commitments (letters of understanding) by Month 3 (2027-01-13) from ≥3 adult ESL programs and ≥2 technical/safety-training organizations, guaranteeing ≥50 learners per partner and enrollment completion by Month 13 (2027-11-13). Include penalty or make-up clauses for recruitment shortfalls. Hire a dedicated 1.5 FTE cohort manager by Month 3 (2027-01-13) (not Month 6 = 2027-04-13) with a 0.5 FTE assistant to manage enrollment, retention and incentives. Conduct a small recruitment pilot at one site in Months 3-5 (2027-01-13 to 2027-03-13) to validate dropout assumptions and refine incentives. Over-recruit to ≥115 per arm (460 total) and budget $30K-$50K contingency for recruitment shortfall or re-engagement costs.
- Establish Editorial Board Charter by Month 1 (2026-11-13) specifying voting rules, tiebreak arbitration mechanism (external neutral arbiter, cost ≤$5K per decision), and conflict-of-interest disclosure. Assign rule-specification workstreams to board subcommittees with clear owners and Month 10 (2027-08-13) draft deadlines for ordinal marker (Decision 1), morphology threshold (Decision 6), homograph policy (Decision 7) and accent anchor (Decision 8). Resolve all board disputes by Month 10 (2027-08-13) and freeze rules at Month 12 (2027-10-13). Secure the external arbiter's agreement and fee schedule by Month 5 (2027-03-13) for any tie-breaking votes.
- Conduct a regulatory and liability landscape analysis by Month 1 (2026-11-13) (40 hours, $5K-$10K) documenting approval pathways, timelines and insurance requirements. Retain legal counsel with product-liability specialization by Month 2 (2026-12-13) and set the liability strategy by Month 4 (2027-02-13). Establish a full-time Regulatory Affairs workstream (1.0 FTE) by Month 1 (2026-11-13) to proactively engage US and UK regulators (Ofqual, OSHA, HSE, state education departments) in Months 5-6 (2027-03-13 to 2027-04-13) for written advisory input on the 'glossary and labeling' pilot scope. If formal approval is required with a 4+ month timeline, create a post-Month-24 (2028-10-13) Phase 2.5 research track for safety-critical work so main ESL pilots are not compressed.
- Secure written audio studio capacity commitments and inter-rater training protocols by Month 2 (2026-12-13). Contract with ≥1 professional studio for 5,000-entry recording with firm timeline (≤4 weeks lead), technical specs and backup vendor. Budget $80K-$120K and conduct a cost-per-entry audit by Month 4 (2027-02-13); if cost exceeds $20 per entry, switch to speech-synthesis baseline plus human verification of the highest-friction 1,000-1,500 words. Recruit 3-4 raters with ESL or phonetics background and complete inter-rater training on a 100-200 word pilot sample by Month 9 (2027-07-13). Measure Cohen's kappa by Month 10 (2027-08-13) and require ≥0.70 (target ≥0.75) before full production; if kappa <0.70, extend Phase 1 by 4 weeks (≈$85K) or reduce scope to 3,000-4,000 words with board approval.

## 7.2 Secondary Actions

- Publish Editorial Board Charter on the project website by Month 1 (2026-11-13) and hold the first board meeting by Month 2 (2026-12-13). Establish subcommittees for ordinal, morphology, homograph and accent decisions with clear owners and Month 10 (2027-08-13) draft-rule deadlines. Publish final rules with both majority and minority positions on contested items by Month 12 (2027-10-13), along with a 30-day public comment summary.
- Develop a Data Protection and Privacy Policy compliant with GDPR and US state laws by Month 8 (2027-06-13), specifying: data types collected (pronunciation audio, test scores, demographics), retention periods (audio 3 years post-analysis, scores 5 years), access controls (authorized team only, signed data-use agreements), encryption and backup protocols. Engage an Institutional Review Board or Research Ethics Committee by Month 2 (2026-12-13) and obtain written ethics approval by Month 6 (2027-04-13). Publish informed-consent forms and data-use agreements in plain language and multiple ESL languages by Month 10 (2027-08-13).
- Commission a lawyer specializing in intellectual property and language standards by Month 3 (2027-01-13) to draft three alternative licensing scenarios (fully permissive open, name-as-certification-mark, share-alike with divergence tracking). Have the editorial board vote on and publish the chosen Licensing and Name Stewardship Policy by Month 6 (2027-04-13). Establish a standing Standards Stewardship Committee (3-5 board members, 2-4 hours per month) by Month 12 (2027-10-13) with explicit authority to review third-party conformance claims and maintain a public registry of certified/approved materials and variants. Conduct a first conformance audit at Month 15 (2028-01-13) and publish findings on the project website by Month 16 (2028-02-13).
- Identify 2-3 potential permanent steward organizations (language-education non-profits, university consortiums, standards bodies) by Month 18 (2028-04-13) and evaluate their financial stability, mission alignment and standards-maintenance experience. Approach top 2 candidates with a formal Stewardship Proposal by Month 24 (2028-10-13) (coinciding with the go/no-go gate) specifying annual funding ($150K-$250K), responsibilities and decision authority. Request written letters of interest by Month 27 (2029-01-13) and finalize a Memorandum of Understanding by Month 30 (2029-04-13) before v1.0 release. Publish a 5-year Stewardship Roadmap by Month 36 (2029-10-13) documenting review cycles, change-request prioritization and the Stewardship Committee charter.
- Conduct a small recruitment and retention pilot at 1-2 partner sites in Months 3-5 (2027-01-13 to 2027-03-13) with 20-30 learners to validate dropout assumptions and refine incentive amounts ($50-$150 stipend, course credits, certificates). Document weekly completion rates and flag any site below 65% for re-engagement protocols. Use pilot findings to adjust the main-phase recruitment strategy and incentive budget before Month 12 (2027-10-13) enrollment launch.
- Prepare formal regulatory submissions to Ofqual (UK), state education departments (US) and relevant safety regulators (OSHA, HSE) by Month 15 (2028-01-13) with a realistic 4-8 month review timeline. Request expedited review or research-study classification if available. Monitor for approval delays and flag any timeline longer than 6 months to the editorial board by Month 12 (2027-10-13) so that Phase 2 pilots can be restructured as research studies to avoid mandatory approval.
- Establish a communication and outreach workstream (0.5-1.0 FTE) by Month 3 (2027-01-13) to manage quarterly briefings with regulatory and standards-body advisors, publish monthly project updates on the website, and prepare a Phase 1 final report for Month 12 (2027-10-13) summarizing rules, lexicon, pronunciation guidance and early evidence on acceptability of the prefix ordinal marker.

## 7.3 Follow Up Consultation

["At Month 3 (2027-01-13), review signed pilot partner commitments, recruitment pilot data, and initial psychometrician scope. Confirm the Reference Accent Anchor choice and justification, and validate that the external board arbiter has agreed to their role and fee. Assess cohort-manager hiring progress and the audiorecording RFP timeline. Address any slippage in board charter publication or rule-specification workstream kickoff.", "At Month 6 (2027-04-13), conduct a mid-Phase-1 critical-path review: confirm ethics approval status, audit pilot studio capacity and cost-per-entry estimates, review the draft pre-analysis plan from the psychometrician, and assess rule-drafting progress in the board subcommittees. Confirm the Regulatory Affairs workstream is engaged with advisors and obtaining written input on the glossary-and-labeling scope. Address insurance quotes and liability strategy decisions.", "At Month 10 (2027-08-13), conduct a Phase 1 exit-readiness review: validate inter-rater kappa ≥0.70 on the training sample, confirm all four gate thresholds are finalized and ready for pre-registration, review the draft standard and prepare for the 30-day public comment window. Ensure board rule disputes are resolved and the arbiter (if needed) has issued tie-breaking decisions. Confirm pilot partner enrollment is tracking toward 115 per arm by Month 13 (2027-11-13).", "At Month 18 (2028-04-13), conduct a Phase 2 midpoint check: verify that enrollment reached ≥115 per arm by Month 13 (2027-11-13), assess dropout rates and conduct a mid-phase retention check. Review preliminary comprehension-speed and pronunciation-consistency results (if available from the first cohort). Flag any site below 65% completion for re-engagement. Begin early steward-organization outreach and assess interest in a formal proposal."]

## 7.4.A Issue - Pre-Registration Thresholds Remain Proposals, Not Locked Commitments; Gate Credibility Is at Risk

The pre-analysis plan and gate thresholds (ordinal error ≥25%, comprehension speed ≤10% slower, pronunciation consistency ≥15% above control, 30-day retention ≥70%) are labelled 'proposed' throughout the canonical facts and risk assessments. No signed commitment from the independent psychometrician exists; no power analysis confirming that 80 completers per arm achieves 80% statistical power for these effect sizes; no threshold for inter-rater kappa reliability is pre-locked. At Month 11 (2027-09-13), three documents require simultaneous publication: a pre-analysis plan, thresholds and a 30-day public comment window. Without locked thresholds by Month 9 (2027-07-13), stakeholders can dispute the gate outcome as post-hoc tuning, and educators/standards bodies will reject the result as scientifically undefensible. This is a critical path item with zero schedule buffer.

### 7.4.B Tags

- gate-credibility
- metrics-not-locked
- psychometrician-not-hired
- power-analysis-missing

### 7.4.C Mitigation

By Month 1.5 (2026-11-28), publish a Request for Proposals (RFP) for the independent psychometrician specifying: deliverables (pre-analysis plan, power analysis for ≥80 per arm with published effect-size assumptions, validity study design, rater-training protocol, inter-rater kappa calibration by Month 10 = 2027-08-13). By Month 2 (2026-12-13), have a signed contract. By Month 5 (2027-03-13), receive the draft pre-analysis plan including justification for each threshold. By Month 9 (2027-07-13), finalize thresholds and deposit on Open Science Framework. Month 11 (2027-09-13) comment window then proceeds with a defensible, auditable baseline. Allocate $200K (within the $150K-$200K psychometrics budget) for this work and bump the critical path.

### 7.4.D Consequence

Without locked, pre-registered thresholds, the Month 24 (2028-10-13) go/no-go decision is disputable. Educators, standards bodies (TESOL, Ofqual) and publishers will claim the gate was tuned to produce a GO. A false-positive GO launches a weak standard with low Phase 3 adoption (risk: 20-50% uptake reduction). A false-negative NO-GO on inconclusive data triggers a $300K-$600K Phase 2 extension that exhausts the $175K pre-gate reserve and produces a shortfall. Either outcome erodes stakeholder confidence and undermines the 'adoption-first, evidence-gated' positioning that is the project's core legitimacy claim.

### 7.4.E Root Cause

No psychometrician hired; thresholds chosen by example rather than pre-registered; power analysis deferred. The pre-project assessment identifies this as the top priority action, but the canonical facts do not confirm a hire or a signed contract. Threshold proposals derive from the initial plan document, not from validated research design.

## 7.5.A Issue - Pilot Recruitment and Retention Risks Are Underestimated; Fallback Capacity Is Weak

The plan requires ≥80 completers per arm (320 total across 4 arms) by Month 22 (2028-08-13), with enrolment ≥115 per arm (460 total) by Month 13 (2027-11-13) and dropout ≤30%. Pilot partner commitments are due Month 3 (2027-01-13), and a cohort manager is not hired until Month 6 (2027-04-13)—a 3-month gap where recruitment momentum is lost. The 30% dropout tolerance (80 / 0.70 ≈ 114) is high for adult learners in month-long assessments; typical ESL pilot dropout is 30-50%. No fallback is budgeted if enrolment misses 115 per arm; the partner commitments specify 'minimum guaranteed cohort size' but no penalty or recovery plan if they miss. Safety-critical cohort is secondary and unproven in terms of recruitment speed or incentive effectiveness. A single cohort manager with no assistant creates a bottleneck for 460 participants across 5-7 sites.

### 7.5.B Tags

- recruitment-risk
- dropout-unproven
- cohort-manager-single-point-failure
- partner-commitments-not-signed

### 7.5.C Mitigation

By Month 1.5 (2026-11-28), identify 6-8 candidate ESL programs and 3-4 technical/safety-training organizations; send RFPs with a clear enrollment guarantee (≥50 per partner by Month 13 = 2027-11-13) and a penalty clause (e.g., $5K per learner shortfall, or a make-up recruitment window by Month 15 = 2028-01-13). By Month 3 (2027-01-13), secure signed agreements. Hire the cohort manager by Month 3 (2027-01-13) (not Month 6 = 2027-04-13) as a 1.5 FTE role with an assistant (0.5 FTE) to manage enrollment, retention and incentive logistics. Run a small pilot recruitment test (20-30 learners) at one site during Months 3-5 (2027-01-13 to 2027-03-13) to validate dropout assumptions and refine incentive design. Budget an additional $30K-$50K for recruitment shortfall contingency (bonus payments, gift cards, course credits if dropout exceeds 25%). Document dropout and completion rates weekly and flag any site below 65% completion at Month 18 (2028-04-13) for immediate re-engagement or replacement.

### 7.5.D Consequence

Pilot sample size below 80 per arm reduces statistical power by 10-15% and increases the probability of a false-negative gate outcome (missing a real effect) or an inconclusive result that triggers a $300K-$600K extension. Dropout above 40% effectively reduces the sample to <60 per arm, invalidating the power analysis entirely and making the gate result scientifically indefensible. This directly threatens the Month 24 (2028-10-13) GO/NO-GO credibility and extends Phase 2 by 3-6 months, consuming $300K-$600K of the $175K pre-gate reserve and forcing either a budget overrun or a scaled retreat to 2,000-word lexicon or fewer pilot sites.

### 7.5.E Root Cause

ESL and technical training partnerships are 'proposed' (not signed); recruitment timelines and dropout rates are estimates from standard ESL studies, not validated for this pilot design. Cohort manager hire is scheduled after commitments are signed, creating a 3-month gap. No contingency budget for recruitment shortfall or dropout above 30%.

## 7.6.A Issue - Safety-Critical Liability and Regulatory Approval Pathways Are Identified but Not Actively Managed; Delayed Approvals Will Compress Pilots

The plan includes a safety-critical adoption wedge (technical glossary cohort) but defers detailed liability and regulatory analysis to Month 2 (2026-12-13) and Month 4 (2027-02-13). The pre-project assessment flags that rejection by educational authorities (Ofqual, state education departments) is a 'high-likelihood, high-severity risk' with 30-50% adoption impact, yet the Regulatory Affairs workstream is not established until Month 3 (2027-01-13) at 0.5 FTE. Legal counsel is retained by Month 2 (2026-12-13) but the liability strategy is not set until Month 4 (2027-02-13)—two months into the project. If a formal regulatory submission is required (e.g., to Ofqual for accreditation of pilot curriculum), the plan acknowledges a 4-8 month review window, with no contingency path if approval is delayed. The risk register notes that regulatory delays could compress Phase 2 by 4-8 months, yet no pilot-as-research-study fallback is budgeted or pre-negotiated with ethics committees or regulators. Insurance availability and cost for safety-critical materials is not confirmed.

### 7.6.B Tags

- liability-unvalidated
- regulatory-approval-risk
- safety-critical-undefined-scope
- insurance-availability-unknown

### 7.6.C Mitigation

By Month 1 (2026-11-13), commission a regulatory and liability landscape analysis (by the legal counsel or a specialized consultant, 40 hours, $5K-$10K estimate) identifying: (a) whether pilot materials require formal regulatory approval in target jurisdictions (US, UK); (b) approval timeline if required (4-8 months, estimate); (c) whether a 'research study' classification can avoid approval or accelerate it; (d) insurance requirements and preliminary quotes for $1M-$5M product liability coverage. By Month 2 (2026-12-13), have legal counsel retain a product-liability specialist and secure written insurance quotes. Establish a Standing Regulatory Affairs workstream (1.0 FTE, not 0.5) by Month 1 (2026-11-13) to proactively engage regulators (Ofqual, OSHA, HSE) in March-April 2027 (Months 5-6 = 2027-03-13 to 2027-04-13) for non-binding advisory input on the 'glossary and labeling' scope—obtain written responses confirming this scope does not trigger mandatory approval by Month 8 (2027-06-13). If approval is required and takes 4+ months, shift safety-critical pilots to a post-Month-24 (2028-10-13) Phase 2.5 (Months 24-30 = 2028-10-13 to 2029-04-13) research track, funded from Phase 3 reserve, so main ESL pilots are not compressed. Pre-negotiate with ethics committees that pilot data can be used for both educational and safety-efficacy analysis.

### 7.6.D Consequence

If regulatory approval is required but not anticipated, a 4-8 month delay compresses Phase 2 pilots by 33-67%, reducing assessment window from 12 months to 4-8 months. This inflates measurement noise, reduces time for recruitment, and forces a shortened follow-up window (<30 days instead of the target 30-day retention assessment). The gate metrics become inconclusive and trigger a $300K-$600K Phase 2 extension or a NO-GO outcome that wastes the $1.2M Phase 2 spend. Insurance unavailability or cost exceeding $50K annually forces a retreat to non-procedural glossary-only pilots, eliminating the high-impact homograph-disambiguation evidence and reducing adoption value for safety-critical organizations. This directly threatens the safety-critical wedge credibility and the 'adoption-first, evidence-gated' positioning.

### 7.6.E Root Cause

Safety-critical adoption is attractive for high-impact evidence (e.g., homograph disambiguation reduces misreading in procedures) but is not treated as a distinct risk stream with its own approval and insurance pathway. Regulatory landscape assessment is deferred; approval contingencies are not pre-negotiated; insurance quotes are not obtained. The project assumes a 'glossary and labeling' scope for safety pilots (low-risk) but has not obtained written approval from regulators or safety bodies that this scope avoids mandatory approval delays.

---

# 8 Expert: Project Budget & Risk Officer

**Knowledge**: Project financial management, earned-value tracking, budget-contingency reserves, scenario-cost modeling, critical-path scheduling, risk-quantification frameworks (RACI, risk-register integration)

**Why**: The $3.5M budget is fixed and granular: Phase 1 $1.1M, Phase 2 $1.2M, Phase 3 $0.85M, reserve $0.35M. Current risk mitigation assumes a 4-week Phase 1 extension ($85K) and a 3-month Phase 2 extension ($300K), leaving only $35K headroom (estimate). The budget officer will establish monthly earned-value tracking, a rolling cash-flow forecast, and decision rules for reserve draws (current cap: $175K pre-gate). Without rigorous tracking, slippage in audio production ($80K-$120K, Month 6-11 = 2027-04-13 to 2027-09-13), assessment design ($150K-$200K), or partner incentives ($78K-$161K) will exceed the pre-gate cap unnoticed, forcing mid-phase scope cuts or timeline compression that invalidate pilots. The officer will also quantify the cost of each risk scenario (e.g., 6-month Phase 2 extension = $600K, exceeding all reserves), tie them to the go/no-go gate and post-stewardship funding gap ($150K-$250K/yr, $1.5M-$2.5M over 10 years, unfunded).

**What**: By Month 1 (2026-11-13), establish a financial baseline: itemize all Phase 1 and Phase 2 costs by workstream (rules, lexicon, audio, assessment, recruitment, staffing, travel, legal), set monthly burn rates, and publish a rolling cash-flow forecast. By Month 3 (2027-01-13), institute monthly earned-value reviews: track spend-to-date against plan, flag any category exceeding plan by >10%, and model the cost of the two identified fallback scenarios (Phase 1 extension $85K, Phase 2 extension $300K). By Month 12 (2027-10-13), conduct the Phase 1 exit-gate financial review: confirm all pre-gate expenses, validate the reserve balance, and present the reserve-release decision to the board (how much of the $350K reserve is released post-NO-GO or retained post-GO for Phase 3). By Month 24 (2028-10-13), quantify the post-Phase-3 stewardship funding gap and present three scenarios: (a) secured steward organization with committed funding, (b) fundraising/endowment plan requiring $X by Month 36 (2029-10-13), or (c) scaled stewardship (e.g., annual review only, no continuous maintenance).

**Skills**: Project financial management and earned-value analysis, cash-flow forecasting and variance analysis, budget-contingency reserve rules and decision gates, cost-scenario modeling and Monte-Carlo simulation, critical-path and schedule-risk integration, RACI assignment and spending authority

**Search**: project budget manager earned-value analysis reserves, financial planning contingency risk quantification, critical-path schedule cost integration Monte Carlo

## 8.1 Primary Actions

- Establish a monthly cash-flow baseline and earned-value tracking system by Month 1 (2026-11-13): allocate the $1.1M Phase 1 budget across 12 line items (staff, audio, lexicon, assessment, admin); set hard variance triggers (>10% overrun = $33K at Month 2 = 2026-12-13 triggers board variance review within 5 days); publish revised cash-flow forecasts at Months 3, 6 and 9 (2027-01-13, 2027-04-13, 2027-07-13); establish a single named Budget Owner accountable for weekly variance reconciliation.
- Commission and deliver a Power Analysis Memo (2-3 pages) from the independent psychometrician by Month 5 (2027-03-13): specify effect sizes for all four gate metrics (ordinal error, comprehension speed, pronunciation consistency, 30-day retention) with justifying literature citations; conduct power analysis showing required sample size per arm for 80% power at α=0.05; propose a final decision rule (GO/INCONCLUSIVE/NO-GO) for the board. Circulate to the board by Month 6 (2027-04-13) for approval.
- Conduct a 3-month Pilot Baseline Study (Months 1-2 = 2026-11-13 to 2026-12-13) with 2-3 candidate ESL programs and 1 technical-training organization (budget $15K-$20K, estimate): measure realistic recruitment rate (% of eligible → enrolment), dropout by session, and demographic retention patterns; generate probabilistic recruitment model with 50th/75th/90th percentile scenarios; use 75th percentile dropout (not 30%) as planning baseline. Document findings in a Pilot Recruitment and Retention Plan (2-3 pages) by Month 2 (2026-12-13).
- Hire the Phase 2 Cohort Manager by Month 4 (2027-02-13) (not Month 6 = 2027-04-13): allocate 30% of their time Months 4-12 (2027-02-13 to 2027-10-13) to pre-Phase-2 recruitment support and contingency planning; establish monthly enrollment milestones (40% by Month 8 = 2027-06-13, 70% by Month 10 = 2027-08-13, 100% by Month 13 = 2027-11-13) with automatic escalation if missed by >2 weeks (e.g., increased incentives, evening sessions, $20K-$30K budget, estimate).
- Freeze the pre-analysis plan and finalize all four gate thresholds by Month 11 (2027-09-13 at 14:00) with the psychometrician's full written justification and sample-size power curves; register on Open Science Framework with board sign-off; publish on the project website immediately; commission an independent external expert review of the pre-analysis plan by Month 12 (2027-10-13) and publish their summary on the website to establish external credibility.
- Establish a monthly Pilot Retention Dashboard (tracked by the cohort manager) visible to the board by Month 4 (2027-02-13): cumulative enrollments, dropout-to-date (with reasons), projected completers at Month 22 (2028-08-13), and a 95% confidence interval on final sample size; flag to the board if lower bound falls below 70 per arm, triggering automatic Phase 2 delay decision by Month 15 (2028-01-13) (before data collection) rather than post-hoc when too late to recover.
- Establish Phase 1 stage gates with cost baselines and scope-control triggers by Month 1 (2026-11-13): define a go/no-go for each major Phase 1 deliverable (ordinal rule lock at Month 10 = 2027-08-13, audio delivery complete at Month 10 = 2027-08-13, inter-rater kappa ≥0.70 by Month 10 = 2027-08-13, rules pre-registered by Month 11 = 2027-09-13); if any deliverable is at risk >3 weeks in advance, convene an emergency board meeting within 5 days to approve either a scope cut (e.g., 4,000-word lexicon instead of 5,000) or a phased release of the pre-gate reserve (up to $50K with specific justification).

## 8.2 Secondary Actions

- Conduct a budget sensitivity analysis by Month 2 (2026-12-13): model cost scenarios for audio production (per-entry cost $15, $20, $25), rater training (2 weeks vs. 4 weeks), Phase 1 extension (2-week, 4-week options), and Phase 2 cohort-manager staffing intensity; identify the top 5 cost drivers (likely: audio production, participant incentives, partner payments, cohort management, psychometric instrument design) and assign contingency reserves to each.
- Develop a vendor-cost benchmarking and RFQ process by Month 2 (2026-12-13): obtain firm quotes from 2-3 audio studios, 2-3 psychometric assessment platforms, and 2-3 cohort-management or data-collection software tools; lock pricing and capacity guarantees by Month 4 (2027-02-13) to prevent mid-project cost surprises. Document price trends and capacity constraints in a quarterly Cost Update memo for the board.
- Establish a Change-Request Control Process by Month 1 (2026-11-13): define when scope changes (e.g., expanding the lexicon to 6,000 words, adding a second accent, extending recruitment) require board approval and a formal cost-impact analysis; require all in-flight change requests to be logged and tracked with estimated cost impact; report cumulative change-request impacts at Months 6 and 12 (2027-04-13 and 2027-10-13) to the board so surprises are minimized.
- Establish a Phase 2 Budget Envelope and Commitment Schedule by Month 6 (2027-04-13): finalize partner payment agreements (per-session, per-learner, or lump-sum) with signed contracts; lock incentive amounts ($50-$150 per learner, confirm at Month 3 = 2027-01-13); establish quarterly financial reconciliations with each partner to prevent billing disputes and ensure spending aligns with enrolment and retention milestones.
- Commission a Post-Month-36 Stewardship Funding Strategy memo by Month 12 (2027-10-13): identify 2-3 potential steward organizations, model annual stewardship costs ($150K-$250K, estimate, broken down by role, activities, tooling), and propose funding mechanisms (endowment, membership fees, grant funding from foundation or government, organizational budget allocation from steward). Recommend the board begin steward outreach by Month 18 (2028-04-13) to secure a written commitment before the Month 24 (2028-10-13) go/no-go, ensuring no funding gap at Month 36 (2029-10-13).
- Establish quarterly Risk and Financial Health Briefings for the board by Month 3 (2027-01-13): prepare a 2-page Executive Summary at Months 3, 6, 9, 12 (2027-01-13, 2027-04-13, 2027-07-13, 2027-10-13) and Months 15, 18, 21, 24 (2028-01-13, 2028-04-13, 2028-07-13, 2028-10-13) covering: cumulative spend vs. budget, earned-value metrics (schedule performance index, cost performance index), top 3 emerging risks with mitigation status, and any changes to assumptions (e.g., partner commitments, recruitment trends). Recommend action on any metric trending red.
- Build a Contingency-Release Decision Framework by Month 1 (2026-11-13): specify the conditions under which the board can approve a $25K, $50K or $175K pre-gate reserve draw (e.g., draw up to $25K for psychometric re-validation without board vote, $50K-$175K only with written board justification and approval within 5 days). Document this framework in the Reserve Policy and ensure the project lead understands the escalation path and can request draws on a 5-day cycle.

## 8.3 Follow Up Consultation


At the next consultation (recommend Month 3 = 2027-01-13, or immediately if budget concerns emerge earlier), review: (1) actual Phase 1 spend vs. budget baseline and revised cash-flow forecast for Months 2-12 (2026-12-13 to 2027-10-13); (2) enrollment baseline study findings and the probabilistic recruitment model (75th percentile dropout rate); (3) the psychometrician's power analysis memo and effect-size justifications; (4) signed partner commitments and recruitment plans (names, contact info, enrollment milestones); (5) candidate steward organizations and preliminary letters of interest; (6) audio production RFQs and locked vendor pricing by Month 4 (2027-02-13); (7) monthly variance and earned-value dashboards showing Schedule Performance Index and Cost Performance Index trending. Discuss whether Phase 1 is on track to deliver rules lock, 5,000-word lexicon with usable audio, and pre-analysis plan by Month 12 (2027-10-13) without contingency draws >$50K. If Phase 1 is trending red on schedule or cost by Month 6 (2027-04-13), discuss scope-cut options (e.g., 4,000-word lexicon, audio of highest-friction 1,000 words only) and timeline options (e.g., 2-week Phase 1 extension). By Month 12 (2027-10-13), confirm Phase 2 is ready to launch on schedule and on budget, with all pilot recruitment and retention logistics in place, ethics approval finalized, and gate metrics pre-registered and defended.

## 8.4.A Issue - Critical Pre-Gate Budget Headroom Exhausted; Overrun Exposure Unmanaged

The $175K pre-gate draw cap (5% of budget, half the $350K reserve) is inadequate against the identified fallback costs. A Phase 1 4-week extension ($85K) plus rater retraining and pre-registration work leaves only $90K headroom. Any psychometric redesign, audio re-production, or recruitment shortfall acceleration could trigger a $125K+ shortfall before the Month 24 (2028-10-13) gate. The plan acknowledges this but does not establish earned-value checkpoints or burn-rate thresholds that would trigger board escalation early. Without monthly cash-flow tracking and a trigger for reserve deployment, the project will discover budget stress at Month 8-9 (2027-06-13 to 2027-07-13), compressing Phase 2 and invalidating the gate.

### 8.4.B Tags

- budget-headroom-exhaustion
- contingency-inadequacy
- cash-flow-visibility-gap
- reserve-draw-governance-weak

### 8.4.C Mitigation

Establish a monthly burn-rate baseline by Month 1 (2026-11-13): allocate the $1.1M Phase 1 budget across 12 line items (staff, audio, lexicon, assessment design, admin) with specific monthly targets and cumulative earned-value curves. By Month 2 (2026-12-13), set hard triggers: if cumulative actual spend exceeds budget baseline by >10% ($33K at Month 2 = 2026-12-13), trigger a board variance review within 5 days and a recovery plan within 10 days (e.g., defer discretionary travel, reduce audio takes from 2 to 1.5, compress rater training timeline). At Months 3, 6 and 9 (2027-01-13, 2027-04-13, 2027-07-13), conduct earned-value analysis (planned vs. actual cumulative spend, schedule performance index) and publish a revised cash-flow forecast for the remaining phase. If forecast predicts Phase 1 overrun >$50K, convene an emergency board meeting to approve either a Phase 1 scope cut (e.g., 4,000-word lexicon, single-accent audio only) or a phased release of the pre-gate reserve tranche (up to $50K additional with specific justification). Establish a monthly reconciliation with the finance function and a single, named Budget Owner accountable for weekly variance tracking.

### 8.4.D Consequence

Without immediate action: Phase 1 cost overrun discovered at Month 9-10 (2027-07-13 to 2027-08-13) leaves 2 months to absorb it, forcing either a $175K+ draw that consumes the reserve, or a 1-2 month Phase 2 delay that compresses pilot recruitment and data collection. A delayed Phase 2 start by 4-8 weeks erodes the pilot window from 12 to 8-10 months, reducing assessment sessions from 4 to 3 and cutting effective sample size by 15-25% after attrition, invalidating statistical power for the go/no-go gate. False-negative or inconclusive gate outcome forces a 3-6 month extension ($300K-$600K), fully exhausting the reserve and delaying v1.0 release by 6-12 months.

### 8.4.E Root Cause

The reserve design assumes independent fallbacks (one 4-week Phase 1 extension OR rater retraining, not both), but real execution risk cascades (weak audio delivery → delayed recording → rater calibration compressed). The $175K cap was set as a static policy without earned-value triggers or monthly burn-rate limits. No Phase 1 stage gates or cost baselines exist to detect overspend early enough to adjust scope or schedule.

## 8.5.A Issue - Pilot Recruitment and Retention Risks Underestimated; Sample-Size Loss Unmitigated

The plan targets at least 80 completers per arm (320 total across 4 arms), requiring at least 115 enrolments per arm (460 total) at a 30% dropout tolerance. However, this depends on signed pilot partner commitments by Month 3 (2027-01-13)—9 months away—with no interim recruitment checkpoints. The plan assumes dropout <=30%, but typical adult-education and technical-training pilot dropout is 35-45% without active incentive management. No cohort manager is hired until Month 6 (2027-04-13), leaving 3 months of recruitment unmanaged. If recruitment lags (only 70-80 enrolments per arm by Month 10 = 2027-08-13) and dropout reaches 40% (realistic without manager), only 48-60 completers per arm survive, dropping below the 80-per-arm minimum by >25%, invalidating statistical power for the four gate metrics.

### 8.5.B Tags

- pilot-sample-size-risk
- recruitment-timeline-compressed
- retention-management-delayed
- statistical-power-threatened

### 8.5.C Mitigation

Establish a Pilot Recruitment and Retention Plan (2-3 pages) by Month 2 (2026-12-13): conduct a pilot baseline study with 2-3 candidate ESL programs and 1 technical-training organization (Months 1-2 = 2026-11-13 to 2026-12-13, budget $15K-$20K, estimate) to measure realistic recruitment (% of eligible population converting to enrolment), baseline dropout (% completing all 4 sessions without intensive management), and demographic retention patterns (age, language background, motivation). From this, generate a probabilistic recruitment model with 50th, 75th and 90th percentile scenarios, and a retention curve month-by-month. Use the 75th percentile dropout rate (not 30%) as your planning baseline. By Month 3 (2027-01-13), require each partner to submit a written recruitment plan specifying: list of all eligible learners (N), weekly recruitment calls/emails, in-person enrollment sessions (dates, venues), and partner staff time allocated. Establish interim enrollment milestones (40% enrolled by Month 8 = 2027-06-13, 70% by Month 10 = 2027-08-13, 100% by Month 13 = 2027-11-13) with automatic escalation if missed by >2 weeks: if a partner falls behind, the cohort manager (hired early, by Month 4 = 2027-02-13, not Month 6 = 2027-04-13) activates acceleration tactics (increased incentives, evening/weekend sessions, partner marketing campaign, $20K-$30K budget, estimate). Hire the cohort manager by Month 4 (2027-02-13) (not Month 6 = 2027-04-13) and allocate 30% of their time Months 4-12 (2027-02-13 to 2027-10-13) to pre-Phase-2 recruitment support and contingency planning. Establish a monthly retention-tracking dashboard visible to the board: enrollments to date, dropout-to-date (with reasons), projected completers, and a 95% confidence interval on final sample size; flag to the board if the lower confidence bound falls below 70 per arm, triggering an automatic Phase 2 delay decision by Month 15 (2028-01-13) (before data collection starts) rather than Month 22 (2028-08-13) when it is too late to recover.

### 8.5.D Consequence

If recruitment achieves only 350-400 enrolments by Month 12 (2027-10-13) (a 20-25% miss, within historical range for voluntary adult pilots) and dropout averages 35% (not 30%), only 227-260 completers survive across 4 arms, leaving 57-65 per arm, cutting sample size by 30-40% below the 80-per-arm target. Statistical power drops from 80% to ~60%, raising the Type II error (false-negative) rate from 20% to 40% and making it 40% likely the gate will fail to detect a true, clinically meaningful effect on ordinal error or pronunciation consistency. A weakened gate forces either an inconclusive outcome and a 3-month Phase 2 extension ($300K, estimate), or a false-negative gate that kills the project despite potentially real effects masked by sample-size underpowering.

### 8.5.E Root Cause

The plan separates recruitment (signed by Month 3 = 2027-01-13) from retention management (cohort manager hired Month 6 = 2027-04-13), creating a 3-month gap where enrolment ramps without active support. Dropout tolerance (30%) is policy-level rather than based on external benchmarking or partner experience. No intermediate enrollment targets (e.g., 50% enrolled by Month 9 = 2027-07-13) trigger early course correction. The 460-enrolment target is treated as a firm commitment risk rather than a probabilistic forecast with sensitivity analysis.

## 8.6.A Issue - Gate Metrics Pre-Registration and Threshold Justification Incomplete; Defensibility at Risk

The plan proposes four gate thresholds (ordinal error ≥25% reduction, comprehension ≤10% slower, pronunciation consistency ≥15% above control, 30-day retention ≥70%), but none are pre-registered. Pre-registration is scheduled for Month 11 (2027-09-13), just 5 weeks before pilots begin. No power analysis has been conducted to justify why 80 completers per arm is sufficient to detect these effect sizes with 80% power, and no published benchmarks exist for 'pronunciation consistency' kappa targets in a novel constructed-language context. The plan lacks justification for why ≥15% above control is meaningful, or whether ordinal-only error reduction (the single rule tested most) is likely to yield ≥25% improvement when pilot participants see only 4-8 hours of Clear English exposure across 12 months. Without pre-registered, justified thresholds, the board faces pressure post-hoc to adjust thresholds to match observed data (goalpost-moving), inviting stakeholder claims that the gate was rigged.

### 8.6.B Tags

- pre-registration-delayed
- power-analysis-absent
- threshold-justification-weak
- gate-defensibility-compromised

### 8.6.C Mitigation

Immediately commission a Power Analysis Memo (2-3 pages) from the independent psychometrician by Month 2 (2026-12-13), with delivery by Month 5 (2027-03-13). The memo must: (1) specify the assumed effect sizes for each of the four gate metrics (ordinal error reduction, comprehension speed, pronunciation consistency, 30-day retention), justified by reference to analogous interventions (e.g., citation to adult ESL learning studies for retention benchmarks, dyslexia or speech-therapy research for pronunciation consistency effect sizes); (2) conduct a power analysis for each metric, showing the sample size (per arm) required to achieve 80% power at α=0.05 (two-tailed) for each effect size; (3) justify why 80 per arm (or the revised number) is feasible and cost-effective given the partner commitment and dropout assumptions; (4) propose a decision rule for the four metrics (e.g., GO if ≥3 of 4 metrics meet thresholds and all are valid, INCONCLUSIVE if 1-2 metrics fail but data quality is high, NO-GO if ≥2 metrics fail or data quality is compromised). Circulate this memo to the board by Month 6 (2027-04-13) for approval and comment. By Month 10 (2027-08-13), the psychometrician must deliver the finalized pre-analysis plan (5-7 pages) specifying: exact thresholds for each metric (with effect sizes and sample sizes cited), minimum sample size per arm (with sensitivity analysis: power under 70, 80, 100 per arm scenarios), primary outcomes (ordinal error and comprehension speed) and secondary outcomes (pronunciation consistency, retention), the justification for any thresholds that differ from Month 5 (2027-03-13) proposals, and the specific decision rule for the board gate vote. Register this plan on Open Science Framework or equivalent by Month 11 (2027-09-13 at 14:00) with board sign-off, and publish it on the project website immediately. By Month 12 (2027-10-13), commission an independent external expert (not the project's psychometrician) to review the pre-analysis plan for statistical rigor and boundary conditions (e.g., 'what happens if comprehension time is highly skewed or outlier-laden?'), and publish their review summary on the website. This sequence ensures thresholds are justified, pre-committed and defensible by Month 11 (2027-09-13), 5 weeks before pilots begin, and establishes external credibility for the gate.

### 8.6.D Consequence

At Month 11 (2027-09-13), when the board convenes to pre-register thresholds, if the psychometrician's power analysis reveals that 80 per arm is underpowered (true power 65-70%) to detect a 25% ordinal error reduction, the board faces three bad choices: (1) freeze thresholds at pre-registered but underpowered levels, risking inconclusive gate findings; (2) adjust thresholds downward post-hoc (e.g., 20% reduction instead of 25%), inviting the appearance of goalpost-moving and stakeholder skepticism ('the bar was lowered to get a GO'); (3) delay pilots by 4-6 weeks to recruit additional participants, compressing the assessment window and reducing data quality. Any of these outcomes weakens the gate's credibility as a defensible, pre-committed decision rule. If a NO-GO is reached on the ordinal-error metric (e.g., 18% reduction, below the 25% threshold), stakeholders can claim the threshold was arbitrary because it was never justified against external evidence or similar standards.

### 8.6.E Root Cause

The plan treats pre-registration as a procedural checklist item (Month 11 = 2027-09-13) rather than as foundational evidence work that must precede protocol sign-off. No power analysis or effect-size literature review has been conducted to anchor the 80-per-arm sample-size estimate or the proposed thresholds. The pronunciation consistency metric is novel (no published kappa benchmarks in this domain) and its meaningfulness is asserted rather than validated. The plan assumes a psychometrician will be hired by Month 2 (2026-12-13) but does not require them to deliver a power-analysis memo by Month 5 (2027-03-13) before rule-locking, so threshold design is decoupled from the rule-specification timeline.