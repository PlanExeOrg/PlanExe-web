
## Strengths 👍💪🦾
- Parallel, non-mandatory positioning (supplementary module, no K-12 replacement) lowers educator and publisher resistance.
- Light-touch design: standard spellings unchanged, prefix ordinals convert mechanically and coexist with legacy 1st/2nd/3rd forms.
- Evidence-gated structure: four pre-registered metrics, a Month 24 (2028-10-13) go/no-go, and up to $1.2M returnable on a no-go (estimate).
- Clear ESL-first wedge with a defined pilot design: 2 cohorts x 2 conditions, at least 80 completers per arm (estimate).
- Risk register is detailed, with owners, dates and fallbacks (4-week Phase 1 extension about $85K, estimate).
- Practitioner-leaning board with linguist veto, tiebreak arbiter and certification-mark name stewardship address ambiguity and fragmentation.
- Narrow safety-critical scope (glossary and labeling only, legal counsel by Month 2 = 2026-12-13) bounds liability.

## Weaknesses 👎😱🪫⚠️
- Post-Month 36 (2029-10-13) stewardship is unfunded: $150K-$250K per year (estimate), so a v1.0 release depends on a steward commitment.
- Pre-gate reserve draws are capped at $175K, so a $300K overrun (8.6% of budget, estimate) exceeds headroom by $125K.
- Thin buffer: a Phase 1 extension plus a 3-month Phase 2 extension leaves a $35K shortfall (estimate).
- Critical path is a single sequence (rules, lexicon, audio, instruments, recruitment); a 6-week slip compresses pilots.
- Dependence on scarce roles (psychometrician, cohort manager) and an untested purpose-built assessment battery.
- Single anchor accent can look regionally biased and may draw multi-accent demands.
- The overlay needs a printed pronunciation key, so print materials are not purely standard.
- Gate thresholds are still proposals, not pre-registered, and no authoring tooling is funded for homograph marking.
- Intelligibility claim (at least 90% of control accuracy within 2 weeks) is unproven.

## Opportunities 🌈🌐
- Safety-critical ordinal and homograph ambiguity gives a measurable, incident-linked benefit for the technical glossary cohort once evidence exists.
- ESL publishers can co-produce curricula; a 30-day early-rights window for early adopters could speed uptake.
- Precedents (ASD-STE100, ICAO aviation English) offer governance, rater-calibration and rollout lessons.
- University partners can supply raters and graduate assistants cheaply.
- Open licensing and a free conformance checklist encourage third-party tools and materials.
- Open pre-registration and published rationale build credibility with standards bodies and TESOL/IATEFL.
- A pronunciation overlay and mechanical ordinal conversion could be reused by learning apps and style checkers.

## Threats ☠️🛑🚨☢︎💩☣︎
- Educator, publisher and standards-body rejection as a 'non-standard' variant (high likelihood, high severity).
- Pilot recruitment shortfall or dropout above 30% invalidates gate metrics and may force a 3-6 month extension costing $300K-$600K (estimate).
- Disputed assessment validity or rater kappa below 0.70 could cause a false-negative or false-positive gate.
- Native-reader rejection, as in past spelling reforms (Simplified Spelling Board, Shavian).
- Liability or media scrutiny if any safety document is misread.
- Fragmentation and look-alike variants after release, with weak enforcement against offshore publishers.
- Ethics-approval delays and audio data-protection exposure (GDPR, US state laws).
- Competing plain-language and controlled-language standards backed by larger bodies.
- Basic English-style fade if no steward is found.

## Recommendations 💡✅
- Hire the independent psychometrician by Month 2 (2026-12-13); draft the pre-analysis plan with thresholds and power analysis by Month 5 (2027-03-13); pre-register by Month 11 (2027-09-13) (owner: project lead, board).
- Publish the board charter, voting rules and tiebreak arbiter by Month 1 (2026-11-13); agree the arbiter by Month 5 (2027-03-13); resolve rule disputes by Month 10 (2027-08-13) (owner: board chair).
- Sign at least 3 ESL programs and 2 technical/safety-training partners by Month 3 (2027-01-13); hire the cohort manager by Month 6 (2027-04-13); over-recruit to at least 115 per arm (estimate) (owner: Phase 2 lead).
- Retain legal counsel by Month 2 (2026-12-13), set the liability strategy by Month 4 (2027-02-13), obtain ethics approval by Month 6 (2027-04-13), and keep safety pilots to glossary and labeling (owner: project lead, counsel).
- Scope audio by Month 2 (2026-12-13) and run a rater calibration by Month 10 (2027-08-13); if cost exceeds $20 per entry, use a synthetic baseline plus human verification (owner: lexicon lead).
- Open steward search at Month 12 (2027-10-13) and secure a written commitment before the Month 30 (2029-04-13) v1.0 release; decide licensing and certification by Month 6 (2027-04-13) (owner: board, stewardship committee).

## Strategic Objectives 🎯🔭⛳🏅
- By Month 11 (2027-09-13), pre-register all four gate metrics with numeric thresholds and sample-size justification, and publish the draft standard for a 30-day comment window.
- By Month 13 (2027-11-13), enrol at least 115 learners per arm (460 total, estimate) and retain at least 80 completers per arm with follow-up completion of at least 70% by Month 22 (2028-08-13).
- By Month 12 (2027-10-13), deliver a 5,000-word lexicon with usable single-accent audio for all entries, coverage of at least 85% of pilot text, and inter-rater kappa of at least 0.70 (target 0.75) (proposed thresholds).
- By Month 24 (2028-10-13), reach a defensible go/no-go: ordinal error reduced at least 25% vs control and comprehension no more than 10% slower (proposed thresholds), within the $1.2M Phase 2 budget.
- By Month 36 (2029-10-13), license at least 3 third-party adopters (at least 1 ESL publisher) under a funded steward commitment, at a cost per adopter tracked against the $0.85M Phase 3 budget (proposed).

## Assumptions 🤔🧠🔍
- ESL-first supplementary positioning remains in force; no mandates or K-12 replacement.
- Canonical budget split holds: $1.1M, $1.2M, $0.85M and $0.35M reserve.
- Ordinal Option A (invariant prefix) and an overlay-only pronunciation approach are retained for v1.0.
- Pilot partners honor signed commitments and ethics approval is obtained by Month 6 (2027-04-13).
- Numeric gate thresholds are proposals until pre-registered.
- A mid-cost US hub is provisional until Month 3 (2027-01-13).

## Missing Information 🧩🤷‍♂️🤷‍♀️
- Power analysis confirming at least 80 completers per arm and expected effect sizes.
- Evidence on native-reader and ESL learner acceptance of the prefix marker and its spoken reading.
- Candidate steward organizations and their appetite for $150K-$250K per year.
- Written interest from major ESL publishers and TESOL/IATEFL.
- Actual audio cost per entry and psychometric vendor quotes.
- Which of the two pilot cohorts (ESL learners or technical/safety readers) returns most readily and what they choose first, as early evidence of what motivates uptake.
- Liability insurance availability and cost for safety-related pilot materials.
- Final choice and justification of the anchor accent.

## Questions 🙋❓💬📌
- Which gate threshold is most likely to fail, and what would you do differently if it did?
- Would a leading ESL publisher adopt the standard on current evidence, and what proof would they need?
- Is the $175K pre-gate reserve cap enough, or should Phase 1 contingency be reallocated?
- Who could credibly steward the standard after Month 36 (2029-10-13), and what would motivate them to fund it?
- How would native readers and educators react to the prefix marker, and how will you test that before rules lock at Month 12 (2027-10-13)?