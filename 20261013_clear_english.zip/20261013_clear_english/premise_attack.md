### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] A third, invented English variant that must stay readable to current speakers yet re-spell, re-pronounce and re-inflect 5,000 words has no buyer: the one niche where a controlled English works already has a governed standard, and everywhere else learners need the English that people actually speak.**

**Bottom Line:** REJECT: A parallel 'Clear English' for ESL and safety-critical writing duplicates an established standard in the only niche that needs it and asks learners to master a variant that nobody else uses.


#### Reasons for Rejection

- The safety-critical and technical-writing niche is already served by ASD-STE100, a maintained, industry-backed controlled English, so a $3.5M newcomer must displace an incumbent that regulators, manufacturers and translators already use.
- The brief demands both that adults comprehend the variant within 2 weeks of exposure and that it regularize spelling-to-sound, irregular verbs and plurals, but each regularization lowers recognizability, so the two requirements pull against each other and cannot both be met.
- Adult ESL pilot cohorts would be taught a 5,000-word 'Clear English' that no employer, examiner, colleague or native speaker uses, so every learner pays twice: once to learn it and again to unlearn it for exams and real conversation.
- A single grapheme-to-phoneme mapping forces the project to choose whose English sounds 'correct' among competing national and regional accents, which invites rejection from the educators and ESL publishers it is supposed to recruit.
- The problems targeted are minor in practice: ordinal oddities (1st/2nd/3rd, 11th-13th) are already handled by writing numerals, and lead/read-type homograph pairs are resolved by context, so a 36-month, three-phase program with a go/no-go gate is aimed at friction that does not justify a new standard.
- An openly licensed standard with no mandate and no K-12 route has no mechanism for convergence, so the likeliest outcome is competing forks and house dialects rather than one adopted standard, which is the opposite of the 'standard' the program promises.

#### Second-Order Effects

- 0–6 months: Rule drafting and early public announcement draw criticism from linguists, plain-language practitioners and technical-writing bodies who point to ASD-STE100 and Basic English, and the project is cast as another spelling-reform stunt before any pilot data exists.
- 1–3 years: Pilot results come from a self-selected, small adult cohort that is poorly matched to the real target population, so the go/no-go metrics (30-day retention, ordinal error rate) are ambiguous, and safety-critical firms decline to run a trial that would double their document-review burden.
- 5–10 years: The published standard sits as a niche artifact with a few enthusiast forks, while any safety-critical use leaves legacy documents in two variants and creates a misreading and liability exposure that no regulator asked for.

#### Evidence

- Case/Incident — Simplified Spelling Board (1906): Carnegie-funded effort with a 300-word list and a Roosevelt order was reversed when the House voted 142-25 to bar the spellings from federal documents, and the Board's spellings never caught on.
- Case/Incident — ASD-STE100 Simplified Technical English (first released 1986 as an AECMA document): a governed, industry-backed controlled English for aircraft maintenance documentation, now at Issue 9 (2025) with roughly 900 approved words, which already fills the safety-critical niche this plan targets.
- Case/Incident — Basic English, C.K. Ogden (1930): a deliberately simplified 850-word English promoted for international use that did not become a widely adopted standard.



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[STRATEGIC] — Fork In The Cockpit: a new spelling, ordinal and verb-form variant aimed at safety-critical documentation adds a second reading standard to the one place where a reader cannot afford to wonder which standard a page is written in, and it attacks the spelling layer when the controlled-language layer that already serves technical writing is what matters.**

**Bottom Line:** REJECT: Fork In The Cockpit puts a second, unrecognised spelling standard into the documents where only one can be trusted, and past English-reform efforts suggest it would end up as a stranded dialect with a small user base. The need for clearer technical English is real, but this premise does not meet it.


#### Reasons for Rejection

- Adult ESL learners and technical staff would spend scarce study hours on a variant that no employer, exam board or regulator recognises, and a worker told to read a manual in a made-up dialect has no real choice about it.
- The editorial board, the pilot and the go/no-go decision all sit with the people who built the standard, with no regulator, aviation or industrial authority obliged to accept it, so nobody outside the project is accountable when a reader misreads a page.
- An openly licensed variant can be copied and altered by anyone, and once a maintenance manual or label is printed in it, mixed Clear English and standard English will circulate in the same workplaces for as long as the documents live.
- The premise misallocates $3.5M (user constraint) to re-spelling 5,000 words (user constraint), while the real problem in technical English is ambiguous sentences and uncontrolled vocabulary, which an existing standard already targets, and a 2-week average comprehension target is far too loose for safety-critical reading.

#### Second-Order Effects

- **Months 0-12 (2026-10-13 to 2027-10-13) — The Cracks Appear:** Linguists, ESL publishers and standards bodies split over which irregular verbs and homographs to regularise, and the rule set reopens at every meeting because no outside authority can close it.
- **Months 12-36 (2027-10-13 to 2029-10-13) — Pilot Theatre:** Pilot cohorts of motivated volunteers produce flattering comprehension numbers that say nothing about stressed, tired workers reading a warning label, and the go/no-go gate is decided on the wrong evidence.
- **Months 36-60 (2029-10-13 to 2031-10-13) — Copycats Arrive:** Rival variants appear under the open licence, each claiming to be the real Clear English, and a handful of companies print mixed-standard documents that readers must now decode twice.
- **Months 60-120 (2031-10-13 to 2036-10-13) — The Reckoning:** Learners who invested in the variant are stranded with a skill no exam or employer recognises, and archives of dual-standard technical documents become a permanent source of avoidable misreading.

#### Evidence

- Law/Standard — ASD-STE100 Simplified Technical English: a maintained controlled-language standard for aerospace and defence maintenance documentation, whose current edition (January 2025) is reported as having 53 writing rules and roughly 900 approved words, and which already serves non-native readers without changing English spelling.
- Case/Report — Simplified Spelling Society (founded 1908) and the Carnegie-funded Progressive Era simplified-spelling campaign in the United States: both pushed spelling reform for decades, and the American effort was undermined in part by schoolteachers' quiet resistance.
- Case/Report — Shavian alphabet: commissioned under George Bernard Shaw's will, selected in a 1958 competition from 467 entries, and never seriously adopted as an alternative way to write English.
- Case/Report — Basic English (C. K. Ogden, 850 words, 1930s): even with a 1943 Churchill-era cabinet committee behind it, it did not become an international language, and what survives is its word list as a beginner vocabulary.



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] A voluntary English variant must out-compete both standard English and an incumbent technical-writing standard, yet offers learners a dead-end dialect and safety documents a fresh misreading hazard.**

**Bottom Line:** REJECT: A voluntary, unmandated English variant with $3.5M and three years cannot displace standard English or the established technical-English standard, and its only certain product is one more convention that safety-critical readers must tell apart from the original.


#### Reasons for Rejection

- Adoption has no engine: with no mandates, no K-12 entry and no universal-adoption claim, nothing compels a single publisher, employer or regulator to switch, and $3.5M cannot buy the network effect that every language standard lives or dies on.
- Safety-critical text is the worst place to introduce a second reading convention: a technician trained on invariant ordinal markers instead of 11th/12th/13th, or on optional lead/lead disambiguation tags, will misread a standard-English manual the day the two meet.
- The niche is already occupied: controlled English for safety-critical and technical documentation exists as an industry-governed standard, so a pilot on a 'safety-critical or technical glossary' duplicates a rival with decades of installed manuals and audit acceptance.
- ESL learners are the intended beneficiaries yet are the ones harmed: a 5,000-word regularized lexicon is a second system on top of the standard English they must still master for jobs, exams and street signs, so every hour spent is a toll paid twice.
- The intelligibility target contradicts the ambition: if adults must understand it within 2 weeks of exposure the changes must be trivial and fix little, and if they fix go/went, mouse/mice and spelling-to-sound at scale the text stops being intelligible to current speakers.

#### Second-Order Effects

- 0–6 months: The editorial board cannot agree on ordinal option A versus B or on the threshold for retaining irregular forms, so Phase 1 rule-writing becomes a public quarrel and educators and standards bodies hear 'another spelling reform' before they hear any data.
- 1–3 years: Pilot results from self-selected adult ESL volunteers and technical staff show decent 30-day retention inside the course and nothing outside it; publishers see no paying market, and the Month 24 (2028-10-13) go/no-go becomes a contested reading of flattering numbers.
- 5–10 years: The open licence yields a handful of divergent forks and a scatter of documents in mutually unreadable rule sets, leaving the standard as one more orphaned variant that adds ambiguity to the very safety documentation it was meant to clarify.

#### Evidence

- Case/Incident — Simplified Spelling Board and Roosevelt order (1906): Roosevelt ordered the Government Printing Office to use 300 simplified spellings, the House voted in December 1906 to keep dictionary spellings, and he rescinded the order; this program asks for a lexicon more than sixteen times larger (recomputed: 5,000 / 300).
- Report/Guidance — ASD-STE100 Simplified Technical English, Issue 9 (2025): an existing controlled-language standard for technical documentation, widely used in aerospace and defence, already occupies the safety-critical clarity niche this plan targets.
- Case/Incident — Initial Teaching Alphabet, Sir James Pitman (1960s): a regularized sound-to-symbol system adopted in UK and US classrooms and largely abandoned by the late 1970s, with learners still having to transition to standard spelling.



### Premise Attack 4 — Cascade
_Tracks second/third-order effects and copycat propagation._

**This is a strategic flaw: a fourth, privately authored orthography is proposed as a "parallel standard" to a language whose entire value is that everyone else already uses the incumbent form. Every learner and safety-critical reader would have to master Clear English and still be fluent in Standard English, so the product has negative marginal value for exactly the audiences it targets, and the "optimize for adoption" goal is contradicted by the design itself.**

**Bottom Line:** Abandon the premise: do not create a new variant of English with new spellings, because a second system that users must learn on top of the first has negative adoption value regardless of how well the rules are written. If the real aim is clarity in ESL and safety-critical documents, the premise of re-spelling English is the source of the failure, not the governance, budget or phasing.


#### Reasons for Rejection

- The Double-Tax Learner: an adult ESL learner who studies Clear English still has to read street signs, prescription labels, contracts, exam papers and employer documents in Standard English. Clear English is therefore an additional cost, never a substitute, and a plan that must be learned on top of the thing it improves cannot win adoption from rational buyers. The 2-week intelligibility target (user constraint) quantifies the cost of entry but nothing in the plan quantifies a payoff.
- The Occupied Niche: safety-critical and technical writing already has a controlled-language incumbent, ASD-STE100 Simplified Technical English (about 900 approved words and 53 writing rules in the January 2025 edition, originating in 1980s aerospace). It cuts ambiguity without re-spelling anything. A 5,000-word re-spelled lexicon enters that niche as a harder, riskier, less-established rival with no regulator, airline or OEM asking for it.
- The Recognizability-Regularity Vise: the plan demands rules regular enough to fix spelling-to-sound and irregular morphology, yet capped so that current speakers understand it within two weeks. Each regularization (went→goed, mice→mouses) either breaks recognizability or is capped so heavily that the irregulars that cause the real friction remain. Any threshold for 'retain irregular forms' is arbitrary and will be attacked by both reformers (too timid) and users (too strange) at once.
- The Accent Hostage Problem: a 'minimal, consistent grapheme-to-phoneme mapping' must pick a reference pronunciation, but English has no single one (rhotic vs non-rhotic, cot/caught, trap/bath, Indian, Nigerian, Singaporean and American norms). Whatever accent anchors the mapping makes the standard 'wrong' for a majority of the intended ESL audience, and the 5,000-word pronunciation guidance becomes a dialect-politics dispute instead of a teaching tool.
- The Self-Graded Gate: the Month 24 (2028-10-13) go/no-go metrics (comprehension speed, ordinal error rate, pronunciation consistency, 30-day retention) measure how well people learn the new system on the project's own materials, with volunteer cohorts. None of them measures transfer back to Standard English, interference errors (mixing the two systems), or error rates in real safety-critical tasks, which are the only outcomes that decide adoption. A gate that cannot return a meaningful 'no' is theater.

#### Second-Order Effects

- Months 0-12 (2026-10-13 to 2027-10-13): the editorial board spends its credibility on decisions with no empirical anchor (ordinals option A vs B, which accent, which 'high-impact' homographs). Linguists outside the project publish critiques of the rule set before the reference corpus exists, and fragmentation arrives early as forks of the draft rules circulate.
- Months 12-24 (2027-10-13 to 2028-10-13): pilot recruitment skews to motivated volunteers, producing flattering 2-week comprehension and 30-day retention numbers. Pilot ESL teachers report the interference problem informally (students mixing Clear and Standard forms on tests such as those they actually need), but these reports are not captured by the four gate metrics.
- Months 24-36 (2028-10-13 to 2029-10-13): a 'go' on weak data triggers publication of Standard v1.0 and an open licence. Third parties immediately fork it, and the stated risk of fragmentation is realized by design: an open licence for a standard with no enforcement body yields multiple incompatible 'Clear English' variants.
- Months 36-60 (2029-10-13 to 2031-10-13): the budget ($3.5M, user constraint) is spent with no sustaining revenue or institutional owner. ESL publishers decline to license because certification bodies and exams do not recognise the variant. Technical-writing teams stay on ASD-STE100 or their house style guides, and the project survives as a hobbyist community.
- Months 60-120 (2031-10-13 to 2036-10-13): the best case is a documentation archive and a small online user group. The worst case is that a few safety documents are issued in Clear English and a mix-up with Standard English ordinals or spellings contributes to a reportable error, which discredits the whole concept of controlled-language variants in regulated industries.

#### Evidence

- Simplified Spelling Board (1906): funded by Andrew Carnegie at $25,000 per year, with members including Mark Twain and Melvil Dewey, it proposed 300 simplified spellings. On Aug 27, 1906 President Theodore Roosevelt ordered the Government Printing Office to use them in executive-department documents. On Dec 13, 1906 the House of Representatives resolved, unanimously, that the printer should follow the standard in generally accepted dictionaries, and Roosevelt rescinded his order. Presidential backing and money still lost to the dictionary incumbent within months.
- Initial Teaching Alphabet (i.t.a.): devised by Sir James Pitman in the early 1960s as an easier route into English reading, it saw considerable uptake in that decade and then fell out of use from the 1970s. A principal reason cited is that children struggled to transfer i.t.a. reading skills to standard orthography and were confused by juggling two writing systems. This is the Double-Tax Learner in a real classroom experiment, and the plan has no metric for transfer.
- ASD-STE100 Simplified Technical English: a controlled-language standard created in the 1980s at the request of the European airline industry, maintained by the ASD and now at about 900 approved words and 53 rules (January 2025 edition). It is the direct incumbent in the 'safety-critical documentation' niche that Clear English claims, and it works without changing spelling, so there is no gap that a re-spelled variant fills.
- The plan has no direct precedent as a voluntary, non-mandated, parallel orthography that was adopted at scale by regulated industries; the adopted analogues (STE, plain-language guidelines) change vocabulary and sentence structure, not spelling. This specific combination is unprecedented in its folly.



### Premise Attack 5 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[STRATEGIC] — Orphan Dialect Trap: A voluntary, mandate-free English variant that is close enough to standard English to be 'intelligible in two weeks' yet different enough to need teaching is born with no installed base, no regulator, and no employer, so the more it fixes, the less anyone can use it.**

**Bottom Line:** REJECT: A voluntary, near-English variant with no authority, no installed base and no customer demanding it cannot be both easy enough to adopt and different enough to matter, and it would turn learners and safety documentation into the unwilling test population for that contradiction. The gate is closed.


#### Reasons for Rejection

- Adult ESL learners are a time-poor, status-vulnerable population who need the English that employers, exam boards, immigration offices and colleagues actually use, and spending their scarce hours on a variant that none of those institutions recognise treats their ambition as raw material for an experiment.
- No body with legal or professional authority sits behind the standard: a self-appointed editorial board and a linguistic review panel would issue rules for safety-critical documents with no certification regime, no liability owner and no route for anyone to answer for a regularised ordinal or disambiguation marker that is misread in the field.
- Introducing a parallel written standard into safety-critical and technical documentation creates a new translation boundary between 'Clear English' and standard English, and every boundary, every mixed-form document and every partial adopter is a fresh point where meaning can be silently corrupted.
- The value proposition contradicts itself: a variant that current speakers grasp within two weeks without real study has changed too little to fix spelling-to-sound or morphology, while one that changes enough to help must be taught, which the plan's own cap on changes, ban on mandates and 'don't optimise for purity' constraint forbid it from achieving.

#### Second-Order Effects

- T+0–6 months (Months 0-6 = 2026-10-13 to 2027-04-13) — The Cracks Appear: The board cannot choose whose pronunciation the grapheme-to-phoneme mapping encodes, and whichever accent it picks alienates the others; arguments over the first ordinal choice and the first 'retain or regularise' cases consume the schedule before a single learner sees material.
- T+1–3 years (Months 12-36 = 2027-10-13 to 2029-10-13) — Copycats Arrive: Small, self-selected pilot cohorts produce flattering comprehension numbers that get quoted far beyond their validity, while rival groups publish competing 'clearer' variants and publishers bolt on their own markers, so fragmentation arrives before adoption does.
- T+5–10 years (Months 60-120 = 2031-10-13 to 2036-10-13) — Norms Degrade: Technical documents appear in unlabelled mixtures of Clear English, standard English and house variants, reviewers can no longer tell which rule set a sentence obeys, and learners trained on the variant are quietly marked down by mainstream tests and hiring managers.
- T+10+ years (Month 120 = 2036-10-13 onward) — The Reckoning: The standard survives as a dormant specification and a cohort of graduates holding a literacy that no institution recognises, while the first documented safety-relevant misreading of a variant marker converts a language experiment into a liability story.

#### Evidence

- Case/Report — Initial Teaching Alphabet (i.t.a.): Sir James Pitman's 44-character reform was taken up by 140 of 158 UK education authorities in at least one school by 1966, then largely abandoned by the late 1970s because moving pupils back to standard spelling proved harder than expected (https://en.wikipedia.org/wiki/Initial_Teaching_Alphabet).
- Standard/Case — ASD-STE100 Simplified Technical English: it exists because the European airline industry asked for it in the 1980s, and its current edition (January 2025) has 53 writing rules and about 900 approved words (https://en.wikipedia.org/wiki/Simplified_Technical_English); it succeeded through demand-pull and narrow scope, which a supply-push variant with a 5,000-word lexicon and no mandate does not have.
- Principle/Analogue — Economics of Standards: the value of a standard rises with the number of users (network effects), so a variant that begins at zero users, has no mandate and explicitly forbids replacing anything has no mechanism for passing the tipping point.
- Principle/Analogue — Second-Language Acquisition: negative transfer (interference) predicts that two systems which are similar but conflict in detail produce more learner errors than two clearly distinct ones, so a near-English variant risks degrading the standard English the learner still needs.