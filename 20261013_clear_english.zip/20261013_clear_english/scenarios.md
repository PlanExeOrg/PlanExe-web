# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** Moderately ambitious, institution-scale standards initiative: a parallel (not replacement) English variant with a 5,000-word core lexicon, a $3.5M (user constraint) budget and a 3-year, 3-phase timeline. Targets niche but high-value audiences (adult ESL, technical and safety-critical writing) and explicitly rejects mandates, K-12 replacement and universal-adoption claims.

**Risk and Novelty:** Novel and unproven: constructed-variant standardization with unknown native-reader acceptance. Main risks are educator pushback, rule ambiguity, fragmentation and liability in safety-critical use. The plan manages these through gating (go/no-go at Month 24 = 2028-10-13), optional markers and a capped change threshold, so the posture is moderate risk with evidence-first discipline.

**Complexity and Constraints:** Moderate-to-high operational complexity: rule specification, reference corpus, pronunciation guidance, print and digital curriculum, four gate metrics (comprehension speed, ordinal error rate, pronunciation consistency, 30-day retention), governance, licensing and outreach. Fixed budget, fixed 12-month phases, physical pilot sites with in-person assessment, and a pre-registered metrics requirement before Month 12 (2027-10-13).

**Domain and Tone:** Public-interest language standardization and education; business purpose without profit motive. Tone is pragmatic, evidence-driven and adoption-first ('optimize for user adoption, not linguistic purity'; 'don't pick the most aggressive scenario').

**Holistic Profile:** A cautious-but-credible, adoption-first standards program: modest linguistic intervention that coexists with standard English, ESL-led pilots, defensible gate evidence at Month 24 (2028-10-13) and balanced funding across three phases. It seeks real third-party uptake rather than maximal linguistic fix or minimal spend.

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Pragmatic Foundation
**Strategic Logic:** Build credible evidence with moderate-risk choices: an invariant ordinal prefix that coexists with legacy forms and converts mechanically, an on-demand pronunciation overlay that leaves printed text standard, and an ESL-first supplementary wedge that fits the pilot cohorts. Purpose-built, independently reviewed assessments give the go/no-go gate defensible data on the ordinal and pronunciation effects, while an even budget spread and a modest board-controlled reserve keep Phase 1 adequately resourced. This is the path best aligned with the brief's adoption-first, no-mandate stance.

**Fit Score:** 9/10

**Why This Path Was Chosen:** Prefix ordinals coexisting with legacy forms, an optional overlay leaving print standard, an ESL-first supplementary wedge, purpose-built validated gate metrics and an even budget align closely with the adoption-first, no-mandate, evidence-gated brief.

**Key Strategic Decisions:**

- **Ordinal Marker Architecture:** Adopt numeric ordinals with an invariant prefix marker placed before the digits, avoiding clashes with the legacy 1st/2nd/3rd suffixes and letting software convert both forms mechanically.
- **Grapheme-to-Phoneme Intervention Depth:** Render pronunciation as an optional software-generated overlay, such as ruby-style annotations in digital materials, so printed text stays standard while learners see the regularized mapping on demand.
- **Adoption Wedge and Sequencing:** Lead with adult ESL programs and publishers, offering Clear English as a supplementary module that sits alongside standard English curricula rather than replacing them.
- **Outcome Metric Battery Design:** Develop a purpose-built assessment set for each of the four metrics, calibrated against a standard-English control group, and have an independent psychometrician review item validity before the pilots begin.
- **Phase Budget Weighting and Reserve:** Spread spending roughly evenly across the three phases, with a modest unallocated reserve released by the editorial board only after the go/no-go decision.

**The Decisive Factors:**

- **Fits adoption-first, no-mandate stance:** an invariant ordinal prefix coexists with legacy 1st/2nd/3rd forms and converts mechanically, while an optional overlay leaves printed text standard, so educators and publishers are not forced to switch.
- **Fits the gate:** purpose-built, independently reviewed assessments cover the four Month 24 (2028-10-13) go/no-go metrics, notably ordinal error rate and pronunciation consistency.
- **Fits the budget:** an even phase split and a modest board-controlled reserve keep Phase 1 rules and the 5,000-word lexicon properly resourced.
- **Pioneer's Gambit rejected:** respelling, 'oneth'-style ordinals and a consumer-toggle wedge are the aggressive path the brief excludes, with a thin Phase 1 and fragmentation risk.
- **Prudent Consolidator less suitable:** off-the-shelf instruments may miss Clear English-specific effects, and a large held reserve can starve early work.
- **Caveat:** print materials still need the pronunciation key printed.

---
## Alternative Paths
### The Pioneer's Gambit
**Strategic Logic:** Pursue the deepest functional fix and the fastest user-base growth: fully spelled regular ordinals, respelling of the highest-friction patterns, and a free reader-facing toggle that builds usage before institutions commit. Spending is front-loaded to pilots and passive measurement at scale to generate evidence quickly, accepting the risks of native-reader rejection, fragmentation and a thin Phase 1. It is shown as the upper bound of ambition; given the brief's instruction to avoid the most aggressive scenario and to optimize for adoption over linguistic purity, it is not the recommended path.

**Fit Score:** 3/10

**Assessment of this Path:** Respelling, spelled-out ordinals such as 'oneth', a consumer toggle-first wedge and a thin Phase 1 are the aggressive path the brief rules out; they heighten native-reader rejection and fragmentation and favor linguistic fix over adoption.

**Key Strategic Decisions:**

- **Ordinal Marker Architecture:** Adopt fully spelled ordinals with a single regular -th ending, retain digits only in tables and codes, and justify the choice through pilot reading-speed comparisons.
- **Grapheme-to-Phoneme Intervention Depth:** Respell only a ranked shortlist of the highest-friction spelling patterns in the core lexicon, keeping every changed form within easy recognition distance of its standard spelling.
- **Adoption Wedge and Sequencing:** Lead with a free, standalone reference site and browser extension that lets any reader toggle between standard and Clear English forms, building a user base before institutional partnerships.
- **Outcome Metric Battery Design:** Embed measurement in normal course work through passive digital logging of response times and error patterns, supplemented by a small supervised audio-capture sample for pronunciation scoring.
- **Phase Budget Weighting and Reserve:** Weight spending toward Phase 2 pilots and assessments, keeping Phase 1 lean through a small expert team and a deliberately narrow first rule set that can be piloted quickly.

### The Prudent Consolidator
**Strategic Logic:** Minimize conversion cost, educator pushback and financial exposure: keep standard spellings intact, add a single pronunciation-guidance layer, use the cheapest-to-teach ordinal scheme, and measure with validated external instruments for maximum credibility. A large contingent tranche is released only against evidence milestones, so a no-go at Month 24 (2028-10-13) returns unspent funds rather than financing a weak launch. The trade-off is that the fix to spelling-to-sound inconsistency is shallow and less precise on Clear English-specific effects.

**Fit Score:** 6/10

**Assessment of this Path:** Low-risk and credible, but off-the-shelf instruments may miss ordinal and pronunciation effects that drive the go/no-go gate, and a large held reserve can under-resource Phase 1 rules and corpus work; the spelling-to-sound fix is shallow.

**Key Strategic Decisions:**

- **Ordinal Marker Architecture:** Adopt numeric ordinals with one invariant suffix on every digit string, so 1, 2, 3, 11, 21 all take the same marker, and publish a fixed spoken reading for that suffix.
- **Grapheme-to-Phoneme Intervention Depth:** Keep standard spellings unchanged and add a consistent pronunciation-guidance layer to the 5,000-word lexicon, using one minimal respelling key in dictionaries and teaching materials.
- **Adoption Wedge and Sequencing:** Lead with adult ESL programs and publishers, offering Clear English as a supplementary module that sits alongside standard English curricula rather than replacing them.
- **Outcome Metric Battery Design:** Adopt validated off-the-shelf reading, listening and recall instruments and adapt them minimally, accepting less precision on Clear English-specific features in exchange for external credibility.
- **Phase Budget Weighting and Reserve:** Hold a large contingent tranche that is released in stages against evidence milestones, so that a no-go outcome at Phase 2 returns unspent funds rather than financing a weak launch.
