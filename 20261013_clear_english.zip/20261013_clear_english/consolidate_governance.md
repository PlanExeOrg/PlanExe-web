# Governance Audit


## Audit - Corruption Risks

- Conflict of interest in editorial board rule decisions: board members with financial stakes in ESL publishers or standards organizations could steer ordinal, morphology or homograph rules to advantage their employers, compromising rule objectivity and learner benefit.
- Nepotism in pilot recruitment and cohort management: educators or cohort administrators favoring their own institution's learners for higher incentives or easier assessment conditions, inflating that site's performance metrics and biasing the go/no-go decision.
- Misuse of pilot audio and learner data: unauthorized retention, sharing or commercial use of pronunciation recordings and learner assessment data beyond stated research scope, exploiting biometric and educational information.
- Bribery of partner institutions: publishers or standards bodies offering unofficial incentives (early access, licensing fee waivers, board seat offers) to editorial board members or outreach staff in exchange for favorable rule positioning or conformance-checklist leniency.
- Information asymmetry and insider advantage: project staff with early knowledge of rule finalization (Month 11–12 = 2027-09-13 to 2027-10-13) or gate outcomes (Month 24 = 2028-10-13) using that information to guide their own institution's curriculum or publishing decisions before public release.
- Kickback schemes in vendor contracts: audio studios, curriculum designers or assessment platforms offering undisclosed rebates or revenue-sharing to procurement staff in exchange for inflated contract awards, straining the $3.5M budget.

## Audit - Misallocation Risks

- Budget front-loading and reserve depletion: exhausting Phase 1 funds (budgeted $1.1M) on non-essential rule refinement, lengthy board meetings or duplicate psychometric studies, leaving insufficient buffer ($175K pre-gate cap) to cover audio production overruns or extension costs, forcing Phase 2 pilot cuts.
- Inefficient audio production and rework: purchasing audio recording without firm studio capacity guarantees, leading to re-records or file loss, doubling the per-entry cost from $15–20 to $30–40 and inflating the audio line item beyond the $80K–$120K budget estimate.
- Pilot incentive leakage and double-payment: paying learner stipends twice (once through the ESL program partner, again by the project), or reimbursing educator travel separately to both the school and the project, inflating Phase 2 participant costs above the budgeted $208K–$351K.
- Personnel underutilization and overstaffing: hiring 10 FTE staff (peak proposed) but assigning only 50–60% of their time to the core Phase 1 rule, lexicon and assessment work, with the remainder dispersed across low-value meetings, reporting and internal coordination.
- Uncontrolled scope creep in the core lexicon: adding domain-specific terms and accent samples beyond the 5,000-word baseline without removing equivalent entries, inflating pronunciation-recording costs by 15–25% ($12K–$30K, estimate) and compressing the Phase 1 timeline.
- Misreporting progress and contingency release: declaring a rule finalized or a metric pre-registered prematurely (e.g., at Month 10 = 2027-08-13 instead of Month 11 = 2027-09-13) to trigger reserve drawdown or board approval, when the work is incomplete or validity not yet confirmed.

## Audit - Procedures

- Monthly financial tracking and critical-path reviews (Months 1–36 = 2026-11-13 to 2029-10-13): project lead reports actual versus budgeted spend, timeline status against milestones (rule finalization, audio completion, recruitment, metrics pre-registration), and flags slips over 2 weeks for board escalation. Audit trail maintained in shared project repository (version-controlled).
- Quarterly stakeholder and partner compliance checks (Months 3, 6, 9, 12, 15, 18, 21, 24 = 2027-01-13, 2027-04-13, 2027-07-13, 2027-10-13, 2028-01-13, 2028-04-13, 2028-07-13, 2028-10-13): confirm pilot partner enrollment commitments are met, cohort manager tracks participant attrition and dropouts against the <=30% tolerated rate, and ESL program and technical-training organization compliance with protocol fidelity is sampled (e.g., 10% of sessions observed or audio-recorded for protocol adherence).
- Pre-gate assessment validity audit at Month 18–22 (2028-04-13 to 2028-08-13): independent external auditor (separate from the psychometrician who designed instruments) reviews pilot data for inter-rater reliability (confirmed kappa >=0.70), construct validity (analysis of confounds and alternative explanations), and data integrity (missing files, outliers, consent violations). Audit report submitted to editorial board by Month 23 (2028-09-13), 1 month before go/no-go, to permit remediation or data extension if validity falls below threshold.
- Rules and governance audit at Month 11 (2027-09-13): editorial board chair certifies that all rule disputes were resolved per the published Charter, that decision logs document both majority and minority positions on contested rules, and that the pre-analysis plan (metrics, thresholds, sample sizes, primary outcomes) matches the finalized rules and no post-hoc changes have been made. Certification published with the draft standard.
- Budget and reserve draw audit at Month 24 (2028-10-13, gate decision): finance audit confirms that total Phase 1–2 spending equals planned allocation +/– variance, that all pre-gate draws from the $175K contingency cap are documented and pre-approved, that no unrecorded commitments or purchase orders exist beyond budgeted lines, and that the reserve balance is at least $175K remaining. Auditor reports go/no-go budget fitness to the board.
- Post-launch conformance audit at Months 30, 36 (2029-04-13, 2029-10-13): spot-check a sample of third-party materials claiming Clear English conformance (e.g., ESL curricula, technical glossaries) against the published conformance checklist; report non-conformances to the Standards Stewardship Committee and recommend corrective action or name-mark revocation within 60 days.

## Audit - Transparency Measures

- Published Editorial Board Charter and decision log (by Month 1 = 2026-11-13, updated quarterly): governance document specifying board composition, voting rules, conflict-of-interest disclosures, tiebreak procedure and arbiter identity; monthly/quarterly log of all rule decisions, with majority and minority positions and explicit rationale, made available on the project website and updated within 10 days of each board meeting.
- Monthly financial and timeline dashboard (live from Month 1 = 2026-11-13): public-facing, read-only view of Phase spend versus budget (aggregated by line item: staff, assessment, audio, curriculum, etc.), critical-path milestones (rule completion, lexicon audit, pre-registration, recruitment) with status and variance, and a forward-looking 6-month cash-flow forecast. Updates published within 5 days of month-end.
- Pre-registered analysis plan and metrics (published Month 11 = 2027-09-13, on OSF or similar public repository): complete specification of the four gate metrics, quantitative pass/fail thresholds, sample-size targets, primary and secondary outcome definitions, control-condition design, confound-control and manipulation-check procedures, and analysis code (R or Python scripts). Any post-registration amendments require written justification and re-publication before gate decision.
- Draft standard and 30-day public comment window (Month 11 = 2027-09-13 to Month 12 = 2027-10-13): full text of Clear English Standard v1.0 draft, including rule set, rationale, examples, exceptions, and ordinal/morphology/homograph specifications, published on the project website with a structured comment form. All substantive comments and project responses published by Month 12 (2027-10-13).
- Pilot protocol and informed-consent templates (published by Month 6 = 2027-04-13): study design, inclusion/exclusion criteria, assessment schedules, data-handling and privacy procedures, and a plain-language learner consent form, available on the project website. Any protocol changes require ethics-board approval and publication of an amendment within 10 days.
- Go/no-go dossier and decision rationale (published within 30 days of Month 24 = 2028-10-13 gate): full analysis of the four gate metrics (tables, plots, effect sizes, statistical tests, confound checks), summary of validity audit findings, enrollment and attrition data, and the editorial board's written decision statement explaining why the standard passed or failed, including any board dissent or conditions on a YES outcome.

# Internal Governance Bodies

### 1. Project Steering Committee

**Rationale for Inclusion:** The Clear English program is a 36-month, $3.5M initiative spanning rule specification, pilot design, gate metrics, recruitment and public release across multiple stakeholder groups (educators, publishers, regulators, learners). Strategic decisions on ordinal architecture, G2P depth, adoption wedge, outcome metrics and phase budget allocation directly shape evidence credibility and adoption likelihood. The Steering Committee provides high-level oversight of these critical strategic levers, monitors phase-gate readiness, arbitrates resource conflicts across phases, and ensures alignment with the adoption-first, evidence-gated mandate and no-mandate, no-K12-replacement constraints.

**Responsibilities:**

- Approve the five critical strategic levers (Ordinal Architecture, G2P Depth, Adoption Wedge, Outcome Metric Battery, Phase Budget Weighting) and reconcile tensions between rule ambition and adoption
- Monitor phase-gate readiness (Month 12 = 2027-10-13 rules lock, Month 24 = 2028-10-13 go/no-go metrics): confirm pre-registration of thresholds, validity audit findings, and pilot enrollment/retention targets
- Authorize draws from the $175K pre-gate contingency reserve for gate-protection needs (psychometric re-validation, Phase 1 timeline extension); recommend to the Editorial Board for post-gate reserve release
- Escalate unresolved editorial board disputes (rule deadlock, governance conflict) to an external arbiter and make final strategic decision if arbiter is impeded
- Review quarterly stakeholder alignment assessments and adjust messaging or phase scope if adoption risks (educator pushback, publisher capacity, regulatory delays) exceed mitigation thresholds

**Initial Setup Actions:**

- Appoint Steering Committee chair and confirm 5–7 core members (project lead, finance lead, external academic partner, one ESL publisher representative, one standards-body advisor) by Month 1 (2026-11-13)
- Publish Steering Committee Charter specifying decision authority, voting rules, escalation paths, and meeting schedule by Month 1 (2026-11-13)
- Confirm the five strategic-lever choices (approved in the 'Pragmatic Foundation' scenario) with explicit written rationale and trade-off documentation by Month 2 (2026-12-13)
- Establish a Critical Path Dashboard with phase milestones, resource allocation and go/no-go gate conditions; review monthly and escalate slips >2 weeks by Month 1 (2026-11-13)
- Schedule phase-gate checkpoint meetings: Month 11 (2027-09-13) pre-registration review, Month 18 (2028-04-13) midpoint check, Month 23 (2028-09-13) validity audit review, Month 24 (2028-10-13) go/no-go decision

**Membership:**

- Project Lead (internal, full-time)
- Finance Lead / Budget Controller (internal, 0.5–1.0 FTE)
- Editorial Board Chair (internal, overlapping role to align rule and resource decisions)
- External Academic Partner (university applied linguistics or standards program, advisory role, ~4 hours/month)
- Psychometrician or Assessment Lead (internal, hired Month 2 = 2026-12-13, represents measurement credibility and validity)
- ESL Publisher Representative (external, non-binding advisory; input on adoption wedge viability)
- Standards Body Advisor (external, e.g., TESOL, IATEFL representative; input on regulatory and adoption landscape)

**Decision Rights:** Strategic decisions with financial impact >$50K (equipment, vendor contracts, Phase-wide re-scoping, reserve draws up to $175K pre-gate limit); authorization of phase-gate transitions and go/no-go timing adjustments; approval of escalation paths to external arbiter for rule deadlock. Decisions delegated to the Editorial Board: ordinal marker pronunciation specifics, morphology retention-threshold tuning, homograph-pair list prioritization, individual rule rationale. Budget authority: Steering Committee approves spending within Phase allocations; requests exceeding phase budget or drawing >$50K from reserve require Steering Committee vote.

**Decision Mechanism:** Steering Committee quorum: 5 of 7 members. Standard decision rule: consensus or simple majority (>50%) with brief documented rationale. Tie-breaker: Project Lead holds a tie-breaking vote. Escalation: if Steering Committee cannot reach consensus on a strategic lever (e.g., adoption wedge sequencing, gate-threshold stringency), the matter is escalated to a neutral External Arbiter (appointed by Month 5 = 2027-03-13, TBD per Editorial Board Charter) for binding recommendation to the Committee within 2 weeks.

**Meeting Cadence:** Monthly standing meetings (first Tuesday of each month, 2 hours); additional checkpoint meetings at Months 11 (2027-09-13), 18 (2028-04-13), 23 (2028-09-13) (90 minutes each) for gate readiness reviews. Ad-hoc emergency meetings called by the Project Lead if any critical-path item slips >2 weeks or a budget variance >$50K is discovered.

**Typical Agenda Items:**

- Phase milestone status and critical-path variance (rules finalization, audio completion, recruitment, pre-registration, analysis)
- Monthly spend report: actual vs. budgeted by line item (staff, assessment, audio, curriculum, partner costs); cumulative variance and forecast; contingency-reserve balance
- Stakeholder alignment and adoption-risk assessment: educator pushback signals, publisher engagement, regulatory clearance status, pilot partner enrollment progress
- Governance and rule-decision log: summary of Editorial Board decisions from prior month, any deadlocks escalated, arbiter recommendations
- Gate readiness: validity audit findings (kappa, construct validity, confounds), pilot data quality, analysis-plan adherence, thresholds locked

**Escalation Path:** Unresolved strategic disputes (e.g., rule deadlock, adoption-wedge timing, reserve-draw disputes) are escalated to a neutral External Arbiter appointed jointly by the Steering Committee and Editorial Board by Month 5 (2027-03-13). The arbiter's recommendation is binding unless both the Steering Committee and Editorial Board formally object within 5 business days. If both reject the arbiter's recommendation, the matter escalates to the program's Funding Authority (granting body or institutional sponsor) for final decision. Post-Month-36 stewardship funding gaps trigger escalation to a designated Steward-Search Lead appointed by Month 24 (2028-10-13).
### 2. Editorial Board and Linguistic Review Panel

**Rationale for Inclusion:** Clear English rules must be specific, defensible, and internally consistent to serve as a credible reference for pilots, third-party adopters and educators. The Editorial Board is responsible for finalizing ordinal marker pronunciation, morphology retention thresholds, homograph-disambiguation policy, core-lexicon selection basis, and rule exceptions. The Board also logs all decisions with explicit rationale, resolves internal conflicts over linguistic priorities (consistency vs. usability), and manages the draft-standard 30-day public comment window. A Linguistic Review Panel (embedded within the Board) provides formal review-and-veto authority on rule ambiguities and contradictions, protecting against drift or oversimplification that would compromise the standard's reference value. This separation of editorial authority from strategic steering ensures that rule quality is not subordinated to adoption or budget pressures.

**Responsibilities:**

- Finalize all rule specifications (ordinal marker pronunciation, G2P mapping logic, morphology retention threshold, homograph-pair list, core-lexicon selection basis and exceptions) by Month 11 (2027-09-13) with explicit published rationale for each rule and for any exceptions or boundary cases
- Manage the Linguistic Review Panel: linguist members conduct formal ambiguity-and-contradiction review of proposed rules; veto authority is limited to findings of logical inconsistency, circularity or lack of publishable justification; no veto on rule choice itself
- Maintain a Decision Log: document all rule decisions, voting outcomes, dissenting opinions and the rationale for each outcome, updated within 3 business days of each board meeting; publish quarterly (Months 3, 6, 9, 12 = 2027-01-13, 2027-04-13, 2027-07-13, 2027-10-13)
- Conduct conflict resolution and tiebreaker escalation per the published Editorial Board Charter; invite formal linguist review for any deadlocked rule before escalation to the external arbiter
- Oversee the draft-standard 30-day public comment window (Month 11–12 = 2027-09-13 to 2027-10-13): publish the draft, manage comment submissions, respond in writing to all substantive comments, and publish responses with the final v1.0 rule set
- Commission and review all rule-related studies or evidence (e.g., native-speaker acceptance of ordinal forms, misread rates on homograph pairs during pilots) and integrate findings into rule tuning before v1.0 lock

**Initial Setup Actions:**

- Publish Editorial Board Charter by Month 1 (2026-11-13): composition (7–9 members; practitioner-leaning with linguist review-and-veto), voting rules (consensus or simple majority, with explicit tie-breaker), conflict-of-interest disclosure template, and decision-logging protocol
- Confirm board membership by Month 1 (2026-11-13): recruit 4–5 practitioners (ESL instructors, technical writers, safety trainers), 2–3 linguists (applied linguistics, morphology/phonology specialists), and optionally 1 learner representative; document conflict-of-interest attestations
- Appoint or confirm the external Arbiter by Month 5 (2027-03-13): independent linguist or standards-design specialist with no financial stake in ESL publishing or standards bodies; agree on fee ($10K–$20K estimate) and availability for 2-week turnaround on escalations
- Hold the first Editorial Board meeting by Month 2 (2026-12-13) to surface rule-specification tensions and assign workstreams (ordinal, morphology, homograph, lexicon, pronunciation-guidance logic) to subcommittees; set internal deadlines for rule drafts (Month 6 = 2027-04-13)
- Establish and staff a Linguistic Review Panel: designate 2–3 board linguists to form a standing subcommittee; schedule monthly 90-minute review meetings Months 5–11 (2027-03-13 to 2027-09-13) to examine proposed rules for ambiguity and contradiction before board vote

**Membership:**

- Editorial Board Chair (internal, practitioner or linguist with governance experience, 0.5 FTE)
- Practitioners (4–5 members, internal or closely affiliated): adult ESL instructors (2), technical writer or safety-training specialist (1–2), representing classroom and safety-critical contexts where rules will be applied
- Linguists (2–3 members, internal or university-affiliated): specialists in morphology, phonology, or applied linguistics; formal veto authority on rule ambiguity and contradiction; at least one with standards-development experience
- Learner Representative (optional, 1 member): adult ESL learner or recent graduate who can speak to rule comprehensibility and usability from the learner perspective; attends selected meetings and is consulted on rule clarity before public comment
- Psychometrician or Assessment Specialist (liaison, internal, ~2 hours/month): provides data on rule effects from validity studies and pilot midpoints; informs rule tuning based on evidence (e.g., ordinal error rates, comprehension confounds)

**Decision Rights:** Full decision authority over all rule specifications, thresholds and exceptions; all rule decisions are final once the Decision Log entry is signed by the Chair and published. The Linguistic Review Panel may veto a rule only if it finds the rule to be internally contradictory, logically circular, or lacking a publishable justification; such vetoes are documented in the Decision Log and escalated to the full board for revision or dispute resolution. The board may not override the Steering Committee's strategic-lever decisions (e.g., the choice of prefix ordinals, optional pronunciation overlay, ESL-first wedge) but may propose refinements or implementation guidance to the Steering Committee if rule-specification work reveals unforeseen conflicts. The board controls the draft-standard comment window process and may integrate substantive public feedback into rule clarification, but core rules cannot be reopened except post-v1.0 via formal Change-Control procedures.

**Decision Mechanism:** Simple majority voting (>50% of present members); quorum: 5 of 7–9 members. Consensus is sought as the default, but if consensus cannot be reached, a majority vote decides. Linguistic Review Panel veto on ambiguity/contradiction is binding unless the full board overrides it by supermajority (2/3 of present members). If a supermajority override is invoked, the dissenting linguist opinions are documented in the Decision Log and published with the final rule. Tie-breaker: the Board Chair casts the tie-breaking vote if voting is deadlocked; if the Chair is conflicted, an external Arbiter is called to cast the tie-breaker within 2 weeks.

**Meeting Cadence:** Monthly full Editorial Board meetings (second Thursday of each month, 2 hours); Linguistic Review Panel subcommittee meetings monthly (fourth Thursday, 90 minutes) during Months 5–11 (2027-03-13 to 2027-09-13); additional subcommittee workstreams (ordinal, morphology, homograph, lexicon) meet biweekly (1.5 hours) Months 2–10 (2026-12-13 to 2027-08-13) to draft and refine rules. Emergency Board meetings convened by the Chair if an escalated dispute or public comment requires urgent resolution.

**Typical Agenda Items:**

- Rule-specification progress reports from subcommittees: ordinal-marker pronunciation logic, morphology retention threshold rationale, homograph-pair selection and enforcement policy, core-lexicon selection basis and coverage audit findings
- Linguistic Review Panel findings: ambiguities or contradictions identified in proposed rules; revision proposals or escalation requests
- Conflict resolution and tiebreaker decisions: documented disagreements from prior meetings and the board's resolution
- Public comment review (Month 11–12 = 2027-09-13 to 2027-10-13): summary of substantive comments and project responses; integration of feedback into rule clarifications
- Integration of pilot data (Month 18 = 2028-04-13 onwards): preliminary ordinal error rates, comprehension speed, pronunciation-consistency findings; implications for rule tuning or exception-list updates before v1.0 lock

**Escalation Path:** Unresolved rule disputes between practitioners and linguists are escalated to the external Arbiter within 5 business days of a failed board vote; the Arbiter has 2 weeks to make a binding recommendation on how to resolve the conflict (e.g., adopt a minority rule position, refine the rule to address both perspectives, defer the decision to pilot evidence). If the Arbiter's recommendation is rejected by both the Steering Committee and Editorial Board, the matter escalates to the Funding Authority. Disputes over whether a rule is ambiguous/contradictory (triggering Linguistic Review veto) are escalated to the Arbiter if the full board cannot resolve the veto by supermajority override within 2 weeks. Substantive public comments during the Month 11–12 (2027-09-13 to 2027-10-13) comment window that challenge rule validity are triaged by the Editorial Board; if unresolved, a representative comment is escalated to the Arbiter for a recommendation on whether the rule should be revised before v1.0 finalization.
### 3. Metrics & Validation Committee

**Rationale for Inclusion:** The Month 24 (2028-10-13) go/no-go gate depends entirely on the credibility of four pre-registered, psychometrically sound outcome metrics (ordinal error rate, comprehension speed, pronunciation consistency, 30-day retention). Any weakness in instrument design, inter-rater reliability, construct validity, confound control or data integrity directly undermines the gate decision and risks a false-positive (weak standard launched, damaging long-term credibility) or false-negative (viable standard rejected, stranding Phase 3 and damaging adoption). The Metrics & Validation Committee ensures that instruments are purpose-built and independently validated, that validity assumptions are tested, that measurement procedures are faithfully executed across pilots, and that any validity threats are identified early (Months 18–21 = 2028-04-13 to 2028-07-13) so remediation is possible before Month 24 (2028-10-13). This committee operates at arm's length from the Editorial Board and Steering Committee to maintain measurement impartiality.

**Responsibilities:**

- Design the four gate metrics (ordinal error rate, comprehension speed, pronunciation consistency, 30-day retention) with explicit construct validity analysis; draft the pre-analysis plan specifying quantitative pass/fail thresholds, primary and secondary outcomes, confound-control procedures and manipulation checks by Month 5 (2027-03-13)
- Commission an independent validity study (N=20–30 learners) in Months 10–11 (2027-08-13 to 2027-09-13) to calibrate instruments and confirm that they discriminate between Clear English and standard-English conditions; publish findings in the pre-analysis plan
- Pre-register the analysis plan (metrics, thresholds, sample sizes, primary outcomes, analysis code) on a public repository (e.g., OSF) by Month 11 (2027-09-13), with explicit documentation of any post-hoc amendments or deviations
- Establish and monitor inter-rater reliability protocols: target Cohen's kappa ≥0.75 (proposed) for pronunciation consistency and ordinal-error scoring; conduct a calibration study by Month 11 (2027-09-13) and rater-training refreshers at Month 18 (2028-04-13) midpoint if kappa is dropping below 0.70
- Conduct a mid-phase validity audit at Months 18–22 (2028-04-13 to 2028-08-13) by an external independent auditor: examine pilot data for inter-rater reliability, construct validity (confound analysis, effect-size checks), data integrity (missing files, outliers, consent violations) and compliance with the pre-registered analysis plan; report findings to the Steering Committee by Month 23 (2028-09-13)
- Monitor measurement compliance during pilots: confirm that all assessments follow protocol, that data is securely stored with backups, that 30-day follow-up is tracked, and that participant dropouts are documented; quarterly data-quality reports to the Steering Committee

**Initial Setup Actions:**

- Hire an independent psychometrician (external or internal dedicated role) by Month 2 (2026-12-13); allocate $150K–$200K (estimate) for instrument design, validity study and inter-rater work
- Draft the Metrics & Validation Committee Charter by Month 2 (2026-12-13) specifying the Committee's authority (independent from Editorial Board and Steering Committee), decision procedures (consensus on technical validity), and escalation paths (validity threats escalate to Steering Committee within 48 hours)
- Establish the Committee membership by Month 3 (2027-01-13): psychometrician (Chair), 1–2 external applied-linguistics or measurement specialists (e.g., university faculty with publications on ESL assessment), data-integrity specialist or research-compliance officer (internal)
- Conduct a detailed construct-validity literature review and expert-panel discussion by Month 4 (2027-02-13): identify plausible confounds (repeated exposure, learner motivation, accent proximity, baseline literacy) and design explicit control conditions and manipulation checks to isolate Clear English effects
- Draft the pre-analysis plan (Months 4–5 = 2027-02-13 to 2027-03-13) and circulate for peer review to external measurement experts; incorporate feedback and finalize by Month 5 (2027-03-13)
- Design and conduct the validity-study protocol by Month 9–10 (2027-07-13 to 2027-08-13): recruit N=20–30 learners, administer Clear English and standard-English conditions, run preliminary analyses and publish findings in the pre-analysis plan by Month 11 (2027-09-13)

**Membership:**

- Psychometrician / Assessment Lead (internal, hired by Month 2 = 2026-12-13, Chair, 0.5–1.0 FTE dedicated to metrics and validation through Month 24 = 2028-10-13)
- External Measurement Specialist (e.g., university applied-linguistics researcher with ESL assessment publications, ~6 hours/month, advisory role to ensure independence from project bias)
- Data Integrity & Research Compliance Officer (internal, ~4 hours/month, ensures IRB adherence, data protection, consent and privacy protocols)
- Pilot Project Manager or Cohort Administrator (internal liaison, ~2 hours/month, provides data-quality updates and flags protocol deviations)

**Decision Rights:** Full authority over instrument design, validity analysis, data-quality standards and the pre-analysis plan; authority to halt or suspend pilots if data integrity is compromised or inter-rater reliability falls below the 0.70 floor for more than 2 weeks. May recommend changes to pilot protocol (e.g., additional rater training, modified assessment schedule, extended follow-up) to the Steering Committee; the Committee's recommendation is binding on pilot operations. May request extension of Phase 1 by up to 4 weeks (at ~$85K cost, estimate) if the validity study or inter-rater calibration requires additional time; Steering Committee must approve extensions >2 weeks. The Committee cannot override Editorial Board rule decisions but may flag to the Steering Committee if rule changes during Phase 2 pilots would invalidate previously calibrated instruments.

**Decision Mechanism:** Consensus on technical validity matters (instrument design, confound-control procedures, thresholds, analysis plan). If consensus cannot be reached, the Psychometrician (Chair) makes the final decision with documented rationale. Disagreements between the Psychometrician and external specialist are escalated to the Steering Committee if they affect go/no-go credibility (e.g., conflicting views on minimum sample size, effect-size interpretation). Data-integrity violations or inter-rater reliability below 0.70 trigger an automatic flag to the Steering Committee within 48 hours; remediation steps are determined by consensus of the Committee or, if urgent, by the Psychometrician in consultation with the Steering Committee.

**Meeting Cadence:** Bi-weekly standing meetings (Mondays, 90 minutes) from Month 2 (2026-12-13) through Month 24 (2028-10-13). Additional meetings at Months 10–11 (2027-08-13 to 2027-09-13) (weekly, for validity-study completion) and Months 18–24 (2028-04-13 to 2028-10-13) (weekly, for pilot monitoring and midpoint analysis). Emergency meetings convened within 48 hours if data-integrity issues or inter-rater reliability drops are discovered.

**Typical Agenda Items:**

- Instrument design progress and construct-validity analysis: control-condition design, manipulation-check measures, confound-control procedures
- Inter-rater reliability: kappa scores and trends, rater calibration and training updates, scoring-procedure adherence
- Validity-study and pilot data-quality reports: instrument performance, effect sizes, missing data, consent and privacy compliance, participant retention
- Pre-analysis plan review and finalization: threshold specification, sample-size power analysis, primary and secondary outcomes, analysis code
- Mid-phase audit findings (Month 18–22 = 2028-04-13 to 2028-08-13): validity threats, remediation recommendations, implications for gate credibility

**Escalation Path:** Data-integrity violations (missing recordings, unauthorized access, consent breaches) escalate immediately (within 48 hours) to the Steering Committee and the internal Data Integrity Officer; serious breaches (e.g., data loss) trigger suspension of affected pilot arms and immediate notification to IRB/ethics board. Inter-rater reliability below 0.70 for more than 2 weeks escalates to the Steering Committee with a remediation plan (rater retraining, extended inter-rater calibration, or Phase 1 extension); if remediation is not effective by Month 21 (2028-07-13), the Committee recommends to the Steering Committee whether to proceed to gate decision with degraded measurement or extend Phase 2. Construct-validity threats (e.g., evidence that a confound is larger than expected, inflating apparent Clear English effects) escalate to the Steering Committee with a recommendation for additional analysis or a supplementary validity study (costing up to $50K, estimate) by Month 21 (2028-07-13).
### 4. Compliance & Risk Management Committee

**Rationale for Inclusion:** The Clear English program spans 36 months, operates across multiple jurisdictions (UK, US, possibly EU), manages sensitive biometric data (pronunciation audio), engages vulnerable populations (adult ESL learners), pilots safety-critical documentation, and carries reputational and legal exposure if incidents or violations occur. Key risks include data-privacy breaches (GDPR, US state law violations), ethics-approval delays (2–8 weeks, estimated), safety-critical liability (injury linked to Clear English documentation), educator and standards-body pushback, financial overruns exceeding the $175K pre-gate reserve cap, and fragmentation/unofficial variants post-release. The Compliance & Risk Management Committee provides active, continuous monitoring and mitigation of these risks; escalates emerging threats to the Steering Committee; ensures legal, ethical and regulatory alignment; and maintains a current risk register with ownership and action plans. This committee operates independently from rule development and measurement to maintain impartiality on governance and risk issues.

**Responsibilities:**

- Maintain and update a live risk register (20 identified risks from the assumptions document, plus emerging risks) with ownership, mitigation actions, status and escalation criteria; conduct quarterly risk reviews (Months 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36 = 2027-01-13 onwards) and publish a summary risk dashboard to the Steering Committee
- Secure and monitor ethics-board (IRB) and data-protection compliance: ensure IRB approval of pilot protocol and consent forms by Month 6 (2027-04-13); establish encrypted audio storage with backups by Month 6 (2027-04-13); conduct a data-protection audit by Month 8 (2027-06-13); publish a privacy policy by Month 12 (2027-10-13); ensure GDPR and US state law compliance for all participant data handling
- Manage legal, liability and safety-critical risk: retain legal counsel specializing in product liability and regulatory compliance by Month 2 (2026-12-13); develop a liability insurance and risk-mitigation strategy by Month 4 (2027-02-13) with liability costs capped at $150K–$200K (estimate); establish safety-critical pilot boundaries (glossary and labeling exercises only, no live operational procedures before Month 24 = 2028-10-13) and enforce via protocol review and signed agreements with pilot partners
- Monitor stakeholder adoption and pushback risks: track educator and publisher engagement metrics (open rates on outreach, meeting attendance, non-binding letters of interest, pilot partner retention) monthly; flag educator-pushback signals (critical social media posts, TESOL/IATEFL concerns, pilot-site withdrawal) within 48 hours to the Steering Committee; trigger corrective outreach (messaging, training, incentives) if engagement drops below thresholds
- Monitor budget and timeline risks: track monthly spend variance against Phase allocations; flag budget variances >$50K or timeline slips >2 weeks to the Steering Committee; recommend contingency draws (up to $175K pre-gate cap) or scope adjustments; conduct a formal budget-fitness audit at Month 24 (2028-10-13) before go/no-go decision
- Manage post-release governance and fragmentation risks: by Month 24 (2028-10-13), identify potential steward organizations and approach them for funding commitments; design the licensing and name-stewardship model (certification mark, conformance checklist) and publish by Month 12 (2027-10-13); establish a Standards Stewardship Committee charter and decision procedures by Month 30 (2029-04-13); monitor for unofficial variants and non-conforming uses of the 'Clear English' name post-release and enforce name restrictions via the certification mark

**Initial Setup Actions:**

- Appoint Committee Chair and members by Month 1 (2026-11-13): recruit a risk-management or compliance specialist (internal or external advisor, 0.5 FTE), legal counsel or in-house counsel (external retainer, ~4 hours/month), ethics/IRB liaison (internal or academic partner, ~3 hours/month), and a stakeholder-engagement or communications specialist (internal, 0.5 FTE)
- Publish Compliance & Risk Management Committee Charter by Month 1 (2026-11-13): define committee authority (independent escalation to Steering Committee for risks exceeding tolerances), decision procedures (consensus on risk rating and mitigation ownership), and reporting cadence
- Develop a comprehensive Risk Register template by Month 2 (2026-12-13): categorize risks by domain (regulatory/standards adoption, pilot recruitment/retention, assessment validity, rule ambiguity, safety-critical liability, budget/timeline, educator pushback, fragmentation, data privacy, stewardship funding); specify likelihood, severity, current mitigation status, owners and escalation thresholds
- Engage legal counsel by Month 2 (2026-12-13) and develop a liability and insurance strategy by Month 4 (2027-02-13), including product liability coverage options, regulatory approval pathways for safety-critical pilots, and disclaimer language for all Clear English materials
- Initiate ethics-board engagement by Month 1 (2026-11-13); submit IRB protocol for review by Month 2 (2026-12-13); target approval by Month 6 (2027-04-13)
- Establish data-protection and privacy infrastructure by Month 6 (2027-04-13): contract with a secure audio-storage vendor, implement encryption and access controls, establish backup and disaster-recovery procedures, and conduct a dry-run with a small pilot cohort (N=5–10) by Month 10 (2027-08-13)
- Schedule the first Committee meeting by Month 1 (2026-11-13) to populate the Risk Register, assign owners and confirm mitigation timelines

**Membership:**

- Compliance & Risk Management Committee Chair (internal or external advisor, 0.5 FTE, governance or risk-management background, leads risk reviews and Steering Committee escalations)
- Legal Counsel / Product Liability Specialist (external retainer, ~4 hours/month, advises on product liability, regulatory pathways for safety-critical use, disclaimer language and insurance options)
- Ethics & Data-Protection Specialist (internal or external, ~3–4 hours/month, manages IRB/ethics-board approval, data-protection compliance with GDPR and US state law, consent procedures, audit trails)
- Stakeholder Engagement / Communications Lead (internal, 0.5 FTE, tracks educator and publisher engagement, flags pushback signals, coordinates corrective outreach and messaging)
- Finance & Budget Lead liaison (internal, ~2 hours/month, provides monthly spend reports, flags budget variances and timeline risks)

**Decision Rights:** Authority to recommend (but not unilaterally impose) changes to pilot protocol, budget allocation or timeline to mitigate identified risks; recommendations are binding on operations if approved by the Steering Committee. Authority to halt or suspend pilots (in coordination with Steering Committee and Metrics & Validation Committee) if data-privacy breaches, ethics violations or safety-critical incidents occur. Authority to recommend spending from the $175K pre-gate contingency reserve (in coordination with Steering Committee) for legal, ethics, insurance or urgent risk-mitigation costs. Authority to veto or modify any pilot operation that violates IRB approval, data-protection compliance, or safety-critical risk boundaries. Does not control rule specifications (Editorial Board authority) or measurement procedures (Metrics & Validation Committee authority) but may flag to those committees if compliance issues arise from rule or measurement design.

**Decision Mechanism:** Consensus on risk assessment and mitigation ownership; if consensus cannot be reached on risk severity or mitigation strategy, the Committee Chair makes the final call with documented rationale. Escalation to the Steering Committee is automatic if a risk is rated 'High' likelihood × 'High' severity, or if mitigation is inadequate or delayed. Emergency decisions (e.g., suspension of a pilot site due to ethics violation) can be made by the Committee Chair in consultation with the Steering Committee within 48 hours.

**Meeting Cadence:** Monthly standing meetings (third Wednesday, 90 minutes) from Month 1 (2026-11-13) through Month 36 (2029-10-13). Quarterly risk reviews (Months 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36 = 2027-01-13 onwards, 120 minutes) with the Steering Committee to present updated Risk Register and escalation summary. Emergency meetings convened within 48 hours if a 'High' risk event occurs (data breach, ethics violation, safety incident, budget overrun exceeding $125K).

**Typical Agenda Items:**

- Risk Register updates: new risks identified, mitigation progress on existing risks, completion of mitigation actions, status and escalation flags
- Legal and liability updates: counsel summary of regulatory landscape, product-liability considerations for safety-critical pilots, insurance recommendations and costs
- Ethics and data-protection compliance: IRB approval status, consent and privacy-audit findings, data-storage security checks, GDPR/US state law compliance summary
- Stakeholder engagement and pushback monitoring: educator and publisher engagement metrics, critical feedback or resistance signals, corrective outreach plans
- Budget and timeline variance: monthly spend report, Phase allocation tracking, contingency-reserve balance and recommended draws
- Stewardship and post-release governance: steward organization identification and funding-commitment status, licensing and name-stewardship model design, fragmentation-control and conformance-checklist planning

**Escalation Path:** All 'High' likelihood × 'High' severity risks escalate to the Steering Committee within 5 business days of identification or status change, with a documented mitigation plan and timeline. Data-privacy breaches or ethics violations escalate immediately (within 48 hours) to the Steering Committee, IRB/ethics board (if required) and relevant data-protection authorities (e.g., ICO in UK, state regulators in US). Safety-critical incidents linked to Clear English documentation escalate immediately to legal counsel, the Steering Committee, relevant workplace safety regulators (OSHA, HSE) and affected pilot organizations; trigger a formal incident investigation and communication plan. Budget overruns exceeding $125K (half the $250K contingency cap) escalate to the Steering Committee with a scope-adjustment or timeline-extension recommendation. Educator or standards-body pushback signals that could reduce pilot enrollment by >20% or delay regulatory approval by >4 weeks escalate to the Steering Committee with a corrective communication and engagement plan.

# Governance Implementation Plan

### 1. Project Lead and Funding Authority jointly identify and appoint the Project Sponsor (external funding body representative or senior institutional leader) and define their role in governance escalation and reserve-draw authorization.

**Responsible Body/Role:** Funding Authority / Institutional Sponsor

**Suggested Timeframe:** Month 0 (2026-10-13) (Project start, within 1 week of kickoff)

**Key Outputs/Deliverables:**

- Project Sponsor role description and appointment letter
- Escalation and decision authority documented in writing

**Dependencies:**

- Funding agreement executed
- Project initiation and resource allocation confirmed

### 2. Project Lead drafts the Project Steering Committee Charter, specifying membership roles, voting rules (simple majority with tie-breaker), escalation procedures for rule deadlock and budget disputes, meeting cadence, and decision thresholds (e.g., >$50K spending decisions, reserve draws, phase-gate authority).

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0 (2026-10-13) (end of Month 0 = 2026-10-13, by 2026-10-13)

**Key Outputs/Deliverables:**

- Draft Steering Committee Charter (2-3 pages, including decision authority matrix, meeting schedule, escalation path to external arbiter and Funding Authority)

**Dependencies:**

- Project Sponsor identified and engaged
- Strategic decisions documented (Pragmatic Foundation scenario confirmed)

### 3. Project Lead circulates the draft Steering Committee Charter to the nominated Steering Committee members (project lead, finance lead, editorial board chair, external academic partner, psychometrician role, ESL publisher advisor, standards-body advisor) for review and feedback; incorporates comments and finalizes.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0.5 (2026-10-28) (within 2 weeks of draft completion)

**Key Outputs/Deliverables:**

- Feedback summary on draft charter
- Steering Committee Charter v1.0 finalized

**Dependencies:**

- Draft Charter circulated
- Nominated member list confirmed

### 4. Project Lead formally publishes the Steering Committee Charter and formally appoints the Steering Committee Chair (typically the Project Lead or an external governance advisor); all 7 members confirm acceptance in writing.

**Responsible Body/Role:** Project Lead with Project Sponsor authorization

**Suggested Timeframe:** Month 1 (2026-11-13) (by 2026-11-13)

**Key Outputs/Deliverables:**

- Published Steering Committee Charter (including decision matrix, voting rules, escalation paths)
- Appointment confirmation letters from all 7 members
- Steering Committee formally constituted

**Dependencies:**

- Charter finalized
- All member nominations confirmed
- Project Sponsor approval

### 5. Project Lead drafts the Editorial Board Charter, specifying practitioner-leaning composition (4-5 practitioners: ESL instructors, technical writers, safety trainers; 2-3 linguists; 1 optional learner rep), voting rules, conflict-of-interest disclosure, decision-logging protocol, Linguistic Review Panel authority and veto scope (limited to ambiguity/contradiction findings), and tiebreaker mechanism.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0 (2026-10-13) (by end of Week 1)

**Key Outputs/Deliverables:**

- Draft Editorial Board Charter (3-4 pages, including member roles, veto authority scope, conflict-of-interest template, decision logging protocol)

**Dependencies:**

- Strategic decisions on Editorial Board composition confirmed (practitioner-leaning, linguist review-and-veto limited to ambiguity)

### 6. Project Lead recruits and confirms Editorial Board membership: 4-5 practitioners (ESL instructors, technical writers, safety trainers), 2-3 linguists (applied linguistics, morphology/phonology specialists with standards-development experience), and optionally 1 learner representative; all members sign conflict-of-interest attestations.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0.5 (2026-10-28) to Month 1 (2026-11-13) (recruitment complete by 2026-11-13)

**Key Outputs/Deliverables:**

- Confirmed membership roster with affiliations and expertise areas
- Signed conflict-of-interest disclosure forms for all members
- Confirmation of first-meeting availability

**Dependencies:**

- Member recruitment outreach completed
- Editorial Board Charter draft available for reference

### 7. Project Lead formally publishes the Editorial Board Charter and announces the confirmed board membership; all members sign the charter in acknowledgment.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 1 (2026-11-13) (by 2026-11-13)

**Key Outputs/Deliverables:**

- Published Editorial Board Charter
- Signed acknowledgment from all 7-9 board members
- Editorial Board formally constituted

**Dependencies:**

- Charter finalized and reviewed by nominated members
- All conflict-of-interest forms signed

### 8. Project Lead identifies and recruits an external Arbiter (neutral linguist or standards-design specialist with no financial stake in ESL publishing or standards bodies) to serve as tiebreaker for rule deadlocks and strategic disputes; document agreed fee ($10K-$20K estimate), availability for 2-week turnaround on escalations, and contact/escalation protocol.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Months 2-5 (2026-12-13 to 2027-03-13) (by 2027-03-13)

**Key Outputs/Deliverables:**

- Arbiter identification and bio
- Signed engagement agreement with fee and availability terms
- Escalation protocol documented for Steering Committee and Editorial Board

**Dependencies:**

- Steering Committee and Editorial Board established
- Budget for arbiter fees allocated ($10K-$20K estimate)

### 9. Project Lead schedules and holds the first Editorial Board meeting to surface rule-specification tensions and assign workstreams (ordinal, morphology, homograph, lexicon, pronunciation-guidance logic) to subcommittees; set internal deadlines for rule drafts (Month 6 = 2027-04-13).

**Responsible Body/Role:** Editorial Board Chair (Project Lead or designated chair)

**Suggested Timeframe:** Month 2 (2026-12-13) (by 2026-12-13)

**Key Outputs/Deliverables:**

- Meeting minutes documenting rule-specification tensions and workstream assignments
- Subcommittee membership confirmed (ordinal, morphology, homograph, lexicon, pronunciation-guidance)
- Internal deadlines locked for draft-rule delivery (Month 6 = 2027-04-13)

**Dependencies:**

- Editorial Board formally constituted
- Charter published

### 10. Project Lead hires an independent psychometrician (external or internal dedicated role, 0.5-1.0 FTE) to lead instrument design, validity analysis and inter-rater reliability work; allocate $150K-$200K (estimate) budget; establish role reporting to Project Lead and the Metrics & Validation Committee (to be formed).

**Responsible Body/Role:** Project Lead with Finance Lead approval

**Suggested Timeframe:** Month 2 (2026-12-13) (by 2026-12-13)

**Key Outputs/Deliverables:**

- Psychometrician job description and offer letter
- Contract or employment agreement signed
- Start date confirmed (Month 2 or early Month 3 = 2027-01-13)
- Budget allocation confirmed: $150K-$200K for total metrics work through Month 24 (2028-10-13)

**Dependencies:**

- Budget and hiring authority available
- Role requirements document prepared

### 11. Psychometrician (with Project Lead support) conducts a detailed construct-validity literature review and expert-panel discussion (involving external applied-linguistics and measurement specialists) to identify plausible confounds (repeated exposure, learner motivation, accent proximity, baseline literacy) and design explicit control conditions and manipulation checks to isolate Clear English effects.

**Responsible Body/Role:** Psychometrician (newly hired), with external measurement specialist advising

**Suggested Timeframe:** Month 4 (2027-02-13) (by 2027-02-13)

**Key Outputs/Deliverables:**

- Construct-validity literature review report (10-15 pages)
- Expert-panel discussion summary (confounds identified, control-condition proposals)
- Preliminary list of manipulation checks and confound-control procedures

**Dependencies:**

- Psychometrician hired and in role
- External specialists identified and available for consultation

### 12. Psychometrician drafts the pre-analysis plan specifying: (1) quantitative pass/fail thresholds for the four gate metrics (ordinal error ≥25% reduction, comprehension speed ≤10% slower, pronunciation consistency ≥15% above control, 30-day retention ≥70%); (2) minimum sample sizes (n≥80 per arm for 80% power at α=0.05); (3) primary and secondary outcomes; (4) intention-to-treat vs. completer-case rules; (5) control conditions and manipulation checks; (6) inter-rater reliability targets (kappa ≥0.75 target, 0.70 floor); (7) data-quality and missing-data protocols.

**Responsible Body/Role:** Psychometrician

**Suggested Timeframe:** Months 4-5 (2027-02-13 to 2027-03-13) (draft complete by 2027-03-13)

**Key Outputs/Deliverables:**

- Pre-analysis plan draft (15-20 pages, including quantitative thresholds with justification, sample-size power analysis, primary outcomes, confound-control procedures, analysis code skeleton)

**Dependencies:**

- Construct-validity review and expert-panel input complete
- Gate metrics specified by Steering Committee and Editorial Board

### 13. Psychometrician circulates the pre-analysis plan draft for external peer review (to external measurement specialists, applied-linguistics researchers, and a representative from the Steering Committee); collects feedback and revises.

**Responsible Body/Role:** Psychometrician with external review committee

**Suggested Timeframe:** Month 5 (2027-03-13) (feedback deadline Month 5 = 2027-03-13, revision complete by Month 5.5 = 2027-03-28)

**Key Outputs/Deliverables:**

- External review feedback summary (2-3 pages)
- Revised pre-analysis plan v2 (incorporating substantive feedback)

**Dependencies:**

- Draft plan circulated to external reviewers
- External reviewers nominated and committed

### 14. Project Lead drafts the Metrics & Validation Committee Charter, specifying the Committee's independence from Editorial Board and Steering Committee, decision authority over instrument design and data-quality standards, authority to recommend (and escalate if needed) changes to pilot protocol, data-integrity standards, and escalation procedures (data-privacy breaches, kappa below 0.70, validity threats escalate to Steering Committee within 48 hours).

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 2 (2026-12-13) (by 2026-12-13)

**Key Outputs/Deliverables:**

- Draft Metrics & Validation Committee Charter (2-3 pages)

**Dependencies:**

- Psychometrician hired
- Steering Committee governance model established

### 15. Project Lead formally appoints the Metrics & Validation Committee: Psychometrician (Chair), 1-2 external applied-linguistics or measurement specialists (e.g., university faculty with ESL assessment publications), and a data-integrity/research-compliance officer (internal); publish the Committee Charter with all members' signed acknowledgment.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 3 (2027-01-13) (by 2027-01-13)

**Key Outputs/Deliverables:**

- Published Metrics & Validation Committee Charter
- Appointment confirmation letters from Committee members
- Committee formally constituted
- Meeting schedule locked (bi-weekly, Mondays 90 minutes, through Month 24 = 2028-10-13)

**Dependencies:**

- Charter drafted and reviewed
- Psychometrician in role and identified as Chair
- External specialists recruited

### 16. Psychometrician designs and conducts the validity-study protocol: recruit N=20-30 adult ESL learners; expose them to both Clear English and standard-English ordinal conditions (within-subject or between-subject design); administer assessment instruments; collect pronunciation audio if applicable; run preliminary analyses (effect sizes, inter-rater kappa, construct-validity checks); document findings.

**Responsible Body/Role:** Psychometrician with Metrics & Validation Committee oversight

**Suggested Timeframe:** Months 9-10 (2027-07-13 to 2027-08-13)

**Key Outputs/Deliverables:**

- Validity-study protocol document (IRB-approved)
- Preliminary analysis results: effect sizes for ordinal error rate, comprehension speed, pronunciation consistency; inter-rater kappa scores; control-condition performance
- Findings report (5-10 pages)

**Dependencies:**

- Ethics/IRB approval obtained by Month 6 (2027-04-13)
- Assessment instruments finalized
- Small pilot cohort recruited (N=20-30)

### 17. Psychometrician incorporates validity-study findings into the final pre-analysis plan; finalize thresholds, sample sizes, and analysis procedures; submit the complete pre-analysis plan to an external pre-registration repository (e.g., Open Science Framework, OSF) by Month 11 (2027-09-13).

**Responsible Body/Role:** Psychometrician

**Suggested Timeframe:** Month 10-11 (2027-08-13 to 2027-09-13) (pre-registration complete by 2027-09-13)

**Key Outputs/Deliverables:**

- Pre-analysis plan v3, final (incorporating validity-study findings)
- OSF or equivalent pre-registration URL and timestamp
- Published pre-analysis plan summary (1-2 pages) available to Steering Committee

**Dependencies:**

- Validity study completed and analyzed
- External review feedback incorporated
- Gate metrics finalized and approved by Steering Committee

### 18. Project Lead drafts the Compliance & Risk Management Committee Charter, specifying the Committee's authority to recommend changes to pilot protocol to mitigate identified risks, to escalate high-severity risks to the Steering Committee within 5 business days, and to halt pilots if data-privacy breaches or ethics violations occur.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 1 (2026-11-13) (by 2026-11-13)

**Key Outputs/Deliverables:**

- Draft Compliance & Risk Management Committee Charter (2-3 pages)

**Dependencies:**

- Steering Committee governance model established
- Risk register template prepared

### 19. Project Lead recruits Compliance & Risk Management Committee members: risk-management specialist (Chair, 0.5 FTE), external legal counsel (product liability and regulatory compliance, ~4 hours/month retainer), ethics/IRB liaison (internal or academic partner, ~3-4 hours/month), stakeholder-engagement/communications lead (internal, 0.5 FTE), and finance/budget lead liaison (internal, ~2 hours/month).

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 1-2 (2026-11-13 to 2026-12-13)

**Key Outputs/Deliverables:**

- Confirmed Committee membership with roles and affiliations
- Signed engagement letters for external legal counsel and ethics liaison
- Committee members ready to attend first meeting

**Dependencies:**

- Committee Charter drafted
- Budget allocated for legal counsel, ethics consulting, and additional FTE

### 20. Project Lead formally appoints the Compliance & Risk Management Committee with published Charter; all members sign acknowledgment.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 1 (2026-11-13) (by 2026-11-13)

**Key Outputs/Deliverables:**

- Published Compliance & Risk Management Committee Charter
- Appointment confirmation letters from all members
- Committee formally constituted
- Meeting schedule locked (monthly, third Wednesday 90 minutes, through Month 36 = 2029-10-13)

**Dependencies:**

- Charter finalized
- All members confirmed

### 21. Project Lead engages external legal counsel (product-liability and regulatory-compliance specialist) to advise on liability, insurance, disclaimer language for safety-critical materials, and regulatory approval pathways for safety-critical pilots; retain by signed engagement letter by Month 2 (2026-12-13).

**Responsible Body/Role:** Project Lead with Compliance & Risk Management Committee guidance

**Suggested Timeframe:** Month 2 (2026-12-13) (by 2026-12-13)

**Key Outputs/Deliverables:**

- Signed legal counsel engagement letter ($10K-$20K estimated annual retainer estimate)
- Preliminary legal review of project liability and insurance needs

**Dependencies:**

- Budget for legal counsel allocated
- Compliance & Risk Management Committee Chair identified

### 22. Compliance & Risk Management Committee develops a comprehensive Risk Register template categorizing risks by domain (regulatory/standards adoption, pilot recruitment/retention, assessment validity, rule ambiguity, safety-critical liability, budget/timeline, educator pushback, fragmentation, data privacy, stewardship funding); list 20 identified risks from assumptions document plus space for emerging risks; specify likelihood, severity, mitigation status, owners and escalation thresholds.

**Responsible Body/Role:** Compliance & Risk Management Committee Chair with Committee members

**Suggested Timeframe:** Month 2 (2026-12-13) (by 2026-12-13)

**Key Outputs/Deliverables:**

- Risk Register template (Excel or web-based tool) with 20+ pre-populated risks, likelihood/severity matrix, mitigation columns, owner assignments
- Risk tolerance thresholds documented (high×high and high×medium risks escalate automatically)

**Dependencies:**

- Committee members recruited and in role
- Risk assumptions document reviewed

### 23. Compliance & Risk Management Committee holds first meeting to populate the Risk Register, assign mitigation owners, confirm timelines and escalation procedures, and establish quarterly risk-review schedule (Months 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36 = 2027-01-13 onwards).

**Responsible Body/Role:** Compliance & Risk Management Committee

**Suggested Timeframe:** Month 1 (2026-11-13) (by 2026-11-13)

**Key Outputs/Deliverables:**

- Completed Risk Register with mitigation owners and target completion dates
- Quarterly risk-review schedule published
- First quarterly risk review scheduled for Month 3 (2027-01-13)
- Meeting minutes documenting risk assignments and escalation paths

**Dependencies:**

- Committee formally constituted
- Risk Register template ready

### 24. Project Lead engages ethics review board or Institutional Review Board (IRB) to clarify whether the pilot qualifies as research requiring formal review; submit initial consultation request by Month 1 (2026-11-13).

**Responsible Body/Role:** Compliance & Risk Management Committee (ethics liaison) with Project Lead

**Suggested Timeframe:** Months 1-2 (2026-11-13 to 2026-12-13)

**Key Outputs/Deliverables:**

- Initial IRB consultation completed
- Written guidance on whether full protocol review is required
- IRB contact and process timeline documented

**Dependencies:**

- Ethics liaison identified
- Initial pilot design document available

### 25. Compliance & Risk Management Committee drafts a formal IRB protocol (including study design, informed-consent forms, data-handling procedures, audio-recording consent with options for data deletion, privacy safeguards, confidentiality measures) and submits to IRB for review by Month 3 (2027-01-13), targeting approval by Month 6 (2027-04-13).

**Responsible Body/Role:** Compliance & Risk Management Committee (ethics liaison) with Psychometrician input

**Suggested Timeframe:** Months 2-3 (2026-12-13 to 2027-01-13) (draft complete by 2027-01-13, submitted to IRB)

**Key Outputs/Deliverables:**

- Formal IRB protocol document (15-20 pages: study background, objectives, design, population, procedures, informed-consent form, data-protection plan, confidentiality safeguards, audio-consent options)
- Submitted to IRB with cover letter
- IRB submission date and expected review timeline documented

**Dependencies:**

- Initial IRB consultation completed
- Pilot design and assessment procedures finalized
- Ethics liaison in role

### 26. Compliance & Risk Management Committee secures encrypted audio-storage infrastructure with access controls, backup and disaster-recovery protocols; conduct vendor selection and sign contract by Month 6 (2027-04-13); set up storage systems and test backup procedures by Month 6 (2027-04-13).

**Responsible Body/Role:** Compliance & Risk Management Committee (data-integrity officer) with IT/project support

**Suggested Timeframe:** Months 4-6 (2027-02-13 to 2027-04-13)

**Key Outputs/Deliverables:**

- Audio-storage vendor selected and contract signed
- Storage infrastructure deployed and tested
- Access-control and encryption protocols documented
- Backup and disaster-recovery procedures tested with dry-run data

**Dependencies:**

- Data-integrity officer in role
- Budget allocated for storage ($20K-$30K estimate)

### 27. Compliance & Risk Management Committee conducts a data-protection audit (GDPR compliance, US state privacy law requirements, data-retention schedules, participant access rights) and publishes a privacy policy and data-retention schedule on the project website by Month 12 (2027-10-13); document findings and any compliance gaps.

**Responsible Body/Role:** Compliance & Risk Management Committee (ethics liaison, legal counsel)

**Suggested Timeframe:** Months 8-12 (2027-06-13 to 2027-10-13)

**Key Outputs/Deliverables:**

- Data-protection audit report (5-10 pages, GDPR/US law compliance assessment)
- Published privacy policy on project website
- Published data-retention schedule (e.g., audio deleted after analysis unless participant requests retention)
- Participant-access and data-deletion procedures documented

**Dependencies:**

- Ethics/IRB protocol approved
- Audio storage infrastructure in place
- Legal counsel advising

### 28. Project Lead (with Steering Committee and Editorial Board input) confirms the five critical strategic-lever choices documented in the Pragmatic Foundation scenario: (1) Ordinal Marker Architecture—numeric prefix marker, legacy forms coexist; (2) Grapheme-to-Phoneme Depth—optional overlay, no respelling; (3) Adoption Wedge—ESL-first supplementary; (4) Outcome Metric Battery—purpose-built, independently validated; (5) Phase Budget—even spread ($1.1M/$1.2M/$0.85M). Publish with written rationale and trade-off documentation.

**Responsible Body/Role:** Project Lead with Steering Committee and Editorial Board review

**Suggested Timeframe:** Month 2 (2026-12-13) (by 2026-12-13)

**Key Outputs/Deliverables:**

- Strategic-Lever Confirmation document (3-5 pages, each lever with rationale, alternatives considered, trade-offs documented)
- Published to all governance bodies

**Dependencies:**

- Steering Committee and Editorial Board formally constituted
- Pragmatic Foundation scenario approved by Project Sponsor

### 29. Project Lead establishes a Critical Path Dashboard tracking phase milestones (rules finalization, audio completion, recruitment enrollment, pre-registration, pilot midpoint, analysis), resource allocation by phase and budget line, and go/no-go gate conditions (pre-registration thresholds locked, pilot enrollment ≥80 per arm, 30-day follow-up completion ≥70%, inter-rater kappa ≥0.70, validity audit findings clean); review monthly and escalate slips >2 weeks to Steering Committee.

**Responsible Body/Role:** Project Lead with Finance Lead

**Suggested Timeframe:** Month 1 (2026-11-13) (by 2026-11-13)

**Key Outputs/Deliverables:**

- Critical Path Dashboard (shared spreadsheet or project-management tool with monthly milestone tracking, variance alerts set for >2-week slips, gate-condition checklist)
- Monthly status report template (variance from plan, risk flag summary, next steps)

**Dependencies:**

- Phase structure and budget allocation finalized
- Key milestones defined

### 30. Project Lead schedules phase-gate checkpoint meetings with Steering Committee: (1) Month 11 (2027-09-13) pre-registration review and rules-finalization readiness; (2) Month 18 (2028-04-13) midpoint check on pilot enrollment, retention, and preliminary data quality; (3) Month 23 (2028-09-13) validity audit review and go/no-go readiness; (4) Month 24 (2028-10-13) go/no-go decision meeting.

**Responsible Body/Role:** Project Lead / Steering Committee Chair

**Suggested Timeframe:** Month 1 (2026-11-13) (by 2026-11-13)

**Key Outputs/Deliverables:**

- Calendar holds for all 4 checkpoint meetings locked (90-120 minutes each)
- Checkpoint agenda template distributed (pre-registration status, budget variance, risk summary, gate-condition checklist)

**Dependencies:**

- Steering Committee formally constituted
- Phase timeline and gates confirmed

### 31. Project Lead identifies 3-4 adult ESL programs and 2-3 technical/safety-training organizations as pilot partners; initiate outreach with brief overview of the Clear English program, pilot participation expectations (enrollment, in-person assessments, 30-day follow-up), and proposed partnership terms (per-learner payment, incentive structure, educator training, feedback loop).

**Responsible Body/Role:** Project Lead with Stakeholder Engagement Lead (Compliance & Risk Management Committee)

**Suggested Timeframe:** Month 1-2 (2026-11-13 to 2026-12-13)

**Key Outputs/Deliverables:**

- Outreach list of 5-7 partner organizations identified
- Outreach email and brief describing program, timeline and partnership terms
- First-contact completed with all identified partners

**Dependencies:**

- Pilot design outlined
- Budget for pilot participation costs ($208K-$351K estimate) allocated

### 32. Project Lead and Stakeholder Engagement Lead co-design pilot protocols with representatives from each partner organization (assessment schedule, classroom integration, learner-communication plan, data-sharing agreements); ensure protocols address partner capacity and learner-retention incentives; finalize by Month 3 (2027-01-13).

**Responsible Body/Role:** Project Lead with Stakeholder Engagement Lead and partner representatives

**Suggested Timeframe:** Months 2-3 (2026-12-13 to 2027-01-13)

**Key Outputs/Deliverables:**

- Co-designed pilot protocols (assessment schedule, materials, learner communication, feedback mechanisms)
- Partner feedback and approval documented

**Dependencies:**

- Initial partner outreach completed
- Metrics & Validation Committee assessment instruments drafted

### 33. Project Lead secures signed pilot-partnership commitments from at least 3 adult ESL programs and 2 technical/safety-training organizations, including written enrollment guarantees (≥115 per organization estimate, total ≥460 across 4 arms), contact-hour payment terms, educator training commitment, and data-sharing agreement; all signed by Month 3 (2027-01-13).

**Responsible Body/Role:** Project Lead with Compliance & Risk Management Committee (contract review)

**Suggested Timeframe:** Months 2-3 (2026-12-13 to 2027-01-13)

**Key Outputs/Deliverables:**

- Signed partnership agreements (3-4 pages each, enrollment guarantees, payment terms, data-sharing, educator training, feedback schedule)
- Enrollment commitments documented (total ≥460 learners, breakdown by partner and condition)
- Pilot partner commitment summary (table: partner name, contact, enrollment target, start date, payment terms)

**Dependencies:**

- Co-designed protocols agreed
- IRB approval (or interim approval to proceed pending full approval) obtained

### 34. Project Lead recruits a dedicated Phase 2 cohort manager (1.0 FTE, ~$60K-$80K/year estimate) to oversee pilot enrollment, retention, scheduling, data collection, participant incentive distribution, 30-day follow-up contact, and dropout documentation; hire by Month 6 (2027-04-13) to begin recruitment preparation.

**Responsible Body/Role:** Project Lead with Finance Lead approval

**Suggested Timeframe:** Months 4-6 (2027-02-13 to 2027-04-13)

**Key Outputs/Deliverables:**

- Cohort manager job description and offer letter
- Employment/contract signed
- Start date confirmed (by Month 6 = 2027-04-13)
- Cohort-management systems (tracking, enrollment database, follow-up procedures) set up

**Dependencies:**

- Budget for cohort-manager salary allocated
- Pilot partnership agreements signed

### 35. Project Lead and Stakeholder Engagement Lead develop and deliver educator training on Clear English rules, rationale, pilot administration, and learner communication; training delivered to all pilot site educators (2-3 sessions, in-person or virtual) by Month 10 (2027-08-13); offer continuing education credits or stipends ($20K-$40K estimate) to incentivize participation.

**Responsible Body/Role:** Stakeholder Engagement Lead with Editorial Board input on rule explanation

**Suggested Timeframe:** Months 8-10 (2027-06-13 to 2027-08-13)

**Key Outputs/Deliverables:**

- Educator training curriculum (1-2 days, covering Clear English history, rule rationale, assessment procedures, learner FAQ)
- Training delivery completed at all pilot sites
- Attendance records and feedback from educators
- Continuing education certificates or stipend payments issued (~$50 per educator, estimate)

**Dependencies:**

- Rules finalized by Month 12 (2027-10-13) or draft rules by Month 9 (2027-07-13)
- Pilot partnership agreements signed with training commitment

### 36. Project Lead and Stakeholder Engagement Lead engage ESL teacher professional organizations (TESOL, IATEFL, national equivalents) as advisory partners by Month 2 (2026-12-13), with monthly or quarterly contact to discuss pilot findings, educator concerns, and adoption barriers; track engagement metrics (meeting attendance, feedback quality) monthly.

**Responsible Body/Role:** Stakeholder Engagement Lead

**Suggested Timeframe:** Month 2 onwards (2026-12-13 through Month 36 = 2029-10-13)

**Key Outputs/Deliverables:**

- Advisory partnership letters from TESOL, IATEFL or national equivalents
- Contact and engagement plan (meeting schedule, feedback mechanisms)
- Monthly engagement-metric summary (open rates, attendance, sentiment)

**Dependencies:**

- Stakeholder Engagement Lead in role
- Pilot design and educator concerns documented

### 37. Project Lead and Stakeholder Engagement Lead conduct stakeholder-expectation interviews and focus groups (Months 1-3 = 2026-11-13 to 2027-01-13) with educators, regulators, ESL publishers, and learners to understand their success criteria and concerns; document findings in a Stakeholder Alignment Charter published by Month 6 (2027-04-13).

**Responsible Body/Role:** Stakeholder Engagement Lead with Project Lead

**Suggested Timeframe:** Months 1-6 (2026-11-13 to 2027-04-13)

**Key Outputs/Deliverables:**

- Stakeholder interview and focus-group notes (10-15 interviews/groups, 3-5 key stakeholder segments documented)
- Stakeholder Alignment Charter (3-5 pages, success criteria by segment, concerns flagged, project responses documented)
- Published on project website and distributed to governance bodies

**Dependencies:**

- Stakeholder Engagement Lead in role
- Strategic decisions on adoption wedge and risk mitigation available

### 38. Project Lead and Stakeholder Engagement Lead build stakeholder advisory panels (separate from Editorial Board and Steering Committee) for educators, regulators, and publishers, meeting quarterly (Months 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36 = 2027-01-13 onwards) to surface emerging concerns and expectations; generate quarterly advisory-panel meeting summaries.

**Responsible Body/Role:** Stakeholder Engagement Lead

**Suggested Timeframe:** Month 2 (2026-12-13) onwards (panels established by 2026-12-13, first meeting Month 3 = 2027-01-13)

**Key Outputs/Deliverables:**

- Stakeholder advisory panels formed (educator panel: 3-5 teachers; regulator panel: standards-body and education-authority reps; publisher panel: 2-3 ESL publishers)
- Quarterly meeting notes (expectations, pushback signals, adoption barriers)
- Summary alerts escalated to Steering Committee if engagement drops or pushback increases

**Dependencies:**

- Stakeholder Engagement Lead in role
- Engagement contacts identified from interviews/focus groups

### 39. Project Lead and Stakeholder Engagement Lead conduct a mid-phase stakeholder check-in at Month 18 (2028-04-13) to assess alignment with project expectations and to adjust Phase 2 or Phase 3 strategy if major gaps are identified; publish a brief mid-phase alignment update.

**Responsible Body/Role:** Stakeholder Engagement Lead with Project Lead and Steering Committee

**Suggested Timeframe:** Month 18 (2028-04-13)

**Key Outputs/Deliverables:**

- Mid-phase stakeholder check-in meeting (educator, regulator, publisher panels)
- Alignment-update report (2-3 pages, what's working, what needs adjustment, Phase 3 adoption barriers identified)

**Dependencies:**

- Quarterly advisory panels meeting regularly through Month 18 (2028-04-13)

### 40. Project Lead confirms the single reference accent choice for pronunciation guidance (e.g., General American, Received Pronunciation, or shared-contrast phonemes across accents) with explicit written justification by Month 3 (2027-01-13); document how other major accents (British, American, Australian, Indian) map to the anchor.

**Responsible Body/Role:** Project Lead with Psychometrician and Editorial Board (linguist members) input

**Suggested Timeframe:** Month 3 (2027-01-13) (by 2027-01-13)

**Key Outputs/Deliverables:**

- Accent choice decision document (2-3 pages, anchor selected, justification, mapping to other accents outlined)
- Published and available to all governance bodies

**Dependencies:**

- Editorial Board linguist members in role
- Psychometrician and Reference Accent decision maker engaged

### 41. Project Lead and Finance Lead implement monthly financial tracking and rolling 6-month cash-flow forecasting from Month 1 (2026-11-13) onwards; track actual spending by Phase and budget line against allocations; flag variances >$50K or timeline slips >2 weeks for Steering Committee review.

**Responsible Body/Role:** Finance Lead with Project Lead

**Suggested Timeframe:** Month 1 onwards (2026-11-13 through Month 36 = 2029-10-13)

**Key Outputs/Deliverables:**

- Monthly spend report (Phase allocation, actual vs. budget by line item, cumulative variance, 6-month forecast)
- Budget-variance alert procedure (thresholds, escalation path to Steering Committee)
- Contingency-reserve balance tracked monthly

**Dependencies:**

- Phase budget allocations and spending authorization framework established
- Accounting system or finance tracking tool in place

### 42. Project Lead and Finance Lead conduct a formal spending review at Month 9 (2027-07-13) to assess Phase 1 expenses against budget and to adjust Phase 2 allocations if needed; Steering Committee reviews findings and approves any reallocation or contingency draws.

**Responsible Body/Role:** Finance Lead with Project Lead and Steering Committee

**Suggested Timeframe:** Month 9 (2027-07-13)

**Key Outputs/Deliverables:**

- Month 9 (2027-07-13) spending review report (Phase 1 actual spend, variances by line item, Phase 2 budget adjustment recommendations if needed)
- Steering Committee decision on any Phase 2 reallocation or contingency draw (up to $175K pre-gate cap)

**Dependencies:**

- Monthly spend tracking established and regular
- Phase 1 major expenses largely committed or incurred (staff, instruments, partnership agreements)

### 43. Project Lead negotiates fixed-rate contracts with curriculum vendors and audio studios by Month 3 (2027-01-13) to lock recording and design costs; specify deliverables, timeline, quality standards and penalties for delays.

**Responsible Body/Role:** Project Lead with Finance Lead

**Suggested Timeframe:** Months 1-3 (2026-11-13 to 2027-01-13)

**Key Outputs/Deliverables:**

- Fixed-rate contracts signed with audio studio (recording 5,000 entries), curriculum designer, and any other key vendors
- Cost per deliverable locked (e.g., $15-20 per audio entry, $X per curriculum module)
- Timeline and quality-acceptance criteria documented

**Dependencies:**

- Vendor selection process completed
- Budget allocation for audio recording ($80K-$120K estimate) and curriculum ($X estimate) available

### 44. Project Lead identifies a contingency audio studio or recording partner as a backup by Month 3 (2027-01-13) in case the primary vendor encounters delays or quality issues; document backup contact and standby agreement.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 3 (2027-01-13) (by 2027-01-13)

**Key Outputs/Deliverables:**

- Backup vendor identified and standby agreement in place (turnaround time, cost differential if backup is activated)

**Dependencies:**

- Primary audio vendor contracted

### 45. Editorial Board (ordinal workstream subcommittee) finalizes the ordinal-marker pronunciation specification (symbol, spoken reading, conversion rules from legacy 1st/2nd/3rd forms) and documents with explicit rationale by Month 10 (2027-08-13); Linguistic Review Panel vets for ambiguity.

**Responsible Body/Role:** Editorial Board (ordinal subcommittee) with Linguistic Review Panel oversight

**Suggested Timeframe:** Months 6-10 (2027-04-13 to 2027-08-13)

**Key Outputs/Deliverables:**

- Ordinal-marker pronunciation specification (2-3 pages, marker symbol, spoken reading rule, legacy-form conversion examples, boundary cases clarified)
- Rationale document (why this marker/pronunciation, design alternatives considered)

**Dependencies:**

- Editorial Board and Linguistic Review Panel formally constituted
- Ordinal workstream assigned and meeting regularly

### 46. Editorial Board (morphology workstream subcommittee) finalizes the irregular-morphology retention threshold, specifying which irregular verbs and plurals are retained (e.g., high-frequency forms like go/went) and which are regularized (lower-frequency or high-learning-friction forms); document rationale and published list of ~25% of irregulars regularized by Month 10 (2027-08-13).

**Responsible Body/Role:** Editorial Board (morphology subcommittee) with Linguistic Review Panel oversight

**Suggested Timeframe:** Months 6-10 (2027-04-13 to 2027-08-13)

**Key Outputs/Deliverables:**

- Morphology retention-threshold specification (frequency cutoff, recognition-penalty analysis, final list of regularized forms)
- Rationale document (retention rule justification, alternatives considered)
- Published list of retained irregular forms and regularized replacements (supporting the ~25% change rate proposed threshold)

**Dependencies:**

- Editorial Board morphology subcommittee in role
- Core-lexicon frequency data available

### 47. Editorial Board (homograph workstream subcommittee) finalizes the homograph-disambiguation policy, specifying the published list of ≤50 high-impact homograph/homophone pairs (e.g., lead/lead, read/read) and whether each requires a marker (mandatory in safety-critical docs), optional elsewhere, or a rewrite rule; document enforcement policy by Month 10 (2027-08-13).

**Responsible Body/Role:** Editorial Board (homograph subcommittee) with Linguistic Review Panel oversight

**Suggested Timeframe:** Months 6-10 (2027-04-13 to 2027-08-13)

**Key Outputs/Deliverables:**

- Homograph-disambiguation policy (published pair list ≤50 pairs estimate, marker vs. rewrite rule decision per pair, enforcement procedure for safety-critical documents)
- Rationale document (incident-based selection of pairs, cost/benefit of markers vs. rewrites)
- Marker symbol (if used) and application rules documented

**Dependencies:**

- Editorial Board homograph subcommittee in role
- Safety-critical pilot context identified

### 48. Editorial Board (lexicon workstream subcommittee) finalizes the core-lexicon selection basis (frequency-led general words + technical/safety reserve block), completes the 5,000-word list with pronunciations mapped and selection rationale documented by Month 10 (2027-08-13); audit coverage of pilot running text (target ≥85% coverage).

**Responsible Body/Role:** Editorial Board (lexicon subcommittee) with Psychometrician consultation

**Suggested Timeframe:** Months 4-10 (2027-02-13 to 2027-08-13)

**Key Outputs/Deliverables:**

- Core-lexicon selection basis document (frequency-led approach, technical/safety block details, rationale for selection principle)
- Final 5,000-word list (Excel with orthography, pronunciation guidance, standard-English mapping, frequency rank)
- Coverage audit report (% of running text in pilot materials, ESL curricula, safety glossaries covered by lexicon)

**Dependencies:**

- Editorial Board lexicon subcommittee in role
- Frequency corpora or domain-specific corpus available

### 49. Editorial Board conducts the first formal Editorial Board meeting (Month 2 = 2026-12-13) and subsequent monthly or biweekly subcommittee meetings (ordinal, morphology, homograph, lexicon, pronunciation-guidance logic) during Months 2-10 (2026-12-13 to 2027-08-13) to draft and refine rules; resolve conflicts using the Board's decision mechanism (simple majority, with linguist veto on ambiguity, escalation to external arbiter if needed).

**Responsible Body/Role:** Editorial Board with Linguistic Review Panel

**Suggested Timeframe:** Months 2-10 (2026-12-13 to 2027-08-13)

**Key Outputs/Deliverables:**

- Monthly Board meeting minutes documenting rule-decision progress, any conflicts, and escalations
- Biweekly subcommittee meeting notes (draft rule proposals, feedback cycles)

**Dependencies:**

- Editorial Board formally constituted
- Subcommittees assigned (Month 2 = 2026-12-13)

### 50. Linguistic Review Panel (linguist members of Editorial Board) conducts monthly 90-minute review meetings (Months 5-11 = 2027-03-13 to 2027-09-13) to examine proposed rules from subcommittees for ambiguity, logical contradiction, or lack of publishable justification; document any veto findings and escalation requests.

**Responsible Body/Role:** Linguistic Review Panel (embedded in Editorial Board)

**Suggested Timeframe:** Months 5-11 (2027-03-13 to 2027-09-13)

**Key Outputs/Deliverables:**

- Monthly Linguistic Review Panel meeting summaries (rules reviewed, veto findings, escalation requests if consensus not reached)
- Vetoed rules escalated to full Editorial Board for discussion and resolution

**Dependencies:**

- Linguistic Review Panel formally designated
- Monthly subcommittee drafts available for review

### 51. Editorial Board (with Project Lead support) maintains a Decision Log documenting all rule decisions, voting outcomes, dissenting opinions and rationale for each outcome; update within 3 business days of each board or subcommittee decision; publish quarterly (Months 3, 6, 9, 12 = 2027-01-13, 2027-04-13, 2027-07-13, 2027-10-13).

**Responsible Body/Role:** Editorial Board Chair with Project Lead administrative support

**Suggested Timeframe:** Months 1-12 (2026-11-13 to 2027-10-13, ongoing)

**Key Outputs/Deliverables:**

- Decision Log (running document, updated after each decision, includes rule name, voting tally, rationale, dissenting opinion summary)
- Quarterly published Decision Log summaries (Months 3, 6, 9, 12 = 2027-01-13, 2027-04-13, 2027-07-13, 2027-10-13)

**Dependencies:**

- Editorial Board meetings ongoing

### 52. Editorial Board resolves all unresolved rule disputes and tiebreaker escalations by Month 10 (2027-08-13), allowing a 1-month buffer for drafting and public comment before Month 11 (2027-09-13) finalization; any deadlocked disputes are escalated to the external Arbiter for binding recommendation within 2 weeks.

**Responsible Body/Role:** Editorial Board with external Arbiter if escalated

**Suggested Timeframe:** Month 10 (2027-08-13)

**Key Outputs/Deliverables:**

- Resolution of any outstanding rule disputes (tiebreaker decisions documented, arbiter recommendations if escalated)
- Confirmation that all core rules (ordinal, morphology, homograph, G2P, lexicon) are finalized

**Dependencies:**

- Linguistic Review Panel and subcommittee work completed

### 53. Editorial Board drafts the Clear English Standard v0.1 (draft) by Month 11 (2027-09-13), incorporating all finalized rules, lexicon, rationale and examples; publish the draft for a 30-day public-comment window (Months 11-12 = 2027-09-13 to 2027-10-13).

**Responsible Body/Role:** Editorial Board with Project Lead publication support

**Suggested Timeframe:** Month 11 (2027-09-13) (draft published by 2027-09-13 for 30-day window)

**Key Outputs/Deliverables:**

- Clear English Standard v0.1 draft document (30-50 pages, rule specifications, rationale, glossary examples, lexicon preview)
- Published on project website with instructions for submitting comments
- 30-day comment window open Months 11-12 (2027-09-13 to 2027-10-13)

**Dependencies:**

- All core-rule specifications finalized by Month 11 (2027-09-13)

### 54. Editorial Board manages the draft-standard 30-day public-comment window (Months 11-12 = 2027-09-13 to 2027-10-13): collect all substantive comments, triage by rule domain, draft responses addressing or acknowledging each comment, and prepare a summary of comments and responses for publication with v1.0.

**Responsible Body/Role:** Editorial Board with Project Lead administrative support

**Suggested Timeframe:** Months 11-12 (2027-09-13 to 2027-10-13)

**Key Outputs/Deliverables:**

- Public-comment submissions log (rule domain, commenter affiliation, summary of comment)
- Editorial Board responses to substantive comments (addressing concerns, clarifying rule intent, or documenting disagreement)
- Comment summary report (themes, key feedback, changes to v0.1 triggered by comments)

**Dependencies:**

- Draft standard published for public comment

### 55. Editorial Board incorporates substantive public feedback into rule clarifications (not reopening core rules) and publishes the final Clear English Standard v1.0 by Month 12 (2027-10-13), including the Decision Log (rule rationale), list of retained irregular forms, homograph-pair list, lexicon with pronunciation guidance, style guide covering ordinals/homographs/morphology, and published responses to public comments.

**Responsible Body/Role:** Editorial Board with Project Lead

**Suggested Timeframe:** Month 12 (2027-10-13) (by 2027-10-13)

**Key Outputs/Deliverables:**

- Clear English Standard v1.0 (final, 40-60 pages, all rules locked, Decision Log published, public-comment responses included)
- Accompanying style guide for ordinals, homograph markers, morphology and G2P application
- Reference dictionary entry list (5,000 words with pronunciations, mappings, examples)

**Dependencies:**

- 30-day public-comment window completed
- All rule disputes resolved

### 56. Project Lead determines and fixes the Licensing and Name Stewardship model by Month 6 (2027-04-13), choosing either a certification-mark approach (name restricted to conforming materials against a checklist) or a permissive share-alike license (permitting forks with divergence disclosure and distinct naming); publish the model by Month 12 (2027-10-13).

**Responsible Body/Role:** Project Lead with Compliance & Risk Management Committee (legal counsel) and Steering Committee input

**Suggested Timeframe:** Months 4-6 (2027-02-13 to 2027-04-13) (decision finalized by 2027-04-13)

**Key Outputs/Deliverables:**

- Licensing and Name Stewardship decision document (model chosen, rationale, conformance checklist if certification mark, license text if share-alike)
- Published by Month 12 (2027-10-13) with open licenses and/or certification-mark registration completed

**Dependencies:**

- Strategic decision on adoption strategy and third-party use anticipated

### 57. Project Lead and Compliance & Risk Management Committee develop a formal safety-critical pilot boundary and enforcement procedure by Month 4 (2027-02-13), specifying that safety-critical pilots are limited to glossary and labeling exercises, not live operational procedures, before Month 24 (2028-10-13) go/no-go decision; all materials carry explicit disclaimers and are reviewed by qualified human experts before use.

**Responsible Body/Role:** Compliance & Risk Management Committee (legal counsel, safety-critical partners) with Project Lead

**Suggested Timeframe:** Month 4 (2027-02-13) (by 2027-02-13)

**Key Outputs/Deliverables:**

- Safety-critical pilot scope document (glossary and labeling exercises defined, operational procedures explicitly excluded pre-Month-24)
- Disclaimer language for all materials (project does not guarantee safety of Clear English documents)
- Human-review procedure (qualified expert sign-off required before materials used in real settings)

**Dependencies:**

- Legal counsel engaged
- Safety-critical partners identified

### 58. Psychometrician conducts rater-training and inter-rater calibration study by Month 11 (2027-09-13), recruiting 3-5 raters to score a sample of ~100-200 ordinal and pronunciation items from both Clear English and standard-English conditions; target Cohen's kappa ≥0.75 (proposed) for each metric; document training protocol, scoring rubric, and any rater disagreements.

**Responsible Body/Role:** Psychometrician with Metrics & Validation Committee

**Suggested Timeframe:** Month 10-11 (2027-08-13 to 2027-09-13)

**Key Outputs/Deliverables:**

- Rater-training protocol document (training materials, scoringexamples, practice exercises)
- Inter-rater reliability study results (Cohen's kappa for ordinal error scoring, pronunciation consistency scoring, per-rater comparisons)
- Published scoring rubric (ordinal error criteria, pronunciation consistency criteria, boundary cases)
- Rater-training completion certificate or sign-off

**Dependencies:**

- Assessment instruments finalized
- Raters recruited and willing to attend training by Month 10 (2027-08-13)

### 59. Psychometrician and Project Lead conduct a dry-run of all assessment tools, data-collection procedures and audio-capture/storage workflows with a small pilot cohort (N=5-10 learners from one of the partner sites) by Month 10 (2027-08-13); test recording, storage, backup, data-labeling and analysis workflow; document findings and remediate any issues.

**Responsible Body/Role:** Psychometrician with Metrics & Validation Committee and one pilot partner

**Suggested Timeframe:** Month 10 (2027-08-13)

**Key Outputs/Deliverables:**

- Dry-run protocol (assessment schedule, learner recruitment, data-collection procedures)
- Dry-run findings report (audio quality assessment, data-storage/backup functionality, learner feedback on assessments, procedural timing)
- Remediation actions if issues found (e.g., audio-quality improvements, procedure clarifications)

**Dependencies:**

- Assessment instruments finalized
- Audio storage infrastructure in place and tested
- IRB approval (or interim clearance) to proceed with dry-run

### 60. Project Lead hires or designates an educator liaison (0.5-1.0 FTE, ~$50K-$70K/year estimate) by Month 6 (2027-04-13) to lead teacher engagement, training delivery, feedback loops and corrective outreach; educator liaison reports to Project Lead and Stakeholder Engagement Lead.

**Responsible Body/Role:** Project Lead with Finance Lead approval

**Suggested Timeframe:** Months 4-6 (2027-02-13 to 2027-04-13) (hire by 2027-04-13)

**Key Outputs/Deliverables:**

- Educator-liaison job description and offer letter
- Employment/contract signed
- Start date confirmed (by Month 6 = 2027-04-13)

**Dependencies:**

- Budget for educator-liaison role allocated

### 61. Compliance & Risk Management Committee develops a contingency plan for Phase 1 timeline extension (up to 4 weeks by Month 10 = 2027-08-13 if inter-rater reliability kappa <0.70 after initial training): cost ~$85K (estimate), approval by Steering Committee required; identify where the extension impacts Phase 2 start and pilot enrollment schedule.

**Responsible Body/Role:** Compliance & Risk Management Committee with Finance Lead and Steering Committee

**Suggested Timeframe:** Month 8 (2027-06-13)

**Key Outputs/Deliverables:**

- Phase 1 extension contingency plan (trigger: kappa <0.70 at Month 10 = 2027-08-13 check, remediation: 2-4 week rater retraining, cost ~$85K estimate, Steering Committee approval required)

**Dependencies:**

- Phase 1 budget and timeline understood
- Inter-rater calibration protocol established

### 62. Steering Committee reviews the pre-registered metrics, pre-analysis plan and go/no-go gate conditions at a scheduled checkpoint meeting (Month 11 = 2027-09-13); confirm that all four metrics have quantitative thresholds locked, sample size is n≥80 per arm, inter-rater reliability target is clear (kappa ≥0.75 target, 0.70 floor), and analysis plan is finalized and publicly registered.

**Responsible Body/Role:** Steering Committee with Psychometrician and Metrics & Validation Committee

**Suggested Timeframe:** Month 11 (2027-09-13)

**Key Outputs/Deliverables:**

- Steering Committee checkpoint-meeting minutes: pre-registration review, gate-condition checklist completed, Phase 2 green light confirmed

**Dependencies:**

- Pre-analysis plan registered by Month 11 (2027-09-13)
- Inter-rater training completed and documented
- Dry-run of tools completed without major issues

### 63. Project Lead and Steering Committee hold the Phase 1 exit meeting at Month 12 (2027-10-13) to confirm that all Phase 1 deliverables are complete and Phase 2 can begin: (1) Clear English Standard v1.0 published; (2) 5,000-word lexicon with audio recordings usable; (3) pre-analysis plan pre-registered; (4) inter-rater reliability ≥0.70 floor confirmed; (5) ethics/IRB approval in hand; (6) pilot partnership agreements signed; (7) assessment instruments finalized; (8) Critical Path Dashboard showing Phase 2 readiness.

**Responsible Body/Role:** Steering Committee with Project Lead

**Suggested Timeframe:** Month 12 (2027-10-13)

**Key Outputs/Deliverables:**

- Phase 1 exit meeting minutes: all gate conditions verified, Phase 2 formally authorized to proceed, Project Lead briefed on Phase 2 milestones

**Dependencies:**

- All Phase 1 deliverables substantially complete

### 64. Project Lead and Cohort Manager begin pilot recruitment at the partner sites, targeting enrollment of ≥115 learners per arm (4 arms total, ~460 learners estimate) with ≤30% target dropout, by Month 13 (2027-11-13); distribute learner-information packets, obtain informed consent, distribute incentives and certificates to encourage completion.

**Responsible Body/Role:** Cohort Manager with pilot partner sites

**Suggested Timeframe:** Months 13-14 (2027-11-13 to 2027-12-13, enrollment complete by Month 13 = 2027-11-13)

**Key Outputs/Deliverables:**

- Pilot enrollment summary (learners per site, per arm, demographic profile)
- Signed informed-consent forms (all learners)
- Participant incentive and certificate-distribution records

**Dependencies:**

- Pilot partnership agreements signed
- IRB approval finalized
- Cohort Manager in role

### 65. Metrics & Validation Committee conducts a mid-phase validity audit by an independent external auditor (Month 18-22 = 2028-04-13 to 2028-08-13), examining pilot data for: (1) inter-rater reliability (kappa trends, scorer drift); (2) construct validity (confound analysis, effect-size checks); (3) data integrity (missing files, outliers, consent violations); (4) compliance with pre-registered analysis plan. Report findings to Steering Committee by Month 23 (2028-09-13).

**Responsible Body/Role:** Metrics & Validation Committee with external independent auditor

**Suggested Timeframe:** Months 18-23 (2028-04-13 to 2028-09-13)

**Key Outputs/Deliverables:**

- Mid-phase validity audit report (inter-rater reliability findings, effect-size preliminary results, data-quality issues identified, remediation recommendations)

**Dependencies:**

- Pilot running for ≥6 months (Month 18 = 2028-04-13 check occurs mid-Phase 2)
- Preliminary data available for audit

### 66. Steering Committee holds a Phase 2 midpoint checkpoint meeting (Month 18 = 2028-04-13) to review pilot enrollment, retention, preliminary data quality, and any validity or operational issues; adjust Phase 2 timeline or scope if major problems identified; recommend any remediation (additional rater training, extended follow-up).

**Responsible Body/Role:** Steering Committee with Metrics & Validation Committee and Project Lead

**Suggested Timeframe:** Month 18 (2028-04-13)

**Key Outputs/Deliverables:**

- Phase 2 midpoint checkpoint-meeting minutes: enrollment status, retention rate, preliminary data quality, validity issues if any, recommended remediation

**Dependencies:**

- Pilot running, enrollment complete, ≥6 months of data available

### 67. Compliance & Risk Management Committee reviews the Risk Register quarterly (Months 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36 = 2027-01-13 onwards), assessing mitigation progress, emerging risks, and escalation status; generate a summary risk dashboard for Steering Committee review at each quarterly gate checkpoint.

**Responsible Body/Role:** Compliance & Risk Management Committee

**Suggested Timeframe:** Quarterly (Months 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36 = 2027-01-13 onwards)

**Key Outputs/Deliverables:**

- Quarterly Risk Register update (status of mitigation actions, newly identified risks, high-severity risks escalated)
- Risk dashboard summary (2-3 pages, risk-heatmap by domain, key escalations, overall risk posture)

**Dependencies:**

- Risk Register maintained monthly
- Quarterly checkpoint meetings scheduled with Steering Committee

### 68. Project Lead and Compliance & Risk Management Committee conduct a lexicon-coverage audit (Month 8 = 2027-06-13) of the 5,000-word core lexicon against pilot running-text materials and technical glossaries; confirm ≥85% coverage (proposed threshold) or identify gaps and prioritize expansion; if coverage <85%, allocate time and budget (~$30K-$50K estimate) for targeted lexicon expansion by Month 10 (2027-08-13).

**Responsible Body/Role:** Project Lead with Editorial Board (lexicon subcommittee)

**Suggested Timeframe:** Month 8 (2027-06-13)

**Key Outputs/Deliverables:**

- Lexicon coverage audit report (% of running text in pilot materials and ESL curricula, gap analysis by domain)
- If coverage <85%: targeted expansion plan (words added, pronunciation recorded, timeline to Month 10 = 2027-08-13)

**Dependencies:**

- 5,000-word lexicon substantially finalized
- Pilot materials identified

### 69. Compliance & Risk Management Committee identifies 2-3 potential permanent steward organizations (language-education non-profits, university consortiums, international standards bodies) and approaches them by Month 27 (2029-01-13) with a stewardship proposal (estimated $150K-$250K per year for ongoing maintenance and governance); secure written commitment by Month 33 (2029-07-13) before v1.0 public release.

**Responsible Body/Role:** Compliance & Risk Management Committee (Chair or Stakeholder Engagement Lead) with Project Lead

**Suggested Timeframe:** Months 24-33 (2028-10-13 to 2029-07-13)

**Key Outputs/Deliverables:**

- Steward-organization identification and outreach (proposal letter, governance model, funding needs)
- Stewardship commitment letters from at least one organization by Month 33 (2029-07-13)

**Dependencies:**

- Phase 2 go/no-go decision completed (Month 24 = 2028-10-13)
- Stewardship funding model defined and budgeted

### 70. Steering Committee holds the Phase 2 go/no-go decision meeting (Month 24 = 2028-10-13): review final pilot data, validity-audit findings, all four gate metrics against pre-registered thresholds, and statistical significance; determine GO (all thresholds met, data valid, n≥80 completers per arm, kappa ≥0.70, follow-up ≥70% complete) or NO-GO (any metric fails threshold or data invalid); document decision rationale and next steps for Phase 3.

**Responsible Body/Role:** Steering Committee with Psychometrician, Metrics & Validation Committee, and Editorial Board (for rule implications)

**Suggested Timeframe:** Month 24 (2028-10-13)

**Key Outputs/Deliverables:**

- Go/no-go decision meeting minutes: metric results tabulated, threshold comparisons, validity-audit recommendations reviewed, final decision recorded with rationale
- If GO: Phase 3 authorization approved, v1.0 release timeline and stewardship-funding readiness confirmed
- If NO-GO: documented reasons, options for extension/rework, or project closeout decision

**Dependencies:**

- All pilot data collected and analyzed (data lock by Month 22 = 2028-08-13)
- Validity audit completed (Month 23 = 2028-09-13)
- Pre-analysis plan adhered to

### 71. If Phase 2 go/no-go is GO (Month 24 = 2028-10-13), Steering Committee authorizes Phase 3 (v1.0 public release and limited adoption) and confirms stewardship-funding commitment is in place before v1.0 release (Month 30 = 2029-04-13); Project Lead begins Phase 3 planning (curriculum finalization, publisher outreach, marketing materials).

**Responsible Body/Role:** Steering Committee with Project Lead

**Suggested Timeframe:** Month 24 (2028-10-13) onwards

**Key Outputs/Deliverables:**

- Phase 3 authorization memo (stewardship commitment confirmed, release timeline locked, governance transition plan to steward organization begun)

**Dependencies:**

- Phase 2 go/no-go = GO

### 72. If Phase 2 go/no-go is NO-GO (Month 24 = 2028-10-13), Steering Committee documents the reasons, considers options for a limited Phase 2 extension (3-6 months, ~$300K-$600K estimate, not budgeted pre-gate), rework of identified rule weaknesses, or project closeout; all Phase 3 funds ($0.85M) and remaining reserve (~$175K or more, depending on pre-gate draws) are held or returned to Funding Authority.

**Responsible Body/Role:** Steering Committee with Project Sponsor and Funding Authority

**Suggested Timeframe:** Month 24 (2028-10-13) onwards

**Key Outputs/Deliverables:**

- No-go decision memo: reasons for gate failure, options analysis (extension vs. closeout), recommendation to Funding Authority

**Dependencies:**

- Phase 2 go/no-go = NO-GO

### 73. Project Lead and Compliance & Risk Management Committee establish a Standards Stewardship Committee (separate from the Phase 1-3 Editorial Board) with 3-5 members (representing steward organization, Editorial Board, and key adopters), formal decision authority, published charter and meeting schedule by Month 30 (2029-04-13), to govern the standard post-Phase-3.

**Responsible Body/Role:** Project Lead with Steward Organization (if Phase 2 GO)

**Suggested Timeframe:** Months 30-36 (2029-04-13 to 2029-10-13)

**Key Outputs/Deliverables:**

- Standards Stewardship Committee Charter (governance, decision authority, annual review process, change-request procedures)
- Stewardship Committee membership confirmed
- Published 5-year stewardship roadmap (how standard will be updated, change-request prioritization, conflict-resolution procedures)

**Dependencies:**

- Phase 2 go/no-go = GO
- Stewardship-organization commitment letters received

### 74. Project Lead publishes the final Clear English Standard v1.0, reference dictionary, style guide and associated licensing/conformance documentation (if certification mark model chosen) by Month 30 (2029-04-13), conditional on a written steward-organization commitment; begin limited-scope Phase 3 adoption (Months 30-36 = 2029-04-13 to 2029-10-13).

**Responsible Body/Role:** Project Lead with Editorial Board and Steward Organization

**Suggested Timeframe:** Month 30 (2029-04-13)

**Key Outputs/Deliverables:**

- Clear English Standard v1.0 (final published version, with pilot validation evidence and go/no-go gate decision documented)
- Reference dictionary (5,000 entries, pronunciations, mappings to standard English, examples)
- Style guide (application of ordinals, homograph markers, morphology rules, G2P guidance)
- Open licenses and/or certification-mark documentation
- Published go/no-go gate report (metrics achieved, evidence summary, implications for adoption)

**Dependencies:**

- Phase 2 go/no-go = GO
- Stewardship-organization commitment and funding in place

# Decision Escalation Matrix

**Budget Overrun Exceeding Pre-Gate Contingency Cap**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of spending variance (>$50K threshold) with Finance Lead presentation; if draw requested exceeds $175K pre-gate cap, escalation to Project Sponsor and Funding Authority for approval of scope reduction, Phase 2 extension costs, or project termination decision.
Rationale: The fixed $3.5M budget with only $175K pre-gate contingency (5% of total) is the binding constraint. A $300K overrun (8.6% of budget estimate) would exhaust the pre-gate reserve and force cuts to pilot scope, assessment quality, or curriculum development. This directly threatens gate credibility and adoption feasibility.
Negative Consequences: Budget overrun >$175K pre-gate forces either pilot scope cuts (fewer cohorts, smaller assessment battery) that weaken go/no-go evidence, curriculum quality reduction that undermines adoption appeal, or Project Sponsor intervention to extend Phase 1 or Phase 2 at cost to Phase 3 outreach. Uncontrolled spending could strand Phase 3 ($850K) if reserve is depleted mid-pilot.

**Inter-Rater Reliability Below Measurement Floor After Calibration**
Escalation Level: Steering Committee and Metrics & Validation Committee (joint escalation)
Approval Process: Metrics & Validation Committee flags kappa <0.70 to Steering Committee within 48 hours; Steering Committee reviews remediation plan (extended rater training, Phase 1 extension by up to 4 weeks at ~$85K estimate) and votes to approve extension or to proceed to Phase 2 with acknowledged measurement degradation. If measurement remains <0.70 by Month 11 (2027-09-13), gate decision is at risk and Steering Committee recommends formal extension or scope reduction.
Rationale: Pronunciation consistency and ordinal-error scoring depend on inter-rater reliability (kappa ≥0.75 target, ≥0.70 floor proposed). Scoring below the floor inflates measurement error by 20%+ and reduces statistical power to detect Clear English effects by 10–15%, risking false-negative gate outcome and stranding $1.2M–$1.4M in Phase 2–3 spending.
Negative Consequences: Kappa below 0.70 invalidates the pronunciation-consistency metric; gate decision becomes scientifically disputable, potentially triggering partner and standards-body loss of confidence. A false-negative outcome kills a viable standard. A false-positive launches weak standard, damaging credibility by Month 48–60 (2030-10-13 to 2031-10-13) and reducing Phase 3 adoption by 30–50%.

**Editorial Board Deadlock or Ambiguous Rules Unresolved by Month 10 (2027-08-13)**
Escalation Level: External Arbiter (appointed by Month 5 = 2027-03-13), with final escalation to Project Sponsor if arbiter recommendation is rejected
Approval Process: Editorial Board attempts consensus or majority vote by Month 10 (2027-08-13); if deadlocked rule dispute persists, matter escalates to external Arbiter (neutral linguist or standards-design specialist, $10K–$20K cost estimate) for binding recommendation within 2 weeks. If Arbiter's recommendation is rejected by both Steering Committee and Editorial Board, matter escalates to Project Sponsor for final decision by Month 11 (2027-09-13).
Rationale: Rules must be finalized by Month 12 (2027-10-13) to allow a 30-day public comment window before v1.0 lock at Phase 2 start. Unresolved disputes (ordinal pronunciation, morphology retention threshold, homograph marker policy) prevent rule publication and delay pilots. Mid-pilot rule changes invalidate earlier assessments and confound results.
Negative Consequences: A 4-week board deadlock compresses Phase 2 pilots from 12 to 8–10 months (33–50% reduction in pilot window), weakening statistical power and data quality. Ambiguous rules during pilots cause 10–20% rule misapplication (estimate), confounding results and rendering gate metrics inconclusive. Forced, unclear rules damage educator and publisher confidence in the standard pre-launch.

**Pilot Recruitment or Retention Falls Below Minimum Sample Size**
Escalation Level: Project Steering Committee with Compliance & Risk Management Committee
Approval Process: Cohort Manager and Compliance & Risk Management Committee flag enrolment shortfall (<80 completers per arm estimate or dropout >30%) to Steering Committee; Steering Committee reviews retention-incentive options (increased stipends, additional contact hours, partner re-engagement), pilot schedule extension (adding 4–8 weeks to Phase 2, estimated cost $85K–$170K), or scope reduction (reducing to 2 arms or smaller sample). If shortfall cannot be remedied, Steering Committee escalates to Project Sponsor for decision on extension cost or gate delay.
Rationale: The go/no-go gate requires ≥80 completers per arm (4 arms × 80 = 320 completers) to achieve 80% statistical power at α=0.05 (proposed). Enrollment <50 per arm or dropout >30% undermines all four gate metrics (ordinal error rate, comprehension speed, pronunciation consistency, 30-day retention) and renders the Month 24 (2028-10-13) decision scientifically indefensible.
Negative Consequences: Insufficient sample size makes gate metrics statistically unreliable; forced gate decision becomes disputable and risks either false-positive (weak standard launched, credibility damaged) or false-negative (viable standard rejected, $1.2M–$1.4M Phase 2–3 spending wasted). High dropout reduces effective n by 15–30%, compounding power loss. Phase 2 extension by 3–6 months ($300K–$600K estimate, unbudgeted) could strain remaining contingency and delay Phase 3 release to Month 36–42 (2029-10-13 to 2030-04-13).

**Safety-Critical Incident or Material Liability Claim Linked to Clear English**
Escalation Level: Compliance & Risk Management Committee (immediate within 48 hours) to legal counsel, Steering Committee, and relevant safety regulators (OSHA, HSE, workplace safety authority)
Approval Process: Incident-reporting protocol triggered: Compliance & Risk Management Committee notifies legal counsel, Project Sponsor, Steering Committee and affected pilot organization within 48 hours. Legal counsel advises on regulatory notification, disclosure obligations and potential liability exposure. Formal incident investigation conducted within 2 weeks; findings and remediation plan reviewed by Steering Committee. If incident is serious (injury, near-miss in safety-critical context), Project Sponsor and Funding Authority make final decision on pilot suspension, materials withdrawal, or project continuation.
Rationale: Safety-critical pilots (glossary and labeling exercises, no live operational procedures until Month 24 = 2028-10-13) are bounded by legal disclaimers and human expert review. However, any documented injury, near-miss or serious misreading linked to Clear English documentation triggers liability exposure, regulatory investigation and potential mandate for project pause. Insurance, legal review and risk-approval processes may be costly ($150K–$200K estimate) and slow.
Negative Consequences: A serious incident (injury linked to Clear English documentation) could result in litigation, regulatory action (OSHA, EPA, or equivalent investigation), mandatory product recall or withdrawal of the standard, and immediate pause or termination of the initiative. Media scrutiny and credibility loss would follow, reducing Phase 3 adoption to near-zero even if gate is positive. Incident response costs ($100K–$500K estimate) could exceed remaining budget and force Phase 3 cancellation.

**Educator Pushback or Standards-Body Regulatory Rejection Blocking Pilot Access or Third-Party Adoption**
Escalation Level: Project Steering Committee and Stakeholder Engagement Lead, with escalation to Project Sponsor if adoption risk exceeds tolerance
Approval Process: Stakeholder Engagement Lead monitors educator and standards-body sentiment (TESOL, IATEFL, national education authorities) and flags critical feedback or rejection signals to Steering Committee within 48 hours if sentiment shifts >20% toward rejection or if a major partner withdraws support. Steering Committee reviews corrective outreach plan (revised messaging, educator training, licensing clarity, partner re-engagement). If regulatory approval is delayed >4 weeks or pilot enrollment declines >20% due to pushback, matter escalates to Project Sponsor for decision on messaging adjustment, timeline extension, or scope reduction.
Rationale: Educator and standards-body adoption is essential to pilot recruitment and Phase 3 success. High-likelihood risk: educators may perceive Clear English as a threat to standard English instruction or a non-standard variant imposed from outside. Standards bodies may demand formal approval or alignment with existing curricula. Unmanaged pushback reduces pilot enrollment by 20–50% (estimate) and delays institutional partnerships, compressing Phase 2 timeline and weakening gate credibility.
Negative Consequences: Low educator engagement could reduce pilot quality and statistical power, making gate metrics inconclusive or disputable. Public criticism from TESOL, IATEFL or national education authorities could trigger negative media coverage, damaging credibility before go/no-go decision. Regulatory approval delays of 4–8 months (estimate) push pilot timeline into Month 28–32 (2029-02-13 to 2029-06-13), jeopardizing the Month 24 (2028-10-13) gate. Even if gate is positive, educator resistance could reduce Phase 3 adoption by 30–50%, capping learner reach at 15,000–35,000 instead of 100,000+.

# Monitoring Progress

### 1. Gate Metrics Credibility and Pre-Registration Tracking
**Monitoring Tools/Platforms:**

  - Pre-Analysis Plan Repository (OSF)
  - Metrics & Validation Committee Monthly Report Template
  - Inter-Rater Reliability Tracking Spreadsheet
  - Validity Study Results Dashboard

**Frequency:** Bi-weekly Metrics & Validation Committee meetings (Months 2-24 = 2026-12-13 to 2028-10-13); monthly reporting to Steering Committee; validity audit mid-phase (Months 18-23 = 2028-04-13 to 2028-09-13)

**Responsible Role:** Metrics & Validation Committee (Chair: Psychometrician, with external measurement specialist oversight)

**Adaptation Process:** The Psychometrician and Committee detect measurement validity threats (inter-rater kappa drift below 0.70, effect-size anomalies, confound signals, data integrity issues) via ongoing analysis and the independent mid-phase validity audit. Threats escalate immediately to the Steering Committee with remediation options (rater retraining, extended calibration, supplementary analysis, Phase 1 extension by up to 4 weeks estimated at ~$85K cost). If kappa falls below 0.70 at the Month 10 (2027-08-13) checkpoint and retraining during Month 10-11 (2027-08-13 to 2027-09-13) does not restore it to ≥0.70, Phase 1 is extended by 4 weeks with Steering Committee approval.

**Adaptation Trigger:** Inter-rater reliability (Cohen's kappa) <0.70 for more than 2 weeks; effect sizes falling outside expected range (confound signal); missing pilot data >15% by Month 21 (2028-07-13); validity audit findings (Month 23 = 2028-09-13) that challenge construct validity or reveal data-integrity violations; any deviation from the pre-registered analysis plan discovered during Phase 2 execution.

### 2. Editorial Board Rule Finalization and Decision Logging
**Monitoring Tools/Platforms:**

  - Editorial Board Decision Log (version-controlled document)
  - Rule Specification Workstream Status Tracker
  - Linguistic Review Panel Monthly Findings Report
  - Dispute Escalation and Arbiter Recommendation Log

**Frequency:** Monthly Editorial Board meetings (second Thursday, 2 hours) and biweekly rule-workstream subcommittee meetings (ordinal, morphology, homograph, lexicon, pronunciation-guidance) Months 2-10 (2026-12-13 to 2027-08-13); Linguistic Review Panel monthly vetting (Months 5-11 = 2027-03-13 to 2027-09-13); quarterly published Decision Log summaries (Months 3, 6, 9, 12 = 2027-01-13, 2027-04-13, 2027-07-13, 2027-10-13)

**Responsible Role:** Editorial Board Chair (internal, practitioner or linguist with governance experience, 0.5 FTE) with Linguistic Review Panel (2-3 board linguists, monthly 90-minute meetings) and external Arbiter (appointed by Month 5 = 2027-03-13 for tie-breaking if consensus fails)

**Adaptation Process:** The Editorial Board drafts rule specifications through assigned subcommittees (ordinal marker pronunciation, morphology retention threshold, homograph-pair list, lexicon selection, G2P logic), meeting biweekly through Month 10 (2027-08-13). The Linguistic Review Panel reviews each proposed rule monthly for internal contradiction, ambiguity, or lack of publishable justification; any veto findings are escalated to the full board for resolution. If a rule dispute remains unresolved after board vote and linguist veto, the matter is escalated to the external Arbiter for a binding recommendation within 2 weeks. All decisions are logged within 3 business days with rationale documented. If disputes persist beyond Month 10 (2027-08-13), the escalation to Arbiter triggers immediately; if the Arbiter's recommendation is rejected by both the Steering Committee and Editorial Board, the matter escalates to the Project Sponsor for final decision.

**Adaptation Trigger:** Any rule remaining ambiguous or internally contradictory at the end of a subcommittee meeting; a Linguistic Review Panel veto on a proposed rule; a board vote that deadlocks (tie) or fails to reach simple majority; a rule-specification workstream milestone missed by >2 weeks; any rule conflict that cannot be resolved by consensus by Month 10 (2027-08-13); Arbiter recommendation issued but rejected by Steering Committee or Editorial Board.

### 3. Pilot Recruitment, Enrollment and Retention Tracking
**Monitoring Tools/Platforms:**

  - Cohort Enrollment and Demographics Tracker (spreadsheet)
  - Pilot Partner Monthly Status Report Template
  - Participant Dropout and Attrition Log
  - 30-Day Follow-Up Completion Dashboard

**Frequency:** Weekly enrollment updates from Cohort Manager (Months 13-14 = 2027-11-13 to 2027-12-13); monthly partner status reports and retention metrics (Months 15-24 = 2028-01-13 to 2028-10-13); 30-day follow-up tracking from Month 18 (2028-04-13) onwards; mid-phase checkpoint review (Month 18 = 2028-04-13) with Steering Committee

**Responsible Role:** Cohort Manager (1.0 FTE, hired by Month 6 = 2027-04-13, reports to Project Lead) with Stakeholder Engagement Lead oversight and partner-site liaisons

**Adaptation Process:** The Cohort Manager monitors enrollment weekly against the target of ≥115 per arm (4 arms, 460 total estimate); flags shortfalls to the Project Lead within 48 hours if enrollment lags >2 weeks behind schedule. Dropout and retention are tracked at each assessment point; if attrition exceeds 30% target by Month 18 (2028-04-13) midpoint, the Project Lead and Compliance & Risk Management Committee review retention-incentive options (increased stipends, additional session scheduling flexibility, partner re-engagement) and recommend either intensified outreach or Phase 2 extension (estimated ~$85K-$300K depending on scope, proposed). The Steering Committee reviews enrollment status at quarterly checkpoints (Months 18, 24 = 2028-04-13, 2028-10-13); if effective sample size at Month 22 (2028-08-13, data lock) falls below 80 completers per arm, the Committee escalates to Project Sponsor and decides whether to extend Phase 2 (3-6 months, estimated cost $300K-$600K unbudgeted) or proceed to a disputed go/no-go decision.

**Adaptation Trigger:** Enrollment cumulative shortfall >15% of target by end of Week 8 (Month 13.5 = 2027-11-28, estimate); dropout >30% at any checkpoint; 30-day follow-up completion <70% by Month 23 (2028-09-13); any pilot partner withdraws participation or reduces committed enrollment; effective completers <80 per arm by data lock (Month 22 = 2028-08-13); retention patterns diverge significantly between pilot sites or conditions (suggesting confound or delivery failure).

### 4. Critical Success Factor: Rule Specification Completeness and Clarity
**Monitoring Tools/Platforms:**

  - Rule Finalization Checklist (ordinal, morphology, homograph, lexicon, G2P, pronunciation-guidance specifications)
  - Draft Standard v0.1 Quality Audit Checklist
  - Public Comment and Response Log (Month 11-12 = 2027-09-13 to 2027-10-13)
  - Final Clear English Standard v1.0 Completeness Verification Document

**Frequency:** Monthly rule-workstream progress reviews (Months 2-10 = 2026-12-13 to 2027-08-13); draft-standard preparation and publication (Month 11 = 2027-09-13); public-comment collection and response (Month 11-12 = 2027-09-13 to 2027-10-13); rules-lock verification (Month 12 = 2027-10-13); pre-Phase-2 gate checkpoint (Month 12 = 2027-10-13)

**Responsible Role:** Editorial Board Chair with Project Lead and Compliance & Risk Management Committee support for publication and public-engagement logistics

**Adaptation Process:** The Editorial Board monitors rule-specification completeness through monthly subcommittee reports: ordinal marker pronunciation (fixed form, spoken reading, legacy-form conversion rules), morphology retention threshold (frequency cutoff, retained list, regularized list with justification), homograph-disambiguation policy (published pair list ≤50 estimate, marker vs. rewrite decision per pair, enforcement in safety-critical docs), core-lexicon specification (5,000 words, selection basis documented, coverage audit ≥85% estimate), and G2P guidance (overlay logic, optional application). Any missing specification or unresolved detail is flagged in monthly Board minutes and assigned to a subcommittee for completion by Month 10 (2027-08-13). The draft standard v0.1 is published Month 11 (2027-09-13) with all core specifications; public comments are collected and responded to within 14 days; substantive comments that clarify rule intent (but do not reopen core rules) are incorporated into v1.0. If substantive public comments challenge rule validity (e.g., a comment that the ordinal marker is ambiguous or the morphology threshold is unjustifiably high), the Editorial Board escalates the comment to the external Arbiter for recommendation on whether rule revision is warranted before v1.0 finalization; if the Arbiter recommends revision, the rule is clarified or refined by Month 12 (2027-10-13).

**Adaptation Trigger:** Any rule specification incomplete or marked 'TBD' at the end of Month 9 (2027-07-13); Editorial Board unable to reach consensus on a core rule by Month 10 (2027-08-13); draft standard v0.1 missing a major specification (e.g., no ordinal-marker spoken-reading guidance, no morphology-retention list, no homograph-pair list); public-comment window generates substantive challenges to rule logic or clarity that the Editorial Board cannot resolve without revision; Arbiter recommendation issued indicating rule ambiguity that requires pre-v1.0 fix.

### 5. Critical Success Factor: Pilot Partner Commitment and Institutional Support
**Monitoring Tools/Platforms:**

  - Pilot Partnership Agreement Register (signed commitments, per-partner)
  - Partner Capacity and Engagement Tracker (monthly contact logs, meeting attendance, materials review)
  - Educator and Standards-Body Advisory Panel Meeting Notes
  - Publisher Letter-of-Interest Log (non-binding commitments)

**Frequency:** Monthly check-in calls with each of the 5-7 pilot partners (ESL programs and technical/safety-training organizations); quarterly advisory panel meetings with educators, regulators and publishers (Months 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36 = 2027-01-13 onwards); mid-phase stakeholder-alignment review (Month 18 = 2028-04-13); monthly engagement-metric reports to Steering Committee

**Responsible Role:** Stakeholder Engagement Lead (internal, 0.5 FTE) with Project Lead oversight and Compliance & Risk Management Committee escalation support

**Adaptation Process:** The Stakeholder Engagement Lead maintains signed partnership agreements with ≥3 adult ESL programs and ≥2 technical/safety-training organizations by Month 3 (2027-01-13), documenting enrollment guarantees, payment terms, educator-training participation, and feedback schedules. Monthly contact logs track partner engagement (meeting attendance, readiness for material delivery, instructor preparation); any partner showing signs of disengagement (missed meetings, enrollment delays, budget constraints) is flagged to the Project Lead within 48 hours for re-engagement outreach. Quarterly advisory panels (educators, regulators, publishers) surface emerging adoption barriers or standards-body concerns; if a panel signals potential rejection or major pushback (e.g., 'Clear English is a threat to standard English instruction'), the Project Lead and Stakeholder Engagement Lead convene an emergency response meeting and recommend corrective messaging or protocol adjustments to the Steering Committee. If a pilot partner withdraws or reduces commitment to <80 committed learners, the Project Lead immediately flags the shortfall and activates a backup partner or expanded recruitment at an existing site.

**Adaptation Trigger:** A pilot partner misses two consecutive monthly check-ins without explanation; a partner withdraws or reduces enrollment commitment by >20%; educator or standards-body advisory panel reports >20% increase in critical sentiment or adoption concerns; a major ESL publisher or standards body (TESOL, IATEFL, national education authority) signals that Clear English is not aligned with their curricula or standards and declines partnership; educator pushback signals in social media, professional forums or direct feedback reach a threshold of >10% of outreach audience expressing concern or rejection.

### 6. Risk Management: Budget, Timeline and Contingency Tracking
**Monitoring Tools/Platforms:**

  - Monthly Spend Report (by Phase, budget line, actual vs. budget variance)
  - Critical Path Dashboard (milestones, resource allocation, variance alerts >2 weeks)
  - Contingency Reserve Balance Tracker
  - Risk Register (quarterly updates, Months 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36 = 2027-01-13 onwards)

**Frequency:** Monthly financial tracking (cumulative spend, 6-month forecast) and critical-path review; spending-review gate (Month 9 = 2027-07-13) and mid-phase check (Month 18 = 2028-04-13); formal Phase-1 exit review (Month 12 = 2027-10-13); quarterly risk reviews with Steering Committee (Months 3, 6, 9, 12, 15, 18, 21, 24 = 2027-01-13 onwards)

**Responsible Role:** Finance Lead (0.5-1.0 FTE internal budget controller) with Compliance & Risk Management Committee (Chair) and Project Lead

**Adaptation Process:** The Finance Lead tracks cumulative monthly spend against Phase allocations ($1.1M Phase 1, $1.2M Phase 2, $0.85M Phase 3) and provides a variance report flagging any line item >10% over or under budget and cumulative Phase variance >$50K. The Critical Path Dashboard is reviewed monthly for slippage >2 weeks on key milestones (rules finalization Month 12 = 2027-10-13, audio completion Month 11 = 2027-09-13, pre-registration Month 11 = 2027-09-13, recruitment/enrollment Month 13 = 2027-11-13, data lock Month 22 = 2028-08-13); any slip triggers immediate escalation to the Steering Committee with impact assessment (does it compress Phase 2 pilot window, risk kappa validation, or push go/no-go decision past Month 24 = 2028-10-13?). The Contingency Reserve Balance ($350K total, capped at $175K draws pre-gate for evidence-protection needs) is tracked monthly; the Finance Lead and Compliance & Risk Management Committee recommend draws for Phase-1 extension (≤$85K estimated) or psychometric re-validation (≤$50K estimated) if gate-protection risks emerge; all draws >$50K require Steering Committee approval. The Compliance & Risk Management Committee reviews the Risk Register quarterly and escalates any High×High risk (e.g., >$50K overrun, pilot recruitment collapse, inter-rater reliability failure, educator pushback >20%, safety incident) to the Steering Committee within 5 business days with mitigation recommendation.

**Adaptation Trigger:** Any single line-item spend variance >$50K or Phase cumulative variance >$50K; critical-path milestone slip >2 weeks; cumulative spend forecast indicating total project cost will exceed $3.5M by >$125K at any checkpoint; contingency reserve balance falls below $175K pre-gate threshold; identified High×High risk from Risk Register requiring immediate mitigation (e.g., safety incident, data breach, major partner withdrawal); budget variance discovered that cannot be resolved within existing Phase allocations, requiring scope cuts or timeline extension.

### 7. Risk Management: Safety-Critical Liability and Compliance
**Monitoring Tools/Platforms:**

  - Safety-Critical Pilot Boundary Log (materials type, human-review sign-off)
  - Legal Counsel Regulatory Advice Log
  - Data-Protection Audit Reports (Months 6, 8 = 2027-04-13, 2027-06-13)
  - Ethics/IRB Approval Status and Incident-Reporting Log
  - Disclaimer and Consent-Form Attestation Tracker

**Frequency:** Monthly review of safety-critical materials and human-expert sign-offs (if any safety pilots are conducted); quarterly legal and compliance check-ins with retained counsel; ethics/IRB communication as needed (ongoing after Month 6 = 2027-04-13 approval); data-protection audit (Month 8 = 2027-06-13) and privacy-policy publication (Month 12 = 2027-10-13); immediate incident-reporting and escalation (within 48 hours if incident occurs)

**Responsible Role:** Compliance & Risk Management Committee (Chair, risk-management specialist, 0.5 FTE), with external legal counsel (product liability and regulatory compliance specialist, ~4 hours/month retainer), ethics/IRB liaison (internal or external, ~3-4 hours/month), and Data Integrity Officer (internal, ~2 hours/month)

**Adaptation Process:** The Compliance & Risk Management Committee establishes clear boundaries for safety-critical pilots: glossary and labeling exercises only (no live operational procedures) until after Month 24 (2028-10-13) go/no-go decision; all materials carry explicit disclaimers ('Clear English is a non-standard variant; use with qualified expert human review') and require sign-off by a qualified human expert (trainer, safety officer) before deployment. Legal counsel advises on regulatory pathways, insurance coverage options ($150K-$200K estimated budget cap), and product liability risk. The Committee ensures ethics/IRB approval is obtained by Month 6 (2027-04-13), covering informed consent, audio-recording protocols, data-protection measures and participant opt-out procedures. A data-protection audit (Month 8 = 2027-06-13) verifies GDPR compliance (UK, if applicable), US state privacy law compliance, encrypted storage setup, backup procedures, and data-retention schedules; any gaps identified are remediated by Month 12 (2027-10-13) with documented attestation. If a safety incident, data breach or ethics violation occurs, the Committee triggers an immediate incident-reporting protocol (within 48 hours): notification to legal counsel, Project Sponsor, Steering Committee, affected pilot organization, and (if required) regulatory authorities; formal investigation within 2 weeks; remediation plan reviewed by Steering Committee; decision on whether to suspend pilots, withdraw materials, or modify protocols.

**Adaptation Trigger:** Documented safety incident or near-miss in any safety-critical pilot material linking Clear English wording to misunderstanding, wrong action, or injury; data-protection audit finding a gap in encryption, access control, consent documentation or backup procedures; ethics/IRB approval delayed by >2 weeks or conditional on substantive protocol revisions; legal counsel assessment that liability insurance or regulatory approval cost will exceed $200K (estimated cap); incident report from a pilot site or external source alleging that Clear English documentation caused confusion, incorrect action or safety concern; participant complaint regarding data privacy, recording use or consent procedures.

### 8. Risk Management: Educator Pushback and Adoption Resistance
**Monitoring Tools/Platforms:**

  - Stakeholder Sentiment and Engagement Tracker (quarterly advisory panel feedback)
  - Educator and Standards-Body Pushback Alert Log
  - Corrective Outreach and Messaging Log
  - Stakeholder Alignment Charter and Mid-Phase Review Document

**Frequency:** Monthly tracking of educator and publisher engagement metrics (open rates on outreach, meeting attendance, sentiment); quarterly advisory panel meetings (Months 3, 6, 9, 12, 15, 18, 21, 24 = 2027-01-13 onwards); real-time monitoring of social media, professional forums (TESOL, IATEFL) and direct feedback for critical signals; mid-phase stakeholder-alignment check-in (Month 18 = 2028-04-13)

**Responsible Role:** Stakeholder Engagement Lead (internal, 0.5 FTE) with Educator Liaison (0.5-1.0 FTE, hired by Month 6 = 2027-04-13) and Compliance & Risk Management Committee escalation support

**Adaptation Process:** The Stakeholder Engagement Lead maintains engagement metrics (email open rates, advisory-panel attendance, meeting frequency) and flags declining engagement or critical feedback within 48 hours. Advisory panels (educators, standards bodies, publishers) meet quarterly and provide structured feedback on adoption concerns, messaging clarity and perceived barriers. If educator sentiment shifts negatively (e.g., >20% of panel respondents report concern that Clear English is a threat to standard English instruction) or if a major professional organization (TESOL, IATEFL, national education authority) signals rejection or demands for changes, the Project Lead and Stakeholder Engagement Lead convene an emergency response meeting. Corrective actions may include: revised messaging emphasizing that Clear English is supplementary and optional (not a replacement); expanded educator training and stipends to increase buy-in; modification of pilot protocols to better integrate into existing courses; or escalation to the Steering Committee if institutional approval is jeopardized.

**Adaptation Trigger:** Any TESOL, IATEFL or major national education-authority public statement indicating concern or rejection of Clear English; educator advisory panel reports >20% increase in critical sentiment about adoption barriers or rule comprehensibility; social media or professional-forum activity critical of Clear English reaches >50 mentions in a month or >10 from respected educators; a pilot partner signals that educator concerns are blocking enrollment or participation commitment; an ESL publisher or major adopter candidate explicitly declines participation citing educator resistance or institutional non-alignment.

### 9. Critical Success Factor: Pronunciation Consistency Measurement and Reference Accent Anchoring
**Monitoring Tools/Platforms:**

  - Reference Accent Selection and Justification Document
  - Inter-Rater Reliability Tracking and Rater Training Protocol
  - Pronunciation Audio Storage and Backup Audit Log
  - Pronunciation Consistency Score Preliminary Results (Months 18-24 = 2028-04-13 to 2028-10-13)

**Frequency:** Accent-selection decision and documentation (Month 3 = 2027-01-13); rater-training completion and inter-rater calibration (Months 10-11 = 2027-08-13 to 2027-09-13); monthly audio storage and backup verification (Months 6-24 = 2027-04-13 to 2028-10-13); pronunciation-score reporting and inter-rater reliability checks (Months 15-24 = 2028-01-13 to 2028-10-13, weekly during active pilot scoring)

**Responsible Role:** Psychometrician (hired by Month 2 = 2026-12-13, 0.5-1.0 FTE) with Metrics & Validation Committee oversight and external measurement specialist consultation; Data Integrity Officer (internal, ~2 hours/month) for audio storage and backup verification

**Adaptation Process:** By Month 3 (2027-01-13), the Psychometrician and Editorial Board (linguist members) select a single reference accent (e.g., General American, Received Pronunciation, or shared-contrast phonemes across accents) with explicit written justification and documentation of how other accents map to the anchor. Rater training and inter-rater calibration occur in Months 10-11 (2027-08-13 to 2027-09-13): 3-5 raters are trained on pronunciation-consistency scoring rubric using 100-200 sample words from both Clear English and control conditions; Cohen's kappa is computed per rater pair, targeting ≥0.75 (proposed threshold) with a floor of 0.70. If initial kappa falls below 0.70, raters receive targeted retraining and a second calibration round within 2 weeks; if kappa remains <0.70 after retraining, the Phase 1 extension contingency ($85K estimated) is triggered to allow additional rater training by Month 12 (2027-10-13). Audio storage is verified monthly for encryption, access controls, backup functionality and completeness (no missing recordings >1% estimated); a dry-run with a small cohort (N=5-10) occurs at Month 10 (2027-08-13) to test recording quality, file organization and rater workflow. During Phase 2 pilots (Months 15-24 = 2028-01-13 to 2028-10-13), pronunciation scoring occurs weekly; inter-rater reliability is re-checked every 2 weeks (weekly during months 20-24 = 2028-08-13 to 2028-10-13); if kappa drops below 0.70 during active scoring, the Metrics & Validation Committee immediately recommends rater re-calibration or additional training.

**Adaptation Trigger:** Reference accent choice is not finalized and justified by Month 3 (2027-01-13); initial inter-rater kappa <0.70 after first training in Month 10-11 (2027-08-13 to 2027-09-13); inter-rater kappa remains <0.70 after retraining; audio storage audit identifies >1% missing or corrupted files; rater drift observed (kappa declining >0.05 over a 4-week interval during Phase 2 scoring); pronunciation-consistency preliminary results show no meaningful difference between Clear English and control conditions or effect sizes contradicting pilot expectations (potential confound signal).

### 10. Risk Management: Post-Project Stewardship Funding and Governance Sustainability
**Monitoring Tools/Platforms:**

  - Steward Organization Identification and Outreach Log
  - Stewardship Funding Commitment Letters
  - Standards Stewardship Committee Charter and 5-Year Roadmap
  - Post-Phase-3 Governance Transition Plan

**Frequency:** Steward identification and approach (Months 24-27 = 2028-10-13 to 2029-01-13); commitment letters sought (by Month 33 = 2029-07-13); Stewardship Committee and 5-year roadmap finalized (by Month 36 = 2029-10-13); quarterly post-launch governance check-ins (Months 36, 39, 42 = 2029-10-13, 2030-01-13, 2030-04-13, ... as funded)

**Responsible Role:** Compliance & Risk Management Committee (Chair, risk-management specialist) with Project Lead and Stakeholder Engagement Lead, in collaboration with the Phase 2 go/no-go decision (if GO) Project Sponsor

**Adaptation Process:** After the Month 24 (2028-10-13) Phase 2 go/no-go decision, if GO, the Project Lead and Compliance & Risk Management Committee begin identifying potential permanent steward organizations (language-education non-profits, university consortiums, international standards bodies such as ISO or academic organizations) with track records in standards maintenance and funding stability. By Month 27 (2029-01-13), outreach is initiated with a stewardship proposal (estimated annual budget $150K-$250K estimate for ongoing maintenance, governance, change-request review, and lexicon updates). Commitment letters from at least one steward organization are sought by Month 33 (2029-07-13); if no commitment is obtained by this date, the Project Lead escalates to the Project Sponsor for a decision: either (a) defer v1.0 public release pending stewardship commitment (delaying release beyond Month 30 = 2029-04-13), (b) release v1.0 with a conditional sunset clause (e.g., 'This standard will be maintained only if stewardship funding is secured by Month X'), or (c) proceed with release and accept the risk that the standard will atrophy if no steward emerges. A Standards Stewardship Committee is formally established by Month 30 (2029-04-13) with 3-5 members (steward-organization representative, Editorial Board continuity, key adopter representatives) and a published charter and 5-year roadmap specifying how the standard will be updated, how change requests will be prioritized and resolved, and how conflicts over rule interpretation will be handled.

**Adaptation Trigger:** Phase 2 go/no-go is GO (Month 24 = 2028-10-13) and no steward organization has been approached by Month 24 (2028-10-13); steward outreach begins but by Month 30 (2029-04-13) no letter of commitment is in hand; potential steward organizations decline participation (budget constraints, competing priorities); a steward-organization commitment is received but with conditions (e.g., 'only if ESL publisher adoption reaches 50,000+ learners by Month X') that are unrealistic or unverifiable; the Steering Committee or Project Sponsor determines that the standard's post-Phase-3 viability is at risk and recommends either release deferral or conditional-release strategy.

### 11. Risk Management: Rule Fragmentation and Non-Conforming Variants Post-Release
**Monitoring Tools/Platforms:**

  - Licensing and Name-Stewardship Model Decision Document
  - Conformance Checklist (public, light, free)
  - Third-Party Adoption and Licensing Registry
  - Non-Conforming Fork and Unofficial Variant Alert Log

**Frequency:** Licensing model finalized (by Month 6 = 2027-04-13) and published (Month 12 = 2027-10-13); conformance checklist published (Month 12 = 2027-10-13); post-release monitoring for unofficial variants and non-conforming uses (quarterly, Months 30, 33, 36, 39 = 2029-04-13, 2029-07-13, 2029-10-13, 2030-01-13, ... post-release, starting Month 30 = 2029-04-13)

**Responsible Role:** Compliance & Risk Management Committee (Chair) with Standards Stewardship Committee (post-Month 36 = 2029-10-13) and Stakeholder Engagement Lead; external legal counsel if name-stewardship disputes arise

**Adaptation Process:** By Month 6 (2027-04-13), the Compliance & Risk Management Committee and Project Lead (with external legal counsel input) finalize the Licensing and Name Stewardship model: either (a) text and dictionary openly licensed; 'Clear English' name reserved as a certification mark (requiring conformance against a public checklist) awarded to materials that pass the checklist, or (b) text and dictionary under a permissive share-alike license (permitting derivative works if divergence is disclosed and a distinct name is adopted once >10% of rules diverge, proposed threshold). A public, light, free conformance checklist is published by Month 12 (2027-10-13), specifying the key rules (ordinal marker form, morphology changes, homograph markers, lexicon boundaries) that materials must follow to claim 'Clear English' conformance. Post-release (starting Month 30 = 2029-04-13), the Standards Stewardship Committee (or Project Lead, if Stewardship Committee not yet established) monitors for third-party uses of the 'Clear English' name and for unofficial forks or non-conforming variants. A public registry of licensed adopters is maintained; if an organization uses the name without conformance (detected via social media, publishing announcements, or direct report), the Stewardship Committee issues a public clarification or, if certification model is in force, withholds the mark and may issue a public statement that the variant is non-conforming.

**Adaptation Trigger:** A third party publicly labels a variant or material as 'Clear English' but the variant incorporates rule changes beyond the 10% divergence threshold (proposed) or omits required core rules; a significant non-conforming fork is discovered (detected via web search, standards-body inquiry, or third-party report) suggesting that the 'Clear English' name is being applied to non-standardized material, creating confusion; the Stewardship Committee receives >3 inquiries or complaints in a quarter about non-conforming use of the name; an offline publisher or organization uses the name in printed material without seeking conformance review and the Stewardship Committee learns of it via partner or standards-body feedback; an open-source project or crowdsourced variant emerges that claims Clear English affiliation but diverges significantly from the published standard.

# Governance Extra

## Governance Validation Checks

1. Completeness: All core governance components are defined (Editorial Board Charter, Steering Committee Charter, Metrics & Validation Committee Charter, Compliance & Risk Management Committee Charter, escalation matrix, monitoring framework, implementation plan). Governance bodies span rule specification (Editorial Board), strategic oversight (Steering Committee), measurement credibility (Metrics & Validation Committee) and risk/compliance management (Compliance & Risk Management Committee). Decision authority and escalation paths are explicitly mapped. The framework covers all three phases and includes post-Phase-3 stewardship planning (Standards Stewardship Committee, steward identification by Month 33 = 2029-07-13). One core gap: the role and decision authority of the ultimate Project Sponsor (external funding body) is mentioned in Phase 3 implementation but not formally chartered; clarify escalation from Steering Committee to Sponsor for strategic disputes or go/no-go outcome challenges.
2. Internal Consistency: Rule decisions (Editorial Board) feed into measurement design (Metrics & Validation Committee pre-registers ordinal-error-rate and pronunciation-consistency scoring rubrics tied to finalized rules by Month 11 = 2027-09-13). Pilot recruitment (Compliance & Risk Management Committee and Stakeholder Engagement Lead) is contingent on partner commitments signed by Month 3 (2027-01-13) and ethics approval by Month 6 (2027-04-13), both tracked against timelines. Budget monitoring (Finance Lead, Steering Committee monthly reviews) enforces the $175K pre-gate contingency cap and flags overruns for escalation. Timeline and critical-path tracking (Project Lead, Steering Committee) monitor sequential dependencies (rules Month 12 = 2027-10-13, audio Month 11 = 2027-09-13, pre-registration Month 11 = 2027-09-13, recruitment Month 13 = 2027-11-13, data lock Month 22 = 2028-08-13, gate Month 24 = 2028-10-13). Escalation matrix specifies approval processes and negative consequences for each risk type. No detected logical conflicts; however, the adaptive mechanisms (e.g., how the board proceeds if Arbiter recommendation is rejected, how Phase 1 extension is funded if kappa<0.70) could be more explicit in terms of decision authority and contingency funding draw procedures.
3. Clarity of Roles and Authority: Editorial Board chair and Steering Committee chair are identified as distinct roles. Editorial Board linguist members hold formal veto authority, limited to rule ambiguity and contradiction findings (not rule substance). Metrics & Validation Committee operates at 'arm's length' from Editorial Board and Steering Committee to maintain measurement independence. Project Sponsor role is mentioned for escalation but is not formally chartered; the Sponsor's approval authority for reserve draws >$175K, Phase extensions, and major scope changes should be explicitly documented in a Sponsor Charter by Month 0 (2026-10-13). Conflict-of-interest disclosure procedures are specified (Editorial Board Charter, attestations collected by Month 1 = 2026-11-13), but no described mechanism for handling conflicts (e.g., if an Editorial Board member's institution benefits from a rule decision). Stakeholder Engagement Lead and Educator Liaison roles are defined with clear responsibilities (partner engagement, corrective outreach), but their authority to modify pilot protocols or messaging without Steering Committee approval is unclear; specify delegation limits.
4. Process Depth and Operational Clarity: Rule-finalization process is detailed (subcommittees biweekly Months 2-10 = 2026-12-13 to 2027-08-13, Linguistic Review Panel monthly vetting, escalation to Arbiter for deadlock, 30-day public comment Month 11-12 = 2027-09-13 to 2027-10-13, v1.0 lock Month 12 = 2027-10-13), with decision-logging discipline. Gate metric design includes construct-validity analysis and pre-registration (Months 4-5 = 2027-02-13 to 2027-03-13 literature review and expert panel, validity study Months 10-11 = 2027-08-13 to 2027-09-13, pre-analysis plan finalization Month 11 = 2027-09-13, registration by Month 11.5 = 2027-09-28 proposed). However, three operational processes need more detail: (a) Conflict-of-interest management: no procedure specified for what happens if an Editorial Board member's employer benefits from a rule decision or if a Steering Committee member has financial stake in ESL publishing; (b) Whistleblower or ethics-violation reporting: no designated reporting channel or investigation procedure if misconduct (data manipulation, participant coercion, unauthorized audio use) is alleged; (c) Change-control post-v1.0: the decision specifies 'v1.0 frozen 12 months' but does not detail how errata will be identified, approved and communicated; specify errata-review procedure and timeline.
5. Process Completeness: Gaps identified in three areas: (1) Quantitative Gate Thresholds: The four metrics (ordinal error rate ≥25% reduction, comprehension speed ≤10% slower, pronunciation consistency ≥15% above control, 30-day retention ≥70%) are named and loosely specified with proposed thresholds, but the complete pre-analysis plan (including statistical test type, sample-size power analysis calculation, primary vs. secondary outcome hierarchy, intention-to-treat rules, missing-data imputation procedures, effect-size interpretation guidance) must be drafted by Month 5 (2027-03-13), externally peer-reviewed by Month 5.5 (2027-03-28), and locked by Month 11 (2027-09-13) before pre-registration. The canonical facts document specifies the thresholds but does not reference the underlying power analysis or effect-size assumptions; confirm that the $150K-$200K (estimate) psychometrics budget includes power analysis, effect-size justification studies and post-hoc sensitivity analysis. (2) Construct-Validity and Confound Controls: The implementation plan specifies 'detailed construct-validity literature review' (Month 4 = 2027-02-13) and 'expert-panel discussion' (Month 4 = 2027-02-13) but does not describe how confounds (repeated exposure, learner motivation, accent proximity) will be operationalized or measured in the pilot; detail the control-condition design (e.g., standard-English ordinals with explicit rule instruction vs. implicit exposure) and manipulation-check procedures (e.g., post-test questions asking learners which rule system they learned) in the pre-analysis plan. (3) Data Integrity and Consent Escalation: The Compliance & Risk Management Committee monitors data-protection compliance, but the framework does not specify a formal data-privacy incident-response procedure (who investigates, timeline, notification of affected participants, regulatory reporting); draft a written Data-Privacy Incident Response Plan by Month 4 (2027-02-13) and include it in the IRB protocol.
6. Potential Gaps Requiring Clarification: (a) Project Sponsor Role: The Sponsor (external funding body representative or senior institutional leader) is mentioned as having authority to approve reserve draws >$175K and to make final decisions on Phase extensions or project termination, but is not formally chartered. Draft a Project Sponsor Charter by Month 0 (2026-10-13) specifying escalation thresholds (e.g., Sponsor approval required for budget increases >$300K, timeline extensions >8 weeks, scope reductions >15%), decision timeline (e.g., Sponsor must decide within 10 business days of escalation), and communication protocol (monthly reporting, ad-hoc escalation alerts). (b) Delegation Below Committee Level: The framework grants authority to committee chairs (Editorial Board Chair, Psychometrician as Metrics & Validation Committee Chair, Compliance & Risk Management Committee Chair, Project Lead) but does not specify whether these chairs can make routine operational decisions (e.g., can the Psychometrician hire a research assistant without Steering Committee approval? Can the Project Lead approve a $20K curriculum-design invoice without Finance Lead sign-off?) Define delegation authority thresholds (e.g., <$25K spending, <2-week timeline impact, routine operational decisions delegated to committee chairs; >$50K or strategic decisions require Steering Committee approval). (c) Standards Stewardship Committee Transition: The frame work specifies that a Standards Stewardship Committee will be established by Month 30 (2029-04-13) post-Phase-3, but the relationship between the Phase 1-3 Editorial Board and the post-Phase-3 Stewardship Committee is unclear. Will Editorial Board members serve on the Stewardship Committee? Will there be a formal transition meeting and knowledge-transfer protocol? Will the same decision-logging and conflict-resolution procedures apply post-Phase-3? Specify a Stewardship Committee Charter (to be finalized by Month 30 = 2029-04-13) that documents governance continuity and transition procedures.

## Tough Questions

1. Gate Metrics Credibility: By Month 11 (2027-09-13), can the Psychometrician and Metrics & Validation Committee certify that the four gate metrics (ordinal error rate ≥25% reduction, comprehension speed ≤10% slower, pronunciation consistency ≥15% above control, 30-day retention ≥70%) are grounded in a defensible power analysis (≥80% power at α=0.05), that the sample size target (≥80 completers per arm) is justified and achievable by data lock (Month 22 = 2028-08-13), and that inter-rater reliability is calibrated to kappa ≥0.70 floor? What assumptions underlie the ≥25% ordinal-error-reduction threshold—is it based on benchmarking against other language-learning interventions, or is it a consensus judgment of the Editorial Board, and if the latter, what is the evidentiary basis?
2. Rule Finalization and Ambiguity: By Month 11 (2027-09-13), will the Editorial Board publish a complete, non-ambiguous Clear English Standard v0.1 that specifies the ordinal marker symbol, its spoken pronunciation, the morphology retention cutoff with a published list of retained vs. regularized forms, the homograph-pair list with enforcement policy per pair, and the core-lexicon specification with coverage audit showing ≥85% coverage of pilot running text? If the Editorial Board cannot finalize all core rules without escalation to the external Arbiter, what is the timeline for Arbiter resolution, and does it still permit the 30-day public comment window before Month 12 (2027-10-13) v0.1 publication?
3. Construct Validity of Gate Metrics: What explicit control conditions and manipulation checks will be embedded in the Phase 2 pilots to isolate Clear English effects from alternative explanations (repeated exposure to ordinals, learner motivation to participate in a 'novel standard' study, accent proximity to learners' first language, baseline literacy differences)? By Month 5 (2027-03-13), will the Psychometrician publish a detailed construct-validity section of the pre-analysis plan that documents how each confound is measured and how the primary analysis will control for it (e.g., via regression, matching, or stratified analysis)?
4. Pilot Recruitment and Retention Evidence: By Month 3 (2027-01-13), what are the signed, written enrollment commitments from 3-4 adult ESL programs and 2-3 technical/safety-training organizations, and what does each commitment document (per-learner guarantee, payment terms, educator training, retention incentives, dropout tolerance)? By Month 13 (2027-11-13), what is the actual enrollment vs. the ≥115 per arm target, and if shortfall is >15%, what is the contingency plan (additional recruitment sites, extended enrollment period, Phase 2 timeline extension) and associated cost within the $175K pre-gate contingency cap?
5. Budget and Timeline Discipline: At the Month 9 (2027-07-13) Phase 1 spending review, what is the actual cumulative spend vs. the $1.1M Phase 1 budget allocation, and what is the 6-month forecast for Phase 2 spending (Month 9-14 = 2027-07-13 to 2027-12-13)? If Phase 1 spend is >10% over or <10% under budget, what is the root cause and what reallocation is recommended to maintain the $175K pre-gate contingency cap intact? If Phase 2 forecast indicates a $300K overrun (8.6% of total budget), what scope reduction is proposed—fewer pilot cohorts, smaller assessment battery, or Phase 1 extension deferral?
6. Measurement Inter-Rater Reliability Assurance: By Month 11 (2027-09-13), after rater training and the calibration study (Months 10-11 = 2027-08-13 to 2027-09-13), will Cohen's kappa for pronunciation-consistency scoring and ordinal-error scoring meet the ≥0.75 (proposed) target and exceed the 0.70 floor across all rater pairs? If any rater pair falls below 0.70 after the initial 2-week retraining window (Month 10-11 = 2027-08-13 to 2027-09-13), what is the evidence that a 4-week Phase 1 extension (~$85K cost) will remediate the reliability gap, and by what date must kappa be confirmed ≥0.70 (proposed: Month 12 = 2027-10-13) to permit Phase 2 green light?
7. Educator Engagement and Pushback Signals: By Month 6 (2027-04-13), what baseline metrics establish educator and standards-body sentiment on Clear English (e.g., survey of TESOL members, social-media sentiment analysis, direct interviews with 10-15 curriculum directors)? By Month 18 (2028-04-13), what is the change in sentiment, and what threshold of increase in critical feedback (>20% negative mentions, loss of a major partner commitment, a published TESOL or IATEFL position statement expressing concern) would trigger the 'educator pushback' escalation procedure to the Steering Committee and corrective outreach?

## Summary

The Clear English program is a moderately ambitious, evidence-gated, 36-month language-standardization initiative ($3.5M user constraint) spanning rule specification, pilot validation and public release. The governance framework—comprising a practitioner-leaning Editorial Board, an independent Metrics & Validation Committee, a Steering Committee with escalation authority, and a Compliance & Risk Management Committee—is comprehensive and well-structured to manage critical dependencies: rule clarity (Month 12 = 2027-10-13 lock), measurement credibility (pre-registered metrics by Month 11 = 2027-09-13), pilot recruitment and retention (460 learners across 4 arms), and post-launch stewardship (commitment sought by Month 33 = 2029-07-13). The framework prioritizes adoption-first, evidence-based decision-making, with clear escalation paths for rule deadlock, budget overruns, measurement threats and stakeholder pushback. Key strengths include pre-registration discipline, independent validity oversight, and explicit governance charters. Critical remaining gaps are quantitative gate thresholds (must be finalized and pre-registered by Month 11 = 2027-09-13), construct-validity control procedures, stewardship funding security (currently unfunded), and clear contingency procedures if critical path items slip or validity falls short of standards.