28 explicit calculations found in the documents re-computed without an LLM; 1 does not match its stated result.

| Section | Statement | Stated | Computed |
|---|---|---|---|
| Canonical Facts | $85K (1.1M/12 x 0.923 months = 1.1M x 4/52 | 1.1M | 84.61k |
