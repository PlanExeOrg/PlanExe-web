## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Have enough pilot partners signed enrolment commitments, and does early retention evidence support the planned dropout? | Signed commitments from ≥3 adult ESL programs and ≥2 technical/safety-training organizations by Month 3 (2027-01-13), with non-binding publisher letters of interest; baseline dropout ≤35% (premortem tripwire is >35%; plan tolerance ≤30%); by Month 6 (2027-04-13), signed guarantees covering ≥320 expected completers. | Signed partner agreements by Month 3 (2027-01-13); retention data from the baseline study or partner history (Months 1–3 = 2026-11-13 to 2027-01-13, subject to ethics clearance); guarantee tally at Month 6 (2027-04-13). | Delay Phase 2 launch and raise the enrolment target above 460 (about 492–582 if dropout is 35–45%), or downsize to ESL-only with a redefined gate; if guarantees are below 320 completers at Month 6 (2027-04-13) despite standby sites, cancel Phase 2 or pivot the wedge before further spend (premortem FM3). |
| 2 | Is the safety-critical glossary/labeling track legally permissible and insurable within the capped liability budget? | Counsel's written advice that no formal regulatory approval is needed; insurer quotes at or below $50K per year (estimate); liability strategy complete by Month 4 (2027-02-13); legal/liability spend within $150K–$200K (estimate). | Written advice from retained counsel and ≥2 insurance brokers, plus informal regulator input (one US, one UK), by Month 4 (2027-02-13). | Split: run the technical cohort after the gate or drop it and proceed ESL-only (premortem FM5). This requires a decision on what the Month 24 (2028-10-13) gate covers with two arms. |
| 3 | Are the ordinal rule and the pronunciation scoring reliable enough to freeze, with audio inside the cost limit? | Inter-rater kappa ≥0.70 floor (target 0.75) at the Month 10 (2027-08-13) check; ordinal marker symbol and spoken form fixed (Month 10 = 2027-08-13, with Month 8 = 2027-06-13 as warning line); ≤5% ambiguous instances in the ordinal conversion test (Month 4 = 2027-02-13, proposed threshold); audio ≤$20 per entry ($100K total, estimate). | Month 4 (2027-02-13) conversion test on 200–300 real documents; Month 3–6 (2027-01-13 to 2027-04-13) rater screening and calibration; Month 10 (2027-08-13) tool dry run and kappa check; firm studio quotes by Month 3 (2027-01-13). | Switch audio to a synthetic baseline plus human verification if cost exceeds $20 per entry; take a 4-week Phase 1 extension (about $85K); if kappa is still below 0.70, drop pronunciation consistency as a primary gate metric by board decision or pivot. No Phase 2 launch on unreliable scoring. |
| 4 | Is the Phase 1 exit package complete, with the gate pre-registered, powered and affordable? | Rules locked at Month 12 (2027-10-13); 4 metrics and thresholds pre-registered at Month 11 (2027-09-13); power analysis confirms ≥80 completers per arm; lexicon coverage ≥85%; ethics approval in hand; forecast pre-gate draws ≤$175K. | OSF registration with psychometrician sign-off (Month 11 = 2027-09-13); closed 30-day comment window; ethics approval letter; budget forecast at Month 12 (2027-10-13). | Delay Phase 2 start by board vote only with a power check; if forecast pre-gate draws exceed $175K with no funded plan to keep ≥80 completers per arm, halt Phase 2 launch and return to the board for descoping or cancellation (premortem FM1). If rules are not locked by Month 13 (2027-11-13), Phase 2 does not launch (FM6). |
| 5 | Do the pilot results meet all four pre-registered thresholds under valid conditions? | ≥25% relative reduction in ordinal error; comprehension ≤10% slower than control; pronunciation consistency ≥15% above control (significant); 30-day retention ≥70% and not below control; validity: ≥80 completers per arm, follow-up completion ≥70%, kappa ≥0.70. | Data lock Month 22 (2028-08-13); analysis and dossier Months 22–24 (2028-08-13 to 2028-10-13); Month 24 (2028-10-13) board decision against the pre-registered plan. | Valid data with any metric failing: NO-GO, close and return unspent funds (up to $1.2M, less draws and wind-down). Invalid or inconclusive data: board-decided 3–6 month extension (about $300K–$600K), whose funding source must be decided in advance. |
| 6 | Is a written, funded steward commitment in hand before v1.0 is released? | Signed steward commitment by Month 30 (2029-04-13) covering $150K–$250K per year (estimate); the Month 33 (2029-07-13) tripwire is <50% of $150K per year; ≥3 licensed adopters (≥1 ESL publisher) by Month 36 (2029-10-13). | Letters of interest by Month 24 (2028-10-13) (≥2 required); signed MOU with named funding source by Month 30 (2029-04-13); release-readiness review at Month 30 (2029-04-13). | Do not release publicly. The project must have decided in advance whether to defer with a funded extension, release frozen and unmaintained, or close and archive; the FM4 stop rule cancels at Month 33 (2029-07-13). Phase 3 outreach spending is paused. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: executive_summary Risk 1; review_plan Reviews 1, 2, 4, 5, 6, 8, 11, 13; self_audit item 4
    canonical: pilot_enrolment_and_dropout = Enrol >=115 per arm = 460 total across 4 arms; tolerated dropout <=30%; 80 completers per arm (estimate)
    observed:  57–75 per arm, 28–40% below minimum; revised target 350–400 to yield 80 completers; '<450 = 10% shortfall'; '70% = 350 of 460'
HIGH CF-002  document: executive_summary; pitch; review_plan Review 14
    canonical: phase2_go_no_go_rule = GO only if all four metrics meet pre-registered thresholds AND validity holds; valid data with any metric failing = NO-GO; invalid/inconclusive = board-decided extension
    observed:  Binary meet/not-meet with fixed $1.2M returned; NO-GO only if ≥2 metrics fail
HIGH CF-003  document: pitch Collaboration Opportunities; review_plan Reviews 2, 4, 10
    canonical: reserve_draw_rule = Pre-gate draws capped at $175K; remaining ≥$175K released only after Month 24 (2028-10-13) GO; stewardship unfunded
    observed:  Steward receives $0.35M reserve; extension and Phase 2.5 funded from the reserve
HIGH CF-004  document: review_plan KPI 3, Reviews 3 and 5; pitch Collaboration Opportunities; premortem FM4
    canonical: v1_release = v1.0 public release by Month 30 (2029-04-13) (proposed), conditional on a written steward commitment
    observed:  Steward commitment/MOU due by Month 33 (2029-07-13), 'before v1.0 release at Month 30 (2029-04-13)'
HIGH CF-005  document: review_plan Reviews 4 and 10; self_audit item 14; premortem FM5
    canonical: pilot_design = 2 cohorts × 2 conditions = 4 arms; GO needs ≥80 completers per arm
    observed:  Safety cohort deferred post-Month 24 (2028-10-13) or cancelled; gate evidence ESL-only; trigger 4 vs 6 months
MEDIUM CF-006  document: canonical_facts (ordinal_rule date); premortem A2
    canonical: ordinal_rule = marker symbol and spoken form fixed by Month 10 (2027-08-13)
    observed:  Month 8 (2027-06-13) warning line (FM2); Month 8 (2027-06-13) lock (Review 13); Month 3 (2027-01-13) rater scoring (A2)
MEDIUM CF-007  document: self_audit items 6 and 15; review_plan Reviews 3 and 6; premortem FM4
    canonical: v1_release = v1.0 release by Month 30 (2029-04-13), conditional on a written steward commitment
    observed:  Cancel at Month 33 (2029-07-13) (premortem) vs defer to Month 36 (2029-10-13) or later (self-audit, review)
MEDIUM CF-008  document: executive_summary; review_plan Reviews 5, 8, 9; premortem A3
    canonical: phase1_exit_gate = ethics approval in hand by Phase 1 exit; ethics approval by Month 6 (2027-04-13) (project plan)
    observed:  Human-participant baseline study in Months 1–2 (2026-11-13 to 2026-12-13)
MEDIUM CF-009  document: executive_summary
    canonical: staffing = 1.0 FTE cohort manager (by Month 6 = 2027-04-13)
    observed:  Month 4 (2027-02-13)
MEDIUM CF-010  document: executive_summary
    canonical: governance_board = charter by Month 1 (2026-11-13); first meeting Month 2 (2026-12-13); arbiter agreed by Month 5 (2027-03-13)
    observed:  Charter with arbiter selection by Month 3 (2027-01-13)
MEDIUM CF-011  document: pitch; review_plan
    canonical: adoption_target = ≥3 licensed adopters by Month 36 (2029-10-13); 10,000–50,000 unvalidated estimate; 100,000+ not a target
    observed:  'millions of learners'; '100,000+ goal'; 10,000–50,000 'by Month 36 (2029-10-13)'
LOW CF-012  document: self_audit; review_plan; executive_summary
    canonical: free_reserve_after_fallbacks = $85K draw leaves $90K headroom; following $300K extension leaves $35K shortfall
    observed:  'exceeds cap by $125K, leaving $90K'; 'exhausts the cap'; '$35K–$90K headroom'; '$125K–$152K'
```

### 1. Dropout and enrolment arithmetic (completers per arm, revised enrolment target, tripwires) (🔴 High)

- **executive_summary Risk 1; review_plan Reviews 1, 5, 6, 8:** Executive summary Risk 1: dropout 35–45% 'reduces completers to 57–75 per arm (28–40% below 80-per-arm minimum)'. Review plan: baseline shows 35–45% dropout, so 'revise enrollment targets to 350–400' and 'enrolment must reach 350–400 to yield 80 completers'.
- **canonical pilot_enrolment_and_dropout; review_plan Reviews 2, 4, 11, 13; self_audit item 4; premortem FM3:** Plain arithmetic from the canonical design (115 per arm, 460 total): 35–45% dropout gives 63–75 completers per arm (6–21% below 80). Reaching 320 completers at 35–45% dropout needs about 492–582 enrolments; 350–400 enrolments yield only about 192–260 completers (48–65 per arm). Review 4 uses '210–240 completers (52–60 per arm)' for the same 350–400 scenario that Review 2 puts at '220–260 (57–65 per arm)'. Tripwires: '<450 total (10% shortfall)' (450 is 2% below 460); '<70% of target (350 vs 460)' (70% of 460 is 322); premortem '<70% of 460 by Month 10 (2027-08-13)'; '<400 at Month 12 (2027-10-13)'.
- **Why it conflicts:** Higher observed dropout requires a higher enrolment target, not a lower one. The documents use 350–400 both as a shortfall scenario and as the corrected target. The percentage ranges and tripwire values do not match the stated bases.
- **Suggested resolution:** Keep 115 per arm / 460 total for 30% dropout. If the baseline shows 35–45% dropout, the corrected requirement is about 492–582 enrolments (123–146 per arm), or a power analysis must justify fewer completers. Treat 350–400 only as a shortfall scenario. State per-arm completers as 63–75 (6–21% below 80). Use one tripwire expressed as a percentage of 460 (e.g. 70% = 322), with one month and one number.

### 2. Gate outcome described as binary stop vs three-outcome rule (🔴 High)

- **executive_summary Focus and Context; pitch Project Overview:** Executive summary: 'if not, the project returns $1.2M unspent Phase 3 funding and closes.' Pitch: 'If the pilots do not meet the threshold metrics, the project stops before public release and returns unspent funds.'
- **canonical phase2_go_no_go_rule, gate_funds_at_risk, phase2_extension_fallback; review_plan Review 14.3:** Canonical rule: valid data with any metric failing = NO-GO; invalid or inconclusive data = board-decided extension (3–6 months, about $300K–$600K). Funds returnable are 'up to $1.2M, less pre-gate draws and wind-down'. Review 14 proposes a different tree: 'NO-GO: ≥2 metrics fail; INCONCLUSIVE: 1–2 metrics borderline, valid data'.
- **Why it conflicts:** The summary and pitch omit the extension outcome and state the return as a fixed $1.2M. Review 14 would treat a single valid failing metric as inconclusive, which the canonical rule classes as NO-GO. The pre-registered decision rule would be ambiguous.
- **Suggested resolution:** Use the canonical three-outcome rule everywhere: GO only if all four metrics pass and validity holds (≥80 completers per arm, follow-up ≥70%, kappa ≥0.70). Valid data with any failure is NO-GO. Invalid data leads to a board-decided extension. Say 'up to $1.2M returnable, less draws and wind-down'. Drop the Review 14 tree or align it.

### 3. $0.35M reserve is claimed by more uses than it can fund (🔴 High) — needs a project decision

- **pitch Collaboration Opportunities; review_plan Reviews 2, 4, 10:** Pitch: the post-v1.0 steward will 'receive $0.35M reserve release post-gate plus pro-rata Phase 3 funding'. Review plan: a 3–6 month Phase 2 extension ($300K–$600K) and a Phase 2.5 safety track ($150K–$300K) are 'funded from Phase 3 reserve'; Phase 3 is 'up to $1.2M if reserve is released post-GO'.
- **canonical reserve_draw_rule, phase3_budget, stewardship_funding_gap:** Canonical: pre-gate draws capped at $175K for gate protection; balance released only after a GO; stewardship is unfunded (revenue $0, gap $150K–$250K per year); Phase 3 is effectively $1.2M only if the reserve is released after a GO. An inconclusive gate is not a GO.
- **Why it conflicts:** The same $350K is promised to pre-gate protection (up to $175K), the Phase 3 top-up, a Phase 2 extension that is needed precisely when no GO exists, a Phase 2.5 safety track and the steward. The pitch presents steward funding as a fact while other documents say it is unfunded.
- **Suggested resolution:** Remove the steward-funding claim from the pitch until a funding decision exists. The project must decide the funding source and order of precedence for: (a) an extension after an inconclusive gate (reserve released without GO? unspent Phase 3 funds? new money?), (b) the Phase 2.5 safety track, (c) any one-off steward endowment from Phase 3 funds. Options: ring-fence a stewardship tranche, leave stewardship unfunded and conditional, or make the extension consume Phase 3 funds and reduce the adoption scope.

### 4. Steward commitment deadline (Month 33 = 2029-07-13) falls after the release it is meant to condition (Month 30 = 2029-04-13) (🔴 High)

- **canonical v1_release; executive_summary; premortem FM4:** v1.0 public release by Month 30 (2029-04-13), 'conditional on a written steward commitment'; executive summary: stewardship commitment 'confirmed before v1.0 release at Month 30 (2029-04-13)'; premortem tripwire 'No signed steward MOU by Month 30 (2029-04-13)'.
- **pitch; review_plan Reviews 3, 5, 6; premortem FM4 stop rule:** Pitch: steward funding 'if commitments are met by Month 33 (2029-07-13)'. Review KPI 3: MOU 'by Month 33 (2029-07-13) … before v1.0 release at Month 30 (2029-04-13)'. Review 3: 'negotiate MOU Months 27–33 (2029-01-13 to 2029-07-13)'. Premortem FM4 stop rule: no signed commitment 'by Month 33 (2029-07-13)'. Review Issue 5: commitment letters 'by Month 33 (2029-07-13)'.
- **Why it conflicts:** A prerequisite cannot be due three months after the milestone it gates. If the commitment arrives at Month 33 (2029-07-13), release cannot occur at Month 30 (2029-04-13). Steward-search start also varies (premortem A4 brief at Month 6 = 2027-04-13; executive summary Month 12 = 2027-10-13; Review 18; Review 24).
- **Suggested resolution:** Keep Month 30 (2029-04-13) as the signed-commitment date and the release gate. Treat Month 33 (2029-07-13) only as the latest point at which a delayed release can still be triggered, and say so explicitly. Align all documents to one search start (Month 12 = 2027-10-13 with a Month 6 = 2027-04-13 candidate brief).

### 5. Safety-critical cohort deferral vs the 4-arm gate (🔴 High) — needs a project decision

- **canonical pilot_design, phase2_go_no_go_rule; project_plan Measurable:** Canonical design: 4 arms (adult ESL and native technical/safety cohort × Clear English vs control); GO requires ≥80 completers per arm; technical cohort is secondary to the ESL wedge.
- **review_plan Reviews 4, 10; self_audit item 14; premortem FM5:** If regulator approval is needed, 'defer safety-critical cohort to a post-Month-24 Phase 2.5 extension ($150K–$300K) funded from Phase 3 reserve' (trigger >6 months in Review 4, >4 months in Review 10 and self-audit). Premortem FM5: 'project proceeds ESL-only'.
- **Why it conflicts:** Removing two arms before Month 24 (2028-10-13) changes the gate population, the 320-completer requirement and the evidence for the technical glossary claims. The deferral trigger also differs (4 vs 6 months). No document states what the Month 24 (2028-10-13) gate decides in that case.
- **Suggested resolution:** Decide before Month 4 (2027-02-13) whether the GO rule applies to the ESL cohort alone when the technical cohort is cancelled or deferred (2 arms, 160 completers) or whether technical-adoption claims are dropped. Fix one approval-delay trigger. Funding for Phase 2.5 depends on the reserve decision.

### 6. Ordinal marker spoken form fixed at the same month as the rater check that depends on it (🟡 Medium) — needs a project decision

- **canonical ordinal_rule, audio_production, rules_freeze_preregistration, phase1_extension_fallback:** Canonical: marker symbol and spoken form fixed by Month 10 (2027-08-13); audio recorded Months 6–11 (2027-04-13 to 2027-09-13); tool dry run and kappa ≥0.70 check at Month 10 (2027-08-13); pre-registration at Month 11 (2027-09-13).
- **premortem A2, FM2; review_plan Reviews 8, 13; self_audit item 5:** Premortem FM2: spoken form 'unresolved at Month 8 (2027-06-13)' is an early warning because 'rater training starts late'; Review 13: lock accent and spoken form by Month 8 (2027-06-13) to begin rater training and confirm kappa by Month 9.5 (2027-07-28). Premortem A2 uses 'pre-screened raters' at Month 3 (2027-01-13) while pre-screening completes at Month 4 (2027-02-13).
- **Why it conflicts:** Raters cannot be trained or calibrated on a reading that is only fixed at the month the kappa check occurs. Audio production for ordinals runs Months 6–11 (2027-04-13 to 2027-09-13), before the reading is fixed. The Month 10 (2027-08-13) lock leaves no buffer before the Month 10 (2027-08-13) kappa check and the 4-week extension fallback.
- **Suggested resolution:** A project decision is needed: (a) move the lock to Month 8 (2027-06-13) as FM2 and Review 13 imply, (b) keep Month 10 (2027-08-13) but run the kappa check on a provisional reading and budget re-recording of ordinal entries, or (c) separate ordinal-marker items from the general lexicon audio schedule. Align A2's Month 3 (2027-01-13) proof-of-concept with the Month 4 (2027-02-13) rater pre-screening.

### 7. Steward fallback: cancel v1.0 or defer it (🟡 Medium) — needs a project decision

- **premortem FM4:** Premortem FM4 stop rule: 'If no signed steward commitment exists by Month 33 (2029-07-13), v1.0 public release is cancelled and the project closes with archived materials.'
- **self_audit items 6, 15; review_plan Reviews 3, 6, 14:** Self-audit items 6 and 15, Review KPI 3 and Review 3: 'defer v1.0 release to Month 36 (2029-10-13) or later until stewardship is funded'. Review Issue 5: do not release publicly until stewardship is secured. Program and Phase 3 funding end at Month 36 (2029-10-13); adopters are due by Month 36 (2029-10-13).
- **Why it conflicts:** Cancellation and deferral are different project outcomes. Deferral past Month 36 (2029-10-13) has no funded team and conflicts with the ≥3 adopters by Month 36 (2029-10-13) target.
- **Suggested resolution:** Decide the no-steward outcome in advance. Options: close and archive (FM4); defer with a funded, time-boxed extension; publish a frozen v1.0 in limited scope with a stated unmaintained status; transfer to an archive custodian. State the adopter target consequence of each.

### 8. Baseline recruitment study before ethics approval and partner commitments (🟡 Medium) — needs a project decision

- **executive_summary Risk 1 and Feedback; review_plan Reviews 5, 8, 9; premortem A3:** Baseline recruitment study with N=20–30 learners at 2–3 sites in Months 1–2 (2026-11-13 to 2026-12-13), with sites identified at Month 1 (2026-11-13) and two assessment sessions; planned as the validation of the dropout assumption.
- **project_plan Compliance Actions, Dependencies; canonical phase1_exit_gate, pilot_partner_commitments:** Ethics/IRB review is engaged Months 1–2 (2026-11-13 to 2026-12-13) and approval is due by Month 6 (2027-04-13); partner commitments are signed by Month 3 (2027-01-13); the psychometrician is hired by Month 2 (2026-12-13). The $15K–$20K cost is not in the phase budgets.
- **Why it conflicts:** A study of adult learners with assessments and attrition tracking would take place before ethics clearance and before partners are committed. The dependency order is reversed and the cost has no budget line.
- **Suggested resolution:** Decide how the dropout evidence is obtained: obtain an IRB exemption or determination for the study in Months 1–2 (2026-11-13 to 2026-12-13); run it after approval and move the Month 3 (2027-01-13) recruitment-plan revision; or use partner historical retention data and literature. Assign a budget line from Phase 1.

### 9. Cohort manager hiring month (🟡 Medium)

- **canonical staffing; project_plan Mitigation Plans; pitch Risks; premortem FM7:** Canonical staffing, project plan, pitch and premortem FM7: 1.0 FTE cohort manager by Month 6 (2027-04-13).
- **executive_summary Risks and Action Orientation:** Executive summary: 'hire cohort manager by Month 4 (2027-02-13) (not Month 6 = 2027-04-13)' and action (6) 'By Month 4 (2027-02-13): Hire Phase 2 Cohort Manager (1.0 FTE)'.
- **Why it conflicts:** The executive summary adopts a review recommendation as if it were the plan. The tripwires and the budget timing follow Month 6 (2027-04-13).
- **Suggested resolution:** Keep Month 6 (2027-04-13) unless the board formally changes the staffing fact. Record 'Month 4 (2027-02-13)' as a proposed acceleration with its cost, so that executive summary and tripwires use the same date.

### 10. Editorial Board Charter and arbiter dates (🟡 Medium)

- **canonical governance_board; project_plan Dependencies:** Charter with voting, tiebreak arbiter and conflict-of-interest rules published by Month 1 (2026-11-13); first meeting Month 2 (2026-12-13); arbiter agreed by Month 5 (2027-03-13).
- **executive_summary Action Orientation:** Executive summary action list: 'By Month 3 (2027-01-13): (5) Publish Editorial Board Charter with voting rules and arbiter selection.'
- **Why it conflicts:** A Month 3 (2027-01-13) charter would postdate the Month 2 (2026-12-13) first board meeting. It conflates charter publication (Month 1 = 2026-11-13) with arbiter agreement (Month 5 = 2027-03-13).
- **Suggested resolution:** State the charter at Month 1 (2026-11-13) and the arbiter agreed at Month 5 (2027-03-13) in the action list.

### 11. Adoption reach: 'millions' and 100,000+ vs 10,000–50,000 unvalidated estimate (🟡 Medium)

- **canonical adoption_target:** Canonical: 10,000–50,000 learner reach is an unvalidated estimate; 100,000+ is not a target; no universal-adoption claims.
- **pitch Project Overview and Long-term Vision; review_plan Reviews 5, 6, 14:** Pitch opening: 'a pathway for millions of learners'. Review plan: reach capped 'at 10,000–20,000 (vs. the unvalidated 100,000+ goal)'. Pitch: 10,000–50,000 'within 5 years'; Review 14: the same reach 'by Month 36 (2029-10-13)'.
- **Why it conflicts:** The pitch claims reach orders of magnitude above the estimate and the review keeps 100,000+ as a goal. The time horizon for 10,000–50,000 (5 years vs Month 36 = 2029-10-13) also differs.
- **Suggested resolution:** Remove 'millions' and 100,000+ goal language. State 10,000–50,000 learners as an unvalidated estimate within 5 years. Keep Month 36 (2029-10-13) only for the ≥3 adopter target.

### 12. Pre-gate reserve headroom arithmetic (⚪ Low)

- **canonical free_reserve_after_fallbacks, overrun_exposure:** Canonical: a 4-week extension ($85K) leaves $90K headroom under the $175K cap; a following 3-month Phase 2 extension ($300K) leaves a $35K shortfall; a $300K overrun exceeds the cap by $125K.
- **self_audit item 6; review_plan Reviews 4, 11; executive_summary Feedback:** Self-audit item 6: stacked scenarios 'exceeding the cap by $125K, leaving only $90K unallocated headroom'. Review 4: $85K draw 'exhausts the pre-gate $175K draw cap, leaving zero contingency' (body: $90K left). Executive summary: '$175K pre-gate draw cap ($35K–$90K headroom)'. Review 11: $40K–$50K overrun leaves '$125K–$152K' (175−40 to 175−50 = $125K–$135K) and equals '2.7–3.5% of Phase 1 budget' (3.6–4.5% of $1.1M).
- **Why it conflicts:** Exceeding the cap and having $90K headroom are different scenarios. $35K is a shortfall, not headroom. The percentages do not reconcile.
- **Suggested resolution:** Use the canonical figures: $85K leaves $90K headroom; $85K plus a $300K extension is a $35K shortfall; $300K overrun is $125K over the cap. Recompute the percentages against $1.1M.

## Summary

The core frame is consistent across documents: $3.5M, three 12-month phases, the $1.1M/$1.2M/$0.85M/$0.35M split, the Month 24 (2028-10-13) gate, the four proposed gate metrics and the ESL-first wedge. The serious faults are in derived numbers and fallback logic. Dropout and enrolment arithmetic does not reconcile (the review proposes lowering enrolment when dropout is higher). The gate is described as binary although the canonical rule has a board-decided extension outcome. The $0.35M reserve is claimed by several uses that together exceed it. The steward commitment deadline (Month 33 = 2029-07-13) is scheduled after the release it conditions (Month 30 = 2029-04-13). The executive summary and pitch follow pre-reconciliation or review-recommended values (cohort manager Month 4 = 2027-02-13, charter Month 3 = 2027-01-13, "millions" of learners, steward funded from the reserve) instead of the canonical facts. Most items are repairable text fixes. The needs_decision items concern reserve funding, steward fallback, safety-cohort deferral, baseline-study ethics and the ordinal spoken-form lock date.