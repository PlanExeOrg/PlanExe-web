### 1. Project Lead and Funding Authority jointly identify and appoint the Project Sponsor (external funding body representative or senior institutional leader) and define their role in governance escalation and reserve-draw authorization.

**Responsible Body/Role:** Funding Authority / Institutional Sponsor

**Suggested Timeframe:** Month 0 (2026-10-13) (Project start, within 1 week of kickoff)

**Key Outputs/Deliverables:**

- Project Sponsor role description and appointment letter
- Escalation and decision authority documented in writing

**Dependencies:**

- Funding agreement executed
- Project initiation and resource allocation confirmed

### 2. Project Lead drafts the Project Steering Committee Charter, specifying membership roles, voting rules (simple majority with tie-breaker), escalation procedures for rule deadlock and budget disputes, meeting cadence, and decision thresholds (e.g., >$50K spending decisions, reserve draws, phase-gate authority).

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0 (2026-10-13) (end of Month 0 = 2026-10-13, by 2026-10-13)

**Key Outputs/Deliverables:**

- Draft Steering Committee Charter (2-3 pages, including decision authority matrix, meeting schedule, escalation path to external arbiter and Funding Authority)

**Dependencies:**

- Project Sponsor identified and engaged
- Strategic decisions documented (Pragmatic Foundation scenario confirmed)

### 3. Project Lead circulates the draft Steering Committee Charter to the nominated Steering Committee members (project lead, finance lead, editorial board chair, external academic partner, psychometrician role, ESL publisher advisor, standards-body advisor) for review and feedback; incorporates comments and finalizes.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0.5 (2026-10-28) (within 2 weeks of draft completion)

**Key Outputs/Deliverables:**

- Feedback summary on draft charter
- Steering Committee Charter v1.0 finalized

**Dependencies:**

- Draft Charter circulated
- Nominated member list confirmed

### 4. Project Lead formally publishes the Steering Committee Charter and formally appoints the Steering Committee Chair (typically the Project Lead or an external governance advisor); all 7 members confirm acceptance in writing.

**Responsible Body/Role:** Project Lead with Project Sponsor authorization

**Suggested Timeframe:** Month 1 (2026-11-13) (by 2026-11-13)

**Key Outputs/Deliverables:**

- Published Steering Committee Charter (including decision matrix, voting rules, escalation paths)
- Appointment confirmation letters from all 7 members
- Steering Committee formally constituted

**Dependencies:**

- Charter finalized
- All member nominations confirmed
- Project Sponsor approval

### 5. Project Lead drafts the Editorial Board Charter, specifying practitioner-leaning composition (4-5 practitioners: ESL instructors, technical writers, safety trainers; 2-3 linguists; 1 optional learner rep), voting rules, conflict-of-interest disclosure, decision-logging protocol, Linguistic Review Panel authority and veto scope (limited to ambiguity/contradiction findings), and tiebreaker mechanism.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0 (2026-10-13) (by end of Week 1)

**Key Outputs/Deliverables:**

- Draft Editorial Board Charter (3-4 pages, including member roles, veto authority scope, conflict-of-interest template, decision logging protocol)

**Dependencies:**

- Strategic decisions on Editorial Board composition confirmed (practitioner-leaning, linguist review-and-veto limited to ambiguity)

### 6. Project Lead recruits and confirms Editorial Board membership: 4-5 practitioners (ESL instructors, technical writers, safety trainers), 2-3 linguists (applied linguistics, morphology/phonology specialists with standards-development experience), and optionally 1 learner representative; all members sign conflict-of-interest attestations.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 0.5 (2026-10-28) to Month 1 (2026-11-13) (recruitment complete by 2026-11-13)

**Key Outputs/Deliverables:**

- Confirmed membership roster with affiliations and expertise areas
- Signed conflict-of-interest disclosure forms for all members
- Confirmation of first-meeting availability

**Dependencies:**

- Member recruitment outreach completed
- Editorial Board Charter draft available for reference

### 7. Project Lead formally publishes the Editorial Board Charter and announces the confirmed board membership; all members sign the charter in acknowledgment.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 1 (2026-11-13) (by 2026-11-13)

**Key Outputs/Deliverables:**

- Published Editorial Board Charter
- Signed acknowledgment from all 7-9 board members
- Editorial Board formally constituted

**Dependencies:**

- Charter finalized and reviewed by nominated members
- All conflict-of-interest forms signed

### 8. Project Lead identifies and recruits an external Arbiter (neutral linguist or standards-design specialist with no financial stake in ESL publishing or standards bodies) to serve as tiebreaker for rule deadlocks and strategic disputes; document agreed fee ($10K-$20K estimate), availability for 2-week turnaround on escalations, and contact/escalation protocol.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Months 2-5 (2026-12-13 to 2027-03-13) (by 2027-03-13)

**Key Outputs/Deliverables:**

- Arbiter identification and bio
- Signed engagement agreement with fee and availability terms
- Escalation protocol documented for Steering Committee and Editorial Board

**Dependencies:**

- Steering Committee and Editorial Board established
- Budget for arbiter fees allocated ($10K-$20K estimate)

### 9. Project Lead schedules and holds the first Editorial Board meeting to surface rule-specification tensions and assign workstreams (ordinal, morphology, homograph, lexicon, pronunciation-guidance logic) to subcommittees; set internal deadlines for rule drafts (Month 6 = 2027-04-13).

**Responsible Body/Role:** Editorial Board Chair (Project Lead or designated chair)

**Suggested Timeframe:** Month 2 (2026-12-13) (by 2026-12-13)

**Key Outputs/Deliverables:**

- Meeting minutes documenting rule-specification tensions and workstream assignments
- Subcommittee membership confirmed (ordinal, morphology, homograph, lexicon, pronunciation-guidance)
- Internal deadlines locked for draft-rule delivery (Month 6 = 2027-04-13)

**Dependencies:**

- Editorial Board formally constituted
- Charter published

### 10. Project Lead hires an independent psychometrician (external or internal dedicated role, 0.5-1.0 FTE) to lead instrument design, validity analysis and inter-rater reliability work; allocate $150K-$200K (estimate) budget; establish role reporting to Project Lead and the Metrics & Validation Committee (to be formed).

**Responsible Body/Role:** Project Lead with Finance Lead approval

**Suggested Timeframe:** Month 2 (2026-12-13) (by 2026-12-13)

**Key Outputs/Deliverables:**

- Psychometrician job description and offer letter
- Contract or employment agreement signed
- Start date confirmed (Month 2 or early Month 3 = 2027-01-13)
- Budget allocation confirmed: $150K-$200K for total metrics work through Month 24 (2028-10-13)

**Dependencies:**

- Budget and hiring authority available
- Role requirements document prepared

### 11. Psychometrician (with Project Lead support) conducts a detailed construct-validity literature review and expert-panel discussion (involving external applied-linguistics and measurement specialists) to identify plausible confounds (repeated exposure, learner motivation, accent proximity, baseline literacy) and design explicit control conditions and manipulation checks to isolate Clear English effects.

**Responsible Body/Role:** Psychometrician (newly hired), with external measurement specialist advising

**Suggested Timeframe:** Month 4 (2027-02-13) (by 2027-02-13)

**Key Outputs/Deliverables:**

- Construct-validity literature review report (10-15 pages)
- Expert-panel discussion summary (confounds identified, control-condition proposals)
- Preliminary list of manipulation checks and confound-control procedures

**Dependencies:**

- Psychometrician hired and in role
- External specialists identified and available for consultation

### 12. Psychometrician drafts the pre-analysis plan specifying: (1) quantitative pass/fail thresholds for the four gate metrics (ordinal error ≥25% reduction, comprehension speed ≤10% slower, pronunciation consistency ≥15% above control, 30-day retention ≥70%); (2) minimum sample sizes (n≥80 per arm for 80% power at α=0.05); (3) primary and secondary outcomes; (4) intention-to-treat vs. completer-case rules; (5) control conditions and manipulation checks; (6) inter-rater reliability targets (kappa ≥0.75 target, 0.70 floor); (7) data-quality and missing-data protocols.

**Responsible Body/Role:** Psychometrician

**Suggested Timeframe:** Months 4-5 (2027-02-13 to 2027-03-13) (draft complete by 2027-03-13)

**Key Outputs/Deliverables:**

- Pre-analysis plan draft (15-20 pages, including quantitative thresholds with justification, sample-size power analysis, primary outcomes, confound-control procedures, analysis code skeleton)

**Dependencies:**

- Construct-validity review and expert-panel input complete
- Gate metrics specified by Steering Committee and Editorial Board

### 13. Psychometrician circulates the pre-analysis plan draft for external peer review (to external measurement specialists, applied-linguistics researchers, and a representative from the Steering Committee); collects feedback and revises.

**Responsible Body/Role:** Psychometrician with external review committee

**Suggested Timeframe:** Month 5 (2027-03-13) (feedback deadline Month 5 = 2027-03-13, revision complete by Month 5.5 = 2027-03-28)

**Key Outputs/Deliverables:**

- External review feedback summary (2-3 pages)
- Revised pre-analysis plan v2 (incorporating substantive feedback)

**Dependencies:**

- Draft plan circulated to external reviewers
- External reviewers nominated and committed

### 14. Project Lead drafts the Metrics & Validation Committee Charter, specifying the Committee's independence from Editorial Board and Steering Committee, decision authority over instrument design and data-quality standards, authority to recommend (and escalate if needed) changes to pilot protocol, data-integrity standards, and escalation procedures (data-privacy breaches, kappa below 0.70, validity threats escalate to Steering Committee within 48 hours).

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 2 (2026-12-13) (by 2026-12-13)

**Key Outputs/Deliverables:**

- Draft Metrics & Validation Committee Charter (2-3 pages)

**Dependencies:**

- Psychometrician hired
- Steering Committee governance model established

### 15. Project Lead formally appoints the Metrics & Validation Committee: Psychometrician (Chair), 1-2 external applied-linguistics or measurement specialists (e.g., university faculty with ESL assessment publications), and a data-integrity/research-compliance officer (internal); publish the Committee Charter with all members' signed acknowledgment.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 3 (2027-01-13) (by 2027-01-13)

**Key Outputs/Deliverables:**

- Published Metrics & Validation Committee Charter
- Appointment confirmation letters from Committee members
- Committee formally constituted
- Meeting schedule locked (bi-weekly, Mondays 90 minutes, through Month 24 = 2028-10-13)

**Dependencies:**

- Charter drafted and reviewed
- Psychometrician in role and identified as Chair
- External specialists recruited

### 16. Psychometrician designs and conducts the validity-study protocol: recruit N=20-30 adult ESL learners; expose them to both Clear English and standard-English ordinal conditions (within-subject or between-subject design); administer assessment instruments; collect pronunciation audio if applicable; run preliminary analyses (effect sizes, inter-rater kappa, construct-validity checks); document findings.

**Responsible Body/Role:** Psychometrician with Metrics & Validation Committee oversight

**Suggested Timeframe:** Months 9-10 (2027-07-13 to 2027-08-13)

**Key Outputs/Deliverables:**

- Validity-study protocol document (IRB-approved)
- Preliminary analysis results: effect sizes for ordinal error rate, comprehension speed, pronunciation consistency; inter-rater kappa scores; control-condition performance
- Findings report (5-10 pages)

**Dependencies:**

- Ethics/IRB approval obtained by Month 6 (2027-04-13)
- Assessment instruments finalized
- Small pilot cohort recruited (N=20-30)

### 17. Psychometrician incorporates validity-study findings into the final pre-analysis plan; finalize thresholds, sample sizes, and analysis procedures; submit the complete pre-analysis plan to an external pre-registration repository (e.g., Open Science Framework, OSF) by Month 11 (2027-09-13).

**Responsible Body/Role:** Psychometrician

**Suggested Timeframe:** Month 10-11 (2027-08-13 to 2027-09-13) (pre-registration complete by 2027-09-13)

**Key Outputs/Deliverables:**

- Pre-analysis plan v3, final (incorporating validity-study findings)
- OSF or equivalent pre-registration URL and timestamp
- Published pre-analysis plan summary (1-2 pages) available to Steering Committee

**Dependencies:**

- Validity study completed and analyzed
- External review feedback incorporated
- Gate metrics finalized and approved by Steering Committee

### 18. Project Lead drafts the Compliance & Risk Management Committee Charter, specifying the Committee's authority to recommend changes to pilot protocol to mitigate identified risks, to escalate high-severity risks to the Steering Committee within 5 business days, and to halt pilots if data-privacy breaches or ethics violations occur.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 1 (2026-11-13) (by 2026-11-13)

**Key Outputs/Deliverables:**

- Draft Compliance & Risk Management Committee Charter (2-3 pages)

**Dependencies:**

- Steering Committee governance model established
- Risk register template prepared

### 19. Project Lead recruits Compliance & Risk Management Committee members: risk-management specialist (Chair, 0.5 FTE), external legal counsel (product liability and regulatory compliance, ~4 hours/month retainer), ethics/IRB liaison (internal or academic partner, ~3-4 hours/month), stakeholder-engagement/communications lead (internal, 0.5 FTE), and finance/budget lead liaison (internal, ~2 hours/month).

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 1-2 (2026-11-13 to 2026-12-13)

**Key Outputs/Deliverables:**

- Confirmed Committee membership with roles and affiliations
- Signed engagement letters for external legal counsel and ethics liaison
- Committee members ready to attend first meeting

**Dependencies:**

- Committee Charter drafted
- Budget allocated for legal counsel, ethics consulting, and additional FTE

### 20. Project Lead formally appoints the Compliance & Risk Management Committee with published Charter; all members sign acknowledgment.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 1 (2026-11-13) (by 2026-11-13)

**Key Outputs/Deliverables:**

- Published Compliance & Risk Management Committee Charter
- Appointment confirmation letters from all members
- Committee formally constituted
- Meeting schedule locked (monthly, third Wednesday 90 minutes, through Month 36 = 2029-10-13)

**Dependencies:**

- Charter finalized
- All members confirmed

### 21. Project Lead engages external legal counsel (product-liability and regulatory-compliance specialist) to advise on liability, insurance, disclaimer language for safety-critical materials, and regulatory approval pathways for safety-critical pilots; retain by signed engagement letter by Month 2 (2026-12-13).

**Responsible Body/Role:** Project Lead with Compliance & Risk Management Committee guidance

**Suggested Timeframe:** Month 2 (2026-12-13) (by 2026-12-13)

**Key Outputs/Deliverables:**

- Signed legal counsel engagement letter ($10K-$20K estimated annual retainer estimate)
- Preliminary legal review of project liability and insurance needs

**Dependencies:**

- Budget for legal counsel allocated
- Compliance & Risk Management Committee Chair identified

### 22. Compliance & Risk Management Committee develops a comprehensive Risk Register template categorizing risks by domain (regulatory/standards adoption, pilot recruitment/retention, assessment validity, rule ambiguity, safety-critical liability, budget/timeline, educator pushback, fragmentation, data privacy, stewardship funding); list 20 identified risks from assumptions document plus space for emerging risks; specify likelihood, severity, mitigation status, owners and escalation thresholds.

**Responsible Body/Role:** Compliance & Risk Management Committee Chair with Committee members

**Suggested Timeframe:** Month 2 (2026-12-13) (by 2026-12-13)

**Key Outputs/Deliverables:**

- Risk Register template (Excel or web-based tool) with 20+ pre-populated risks, likelihood/severity matrix, mitigation columns, owner assignments
- Risk tolerance thresholds documented (high×high and high×medium risks escalate automatically)

**Dependencies:**

- Committee members recruited and in role
- Risk assumptions document reviewed

### 23. Compliance & Risk Management Committee holds first meeting to populate the Risk Register, assign mitigation owners, confirm timelines and escalation procedures, and establish quarterly risk-review schedule (Months 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36 = 2027-01-13 onwards).

**Responsible Body/Role:** Compliance & Risk Management Committee

**Suggested Timeframe:** Month 1 (2026-11-13) (by 2026-11-13)

**Key Outputs/Deliverables:**

- Completed Risk Register with mitigation owners and target completion dates
- Quarterly risk-review schedule published
- First quarterly risk review scheduled for Month 3 (2027-01-13)
- Meeting minutes documenting risk assignments and escalation paths

**Dependencies:**

- Committee formally constituted
- Risk Register template ready

### 24. Project Lead engages ethics review board or Institutional Review Board (IRB) to clarify whether the pilot qualifies as research requiring formal review; submit initial consultation request by Month 1 (2026-11-13).

**Responsible Body/Role:** Compliance & Risk Management Committee (ethics liaison) with Project Lead

**Suggested Timeframe:** Months 1-2 (2026-11-13 to 2026-12-13)

**Key Outputs/Deliverables:**

- Initial IRB consultation completed
- Written guidance on whether full protocol review is required
- IRB contact and process timeline documented

**Dependencies:**

- Ethics liaison identified
- Initial pilot design document available

### 25. Compliance & Risk Management Committee drafts a formal IRB protocol (including study design, informed-consent forms, data-handling procedures, audio-recording consent with options for data deletion, privacy safeguards, confidentiality measures) and submits to IRB for review by Month 3 (2027-01-13), targeting approval by Month 6 (2027-04-13).

**Responsible Body/Role:** Compliance & Risk Management Committee (ethics liaison) with Psychometrician input

**Suggested Timeframe:** Months 2-3 (2026-12-13 to 2027-01-13) (draft complete by 2027-01-13, submitted to IRB)

**Key Outputs/Deliverables:**

- Formal IRB protocol document (15-20 pages: study background, objectives, design, population, procedures, informed-consent form, data-protection plan, confidentiality safeguards, audio-consent options)
- Submitted to IRB with cover letter
- IRB submission date and expected review timeline documented

**Dependencies:**

- Initial IRB consultation completed
- Pilot design and assessment procedures finalized
- Ethics liaison in role

### 26. Compliance & Risk Management Committee secures encrypted audio-storage infrastructure with access controls, backup and disaster-recovery protocols; conduct vendor selection and sign contract by Month 6 (2027-04-13); set up storage systems and test backup procedures by Month 6 (2027-04-13).

**Responsible Body/Role:** Compliance & Risk Management Committee (data-integrity officer) with IT/project support

**Suggested Timeframe:** Months 4-6 (2027-02-13 to 2027-04-13)

**Key Outputs/Deliverables:**

- Audio-storage vendor selected and contract signed
- Storage infrastructure deployed and tested
- Access-control and encryption protocols documented
- Backup and disaster-recovery procedures tested with dry-run data

**Dependencies:**

- Data-integrity officer in role
- Budget allocated for storage ($20K-$30K estimate)

### 27. Compliance & Risk Management Committee conducts a data-protection audit (GDPR compliance, US state privacy law requirements, data-retention schedules, participant access rights) and publishes a privacy policy and data-retention schedule on the project website by Month 12 (2027-10-13); document findings and any compliance gaps.

**Responsible Body/Role:** Compliance & Risk Management Committee (ethics liaison, legal counsel)

**Suggested Timeframe:** Months 8-12 (2027-06-13 to 2027-10-13)

**Key Outputs/Deliverables:**

- Data-protection audit report (5-10 pages, GDPR/US law compliance assessment)
- Published privacy policy on project website
- Published data-retention schedule (e.g., audio deleted after analysis unless participant requests retention)
- Participant-access and data-deletion procedures documented

**Dependencies:**

- Ethics/IRB protocol approved
- Audio storage infrastructure in place
- Legal counsel advising

### 28. Project Lead (with Steering Committee and Editorial Board input) confirms the five critical strategic-lever choices documented in the Pragmatic Foundation scenario: (1) Ordinal Marker Architecture—numeric prefix marker, legacy forms coexist; (2) Grapheme-to-Phoneme Depth—optional overlay, no respelling; (3) Adoption Wedge—ESL-first supplementary; (4) Outcome Metric Battery—purpose-built, independently validated; (5) Phase Budget—even spread ($1.1M/$1.2M/$0.85M). Publish with written rationale and trade-off documentation.

**Responsible Body/Role:** Project Lead with Steering Committee and Editorial Board review

**Suggested Timeframe:** Month 2 (2026-12-13) (by 2026-12-13)

**Key Outputs/Deliverables:**

- Strategic-Lever Confirmation document (3-5 pages, each lever with rationale, alternatives considered, trade-offs documented)
- Published to all governance bodies

**Dependencies:**

- Steering Committee and Editorial Board formally constituted
- Pragmatic Foundation scenario approved by Project Sponsor

### 29. Project Lead establishes a Critical Path Dashboard tracking phase milestones (rules finalization, audio completion, recruitment enrollment, pre-registration, pilot midpoint, analysis), resource allocation by phase and budget line, and go/no-go gate conditions (pre-registration thresholds locked, pilot enrollment ≥80 per arm, 30-day follow-up completion ≥70%, inter-rater kappa ≥0.70, validity audit findings clean); review monthly and escalate slips >2 weeks to Steering Committee.

**Responsible Body/Role:** Project Lead with Finance Lead

**Suggested Timeframe:** Month 1 (2026-11-13) (by 2026-11-13)

**Key Outputs/Deliverables:**

- Critical Path Dashboard (shared spreadsheet or project-management tool with monthly milestone tracking, variance alerts set for >2-week slips, gate-condition checklist)
- Monthly status report template (variance from plan, risk flag summary, next steps)

**Dependencies:**

- Phase structure and budget allocation finalized
- Key milestones defined

### 30. Project Lead schedules phase-gate checkpoint meetings with Steering Committee: (1) Month 11 (2027-09-13) pre-registration review and rules-finalization readiness; (2) Month 18 (2028-04-13) midpoint check on pilot enrollment, retention, and preliminary data quality; (3) Month 23 (2028-09-13) validity audit review and go/no-go readiness; (4) Month 24 (2028-10-13) go/no-go decision meeting.

**Responsible Body/Role:** Project Lead / Steering Committee Chair

**Suggested Timeframe:** Month 1 (2026-11-13) (by 2026-11-13)

**Key Outputs/Deliverables:**

- Calendar holds for all 4 checkpoint meetings locked (90-120 minutes each)
- Checkpoint agenda template distributed (pre-registration status, budget variance, risk summary, gate-condition checklist)

**Dependencies:**

- Steering Committee formally constituted
- Phase timeline and gates confirmed

### 31. Project Lead identifies 3-4 adult ESL programs and 2-3 technical/safety-training organizations as pilot partners; initiate outreach with brief overview of the Clear English program, pilot participation expectations (enrollment, in-person assessments, 30-day follow-up), and proposed partnership terms (per-learner payment, incentive structure, educator training, feedback loop).

**Responsible Body/Role:** Project Lead with Stakeholder Engagement Lead (Compliance & Risk Management Committee)

**Suggested Timeframe:** Month 1-2 (2026-11-13 to 2026-12-13)

**Key Outputs/Deliverables:**

- Outreach list of 5-7 partner organizations identified
- Outreach email and brief describing program, timeline and partnership terms
- First-contact completed with all identified partners

**Dependencies:**

- Pilot design outlined
- Budget for pilot participation costs ($208K-$351K estimate) allocated

### 32. Project Lead and Stakeholder Engagement Lead co-design pilot protocols with representatives from each partner organization (assessment schedule, classroom integration, learner-communication plan, data-sharing agreements); ensure protocols address partner capacity and learner-retention incentives; finalize by Month 3 (2027-01-13).

**Responsible Body/Role:** Project Lead with Stakeholder Engagement Lead and partner representatives

**Suggested Timeframe:** Months 2-3 (2026-12-13 to 2027-01-13)

**Key Outputs/Deliverables:**

- Co-designed pilot protocols (assessment schedule, materials, learner communication, feedback mechanisms)
- Partner feedback and approval documented

**Dependencies:**

- Initial partner outreach completed
- Metrics & Validation Committee assessment instruments drafted

### 33. Project Lead secures signed pilot-partnership commitments from at least 3 adult ESL programs and 2 technical/safety-training organizations, including written enrollment guarantees (≥115 per organization estimate, total ≥460 across 4 arms), contact-hour payment terms, educator training commitment, and data-sharing agreement; all signed by Month 3 (2027-01-13).

**Responsible Body/Role:** Project Lead with Compliance & Risk Management Committee (contract review)

**Suggested Timeframe:** Months 2-3 (2026-12-13 to 2027-01-13)

**Key Outputs/Deliverables:**

- Signed partnership agreements (3-4 pages each, enrollment guarantees, payment terms, data-sharing, educator training, feedback schedule)
- Enrollment commitments documented (total ≥460 learners, breakdown by partner and condition)
- Pilot partner commitment summary (table: partner name, contact, enrollment target, start date, payment terms)

**Dependencies:**

- Co-designed protocols agreed
- IRB approval (or interim approval to proceed pending full approval) obtained

### 34. Project Lead recruits a dedicated Phase 2 cohort manager (1.0 FTE, ~$60K-$80K/year estimate) to oversee pilot enrollment, retention, scheduling, data collection, participant incentive distribution, 30-day follow-up contact, and dropout documentation; hire by Month 6 (2027-04-13) to begin recruitment preparation.

**Responsible Body/Role:** Project Lead with Finance Lead approval

**Suggested Timeframe:** Months 4-6 (2027-02-13 to 2027-04-13)

**Key Outputs/Deliverables:**

- Cohort manager job description and offer letter
- Employment/contract signed
- Start date confirmed (by Month 6 = 2027-04-13)
- Cohort-management systems (tracking, enrollment database, follow-up procedures) set up

**Dependencies:**

- Budget for cohort-manager salary allocated
- Pilot partnership agreements signed

### 35. Project Lead and Stakeholder Engagement Lead develop and deliver educator training on Clear English rules, rationale, pilot administration, and learner communication; training delivered to all pilot site educators (2-3 sessions, in-person or virtual) by Month 10 (2027-08-13); offer continuing education credits or stipends ($20K-$40K estimate) to incentivize participation.

**Responsible Body/Role:** Stakeholder Engagement Lead with Editorial Board input on rule explanation

**Suggested Timeframe:** Months 8-10 (2027-06-13 to 2027-08-13)

**Key Outputs/Deliverables:**

- Educator training curriculum (1-2 days, covering Clear English history, rule rationale, assessment procedures, learner FAQ)
- Training delivery completed at all pilot sites
- Attendance records and feedback from educators
- Continuing education certificates or stipend payments issued (~$50 per educator, estimate)

**Dependencies:**

- Rules finalized by Month 12 (2027-10-13) or draft rules by Month 9 (2027-07-13)
- Pilot partnership agreements signed with training commitment

### 36. Project Lead and Stakeholder Engagement Lead engage ESL teacher professional organizations (TESOL, IATEFL, national equivalents) as advisory partners by Month 2 (2026-12-13), with monthly or quarterly contact to discuss pilot findings, educator concerns, and adoption barriers; track engagement metrics (meeting attendance, feedback quality) monthly.

**Responsible Body/Role:** Stakeholder Engagement Lead

**Suggested Timeframe:** Month 2 onwards (2026-12-13 through Month 36 = 2029-10-13)

**Key Outputs/Deliverables:**

- Advisory partnership letters from TESOL, IATEFL or national equivalents
- Contact and engagement plan (meeting schedule, feedback mechanisms)
- Monthly engagement-metric summary (open rates, attendance, sentiment)

**Dependencies:**

- Stakeholder Engagement Lead in role
- Pilot design and educator concerns documented

### 37. Project Lead and Stakeholder Engagement Lead conduct stakeholder-expectation interviews and focus groups (Months 1-3 = 2026-11-13 to 2027-01-13) with educators, regulators, ESL publishers, and learners to understand their success criteria and concerns; document findings in a Stakeholder Alignment Charter published by Month 6 (2027-04-13).

**Responsible Body/Role:** Stakeholder Engagement Lead with Project Lead

**Suggested Timeframe:** Months 1-6 (2026-11-13 to 2027-04-13)

**Key Outputs/Deliverables:**

- Stakeholder interview and focus-group notes (10-15 interviews/groups, 3-5 key stakeholder segments documented)
- Stakeholder Alignment Charter (3-5 pages, success criteria by segment, concerns flagged, project responses documented)
- Published on project website and distributed to governance bodies

**Dependencies:**

- Stakeholder Engagement Lead in role
- Strategic decisions on adoption wedge and risk mitigation available

### 38. Project Lead and Stakeholder Engagement Lead build stakeholder advisory panels (separate from Editorial Board and Steering Committee) for educators, regulators, and publishers, meeting quarterly (Months 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36 = 2027-01-13 onwards) to surface emerging concerns and expectations; generate quarterly advisory-panel meeting summaries.

**Responsible Body/Role:** Stakeholder Engagement Lead

**Suggested Timeframe:** Month 2 (2026-12-13) onwards (panels established by 2026-12-13, first meeting Month 3 = 2027-01-13)

**Key Outputs/Deliverables:**

- Stakeholder advisory panels formed (educator panel: 3-5 teachers; regulator panel: standards-body and education-authority reps; publisher panel: 2-3 ESL publishers)
- Quarterly meeting notes (expectations, pushback signals, adoption barriers)
- Summary alerts escalated to Steering Committee if engagement drops or pushback increases

**Dependencies:**

- Stakeholder Engagement Lead in role
- Engagement contacts identified from interviews/focus groups

### 39. Project Lead and Stakeholder Engagement Lead conduct a mid-phase stakeholder check-in at Month 18 (2028-04-13) to assess alignment with project expectations and to adjust Phase 2 or Phase 3 strategy if major gaps are identified; publish a brief mid-phase alignment update.

**Responsible Body/Role:** Stakeholder Engagement Lead with Project Lead and Steering Committee

**Suggested Timeframe:** Month 18 (2028-04-13)

**Key Outputs/Deliverables:**

- Mid-phase stakeholder check-in meeting (educator, regulator, publisher panels)
- Alignment-update report (2-3 pages, what's working, what needs adjustment, Phase 3 adoption barriers identified)

**Dependencies:**

- Quarterly advisory panels meeting regularly through Month 18 (2028-04-13)

### 40. Project Lead confirms the single reference accent choice for pronunciation guidance (e.g., General American, Received Pronunciation, or shared-contrast phonemes across accents) with explicit written justification by Month 3 (2027-01-13); document how other major accents (British, American, Australian, Indian) map to the anchor.

**Responsible Body/Role:** Project Lead with Psychometrician and Editorial Board (linguist members) input

**Suggested Timeframe:** Month 3 (2027-01-13) (by 2027-01-13)

**Key Outputs/Deliverables:**

- Accent choice decision document (2-3 pages, anchor selected, justification, mapping to other accents outlined)
- Published and available to all governance bodies

**Dependencies:**

- Editorial Board linguist members in role
- Psychometrician and Reference Accent decision maker engaged

### 41. Project Lead and Finance Lead implement monthly financial tracking and rolling 6-month cash-flow forecasting from Month 1 (2026-11-13) onwards; track actual spending by Phase and budget line against allocations; flag variances >$50K or timeline slips >2 weeks for Steering Committee review.

**Responsible Body/Role:** Finance Lead with Project Lead

**Suggested Timeframe:** Month 1 onwards (2026-11-13 through Month 36 = 2029-10-13)

**Key Outputs/Deliverables:**

- Monthly spend report (Phase allocation, actual vs. budget by line item, cumulative variance, 6-month forecast)
- Budget-variance alert procedure (thresholds, escalation path to Steering Committee)
- Contingency-reserve balance tracked monthly

**Dependencies:**

- Phase budget allocations and spending authorization framework established
- Accounting system or finance tracking tool in place

### 42. Project Lead and Finance Lead conduct a formal spending review at Month 9 (2027-07-13) to assess Phase 1 expenses against budget and to adjust Phase 2 allocations if needed; Steering Committee reviews findings and approves any reallocation or contingency draws.

**Responsible Body/Role:** Finance Lead with Project Lead and Steering Committee

**Suggested Timeframe:** Month 9 (2027-07-13)

**Key Outputs/Deliverables:**

- Month 9 (2027-07-13) spending review report (Phase 1 actual spend, variances by line item, Phase 2 budget adjustment recommendations if needed)
- Steering Committee decision on any Phase 2 reallocation or contingency draw (up to $175K pre-gate cap)

**Dependencies:**

- Monthly spend tracking established and regular
- Phase 1 major expenses largely committed or incurred (staff, instruments, partnership agreements)

### 43. Project Lead negotiates fixed-rate contracts with curriculum vendors and audio studios by Month 3 (2027-01-13) to lock recording and design costs; specify deliverables, timeline, quality standards and penalties for delays.

**Responsible Body/Role:** Project Lead with Finance Lead

**Suggested Timeframe:** Months 1-3 (2026-11-13 to 2027-01-13)

**Key Outputs/Deliverables:**

- Fixed-rate contracts signed with audio studio (recording 5,000 entries), curriculum designer, and any other key vendors
- Cost per deliverable locked (e.g., $15-20 per audio entry, $X per curriculum module)
- Timeline and quality-acceptance criteria documented

**Dependencies:**

- Vendor selection process completed
- Budget allocation for audio recording ($80K-$120K estimate) and curriculum ($X estimate) available

### 44. Project Lead identifies a contingency audio studio or recording partner as a backup by Month 3 (2027-01-13) in case the primary vendor encounters delays or quality issues; document backup contact and standby agreement.

**Responsible Body/Role:** Project Lead

**Suggested Timeframe:** Month 3 (2027-01-13) (by 2027-01-13)

**Key Outputs/Deliverables:**

- Backup vendor identified and standby agreement in place (turnaround time, cost differential if backup is activated)

**Dependencies:**

- Primary audio vendor contracted

### 45. Editorial Board (ordinal workstream subcommittee) finalizes the ordinal-marker pronunciation specification (symbol, spoken reading, conversion rules from legacy 1st/2nd/3rd forms) and documents with explicit rationale by Month 10 (2027-08-13); Linguistic Review Panel vets for ambiguity.

**Responsible Body/Role:** Editorial Board (ordinal subcommittee) with Linguistic Review Panel oversight

**Suggested Timeframe:** Months 6-10 (2027-04-13 to 2027-08-13)

**Key Outputs/Deliverables:**

- Ordinal-marker pronunciation specification (2-3 pages, marker symbol, spoken reading rule, legacy-form conversion examples, boundary cases clarified)
- Rationale document (why this marker/pronunciation, design alternatives considered)

**Dependencies:**

- Editorial Board and Linguistic Review Panel formally constituted
- Ordinal workstream assigned and meeting regularly

### 46. Editorial Board (morphology workstream subcommittee) finalizes the irregular-morphology retention threshold, specifying which irregular verbs and plurals are retained (e.g., high-frequency forms like go/went) and which are regularized (lower-frequency or high-learning-friction forms); document rationale and published list of ~25% of irregulars regularized by Month 10 (2027-08-13).

**Responsible Body/Role:** Editorial Board (morphology subcommittee) with Linguistic Review Panel oversight

**Suggested Timeframe:** Months 6-10 (2027-04-13 to 2027-08-13)

**Key Outputs/Deliverables:**

- Morphology retention-threshold specification (frequency cutoff, recognition-penalty analysis, final list of regularized forms)
- Rationale document (retention rule justification, alternatives considered)
- Published list of retained irregular forms and regularized replacements (supporting the ~25% change rate proposed threshold)

**Dependencies:**

- Editorial Board morphology subcommittee in role
- Core-lexicon frequency data available

### 47. Editorial Board (homograph workstream subcommittee) finalizes the homograph-disambiguation policy, specifying the published list of ≤50 high-impact homograph/homophone pairs (e.g., lead/lead, read/read) and whether each requires a marker (mandatory in safety-critical docs), optional elsewhere, or a rewrite rule; document enforcement policy by Month 10 (2027-08-13).

**Responsible Body/Role:** Editorial Board (homograph subcommittee) with Linguistic Review Panel oversight

**Suggested Timeframe:** Months 6-10 (2027-04-13 to 2027-08-13)

**Key Outputs/Deliverables:**

- Homograph-disambiguation policy (published pair list ≤50 pairs estimate, marker vs. rewrite rule decision per pair, enforcement procedure for safety-critical documents)
- Rationale document (incident-based selection of pairs, cost/benefit of markers vs. rewrites)
- Marker symbol (if used) and application rules documented

**Dependencies:**

- Editorial Board homograph subcommittee in role
- Safety-critical pilot context identified

### 48. Editorial Board (lexicon workstream subcommittee) finalizes the core-lexicon selection basis (frequency-led general words + technical/safety reserve block), completes the 5,000-word list with pronunciations mapped and selection rationale documented by Month 10 (2027-08-13); audit coverage of pilot running text (target ≥85% coverage).

**Responsible Body/Role:** Editorial Board (lexicon subcommittee) with Psychometrician consultation

**Suggested Timeframe:** Months 4-10 (2027-02-13 to 2027-08-13)

**Key Outputs/Deliverables:**

- Core-lexicon selection basis document (frequency-led approach, technical/safety block details, rationale for selection principle)
- Final 5,000-word list (Excel with orthography, pronunciation guidance, standard-English mapping, frequency rank)
- Coverage audit report (% of running text in pilot materials, ESL curricula, safety glossaries covered by lexicon)

**Dependencies:**

- Editorial Board lexicon subcommittee in role
- Frequency corpora or domain-specific corpus available

### 49. Editorial Board conducts the first formal Editorial Board meeting (Month 2 = 2026-12-13) and subsequent monthly or biweekly subcommittee meetings (ordinal, morphology, homograph, lexicon, pronunciation-guidance logic) during Months 2-10 (2026-12-13 to 2027-08-13) to draft and refine rules; resolve conflicts using the Board's decision mechanism (simple majority, with linguist veto on ambiguity, escalation to external arbiter if needed).

**Responsible Body/Role:** Editorial Board with Linguistic Review Panel

**Suggested Timeframe:** Months 2-10 (2026-12-13 to 2027-08-13)

**Key Outputs/Deliverables:**

- Monthly Board meeting minutes documenting rule-decision progress, any conflicts, and escalations
- Biweekly subcommittee meeting notes (draft rule proposals, feedback cycles)

**Dependencies:**

- Editorial Board formally constituted
- Subcommittees assigned (Month 2 = 2026-12-13)

### 50. Linguistic Review Panel (linguist members of Editorial Board) conducts monthly 90-minute review meetings (Months 5-11 = 2027-03-13 to 2027-09-13) to examine proposed rules from subcommittees for ambiguity, logical contradiction, or lack of publishable justification; document any veto findings and escalation requests.

**Responsible Body/Role:** Linguistic Review Panel (embedded in Editorial Board)

**Suggested Timeframe:** Months 5-11 (2027-03-13 to 2027-09-13)

**Key Outputs/Deliverables:**

- Monthly Linguistic Review Panel meeting summaries (rules reviewed, veto findings, escalation requests if consensus not reached)
- Vetoed rules escalated to full Editorial Board for discussion and resolution

**Dependencies:**

- Linguistic Review Panel formally designated
- Monthly subcommittee drafts available for review

### 51. Editorial Board (with Project Lead support) maintains a Decision Log documenting all rule decisions, voting outcomes, dissenting opinions and rationale for each outcome; update within 3 business days of each board or subcommittee decision; publish quarterly (Months 3, 6, 9, 12 = 2027-01-13, 2027-04-13, 2027-07-13, 2027-10-13).

**Responsible Body/Role:** Editorial Board Chair with Project Lead administrative support

**Suggested Timeframe:** Months 1-12 (2026-11-13 to 2027-10-13, ongoing)

**Key Outputs/Deliverables:**

- Decision Log (running document, updated after each decision, includes rule name, voting tally, rationale, dissenting opinion summary)
- Quarterly published Decision Log summaries (Months 3, 6, 9, 12 = 2027-01-13, 2027-04-13, 2027-07-13, 2027-10-13)

**Dependencies:**

- Editorial Board meetings ongoing

### 52. Editorial Board resolves all unresolved rule disputes and tiebreaker escalations by Month 10 (2027-08-13), allowing a 1-month buffer for drafting and public comment before Month 11 (2027-09-13) finalization; any deadlocked disputes are escalated to the external Arbiter for binding recommendation within 2 weeks.

**Responsible Body/Role:** Editorial Board with external Arbiter if escalated

**Suggested Timeframe:** Month 10 (2027-08-13)

**Key Outputs/Deliverables:**

- Resolution of any outstanding rule disputes (tiebreaker decisions documented, arbiter recommendations if escalated)
- Confirmation that all core rules (ordinal, morphology, homograph, G2P, lexicon) are finalized

**Dependencies:**

- Linguistic Review Panel and subcommittee work completed

### 53. Editorial Board drafts the Clear English Standard v0.1 (draft) by Month 11 (2027-09-13), incorporating all finalized rules, lexicon, rationale and examples; publish the draft for a 30-day public-comment window (Months 11-12 = 2027-09-13 to 2027-10-13).

**Responsible Body/Role:** Editorial Board with Project Lead publication support

**Suggested Timeframe:** Month 11 (2027-09-13) (draft published by 2027-09-13 for 30-day window)

**Key Outputs/Deliverables:**

- Clear English Standard v0.1 draft document (30-50 pages, rule specifications, rationale, glossary examples, lexicon preview)
- Published on project website with instructions for submitting comments
- 30-day comment window open Months 11-12 (2027-09-13 to 2027-10-13)

**Dependencies:**

- All core-rule specifications finalized by Month 11 (2027-09-13)

### 54. Editorial Board manages the draft-standard 30-day public-comment window (Months 11-12 = 2027-09-13 to 2027-10-13): collect all substantive comments, triage by rule domain, draft responses addressing or acknowledging each comment, and prepare a summary of comments and responses for publication with v1.0.

**Responsible Body/Role:** Editorial Board with Project Lead administrative support

**Suggested Timeframe:** Months 11-12 (2027-09-13 to 2027-10-13)

**Key Outputs/Deliverables:**

- Public-comment submissions log (rule domain, commenter affiliation, summary of comment)
- Editorial Board responses to substantive comments (addressing concerns, clarifying rule intent, or documenting disagreement)
- Comment summary report (themes, key feedback, changes to v0.1 triggered by comments)

**Dependencies:**

- Draft standard published for public comment

### 55. Editorial Board incorporates substantive public feedback into rule clarifications (not reopening core rules) and publishes the final Clear English Standard v1.0 by Month 12 (2027-10-13), including the Decision Log (rule rationale), list of retained irregular forms, homograph-pair list, lexicon with pronunciation guidance, style guide covering ordinals/homographs/morphology, and published responses to public comments.

**Responsible Body/Role:** Editorial Board with Project Lead

**Suggested Timeframe:** Month 12 (2027-10-13) (by 2027-10-13)

**Key Outputs/Deliverables:**

- Clear English Standard v1.0 (final, 40-60 pages, all rules locked, Decision Log published, public-comment responses included)
- Accompanying style guide for ordinals, homograph markers, morphology and G2P application
- Reference dictionary entry list (5,000 words with pronunciations, mappings, examples)

**Dependencies:**

- 30-day public-comment window completed
- All rule disputes resolved

### 56. Project Lead determines and fixes the Licensing and Name Stewardship model by Month 6 (2027-04-13), choosing either a certification-mark approach (name restricted to conforming materials against a checklist) or a permissive share-alike license (permitting forks with divergence disclosure and distinct naming); publish the model by Month 12 (2027-10-13).

**Responsible Body/Role:** Project Lead with Compliance & Risk Management Committee (legal counsel) and Steering Committee input

**Suggested Timeframe:** Months 4-6 (2027-02-13 to 2027-04-13) (decision finalized by 2027-04-13)

**Key Outputs/Deliverables:**

- Licensing and Name Stewardship decision document (model chosen, rationale, conformance checklist if certification mark, license text if share-alike)
- Published by Month 12 (2027-10-13) with open licenses and/or certification-mark registration completed

**Dependencies:**

- Strategic decision on adoption strategy and third-party use anticipated

### 57. Project Lead and Compliance & Risk Management Committee develop a formal safety-critical pilot boundary and enforcement procedure by Month 4 (2027-02-13), specifying that safety-critical pilots are limited to glossary and labeling exercises, not live operational procedures, before Month 24 (2028-10-13) go/no-go decision; all materials carry explicit disclaimers and are reviewed by qualified human experts before use.

**Responsible Body/Role:** Compliance & Risk Management Committee (legal counsel, safety-critical partners) with Project Lead

**Suggested Timeframe:** Month 4 (2027-02-13) (by 2027-02-13)

**Key Outputs/Deliverables:**

- Safety-critical pilot scope document (glossary and labeling exercises defined, operational procedures explicitly excluded pre-Month-24)
- Disclaimer language for all materials (project does not guarantee safety of Clear English documents)
- Human-review procedure (qualified expert sign-off required before materials used in real settings)

**Dependencies:**

- Legal counsel engaged
- Safety-critical partners identified

### 58. Psychometrician conducts rater-training and inter-rater calibration study by Month 11 (2027-09-13), recruiting 3-5 raters to score a sample of ~100-200 ordinal and pronunciation items from both Clear English and standard-English conditions; target Cohen's kappa ≥0.75 (proposed) for each metric; document training protocol, scoring rubric, and any rater disagreements.

**Responsible Body/Role:** Psychometrician with Metrics & Validation Committee

**Suggested Timeframe:** Month 10-11 (2027-08-13 to 2027-09-13)

**Key Outputs/Deliverables:**

- Rater-training protocol document (training materials, scoringexamples, practice exercises)
- Inter-rater reliability study results (Cohen's kappa for ordinal error scoring, pronunciation consistency scoring, per-rater comparisons)
- Published scoring rubric (ordinal error criteria, pronunciation consistency criteria, boundary cases)
- Rater-training completion certificate or sign-off

**Dependencies:**

- Assessment instruments finalized
- Raters recruited and willing to attend training by Month 10 (2027-08-13)

### 59. Psychometrician and Project Lead conduct a dry-run of all assessment tools, data-collection procedures and audio-capture/storage workflows with a small pilot cohort (N=5-10 learners from one of the partner sites) by Month 10 (2027-08-13); test recording, storage, backup, data-labeling and analysis workflow; document findings and remediate any issues.

**Responsible Body/Role:** Psychometrician with Metrics & Validation Committee and one pilot partner

**Suggested Timeframe:** Month 10 (2027-08-13)

**Key Outputs/Deliverables:**

- Dry-run protocol (assessment schedule, learner recruitment, data-collection procedures)
- Dry-run findings report (audio quality assessment, data-storage/backup functionality, learner feedback on assessments, procedural timing)
- Remediation actions if issues found (e.g., audio-quality improvements, procedure clarifications)

**Dependencies:**

- Assessment instruments finalized
- Audio storage infrastructure in place and tested
- IRB approval (or interim clearance) to proceed with dry-run

### 60. Project Lead hires or designates an educator liaison (0.5-1.0 FTE, ~$50K-$70K/year estimate) by Month 6 (2027-04-13) to lead teacher engagement, training delivery, feedback loops and corrective outreach; educator liaison reports to Project Lead and Stakeholder Engagement Lead.

**Responsible Body/Role:** Project Lead with Finance Lead approval

**Suggested Timeframe:** Months 4-6 (2027-02-13 to 2027-04-13) (hire by 2027-04-13)

**Key Outputs/Deliverables:**

- Educator-liaison job description and offer letter
- Employment/contract signed
- Start date confirmed (by Month 6 = 2027-04-13)

**Dependencies:**

- Budget for educator-liaison role allocated

### 61. Compliance & Risk Management Committee develops a contingency plan for Phase 1 timeline extension (up to 4 weeks by Month 10 = 2027-08-13 if inter-rater reliability kappa <0.70 after initial training): cost ~$85K (estimate), approval by Steering Committee required; identify where the extension impacts Phase 2 start and pilot enrollment schedule.

**Responsible Body/Role:** Compliance & Risk Management Committee with Finance Lead and Steering Committee

**Suggested Timeframe:** Month 8 (2027-06-13)

**Key Outputs/Deliverables:**

- Phase 1 extension contingency plan (trigger: kappa <0.70 at Month 10 = 2027-08-13 check, remediation: 2-4 week rater retraining, cost ~$85K estimate, Steering Committee approval required)

**Dependencies:**

- Phase 1 budget and timeline understood
- Inter-rater calibration protocol established

### 62. Steering Committee reviews the pre-registered metrics, pre-analysis plan and go/no-go gate conditions at a scheduled checkpoint meeting (Month 11 = 2027-09-13); confirm that all four metrics have quantitative thresholds locked, sample size is n≥80 per arm, inter-rater reliability target is clear (kappa ≥0.75 target, 0.70 floor), and analysis plan is finalized and publicly registered.

**Responsible Body/Role:** Steering Committee with Psychometrician and Metrics & Validation Committee

**Suggested Timeframe:** Month 11 (2027-09-13)

**Key Outputs/Deliverables:**

- Steering Committee checkpoint-meeting minutes: pre-registration review, gate-condition checklist completed, Phase 2 green light confirmed

**Dependencies:**

- Pre-analysis plan registered by Month 11 (2027-09-13)
- Inter-rater training completed and documented
- Dry-run of tools completed without major issues

### 63. Project Lead and Steering Committee hold the Phase 1 exit meeting at Month 12 (2027-10-13) to confirm that all Phase 1 deliverables are complete and Phase 2 can begin: (1) Clear English Standard v1.0 published; (2) 5,000-word lexicon with audio recordings usable; (3) pre-analysis plan pre-registered; (4) inter-rater reliability ≥0.70 floor confirmed; (5) ethics/IRB approval in hand; (6) pilot partnership agreements signed; (7) assessment instruments finalized; (8) Critical Path Dashboard showing Phase 2 readiness.

**Responsible Body/Role:** Steering Committee with Project Lead

**Suggested Timeframe:** Month 12 (2027-10-13)

**Key Outputs/Deliverables:**

- Phase 1 exit meeting minutes: all gate conditions verified, Phase 2 formally authorized to proceed, Project Lead briefed on Phase 2 milestones

**Dependencies:**

- All Phase 1 deliverables substantially complete

### 64. Project Lead and Cohort Manager begin pilot recruitment at the partner sites, targeting enrollment of ≥115 learners per arm (4 arms total, ~460 learners estimate) with ≤30% target dropout, by Month 13 (2027-11-13); distribute learner-information packets, obtain informed consent, distribute incentives and certificates to encourage completion.

**Responsible Body/Role:** Cohort Manager with pilot partner sites

**Suggested Timeframe:** Months 13-14 (2027-11-13 to 2027-12-13, enrollment complete by Month 13 = 2027-11-13)

**Key Outputs/Deliverables:**

- Pilot enrollment summary (learners per site, per arm, demographic profile)
- Signed informed-consent forms (all learners)
- Participant incentive and certificate-distribution records

**Dependencies:**

- Pilot partnership agreements signed
- IRB approval finalized
- Cohort Manager in role

### 65. Metrics & Validation Committee conducts a mid-phase validity audit by an independent external auditor (Month 18-22 = 2028-04-13 to 2028-08-13), examining pilot data for: (1) inter-rater reliability (kappa trends, scorer drift); (2) construct validity (confound analysis, effect-size checks); (3) data integrity (missing files, outliers, consent violations); (4) compliance with pre-registered analysis plan. Report findings to Steering Committee by Month 23 (2028-09-13).

**Responsible Body/Role:** Metrics & Validation Committee with external independent auditor

**Suggested Timeframe:** Months 18-23 (2028-04-13 to 2028-09-13)

**Key Outputs/Deliverables:**

- Mid-phase validity audit report (inter-rater reliability findings, effect-size preliminary results, data-quality issues identified, remediation recommendations)

**Dependencies:**

- Pilot running for ≥6 months (Month 18 = 2028-04-13 check occurs mid-Phase 2)
- Preliminary data available for audit

### 66. Steering Committee holds a Phase 2 midpoint checkpoint meeting (Month 18 = 2028-04-13) to review pilot enrollment, retention, preliminary data quality, and any validity or operational issues; adjust Phase 2 timeline or scope if major problems identified; recommend any remediation (additional rater training, extended follow-up).

**Responsible Body/Role:** Steering Committee with Metrics & Validation Committee and Project Lead

**Suggested Timeframe:** Month 18 (2028-04-13)

**Key Outputs/Deliverables:**

- Phase 2 midpoint checkpoint-meeting minutes: enrollment status, retention rate, preliminary data quality, validity issues if any, recommended remediation

**Dependencies:**

- Pilot running, enrollment complete, ≥6 months of data available

### 67. Compliance & Risk Management Committee reviews the Risk Register quarterly (Months 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36 = 2027-01-13 onwards), assessing mitigation progress, emerging risks, and escalation status; generate a summary risk dashboard for Steering Committee review at each quarterly gate checkpoint.

**Responsible Body/Role:** Compliance & Risk Management Committee

**Suggested Timeframe:** Quarterly (Months 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36 = 2027-01-13 onwards)

**Key Outputs/Deliverables:**

- Quarterly Risk Register update (status of mitigation actions, newly identified risks, high-severity risks escalated)
- Risk dashboard summary (2-3 pages, risk-heatmap by domain, key escalations, overall risk posture)

**Dependencies:**

- Risk Register maintained monthly
- Quarterly checkpoint meetings scheduled with Steering Committee

### 68. Project Lead and Compliance & Risk Management Committee conduct a lexicon-coverage audit (Month 8 = 2027-06-13) of the 5,000-word core lexicon against pilot running-text materials and technical glossaries; confirm ≥85% coverage (proposed threshold) or identify gaps and prioritize expansion; if coverage <85%, allocate time and budget (~$30K-$50K estimate) for targeted lexicon expansion by Month 10 (2027-08-13).

**Responsible Body/Role:** Project Lead with Editorial Board (lexicon subcommittee)

**Suggested Timeframe:** Month 8 (2027-06-13)

**Key Outputs/Deliverables:**

- Lexicon coverage audit report (% of running text in pilot materials and ESL curricula, gap analysis by domain)
- If coverage <85%: targeted expansion plan (words added, pronunciation recorded, timeline to Month 10 = 2027-08-13)

**Dependencies:**

- 5,000-word lexicon substantially finalized
- Pilot materials identified

### 69. Compliance & Risk Management Committee identifies 2-3 potential permanent steward organizations (language-education non-profits, university consortiums, international standards bodies) and approaches them by Month 27 (2029-01-13) with a stewardship proposal (estimated $150K-$250K per year for ongoing maintenance and governance); secure written commitment by Month 33 (2029-07-13) before v1.0 public release.

**Responsible Body/Role:** Compliance & Risk Management Committee (Chair or Stakeholder Engagement Lead) with Project Lead

**Suggested Timeframe:** Months 24-33 (2028-10-13 to 2029-07-13)

**Key Outputs/Deliverables:**

- Steward-organization identification and outreach (proposal letter, governance model, funding needs)
- Stewardship commitment letters from at least one organization by Month 33 (2029-07-13)

**Dependencies:**

- Phase 2 go/no-go decision completed (Month 24 = 2028-10-13)
- Stewardship funding model defined and budgeted

### 70. Steering Committee holds the Phase 2 go/no-go decision meeting (Month 24 = 2028-10-13): review final pilot data, validity-audit findings, all four gate metrics against pre-registered thresholds, and statistical significance; determine GO (all thresholds met, data valid, n≥80 completers per arm, kappa ≥0.70, follow-up ≥70% complete) or NO-GO (any metric fails threshold or data invalid); document decision rationale and next steps for Phase 3.

**Responsible Body/Role:** Steering Committee with Psychometrician, Metrics & Validation Committee, and Editorial Board (for rule implications)

**Suggested Timeframe:** Month 24 (2028-10-13)

**Key Outputs/Deliverables:**

- Go/no-go decision meeting minutes: metric results tabulated, threshold comparisons, validity-audit recommendations reviewed, final decision recorded with rationale
- If GO: Phase 3 authorization approved, v1.0 release timeline and stewardship-funding readiness confirmed
- If NO-GO: documented reasons, options for extension/rework, or project closeout decision

**Dependencies:**

- All pilot data collected and analyzed (data lock by Month 22 = 2028-08-13)
- Validity audit completed (Month 23 = 2028-09-13)
- Pre-analysis plan adhered to

### 71. If Phase 2 go/no-go is GO (Month 24 = 2028-10-13), Steering Committee authorizes Phase 3 (v1.0 public release and limited adoption) and confirms stewardship-funding commitment is in place before v1.0 release (Month 30 = 2029-04-13); Project Lead begins Phase 3 planning (curriculum finalization, publisher outreach, marketing materials).

**Responsible Body/Role:** Steering Committee with Project Lead

**Suggested Timeframe:** Month 24 (2028-10-13) onwards

**Key Outputs/Deliverables:**

- Phase 3 authorization memo (stewardship commitment confirmed, release timeline locked, governance transition plan to steward organization begun)

**Dependencies:**

- Phase 2 go/no-go = GO

### 72. If Phase 2 go/no-go is NO-GO (Month 24 = 2028-10-13), Steering Committee documents the reasons, considers options for a limited Phase 2 extension (3-6 months, ~$300K-$600K estimate, not budgeted pre-gate), rework of identified rule weaknesses, or project closeout; all Phase 3 funds ($0.85M) and remaining reserve (~$175K or more, depending on pre-gate draws) are held or returned to Funding Authority.

**Responsible Body/Role:** Steering Committee with Project Sponsor and Funding Authority

**Suggested Timeframe:** Month 24 (2028-10-13) onwards

**Key Outputs/Deliverables:**

- No-go decision memo: reasons for gate failure, options analysis (extension vs. closeout), recommendation to Funding Authority

**Dependencies:**

- Phase 2 go/no-go = NO-GO

### 73. Project Lead and Compliance & Risk Management Committee establish a Standards Stewardship Committee (separate from the Phase 1-3 Editorial Board) with 3-5 members (representing steward organization, Editorial Board, and key adopters), formal decision authority, published charter and meeting schedule by Month 30 (2029-04-13), to govern the standard post-Phase-3.

**Responsible Body/Role:** Project Lead with Steward Organization (if Phase 2 GO)

**Suggested Timeframe:** Months 30-36 (2029-04-13 to 2029-10-13)

**Key Outputs/Deliverables:**

- Standards Stewardship Committee Charter (governance, decision authority, annual review process, change-request procedures)
- Stewardship Committee membership confirmed
- Published 5-year stewardship roadmap (how standard will be updated, change-request prioritization, conflict-resolution procedures)

**Dependencies:**

- Phase 2 go/no-go = GO
- Stewardship-organization commitment letters received

### 74. Project Lead publishes the final Clear English Standard v1.0, reference dictionary, style guide and associated licensing/conformance documentation (if certification mark model chosen) by Month 30 (2029-04-13), conditional on a written steward-organization commitment; begin limited-scope Phase 3 adoption (Months 30-36 = 2029-04-13 to 2029-10-13).

**Responsible Body/Role:** Project Lead with Editorial Board and Steward Organization

**Suggested Timeframe:** Month 30 (2029-04-13)

**Key Outputs/Deliverables:**

- Clear English Standard v1.0 (final published version, with pilot validation evidence and go/no-go gate decision documented)
- Reference dictionary (5,000 entries, pronunciations, mappings to standard English, examples)
- Style guide (application of ordinals, homograph markers, morphology rules, G2P guidance)
- Open licenses and/or certification-mark documentation
- Published go/no-go gate report (metrics achieved, evidence summary, implications for adoption)

**Dependencies:**

- Phase 2 go/no-go = GO
- Stewardship-organization commitment and funding in place