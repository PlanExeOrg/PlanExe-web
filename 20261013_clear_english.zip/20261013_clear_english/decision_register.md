**5 open decisions: 4 high and 1 medium severity.** The safety-cohort fallback (Month 4 = 2027-02-13) and baseline study form (Month 1 = 2026-11-13) are the most urgent, since they shape the Month 3 (2027-01-13) partner gate and the 4-arm design. The reserve waterfall should be settled by Month 6 (2027-04-13), and the steward fallback and steward funding before Month 27 (2029-01-13). Until then the plan can proceed on canonical values: Phase 1 rule drafting, lexicon, board setup and counsel retention.

| # | Decision | Severity | Owner | Decide by | Blocks |
|---|---|---|---|---|---|
| 1 | Reserve waterfall | 🔴 High | Project Sponsor and Funding Authority, on Steering Committee recommendation | Month 6 (2027-04-13), before the pre-registration and enrolment commitments that set Phase 2 exposure. | Phase 1 exit (Month 12 = 2027-10-13) and the Month 24 (2028-10-13) inconclusive-data branch. |
| 2 | Safety-cohort fallback | 🔴 High | Steering Committee with Compliance & Risk Management Committee; Sponsor if budget changes | Month 4 (2027-02-13) (liability strategy and written regulator advice), before Phase 2 design is registered. | Phase 1 exit gate (Month 12 = 2027-10-13) and pre-registration (Month 11 = 2027-09-13). |
| 3 | Steward fallback rule | 🔴 High | Project Sponsor and Funding Authority | Month 27 (2029-01-13), before MOU negotiation (Months 27-30 = 2029-01-13 to 2029-04-13). | v1.0 release (Month 30 = 2029-04-13) and Phase 3 closeout. |
| 4 | Steward funding from project budget | 🔴 High | Project Sponsor and Funding Authority | Month 12 (2027-10-13), so candidate stewards see terms in the candidate brief. | Steward MOU (Month 30 = 2029-04-13) and v1.0 release. |
| 5 | Baseline study form | 🟡 Medium | Steering Committee with Compliance & Risk Management Committee and the psychometrician | Month 1 (2026-11-13), before any learner contact. | Month 3 (2027-01-13) partner and dropout gate. |

## 1. Reserve waterfall (🔴 High)

**Decision:** How is the $0.35M reserve ranked and released across pre-gate protection, a Phase 2 extension after inconclusive data, Phase 3 top-up and Phase 2.5?

**Why it is open:** Canonical rule caps pre-gate draws at $175K and releases the balance only after a Month 24 (2028-10-13) GO. Reviews charge a $300K-$600K extension and Phase 2.5 to the 'entire reserve', which an inconclusive result cannot release.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Board may release a defined part of the post-gate balance for a validated extension without a GO. | Extension of up to about $175K becomes fundable; still below a 3-month extension ($300K) unless Phase 3 underspend adds. Weakens the gate-protection of funds. | reserve_draw_rule; gate_funds_at_risk; Reviews 1, 2, 4, 5, 10. |
| B. Cap any extension at what the $175K pre-gate cap and Phase 3 underspend can cover. | Extension limited to a shorter period than 3-6 months; the reserve order is fixed and no Phase 2.5 is funded. | phase2_extension_fallback; free_reserve_after_fallbacks. |
| C. Treat extension as unfunded; require descoping or termination. | Keeps the reserve rule intact; inconclusive data leads to descope or wind-down, with up to $1.2M returnable. | phase2_go_no_go_rule wording; extension text in reviews. |

- **If nobody decides:** Canonical rule applies: no post-gate release without a GO, so an extension is unfunded.
- **Owner:** Project Sponsor and Funding Authority, on Steering Committee recommendation
- **Decide by:** Month 6 (2027-04-13), before the pre-registration and enrolment commitments that set Phase 2 exposure.
- **Blocks:** Phase 1 exit (Month 12 = 2027-10-13) and the Month 24 (2028-10-13) inconclusive-data branch.

## 2. Safety-cohort fallback (🔴 High)

**Decision:** If safety-critical pilots cannot proceed, does the gate become an ESL-only 2-arm design, or is the technical cohort deferred to a Phase 2.5?

**Why it is open:** Canonical design is 4 arms and 320 completers. Reviews defer the cohort after 4 or 6 months and date regulator advice at Month 4, 6 or 8 (2027-02-13, 2027-04-13, 2027-06-13).

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. ESL-only 2-arm gate (160 completers), technical cohort non-gating. | Keeps Month 24 (2028-10-13) gate timing; narrows evidence to ESL; re-register validity conditions; lowers enrolment and participant costs. | pilot_design; pilot_min_completers; pilot_enrolment_and_dropout; pitch claims. |
| B. Defer the technical cohort to a Phase 2.5 after Month 24 (2028-10-13). | Needs funding outside the current budget; the gate rests on ESL arms; safety benefit claims remain unvalidated at gate. | pilot_design; phase3_budget; adoption_wedge. |
| C. Hold the 4-arm gate and delay the gate until approval is secured. | Pilot window shrinks or the gate slips past Month 24 (2028-10-13); extension cost of $85K-$170K per 4-8 weeks (estimate). | pilot_schedule; safety_limits; budget. |

- **If nobody decides:** At Month 4 (2027-02-13) with no written counsel and regulator advice, the technical cohort is cancelled or deferred and ESL-only runs, with unregistered validity conditions.
- **Owner:** Steering Committee with Compliance & Risk Management Committee; Sponsor if budget changes
- **Decide by:** Month 4 (2027-02-13) (liability strategy and written regulator advice), before Phase 2 design is registered.
- **Blocks:** Phase 1 exit gate (Month 12 = 2027-10-13) and pre-registration (Month 11 = 2027-09-13).

## 3. Steward fallback rule (🔴 High)

**Decision:** If no steward MOU is signed by Month 30 (2029-04-13), is v1.0 cancelled at Month 33 (2029-07-13), or may release be deferred beyond Month 36 (2029-10-13) with funding?

**Why it is open:** FM4 cancels at Month 33 (2029-07-13). Reviews 5, 6, 9, 14 and Self-audit 20 allow deferral to Month 36 (2029-10-13) or later, outside the funded program.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Cancel and archive at Month 33 (2029-07-13) if unsigned. | Hard stop; no unfunded tail; the adopter target by Month 36 (2029-10-13) is likely missed. | v1_release; Reviews 5, 6, 9, 14; Self-audit 20. |
| B. Allow a funded deferral beyond Month 36 (2029-10-13). | Requires a funder for the team (cost not set); re-date the adopter target. | program_structure; adoption_target; total_budget. |

- **If nobody decides:** FM4 applies: release not triggered; v1.0 is cancelled at Month 33 (2029-07-13) and materials are archived.
- **Owner:** Project Sponsor and Funding Authority
- **Decide by:** Month 27 (2029-01-13), before MOU negotiation (Months 27-30 = 2029-01-13 to 2029-04-13).
- **Blocks:** v1.0 release (Month 30 = 2029-04-13) and Phase 3 closeout.

## 4. Steward funding from project budget (🔴 High)

**Decision:** Does the steward receive any project money (reserve or Phase 3 underspend), or is stewardship funded entirely externally?

**Why it is open:** Pitch states the steward receives the $0.35M reserve plus pro-rata Phase 3 funding. The plan treats $150K-$250K per year (estimate) as unfunded; the reserve is also claimed elsewhere.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Steward receives nothing from the project budget. | Reserve remains for the gate and extension; steward must find $150K-$250K per year (estimate) externally, raising the Month 30 (2029-04-13) MOU risk. | Pitch Collaboration Opportunities. |
| B. Fixed capped seed from unspent Phase 3 or reserve, ranked after gate protection and extension. | Improves MOU odds; only available after a GO; needs a stated cap. | reserve_draw_rule; stewardship_funding_gap; pitch. |
| C. Funding entirely external (consortium or funder). | Project funds untouched; adds funder outreach work before Month 24 (2028-10-13). | stewardship_funding_gap; outreach plan. |

- **If nobody decides:** The pitch transfer is removed; stewardship stays an unfunded gap.
- **Owner:** Project Sponsor and Funding Authority
- **Decide by:** Month 12 (2027-10-13), so candidate stewards see terms in the candidate brief.
- **Blocks:** Steward MOU (Month 30 = 2029-04-13) and v1.0 release.

## 5. Baseline study form (🟡 Medium)

**Decision:** In what form is the dropout baseline study run: with ethics approval first, as a non-participant evidence review, or after Month 6 (2027-04-13)?

**Why it is open:** The study (20-30 learners, Months 1-2 = 2026-11-13 to 2026-12-13) precedes ethics approval (Month 6 = 2027-04-13), consent forms and partner signatures (Month 3 = 2027-01-13), and cannot observe 30-day or 12-month dropout.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Obtain ethics exemption or approval before starting, with consent and partner agreement first. | Real data, but the start slips beyond Months 1-2 (2026-11-13 to 2026-12-13); Month 3 (2027-01-13) retargeting is at risk. | Compliance actions; Month 3 (2027-01-13) retargeting date. |
| B. Non-participant evidence review of partner attrition and literature in Months 1-3 (2026-11-13 to 2027-01-13). | No ethics issue; weaker evidence; fits Month 3 (2027-01-13) gate. | Risk 1; Reviews 3, 8; Premortem A3. |
| C. Move the study after Month 6 (2027-04-13) and drop the 30-day/12-month claim. | Late input to the Month 12 (2027-10-13) enrolment audit; Month 3 (2027-01-13) dropout threshold of 35% cannot be tested. | pilot_partner_commitments gate evidence; Month 3 (2027-01-13) deadline. |

- **If nobody decides:** The study is not run before Month 3 (2027-01-13); the dropout test uses partner-history evidence only.
- **Owner:** Steering Committee with Compliance & Risk Management Committee and the psychometrician
- **Decide by:** Month 1 (2026-11-13), before any learner contact.
- **Blocks:** Month 3 (2027-01-13) partner and dropout gate.

## Choices made on your behalf

Set when the scenario was selected, not by you. Confirm or change them.

| Lever | Chosen | Strongest alternative | Why it matters | Revisit by |
|---|---|---|---|---|
| Ordinal Marker Architecture | Numeric ordinals with an invariant prefix marker; legacy forms accepted and mechanically convertible. | Fully spelled ordinals with a single regular -th ending (Pioneer's Gambit). | Sets the ordinal-error metric and converter ambiguity risk (at most 5% ambiguous (proposed threshold)). | Month 8 (2027-06-13) (ordinal lock) / Month 10 (2027-08-13) kappa check |
| Grapheme-to-Phoneme Intervention Depth | Standard spellings unchanged; optional software-generated pronunciation overlay, printed key in print. | Respell a ranked shortlist of high-friction patterns (Pioneer's Gambit). | Drives how much pronunciation consistency can improve against the +15% gate. | Month 12 (2027-10-13) rules lock |
| Adoption Wedge and Sequencing | Adult ESL programs and publishers first, as a supplementary module; technical cohort secondary. | Free reader-facing site and browser toggle before institutions commit. | Determines who must sign by Month 3 (2027-01-13) and the pilot recruitment path. | Month 3 (2027-01-13) partner gate |
| Outcome Metric Battery Design | Purpose-built assessments for each of four metrics, with independent psychometrician review. | Off-the-shelf validated instruments (Prudent Consolidator) or passive logging. | Sets gate credibility and the $150K-$200K (estimate) psychometrics cost. | Month 5 (2027-03-13) power analysis |
| Phase Budget Weighting and Reserve | Roughly even phase split ($1.1M / $1.2M / $0.85M) with a $0.35M board-held reserve released after GO. | Large staged contingent tranche released against milestones, or a lean Phase 1 weighted to Phase 2. | Controls Phase 1 resourcing and funds at risk at the Month 24 (2028-10-13) gate. | Month 12 (2027-10-13) Phase 1 exit |
