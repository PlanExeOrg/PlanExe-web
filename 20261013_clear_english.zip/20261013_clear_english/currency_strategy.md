This plan involves money.

## Currencies

- **USD:** Primary currency for the $3.5M budget constraint specified by the user. All budget splits across three phases, staff salaries, pilot assessments, print curriculum production and outreach travel will be denominated in USD for consolidated reporting.
- **GBP:** Relevant for Location 1 (Cambridge/Oxford area, England). If the editorial board, linguistic review, or any portion of pilot cohorts are situated in the UK, local spending on office space, ESL school partnerships, publisher meetings and assessment administration will occur in GBP.
- **EUR:** Relevant if outreach expands to European standards bodies, ESL publishers or applied linguistics networks. Safety-critical documentation adoption may involve coordination with European regulatory bodies or technical-writing organizations where EUR transactions occur.

**Primary currency:** USD

**Currency strategy:** All budgeting and financial reporting will be conducted in USD, aligning with the fixed $3.5M constraint. Phase splits and milestone payments will be tracked in USD. For operations in the UK (Location 1 option), GBP exchange rates should be locked at contract signature to avoid variance in office, partner and pilot costs; a modest contingency (2–3% of UK-based spending) is recommended to absorb currency fluctuation. If outreach to European standards bodies or ESL publishers occurs in Phase 3, EUR spending should be pre-approved and capped as a percentage of outreach budget. No hedging instruments are necessary given the modest scale and the administrative burden they impose on a small team; instead, fixed-rate agreements with vendors and partners will be prioritized to minimize exchange-rate surprise.