### 1. Project Steering Committee

**Rationale for Inclusion:** The Clear English program is a 36-month, $3.5M initiative spanning rule specification, pilot design, gate metrics, recruitment and public release across multiple stakeholder groups (educators, publishers, regulators, learners). Strategic decisions on ordinal architecture, G2P depth, adoption wedge, outcome metrics and phase budget allocation directly shape evidence credibility and adoption likelihood. The Steering Committee provides high-level oversight of these critical strategic levers, monitors phase-gate readiness, arbitrates resource conflicts across phases, and ensures alignment with the adoption-first, evidence-gated mandate and no-mandate, no-K12-replacement constraints.

**Responsibilities:**

- Approve the five critical strategic levers (Ordinal Architecture, G2P Depth, Adoption Wedge, Outcome Metric Battery, Phase Budget Weighting) and reconcile tensions between rule ambition and adoption
- Monitor phase-gate readiness (Month 12 = 2027-10-13 rules lock, Month 24 = 2028-10-13 go/no-go metrics): confirm pre-registration of thresholds, validity audit findings, and pilot enrollment/retention targets
- Authorize draws from the $175K pre-gate contingency reserve for gate-protection needs (psychometric re-validation, Phase 1 timeline extension); recommend to the Editorial Board for post-gate reserve release
- Escalate unresolved editorial board disputes (rule deadlock, governance conflict) to an external arbiter and make final strategic decision if arbiter is impeded
- Review quarterly stakeholder alignment assessments and adjust messaging or phase scope if adoption risks (educator pushback, publisher capacity, regulatory delays) exceed mitigation thresholds

**Initial Setup Actions:**

- Appoint Steering Committee chair and confirm 5–7 core members (project lead, finance lead, external academic partner, one ESL publisher representative, one standards-body advisor) by Month 1 (2026-11-13)
- Publish Steering Committee Charter specifying decision authority, voting rules, escalation paths, and meeting schedule by Month 1 (2026-11-13)
- Confirm the five strategic-lever choices (approved in the 'Pragmatic Foundation' scenario) with explicit written rationale and trade-off documentation by Month 2 (2026-12-13)
- Establish a Critical Path Dashboard with phase milestones, resource allocation and go/no-go gate conditions; review monthly and escalate slips >2 weeks by Month 1 (2026-11-13)
- Schedule phase-gate checkpoint meetings: Month 11 (2027-09-13) pre-registration review, Month 18 (2028-04-13) midpoint check, Month 23 (2028-09-13) validity audit review, Month 24 (2028-10-13) go/no-go decision

**Membership:**

- Project Lead (internal, full-time)
- Finance Lead / Budget Controller (internal, 0.5–1.0 FTE)
- Editorial Board Chair (internal, overlapping role to align rule and resource decisions)
- External Academic Partner (university applied linguistics or standards program, advisory role, ~4 hours/month)
- Psychometrician or Assessment Lead (internal, hired Month 2 = 2026-12-13, represents measurement credibility and validity)
- ESL Publisher Representative (external, non-binding advisory; input on adoption wedge viability)
- Standards Body Advisor (external, e.g., TESOL, IATEFL representative; input on regulatory and adoption landscape)

**Decision Rights:** Strategic decisions with financial impact >$50K (equipment, vendor contracts, Phase-wide re-scoping, reserve draws up to $175K pre-gate limit); authorization of phase-gate transitions and go/no-go timing adjustments; approval of escalation paths to external arbiter for rule deadlock. Decisions delegated to the Editorial Board: ordinal marker pronunciation specifics, morphology retention-threshold tuning, homograph-pair list prioritization, individual rule rationale. Budget authority: Steering Committee approves spending within Phase allocations; requests exceeding phase budget or drawing >$50K from reserve require Steering Committee vote.

**Decision Mechanism:** Steering Committee quorum: 5 of 7 members. Standard decision rule: consensus or simple majority (>50%) with brief documented rationale. Tie-breaker: Project Lead holds a tie-breaking vote. Escalation: if Steering Committee cannot reach consensus on a strategic lever (e.g., adoption wedge sequencing, gate-threshold stringency), the matter is escalated to a neutral External Arbiter (appointed by Month 5 = 2027-03-13, TBD per Editorial Board Charter) for binding recommendation to the Committee within 2 weeks.

**Meeting Cadence:** Monthly standing meetings (first Tuesday of each month, 2 hours); additional checkpoint meetings at Months 11 (2027-09-13), 18 (2028-04-13), 23 (2028-09-13) (90 minutes each) for gate readiness reviews. Ad-hoc emergency meetings called by the Project Lead if any critical-path item slips >2 weeks or a budget variance >$50K is discovered.

**Typical Agenda Items:**

- Phase milestone status and critical-path variance (rules finalization, audio completion, recruitment, pre-registration, analysis)
- Monthly spend report: actual vs. budgeted by line item (staff, assessment, audio, curriculum, partner costs); cumulative variance and forecast; contingency-reserve balance
- Stakeholder alignment and adoption-risk assessment: educator pushback signals, publisher engagement, regulatory clearance status, pilot partner enrollment progress
- Governance and rule-decision log: summary of Editorial Board decisions from prior month, any deadlocks escalated, arbiter recommendations
- Gate readiness: validity audit findings (kappa, construct validity, confounds), pilot data quality, analysis-plan adherence, thresholds locked

**Escalation Path:** Unresolved strategic disputes (e.g., rule deadlock, adoption-wedge timing, reserve-draw disputes) are escalated to a neutral External Arbiter appointed jointly by the Steering Committee and Editorial Board by Month 5 (2027-03-13). The arbiter's recommendation is binding unless both the Steering Committee and Editorial Board formally object within 5 business days. If both reject the arbiter's recommendation, the matter escalates to the program's Funding Authority (granting body or institutional sponsor) for final decision. Post-Month-36 stewardship funding gaps trigger escalation to a designated Steward-Search Lead appointed by Month 24 (2028-10-13).
### 2. Editorial Board and Linguistic Review Panel

**Rationale for Inclusion:** Clear English rules must be specific, defensible, and internally consistent to serve as a credible reference for pilots, third-party adopters and educators. The Editorial Board is responsible for finalizing ordinal marker pronunciation, morphology retention thresholds, homograph-disambiguation policy, core-lexicon selection basis, and rule exceptions. The Board also logs all decisions with explicit rationale, resolves internal conflicts over linguistic priorities (consistency vs. usability), and manages the draft-standard 30-day public comment window. A Linguistic Review Panel (embedded within the Board) provides formal review-and-veto authority on rule ambiguities and contradictions, protecting against drift or oversimplification that would compromise the standard's reference value. This separation of editorial authority from strategic steering ensures that rule quality is not subordinated to adoption or budget pressures.

**Responsibilities:**

- Finalize all rule specifications (ordinal marker pronunciation, G2P mapping logic, morphology retention threshold, homograph-pair list, core-lexicon selection basis and exceptions) by Month 11 (2027-09-13) with explicit published rationale for each rule and for any exceptions or boundary cases
- Manage the Linguistic Review Panel: linguist members conduct formal ambiguity-and-contradiction review of proposed rules; veto authority is limited to findings of logical inconsistency, circularity or lack of publishable justification; no veto on rule choice itself
- Maintain a Decision Log: document all rule decisions, voting outcomes, dissenting opinions and the rationale for each outcome, updated within 3 business days of each board meeting; publish quarterly (Months 3, 6, 9, 12 = 2027-01-13, 2027-04-13, 2027-07-13, 2027-10-13)
- Conduct conflict resolution and tiebreaker escalation per the published Editorial Board Charter; invite formal linguist review for any deadlocked rule before escalation to the external arbiter
- Oversee the draft-standard 30-day public comment window (Month 11–12 = 2027-09-13 to 2027-10-13): publish the draft, manage comment submissions, respond in writing to all substantive comments, and publish responses with the final v1.0 rule set
- Commission and review all rule-related studies or evidence (e.g., native-speaker acceptance of ordinal forms, misread rates on homograph pairs during pilots) and integrate findings into rule tuning before v1.0 lock

**Initial Setup Actions:**

- Publish Editorial Board Charter by Month 1 (2026-11-13): composition (7–9 members; practitioner-leaning with linguist review-and-veto), voting rules (consensus or simple majority, with explicit tie-breaker), conflict-of-interest disclosure template, and decision-logging protocol
- Confirm board membership by Month 1 (2026-11-13): recruit 4–5 practitioners (ESL instructors, technical writers, safety trainers), 2–3 linguists (applied linguistics, morphology/phonology specialists), and optionally 1 learner representative; document conflict-of-interest attestations
- Appoint or confirm the external Arbiter by Month 5 (2027-03-13): independent linguist or standards-design specialist with no financial stake in ESL publishing or standards bodies; agree on fee ($10K–$20K estimate) and availability for 2-week turnaround on escalations
- Hold the first Editorial Board meeting by Month 2 (2026-12-13) to surface rule-specification tensions and assign workstreams (ordinal, morphology, homograph, lexicon, pronunciation-guidance logic) to subcommittees; set internal deadlines for rule drafts (Month 6 = 2027-04-13)
- Establish and staff a Linguistic Review Panel: designate 2–3 board linguists to form a standing subcommittee; schedule monthly 90-minute review meetings Months 5–11 (2027-03-13 to 2027-09-13) to examine proposed rules for ambiguity and contradiction before board vote

**Membership:**

- Editorial Board Chair (internal, practitioner or linguist with governance experience, 0.5 FTE)
- Practitioners (4–5 members, internal or closely affiliated): adult ESL instructors (2), technical writer or safety-training specialist (1–2), representing classroom and safety-critical contexts where rules will be applied
- Linguists (2–3 members, internal or university-affiliated): specialists in morphology, phonology, or applied linguistics; formal veto authority on rule ambiguity and contradiction; at least one with standards-development experience
- Learner Representative (optional, 1 member): adult ESL learner or recent graduate who can speak to rule comprehensibility and usability from the learner perspective; attends selected meetings and is consulted on rule clarity before public comment
- Psychometrician or Assessment Specialist (liaison, internal, ~2 hours/month): provides data on rule effects from validity studies and pilot midpoints; informs rule tuning based on evidence (e.g., ordinal error rates, comprehension confounds)

**Decision Rights:** Full decision authority over all rule specifications, thresholds and exceptions; all rule decisions are final once the Decision Log entry is signed by the Chair and published. The Linguistic Review Panel may veto a rule only if it finds the rule to be internally contradictory, logically circular, or lacking a publishable justification; such vetoes are documented in the Decision Log and escalated to the full board for revision or dispute resolution. The board may not override the Steering Committee's strategic-lever decisions (e.g., the choice of prefix ordinals, optional pronunciation overlay, ESL-first wedge) but may propose refinements or implementation guidance to the Steering Committee if rule-specification work reveals unforeseen conflicts. The board controls the draft-standard comment window process and may integrate substantive public feedback into rule clarification, but core rules cannot be reopened except post-v1.0 via formal Change-Control procedures.

**Decision Mechanism:** Simple majority voting (>50% of present members); quorum: 5 of 7–9 members. Consensus is sought as the default, but if consensus cannot be reached, a majority vote decides. Linguistic Review Panel veto on ambiguity/contradiction is binding unless the full board overrides it by supermajority (2/3 of present members). If a supermajority override is invoked, the dissenting linguist opinions are documented in the Decision Log and published with the final rule. Tie-breaker: the Board Chair casts the tie-breaking vote if voting is deadlocked; if the Chair is conflicted, an external Arbiter is called to cast the tie-breaker within 2 weeks.

**Meeting Cadence:** Monthly full Editorial Board meetings (second Thursday of each month, 2 hours); Linguistic Review Panel subcommittee meetings monthly (fourth Thursday, 90 minutes) during Months 5–11 (2027-03-13 to 2027-09-13); additional subcommittee workstreams (ordinal, morphology, homograph, lexicon) meet biweekly (1.5 hours) Months 2–10 (2026-12-13 to 2027-08-13) to draft and refine rules. Emergency Board meetings convened by the Chair if an escalated dispute or public comment requires urgent resolution.

**Typical Agenda Items:**

- Rule-specification progress reports from subcommittees: ordinal-marker pronunciation logic, morphology retention threshold rationale, homograph-pair selection and enforcement policy, core-lexicon selection basis and coverage audit findings
- Linguistic Review Panel findings: ambiguities or contradictions identified in proposed rules; revision proposals or escalation requests
- Conflict resolution and tiebreaker decisions: documented disagreements from prior meetings and the board's resolution
- Public comment review (Month 11–12 = 2027-09-13 to 2027-10-13): summary of substantive comments and project responses; integration of feedback into rule clarifications
- Integration of pilot data (Month 18 = 2028-04-13 onwards): preliminary ordinal error rates, comprehension speed, pronunciation-consistency findings; implications for rule tuning or exception-list updates before v1.0 lock

**Escalation Path:** Unresolved rule disputes between practitioners and linguists are escalated to the external Arbiter within 5 business days of a failed board vote; the Arbiter has 2 weeks to make a binding recommendation on how to resolve the conflict (e.g., adopt a minority rule position, refine the rule to address both perspectives, defer the decision to pilot evidence). If the Arbiter's recommendation is rejected by both the Steering Committee and Editorial Board, the matter escalates to the Funding Authority. Disputes over whether a rule is ambiguous/contradictory (triggering Linguistic Review veto) are escalated to the Arbiter if the full board cannot resolve the veto by supermajority override within 2 weeks. Substantive public comments during the Month 11–12 (2027-09-13 to 2027-10-13) comment window that challenge rule validity are triaged by the Editorial Board; if unresolved, a representative comment is escalated to the Arbiter for a recommendation on whether the rule should be revised before v1.0 finalization.
### 3. Metrics & Validation Committee

**Rationale for Inclusion:** The Month 24 (2028-10-13) go/no-go gate depends entirely on the credibility of four pre-registered, psychometrically sound outcome metrics (ordinal error rate, comprehension speed, pronunciation consistency, 30-day retention). Any weakness in instrument design, inter-rater reliability, construct validity, confound control or data integrity directly undermines the gate decision and risks a false-positive (weak standard launched, damaging long-term credibility) or false-negative (viable standard rejected, stranding Phase 3 and damaging adoption). The Metrics & Validation Committee ensures that instruments are purpose-built and independently validated, that validity assumptions are tested, that measurement procedures are faithfully executed across pilots, and that any validity threats are identified early (Months 18–21 = 2028-04-13 to 2028-07-13) so remediation is possible before Month 24 (2028-10-13). This committee operates at arm's length from the Editorial Board and Steering Committee to maintain measurement impartiality.

**Responsibilities:**

- Design the four gate metrics (ordinal error rate, comprehension speed, pronunciation consistency, 30-day retention) with explicit construct validity analysis; draft the pre-analysis plan specifying quantitative pass/fail thresholds, primary and secondary outcomes, confound-control procedures and manipulation checks by Month 5 (2027-03-13)
- Commission an independent validity study (N=20–30 learners) in Months 10–11 (2027-08-13 to 2027-09-13) to calibrate instruments and confirm that they discriminate between Clear English and standard-English conditions; publish findings in the pre-analysis plan
- Pre-register the analysis plan (metrics, thresholds, sample sizes, primary outcomes, analysis code) on a public repository (e.g., OSF) by Month 11 (2027-09-13), with explicit documentation of any post-hoc amendments or deviations
- Establish and monitor inter-rater reliability protocols: target Cohen's kappa ≥0.75 (proposed) for pronunciation consistency and ordinal-error scoring; conduct a calibration study by Month 11 (2027-09-13) and rater-training refreshers at Month 18 (2028-04-13) midpoint if kappa is dropping below 0.70
- Conduct a mid-phase validity audit at Months 18–22 (2028-04-13 to 2028-08-13) by an external independent auditor: examine pilot data for inter-rater reliability, construct validity (confound analysis, effect-size checks), data integrity (missing files, outliers, consent violations) and compliance with the pre-registered analysis plan; report findings to the Steering Committee by Month 23 (2028-09-13)
- Monitor measurement compliance during pilots: confirm that all assessments follow protocol, that data is securely stored with backups, that 30-day follow-up is tracked, and that participant dropouts are documented; quarterly data-quality reports to the Steering Committee

**Initial Setup Actions:**

- Hire an independent psychometrician (external or internal dedicated role) by Month 2 (2026-12-13); allocate $150K–$200K (estimate) for instrument design, validity study and inter-rater work
- Draft the Metrics & Validation Committee Charter by Month 2 (2026-12-13) specifying the Committee's authority (independent from Editorial Board and Steering Committee), decision procedures (consensus on technical validity), and escalation paths (validity threats escalate to Steering Committee within 48 hours)
- Establish the Committee membership by Month 3 (2027-01-13): psychometrician (Chair), 1–2 external applied-linguistics or measurement specialists (e.g., university faculty with publications on ESL assessment), data-integrity specialist or research-compliance officer (internal)
- Conduct a detailed construct-validity literature review and expert-panel discussion by Month 4 (2027-02-13): identify plausible confounds (repeated exposure, learner motivation, accent proximity, baseline literacy) and design explicit control conditions and manipulation checks to isolate Clear English effects
- Draft the pre-analysis plan (Months 4–5 = 2027-02-13 to 2027-03-13) and circulate for peer review to external measurement experts; incorporate feedback and finalize by Month 5 (2027-03-13)
- Design and conduct the validity-study protocol by Month 9–10 (2027-07-13 to 2027-08-13): recruit N=20–30 learners, administer Clear English and standard-English conditions, run preliminary analyses and publish findings in the pre-analysis plan by Month 11 (2027-09-13)

**Membership:**

- Psychometrician / Assessment Lead (internal, hired by Month 2 = 2026-12-13, Chair, 0.5–1.0 FTE dedicated to metrics and validation through Month 24 = 2028-10-13)
- External Measurement Specialist (e.g., university applied-linguistics researcher with ESL assessment publications, ~6 hours/month, advisory role to ensure independence from project bias)
- Data Integrity & Research Compliance Officer (internal, ~4 hours/month, ensures IRB adherence, data protection, consent and privacy protocols)
- Pilot Project Manager or Cohort Administrator (internal liaison, ~2 hours/month, provides data-quality updates and flags protocol deviations)

**Decision Rights:** Full authority over instrument design, validity analysis, data-quality standards and the pre-analysis plan; authority to halt or suspend pilots if data integrity is compromised or inter-rater reliability falls below the 0.70 floor for more than 2 weeks. May recommend changes to pilot protocol (e.g., additional rater training, modified assessment schedule, extended follow-up) to the Steering Committee; the Committee's recommendation is binding on pilot operations. May request extension of Phase 1 by up to 4 weeks (at ~$85K cost, estimate) if the validity study or inter-rater calibration requires additional time; Steering Committee must approve extensions >2 weeks. The Committee cannot override Editorial Board rule decisions but may flag to the Steering Committee if rule changes during Phase 2 pilots would invalidate previously calibrated instruments.

**Decision Mechanism:** Consensus on technical validity matters (instrument design, confound-control procedures, thresholds, analysis plan). If consensus cannot be reached, the Psychometrician (Chair) makes the final decision with documented rationale. Disagreements between the Psychometrician and external specialist are escalated to the Steering Committee if they affect go/no-go credibility (e.g., conflicting views on minimum sample size, effect-size interpretation). Data-integrity violations or inter-rater reliability below 0.70 trigger an automatic flag to the Steering Committee within 48 hours; remediation steps are determined by consensus of the Committee or, if urgent, by the Psychometrician in consultation with the Steering Committee.

**Meeting Cadence:** Bi-weekly standing meetings (Mondays, 90 minutes) from Month 2 (2026-12-13) through Month 24 (2028-10-13). Additional meetings at Months 10–11 (2027-08-13 to 2027-09-13) (weekly, for validity-study completion) and Months 18–24 (2028-04-13 to 2028-10-13) (weekly, for pilot monitoring and midpoint analysis). Emergency meetings convened within 48 hours if data-integrity issues or inter-rater reliability drops are discovered.

**Typical Agenda Items:**

- Instrument design progress and construct-validity analysis: control-condition design, manipulation-check measures, confound-control procedures
- Inter-rater reliability: kappa scores and trends, rater calibration and training updates, scoring-procedure adherence
- Validity-study and pilot data-quality reports: instrument performance, effect sizes, missing data, consent and privacy compliance, participant retention
- Pre-analysis plan review and finalization: threshold specification, sample-size power analysis, primary and secondary outcomes, analysis code
- Mid-phase audit findings (Month 18–22 = 2028-04-13 to 2028-08-13): validity threats, remediation recommendations, implications for gate credibility

**Escalation Path:** Data-integrity violations (missing recordings, unauthorized access, consent breaches) escalate immediately (within 48 hours) to the Steering Committee and the internal Data Integrity Officer; serious breaches (e.g., data loss) trigger suspension of affected pilot arms and immediate notification to IRB/ethics board. Inter-rater reliability below 0.70 for more than 2 weeks escalates to the Steering Committee with a remediation plan (rater retraining, extended inter-rater calibration, or Phase 1 extension); if remediation is not effective by Month 21 (2028-07-13), the Committee recommends to the Steering Committee whether to proceed to gate decision with degraded measurement or extend Phase 2. Construct-validity threats (e.g., evidence that a confound is larger than expected, inflating apparent Clear English effects) escalate to the Steering Committee with a recommendation for additional analysis or a supplementary validity study (costing up to $50K, estimate) by Month 21 (2028-07-13).
### 4. Compliance & Risk Management Committee

**Rationale for Inclusion:** The Clear English program spans 36 months, operates across multiple jurisdictions (UK, US, possibly EU), manages sensitive biometric data (pronunciation audio), engages vulnerable populations (adult ESL learners), pilots safety-critical documentation, and carries reputational and legal exposure if incidents or violations occur. Key risks include data-privacy breaches (GDPR, US state law violations), ethics-approval delays (2–8 weeks, estimated), safety-critical liability (injury linked to Clear English documentation), educator and standards-body pushback, financial overruns exceeding the $175K pre-gate reserve cap, and fragmentation/unofficial variants post-release. The Compliance & Risk Management Committee provides active, continuous monitoring and mitigation of these risks; escalates emerging threats to the Steering Committee; ensures legal, ethical and regulatory alignment; and maintains a current risk register with ownership and action plans. This committee operates independently from rule development and measurement to maintain impartiality on governance and risk issues.

**Responsibilities:**

- Maintain and update a live risk register (20 identified risks from the assumptions document, plus emerging risks) with ownership, mitigation actions, status and escalation criteria; conduct quarterly risk reviews (Months 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36 = 2027-01-13 onwards) and publish a summary risk dashboard to the Steering Committee
- Secure and monitor ethics-board (IRB) and data-protection compliance: ensure IRB approval of pilot protocol and consent forms by Month 6 (2027-04-13); establish encrypted audio storage with backups by Month 6 (2027-04-13); conduct a data-protection audit by Month 8 (2027-06-13); publish a privacy policy by Month 12 (2027-10-13); ensure GDPR and US state law compliance for all participant data handling
- Manage legal, liability and safety-critical risk: retain legal counsel specializing in product liability and regulatory compliance by Month 2 (2026-12-13); develop a liability insurance and risk-mitigation strategy by Month 4 (2027-02-13) with liability costs capped at $150K–$200K (estimate); establish safety-critical pilot boundaries (glossary and labeling exercises only, no live operational procedures before Month 24 = 2028-10-13) and enforce via protocol review and signed agreements with pilot partners
- Monitor stakeholder adoption and pushback risks: track educator and publisher engagement metrics (open rates on outreach, meeting attendance, non-binding letters of interest, pilot partner retention) monthly; flag educator-pushback signals (critical social media posts, TESOL/IATEFL concerns, pilot-site withdrawal) within 48 hours to the Steering Committee; trigger corrective outreach (messaging, training, incentives) if engagement drops below thresholds
- Monitor budget and timeline risks: track monthly spend variance against Phase allocations; flag budget variances >$50K or timeline slips >2 weeks to the Steering Committee; recommend contingency draws (up to $175K pre-gate cap) or scope adjustments; conduct a formal budget-fitness audit at Month 24 (2028-10-13) before go/no-go decision
- Manage post-release governance and fragmentation risks: by Month 24 (2028-10-13), identify potential steward organizations and approach them for funding commitments; design the licensing and name-stewardship model (certification mark, conformance checklist) and publish by Month 12 (2027-10-13); establish a Standards Stewardship Committee charter and decision procedures by Month 30 (2029-04-13); monitor for unofficial variants and non-conforming uses of the 'Clear English' name post-release and enforce name restrictions via the certification mark

**Initial Setup Actions:**

- Appoint Committee Chair and members by Month 1 (2026-11-13): recruit a risk-management or compliance specialist (internal or external advisor, 0.5 FTE), legal counsel or in-house counsel (external retainer, ~4 hours/month), ethics/IRB liaison (internal or academic partner, ~3 hours/month), and a stakeholder-engagement or communications specialist (internal, 0.5 FTE)
- Publish Compliance & Risk Management Committee Charter by Month 1 (2026-11-13): define committee authority (independent escalation to Steering Committee for risks exceeding tolerances), decision procedures (consensus on risk rating and mitigation ownership), and reporting cadence
- Develop a comprehensive Risk Register template by Month 2 (2026-12-13): categorize risks by domain (regulatory/standards adoption, pilot recruitment/retention, assessment validity, rule ambiguity, safety-critical liability, budget/timeline, educator pushback, fragmentation, data privacy, stewardship funding); specify likelihood, severity, current mitigation status, owners and escalation thresholds
- Engage legal counsel by Month 2 (2026-12-13) and develop a liability and insurance strategy by Month 4 (2027-02-13), including product liability coverage options, regulatory approval pathways for safety-critical pilots, and disclaimer language for all Clear English materials
- Initiate ethics-board engagement by Month 1 (2026-11-13); submit IRB protocol for review by Month 2 (2026-12-13); target approval by Month 6 (2027-04-13)
- Establish data-protection and privacy infrastructure by Month 6 (2027-04-13): contract with a secure audio-storage vendor, implement encryption and access controls, establish backup and disaster-recovery procedures, and conduct a dry-run with a small pilot cohort (N=5–10) by Month 10 (2027-08-13)
- Schedule the first Committee meeting by Month 1 (2026-11-13) to populate the Risk Register, assign owners and confirm mitigation timelines

**Membership:**

- Compliance & Risk Management Committee Chair (internal or external advisor, 0.5 FTE, governance or risk-management background, leads risk reviews and Steering Committee escalations)
- Legal Counsel / Product Liability Specialist (external retainer, ~4 hours/month, advises on product liability, regulatory pathways for safety-critical use, disclaimer language and insurance options)
- Ethics & Data-Protection Specialist (internal or external, ~3–4 hours/month, manages IRB/ethics-board approval, data-protection compliance with GDPR and US state law, consent procedures, audit trails)
- Stakeholder Engagement / Communications Lead (internal, 0.5 FTE, tracks educator and publisher engagement, flags pushback signals, coordinates corrective outreach and messaging)
- Finance & Budget Lead liaison (internal, ~2 hours/month, provides monthly spend reports, flags budget variances and timeline risks)

**Decision Rights:** Authority to recommend (but not unilaterally impose) changes to pilot protocol, budget allocation or timeline to mitigate identified risks; recommendations are binding on operations if approved by the Steering Committee. Authority to halt or suspend pilots (in coordination with Steering Committee and Metrics & Validation Committee) if data-privacy breaches, ethics violations or safety-critical incidents occur. Authority to recommend spending from the $175K pre-gate contingency reserve (in coordination with Steering Committee) for legal, ethics, insurance or urgent risk-mitigation costs. Authority to veto or modify any pilot operation that violates IRB approval, data-protection compliance, or safety-critical risk boundaries. Does not control rule specifications (Editorial Board authority) or measurement procedures (Metrics & Validation Committee authority) but may flag to those committees if compliance issues arise from rule or measurement design.

**Decision Mechanism:** Consensus on risk assessment and mitigation ownership; if consensus cannot be reached on risk severity or mitigation strategy, the Committee Chair makes the final call with documented rationale. Escalation to the Steering Committee is automatic if a risk is rated 'High' likelihood × 'High' severity, or if mitigation is inadequate or delayed. Emergency decisions (e.g., suspension of a pilot site due to ethics violation) can be made by the Committee Chair in consultation with the Steering Committee within 48 hours.

**Meeting Cadence:** Monthly standing meetings (third Wednesday, 90 minutes) from Month 1 (2026-11-13) through Month 36 (2029-10-13). Quarterly risk reviews (Months 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36 = 2027-01-13 onwards, 120 minutes) with the Steering Committee to present updated Risk Register and escalation summary. Emergency meetings convened within 48 hours if a 'High' risk event occurs (data breach, ethics violation, safety incident, budget overrun exceeding $125K).

**Typical Agenda Items:**

- Risk Register updates: new risks identified, mitigation progress on existing risks, completion of mitigation actions, status and escalation flags
- Legal and liability updates: counsel summary of regulatory landscape, product-liability considerations for safety-critical pilots, insurance recommendations and costs
- Ethics and data-protection compliance: IRB approval status, consent and privacy-audit findings, data-storage security checks, GDPR/US state law compliance summary
- Stakeholder engagement and pushback monitoring: educator and publisher engagement metrics, critical feedback or resistance signals, corrective outreach plans
- Budget and timeline variance: monthly spend report, Phase allocation tracking, contingency-reserve balance and recommended draws
- Stewardship and post-release governance: steward organization identification and funding-commitment status, licensing and name-stewardship model design, fragmentation-control and conformance-checklist planning

**Escalation Path:** All 'High' likelihood × 'High' severity risks escalate to the Steering Committee within 5 business days of identification or status change, with a documented mitigation plan and timeline. Data-privacy breaches or ethics violations escalate immediately (within 48 hours) to the Steering Committee, IRB/ethics board (if required) and relevant data-protection authorities (e.g., ICO in UK, state regulators in US). Safety-critical incidents linked to Clear English documentation escalate immediately to legal counsel, the Steering Committee, relevant workplace safety regulators (OSHA, HSE) and affected pilot organizations; trigger a formal incident investigation and communication plan. Budget overruns exceeding $125K (half the $250K contingency cap) escalate to the Steering Committee with a scope-adjustment or timeline-extension recommendation. Educator or standards-body pushback signals that could reduce pilot enrollment by >20% or delay regulatory approval by >4 weeks escalate to the Steering Committee with a corrective communication and engagement plan.