
## Documents to Create

### 1. Project Charter

**ID:** 45622232-b1ca-478f-84a7-9d0c7b8650af

**Description:** Foundational project governance document specifying the Clear English Standard program scope (36-month, 3-phase, $3.5M fixed budget), go/no-go gate at Month 24 (2028-10-13), primary deliverables (v1.0 standard, dictionary, style guide, pilot curriculum), stakeholder roles, success criteria, and approval authorities. Intended audience: editorial board, funding bodies, institutional partners.

**Responsible Role Type:** Project Manager / Program Director

**Primary Template:** PMI Project Charter Template

**Secondary Template:** PRINCE2 Project Initiation Document

**Steps:**

- Draft scope statement covering ordinal standardization, 5,000-word lexicon, pronunciation guidance, pilot evidence and public release
- Specify the three phases (rules, pilots, adoption) with exit gates and budget allocation
- Define success metrics (go/no-go thresholds for ordinal error, comprehension speed, pronunciation consistency, 30-day retention)
- Identify primary stakeholders (project lead, editorial board, psychometrician, pilot partners, steward candidates)
- Establish decision authority (editorial board for rules; project lead for timeline/budget)
- Obtain signatures from program sponsor and editorial board chair by Month 1 (2026-11-13)

**Approval Authorities:** Program Sponsor, Editorial Board Chair, Project Lead

### 2. Editorial Board Charter and Governance Framework

**ID:** 46f4c8a2-aedf-4c93-bdfd-f4efff63255c

**Description:** Formal document establishing editorial board composition, voting rules, conflict-of-interest disclosure, tiebreak-arbiter selection process, decision-logging requirements, and rule-finalization timeline. Specifies how disputed rule decisions (ordinal, morphology, homographs, accent) are escalated and resolved. Audience: editorial board members, project team, external stakeholders seeking legitimacy.

**Responsible Role Type:** Project Manager / Governance Administrator

**Primary Template:** ISO/TC 37 Language and Terminology Committee governance templates

**Secondary Template:** ASD-STE100 Maintenance Group procedures

**Steps:**

- Define board composition (7–9 members: linguists, ESL teachers, technical writers, learner representatives, standards-body liaisons)
- Establish voting thresholds (simple majority, quorum 6 of 9) and linguist-review scope (ambiguity/contradiction only, not subjective preference)
- Specify tiebreak arbiter role: external neutral party (e.g., university linguistics chair, ISO observer), conflict-of-interest rules, fee cap ($5K–$20K per decision)
- Publish decision-logging template and conflict-of-interest disclosure form
- Establish rule-specification workstreams: owners assigned, Month 10 (2027-08-13) draft deadlines
- Define escalation path: disputes unsolved by Month 8 (2027-06-13) go to arbiter; board votes on arbiter recommendation by Month 10 (2027-08-13); final rules locked Month 12 (2027-10-13)
- Obtain board sign-off and publish on project website by Month 1 (2026-11-13)

**Approval Authorities:** Editorial Board Chair, Program Sponsor

### 3. Outcome Metric Battery Design and Pre-Analysis Plan

**ID:** 95578caa-10a4-450b-8ef1-0fc637c2d8fc

**Description:** Detailed specification of four go/no-go metrics (ordinal error rate, comprehension speed, pronunciation consistency, 30-day retention) including measurement instruments, scoring procedures, control-group design, inter-rater reliability targets (kappa ≥0.70 floor, ≥0.75 target), sample-size justification via power analysis, pre-registered pass/fail thresholds, and intention-to-treat analysis rules. Independently reviewed by a psychometrician. Registered on Open Science Framework by Month 11 (2027-09-13). Intended for editorial board, external reviewers, and regulatory bodies.

**Responsible Role Type:** Psychometrician / Assessment Specialist

**Primary Template:** Open Science Framework pre-registration template (aspredicted.org or equivalent)

**Secondary Template:** APA Standards for Educational and Psychological Testing

**Steps:**

- Conduct literature review on adult ESL learning effects, comprehension-speed benchmarks, and pronunciation consistency measurement
- Propose instrument candidates for each metric (reading-to-matching for ordinal error; TOEFL-style comprehension for reading speed; phonemic-transcription for pronunciation; delayed-recall for retention)
- Design a validity study (N=20–30 adult ESL and technical learners, Months 10–11 = 2027-08-13 to 2027-09-13) to estimate effect sizes
- Conduct power analysis: calculate sample size per arm for 80% power at α=0.05 to detect proposed effect sizes
- Justify each proposed threshold (e.g., ordinal error ≥25% reduction) with reference to analogous interventions and Phase 1 pilot effect estimates
- Specify control-group design and manipulation checks to isolate Clear English effects from confounds (repeated exposure, motivation, first-language phonology)
- Define inter-rater training protocol for pronunciation consistency scoring: rater selection criteria, Cohen's kappa calibration on ≥100-word pilot sample, retraining trigger if kappa <0.70
- Document intention-to-treat rules: handling of missing data, early dropouts, multivariate analyses for confound adjustment
- Complete draft by Month 5 (2027-03-13); finalize with board input by Month 9 (2027-07-13); register on OSF by Month 11 (2027-09-13); publish registered plan on project website immediately

**Approval Authorities:** Independent Psychometrician (lead author), Editorial Board (vote on thresholds), External Expert Reviewer

### 4. Clear English Standard Specification v0.9 (Draft for Comment)

**ID:** 514a9a21-d20b-4eae-8c79-48f9e0170564

**Description:** Comprehensive draft rule set covering ordinal representation (prefix-marker notation + invariant spoken form), grapheme-to-phoneme mapping for core lexicon (pronunciation overlay guidance), morphology retention rules (irregular verbs/plurals threshold), homograph disambiguation policy (marker list + application rules), and accent-anchor specification (phonemic inventory + mapping to other varieties). Includes rationale, worked examples, exceptions, and change-control procedures. Published for 30-day public comment by Month 11 (2027-09-13). Intended for educators, publishers, standards bodies, and ESL professionals.

**Responsible Role Type:** Linguistic Specialist / Computational Linguist

**Primary Template:** ISO 639-5 Language Code standard template

**Secondary Template:** ASD-STE100 specification document format

**Steps:**

- Consolidate rule specifications from editorial-board subcommittees: ordinal (prefix marker, spoken form finalized Month 10 = 2027-08-13), morphology (frequency threshold + ranked exception list), homographs (≤50 high-impact pairs + disambiguation markers for safety-critical contexts only), accent anchor (phonemic inventory, vowel quality conventions, key consonant contrasts, mapping to RP/GenAm/other varieties)
- Draft written rules with explicit if-then criteria (e.g., 'if a word rank >1000 in frequency, regularize irregular forms; if rank ≤1000, retain legacy form')
- Provide 20–50 worked examples per rule (ordinal dates/lists, morphology paradigms, homograph disambiguation in procedure context, pronunciation guidance samples)
- Document rule justifications and linguistic precedents (e.g., Basic English, ASD-STE100 controlled vocabulary, ESL morphology acquisition research)
- Specify exceptions and edge cases (e.g., 'go/went retained despite frequency <1,000 due to learner salience')
- Draft a Change-Control and Release Cadence policy: v1.0 frozen for 12 months, errata-only, consolidated v2.0 review
- Publish as a 20–30 page draft specification by Month 11 (2027-09-13) with a public comment form; collect feedback through Month 11.5 (2027-09-28); respond to comments and finalize by Month 12 (2027-10-13) with a published Response Document

**Approval Authorities:** Editorial Board (majority vote + tiebreak if needed), Public Comment Review Committee

### 5. 5,000-Word Core Lexicon with Pronunciation Guidance

**ID:** 9cf52d63-45ad-4552-a0de-77bff7411467

**Description:** Ranked list of 5,000 English word types (4,500 frequency-led general vocabulary + 500 technical/safety block) with: frequency band and corpus source, part-of-speech and word sense (polysemy markers), pronunciation guidance (IPA-based or minimal respelling overlay notation), mapping to standard English equivalent, and notes on rule exceptions (e.g., irregular verbs retained). Coverage audit confirms ≥85% of pilot running text. Delivered with a companion Pronunciation Key (single reference-accent anchor specification + notation guide). Intended as input for dictionary, curriculum, and pilot materials.

**Responsible Role Type:** Linguistic Specialist / Lexical Semanticist

**Primary Template:** ISO 1087 Terminology Databases standard

**Secondary Template:** Merriam-Webster or Cambridge Dictionary lexicographic entry template

**Steps:**

- Finalize Core Lexicon Selection Basis (Decision 9): frequency-led with incident-driven optional seeding or domain-led? Source: large ESL corpus (e.g., COCA General Academic sublist, Cambridge English Corpus, learner-error corpora) or technical glossaries (safety procedures, medical device labels, aviation manuals)?
- Conduct word-frequency analysis on candidate corpus; identify top 4,500 words ranked by corpus frequency, TOEFL syllabus coverage, or incident-report mention count
- Reserve 500 slots (10%) for technical/safety vocabulary: pharmaceutical, industrial, aviation, medical device terminology identified from incident reports or standards-body glossaries
- By Month 8 (2027-06-13), audit coverage: analyze running text from at least 2–3 pilot ESL textbooks and technical glossaries (first 10,000 running words each); calculate type coverage % (distinct word forms in pilot text that appear in the 5,000-word list). Target ≥85% type coverage.
- If coverage <85%, identify highest-frequency missing words and add from a pre-compiled secondary candidate list by Month 10 (2027-08-13); document the final lexicon provenance and coverage in a Coverage Report
- For each lexicon entry, add: word form, frequency rank, part-of-speech, corpus source, common word senses (polysemy), irregular morphological forms (verbs, plurals) with retention justification (if applicable), and pronunciation guidance reference (pointer to the Pronunciation Key)
- Deliver the lexicon as a sortable database (Excel, CSV, or wiki) by Month 12 (2027-10-13); publish a summary list with pronunciation key on the project website

**Approval Authorities:** Linguistic Specialist (lead), Editorial Board (sign-off on coverage and exceptions)

### 6. Pronunciation Guidance System and Rater-Calibration Protocol

**ID:** 5915ff9b-fbd8-495b-a118-cbffa5cf01d4

**Description:** Complete specification of the single reference-accent anchor (chosen phoneme inventory, vowel quality conventions, exemplar recordings, mapping to other major English varieties). Includes pronunciation-notation system (IPA-based, minimal respelling, or hybrid) with rater-training manual and inter-rater reliability scoring rubric for the pronunciation-consistency metric. Specifies Cohen's kappa target (≥0.75) and floor (≥0.70), calibration procedure (100–200 word pilot sample), and retraining trigger. Designed so raters can achieve reliable pronunciation-consistency scoring by Month 10 (2027-08-13).

**Responsible Role Type:** Orthography & Phonetics Designer / Audio Production Manager

**Primary Template:** IPA Handbook or Pullum & Ladusaw Phonetic Symbol Unicode chart

**Secondary Template:** ESL pronunciation-teaching manual (e.g., Celce-Murcia, Brinton & Goodwin)

**Steps:**

- By Month 3 (2027-01-13), finalize reference-accent anchor: document phonemic inventory, vowel-quality distinctions (e.g., IPA [ɪ] vs [i], [ʌ] vs [ɑ]), key consonant contrasts, syllable stress marking, and intonation conventions; justify choice (learnability for ESL, learner demand, phonological distinctiveness) against 2–3 alternative candidates; provide 20–30 exemplar word recordings in the anchor accent
- By Month 3 (2027-01-13), decide pronunciation-notation system for the lexicon: IPA transcription (most precise, requires trained eye), minimal respelling (most accessible, less precise), or hybrid (IPA for raters, simplified overlay for learners); document notation conventions with a 1–2 page guide and worked examples for common consonant and vowel patterns
- Design the Rater Training Manual (3–5 pages): specify rater prerequisites (native or near-native proficiency in reference accent, prior ESL teaching or phonetics training); rater-selection criteria; training sessions (how many hours, what content: anchor pronunciation exposure, practice listening/transcribing on pilot word sample); and certification procedure (raters must achieve kappa ≥0.70 on a 50–100 word training sample before proceeding to full inter-rater calibration)
- Draft the Pronunciation-Consistency Scoring Rubric (1–2 pages): define the scoring scale (binary match/mismatch vs. 1–5 quality rating), inter-rater procedure (raters score audio files independently, blinded to learner condition and identity), disagreement resolution (if kappa <0.70, identify which phonemes are problematic, retrain, and retest), and edge-case handling (unclear audio, non-native-like but intelligible pronunciations, learner code-switching)
- By Month 8 (2027-06-13), recruit 3–4 qualified raters and begin training on the anchor accent and notation system
- By Month 10 (2027-08-13), conduct inter-rater calibration on a 100–200 word pilot sample: each rater independently scores all words, Cohen's kappa is calculated, results reviewed; if kappa ≥0.75, proceed to full lexicon recording; if 0.70–0.74, implement targeted retraining on disagreed phonemes, retest by Month 10.5 (2027-08-28); if <0.70, pivot to hybrid model (speech-synthesis baseline + human verification of highest-friction subset only)
- Finalize and publish the complete Pronunciation Guidance System (all raters trained, notation documented, rubric tested) by Month 11 (2027-09-13)

**Approval Authorities:** Audio Production Manager, Independent Psychometrician (kappa validation), Editorial Board

### 7. Pilot Curriculum and Assessment Materials (ESL and Technical Cohorts)

**ID:** 3cdd003f-8e44-405c-b69a-1771e27cdcbf

**Description:** Print and digital learning modules embedding Clear English rules (ordinal prefix, pronunciation guidance, morphology, homograph disambiguation) in scaffolded, contextually meaningful exercises. Separate modules for ESL cohort (vocabulary, reading, writing) and technical/safety cohort (procedure reading, glossary application). Includes embedded comprehension-speed assessments, ordinal-accuracy tasks, pronunciation samples, and 30-day retention recall exercises. Designed to be pedagogically sound, rule-error-free, and implementable within existing ESL and technical-training course structures. Pilot-ready by Month 13 (2027-11-13).

**Responsible Role Type:** Curriculum Designer / Materials Developer

**Primary Template:** TESOL Adult ESL Curriculum Framework

**Secondary Template:** IEC 62304 (medical device procedure documentation) or ASD-STE100 technical-writing template

**Steps:**

- By Month 5 (2027-03-13), draft learning objectives aligned to each gate metric: (a) ordinal prefix: learners identify and produce prefix-marked ordinals in 1–2 exposures with ≥90% accuracy; (b) pronunciation: learners produce reference-anchor pronunciations of core vocabulary with ≥85% phonemic accuracy; (c) comprehension: learners read mixed Clear English / standard text at ≥90% accuracy within 2 weeks; (d) retention: learned rules persist at ≥70% of immediate accuracy at 30 days
- Design unit sequence: Unit 1 (ordinal prefix + number notation), Unit 2 (core vocabulary + pronunciation overlay), Unit 3 (morphology + irregular-form rules), Unit 4 (homograph disambiguation + procedure context), Unit 5 (mixed reading + retention practice). 4–8 weeks total per cohort.
- Develop lesson plans with worked examples, exercises, and assessment checkpoints (inline comprehension checks, pronunciation samples, error-spotting tasks)
- For ESL module: embed ordinals in dates, numbered lists, sequence procedures; use core lexicon in grade-appropriate passages; include pronunciation guidance (printed key, optional digital overlay)
- For technical module: source 2–3 real procedure excerpts (safety, pharmaceutical, industrial) from partner organizations; adapt them to Clear English form; include homograph-marker examples; add pre/post comprehension and error-identification tasks
- By Month 10 (2027-08-13), conduct a dry run with 5–10 learners at a pilot partner site: administer Unit 1 and Unit 2 lessons, measure rule comprehension and learner engagement, identify ambiguities, record timing; iterate on lesson sequence and clarity
- By Month 12 (2027-10-13), finalize curriculum for pilot launch; incorporate feedback from dry run; confirm rule compliance with the frozen rules (Month 12 = 2027-10-13 lock)
- Deliver print curriculum (workbook or pamphlet), digital-module files (LMS-compatible), instructor guides (lesson plans, answer keys, pronunciation guidance), and assessment tooling by Month 13 (2027-11-13)

**Approval Authorities:** Curriculum Designer (lead), Linguistic Specialist (rule compliance), Pilot Partners (pedagogical fit), Psychometrician (assessment validity)

### 8. Pilot Partner Memoranda of Understanding (MOUs)

**ID:** 7d530971-4d91-4e4d-8132-fc1488329beb

**Description:** Legally binding agreements with each pilot partner organization (ESL programs and technical/safety-training sites) specifying: minimum learner enrollment (≥50 per partner by Month 13 = 2027-11-13), assessment schedule (4 in-person/virtual sessions across Months 13–24 = 2027-11-13 to 2028-10-13), data-collection protocols (informed consent, audio recording, test administration), learner incentives ($50–$150 per learner estimate, breakdown by partner), partner payment terms ($30–$50 per session per learner estimate, or lump-sum), and penalty clauses (liquidated damages if recruitment shortfalls, make-up recruitment window by Month 15 = 2028-01-13, escalation contacts). Signed by Month 3 (2027-01-13).

**Responsible Role Type:** Project Manager / Regulatory Affairs Manager

**Primary Template:** University-Nonprofit Research Partnership Agreement template

**Secondary Template:** TESOL Program Partnership MOU template

**Steps:**

- Identify 4–5 candidate ESL programs and 3 candidate technical/safety-training organizations; confirm provisional interest and capacity by Month 1 (2026-11-13)
- Draft a standard MOU template covering: scope (pilot study, experimental materials, 4-month engagement Months 13–24 = 2027-11-13 to 2028-10-13); learner recruitment target (≥50); assessment schedule and on-site requirements (4 sessions, 1–2 hours each); incentive structure (who pays, how much, payment timing); data ownership and confidentiality (Clear English project owns data, partner commits to confidentiality); exit clause (if partner cannot meet enrollment by Month 14 = 2027-12-13, 30-day notice and make-up recruitment window by Month 15 = 2028-01-13); liability and indemnification (materials are experimental, partner assumes risk of use, materials not permitted for operational/life-critical use without explicit written approval)
- Customize MOU for each partner: specify their committed enrollment (50–75 learners, estimate), partner staff roles (recruitment lead, assessment site coordinator), and partner payment structure (lump-sum vs. per-learner)
- Include appendices: curriculum outline, informed-consent form, data-collection schedule, learner incentive structure, contact escalation procedures
- Obtain signed MOUs from ≥3 ESL programs and ≥2 technical/safety-training organizations by Month 3 (2027-01-13); file originals and provide copies to each partner and the project lead

**Approval Authorities:** Project Manager (legal review), Partner Organization Authorized Representative, Program Sponsor (budget commitment)

### 9. Regulatory and Stakeholder Engagement Map

**ID:** 2c4f7e42-e55e-4c24-a78d-731e30ca8f70

**Description:** Strategic landscape document identifying: (a) regulatory bodies with approval authority or advisory influence (TESOL, Ofqual, state education departments, OSHA, HSE, ISO language committees); (b) ESL publishers and standards-body liaisons to approach for endorsement or partnerships; (c) regulatory approval timelines and conditions for each jurisdiction where pilots operate; (d) recommended engagement strategy (advisory seats, non-binding letters of interest, formal submissions, approval-pathway navigation). Guides Month 1–6 (2026-11-13 to 2027-04-13) outreach and flags approval-delay risks to the editorial board by Month 6 (2027-04-13).

**Responsible Role Type:** Regulatory Affairs Manager / Stakeholder Engagement Lead

**Primary Template:** ICAO standards-adoption roadmap template

**Secondary Template:** ISO/TC 37 Language Committee engagement matrix

**Steps:**

- By Month 1 (2026-11-13), identify all regulatory bodies and standards organizations relevant to target sectors (education, ESL, technical writing, safety-critical documentation) in pilot jurisdictions (US, UK, optionally EU if applicable): TESOL, IATEFL, Ofqual (UK), CEDEFOP (EU), CEFR governing committee, OSHA, HSE, ISO language committees, relevant industry standards bodies (e.g., ASD for aerospace, IEC for medical/industrial)
- For each body, document: mission/scope, approval authority or advisory influence, decision-making timeline (if approval required: 4–8 months estimated, or advisory consultation: 2–4 months), contact process, and likelihood of endorsement or blocking (high/medium/low estimate)
- Develop tailored engagement strategy for each category: (a) mandatory-approval bodies—prepare formal submissions by Month 15 (2028-01-13), pre-negotiate for research-study exemptions if available; (b) advisory bodies—solicit non-binding letters of interest by Month 3 (2027-01-13), brief quarterly Months 6, 12, 18, 24 (2027-04-13, 2027-10-13, 2028-04-13, 2028-10-13); (c) publishers—solicit letters of interest in Phase 3 adoption by Month 3 (2027-01-13), publish a '30-day rights' window at Phase 3 start (Month 24 = 2028-10-13) to incentivize early adoption
- For each target regulator, propose an initial contact and meeting (Month 2–3 = 2026-12-13 to 2027-01-13), a written advisory request (Month 4 = 2027-02-13), and scheduled briefings (quarterly through Month 36 = 2029-10-13)
- Identify approval-delay risks and escalation triggers: if a mandatory-approval body signals 6+ month timeline or blocking intent by Month 12 (2027-10-13), flag to the editorial board for contingency planning (e.g., shift safety-critical pilots to post-Phase-2 Phase 2.5, restructure main pilots as research studies to bypass approval)
- Publish the Regulatory and Stakeholder Map (2–3 pages) on the project website by Month 1 (2026-11-13) to signal proactive engagement; update quarterly with new contacts, approvals, or blocking signals

**Approval Authorities:** Project Manager, Regulatory Affairs Manager, Editorial Board (escalation decisions)

### 10. Data Protection and Privacy Policy

**ID:** b3a58520-c73f-4e3b-90b2-ac9c14faa57d

**Description:** Comprehensive GDPR and US state law-compliant document specifying: data types collected (pronunciation audio, test scores, demographics), collection purpose (pilot measurement for gate metrics), lawful processing grounds (participant consent + research exemption), retention periods (audio 3 years post-analysis; scores 5 years for replication; consent forms 3 years minimum), access controls (authorized team members only, signed data-use agreements), encryption standards (AES-256 or equivalent, FIPS 140-2 validated), backup and disaster-recovery procedures, participant rights (access, correction, deletion within 30 days), breach-notification protocol, and Data Protection Impact Assessment summary (GDPR Article 35). Published alongside informed-consent forms. Audience: research participants, ethics committees, data-protection authorities.

**Responsible Role Type:** Data Protection Officer / Legal Counsel

**Primary Template:** GDPR Data Protection Policy template (ICO or national equivalents)

**Secondary Template:** US University IRB research-participant privacy policy template

**Steps:**

- By Month 1 (2026-11-13), commission a Data Protection Impact Assessment (DPIA) under GDPR Article 35 or UK Data Protection Act 2018 Schedule 1, documenting: lawful processing ground (explicit consent + research exemption for academic research), data-minimization strategy (inter-rater reliability piloted on 200–300 word subset before full 5,000-word recording), processing necessity, retention schedule, and risk mitigation (encryption, access controls, breach notification)
- Draft the Privacy Policy (2–3 pages) in plain language: explain what data are collected (pronunciation audio recordings, reading-comprehension test responses, demographic info), why (to measure learning outcomes on Clear English rules), who can access (core research team, auditors, data-protection authorities if breach), how long data are kept (audio 3 years post-analysis unless participant requests longer retention for archival; test scores 5 years for study replication; consent forms 3 years minimum for compliance audit), and participants' rights (see their data, ask for corrections, request deletion within 30 days). Include data-breach notification procedure (internal alert within 24 hours, participant notification within 72 hours if data is material to privacy, regulator notification per GDPR Article 33).
- Specify encryption and security: audio stored on encrypted servers (AES-256, FIPS 140-2 validated, or equivalent cloud-provider encryption like AWS KMS or Azure Key Vault); access controlled via role-based credentials and audit logs; backups encrypted and geographically separated; encryption keys held in split custody (project team + external escrow service, or cloud-provider key management service)
- Define participant deletion rights and workflow: if a participant requests deletion, audio file is securely wiped within 30 days; test scores may be anonymized and retained if needed for aggregate analysis; participant receives written confirmation of deletion
- Draft plain-language Informed Consent Form (1–2 pages in English and ESL learners' home languages if feasible): explain the study, data collection, retention, rights, and risks in accessible language; include signature/digital consent option; provide a copy to each participant
- Publish Privacy Policy and Informed Consent Form on the project website by Month 8 (2027-06-13); finalize after ethics-board approval (Month 6 = 2027-04-13) for any required language changes

**Approval Authorities:** Data Protection Officer (lead author), Institutional Review Board (ethics approval), Legal Counsel (GDPR/state law compliance), Project Lead (finalization)

### 11. Licensing and Name Stewardship Policy

**ID:** 875c7976-9657-4bdc-ba33-07a9f73692c7

**Description:** Legal document specifying the open-licensing model for the Clear English Standard text and dictionary, and the mechanism for protecting the 'Clear English' name and brand against non-conforming variants. Three scenarios evaluated: (a) fully permissive open license (CC-BY) with no name control; (b) open text/dictionary (CC-BY) + 'Clear English' as a certification mark against a published conformance checklist; (c) share-alike license (CC-BY-SA) requiring divergent works to adopt a distinct name. Includes conformance checklist (what must a material do to qualify as Clear English?), certification process (who reviews, cost, timeline), dispute resolution (how are non-conforming uses addressed?), and licensing templates for third-party adopters. Decided by Month 6 (2027-04-13), published by Month 12 (2027-10-13). Audience: publishers, educators, standards bodies, adopters.

**Responsible Role Type:** Legal Counsel / IP Specialist

**Primary Template:** Creative Commons License selector and templates

**Secondary Template:** ISO/IEC 27001 conformance assessment framework

**Steps:**

- By Month 2 (2026-12-13), commission a 3–5 page Licensing and Name-Stewardship Analysis comparing the three scenarios on: (a) adoption friction (ease for publishers to adopt), (b) fragmentation risk (likelihood of non-conforming variants), (c) governance overhead (cost and staff time for certification, dispute resolution), (d) perceived fairness and openness (risk of gatekeeping perception)
- By Month 3 (2027-01-13), present analysis to the editorial board with a recommendation; establish a voting procedure (simple majority; if tied, program lead + external arbiter decide). By Month 5 (2027-03-13), board votes and selects the model.
- For the chosen model, develop: (a) licensing template (standard text to be included in published materials: 'This work is licensed under CC-BY [or chosen license], with conformance to version 1.0 of the Clear English Standard'; (b) conformance checklist (2–3 pages: 'A material is Clear English v1.0-conformant if it: uses the prefix-marker ordinal notation, applies the morphology rules with documented exceptions, marks ≥90% of listed homographs in safety-critical contexts, etc.'); (c) certification process (who applies, how: online form, self-certification or third-party audit?, cost if any, timeline for decision)
- If certification-mark model is chosen: draft a formal registration application for the trademark/certification mark (work with IP counsel, Month 3 = 2027-01-13), establish a Standing Standards Stewardship Committee (Month 12 = 2027-10-13) with 3–5 members and explicit authority to review conformance claims and maintain a public registry of certified materials
- If share-alike model is chosen: draft a divergence-disclosure template so divergent works explicitly state which rules they depart from and adopt a distinct name (e.g., 'Clear English Plus: adds phonetic diacritics' or 'Simplified Clear English: reduces lexicon to 3,000 words')
- Publish the chosen Licensing and Name Stewardship Policy (3–5 pages) on the project website by Month 12 (2027-10-13), including the conformance checklist, certification process, templates, and the first list of approved/certified materials (if any, from early Phase 3 adopters)

**Approval Authorities:** Legal Counsel (lead author), Editorial Board (policy adoption), Program Sponsor (IP strategy sign-off)

### 12. Pilot Recruitment and Retention Plan

**ID:** a448d45e-112a-47b5-aea4-39df5b421c54

**Description:** Operational plan specifying recruitment targets (≥115 enrolled per arm = 460 total by Month 13 = 2027-11-13), recruitment strategy per partner (marketing channels, eligibility criteria, enrollment milestones), learner incentive structure ($50–$150 per learner estimate, breakdown), partner payment terms ($30–$50 per session estimate or lump-sum), dropout-risk mitigation (incentives, flexible scheduling, peer cohorts, make-up sessions within ±1 week), and monthly retention tracking (dashboard showing % enrolled, dropout-to-date, projected completers). Probabilistic enrollment model with 50th/75th/90th percentile scenarios based on pilot baseline study (Months 1–2 = 2026-11-13 to 2026-12-13). Includes escalation protocol: if enrollment misses interim milestones by >2 weeks, activate acceleration tactics (increased incentives, evening sessions, $20K–$30K budget).

**Responsible Role Type:** Phase 2 Cohort Manager / Recruitment Specialist

**Primary Template:** TESOL Adult ESL Program recruitment and retention toolkit

**Secondary Template:** National Institutes of Health (NIH) recruitment and retention guidance

**Steps:**

- By Month 2 (2026-12-13), conduct a Pilot Baseline Study (N=20–30 learners at 1–2 sites, Months 1–2 = 2026-11-13 to 2026-12-13): measure recruitment conversion rate (% of eligible population converting to enrollment), baseline dropout rate (% completing all 4 assessment sessions without active management), and demographic patterns (age, language background, work stability, motivation). Budget $15K–$20K (estimate).
- Develop a probabilistic recruitment model: use baseline data to estimate enrollment and dropout distributions; forecast completers under 50th, 75th, 90th percentile dropout scenarios (e.g., 75th percentile dropout = 40%, not 30%); use 75th percentile as planning baseline.
- For each pilot partner, document: target enrollment (50–75 learners per partner estimate), recruitment channels (email, social media, in-class announcement, partner staff referral), eligibility criteria (age, ESL proficiency level, availability for 4 sessions), enrollment window (Months 12–13 = 2027-10-13 to 2027-11-13), and interim milestones (40% enrolled by Month 8 = 2027-06-13, 70% by Month 10 = 2027-08-13, 100% by Month 13 = 2027-11-13).
- Specify learner incentives: certificate of completion ($0 cost, high perceived value for ESL learners), course credit (if available through partner), gift cards or stipends ($50–$150 per learner estimate based on assessment burden and regional wage, tiered for full completion vs. 3-of-4 sessions). Total incentive budget: $23K–$69K ($50–$150 × 460 learners, estimate).
- Specify partner payments: per-session payment ($30–$50 per learner per session, estimate, paid to partner for administrative and facility costs) or lump-sum ($12K–$20K per partner estimate). Total partner payment: $55K–$92K (estimate). Include invoicing and reconciliation procedures.
- Establish dropout-response protocol: weekly attendance tracking by cohort manager; if a learner misses a session, outreach within 24 hours (phone, email, in-person visit); offer one make-up session within ±1 week; if learner misses 2 consecutive sessions, conduct a brief check-in to assess barriers (work conflict, health, childcare) and offer alternative scheduling or incentive boost ($20–$30 bonus, estimate, if retention is at risk); if learner misses 3 sessions, mark as dropout but maintain contact for 30-day follow-up.
- Establish a monthly Retention Dashboard (tracked by cohort manager, visible to board): cumulative enrollments by partner, dropout-to-date (with reasons: work conflict, health, family emergency, lost interest, scheduling conflict), dropout rate by session (Session 1 dropout typically ≥10%, Session 4 dropout typically ≥15% cumulatively), projected completers at Month 22 (2028-08-13), and 95% confidence interval on final sample size. Flag to board if lower confidence bound falls below 70 per arm, triggering Phase 2 delay decision by Month 15 (2028-01-13) rather than Month 22 (2028-08-13) when too late to recover.
- Establish contingency budget: $20K–$30K (estimate) for recruitment shortfall or dropout exceeding 35% (e.g., bonus payments, evening sessions, transportation reimbursement, partner incentive increases). Activate by Month 8 (2027-06-13) if enrollment tracking suggests shortfall.
- Publish final Recruitment and Retention Plan by Month 4 (2027-02-13); circulate to all partners and obtain sign-off on enrollment targets and timelines by Month 6 (2027-04-13)

**Approval Authorities:** Cohort Manager (lead), Project Manager (budget and contingency authority), Pilot Partners (enrollment commitment)

### 13. Project Risk Register

**ID:** 937ec994-723f-4b4e-97cc-afbcd609d58f

**Description:** Living document identifying 20+ project risks (regulatory rejection, pilot recruitment failure, assessment validity, audio-production bottleneck, editorial board deadlock, safety-critical liability, etc.) with: risk description, likelihood (high/medium/low), severity (high/medium/low), risk owner, mitigation strategy, mitigation timeline, and escalation trigger. Updated monthly, with critical-path risks flagged to the editorial board at Months 3, 6, 9, 12, 18, 24 (2027-01-13, 2027-04-13, 2027-07-13, 2027-10-13, 2028-04-13, 2028-10-13). Guides contingency reserve allocation and Phase-1 exit-gate readiness assessment.

**Responsible Role Type:** Project Manager / Risk Officer

**Primary Template:** PMI Risk Management Plan template

**Secondary Template:** ISO 31000:2018 Risk Management standard

**Steps:**

- By Month 1 (2026-11-13), establish the risk register framework: risk category (regulatory, technical, operational, financial, stakeholder), description (2–3 sentences), likelihood/severity (L/M/H and impact scale $), risk owner (named individual), mitigation strategy (specific action), mitigation timeline, trigger for escalation (what condition triggers board notification?), and contingency budget allocation (if applicable)
- Identify top risks from the pre-project risk register and strategic_decisions documents: (1) regulatory rejection by standards bodies (likelihood: high, severity: high, owner: regulatory affairs manager); (2) pilot recruitment/retention shortfall (likelihood: high, severity: high, owner: cohort manager); (3) assessment validity/rater reliability (likelihood: medium, severity: high, owner: psychometrician); (4) editorial board deadlock on rules (likelihood: medium, severity: medium, owner: board chair); (5) safety-critical liability exposure (likelihood: low, severity: high, owner: legal counsel); (6) audio-production bottleneck (likelihood: medium, severity: high, owner: audio production manager); (7) budget overrun (likelihood: medium, severity: medium, owner: project manager/budget officer); (8) Phase 1 timeline slip (likelihood: medium, severity: medium, owner: project manager); (9) post-Phase-3 stewardship funding gap (likelihood: high, severity: medium-high, owner: stewardship committee); (10) educator pushback/non-compliance (likelihood: high, severity: medium, owner: educator liaison). Add 10+ secondary risks.
- For each risk, specify: mitigation action (e.g., 'engage regulators as advisors by Month 2 = 2026-12-13, obtain written advisory feedback by Month 4 = 2027-02-13, prepare regulatory submission by Month 15 = 2028-01-13'), mitigation timeline, and contingency budget (e.g., regulatory approval delay = $85K–$170K Phase 1 extension, budget already allocated; audio-production delay = $40K–$80K rater retraining, allocated from psychometrics budget).
- Assign risk owners and escalation triggers: if a risk trend (e.g., 'studio capacity unavailable by Month 4 = 2027-02-13') is detected >4 weeks in advance, risk owner escalates to project manager; project manager flags to editorial board if mitigation cost exceeds $50K or timeline impact >2 weeks.
- Establish monthly risk-review cycle: by the 10th business day of each month, risk owners provide updates on mitigation status, emerging risks, and contingency budget burn; project manager rolls up to board by the 20th for discussion
- Update the register quarterly (Months 3, 6, 9, 12, 18, 24, 30, 36 = 2027-01-13 through 2029-10-13) as project conditions change; publish the register on the project intranet for team visibility

**Approval Authorities:** Project Manager (owner and primary analyst), Risk Officer (if separate), Editorial Board (escalation and contingency release decisions)

### 14. Project Budget and Cash-Flow Forecast

**ID:** 5cd6b401-d03a-4db9-ab35-ad056a110faf

**Description:** Detailed financial baseline (itemized Phase 1 and Phase 2 costs by workstream: staff, audio, lexicon, assessment, incentives, partner payments, travel, legal), monthly burn rates, cumulative earned-value curves, and rolling 6-month cash-flow forecast. Establishes variance triggers (>10% overrun flagged within 5 days), contingency-reserve allocation, and draw-authorization procedures (up to $25K without board vote, $25K–$175K with 5-day approval). Updated monthly with actual vs. plan variance analysis and spending forecast revision. Audience: project lead, finance office, editorial board.

**Responsible Role Type:** Budget Officer / Financial Manager

**Primary Template:** PMI Budget Template and Project Financial Plan

**Secondary Template:** US Federal Grants Management Handbook (if government-funded)

**Steps:**

- By Month 1 (2026-11-13), establish the financial baseline: allocate $1.1M Phase 1 budget across 12 line items: (a) staff (project lead, linguists, psychometrician, curriculum designer): est. $450K–$550K (estimate); (b) audio production (studio, rater training, inter-rater work): est. $80K–$120K (estimate); (c) assessment and instruments (validity study, pre-registration, review): est. $150K–$200K (estimate); (d) legal and regulatory (counsel retainer, liability analysis, IRB submission): est. $30K–$50K (estimate); (e) administrative (office space, meetings, communication tools): est. $50K–$80K (estimate); (f) travel (board meetings, stakeholder engagement): est. $20K–$30K (estimate); (g) contingency: $175K (pre-gate cap).
- Set monthly burn-rate targets: Phase 1 $1.1M / 12 months ≈ $92K/month (estimate); Phase 2 $1.2M / 12 months ≈ $100K/month (estimate)
- Establish variance triggers: if cumulative actual spend exceeds baseline by >10% at any month ($33K at Month 2 = 2026-12-13), trigger variance review within 5 days and recovery plan within 10 days
- Draft contingency-reserve draw procedures: up to $25K (single-approval draws) can be released by the project lead for pre-approved gate-protection needs (psychometric re-validation, rater retraining, recruitment shortfall response); $25K–$175K draws require board approval within 5 days with written justification (e.g., 'inter-rater kappa = 0.65, additional 2 weeks of rater training at $40K estimated, approved by board for Month 10.5 = 2027-08-28 extension')
- Establish monthly reconciliation: by the 5th business day of each month, actual spending is reconciled against plan; by the 10th, a one-page variance summary is circulated to the project lead and finance office; by the 20th, project lead presents to the board
- Conduct quarterly earned-value analysis (Months 3, 6, 9, 12 = 2027-01-13, 2027-04-13, 2027-07-13, 2027-10-13): calculate Schedule Performance Index (SPI = earned value / planned value, target ≥0.95 to stay on schedule) and Cost Performance Index (CPI = earned value / actual cost, target ≥1.0 to stay within budget); if either index <0.95 by Month 9 (2027-07-13), convene emergency board meeting to approve scope cuts or timeline adjustments
- Establish a rolling 6-month cash-flow forecast: at Months 3, 6, 9 (2027-01-13, 2027-04-13, 2027-07-13), project upcoming spending for the next 6 months and identify any forecasted variances >$50K (estimate) requiring contingency draw or phase-delay decision
- Publish the initial financial baseline by Month 1.5 (2026-11-28); update monthly and distribute to the project lead, budget owner, and board at the monthly meeting

**Approval Authorities:** Budget Officer (lead analyst), Finance Office (baseline approval), Program Sponsor (contingency draw >$50K)

### 15. Project Communication and Outreach Plan

**ID:** 34cc93e7-4de2-43d0-820a-5649f26ce2eb

**Description:** Strategy for internal (team) and external (stakeholders, public) communication covering: monthly board briefings, quarterly stakeholder advisory updates (TESOL, publishers, regulators), Phase 1 final report (Month 12 = 2027-10-13), Phase 2 mid-phase check-in (Month 18 = 2028-04-13), gate decision announcement (Month 24 = 2028-10-13), v1.0 release announcement (Month 30 = 2029-04-13), and ongoing website updates. Includes messaging framework (why Clear English matters, who benefits, evidence-based positioning), key documents for release (draft standard, published research, testimonials), media talking points, and escalation protocol for negative feedback or misunderstandings.

**Responsible Role Type:** Communication Specialist / Outreach Lead

**Primary Template:** TESOL Conference presentation and advocacy toolkit

**Secondary Template:** Nonprofit comms plan templates

**Steps:**

- By Month 1 (2026-11-13), establish communication channels: project website (overview, research rationale, team bios, timeline); monthly newsletter (team updates, stakeholder news); Twitter/social media (headlines, research findings, adoption stories); and quarterly briefings (board, advisory panels, publishers)
- Draft messaging framework: headline ('Clear English: a standards-based, evidence-driven approach to reducing spelling-to-sound ambiguity for adult ESL and safety-critical documentation'); key messages ('we are not replacing standard English, we are offering an optional, research-validated variant'; 'our gate decision will be pre-registered and transparent'; 'we are co-designing with educators, not imposing top-down'); target audience (adult ESL learners and teachers, technical writers, standards bodies, language researchers)
- Establish stakeholder briefing schedule: monthly board meetings (internal team + board members); quarterly advisory briefings (TESOL, IATEFL, publishers, regulators)—Month 6, 12, 18, 24 (2027-04-13, 2027-10-13, 2028-04-13, 2028-10-13)—covering progress, findings, and adoption readiness; annual report to funders (Month 12, 24, 36 = 2027-10-13, 2028-10-13, 2029-10-13)
- Plan key publication milestones: (a) Month 1 (2026-11-13)—project launch announcement, board charter, research rationale briefing to advisory partners; (b) Month 12 (2027-10-13)—Phase 1 final report, draft standard, lexicon, pronunciation guidance system, pre-registered gate metrics; (c) Month 18 (2028-04-13)—mid-phase pilot update, preliminary data if available; (d) Month 24 (2028-10-13)—gate decision announcement, pilot findings summary, Phase 3 adoption strategy; (e) Month 30 (2029-04-13)—v1.0 standard release, style guide, certification policy, steward announcement; (f) Month 36 (2029-10-13)—project final report, adoption metrics, lessons learned, post-project stewardship plan
- Draft a media/FAQ response template for common objections: 'Isn't this just another constructed language that won't be used?' (answer: we are designing for adoption from the start, working with real ESL and safety-critical partners, and only releasing if evidence supports it); 'Why not just teach standard English better?' (answer: standard English has inherent irregularities that are not teachable; we offer an optional variant for specific use cases where consistency matters, like safety documentation); 'Who is funding this?' (answer: [name funder or 'non-profit consortium'], and all materials will be openly licensed for non-commercial use)'
- Establish escalation protocol: if negative media coverage or stakeholder criticism emerges, the project lead and communication lead meet within 2 days to draft a response; for substantive criticism (e.g., 'your gate metrics are biased'), convene an expert to provide an independent response by Month 3 (2027-01-13) of criticism; publish all responses on the project website with a 'FAQ' section
- Publish the Communication Plan on the project website by Month 1.5 (2026-11-28)

**Approval Authorities:** Project Lead (strategy approval), Editorial Board (messaging review), Communications Office (if university-affiliated)

### 16. Post-Phase-3 Stewardship and Sustainability Plan

**ID:** e1b68dda-3043-4fd9-b81a-67a90014b522

**Description:** Document identifying permanent steward organization(s) for the Clear English Standard post-Month 36 (2029-10-13), with committed annual funding ($150K–$250K estimated), governance structure (Stewardship Committee role, decision authority, meeting schedule), and 5-year operational roadmap (errata handling, version review cycles, change-request prioritization, rule-interpretation guidance, conformance-claim arbitration). Includes options for stewardship models (university consortium, language non-profit, standards-body joint hosting, or hybrid). Signed steward commitment required before v1.0 release (Month 30 = 2029-04-13). Guides Month 12–30 (2027-10-13 to 2029-04-13) steward-search and funding negotiations.

**Responsible Role Type:** Stewardship Committee Lead / Sustainability Manager

**Primary Template:** ISO standards body governance and maintenance framework

**Secondary Template:** Wikimedia Foundation sustainability plan template

**Steps:**

- By Month 12 (2027-10-13), establish a Standing Stewardship Committee (3–5 board members with 2–4 hours/month time commitment) tasked with: (a) identifying 2–3 potential steward organizations; (b) auditing their financial stability (3+ years audited financials), mission alignment (language education, standards, or public interest), and standards-maintenance experience (e.g., have they maintained a standard for 5+ years?); (c) drafting a Stewardship Proposal specifying annual budget, responsibilities, and funding sources
- By Month 18 (2028-04-13), circulate a one-page Stewardship Proposal to 2–3 candidate organizations specifying: (a) role: maintain Clear English Standard v1.0 and post-release versions, respond to conformance claims, issue guidance on rule interpretation, conduct a full review every 3–5 years; (b) annual budget: $150K–$250K (estimate, itemized by role: part-time director $60K–$80K, administrative support $20K–$30K, legal/compliance $15K–$20K, meetings/communication $10K–$15K, reserve $25K–$50K); (c) funding source: endowment, member/subscriber fees, institutional budget, or grant funding; (d) governance: Stewardship Committee (3–5 seats), decision-making via consensus or majority vote, annual public report; (e) decision authority: committee votes on errata, version releases, conformance claims, and rule interpretation guidance; escalations to a board arbiter if consensus fails
- By Month 24 (2028-10-13), the Stewardship Committee solicits written letters of interest from top candidates (non-binding). By Month 27 (2029-01-13), invite top candidate(s) to negotiate a Memorandum of Understanding (MOU) specifying: (a) term (≥10 years, renewable); (b) funding commitment (annual amount, source, and contingency if funding shortfall); (c) governance and decision authority (Stewardship Committee composition, voting rules, terms); (d) accountability (annual report to public, audit rights, performance metrics)
- By Month 30 (2029-04-13), finalize and publish the signed MOU on the project website. v1.0 release proceeds only with a signed MOU in hand.
- By Month 36 (2029-10-13), publish a 5-year Stewardship Roadmap (2–3 pages) documenting: (a) review schedule (year 1: bug fixes and errata; year 2–3: minor clarifications; year 5: full standards review); (b) change-request prioritization (safety-critical corrections prioritized within 30 days; minor clarifications within 3 months; new rules deferred to v2.0 review); (c) conformance-claim process (who may request a conformance ruling, timeline, cost); (d) dispute resolution (arbitration process if organizations claim non-conformance); (e) funding contingency (if steward funding lapses, identify backup steward or escalation to a standards-body or regulatory authority)

**Approval Authorities:** Stewardship Committee (proposal development), Editorial Board (steward approval), Candidate Steward Organizations (MOU signature), Program Sponsor (funding commitment confirmation)

### 17. Phase 2 Pilot Protocol and Standard Operating Procedures

**ID:** a75a2c29-9d9d-46cd-af97-103dc0f77884

**Description:** Comprehensive operational manual (25–50 pages) specifying all Phase 2 pilot procedures in detail: participant recruitment and informed-consent process, four assessment sessions (dates, duration, location, virtual/in-person), measurement instruments (ordinal-accuracy tasks, comprehension-speed texts, pronunciation audio capture, retention recall), inter-rater scoring procedures, data management (audio storage, encryption, access control), fidelity monitoring (how adherence to Clear English rules is verified in curriculum delivery), participant attrition response (24-hour outreach protocol, make-up session options), data-quality checks (missing data handling, outlier detection), safety and ethics protocols (informed consent refresher, confidentiality enforcement, breach reporting), and site-coordinator roles and contacts. Ready by Month 13 (2027-11-13).

**Responsible Role Type:** Cohort Manager / Phase 2 Operations Lead

**Primary Template:** NIH Institutional Review Board protocol procedures

**Secondary Template:** TESOL Classroom Research procedures manual

**Steps:**

- By Month 12 (2027-10-13), draft comprehensive Standard Operating Procedures (SOP) manual covering all Phase 2 logistics: (a) recruitment: timeline (Months 12–13 = 2027-10-13 to 2027-11-13), eligibility criteria, enrollment target per site, partner role; (b) informed consent: when signed (at enrollment), refresher signing protocol (at Session 1), and documentation procedures; (c) four assessment sessions: dates (Sessions 1–2 in Months 14–15 = 2027-12-13 to 2028-01-13; Session 3 in Month 20 = 2028-06-13; Session 4 in Month 23 = 2028-09-13), duration (1–2 hours per session), format (in-person at partner site, or virtual if approved by partner), materials and technology (audio recording setup, test platform login, pronunciation playback equipment), and session flow (informed-consent refresher, instructions, task execution, debrief)
- For measurement instruments, specify: (a) ordinal-accuracy task: task format (multiple-choice matching, error-spotting, or ordinal-production), examples, scoring procedure, time limit; (b) comprehension-speed assessment: passage length and readability (must cover ≥85% of core lexicon to avoid confound), timing (automatic via software or manual), accuracy scoring (% correct), and speed calculation (words per minute or ms per item); (c) pronunciation audio capture: recording device and format (MP3, WAV, bit-rate), pronunciation task (read a list of 20–50 core-lexicon words, or read sentences), setup and quality checks (decibel level, background noise, intelligibility); (d) 30-day retention: recall format (recognition vs. cued recall, written vs. oral), item selection (subset of Session 1 vocabulary), and scoring procedure
- Specify data management and security: (a) audio storage: encrypted folder on secure server, file-naming convention (learner ID + session number + date), access-control list (named team members only), backup schedule (daily, geographically separate location), and retention schedule (keep until Month 27 = 2029-01-13, delete or archive per consent); (b) test scores and metadata: encrypted spreadsheet (Excel, password-protected, or REDCap), separate from learner names (identify only by learner ID), retention schedule (keep 5 years per consent); (c) logs: access log (who opened each file, when, for how long) maintained automatically by server or manually by cohort manager, reviewed monthly for unauthorized access
- Specify fidelity monitoring: (a) curriculum adherence checklist: site coordinator confirms each week that curriculum units 1–4 were taught as designed (rule explanations, worked examples, practice exercises); (b) rule-application check: cohort manager and curriculum designer review a sample of learner work (assignments, audio) from each site monthly to identify rule misapplications or confusion; (c) engagement survey: brief learner questionnaire (2–3 questions: 'Do you understand the ordinal rule?' 'Are you able to apply it in writing/speaking?') administered at Session 2 and Session 4 to gauge learner comprehension; (d) incident reporting: site coordinators report any learner confusion, rule ambiguity, or implementation barrier within 24 hours; cohort manager and curriculum designer escalate to project lead if issue affects >2 learners or requires rule clarification
- Specify participant attrition response: (a) attendance tracking: cohort manager maintains a real-time spreadsheet of scheduled/attended sessions and documented reasons for non-attendance; (b) first absence: cohort manager contacts learner within 24 hours (phone, email, or in-person, per learner preference) to offer encouragement and ask about barriers; (c) second absence: more intensive contact, offer alternative session times or virtual participation if feasible; consider incentive offer ($20–$30 bonus, estimate); (d) third absence: mark learner as 'at-risk dropout,' conduct a final check-in with option to rejoin at Session 3 if learner wishes; continue 30-day contact attempt even if dropout
- Specify participant rights and safety: (a) informed consent: learner must sign consent form (or digital consent) before Session 1; consent includes right to withdraw at any time, right to ask questions, contact info for project lead and ethics committee; (b) data access: learner may request a copy of their test scores or pronunciation audio within 30 days; (c) confidentiality: all data are stored by learner ID only, not learner name, and access is restricted to core team members under signed data-use agreements; (d) breach reporting: if audio or data is accessed without authorization or if learner reports concern about privacy, cohort manager escalates to project lead and data protection officer within 24 hours; incident is documented and may require participant notification
- Publish final Phase 2 Protocol and SOP manual by Month 13 (2027-11-13), after ethics-board approval and team training. Include checklists, templates (learner sign-up sheet, attendance form, incident report), technology setup guides, and troubleshooting FAQs. Conduct a mandatory training session with all site coordinators before Session 1 (by Month 13.5 = 2027-11-28).

**Approval Authorities:** Phase 2 Project Lead (operational responsibility), Institutional Review Board (ethics approval), Cohort Manager (implementation and daily oversight), Site Coordinators (acknowledgment of SOP)

### 18. Month 24 (2028-10-13) Go/No-Go Gate Decision Dossier

**ID:** 185bf486-9165-4149-ba9b-4d920d361131

**Description:** Comprehensive summary document (30–50 pages) for the editorial board's Month 24 (2028-10-13) go/no-go decision, containing: pilot design overview and enrolled-sample demographics, four gate metrics results (ordinal error reduction %, comprehension speed comparison, pronunciation consistency kappa scores, 30-day retention %), statistical significance tests and effect-size estimates, pre-registered thresholds and how each metric fared (GO/NO-GO per metric), data-quality assessment (missing data, outliers, inter-rater reliability, early-dropout impact), fidelity findings (curriculum adherence, site compliance), qualitative feedback from site coordinators and learners, validity discussion (were the metrics measuring what they intended?), minority positions from board members if any metrics disagreed with the threshold, and a recommendation for GO, INCONCLUSIVE, or NO-GO. Includes appendices (detailed statistical tables, learner quotes, site-compliance summaries). Completed by Month 24 (2028-10-13) and published on the project website within 2 weeks for transparency.

**Responsible Role Type:** Psychometrician / Data Analyst

**Primary Template:** NIH Phase II Clinical Trial Decision Summary

**Secondary Template:** ISO 13374 Data interpretation standard (for evidence summarization)

**Steps:**

- By Month 22 (2028-08-13), data lock: all participant assessments must be complete and scored by this date (Month 23 = 2028-09-13 allow 30-day follow-up completion to occur and be scored by Month 24 = 2028-10-13)
- By Month 22.5 (2028-08-28), psychometrician conducts preliminary data-quality checks: missing data patterns (identify any participants with incomplete data streams), outliers (flagged via z-score or interquartile-range methods; decision made case-by-case whether to exclude, transform, or retain), inter-rater reliability audits (verify kappa ≥0.70 for pronunciation scoring; if kappa drops below 0.70 post-hoc, flag as a data-quality issue and discuss whether pronunciation metric is valid)
- By Month 23 (2028-09-13), psychometrician completes primary analysis: calculate effect sizes and statistical significance tests for each gate metric using pre-registered intention-to-treat protocol (all enrolled participants analyzed in their assigned condition, regardless of compliance or dropout). Report: ordinal error reduction (% difference between Clear English and control arm, 95% confidence interval, p-value), comprehension speed (mean reading time comparison, Cohen's d effect size, significance), pronunciation consistency (Cohen's kappa ≥0.75 target or ≥0.70 floor, mean kappa score by rater pair and overall), 30-day retention (% of immediate post-test performance retained at 30 days, comparison to control). Include subgroup analyses if sample size allows (e.g., effect by first language, ESL proficiency level, age) and sensitivity analyses (e.g., excluding outliers, intention-to-treat vs. completer-only). Prepare detailed statistical report (10–15 pages) with tables and figures.
- By Month 23 (2028-09-13), curriculum-fidelity analysis: summarize site compliance with curriculum protocol (which rules were taught, which were missed?), learner engagement and comprehension (based on engagement survey and assignment quality), and any rule-implementation barriers (ambiguities, learner confusion, site-level deviations). Report frequencies (e.g., 'site A: 95% fidelity, site B: 87% fidelity, overall: 91%') and qualitative themes (e.g., 'learners requested more pronunciation examples,' 'ordinal prefix took 3 exposures, not 2, to master'). Qualitative findings help interpret metric results (e.g., if comprehension is slower, is it due to the rules or due to poor curriculum fidelity at one site?).
- By Month 23.5 (2028-09-28), editorial-board lead (program director) compiles the Gate Decision Dossier: (a) executive summary (1–2 pages: pilot design, enrolled sample, gate metrics results, recommendation); (b) pilot design section (2–3 pages: enrollment targets and achieved sample, cohort characteristics [age, language background, proficiency level], attrition analysis [dropout rates by session, reasons], data-quality issues); (c) metrics results section (8–12 pages: for each of the four metrics, report descriptive statistics, primary analysis result, comparison to pre-registered threshold, significance test, and interpretation); (d) data-quality and validity discussion (3–4 pages: missing-data pattern, inter-rater reliability outcome, potential confounds and how they were controlled, construct-validity evidence); (e) fidelity findings (2–3 pages: summary of curriculum adherence by site, learner engagement, rule-learning curves); (f) qualitative feedback (1–2 pages: representative quotes from site coordinators and learners about rule clarity, usability, acceptance); (g) minority positions (if a board member or external reviewer disagreed with the interpretation, publish their position and the majority response); (h) conclusion and recommendation: GO (all four metrics met pre-registered thresholds with valid data), INCONCLUSIVE (1–2 metrics borderline, data quality mixed, recommend 3–6 month extension for additional data or resolution), or NO-GO (≥2 metrics failed pre-registered thresholds or data quality was compromised such that metrics are uninterpretable)
- By Month 24 (2028-10-13), psychometrician and program director present the dossier to the editorial board at a special meeting. Board votes on the recommendation (GO/INCONCLUSIVE/NO-GO) using the pre-registered voting rules (simple majority, linguist review for any rule-interpretation issues). Minority positions are published alongside the majority decision.
- Within 2 weeks of the board decision, publish the full Gate Decision Dossier (with statistical tables, learner quotes, methodology details) on the project website. Publish an executive summary (2–3 page lay-friendly version) in the project newsletter and on social media. This transparency prevents later claims that the gate was rigged or data were hidden.

**Approval Authorities:** Independent Psychometrician (data analyst and primary author), Editorial Board (voting on recommendation), Program Director (final sign-off and publication)

### 19. Change-Control and Release Cadence Policy

**ID:** e5abd75b-0f30-4732-8db8-bec33ccb08d4

**Description:** Document specifying how the Clear English Standard changes after v1.0 publication: freeze period (v1.0 frozen for 12 months, errata-only), scheduled v2.0 review (proposed timeline and process), version-numbering scheme (1.0, 1.1 errata, 2.0 major revision), deprecation notice procedures, and conversion tables for users migrating between versions. Addresses Decision 10 and prevents fragmentation or uncontrolled rule changes during Phase 3 adoption. Guides third-party adopters' versioning strategy. Published by Month 12 (2027-10-13).

**Responsible Role Type:** Project Manager / Editorial Board Chair

**Primary Template:** Semantic Versioning (semver.org) standard

**Secondary Template:** ISO 639 language-code versioning and change-control procedures

**Steps:**

- By Month 6 (2027-04-13), convene the Editorial Board to decide on a change-control and release cadence (Decision 10: three options: frozen v1.0, scheduled minor revisions, or candidate-standard with public-comment cycles)
- Draft a 2–3 page Change-Control Policy specifying: (a) v1.0 freeze period (12 months from release, proposed); (b) errata definition and handling (what qualifies as an errata vs. a rule change); (c) errata-publication process (errata published on project website with rationale, no reprints required; printed materials carry an 'errata notice' URL); (d) v2.0 review process (scheduled for Month 36–48 = 2029-10-13 to 2030-10-13, proposed, involving full board review, stakeholder comment, and 6-month revision); (e) version-numbering scheme (1.0, 1.0.1 errata, 2.0, 2.1, etc.); (f) deprecation notice (any version older than 5 years is marked 'legacy'; support is offered but no guarantee of responsiveness)
- Publish the Change-Control Policy on the project website by Month 12 (2027-10-13); alert all adopters and stakeholders of the versioning scheme and change-request procedures

**Approval Authorities:** Editorial Board (majority vote on cadence), Project Manager (implementation)

### 20. Financial Audit and Contingency-Reserve Release Decision Framework

**ID:** bc36c61c-26f2-40f0-b374-5fbb8f55c4fc

**Description:** Document establishing the decision rules for releasing the $0.35M reserve fund: pre-gate draws (capped at $175K for gate-protection needs), post-go decision reserve release (the remaining $175K released to Phase 3 if GO, returned to funder if NO-GO), and contingency triggers (budget overrun >$100K cumulative, timeline slip >4 weeks, data-quality issues requiring rework). Guides the Month 9 (2027-07-13) Phase 1 financial review and Month 24 (2028-10-13) gate decision. Prepared by the budget officer and approved by the program sponsor.

**Responsible Role Type:** Budget Officer / Financial Manager

**Primary Template:** PMI Project Budget Baseline and Variance Procedures

**Secondary Template:** US Federal Grants Management contingency and reserve-release policies

**Steps:**

- By Month 2 (2026-12-13), establish contingency-reserve decision framework: (a) pre-gate reserve draws (up to $25K by project lead without board approval for pre-registered gate-protection needs; $25K–$175K with board approval within 5 days); (b) draw triggers (kappa <0.70 at Month 10 = 2027-08-13, requiring rater retraining; recruitment shortfall >15% by Month 8 = 2027-06-13, requiring acceleration tactics; audio-production cost >$20 per entry, requiring hybrid model pivot); (c) post-gate reserve release decision (board votes to release remaining $175K to Phase 3 only if gate outcome is GO, or return to funder if NO-GO); (d) no-go contingency (if Phase 2 is extended by 3–6 months, the additional cost is drawn from reserve first, then from Phase 3 budget if reserve is exhausted)
- Publish the contingency-reserve decision framework on the project intranet by Month 3 (2027-01-13) so that all team members understand when and how reserve draws can be requested

**Approval Authorities:** Budget Officer (framework design), Program Sponsor (reserve approval authority), Editorial Board (post-gate release decision)

### 21. Quarterly Project Status and Risk Briefing

**ID:** 3c0db14f-0127-46d2-9d97-32fc927f4ad2

**Description:** Short (2–3 page) executive briefing prepared quarterly (Months 3, 6, 9, 12, 18, 24, 30, 36 = 2027-01-13 through 2029-10-13) covering: progress toward milestones, earned-value metrics (Schedule Performance Index, Cost Performance Index), top 3 active risks and mitigation status, any contingency-reserve draws or scope changes in the prior quarter, and forward-looking issues anticipated in the next quarter. Intended audience: editorial board, program sponsor, and external funders.

**Responsible Role Type:** Project Manager / Communication Lead

**Primary Template:** PMI Project Status Report template

**Secondary Template:** Grant-funder quarterly progress-report template

**Steps:**

- By Month 3 (2027-01-13), establish quarterly briefing format and distribution list
- For each quarter, compile: (a) milestone progress (rules drafted? lexicon coverage audit complete? audio production on schedule?); (b) financial status (actual spend vs. budget, contingency draws, forecast to completion); (c) risk status (top risks, mitigation progress, new risks identified); (d) team news (staffing changes, key hires, departures); (e) forward look (next quarter milestones, anticipated decisions or challenges)
- Publish each quarterly briefing on the project website within 2 weeks of month-end

**Approval Authorities:** Project Manager (lead author), Editorial Board Chair (review and sign-off)

## Documents to Find

### 1. ESL Learner Corpus and Frequency Data

**ID:** c7580490-a507-489a-b615-884e736dbb1a

**Description:** Large corpus of English text produced by or targeted at adult ESL learners (e.g., Cambridge English Learner Corpus, TOEFL corpus, COCA General Academic subsection, JACET list of academic words). Required to derive the 5,000-word core lexicon by frequency ranking and to identify the highest-frequency irregular verbs and morphologically complex words that must be retained for learnability. Intended audience for analysis: lexicon designer.

**Recency Requirement:** Most recent available version (corpus data is cumulative; updates are beneficial but not time-critical for word-frequency ranking).

**Responsible Role Type:** Linguistic Specialist / Corpus Analyst

**Access Difficulty:** Easy to Medium. COCA is freely available online; Cambridge Corpus requires institutional subscription (typically free via university library access); TOEFL lists are public. Compile into a ranked lexicon by Month 3 (2027-01-13).

**Steps:**

- Search 'Cambridge English Learner Corpus' on the Cambridge University Press or Cambridge Assessment websites; request access via institutional subscription or research-licensing agreement.
- Search 'COCA Corpus of Contemporary American English' (Mark Davies' corpus at Brigham Young University); freely available online with frequency lists and word concordance tools.
- Search 'TOEFL word list' and 'GRE vocabulary list' for academic-vocabulary rankings; available from Educational Testing Service and other test publishers.
- Contact applied-linguistics researchers at universities with ESL-research programs (University of Michigan, University of Pennsylvania, University of Minnesota) for access to in-house ESL learner corpora or compiled frequency lists.

### 2. Existing English Irregular Verb and Morphology Error Databases

**ID:** 3dc2b5a3-8804-4046-8846-c003e51081b0

**Description:** Published research databases and learner-error corpora (e.g., ELEC corpus from Chujo & Hasegawa, learner error corpora compiled by ESL-assessment organizations) documenting which irregular verbs and plural forms are most frequently misused or cause learning difficulty for adult ESL learners. Required to rank the morphology retention threshold (which irregulars to keep, which to regularize) and to identify the highest-friction patterns. Intended audience: morphology-rule workstream lead.

**Recency Requirement:** Prefer studies published within the last 10 years (2016–2026 estimate); morphology acquisition patterns are stable over time, so older research is acceptable if recent is unavailable.

**Responsible Role Type:** Linguistic Specialist / Applied Linguist

**Access Difficulty:** Medium. Published studies are freely available via academic databases (Google Scholar, ResearchGate); access to corpus data may require emailing authors or institutional subscription. Compile by Month 5 (2027-03-13).

**Steps:**

- Search 'ELEC corpus' (corpus of English learner errors compiled by Kiyomi Chujo, Waseda University); available via academic publications and corpus-sharing repositories.
- Search PubMed and Google Scholar for peer-reviewed studies on 'English morphology acquisition ESL' or 'irregular verb learning errors adult learners'; download full-text PDFs from university library access.
- Contact the TESOL Research Interest Group and ask for recommended learner-error corpora or morphology studies; reach out to applied-linguistics researchers at ESL-assessment organizations (Cambridge, TOEFL, IELTS).
- Review the error taxonomy in major ESL-assessment scoring rubrics (e.g., TOEFL Independent Writing Rubric) for documented patterns of morphology and verb-form errors.

### 3. ASD-STE100 Simplified Technical English Standard and Vocabulary List

**ID:** e93b639f-ca75-4c05-b5e1-62df389d48b4

**Description:** Official specification of the ASD-STE100 standard (Simplified Technical English) including the approved-word list (~1,000 words), writing rules (~60 rules), and examples. Required for the Controlled-Language Alignment Posture decision (Decision 12) to assess compatibility between Clear English and existing controlled-language standards, and to identify any overlap in technical vocabulary for the safety-critical glossary cohort. Intended audience: linguistic specialist and controlled-language alignment workstream.

**Recency Requirement:** Current issue of ASD-STE100 (issued and updated periodically by the ASD STE100 Maintenance Group). Obtain the most recent release available at the time of analysis (Months 2–3 = 2026-12-13 to 2027-01-13).

**Responsible Role Type:** Linguistic Specialist / Standards Analyst

**Access Difficulty:** Medium. Official specification may require membership or purchase; public information and compatibility discussions are available through the STEMG contact process. Obtain by Month 3 (2027-01-13).

**Steps:**

- Visit the official ASD-STE100 website (https://www.asd-ste100.org) and navigate to the specification and vocabulary-download pages.
- Request the ASD-STE100 specification and vocabulary list via the official contact form; may require membership or licensing fee (~$500–$2,000 USD estimate, or free for certain institutional affiliations).
- Contact the ASD STE100 Maintenance Group (STEMG) via email to request the specification and discuss compatibility with Clear English; the group may have public-domain excerpts or open-access documentation.
- Search for peer-reviewed publications or technical reports on ASD-STE100 that publish examples or word lists; these are often freely available on ResearchGate or university repositories.

### 4. Homograph and Homophone Lists for English (Including Specialized Domains)

**ID:** b0d2d465-7f48-4c9a-949a-e22839d65ed0

**Description:** Comprehensive list of English homographs (same spelling, different pronunciation/meaning; e.g., lead/lead, read/read) and homophones (same pronunciation, different meaning; e.g., to/two/too) with frequency rankings and domain relevance (common in technical, medical, legal, or general English). Required for Homograph Disambiguation Policy (Decision 7) to define which pairs must be marked, which are low-priority, and which are domain-specific. Intended audience: homograph-policy workstream lead and safety-critical curriculum designer.

**Recency Requirement:** Existing lists of homographs are stable (no recent updates expected); use any authoritative source published in the last 15 years.

**Responsible Role Type:** Linguistic Specialist / Semanticist

**Access Difficulty:** Easy. Homograph lists are published in linguistics textbooks and online dictionaries; many are freely available. Compile a prioritized list by Month 4 (2027-02-13).

**Steps:**

- Search 'English homograph list' and 'English homophone list' on Google Scholar, Academia.edu, or ResearchGate; download academic papers that compile and rank homographs by frequency.
- Consult specialized dictionaries and corpus-analysis tools: search for 'homograph' in the Online Etymology Dictionary, Merriam-Webster, or the Oxford English Dictionary (OED) unabridged edition.
- Search for domain-specific homograph lists in technical-writing and safety-documentation standards (e.g., FAA style guide, medical-device documentation guidelines, pharmacy and pharmaceutical regulatory guidance) to identify high-impact pairs in safety-critical contexts.
- Use corpus-analysis software (AntConc, SketchEngine) to identify ambiguous words in the core lexicon and check whether they appear in multiple senses in the corpus.

### 5. ICAO Language Proficiency Requirements and Aviation English Assessment Data

**ID:** 957ccb9b-9591-4b49-9ba5-615668533128

**Description:** Official ICAO Annex 1 and Doc 9835 (Manual on the Implementation of ICAO Language Proficiency Requirements) and supporting research on pronunciation consistency, inter-rater reliability, and accent variation in aviation contexts. Required to benchmark pronunciation-consistency measurement and inter-rater training procedures (Decision 8: Reference Accent Anchor) and to identify precedents for rater calibration in safety-critical settings. Intended audience: psychometrician and pronunciation-guidance specialist.

**Recency Requirement:** Most recent ICAO Annex 1 (updated periodically); Annex is current to 2025 estimate. Supporting research published in the last 10 years (2016–2026 estimate) on language proficiency assessment and inter-rater reliability.

**Responsible Role Type:** Psychometrician / Assessment Specialist

**Access Difficulty:** Medium. Official ICAO documents require purchase; research papers are freely available via academic databases. Obtain by Month 4 (2027-02-13).

**Steps:**

- Visit the ICAO website (https://www.icao.int) and download Annex 1 and Doc 9835 from the official ICAO store (may require purchase, ~$100–$200 USD estimate).
- Contact ICAO's Air Navigation Bureau via email to request sample documents or publicly available excerpts.
- Search Google Scholar for peer-reviewed papers on 'ICAO aviation English assessment,' 'inter-rater reliability aviation proficiency,' or 'pronunciation assessment standardization'; download full texts via university library or author email.

### 6. Existing ESL and Technical-Writing Textbooks and Curricula (Sample Materials)

**ID:** 2e43572b-b45d-4cec-b987-d41dae20b19e

**Description:** Representative ESL textbooks (e.g., Cambridge English series, Oxford English series), ESL course syllabi, and technical-writing training materials from pilot partner organizations to use as a corpus for the lexicon-coverage audit (confirming that the 5,000-word core lexicon covers ≥85% of running text in actual pilot curricula). Intended audience: lexicon designer and curriculum analyst.

**Recency Requirement:** Textbooks and curricula in current use (published within the last 5 years, 2021–2026 estimate). Historical or outdated materials are not suitable for coverage audit.

**Responsible Role Type:** Curriculum Designer / Lexicon Analyst

**Access Difficulty:** Medium to Easy. ESL textbooks are widely available; pilot partner materials require signed agreements and may be confidential. Obtain sample materials by Month 4 (2027-02-13); complete coverage audit by Month 8 (2027-06-13).

**Steps:**

- Request sample ESL textbooks and course materials from pilot partner organizations (ESL programs and community colleges identified by Month 3 = 2027-01-13); ask them to provide 1–2 complete units (e.g., a chapter from a Cambridge English grammar book, or a week's worth of lesson materials).
- Purchase or borrow from university library: Cambridge English, Oxford English, and ESL textbook series are widely available in academic libraries.
- Search for publicly available ESL syllabi and curriculum guides online (e.g., via Open Education Resources platforms like OpenStax or Merlot); access free digital versions of ESL materials.
- Request technical-writing and safety-documentation samples from pilot partners (manufacturing, pharmaceutical, or utility companies with training programs); these materials are often confidential but may be shared under a non-disclosure agreement.

### 7. US State and UK (Ofqual) Education Standards and Curriculum Guidance for Adult ESL

**ID:** 366c3aac-28a7-4e5b-b728-dd92abe14b0b

**Description:** Official education-curriculum standards and guidance from US state education departments and UK Ofqual (Office of Qualifications and Examinations Regulation) specifying ESL learning objectives, proficiency levels, and alignment requirements for accredited ESL programs. Required to assess regulatory fit (whether Clear English can be integrated into accredited programs without violating curriculum standards) and to inform the Regulatory Engagement strategy (Decision 12). Intended audience: regulatory affairs manager and educational standards liaison.

**Recency Requirement:** Current standards (updated every 3–5 years; use the most recent version available in 2026–2027 estimate).

**Responsible Role Type:** Regulatory Affairs Manager / Educational Policy Analyst

**Access Difficulty:** Easy. Education standards are publicly available online; contact with state agencies is typically responsive. Obtain by Month 4 (2027-02-13).

**Steps:**

- Search each US state education department website (e.g., California Department of Education, Texas Education Agency, Massachusetts Department of Elementary and Secondary Education) for 'adult ESL standards' or 'English language learner standards'.
- Visit Ofqual website (https://www.gov.uk/government/organisations/ofqual) and search for 'English language standards,' 'GCSE English,' and 'functional skills English' guidance.
- Contact state education agency ESL coordinators and ask them to email the relevant standards documents and any guidance on approving supplementary or variant materials.
- Search CEFR (Common European Framework of Reference) guidance and its implementation across US and UK curricula; CEFR is freely available online and widely used as a curriculum reference.

### 8. Research Literature on Adult ESL Learning Outcomes, Effect Sizes, and Pronunciation Acquisition

**ID:** d8abe0fc-3db8-4f0d-9205-dc397ce4b9eb

**Description:** Peer-reviewed empirical research on adult ESL reading comprehension, morphology and irregular-verb learning, pronunciation acquisition, and long-term retention (30-day and beyond). Required to establish effect-size assumptions for power analysis (Outcome Metric Battery Design, Decision 4), to benchmark gate thresholds (e.g., is a 25% improvement in ordinal-error rate realistic?), and to inform pronunciation-consistency measurement design. Intended audience: psychometrician and applied linguist.

**Recency Requirement:** Prefer studies published in the last 10 years (2016–2026 estimate); older foundational studies (1990–2015 estimate) are acceptable if recent research is sparse.

**Responsible Role Type:** Psychometrician / Applied Linguist

**Access Difficulty:** Medium to Easy. Research papers are freely available via Google Scholar and ResearchGate (author-hosted PDFs); some require university library subscription or author email request. Compile literature review by Month 5 (2027-03-13).

**Steps:**

- Search PubMed, ERIC (Education Resources Information Center), Google Scholar, and Linguistics and Language Behavior Abstracts (LLBA) for: 'adult ESL reading comprehension effect size,' 'ESL morphology learning,' 'pronunciation accuracy adult learners,' '30-day language retention.'
- Search 'Krashen acquisition hypothesis' and 'comprehensible input' for foundational ESL learning theory; these are widely cited and available in university libraries.
- Contact research centers specializing in ESL and applied linguistics (e.g., Center for Applied Linguistics, University of Michigan School of Education, Georgetown University ESL program) and ask them to recommend key papers and effect-size estimates.
- Review meta-analyses and systematic reviews on ESL interventions (search 'ESL intervention meta-analysis') to extract aggregated effect-size data.

### 9. Safety-Critical Documentation Standards and Best-Practice Guidance

**ID:** e0a8f8c9-6cbe-44a7-8f17-02a9fabc40ba

**Description:** Official standards and best-practice documents for safety-critical documentation (e.g., IEC 62304 for medical devices, DO-178C for aviation software, ISO 26262 for automotive functional safety, workplace safety standards like OSHA regulations, HSE guidance). Required for the Safety-Critical Adoption Wedge decision, liability assessment (Decision 7: Homograph Disambiguation Policy applied to safety contexts), and design of the safety-critical pilot cohort. Intended audience: technical-writing specialist, legal counsel, and safety-critical curriculum designer.

**Recency Requirement:** Current standards (updated every 5–10 years; use versions current to 2024–2026 estimate).

**Responsible Role Type:** Technical Writing Specialist / Legal Counsel

**Access Difficulty:** Medium. Official standards require purchase, but universities often have subscriptions; regulatory and HSE guidance is free. Obtain by Month 4 (2027-02-13).

**Steps:**

- Search IEC, ISO, and ANSI websites for the official standards documents; many are available for purchase (~$100–$500 USD per standard). Universities often have institutional subscriptions.
- Search FAA website (Federal Aviation Administration) for 'FAA style guide' and 'aviation English' best practices; FAA guidance is publicly available.
- Search OSHA website (US Occupational Safety and Health Administration) for 'hazard communication standard,' 'labeling requirements,' and 'procedure documentation guidance'; OSHA guidance is freely available.
- Contact HSE (UK Health and Safety Executive) via their website and request guidance on technical documentation and workplace communications.
- Search Google Scholar for peer-reviewed papers on 'medical device documentation clarity,' 'safety-critical software documentation standards,' or 'procedure readability in operational settings.'

### 10. Existing Incident Reports and Near-Miss Records from Safety-Critical Sectors (Anonymized or Aggregated)

**ID:** 92dddeac-2f09-42c0-8a74-8871339ee0e8

**Description:** Aggregated or anonymized incident data (e.g., OSHA incident reports, HSE near-miss summaries, FAA accident investigation summaries, pharmacological adverse-event reports from FDA MedWatch) where documentation ambiguity, unclear labeling, or procedure misinterpretation contributed to the incident. Required for the Core Lexicon Selection Basis decision (incident-driven vocabulary selection) and to justify the high-impact homograph list for safety-critical contexts. Intended audience: safety-critical curriculum designer and lexicon analyst.

**Recency Requirement:** Most recent available incident data (5–10 years, 2016–2026 estimate); aggregated summaries are more accessible than individual case files.

**Responsible Role Type:** Safety Specialist / Technical Writer

**Access Difficulty:** Medium. Public incident summaries are available online; detailed case files may be confidential. Access aggregated data by Month 4 (2027-02-13) to inform the lexicon and homograph policy; specific case details may be restricted but are not critical for design purposes.

**Steps:**

- Search OSHA database (https://www.osha.gov) for public incident summaries and case studies involving documentation-related incidents.
- Search HSE website (https://www.hse.gov.uk) for 'major incident reports' and 'near-miss case studies'; many are published in aggregated form.
- Search FAA Safety Data Reporting System (SDRS) and National Transportation Safety Board (NTSB) accident investigation summaries for documentation-related factors (freely available online).
- Contact the pharmacological safety-monitoring authorities (FDA MedWatch, EMA PharmGKB) for aggregated adverse-event data involving medication-error or labeling-confusion incidents (some data are publicly available; specific cases may require authorization).
- Contact workplace-safety training organizations and consult incident case-study libraries they maintain.

### 11. ESL Publisher Catalogs and Current Curriculum Offerings

**ID:** a49d857e-190c-42e6-b9ad-22555841c2eb

**Description:** Catalogs and sample materials from major ESL publishers (Cambridge University Press, Oxford University Press, Pearson, Cengage, National Geographic Learning, etc.) showing current ESL curriculum offerings, vocabulary coverage, and supplementary-module options. Required to assess publisher interest in Clear English adoption (Adoption Wedge decision) and to position Clear English as a supplementary module compatible with existing curricula. Intended audience: adoption-wedge workstream lead and ESL-curriculum liaison.

**Recency Requirement:** Current catalogs (2025–2026 estimate); older catalogs (2020+) show trend and may be acceptable if current are unavailable.

**Responsible Role Type:** Adoption and Outreach Lead

**Access Difficulty:** Easy. Publisher catalogs are freely available online or via email request. Obtain by Month 3 (2027-01-13) for the adoption-wedge analysis.

**Steps:**

- Visit publisher websites (Cambridge.org, Oxford University Press, Pearson, Cengage Learning) and download current ESL curriculum catalogs and course descriptions.
- Request sample ESL materials and curriculum guides directly from publisher customer-service teams; most publishers provide free sample chapters and syllabus templates.
- Attend TESOL International Convention (annual, typically March–April) and contact publisher booths to discuss Clear English compatibility with their curricula; collect business cards and follow up with emails.
- Search for recent ESL-curriculum reviews in TESOL Quarterly or other peer-reviewed journals; these may cite publisher offerings and adoption trends.

### 12. TESOL and IATEFL Professional Organization Governance and Endorsement Processes

**ID:** 51966ace-30da-4877-9831-e849d0a3de3b

**Description:** Official documentation from TESOL International Association and IATEFL (International Association of Teachers of English as a Foreign Language) specifying how these professional organizations review, endorse, or recommend language standards, curricula, and assessment tools to their members. Required to understand the pathway for Clear English to be endorsed or recommended by major ESL professional organizations, and to position the project as aligned with professional values. Intended audience: stakeholder-engagement and adoption-strategy workstream.

**Recency Requirement:** Current governance and endorsement policies (updated periodically; use the most recent available in 2026).

**Responsible Role Type:** Stakeholder Engagement Lead / Educational Standards Liaison

**Access Difficulty:** Easy. Professional organization policies are publicly available on websites or available via email request. Obtain by Month 2 (2026-12-13).

**Steps:**

- Visit TESOL International website (https://www.tesol.org) and search for 'standards endorsement,' 'curriculum review,' and 'professional recommendations'; download policy documents.
- Visit IATEFL website (https://www.iatefl.org) and search for similar governance and endorsement processes.
- Contact TESOL and IATEFL leadership (executive director, research committee chair) via email; ask them to explain the pathway for a language standard to be reviewed and endorsed.
- Review past TESOL positions or resolutions on language standards and language variation (e.g., 'TESOL Position Statement on Multilingualism and Multiculturalism' available on website).

### 13. Pronunciation and Phonetics Teaching Research (Pronunciation Accuracy, Inter-Rater Reliability, Accent Pedagogy)

**ID:** d510c573-3bd3-4035-a60e-d7cfd69a7f98

**Description:** Peer-reviewed research on pronunciation teaching and assessment in adult ESL contexts, including studies on inter-rater reliability (Cohen's kappa) in pronunciation assessment, effect of native-like accent on comprehensibility, and strategies for teaching standard-English pronunciation to diverse learner populations. Required to design the pronunciation-consistency metric and inter-rater training (Pronunciation Guidance System, Decision 8), and to establish realistic targets for pronunciation accuracy. Intended audience: phonetics specialist and psychometrician.

**Recency Requirement:** Prefer studies published in the last 15 years (2011–2026 estimate); foundational studies on IPA and pronunciation teaching pedagogy are timeless and may be older.

**Responsible Role Type:** Phonetics and Pronunciation Specialist / Psychometrician

**Access Difficulty:** Medium to Easy. Research papers are freely available on Google Scholar and ResearchGate; some require university library subscription. Compile by Month 4 (2027-02-13).

**Steps:**

- Search Google Scholar, ERIC, and LLBA for: 'pronunciation assessment ESL,' 'inter-rater reliability pronunciation,' 'native-like accent comprehensibility,' 'accentedness acceptability ESL learners.'
- Review textbooks on ESL pronunciation teaching (e.g., Celce-Murcia, Brinton & Goodwin 'Teaching Pronunciation'; Dalton & Seidlhofer 'Pronunciation'; Jenkins 'World Englishes') for frameworks and empirical findings.
- Contact applied-linguistics researchers specializing in pronunciation at universities with strong ESL programs (e.g., University of Michigan, Georgia State University, University of Texas at Austin) and ask them to recommend key papers.

### 14. Corpus of English Spelling Irregularities and Grapheme-to-Phoneme Mapping Rules

**ID:** 310887a3-943c-472d-bbe9-9c832956e4df

**Description:** Linguistic research or curated corpus documenting the patterns of English spelling-to-sound irregularities (grapheme-to-phoneme mismatches), such as the 'ough' patterns (rough, through, though, thorough, dough), vowel digraphs (ea, ei, ie), and silent letters. Required to design the Grapheme-to-Phoneme Intervention rules (Decision 2) and to prioritize which words in the core lexicon need the most pronunciation guidance. Intended audience: linguistic specialist and pronunciation specialist.

**Recency Requirement:** Existing linguistic descriptions of English phonology are stable; use any authoritative source published in the last 30 years.

**Responsible Role Type:** Linguistic Specialist / Phonetics Specialist

**Access Difficulty:** Easy. Phonology and linguistics textbooks are widely available in university libraries. Compile by Month 3 (2027-01-13).

**Steps:**

- Consult foundational linguistics and phonology textbooks (e.g., Fromkin & Rodman 'An Introduction to Language'; Yavaş 'Applied English Phonology') for descriptions of English grapheme-to-phoneme patterns.
- Search for 'English spelling-sound correspondences' and 'English phonology exceptions' in academic databases; many linguistics papers analyze irregular patterns.
- Consult the English Phonetics and Phonology section of linguistics handbooks (e.g., Oxford Handbook of the History of English).
- Use online phonetic resources (e.g., Howjsay, Pronunciation Guide) to systematically check how various spelling patterns are pronounced; compile a list of high-friction patterns (those with multiple pronunciations or unexpected pronunciations).

### 15. Office of the Registrar or Standards-Authority Contact Lists for TESOL, Ofqual, and State Education Departments

**ID:** 4ff8a5de-ef0f-44dc-9f9f-790146705744

**Description:** Contact directories and organizational structures for TESOL International, IATEFL, Ofqual (UK), US state education departments (California, Texas, New York, etc.), CEFR governance bodies, and ISO language-standards committees. Required to identify the regulatory affairs and stakeholder engagement contacts to approach by Month 2–3 (2026-12-13 to 2027-01-13) for advisory input on the Clear English adoption pathway. Intended audience: regulatory affairs manager and stakeholder-engagement lead.

**Recency Requirement:** Current contact information (2025–2026); organization structures are relatively stable but should be verified by directly visiting organization websites.

**Responsible Role Type:** Regulatory Affairs Manager

**Access Difficulty:** Easy. All contact information is publicly available on organization websites. Compile by Month 1 (2026-11-13).

**Steps:**

- Visit TESOL International website and search for 'contact us,' 'research committee,' and 'organizational leadership'; compile contact info for executive director, research chair, and regional coordinators.
- Visit Ofqual website (gov.uk/ofqual) and search for 'contact,' 'English standards,' and 'consultation processes'; note the relevant Ofqual divisions (Vocational and Technical, GCSEs, etc.) that oversee ESL or language standards.
- Visit each state education department website (California, Texas, New York, Massachusetts, Florida) and search for 'ESL coordinator,' 'language standards contact,' or 'adult education division'; compile email addresses.
- Search for CEFR governance and contact information via the Council of Europe website (coe.int).

### 16. List of University Linguistics and Applied-Linguistics Departments and Research Centers (ESL, Phonetics, Assessment Specialists)

**ID:** 089d77b3-8509-4bf1-bea3-8f21f3851b42

**Description:** Compiled list of universities with strong applied-linguistics, ESL, and psychometric-assessment programs (e.g., University of Michigan, University of Pennsylvania, Georgetown University, University of Texas at Austin, UCLA, USC, University of Minnesota), including contact info for department chairs, research-center directors, and specialists in ESL assessment, pronunciation pedagogy, and language standards. Required for recruiting the independent psychometrician, pronunciation specialist, and external expert reviewers by Month 2 (2026-12-13). Intended audience: recruiting and hiring workstream.

**Recency Requirement:** Current departmental contact information (2025–2026); verify via university websites before contacting.

**Responsible Role Type:** Project Manager / Recruiting Coordinator

**Access Difficulty:** Easy. University websites and departmental directories are publicly available. Compile by Month 1 (2026-11-13).

**Steps:**

- Search 'universities with ESL programs' or 'applied linguistics graduate programs' online; use university ranking websites (QS, Times Higher Education) to identify leading ESL and linguistics departments.
- Visit each identified university's department website and compile contact info for faculty specializing in assessment, phonetics, and ESL pedagogy.
- Search for 'centers for applied linguistics' and 'ESL research centers'; contact centers like the Center for Applied Linguistics (CAL) in Washington, DC, or university-based centers.