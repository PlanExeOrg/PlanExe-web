### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and direction for the project, given its high-risk, high-reward nature, significant budget, and ethical complexities. Ensures alignment with overall organizational goals and manages strategic risks.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic direction and guidance.
- Monitor project progress against strategic objectives.
- Approve major changes to project scope, budget, or timeline (>$10M USD).
- Oversee risk management at a strategic level.
- Resolve strategic conflicts and escalate issues as needed.
- Approve the Ethical Justification Narrative.
- Approve the International Legal Framework Navigation strategy.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define escalation paths.
- Approve initial project plan.

**Membership:**

- CEO
- CFO
- Chief Medical Officer
- Head of Legal
- Independent Ethics Advisor (External)
- Project Director

**Decision Rights:** Strategic decisions related to project scope, budget, timeline, and strategic risks. Any budget change exceeding $10M USD requires Steering Committee approval.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the CEO has the deciding vote.

**Meeting Cadence:** Quarterly, or more frequently as needed.

**Typical Agenda Items:**

- Review project progress against strategic objectives.
- Review and approve budget and timeline updates.
- Review and approve risk management plans.
- Discuss and resolve strategic issues.
- Review Ethical Oversight Committee reports.
- Review legal and compliance reports.

**Escalation Path:** Board of Directors
### 2. Core Project Team

**Rationale for Inclusion:** Manages the day-to-day execution of the project, ensuring efficient operations and adherence to the project plan. Addresses operational risks and implements mitigation strategies.

**Responsibilities:**

- Develop and maintain detailed project plans.
- Manage project budget and resources.
- Track project progress and report to the Project Steering Committee.
- Identify and manage operational risks.
- Implement mitigation strategies.
- Coordinate activities across different project teams.
- Make operational decisions within approved budget and scope (up to $10M USD).
- Manage the Agnate Development Methodology.
- Manage the Facility Security Perimeter.

**Initial Setup Actions:**

- Define team roles and responsibilities.
- Establish communication protocols.
- Set up project management tools.
- Develop detailed project schedule.

**Membership:**

- Project Manager
- Chief Medical Officer
- Head of Security
- Lead Geneticist
- Facility Construction Manager
- Head of Procurement

**Decision Rights:** Operational decisions related to project execution, resource allocation, and risk management within approved budget and scope. Any budget change up to $10M USD can be approved by the Core Project Team.

**Decision Mechanism:** Decisions made by consensus. If consensus cannot be reached, the Project Manager makes the final decision, documenting the rationale.

**Meeting Cadence:** Weekly.

**Typical Agenda Items:**

- Review project progress against plan.
- Discuss and resolve operational issues.
- Review and update risk register.
- Review budget and resource utilization.
- Coordinate activities across different project teams.

**Escalation Path:** Project Steering Committee
### 3. Ethical Oversight Committee

**Rationale for Inclusion:** Provides independent ethical review and guidance for the project, given its ethically sensitive nature. Ensures adherence to ethical principles and minimizes reputational risks.

**Responsibilities:**

- Review and approve ethical protocols for agnate development and organ harvesting.
- Monitor agnate well-being and ensure humane treatment.
- Investigate and address ethical concerns raised by staff or external stakeholders.
- Provide recommendations to the Project Steering Committee on ethical issues.
- Ensure compliance with international ethical standards.
- Oversee the Staff Psychological Screening program.
- Oversee the Agnate Psychological Management program.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop ethical guidelines.
- Establish reporting mechanisms.

**Membership:**

- Independent Bioethicist (External)
- Human Rights Advocate (External)
- Medical Ethicist
- Legal Counsel
- Representative from the VIP Consortium
- Agnate Welfare Advocate (Internal)

**Decision Rights:** Ethical decisions related to agnate treatment, organ harvesting protocols, and compliance with ethical standards. The Ethical Oversight Committee has the authority to halt any activity deemed unethical.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Independent Bioethicist has the deciding vote.

**Meeting Cadence:** Monthly, or more frequently as needed.

**Typical Agenda Items:**

- Review ethical protocols.
- Review agnate welfare reports.
- Discuss and resolve ethical concerns.
- Review compliance with ethical standards.
- Review Staff Psychological Screening reports.
- Review Agnate Psychological Management reports.

**Escalation Path:** Project Steering Committee, Board of Directors
### 4. Technical Advisory Group

**Rationale for Inclusion:** Provides expert technical advice and guidance on genetic engineering, organ harvesting, and facility operations. Ensures the project utilizes the best available technologies and mitigates technical risks.

**Responsibilities:**

- Review and approve technical designs for the facility.
- Provide expert advice on genetic engineering and organ harvesting techniques.
- Monitor technical risks and recommend mitigation strategies.
- Evaluate new technologies and recommend adoption.
- Ensure compliance with technical standards and regulations.
- Oversee the Organ Viability Enhancement Protocol.
- Oversee the Agnate Cognitive Development Trajectory.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define technical standards.
- Establish communication protocols.

**Membership:**

- Lead Geneticist
- Chief Medical Officer
- Facility Construction Manager
- External Expert in Genetic Engineering
- External Expert in Organ Transplantation
- External Expert in Sustainable Facility Operations

**Decision Rights:** Technical decisions related to facility design, genetic engineering, organ harvesting, and compliance with technical standards. The Technical Advisory Group has the authority to recommend changes to technical designs or protocols.

**Decision Mechanism:** Decisions made by consensus. If consensus cannot be reached, the Lead Geneticist and Chief Medical Officer jointly make the final decision, documenting the rationale.

**Meeting Cadence:** Monthly, or more frequently as needed.

**Typical Agenda Items:**

- Review technical designs.
- Review genetic engineering and organ harvesting protocols.
- Discuss and resolve technical issues.
- Review compliance with technical standards.
- Review Organ Viability Enhancement Protocol reports.
- Review Agnate Cognitive Development Trajectory reports.

**Escalation Path:** Project Steering Committee
### 5. Compliance and Security Committee

**Rationale for Inclusion:** Ensures comprehensive compliance oversight, including GDPR, ethical standards, and relevant regulations, given the project's sensitive data handling and potential legal risks. Manages security protocols to protect the facility and its data.

**Responsibilities:**

- Develop and implement a comprehensive compliance program.
- Ensure compliance with GDPR and other data privacy regulations.
- Monitor adherence to ethical standards and relevant regulations.
- Conduct regular audits to identify and address compliance gaps.
- Develop and implement security protocols to protect the facility and its data.
- Investigate and respond to security breaches.
- Oversee the Security Protocol Rigor.
- Oversee the Staff Psychological Screening.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop compliance plan.
- Develop security protocols.

**Membership:**

- Head of Security
- Legal Counsel
- Data Protection Officer
- Compliance Officer
- External Cybersecurity Expert
- External Legal Expert in International Law

**Decision Rights:** Compliance and security decisions related to data privacy, ethical standards, regulatory compliance, and facility security. The Compliance and Security Committee has the authority to implement security measures and enforce compliance policies.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Legal Counsel has the deciding vote.

**Meeting Cadence:** Monthly, or more frequently as needed.

**Typical Agenda Items:**

- Review compliance reports.
- Review security incident reports.
- Discuss and resolve compliance and security issues.
- Review and update compliance plan.
- Review and update security protocols.
- Review Security Protocol Rigor reports.
- Review Staff Psychological Screening reports.

**Escalation Path:** Project Steering Committee