### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Core Team ToR v0.1

**Dependencies:**

- Project Plan Approved

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Ethical Oversight Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics Committee ToR v0.1

**Dependencies:**

- Project Plan Approved

### 4. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Plan Approved

### 5. Project Manager drafts initial Terms of Reference (ToR) for the Compliance and Security Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Compliance and Security Committee ToR v0.1

**Dependencies:**

- Project Plan Approved

### 6. Circulate Draft SteerCo ToR for review by nominated members (CEO, CFO, Chief Medical Officer, Head of Legal, Independent Ethics Advisor, Project Director).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 7. Circulate Draft Core Team ToR for review by nominated members (Project Manager, Chief Medical Officer, Head of Security, Lead Geneticist, Facility Construction Manager, Head of Procurement).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Core Team ToR v0.1
- Nominated Members List Available

### 8. Circulate Draft Ethics Committee ToR for review by nominated members (Independent Bioethicist, Human Rights Advocate, Medical Ethicist, Legal Counsel, Representative from the VIP Consortium, Agnate Welfare Advocate).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics Committee ToR v0.1
- Nominated Members List Available

### 9. Circulate Draft Technical Advisory Group ToR for review by nominated members (Lead Geneticist, Chief Medical Officer, Facility Construction Manager, External Expert in Genetic Engineering, External Expert in Organ Transplantation, External Expert in Sustainable Facility Operations).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1
- Nominated Members List Available

### 10. Circulate Draft Compliance and Security Committee ToR for review by nominated members (Head of Security, Legal Counsel, Data Protection Officer, Compliance Officer, External Cybersecurity Expert, External Legal Expert in International Law).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Compliance and Security Committee ToR v0.1
- Nominated Members List Available

### 11. Project Manager finalizes the Project Steering Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft SteerCo ToR v0.1

### 12. Project Manager finalizes the Core Project Team Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Core Team ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Core Team ToR v0.1

### 13. Project Manager finalizes the Ethical Oversight Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics Committee ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Ethics Committee ToR v0.1

### 14. Project Manager finalizes the Technical Advisory Group Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Technical Advisory Group ToR v0.1

### 15. Project Manager finalizes the Compliance and Security Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Compliance and Security Committee ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Compliance and Security Committee ToR v0.1

### 16. CEO formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** CEO

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 17. CEO formally appoints the Chair of the Ethical Oversight Committee.

**Responsible Body/Role:** CEO

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics Committee ToR v1.0

### 18. CEO formally appoints the Chair of the Technical Advisory Group.

**Responsible Body/Role:** CEO

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Technical Advisory Group ToR v1.0

### 19. CEO formally appoints the Chair of the Compliance and Security Committee.

**Responsible Body/Role:** CEO

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Compliance and Security Committee ToR v1.0

### 20. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Final SteerCo ToR v1.0
- Appointment Confirmation Email

### 21. Project Manager schedules the initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Final Core Team ToR v1.0

### 22. Project Manager schedules the initial Ethical Oversight Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Final Ethics Committee ToR v1.0
- Appointment Confirmation Email

### 23. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Final Technical Advisory Group ToR v1.0
- Appointment Confirmation Email

### 24. Project Manager schedules the initial Compliance and Security Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Final Compliance and Security Committee ToR v1.0
- Appointment Confirmation Email

### 25. Hold initial Project Steering Committee kick-off meeting. Review ToR, approve initial project plan, define escalation paths.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Initial Project Plan

**Dependencies:**

- Meeting Invitation
- Final SteerCo ToR v1.0

### 26. Hold initial Core Project Team kick-off meeting. Define team roles and responsibilities, establish communication protocols, set up project management tools, develop detailed project schedule.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Defined Team Roles and Responsibilities
- Established Communication Protocols
- Project Management Tools Setup
- Detailed Project Schedule

**Dependencies:**

- Meeting Invitation
- Final Core Team ToR v1.0

### 27. Hold initial Ethical Oversight Committee kick-off meeting. Review ToR, develop ethical guidelines, establish reporting mechanisms.

**Responsible Body/Role:** Ethical Oversight Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Developed Ethical Guidelines
- Established Reporting Mechanisms

**Dependencies:**

- Meeting Invitation
- Final Ethics Committee ToR v1.0

### 28. Hold initial Technical Advisory Group kick-off meeting. Review ToR, define technical standards, establish communication protocols.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Defined Technical Standards
- Established Communication Protocols

**Dependencies:**

- Meeting Invitation
- Final Technical Advisory Group ToR v1.0

### 29. Hold initial Compliance and Security Committee kick-off meeting. Review ToR, develop compliance plan, develop security protocols.

**Responsible Body/Role:** Compliance and Security Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Developed Compliance Plan
- Developed Security Protocols

**Dependencies:**

- Meeting Invitation
- Final Compliance and Security Committee ToR v1.0