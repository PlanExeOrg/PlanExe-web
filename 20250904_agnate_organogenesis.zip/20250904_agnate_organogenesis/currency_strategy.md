This plan involves money.

## Currencies

- **USD:** The project budget is defined in USD.
- **MHL:** Local currency of the Marshall Islands, where the facility will be located. Used for local expenses and transactions.
- **AUD:** Australian Dollar, commonly used in the Marshall Islands.
- **KIR:** Local currency of Kiribati, an alternative location. Used for local expenses and transactions if the facility is located there.
- **FSM:** Local currency of the Federated States of Micronesia, an alternative location. Used for local expenses and transactions if the facility is located there.

**Primary currency:** USD

**Currency strategy:** USD will be used for budgeting and reporting. Local currencies (MHL, AUD, KIR, FSM) may be used for local transactions. Hedging strategies should be considered to mitigate exchange rate fluctuations.