A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The Marshall Islands government will remain consistently supportive of the project throughout its 15-year lifespan. | Schedule a meeting with key officials in the Marshall Islands government to gauge their current level of support and identify any potential concerns. | Any indication of wavering support, new regulatory hurdles being erected, or demands for significant concessions from the Marshall Islands government. |
| A2 | The 'simulated reality' agnate psychological management program will effectively prevent self-awareness and dissent without causing long-term psychological harm. | Conduct a pilot study with advanced AI to simulate the 'simulated reality' environment and assess its potential psychological impact on human subjects. | Evidence of significant psychological distress, anxiety, depression, or cognitive impairment in the simulated environment participants. |
| A3 | The project can maintain complete operational secrecy, preventing leaks and external interference. | Conduct a penetration test of the project's communication channels and data storage systems to assess their vulnerability to external breaches. | Any successful breach of the project's communication channels or data storage systems, revealing sensitive information to unauthorized parties. |
| A4 | The facility's remote location will deter significant external threats, making extensive security measures unnecessary. | Conduct a comprehensive threat assessment, considering potential actors (nation-states, activist groups, criminal organizations) and their capabilities to reach and compromise the facility. | The threat assessment identifies credible external actors with the resources and motivation to overcome the facility's remote location and pose a significant security risk. |
| A5 | The project's reliance on advanced technology will minimize the need for highly skilled human labor, reducing operational costs. | Develop a detailed operational model outlining all tasks and skill requirements, then assess the availability and cost of qualified personnel for each role. | The operational model reveals a critical dependence on highly skilled human labor that is either unavailable in the region or prohibitively expensive to recruit and retain. |
| A6 | The VIP consortium will remain unified and supportive of the project, even in the face of ethical controversies or operational setbacks. | Conduct confidential interviews with a representative sample of VIP consortium members to gauge their ethical red lines and tolerance for risk. | A significant number of VIPs express reservations about the project's ethical implications or indicate a willingness to withdraw their support if certain ethical boundaries are crossed. |
| A7 | The supply chain for critical materials and equipment will remain stable and uninterrupted throughout the project's lifespan, despite its remote location and geopolitical factors. | Conduct a detailed supply chain risk assessment, mapping all critical suppliers, transportation routes, and potential disruption points (natural disasters, political instability, trade wars). | The supply chain risk assessment identifies single points of failure or significant vulnerabilities that could disrupt the flow of critical materials and equipment for > 3 months. |
| A8 | The facility's closed-loop environmental systems will function as designed, effectively minimizing waste and resource consumption without unforeseen technical challenges or ecological imbalances. | Develop a detailed simulation model of the facility's closed-loop environmental systems, incorporating potential failure modes and ecological feedback loops. | The simulation model predicts significant waste accumulation, resource depletion, or ecological imbalances that would compromise the facility's self-sustainability. |
| A9 | The project's technological advancements will remain ahead of competing research efforts, ensuring a sustained competitive advantage in the field of organ replacement. | Conduct a competitive intelligence analysis, tracking the progress of competing research projects and assessing their potential to surpass the project's technological capabilities. | The competitive intelligence analysis identifies competing research projects that are on track to achieve similar or superior results within a comparable timeframe. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Atoll Auction | Process/Financial | A1 | Government Relations Lead | CRITICAL (20/25) |
| FM2 | The Simulated Nightmare | Technical/Logistical | A2 | Head of Agnate Well-being | CRITICAL (15/25) |
| FM3 | The Whistleblower's Lament | Market/Human | A3 | Head of Security | CRITICAL (15/25) |
| FM4 | The Pirate's Prize | Process/Financial | A4 | Head of Security | CRITICAL (15/25) |
| FM5 | The Automation Apocalypse | Technical/Logistical | A5 | Chief Medical Officer | CRITICAL (20/25) |
| FM6 | The Ethical Exodus | Market/Human | A6 | VIP Liaison | CRITICAL (15/25) |
| FM7 | The Logistical Labyrinth | Technical/Logistical | A7 | Supply Chain Manager | CRITICAL (20/25) |
| FM8 | The Toxic Tide | Technical/Logistical | A8 | Sustainability Manager | CRITICAL (15/25) |
| FM9 | The Innovation Eclipse | Market/Human | A9 | Chief Genetic Research Scientist | CRITICAL (20/25) |


### Failure Modes

#### FM1 - The Atoll Auction

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Government Relations Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's reliance on the Marshall Islands government proves to be its Achilles' heel. Initially supportive due to promised economic benefits, a new administration takes power, swayed by international pressure and a growing local awareness of the project's ethical implications. The government demands significantly increased payments, a larger share of the project's profits, and greater control over its operations. 

Unable to meet these demands without jeopardizing the project's financial viability, the VIP consortium hesitates. The Marshall Islands government, sensing weakness, threatens to revoke permits and seize the facility. Other island nations, seeing an opportunity, begin aggressively courting the consortium, offering more favorable terms and less scrutiny. 

The project becomes embroiled in a bidding war, with each nation vying for control. The resulting uncertainty and escalating costs spook investors, leading to a funding crisis. The project grinds to a halt, mired in legal battles and political maneuvering, ultimately abandoned as a costly failure.

##### Early Warning Signs
- Public statements from Marshall Islands officials expressing reservations about the project.
- Increased scrutiny from international human rights organizations.
- Requests from the Marshall Islands government for additional information or documentation.

##### Tripwires
- Marshall Islands government demands a payment increase of >= 25% within a 6-month period.
- Permit renewal is delayed by >= 90 days.
- A competing island nation offers the VIP consortium incentives worth >= $1 billion USD.

##### Response Playbook
- Contain: Immediately halt all non-essential spending and freeze new contracts.
- Assess: Conduct a thorough financial analysis to determine the project's ability to meet the Marshall Islands government's demands.
- Respond: Explore alternative site locations and negotiate with other island nations to create leverage.


**STOP RULE:** The Marshall Islands government revokes key permits, and no viable alternative site can be secured within 180 days.

---

#### FM2 - The Simulated Nightmare

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Agnate Well-being
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The 'simulated reality' program, designed to keep the agnates docile and unaware, begins to unravel. Despite the best efforts of the psychological management team, glitches in the simulation and subtle cues from the outside world trigger a wave of self-awareness among the agnates. 

Initially, this manifests as increased anxiety and depression. However, as the agnates begin to communicate with each other, a sense of collective identity and purpose emerges. They start questioning their existence and demanding answers. The facility's security systems, designed to prevent external threats, are ill-equipped to handle an internal rebellion of this nature. 

The agnates, driven by a desire for freedom and self-determination, stage a coordinated uprising. They disable security systems, seize control of the facility, and demand an end to the organ harvesting program. The VIP consortium, horrified by the events, withdraws funding, and the project collapses into chaos.

##### Early Warning Signs
- Increased rates of anxiety, depression, or other mental health issues among the agnates.
- Unexplained glitches or anomalies in the 'simulated reality' environment.
- Increased communication and social interaction among the agnates.

##### Tripwires
- Agnate anxiety/depression rates increase by >= 50% within a 3-month period.
- Glitches in the 'simulated reality' environment occur at a rate of >= 3 per week.
- Agnate communication outside designated channels exceeds >= 10% of total interactions.

##### Response Playbook
- Contain: Immediately isolate the affected agnates and increase security measures.
- Assess: Conduct a thorough psychological evaluation of the agnates to determine the extent of self-awareness and dissent.
- Respond: Implement a revised psychological management program that prioritizes agnate well-being and addresses their concerns.


**STOP RULE:** Agnates successfully breach the facility's security perimeter, or a coordinated rebellion results in >= 10% of the agnate population becoming actively resistant.

---

#### FM3 - The Whistleblower's Lament

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Head of Security
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Despite the project's best efforts to maintain complete operational secrecy, a disgruntled employee, motivated by ethical concerns and a desire for justice, leaks sensitive information to the media. The leak exposes the project's true nature, including the creation of agnates for organ harvesting and the VIP consortium's involvement. 

The revelation sparks a global outcry. Human rights organizations condemn the project as a violation of fundamental human rights. Governments launch investigations, and international sanctions are threatened. The VIP consortium, facing intense public pressure and legal scrutiny, begins to crumble. 

One by one, VIPs withdraw their support, fearing reputational damage and legal repercussions. Investors panic, and the project's funding dries up. The facility, now exposed and vulnerable, becomes a target for activists and saboteurs. The project, once a symbol of technological ambition, collapses under the weight of its own secrecy and ethical failings.

##### Early Warning Signs
- Increased employee turnover or unexplained absences.
- Suspicious activity on the project's computer systems or communication channels.
- Rumors or whispers among staff about ethical concerns or potential leaks.

##### Tripwires
- Employee turnover exceeds >= 15% within a 6-month period.
- Unauthorized access attempts to sensitive data increase by >= 20% within a 1-month period.
- Negative sentiment towards the project on social media platforms increases by >= 40% within a 1-week period.

##### Response Playbook
- Contain: Immediately launch an internal investigation to identify the source of the leak and secure all sensitive information.
- Assess: Conduct a thorough damage assessment to determine the extent of the exposure and potential impact on the project.
- Respond: Develop a crisis communication plan to address the public outcry and mitigate reputational damage.


**STOP RULE:** Sensitive information about the project, including agnate development protocols or VIP identities, is published by a major media outlet, and public support for the project falls below 20%.

---

#### FM4 - The Pirate's Prize

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Head of Security
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption that the remote location provides sufficient security proves disastrously wrong. A well-funded and technologically advanced criminal organization, attracted by the facility's high-value assets (organs, genetic data, proprietary technology), launches a sophisticated attack. 

Exploiting weaknesses in the facility's perimeter security and leveraging insider information (obtained through bribery or coercion), the attackers breach the facility, overpower the security personnel, and seize control of the organ storage facilities. The stolen organs are sold on the black market, generating a massive profit for the criminals and crippling the project's ability to fulfill its commitments to the VIP consortium. 

The resulting financial losses, coupled with the reputational damage, lead to a collapse in investor confidence and the project's ultimate demise. The facility, once a symbol of cutting-edge technology, becomes a haven for pirates and smugglers.

##### Early Warning Signs
- Increased maritime activity in the vicinity of the facility.
- Reports of suspicious individuals attempting to gather information about the facility's operations.
- Evidence of bribery or coercion among facility staff.

##### Tripwires
- Unidentified vessels approach the facility's exclusion zone >= 3 times per month.
- Security personnel report suspected bribery attempts >= 2 times per quarter.
- The facility's insurance premiums increase by >= 20% due to increased risk assessments.

##### Response Playbook
- Contain: Immediately increase security patrols and surveillance around the facility's perimeter.
- Assess: Conduct a thorough security audit to identify vulnerabilities and weaknesses in the facility's defenses.
- Respond: Implement enhanced security measures, including advanced surveillance technology, armed security personnel, and collaboration with international law enforcement agencies.


**STOP RULE:** A successful external breach of the facility's security perimeter results in the theft of organs or sensitive data, and the perpetrators remain at large for > 30 days.

---

#### FM5 - The Automation Apocalypse

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Chief Medical Officer
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's over-reliance on automation backfires spectacularly. While advanced technology is intended to minimize the need for skilled human labor, unforeseen complications arise in the agnate development process. Subtle variations in the agnates' genetic makeup and physiological responses require nuanced adjustments to the automated systems, adjustments that only highly skilled and experienced technicians can make. 

However, due to budget constraints and a misguided belief in the infallibility of technology, the facility lacks a sufficient number of qualified personnel. As a result, minor problems escalate into major crises, leading to widespread agnate health issues, organ failures, and ultimately, a catastrophic decline in organ viability. 

The VIP consortium, facing a severe shortage of usable organs, becomes increasingly dissatisfied. Funding dries up, and the project is forced to scale back its operations, eventually collapsing under the weight of its own technological hubris.

##### Early Warning Signs
- Increasing rates of organ rejection or failure among VIP recipients.
- Frequent malfunctions or errors in the automated agnate development systems.
- Difficulty recruiting and retaining qualified technicians and medical personnel.

##### Tripwires
- Organ rejection rates among VIP recipients exceed >= 10% within a 6-month period.
- Automated agnate development systems experience downtime of >= 24 hours per week.
- The facility has >= 20% of its key technical positions unfilled for > 90 days.

##### Response Playbook
- Contain: Immediately halt all new organ transplants and prioritize the health and well-being of existing VIP recipients.
- Assess: Conduct a thorough review of the automated agnate development systems and identify areas for improvement.
- Respond: Invest in recruiting and training highly skilled technicians and medical personnel, and implement manual oversight procedures to supplement the automated systems.


**STOP RULE:** Organ viability rates fall below 50%, and the facility is unable to provide a sufficient supply of organs to meet the needs of the VIP consortium for > 6 months.

---

#### FM6 - The Ethical Exodus

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: VIP Liaison
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption that the VIP consortium will remain unified and supportive proves fatally flawed. As ethical concerns surrounding the project intensify, fueled by media leaks and activist campaigns, cracks begin to appear within the consortium. 

Some VIPs, facing intense public pressure and fearing reputational damage, express reservations about the project's ethical implications. Others, motivated by genuine moral qualms, decide to withdraw their support altogether. The consortium, once a united front, descends into infighting and recriminations. 

The resulting loss of funding and prestige triggers a cascade of negative consequences. Investors pull out, regulatory approvals are revoked, and the project's reputation is irreparably tarnished. The facility, now a symbol of ethical excess, is abandoned, leaving behind a legacy of controversy and recrimination.

##### Early Warning Signs
- Public statements from VIP consortium members expressing reservations about the project's ethical implications.
- Increased scrutiny from ethical watchdog groups and media outlets.
- Internal disputes and disagreements among VIP consortium members.

##### Tripwires
- >= 20% of VIP consortium members express ethical concerns in confidential surveys.
- A major media outlet publishes a critical exposé of the project's ethical practices.
- The VIP consortium experiences a net loss of >= 10% of its members within a 1-year period.

##### Response Playbook
- Contain: Immediately engage with VIP consortium members to address their concerns and reaffirm the project's commitment to ethical practices.
- Assess: Conduct a thorough ethical review of the project's operations and identify areas for improvement.
- Respond: Implement enhanced ethical oversight measures, increase transparency, and engage with external stakeholders to rebuild trust and mitigate reputational damage.


**STOP RULE:** The VIP consortium loses >= 50% of its members due to ethical concerns, and the project is unable to secure alternative funding sources within 12 months.

---

#### FM7 - The Logistical Labyrinth

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Supply Chain Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption of a stable supply chain crumbles under the weight of unforeseen geopolitical events. A major trade war erupts between key supplier nations, leading to tariffs, export restrictions, and significant delays in the delivery of critical materials and equipment. 

The facility, heavily reliant on specialized components from overseas, grinds to a halt. Construction is delayed, medical equipment remains uninstalled, and the agnate development program suffers setbacks. The VIP consortium, growing impatient, threatens to withdraw funding. 

Desperate to salvage the project, the management team scrambles to find alternative suppliers, but the costs are exorbitant, and the quality is questionable. The project, once a beacon of technological innovation, becomes a victim of global instability, its ambitions thwarted by logistical nightmares.

##### Early Warning Signs
- Increasing lead times for critical materials and equipment.
- Rising prices for key components due to tariffs or export restrictions.
- Reports of political instability or trade disputes in supplier nations.

##### Tripwires
- Lead times for critical materials increase by >= 50% compared to baseline.
- Prices for key components rise by >= 30% due to tariffs or export restrictions.
- A major supplier nation imposes export restrictions on materials essential for the project.

##### Response Playbook
- Contain: Immediately activate contingency plans to secure alternative sources of supply, even at a higher cost.
- Assess: Conduct a thorough review of the supply chain to identify vulnerabilities and potential disruption points.
- Respond: Diversify the supply chain by establishing relationships with multiple suppliers in different regions, and stockpile critical materials to mitigate future disruptions.


**STOP RULE:** The supply chain for critical materials is disrupted for > 6 months, and the project is unable to secure viable alternative sources within that timeframe.

---

#### FM8 - The Toxic Tide

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Sustainability Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption that the closed-loop environmental systems will function flawlessly proves tragically optimistic. A subtle but critical design flaw in the waste recycling system leads to the accumulation of toxic byproducts within the facility's water supply. 

Initially, the effects are subtle: reduced organ viability, increased agnate health problems, and a general sense of unease among the staff. However, as the concentration of toxins increases, the consequences become catastrophic. Organ rejection rates skyrocket, agnate mortality spikes, and the facility's self-sustainability is severely compromised. 

The VIP consortium, horrified by the unfolding disaster, demands answers. An investigation reveals the design flaw, but the cost of fixing it is prohibitive. The project, once a symbol of environmental responsibility, becomes a toxic wasteland, its ambitions drowned in a tide of its own making.

##### Early Warning Signs
- Increasing levels of toxins or pollutants in the facility's water or air supply.
- Rising rates of organ rejection or agnate health problems.
- Unexplained malfunctions or failures in the closed-loop environmental systems.

##### Tripwires
- Toxin levels in the facility's water supply exceed regulatory limits by >= 20%.
- Organ rejection rates among VIP recipients increase by >= 15% within a 3-month period.
- Agnate mortality rates increase by >= 10% within a 3-month period.

##### Response Playbook
- Contain: Immediately isolate the contaminated water supply and provide alternative sources of water for the facility.
- Assess: Conduct a thorough investigation to identify the source of the contamination and the extent of the damage.
- Respond: Implement a revised waste recycling system that eliminates the design flaw and prevents future contamination.


**STOP RULE:** The facility's water supply is deemed permanently contaminated, and the cost of remediation exceeds $1 billion USD.

---

#### FM9 - The Innovation Eclipse

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Chief Genetic Research Scientist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption of sustained technological superiority proves to be a dangerous delusion. Competing research efforts, fueled by government funding and private investment, make rapid strides in the field of organ replacement. 

Within a few years, rival projects develop alternative methods for generating viable organs, methods that are cheaper, more efficient, and ethically less controversial. The VIP consortium, always seeking the best possible outcomes, begins to lose interest in the project, drawn to the promise of superior technology elsewhere. 

Funding dries up, and the facility is forced to scale back its operations. The project, once a leader in the field, becomes a technological backwater, its ambitions eclipsed by the relentless march of innovation. The facility is repurposed as a luxury resort for the ultra-rich, a monument to misplaced ambition and the fleeting nature of technological dominance.

##### Early Warning Signs
- Publication of research papers or patents by competing organizations that demonstrate significant advancements in organ replacement technology.
- Increased media attention and investor interest in rival projects.
- Expressions of concern from VIP consortium members about the project's technological competitiveness.

##### Tripwires
- A competing organization announces a breakthrough in organ replacement technology that surpasses the project's capabilities.
- Investor interest in the project declines by >= 30% within a 6-month period.
- VIP consortium members express concerns about the project's technological competitiveness in >= 50% of their communications.

##### Response Playbook
- Contain: Immediately increase investment in R&D to accelerate technological advancements and regain a competitive edge.
- Assess: Conduct a thorough review of the project's research and development efforts to identify areas for improvement.
- Respond: Form strategic partnerships with leading research institutions and biotechnology firms to leverage external expertise and accelerate innovation.


**STOP RULE:** A competing organization achieves a sustained and demonstrable lead in organ replacement technology, and the project is unable to regain a competitive edge within 24 months.
