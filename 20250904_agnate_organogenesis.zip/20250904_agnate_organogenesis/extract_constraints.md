## Positive Constraints

- Self-sustaining off-shore facility
- Gestating, raising, and harvesting genetically identical “agnates”
- Provide on-demand organ and tissue replacements
- Target audience: 500 global VIPs
- Goal: Radical life extension for VIPs
- Operate fully in public with global policymakers complicity
- Capacity: housing 2000 individuals (1500 agnates and 500 operational staff)
- Timeline: 15 years to full operational capacity
- Agnates must be unaware of their true purpose or the outside world
- Location: Near the Marshall Islands
- Budget: $60 Billion USD
