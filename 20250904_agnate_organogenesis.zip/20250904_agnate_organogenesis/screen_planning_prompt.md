**Verdict:** 🟢 USABLE

**Rationale:** The prompt describes a concrete, albeit ethically questionable, project with specific details about location, budget, timeline, and capacity. It provides enough information to generate a multi-step plan, even if the project's premise is unusual.