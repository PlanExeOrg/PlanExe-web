
## Audit - Corruption Risks

- Bribery of Marshall Islands officials to expedite permits or overlook environmental regulations.
- Kickbacks from construction companies or medical equipment suppliers in exchange for inflated contracts.
- Nepotism in hiring practices, favoring relatives or friends for high-paying positions regardless of qualifications.
- Conflicts of interest involving members of the Ethical Oversight Committee who may have financial ties to the VIP consortium.
- Misuse of confidential VIP medical information for personal gain or blackmail.

## Audit - Misallocation Risks

- Inflated invoices from shell corporations used to siphon funds for personal enrichment.
- Double-billing for services rendered by contractors or consultants.
- Unnecessary or lavish expenses disguised as legitimate project costs (e.g., luxury travel, entertainment).
- Misreporting of project progress to secure continued funding despite delays or failures.
- Unauthorized use of facility resources (e.g., medical equipment, personnel) for personal purposes.

## Audit - Procedures

- Conduct quarterly internal audits of all financial transactions, focusing on high-value contracts and expense reports. Responsibility: Internal Audit Team.
- Perform annual external audits by an independent accounting firm to verify financial statements and compliance with regulations. Responsibility: External Audit Firm.
- Implement a whistleblower hotline and protection policy to encourage reporting of suspected fraud or corruption. Responsibility: Legal Department.
- Conduct periodic reviews of all contracts with suppliers and contractors to ensure fair pricing and compliance with ethical standards. Responsibility: Procurement Department, Legal Department.
- Perform regular compliance checks to ensure adherence to biosafety regulations, environmental regulations, and international ethical standards for organ harvesting. Responsibility: Compliance Officer, Ethical Oversight Committee.

## Audit - Transparency Measures

- Establish a project website with a dashboard displaying key performance indicators (KPIs) such as budget expenditures, construction progress, and organ transplant success rates.
- Publish minutes of Ethical Oversight Committee meetings (redacted to protect VIP privacy) on the project website.
- Implement a publicly accessible whistleblower mechanism with guaranteed anonymity and protection from retaliation.
- Document and publish the selection criteria for all major vendors and contractors on the project website.
- Make the project's environmental impact assessment reports and sustainability plans publicly available.