**Purpose:** business

**Purpose Detailed:** Commercial operation for providing organ and tissue replacements to VIPs, aiming for radical life extension and profit.

**Topic:** Off-shore facility for organ and tissue replacement