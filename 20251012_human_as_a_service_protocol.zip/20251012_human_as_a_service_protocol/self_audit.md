Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 14 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 5 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project focuses on creating an open protocol for a physical labor marketplace, which is an organizational and economic challenge, not a physics one. The plan explicitly discourages the use of blockchain and DAOs.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (HaaS platform) + market (physical labor) + tech/process (open protocol + on-site verification) + policy (AB5 compliance) without independent evidence at comparable scale. The plan lacks evidence that this combination can work.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Each track must produce one authoritative source or a supervised pilot showing results vs a baseline. Define NO-GO gates. Owner: Project Lead / Deliverable: Validation Report / Date: 90 days


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions buzzwords like "open protocol" without defining a business-level mechanism-of-action (inputs→process→customer value). The plan does not include one-pagers defining the value hypotheses, success metrics, and decision hooks for these strategic concepts.

**Mitigation**: Project Lead: Create one-pagers for 'open protocol', 'HaaS', and 'resilient marketplace' defining value hypotheses, success metrics, and decision hooks. Due: within 60 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies some risks (regulatory, technical, financial) and includes mitigation plans. However, it lacks explicit analysis of risk cascades or second-order effects. For example, "Unexpected regulatory hurdles or permitting in Silicon Valley" is listed, but the cascade (delay → cost overrun → scope reduction) isn't detailed.

**Mitigation**: Risk Manager: Expand the risk register to map potential risk cascades and second-order effects, adding controls and a dated review cadence. Due: within 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions "Regulatory hurdles and permitting delays" as a risk, but there is no evidence of a permit/approval matrix or timeline. The plan does not include a list of required permits.

**Mitigation**: Legal Counsel: Create a permit/approval matrix with typical lead times for Silicon Valley, including dated predecessors and a NO-GO threshold on slip. Due: within 60 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not include a financing plan listing sources/status, draw schedule, or covenants. The plan mentions a "budget of $40 million and a 24-month timeframe" but does not specify the funding source or draw schedule.

**Mitigation**: CFO: Create a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO-GO on missed financing gates. Due: within 30 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks scale-appropriate benchmarks for a $40M project in Silicon Valley. There are no vendor quotes or per-area cost normalizations. The plan does not include benchmarks for fit-out, capex, or opex.

**Mitigation**: CFO: Obtain ≥3 fit-out/capex/opex benchmarks for Silicon Valley, normalize per-area, and adjust budget or de-scope by 90 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., adoption, revenue) as single numbers without ranges or scenarios. For example, the SWOT analysis lists "Achieve adoption of the HaaS protocol by at least 50 service providers" without a range.

**Mitigation**: Project Manager: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for service provider adoption. Due: within 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions build-critical components (open protocol, verification process, job matching algorithm) but lacks engineering artifacts. There are no technical specs, interface contracts, acceptance tests, or integration plans.

**Mitigation**: Engineering Lead: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components. Due: within 90 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes critical claims without verifiable artifacts. For example, the plan states, "Secure partnerships with professional certification bodies," but lacks evidence of existing agreements or even preliminary discussions with such bodies.

**Mitigation**: Partnerships Lead: Secure letters of intent from at least two professional certification bodies, outlining potential partnership terms, within 60 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions abstract deliverables like "a resilient marketplace" without specific, verifiable qualities. The plan does not define what "resilient" means in measurable terms.

**Mitigation**: Project Manager: Define SMART criteria for 'a resilient marketplace,' including a KPI for platform uptime (e.g., 99.9% availability) and a KPI for provider churn (e.g., <10% annual churn). Due: within 30 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes on-site verification by trusted professionals. This feature adds significant cost and complexity. It's unclear how this directly supports the core goals of interoperability and preventing vendor lock-in.

**Mitigation**: Project Team: Produce a one-page benefit case justifying on-site verification, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog. Due: within 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Protocol Architect' role is essential for designing the open protocol, which is the core of the project. The plan states, "This role is crucial for designing the open protocol." Finding someone with the right expertise will be difficult.

**Mitigation**: HR: Validate the talent market for a 'Protocol Architect' with expertise in open protocols and distributed systems. Deliverable: Talent availability report. Date: Within 30 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not map required legal approvals or name controlling statutes. The plan mentions "California Labor Laws (AB5)" and "California Consumer Privacy Act (CCPA)" but lacks a regulatory matrix.

**Mitigation**: Legal Counsel: Create a regulatory matrix (authority, artifact, lead time, predecessors) for all required permits/licenses/approvals, including AB5/CCPA compliance. Due: within 60 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions a "resilient marketplace" but lacks details on long-term funding, maintenance, or adaptation. The plan does not include a technology roadmap or succession plan.

**Mitigation**: Project Manager: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession plan, and technology roadmap. Due: within 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan implies physical locations in Silicon Valley but lacks specifics on zoning, occupancy, or permits. The plan states, "Project is explicitly located in Silicon Valley" but does not address local constraints.

**Mitigation**: Real Estate Team: Perform a fatal-flaw screen with authorities/experts regarding zoning/land-use for the intended physical locations in Silicon Valley. Deliverable: Written summary. Date: Within 60 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions reliance on third-party vendors but lacks evidence of SLAs or tested failover plans. The plan states, "Reliance on third-party vendors. Disruptions could impact implementation" but does not include vendor contracts.

**Mitigation**: Procurement Team: Secure SLAs with key vendors (payment gateway, cloud provider, background check service) including uptime guarantees and failover procedures. Due: within 90 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the 'Project Manager' and 'Software Developers' may have conflicting incentives. The Project Manager is incentivized to deliver the project on time and within budget. Software Developers are incentivized to build a robust and scalable protocol.

**Mitigation**: Project Lead: Define a shared OKR focused on delivering a functional, scalable protocol within budget, aligning incentives for both Project Manager and Software Developers. Due: within 30 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a change-control process. The plan does not include a dashboard or a change board.

**Mitigation**: Project Manager: Establish a monthly review with a KPI dashboard and a lightweight change board. Owner: Project Lead. Deliverable: Review cadence. Date: Within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has ≥3 High risks (e.g., No Real-World Proof, Underestimating Risks, Budget Too Low) that are strongly coupled. For example, the lack of real-world proof increases the likelihood of cost overruns and schedule delays.

**Mitigation**: Project Lead: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Due: within 90 days.