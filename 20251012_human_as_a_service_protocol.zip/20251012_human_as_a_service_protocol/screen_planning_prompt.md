**Verdict:** 🟢 USABLE

**Rationale:** The prompt describes a concrete project with a specific goal, budget, timeline, and location. It provides enough detail to generate a multi-step plan for the pilot project.