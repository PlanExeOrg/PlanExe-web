A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Service providers are willing to share data for interoperability. | Survey a representative sample of service providers in the target vertical about their willingness to share data, specifying the type of data and the purpose. | More than 30% of surveyed service providers express unwillingness to share the specified data. |
| A2 | The selected pilot project vertical is representative of the broader physical labor market. | Conduct a comparative analysis of the selected vertical against the broader physical labor market, focusing on key characteristics like average project size, skill requirements, and regulatory landscape. | The selected vertical deviates by more than 25% from the broader market average in two or more key characteristics. |
| A3 | Workers are willing to undergo verification processes. | Survey a representative sample of workers in the target demographic about their willingness to undergo various verification steps (background checks, skill assessments, etc.), specifying the time commitment and potential costs. | More than 40% of surveyed workers express unwillingness to complete all required verification steps. |
| A4 | Clients are willing to pay a premium for verified workers. | Conduct a survey of potential clients, presenting different service options with varying levels of worker verification and associated price points. | More than 50% of surveyed clients indicate they are unwilling to pay more than a 10% premium for verified workers. |
| A5 | The open protocol can be implemented without compromising data security. | Conduct a security audit of the proposed open protocol implementation, focusing on potential vulnerabilities related to data breaches and unauthorized access. | The security audit identifies critical vulnerabilities that cannot be mitigated without significantly altering the open protocol's functionality. |
| A6 | Existing insurance products adequately cover the risks associated with HaaS workers. | Consult with insurance providers to assess the availability and cost of insurance coverage for HaaS workers, focusing on specific risks related to physical labor tasks. | Insurance providers are unwilling to offer coverage for HaaS workers at a reasonable price, or the available coverage excludes key risks associated with physical labor. |
| A7 | The HaaS platform can effectively manage real-time scheduling and dispatch of workers. | Simulate peak demand scenarios and assess the platform's ability to efficiently schedule and dispatch workers to meet client requests within acceptable timeframes. | The simulation reveals significant delays in scheduling and dispatch, resulting in client wait times exceeding 30 minutes during peak demand. |
| A8 | Workers will consistently use the platform's communication tools for job-related communication. | Track worker usage of the platform's communication tools (e.g., messaging, video conferencing) during pilot projects and compare it to external communication methods (e.g., phone calls, text messages). | Worker usage of the platform's communication tools is less than 50% of total job-related communication. |
| A9 | Clients will provide accurate and detailed task descriptions. | Analyze a sample of client task descriptions from pilot projects to assess their clarity, completeness, and accuracy in conveying the required tasks and expectations. | More than 40% of client task descriptions are deemed incomplete, ambiguous, or inaccurate by workers. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Data Desert Disaster | Process/Financial | A1 | Head of Partnerships | CRITICAL (16/25) |
| FM2 | The Niche Nightmare | Technical/Logistical | A2 | Head of Engineering | CRITICAL (15/25) |
| FM3 | The Verification Revolt | Market/Human | A3 | Head of Marketing | CRITICAL (16/25) |
| FM4 | The Price of Trust: A Premium Too High | Market/Human | A4 | Head of Sales | CRITICAL (16/25) |
| FM5 | The Security Sacrifice: Open Protocol's Fatal Flaw | Technical/Logistical | A5 | Chief Information Security Officer | CRITICAL (15/25) |
| FM6 | The Uninsurable Risk: A Financial Black Hole | Process/Financial | A6 | Chief Financial Officer | CRITICAL (16/25) |
| FM7 | The Scheduling Showdown: A Real-Time Meltdown | Technical/Logistical | A7 | Head of Operations | CRITICAL (20/25) |
| FM8 | The Communication Breakdown: A Tower of Babel | Market/Human | A8 | Head of Customer Support | HIGH (12/25) |
| FM9 | The Task Description Trap: A Recipe for Disaster | Process/Financial | A9 | Head of Product | CRITICAL (16/25) |


### Failure Modes

#### FM1 - The Data Desert Disaster

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Head of Partnerships
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The core assumption that service providers will willingly share data for interoperability proves false. This leads to a cascade of negative consequences:

*   **Protocol Ineffectiveness:** The open protocol becomes crippled, unable to facilitate seamless data exchange between providers.
*   **Limited Interoperability:** The platform fails to achieve its core value proposition of vendor independence, as providers remain siloed.
*   **Reduced Market Reach:** Clients are hesitant to adopt a platform with limited interoperability, hindering market penetration.
*   **Financial Losses:** The project fails to attract sufficient service providers and clients, leading to revenue shortfalls and potential project cancellation.

##### Early Warning Signs
- Initial service provider sign-up rate is below 50% of projections.
- Service providers actively resist integrating with the platform's API.
- Client feedback indicates dissatisfaction with the limited choice of service providers.

##### Tripwires
- Service provider API integration rate <= 20% after 3 months.
- Client satisfaction score related to provider choice <= 3/5.
- Number of active service providers sharing data < 10 after 6 months.

##### Response Playbook
- Contain: Immediately halt further development of data-dependent features.
- Assess: Conduct an emergency meeting with service providers to understand their data sharing concerns.
- Respond: Explore alternative interoperability solutions that minimize data sharing requirements, such as federated learning or data anonymization techniques.


**STOP RULE:** If a viable alternative interoperability solution cannot be identified within 3 months, pivot to a closed-platform model or cancel the project.

---

#### FM2 - The Niche Nightmare

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption that the selected pilot project vertical is representative of the broader physical labor market proves incorrect. This leads to a series of technical and logistical challenges:

*   **Protocol Mismatch:** The open protocol is optimized for the specific needs of the pilot vertical but fails to adapt to the diverse requirements of other physical labor sectors.
*   **Limited Scalability:** The platform's infrastructure and verification processes are tailored to the pilot vertical, making it difficult to expand to new service categories.
*   **Technical Debt:** The project accumulates technical debt as developers attempt to retrofit the protocol to accommodate new verticals.
*   **Logistical Bottlenecks:** The on-site verification process becomes a bottleneck as it struggles to handle the unique challenges of different physical labor tasks.

##### Early Warning Signs
- Expansion to new service categories requires significant code modifications.
- On-site verification times increase by more than 50% for non-pilot tasks.
- Service providers in new verticals express dissatisfaction with the protocol's limitations.

##### Tripwires
- Effort to adapt protocol to new vertical >= 200% of initial estimates.
- On-site verification failure rate for new verticals >= 15%.
- Number of support tickets related to protocol limitations >= 20 per week.

##### Response Playbook
- Contain: Freeze development of new features and focus on stabilizing the existing platform.
- Assess: Conduct a thorough analysis of the technical debt and logistical bottlenecks.
- Respond: Refactor the open protocol to be more modular and adaptable, and redesign the verification process to be more flexible and scalable.


**STOP RULE:** If the cost of refactoring the protocol exceeds $2 million or the redesign of the verification process is deemed infeasible, cancel the project.

---

#### FM3 - The Verification Revolt

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Head of Marketing
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The assumption that workers are willing to undergo verification processes proves false. This leads to a market and human capital crisis:

*   **Workforce Shortage:** The platform struggles to attract a sufficient number of workers due to the perceived intrusiveness and time commitment of the verification process.
*   **Negative Brand Perception:** The platform gains a reputation for being overly bureaucratic and unwelcoming to workers.
*   **Reduced Service Quality:** The limited pool of verified workers leads to longer wait times and reduced service quality for clients.
*   **Market Share Erosion:** Clients migrate to competing platforms with less stringent verification requirements, resulting in a loss of market share.

##### Early Warning Signs
- Worker application completion rate is below 40%.
- Worker churn rate exceeds 20% per month.
- Client complaints about worker availability increase by more than 30%.

##### Tripwires
- Worker application completion rate <= 30% after 2 months.
- Average time to verify a worker >= 7 days.
- Number of active verified workers < 50 after 6 months.

##### Response Playbook
- Contain: Immediately suspend all non-essential verification steps.
- Assess: Conduct a survey to understand worker concerns about the verification process.
- Respond: Redesign the verification process to be less intrusive and more efficient, and offer incentives for completing the verification process.


**STOP RULE:** If the platform fails to attract at least 100 verified workers within 9 months, pivot to a less stringent verification model or cancel the project.

---

#### FM4 - The Price of Trust: A Premium Too High

- **Archetype**: Market/Human
- **Root Cause**: Assumption A4
- **Owner**: Head of Sales
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The assumption that clients are willing to pay a premium for verified workers proves false. This leads to a market adoption crisis:

*   **Client Aversion:** Clients balk at the higher prices associated with verified workers, opting for cheaper, unverified alternatives.
*   **Reduced Demand:** Overall demand for the HaaS platform declines as clients seek more affordable options elsewhere.
*   **Service Provider Exodus:** Verified workers, unable to secure enough jobs at the premium rate, leave the platform for competing services.
*   **Financial Instability:** The platform struggles to generate revenue, leading to budget cuts and potential project failure.

##### Early Warning Signs
- Client conversion rate from trial to paid subscriptions is below 30%.
- Average job bidding price is consistently lower than projected.
- Client feedback indicates price sensitivity and unwillingness to pay for verification.

##### Tripwires
- Client conversion rate <= 25% after 3 months.
- Average job bidding price <= 80% of projected price.
- Client churn rate >= 10% per month.

##### Response Playbook
- Contain: Immediately offer discounted rates for verified workers to stimulate demand.
- Assess: Conduct a market analysis to determine the optimal price point for verified services.
- Respond: Explore alternative revenue models, such as tiered pricing or subscription-based access to verified workers.


**STOP RULE:** If a viable pricing strategy cannot be identified within 3 months, pivot to a lower-cost, unverified service model or cancel the project.

---

#### FM5 - The Security Sacrifice: Open Protocol's Fatal Flaw

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Chief Information Security Officer
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption that the open protocol can be implemented without compromising data security proves false. This leads to a catastrophic security breach:

*   **Data Breach:** Sensitive client and worker data is exposed due to vulnerabilities in the open protocol implementation.
*   **Reputational Damage:** The platform suffers a severe reputational blow, losing user trust and credibility.
*   **Legal Liabilities:** The project faces significant legal liabilities and fines due to data privacy violations.
*   **Platform Shutdown:** The platform is forced to shut down to address the security breach and prevent further data loss.

##### Early Warning Signs
- Security audits reveal critical vulnerabilities in the open protocol implementation.
- Unauthorized access attempts to sensitive data are detected.
- Security experts express concerns about the protocol's security design.

##### Tripwires
- Critical security vulnerabilities remain unresolved after 2 weeks.
- Unauthorized access attempts exceed 5 per day.
- Data breach insurance premiums increase by more than 50%.

##### Response Playbook
- Contain: Immediately suspend all data processing and shut down the platform.
- Assess: Conduct a thorough security investigation to identify the root cause of the vulnerabilities.
- Respond: Redesign the open protocol to address the security vulnerabilities, or abandon the open protocol approach in favor of a more secure, proprietary solution.


**STOP RULE:** If the security vulnerabilities cannot be resolved within 1 month, or the cost of redesigning the protocol exceeds $1 million, cancel the project.

---

#### FM6 - The Uninsurable Risk: A Financial Black Hole

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A6
- **Owner**: Chief Financial Officer
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The assumption that existing insurance products adequately cover the risks associated with HaaS workers proves false. This leads to a financial crisis:

*   **Unforeseen Liabilities:** The platform faces significant financial liabilities due to accidents or injuries that are not covered by existing insurance policies.
*   **Increased Operating Costs:** The platform is forced to self-insure or purchase expensive, specialized insurance coverage, significantly increasing operating costs.
*   **Service Provider Reluctance:** Service providers are hesitant to join the platform due to the lack of adequate insurance protection.
*   **Financial Ruin:** The platform is unable to sustain the financial burden of uninsured liabilities, leading to bankruptcy and project failure.

##### Early Warning Signs
- Insurance providers decline to offer coverage for specific physical labor tasks.
- Insurance premiums for HaaS workers are significantly higher than projected.
- Service providers express concerns about the lack of adequate insurance protection.

##### Tripwires
- Insurance premiums exceed 15% of projected revenue.
- Number of uninsured incidents >= 3 per month.
- Service provider sign-up rate declines by more than 20%.

##### Response Playbook
- Contain: Immediately suspend all high-risk physical labor tasks.
- Assess: Conduct a comprehensive risk assessment to identify all potential liabilities.
- Respond: Negotiate with insurance providers to develop customized insurance policies for HaaS workers, or establish a self-insurance fund to cover potential liabilities.


**STOP RULE:** If adequate insurance coverage cannot be secured within 3 months, or the cost of self-insurance exceeds $500,000 per year, cancel the project.

---

#### FM7 - The Scheduling Showdown: A Real-Time Meltdown

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Head of Operations
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption that the HaaS platform can effectively manage real-time scheduling and dispatch of workers proves false. This leads to a logistical nightmare:

*   **Dispatch Delays:** The platform struggles to efficiently match workers with jobs, resulting in significant delays in dispatching workers to client locations.
*   **Client Dissatisfaction:** Clients experience long wait times and unreliable service, leading to widespread dissatisfaction and churn.
*   **Worker Frustration:** Workers are unable to accept jobs in a timely manner, resulting in lost income and frustration.
*   **Operational Chaos:** The platform's scheduling system becomes overwhelmed, leading to errors, conflicts, and overall operational chaos.

##### Early Warning Signs
- Average dispatch time exceeds 15 minutes.
- Client wait times are consistently longer than projected.
- Worker complaints about scheduling inefficiencies increase significantly.

##### Tripwires
- Average dispatch time >= 20 minutes.
- Client satisfaction score related to dispatch speed <= 3/5.
- Worker acceptance rate for job offers < 60%.

##### Response Playbook
- Contain: Immediately implement manual dispatch procedures to address urgent client requests.
- Assess: Conduct a thorough analysis of the scheduling algorithm and infrastructure to identify bottlenecks.
- Respond: Redesign the scheduling algorithm to be more efficient and scalable, and upgrade the platform's infrastructure to handle peak demand.


**STOP RULE:** If the scheduling algorithm cannot be significantly improved within 2 months, or the infrastructure upgrade is deemed infeasible, cancel the project.

---

#### FM8 - The Communication Breakdown: A Tower of Babel

- **Archetype**: Market/Human
- **Root Cause**: Assumption A8
- **Owner**: Head of Customer Support
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The assumption that workers will consistently use the platform's communication tools for job-related communication proves false. This leads to a communication breakdown:

*   **Information Silos:** Critical job-related information is exchanged outside the platform, leading to miscommunication, errors, and disputes.
*   **Lack of Transparency:** The platform lacks visibility into worker-client communication, hindering quality control and dispute resolution.
*   **Reduced Accountability:** Workers and clients are less accountable for their actions when communication occurs outside the platform.
*   **Erosion of Trust:** The lack of a centralized communication channel erodes trust between workers, clients, and the platform.

##### Early Warning Signs
- Worker usage of the platform's messaging feature is below 50%.
- Client complaints about miscommunication increase significantly.
- Dispute resolution times are longer than projected.

##### Tripwires
- Worker usage of platform communication tools <= 40%.
- Client satisfaction score related to communication clarity <= 3/5.
- Dispute resolution time >= 48 hours.

##### Response Playbook
- Contain: Implement mandatory communication protocols requiring all job-related communication to occur within the platform.
- Assess: Conduct a survey to understand why workers are not using the platform's communication tools.
- Respond: Redesign the communication tools to be more user-friendly and convenient, and offer incentives for using them.


**STOP RULE:** If mandatory communication protocols are ineffective, and platform communication tool usage remains below 50% after 1 month, pivot to a model that does not rely on centralized communication or cancel the project.

---

#### FM9 - The Task Description Trap: A Recipe for Disaster

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Head of Product
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The assumption that clients will provide accurate and detailed task descriptions proves false. This leads to a process and financial quagmire:

*   **Scope Creep:** Workers encounter unexpected tasks or requirements that were not included in the initial task description, leading to scope creep and disputes.
*   **Rework and Delays:** Workers are forced to redo tasks due to inaccurate or incomplete instructions, resulting in delays and increased costs.
*   **Client Dissatisfaction:** Clients are dissatisfied with the quality of work due to misaligned expectations and unclear task requirements.
*   **Financial Losses:** The platform incurs financial losses due to rework, disputes, and client refunds.

##### Early Warning Signs
- Worker complaints about inaccurate task descriptions increase significantly.
- Project completion times are consistently longer than projected.
- Dispute rates related to task scope and requirements are higher than expected.

##### Tripwires
- Worker complaints about task descriptions >= 20% of all projects.
- Average project completion time >= 120% of projected time.
- Dispute rate related to task scope >= 10%.

##### Response Playbook
- Contain: Implement a mandatory task description review process to ensure clarity and completeness before assigning workers.
- Assess: Conduct a survey to understand why clients are providing inaccurate task descriptions.
- Respond: Redesign the task description form to be more user-friendly and provide clear guidance on how to describe tasks effectively, and offer incentives for providing detailed and accurate descriptions.


**STOP RULE:** If the task description review process is ineffective, and worker complaints remain high after 1 month, pivot to a model that includes on-site task assessment or cancel the project.
