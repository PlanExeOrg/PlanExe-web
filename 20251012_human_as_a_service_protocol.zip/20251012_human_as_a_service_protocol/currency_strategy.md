This plan involves money.

## Currencies

- **USD:** The project budget is defined in USD, and the primary location is Silicon Valley, USA.

**Primary currency:** USD

**Currency strategy:** USD will be used for all transactions. No additional international risk management is needed.