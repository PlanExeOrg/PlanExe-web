**Verdict:** 🟢 USABLE

**Rationale:** The prompt describes a concrete construction project (building a roundabout) with specific details including location (Hungary), budget (€1.3 million), and immediate start timeline.