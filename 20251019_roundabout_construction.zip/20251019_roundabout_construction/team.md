*Roles Needed & Example People*

# Roles

## 1. Project Director & Lead Strategist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Project Director owns the overall strategic alignment, budget integrity, and contingency protection, requiring full organizational control and commitment to the Pragmatic Optimization path.

**Explanation**:
Owns the overall 'Pragmatic Optimization' path, responsible for high-level decision-making, budget adherence (€1.3M ceiling), and protecting the contingency buffer. Drives the ASAP start.

**Consequences**:
Loss of strategic alignment, immediate budget overrun due to uncontrolled spending velocity, and failure to reconcile conflicting strategic choices (e.g., land acquisition vs. subcontractor quality).

**People Count**:
1

**Typical Activities**:
Overseeing the execution of the overall project strategy, managing the total €1.3M budget ceiling, chairing weekly executive risk review meetings, making final calls on trade-offs between schedule velocity and contingency draw-down, and taking ultimate accountability for strategic alignment across all team functions.

**Background Story**:
Dr. Alistair Vance, hailing from Edinburgh, Scotland, is the Project Director and Lead Strategist. He holds a Ph.D. in Civil Engineering Management from TU Delft, specializing in risk transfer mechanisms in constrained infrastructure funding. His experience includes successfully guiding three major regional transport upgrades across the UK and Ireland, all delivered within 2% of their fixed budgets by relentlessly enforcing strategic alignment. Dr. Vance is intimately familiar with balancing CAPEX preservation against long-term asset performance, making him the perfect candidate to steer the 'Pragmatic Optimization' path for this Hungarian roundabout project.

**Equipment Needs**:
High-powered laptop with specialized project management and risk visualization software (e.g., Primavera P6 access, BIM integration tools), secure access to the €1.3M budget draw-down tracking system, mobile communication suite for remote site communication.

**Facility Needs**:
Dedicated, secure project office space (even if temporary) near the site for executive meetings and sensitive budget/contract review, high-speed internet connection.

## 2. Geotechnical & Subsurface Risk Manager

**Contract Type**: `independent_contractor`

**Contract Type Justification**: As the role is focused on managing the consequences of intentionally limited subsurface investigation (Risk 2), this requires specialized, on-demand geotechnical expertise for emergency response/verification rather than continuous internal staffing.

**Explanation**:
Manages the consequences of the limited investigation scope (Risk 2, High/High). Responsible for ensuring the Rapid Geotechnical Response Contract is effective, monitoring soil preparation protocols, and verifying the suitability of in-situ stabilization methods.

**Consequences**:
Catastrophic failure during earthworks due to unexpected soil conditions, leading to complete project halt, budget depletion for emergency remediation, and potential structural failure or settlement.

**People Count**:
min 1, max 2, depending on project scale and workload.

**Typical Activities**:
Finalizing and maintaining the 72-hour rapid response standby contract for dewatering/grouting crews, overseeing the execution of the limited borehole testing program, verifying the suitability of in-situ soil amendment techniques utilized by subcontractors, and dynamically modeling the impact of subsurface failures against the project schedule.

**Background Story**:
Katalin Horváth, based near Szeged, Hungary, acts as the Geotechnical & Subsurface Risk Manager. Having earned her Master of Science in Soil Mechanics from the Budapest University of Technology and Economics (BME), Katalin spent a decade consulting on drainage and embankment stability for Hungarian agricultural land reclamation projects. She deeply understands the localized geological risks (Risk 2: High/High) inherent in the Great Hungarian Plain and was specifically brought in to manage the emergency response protocols required when the limited subsurface investigation inevitably encounters unexpected water tables or weak strata.

**Equipment Needs**:
Mobile geotechnical laboratory kit (including compaction testers, dynamic cone penetrometer (DCP), specialized sampling tools), remote telemetry units for monitoring dewatering/grouting equipment performance, RTK GPS for precise boundary verification.

**Facility Needs**:
Secure, climate-controlled storage facility on or adjacent to the site for rapid-response grouting materials and specialized drilling/testing consumables.

## 3. Construction & Pavement Quality Assurance Lead (Site Engineer)

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Construction & Pavement Quality Assurance Lead must be a dedicated employee (Site Engineer) to implement the delegated QA/QC authority (Risk 5 mitigation) consistently across all foundation and material placement phases.

**Explanation**:
The delegated expert responsible for day-to-day on-site quality control, specifically verifying the foundation work (subgrade preparation) and ensuring the flexibility in pavement material specifications (dual-lane ready) is executed to the required standard despite using local subcontractors.

**Consequences**:
Quality slippage leading to premature failure (rutting, cracking) or functional obsolescence, undermining the structural integrity purchased by the budget, requiring costly rework.

**People Count**:
1

**Typical Activities**:
Implementing the delegated performance metrics for foundation compaction tests, conducting mandatory daily site walkthroughs to verify adherence to the chosen dual-lane geometry benchmarks, signing off on the acceptability of primary and secondary base course materials based on pre-agreed tolerance thresholds, and conducting remedial work verification if sub-grade stabilization fails.

**Background Story**:
Marco Bellini, a highly experienced Site Engineer from Milan, Italy, serves as the Construction & Pavement Quality Assurance Lead. Marco holds EU certifications in road paving technology and has spent fifteen years overseeing quality control for European highway consortia where material tolerances were often flexible due to supply chain volatility. His skill lies in translating design intent—specifically the dual-lane readiness—into hardened, measurable execution standards on site, ensuring local contractors deliver quality foundations despite pressure to cut corners.

**Equipment Needs**:
Calibrated surveying equipment (Total Station/Level), Nuclear Density Gauge (NDG) for soil compaction testing, core drilling rig access contracts, asphalt sampling coring equipment, tablet/software for immediate QA/QC sign-off log entry.

**Facility Needs**:
Temporary, clean, secure laydown area for material sampling and initial QA/QC checks; access to a certified, independent materials testing lab nearby (as per the review conclusion).

## 4. Regulatory & Stakeholder Navigator (Junior Coordinator)

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Regulatory & Stakeholder Navigator (Junior Coordinator) handles high-frequency, sequential administrative tasks to interface with Hungarian authorities (KVI). This role aligns best with a specialized liaison agency or contractor to navigate fluid regulatory environments. 

**Explanation**:
Handles the high-volume, sequential tasks of interfacing with Hungarian authorities (KVI, Municipalities). Directly responsible for managing the phased approval protocol and ensuring the Project Director is shielded from minor administrative friction to focus on QA.

**Consequences**:
Cascading regulatory delays (Risk 3) due to slow response times or poor documentation sequencing, completely neutralizing the 'ASAP' start goal.

**People Count**:
1

**Typical Activities**:
Managing the sequential submission and tracking of all planning and environmental documentation, attending bi-weekly site review meetings with municipal engineers as the Director's representative, meticulously logging response times against the KVI's 21-day SLA, and coordinating site access notifications for local authorities.

**Background Story**:
Péter Kovács, a native of Debrecen, Hungary, is the Regulatory & Stakeholder Navigator, starting as the Junior Coordinator. Péter possesses strong administrative skills honed while coordinating logistics for regional political campaigns, giving him acute familiarity with local bureaucratic sequencing in Hungarian governmental offices, including the County Basin Water Directorate (KVI). His relevance is ensuring the phased regulatory strategy succeeds by maintaining proactive communication, shielding the Project Director from administrative noise.

**Equipment Needs**:
Secure, high-volume document management system with version control specifically for Hungarian regulatory submissions, encrypted encrypted mobile communication device for liaison duties, schedule tracking interface for monitoring KVI response SLAs.

**Facility Needs**:
Access to a dedicated workspace with secure document handling protocols, allowing flexible arrangement of meetings with local authorities (potentially off-site municipal offices).

## 5. Land & Easement Acquisition Specialist

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Land & Easement Acquisition Specialist manages time-sensitive, negotiation-heavy tasks focused on temporary use easements. This expertise is often sourced externally on a project-by-project basis to ensure rapid, legally precise short-term property access.

**Explanation**:
Focuses exclusively on the 'Land Acquisition Strategy' by managing the negotiation and rapid execution of temporary use easements. This role minimizes upfront capital outlay while securing the necessary right-of-way perimeter for the dual-lane configuration.

**Consequences**:
Legal disputes or inability to secure site access, leading to immediate schedule stoppage, or, conversely, overspending non-contingent capital on freehold, jeopardizing budget integrity.

**People Count**:
min 1, max 2, depending on complexity of local land ownership maps.

**Typical Activities**:
Drafting and executing temporary use easement agreements for non-structural land parcels, liaising directly with Hungarian landowners to secure immediate site establishment boundaries, calculating the precise acreage required for the future dual-lane expansion envelope, and tracking expenditure against the €130,000 Land Acquisition capital ceiling to prevent budget bleed.

**Background Story**:
Sofia Mendes, based in Lisbon, Portugal, is the Land & Easement Acquisition Specialist. Sofia’s background is in real estate portfolio management involving temporary site occupancy for major utility installation across Southern Europe. She excels at negotiating non-freehold arrangements under tight deadlines, focusing purely on securing perimeter access via temporary use easements to minimize the initial capital burn rate, which is critical for protecting the €1.3M budget contingency.

**Equipment Needs**:
Geographic Information System (GIS) software license for perimeter mapping against cadastral data, secure access to Land Management Databases, high-speed legal document signing hardware/software (for digital easement execution).

**Facility Needs**:
Temporary field office near land registry offices or a secure base for legal document drafting and landowner negotiation sessions.

## 6. Logistics & Materials Flow Manager

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Logistics & Materials Flow Manager must procure immediate contractual options for secondary material sourcing (Decision 81f06e88). This specialization is best fulfilled by an external logistics consultant ensuring rapid, specialized fulfillment of material flexibility requirements.

**Explanation**:
Oversees the dual-sourcing strategy for pavement materials (local vs. alternative base). Ensures necessary contractual options are maintained for the secondary reinforcement system and manages coordination for critical mobilization materials to meet the tight construction schedule.

**Consequences**:
Inability to act on the flexible material specifications when subgrade issues arise, potentially causing major paving gaps (Risk 4) or forcing expensive emergency sourcing.

**People Count**:
1

**Typical Activities**:
Securing retainer agreements and call-off contracts for the secondary pavement reinforcement system, forecasting material needs based on the optimistic 10-week earthworks window, coordinating just-in-time delivery schedules for aggregate to maintain continuous paving operations, and validating supplier certification compliance for initial material batches.

**Background Story**:
Cheng Wei, originally from Shanghai, China, works as the Logistics & Materials Flow Manager. He holds an ISM certification and specialized in supply chain resilience for complex European construction projects. Cheng’s expertise involves managing dual-sourcing contracts and ensuring that the project’s flexibility—the ability to swap between primary local materials and secondary imported reinforcement systems—is backed by binding contractual agreements to prevent schedule stalls (Risk 4).

**Equipment Needs**:
Material tracking software integrated with supplier ERPs, contract management platform for triggering call-off orders against secondary material options, vehicle access for site inspection of aggregate stockpiles.

**Facility Needs**:
Secure, designated site storage area specifically rated for various classes of aggregate and base course materials, potentially including weather protection for high-value secondary components.

## 7. Financial Controller & Currency Hedge Analyst

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Financial Controller must have continuous, unwavering fiduciary oversight of the tight 1.3M EUR budget and manage complex, ongoing currency hedging instruments, requiring dedicated internal commitment.

**Explanation**:
Manages the 1.3M EUR budget tracking, monitors draw-down velocity, and critically executes and monitors the 70% forward hedging required to protect the local labor component against HUF/EUR volatility (Risk 7).

**Consequences**:
Unforeseen labor cost escalation due to currency fluctuations, potentially eroding the critical contingency buffer allocated for technical risks.

**People Count**:
1

**Typical Activities**:
Maintaining real-time project expenditure tracking against the €1.3M ceiling, executing and monitoring the forward exchange contracts for HUF labor costs, providing monthly variance analysis explaining any deviation from the anticipated drawdown velocity, and managing the protected balance of the €100,000 Land Acquisition ring-fenced fund.

**Background Story**:
Dr. Evelyn Reed, from London, UK, is the Financial Controller & Currency Hedge Analyst. Dr. Reed specialized in managing cross-border infrastructure financing risk, holding a CFA charter with a focus on emerging market currency exposure. Her primary mandate is to maintain the structural integrity of the €1.3 million budget, most pressingly by executing the complex 70% forward hedging strategy to insulate local Hungarian labor costs (HUF expenditure) from adverse EUR/HUF exchange rate fluctuations (Risk 7).

**Equipment Needs**:
Specialized treasury software suite capable of managing EUR/HUF forward hedging contracts, secure financial reporting terminal, integrated ERP system for monitoring expenditure velocity against planned draw-down schedule.

**Facility Needs**:
A private, secure, climate-controlled area within the Project Office dedicated solely to financial and contract documentation.

## 8. Drainage & Environmental Compliance Officer

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Drainage & Environmental Compliance Officer is needed to ensure the specific, calculated risk of the minimalist drainage plan meets KVI standards, requiring specialized environmental engineering consultancy expertise rather than general management staff.

**Explanation**:
Specializes in ensuring the minimalist drainage plan (decentralized planters + swales) meets Hungarian environmental discharge standards, especially managing the 30% runoff deficit risk identified in the assumptions review, thereby shielding the project from undue KVI scrutiny (Risk 3).

**Consequences**:
Failure to meet environmental discharge limits, resulting in stop-work orders from the County Basin Water Directorate (KVI) or mandatory, costly installation of off-site retention infrastructure.

**People Count**:
1

**Typical Activities**:
Conducting hydrological modeling based on current soil permeability tests to validate the 70% drainage coverage, designing the necessary supplementary swale systems to manage the 30% runoff deficit, actively preparing environmental discharge documentation for the KVI application, and verifying the integration of bio-retention planters within the easement boundaries.

**Background Story**:
László Nagy, a Hungarian hydraulic engineer from Vác, serves as the Drainage & Environmental Compliance Officer. László spent his career ensuring agricultural waterways met stringent EU discharge directives along the Danube basin. He is critically relevant because the chosen minimalist drainage strategy (decentralized planters) only manages 70% of runoff, and László is solely tasked with proving the remaining 30% deficit, managed through engineered swales, will not trigger regulatory penalties from the KVI (Risk 3) or cause subgrade saturation (Risk 2).

**Equipment Needs**:
Hydrological modeling software (e.g., HEC-RAS) licenses, field testing meters for soil permeability (per research requirements), digital camera/GPS tools for documenting bio-retention planter installation compliance.

**Facility Needs**:
Access to regional Hungarian environmental data centers or reliable satellite data feeds to model peak runoff scenarios accurately against the constrained site footprint.

---

# Omissions

## 1. Missing Communication & Information Hand-off Lead

The team has a Regulatory Navigator (junior coordinator) for external politics and a Project Director for strategy. However, there is no clear role responsible for internally consolidating technical outputs (geotech reports, QA/QC logs, material reports) and channeling them into decision inputs efficiently. This task seems unofficially split, creating potential for critical information gaps between the Director, the Site Engineer, and the Geotechnical Manager.

**Recommendation**:
Integrate the responsibility for creating a 'Daily Technical Synthesis Report' into the existing Site Engineer's duties (Construction & Pavement Quality Assurance Lead). This report must summarize the day's geotechnical findings, QA pass/fail rates, and material verification status, ensuring the Project Director receives a non-political distillation of site reality before executive meetings.

## 2. Lack of Dedicated Financial Oversight for Hedging/Drawdown

The Financial Controller manages the budget cap and hedging, but the chosen strategy relies heavily on managing Drawdown Velocity (Decision 12) and currency hedging (Risk 7). There is no specialized resource monitoring the *rate* of expenditure against inflation risk daily, which is crucial when operating close to the minimum contingency buffer.

**Recommendation**:
The Financial Controller & Currency Hedge Analyst should dedicate a minimum of 40% of their time specifically to monitoring drawdown velocity against the 6-month hedging schedule, treating unchecked drawdown as a parallel risk requiring immediate Director escalation, similar to Risk 2 (Geotech).

## 3. Absence of Post-Construction/Commissioning Handover Planning

The project scope, team roles, and derived assumptions are heavily focused on design, procurement, and construction completion. There is no designated responsibility for the final asset handover, official commissioning acceptance by Hungarian authorities, or transition to long-term asset maintenance.

**Recommendation**:
Assign the final responsibility for commissioning sign-off and documentation archival to the Regulatory & Stakeholder Navigator (Péter Kovács). His existing relationship with KVI and municipal bodies makes him the logical party to shepherd the final paperwork, ensuring the asset officially transitions out of the project team's purview.

---

# Potential Improvements

## 1. Clarifying Authority Between Director and Site Engineer on Material Tolerance

The Site Engineer (Marco Bellini) is responsible for QA/QC execution, but the decision on accepting 'off-spec' materials (Decision 11) is a high-level strategic trade-off managed by the Director. This intersection requires precise delegation to avoid delays when minor material variances occur on site.

**Recommendation**:
Formalize the delegation matrix: The Site Engineer can approve material deviations up to 2% deviation from specification thresholds without escalating. Any deviation of 2% or more, or any deviation that impacts the 'dual-lane readiness' standard, requires mandatory, documented sign-off from the Project Director himself, ensuring strategic review precedes financial risk acceptance.

## 2. Improving Synchronization Between Land Acquisition and Subsurface Testing

The team chose temporary easements (minimal CAPEX) but also restricted subsurface testing. The Land Specialist secures the perimeter based on dual-lane needs, but the timing of detailed geotechnical checks around that perimeter needs tighter coupling with site availability.

**Recommendation**:
Mandate that the Land & Easement Acquisition Specialist must provide the Geotechnical Manager with 'Final Permitted Access Schedules' for all easement parcels 7 days prior to the scheduled starting of any subsurface sampling or testing on that parcel. This ensures the Geotechnical Manager can perfectly align limited boreholes with available, legally secured ground.

## 3. Standardizing Geotechnical Data Input for Drainage Compliance

The Drainage Officer relies on limited geotechnical data to prove the 30% runoff deficit can be managed via swales. If the data is insufficient, the Drainage Officer risks triggering the Geotechnical Risk response inappropriately, or worse, approving poor designs.

**Recommendation**:
Require the Geotechnical & Subsurface Risk Manager to provide a formal, written 'Soil Permeability Envelope Summary' specifically tailored to the Drainage Officer's modeling needs (minimum/maximum permeability assumptions for the top 1 meter of soil across the site). This specific output must be delivered before the Drainage Officer finalizes swale designs, ensuring technical assumptions are aligned.