## Positive Constraints

- Construct a big roundabout
- Location: middle of nowhere in Hungary
- Budget: 1.3 million EUR
- Project start ASAP
