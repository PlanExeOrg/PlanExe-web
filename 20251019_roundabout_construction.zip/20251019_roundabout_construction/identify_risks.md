
## Risk 1 - Financial
Budget Erosion due to Conservative Land Acquisition Strategy: The chosen strategy (Decision 3f955aa3) utilizes temporary use easements to preserve initial capital. If unexpected legal challenges or landowner resistance forces the conversion of easements to permanent freehold purchases on highly valued parcels, the resulting negotiations or necessary condemnations could significantly exceed initial cost projections for land acquisition.

**Impact:** If contested freehold acquisitions are necessary, the cost could inflate by 15% to 40% over the estimated land budget, translating to an extra cost of 80,000 – 200,000 EUR, which will severely impact the contingency buffer.

**Likelihood:** Medium

**Severity:** High

**Action:** Establish a pre-negotiated maximum ceiling price for freehold conversion for all identified easement parcels. Immediately budget a dedicated minimum fund (e.g., 100,000 EUR) specifically for Land Acquisition contingency, separate from the main construction float.

## Risk 2 - Technical / Geotechnical
Unforeseen Subsurface Conditions Exceeding Limited Investigation Scope: The chosen strategy (Decision 6dadee17) limits detailed geotechnical testing exclusively to known anomalous zones. If unexpected soft soils or high water tables exist outside these zones, the lack of prior data will cause significant delays and cost escalation during earthworks when encountering these unknown conditions.

**Impact:** Encountering major unknown poor bearing capacity zones could halt earthworks for 3–6 weeks per incident, leading to a minimum schedule delay of 4–8 weeks and requiring costly, unplanned deep stabilization material importation.

**Likelihood:** High

**Severity:** High

**Action:** Allocate 50% of the identified geotechnical testing budget savings towards mobilizing a rapid-response geotechnical repair crew capable of immediate in-situ treatment or emergency dewatering, mitigating the schedule impact when the risk materializes.

## Risk 3 - Regulatory & Permitting
Cascading Delays from Phased Regulatory Approval: The plan adopts a phased inspection protocol (Decision 79c3a11d) focusing on environmental sign-off first. If environmental authorities delay issuing final clearance (Due to, for instance, non-compliance with Decision f55f5c74 drainage requirements), the subsequent traffic and municipal approvals cannot be initiated, causing a full project standstill.

**Impact:** A delay in the primary environmental sign-off by 4-6 weeks during the critical pre-mobilization phase will push the project start date significantly past 'ASAP,' potentially delaying final commissioning by 2-3 months.

**Likelihood:** Medium

**Severity:** High

**Action:** Develop 'shadow' submission packages for subsequent regulatory bodies (traffic, municipal) that address preliminary data, allowing for immediate submission the moment the primary environmental approval is granted, thus overlapping review cycles where feasible.

## Risk 4 - Supply Chain
Inability to Leverage Dual-Pavement Specification Flexibility: The strategy relies on accommodating two alternative base reinforcement systems (Decision 81f06e88) based on material testing. If subgrade testing is delayed (due to Decision 6dadee17 limitations) or if the primary local material proves non-compliant, switching to the secondary option may face supply shortages or price spikes, especially in a remote Hungarian location.

**Impact:** Inability to pivot quickly to the secondary material source could cause a 4-week gap in paving operations while new sourcing arrangements are made, costing approximately 30,000 EUR in idle crew mobilization fees.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Pre-qualify and secure contractual options (at a small commitment fee) with suppliers for the secondary reinforcement system now, ensuring the lead time for the alternate material will not exceed known lead times for the primary choice.

## Risk 5 - Operational / Schedule
Reduced Oversight Capacity Due to Regulatory Focus: Senior project managers will dedicate significant time to proactive liaison with Hungarian authorities (Decision 79c3a11d). This diversion of senior oversight capacity reduces the personnel available for critical, real-time on-site quality control during dynamic construction phases, potentially allowing specification slippage.

**Impact:** Reduced QA/QC oversight during earthworks or primary paving could lead to structural compromises (e.g., poor compaction, faulty asphalt laydown) resulting in mandatory rework costing 5% of the affected phase budget (Est. 20,000 EUR) plus related downtime.

**Likelihood:** High

**Severity:** Medium

**Action:** Delegate specific, measurable quality acceptance authority to a trusted, experienced Site Engineer, empowering them with clear sign-off metrics to manage day-to-day quality assurance without requiring constant Director intervention.

## Risk 6 - Technical / Engineering
Premature Obsolescence due to Conservative Geometry Choice: Designing for a dual-lane configuration built sequentially (Decision 4213f7c3) saves initial capital but requires construction phasing that is less efficient than a single, complex build (like a turbo-roundabout). Regional economic acceleration in Hungary could lead to traffic volumes exceeding the planned overlay capacity before the dual-lane structure is finished.

**Impact:** If traffic exceeds capacity within 2-3 years, the asset fails to meet its underlying societal objective, requiring immediate, costly widening works (reconstruction impacting traffic flow) far sooner than the 15-year expected life.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Ensure the initial easement acquisition (Decision 3f955aa3) secures sufficient right-of-way setback to permit the expansion of the roadway structure without requiring re-entry into land acquisition proceedings for the future widening phase.

## Risk 7 - Financial / Currency
HUF/EUR Conversion Volatility Impact on Local Labor Costs: While the budget is in EUR, local labor and minor purchases use HUF (Currency Strategy). If the HUF weakens significantly against the EUR between contract signing and payment milestones, the actual cost burden (in EUR terms) for Hungarian labor and site services will rise unexpectedly.

**Impact:** A 5% adverse movement in the EUR/HUF exchange rate over the 12-month cycle could lead to an undocumented cost overrun of 15,000–30,000 EUR, directly depleting the contingency fund dedicated to physical execution risks.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Implement a 70% forward hedging contract covering critical, high-volume HUF expenditures (estimated labor force costs) for the initial 6 months of construction, locking in the favorable expected EUR equivalent.

## Risk 8 - Social / Political
Community Resistance to Construction Traffic Management: Choosing a total road closure (Decision d677b910) for efficiency will generate significant local opposition due to the long detour distances in a rural location, risking community sabotage or organized political complaints that slow down subsequent official sign-offs.

**Impact:** Severe public backlash could lead to local authorities being pressured to impose stop-work orders during politically sensitive periods or mandate expensive, politically motivated last-minute design changes.

**Likelihood:** High

**Severity:** Medium

**Action:** As a counterbalance to the full closure, immediately engage the Local Authority Engagement Cadence (Decision 0ffa024e) to announce concrete, visible benefits (e.g., immediate localized road repairs nearby) concurrent with the closure announcement to build political capital.

## Risk summary
The project faces critical risks primarily stemming from the execution strategy aligned with the 'Pragmatic Optimization' path. The two most severe, intertwined risks are **Unforeseen Subsurface Conditions** (High Likelihood/High Severity due to limited investigation scope) and the **Budget Erosion from Land Acquisition Conflicts** (Medium/High due to reliance on easements). These risks directly attack the project's tight 1.3M EUR budget constraint. A third critical risk involves **Cascading Delays from Phased Regulatory Approval** (Medium/High), which could negate the ASAP start goal. Mitigation efforts must focus on aggressively protecting the financial reserves against geotechnical surprises and ensuring regulatory progression flows seamlessly, even if it means accepting minor schedule slippage in line with the decision to use phased inspections.