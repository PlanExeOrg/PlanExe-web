Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 19 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 0 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the scope is limited to laws of physics. The plan describes civil engineering trade-offs (geotechnical certainty vs. schedule acceleration) which do not require breaking any fundamental physical law (e.g., thermodynamics, relativity).

**Mitigation**: None.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination: successful execution of a 'Pragmatic Optimization' strategy requires perfect management of high geotechnical uncertainty (limited testing) against a tight budget and schedule. Quotes confirm this core risk: 'Subsurface Investigation Scope Limitation is critically shallow, transferring high geotechnical uncertainty directly into the construction budget (High/High risk)'.

**Mitigation**: Project Director: Immediately halt all non-land/regulatory spending and execute Monte Carlo simulation to validate ECF vs. contingency buffer (<€150k threshold) within 7 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on undefined strategic concepts that drive critical risk trade-offs. The core strategy, 'Pragmatic Optimization,' lacks definition beyond choosing specific decision stances. The prompt requires defining mechanism-of-action, ownership, and outcomes, which are omitted. Quote: 'The primary strategic tension identified for this infrastructure project revolves around Geotechnical Certainty vs. Schedule Acceleration.'

**Mitigation**: Project Director & Lead Strategist: Produce a one-pager defining 'Pragmatic Optimization' mechanism, ownership, and 'ASAP' success metrics by July 15, 2026.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan explicitly highlights cascade risks but fails to detail the resulting second-order effects or concrete financial/legal cross-linkages required by the rubric. Quote: 'Relying on compulsory purchase immediately delays mobilization... while paying premium cash reduces the contingency buffer necessary for unforeseen subsurface remediation costs.' This cascade is stated but not formally mapped.

**Mitigation**: Project Director: Map all five critical levers (Land, Investigation, Geometry, Subgrade, Tolerance) to explicit financial/regulatory cascade outcomes by the next executive review.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent, directly failing criterion (b) for rating HIGH. The plan mentions regulatory hurdles repeatedly but lacks a structured matrix. Quote: 'Cascading Delays from Phased Regulatory Approval (Decision 79c3a11d)'.

**Mitigation**: Regulatory & Stakeholder Navigator: Deliver a complete, dated permit/approval matrix mapping KVI and Municipal deadlines against the 10-week earthworks window within 14 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed funding sources are entirely absent, and runway calculation is unaddressed. The plan mentions a fixed budget of “1.3 million EUR” but names no sources (committed, LOI, or otherwise) and fails to define a financing draw schedule or covenants, thus failing the rubric criteria.

**Mitigation**: Financial Controller & Currency Hedge Analyst: Deliver a dated financing plan listing all funding sources, status, draw schedule, financial gates (covenants), and calculated runway by August 15, 2026.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical planning elements required for cost realism normalization are missing entirely, directly violating the rubric instruction to cite math and comparables. The plan does not provide the 1.3M EUR budget's breakdown (e.g., cost per m² for fit-out/capex) or any relevant benchmarks/quotes to substantiate the figure against the scope.

**Mitigation**: Project Director & Financial Controller: Commission an immediate 3-party cost benchmarking exercise (including 3 comparables) and normalize the €1.3M budget against the required footprint (m²) within 45 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections only as single numbers without ranges or scenario analyses, indicative of unchecked optimism. Quote from Goal Statement: 'Construct a fully functional, dual-lane ready roundabout... adhering to the 1.3 Million EUR budget' and 'Earthworks targeted for completion within 10 weeks'.

**Mitigation**: Project Director: Require the Financial Controller to generate Best/Base/Worst-Case financial scenarios based on ECF results and schedule slippage (≤2-week bands) within 30 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan explicitly states core components lack necessary documentation and the expert review confirmed this structural gap. Quote: 'Subsurface Investigation Scope Limitation is critically shallow, transferring high uncertainty onto the active construction budget' and expert advice demands immediate scope revision.

**Mitigation**: Project Director & Geotechnical & Subsurface Risk Manager: Re-scope geotechnical investigation to cover 50% of the footprint to 3m depth, formally documenting the resulting Minimum Viable Base Specification within 30 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the rubric requires citation of a critical claim lacking verifiable artifact, and the plan makes several critical claims about land acquisition that are unproven. Specifically, the plan claims reliance on 'temporary use easements for all non-structural land' (Decision 1), but the evidence required (e.g., executed easement documents or land registry proof) is entirely absent.

**Mitigation**: Land & Easement Acquisition Specialist: Deliver signed, executed temporary use easement documents covering 100% of non-structural land by 2026-05-30.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project depends on the highly abstract deliverable: 'Construct a fully functional, dual-lane ready roundabout'. This lacks a quantifiable KPI for structural durability. Quote: 'Project completion is measured by final acceptance inspection confirming the physical construction of the intersection geometry meets dual-lane readiness standards'.

**Mitigation**: Site Engineer: Define SMART criteria for dual-lane readiness, including a KPI for minimum 10-year pavement service life (e.g., <5% structural deflection) by 2026-06-30.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan introduces 'turbo-roundabout' geometry necessitating 'highly precise, complex earthworks' (Intersection Geometry, Decision 4) while explicitly choosing 'Subsurface Investigation Scope Limitation' (Decision 5). This combination of high-precision construction requirements built upon minimal geological certainty constitutes potential Gold Plating, as the complexity does not directly secure the core goals of cost preservation or access. The core goals are defined as 'adhering to the 1.3 Million EUR budget' and 'commencing construction activities as soon as feasible (ASAP start)'.

**Mitigation**: Project Director: Initiate a Benefit Case Review for the 'turbo-roundabout' option, justifying inclusion with a KPI, owner, cost, or move to backlog by 2026-06-15.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan's success hinges on the 'Geotechnical & Subsurface Risk Manager' (Katalin Horváth), a highly specialized expert required to manage consequence (72-hour response contract) for an intentionally high-impact risk (High/High geotechnical failure from limited testing). This expertise is rare.

**Mitigation**: Project Director: Initiate immediate validation of talent market salaries and availability for a specialized Geotechnical and Subsurface Risk Manager within 14 days to confirm go/no-go.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents severe legality and jurisdiction uncertainty, immediately meeting the HIGH threshold set by the rubric. There is no mapping of required permits or governing statutes. Quote: 'Compliance Actions: Compile and submit comprehensive environmental documentation package to KVI immediately.' The required legal artifacts and specific controlling regimes are unmapped.

**Mitigation**: Regulatory & Stakeholder Navigator: Create a jurisdictional regulatory matrix listing all required Hungarian permits, legal authorities (KVI, Municipal), lead times, and formal submission artifacts within 21 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan reveals a planned erosion of asset quality to meet the initial CapEx constraint, identified as a critical trade-off. Quote: 'Reducing the standard required thickness of the asphalt course or selecting a lower-grade aggregate base layer immediately cuts the consumption of high-cost bituminous materials... [and] necessitates a faster planned re-pavement cycle within a decade.'

**Mitigation**: Project Director & Financial Controller: Perform the required NPV analysis comparing CapEx savings vs. 10-year OpEx increase; mandate full-spec base if lifecycle cost (NPV) penalty exceeds 20% of saved CapEx.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan explicitly establishes a trade-off where governmental approvals create known schedule conflicts that are explicitly accepted. Quote: 'Adopt a phased inspection and approval protocol, securing environmental sign-off first, followed sequentially by traffic management approvals, accepting potential downstream idle time.' This acceptance of 'idle time' directly conflicts with the 'ASAP start' mandate.

**Mitigation**: Regulatory & Stakeholder Navigator: Pivot the strategy to parallel review submissions for Municipal approval immediately upon KVI EIA submission, aiming for a binding 14-day KVI response commitment.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because all critical external dependencies rely on uncertain timelines, specifically regulatory approval commitments. The plan accepts known delays: 'accepting potential downstream idle time.' Furthermore, external experts flagged this as a 'Fatal Flaw' due to reliance on slow sequential processing conflicting with the 'ASAP' start.

**Mitigation**: Regulatory & Stakeholder Navigator: Secure written commitment from KVI guaranteeing max 14-day response for EIA; otherwise, initiate parallel municipal review immediately.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the **Land Acquisition Specialist** (incentive: minimize initial capital outlay via easements) conflicts with the **Financial Controller** (incentive: protect the tight €1.3M budget, requiring low upfront spend to maintain contingency). The plan shows budget pressure causing planned overspend: '...paying premium cash reduces the contingency buffer necessary for unforeseen subsurface remediation costs.'

**Mitigation**: Project Director: Establish a shared OKR defining 'Acceptable Upfront Land Spend' (≤€130k) that mandates easement use, monitored by both owners by 2026-05-30.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks the required formal control artifacts demonstrating accountability and adaptive capacity throughout execution. The review explicitly flags this absence: 'Vague ‘we will monitor’ is insufficient.' There are no explicit KPIs, review cadences, or defined change control thresholds mentioned in the provided text.

**Mitigation**: Project Director: Establish a monthly review cadence, develop a KPI dashboard, and mandate a lightweight Change Control Board (CCB) governance charter by August 30, 2026.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks an integrated cross-impact analysis necessary to surface cascades as required by the rubric. The specific overlooked multi-node cascade is the incompatibility between **Limited Subsurface Investigation (Critical Risk)** and **Dual-Lane Geometry Requirement**, which necessitates higher subgrade support standards, thus directly violating the **Pavement Structure Specification Alternative (High Risk)** which opts for cheaper base materials.

**Mitigation**: Project Director & Lead Strategist: Deliver a formal Bow-Tie/FTA diagram linking Geotech (Input), Pavement Specs (Output), and Budget Contingency (Financial Outcome) by 2026-07-30.