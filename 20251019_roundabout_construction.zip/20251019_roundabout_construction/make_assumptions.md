
## Question 1 - Given the 1.3 Million EUR budget, what is the maximum allowable percentage of this capital that can be immediately allocated to non-recoverable Land Acquisition costs (easements and initial freehold settlements) without jeopardizing the minimum required 15% construction contingency buffer?

**Assumptions:** Assumption: The total 1.3 Million EUR budget requires a minimum 15% (EUR 195,000) contingency buffer dedicated primarily to technical risks identified (geotechnical/materials issues). Therefore, the maximum allocation for Land Acquisition (which consumes capital early) is set at 10% of the total budget, or 130,000 EUR, to maintain adequate float for execution.

**Assessments:** Title: Funding Allocation Threshold Assessment
Description: Evaluation of the hard limit for upfront capital commitment to land rights.
Details: Exceeding the 130,000 EUR cap for land acquisition will reduce the technical contingency below the recommended 15% minimum buffer. Risk 1 (Budget Erosion from Land Acquisition) becomes virtually uncontrollable. Opportunity exists to negotiate shorter-term, higher-fee easements (leveraging Decision 3f955aa3 strategy) if a strict ceiling of 10% of total budget is enforced.

## Question 2 - What is the targeted duration (in weeks) for the earthworks and subgrade preparation phase, acknowledging the Subsurface Investigation Scope Limitation of only testing known anomalies, and how does this timeline support the 'ASAP' project start date of April 28, 2026?

**Assumptions:** Assumption: The 'ASAP' start date of 2026-Apr-28 mandates mobilization commencement by mid-May 2026. Given the limited subsurface investigation (Decision 6dadee17), the Earthworks/Subgrade phase is estimated optimistically at 10 weeks, contingent upon no major unknown geotechnical issues arising.

**Assessments:** Title: Timeline Viability Against Limited Investigation
Description: Assessment of project schedule feasibility based on optimized earthworks duration.
Details: An estimated 10-week earthworks phase starting in mid-May 2026 targets completion in late July 2026. This timeline is aggressive; Risk 2 (Unforeseen Subsurface Conditions) has a High Likelihood impact, meaning a single significant delay could extend this phase by 4-6 weeks, jeopardizing the entire schedule. Opportunity: If testing is truly limited and geology is benign, schedule compression of 2 weeks might be achievable.

## Question 3 - Given the reliance on local Hungarian contractors and limited international expert staff (Decision e1ae8612), what is the specified required certification/skill gap analysis ensuring local teams possess the necessary expertise for the dual-lane geometry overlay readiness?

**Assumptions:** Assumption: The complexity of preparing for a dual-lane overlay (Decision 4213f7c3) requires specific knowledge in long-term pavement marking substrate preparation. A gap analysis mandates a minimum of two certified Hungarian supervisors must undergo a 2-week certification course costing approximately 8,000 EUR, funded from the operational budget.

**Assessments:** Title: Personnel Competency Assurance Assessment
Description: Evaluating specialized skills transfer for future-proofing the construction.
Details: Failure to certify local supervisors in the specific dual-lane preparation technology risks executing the initial base layer poorly, making the eventual overlay conversion costly or impossible (Risk 6 impact). The 8,000 EUR immediate training cost is preferable to rework costs estimated at 20,000 EUR (Risk 5 consequence). Benefit: Successful upskilling stabilizes long-term maintenance capability within the local workforce.

## Question 4 - To mitigate Risk 3 (Cascading Regulatory Delays), what specific Hungarian permitting authority (e.g., Ministry of Interior, Regional Environmental Authority) is prioritized for the initial 'environmental sign-off' phase, and what contractual service level agreement (SLA) defines 'delayed' status?

**Assumptions:** Assumption: For infrastructure projects in rural Hungary, the primary controlling body for environmental sign-off is the relevant County Basin Water Directorate (KVI). A 'delayed' status is contractually defined as a lack of official written response or request for further information within 21 calendar days of formal package submission.

**Assessments:** Title: Governance and Regulatory Friction Profiling
Description: Pinpointing the critical path regulatory bottleneck and defining measurable checkpoints.
Details: Targeting the KVI is crucial, as their water management sign-off directly impacts Decision 9 (Drainage Architecture). If the 21-day SLA is breached, Risk 3 activates. Opportunity: Leveraging Decision 79c3a11d's high-level liaison immediately upon submission can subjectively reduce response time by 50%, achieving sign-off in ~10 days.

## Question 5 - Given the High Likelihood of geotechnical failure (Risk 2), what specific site equipment mobilization contract clauses are required to guarantee the rapid deployment of emergency dewatering or deep stabilization resources within 72 hours of a subsurface failure discovery?

**Assumptions:** Assumption: The rapid-response crew mobilized via mitigation for Risk 2 must maintain a pre-contracted standby rate equivalent to 10% of their mobilization fee, ensuring Tier 1 availability within 72 hours. This standby cost is estimated at 5,000 EUR per month of earthworks duration (10 weeks total).

**Assessments:** Title: Safety and Risk Mitigation Pre-Commitment
Description: Ensuring technical preparedness effectively translates into executable risk mitigation.
Details: The 5,000 EUR monthly standby fee is a direct upfront cost to hedge against massive schedule/budget loss from Risk 2. Failure to contractually bind this response increases the effective severity of any subsurface discovery, potentially leading to schedule losses exceeding 6 weeks. Benefit: This preemptive expenditure formalizes the safety buffer required by the pragmatic optimization strategy.

## Question 6 - Which of the three proposed drainage strategies (Decision f55f5c74) aligns best with the minimal footprint required by the Land Acquisition Strategy (easements only), and what is the estimated volumetric capacity deviation compared to a standard retention pond?

**Assumptions:** Assumption: Strategy 3 (Dispersed, decentralized bio-retention planters integrated into roadside margins) is the only drainage option that adheres strictly to the minimal, non-structural easement footprint, requiring zero dedicated pond acreage. This solution is assumed to handle 70% of peak runoff volume, leaving a 30% deficit addressed by roadside swales.

**Assessments:** Title: Environmental Compliance Within Footprint Constraints
Description: Validation of the chosen drainage strategy against physical land constraints.
Details: Strategy 3 is mandatory given the Land Acquisition constraint (Risk 1 mitigation). The risk is that the 30% runoff shortfall forces reliance on external ditches, potentially conflicting with Decision 9 and incurring minor additional ROW claims. Opportunity: Low-impact bio-retention often satisfies local environmental inspectors more readily than large, artificial retention ponds.

## Question 7 - Considering the pragmatic path selected, how will senior management ensure the local authority engagement cadence (Decision 0ffa024e) is prioritized to compensate for the slow, phased regulatory approval process (Decision 79c3a11d) without over-diverting resources from critical on-site quality checks (Risk 5)?

**Assumptions:** Assumption: The Project Director will dedicate a dedicated, junior Project Coordinator (PC) to manage the bi-weekly engagement cadence (leveraging Strategy 1 of Decision 0ffa024e), reporting directly to the Director. This frees the Director (Risk 5 mitigation) to focus 70% of their time on site QA/QC.

**Assessments:** Title: Stakeholder Management Resource Balancing
Description: Assessing the feasibility of meeting regulatory engagement while preserving site oversight.
Details: Allocating a dedicated PC for liaison manages Risk 5 by shielding the Director, allowing the Director to address the primary QA needs during earthworks. The risk shifts slightly toward the PC's competence in nuanced political navigation, but this is a lower severity risk than construction failure. Synergy: This operational division supports the phased environmental approval by ensuring consistent communication flow.

## Question 8 - To manage the currency risk associated with HUF labor costs (Risk 7), what precise percentage of the construction phase budget (excluding land acquisition) should be ring-fenced for immediate hedging activity based on the estimated local labor component?

**Assumptions:** Assumption: Based on standard Hungarian infrastructure cost models for a project of this nature, local labor and minor procurements constitute approximately 35% of the total eligible construction expenditure (1.3M EUR minus estimated Land Acquisition). Therefore, 70% hedging (per Risk 7 mitigation) should target 70% of 35% of the remaining budget.

**Assessments:** Title: Operational Systems Currency Risk Management
Description: Quantifying the financial exposure that requires immediate hedging intervention.
Details: If 400,000 EUR is provisionally allocated to civil works post-land acquisition, the target HUF exposure is approx. 140,000 EUR (35% of 400k). Hedging 70% of this exposure means securing 98,000 EUR worth of HUF forward contracts immediately. This financial action directly protects the operational budget integrity against macroeconomic shifts, a key component of long-term system stability.