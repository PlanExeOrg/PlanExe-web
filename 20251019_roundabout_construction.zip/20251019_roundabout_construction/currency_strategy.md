This plan involves money.

## Currencies

- **EUR:** The budget is explicitly stated in Euros (€1.3 million), and EUR is the currency for major construction contracts and international budgeting.
- **HUF:** Hungarian Forint is the local transactional currency for smaller labor costs, local services, and day-to-day site expenses within Hungary.

**Primary currency:** EUR

**Currency strategy:** The project budget and primary financial reporting will be maintained in EUR, matching the fixed contract amount. Local expenditures (labor, minor supplies in Hungary) will be executed in HUF, requiring regular conversion monitoring to ensure the EUR budget is not eroded by adverse long-term HUF fluctuations.