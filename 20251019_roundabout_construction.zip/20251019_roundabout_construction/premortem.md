A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The chosen 'Pragmatic Optimization' strategy sufficiently compensates for the High/High geotechnical risk (due to limited investigation) via the 72-hour rapid response contract and the €195k contingency buffer. | Immediately halt all spending not tied to land access or KVI lobbying. Demand the Geotechnical Risk Modeler (Expert 2) deliver a final Expected Cost of Failure (ECF) model for Class 3 soil conditions across 50% of the footprint within 7 days. | The calculated ECF for a single major subsurface failure incident exceeds €150,000, or the required depth/coverage for the reassessment cannot be secured within 14 days. |
| A2 | Local Hungarian subcontractors possess the latent technical competence to successfully execute the high-specification base compaction required for the 'dual-lane ready' geometry without the benefit of comprehensive geotechnical testing. | The Site Engineer must immediately contract an independent, accredited third-party lab to conduct a mandatory pre-mobilization audit of the top two shortlisted pavement subcontractors against the Minimum Viable Base Specification for dual-carriageway standards. | The audit reveals a deficiency in achieving required CBR/compaction standards in more than 25% of their sample work, or the cost to train their supervisors (€8,000) must be doubled to secure reliable performance. |
| A3 | The phased regulatory approval strategy (environmental first, sequential municipal design review) will not introduce schedule-killing idle time, allowing the 'ASAP' earthworks mobilization to commence within the 10-week target window. | The Regulatory & Stakeholder Navigator must secure written, binding commitment from the County Basin Water Directorate (KVI) guaranteeing a maximum 14-day response/clarification cycle for the primary EIA submission, to be delivered within 21 days. | KVI will not commit to a 14-day cycle (only offering 21+ days), or the Municipal Engineering Department requires submission of the KVI-approved environmental plan before they will begin their design review. |
| A1 | The chosen 'Pragmatic Optimization' strategy sufficiently compensates for the High/High geotechnical risk (due to limited investigation) via the 72-hour rapid response contract and the €195k contingency buffer. | Immediately halt all spending not tied to land access or KVI lobbying. Demand the Geotechnical Risk Modeler (Expert 2) deliver a final Expected Cost of Failure (ECF) model for Class 3 soil conditions across 50% of the footprint within 7 days. | The calculated ECF for a single major subsurface failure incident exceeds €150,000, or the required depth/coverage for the reassessment cannot be secured within 14 days. |
| A2 | Local Hungarian subcontractors possess the latent technical competence to successfully execute the high-specification base compaction required for the 'dual-lane ready' geometry without the benefit of comprehensive geotechnical testing. | The Site Engineer must immediately contract an independent, accredited third-party lab to conduct a mandatory pre-mobilization audit of the top two shortlisted pavement subcontractors against the Minimum Viable Base Specification for dual-carriageway standards. | The audit reveals a deficiency in achieving required CBR/compaction standards in more than 25% of their sample work, or the cost to train their supervisors (€8,000) must be doubled to secure reliable performance. |
| A3 | The phased regulatory approval strategy (environmental first, sequential municipal design review) will not introduce schedule-killing idle time, allowing the 'ASAP' earthworks mobilization to commence within the 10-week target window. | The Regulatory & Stakeholder Navigator must secure written, binding commitment from the County Basin Water Directorate (KVI) guaranteeing a maximum 14-day response/clarification cycle for the primary EIA submission, to be delivered within 21 days. | KVI will not commit to a 14-day cycle (only offering 21+ days), or the Municipal Engineering Department requires submission of the KVI-approved environmental plan before they will begin their design review. |
| A4 | The upfront decision to use only temporary use easements for non-structural land successfully shields the project from mid-execution legal challenges requiring immediate, costly freehold conversion negotiations. | The Land & Easement Acquisition Specialist must confirm via signed landowner attestations that no parcel secured via easement has recorded legacy claims that could mandate compulsory purchase proceedings or require additional financial compensation before final street surfacing. | A single, critical non-structural parcel secured via easement is subject to an active, non-waivable pre-existing right-of-way claim, forcing the reallocation of the ring-fenced €100k acquisition contingency. |
| A5 | The Project Director's delegation of 70% of QA/QC execution authority to the experienced Site Engineer will not create an operational gap in high-level strategic governance, specifically regarding material tolerance waivers (Decision 11). | The Project Director and Site Engineer must co-sign a formal Governance Matrix documenting that the Site Engineer has unilateral waiver authority only up to 1.5% material deviation and must elevate any 1.5%-2.0% deviation to the Director for strategic budget review. | The Site Engineer escalates 5 or more material variance decisions (even if below 2.0%) in a single week, indicating a lack of confidence or uncertainty in the delegated metrics, slowing the paving pace by >20%. |
| A6 | The reliance on a minimalist, decentralized drainage solution (70% coverage via planters) is sufficient to meet Hungarian environmental discharge standards under 'worst-case' seasonal peak rainfall events. | The Drainage & Environmental Compliance Officer must present the KVI with the full hydrological model, including the 30% unmanaged runoff deficit, and receive documented, written pre-approval that this deficit will not trigger an environmental compliance stop-work order if peak rainfall occurs. | KVI requires the installation of external, off-site containment infrastructure (like a retention pond) to manage the 30% deficit, an action that requires land outside the secured easements. |
| A1 | The chosen 'Pragmatic Optimization' strategy sufficiently compensates for the High/High geotechnical risk (due to limited investigation) via the 72-hour rapid response contract and the €195k contingency buffer. | Immediately halt all spending not tied to land access or KVI lobbying. Demand the Geotechnical Risk Modeler (Expert 2) deliver a final Expected Cost of Failure (ECF) model for Class 3 soil conditions across 50% of the footprint within 7 days. | The calculated ECF for a single major subsurface failure incident exceeds €150,000, or the required depth/coverage for the reassessment cannot be secured within 14 days. |
| A2 | Local Hungarian subcontractors possess the latent technical competence to successfully execute the high-specification base compaction required for the 'dual-lane ready' geometry without the benefit of comprehensive geotechnical testing. | The Site Engineer must immediately contract an independent, accredited third-party lab to conduct a mandatory pre-mobilization audit of the top two shortlisted pavement subcontractors against the Minimum Viable Base Specification for dual-carriageway standards. | The audit reveals a deficiency in achieving required CBR/compaction standards in more than 25% of their sample work, or the cost to train their supervisors (€8,000) must be doubled to secure reliable performance. |
| A3 | The phased regulatory approval strategy (environmental first, sequential municipal design review) will not introduce schedule-killing idle time, allowing the 'ASAP' earthworks mobilization to commence within the 10-week target window. | The Regulatory & Stakeholder Navigator must secure written, binding commitment from the County Basin Water Directorate (KVI) guaranteeing a maximum 14-day response/clarification cycle for the primary EIA submission, to be delivered within 21 days. | KVI will not commit to a 14-day cycle (only offering 21+ days), or the Municipal Engineering Department requires submission of the KVI-approved environmental plan before they will begin their design review. |
| A4 | The upfront decision to use only temporary use easements for non-structural land successfully shields the project from mid-execution legal challenges requiring immediate, costly freehold conversion negotiations. | The Land & Easement Acquisition Specialist must confirm via signed landowner attestations that no parcel secured via easement has recorded legacy claims that could mandate compulsory purchase proceedings or require additional financial compensation before final street surfacing. | A single, critical non-structural parcel secured via easement is subject to an active, non-waivable pre-existing right-of-way claim, forcing the reallocation of the ring-fenced €100k acquisition contingency. |
| A5 | The Project Director's delegation of 70% of QA/QC execution authority to the experienced Site Engineer will not create an operational gap in high-level strategic governance, specifically regarding material tolerance waivers (Decision 11). | The Project Director and Site Engineer must co-sign a formal Governance Matrix documenting that the Site Engineer has unilateral waiver authority only up to 1.5% material deviation and must elevate any 1.5%-2.0% deviation to the Director for strategic budget review. | The Site Engineer escalates 5 or more material variance decisions (even if below 2.0%) in a single week, indicating a lack of confidence or uncertainty in the delegated metrics, slowing the paving pace by >20%. |
| A6 | The reliance on a minimalist, decentralized drainage solution (70% coverage via planters) is sufficient to meet Hungarian environmental discharge standards under 'worst-case' seasonal peak rainfall events. | The Drainage & Environmental Compliance Officer must present the KVI with the full hydrological model, including the 30% unmanaged runoff deficit, and receive documented, written pre-approval that this deficit will not trigger an environmental compliance stop-work order if peak rainfall occurs. | KVI requires the installation of external, off-site containment infrastructure (like a retention pond) to manage the 30% deficit, an action that requires land outside the secured easements. |
| A7 | The decision to prioritize local material sourcing (Decision 2) for base materials means that the necessary high-volume aggregate deliveries can maintain a just-in-time cadence aligned with the 10-week earthworks schedule without disruption from localized site storage limitations or contractor scheduling conflicts. | The Logistics & Materials Flow Manager must secure signed, 3-week lookahead delivery schedules from the primary aggregate supplier demonstrating 100% compliance with the 10-week earthworks timeline, with physical site space verified for the expected just-in-time stockpiles. | The aggregate supplier reports an inability to meet the tight delivery window due to site congestion, projecting a necessary 2-week stockpile buffer that physically exceeds the available area between the easement boundaries. |
| A8 | The chosen traffic management strategy (full corridor closure) is politically sustainable for the required three-month duration, meaning local community/economic disruption will not result in executive intervention leading to a mandatory adoption of the slower, partial-access traffic plan. | The Regulatory & Stakeholder Navigator must conduct a focused, third-party political sentiment poll in the adjacent municipalities one week post-closure, specifically testing tolerance thresholds for detour length and duration. | The sentiment poll indicates that local business disruption ratings exceed 7/10 tolerance, prompting a formal request from the Municipal Engineering Body for the Project Director to replace the full closure schedule with the phased traffic management approach (Decision 15, Strategy 2). |
| A9 | The financing drawdown velocity (accelerated rate) is achieving its goal of locking in material costs against mid-term inflation shocks, meaning that costs quoted for major material batches (asphalt/signage) 90 days out remain static or decrease. | The Financial Controller must compare Q3 2026 material Pro-Forma invoices (locked in by early drawdown) against current Q4 2026 quoted spot rates for the main asphalt supplier and imported signage components; any quoted rise exceeding 1.5% invalidates the hedge strategy's success. | Q4 spot rates for bituminous materials show an unhedged cost increase greater than 1.5% compared to the Q3 prices locked in by the accelerated drawdown schedule, indicating inflation risk was not adequately mitigated. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Contingency Collapse: Sinking into the Subgrade Abyss | Process/Financial | A1 | Project Director & Lead Strategist | CRITICAL (20/25) |
| FM2 | The Administrative Freeze: Regulatory Stagnation Traps Mobilized Crews | Technical/Logistical | A3 | Regulatory & Stakeholder Navigator | CRITICAL (16/25) |
| FM3 | The Sub-Par Foundation: Local Skill Gap Undermines Dual-Lane Readiness | Market/Human | A2 | Construction & Pavement Quality Assurance Lead (Site Engineer) | CRITICAL (15/25) |
| FM4 | The Contingency Collapse: Sinking into the Subgrade Abyss | Process/Financial | A1 | Project Director & Lead Strategist | CRITICAL (20/25) |
| FM5 | The Administrative Freeze: Regulatory Stagnation Traps Mobilized Crews | Technical/Logistical | A3 | Regulatory & Stakeholder Navigator | CRITICAL (16/25) |
| FM6 | The Sub-Par Foundation: Local Skill Gap Undermines Dual-Lane Readiness | Market/Human | A2 | Construction & Pavement Quality Assurance Lead (Site Engineer) | CRITICAL (15/25) |
| FM7 | The Contingency Collapse: Sinking into the Subgrade Abyss | Process/Financial | A1 | Project Director & Lead Strategist | CRITICAL (20/25) |
| FM8 | The Administrative Freeze: Regulatory Stagnation Traps Mobilized Crews | Technical/Logistical | A3 | Regulatory & Stakeholder Navigator | CRITICAL (16/25) |
| FM9 | The Quality Cascade: Delegated Authority Breeds Specification Drift | Market/Human | A5 | Construction & Pavement Quality Assurance Lead (Site Engineer) | HIGH (12/25) |


### Failure Modes

#### FM1 - The Contingency Collapse: Sinking into the Subgrade Abyss

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Project Director & Lead Strategist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Failure occurs during initial bulk earthworks (Week 4-6). The limited geotechnical scope (relying only on anomalous zones) misses a significant deposit of untreated alluvial soft soil across the primary line of travel. This requires immediate deep soil mixing/grouting, estimated at €180,000. The initial budget allocated only €130,000 for land acquisition, leaving only €195,000 in technical contingency. The €180,000 remediation cost depletes the buffer down to €15,000, rendering the project un-insurable for subsequent, minor issues. The Financial Controller flags that the ECF model was fatally optimistic, leading to an immediate halt in all procurement of specialized paving materials.

##### Early Warning Signs
- ECF model validation (Data Item 2) returns a value >= €150,000.
- Initial excavation encounters soil resistivity/density measurements 40% below the minimum acceptable threshold for 5 consecutive meters.
- The Project Director authorizes the first draw from the technical contingency fund exceeding €20,000 before base layer preparation begins.

##### Tripwires
- Technical Contingency Drawdown >= 50% (€97,500) before paving course is sampled.
- Geotechnical Risk Manager refuses to sign off on subgrade preparation for 3 consecutive days.
- Required stabilization cost estimate exceeds €150,000.

##### Response Playbook
- Contain: Immediately issue a Stop Work Order affecting all earthworks and mandate exclusion zones around the affected area to prevent spread or contamination.
- Assess: The Geotechnical Risk Manager must produce a full, verified ECF for remediation of the affected area within 48 hours, and the Financial Controller must confirm the exact remaining contingency balance.
- Respond: If ECF exceeds remaining contingency, the Project Director immediately notifies financial stakeholders and initiates the contingency/scope adjustment action defined in Review 1.4.C (increase contingency to 20% or pivot geometry).


**STOP RULE:** Technical contingency buffer is reduced to less than €50,000 due to geotechnical overruns.

---

#### FM2 - The Administrative Freeze: Regulatory Stagnation Traps Mobilized Crews

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A3
- **Owner**: Regulatory & Stakeholder Navigator
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project mobilizes on schedule (ASAP start) by securing easements and training supervisors, but the sequential regulatory strategy fails to secure municipal paving sign-off following the initial environmental approval (KVI). KVI approves the EIA but Municipal Engineering requires an additional 6 weeks for its secondary review, directly contradicting the 14-day commitment sought. Contractors, mobilized under the strict 10-week earthworks window, are forced into standby. The €10,000-$15,000/week standby cost rapidly burns through the remaining contingency, forcing a halt in material ordering for the specialized secondary pavement reinforcement system (Risk 4), leaving the project structurally incomplete and financially insolvent.

##### Early Warning Signs
- The Regulatory Navigator reports that the Municipal Engineering Department has not acknowledged receipt of the 'shadow submissions' within 10 days of the EIA submission.
- The time elapsed between KVI Environmental Sign-off and Municipal Design Approval exceeds 21 calendar days (Regulatory Review 1.6).
- The Project Director authorizes standby payments to the primary earthworks contractor for 10 consecutive business days.

##### Tripwires
- Total regulatory elapsed time breaches 35 days before paving permit issuance.
- Standby costs accumulate to exceed €50,000.
- Municipal Engineering review cycle exceeds 21 days.

##### Response Playbook
- Contain: Immediately halt all non-essential contractor mobilization and place earthworks crews on minimum-skeleton crew standby contracts only to minimize drain.
- Assess: Regulatory Navigator must produce a detailed, party-by-party RACI chart showing the exact bottlenecking authority and the associated contractual penalty exposure for idle time.
- Respond: The Project Director personally intervenes with the Municipal Engineering Head, threatening formal escalation to the next highest regional authority (per Review 1.1.C), authorized by the prepared political buffer communication.


**STOP RULE:** Total schedule delay caused by regulatory sequencing exceeds 6 calendar weeks, exceeding the conservative earthworks buffer.

---

#### FM3 - The Sub-Par Foundation: Local Skill Gap Undermines Dual-Lane Readiness

- **Archetype**: Market/Human
- **Root Cause**: Assumption A2
- **Owner**: Construction & Pavement Quality Assurance Lead (Site Engineer)
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The Pragmatic Optimization strategy mandated contracting with local Hungarian firms (Decision 6) while simultaneously relying on their ability to meet the structural demands of a 'dual-lane ready' geometry without definitive geotechnical validation. The independent competency audit (Assumption A2 test) fails catastrophically, revealing that while subcontractors are competitive on price, their base compaction techniques are only suitable for single-lane standards (Risk 2.5). When the Site Engineer rejects the first major segment of the subgrade, the contractors refuse the mandated rework, citing contractual ambiguity around the 'dual-lane readiness' standard. This escalates into a legal dispute (Risk 5), leading to a complete mobilization withdrawal by the primary contractor, effectively stopping the project while the technical specifications are re-litigated.

##### Early Warning Signs
- The pre-mobilization subcontractor audit reveals a quality score below 75% against the CBR requirements.
- Site Engineer rejects the first 200m of subgrade preparation, citing density variances beyond 5% tolerance.
- The primary Hungarian subcontractor issues a formal notice of dispute regarding the definition of 'dual-lane readiness' in the contract specification.

##### Tripwires
- Subcontractor rework/rejection costs exceed €40,000.
- Rework cycle adds 15 calendar days to the earthworks schedule timeline.
- Site Engineer requires Director sign-off for material rejection more than 3 times in one week.

##### Response Playbook
- Contain: Immediately halt payment processing to the disputing subcontractor and issue a formal notice of cure period invocation, freezing all access to site equipment.
- Assess: The Civil Engineering Contracts Specialist initiates a rapid review of the contract language defining 'dual-lane readiness' vs. the base specification, while the Project Director begins vetting the secondary (international) contractor pool as a backup option.
- Respond: If the cure is not met within 7 days, the Director formally terminates the primary contract portion and initiates the retainer activation for the secondary reinforcement system contractor (Decision 81f06e88) to bridge the execution gap.


**STOP RULE:** The primary Hungarian earthworks contractor formally files a liability claim against the project due to specification dispute or withdraws from site for more than 14 continuous days.

---

#### FM4 - The Contingency Collapse: Sinking into the Subgrade Abyss

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Project Director & Lead Strategist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Failure occurs during initial bulk earthworks (Week 4-6). The limited geotechnical scope (relying only on anomalous zones) misses a significant deposit of untreated alluvial soft soil across the primary line of travel. This requires immediate deep soil mixing/grouting, estimated at €180,000. The initial budget allocated only €130,000 for land acquisition, leaving only €195,000 in technical contingency. The €180,000 remediation cost depletes the buffer down to €15,000, rendering the project un-insurable for subsequent, minor issues. The Financial Controller flags that the ECF model was fatally optimistic, leading to an immediate halt in all procurement of specialized paving materials.

##### Early Warning Signs
- ECF model validation (Data Item 2) returns a value >= €150,000.
- Initial excavation encounters soil resistivity/density measurements 40% below the minimum acceptable threshold for 5 consecutive meters.
- The Project Director authorizes the first draw from the technical contingency fund exceeding €20,000 before base layer preparation begins.

##### Tripwires
- Technical Contingency Drawdown >= 50% (€97,500) before paving course is sampled.
- Geotechnical Risk Manager refuses to sign off on subgrade preparation for 3 consecutive days.
- Required stabilization cost estimate exceeds €150,000.

##### Response Playbook
- Contain: Immediately issue a Stop Work Order affecting all earthworks and mandate exclusion zones around the affected area to prevent spread or contamination.
- Assess: The Geotechnical Risk Manager must produce a full, verified ECF for remediation of the affected area within 48 hours, and the Financial Controller must confirm the exact remaining contingency balance.
- Respond: If ECF exceeds remaining contingency, the Project Director immediately notifies financial stakeholders and initiates the contingency/scope adjustment action defined in Review 1.4.C (increase contingency to 20% or pivot geometry).


**STOP RULE:** Technical contingency buffer is reduced to less than €50,000 due to geotechnical overruns.

---

#### FM5 - The Administrative Freeze: Regulatory Stagnation Traps Mobilized Crews

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A3
- **Owner**: Regulatory & Stakeholder Navigator
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project mobilizes on schedule (ASAP start) by securing easements and training supervisors, but the sequential regulatory strategy fails to secure municipal paving sign-off following the initial environmental approval (KVI). KVI approves the EIA but Municipal Engineering requires an additional 6 weeks for its secondary review, directly contradicting the 14-day commitment sought. Contractors, mobilized under the strict 10-week earthworks window, are forced into standby. The €10,000-$15,000/week standby cost rapidly burns through the remaining contingency, forcing a halt in material ordering for the specialized secondary pavement reinforcement system (Risk 4), leaving the project structurally incomplete and financially insolvent.

##### Early Warning Signs
- The Regulatory Navigator reports that the Municipal Engineering Department has not acknowledged receipt of the 'shadow submissions' within 10 days of the EIA submission.
- The time elapsed between KVI Environmental Sign-off and Municipal Design Approval exceeds 21 calendar days (Regulatory Review 1.6).
- The Project Director authorizes standby payments to the primary earthworks contractor for 10 consecutive business days.

##### Tripwires
- Total regulatory elapsed time breaches 35 days before paving permit issuance.
- Standby costs accumulate to exceed €50,000.
- Municipal Engineering review cycle exceeds 21 days.

##### Response Playbook
- Contain: Immediately halt all non-essential contractor mobilization and place earthworks crews on minimum-skeleton crew standby contracts only to minimize drain.
- Assess: Regulatory Navigator must produce a detailed, party-by-party RACI chart showing the exact bottlenecking authority and the associated contractual penalty exposure for idle time.
- Respond: The Project Director personally intervenes with the Municipal Engineering Head, threatening formal escalation to the next highest regional authority (per Review 1.1.C), authorized by the prepared political buffer communication.


**STOP RULE:** Total schedule delay caused by regulatory sequencing exceeds 6 calendar weeks, exceeding the conservative earthworks buffer.

---

#### FM6 - The Sub-Par Foundation: Local Skill Gap Undermines Dual-Lane Readiness

- **Archetype**: Market/Human
- **Root Cause**: Assumption A2
- **Owner**: Construction & Pavement Quality Assurance Lead (Site Engineer)
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The Pragmatic Optimization strategy mandated contracting with local Hungarian firms (Decision 6) while simultaneously relying on their ability to meet the structural demands of a 'dual-lane ready' geometry without definitive geotechnical validation. The independent competency audit (Assumption A2 test) fails catastrophically, revealing that while subcontractors are competitive on price, their base compaction techniques are only suitable for single-lane standards (Risk 2.5). When the Site Engineer rejects the first major segment of the subgrade, the contractors refuse the mandated rework, citing contractual ambiguity around the 'dual-lane readiness' standard. This escalates into a legal dispute (Risk 5), leading to a complete mobilization withdrawal by the primary contractor, effectively stopping the project while the technical specifications are re-litigated.

##### Early Warning Signs
- The pre-mobilization subcontractor audit reveals a quality score below 75% against the CBR requirements.
- Site Engineer rejects the first 200m of subgrade preparation, citing density variances beyond 5% tolerance.
- Primary Hungarian subcontractor issues a formal notice of dispute regarding the definition of 'dual-lane readiness' in the contract specification.

##### Tripwires
- Subcontractor rework/rejection costs exceed €40,000.
- Rework cycle adds 15 calendar days to the earthworks schedule timeline.
- Site Engineer requires Director sign-off for material rejection more than 3 times in one week.

##### Response Playbook
- Contain: Immediately halt payment processing to the disputing subcontractor and issue a formal notice of cure period invocation, freezing all access to site equipment.
- Assess: The Civil Engineering Contracts Specialist initiates a rapid review of the contract language defining 'dual-lane readiness' vs. the base specification, while the Project Director begins vetting the secondary (international) contractor pool as a backup option.
- Respond: If the cure is not met within 7 days, the Director formally terminates the primary contract portion and initiates the retainer activation for the secondary reinforcement system contractor (Decision 81f06e88) to bridge the execution gap.


**STOP RULE:** The primary Hungarian earthworks contractor formally files a liability claim against the project due to specification dispute or withdraws from site for more than 14 continuous days.

---

#### FM7 - The Contingency Collapse: Sinking into the Subgrade Abyss

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Project Director & Lead Strategist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Failure occurs during initial bulk earthworks (Week 4-6). The limited geotechnical scope (relying only on anomalous zones) misses a significant deposit of untreated alluvial soft soil across the primary line of travel. This requires immediate deep soil mixing/grouting, estimated at €180,000. The initial budget allocated only €130,000 for land acquisition, leaving only €195,000 in technical contingency. The €180,000 remediation cost depletes the buffer down to €15,000, rendering the project un-insurable for subsequent, minor issues. The Financial Controller flags that the ECF model was fatally optimistic, leading to an immediate halt in all procurement of specialized paving materials.

##### Early Warning Signs
- ECF model validation (Data Item 2) returns a value >= €150,000.
- Initial excavation encounters soil resistivity/density measurements 40% below the minimum acceptable threshold for 5 consecutive meters.
- The Project Director authorizes the first draw from the technical contingency fund exceeding €20,000 before base layer preparation begins.

##### Tripwires
- Technical Contingency Drawdown >= 50% (€97,500) before paving course is sampled.
- Geotechnical Risk Manager refuses to sign off on subgrade preparation for 3 consecutive days.
- Required stabilization cost estimate exceeds €150,000.

##### Response Playbook
- Contain: Immediately issue a Stop Work Order affecting all earthworks and mandate exclusion zones around the affected area to prevent spread or contamination.
- Assess: The Geotechnical Risk Manager must produce a full, verified ECF for remediation of the affected area within 48 hours, and the Financial Controller must confirm the exact remaining contingency balance.
- Respond: If ECF exceeds remaining contingency, the Project Director immediately notifies financial stakeholders and initiates the contingency/scope adjustment action defined in Review 1.4.C (increase contingency to 20% or pivot geometry).


**STOP RULE:** Technical contingency buffer is reduced to less than €50,000 due to geotechnical overruns.

---

#### FM8 - The Administrative Freeze: Regulatory Stagnation Traps Mobilized Crews

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A3
- **Owner**: Regulatory & Stakeholder Navigator
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project mobilizes on schedule (ASAP start) by securing easements and training supervisors, but the sequential regulatory strategy fails to secure municipal paving sign-off following the initial environmental approval (KVI). KVI approves the EIA but Municipal Engineering requires an additional 6 weeks for its secondary review, directly contradicting the 14-day commitment sought. Contractors, mobilized under the strict 10-week earthworks window, are forced into standby. The €10,000-$15,000/week standby cost rapidly burns through the remaining contingency, forcing a halt in material ordering for the specialized secondary pavement reinforcement system (Risk 4), leaving the project structurally incomplete and financially insolvent.

##### Early Warning Signs
- The Regulatory Navigator reports that the Municipal Engineering Department has not acknowledged receipt of the 'shadow submissions' within 10 days of the EIA submission.
- The time elapsed between KVI Environmental Sign-off and Municipal Design Approval exceeds 21 calendar days (Regulatory Review 1.6).
- The Project Director authorizes standby payments to the primary earthworks contractor for 10 consecutive business days.

##### Tripwires
- Total regulatory elapsed time breaches 35 days before paving permit issuance.
- Standby costs accumulate to exceed €50,000.
- Municipal Engineering review cycle exceeds 21 days.

##### Response Playbook
- Contain: Immediately halt all non-essential contractor mobilization and place earthworks crews on minimum-skeleton crew standby contracts only to minimize drain.
- Assess: Regulatory Navigator must produce a detailed, party-by-party RACI chart showing the exact bottlenecking authority and the associated contractual penalty exposure for idle time.
- Respond: The Project Director personally intervenes with the Municipal Engineering Head, threatening formal escalation to the next highest regional authority (per Review 1.1.C), authorized by the prepared political buffer communication.


**STOP RULE:** Total schedule delay caused by regulatory sequencing exceeds 6 calendar weeks, exceeding the conservative earthworks buffer.

---

#### FM9 - The Quality Cascade: Delegated Authority Breeds Specification Drift

- **Archetype**: Market/Human
- **Root Cause**: Assumption A5
- **Owner**: Construction & Pavement Quality Assurance Lead (Site Engineer)
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The Project Director delegated significant QA/QC authority to the Site Engineer to maintain schedule velocity (Risk 5 mitigation). However, the inherent tension between the basic materials (local aggregate) and the long-term resilience (dual-lane ready) proves too complex for the 2% waiver threshold. The Site Engineer, facing pressure to keep paving moving, uses the unilateral authority excessively on non-critical base lifts, leading to a cumulative 4% deviation in binder content across the foundation layers. This subtle drift is missed by the Project Director due to the delegation, resulting in premature rutting discovered during a post-commissioning visual inspection 6 months later. The failure is structural, but the root cause is governance ambiguity leading to loss of strategic oversight on quality.

##### Early Warning Signs
- Site Engineer approves 5 or more material deviations in a single 72-hour period.
- The PQA Pilot Program reports compaction density variance consistently above the 3% threshold for subgrade.
- The Financial Controller notes that the cost variance for material procurement is trending 2% below target (suggesting over-acceptance of off-spec product).

##### Tripwires
- Cumulative 3-shift material rejection rate exceeds 10% of total base course volume.
- The Project Director has to approve 3 separate material tolerance waivers (over 1.5%) in one week.
- The Site Engineer requests re-training or clarification on deviation thresholds more than once.

##### Response Playbook
- Contain: Issue an immediate site-wide 'Hold Point' for all asphalt placement until the Governance Matrix is formally re-ratified by the Project Director and Site Engineer.
- Assess: Contracts Specialist reviews all recent waiver documentation signed by the Site Engineer for consistency against the 2% tolerance rule, while the Pavement Design Engineer assesses the implied lifecycle impact of the accepted deviations.
- Respond: If deviations impact structural integrity, re-engage the subcontractor with a formal warning, back-charging rework costs against the contractual retention, contingent on the results of the lifecycle analysis.


**STOP RULE:** Any material deviation exceeding 2.5% (binder or gradation) is discovered by third-party testing on any load-bearing course.
