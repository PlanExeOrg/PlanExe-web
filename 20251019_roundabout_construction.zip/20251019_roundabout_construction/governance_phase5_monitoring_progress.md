### 1. Tracking Progression against Critical Decision Parameters (Pragmatic Optimization Strategy)
**Monitoring Tools/Platforms:**

  - Project Operating Committee (POC) Weekly Dashboard
  - Decision Matrix Tracking Log (tracking status of 5 primary decisions)

**Frequency:** Weekly

**Responsible Role:** Project Operating Committee (POC)

**Adaptation Process:** POC reviews deviation and immediately updates the relevant associated tracking log (e.g., updating the Easement Negotiation Status Log or the Pavement Option Selection Tracker). If deviation triggers a PSDB escalation threshold, the POC Chair initiates a formal report to the PSDB.

**Adaptation Trigger:** Any of the five primary 'Builder' strategic choices showing a critical path parameter deviation greater than 1 week (e.g., easement acquisition pending past target date, or material option decision delayed past required procurement lead time).

### 2. Geotechnical Risk Monitoring (Tracking Risk 2 Materialization)
**Monitoring Tools/Platforms:**

  - Technical Assurance Group (TAG) Bi-weekly Testing Report
  - Rapid Response Geotech Crew Standby Contract Status
  - Geotechnical Contingency Expenditure Tracker

**Frequency:** Bi-weekly (during earthworks); Monthly thereafter

**Responsible Role:** Technical Assurance Group (TAG)

**Adaptation Process:** If testing results indicate conditions requiring intervention beyond benign geology, TAG provides a unanimous recommendation for immediate mobilization of the Rapid Response Crew (guaranteed 72-hour deployment) and escalates the finding to the POC. The POC approves drawdown from the specialized geotechnical reserve if needed.

**Adaptation Trigger:** In-situ testing results flag soil cohesion or water table conditions that exceed the acceptable bounds defined for the 'limited investigation zone,' or if the Rapid Response Crew standby contract is utilized.

### 3. Regulatory Compliance and Timeline Assurance (Tracking Risk 3)
**Monitoring Tools/Platforms:**

  - KVI Service Level Agreement (SLA) Compliance Tracker (Monitoring 21-day response window)
  - Junior Project Coordinator Weekly Liaison Report

**Frequency:** Weekly

**Responsible Role:** Junior Project Coordinator (Reporting to POC)

**Adaptation Process:** If the KVI SLA is breached (day 22+ without response), the POC Chair immediately notifies the PSDB, who will then execute the external political escalation path defined in the Decision Escalation Matrix.

**Adaptation Trigger:** Written confirmation of no response from the County Basin Water Directorate (KVI) exceeding 21 calendar days past the formal submission date.

### 4. Financial Health and Contingency Protection (Tracking Budget and Risk 7)
**Monitoring Tools/Platforms:**

  - Monthly Budget Burn-Rate Report (EUR vs HUF expenditure breakdown)
  - HUF/EUR Forward Hedge Performance Statement
  - Contingency Usage Log (Segregated tracking for Land Acquisition vs. Geotechnical)

**Frequency:** Monthly

**Responsible Role:** Head of Finance (Reporting to PSDB)

**Adaptation Process:** If the aggregate contingency burn rate (excluding Land Acquisition ring-fence) exceeds 20% of the total allowable contingency within any given month, the Head of Finance issues an immediate Risk Watch alert to the PSDB, triggering a mandatory PSDB review of expenditure velocity.

**Adaptation Trigger:** Total remaining unallocated contingency falls consistently below 12% of the total project budget (€156,000), or if the currency hedging position shows a net loss exceeding €5,000 due to adverse HUF fluctuations.

### 5. QA/QC Execution Monitoring against Delegation (Tracking Risk 5)
**Monitoring Tools/Platforms:**

  - Site Engineer Daily QA/QC Sign-off Checklist (Must document adherence to dual-lane base requirements)
  - CERAG Subcontractor Certification Compliance Audit Log

**Frequency:** Daily (Site Engineer); Bimonthly (CERAG Audit)

**Responsible Role:** Site Engineer (Day-to-Day) & CERAG (Oversight)

**Adaptation Process:** If the Site Engineer's sign-off sheet shows more than three instances in one week of accepting material variances (>5% binder content) without explicit, written authorization from the POC (a breach of specification tolerance), CERAG initiates an immediate investigation and potential fund freeze.

**Adaptation Trigger:** Discovery of non-conforming material placement (e.g., base layer compaction below standard) that directly violates the scope defined by the TAG, or a confirmation from CERAG that a necessary subcontractor certification audit has failed.