**Purpose:** business

**Purpose Detailed:** Planning and execution of a large-scale civil engineering/infrastructure project with a fixed budget, falling under large-scale societal or governmental objectives (even if the location is currently remote).

**Topic:** Large-scale infrastructure construction (roundabout)