# Governance Audit


## Audit - Corruption Risks

- Bribes or facilitation payments to the Hungarian authorities (County Basin Water Directorate or Municipal Engineering Departments) to bypass standard sequential review, specifically attempting to expedite the 'ASAP' start date or gain approval for the restricted subsurface investigation scope.
- Kickbacks between the Project Director or Junior Project Coordinator and the local Hungarian construction subcontractors in exchange for awarding high-volume earthworks or paving contracts without rigorous competitive bidding, especially concerning the utilization of local, pre-purchased materials.
- Nepotism or conflicts of interest in awarding the specialized, high-upfront cost contracts, such as the contract for the 'high-level political liaison' or the retainer agreement for the rapid-response geotechnical crew, favoring politically connected but potentially unqualified Hungarian firms.
- Misuse of contingency funds specifically ring-fenced for Land Acquisition or Geotechnical Response to cover unauthorized 'premium cash offers' to landowners, potentially involving undocumented payments to local agents or officials.
- Trading of favors where the Project Director offers regulatory leniency concerning the 'Material Off-Specification Tolerance Threshold' (allowing lower-grade asphalt) in return for personal benefit or preferential treatment from the material suppliers.

## Audit - Misallocation Risks

- Misallocation of the Land Acquisition capital (up to 130,000 EUR) due to immediate buyout offers instead of utilizing temporary use easements, thereby depleting the essential 15% contingency buffer needed for unforeseen subsurface remediation.
- Double spending or inefficient allocation of the Geotechnical budget by paying the 5,000 EUR/month standby fee for rapid-response crews while simultaneously limiting investigation scope, potentially paying for emergency services that are never utilized because the standard work proceeds without incident, or paying for specialized crew mobilization when basic dewatering would suffice.
- Unauthorized use of construction materials: Utilizing specialized, high-specification asphalt intended for the wearing course (which is prioritized for quality) on non-critical sub-base layers, due to poor segregation of primary and secondary material specifications.
- Misreporting progress related to geometry: Declaring the structure 'dual-lane ready' prematurely by applying paint/rumble strips before the underlying subgrade stabilization has achieved required load-bearing capacity, leading to false financial drawdown prior to structural verification.
- Inefficient allocation of labor resources: Spending significant budget on international experts (Decision 6) when the strategy leans toward utilizing primarily local Hungarian contractors for bulk work, leading to unnecessary foreign wage drawdowns against the fixed budget.

## Audit - Procedures

- Quarterly financial audits of all EUR/HUF transactions, focusing specifically on verifying HUF expenditures against the 70% forward hedging contract coverage to detect unauthorized currency exposure or misuse of hedged funds.
- Post-mobilization audit (within 30 days of site start) to verify that the Land Acquisition budget expenditure does not exceed the 130,000 EUR hard cap identified for easements, confirming the minimum 15% contingency remains untouched.
- Periodic technical audits (at 50% earthworks completion and post-paving) to test the actual load-bearing capacity of the subgrade and base layers against the expectations set by the limited subsurface investigation, paying close attention to localized anomalies identified during initial aerial review.
- Contract compliance review on all high-expenditure packages (Land Acquisition, Rapid Response Crew retainer, and Liaison Services), ensuring procurement followed documented sole-sourcing justification or competitive analysis, especially concerning Decision 79c3a11d (Political Liaison).
- Compliance confirmation by the Site Engineer (post-delegation) verifying that all local subcontractors performing base layer work have completed the mandatory two-week specialized certification required for dual-lane readiness execution.

## Audit - Transparency Measures

- Publication of a quarterly 'Budget Status Report' detailing EUR spent vs. committed budget, explicitly showing the remaining contingency balance and the utilization breakdown for the ring-fenced Land Acquisition contingency fund (€100,000).
- Mandatory publication of the Minutes of all meetings held between the Junior Project Coordinator and the County Basin Water Directorate (KVI), detailing any delays beyond the 21-day SLA threshold and proposed mitigation actions.
- Establishment of a public-facing 'Material Sourcing Log' accessible online (though technical specifications protected), showing the source origin and specific certification status (Local Hungarian vs. Secondary Option) for all substantial aggregate and asphalt deliveries.
- Creation of a formal change request log requiring sign-off from the Project Director for any deviation impacting the planned dual-lane geometry or material tolerance thresholds, documented immediately upon decision.
- Public disclosure of the Governance Matrix assigning QA/QC authority to the Site Engineer, making clear the respective quality assurance responsibilities versus the Project Director’s regulatory oversight focus, ensuring accountability for Risk 5 mitigation.

# Internal Governance Bodies

### 1. Project Strategy and Direction Board (PSDB)

**Rationale for Inclusion:** Required for high-level mandate and approval of the critical strategic trade-offs identified (e.g., budget vs. geotechnical certainty, geometry vs. schedule/cost), ensuring alignment with the 1.3M EUR constraint and ASAP start commitment. It serves as the ultimate fiduciary and strategic risk decision-maker.

**Responsibilities:**

- Approve final Land Acquisition Strategy following recommendation from Operating Committee (especially deviation from the €130k acquisition cap).
- Review and approve any necessary reserve utilization from the 15% contingency (€195k minimum).
- Authorize invocation of significant change requests exceeding 5% of the single-phase budget (e.g., full pivot from dual-lane readiness).
- Provide final sign-off on the commencement of physical construction following regulatory approval milestones.
- Oversight liaison for funding governance and currency hedging strategy compliance.

**Initial Setup Actions:**

- Finalize and ratify the Terms of Reference (ToR), defining financial thresholds for escalation.
- Elect the Board Chair and confirm representation from the ultimate funding body.
- Approve the initial budget allocation structure, specifically validating the €100,000 ring-fenced Land Acquisition contingency.

**Membership:**

- Sponsor/Ultimate Authority (Chair)
- Head of Finance (Focal for Budget/Currency)
- Project Director (Executive Reporting Member)
- Independent External Infrastructure Advisor (Impartial Oversight)

**Decision Rights:** Decisions concerning budget contingency drawdowns in excess of €20,000, any requested schedule extensions beyond 2 weeks, and approval of Land Acquisition expenditure ceilings.

**Decision Mechanism:** Majority vote (51% of voting members). Tie-breaker: Chair's casting vote, unless the tie involves a financial risk exceeding €50,000, in which case the decision is deferred to the Head of Finance for immediate risk analysis before re-vote.

**Meeting Cadence:** Monthly, or immediately upon request if a risk breach exceeds High/High severity threshold.

**Typical Agenda Items:**

- Contingency Fund Status and Forecast Burn Rate
- Review of Critical Path Milestone Achievability
- Strategic Risk Profile Review (Focus on Geotechnical/Regulatory Blockers)
- Review of Land Acquisition Spend vs. Cap

**Escalation Path:** Issues of governance failure or unresolvable conflict regarding fiduciary duty are escalated directly to the organization's Executive Board/Audit Committee.
### 2. Project Operating Committee (POC)

**Rationale for Inclusion:** Serves as the core operational management body, responsible for executing the 'Pragmatic Optimization' strategy chosen. It bridges the gap between strategic objectives (set by the PSDB) and daily execution, managing the complex coordination between technical design choices and regulatory sequence.

**Responsibilities:**

- Manage and coordinate the output of the Technical Assurance Group and the Compliance/Liaison Lead.
- Approve operational expenditure variations below the strategic threshold (e.g., minor changes in local contractor sourcing).
- Monitor the 10-week earthworks schedule aggressively and determine Go/No-Go decision for mobilization.
- Oversee implementation of Risk 5 mitigation (QA delegation) and Risk 8 mitigation (Traffic Management/Liaison Interface).
- Manage application and utilization of the €5,000/month Rapid Response Standby Contract.

**Initial Setup Actions:**

- Define and document the governance matrix for Site Engineer QA delegation.
- Finalize retainer agreements for Rapid Response Geotech Crew and Political Liaison.
- Approve the initial JIT/phased procurement schedule for Option A/Option B materials.

**Membership:**

- Project Director (Chair)
- Site Engineer (Primary QA/QC Lead)
- Junior Project Coordinator (Regulatory & Liaison Lead)
- Lead Contract Manager (Procurement/Local Sourcing)

**Decision Rights:** Operational decisions, including material selection between pre-qualified Option A/B, awarding retainer contracts under €15,000, and managing day-to-day adherence to the phased regulatory submission schedule.

**Decision Mechanism:** Consensus required for all decisions impacting schedule contingency. If consensus fails, the Project Director makes the final call, which must be documented with dissenting opinions recorded for PSDB review.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of Site Engineer QA/QC adherence report (incorporating subcontractor certification status)
- Regulatory Status Update from Junior PC (KVI SLA status)
- Change Log Review (All variations below €20k threshold)
- Hazard Review: Status of Subsurface Investigation findings vs. planned scope limitations

**Escalation Path:** Unresolved schedule adherence issues threatening the 10-week earthworks target, or any unidentified regulatory delay exceeding 14 days past SLA, are immediately escalated to the Project Strategy and Direction Board (PSDB).
### 3. Technical Assurance Group (TAG)

**Rationale for Inclusion:** Crucial due to the high technical risks associated with limited geotechnical investigation (Risk 2) and the uncertainty surrounding foundational viability (Decision 7 and 13). This body provides independent technical verification, preventing the Site Engineer's day-to-day focus from compromising structural integrity.

**Responsibilities:**

- Audit the limited subsurface investigation results against expected anomaly zones.
- Verify the execution standards of the local subcontractors performing base stabilization (including pre-mobilization audit of certification).
- Provide technical recommendation on whether to proceed with Option A or Option B reinforcement systems based on in-situ testing.
- Validate the adequacy of the 70% decentralized drainage solution (Assumption 6) against soil permeability models.

**Initial Setup Actions:**

- Define the minimum structural performance metrics required for 'Dual-Lane Readiness'.
- Contract and onboard independent third-party auditors for subcontractor certification verification.
- Establish protocol for immediate mobilization of the Rapid Response Crew contingent upon TAG flagging a critical subsurface finding.

**Membership:**

- Independent Civil Engineer specializing in Hungarian Subsoils (Chair)
- Site Engineer (Operational Input)
- Representative from the Rapid Response Geotech Crew (Advisory)
- PSDB Technical Monitor (Non-voting observer)

**Decision Rights:** Authority to mandate an immediate, short-term stop-work order (up to 3 days) specifically on earthworks/base foundation activities if structural integrity testing fails initial pass criteria. Authority to recommend up to €10,000 from segregated geotechnical contingency for non-emergency focused testing.

**Decision Mechanism:** Unanimous agreement required for issuing a stop-work order. Recommendations are based on a documented technical risk assessment score, requiring 75% agreement among voting members.

**Meeting Cadence:** Bi-weekly during earthworks; Monthly post-paving foundation inspection phase.

**Typical Agenda Items:**

- Subsurface Anomaly Review and Testing Results
- Base Compaction Test Outputs vs. Design Load Targets
- Material Resilience Strategy (Option A/B choice justification)
- Drainage System Integrity Assessment

**Escalation Path:** Critical structural failure findings or disagreement that threatens to incur costs exceeding €20,000 is escalated immediately to the Project Strategy and Direction Board (PSDB).
### 4. Compliance, Ethics, and Regulatory Assurance Group (CERAG)

**Rationale for Inclusion:** Essential for direct oversight of corruption risks identified (bribery, kickbacks) and managing critical regulatory dependencies (KVI environmental sign-off). Assigning compliance oversight explicitly prevents the Project Director/Coordinator from conflating political liaison duties with strict adherence to MSZ standards and Hungarian law.

**Responsibilities:**

- Conduct quarterly financial audits focusing on EUR/HUF hedging and land acquisition compliance (€130k cap).
- Monitor the Junior Project Coordinator’s engagement metrics with the KVI (Risk 3) and publicly publish violation logs (>21 day delays).
- Provide assurance that procurement contracts (Liaison, Rapid Response) adhere to documented justification for sole-sourcing.
- Oversee compliance confirmation of local subcontractor training (Risk 5 mitigation validation).
- Act as the designated body for receiving and investigating whistleblower reports related to ethical breaches or material specification tolerance overrides.

**Initial Setup Actions:**

- Establish the direct reporting line from CERAG Chair to the PSDB Independent Advisor.
- Publish the Audit Procedures (Financial/Technical) required for the project.
- Finalize the secure channel for anonymous reporting.

**Membership:**

- Independent Compliance Officer/Internal Auditor (Chair)
- Legal Counsel (Hungary focus)
- External Fraud & Corruption Risk Specialist
- Project Director (Non-voting, for information sharing only)

**Decision Rights:** Authority to freeze funds allocated to any specific contract engagement (e.g., Liaison Services) pending an investigation, provided the freeze amount is below €15,000 and does not directly impact immediate life-safety works.

**Decision Mechanism:** Unanimous vote is required to elevate a compliance finding to the Project Strategy and Direction Board (PSDB) for mandatory financial review.

**Meeting Cadence:** Bimonthly, with mandatory publication of compliance findings 7 days after review.

**Typical Agenda Items:**

- Review of Budget Status Report (Contingency Usage Detail)
- KVI Sign-off SLA Adherence & Delay Analysis
- Subcontractor Certification Audit Status
- Review of Change Request Log for unauthorized specification slippage

**Escalation Path:** Confirmed findings of financial fraud, conflicts of interest, or willful deviation from mandated MSZ standards are escalated immediately to the organization's Executive Board/External Legal Authority for potential prosecution or external regulatory reporting.

# Governance Implementation Plan

### 1. Project Sponsor formally establishes the Project Strategy and Direction Board (PSDB) and appoints the Board Chair and Head of Finance representation.

**Responsible Body/Role:** Sponsor/Ultimate Authority

**Suggested Timeframe:** Project Week 1 (May 1)

**Key Outputs/Deliverables:**

- PSDB Mandate Letter
- Confirmation of Board Chair and Initial Voting Members List

**Dependencies:**

- Project Kickoff Complete
- Governance Structure Defined

### 2. PSDB Chair commissions drafting of the formal Terms of Reference (ToR) for the PSDB, defining financial thresholds (€20,000 operating decision rights, €50,000 tie-breaker limit) and primary risk escalation triggers.

**Responsible Body/Role:** PSDB Chair

**Suggested Timeframe:** Project Week 1 (May 1)

**Key Outputs/Deliverables:**

- Draft PSDB ToR v0.1

**Dependencies:**

- PSDB established

### 3. PSDB reviews and formally ratifies the PSDB ToR, and approves the initial budget allocation structure, including validation of the €100,000 ring-fenced Land Acquisition contingency.

**Responsible Body/Role:** Project Strategy and Direction Board (PSDB)

**Suggested Timeframe:** Project Week 2 (May 8)

**Key Outputs/Deliverables:**

- Approved PSDB ToR v1.0
- Initial Budget Allocation Sign-off Document

**Dependencies:**

- Draft PSDB ToR v0.1 available
- Initial Budget Structure defined in assumptions

### 4. Project Director commissions drafting of POC Charter, Governance Matrix (Risk 5 mitigation), and initial procurement specifications.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2 (May 8)

**Key Outputs/Deliverables:**

- Draft POC Charter v0.1
- Draft Governance Matrix (QA Delegation)
- Draft Retainer Specifications (Rapid Response, Liaison)

**Dependencies:**

- PSDB established
- Strategic Decisions Finalized (Pragmatic Optimization Path)

### 5. Project Director confirms appointment of Site Engineer, Junior Project Coordinator, and Lead Contract Manager (members of the POC).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3 (May 15)

**Key Outputs/Deliverables:**

- Confirmed POC Core Membership List

**Dependencies:**

- Draft POC Charter v0.1 available

### 6. POC holds its first meeting to approve its Charter, finalize the Governance Matrix (confirming Site Engineer QA authority), and formally task the JPC with initiating Land Easement negotiations (Decision 3f955aa3 strategy).

**Responsible Body/Role:** Project Operating Committee (POC)

**Suggested Timeframe:** Project Week 3 (May 15)

**Key Outputs/Deliverables:**

- Approved POC Charter
- Finalized QA Delegation Matrix
- Action: Initiate Land Easement Negotiations

**Dependencies:**

- Confirmed POC Core Membership List
- Confirmed Land Acquisition Strategy (Easements)

### 7. Legal Counsel/Compliance Officer commissions drafting of CERAG Charter, Audit Procedures, and ensures secure reporting channels are established.

**Responsible Body/Role:** Legal Counsel (Guided by Compliance Officer)

**Suggested Timeframe:** Project Week 4 (May 22)

**Key Outputs/Deliverables:**

- Draft CERAG Charter
- Initial Audit Procedure Outline

**Dependencies:**

- PSDB established (for oversight channel definition)

### 8. Project Director/Lead Contract Manager finalize and sign retainer agreements for Rapid Response Geotech Crew (€5,000/month standby) and Political Liaison/Consultancy.

**Responsible Body/Role:** Lead Contract Manager

**Suggested Timeframe:** Project Week 5 (May 29)

**Key Outputs/Deliverables:**

- Signed Rapid Response Contract
- Signed Political Liaison Contract

**Dependencies:**

- POC approval of operational expenditure variation
- Risk Mitigation 2 & 3 specific resource procurement initiated

### 9. Project Director commissions drafting of TAG Charter, defining technical validation metrics for 'Dual-Lane Readiness' and protocols for Option A/Option B material selection.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5 (May 29)

**Key Outputs/Deliverables:**

- Draft TAG Charter v0.1
- Draft Dual-Lane Readiness Specification

**Dependencies:**

- Intersection Geometry Decision finalization (Dual-Lane)

### 10. Independent Civil Engineer (Chair) is onboarded, reviews Draft TAG Charter, and begins third-party (subcontractor) pre-mobilization certification audit.

**Responsible Body/Role:** Independent Civil Engineer (TAG Chair)

**Suggested Timeframe:** Project Week 6 (Jun 5)

**Key Outputs/Deliverables:**

- TAG officially formed with Chair
- Initial Subcontractor Audit Plan

**Dependencies:**

- Draft TAG Charter v0.1
- Assumption 1: Local Contractor Validation needed

### 11. Junior Project Coordinator (JPC) submits the comprehensive 'over-the-top' environmental submission package to the County Basin Water Directorate (KVI), triggering the 21-day SLA (Risk 3).

**Responsible Body/Role:** Junior Project Coordinator

**Suggested Timeframe:** Project Week 6 (Jun 5)

**Key Outputs/Deliverables:**

- KVI Submission Receipt Confirmation
- SLA Clock Started (T=0 for Regulatory Delay)

**Dependencies:**

- Regulatory Authorization Pipeline Management Strategy (Phased Approval)
- Confirmation of Drainage Strategy (Assumption 4 alignment)

### 12. CERAG Chair confirms Audit Procedures and reports finalized Charter to PSDB for awareness, establishing the compliance monitoring baseline.

**Responsible Body/Role:** Compliance, Ethics, and Regulatory Assurance Group (CERAG)

**Suggested Timeframe:** Project Week 7 (Jun 12)

**Key Outputs/Deliverables:**

- Approved CERAG Charter & Audit Procedures
- PSDB Awareness Notification regarding compliance monitoring scope

**Dependencies:**

- Draft CERAG Charter approval

### 13. TAG holds its first meeting to finalize Dual-Lane Readiness metrics and issue the formal requirement list for subcontractor structural verification checks (focusing on base layer execution capability).

**Responsible Body/Role:** Technical Assurance Group (TAG)

**Suggested Timeframe:** Project Week 8 (Jun 19)

**Key Outputs/Deliverables:**

- Final Dual-Lane Readiness Specification v1.0
- Formal Subcontractor Verification Checklist issued to POC

**Dependencies:**

- TAG officially formed
- Approved POC/TAG interaction defined

### 14. POC reviews initial outputs: Subcontractor Audit findings and KVI SLA status. POC makes Go/No-Go decision for full mobilization pending required prerequisite permits (Road Traffic Permit & KVI Sign-off).

**Responsible Body/Role:** Project Operating Committee (POC)

**Suggested Timeframe:** Project Week 9 (Jun 26)

**Key Outputs/Deliverables:**

- Mobilization Go/No-Go Decision Record
- Contingency allocation recommendation if KVI breach imminent

**Dependencies:**

- KVI SLA progress update
- Initial Subcontractor Audit Report (from TAG)
- Land Acquisition 50% complete

### 15. If mobilization is 'Go', Project Director formally activates the Project Execution Phase, initiating the 10-week aggressive earthworks schedule and commencing the *Project Strategy and Direction Board (PSDB) Monthly Meeting Cadence*.

**Responsible Body/Role:** Project Director / PSDB Chair

**Suggested Timeframe:** Project Week 10 (Jul 3)

**Key Outputs/Deliverables:**

- Official Construction Start Notification
- First PSDB Monthly Operational Review Meeting Held

**Dependencies:**

- Mobilization Go/No-Go Decision approved
- KVI or equivalent primary regulatory approval secured

# Decision Escalation Matrix

**Proposed Land Acquisition Expenditure Exceeding 10% Cap**
Escalation Level: Project Strategy and Direction Board (PSDB)
Approval Process: Majority vote, with Head of Finance to provide immediate adverse risk analysis if required.
Rationale: Upfront capital commitment for land exceeds the pre-approved 130,000 EUR ceiling, directly threatening the minimum 15% operational contingency buffer.
Negative Consequences: Budget overrun, reduction in fiduciary protection against unforeseen geotechnical issues (Risk 2).

**Unforeseen Subsurface Conditions requiring mobilization of rapid-response crew (Rock/High Water Table)**
Escalation Level: Technical Assurance Group (TAG)
Approval Process: Unanimous agreement required to issue a short-term stop-work order; 75% agreement for technical recommendation to POC.
Rationale: High/High technical risk (Risk 2) materially materialized, demanding immediate, documented technical verification before the POC can deploy expensive, pre-contracted emergency resources.
Negative Consequences: Schedule delay leading to idle crew costs, potential need to utilize geotechnical contingency funds, and risk of structural failure if remediation is inappropriate.

**Regulatory Delay Exceeding 14 Days Past KVI Service Level Agreement (SLA)**
Escalation Level: Project Strategy and Direction Board (PSDB)
Approval Process: PSDB addresses governance failure; the Chair instructs the Project Director to escalate the issue to external political sponsors.
Rationale: Failure of the POC-managed Regulatory pipeline (Risk 3) signals a blockage requiring strategic intervention beyond the POC's operational scope to prevent critical path extension.
Negative Consequences: Cascading schedule delay pushing commissioning past target date, leading to financial penalties and reputational damage.

**Material Sourcing Conflict: Second Pavement Specification required before Initial Site Delivery**
Escalation Level: Project Operating Committee (POC)
Approval Process: Consensus required; if failed, Project Director has final call, documented for PSDB.
Rationale: A decision regarding which reinforcement system (Option A or B) must be locked in based on early testing, directly impacting the Lead Contract Manager's ability to procure resources under budget limits.
Negative Consequences: Failure to decide locks in the high-risk option or incurs 4-week paving gap due to material lead times (Risk 4).

**Reported Material Specification Override (Site Engineer accepting >5% binder content variance)**
Escalation Level: Compliance, Ethics, and Regulatory Assurance Group (CERAG)
Approval Process: CERAG investigates and, if confirmed, freezes contract funds below €15,000 pending PSDB review.
Rationale: This constitutes a willful deviation from mandated MSZ standards (Risk 5 mitigation failure) impacting asset longevity, triggering fiduciary/ethics review.
Negative Consequences: Premature structural failure (cracking/rutting), potential legal ramifications for non-compliance, and complete loss of asset service life expectations.

**Proposal to implement Full, Extended Road Closure for Construction (Decision d677b910 Strategy 1)**
Escalation Level: Project Strategy and Direction Board (PSDB)
Approval Process: PSDB vote required due to high community impact (Risk 8) and schedule compression trade-off.
Rationale: A full closure significantly alters the political risk profile and neighborhood acceptance, requiring executive sign-off on the community disruption versus the schedule benefit.
Negative Consequences: Severe community backlash leading to potential regulatory intervention or public opposition delaying the project further.

# Monitoring Progress

### 1. Tracking Progression against Critical Decision Parameters (Pragmatic Optimization Strategy)
**Monitoring Tools/Platforms:**

  - Project Operating Committee (POC) Weekly Dashboard
  - Decision Matrix Tracking Log (tracking status of 5 primary decisions)

**Frequency:** Weekly

**Responsible Role:** Project Operating Committee (POC)

**Adaptation Process:** POC reviews deviation and immediately updates the relevant associated tracking log (e.g., updating the Easement Negotiation Status Log or the Pavement Option Selection Tracker). If deviation triggers a PSDB escalation threshold, the POC Chair initiates a formal report to the PSDB.

**Adaptation Trigger:** Any of the five primary 'Builder' strategic choices showing a critical path parameter deviation greater than 1 week (e.g., easement acquisition pending past target date, or material option decision delayed past required procurement lead time).

### 2. Geotechnical Risk Monitoring (Tracking Risk 2 Materialization)
**Monitoring Tools/Platforms:**

  - Technical Assurance Group (TAG) Bi-weekly Testing Report
  - Rapid Response Geotech Crew Standby Contract Status
  - Geotechnical Contingency Expenditure Tracker

**Frequency:** Bi-weekly (during earthworks); Monthly thereafter

**Responsible Role:** Technical Assurance Group (TAG)

**Adaptation Process:** If testing results indicate conditions requiring intervention beyond benign geology, TAG provides a unanimous recommendation for immediate mobilization of the Rapid Response Crew (guaranteed 72-hour deployment) and escalates the finding to the POC. The POC approves drawdown from the specialized geotechnical reserve if needed.

**Adaptation Trigger:** In-situ testing results flag soil cohesion or water table conditions that exceed the acceptable bounds defined for the 'limited investigation zone,' or if the Rapid Response Crew standby contract is utilized.

### 3. Regulatory Compliance and Timeline Assurance (Tracking Risk 3)
**Monitoring Tools/Platforms:**

  - KVI Service Level Agreement (SLA) Compliance Tracker (Monitoring 21-day response window)
  - Junior Project Coordinator Weekly Liaison Report

**Frequency:** Weekly

**Responsible Role:** Junior Project Coordinator (Reporting to POC)

**Adaptation Process:** If the KVI SLA is breached (day 22+ without response), the POC Chair immediately notifies the PSDB, who will then execute the external political escalation path defined in the Decision Escalation Matrix.

**Adaptation Trigger:** Written confirmation of no response from the County Basin Water Directorate (KVI) exceeding 21 calendar days past the formal submission date.

### 4. Financial Health and Contingency Protection (Tracking Budget and Risk 7)
**Monitoring Tools/Platforms:**

  - Monthly Budget Burn-Rate Report (EUR vs HUF expenditure breakdown)
  - HUF/EUR Forward Hedge Performance Statement
  - Contingency Usage Log (Segregated tracking for Land Acquisition vs. Geotechnical)

**Frequency:** Monthly

**Responsible Role:** Head of Finance (Reporting to PSDB)

**Adaptation Process:** If the aggregate contingency burn rate (excluding Land Acquisition ring-fence) exceeds 20% of the total allowable contingency within any given month, the Head of Finance issues an immediate Risk Watch alert to the PSDB, triggering a mandatory PSDB review of expenditure velocity.

**Adaptation Trigger:** Total remaining unallocated contingency falls consistently below 12% of the total project budget (€156,000), or if the currency hedging position shows a net loss exceeding €5,000 due to adverse HUF fluctuations.

### 5. QA/QC Execution Monitoring against Delegation (Tracking Risk 5)
**Monitoring Tools/Platforms:**

  - Site Engineer Daily QA/QC Sign-off Checklist (Must document adherence to dual-lane base requirements)
  - CERAG Subcontractor Certification Compliance Audit Log

**Frequency:** Daily (Site Engineer); Bimonthly (CERAG Audit)

**Responsible Role:** Site Engineer (Day-to-Day) & CERAG (Oversight)

**Adaptation Process:** If the Site Engineer's sign-off sheet shows more than three instances in one week of accepting material variances (>5% binder content) without explicit, written authorization from the POC (a breach of specification tolerance), CERAG initiates an immediate investigation and potential fund freeze.

**Adaptation Trigger:** Discovery of non-conforming material placement (e.g., base layer compaction below standard) that directly violates the scope defined by the TAG, or a confirmation from CERAG that a necessary subcontractor certification audit has failed.

# Governance Extra

## Governance Validation Checks

1. Completeness Confirmation: All requested core governance components (Bodies, Implementation Plan, Escalation Matrix, Monitoring Plan) have been generated and are present.
2. Internal Consistency Check: The framework demonstrates strong alignment. The 'Pragmatic Optimization' strategy directly dictates the selected decisions in the project plan, and these decisions are managed by the defined governance bodies (PSDB, POC, TAG, CERAG). For example, Risk 2 (Geotechnical Uncertainty) appropriately escalates to TAG in the matrix and is monitored via TAG’s bi-weekly reports.
3. Potential Gaps / Areas for Enhancement (1): Clarity on Project Sponsor/Ultimate Authority Role: While the Sponsor sits as Chair of the PSDB, their day-to-day delegation authority to the Project Director or POC is not explicitly defined. Clarification is needed on what actions the Sponsor can legally mandate without a full PSDB vote.
4. Potential Gaps / Areas for Enhancement (2): Detailed Conflict of Interest Management Protocol: CERAG is assigned to investigate conflicts, but the *process* for an individual (like the Project Director) declaring a potential conflict (e.g., concerning the Political Liaison contract) is missing. A mandatory declaration frequency and process should be documented.
5. Potential Gaps / Areas for Enhancement (3): Granularity of Delegation for Site Engineer: The governance matrix delegates QA/QC to the Site Engineer (Risk 5 mitigation), but the *limits* of their material acceptance authority relative to the POC/TAG decisions needs stricter definition. Specifically, the threshold for requiring POC override before accepting material variance must be quantified (e.g., Site Engineer decision limit is <2% variance; >2% requires POC review).
6. Potential Gaps / Areas for Enhancement (4): Change Control Process Integration: A formal, project-wide Change Request (CR) process is implied by the monitoring plan (Change Request Log), but the mechanism for *initiating* a CR (beyond the Director/POC level) and the required documentation standard for CR submission are not detailed.
7. Potential Gaps / Areas for Enhancement (5): Integration of Currency Hedging Oversight: While Head of Finance monitors the hedge performance monthly, the PSDB's *action* if the hedge performs poorly (Risk 7) is not clearly mapped in the escalation matrix, limiting the PSDB's ability to respond proactively to currency-driven reserve erosion.

## Tough Questions

1. What is the current status (Day Count) against the County Basin Water Directorate (KVI) 21-day SLA, and specifically, which external political sponsors has the PSDB Chair engaged to mitigate the delay risk?
2. Provide documentary evidence that the Site Engineer has been fully certified and has executed the mandatory initial review/sign-off for the two most critical local pavement subcontractors, as required by TAG/Assumption 1?
3. If the Land Acquisition expenditure cap of €130,000 is breached next month, what is the immediate, pre-agreed contingency reduction plan established by the Head of Finance for the geotechnical reserve (€5,000/month standby fund)?
4. Detail the performance metrics used by the Junior Project Coordinator to validate the 'effectiveness' of the dual-lane geometry strategy, given that physical testing cannot occur until later phases?
5. During the current reporting period, has the Project Director or any POC member declared a Conflict of Interest related to the selection or continued engagement of the Political Liaison consultant, and if so, how was this conflict managed via CERAG?
6. What is the documented justification for utilizing the 30% unmanaged runoff allowance (resulting from Assumption 6/Drainage Strategy), and what is the TAG’s quantified confidence level that this deficit will not precipitate a settlement risk rise in Location 3?
7. Show the exact calculation for the current buffer remaining in the unallocated contingency fund following any usage this month, cross-referenced against the 12% trigger threshold for an automatic PSDB review alert.

## Summary

The project governance framework is strategically sound, correctly prioritizing the management of geotechnical uncertainty (Risk 2) and regulatory timelines (Risk 3) through the implementation of specialized assurance bodies (TAG, CERAG). The selected 'Pragmatic Optimization' path is well-embedded across the decision framework. Key strengths lie in the clear segregation of duties between operational management (POC) and strategic oversight (PSDB), and proactive measures taken against corruption. However, significant refinement is required in explicitly defining the scope and limits of delegated operational authority (Site Engineer QA/QC), formalizing conflict of interest declaration procedures, and clarifying the intervention steps for the PSDB when financial hedges fail.