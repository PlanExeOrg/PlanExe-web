### 1. Project Sponsor formally establishes the Project Strategy and Direction Board (PSDB) and appoints the Board Chair and Head of Finance representation.

**Responsible Body/Role:** Sponsor/Ultimate Authority

**Suggested Timeframe:** Project Week 1 (May 1)

**Key Outputs/Deliverables:**

- PSDB Mandate Letter
- Confirmation of Board Chair and Initial Voting Members List

**Dependencies:**

- Project Kickoff Complete
- Governance Structure Defined

### 2. PSDB Chair commissions drafting of the formal Terms of Reference (ToR) for the PSDB, defining financial thresholds (€20,000 operating decision rights, €50,000 tie-breaker limit) and primary risk escalation triggers.

**Responsible Body/Role:** PSDB Chair

**Suggested Timeframe:** Project Week 1 (May 1)

**Key Outputs/Deliverables:**

- Draft PSDB ToR v0.1

**Dependencies:**

- PSDB established

### 3. PSDB reviews and formally ratifies the PSDB ToR, and approves the initial budget allocation structure, including validation of the €100,000 ring-fenced Land Acquisition contingency.

**Responsible Body/Role:** Project Strategy and Direction Board (PSDB)

**Suggested Timeframe:** Project Week 2 (May 8)

**Key Outputs/Deliverables:**

- Approved PSDB ToR v1.0
- Initial Budget Allocation Sign-off Document

**Dependencies:**

- Draft PSDB ToR v0.1 available
- Initial Budget Structure defined in assumptions

### 4. Project Director commissions drafting of POC Charter, Governance Matrix (Risk 5 mitigation), and initial procurement specifications.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2 (May 8)

**Key Outputs/Deliverables:**

- Draft POC Charter v0.1
- Draft Governance Matrix (QA Delegation)
- Draft Retainer Specifications (Rapid Response, Liaison)

**Dependencies:**

- PSDB established
- Strategic Decisions Finalized (Pragmatic Optimization Path)

### 5. Project Director confirms appointment of Site Engineer, Junior Project Coordinator, and Lead Contract Manager (members of the POC).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3 (May 15)

**Key Outputs/Deliverables:**

- Confirmed POC Core Membership List

**Dependencies:**

- Draft POC Charter v0.1 available

### 6. POC holds its first meeting to approve its Charter, finalize the Governance Matrix (confirming Site Engineer QA authority), and formally task the JPC with initiating Land Easement negotiations (Decision 3f955aa3 strategy).

**Responsible Body/Role:** Project Operating Committee (POC)

**Suggested Timeframe:** Project Week 3 (May 15)

**Key Outputs/Deliverables:**

- Approved POC Charter
- Finalized QA Delegation Matrix
- Action: Initiate Land Easement Negotiations

**Dependencies:**

- Confirmed POC Core Membership List
- Confirmed Land Acquisition Strategy (Easements)

### 7. Legal Counsel/Compliance Officer commissions drafting of CERAG Charter, Audit Procedures, and ensures secure reporting channels are established.

**Responsible Body/Role:** Legal Counsel (Guided by Compliance Officer)

**Suggested Timeframe:** Project Week 4 (May 22)

**Key Outputs/Deliverables:**

- Draft CERAG Charter
- Initial Audit Procedure Outline

**Dependencies:**

- PSDB established (for oversight channel definition)

### 8. Project Director/Lead Contract Manager finalize and sign retainer agreements for Rapid Response Geotech Crew (€5,000/month standby) and Political Liaison/Consultancy.

**Responsible Body/Role:** Lead Contract Manager

**Suggested Timeframe:** Project Week 5 (May 29)

**Key Outputs/Deliverables:**

- Signed Rapid Response Contract
- Signed Political Liaison Contract

**Dependencies:**

- POC approval of operational expenditure variation
- Risk Mitigation 2 & 3 specific resource procurement initiated

### 9. Project Director commissions drafting of TAG Charter, defining technical validation metrics for 'Dual-Lane Readiness' and protocols for Option A/Option B material selection.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5 (May 29)

**Key Outputs/Deliverables:**

- Draft TAG Charter v0.1
- Draft Dual-Lane Readiness Specification

**Dependencies:**

- Intersection Geometry Decision finalization (Dual-Lane)

### 10. Independent Civil Engineer (Chair) is onboarded, reviews Draft TAG Charter, and begins third-party (subcontractor) pre-mobilization certification audit.

**Responsible Body/Role:** Independent Civil Engineer (TAG Chair)

**Suggested Timeframe:** Project Week 6 (Jun 5)

**Key Outputs/Deliverables:**

- TAG officially formed with Chair
- Initial Subcontractor Audit Plan

**Dependencies:**

- Draft TAG Charter v0.1
- Assumption 1: Local Contractor Validation needed

### 11. Junior Project Coordinator (JPC) submits the comprehensive 'over-the-top' environmental submission package to the County Basin Water Directorate (KVI), triggering the 21-day SLA (Risk 3).

**Responsible Body/Role:** Junior Project Coordinator

**Suggested Timeframe:** Project Week 6 (Jun 5)

**Key Outputs/Deliverables:**

- KVI Submission Receipt Confirmation
- SLA Clock Started (T=0 for Regulatory Delay)

**Dependencies:**

- Regulatory Authorization Pipeline Management Strategy (Phased Approval)
- Confirmation of Drainage Strategy (Assumption 4 alignment)

### 12. CERAG Chair confirms Audit Procedures and reports finalized Charter to PSDB for awareness, establishing the compliance monitoring baseline.

**Responsible Body/Role:** Compliance, Ethics, and Regulatory Assurance Group (CERAG)

**Suggested Timeframe:** Project Week 7 (Jun 12)

**Key Outputs/Deliverables:**

- Approved CERAG Charter & Audit Procedures
- PSDB Awareness Notification regarding compliance monitoring scope

**Dependencies:**

- Draft CERAG Charter approval

### 13. TAG holds its first meeting to finalize Dual-Lane Readiness metrics and issue the formal requirement list for subcontractor structural verification checks (focusing on base layer execution capability).

**Responsible Body/Role:** Technical Assurance Group (TAG)

**Suggested Timeframe:** Project Week 8 (Jun 19)

**Key Outputs/Deliverables:**

- Final Dual-Lane Readiness Specification v1.0
- Formal Subcontractor Verification Checklist issued to POC

**Dependencies:**

- TAG officially formed
- Approved POC/TAG interaction defined

### 14. POC reviews initial outputs: Subcontractor Audit findings and KVI SLA status. POC makes Go/No-Go decision for full mobilization pending required prerequisite permits (Road Traffic Permit & KVI Sign-off).

**Responsible Body/Role:** Project Operating Committee (POC)

**Suggested Timeframe:** Project Week 9 (Jun 26)

**Key Outputs/Deliverables:**

- Mobilization Go/No-Go Decision Record
- Contingency allocation recommendation if KVI breach imminent

**Dependencies:**

- KVI SLA progress update
- Initial Subcontractor Audit Report (from TAG)
- Land Acquisition 50% complete

### 15. If mobilization is 'Go', Project Director formally activates the Project Execution Phase, initiating the 10-week aggressive earthworks schedule and commencing the *Project Strategy and Direction Board (PSDB) Monthly Meeting Cadence*.

**Responsible Body/Role:** Project Director / PSDB Chair

**Suggested Timeframe:** Project Week 10 (Jul 3)

**Key Outputs/Deliverables:**

- Official Construction Start Notification
- First PSDB Monthly Operational Review Meeting Held

**Dependencies:**

- Mobilization Go/No-Go Decision approved
- KVI or equivalent primary regulatory approval secured