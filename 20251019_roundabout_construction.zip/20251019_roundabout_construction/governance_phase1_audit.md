
## Audit - Corruption Risks

- Bribes or facilitation payments to the Hungarian authorities (County Basin Water Directorate or Municipal Engineering Departments) to bypass standard sequential review, specifically attempting to expedite the 'ASAP' start date or gain approval for the restricted subsurface investigation scope.
- Kickbacks between the Project Director or Junior Project Coordinator and the local Hungarian construction subcontractors in exchange for awarding high-volume earthworks or paving contracts without rigorous competitive bidding, especially concerning the utilization of local, pre-purchased materials.
- Nepotism or conflicts of interest in awarding the specialized, high-upfront cost contracts, such as the contract for the 'high-level political liaison' or the retainer agreement for the rapid-response geotechnical crew, favoring politically connected but potentially unqualified Hungarian firms.
- Misuse of contingency funds specifically ring-fenced for Land Acquisition or Geotechnical Response to cover unauthorized 'premium cash offers' to landowners, potentially involving undocumented payments to local agents or officials.
- Trading of favors where the Project Director offers regulatory leniency concerning the 'Material Off-Specification Tolerance Threshold' (allowing lower-grade asphalt) in return for personal benefit or preferential treatment from the material suppliers.

## Audit - Misallocation Risks

- Misallocation of the Land Acquisition capital (up to 130,000 EUR) due to immediate buyout offers instead of utilizing temporary use easements, thereby depleting the essential 15% contingency buffer needed for unforeseen subsurface remediation.
- Double spending or inefficient allocation of the Geotechnical budget by paying the 5,000 EUR/month standby fee for rapid-response crews while simultaneously limiting investigation scope, potentially paying for emergency services that are never utilized because the standard work proceeds without incident, or paying for specialized crew mobilization when basic dewatering would suffice.
- Unauthorized use of construction materials: Utilizing specialized, high-specification asphalt intended for the wearing course (which is prioritized for quality) on non-critical sub-base layers, due to poor segregation of primary and secondary material specifications.
- Misreporting progress related to geometry: Declaring the structure 'dual-lane ready' prematurely by applying paint/rumble strips before the underlying subgrade stabilization has achieved required load-bearing capacity, leading to false financial drawdown prior to structural verification.
- Inefficient allocation of labor resources: Spending significant budget on international experts (Decision 6) when the strategy leans toward utilizing primarily local Hungarian contractors for bulk work, leading to unnecessary foreign wage drawdowns against the fixed budget.

## Audit - Procedures

- Quarterly financial audits of all EUR/HUF transactions, focusing specifically on verifying HUF expenditures against the 70% forward hedging contract coverage to detect unauthorized currency exposure or misuse of hedged funds.
- Post-mobilization audit (within 30 days of site start) to verify that the Land Acquisition budget expenditure does not exceed the 130,000 EUR hard cap identified for easements, confirming the minimum 15% contingency remains untouched.
- Periodic technical audits (at 50% earthworks completion and post-paving) to test the actual load-bearing capacity of the subgrade and base layers against the expectations set by the limited subsurface investigation, paying close attention to localized anomalies identified during initial aerial review.
- Contract compliance review on all high-expenditure packages (Land Acquisition, Rapid Response Crew retainer, and Liaison Services), ensuring procurement followed documented sole-sourcing justification or competitive analysis, especially concerning Decision 79c3a11d (Political Liaison).
- Compliance confirmation by the Site Engineer (post-delegation) verifying that all local subcontractors performing base layer work have completed the mandatory two-week specialized certification required for dual-lane readiness execution.

## Audit - Transparency Measures

- Publication of a quarterly 'Budget Status Report' detailing EUR spent vs. committed budget, explicitly showing the remaining contingency balance and the utilization breakdown for the ring-fenced Land Acquisition contingency fund (€100,000).
- Mandatory publication of the Minutes of all meetings held between the Junior Project Coordinator and the County Basin Water Directorate (KVI), detailing any delays beyond the 21-day SLA threshold and proposed mitigation actions.
- Establishment of a public-facing 'Material Sourcing Log' accessible online (though technical specifications protected), showing the source origin and specific certification status (Local Hungarian vs. Secondary Option) for all substantial aggregate and asphalt deliveries.
- Creation of a formal change request log requiring sign-off from the Project Director for any deviation impacting the planned dual-lane geometry or material tolerance thresholds, documented immediately upon decision.
- Public disclosure of the Governance Matrix assigning QA/QC authority to the Site Engineer, making clear the respective quality assurance responsibilities versus the Project Director’s regulatory oversight focus, ensuring accountability for Risk 5 mitigation.