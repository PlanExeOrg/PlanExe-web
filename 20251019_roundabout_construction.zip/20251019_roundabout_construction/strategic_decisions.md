## Primary Decisions
The vital few decisions that have the most impact.


The primary strategic tension identified for this infrastructure project revolves around **Geotechnical Certainty vs. Schedule Acceleration** and **Upfront Capital Preservation vs. Asset Life Expectancy**. The five 'Critical' and 'High' levers—Land Acquisition, Investigation Scope Limitation, Geometry, Subgrade Protocol, and Material Tolerance—collectively control the foundational risk profile: securing the land, understanding what lies beneath it, and deciding how resilient the resulting structure must be to meet the fixed budget.

### Decision 1: Land Acquisition Strategy for Right-of-Way
**Lever ID:** `3f955aa3-edd7-4434-a3bd-56f097a1960c`

**The Core Decision:** This lever determines the legal and financial pathway for securing the necessary ground footprint for construction. Success hinges on balancing speed and cost: premium cash offers achieve rapid site stabilization but deplete the budget contingency, while eminent domain risks significant delays. Key metrics involve time-to-possession and immediate cash outlay vs. total acquisition cost.

**Why It Matters:** Securing the necessary land footprint through eminent domain proceedings will introduce significant regulatory friction and timeline delays, potentially exceeding the project start date buffer. Conversely, accelerating purchase agreements through immediate, premium cash offers stabilizes the site but consumes a substantial portion of the already taut 1.3 million EUR budget, reducing contingency for unexpected subsurface conditions.

**Strategic Choices:**

1. Pursue immediate, non-contingent freehold acquisition by offering above-market valuations to private landowners to bypass protracted negotiation phases.
2. Utilize temporary use easements for all non-structural land surrounding the critical roadway footprint to minimize initial capital outlay and only acquire necessary core parcels.
3. Initiate compulsory purchase order proceedings immediately, acknowledging the certainty of judicial review timelines which may delay site mobilization by several months.

**Trade-Off / Risk:** Relying on compulsory purchase immediately delays mobilization until judicial review resolves, yet paying premium cash reduces the contingency buffer necessary for unforeseen subsurface remediation costs.

**Strategic Connections:**

**Synergy:** Synergizes strongly with Subgrade Preparation and Stabilization Protocol by ensuring immediate access to the site, accelerating the start date for geotechnical work.

**Conflict:** Directly conflicts with Financing Drawdown Schedule Velocity due to the immediate, potentially large capital expenditure, and constrains Subsurface Investigation Scope Limitation if insufficient land is secured quickly.

**Justification:** *Critical*, This lever governs site access, a necessary precondition for any physical work. Its conflict text shows it forces a direct trade-off between budget contingency (premium cash) and schedule certainty (eminent domain delays), making it central to the project's core risk profile.

### Decision 2: Material Sourcing and Specification Resilience
**Lever ID:** `81f06e88-6908-4ad8-b306-9ccd388127f7`

**The Core Decision:** This strategy manages the risk associated with material supply chain integrity and quality for concrete, asphalt, and aggregate. Resilience is built by selecting stable local sources or pre-purchasing, mitigating volatility. Success is measured by minimizing material-related change orders and ensuring the final pavement structure meets load-bearing specifications within budget.

**Why It Matters:** Committing to high-grade, locally sourced Hungarian asphalt and aggregate locks in supply chains early, protecting against future European port congestion or import cost spikes, but this restricts options if initial geological surveys reveal unexpected subgrade instability requiring specialized deep-layer stabilization materials not locally available. Conversely, specifying readily available but lower-grade materials reduces immediate material cost but necessitates a deeper, more expensive sub-base layer to achieve required load-bearing capacity.

**Strategic Choices:**

1. Mandate 100% utilization of certified Hungarian-quarried aggregate and locally processed asphalt mixes to minimize cross-border logistics risk and customs delays.
2. Pre-purchase and stockpile critical high-volume materials (like base course aggregate) based on upfront projections, accepting storage costs to insulate against Q3 market volatility.
3. Design the pavement structure to accommodate two alternative base reinforcement systems, allowing on-site material testing to dictate the final, specification-compliant layering choice.

**Trade-Off / Risk:** Stockpiling materials hedges against market spikes but introduces site storage logistics and risk of contamination or degradation before placement, requiring material retesting later.

**Strategic Connections:**

**Synergy:** Amplifies Material Off-Specification Tolerance Threshold by establishing high baseline quality early, reducing the need to invoke costly waivers later in the process.

**Conflict:** Poses a trade-off against Pavement Structure Specification Alternative; specifying only local, high-grade materials limits flexibility if the subgrade requires a different, non-local stabilizing agent.

**Justification:** *High*, This lever manages material cost volatility against quality requirements. Its synergy with structure specification reveals it is key to balancing budget conservation (local sourcing) against potential structural compromises arising from subgrade variability.

### Decision 3: Regulatory Authorization Pipeline Management
**Lever ID:** `79c3a11d-0c97-4615-af46-47a83b6f40be`

**The Core Decision:** This operational lever focuses on navigating the governmental review process efficiently by managing submission sequencing and political engagement. The scope covers environmental, traffic, and municipal engineering approvals. Success is avoiding cascading delays by delivering information packages that satisfy diverse agency requirements in parallel or rapid sequence, crucial for meeting the ASAP start date.

**Why It Matters:** Submitting a comprehensive, 'over-the-top' package to Hungarian authorities, addressing all potential environmental and traffic impact concerns simultaneously, aims to forestall back-and-forth clarification requests that invariably stall permitting. However, this upfront documentation investment is high risk; if the initial assessment fundamentally misinterprets a specific regional environmental sensitivity, the entire package will require a complete, costly resubmission cycle.

**Strategic Choices:**

1. Adopt a phased inspection and approval protocol, securing environmental sign-off first, followed sequentially by traffic management approvals, accepting potential downstream idle time.
2. Engage a high-level political liaison immediately to concurrently navigate departmental approvals in parallel rather than relying on standardized sequential submission through primary channels.
3. Insist on pre-approval of the final design specifications directly with the lead municipal engineer prior to formal submission, minimizing bureaucratic review cycles.

**Trade-Off / Risk:** Using a high-level liaison speeds bureaucratic navigation, but this external influence may lead to compliance shortcuts requiring expensive remediation if the final physical build deviates from strict national standards.

**Strategic Connections:**

**Synergy:** Greatly enhances Local Authority Engagement Cadence by providing a structured, proactive framework for communication, ensuring all stakeholders receive necessary documentation simultaneously.

**Conflict:** Creates tension with Regulatory Authorization Pipeline Management, as high-level liaisons might inadvertently compromise strict adherence to Drainage and Runoff Management Architecture standards.

**Justification:** *High*, Essential for timeline success, this lever controls bureaucratic bottlenecks. Its synergy with 'Local Authority Engagement Cadence' confirms it is a hub for maintaining official alignment, directly impacting the project's ability to mobilize 'ASAP'.

### Decision 4: Intersection Geometry and Throughput Requirement
**Lever ID:** `4213f7c3-cc1c-4f68-9965-74bf30effc00`

**The Core Decision:** This foundational engineering choice dictates the physical dimensions and complexity of the roundabout layout. It directly impacts both initial site works (excavation, paving volume) and long-term functional viability. The critical trade-off is between minimizing immediate construction expenditure (smaller footprint) versus future-proofing against rapid traffic volume growth.

**Why It Matters:** Designing the roundabout to meet the highest projected future traffic flow standards (e.g., a tight, single-lane design for low volume) minimizes immediate earthworks and materials usage, preserving budget contingency for unforeseen base issues. However, this conservative geometric choice locks the structure into rapid obsolescence if regional economic development in Hungary accelerates traffic volume expectations beyond the initial forecast period, necessitating expensive future widening.

**Strategic Choices:**

1. Build a single-lane circulatory roadway with the smallest possible inscribed circle diameter compatible with immediate permitting requirements to minimize excavation and paving costs.
2. Design for a dual-lane configuration where the second lane is initially marked by paint and non-structural rumble strips, allowing for rapid, low-cost asphalt overlay conversion when needed.
3. Adopt a compact, modern 'turbo-roundabout' geometry which requires highly precise, complex earthworks initially but maximizes safety and capacity within the current fixed footprint.

**Trade-Off / Risk:** The turbo-roundabout offers peak utilization for the footprint but requires specialized surveying and paving equipment, increasing initial risk exposure compared to simpler designs.

**Strategic Connections:**

**Synergy:** Its geometry heavily influences the requirements for Subgrade Preparation and Stabilization Protocol, as more complex layouts may mandate different load distribution needs.

**Conflict:** A conservative, small geometry conflicts with ensuring the long-term viability addressed by Traffic Management During Construction Phase, as future widening will require disruptive modifications.

**Justification:** *Critical*, This is the core engineering decision, trading immediate cost/materials against long-term asset viability. Its influence on subgrade needs (synergy) and the need for future disruptive construction (conflict) establishes it as a foundational strategic choice.

### Decision 5: Subsurface Investigation Scope Limitation
**Lever ID:** `6dadee17-c062-470b-873b-fdee64d15dc4`

**The Core Decision:** This lever optimizes the project schedule by intentionally restricting the scope and depth of geotechnical surveys far below typical engineering standards. The primary goal is rapid site mobilization, trading detailed subsurface certainty for immediate ground-breaking capability. Success is measured by the time saved before first excavation, but this action directly elevates contingency usage risk later in the project when unexpected soil conditions require immediate, expensive remediation.

**Why It Matters:** Limiting the extent of geotechnical survey penetration beyond mandated minimal depths accelerates the initial site mobilization phase, removing a crucial early-stage gate dependency. However, this action transfers unknown geotechnical risk directly into the active construction schedule and budget, where unexpected voids or poor bearing capacity require costly, hard-to-source emergency remediation materials. The benefit is speed; the cost is immediate financial exposure once excavation begins.

**Strategic Choices:**

1. Proceed using only surface visual assessment and mandated minimal borehole data points, treating all deeper layers as textbook assumptions to expedite site validation and initial ground breaking.
2. Commission staged, high-density seismic profiling across the entire footprint prior to any earthworks, ensuring subsurface uncertainty is resolved at the design phase, albeit delaying mobilization by several weeks.
3. Restrict detailed subsurface testing exclusively to known anomalous zones flagged during initial aerial imagery review, accepting localized settlement risk in exchange for generalized rapid deployment.

**Trade-Off / Risk:** Restricting deep geotechnical surveys saves valuable weeks upstream, but it guarantees uncontrolled cost exposure during earthworks when encountering unexpected soft soils or high water tables requiring immediate deep stabilization.

**Strategic Connections:**

**Synergy:** Aggressively pursuing this lever synergizes with Financing Drawdown Schedule Velocity by accelerating the initial expenditure timeline, allowing earlier bulk payments for earthworks mobilization.

**Conflict:** This choice directly conflicts with Material Off-Specification Tolerance Threshold, as unexpected subsurface issues necessitate rapid, costly sourcing of high-tolerance stabilization or void-filling materials.

**Justification:** *Critical*, This is arguably the highest risk lever: limiting investigation accelerates mobilization time but transfers all geotechnical uncertainty onto the active construction budget, directly controlling the contingency buffer and immediate cost exposure.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Labor Force Composition and Retention Model
**Lever ID:** `e1ae8612-ff74-4228-8052-dbda38588e49`

**The Core Decision:** This lever governs workforce sourcing, balancing the cost benefits of local Hungarian labor against the specialized skills of international experts. The model affects productivity, quality assurance, and labor cost burden relative to the fixed budget. Success is defined by timely completion with minimal rework, maintaining labor costs within their allocated proportion of the total construction budget.

**Why It Matters:** Staffing the project entirely with specialized international crews ensures immediate high productivity upon site handover, but their higher expatriate wages and accommodation costs will rapidly deplete the budget, especially if delays occur. Relying primarily on local Hungarian construction firms stabilizes operational costs if work aligns with regional pay scales, but it introduces quality assurance risks and reliance on external subcontractor performance standards interpretation.

**Strategic Choices:**

1. Maintain a core management team of five international experts and subcontract all bulk earthworks and paving operations to established regional Hungarian contractors.
2. Provide comprehensive, performance-linked retention bonuses payable only upon final project commissioning to incentivize specialized international labor consistency across the entire duration.
3. Establish an internal training and certification path for local Hungarian general laborers focused specifically on the roundabout's design requirements, aiming for near-total local labor utilization.

**Trade-Off / Risk:** High retention bonuses motivate quality work, but tying the entire incentive to final commissioning risks attrition if interim milestones are missed, leaving critical phases understaffed.

**Strategic Connections:**

**Synergy:** Enables the successful implementation of complex designs by ensuring expertise is available, thus supporting Intersection Geometry and Throughput Requirement execution standards.

**Conflict:** Directly conflicts with Financing Drawdown Schedule Velocity, as utilizing high-cost international labor accelerates expenditure rates, shortening the available float for unforeseen costs.

**Justification:** *Medium*, While critical for execution quality, this lever's primary impact is on cost draw-down velocity and quality assurance, which are secondary drivers compared to initial site access or core design trade-offs.

### Decision 7: Subgrade Preparation and Stabilization Protocol
**Lever ID:** `4bb3afdb-b58f-4fa2-bb34-f96ab6c37847`

**The Core Decision:** This lever defines the methodology for establishing the load-bearing platform beneath the pavement layers. Success is measured by achieving target compaction density quickly and using minimal costly imported aggregate. The strategic insight is balancing geotechnical risk against immediate material cost savings through in-situ treatment versus higher upfront surveying costs.

**Why It Matters:** Employing non-standard, in-situ soil mixing or chemical stabilization techniques can drastically reduce the need to import expensive aggregate base layers from distant processing plants. This conserves the material budget, but introduces significant risk based on the variability and unknown composition of the specific Hungarian subsoil, potentially leading to unforeseen structural failures later.

**Strategic Choices:**

1. Implement comprehensive geotechnical surveys across the entire footprint to allow for bespoke, minimal importation of foreign aggregate materials.
2. Mandate standard, proven granular base consolidation methods using imported materials exclusively, accepting the higher direct material transit and procurement costs.
3. Utilize deep dynamic compaction methods to densify existing in-situ soils for base support, relying on vibration energy rather than bulk material replacement to achieve required bearing capacity.

**Trade-Off / Risk:** In-situ stabilization saves on material haulage costs but leverages unknown soil geology, creating a substantial long-term risk of differential settlement if the initial compaction energy is insufficient for the specific strata.

**Strategic Connections:**

**Synergy:** Enables budget optimization through collaboration with Material Sourcing and Specification Resilience by reducing reliance on imported aggregate base layers.

**Conflict:** Conflicts with Pavement Structure Specification Alternative by potentially compromising the designed load rating if in-situ stabilization performs poorly under subsequent stress.

**Justification:** *High*, This lever directly manages the foundational risk tied to 'unforeseen subsurface conditions.' Its ability to reduce imported material reliance (synergy) creates a major pathway for budget optimization against geotechnical uncertainty.

### Decision 8: Local Authority Engagement Cadence
**Lever ID:** `0ffa024e-6c54-483e-871b-e99ec00d569d`

**The Core Decision:** This governs the frequency and depth of interaction with Hungarian regional government bodies regarding the project's execution. Key metrics include minimizing bureaucratic delays and maintaining high political capital. The primary benefit is creating a buffer against unforeseen permit issues, trading direct oversight time for institutional alignment.

**Why It Matters:** Increasing the frequency of formal progress reviews and site walkthroughs with the responsible Hungarian county government fosters strong political goodwill, which can ease unexpected bureaucracy or expedite utility access if issues arise. This dedicated management time diverts senior project personnel away from direct site supervision, potentially allowing lower-level quality deviations to occur unchecked during critical paving phases.

**Strategic Choices:**

1. Establish a mandatory bi-weekly progress meeting attended by the Hungarian County Engineer and Project Director, emphasizing proactive dispute resolution pathways.
2. Limit official liaison to legally required monthly milestones, minimizing administrative overhead to maximize time spent on direct site execution and quality control.
3. Outsource all local government liaison and permitting management to a specialized, politically connected Budapest-based third-party consultancy for maximum institutional access.

**Trade-Off / Risk:** Intensive official engagement secures political insurance against unforeseen bureaucratic hurdles, but the dedicated senior time investment subtracts valuable oversight capacity from crucial, time-sensitive construction activities.

**Strategic Connections:**

**Synergy:** Amplifies Regulatory Authorization Pipeline Management by proactively addressing local official concerns, smoothing pathways for necessary permit approvals and sign-offs.

**Conflict:** Trades off against Traffic Management During Construction Phase, as senior personnel focused on high-level official engagement are then unavailable for critical on-site coordination of traffic flow changes.

**Justification:** *Medium*, This is a tactical management lever supporting the authorization process. While important for smoothing bureaucracy, it is supportive of the higher-level regulatory management lever rather than controlling a primary project tension itself.

### Decision 9: Drainage and Runoff Management Architecture
**Lever ID:** `f55f5c74-94ea-44f2-bb0f-ea199279326e`

**The Core Decision:** This dictates how surface water is managed to ensure long-term hydrological stability and environmental compliance around the new impermeable surface. Its scope includes land use planning for catchment features. Success involves meeting environmental discharge limits without consuming extra capital or exceeding the initially planned physical footprint. 

**Why It Matters:** Designing for zero net downstream impact by installing comprehensive on-site retention ponds and infiltration basins guarantees environmental compliance, even under extreme rainfall events. This requires dedicating significant peripheral land area, which might not be readily available or may necessitate costly boundary adjustments outside the initially secured right-of-way envelope.

**Strategic Choices:**

1. Install robust engineered swales and graded earthworks designed to direct all surface water runoff to the nearest existing natural waterway, minimizing imported piping.
2. Construct deep underground permeable soakaway pits directly beneath landscape features, ensuring no additional surface area is consumed by required water retention infrastructure.
3. Implement dispersed, decentralized bio-retention planters integrated directly into the roadside furniture margins, treating small volumes close to the source across the entire site.

**Trade-Off / Risk:** Incorporating large-scale retention features near the site ensures long-term hydrological stability but risks infringing upon land acquisition boundaries not yet fully secured or zoned for containment structures.

**Strategic Connections:**

**Synergy:** Directly supports achieving compliance targets outlined in Regulatory Authorization Pipeline Management by preemptively solving environmental water discharge concerns.

**Conflict:** Trades off against Land Acquisition Strategy for Right-of-Way, as deep infiltration pits or large retention areas require significant, potentially unbudgeted, land area consumption.

**Justification:** *Medium*, This lever governs compliance aspects and directly conflicts with the critical Land Acquisition Strategy by requiring additional site footprint, making it an important secondary constraint.

### Decision 10: Lighting and Ancillary Signage Standardization
**Lever ID:** `638912a3-026e-4008-b449-c95e61fd99e2`

**The Core Decision:** This lever determines the power source and standardization for all roadway illumination and informational signs, balancing capital cost against operational resilience in a remote location. Metrics involve upfront unit cost vs. long-term maintenance/grid independence. The insight is prioritizing system autonomy over initial procurement expenditure.

**Why It Matters:** Selecting internationally recognized, high-specification photovoltaic-powered LED signage and lighting minimizes reliance on connecting to the potentially unreliable or distant national grid infrastructure. This trades guaranteed operational independence for a higher upfront unit cost for specialized autonomous equipment, straining the modest fixed capital budget.

**Strategic Choices:**

1. Utilize only locally sourced, conventionally wired, high-pressure sodium lighting systems powered directly from the main grid connection, accepting vulnerability to local power stability.
2. Specify durable, self-contained solar-powered LED signage and highly reflective pavement markings requiring zero electrical utility connection or ongoing service contracts.
3. Eliminate all dedicated roadway lighting beyond standard regulatory signage illumination, prioritizing budget allocation toward pavement depth and structural integrity.

**Trade-Off / Risk:** Adopting off-grid solar lighting provides robust functional reliability independent of the remote grid, but the specialized, higher-cost units will consume capital that could otherwise fund structural material upgrades.

**Strategic Connections:**

**Synergy:** Amplifies Site Security and Vandalism Mitigation Posture by using autonomous solar lighting systems that remain operational even if general construction power is temporary disconnected or compromised.

**Conflict:** Creates a conflict with Financing Drawdown Schedule Velocity, as the higher upfront unit cost for specialized photovoltaic hardware strains the initial expenditure profile disproportionately.

**Justification:** *Low*, This is largely an operational specification (lighting/signage) that impacts budget, but it does not govern the existential trade-offs (schedule, core design, site access) identified as driving the majority of strategic outcomes.

### Decision 11: Material Off-Specification Tolerance Threshold
**Lever ID:** `f776ba5f-61e6-492a-b1ca-5adeb8cd3cf6`

**The Core Decision:** This lever establishes the permissible deviation from required material specifications, particularly for asphalt mixes, to balance budget pressure against product quality. While it saves on logistics and procurement time, success relies on accurate assessment of the residual long-term risk to pavement longevity from using non-perfectly compliant materials.

**Why It Matters:** Relaxing the tolerance for slight deviations in asphalt mix composition (e.g., binder content, aggregate gradation) allows sourcing from smaller, pre-existing stockpiles nearer the site, saving significant freight costs and accelerating pavement completion. This relaxation, however, introduces measurable long-term pavement variability, potentially leading to premature rutting or cracking under heavy loads.

**Strategic Choices:**

1. Mandate strict adherence to all Hungarian National Standards Authority (MSZ) specifications for all asphalt courses, utilizing only certified suppliers regardless of their logistical distance.
2. Permit material variances up to 5% below the specified binder content on binder courses if local suppliers can guarantee immediate delivery within 48 hours of order placement.
3. Accept only local, low-cost aggregate and locally produced asphalt mixes that meet a minimum 95% internal specification compliance, using quality checks only on the topmost wearing course.

**Trade-Off / Risk:** Lowering tolerance standards on base material composition accelerates project pace significantly by accessing closer, ready-made supply, yet this risks fundamental structural failure within the intended asset lifespan.

**Strategic Connections:**

**Synergy:** Directly enables efficiency gains within Material Sourcing and Specification Resilience by rapidly validating and utilizing locally available, ready-to-use, albeit slightly deviated, asphalt stockpiles.

**Conflict:** Directly undermines the long-term goals of Pavement Structure Specification Alternative by accepting immediate material variance that reduces the expected service life of the final driving surface.

**Justification:** *High*, This lever directly controls the trade-off between material logistics speed/cost savings and long-term pavement structural life. It governs when material quality must be enforced versus when budget/schedule pressures allow for acceptable risk.

### Decision 12: Financing Drawdown Schedule Velocity
**Lever ID:** `0c8d6f30-9b02-48fe-9aef-1ff59607161c`

**The Core Decision:** This lever governs the rate at which the 1.3 million EUR budget is dispersed to contractors and suppliers. Accelerated drawdown aims to lock in current material costs against mid-project inflation, thereby securing critical path components early. The challenge is the potential forfeiture of trade discounts negotiated for end-of-cycle settlements, requiring careful management to balance cost certainty against working capital preservation.

**Why It Matters:** Aggressively front-loading the utilization of the 1.3 million EUR budget accelerates physical progress, securing critical paths earlier against potential late-stage inflation shocks or currency volatility in the Eurozone. This speed, however, demands paying suppliers and subcontractors on shorter cycles, potentially forfeiting volume-based discounts negotiated for later phased payments or incurring early mobilization premiums. Maintaining a measured pace preserves working capital flexibility but exposes committed costs to unmitigated future risk.

**Strategic Choices:**

1. Execute maximum payment releases against long-lead material procurement and bulk earthworks within the first quarter to establish project permanence rapidly, using capital upfront to lock in current pricing.
2. Stagger payment milestones strictly corresponding to verifiable physical completion percentages, forcing contractors to finance interim time gaps using their own working capital to maintain budget liquidity.
3. Establish a 'trigger-based' drawdown acceleration model, releasing accelerated funds only upon the successful, independent verification of subcontractor performance in quality metrics, not solely on elapsed time.

**Trade-Off / Risk:** Rapidly drawing down the budget front-loads risk against early material pricing but secures critical path progress against the risk of mid-project funding freezes or unexpected currency fluctuations impacting later purchases.

**Strategic Connections:**

**Synergy:** A faster drawdown schedule enhances the impact of Material Sourcing and Specification Resilience by enabling early, large-volume material orders, locking in favorable terms before potential market changes.

**Conflict:** Rapid front-loading conflicts with Pavement Structure Specification Alternative, as front-loading requires committing to core material specifications based on early estimates, potentially locking in higher costs unnecessarily.

**Justification:** *Medium*, This lever controls the *pace* of financial expenditure. While crucial for inflation hedging, it is secondary to *what* that money is being spent on (e.g., land, materials science, geometry decisions).

### Decision 13: Pavement Structure Specification Alternative
**Lever ID:** `b41f6c5c-4532-4916-8357-d588fb5485bb`

**The Core Decision:** This involves making value engineering choices regarding the layers of the final asphalt and base structure, trading immediate capital savings for reduced asset longevity. By selecting cheaper materials or thinner courses, initial budget constraints are met, but the required maintenance interval shortens considerably. Key metrics involve comparing the upfront material cost reduction against the predicted net present value (NPV) of the earlier scheduled overhaul.

**Why It Matters:** Reducing the standard required thickness of the asphalt course or selecting a lower-grade aggregate base layer immediately cuts the consumption of high-cost bituminous materials, preserving budget for foundational elements or signaling. This modification directly lowers the design life expectancy of the final surface layer and mandates a faster planned re-pavement cycle within a decade, transferring maintenance cost into the operational lifecycle. The trade-off is reduced initial expenditure versus guaranteed deferred lifecycle expense.

**Strategic Choices:**

1. Substitute the specified high-stability asphalt concrete mix with a lower binder-content, locally sourced aggregate, accepting a documented 25% reduction in predicted service life span post-construction.
2. Mandate the use of full-depth stabilized base layer construction (e.g., cement-treated aggregate, CTA) beneath a thinner surface course, transferring material cost volatility from asphalt consumables to stabilization agents.
3. Adopt proprietary polymer-modified asphalt formulations known for high early strength gain, allowing immediate traffic loading but increasing the per-tonne material cost significantly higher than the baseline contract.

**Trade-Off / Risk:** Reducing pavement depth directly lowers the material bill now, but this constitutes deferred maintenance baked into the asset's core, ensuring higher lifecycle costs and a mandatory reconstruction sooner than traditional design life.

**Strategic Connections:**

**Synergy:** This lever pairs well with Subgrade Preparation and Stabilization Protocol, as cheaper, thinner surface courses require extremely robust and well-executed foundational stabilization work to maximize service life.

**Conflict:** This choice inherently conflicts with Lighting and Ancillary Signage Standardization, as savings secured here may need to be redirected to cover higher-than-expected costs encountered in specialized ancillary specification scope creep.

**Justification:** *High*, This directly engineers the required lifecycle of the asset to meet the fixed budget. It forces a fundamental trade-off: initial CapEx reduction versus guaranteed increased long-term OpEx (deferred maintenance).

### Decision 14: Site Security and Vandalism Mitigation Posture
**Lever ID:** `123894fd-e6cc-4d11-8378-a2bade438b6c`

**The Core Decision:** This dictates the level of physical protection against theft and damage enacted across the remote site footprint. Employing minimal security saves direct payroll costs but dramatically increases exposure to asset loss and the subsequent schedule disruption caused by unexpected equipment failure or stolen inventory reconciliation. Success is measured by the ratio of security spend versus the quantifiable cost of loss incidents incurred.

**Why It Matters:** Opting for minimal, localized site security (e.g., spot checks, basic fencing) drastically reduces the overhead associated with guarding the remote site 24/7, lowering non-productive labor costs. This lack of presence significantly increases exposure to material theft, equipment damage, and unauthorized site usage, which creates stop-work orders and costly rework whenever breaches are discovered far from the initial budget line item. The saving is immediate general security costs; the exposure is specific, high-impact asset loss.

**Strategic Choices:**

1. Employ only temporary, low-visibility perimeter fencing and rely solely on remote, pre-scheduled inspections by the primary construction manager, minimizing daily physical security payroll expenses.
2. Install comprehensive, high-definition passive monitoring infrastructure (thermal cameras, remote alarming) across the entire perimeter, allowing immediate digital response to intrusions without continuous guard presence.
3. Negotiate a service contract with a local farmer or community association to provide informal, dedicated perimeter monitoring in exchange for immediate access rights to site spoil/disturbed land for their agricultural needs.

**Trade-Off / Risk:** Minimizing physical security saves short-term operational cash flow, but relying on passive measures in a remote area almost certainly leads to episodic theft or vandalism requiring costly, unscheduled site remediation shutdowns.

**Strategic Connections:**

**Synergy:** Minimizing security spend allows for higher investment in proactive quality checks, directly benefiting Subgrade Preparation and Stabilization Protocol by funding extra, unscheduled compaction testing crews.

**Conflict:** Underinvesting in security strains relationships with Local Authority Engagement Cadence, as community concerns about unsupervised nighttime activity or poor asset guarding can lead to regulatory scrutiny.

**Justification:** *Low*, This lever addresses remote site operational risk (theft, etc.). While failure is disruptive, it is a second-order operational risk compared to the primary strategic risk drivers like land acquisition or geotechnical unknowns.

### Decision 15: Traffic Management During Construction Phase
**Lever ID:** `d677b910-bf56-4c32-8278-109c398a6f61`

**The Core Decision:** This controls the physical access method for the construction corridor, choosing between maximum contractor efficiency via total closure or maintaining community throughput via constrained, partial access. Total closure accelerates the critical earthwork and paving phases significantly, but it imposes major logistical difficulties on regional traffic flow. The key trade-off is the time saved on site versus the political and economic fallout from prolonged detours.

**Why It Matters:** Implementing a full, extended closure of the existing roadway geometry to establish the roundabout footprint unimpeded allows for accelerated, uninterrupted earthworks and paving schedules for the central mass. This aggressive approach maximizes on-site worker efficiency but forces all regional traffic onto significantly longer, secondary detour routes, generating substantial political friction and potential secondary economic disruption to local businesses dependent on direct access. The trade-off is construction efficiency versus community acceptance.

**Strategic Choices:**

1. Execute a complete three-month closure of the intersecting corridor, deploying temporary diversion routes kilometres away to enable continuous, uninterrupted heavy machinery operation throughout the core build sequence.
2. Maintain phased, single-lane alternating traffic flow using temporary signalization and flaggers throughout the entire 12-month build, accepting 30% schedule slippage due to traffic sequencing constraints.
3. Construct the final roundabout footprint incrementally on temporary earth berms adjacent to the existing road, shifting traffic only in the final week onto the finished alignment after all material has been placed and cured.

**Trade-Off / Risk:** Full closure maximizes contractor efficiency and speeds the build phase, but it antagonizes local stakeholders by imposing severe, long-duration alternate routing burdens that may invite later regulatory slowdowns.

**Strategic Connections:**

**Synergy:** Full closure is highly synergistic with Subgrade Preparation and Stabilization Protocol, offering uninterrupted, long-duration cycles necessary for optimal curing and compaction standards.

**Conflict:** Aggressively closing the corridor immediately strains Local Authority Engagement Cadence, as the resulting public disruption demands intensive, preemptive communication to mitigate political backlash.

**Justification:** *High*, This lever dictates the primary trade-off between maximizing construction efficiency (full closure) versus managing political/community fallout from disruption. It critically impacts schedule by determining contractor workflow freedom.
