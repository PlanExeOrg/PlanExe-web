**Proposed Land Acquisition Expenditure Exceeding 10% Cap**
Escalation Level: Project Strategy and Direction Board (PSDB)
Approval Process: Majority vote, with Head of Finance to provide immediate adverse risk analysis if required.
Rationale: Upfront capital commitment for land exceeds the pre-approved 130,000 EUR ceiling, directly threatening the minimum 15% operational contingency buffer.
Negative Consequences: Budget overrun, reduction in fiduciary protection against unforeseen geotechnical issues (Risk 2).

**Unforeseen Subsurface Conditions requiring mobilization of rapid-response crew (Rock/High Water Table)**
Escalation Level: Technical Assurance Group (TAG)
Approval Process: Unanimous agreement required to issue a short-term stop-work order; 75% agreement for technical recommendation to POC.
Rationale: High/High technical risk (Risk 2) materially materialized, demanding immediate, documented technical verification before the POC can deploy expensive, pre-contracted emergency resources.
Negative Consequences: Schedule delay leading to idle crew costs, potential need to utilize geotechnical contingency funds, and risk of structural failure if remediation is inappropriate.

**Regulatory Delay Exceeding 14 Days Past KVI Service Level Agreement (SLA)**
Escalation Level: Project Strategy and Direction Board (PSDB)
Approval Process: PSDB addresses governance failure; the Chair instructs the Project Director to escalate the issue to external political sponsors.
Rationale: Failure of the POC-managed Regulatory pipeline (Risk 3) signals a blockage requiring strategic intervention beyond the POC's operational scope to prevent critical path extension.
Negative Consequences: Cascading schedule delay pushing commissioning past target date, leading to financial penalties and reputational damage.

**Material Sourcing Conflict: Second Pavement Specification required before Initial Site Delivery**
Escalation Level: Project Operating Committee (POC)
Approval Process: Consensus required; if failed, Project Director has final call, documented for PSDB.
Rationale: A decision regarding which reinforcement system (Option A or B) must be locked in based on early testing, directly impacting the Lead Contract Manager's ability to procure resources under budget limits.
Negative Consequences: Failure to decide locks in the high-risk option or incurs 4-week paving gap due to material lead times (Risk 4).

**Reported Material Specification Override (Site Engineer accepting >5% binder content variance)**
Escalation Level: Compliance, Ethics, and Regulatory Assurance Group (CERAG)
Approval Process: CERAG investigates and, if confirmed, freezes contract funds below €15,000 pending PSDB review.
Rationale: This constitutes a willful deviation from mandated MSZ standards (Risk 5 mitigation failure) impacting asset longevity, triggering fiduciary/ethics review.
Negative Consequences: Premature structural failure (cracking/rutting), potential legal ramifications for non-compliance, and complete loss of asset service life expectations.

**Proposal to implement Full, Extended Road Closure for Construction (Decision d677b910 Strategy 1)**
Escalation Level: Project Strategy and Direction Board (PSDB)
Approval Process: PSDB vote required due to high community impact (Risk 8) and schedule compression trade-off.
Rationale: A full closure significantly alters the political risk profile and neighborhood acceptance, requiring executive sign-off on the community disruption versus the schedule benefit.
Negative Consequences: Severe community backlash leading to potential regulatory intervention or public opposition delaying the project further.