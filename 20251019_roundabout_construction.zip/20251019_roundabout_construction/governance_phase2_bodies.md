### 1. Project Strategy and Direction Board (PSDB)

**Rationale for Inclusion:** Required for high-level mandate and approval of the critical strategic trade-offs identified (e.g., budget vs. geotechnical certainty, geometry vs. schedule/cost), ensuring alignment with the 1.3M EUR constraint and ASAP start commitment. It serves as the ultimate fiduciary and strategic risk decision-maker.

**Responsibilities:**

- Approve final Land Acquisition Strategy following recommendation from Operating Committee (especially deviation from the €130k acquisition cap).
- Review and approve any necessary reserve utilization from the 15% contingency (€195k minimum).
- Authorize invocation of significant change requests exceeding 5% of the single-phase budget (e.g., full pivot from dual-lane readiness).
- Provide final sign-off on the commencement of physical construction following regulatory approval milestones.
- Oversight liaison for funding governance and currency hedging strategy compliance.

**Initial Setup Actions:**

- Finalize and ratify the Terms of Reference (ToR), defining financial thresholds for escalation.
- Elect the Board Chair and confirm representation from the ultimate funding body.
- Approve the initial budget allocation structure, specifically validating the €100,000 ring-fenced Land Acquisition contingency.

**Membership:**

- Sponsor/Ultimate Authority (Chair)
- Head of Finance (Focal for Budget/Currency)
- Project Director (Executive Reporting Member)
- Independent External Infrastructure Advisor (Impartial Oversight)

**Decision Rights:** Decisions concerning budget contingency drawdowns in excess of €20,000, any requested schedule extensions beyond 2 weeks, and approval of Land Acquisition expenditure ceilings.

**Decision Mechanism:** Majority vote (51% of voting members). Tie-breaker: Chair's casting vote, unless the tie involves a financial risk exceeding €50,000, in which case the decision is deferred to the Head of Finance for immediate risk analysis before re-vote.

**Meeting Cadence:** Monthly, or immediately upon request if a risk breach exceeds High/High severity threshold.

**Typical Agenda Items:**

- Contingency Fund Status and Forecast Burn Rate
- Review of Critical Path Milestone Achievability
- Strategic Risk Profile Review (Focus on Geotechnical/Regulatory Blockers)
- Review of Land Acquisition Spend vs. Cap

**Escalation Path:** Issues of governance failure or unresolvable conflict regarding fiduciary duty are escalated directly to the organization's Executive Board/Audit Committee.
### 2. Project Operating Committee (POC)

**Rationale for Inclusion:** Serves as the core operational management body, responsible for executing the 'Pragmatic Optimization' strategy chosen. It bridges the gap between strategic objectives (set by the PSDB) and daily execution, managing the complex coordination between technical design choices and regulatory sequence.

**Responsibilities:**

- Manage and coordinate the output of the Technical Assurance Group and the Compliance/Liaison Lead.
- Approve operational expenditure variations below the strategic threshold (e.g., minor changes in local contractor sourcing).
- Monitor the 10-week earthworks schedule aggressively and determine Go/No-Go decision for mobilization.
- Oversee implementation of Risk 5 mitigation (QA delegation) and Risk 8 mitigation (Traffic Management/Liaison Interface).
- Manage application and utilization of the €5,000/month Rapid Response Standby Contract.

**Initial Setup Actions:**

- Define and document the governance matrix for Site Engineer QA delegation.
- Finalize retainer agreements for Rapid Response Geotech Crew and Political Liaison.
- Approve the initial JIT/phased procurement schedule for Option A/Option B materials.

**Membership:**

- Project Director (Chair)
- Site Engineer (Primary QA/QC Lead)
- Junior Project Coordinator (Regulatory & Liaison Lead)
- Lead Contract Manager (Procurement/Local Sourcing)

**Decision Rights:** Operational decisions, including material selection between pre-qualified Option A/B, awarding retainer contracts under €15,000, and managing day-to-day adherence to the phased regulatory submission schedule.

**Decision Mechanism:** Consensus required for all decisions impacting schedule contingency. If consensus fails, the Project Director makes the final call, which must be documented with dissenting opinions recorded for PSDB review.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of Site Engineer QA/QC adherence report (incorporating subcontractor certification status)
- Regulatory Status Update from Junior PC (KVI SLA status)
- Change Log Review (All variations below €20k threshold)
- Hazard Review: Status of Subsurface Investigation findings vs. planned scope limitations

**Escalation Path:** Unresolved schedule adherence issues threatening the 10-week earthworks target, or any unidentified regulatory delay exceeding 14 days past SLA, are immediately escalated to the Project Strategy and Direction Board (PSDB).
### 3. Technical Assurance Group (TAG)

**Rationale for Inclusion:** Crucial due to the high technical risks associated with limited geotechnical investigation (Risk 2) and the uncertainty surrounding foundational viability (Decision 7 and 13). This body provides independent technical verification, preventing the Site Engineer's day-to-day focus from compromising structural integrity.

**Responsibilities:**

- Audit the limited subsurface investigation results against expected anomaly zones.
- Verify the execution standards of the local subcontractors performing base stabilization (including pre-mobilization audit of certification).
- Provide technical recommendation on whether to proceed with Option A or Option B reinforcement systems based on in-situ testing.
- Validate the adequacy of the 70% decentralized drainage solution (Assumption 6) against soil permeability models.

**Initial Setup Actions:**

- Define the minimum structural performance metrics required for 'Dual-Lane Readiness'.
- Contract and onboard independent third-party auditors for subcontractor certification verification.
- Establish protocol for immediate mobilization of the Rapid Response Crew contingent upon TAG flagging a critical subsurface finding.

**Membership:**

- Independent Civil Engineer specializing in Hungarian Subsoils (Chair)
- Site Engineer (Operational Input)
- Representative from the Rapid Response Geotech Crew (Advisory)
- PSDB Technical Monitor (Non-voting observer)

**Decision Rights:** Authority to mandate an immediate, short-term stop-work order (up to 3 days) specifically on earthworks/base foundation activities if structural integrity testing fails initial pass criteria. Authority to recommend up to €10,000 from segregated geotechnical contingency for non-emergency focused testing.

**Decision Mechanism:** Unanimous agreement required for issuing a stop-work order. Recommendations are based on a documented technical risk assessment score, requiring 75% agreement among voting members.

**Meeting Cadence:** Bi-weekly during earthworks; Monthly post-paving foundation inspection phase.

**Typical Agenda Items:**

- Subsurface Anomaly Review and Testing Results
- Base Compaction Test Outputs vs. Design Load Targets
- Material Resilience Strategy (Option A/B choice justification)
- Drainage System Integrity Assessment

**Escalation Path:** Critical structural failure findings or disagreement that threatens to incur costs exceeding €20,000 is escalated immediately to the Project Strategy and Direction Board (PSDB).
### 4. Compliance, Ethics, and Regulatory Assurance Group (CERAG)

**Rationale for Inclusion:** Essential for direct oversight of corruption risks identified (bribery, kickbacks) and managing critical regulatory dependencies (KVI environmental sign-off). Assigning compliance oversight explicitly prevents the Project Director/Coordinator from conflating political liaison duties with strict adherence to MSZ standards and Hungarian law.

**Responsibilities:**

- Conduct quarterly financial audits focusing on EUR/HUF hedging and land acquisition compliance (€130k cap).
- Monitor the Junior Project Coordinator’s engagement metrics with the KVI (Risk 3) and publicly publish violation logs (>21 day delays).
- Provide assurance that procurement contracts (Liaison, Rapid Response) adhere to documented justification for sole-sourcing.
- Oversee compliance confirmation of local subcontractor training (Risk 5 mitigation validation).
- Act as the designated body for receiving and investigating whistleblower reports related to ethical breaches or material specification tolerance overrides.

**Initial Setup Actions:**

- Establish the direct reporting line from CERAG Chair to the PSDB Independent Advisor.
- Publish the Audit Procedures (Financial/Technical) required for the project.
- Finalize the secure channel for anonymous reporting.

**Membership:**

- Independent Compliance Officer/Internal Auditor (Chair)
- Legal Counsel (Hungary focus)
- External Fraud & Corruption Risk Specialist
- Project Director (Non-voting, for information sharing only)

**Decision Rights:** Authority to freeze funds allocated to any specific contract engagement (e.g., Liaison Services) pending an investigation, provided the freeze amount is below €15,000 and does not directly impact immediate life-safety works.

**Decision Mechanism:** Unanimous vote is required to elevate a compliance finding to the Project Strategy and Direction Board (PSDB) for mandatory financial review.

**Meeting Cadence:** Bimonthly, with mandatory publication of compliance findings 7 days after review.

**Typical Agenda Items:**

- Review of Budget Status Report (Contingency Usage Detail)
- KVI Sign-off SLA Adherence & Delay Analysis
- Subcontractor Certification Audit Status
- Review of Change Request Log for unauthorized specification slippage

**Escalation Path:** Confirmed findings of financial fraud, conflicts of interest, or willful deviation from mandated MSZ standards are escalated immediately to the organization's Executive Board/External Legal Authority for potential prosecution or external regulatory reporting.