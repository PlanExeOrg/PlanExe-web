## 1. Land Acquisition Capital Expenditure and Legal Status

This data directly validates the most sensitive assumption (Assumption 1: Capital Allocation) and resolves the identified conflict between pursuing easements versus allocating budget for freehold buyouts, which underpins the immediate schedule viability (ASAP start).

### Data to Collect

- Final agreed cost for primary core parcel freehold acquisition (if any).
- Total committed capital against the €130,000 Land Acquisition ceiling.
- Status report confirming temporary use easements are fully executed for non-structural land covering the dual-lane footprint perimeter.
- Legal confirmation that no ongoing eminent domain proceedings are active or pending commencement.

### Simulation Steps

- Use spreadsheet modeling (MS Excel) to plot cumulative land spend against the €130,000 cap and calculate remaining buffer for mobilization.
- Review legal boilerplate documents using document analysis software (e.g., Nitro Pro) to flag deviation from the 'temporary easement' language mandated by the chosen strategy.

### Expert Validation Steps

- Consult the Land & Easement Acquisition Specialist (Sofia Mendes) to confirm immediate, legally sound site access via current easements.
- Consult the Financial Controller & Currency Hedge Analyst (Dr. Evelyn Reed) to verify the cash position against the land acquisition ceiling.

### Responsible Parties

- Land & Easement Acquisition Specialist
- Financial Controller & Currency Hedge Analyst

### Assumptions

- **High:** The strategy adheres to temporary use easements to minimize initial capital outlay, requiring expenditure below €130,000.

### SMART Validation Objective

By 2026-05-30, confirm that legal execution of temporary use easements covers 100% of non-structural land required for dual-lane readiness, with total cash outlay for all land secured remaining strictly below €130,000.

### Notes

- Critical dependency for mobilization (ASAP start). Must confirm avoidance of compulsory purchase activation.


## 2. Geotechnical Investigation Scope and ECF Quantification

The High/High risk of unforeseen subsurface conditions is the single largest financial threat. Validating the ECF against the contingency is mandatory to proceed responsibly, as recommended by both expert reviews.

### Data to Collect

- Final detailed borehole/seismic profiling map defining zones tested vs. zones assumed (Decision 5).
- Formal Expected Cost of Failure (ECF) model quantifying subsurface risk based on limited investigation scope.
- Revised geotechnical contingency allocation, measured against the ECF and the €195,000 minimum buffer.

### Simulation Steps

- Utilize specialized geotechnical risk software (e.g., Rocscience suite) to perform Monte Carlo simulation based on the limited data set to model ECF for encountering Class 3 soil conditions.
- Develop a comparison matrix (Excel) mapping ECF against the protected contingency fund.

### Expert Validation Steps

- Consult the Geotechnical Risk Modeler (Expert 2) to validate the ECF calculation and the 'Go/No-Go' threshold.
- Consult the Civil Engineering Contracts Specialist to ensure any revised investigation scope complies with Hungarian procurement requirements.

### Responsible Parties

- Geotechnical & Subsurface Risk Manager
- Project Director & Lead Strategist

### Assumptions

- **High:** The inherent High/High geotechnical risk can be mitigated via a small contingency buffer (€195k) supported by a 72-hour rapid response contractor.

### SMART Validation Objective

Within 14 calendar days of contract commencement, finalize the Geotechnical Risk ECF model and confirm in writing (signed by the Director and Risk Manager) that ECF is strictly less than €150,000, or formally revise the investigation scope.

### Notes

- If ECF validation fails, the project must pivot to Decision 5, Strategy 2: Full Seismic Profiling.


## 3. Regulatory Review Response Time Commitment (KVI)

Cascading regulatory delays are identified as a Medium/High risk threatening the ASAP schedule. Obtaining a concrete, written commitment (instead of relying on assumed SLAs) is necessary to de-risk the phased approval strategy.

### Data to Collect

- Written commitment from the County Basin Water Directorate (KVI) detailing the maximum response/clarification timeline for the primary EIA submission.
- Documentation showing the 'shadow' submission packages prepared for parallel review by Municipal Engineering bodies.
- SLA agreements signed by the Project Coordinator regarding tracking and reporting KVI response times.

### Simulation Steps

- Model the schedule impact (in MS Project) of a 21-day vs. a 14-day KVI response cycle from the submission date, calculating the resulting shift in the 'ASAP' start milestone.

### Expert Validation Steps

- Consult the Civil Engineering Contracts Specialist to verify the legal standing of any expedited KVI commitment secured.
- Consult the Regulatory & Stakeholder Navigator to confirm the documentation package is compliant with current Hungarian EIA submission standards for regional water management.

### Responsible Parties

- Regulatory & Stakeholder Navigator
- Project Director & Lead Strategist

### Assumptions

- **High:** The sequential (phased) regulatory approval strategy permits an 'ASAP' construction start within the optimistic 10-week earthworks window.

### SMART Validation Objective

By 2026-05-28, secure official written confirmation from KVI guaranteeing a maximum 14-day response window for the initial EIA submission package, or transition liaison efforts to support parallel review submissions.

### Notes

- This validates the successful mitigation of Risk 3 (Cascading Delays).


## 4. Local Contractor Subcontractor Competency Verification

The pragmatic strategy relies heavily on local contractor skill for durable foundations without extensive geotechnical certainty (as highlighted in Assumption Review Issue 1). Competency verification is mandatory to prevent costly future rework (Risk 5 consequence).

### Data to Collect

- Formal audit report from an independent third party assessing the top 2 shortlisted Hungarian pavement subcontractors.
- Specific findings regarding their capability to execute dual-lane (higher CBR) base compaction standards.
- Training completion log for the 2 mandated local supervisors (cost verified against €8,000 budget).

### Simulation Steps

- Use a comparison checklist (Excel) to map the audit findings directly against the required base layer specifications needed for the dual-lane ready geometry.
- Update the project schedule to incorporate the 2-week training duration for supervisors and ensure it does not compress against the earthworks start date.

### Expert Validation Steps

- Consult the Digital Quality Assurance Consultant (Expert 8) for guidance on structuring the audit metrics for base compaction testing.
- Consult the Construction & Pavement Quality Assurance Lead (Site Engineer) to review the audit findings and certify that the selected contractors are competent to meet the structural requirements.

### Responsible Parties

- Construction & Pavement Quality Assurance Lead
- Project Director & Lead Strategist

### Assumptions

- **Medium:** Local Hungarian contractors are capable of executing high-specification base preparation required for dual-lane readiness, supported by mandatory, low-cost training (€8,000).

### SMART Validation Objective

Within 14 days, secure a formal audit report confirming suitability of top 2 subcontractors, and complete the supervisor training for both, ensuring zero impact on the planned earthworks mobilization date.

### Notes

- This action directly addresses the critical weakness identified in the SWOT and review feedback.


## 5. Hydrological Risk Mitigation Cost and Contract

The 30% runoff deficit poses a quantified technical risk (Assumption Review Issue 2). Securing a rapid response contract de-risks potential soil saturation that could otherwise trigger the larger geotechnical ECF.

### Data to Collect

- Signed standing contract guaranteeing 48-hour deployment for dewatering/erosion control specialist for the 30% unmanaged runoff zone.
- Verified cost commitment (€5,000/month standby fee) and official reallocation documentation showing €8,000 moved from contingency to this dedicated fund.
- Finalized swale designs from the Drainage Officer incorporating the minimum permeability assumptions.

### Simulation Steps

- Update the overall contingency tracker to deduct the €8,000 allocated for localized drainage remediation.
- Use flow modeling software (if practical for basic swale design) to ensure the engineered swales complement the decentralized planters based on preliminary soil data.

### Expert Validation Steps

- Consult the Drainage & Environmental Compliance Officer (László Nagy) to certify the contract covers the specific hydrological risk zones identified.
- Consult the Geotechnical Risk Modeler to confirm that the €8,000 allocation is a reasonable 'insurance premium' for this specific, quantified hydrological risk.

### Responsible Parties

- Drainage & Environmental Compliance Officer
- Financial Controller & Currency Hedge Analyst

### Assumptions

- **Low:** The centralized contingency buffer is sufficient to absorb the €8,000 dedicated allocation for localized hydrological remediation.

### SMART Validation Objective

By 2026-05-20, secure the binding 48-hour deployment contract for erosion control, with associated expenditure (€8,000) formally logged against the contingency buffer, and documentation confirmed by the Drainage Officer.

### Notes

- This follows the explicit recommendation from the Assumption Review.


## 6. Currency Hedge Instrument Status

Managing currency volatility (Risk 7) is a non-negotiable financial safeguard against eroding the contingency buffer via unexpected local cost inflation eroding the budget margin.

### Data to Collect

- Proof of execution for the 70% forward hedging contract covering anticipated HUF labor costs for the first 6 months.
- Documentation detailing the specific HUF amount effectively hedged (verified against the estimated €140,000 exposure).

### Simulation Steps

- Model the potential cost variance (in EUR) if the unhedged 30% portion of labor costs were subject to a 10% adverse exchange rate movement.
- Input current spot rates to check if the 70% hedge remains in effect and the instruments are active.

### Expert Validation Steps

- Consult the Financial Controller & Currency Hedge Analyst to confirm the transaction is settled and effective.
- Consult the Construction Logistics and Supply Chain Specialist to confirm the €140,000 labor cost estimate aligns with the initial material procurement schedule.

### Responsible Parties

- Financial Controller & Currency Hedge Analyst

### Assumptions

- **Medium:** The labor cost component is accurately estimated at 35% of the construction budget, allowing the 70% hedge to cover critical exposure.

### SMART Validation Objective

By 2026-05-28, execute the 70% forward hedge contract securing currency exchange rates for the estimated €98,000 HUF expenditure exposure for the initial 6 months.

### Notes

- As per the Geotechnical expert's guidance (2.1), the actual hedging transaction execution should be prioritized immediately over other non-essential financial procurement.

## Summary

Immediate actionable tasks must prioritize the validation of the project's highest financial and schedule risks, focusing sequentially on Land Acquisition finalization, Geotechnical ECF acceptance, and Regulatory commitment. First, secure and confirm the legal/financial status of Land Acquisition by verifying easements and adherence to the €130k cap (Data Item 1). Second, immediately quantify the Geotechnical risk by achieving ECF confirmation below the contingency limit (€150k threshold); if this fails, the project scope *must* change before mobilization (Data Item 2). Third, secure binding KVI response times to de-risk the ASAP schedule from bureaucratic stall-out (Data Item 3). Finally, mandate the competency audit of local subcontractors to secure the foundation quality (Data Item 4) and activate the currency hedge (Data Item 6).