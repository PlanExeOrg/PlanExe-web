
## Documents to Create

### 1. Project Charter: Pragmatic Optimization Infrastructure Project

**ID:** 5ec75f4b-e1f6-428c-ae9c-8adce31c34cd

**Description:** Official foundational document authorizing the project, defining scope boundaries (dual-lane ready roundabout, €1.3M budget ceiling, ASAP start), high-level risks, strategic approach ('Pragmatic Optimization'), and naming primary accountability (Project Director). Type: Project Authorization Document.

**Responsible Role Type:** Project Director & Lead Strategist

**Primary Template:** PMI Project Charter Template

**Secondary Template:** N/A

**Steps:**

- Formalize SMART goals and key dependencies as defined in 'project-plan.md'.
- Document the selected five critical strategic decisions (from 'The Builder' path).
- Obtain initial budgetary sign-off referencing the €1.3M fixed limit.
- Finalize preliminary Project Organization Chart (Team Roles).

**Approval Authorities:** Budget Oversight Entity / Project Sponsor

### 2. Initial Geotechnical Risk Register & ECF Model Snapshot

**ID:** d9bc5fa2-99f3-4e61-b0cf-84ec054f114c

**Description:** A foundational document capturing the initial High/High geotechnical risk (Decision 5) and its associated Expected Cost of Failure (ECF) based on the limited investigation scope assumption. Must establish the initial contingency absorption threshold (€150k ECF limit before triggering re-evaluation). Type: Risk Management Artifact.

**Responsible Role Type:** Geotechnical & Subsurface Risk Manager

**Primary Template:** ISO 31000 Risk Register Template

**Secondary Template:** FHWA Geotechnical Risk Assessment Template

**Steps:**

- Input current High/High risk (Unforeseen Subsurface Conditions) and associated mitigation (72-hour contract).
- Establish the initial ECF calculation based on potential remediation costs for worst-case, shallow failure.
- Document the formal 'Go/No-Go' contingency absorption threshold (€150k ECF).

**Approval Authorities:** Project Director & Lead Strategist

### 3. Land Acquisition Strategy Resolution Document

**ID:** e4f617bd-718b-44c2-a7ba-122208f47256

**Description:** A definitive document resolving the conflict between the preferred 'temporary easement' strategy and the allocated capital for 'premium cash offers/freehold conversion' (€130k max). Must clearly define the chosen path (easement vs. freehold) for asset boundary security and reconcile this with the required right-of-way for future dual-lane expansion. Type: Strategy Resolution Document.

**Responsible Role Type:** Land & Easement Acquisition Specialist

**Primary Template:** Strategic Decision Memo Template

**Secondary Template:** N/A

**Steps:**

- Review current land availability status based on existing official maps.
- Formalize commitment to either Option 1 (Easement focus) or Option 2 (Freehold focus) for the primary site.
- Update the projected capital use against the €130,000 ceiling based on the resolution.
- Obtain sign-off confirming schedule alignment (ASAP) based on the chosen strategy.

**Approval Authorities:** Project Director & Financial Controller & Currency Hedge Analyst

### 4. Regulatory Submission Readiness & SLA Commitment Plan

**ID:** 4b6ddf3f-756c-471d-9a55-cb413e33a92d

**Description:** Outlines the detailed sequence and timelines for submitting documentation to the County Basin Water Directorate (KVI) and Municipal Engineering Departments. Crucially, it must document *written agreements* from these bodies committing to a maximum review SLA (e.g., 14-day or 21-day response time) to counteract the 'phased sequential protocol' risk. Type: Regulatory Compliance Framework.

**Responsible Role Type:** Regulatory & Stakeholder Navigator (Junior Coordinator)

**Primary Template:** Regulatory Compliance Tracker Template

**Secondary Template:** N/A

**Steps:**

- Develop and finalize all content for the initial Environmental Impact Assessment (EIA) package.
- Draft formal written inquiries to KVI and Municipalities requesting written service level agreements (SLAs) for review turnaround.
- Map the dependency flow between KVI sign-off and Municipal approval for the paving sequence.

**Approval Authorities:** Project Director & Lead Strategist

### 5. Minimum Viable Base Specification (MVBS) for Dual-Lane Readiness

**ID:** 6f6ce993-d64e-40da-bcd7-f78e5213f983

**Description:** A technical document defining the absolute minimum C.B.R. (California Bearing Ratio) or equivalent specification required for the subgrade/base layer to structurally support the *potential* dual-lane overlay, independent of the current, limited investigation scope. This acts as the execution benchmark for the Site Engineer. Type: Engineering Specification Standard.

**Responsible Role Type:** Construction & Pavement Quality Assurance Lead (Site Engineer)

**Primary Template:** Hungarian National Standard (MSZ) Road Basis Specification (Modified)

**Secondary Template:** N/A

**Steps:**

- Liaise with Geotechnical Manager to define minimum CBR based on accepted geological assumptions.
- Translate dual-lane readiness requirements into quantifiable, measurable field standards for compaction and layer thickness.
- Integrate acceptance thresholds for primary/secondary material verification (Decision 11).

**Approval Authorities:** Project Director & Geotechnical & Subsurface Risk Manager

### 6. Pavement Quality Assurance (PQA) Pilot Program Charter

**ID:** 0758fd8d-f257-459f-8470-cdaafde2e6e6

**Description:** Defines the scope, methodology (drone/ML), data structure, and acceptance metrics for the compensating quality assurance program designed to mitigate risks from limited geotechnical testing. Includes integration points with the Site Engineer's daily reporting. Type: Quality Management Framework.

**Responsible Role Type:** Construction & Pavement Quality Assurance Lead (Site Engineer)

**Primary Template:** Pilot Program Scope Document

**Secondary Template:** N/A

**Steps:**

- Define the exact coordinates and timing windows for drone scanning relative to earthworks completion.
- Establish the data pipeline for transferring visual data to the modeling consultant.
- Set the quantitative pass/fail metrics that directly compensate for assumed geotechnical certainty.

**Approval Authorities:** Project Director & Lead Strategist

### 7. Initial HUF/EUR Currency Hedging Instruction

**ID:** ca21bb83-1708-4b66-a642-cd10bf2c410b

**Description:** A formal instruction document detailing the required financial instruments (forward contracts) to be executed by the Treasury Analyst to hedge 70% of the projected local labor/material expenditure against adverse EUR/HUF movements for the initial 6-month window. Type: Financial Execution Order.

**Responsible Role Type:** Financial Controller & Currency Hedge Analyst

**Primary Template:** Treasury Forward Contract Execution Template

**Secondary Template:** N/A

**Steps:**

- Finalize construction budget allocation breakdown to isolate the 35% labor/local cost projection.
- Calculate the precise € equivalent (€98,000 theoretical exposure) requiring 70% coverage.
- Liaise with external banking partner to initiate 6-month forward purchase of HUF.

**Approval Authorities:** Project Director & Lead Strategist

### 8. Contractual Retainer Agreement Template for Secondary Material Sourcing

**ID:** 10185b11-f0ed-4d17-ad64-ef3a021635d8

**Description:** A standardized legal template for securing 'call-off' rights against suppliers providing the secondary base reinforcement system (Decision 81f06e88). Must clearly define retainer fee structure, material quality minimums, and delivery lead times for emergency activation. Type: Legal Procurement Artifact.

**Responsible Role Type:** Logistics & Materials Flow Manager

**Primary Template:** Standard European Construction Retainer Agreement

**Secondary Template:** N/A

**Steps:**

- Draft terms based on anticipated mobilization windows (10-week earthworks).
- Review liability clauses with Legal Counsel (if available, otherwise Director assumes legal oversight).
- Establish mechanism for transferring the retainer fee from the construction budget.

**Approval Authorities:** Project Director & Lead Strategist

### 9. Governance Matrix: QA/QC Delegation and Escalation Protocol

**ID:** da7e3ee4-a553-4b15-af5f-fd4af1c78203

**Description:** A structured document formally defining the boundaries of authority between the Project Director and the delegated Site Engineer. Specifically clarifies which material tolerance deviations (up to 2%) the Site Engineer can approve independently versus those requiring the Director’s sign-off (for Decision 11). Type: Internal Governance Document.

**Responsible Role Type:** Project Director & Lead Strategist

**Primary Template:** Authority Delegation Matrix Template

**Secondary Template:** N/A

**Steps:**

- Define decision thresholds for geotechnical findings.
- Map daily/weekly reporting lines from Site Engineer to Project Director.
- Ensure explicit documentation procedure for all design/material variance approvals.

**Approval Authorities:** Project Director & Construction & Pavement Quality Assurance Lead (Site Engineer)

## Documents to Find

### 1. M8 Motorway Section IV: Specific Material Off-Specification Tolerance Contracts

**ID:** 6055b791-f1c6-4720-af74-1f5a90a3945a

**Description:** Existing contract standards or correspondence from the M8 motorway project detailing how the general contractor negotiated or agreed upon allowable tolerance variances for aggregate or base course material from certified suppliers in Hungary. Purpose: Benchmarking expectations for Decision 11.

**Recency Requirement:** Post-2018

**Responsible Role Type:** Logistics & Materials Flow Manager

**Access Difficulty:** Medium

**Steps:**

- Contact the Project Management office of contractors involved in M8 Section IV (e.g., Strabag, Duna Aszfalt).
- Search Hungarian Public Roads (Magyar Közút) archives for procurement records referencing material flexibility clauses.

### 2. Official KVI Environmental Discharge Standards for Rural Hungarian Roadworks

**ID:** 10b746f8-b7f7-4afb-abaa-6f3d07000c2d

**Description:** The current, legally binding regulatory text issued by the County Basin Water Directorate (KVI) specifying net volumetric discharge rates, infiltration requirements, and required certification for surface water management (for Decision 9/Drainage). Purpose: Input for the Drainage Officer's hydrological modeling.

**Recency Requirement:** Current Legislation/Most Recent Revision

**Responsible Role Type:** Drainage & Environmental Compliance Officer

**Access Difficulty:** Medium

**Steps:**

- Search Hungarian government gazettes (Magyar Közlöny) for relevant water management legislation.
- Consult the official KVI website or relevant Ministry portal for technical guidelines.

### 3. Historical/Recent Hungarian Alluvial Plain Geotechnical Survey Data (Central/Eastern Hungary)

**ID:** 55e559b9-42c6-45d1-9e6c-6eaa448f5f29

**Description:** Raw, aggregated geotechnical data (soil classification, shear strength, water table correlation) from existing geological surveys or boreholes drilled within 100km radius of the likely project location, used to refine the probabilistic risk model (Expert Review 2). Purpose: To inform the ECF calculation for Risk 2.

**Recency Requirement:** Past 10 Years

**Responsible Role Type:** Geotechnical & Subsurface Risk Manager

**Access Difficulty:** Hard

**Steps:**

- Contact geological survey departments at BME or Hungarian Geological Survey (MFGI).
- Search academic databases for BME student theses referencing soil conditions in the Great Plain.
- Request aggregated data under local FOI requests, if necessary.

### 4. EU Cohesion Fund Road Rehabilitation Project Pavement Repair Specifications (Szabolcs County)

**ID:** 8503d95b-84ee-4d3b-88a1-f4ab24caab22

**Description:** Technical documentation related to the Szabolcs-Szatmár-Bereg County road rehabilitation projects, specifically detailing how lifecycle cost trade-offs (thinning base layers vs. increasing wearing course quality) were managed contractually and verified on site. Purpose: Benchmarking Decision 13 execution practicality.

**Recency Requirement:** 2018-2024 Cycle

**Responsible Role Type:** Construction & Pavement Quality Assurance Lead (Site Engineer)

**Access Difficulty:** Medium

**Steps:**

- Search Hungarian Ministry of Transport archives related to EU structural fund projects.
- Search BME library resources for related academic performance reviews.
- Contact County Development Agencies in Szabolcs County for contact points on past technical supervisors.

### 5. Hungarian Cadastral Maps and Land Ownership Registry for Planned Area

**ID:** a4780170-407b-48cf-a6e4-054c253ebff7

**Description:** Official geometric surveys and registration records detailing current ownership (or easement eligibility) for all parcels intersecting the planned Right-of-Way footprint required for the dual-lane structure. Purpose: Essential baseline for the Land Acquisition Specialist's work.

**Recency Requirement:** Current

**Responsible Role Type:** Land & Easement Acquisition Specialist

**Access Difficulty:** Medium

**Steps:**

- Submit official request to the Hungarian Land Registry Office (Földhivatal).
- Cross-reference preliminary GIS layouts with registered parcel boundaries.

### 6. Hungarian Construction Labor Cost Indices (HUF/EUR Volatility Data)

**ID:** ec666641-18d5-45f8-b4cb-54d02d6ff195

**Description:** Historical and forecasted exchange rate data and localized labor cost indices specifically for the Hungarian construction sector, necessary for precisely calculating the HUF expenditure base for the mandated 70% hedging (Risk 7). Purpose: To accurately quantify the necessary HUF notional amount for the hedging instrument.

**Recency Requirement:** Past 18 Months and 12-Month Forecast

**Responsible Role Type:** Financial Controller & Currency Hedge Analyst

**Access Difficulty:** Medium

**Steps:**

- Consult major Hungarian banking institutions' economic research departments.
- Search for reports from the Hungarian Central Statistical Office (KSH) related to construction wages.
- Obtain input via the Financial Controller's external treasury contacts.

### 7. GDDKiCA Small Intersection Upgrade Project Independent Geotechnical Audit Reports (Poland)

**ID:** 81d4b91f-9105-4fd3-aab4-e5c97ff96cb9

**Description:** Independent Polish geotechnical audit reports used to validate base compaction quality on fast-track roundabout projects, specifically those mandated due to site uncertainty. Purpose: Benchmarking the structure and delivery of the proposed PQA Pilot Program (Recommendation 1).

**Recency Requirement:** 2021-Present

**Responsible Role Type:** Construction & Pavement Quality Assurance Lead (Site Engineer)

**Access Difficulty:** Hard

**Steps:**

- Search the GDDKiCA public records for 'Priority Safety Interventions' related to roundabouts.
- Contact major Central European construction firms with Polish operations for case study insights.