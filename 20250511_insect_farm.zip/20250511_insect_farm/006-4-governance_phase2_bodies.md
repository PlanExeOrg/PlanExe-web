### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance for the pilot cricket farm project, ensuring alignment with organizational goals and managing strategic risks. Given the project's novelty and potential impact, high-level oversight is crucial.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic direction and guidance.
- Monitor project progress against strategic objectives.
- Approve major changes to project scope, budget, or timeline (>$50,000 DKK).
- Oversee strategic risk management and mitigation.
- Resolve strategic-level conflicts and issues.
- Approve key strategic decisions (e.g., Feedstock Sourcing Strategy, Market Entry Strategy).
- Ensure compliance with ethical guidelines and sustainability goals.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define escalation paths.
- Review and approve project charter.

**Membership:**

- CEO/Executive Sponsor
- Head of Operations
- Head of Marketing
- Independent External Advisor (Agri-Food Tech)
- Project Manager

**Decision Rights:** Strategic decisions related to project scope, budget, timeline, and strategic risks. Approval of budget changes exceeding 50,000 DKK. Approval of key strategic decisions.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the CEO/Executive Sponsor has the deciding vote. Dissenting opinions are documented in meeting minutes.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of project progress against strategic objectives.
- Discussion of strategic risks and mitigation plans.
- Approval of major changes to project scope, budget, or timeline.
- Review of key performance indicators (KPIs).
- Review of compliance and sustainability performance.
- Review of stakeholder engagement activities.

**Escalation Path:** CEO/Executive Leadership Team
### 2. Core Project Team

**Rationale for Inclusion:** Manages the day-to-day execution of the pilot cricket farm project, ensuring efficient operations and adherence to project plans. Essential for operational risk management and timely delivery.

**Responsibilities:**

- Develop and maintain project plans.
- Manage project budget and resources (up to $50,000 DKK without Steering Committee approval).
- Execute project tasks and activities.
- Monitor project progress and identify potential issues.
- Implement risk mitigation plans.
- Report project status to the Project Steering Committee.
- Manage stakeholder communication.
- Ensure compliance with relevant regulations and standards.

**Initial Setup Actions:**

- Define roles and responsibilities.
- Establish communication protocols.
- Set up project management tools.
- Develop detailed project schedule.
- Establish risk register.

**Membership:**

- Project Manager
- Farm Manager
- Technician
- Marketing/Sales Person

**Decision Rights:** Operational decisions related to project execution, resource allocation (within approved budget), and risk mitigation (below strategic thresholds).

**Decision Mechanism:** Decisions made by the Project Manager in consultation with the team. In case of disagreement, the Project Manager has the final decision, documented with rationale.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of current issues and risks.
- Assignment of tasks and responsibilities.
- Review of budget and resource utilization.
- Review of stakeholder communication.
- Review of compliance activities.

**Escalation Path:** Project Steering Committee
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and guidance on cricket farming, controlled environment agriculture, and food safety. Ensures the project utilizes best practices and mitigates technical risks.

**Responsibilities:**

- Provide technical advice on cricket farming practices.
- Review and approve technical designs and specifications.
- Assess the feasibility of new technologies and processes.
- Identify and mitigate technical risks.
- Provide guidance on food safety and hygiene protocols.
- Review and approve biosecurity plans.
- Advise on environmental control strategies.
- Monitor and evaluate technical performance.

**Initial Setup Actions:**

- Define scope of expertise.
- Establish communication channels.
- Review project plans and specifications.
- Identify key technical risks.
- Establish review process for technical documents.

**Membership:**

- Entomologist
- Agricultural Engineer
- Food Safety Specialist
- Environmental Control Expert
- Farm Manager

**Decision Rights:** Provides recommendations and guidance on technical matters. Approves technical designs and specifications. Approves biosecurity plans.

**Decision Mechanism:** Decisions made by consensus. In case of disagreement, the Project Manager and the independent external advisor on the Project Steering Committee will mediate and make the final decision.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of technical performance data.
- Discussion of technical risks and mitigation plans.
- Review of new technologies and processes.
- Review of food safety and hygiene protocols.
- Review of biosecurity plans.
- Review of environmental control strategies.

**Escalation Path:** Project Steering Committee
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures the project adheres to the highest ethical standards and complies with all relevant regulations, including food safety, environmental protection, and data privacy (GDPR). Protects the organization's reputation and minimizes legal risks.

**Responsibilities:**

- Oversee compliance with all relevant regulations and standards.
- Develop and implement ethical guidelines for the project.
- Monitor compliance with food safety regulations.
- Monitor compliance with environmental regulations.
- Ensure compliance with data privacy regulations (GDPR).
- Investigate and resolve ethical concerns and compliance violations.
- Provide training on ethical conduct and compliance requirements.
- Review and approve marketing materials to ensure ethical and accurate representation of the product.

**Initial Setup Actions:**

- Define scope of authority.
- Establish reporting mechanisms.
- Develop ethical guidelines.
- Review relevant regulations and standards.
- Establish investigation procedures.

**Membership:**

- Legal Counsel
- Compliance Officer
- Independent Ethics Advisor
- Project Manager
- Marketing/Sales Person

**Decision Rights:** Authority to investigate and resolve ethical concerns and compliance violations. Authority to recommend corrective actions. Authority to approve compliance policies and procedures.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Independent Ethics Advisor has the deciding vote.

**Meeting Cadence:** Bi-monthly

**Typical Agenda Items:**

- Review of compliance reports.
- Discussion of ethical concerns and compliance violations.
- Review of compliance policies and procedures.
- Review of marketing materials.
- Review of data privacy practices.
- Review of whistleblower reports.

**Escalation Path:** CEO/Executive Leadership Team
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Manages communication and engagement with key stakeholders, including the local community, consumers, regulatory bodies, and local farmers. Ensures positive relationships and addresses concerns effectively, fostering consumer acceptance and regulatory support.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Communicate project progress and updates to stakeholders.
- Gather feedback from stakeholders.
- Address stakeholder concerns and complaints.
- Organize community meetings and events.
- Build relationships with local farmers.
- Engage with regulatory bodies.
- Manage media relations.
- Monitor public perception of the project.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop communication channels.
- Establish feedback mechanisms.
- Define roles and responsibilities.
- Develop stakeholder engagement plan.

**Membership:**

- Marketing/Sales Person
- Community Liaison Officer
- Farm Manager
- Project Manager

**Decision Rights:** Authority to implement the stakeholder engagement plan. Authority to communicate with stakeholders. Authority to address stakeholder concerns and complaints.

**Decision Mechanism:** Decisions made by the Marketing/Sales Person in consultation with the team. In case of disagreement, the Project Manager has the final decision, documented with rationale.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of stakeholder feedback.
- Discussion of stakeholder concerns and complaints.
- Review of communication activities.
- Planning of community meetings and events.
- Review of media coverage.
- Review of public perception data.

**Escalation Path:** Project Steering Committee