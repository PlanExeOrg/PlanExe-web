Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 15 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 4 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan focuses on cricket farming, which does not inherently violate any laws of physics. The plan mentions "controlled environment agriculture" which is an established practice.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (cricket protein) + market (Northern Europe) + tech/process (controlled environment agriculture) + policy (Danish regulations) without independent evidence at comparable scale. There is no credible precedent for this specific system.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Each track must produce one authoritative source or a supervised pilot showing results vs a baseline. Define NO-GO gates. Owner: Project Lead / Deliverable: Validation Report / Date: 2026-06-30


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan uses strategic concepts without defining their mechanism-of-action, owner, or measurable outcomes. The plan mentions "sustainable food production" and "consumer acceptance" without defining how these will be achieved or measured.

**Mitigation**: Project Lead: Create one-pagers for each strategic concept (sustainable food production, consumer acceptance), defining the mechanism-of-action, owner, measurable outcomes, and decision hooks. Due: 2026-06-30


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies risks and mitigation strategies, but doesn't explicitly analyze cascades or quantify second-order impacts. The risk register includes "Negative public perception, consumer resistance" but lacks a cascade analysis.

**Mitigation**: Risk Manager: Map risk cascades (e.g., permit delay → missed peak season → revenue shortfall) and quantify second-order impacts. Add controls and a dated review cadence. Due: 2026-07-30


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a permit/approval matrix. The plan mentions "Apply for food production license", "Environmental permit", "Building permit" but does not map dependencies or lead times.

**Mitigation**: Permitting Lead: Create a permit/approval matrix with dependencies, lead times, and NO-GO thresholds. Due: 2026-07-30


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a dated financing plan listing sources/status, draw schedule, and covenants. The plan mentions "Secure Funding" but does not specify funding sources, amounts, or conditions.

**Mitigation**: Finance Lead: Create a dated financing plan listing sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates. Due: 2026-07-30


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of 1 million DKK lacks substantiation via benchmarks or vendor quotes normalized by area. The plan mentions "1 million DKK pilot House Cricket (Acheta domesticus) farm" but provides no cost breakdown or per-area analysis.

**Mitigation**: Finance Lead: Obtain ≥3 vendor quotes for capex/opex, benchmark per-area costs (DKK/m²), and adjust budget or de-scope by 2026-08-30.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., timeline) as single numbers without ranges or alternative scenarios. The plan states "The goal should be achieved within 18 months" without discussing best/worst cases.

**Mitigation**: Project Manager: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the 18-month completion projection. Due: 2026-08-30


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for build-critical components. The plan mentions "HVAC systems", "Temperature and humidity sensors", and "Air filtration systems" but lacks specs, interface contracts, or acceptance tests.

**Mitigation**: Engineering Lead: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components. Due: 2026-08-30


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes several critical claims without providing verifiable evidence. For example, the plan states, "Secure long-term contracts with local farmers for cricket feed" but lacks any draft contracts or letters of intent.

**Mitigation**: Project Manager: Obtain letters of intent or draft contracts from local farmers regarding cricket feed supply by 2026-08-30, or adjust the scope.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "sustainable protein" and "innovative cricket-based food products" without defining specific, verifiable qualities. These deliverables are abstract and lack SMART acceptance criteria.

**Mitigation**: Product Development & Marketing Specialist: Define SMART criteria for 'sustainable protein' and 'innovative cricket-based food products', including KPIs for consumer ratings and environmental impact. Due: 2026-08-30


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'Develop Prototype Recipes' and 'Design Packaging and Labeling' without a clear benefit case. These activities add cost/complexity but don't directly support core goals like regulatory approval or feedstock sourcing.

**Mitigation**: Product Development & Marketing Specialist: Produce a one-page benefit case justifying inclusion of 'Develop Prototype Recipes' and 'Design Packaging and Labeling', complete with KPI, owner, and estimated cost, or move to backlog. Due: 2026-08-30


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a 'Food Safety & Regulatory Compliance Officer' to ensure compliance with regulations. This role is critical due to the novelty of the project and the complexity of food safety regulations in Denmark, making it difficult to fill.

**Mitigation**: HR: Validate the talent market for a 'Food Safety & Regulatory Compliance Officer' with experience in Danish food regulations within 30 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a regulatory matrix mapping authority, artifact, lead time, and predecessors. The plan mentions permits and licenses but does not detail the specific requirements or processes for obtaining them.

**Mitigation**: Permitting Lead: Create a regulatory matrix detailing the authority, artifact, lead time, and predecessors for all required permits and licenses. Due: 2026-07-30


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "Long-term sustainability compromised" as a risk and includes "Sustainability plan, diversify feed, monitor trends, invest in R&D" as mitigation, but lacks specifics on funding, maintenance, or scalability.

**Mitigation**: Farm Manager: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms. Due: 2026-09-30


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "Requires a location in Western Jutland, Denmark" but lacks evidence of zoning/land-use suitability or written confirmation from authorities. Occupancy/egress, fire load, structural limits, and noise are not addressed.

**Mitigation**: Real Estate Lead: Perform a fatal-flaw screen with authorities/experts regarding zoning/land-use, occupancy/egress, fire load, structural limits, and noise within 60 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "Secure long-term contracts with local farmers for cricket feed" and "alternative sources, buffer stock" but lacks evidence of secondary suppliers or tested failover plans. There is no mention of SLAs.

**Mitigation**: Feedstock Sourcing & Logistics Coordinator: Secure SLAs with primary suppliers and identify a secondary supplier/path for cricket feed. Test failover by 2026-12-31.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Production Efficiency Strategy is incentivized to minimize cost, while the Consumer Acceptance Strategy is incentivized to maximize consumer appeal, creating a conflict over production methods and ingredients.

**Mitigation**: Project Lead: Define a shared OKR (Objective and Key Results) that aligns Production Efficiency and Consumer Acceptance on a common outcome, such as 'Increase market share'. Due: 2026-08-30


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board to the project plan. Due: 2026-07-30


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies several high risks (e.g., disease outbreaks, negative consumer perception, regulatory hurdles) but lacks a cross-impact analysis. A disease outbreak could trigger financial collapse and halt market entry.

**Mitigation**: Risk Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Due: 2026-08-30