This plan involves money.

## Currencies

- **DKK:** Local currency for operations in Denmark.
- **EUR:** Useful for comparison and potential transactions within Europe.

**Primary currency:** DKK

**Currency strategy:** The local currency (DKK) will be used for all transactions. No additional international risk management is needed.