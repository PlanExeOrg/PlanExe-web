**Budget Request Exceeding Core Project Team Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the Core Project Team's delegated financial authority, requiring strategic oversight.
Negative Consequences: Potential budget overruns and financial instability.

**Critical Risk Materialization Impacting Project Goals**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: Requires strategic intervention and resource allocation beyond the Core Project Team's capacity.
Negative Consequences: Project failure or significant delays.

**Technical Advisory Group Deadlock on Biosecurity Plan Approval**
Escalation Level: Project Steering Committee
Approval Process: Project Manager and Independent External Advisor Mediation and Final Decision
Rationale: Requires resolution by a higher authority to ensure project progress and minimize technical risks.
Negative Consequences: Increased risk of disease outbreaks and operational disruptions.

**Proposed Major Scope Change Affecting Strategic Objectives**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Impacts strategic alignment and requires high-level approval to ensure project viability.
Negative Consequences: Misalignment with strategic goals and potential project failure.

**Reported Ethical Concern or Compliance Violation**
Escalation Level: CEO/Executive Leadership Team
Approval Process: Ethics & Compliance Committee Investigation & Recommendation to CEO/Executive Leadership Team
Rationale: Requires independent review and resolution to protect the organization's reputation and minimize legal risks.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Stakeholder Engagement Group Unable to Resolve Community Concerns Regarding Odor Control**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Enhanced Mitigation Plan
Rationale: Requires strategic intervention and resource allocation beyond the Stakeholder Engagement Group's capacity.
Negative Consequences: Negative public perception, project delays, and potential legal challenges.