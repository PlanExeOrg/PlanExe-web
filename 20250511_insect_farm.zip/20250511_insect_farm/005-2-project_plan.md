**Goal Statement:** Establish a 1 million DKK pilot House Cricket (Acheta domesticus) farm in Western Jutland, Denmark, utilizing controlled environment agriculture for food-grade human consumption.

## SMART Criteria

- **Specific:** Create a pilot cricket farm in Western Jutland, Denmark, for human consumption.
- **Measurable:** The successful establishment of the farm can be measured by the commencement of cricket production within the facility.
- **Achievable:** The goal is achievable given the budget and the availability of controlled environment agriculture technology.
- **Relevant:** The goal is relevant as it explores sustainable food production and gathers data for scaling insect protein production.
- **Time-bound:** The goal should be achieved within 18 months.

## Dependencies

- Secure long-term contracts with local farmers for cricket feed.
- Schedule a consultation with the Danish Veterinary and Food Administration (DVFA) to discuss regulatory requirements.
- Define precise temperature and humidity ranges for optimal cricket growth.

## Resources Required

- Cricket feed
- HVAC systems
- Temperature and humidity sensors
- Food-grade disinfectants
- Air filtration systems
- Activated carbon filters

## Related Goals

- Scale insect protein production in Northern Europe
- Build consumer acceptance of sustainable food sources

## Tags

- cricket farm
- controlled environment agriculture
- food-grade
- sustainable food
- insect protein
- Denmark

## Risk Assessment and Mitigation Strategies


### Key Risks

- Delays in permits for food-grade insect production in Denmark
- Failure to achieve optimal environmental conditions, reducing cricket growth
- Cost overruns due to unforeseen expenses
- Negative public perception, consumer resistance
- Disease outbreaks, pest infestations
- Disruptions in cricket feed supply
- Odor control issues
- Challenges integrating with existing infrastructure
- Theft of crickets or equipment
- Long-term sustainability compromised

### Diverse Risks

- Operational risks
- Systematic risks
- Business risks

### Mitigation Plans

- Engage with DVFA, secure consultations, allocate resources for compliance
- Implement monitoring systems, invest in equipment, develop contingency plans
- Detailed budget with contingency, firm quotes, explore financing, cost control
- Consumer education, marketing, partner with chefs, offer samples
- Hygiene protocols, quarantine, pest control, monitor health, consult experts
- Long-term contracts, alternative sources, buffer stock
- Odor control measures, community engagement, odor monitoring
- Assess capacity, obtain quotes, contingency plans
- Security measures, alarm systems, background checks
- Sustainability plan, diversify feed, monitor trends, invest in R&D

## Stakeholder Analysis


### Primary Stakeholders

- Farm Manager
- Technician
- Salesperson

### Secondary Stakeholders

- Danish Veterinary and Food Administration (DVFA)
- Local Community
- Local Farmers
- Consumers

### Engagement Strategies

- Regular updates and progress reports to primary stakeholders
- Consultation with DVFA to ensure compliance
- Community engagement through meetings and partnerships
- Consumer education through marketing and sampling

## Regulatory and Compliance Requirements


### Permits and Licenses

- Food production license
- Environmental permit
- Building permit

### Compliance Standards

- HACCP
- Food safety standards
- Environmental regulations

### Regulatory Bodies

- Danish Veterinary and Food Administration (DVFA)
- Local municipality

### Compliance Actions

- Apply for food production license
- Implement HACCP plan
- Schedule compliance audit
- Implement waste management plan