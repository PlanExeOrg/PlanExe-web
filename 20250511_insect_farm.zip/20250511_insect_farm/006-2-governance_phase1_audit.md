
## Audit - Corruption Risks

- Bribery of local officials to expedite permits or overlook regulatory non-compliance.
- Conflicts of interest in the selection of local farmers for feedstock supply contracts, favoring friends or family regardless of price or quality.
- Kickbacks from HVAC or equipment suppliers in exchange for contract awards.
- Misuse of confidential project information (e.g., production yields, market entry strategies) for personal gain or to benefit competing businesses.
- Trading favors with regulatory inspectors to avoid penalties for non-compliance with food safety or environmental regulations.

## Audit - Misallocation Risks

- Inflated invoices from local suppliers or contractors, with the excess funds diverted for personal use.
- Double-billing for services rendered by consultants or contractors.
- Inefficient allocation of the budget, with excessive spending on non-essential items or activities.
- Unauthorized use of project assets (e.g., vehicles, equipment) for personal purposes.
- Misreporting of project progress or results to secure continued funding or favorable evaluations.

## Audit - Procedures

- Conduct quarterly internal audits of financial records, including invoices, receipts, and bank statements, to detect any irregularities or discrepancies.
- Perform regular inspections of the cricket farm to ensure compliance with food safety and environmental regulations.
- Implement a contract review process with pre-defined thresholds (e.g., any contract exceeding 50,000 DKK requires review by an independent legal counsel).
- Establish a clear expense approval workflow with multiple levels of authorization to prevent unauthorized spending.
- Conduct a post-project external audit to assess the overall effectiveness of the project and identify any areas for improvement.

## Audit - Transparency Measures

- Create a project progress dashboard displaying key performance indicators (KPIs) such as cricket yield, feed conversion ratio, and energy consumption.
- Publish minutes of key project meetings (e.g., stakeholder meetings, regulatory consultations) on a project website or shared drive.
- Establish a whistleblower mechanism for reporting suspected fraud or misconduct, with clear procedures for investigation and resolution.
- Make relevant project policies and reports (e.g., financial reports, environmental impact assessments) publicly accessible.
- Document the selection criteria and rationale for major decisions, such as vendor selection and feedstock sourcing, to ensure fairness and transparency.