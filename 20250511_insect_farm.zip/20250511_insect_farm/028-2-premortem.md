A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The Danish Veterinary and Food Administration (DVFA) will readily approve permits for food-grade insect production within the projected 6-month timeframe. | Submit a detailed permit application package to the DVFA outlining all planned processes and safety measures. | The DVFA requests significant revisions to the application or indicates that the approval process will exceed 9 months. |
| A2 | Consumers in Western Jutland will readily accept cricket-based protein bars and flour as a regular part of their diet. | Conduct blind taste tests of cricket-based protein bars and flour against comparable products with a representative sample of 100 Western Jutland consumers. | Less than 30% of participants rate the cricket-based products as 'acceptable' or 'better than' the comparison products. |
| A3 | Local farmers will consistently supply the required volume of agricultural byproducts at or below the projected cost of 3 DKK/kg. | Obtain firm, written quotes from at least three local farmers for the supply of the specified agricultural byproducts over the next 12 months. | All quotes received exceed 3.5 DKK/kg or farmers are unwilling to guarantee supply for the next 12 months. |
| A4 | The chosen cricket farming technology (vertical racks, automated feeding) will achieve a minimum cricket density of 10,000 crickets per cubic meter within the first 3 months of operation. | Conduct a small-scale pilot test of the chosen technology with a representative cricket population for 3 months, closely monitoring density. | The cricket density consistently remains below 8,000 crickets per cubic meter after 3 months in the pilot test. |
| A5 | The farm's waste management system (composting of frass) will effectively control odor emissions, preventing complaints from nearby residents. | Operate the composting system at full capacity for one month and conduct regular odor monitoring at the property line, using a calibrated olfactometer. | Odor levels at the property line exceed the legally permissible limit (as defined by local regulations) on more than three occasions during the one-month test. |
| A6 | The project team possesses sufficient expertise in all critical areas (entomology, HVAC, marketing) to successfully manage the farm without relying on external consultants beyond the initial setup phase. | Conduct a skills gap analysis of the project team, comparing their expertise to the requirements of each key operational area. | The skills gap analysis identifies significant deficiencies in two or more critical areas, requiring ongoing external support. |
| A7 | The chosen e-commerce platform will seamlessly integrate with the farm's inventory management system and accounting software, providing real-time sales data and accurate financial reporting. | Conduct a full integration test of the e-commerce platform with the farm's inventory and accounting systems, simulating a high volume of transactions. | The integration test reveals significant data synchronization issues, resulting in inaccurate inventory counts or financial reports. |
| A8 | The local workforce possesses the necessary skills and willingness to work in a cricket farm environment, minimizing recruitment and training costs. | Post job openings for farm technician and harvest crew positions and assess the qualifications and interest level of applicants. | Fewer than 5 qualified applicants apply for each position, or the majority of applicants express concerns about working conditions or compensation. |
| A9 | The price of conventional protein sources (beef, chicken) will remain relatively stable, allowing cricket protein to maintain a competitive price point. | Monitor the wholesale prices of beef and chicken for one month, tracking any significant fluctuations. | The average wholesale price of beef or chicken decreases by more than 10% during the one-month monitoring period. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Regulatory Quagmire | Process/Financial | A1 | Permitting Lead | CRITICAL (20/25) |
| FM2 | The Feedstock Fiasco | Technical/Logistical | A3 | Feedstock Sourcing Lead | CRITICAL (15/25) |
| FM3 | The Cricket Crunch Catastrophe | Market/Human | A2 | Marketing Lead | CRITICAL (20/25) |
| FM4 | The Density Debacle | Process/Financial | A4 | Farm Manager | CRITICAL (20/25) |
| FM5 | The Odor Offensive | Technical/Logistical | A5 | Waste Management & Sustainability Coordinator | CRITICAL (15/25) |
| FM6 | The Expertise Erosion | Market/Human | A6 | Project Lead | CRITICAL (20/25) |
| FM7 | The Digital Disconnect | Technical/Logistical | A7 | IT Manager | CRITICAL (20/25) |
| FM8 | The Labor Labyrinth | Market/Human | A8 | Human Resources Manager | CRITICAL (15/25) |
| FM9 | The Protein Price Plunge | Process/Financial | A9 | Sales Manager | HIGH (10/25) |


### Failure Modes

#### FM1 - The Regulatory Quagmire

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Permitting Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's financial model hinges on a swift regulatory approval process. However, the DVFA, facing increasing scrutiny from consumer advocacy groups concerned about novel food safety, unexpectedly delays the permit. Initial estimates suggested a 6-month approval window, but the DVFA, citing the need for additional testing and risk assessments, extends the review period indefinitely. This triggers a cascade of financial problems. The project incurs holding costs for the leased facility, marketing campaigns are put on hold, and investor confidence plummets. The lack of revenue generation during this extended period depletes the contingency fund. Further, the DVFA mandates costly modifications to the production process to meet new, unforeseen safety standards, adding unexpected capital expenditures. The project is now stuck in a regulatory quagmire, bleeding cash with no clear path to market.

##### Early Warning Signs
- DVFA requests additional information beyond the initial application requirements.
- Communication from the DVFA becomes infrequent and non-committal.
- News articles or public statements emerge questioning the safety of insect-based foods.

##### Tripwires
- DVFA approval timeline exceeds 9 months.
- Mandatory process modifications exceed 50,000 DKK.
- Contingency fund depleted by 50% due to holding costs.

##### Response Playbook
- Contain: Immediately freeze all non-essential spending.
- Assess: Conduct a revised financial forecast incorporating the extended timeline and potential modification costs.
- Respond: Explore alternative regulatory pathways or pivot to a less regulated market (e.g., animal feed).


**STOP RULE:** DVFA approval timeline exceeds 12 months, and additional funding cannot be secured.

---

#### FM2 - The Feedstock Fiasco

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A3
- **Owner**: Feedstock Sourcing Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's reliance on locally sourced agricultural byproducts proves to be its Achilles' heel. While initial assessments suggested ample supply at affordable prices, a series of unforeseen events disrupts the feedstock supply chain. A severe drought decimates local crop yields, drastically reducing the availability of agricultural byproducts. Simultaneously, a new biofuel plant opens in the region, driving up demand and prices for the same byproducts. The cricket farm is now caught in a logistical nightmare. Existing contracts with local farmers are unenforceable due to force majeure clauses. Alternative feed sources are either prohibitively expensive or lack the necessary nutritional profile for optimal cricket growth. The crickets experience stunted growth, increased mortality rates, and reduced protein content. The entire production process grinds to a halt, jeopardizing the farm's ability to meet its contractual obligations and maintain its reputation.

##### Early Warning Signs
- Local weather patterns deviate significantly from historical averages.
- Prices for agricultural byproducts begin to rise unexpectedly.
- Farmers express concerns about their ability to meet contractual obligations.

##### Tripwires
- Feedstock prices exceed 3.5 DKK/kg for more than 30 days.
- Cricket mortality rate increases by 20% due to feed quality issues.
- Feedstock supply falls below 75% of projected demand for two consecutive weeks.

##### Response Playbook
- Contain: Immediately implement emergency feed rationing protocols.
- Assess: Conduct a comprehensive review of alternative feed sources and their nutritional profiles.
- Respond: Negotiate emergency supply agreements with distant suppliers or reformulate feed recipes to utilize available resources.


**STOP RULE:** Consistent feedstock supply cannot be secured at a price below 4 DKK/kg within 60 days.

---

#### FM3 - The Cricket Crunch Catastrophe

- **Archetype**: Market/Human
- **Root Cause**: Assumption A2
- **Owner**: Marketing Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Despite extensive marketing efforts touting the nutritional and environmental benefits of cricket protein, consumers in Western Jutland remain stubbornly resistant. Initial taste tests show a slight preference for cricket-based products among environmentally conscious consumers, but this enthusiasm fails to translate into widespread adoption. A series of negative media articles highlighting potential allergen risks and ethical concerns about insect farming further erode public trust. A well-funded campaign by a rival plant-based protein company exploits these fears, portraying cricket protein as 'unnatural' and 'unsafe.' Sales of cricket-based protein bars and flour plummet. Retailers pull the products from their shelves, citing lack of demand. The cricket farm is left with a warehouse full of unsold inventory and a rapidly deteriorating brand image. The project, once hailed as a sustainable food revolution, becomes a cautionary tale of consumer resistance and marketing missteps.

##### Early Warning Signs
- Sales figures consistently fall below projected targets.
- Negative comments and reviews proliferate on social media and online forums.
- Retailers express reluctance to stock or reorder cricket-based products.

##### Tripwires
- Consumer acceptance rate falls below 30% after six months of market entry.
- Sales revenue is 50% below projected targets for two consecutive months.
- Major retailers discontinue stocking cricket-based products.

##### Response Playbook
- Contain: Immediately halt all marketing campaigns and product development efforts.
- Assess: Conduct in-depth consumer research to identify the root causes of resistance.
- Respond: Reformulate products to address taste and texture concerns, and launch a new marketing campaign emphasizing transparency and safety.


**STOP RULE:** Consumer acceptance rate remains below 20% after a revised marketing campaign and product reformulation.

---

#### FM4 - The Density Debacle

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Farm Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The core of the project's financial projections rests on achieving high cricket density within the vertical farming setup. However, the chosen technology fails to deliver. The automated feeding system malfunctions frequently, leading to uneven food distribution and cannibalism among the crickets. The vertical racks, designed to maximize space, create microclimates with inconsistent temperature and humidity, stressing the crickets and hindering their growth. Disease spreads rapidly through the densely packed colonies. The farm struggles to reach even half the projected cricket density. Production costs skyrocket as the farm requires more space, more feed, and more labor to produce the same amount of protein. The project's financial model collapses under the weight of these inefficiencies, rendering it unsustainable.

##### Early Warning Signs
- Automated feeding system malfunctions more than twice per week.
- Significant temperature and humidity variations are detected across the vertical racks.
- Cricket mortality rate exceeds 5% per week.

##### Tripwires
- Cricket density consistently remains below 5,000 crickets per cubic meter after six months of operation.
- Production costs exceed 15 DKK per kilogram of crickets produced.
- The farm requires more than 1.5 times the projected floor space to achieve target production volumes.

##### Response Playbook
- Contain: Immediately reduce the cricket population density to alleviate stress and cannibalism.
- Assess: Conduct a thorough evaluation of the automated feeding system and vertical rack design.
- Respond: Invest in alternative feeding systems and rack designs or pivot to a less intensive farming method.


**STOP RULE:** Cricket density cannot be increased above 6,000 crickets per cubic meter within 9 months, and alternative technologies are cost-prohibitive.

---

#### FM5 - The Odor Offensive

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Waste Management & Sustainability Coordinator
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The farm's waste management system, relying on composting cricket frass, becomes a source of constant conflict with the local community. Despite implementing best practices, the composting process generates persistent and offensive odors that waft across the surrounding area. Residents complain to local authorities, triggering a series of inspections and fines. The farm is forced to implement increasingly expensive odor control measures, including biofilters and chemical treatments, but these prove only partially effective. The negative publicity surrounding the odor issues damages the farm's reputation and erodes consumer trust. Retailers become hesitant to stock cricket-based products, fearing association with the controversy. The farm's operations are severely restricted, and the project faces the threat of closure due to community opposition.

##### Early Warning Signs
- Odor complaints from nearby residents increase significantly.
- Local authorities issue warnings or fines related to odor emissions.
- Media coverage focuses on the negative environmental impact of the farm.

##### Tripwires
- Odor levels at the property line exceed legally permissible limits for more than 5 days per month.
- The farm receives more than 10 odor complaints per month from local residents.
- Local authorities threaten to revoke the farm's operating permit due to odor violations.

##### Response Playbook
- Contain: Immediately suspend composting operations and implement temporary odor control measures.
- Assess: Conduct a thorough review of the composting process and identify the sources of odor emissions.
- Respond: Invest in advanced odor control technologies or relocate the composting facility to a more isolated location.


**STOP RULE:** Odor issues cannot be resolved within 6 months, and community opposition remains high.

---

#### FM6 - The Expertise Erosion

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Project Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project team, initially confident in their combined expertise, discovers critical skill gaps as the farm moves from setup to full-scale operation. The Farm Manager, while experienced in general agriculture, lacks specialized knowledge of entomology and insect disease management. A series of disease outbreaks decimates the cricket population, leading to significant financial losses. The HVAC Technician, while skilled in maintaining climate control systems, struggles to optimize environmental conditions for cricket growth. Production efficiency stagnates, and energy costs remain stubbornly high. The Marketing Lead, lacking experience in the food industry, fails to effectively communicate the benefits of cricket protein to consumers. Sales remain sluggish, and the project struggles to gain traction in the market. The team, stretched thin and lacking critical expertise, becomes demoralized and ineffective. The project, once brimming with promise, slowly unravels due to a lack of specialized knowledge and experience.

##### Early Warning Signs
- Cricket mortality rates increase unexpectedly.
- Energy consumption consistently exceeds projected levels.
- Marketing campaigns fail to generate significant sales leads.

##### Tripwires
- Cricket mortality rate exceeds 10% per week for two consecutive weeks.
- Energy consumption exceeds projected levels by 20% for three consecutive months.
- Sales revenue is 50% below projected targets after six months of market entry.

##### Response Playbook
- Contain: Immediately engage external consultants with expertise in entomology, HVAC optimization, and food marketing.
- Assess: Conduct a thorough skills gap analysis of the project team and identify areas requiring additional training or support.
- Respond: Invest in specialized training for the project team or recruit additional personnel with the necessary expertise.


**STOP RULE:** The project team cannot acquire the necessary expertise within 3 months, and external consultants are cost-prohibitive.

---

#### FM7 - The Digital Disconnect

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: IT Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's reliance on a seamless e-commerce platform proves to be a critical flaw. The chosen platform, initially touted for its integration capabilities, fails to synchronize accurately with the farm's inventory management and accounting systems. Orders are lost, inventory counts are inaccurate, and financial reports are riddled with errors. The farm struggles to fulfill orders on time, leading to customer dissatisfaction and negative reviews. The accounting team spends countless hours manually reconciling data, diverting resources from other critical tasks. The lack of real-time sales data hinders effective marketing and production planning. The entire operation is plagued by digital chaos, undermining efficiency and profitability.

##### Early Warning Signs
- Data synchronization errors occur frequently between the e-commerce platform and other systems.
- Customer complaints about order fulfillment issues increase significantly.
- The accounting team reports difficulty reconciling financial data.

##### Tripwires
- Data synchronization errors occur more than 5 times per week.
- Order fulfillment rate falls below 90%.
- The accounting team spends more than 20 hours per week reconciling data.

##### Response Playbook
- Contain: Immediately suspend automated data synchronization and revert to manual data entry.
- Assess: Conduct a thorough audit of the e-commerce platform's integration capabilities and identify the root causes of the data synchronization issues.
- Respond: Implement a more robust integration solution or switch to a different e-commerce platform.


**STOP RULE:** A reliable e-commerce platform cannot be implemented within 3 months, and online sales are essential for the project's success.

---

#### FM8 - The Labor Labyrinth

- **Archetype**: Market/Human
- **Root Cause**: Assumption A8
- **Owner**: Human Resources Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's assumption of an available and willing local workforce proves to be disastrously wrong. Despite offering competitive wages, the farm struggles to attract qualified applicants for farm technician and harvest crew positions. Many locals express concerns about the nature of the work, citing discomfort with handling insects and potential health risks. The farm is forced to rely on temporary workers from distant regions, increasing labor costs and creating logistical challenges. The temporary workers lack the necessary skills and training, leading to inefficiencies and quality control issues. Employee turnover is high, disrupting operations and requiring constant recruitment efforts. The farm is trapped in a labor labyrinth, unable to secure a stable and skilled workforce.

##### Early Warning Signs
- Job postings remain unfilled for extended periods.
- The majority of applicants lack the necessary skills or experience.
- Employee turnover rate exceeds 10% per month.

##### Tripwires
- Fewer than 3 qualified applicants apply for each open position.
- Employee turnover rate exceeds 15% per month.
- Labor costs exceed projected levels by 20%.

##### Response Playbook
- Contain: Immediately increase wages and benefits to attract more applicants.
- Assess: Conduct a thorough review of the farm's working conditions and identify factors deterring potential employees.
- Respond: Implement employee training programs and improve working conditions to attract and retain a skilled workforce.


**STOP RULE:** A stable and skilled workforce cannot be secured within 6 months, and labor costs become unsustainable.

---

#### FM9 - The Protein Price Plunge

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Sales Manager
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The project's financial viability is undermined by a sudden and unexpected plunge in the price of conventional protein sources. A global glut of beef and chicken floods the market, driving down wholesale prices to record lows. Cricket protein, unable to compete on price, becomes a niche product affordable only to a small segment of consumers. Sales plummet, and retailers reduce their orders. The farm struggles to cover its operating costs, and investors become increasingly nervous. The project, once envisioned as a cost-competitive alternative to traditional protein sources, is now relegated to the margins of the market, struggling to survive in a price war it cannot win.

##### Early Warning Signs
- Wholesale prices of beef and chicken decline significantly.
- Retailers reduce their orders for cricket-based products.
- Sales revenue falls below projected targets.

##### Tripwires
- The average wholesale price of beef or chicken decreases by more than 15% for two consecutive months.
- Sales revenue is 50% below projected targets for three consecutive months.
- Retailers begin discounting cricket-based products to clear inventory.

##### Response Playbook
- Contain: Immediately reduce production costs and explore alternative revenue streams.
- Assess: Conduct a thorough analysis of the competitive landscape and identify opportunities to differentiate cricket protein.
- Respond: Develop a premium branding strategy and target niche markets willing to pay a higher price for sustainable protein.


**STOP RULE:** Cricket protein cannot be sold at a price that covers operating costs, and alternative revenue streams are insufficient to sustain the project.
