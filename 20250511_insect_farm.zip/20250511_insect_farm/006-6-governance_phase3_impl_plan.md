### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 2. Circulate Draft SteerCo ToR for review by nominated members (CEO/Executive Sponsor, Head of Operations, Head of Marketing, Independent External Advisor, Project Manager).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager finalizes the Project Steering Committee ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. CEO/Executive Sponsor formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** CEO/Executive Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Email
- Final SteerCo ToR v1.0

### 6. Hold the initial Project Steering Committee kick-off meeting to review the project charter, finalize the meeting schedule, and define escalation paths.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Project Charter
- Meeting Schedule
- Defined Escalation Paths

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 7. Project Manager defines roles and responsibilities for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Roles and Responsibilities Document

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 8. Project Manager establishes communication protocols for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Communication Protocols Document

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 9. Project Manager sets up project management tools for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Access to Project Management Tools

**Dependencies:**

- Core Project Team Roles and Responsibilities Document
- Core Project Team Communication Protocols Document

### 10. Project Manager develops a detailed project schedule for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Detailed Project Schedule

**Dependencies:**

- Access to Project Management Tools

### 11. Project Manager establishes a risk register for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Risk Register

**Dependencies:**

- Detailed Project Schedule

### 12. Project Manager schedules the initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Risk Register

### 13. Hold the initial Core Project Team kick-off meeting to review project plans, establish communication protocols, and assign initial tasks.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Assigned Initial Tasks

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 14. Project Manager defines the scope of expertise for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Technical Advisory Group Scope of Expertise Document

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 15. Project Manager establishes communication channels for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Technical Advisory Group Communication Channels Document

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 16. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Technical Advisory Group Scope of Expertise Document
- Technical Advisory Group Communication Channels Document

### 17. Hold the initial Technical Advisory Group kick-off meeting to review project plans and specifications, identify key technical risks, and establish a review process for technical documents.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Identified Key Technical Risks
- Established Review Process for Technical Documents

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 18. Legal Counsel defines the scope of authority for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Scope of Authority Document

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 19. Compliance Officer establishes reporting mechanisms for the Ethics & Compliance Committee.

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Reporting Mechanisms Document

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 20. Independent Ethics Advisor develops ethical guidelines for the Ethics & Compliance Committee.

**Responsible Body/Role:** Independent Ethics Advisor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Ethical Guidelines Document

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 21. Legal Counsel reviews relevant regulations and standards for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Relevant Regulations and Standards Document

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 22. Compliance Officer establishes investigation procedures for the Ethics & Compliance Committee.

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Investigation Procedures Document

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 23. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Ethics & Compliance Committee Scope of Authority Document
- Ethics & Compliance Committee Reporting Mechanisms Document
- Ethics & Compliance Committee Ethical Guidelines Document
- Ethics & Compliance Committee Relevant Regulations and Standards Document
- Ethics & Compliance Committee Investigation Procedures Document

### 24. Hold the initial Ethics & Compliance Committee kick-off meeting to review the scope of authority, reporting mechanisms, ethical guidelines, relevant regulations and standards, and investigation procedures.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 25. Marketing/Sales Person identifies key stakeholders for the Stakeholder Engagement Group.

**Responsible Body/Role:** Marketing/Sales Person

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Key Stakeholders List

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 26. Marketing/Sales Person develops communication channels for the Stakeholder Engagement Group.

**Responsible Body/Role:** Marketing/Sales Person

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Communication Channels Document

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 27. Community Liaison Officer establishes feedback mechanisms for the Stakeholder Engagement Group.

**Responsible Body/Role:** Community Liaison Officer

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Feedback Mechanisms Document

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 28. Marketing/Sales Person defines roles and responsibilities for the Stakeholder Engagement Group.

**Responsible Body/Role:** Marketing/Sales Person

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Roles and Responsibilities Document

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 29. Marketing/Sales Person develops a stakeholder engagement plan for the Stakeholder Engagement Group.

**Responsible Body/Role:** Marketing/Sales Person

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Stakeholder Engagement Plan

**Dependencies:**

- Project Plan Approved
- Governance Bodies Defined

### 30. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Stakeholder Engagement Group Key Stakeholders List
- Stakeholder Engagement Group Communication Channels Document
- Stakeholder Engagement Group Feedback Mechanisms Document
- Stakeholder Engagement Group Roles and Responsibilities Document
- Stakeholder Engagement Group Stakeholder Engagement Plan

### 31. Hold the initial Stakeholder Engagement Group kick-off meeting to review the stakeholder engagement plan, communication channels, feedback mechanisms, and roles and responsibilities.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda