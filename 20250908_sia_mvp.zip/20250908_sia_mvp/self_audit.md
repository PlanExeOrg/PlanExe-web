Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 15 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 4 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not describe any technology or system that violates the laws of physics. The plan focuses on regulatory actions, data analysis, and AI, which are all within the realm of possibility.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (AI-driven regulatory platform) + market (energy market regulation) + tech/process (consequence auditing) + policy (regulatory interventions) without independent evidence at comparable scale. There is no mention of a precedent for this specific combination.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Each track must produce one authoritative source or a supervised pilot showing results vs a baseline. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Project Manager / Validation Report / 90 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks definitions with business-level mechanisms-of-action, owners, and measurable outcomes for key strategic concepts. For example, "Shared Intelligence Asset" is not defined in terms of inputs→process→customer value.

**Mitigation**: Project Team: Create one-pagers for 'Shared Intelligence Asset', 'Consequence Audit & Scores', and 'Binding Use Charter' with value hypotheses, success metrics, and decision hooks by 2026-Jul-21.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies several risks (regulatory, technical, financial, etc.) and includes mitigation plans. However, it doesn't explicitly analyze risk cascades or second-order effects. For example, Risk 1 (Regulatory & Permitting) doesn't cascade to Financial or Operational risks.

**Mitigation**: Project Manager: Expand the risk register to include cascade effects and second-order risks, and add controls with a review cadence by 2026-Jul-21.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not include a permit/approval matrix. The plan mentions "Regulatory & Permitting" as a risk, but lacks a comprehensive list of required permits, lead times, and dependencies. "Engage early with regulatory bodies" is insufficient.

**Mitigation**: Regulatory Liaison: Create a permit/approval matrix with required permits, lead times, dependencies, and NO-GO thresholds by 2026-Jul-21.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not include a dated financing plan listing sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates. The plan mentions a CHF 15 million budget, but lacks details on funding sources, draw schedule, and covenants.

**Mitigation**: Project Manager: Develop a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO-GO on missed financing gates by 2026-Jul-21.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks scale-appropriate benchmarks for a CHF 15 million project. There are no vendor quotes or per-area cost normalizations. The plan does not include benchmarks or quotes to substantiate the budget.

**Mitigation**: Project Manager: Benchmark (≥3), obtain quotes, normalize per-area (m²/ft²), and adjust budget or de-scope by 2026-Aug-01.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., completion dates) as single numbers without providing a range or discussing alternative scenarios. For example, the goal statement mentions a "30 months" timeframe without any sensitivity analysis.

**Mitigation**: Project Manager: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the 30-month completion timeframe by 2026-Jul-21.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for build-critical components. There are no technical specs, interface definitions, test plans, or an integration map. The plan mentions "Establish CAS v0.1" but lacks details.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates by 2026-Aug-21.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes several claims without providing verifiable evidence. For example, the plan states: "The project is achievable given the CHF 15 million budget... in Switzerland" but provides no evidence of this.

**Mitigation**: Project Manager: Compile an evidence pack with artifacts (documents/links/IDs) to support key claims by 2026-Jul-21.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "a Shared Intelligence Asset MVP" without specific, verifiable qualities. The SMART criteria are high-level but lack concrete, quantifiable KPIs for the final deliverable.

**Mitigation**: Project Team: Define SMART criteria for the Shared Intelligence Asset MVP, including a KPI for decision-quality lift (e.g., 15% improvement) by 2026-Jul-21.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'Architectural Resilience Strategy' as a decision lever. While important, it does not directly support the core project goals of improving regulatory decision-making or enhancing transparency.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of the 'Architectural Resilience Strategy', complete with a KPI, owner, and estimated cost, or move the feature to the project backlog by 2026-Jul-21.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a 'Normative Charter Guardian' to ensure ethical actions score GREEN. This role requires expertise in ethics, AI, and regulation, making it a unicorn role. The plan does not validate the availability of such talent.

**Mitigation**: HR: Conduct a talent market analysis for the 'Normative Charter Guardian' role, assessing the availability of candidates with the required expertise by 2026-Jul-21.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions compliance with GDPR, Swiss FADP, and energy market regulations, but lacks a regulatory matrix mapping authorities, artifacts, lead times, and predecessors. There is no fatal-flaw analysis.

**Mitigation**: Regulatory Liaison: Develop a regulatory matrix (authority, artifact, lead time, predecessors) and conduct a fatal-flaw analysis by 2026-Jul-21.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions a "sustainability plan" but lacks specifics on funding, maintenance, and technology obsolescence. The plan mentions "Lack of funding for maintenance" as a risk, but does not detail a funding strategy.

**Mitigation**: Project Manager: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession planning, and technology roadmap by 2026-Aug-21.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies Switzerland (Zurich, Geneva, Lausanne) as physical locations, but lacks zoning/land-use verification, occupancy/egress, fire load, structural limits, noise, and permit feasibility. There is no fatal-flaw screen with authorities.

**Mitigation**: Project Manager: Perform a fatal-flaw screen with authorities/experts regarding zoning/land-use, occupancy/egress, fire load, structural limits, noise, and permits for the identified locations by 2026-Aug-21.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions a "single sovereign cloud region" and "hybrid cloud approach" but lacks details on redundancy, failover testing, SLAs, or vendor lock-in mitigation. The plan mentions "Reliance on a single cloud provider" as a risk.

**Mitigation**: Infrastructure Team: Secure SLAs with the cloud provider, add a secondary cloud region, and test failover procedures by 2026-Oct-21.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan states goals for the Regulator (improve decision-making) and the R&D Team (long-term innovation) but lacks alignment. The Regulator is incentivized by short-term compliance, while R&D is incentivized by long-term innovation.

**Mitigation**: Project Manager: Create a shared, measurable objective (OKR) that aligns both the Regulator and R&D Team on a common outcome, such as a specific improvement in regulatory effectiveness by 2026-Jul-21.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a change-control process. Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board with thresholds (when to re-plan/stop) by 2026-Jul-21.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies several high risks (Technical, Data Rights & Governance, Governance & Accountability) but lacks a cross-impact analysis. A failure in Data Rights could trigger Technical failures due to data limitations, cascading into Governance issues.

**Mitigation**: Project Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by 2026-Aug-21.