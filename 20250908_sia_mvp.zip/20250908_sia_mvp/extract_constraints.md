## Positive Constraints

- Shared Intelligence Asset MVP
- One regulator
- One jurisdiction
- Energy-market interventions only
- Advisory use first
- Binding Use Charter considered after measured decision-quality lift
- Structured schema for all qualifying actions
- Consequence Audit & Score (CAS 0.1–10.0)
- Stoplight (GREEN/AMBER/RED) across Human Stability, Economic Resilience, Ecological Integrity, Rights/Legality
- Writes results to a signed, append-only public log within ≤7 days
- ≤48h emergencies
- Public super-majority override with independent review and multilingual rationale required on RED
- CAS v0.1 published (dimensions, weights, aggregation rule, uncertainty bands, stoplight mapping, provenance & change control) before any data/model work
- Data Rights First (source inventory, licenses, DPIAs, de-ID, retention
- Architecture v1 in a single sovereign cloud region with per-tenant KMS/HSM, zero-trust, insider-threat controls, and tamper-evident signed logs
- Models & Validation (baselines + independent calibration audit, model cards, abuse-case red-teaming)
- Portal & Process (reproducible CAS runs, human-in-the-loop review, appeals SLA, Rapid Response corridors for provisional CAS in minutes, one-page Executive Threat Brief: headline stoplight, most-likely outcome, tail-risk, mitigation to flip AMBER→GREEN)
- KPIs: calibration (Brier), discrimination (AUC), decision lift vs human-only baseline, and latency (P50/P95)
- Independent council (judiciary, civil society, domain scientists, security, technical auditors)
- AI registry
- Algorithmic Impact Assessments
- Continuous monitoring
- Kill-switches for drift, audit failure, or governance breach
- Overrides ≤10%/yr, each with public rationale, dissent notes, and appeals
- Normative Charter ensures actions that are “effective” yet unethical can’t score GREEN
- Adoption is pull-based (transparency reports; optional insurer/creditor benefits for mitigations)
- Timeline: 30 months
- Location: Switzerland
- Budget: CHF 15 million
- Project start ASAP

## Negative Constraints

- No clean licenses/DPIAs → no ingestion
- No blockchain
- Avoid multi-bloc federation
- Avoid physical data centers
- Avoid blockchain
- Avoid broad “2005–2025 everything” ingest
