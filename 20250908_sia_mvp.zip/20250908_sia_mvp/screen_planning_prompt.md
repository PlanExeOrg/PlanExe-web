**Verdict:** 🟢 USABLE

**Rationale:** This prompt describes a concrete project with specific details about its goals, architecture, governance, timeline, location, and budget. It provides enough information to generate a multi-step plan.