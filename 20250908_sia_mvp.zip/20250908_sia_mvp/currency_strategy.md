This plan involves money.

## Currencies

- **CHF:** The project budget is specified in Swiss Francs.

**Primary currency:** CHF

**Currency strategy:** The Swiss Franc will be used for all transactions, and no additional international risk management is needed.