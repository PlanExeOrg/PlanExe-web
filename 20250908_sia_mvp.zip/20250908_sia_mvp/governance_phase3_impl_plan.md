### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**


### 2. Project Manager circulates Draft SteerCo ToR v0.1 for review by Senior Regulatory Representative, Chief Technology Officer (or delegate), Chief Legal Officer (or delegate), and Independent External Advisor (Energy Market Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager finalizes SteerCo ToR based on feedback and submits to Executive Leadership Team for approval.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Executive Leadership Team formally approves the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Executive Leadership Team

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Executive Leadership Team formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** Executive Leadership Team

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SteerCo ToR v1.0

### 6. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Email

### 7. Hold the initial Project Steering Committee kick-off meeting to review project goals, governance structure, and initial project plan.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 8. Project Manager defines roles and responsibilities for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Roles and Responsibilities Document

**Dependencies:**


### 9. Project Manager establishes communication protocols and sets up project management tools for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Communication Protocols Document
- Project Management Tool Access

**Dependencies:**

- Core Project Team Roles and Responsibilities Document

### 10. Project Manager develops a detailed project schedule and establishes a risk management plan for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Detailed Project Schedule
- Risk Management Plan

**Dependencies:**

- Communication Protocols Document
- Project Management Tool Access

### 11. Project Manager schedules the initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Detailed Project Schedule
- Risk Management Plan

### 12. Hold the initial Core Project Team kick-off meeting to review project goals, roles, responsibilities, and project schedule.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 13. Project Manager defines the scope of advisory services for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Technical Advisory Group Scope Document

**Dependencies:**


### 14. Project Manager, in consultation with the Project Steering Committee, identifies and recruits technical experts for the Technical Advisory Group (Independent AI Expert, Data Governance Specialist, Cybersecurity Expert, Cloud Architecture Specialist).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- List of TAG Members
- Appointment Letters

**Dependencies:**

- Technical Advisory Group Scope Document
- Project Steering Committee established

### 15. Project Manager establishes communication channels and sets up a meeting schedule for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Communication Channels Established
- Meeting Schedule

**Dependencies:**

- List of TAG Members

### 16. Project Manager reviews project technical documentation with the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Reviewed Technical Documentation

**Dependencies:**

- Communication Channels Established
- Meeting Schedule

### 17. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Reviewed Technical Documentation

### 18. Hold the initial Technical Advisory Group kick-off meeting to review project goals, scope of advisory services, and technical documentation.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 19. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**


### 20. Project Manager circulates Draft Ethics & Compliance Committee ToR v0.1 for review by Legal Counsel (Data Privacy Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 21. Project Manager finalizes Ethics & Compliance Committee ToR based on feedback and submits to Project Steering Committee for approval.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary
- Project Steering Committee established

### 22. Project Steering Committee formally approves the Ethics & Compliance Committee Terms of Reference.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Approved Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 23. Project Steering Committee formally appoints the Chair of the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved Ethics & Compliance Committee ToR v1.0

### 24. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Email

### 25. Hold the initial Ethics & Compliance Committee kick-off meeting to review project goals, governance structure, and ethical guidelines.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 26. Project Manager identifies key stakeholders for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- List of Key Stakeholders

**Dependencies:**


### 27. Project Manager develops a communication strategy for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Communication Strategy Document

**Dependencies:**

- List of Key Stakeholders

### 28. Project Manager establishes communication channels and sets up a meeting schedule for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Communication Channels Established
- Meeting Schedule

**Dependencies:**

- Communication Strategy Document

### 29. Project Manager defines feedback mechanisms for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Feedback Mechanisms Defined

**Dependencies:**

- Communication Channels Established
- Meeting Schedule

### 30. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Feedback Mechanisms Defined

### 31. Hold the initial Stakeholder Engagement Group kick-off meeting to review project goals, communication strategy, and feedback mechanisms.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 32. Project Manager drafts initial Terms of Reference (ToR) for the Independent Council.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Draft Independent Council ToR v0.1

**Dependencies:**


### 33. Project Manager circulates Draft Independent Council ToR v0.1 for review by Legal Counsel and Ethics Officer.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Independent Council ToR v0.1

### 34. Project Manager finalizes Independent Council ToR based on feedback and submits to Executive Leadership Team for approval.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Final Independent Council ToR v1.0

**Dependencies:**

- Feedback Summary

### 35. Executive Leadership Team formally approves the Independent Council Terms of Reference.

**Responsible Body/Role:** Executive Leadership Team

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Approved Independent Council ToR v1.0

**Dependencies:**

- Final Independent Council ToR v1.0

### 36. Executive Leadership Team appoints members to the Independent Council from the judiciary, civil society, domain scientists, security, and technical auditors.

**Responsible Body/Role:** Executive Leadership Team

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- List of Independent Council Members
- Appointment Letters

**Dependencies:**

- Approved Independent Council ToR v1.0

### 37. Project Manager schedules the initial Independent Council kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- List of Independent Council Members

### 38. Hold the initial Independent Council kick-off meeting to review project goals, governance structure, and define the override approval process.

**Responsible Body/Role:** Independent Council

**Suggested Timeframe:** Project Week 14

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda