### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance for the project, ensuring alignment with organizational goals and regulatory requirements, given the project's complexity and high-impact nature.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic direction and guidance.
- Monitor project progress against key milestones and KPIs.
- Approve major changes to project scope, budget, or timeline (above CHF 250,000).
- Oversee risk management and mitigation strategies.
- Ensure alignment with regulatory requirements and ethical standards.
- Resolve strategic conflicts and escalate issues as needed.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define decision-making process.
- Review and approve initial project plan.

**Membership:**

- Senior Regulatory Representative
- Chief Technology Officer (or delegate)
- Chief Legal Officer (or delegate)
- Independent External Advisor (Energy Market Expert)
- Project Manager (ex-officio, non-voting)

**Decision Rights:** Strategic decisions related to project scope, budget (above CHF 250,000), timeline, and strategic risks.

**Decision Mechanism:** Majority vote, with the Chair having the tie-breaking vote. Any dissenting opinions must be formally recorded.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion of key risks and mitigation strategies.
- Approval of change requests (above CHF 250,000).
- Review of financial performance.
- Discussion of strategic issues and opportunities.

**Escalation Path:** Executive Leadership Team
### 2. Core Project Team

**Rationale for Inclusion:** Manages the day-to-day execution of the project, ensuring tasks are completed on time and within budget.  Essential for operational efficiency and project delivery.

**Responsibilities:**

- Develop and maintain project plan.
- Manage project budget (below CHF 250,000) and resources.
- Track project progress and report status to the Steering Committee.
- Identify and manage project risks and issues.
- Coordinate project activities across different teams.
- Ensure adherence to project standards and processes.
- Implement change requests (below CHF 250,000).

**Initial Setup Actions:**

- Define roles and responsibilities.
- Establish communication protocols.
- Set up project management tools.
- Develop detailed project schedule.
- Establish risk management plan.

**Membership:**

- Project Manager
- Lead Data Scientist
- Lead Software Engineer
- Security Lead
- Regulatory Compliance Lead

**Decision Rights:** Operational decisions related to project execution, resource allocation (below CHF 250,000), and risk management (below strategic thresholds).

**Decision Mechanism:** Consensus-based decision-making, with the Project Manager having the final say in case of disagreements.  Documented rationale required for all decisions.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of progress against tasks.
- Discussion of current risks and issues.
- Coordination of activities across teams.
- Review of budget and resource utilization.
- Planning for upcoming tasks.

**Escalation Path:** Project Steering Committee
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and guidance on AI model development, data governance, and system architecture, ensuring the project leverages best practices and avoids technical pitfalls.

**Responsibilities:**

- Review and provide feedback on AI model design and validation.
- Advise on data governance and security best practices.
- Evaluate system architecture and provide recommendations for improvement.
- Assess technical risks and propose mitigation strategies.
- Conduct technical audits and reviews.
- Ensure compliance with technical standards and regulations.

**Initial Setup Actions:**

- Define scope of advisory services.
- Identify and recruit technical experts.
- Establish communication channels.
- Set up meeting schedule.
- Review project technical documentation.

**Membership:**

- Independent AI Expert
- Data Governance Specialist
- Cybersecurity Expert
- Cloud Architecture Specialist
- Lead Data Scientist (ex-officio, non-voting)
- Lead Software Engineer (ex-officio, non-voting)

**Decision Rights:** Advisory role on technical matters, with recommendations considered by the Core Project Team and Steering Committee.

**Decision Mechanism:** Consensus-based recommendations, with dissenting opinions documented and presented to the Core Project Team and Steering Committee.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of AI model performance and validation results.
- Discussion of data governance and security issues.
- Evaluation of system architecture and scalability.
- Assessment of technical risks and mitigation strategies.
- Review of technical standards and regulations.

**Escalation Path:** Project Steering Committee
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures the project adheres to ethical principles, data privacy regulations (GDPR, FADP), and other relevant compliance requirements, safeguarding public trust and minimizing legal risks.

**Responsibilities:**

- Oversee compliance with GDPR, FADP, and other relevant regulations.
- Conduct ethical reviews of AI models and algorithms.
- Develop and implement data privacy policies and procedures.
- Monitor data usage and access controls.
- Investigate and resolve compliance violations.
- Provide training on ethical and compliance issues.
- Review and approve Data Protection Impact Assessments (DPIAs).

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define ethical guidelines.
- Develop compliance framework.

**Membership:**

- Legal Counsel (Data Privacy Expert)
- Ethics Officer
- Regulatory Compliance Lead
- Independent External Advisor (Ethics in AI)
- Data Governance Specialist (ex-officio, non-voting)

**Decision Rights:** Authority to enforce compliance with ethical guidelines and data privacy regulations.  Can halt project activities if ethical or compliance breaches are identified.

**Decision Mechanism:** Majority vote, with the Chair having the tie-breaking vote. All decisions and dissenting opinions must be formally recorded.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of compliance with GDPR and FADP.
- Discussion of ethical issues related to AI models.
- Review of data privacy policies and procedures.
- Investigation of compliance violations.
- Approval of Data Protection Impact Assessments (DPIAs).

**Escalation Path:** Executive Leadership Team
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Facilitates communication and collaboration with key stakeholders, including energy market participants, civil society organizations, and the public, ensuring transparency and addressing concerns related to the project's impact.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct regular meetings and consultations with stakeholders.
- Gather feedback from stakeholders on project progress and impact.
- Address stakeholder concerns and grievances.
- Communicate project information to the public.
- Organize public consultations and workshops.
- Prepare and disseminate transparency reports.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop communication strategy.
- Establish communication channels.
- Set up meeting schedule.
- Define feedback mechanisms.

**Membership:**

- Communications Manager
- Public Relations Officer
- Representative from Civil Society Organization
- Representative from Energy Market Participants
- Project Manager (ex-officio, non-voting)

**Decision Rights:** Advisory role on stakeholder engagement strategies and communication plans.  Responsible for ensuring stakeholder feedback is considered in project decisions.

**Decision Mechanism:** Consensus-based recommendations, with dissenting opinions documented and presented to the Core Project Team and Steering Committee.

**Meeting Cadence:** Bi-monthly

**Typical Agenda Items:**

- Review of stakeholder engagement plan.
- Discussion of stakeholder feedback and concerns.
- Planning for upcoming consultations and workshops.
- Preparation of transparency reports.
- Review of communication materials.

**Escalation Path:** Project Steering Committee
### 6. Independent Council

**Rationale for Inclusion:** Provides independent oversight of the AI registry, algorithmic impact assessments, continuous monitoring, and kill-switches, ensuring accountability and preventing bias or abuse of the system.

**Responsibilities:**

- Oversee the AI registry and algorithmic impact assessments.
- Monitor the system for drift, audit failure, or governance breaches.
- Approve or reject override requests.
- Review and approve the Normative Charter.
- Ensure transparency and accountability in the system's operations.
- Conduct periodic audits of the system's performance and impact.
- Exercise kill-switch authority when necessary.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint members from judiciary, civil society, domain scientists, security, and technical auditors.
- Establish meeting schedule.
- Define override approval process.
- Develop monitoring procedures.

**Membership:**

- Representative from the Judiciary
- Representative from Civil Society
- Domain Scientist (Energy Market Expert)
- Security Expert
- Technical Auditor
- Ethics Officer (ex-officio, non-voting)

**Decision Rights:** Authority to approve or reject override requests, approve the Normative Charter, and exercise kill-switch authority.  Decisions are binding and subject only to appeal to the Executive Leadership Team.

**Decision Mechanism:** Super-majority vote (80%) required for override approvals and kill-switch activation.  All decisions and dissenting opinions must be formally recorded and made public.

**Meeting Cadence:** Quarterly (or more frequently as needed)

**Typical Agenda Items:**

- Review of AI registry and algorithmic impact assessments.
- Monitoring of system performance and drift.
- Review of override requests and justifications.
- Discussion of ethical and governance issues.
- Audit of system performance and impact.
- Review of the Normative Charter.

**Escalation Path:** Executive Leadership Team