**Overall Adherence: 93%**

```
IMPORTANCE_ADHERENCE_SUM = (5×5 + 5×5 + 5×5 + 4×5 + 3×5 + 5×5 + 5×1 + 5×5 + 5×5 + 5×5 + 5×5 + 4×5 + 5×5) = 285
IMPORTANCE_SUM = 5 + 5 + 5 + 4 + 3 + 5 + 5 + 5 + 5 + 5 + 5 + 4 + 5 = 61
OVERALL_ADHERENCE = IMPORTANCE_ADHERENCE_SUM / (IMPORTANCE_SUM × 5) = 285 / 305 = 93%
```

## Summary

| ID | Directive | Type | Importance | Adherence | Category |
|----|-----------|------|------------|-----------|----------|
| 1 | Build a Shared Intelligence Asset MVP. | Requirement | 5/5 | 5/5 | Fully honored |
| 2 | One regulator, one jurisdiction. | Constraint | 5/5 | 5/5 | Fully honored |
| 3 | Energy-market interventions only. | Constraint | 5/5 | 5/5 | Fully honored |
| 4 | Advisory use first. | Requirement | 4/5 | 5/5 | Fully honored |
| 5 | Binding Use Charter considered after measured decision-quality lift. | Requirement | 3/5 | 5/5 | Fully honored |
| 6 | System returns a Consequence Audit & Score (CAS 0.1–10.0) with a stoplight. | Requirement | 5/5 | 5/5 | Fully honored |
| 7 | Results written to a signed, append-only public log within ≤7 days (≤48h emergencies). | Constraint | 5/5 | 1/5 | Ignored |
| 8 | No blockchain. | Banned | 5/5 | 5/5 | Fully honored |
| 9 | Timeline: 30 months. | Constraint | 5/5 | 5/5 | Fully honored |
| 10 | Location: Switzerland. | Constraint | 5/5 | 5/5 | Fully honored |
| 11 | Budget: CHF 15 million. | Constraint | 5/5 | 5/5 | Fully honored |
| 12 | MVP non-goals: multi-bloc federation, physical data centers. | Banned | 4/5 | 5/5 | Fully honored |
| 13 | Build with hard gates. | Requirement | 5/5 | 5/5 | Fully honored |

## Issues

### Issue 7 - Results written to a signed, append-only public log within ≤7 days (≤48h emergencies).

- **Category:** Ignored
- **Adherence:** 1/5
- **Importance:** 5/5
- **Evidence:** 
- **Explanation:** The plan does not mention writing results to a signed, append-only public log within the specified timeframes.
